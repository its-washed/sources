// Chunk 96 - 50 functions

// ============================================================
// Function: FUN_180147f6a
// Address: 0x180147f6a
// Size: 608 bytes
// ============================================================
void fcn.180147f6a(int64_t arg_30h, int64_t arg_50h)
{
    uint32_t uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    char in_CL;
    int64_t iVar8;
    int64_t unaff_RBX;
    int64_t unaff_RDI;
    undefined4 in_XMM0_Da;
    float fVar9;
    float fVar10;
    int64_t var_20h;
    
    if ((((in_CL == '\0') || (*(int32_t *)(unaff_RBX + 0x22c8) != 0)) || (*(int32_t *)(unaff_RBX + 0x2338) != 0)) ||
       ((1 < *(uint32_t *)(unaff_RBX + 0x2288) ||
        (iVar6 = *(int64_t *)(unaff_RBX + 0x21d8), (*(uint32_t *)(iVar6 + 0x14) & 0x10000000) == 0)))) {
        if ((*(int64_t *)(unaff_RBX + 0x21d8) == unaff_RDI) &&
           ((in_CL != '\0' && (*(int32_t *)(unaff_RBX + 0x21e4) == *(int32_t *)(unaff_RDI + 0x1b0))))) {
            *(uint32_t *)(unaff_RBX + 0x227c) = *(uint32_t *)(unaff_RBX + 0x227c) & 0xfffffff4;
            *(uint32_t *)(unaff_RBX + 0x227c) = *(uint32_t *)(unaff_RBX + 0x227c) | 4;
        }
    } else {
        iVar8 = *(int64_t *)(iVar6 + 0x408);
        while ((iVar8 != 0 && (iVar7 = *(int64_t *)(iVar6 + 0x408), (*(uint32_t *)(iVar7 + 0x14) & 0x10000000) != 0))) {
            iVar8 = *(int64_t *)(iVar7 + 0x408);
            iVar6 = iVar7;
        }
        if (((*(int64_t *)(iVar6 + 0x408) == unaff_RDI) && (*(int32_t *)(iVar6 + 0x218) == 0)) &&
           ((*(uint8_t *)(unaff_RBX + 0x227c) & 0x80) == 0)) {
            func_0x00018010e050(in_XMM0_Da, 0);
            func_0x00018010e3f0(*(undefined4 *)(unaff_RDI + 0x454), 1, 0, unaff_RDI + 0x468);
            if (*(char *)(unaff_RBX + 0x21cc) != '\0') {
                *(undefined *)(unaff_RBX + 0x21cc) = 0;
                *(undefined *)(unaff_RBX + 0x2238) = 2;
            }
            iVar6 = *(int64_t *)0x180781f28;
            uVar1 = *(uint32_t *)(unaff_RBX + 0x227c);
            uVar2 = *(undefined4 *)(unaff_RBX + 0x2280);
            uVar3 = *(undefined4 *)(unaff_RBX + 0x2290);
            uVar4 = *(undefined4 *)(unaff_RBX + 0x2288);
            *(undefined2 *)(unaff_RBX + 0x21cd) = 0x101;
            *(undefined2 *)(iVar6 + 0x2278) = 0;
            *(undefined *)(iVar6 + 0x227a) = 1;
            *(bool *)(iVar6 + 0x2239) = *(char *)(iVar6 + 0x223a) != '\0';
            *(uint32_t *)(iVar6 + 0x227c) = uVar1 | 0x80;
            *(undefined4 *)(iVar6 + 0x2288) = uVar4;
            *(undefined4 *)(iVar6 + 0x2290) = uVar3;
            *(undefined4 *)(iVar6 + 0x2280) = uVar2;
        }
    }
    func_0x0001800fc8f0();
    iVar5 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar5 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar5 + -1;
    }
    *(float *)(unaff_RDI + 0x1bc) = *(float *)(unaff_RDI + 0x158) - *(float *)(unaff_RDI + 0x60);
    iVar8 = (int64_t)*(int32_t *)(unaff_RBX + 0x2110) * 0x3c;
    iVar6 = *(int64_t *)(unaff_RBX + 0x2118);
    uVar2 = *(undefined4 *)(iVar8 + -0x30 + iVar6);
    uVar3 = *(undefined4 *)(iVar8 + -0x2c + iVar6);
    *(undefined *)(iVar8 + -4 + iVar6) = 0;
    fVar10 = *(float *)(unaff_RDI + 0x170) - *(float *)(unaff_RDI + 0xd4);
    fVar9 = *(float *)(unaff_RDI + 0x178);
    if (*(float *)(unaff_RDI + 0x178) <= fVar10) {
        fVar9 = fVar10;
    }
    *(float *)(unaff_RDI + 0x178) = fVar9;
    func_0x00018010c110();
    *(undefined4 *)(unaff_RDI + 0x170) = uVar2;
    *(undefined4 *)(unaff_RDI + 0x174) = uVar3;
    *(undefined4 *)(unaff_RDI + 0x214) = 1;
    *(undefined *)(unaff_RDI + 0x198) = 0;
    *(undefined4 *)(unaff_RDI + 0x1b0) = 0;
    *(undefined *)(unaff_RDI + 0x1bb) = 0;
    return;
}

// ============================================================
// Function: FUN_1801481ca
// Address: 0x1801481ca
// Size: 11 bytes
// ============================================================
void fcn.180147f6a(int64_t arg_30h, int64_t arg_50h)
{
    uint32_t uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    char in_CL;
    int64_t iVar8;
    int64_t unaff_RBX;
    int64_t unaff_RDI;
    undefined4 in_XMM0_Da;
    float fVar9;
    float fVar10;
    int64_t var_20h;
    
    if ((((in_CL == '\0') || (*(int32_t *)(unaff_RBX + 0x22c8) != 0)) || (*(int32_t *)(unaff_RBX + 0x2338) != 0)) ||
       ((1 < *(uint32_t *)(unaff_RBX + 0x2288) ||
        (iVar6 = *(int64_t *)(unaff_RBX + 0x21d8), (*(uint32_t *)(iVar6 + 0x14) & 0x10000000) == 0)))) {
        if ((*(int64_t *)(unaff_RBX + 0x21d8) == unaff_RDI) &&
           ((in_CL != '\0' && (*(int32_t *)(unaff_RBX + 0x21e4) == *(int32_t *)(unaff_RDI + 0x1b0))))) {
            *(uint32_t *)(unaff_RBX + 0x227c) = *(uint32_t *)(unaff_RBX + 0x227c) & 0xfffffff4;
            *(uint32_t *)(unaff_RBX + 0x227c) = *(uint32_t *)(unaff_RBX + 0x227c) | 4;
        }
    } else {
        iVar8 = *(int64_t *)(iVar6 + 0x408);
        while ((iVar8 != 0 && (iVar7 = *(int64_t *)(iVar6 + 0x408), (*(uint32_t *)(iVar7 + 0x14) & 0x10000000) != 0))) {
            iVar8 = *(int64_t *)(iVar7 + 0x408);
            iVar6 = iVar7;
        }
        if (((*(int64_t *)(iVar6 + 0x408) == unaff_RDI) && (*(int32_t *)(iVar6 + 0x218) == 0)) &&
           ((*(uint8_t *)(unaff_RBX + 0x227c) & 0x80) == 0)) {
            func_0x00018010e050(in_XMM0_Da, 0);
            func_0x00018010e3f0(*(undefined4 *)(unaff_RDI + 0x454), 1, 0, unaff_RDI + 0x468);
            if (*(char *)(unaff_RBX + 0x21cc) != '\0') {
                *(undefined *)(unaff_RBX + 0x21cc) = 0;
                *(undefined *)(unaff_RBX + 0x2238) = 2;
            }
            iVar6 = *(int64_t *)0x180781f28;
            uVar1 = *(uint32_t *)(unaff_RBX + 0x227c);
            uVar2 = *(undefined4 *)(unaff_RBX + 0x2280);
            uVar3 = *(undefined4 *)(unaff_RBX + 0x2290);
            uVar4 = *(undefined4 *)(unaff_RBX + 0x2288);
            *(undefined2 *)(unaff_RBX + 0x21cd) = 0x101;
            *(undefined2 *)(iVar6 + 0x2278) = 0;
            *(undefined *)(iVar6 + 0x227a) = 1;
            *(bool *)(iVar6 + 0x2239) = *(char *)(iVar6 + 0x223a) != '\0';
            *(uint32_t *)(iVar6 + 0x227c) = uVar1 | 0x80;
            *(undefined4 *)(iVar6 + 0x2288) = uVar4;
            *(undefined4 *)(iVar6 + 0x2290) = uVar3;
            *(undefined4 *)(iVar6 + 0x2280) = uVar2;
        }
    }
    func_0x0001800fc8f0();
    iVar5 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar5 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar5 + -1;
    }
    *(float *)(unaff_RDI + 0x1bc) = *(float *)(unaff_RDI + 0x158) - *(float *)(unaff_RDI + 0x60);
    iVar8 = (int64_t)*(int32_t *)(unaff_RBX + 0x2110) * 0x3c;
    iVar6 = *(int64_t *)(unaff_RBX + 0x2118);
    uVar2 = *(undefined4 *)(iVar8 + -0x30 + iVar6);
    uVar3 = *(undefined4 *)(iVar8 + -0x2c + iVar6);
    *(undefined *)(iVar8 + -4 + iVar6) = 0;
    fVar10 = *(float *)(unaff_RDI + 0x170) - *(float *)(unaff_RDI + 0xd4);
    fVar9 = *(float *)(unaff_RDI + 0x178);
    if (*(float *)(unaff_RDI + 0x178) <= fVar10) {
        fVar9 = fVar10;
    }
    *(float *)(unaff_RDI + 0x178) = fVar9;
    func_0x00018010c110();
    *(undefined4 *)(unaff_RDI + 0x170) = uVar2;
    *(undefined4 *)(unaff_RDI + 0x174) = uVar3;
    *(undefined4 *)(unaff_RDI + 0x214) = 1;
    *(undefined *)(unaff_RDI + 0x198) = 0;
    *(undefined4 *)(unaff_RDI + 0x1b0) = 0;
    *(undefined *)(unaff_RDI + 0x1bb) = 0;
    return;
}

// ============================================================
// Function: FUN_180148270
// Address: 0x180148270
// Size: 90 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_15e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_dech because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Removing arg arg_ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d9ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Removing arg arg_d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29ach because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2971h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.180148270(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    uint16_t uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    char cVar10;
    uint8_t uVar11;
    int32_t iVar12;
    undefined4 uVar13;
    float *pfVar14;
    int64_t iVar15;
    char *pcVar16;
    int32_t iVar17;
    float fVar18;
    float fVar19;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    float fVar20;
    undefined4 unaff_XMM11_Da;
    undefined4 unaff_XMM11_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_c0h;
    undefined4 uStack_b8;
    int64_t var_b4h;
    int64_t var_a8h;
    int64_t iVar21;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar9 = *(int64_t *)0x180781f28;
    uVar6 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar6 + 0x10b) = 1;
    iVar7 = *(int64_t *)(iVar9 + 0x15e0);
    if (*(char *)(iVar7 + 0x10e) != '\0') {
        return uVar6 & 0xffffffffffffff00;
    }
    fVar2 = *(float *)(iVar7 + 0x158);
    iVar21 = CONCAT44(unaff_XMM12_Dd, unaff_XMM12_Dc);
    fVar3 = *(float *)(iVar7 + 0x15c);
    pcVar16 = (char *)arg1;
    if (arg1 != -1) {
        while (cVar10 = *pcVar16, cVar10 != '\0') {
            pcVar16 = pcVar16 + 1;
            if (((cVar10 == '#') && (*pcVar16 == '#')) || (pcVar16 == (char *)0xffffffffffffffff)) break;
        }
    }
    fcn.1800fe0a0(CONCAT44(var_d8h._4_4_, 0xbf800000), arg2);
    cVar10 = fcn.1801481e0();
    iVar8 = *(int64_t *)0x180781f28;
    var_10h = CONCAT71((unkint7)((uint64_t)arg2 >> 8), cVar10);
    if (cVar10 != '\0') {
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 0x2000;
        piVar1 = (int32_t *)(iVar8 + 0x2100);
        uVar13 = *(undefined4 *)(iVar8 + 0x1f78);
        iVar12 = *(int32_t *)(iVar8 + 0x2104);
        if (*piVar1 == iVar12) {
            iVar17 = *piVar1 + 1;
            if (iVar12 == 0) {
                iVar12 = 8;
            } else {
                iVar12 = iVar12 / 2 + iVar12;
            }
            if (iVar17 < iVar12) {
                iVar17 = iVar12;
            }
            fcn.18011fb10(piVar1, iVar17);
        }
        *(undefined4 *)(*(int64_t *)(iVar8 + 0x2108) + (int64_t)*piVar1 * 4) = uVar13;
        *piVar1 = *piVar1 + 1;
    }
    fcn.180107590(arg1);
    if ((char)arg_28h == '\0') {
        fcn.180106080(1);
    }
    if (*(int32_t *)(iVar7 + 0x214) == 0) {
        *(float *)(iVar7 + 0x158) = (float)(int32_t)(*(float *)(iVar9 + 0xdec) * 0.5) + *(float *)(iVar7 + 0x158);
        fcn.1800f68b0(0xe, *(float *)(iVar9 + 0xdec) + *(float *)(iVar9 + 0xdec));
        uVar11 = fcn.180146c70(iVar21, CONCAT44(unaff_XMM11_Db, unaff_XMM11_Da));
        fcn.1800f6a20(1);
        if ((*(uint32_t *)(iVar9 + 0x1fc0) & 0x100) != 0) {
            fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
        }
        *(float *)(iVar7 + 0x158) = *(float *)(iVar7 + 0x158) - (float)(int32_t)(*(float *)(iVar9 + 0xdec) * 0.5);
    } else {
        if ((arg3 == 0) || (*(char *)arg3 == '\0')) {
            fVar19 = 0.0;
        } else {
            pfVar14 = (float *)fcn.1800fe0a0(CONCAT44(var_d8h._4_4_, 0xbf800000), var_10h);
            fVar19 = *pfVar14;
        }
        var_c0h._0_4_ = (float)fcn.180147e60(iVar7 + 0x1c4);
        iVar8 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        if ((*(int64_t *)(iVar8 + 0x208) != 0) || (iVar15 = 0x2d0, *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0) != 0))
        {
            iVar15 = 0x2a0;
        }
        fVar4 = *(float *)(iVar7 + 400);
        fVar18 = (*(float *)(iVar8 + iVar15) - *(float *)(iVar8 + 0x158)) - (float)var_c0h;
        var_c0h._4_4_ = var_c8h._4_4_;
        uVar11 = fcn.180146c70(iVar21, CONCAT44(unaff_XMM11_Db, unaff_XMM11_Da));
        if ((*(uint32_t *)(iVar9 + 0x1fc0) & 0x100) != 0) {
            fVar20 = 0.0;
            if (0.0 <= fVar18) {
                fVar20 = fVar18;
            }
            fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
            if (0.0 < fVar19) {
                fcn.1800f6710(0, iVar9 + 0xee0);
                iVar21 = *(int64_t *)0x180781f28;
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x180645b70;
                *(undefined8 *)(iVar21 + 0x2a28) = 0x1805ab2bc;
                fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
                fcn.1800f6770(1);
            }
            if ((char)placeholder_3 != '\0') {
                fVar19 = *(float *)(iVar9 + 0x12f8);
                var_c0h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed0);
                var_c0h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
                uStack_b8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
                var_b4h._0_4_ =
                     *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                uVar5 = *(uint16_t *)(iVar7 + 0x1d4);
                uVar13 = fcn.1800f5fa0(&var_c0h);
                fcn.1801303d0(*(undefined8 *)(iVar7 + 800), 
                              CONCAT44(fVar19 * 0.134 * 0.5 + fVar4 + fVar3, 
                                       (float)(uint32_t)uVar5 + fVar20 + fVar19 * 0.4 + fVar2), uVar13, fVar19 * 0.866);
            }
        }
    }
    if ((char)arg_28h == '\0') {
        fcn.180106130();
    }
    iVar12 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar12 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar12 + -1;
    }
    if (cVar10 != '\0') {
        fcn.180106030();
    }
    return (uint64_t)uVar11;
}

// ============================================================
// Function: FUN_1801482ca
// Address: 0x1801482ca
// Size: 281 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_15e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_dech because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Removing arg arg_ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d9ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Removing arg arg_d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29ach because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2971h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.180148270(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    uint16_t uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    char cVar10;
    uint8_t uVar11;
    int32_t iVar12;
    undefined4 uVar13;
    float *pfVar14;
    int64_t iVar15;
    char *pcVar16;
    int32_t iVar17;
    float fVar18;
    float fVar19;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    float fVar20;
    undefined4 unaff_XMM11_Da;
    undefined4 unaff_XMM11_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_c0h;
    undefined4 uStack_b8;
    int64_t var_b4h;
    int64_t var_a8h;
    int64_t iVar21;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar9 = *(int64_t *)0x180781f28;
    uVar6 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar6 + 0x10b) = 1;
    iVar7 = *(int64_t *)(iVar9 + 0x15e0);
    if (*(char *)(iVar7 + 0x10e) != '\0') {
        return uVar6 & 0xffffffffffffff00;
    }
    fVar2 = *(float *)(iVar7 + 0x158);
    iVar21 = CONCAT44(unaff_XMM12_Dd, unaff_XMM12_Dc);
    fVar3 = *(float *)(iVar7 + 0x15c);
    pcVar16 = (char *)arg1;
    if (arg1 != -1) {
        while (cVar10 = *pcVar16, cVar10 != '\0') {
            pcVar16 = pcVar16 + 1;
            if (((cVar10 == '#') && (*pcVar16 == '#')) || (pcVar16 == (char *)0xffffffffffffffff)) break;
        }
    }
    fcn.1800fe0a0(CONCAT44(var_d8h._4_4_, 0xbf800000), arg2);
    cVar10 = fcn.1801481e0();
    iVar8 = *(int64_t *)0x180781f28;
    var_10h = CONCAT71((unkint7)((uint64_t)arg2 >> 8), cVar10);
    if (cVar10 != '\0') {
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 0x2000;
        piVar1 = (int32_t *)(iVar8 + 0x2100);
        uVar13 = *(undefined4 *)(iVar8 + 0x1f78);
        iVar12 = *(int32_t *)(iVar8 + 0x2104);
        if (*piVar1 == iVar12) {
            iVar17 = *piVar1 + 1;
            if (iVar12 == 0) {
                iVar12 = 8;
            } else {
                iVar12 = iVar12 / 2 + iVar12;
            }
            if (iVar17 < iVar12) {
                iVar17 = iVar12;
            }
            fcn.18011fb10(piVar1, iVar17);
        }
        *(undefined4 *)(*(int64_t *)(iVar8 + 0x2108) + (int64_t)*piVar1 * 4) = uVar13;
        *piVar1 = *piVar1 + 1;
    }
    fcn.180107590(arg1);
    if ((char)arg_28h == '\0') {
        fcn.180106080(1);
    }
    if (*(int32_t *)(iVar7 + 0x214) == 0) {
        *(float *)(iVar7 + 0x158) = (float)(int32_t)(*(float *)(iVar9 + 0xdec) * 0.5) + *(float *)(iVar7 + 0x158);
        fcn.1800f68b0(0xe, *(float *)(iVar9 + 0xdec) + *(float *)(iVar9 + 0xdec));
        uVar11 = fcn.180146c70(iVar21, CONCAT44(unaff_XMM11_Db, unaff_XMM11_Da));
        fcn.1800f6a20(1);
        if ((*(uint32_t *)(iVar9 + 0x1fc0) & 0x100) != 0) {
            fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
        }
        *(float *)(iVar7 + 0x158) = *(float *)(iVar7 + 0x158) - (float)(int32_t)(*(float *)(iVar9 + 0xdec) * 0.5);
    } else {
        if ((arg3 == 0) || (*(char *)arg3 == '\0')) {
            fVar19 = 0.0;
        } else {
            pfVar14 = (float *)fcn.1800fe0a0(CONCAT44(var_d8h._4_4_, 0xbf800000), var_10h);
            fVar19 = *pfVar14;
        }
        var_c0h._0_4_ = (float)fcn.180147e60(iVar7 + 0x1c4);
        iVar8 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        if ((*(int64_t *)(iVar8 + 0x208) != 0) || (iVar15 = 0x2d0, *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0) != 0))
        {
            iVar15 = 0x2a0;
        }
        fVar4 = *(float *)(iVar7 + 400);
        fVar18 = (*(float *)(iVar8 + iVar15) - *(float *)(iVar8 + 0x158)) - (float)var_c0h;
        var_c0h._4_4_ = var_c8h._4_4_;
        uVar11 = fcn.180146c70(iVar21, CONCAT44(unaff_XMM11_Db, unaff_XMM11_Da));
        if ((*(uint32_t *)(iVar9 + 0x1fc0) & 0x100) != 0) {
            fVar20 = 0.0;
            if (0.0 <= fVar18) {
                fVar20 = fVar18;
            }
            fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
            if (0.0 < fVar19) {
                fcn.1800f6710(0, iVar9 + 0xee0);
                iVar21 = *(int64_t *)0x180781f28;
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x180645b70;
                *(undefined8 *)(iVar21 + 0x2a28) = 0x1805ab2bc;
                fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
                fcn.1800f6770(1);
            }
            if ((char)placeholder_3 != '\0') {
                fVar19 = *(float *)(iVar9 + 0x12f8);
                var_c0h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed0);
                var_c0h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
                uStack_b8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
                var_b4h._0_4_ =
                     *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                uVar5 = *(uint16_t *)(iVar7 + 0x1d4);
                uVar13 = fcn.1800f5fa0(&var_c0h);
                fcn.1801303d0(*(undefined8 *)(iVar7 + 800), 
                              CONCAT44(fVar19 * 0.134 * 0.5 + fVar4 + fVar3, 
                                       (float)(uint32_t)uVar5 + fVar20 + fVar19 * 0.4 + fVar2), uVar13, fVar19 * 0.866);
            }
        }
    }
    if ((char)arg_28h == '\0') {
        fcn.180106130();
    }
    iVar12 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar12 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar12 + -1;
    }
    if (cVar10 != '\0') {
        fcn.180106030();
    }
    return (uint64_t)uVar11;
}

// ============================================================
// Function: FUN_1801483e3
// Address: 0x1801483e3
// Size: 272 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_15e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_dech because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Removing arg arg_ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d9ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Removing arg arg_d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29ach because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2971h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.180148270(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    uint16_t uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    char cVar10;
    uint8_t uVar11;
    int32_t iVar12;
    undefined4 uVar13;
    float *pfVar14;
    int64_t iVar15;
    char *pcVar16;
    int32_t iVar17;
    float fVar18;
    float fVar19;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    float fVar20;
    undefined4 unaff_XMM11_Da;
    undefined4 unaff_XMM11_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_c0h;
    undefined4 uStack_b8;
    int64_t var_b4h;
    int64_t var_a8h;
    int64_t iVar21;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar9 = *(int64_t *)0x180781f28;
    uVar6 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar6 + 0x10b) = 1;
    iVar7 = *(int64_t *)(iVar9 + 0x15e0);
    if (*(char *)(iVar7 + 0x10e) != '\0') {
        return uVar6 & 0xffffffffffffff00;
    }
    fVar2 = *(float *)(iVar7 + 0x158);
    iVar21 = CONCAT44(unaff_XMM12_Dd, unaff_XMM12_Dc);
    fVar3 = *(float *)(iVar7 + 0x15c);
    pcVar16 = (char *)arg1;
    if (arg1 != -1) {
        while (cVar10 = *pcVar16, cVar10 != '\0') {
            pcVar16 = pcVar16 + 1;
            if (((cVar10 == '#') && (*pcVar16 == '#')) || (pcVar16 == (char *)0xffffffffffffffff)) break;
        }
    }
    fcn.1800fe0a0(CONCAT44(var_d8h._4_4_, 0xbf800000), arg2);
    cVar10 = fcn.1801481e0();
    iVar8 = *(int64_t *)0x180781f28;
    var_10h = CONCAT71((unkint7)((uint64_t)arg2 >> 8), cVar10);
    if (cVar10 != '\0') {
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 0x2000;
        piVar1 = (int32_t *)(iVar8 + 0x2100);
        uVar13 = *(undefined4 *)(iVar8 + 0x1f78);
        iVar12 = *(int32_t *)(iVar8 + 0x2104);
        if (*piVar1 == iVar12) {
            iVar17 = *piVar1 + 1;
            if (iVar12 == 0) {
                iVar12 = 8;
            } else {
                iVar12 = iVar12 / 2 + iVar12;
            }
            if (iVar17 < iVar12) {
                iVar17 = iVar12;
            }
            fcn.18011fb10(piVar1, iVar17);
        }
        *(undefined4 *)(*(int64_t *)(iVar8 + 0x2108) + (int64_t)*piVar1 * 4) = uVar13;
        *piVar1 = *piVar1 + 1;
    }
    fcn.180107590(arg1);
    if ((char)arg_28h == '\0') {
        fcn.180106080(1);
    }
    if (*(int32_t *)(iVar7 + 0x214) == 0) {
        *(float *)(iVar7 + 0x158) = (float)(int32_t)(*(float *)(iVar9 + 0xdec) * 0.5) + *(float *)(iVar7 + 0x158);
        fcn.1800f68b0(0xe, *(float *)(iVar9 + 0xdec) + *(float *)(iVar9 + 0xdec));
        uVar11 = fcn.180146c70(iVar21, CONCAT44(unaff_XMM11_Db, unaff_XMM11_Da));
        fcn.1800f6a20(1);
        if ((*(uint32_t *)(iVar9 + 0x1fc0) & 0x100) != 0) {
            fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
        }
        *(float *)(iVar7 + 0x158) = *(float *)(iVar7 + 0x158) - (float)(int32_t)(*(float *)(iVar9 + 0xdec) * 0.5);
    } else {
        if ((arg3 == 0) || (*(char *)arg3 == '\0')) {
            fVar19 = 0.0;
        } else {
            pfVar14 = (float *)fcn.1800fe0a0(CONCAT44(var_d8h._4_4_, 0xbf800000), var_10h);
            fVar19 = *pfVar14;
        }
        var_c0h._0_4_ = (float)fcn.180147e60(iVar7 + 0x1c4);
        iVar8 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        if ((*(int64_t *)(iVar8 + 0x208) != 0) || (iVar15 = 0x2d0, *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0) != 0))
        {
            iVar15 = 0x2a0;
        }
        fVar4 = *(float *)(iVar7 + 400);
        fVar18 = (*(float *)(iVar8 + iVar15) - *(float *)(iVar8 + 0x158)) - (float)var_c0h;
        var_c0h._4_4_ = var_c8h._4_4_;
        uVar11 = fcn.180146c70(iVar21, CONCAT44(unaff_XMM11_Db, unaff_XMM11_Da));
        if ((*(uint32_t *)(iVar9 + 0x1fc0) & 0x100) != 0) {
            fVar20 = 0.0;
            if (0.0 <= fVar18) {
                fVar20 = fVar18;
            }
            fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
            if (0.0 < fVar19) {
                fcn.1800f6710(0, iVar9 + 0xee0);
                iVar21 = *(int64_t *)0x180781f28;
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x180645b70;
                *(undefined8 *)(iVar21 + 0x2a28) = 0x1805ab2bc;
                fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
                fcn.1800f6770(1);
            }
            if ((char)placeholder_3 != '\0') {
                fVar19 = *(float *)(iVar9 + 0x12f8);
                var_c0h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed0);
                var_c0h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
                uStack_b8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
                var_b4h._0_4_ =
                     *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                uVar5 = *(uint16_t *)(iVar7 + 0x1d4);
                uVar13 = fcn.1800f5fa0(&var_c0h);
                fcn.1801303d0(*(undefined8 *)(iVar7 + 800), 
                              CONCAT44(fVar19 * 0.134 * 0.5 + fVar4 + fVar3, 
                                       (float)(uint32_t)uVar5 + fVar20 + fVar19 * 0.4 + fVar2), uVar13, fVar19 * 0.866);
            }
        }
    }
    if ((char)arg_28h == '\0') {
        fcn.180106130();
    }
    iVar12 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar12 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar12 + -1;
    }
    if (cVar10 != '\0') {
        fcn.180106030();
    }
    return (uint64_t)uVar11;
}

// ============================================================
// Function: FUN_1801484f3
// Address: 0x1801484f3
// Size: 259 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_15e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_dech because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Removing arg arg_ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d9ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Removing arg arg_d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29ach because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2971h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.180148270(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    uint16_t uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    char cVar10;
    uint8_t uVar11;
    int32_t iVar12;
    undefined4 uVar13;
    float *pfVar14;
    int64_t iVar15;
    char *pcVar16;
    int32_t iVar17;
    float fVar18;
    float fVar19;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    float fVar20;
    undefined4 unaff_XMM11_Da;
    undefined4 unaff_XMM11_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_c0h;
    undefined4 uStack_b8;
    int64_t var_b4h;
    int64_t var_a8h;
    int64_t iVar21;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar9 = *(int64_t *)0x180781f28;
    uVar6 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar6 + 0x10b) = 1;
    iVar7 = *(int64_t *)(iVar9 + 0x15e0);
    if (*(char *)(iVar7 + 0x10e) != '\0') {
        return uVar6 & 0xffffffffffffff00;
    }
    fVar2 = *(float *)(iVar7 + 0x158);
    iVar21 = CONCAT44(unaff_XMM12_Dd, unaff_XMM12_Dc);
    fVar3 = *(float *)(iVar7 + 0x15c);
    pcVar16 = (char *)arg1;
    if (arg1 != -1) {
        while (cVar10 = *pcVar16, cVar10 != '\0') {
            pcVar16 = pcVar16 + 1;
            if (((cVar10 == '#') && (*pcVar16 == '#')) || (pcVar16 == (char *)0xffffffffffffffff)) break;
        }
    }
    fcn.1800fe0a0(CONCAT44(var_d8h._4_4_, 0xbf800000), arg2);
    cVar10 = fcn.1801481e0();
    iVar8 = *(int64_t *)0x180781f28;
    var_10h = CONCAT71((unkint7)((uint64_t)arg2 >> 8), cVar10);
    if (cVar10 != '\0') {
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 0x2000;
        piVar1 = (int32_t *)(iVar8 + 0x2100);
        uVar13 = *(undefined4 *)(iVar8 + 0x1f78);
        iVar12 = *(int32_t *)(iVar8 + 0x2104);
        if (*piVar1 == iVar12) {
            iVar17 = *piVar1 + 1;
            if (iVar12 == 0) {
                iVar12 = 8;
            } else {
                iVar12 = iVar12 / 2 + iVar12;
            }
            if (iVar17 < iVar12) {
                iVar17 = iVar12;
            }
            fcn.18011fb10(piVar1, iVar17);
        }
        *(undefined4 *)(*(int64_t *)(iVar8 + 0x2108) + (int64_t)*piVar1 * 4) = uVar13;
        *piVar1 = *piVar1 + 1;
    }
    fcn.180107590(arg1);
    if ((char)arg_28h == '\0') {
        fcn.180106080(1);
    }
    if (*(int32_t *)(iVar7 + 0x214) == 0) {
        *(float *)(iVar7 + 0x158) = (float)(int32_t)(*(float *)(iVar9 + 0xdec) * 0.5) + *(float *)(iVar7 + 0x158);
        fcn.1800f68b0(0xe, *(float *)(iVar9 + 0xdec) + *(float *)(iVar9 + 0xdec));
        uVar11 = fcn.180146c70(iVar21, CONCAT44(unaff_XMM11_Db, unaff_XMM11_Da));
        fcn.1800f6a20(1);
        if ((*(uint32_t *)(iVar9 + 0x1fc0) & 0x100) != 0) {
            fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
        }
        *(float *)(iVar7 + 0x158) = *(float *)(iVar7 + 0x158) - (float)(int32_t)(*(float *)(iVar9 + 0xdec) * 0.5);
    } else {
        if ((arg3 == 0) || (*(char *)arg3 == '\0')) {
            fVar19 = 0.0;
        } else {
            pfVar14 = (float *)fcn.1800fe0a0(CONCAT44(var_d8h._4_4_, 0xbf800000), var_10h);
            fVar19 = *pfVar14;
        }
        var_c0h._0_4_ = (float)fcn.180147e60(iVar7 + 0x1c4);
        iVar8 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        if ((*(int64_t *)(iVar8 + 0x208) != 0) || (iVar15 = 0x2d0, *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0) != 0))
        {
            iVar15 = 0x2a0;
        }
        fVar4 = *(float *)(iVar7 + 400);
        fVar18 = (*(float *)(iVar8 + iVar15) - *(float *)(iVar8 + 0x158)) - (float)var_c0h;
        var_c0h._4_4_ = var_c8h._4_4_;
        uVar11 = fcn.180146c70(iVar21, CONCAT44(unaff_XMM11_Db, unaff_XMM11_Da));
        if ((*(uint32_t *)(iVar9 + 0x1fc0) & 0x100) != 0) {
            fVar20 = 0.0;
            if (0.0 <= fVar18) {
                fVar20 = fVar18;
            }
            fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
            if (0.0 < fVar19) {
                fcn.1800f6710(0, iVar9 + 0xee0);
                iVar21 = *(int64_t *)0x180781f28;
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x180645b70;
                *(undefined8 *)(iVar21 + 0x2a28) = 0x1805ab2bc;
                fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
                fcn.1800f6770(1);
            }
            if ((char)placeholder_3 != '\0') {
                fVar19 = *(float *)(iVar9 + 0x12f8);
                var_c0h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed0);
                var_c0h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
                uStack_b8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
                var_b4h._0_4_ =
                     *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                uVar5 = *(uint16_t *)(iVar7 + 0x1d4);
                uVar13 = fcn.1800f5fa0(&var_c0h);
                fcn.1801303d0(*(undefined8 *)(iVar7 + 800), 
                              CONCAT44(fVar19 * 0.134 * 0.5 + fVar4 + fVar3, 
                                       (float)(uint32_t)uVar5 + fVar20 + fVar19 * 0.4 + fVar2), uVar13, fVar19 * 0.866);
            }
        }
    }
    if ((char)arg_28h == '\0') {
        fcn.180106130();
    }
    iVar12 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar12 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar12 + -1;
    }
    if (cVar10 != '\0') {
        fcn.180106030();
    }
    return (uint64_t)uVar11;
}

// ============================================================
// Function: FUN_1801485f6
// Address: 0x1801485f6
// Size: 350 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_15e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_dech because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Removing arg arg_ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d9ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Removing arg arg_d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29ach because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2971h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.180148270(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    uint16_t uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    char cVar10;
    uint8_t uVar11;
    int32_t iVar12;
    undefined4 uVar13;
    float *pfVar14;
    int64_t iVar15;
    char *pcVar16;
    int32_t iVar17;
    float fVar18;
    float fVar19;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    float fVar20;
    undefined4 unaff_XMM11_Da;
    undefined4 unaff_XMM11_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_c0h;
    undefined4 uStack_b8;
    int64_t var_b4h;
    int64_t var_a8h;
    int64_t iVar21;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar9 = *(int64_t *)0x180781f28;
    uVar6 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar6 + 0x10b) = 1;
    iVar7 = *(int64_t *)(iVar9 + 0x15e0);
    if (*(char *)(iVar7 + 0x10e) != '\0') {
        return uVar6 & 0xffffffffffffff00;
    }
    fVar2 = *(float *)(iVar7 + 0x158);
    iVar21 = CONCAT44(unaff_XMM12_Dd, unaff_XMM12_Dc);
    fVar3 = *(float *)(iVar7 + 0x15c);
    pcVar16 = (char *)arg1;
    if (arg1 != -1) {
        while (cVar10 = *pcVar16, cVar10 != '\0') {
            pcVar16 = pcVar16 + 1;
            if (((cVar10 == '#') && (*pcVar16 == '#')) || (pcVar16 == (char *)0xffffffffffffffff)) break;
        }
    }
    fcn.1800fe0a0(CONCAT44(var_d8h._4_4_, 0xbf800000), arg2);
    cVar10 = fcn.1801481e0();
    iVar8 = *(int64_t *)0x180781f28;
    var_10h = CONCAT71((unkint7)((uint64_t)arg2 >> 8), cVar10);
    if (cVar10 != '\0') {
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 0x2000;
        piVar1 = (int32_t *)(iVar8 + 0x2100);
        uVar13 = *(undefined4 *)(iVar8 + 0x1f78);
        iVar12 = *(int32_t *)(iVar8 + 0x2104);
        if (*piVar1 == iVar12) {
            iVar17 = *piVar1 + 1;
            if (iVar12 == 0) {
                iVar12 = 8;
            } else {
                iVar12 = iVar12 / 2 + iVar12;
            }
            if (iVar17 < iVar12) {
                iVar17 = iVar12;
            }
            fcn.18011fb10(piVar1, iVar17);
        }
        *(undefined4 *)(*(int64_t *)(iVar8 + 0x2108) + (int64_t)*piVar1 * 4) = uVar13;
        *piVar1 = *piVar1 + 1;
    }
    fcn.180107590(arg1);
    if ((char)arg_28h == '\0') {
        fcn.180106080(1);
    }
    if (*(int32_t *)(iVar7 + 0x214) == 0) {
        *(float *)(iVar7 + 0x158) = (float)(int32_t)(*(float *)(iVar9 + 0xdec) * 0.5) + *(float *)(iVar7 + 0x158);
        fcn.1800f68b0(0xe, *(float *)(iVar9 + 0xdec) + *(float *)(iVar9 + 0xdec));
        uVar11 = fcn.180146c70(iVar21, CONCAT44(unaff_XMM11_Db, unaff_XMM11_Da));
        fcn.1800f6a20(1);
        if ((*(uint32_t *)(iVar9 + 0x1fc0) & 0x100) != 0) {
            fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
        }
        *(float *)(iVar7 + 0x158) = *(float *)(iVar7 + 0x158) - (float)(int32_t)(*(float *)(iVar9 + 0xdec) * 0.5);
    } else {
        if ((arg3 == 0) || (*(char *)arg3 == '\0')) {
            fVar19 = 0.0;
        } else {
            pfVar14 = (float *)fcn.1800fe0a0(CONCAT44(var_d8h._4_4_, 0xbf800000), var_10h);
            fVar19 = *pfVar14;
        }
        var_c0h._0_4_ = (float)fcn.180147e60(iVar7 + 0x1c4);
        iVar8 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        if ((*(int64_t *)(iVar8 + 0x208) != 0) || (iVar15 = 0x2d0, *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0) != 0))
        {
            iVar15 = 0x2a0;
        }
        fVar4 = *(float *)(iVar7 + 400);
        fVar18 = (*(float *)(iVar8 + iVar15) - *(float *)(iVar8 + 0x158)) - (float)var_c0h;
        var_c0h._4_4_ = var_c8h._4_4_;
        uVar11 = fcn.180146c70(iVar21, CONCAT44(unaff_XMM11_Db, unaff_XMM11_Da));
        if ((*(uint32_t *)(iVar9 + 0x1fc0) & 0x100) != 0) {
            fVar20 = 0.0;
            if (0.0 <= fVar18) {
                fVar20 = fVar18;
            }
            fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
            if (0.0 < fVar19) {
                fcn.1800f6710(0, iVar9 + 0xee0);
                iVar21 = *(int64_t *)0x180781f28;
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x180645b70;
                *(undefined8 *)(iVar21 + 0x2a28) = 0x1805ab2bc;
                fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
                fcn.1800f6770(1);
            }
            if ((char)placeholder_3 != '\0') {
                fVar19 = *(float *)(iVar9 + 0x12f8);
                var_c0h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed0);
                var_c0h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
                uStack_b8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
                var_b4h._0_4_ =
                     *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                uVar5 = *(uint16_t *)(iVar7 + 0x1d4);
                uVar13 = fcn.1800f5fa0(&var_c0h);
                fcn.1801303d0(*(undefined8 *)(iVar7 + 800), 
                              CONCAT44(fVar19 * 0.134 * 0.5 + fVar4 + fVar3, 
                                       (float)(uint32_t)uVar5 + fVar20 + fVar19 * 0.4 + fVar2), uVar13, fVar19 * 0.866);
            }
        }
    }
    if ((char)arg_28h == '\0') {
        fcn.180106130();
    }
    iVar12 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar12 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar12 + -1;
    }
    if (cVar10 != '\0') {
        fcn.180106030();
    }
    return (uint64_t)uVar11;
}

// ============================================================
// Function: FUN_180148754
// Address: 0x180148754
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_15e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_dech because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Removing arg arg_ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d9ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Removing arg arg_d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29ach because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2971h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.180148270(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    uint16_t uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    char cVar10;
    uint8_t uVar11;
    int32_t iVar12;
    undefined4 uVar13;
    float *pfVar14;
    int64_t iVar15;
    char *pcVar16;
    int32_t iVar17;
    float fVar18;
    float fVar19;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    float fVar20;
    undefined4 unaff_XMM11_Da;
    undefined4 unaff_XMM11_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_c0h;
    undefined4 uStack_b8;
    int64_t var_b4h;
    int64_t var_a8h;
    int64_t iVar21;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar9 = *(int64_t *)0x180781f28;
    uVar6 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar6 + 0x10b) = 1;
    iVar7 = *(int64_t *)(iVar9 + 0x15e0);
    if (*(char *)(iVar7 + 0x10e) != '\0') {
        return uVar6 & 0xffffffffffffff00;
    }
    fVar2 = *(float *)(iVar7 + 0x158);
    iVar21 = CONCAT44(unaff_XMM12_Dd, unaff_XMM12_Dc);
    fVar3 = *(float *)(iVar7 + 0x15c);
    pcVar16 = (char *)arg1;
    if (arg1 != -1) {
        while (cVar10 = *pcVar16, cVar10 != '\0') {
            pcVar16 = pcVar16 + 1;
            if (((cVar10 == '#') && (*pcVar16 == '#')) || (pcVar16 == (char *)0xffffffffffffffff)) break;
        }
    }
    fcn.1800fe0a0(CONCAT44(var_d8h._4_4_, 0xbf800000), arg2);
    cVar10 = fcn.1801481e0();
    iVar8 = *(int64_t *)0x180781f28;
    var_10h = CONCAT71((unkint7)((uint64_t)arg2 >> 8), cVar10);
    if (cVar10 != '\0') {
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 0x2000;
        piVar1 = (int32_t *)(iVar8 + 0x2100);
        uVar13 = *(undefined4 *)(iVar8 + 0x1f78);
        iVar12 = *(int32_t *)(iVar8 + 0x2104);
        if (*piVar1 == iVar12) {
            iVar17 = *piVar1 + 1;
            if (iVar12 == 0) {
                iVar12 = 8;
            } else {
                iVar12 = iVar12 / 2 + iVar12;
            }
            if (iVar17 < iVar12) {
                iVar17 = iVar12;
            }
            fcn.18011fb10(piVar1, iVar17);
        }
        *(undefined4 *)(*(int64_t *)(iVar8 + 0x2108) + (int64_t)*piVar1 * 4) = uVar13;
        *piVar1 = *piVar1 + 1;
    }
    fcn.180107590(arg1);
    if ((char)arg_28h == '\0') {
        fcn.180106080(1);
    }
    if (*(int32_t *)(iVar7 + 0x214) == 0) {
        *(float *)(iVar7 + 0x158) = (float)(int32_t)(*(float *)(iVar9 + 0xdec) * 0.5) + *(float *)(iVar7 + 0x158);
        fcn.1800f68b0(0xe, *(float *)(iVar9 + 0xdec) + *(float *)(iVar9 + 0xdec));
        uVar11 = fcn.180146c70(iVar21, CONCAT44(unaff_XMM11_Db, unaff_XMM11_Da));
        fcn.1800f6a20(1);
        if ((*(uint32_t *)(iVar9 + 0x1fc0) & 0x100) != 0) {
            fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
        }
        *(float *)(iVar7 + 0x158) = *(float *)(iVar7 + 0x158) - (float)(int32_t)(*(float *)(iVar9 + 0xdec) * 0.5);
    } else {
        if ((arg3 == 0) || (*(char *)arg3 == '\0')) {
            fVar19 = 0.0;
        } else {
            pfVar14 = (float *)fcn.1800fe0a0(CONCAT44(var_d8h._4_4_, 0xbf800000), var_10h);
            fVar19 = *pfVar14;
        }
        var_c0h._0_4_ = (float)fcn.180147e60(iVar7 + 0x1c4);
        iVar8 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        if ((*(int64_t *)(iVar8 + 0x208) != 0) || (iVar15 = 0x2d0, *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0) != 0))
        {
            iVar15 = 0x2a0;
        }
        fVar4 = *(float *)(iVar7 + 400);
        fVar18 = (*(float *)(iVar8 + iVar15) - *(float *)(iVar8 + 0x158)) - (float)var_c0h;
        var_c0h._4_4_ = var_c8h._4_4_;
        uVar11 = fcn.180146c70(iVar21, CONCAT44(unaff_XMM11_Db, unaff_XMM11_Da));
        if ((*(uint32_t *)(iVar9 + 0x1fc0) & 0x100) != 0) {
            fVar20 = 0.0;
            if (0.0 <= fVar18) {
                fVar20 = fVar18;
            }
            fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
            if (0.0 < fVar19) {
                fcn.1800f6710(0, iVar9 + 0xee0);
                iVar21 = *(int64_t *)0x180781f28;
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x180645b70;
                *(undefined8 *)(iVar21 + 0x2a28) = 0x1805ab2bc;
                fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
                fcn.1800f6770(1);
            }
            if ((char)placeholder_3 != '\0') {
                fVar19 = *(float *)(iVar9 + 0x12f8);
                var_c0h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed0);
                var_c0h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
                uStack_b8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
                var_b4h._0_4_ =
                     *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                uVar5 = *(uint16_t *)(iVar7 + 0x1d4);
                uVar13 = fcn.1800f5fa0(&var_c0h);
                fcn.1801303d0(*(undefined8 *)(iVar7 + 800), 
                              CONCAT44(fVar19 * 0.134 * 0.5 + fVar4 + fVar3, 
                                       (float)(uint32_t)uVar5 + fVar20 + fVar19 * 0.4 + fVar2), uVar13, fVar19 * 0.866);
            }
        }
    }
    if ((char)arg_28h == '\0') {
        fcn.180106130();
    }
    iVar12 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar12 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar12 + -1;
    }
    if (cVar10 != '\0') {
        fcn.180106030();
    }
    return (uint64_t)uVar11;
}

// ============================================================
// Function: FUN_18014875a
// Address: 0x18014875a
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_15e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_dech because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Removing arg arg_ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d9ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Removing arg arg_d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29ach because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2971h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.180148270(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    uint16_t uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    char cVar10;
    uint8_t uVar11;
    int32_t iVar12;
    undefined4 uVar13;
    float *pfVar14;
    int64_t iVar15;
    char *pcVar16;
    int32_t iVar17;
    float fVar18;
    float fVar19;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    float fVar20;
    undefined4 unaff_XMM11_Da;
    undefined4 unaff_XMM11_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_c0h;
    undefined4 uStack_b8;
    int64_t var_b4h;
    int64_t var_a8h;
    int64_t iVar21;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar9 = *(int64_t *)0x180781f28;
    uVar6 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar6 + 0x10b) = 1;
    iVar7 = *(int64_t *)(iVar9 + 0x15e0);
    if (*(char *)(iVar7 + 0x10e) != '\0') {
        return uVar6 & 0xffffffffffffff00;
    }
    fVar2 = *(float *)(iVar7 + 0x158);
    iVar21 = CONCAT44(unaff_XMM12_Dd, unaff_XMM12_Dc);
    fVar3 = *(float *)(iVar7 + 0x15c);
    pcVar16 = (char *)arg1;
    if (arg1 != -1) {
        while (cVar10 = *pcVar16, cVar10 != '\0') {
            pcVar16 = pcVar16 + 1;
            if (((cVar10 == '#') && (*pcVar16 == '#')) || (pcVar16 == (char *)0xffffffffffffffff)) break;
        }
    }
    fcn.1800fe0a0(CONCAT44(var_d8h._4_4_, 0xbf800000), arg2);
    cVar10 = fcn.1801481e0();
    iVar8 = *(int64_t *)0x180781f28;
    var_10h = CONCAT71((unkint7)((uint64_t)arg2 >> 8), cVar10);
    if (cVar10 != '\0') {
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 0x2000;
        piVar1 = (int32_t *)(iVar8 + 0x2100);
        uVar13 = *(undefined4 *)(iVar8 + 0x1f78);
        iVar12 = *(int32_t *)(iVar8 + 0x2104);
        if (*piVar1 == iVar12) {
            iVar17 = *piVar1 + 1;
            if (iVar12 == 0) {
                iVar12 = 8;
            } else {
                iVar12 = iVar12 / 2 + iVar12;
            }
            if (iVar17 < iVar12) {
                iVar17 = iVar12;
            }
            fcn.18011fb10(piVar1, iVar17);
        }
        *(undefined4 *)(*(int64_t *)(iVar8 + 0x2108) + (int64_t)*piVar1 * 4) = uVar13;
        *piVar1 = *piVar1 + 1;
    }
    fcn.180107590(arg1);
    if ((char)arg_28h == '\0') {
        fcn.180106080(1);
    }
    if (*(int32_t *)(iVar7 + 0x214) == 0) {
        *(float *)(iVar7 + 0x158) = (float)(int32_t)(*(float *)(iVar9 + 0xdec) * 0.5) + *(float *)(iVar7 + 0x158);
        fcn.1800f68b0(0xe, *(float *)(iVar9 + 0xdec) + *(float *)(iVar9 + 0xdec));
        uVar11 = fcn.180146c70(iVar21, CONCAT44(unaff_XMM11_Db, unaff_XMM11_Da));
        fcn.1800f6a20(1);
        if ((*(uint32_t *)(iVar9 + 0x1fc0) & 0x100) != 0) {
            fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
        }
        *(float *)(iVar7 + 0x158) = *(float *)(iVar7 + 0x158) - (float)(int32_t)(*(float *)(iVar9 + 0xdec) * 0.5);
    } else {
        if ((arg3 == 0) || (*(char *)arg3 == '\0')) {
            fVar19 = 0.0;
        } else {
            pfVar14 = (float *)fcn.1800fe0a0(CONCAT44(var_d8h._4_4_, 0xbf800000), var_10h);
            fVar19 = *pfVar14;
        }
        var_c0h._0_4_ = (float)fcn.180147e60(iVar7 + 0x1c4);
        iVar8 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        if ((*(int64_t *)(iVar8 + 0x208) != 0) || (iVar15 = 0x2d0, *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0) != 0))
        {
            iVar15 = 0x2a0;
        }
        fVar4 = *(float *)(iVar7 + 400);
        fVar18 = (*(float *)(iVar8 + iVar15) - *(float *)(iVar8 + 0x158)) - (float)var_c0h;
        var_c0h._4_4_ = var_c8h._4_4_;
        uVar11 = fcn.180146c70(iVar21, CONCAT44(unaff_XMM11_Db, unaff_XMM11_Da));
        if ((*(uint32_t *)(iVar9 + 0x1fc0) & 0x100) != 0) {
            fVar20 = 0.0;
            if (0.0 <= fVar18) {
                fVar20 = fVar18;
            }
            fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
            if (0.0 < fVar19) {
                fcn.1800f6710(0, iVar9 + 0xee0);
                iVar21 = *(int64_t *)0x180781f28;
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x180645b70;
                *(undefined8 *)(iVar21 + 0x2a28) = 0x1805ab2bc;
                fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
                fcn.1800f6770(1);
            }
            if ((char)placeholder_3 != '\0') {
                fVar19 = *(float *)(iVar9 + 0x12f8);
                var_c0h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed0);
                var_c0h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
                uStack_b8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
                var_b4h._0_4_ =
                     *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                uVar5 = *(uint16_t *)(iVar7 + 0x1d4);
                uVar13 = fcn.1800f5fa0(&var_c0h);
                fcn.1801303d0(*(undefined8 *)(iVar7 + 800), 
                              CONCAT44(fVar19 * 0.134 * 0.5 + fVar4 + fVar3, 
                                       (float)(uint32_t)uVar5 + fVar20 + fVar19 * 0.4 + fVar2), uVar13, fVar19 * 0.866);
            }
        }
    }
    if ((char)arg_28h == '\0') {
        fcn.180106130();
    }
    iVar12 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar12 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar12 + -1;
    }
    if (cVar10 != '\0') {
        fcn.180106030();
    }
    return (uint64_t)uVar11;
}

// ============================================================
// Function: FUN_18014879c
// Address: 0x18014879c
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_15e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_dech because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Removing arg arg_ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d9ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Removing arg arg_d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29ach because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2971h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.180148270(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    uint16_t uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    char cVar10;
    uint8_t uVar11;
    int32_t iVar12;
    undefined4 uVar13;
    float *pfVar14;
    int64_t iVar15;
    char *pcVar16;
    int32_t iVar17;
    float fVar18;
    float fVar19;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    float fVar20;
    undefined4 unaff_XMM11_Da;
    undefined4 unaff_XMM11_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_c0h;
    undefined4 uStack_b8;
    int64_t var_b4h;
    int64_t var_a8h;
    int64_t iVar21;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar9 = *(int64_t *)0x180781f28;
    uVar6 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar6 + 0x10b) = 1;
    iVar7 = *(int64_t *)(iVar9 + 0x15e0);
    if (*(char *)(iVar7 + 0x10e) != '\0') {
        return uVar6 & 0xffffffffffffff00;
    }
    fVar2 = *(float *)(iVar7 + 0x158);
    iVar21 = CONCAT44(unaff_XMM12_Dd, unaff_XMM12_Dc);
    fVar3 = *(float *)(iVar7 + 0x15c);
    pcVar16 = (char *)arg1;
    if (arg1 != -1) {
        while (cVar10 = *pcVar16, cVar10 != '\0') {
            pcVar16 = pcVar16 + 1;
            if (((cVar10 == '#') && (*pcVar16 == '#')) || (pcVar16 == (char *)0xffffffffffffffff)) break;
        }
    }
    fcn.1800fe0a0(CONCAT44(var_d8h._4_4_, 0xbf800000), arg2);
    cVar10 = fcn.1801481e0();
    iVar8 = *(int64_t *)0x180781f28;
    var_10h = CONCAT71((unkint7)((uint64_t)arg2 >> 8), cVar10);
    if (cVar10 != '\0') {
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 0x2000;
        piVar1 = (int32_t *)(iVar8 + 0x2100);
        uVar13 = *(undefined4 *)(iVar8 + 0x1f78);
        iVar12 = *(int32_t *)(iVar8 + 0x2104);
        if (*piVar1 == iVar12) {
            iVar17 = *piVar1 + 1;
            if (iVar12 == 0) {
                iVar12 = 8;
            } else {
                iVar12 = iVar12 / 2 + iVar12;
            }
            if (iVar17 < iVar12) {
                iVar17 = iVar12;
            }
            fcn.18011fb10(piVar1, iVar17);
        }
        *(undefined4 *)(*(int64_t *)(iVar8 + 0x2108) + (int64_t)*piVar1 * 4) = uVar13;
        *piVar1 = *piVar1 + 1;
    }
    fcn.180107590(arg1);
    if ((char)arg_28h == '\0') {
        fcn.180106080(1);
    }
    if (*(int32_t *)(iVar7 + 0x214) == 0) {
        *(float *)(iVar7 + 0x158) = (float)(int32_t)(*(float *)(iVar9 + 0xdec) * 0.5) + *(float *)(iVar7 + 0x158);
        fcn.1800f68b0(0xe, *(float *)(iVar9 + 0xdec) + *(float *)(iVar9 + 0xdec));
        uVar11 = fcn.180146c70(iVar21, CONCAT44(unaff_XMM11_Db, unaff_XMM11_Da));
        fcn.1800f6a20(1);
        if ((*(uint32_t *)(iVar9 + 0x1fc0) & 0x100) != 0) {
            fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
        }
        *(float *)(iVar7 + 0x158) = *(float *)(iVar7 + 0x158) - (float)(int32_t)(*(float *)(iVar9 + 0xdec) * 0.5);
    } else {
        if ((arg3 == 0) || (*(char *)arg3 == '\0')) {
            fVar19 = 0.0;
        } else {
            pfVar14 = (float *)fcn.1800fe0a0(CONCAT44(var_d8h._4_4_, 0xbf800000), var_10h);
            fVar19 = *pfVar14;
        }
        var_c0h._0_4_ = (float)fcn.180147e60(iVar7 + 0x1c4);
        iVar8 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        if ((*(int64_t *)(iVar8 + 0x208) != 0) || (iVar15 = 0x2d0, *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0) != 0))
        {
            iVar15 = 0x2a0;
        }
        fVar4 = *(float *)(iVar7 + 400);
        fVar18 = (*(float *)(iVar8 + iVar15) - *(float *)(iVar8 + 0x158)) - (float)var_c0h;
        var_c0h._4_4_ = var_c8h._4_4_;
        uVar11 = fcn.180146c70(iVar21, CONCAT44(unaff_XMM11_Db, unaff_XMM11_Da));
        if ((*(uint32_t *)(iVar9 + 0x1fc0) & 0x100) != 0) {
            fVar20 = 0.0;
            if (0.0 <= fVar18) {
                fVar20 = fVar18;
            }
            fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
            if (0.0 < fVar19) {
                fcn.1800f6710(0, iVar9 + 0xee0);
                iVar21 = *(int64_t *)0x180781f28;
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x180645b70;
                *(undefined8 *)(iVar21 + 0x2a28) = 0x1805ab2bc;
                fcn.1800f6cb0(CONCAT44(unaff_XMM8_Dd, unaff_XMM8_Dc));
                fcn.1800f6770(1);
            }
            if ((char)placeholder_3 != '\0') {
                fVar19 = *(float *)(iVar9 + 0x12f8);
                var_c0h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed0);
                var_c0h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
                uStack_b8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
                var_b4h._0_4_ =
                     *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                uVar5 = *(uint16_t *)(iVar7 + 0x1d4);
                uVar13 = fcn.1800f5fa0(&var_c0h);
                fcn.1801303d0(*(undefined8 *)(iVar7 + 800), 
                              CONCAT44(fVar19 * 0.134 * 0.5 + fVar4 + fVar3, 
                                       (float)(uint32_t)uVar5 + fVar20 + fVar19 * 0.4 + fVar2), uVar13, fVar19 * 0.866);
            }
        }
    }
    if ((char)arg_28h == '\0') {
        fcn.180106130();
    }
    iVar12 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar12 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar12 + -1;
    }
    if (cVar10 != '\0') {
        fcn.180106030();
    }
    return (uint64_t)uVar11;
}

// ============================================================
// Function: FUN_180148870
// Address: 0x180148870
// Size: 130 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_10eh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel

uint64_t fcn.180148870(int64_t arg_90h, int64_t arg_148h, int64_t arg_150h, int64_t arg_158h)
{
    float fVar1;
    float fVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint64_t in_RAX;
    int32_t *piVar9;
    undefined8 uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t iVar15;
    int64_t var_20h;
    int64_t in_stack_000000f8;
    int64_t var_38h;
    int64_t var_18h;
    
    iVar6 = *(int64_t *)0x180781f28;
    iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar5 + 0x10e) != '\0') {
        return in_RAX & 0xffffffffffffff00;
    }
    uVar7 = fcn.1800f5a90(0x18063cd80, 0, 
                          *(undefined4 *)(*(int64_t *)(iVar5 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar5 + 0x148) * 4));
    piVar9 = (int32_t *)fcn.1800f6170(iVar6 + 0x2550, uVar7);
    if (*piVar9 == -1) {
        *piVar9 = *(int32_t *)(iVar6 + 0x2560);
        iVar3 = *(int32_t *)(iVar6 + 0x2560);
        if (iVar3 == *(int32_t *)(iVar6 + 0x2540)) {
            iVar4 = *(int32_t *)(iVar6 + 0x2544);
            iVar13 = *(int32_t *)(iVar6 + 0x2540) + 1;
            if (iVar4 < iVar13) {
                if (iVar4 == 0) {
                    iVar8 = 8;
                } else {
                    iVar8 = iVar4 / 2 + iVar4;
                }
                iVar14 = iVar13;
                if (iVar13 < iVar8) {
                    iVar14 = iVar8;
                }
                if (iVar4 < iVar14) {
                    uVar10 = fcn.18046d050((int64_t)iVar14 * 0xb0);
                    if (*(int64_t *)(iVar6 + 0x2548) != 0) {
                        fcn.180498030(uVar10, *(int64_t *)(iVar6 + 0x2548), (int64_t)*(int32_t *)(iVar6 + 0x2540) * 0xb0
                                     );
                        fcn.180460d90(*(undefined8 *)(iVar6 + 0x2548));
                    }
                    *(undefined8 *)(iVar6 + 0x2548) = uVar10;
                    *(int32_t *)(iVar6 + 0x2544) = iVar14;
                }
            }
            *(int32_t *)(iVar6 + 0x2540) = iVar13;
            *(int32_t *)(iVar6 + 0x2560) = *(int32_t *)(iVar6 + 0x2560) + 1;
        } else {
            *(undefined4 *)(iVar6 + 0x2560) = *(undefined4 *)((int64_t)iVar3 * 0xb0 + *(int64_t *)(iVar6 + 0x2548));
        }
        iVar12 = (int64_t)iVar3 * 0xb0;
        iVar15 = *(int64_t *)(iVar6 + 0x2548) + iVar12;
        if (iVar15 != 0) {
            fcn.1804986e0(iVar15, 0, 0xb0);
            *(undefined8 *)(iVar15 + 0x30) = 0xffffffffffffffff;
            *(undefined2 *)(iVar15 + 0x8a) = 0xffff;
        }
        *(int32_t *)(iVar6 + 0x2564) = *(int32_t *)(iVar6 + 0x2564) + 1;
        iVar12 = *(int64_t *)(iVar6 + 0x2548) + iVar12;
    } else {
        iVar12 = (int64_t)*piVar9 * 0xb0 + *(int64_t *)(iVar6 + 0x2548);
    }
    fVar1 = *(float *)(iVar5 + 0x158);
    fVar2 = *(float *)(iVar5 + 0x2a0);
    *(undefined4 *)(iVar12 + 0x1c) = uVar7;
    *(float *)(iVar12 + 0x74) = fVar1 - (float)(int32_t)(*(float *)(iVar5 + 0x90) * 0.5);
    *(float *)(iVar12 + 0x78) = (float)(int32_t)(*(float *)(iVar5 + 0x90) * 0.5) + fVar2;
    uVar11 = fcn.180148ad0(in_stack_000000f8);
    return uVar11;
}

// ============================================================
// Function: FUN_1801488f2
// Address: 0x1801488f2
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_10eh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel

uint64_t fcn.180148870(int64_t arg_90h, int64_t arg_148h, int64_t arg_150h, int64_t arg_158h)
{
    float fVar1;
    float fVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint64_t in_RAX;
    int32_t *piVar9;
    undefined8 uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t iVar15;
    int64_t var_20h;
    int64_t in_stack_000000f8;
    int64_t var_38h;
    int64_t var_18h;
    
    iVar6 = *(int64_t *)0x180781f28;
    iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar5 + 0x10e) != '\0') {
        return in_RAX & 0xffffffffffffff00;
    }
    uVar7 = fcn.1800f5a90(0x18063cd80, 0, 
                          *(undefined4 *)(*(int64_t *)(iVar5 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar5 + 0x148) * 4));
    piVar9 = (int32_t *)fcn.1800f6170(iVar6 + 0x2550, uVar7);
    if (*piVar9 == -1) {
        *piVar9 = *(int32_t *)(iVar6 + 0x2560);
        iVar3 = *(int32_t *)(iVar6 + 0x2560);
        if (iVar3 == *(int32_t *)(iVar6 + 0x2540)) {
            iVar4 = *(int32_t *)(iVar6 + 0x2544);
            iVar13 = *(int32_t *)(iVar6 + 0x2540) + 1;
            if (iVar4 < iVar13) {
                if (iVar4 == 0) {
                    iVar8 = 8;
                } else {
                    iVar8 = iVar4 / 2 + iVar4;
                }
                iVar14 = iVar13;
                if (iVar13 < iVar8) {
                    iVar14 = iVar8;
                }
                if (iVar4 < iVar14) {
                    uVar10 = fcn.18046d050((int64_t)iVar14 * 0xb0);
                    if (*(int64_t *)(iVar6 + 0x2548) != 0) {
                        fcn.180498030(uVar10, *(int64_t *)(iVar6 + 0x2548), (int64_t)*(int32_t *)(iVar6 + 0x2540) * 0xb0
                                     );
                        fcn.180460d90(*(undefined8 *)(iVar6 + 0x2548));
                    }
                    *(undefined8 *)(iVar6 + 0x2548) = uVar10;
                    *(int32_t *)(iVar6 + 0x2544) = iVar14;
                }
            }
            *(int32_t *)(iVar6 + 0x2540) = iVar13;
            *(int32_t *)(iVar6 + 0x2560) = *(int32_t *)(iVar6 + 0x2560) + 1;
        } else {
            *(undefined4 *)(iVar6 + 0x2560) = *(undefined4 *)((int64_t)iVar3 * 0xb0 + *(int64_t *)(iVar6 + 0x2548));
        }
        iVar12 = (int64_t)iVar3 * 0xb0;
        iVar15 = *(int64_t *)(iVar6 + 0x2548) + iVar12;
        if (iVar15 != 0) {
            fcn.1804986e0(iVar15, 0, 0xb0);
            *(undefined8 *)(iVar15 + 0x30) = 0xffffffffffffffff;
            *(undefined2 *)(iVar15 + 0x8a) = 0xffff;
        }
        *(int32_t *)(iVar6 + 0x2564) = *(int32_t *)(iVar6 + 0x2564) + 1;
        iVar12 = *(int64_t *)(iVar6 + 0x2548) + iVar12;
    } else {
        iVar12 = (int64_t)*piVar9 * 0xb0 + *(int64_t *)(iVar6 + 0x2548);
    }
    fVar1 = *(float *)(iVar5 + 0x158);
    fVar2 = *(float *)(iVar5 + 0x2a0);
    *(undefined4 *)(iVar12 + 0x1c) = uVar7;
    *(float *)(iVar12 + 0x74) = fVar1 - (float)(int32_t)(*(float *)(iVar5 + 0x90) * 0.5);
    *(float *)(iVar12 + 0x78) = (float)(int32_t)(*(float *)(iVar5 + 0x90) * 0.5) + fVar2;
    uVar11 = fcn.180148ad0(in_stack_000000f8);
    return uVar11;
}

// ============================================================
// Function: FUN_180148904
// Address: 0x180148904
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_10eh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel

uint64_t fcn.180148870(int64_t arg_90h, int64_t arg_148h, int64_t arg_150h, int64_t arg_158h)
{
    float fVar1;
    float fVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint64_t in_RAX;
    int32_t *piVar9;
    undefined8 uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t iVar15;
    int64_t var_20h;
    int64_t in_stack_000000f8;
    int64_t var_38h;
    int64_t var_18h;
    
    iVar6 = *(int64_t *)0x180781f28;
    iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar5 + 0x10e) != '\0') {
        return in_RAX & 0xffffffffffffff00;
    }
    uVar7 = fcn.1800f5a90(0x18063cd80, 0, 
                          *(undefined4 *)(*(int64_t *)(iVar5 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar5 + 0x148) * 4));
    piVar9 = (int32_t *)fcn.1800f6170(iVar6 + 0x2550, uVar7);
    if (*piVar9 == -1) {
        *piVar9 = *(int32_t *)(iVar6 + 0x2560);
        iVar3 = *(int32_t *)(iVar6 + 0x2560);
        if (iVar3 == *(int32_t *)(iVar6 + 0x2540)) {
            iVar4 = *(int32_t *)(iVar6 + 0x2544);
            iVar13 = *(int32_t *)(iVar6 + 0x2540) + 1;
            if (iVar4 < iVar13) {
                if (iVar4 == 0) {
                    iVar8 = 8;
                } else {
                    iVar8 = iVar4 / 2 + iVar4;
                }
                iVar14 = iVar13;
                if (iVar13 < iVar8) {
                    iVar14 = iVar8;
                }
                if (iVar4 < iVar14) {
                    uVar10 = fcn.18046d050((int64_t)iVar14 * 0xb0);
                    if (*(int64_t *)(iVar6 + 0x2548) != 0) {
                        fcn.180498030(uVar10, *(int64_t *)(iVar6 + 0x2548), (int64_t)*(int32_t *)(iVar6 + 0x2540) * 0xb0
                                     );
                        fcn.180460d90(*(undefined8 *)(iVar6 + 0x2548));
                    }
                    *(undefined8 *)(iVar6 + 0x2548) = uVar10;
                    *(int32_t *)(iVar6 + 0x2544) = iVar14;
                }
            }
            *(int32_t *)(iVar6 + 0x2540) = iVar13;
            *(int32_t *)(iVar6 + 0x2560) = *(int32_t *)(iVar6 + 0x2560) + 1;
        } else {
            *(undefined4 *)(iVar6 + 0x2560) = *(undefined4 *)((int64_t)iVar3 * 0xb0 + *(int64_t *)(iVar6 + 0x2548));
        }
        iVar12 = (int64_t)iVar3 * 0xb0;
        iVar15 = *(int64_t *)(iVar6 + 0x2548) + iVar12;
        if (iVar15 != 0) {
            fcn.1804986e0(iVar15, 0, 0xb0);
            *(undefined8 *)(iVar15 + 0x30) = 0xffffffffffffffff;
            *(undefined2 *)(iVar15 + 0x8a) = 0xffff;
        }
        *(int32_t *)(iVar6 + 0x2564) = *(int32_t *)(iVar6 + 0x2564) + 1;
        iVar12 = *(int64_t *)(iVar6 + 0x2548) + iVar12;
    } else {
        iVar12 = (int64_t)*piVar9 * 0xb0 + *(int64_t *)(iVar6 + 0x2548);
    }
    fVar1 = *(float *)(iVar5 + 0x158);
    fVar2 = *(float *)(iVar5 + 0x2a0);
    *(undefined4 *)(iVar12 + 0x1c) = uVar7;
    *(float *)(iVar12 + 0x74) = fVar1 - (float)(int32_t)(*(float *)(iVar5 + 0x90) * 0.5);
    *(float *)(iVar12 + 0x78) = (float)(int32_t)(*(float *)(iVar5 + 0x90) * 0.5) + fVar2;
    uVar11 = fcn.180148ad0(in_stack_000000f8);
    return uVar11;
}

// ============================================================
// Function: FUN_18014894e
// Address: 0x18014894e
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_10eh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel

uint64_t fcn.180148870(int64_t arg_90h, int64_t arg_148h, int64_t arg_150h, int64_t arg_158h)
{
    float fVar1;
    float fVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint64_t in_RAX;
    int32_t *piVar9;
    undefined8 uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t iVar15;
    int64_t var_20h;
    int64_t in_stack_000000f8;
    int64_t var_38h;
    int64_t var_18h;
    
    iVar6 = *(int64_t *)0x180781f28;
    iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar5 + 0x10e) != '\0') {
        return in_RAX & 0xffffffffffffff00;
    }
    uVar7 = fcn.1800f5a90(0x18063cd80, 0, 
                          *(undefined4 *)(*(int64_t *)(iVar5 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar5 + 0x148) * 4));
    piVar9 = (int32_t *)fcn.1800f6170(iVar6 + 0x2550, uVar7);
    if (*piVar9 == -1) {
        *piVar9 = *(int32_t *)(iVar6 + 0x2560);
        iVar3 = *(int32_t *)(iVar6 + 0x2560);
        if (iVar3 == *(int32_t *)(iVar6 + 0x2540)) {
            iVar4 = *(int32_t *)(iVar6 + 0x2544);
            iVar13 = *(int32_t *)(iVar6 + 0x2540) + 1;
            if (iVar4 < iVar13) {
                if (iVar4 == 0) {
                    iVar8 = 8;
                } else {
                    iVar8 = iVar4 / 2 + iVar4;
                }
                iVar14 = iVar13;
                if (iVar13 < iVar8) {
                    iVar14 = iVar8;
                }
                if (iVar4 < iVar14) {
                    uVar10 = fcn.18046d050((int64_t)iVar14 * 0xb0);
                    if (*(int64_t *)(iVar6 + 0x2548) != 0) {
                        fcn.180498030(uVar10, *(int64_t *)(iVar6 + 0x2548), (int64_t)*(int32_t *)(iVar6 + 0x2540) * 0xb0
                                     );
                        fcn.180460d90(*(undefined8 *)(iVar6 + 0x2548));
                    }
                    *(undefined8 *)(iVar6 + 0x2548) = uVar10;
                    *(int32_t *)(iVar6 + 0x2544) = iVar14;
                }
            }
            *(int32_t *)(iVar6 + 0x2540) = iVar13;
            *(int32_t *)(iVar6 + 0x2560) = *(int32_t *)(iVar6 + 0x2560) + 1;
        } else {
            *(undefined4 *)(iVar6 + 0x2560) = *(undefined4 *)((int64_t)iVar3 * 0xb0 + *(int64_t *)(iVar6 + 0x2548));
        }
        iVar12 = (int64_t)iVar3 * 0xb0;
        iVar15 = *(int64_t *)(iVar6 + 0x2548) + iVar12;
        if (iVar15 != 0) {
            fcn.1804986e0(iVar15, 0, 0xb0);
            *(undefined8 *)(iVar15 + 0x30) = 0xffffffffffffffff;
            *(undefined2 *)(iVar15 + 0x8a) = 0xffff;
        }
        *(int32_t *)(iVar6 + 0x2564) = *(int32_t *)(iVar6 + 0x2564) + 1;
        iVar12 = *(int64_t *)(iVar6 + 0x2548) + iVar12;
    } else {
        iVar12 = (int64_t)*piVar9 * 0xb0 + *(int64_t *)(iVar6 + 0x2548);
    }
    fVar1 = *(float *)(iVar5 + 0x158);
    fVar2 = *(float *)(iVar5 + 0x2a0);
    *(undefined4 *)(iVar12 + 0x1c) = uVar7;
    *(float *)(iVar12 + 0x74) = fVar1 - (float)(int32_t)(*(float *)(iVar5 + 0x90) * 0.5);
    *(float *)(iVar12 + 0x78) = (float)(int32_t)(*(float *)(iVar5 + 0x90) * 0.5) + fVar2;
    uVar11 = fcn.180148ad0(in_stack_000000f8);
    return uVar11;
}

// ============================================================
// Function: FUN_18014899b
// Address: 0x18014899b
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_10eh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel

uint64_t fcn.180148870(int64_t arg_90h, int64_t arg_148h, int64_t arg_150h, int64_t arg_158h)
{
    float fVar1;
    float fVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint64_t in_RAX;
    int32_t *piVar9;
    undefined8 uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t iVar15;
    int64_t var_20h;
    int64_t in_stack_000000f8;
    int64_t var_38h;
    int64_t var_18h;
    
    iVar6 = *(int64_t *)0x180781f28;
    iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar5 + 0x10e) != '\0') {
        return in_RAX & 0xffffffffffffff00;
    }
    uVar7 = fcn.1800f5a90(0x18063cd80, 0, 
                          *(undefined4 *)(*(int64_t *)(iVar5 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar5 + 0x148) * 4));
    piVar9 = (int32_t *)fcn.1800f6170(iVar6 + 0x2550, uVar7);
    if (*piVar9 == -1) {
        *piVar9 = *(int32_t *)(iVar6 + 0x2560);
        iVar3 = *(int32_t *)(iVar6 + 0x2560);
        if (iVar3 == *(int32_t *)(iVar6 + 0x2540)) {
            iVar4 = *(int32_t *)(iVar6 + 0x2544);
            iVar13 = *(int32_t *)(iVar6 + 0x2540) + 1;
            if (iVar4 < iVar13) {
                if (iVar4 == 0) {
                    iVar8 = 8;
                } else {
                    iVar8 = iVar4 / 2 + iVar4;
                }
                iVar14 = iVar13;
                if (iVar13 < iVar8) {
                    iVar14 = iVar8;
                }
                if (iVar4 < iVar14) {
                    uVar10 = fcn.18046d050((int64_t)iVar14 * 0xb0);
                    if (*(int64_t *)(iVar6 + 0x2548) != 0) {
                        fcn.180498030(uVar10, *(int64_t *)(iVar6 + 0x2548), (int64_t)*(int32_t *)(iVar6 + 0x2540) * 0xb0
                                     );
                        fcn.180460d90(*(undefined8 *)(iVar6 + 0x2548));
                    }
                    *(undefined8 *)(iVar6 + 0x2548) = uVar10;
                    *(int32_t *)(iVar6 + 0x2544) = iVar14;
                }
            }
            *(int32_t *)(iVar6 + 0x2540) = iVar13;
            *(int32_t *)(iVar6 + 0x2560) = *(int32_t *)(iVar6 + 0x2560) + 1;
        } else {
            *(undefined4 *)(iVar6 + 0x2560) = *(undefined4 *)((int64_t)iVar3 * 0xb0 + *(int64_t *)(iVar6 + 0x2548));
        }
        iVar12 = (int64_t)iVar3 * 0xb0;
        iVar15 = *(int64_t *)(iVar6 + 0x2548) + iVar12;
        if (iVar15 != 0) {
            fcn.1804986e0(iVar15, 0, 0xb0);
            *(undefined8 *)(iVar15 + 0x30) = 0xffffffffffffffff;
            *(undefined2 *)(iVar15 + 0x8a) = 0xffff;
        }
        *(int32_t *)(iVar6 + 0x2564) = *(int32_t *)(iVar6 + 0x2564) + 1;
        iVar12 = *(int64_t *)(iVar6 + 0x2548) + iVar12;
    } else {
        iVar12 = (int64_t)*piVar9 * 0xb0 + *(int64_t *)(iVar6 + 0x2548);
    }
    fVar1 = *(float *)(iVar5 + 0x158);
    fVar2 = *(float *)(iVar5 + 0x2a0);
    *(undefined4 *)(iVar12 + 0x1c) = uVar7;
    *(float *)(iVar12 + 0x74) = fVar1 - (float)(int32_t)(*(float *)(iVar5 + 0x90) * 0.5);
    *(float *)(iVar12 + 0x78) = (float)(int32_t)(*(float *)(iVar5 + 0x90) * 0.5) + fVar2;
    uVar11 = fcn.180148ad0(in_stack_000000f8);
    return uVar11;
}

// ============================================================
// Function: FUN_1801489db
// Address: 0x1801489db
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_10eh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel

uint64_t fcn.180148870(int64_t arg_90h, int64_t arg_148h, int64_t arg_150h, int64_t arg_158h)
{
    float fVar1;
    float fVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint64_t in_RAX;
    int32_t *piVar9;
    undefined8 uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t iVar15;
    int64_t var_20h;
    int64_t in_stack_000000f8;
    int64_t var_38h;
    int64_t var_18h;
    
    iVar6 = *(int64_t *)0x180781f28;
    iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar5 + 0x10e) != '\0') {
        return in_RAX & 0xffffffffffffff00;
    }
    uVar7 = fcn.1800f5a90(0x18063cd80, 0, 
                          *(undefined4 *)(*(int64_t *)(iVar5 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar5 + 0x148) * 4));
    piVar9 = (int32_t *)fcn.1800f6170(iVar6 + 0x2550, uVar7);
    if (*piVar9 == -1) {
        *piVar9 = *(int32_t *)(iVar6 + 0x2560);
        iVar3 = *(int32_t *)(iVar6 + 0x2560);
        if (iVar3 == *(int32_t *)(iVar6 + 0x2540)) {
            iVar4 = *(int32_t *)(iVar6 + 0x2544);
            iVar13 = *(int32_t *)(iVar6 + 0x2540) + 1;
            if (iVar4 < iVar13) {
                if (iVar4 == 0) {
                    iVar8 = 8;
                } else {
                    iVar8 = iVar4 / 2 + iVar4;
                }
                iVar14 = iVar13;
                if (iVar13 < iVar8) {
                    iVar14 = iVar8;
                }
                if (iVar4 < iVar14) {
                    uVar10 = fcn.18046d050((int64_t)iVar14 * 0xb0);
                    if (*(int64_t *)(iVar6 + 0x2548) != 0) {
                        fcn.180498030(uVar10, *(int64_t *)(iVar6 + 0x2548), (int64_t)*(int32_t *)(iVar6 + 0x2540) * 0xb0
                                     );
                        fcn.180460d90(*(undefined8 *)(iVar6 + 0x2548));
                    }
                    *(undefined8 *)(iVar6 + 0x2548) = uVar10;
                    *(int32_t *)(iVar6 + 0x2544) = iVar14;
                }
            }
            *(int32_t *)(iVar6 + 0x2540) = iVar13;
            *(int32_t *)(iVar6 + 0x2560) = *(int32_t *)(iVar6 + 0x2560) + 1;
        } else {
            *(undefined4 *)(iVar6 + 0x2560) = *(undefined4 *)((int64_t)iVar3 * 0xb0 + *(int64_t *)(iVar6 + 0x2548));
        }
        iVar12 = (int64_t)iVar3 * 0xb0;
        iVar15 = *(int64_t *)(iVar6 + 0x2548) + iVar12;
        if (iVar15 != 0) {
            fcn.1804986e0(iVar15, 0, 0xb0);
            *(undefined8 *)(iVar15 + 0x30) = 0xffffffffffffffff;
            *(undefined2 *)(iVar15 + 0x8a) = 0xffff;
        }
        *(int32_t *)(iVar6 + 0x2564) = *(int32_t *)(iVar6 + 0x2564) + 1;
        iVar12 = *(int64_t *)(iVar6 + 0x2548) + iVar12;
    } else {
        iVar12 = (int64_t)*piVar9 * 0xb0 + *(int64_t *)(iVar6 + 0x2548);
    }
    fVar1 = *(float *)(iVar5 + 0x158);
    fVar2 = *(float *)(iVar5 + 0x2a0);
    *(undefined4 *)(iVar12 + 0x1c) = uVar7;
    *(float *)(iVar12 + 0x74) = fVar1 - (float)(int32_t)(*(float *)(iVar5 + 0x90) * 0.5);
    *(float *)(iVar12 + 0x78) = (float)(int32_t)(*(float *)(iVar5 + 0x90) * 0.5) + fVar2;
    uVar11 = fcn.180148ad0(in_stack_000000f8);
    return uVar11;
}

// ============================================================
// Function: FUN_180148a19
// Address: 0x180148a19
// Size: 176 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_10eh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel

uint64_t fcn.180148870(int64_t arg_90h, int64_t arg_148h, int64_t arg_150h, int64_t arg_158h)
{
    float fVar1;
    float fVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint64_t in_RAX;
    int32_t *piVar9;
    undefined8 uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t iVar15;
    int64_t var_20h;
    int64_t in_stack_000000f8;
    int64_t var_38h;
    int64_t var_18h;
    
    iVar6 = *(int64_t *)0x180781f28;
    iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar5 + 0x10e) != '\0') {
        return in_RAX & 0xffffffffffffff00;
    }
    uVar7 = fcn.1800f5a90(0x18063cd80, 0, 
                          *(undefined4 *)(*(int64_t *)(iVar5 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar5 + 0x148) * 4));
    piVar9 = (int32_t *)fcn.1800f6170(iVar6 + 0x2550, uVar7);
    if (*piVar9 == -1) {
        *piVar9 = *(int32_t *)(iVar6 + 0x2560);
        iVar3 = *(int32_t *)(iVar6 + 0x2560);
        if (iVar3 == *(int32_t *)(iVar6 + 0x2540)) {
            iVar4 = *(int32_t *)(iVar6 + 0x2544);
            iVar13 = *(int32_t *)(iVar6 + 0x2540) + 1;
            if (iVar4 < iVar13) {
                if (iVar4 == 0) {
                    iVar8 = 8;
                } else {
                    iVar8 = iVar4 / 2 + iVar4;
                }
                iVar14 = iVar13;
                if (iVar13 < iVar8) {
                    iVar14 = iVar8;
                }
                if (iVar4 < iVar14) {
                    uVar10 = fcn.18046d050((int64_t)iVar14 * 0xb0);
                    if (*(int64_t *)(iVar6 + 0x2548) != 0) {
                        fcn.180498030(uVar10, *(int64_t *)(iVar6 + 0x2548), (int64_t)*(int32_t *)(iVar6 + 0x2540) * 0xb0
                                     );
                        fcn.180460d90(*(undefined8 *)(iVar6 + 0x2548));
                    }
                    *(undefined8 *)(iVar6 + 0x2548) = uVar10;
                    *(int32_t *)(iVar6 + 0x2544) = iVar14;
                }
            }
            *(int32_t *)(iVar6 + 0x2540) = iVar13;
            *(int32_t *)(iVar6 + 0x2560) = *(int32_t *)(iVar6 + 0x2560) + 1;
        } else {
            *(undefined4 *)(iVar6 + 0x2560) = *(undefined4 *)((int64_t)iVar3 * 0xb0 + *(int64_t *)(iVar6 + 0x2548));
        }
        iVar12 = (int64_t)iVar3 * 0xb0;
        iVar15 = *(int64_t *)(iVar6 + 0x2548) + iVar12;
        if (iVar15 != 0) {
            fcn.1804986e0(iVar15, 0, 0xb0);
            *(undefined8 *)(iVar15 + 0x30) = 0xffffffffffffffff;
            *(undefined2 *)(iVar15 + 0x8a) = 0xffff;
        }
        *(int32_t *)(iVar6 + 0x2564) = *(int32_t *)(iVar6 + 0x2564) + 1;
        iVar12 = *(int64_t *)(iVar6 + 0x2548) + iVar12;
    } else {
        iVar12 = (int64_t)*piVar9 * 0xb0 + *(int64_t *)(iVar6 + 0x2548);
    }
    fVar1 = *(float *)(iVar5 + 0x158);
    fVar2 = *(float *)(iVar5 + 0x2a0);
    *(undefined4 *)(iVar12 + 0x1c) = uVar7;
    *(float *)(iVar12 + 0x74) = fVar1 - (float)(int32_t)(*(float *)(iVar5 + 0x90) * 0.5);
    *(float *)(iVar12 + 0x78) = (float)(int32_t)(*(float *)(iVar5 + 0x90) * 0.5) + fVar2;
    uVar11 = fcn.180148ad0(in_stack_000000f8);
    return uVar11;
}

// ============================================================
// Function: FUN_180148ad0
// Address: 0x180148ad0
// Size: 450 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_10eh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

undefined8 fcn.180148ad0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_158h)
{
    undefined4 *puVar1;
    float fVar2;
    float fVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int32_t iVar11;
    undefined8 uVar12;
    int64_t iVar13;
    int32_t iVar14;
    uint32_t uVar15;
    int32_t iVar16;
    uint32_t uVar17;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_24h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    float var_4ch;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar9 = *(int64_t *)0x180781f28;
    uVar17 = (uint32_t)arg3;
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar13 + 0x10e) == '\0') {
        if ((arg3 & 0x100000U) == 0) {
            fcn.1801076d0(*(undefined4 *)(arg1 + 0x1c));
        }
        uVar4 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x2548);
        if (((uint64_t)arg1 < uVar4) ||
           ((int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2540) * 0xb0 + uVar4 <= (uint64_t)arg1)) {
            var_60h._0_4_ = 0xffffffff;
            var_68h = arg1;
        } else {
            var_68h = 0;
            var_60h._0_4_ = (undefined4)((int64_t)(arg1 - uVar4) / 0xb0);
        }
        iVar14 = *(int32_t *)(iVar9 + 0x256c);
        if (*(int32_t *)(iVar9 + 0x2568) == iVar14) {
            iVar16 = *(int32_t *)(iVar9 + 0x2568) + 1;
            if (iVar14 == 0) {
                iVar11 = 8;
            } else {
                iVar11 = iVar14 / 2 + iVar14;
            }
            if (iVar16 < iVar11) {
                iVar16 = iVar11;
            }
            if (iVar14 < iVar16) {
                uVar12 = fcn.18046d050((int64_t)iVar16 << 4);
                if (*(int64_t *)(iVar9 + 0x2570) != 0) {
                    fcn.180498030(uVar12, *(int64_t *)(iVar9 + 0x2570), (int64_t)*(int32_t *)(iVar9 + 0x2568) << 4);
                    fcn.180460d90(*(undefined8 *)(iVar9 + 0x2570));
                }
                *(undefined8 *)(iVar9 + 0x2570) = uVar12;
                *(int32_t *)(iVar9 + 0x256c) = iVar16;
            }
        }
        puVar1 = (undefined4 *)(*(int64_t *)(iVar9 + 0x2570) + (int64_t)*(int32_t *)(iVar9 + 0x2568) * 0x10);
        *puVar1 = (undefined4)var_68h;
        puVar1[1] = var_68h._4_4_;
        puVar1[2] = (undefined4)var_60h;
        puVar1[3] = var_60h._4_4_;
        *(int32_t *)(iVar9 + 0x2568) = *(int32_t *)(iVar9 + 0x2568) + 1;
        *(int64_t *)(iVar9 + 0x2538) = arg1;
        iVar14 = *(int32_t *)(arg1 + 0x30);
        *(int64_t *)arg1 = iVar13;
        *(undefined8 *)(arg1 + 0x98) = *(undefined8 *)(iVar13 + 0x158);
        if (iVar14 == *(int32_t *)(iVar9 + 4)) {
            fVar2 = *(float *)(arg1 + 0x8c);
            fVar3 = *(float *)(arg1 + 0x44);
            *(undefined4 *)(iVar13 + 0x158) = *(undefined4 *)(arg1 + 0x38);
            *(float *)(iVar13 + 0x15c) = fVar2 + fVar3;
            *(char *)(arg1 + 0x82) = *(char *)(arg1 + 0x82) + '\x01';
        } else {
            if (((((uVar17 & 1) != (*(uint32_t *)(arg1 + 0x18) & 1)) ||
                 ((*(char *)(arg1 + 0x85) != '\0' && ((arg3 & 1U) == 0)))) && ((arg3 & 0x100000U) == 0)) &&
               (1 < *(uint32_t *)(arg1 + 8))) {
                fcn.18046f0d0(var_68h);
                iVar14 = *(int32_t *)(arg1 + 0x30);
            }
            *(char *)(arg1 + 0x85) = '\0';
            uVar15 = uVar17 | 0x80;
            if ((arg3 & 0x380U) != 0) {
                uVar15 = uVar17;
            }
            *(uint32_t *)(arg1 + 0x18) = uVar15;
            uVar5 = *(undefined4 *)arg2;
            uVar6 = *(undefined4 *)(arg2 + 4);
            uVar7 = *(undefined4 *)(arg2 + 8);
            uVar8 = *(undefined4 *)(arg2 + 0xc);
            *(int32_t *)(arg1 + 0x34) = iVar14;
            iVar10 = *(int64_t *)0x180781f28;
            *(undefined4 *)(arg1 + 0x38) = uVar5;
            *(undefined4 *)(arg1 + 0x3c) = uVar6;
            *(undefined4 *)(arg1 + 0x40) = uVar7;
            *(undefined4 *)(arg1 + 0x44) = uVar8;
            *(undefined *)(arg1 + 0x83) = 1;
            *(undefined4 *)(arg1 + 0x30) = *(undefined4 *)(iVar9 + 4);
            *(undefined4 *)(arg1 + 0x50) = *(undefined4 *)(arg1 + 0x4c);
            *(undefined4 *)(arg1 + 0x4c) = 0;
            fVar2 = *(float *)(iVar9 + 0xdf0);
            *(float *)(arg1 + 0x8c) = fVar2;
            fVar3 = *(float *)(arg1 + 0x44);
            *(undefined8 *)(arg1 + 0x90) = *(undefined8 *)(iVar9 + 0xddc);
            *(undefined4 *)(arg1 + 0x88) = 0xffff0000;
            *(undefined *)(arg1 + 0x82) = 1;
            *(undefined4 *)(iVar13 + 0x158) = *(undefined4 *)(arg1 + 0x38);
            *(float *)(iVar13 + 0x15c) = fVar2 + fVar3;
            iVar13 = 0x3b0;
            if ((uVar15 >> 0x15 & 1) != 0) {
                iVar13 = 0x380;
            }
            puVar1 = (undefined4 *)(iVar13 + 0xd90 + iVar10);
            var_58h._0_4_ = *puVar1;
            var_58h._4_4_ = puVar1[1];
            uStack_50 = puVar1[2];
            var_4ch = (float)puVar1[3] * *(float *)(iVar10 + 0xd9c);
            if (0.0 < *(float *)(iVar9 + 0xe4c)) {
                fcn.1800f5fa0(&var_58h);
                fcn.180126550((uint64_t)var_78h._4_4_ << 0x20, unaff_retaddr);
            }
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180148c92
// Address: 0x180148c92
// Size: 310 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_10eh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

undefined8 fcn.180148ad0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_158h)
{
    undefined4 *puVar1;
    float fVar2;
    float fVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int32_t iVar11;
    undefined8 uVar12;
    int64_t iVar13;
    int32_t iVar14;
    uint32_t uVar15;
    int32_t iVar16;
    uint32_t uVar17;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_24h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    float var_4ch;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar9 = *(int64_t *)0x180781f28;
    uVar17 = (uint32_t)arg3;
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar13 + 0x10e) == '\0') {
        if ((arg3 & 0x100000U) == 0) {
            fcn.1801076d0(*(undefined4 *)(arg1 + 0x1c));
        }
        uVar4 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x2548);
        if (((uint64_t)arg1 < uVar4) ||
           ((int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2540) * 0xb0 + uVar4 <= (uint64_t)arg1)) {
            var_60h._0_4_ = 0xffffffff;
            var_68h = arg1;
        } else {
            var_68h = 0;
            var_60h._0_4_ = (undefined4)((int64_t)(arg1 - uVar4) / 0xb0);
        }
        iVar14 = *(int32_t *)(iVar9 + 0x256c);
        if (*(int32_t *)(iVar9 + 0x2568) == iVar14) {
            iVar16 = *(int32_t *)(iVar9 + 0x2568) + 1;
            if (iVar14 == 0) {
                iVar11 = 8;
            } else {
                iVar11 = iVar14 / 2 + iVar14;
            }
            if (iVar16 < iVar11) {
                iVar16 = iVar11;
            }
            if (iVar14 < iVar16) {
                uVar12 = fcn.18046d050((int64_t)iVar16 << 4);
                if (*(int64_t *)(iVar9 + 0x2570) != 0) {
                    fcn.180498030(uVar12, *(int64_t *)(iVar9 + 0x2570), (int64_t)*(int32_t *)(iVar9 + 0x2568) << 4);
                    fcn.180460d90(*(undefined8 *)(iVar9 + 0x2570));
                }
                *(undefined8 *)(iVar9 + 0x2570) = uVar12;
                *(int32_t *)(iVar9 + 0x256c) = iVar16;
            }
        }
        puVar1 = (undefined4 *)(*(int64_t *)(iVar9 + 0x2570) + (int64_t)*(int32_t *)(iVar9 + 0x2568) * 0x10);
        *puVar1 = (undefined4)var_68h;
        puVar1[1] = var_68h._4_4_;
        puVar1[2] = (undefined4)var_60h;
        puVar1[3] = var_60h._4_4_;
        *(int32_t *)(iVar9 + 0x2568) = *(int32_t *)(iVar9 + 0x2568) + 1;
        *(int64_t *)(iVar9 + 0x2538) = arg1;
        iVar14 = *(int32_t *)(arg1 + 0x30);
        *(int64_t *)arg1 = iVar13;
        *(undefined8 *)(arg1 + 0x98) = *(undefined8 *)(iVar13 + 0x158);
        if (iVar14 == *(int32_t *)(iVar9 + 4)) {
            fVar2 = *(float *)(arg1 + 0x8c);
            fVar3 = *(float *)(arg1 + 0x44);
            *(undefined4 *)(iVar13 + 0x158) = *(undefined4 *)(arg1 + 0x38);
            *(float *)(iVar13 + 0x15c) = fVar2 + fVar3;
            *(char *)(arg1 + 0x82) = *(char *)(arg1 + 0x82) + '\x01';
        } else {
            if (((((uVar17 & 1) != (*(uint32_t *)(arg1 + 0x18) & 1)) ||
                 ((*(char *)(arg1 + 0x85) != '\0' && ((arg3 & 1U) == 0)))) && ((arg3 & 0x100000U) == 0)) &&
               (1 < *(uint32_t *)(arg1 + 8))) {
                fcn.18046f0d0(var_68h);
                iVar14 = *(int32_t *)(arg1 + 0x30);
            }
            *(char *)(arg1 + 0x85) = '\0';
            uVar15 = uVar17 | 0x80;
            if ((arg3 & 0x380U) != 0) {
                uVar15 = uVar17;
            }
            *(uint32_t *)(arg1 + 0x18) = uVar15;
            uVar5 = *(undefined4 *)arg2;
            uVar6 = *(undefined4 *)(arg2 + 4);
            uVar7 = *(undefined4 *)(arg2 + 8);
            uVar8 = *(undefined4 *)(arg2 + 0xc);
            *(int32_t *)(arg1 + 0x34) = iVar14;
            iVar10 = *(int64_t *)0x180781f28;
            *(undefined4 *)(arg1 + 0x38) = uVar5;
            *(undefined4 *)(arg1 + 0x3c) = uVar6;
            *(undefined4 *)(arg1 + 0x40) = uVar7;
            *(undefined4 *)(arg1 + 0x44) = uVar8;
            *(undefined *)(arg1 + 0x83) = 1;
            *(undefined4 *)(arg1 + 0x30) = *(undefined4 *)(iVar9 + 4);
            *(undefined4 *)(arg1 + 0x50) = *(undefined4 *)(arg1 + 0x4c);
            *(undefined4 *)(arg1 + 0x4c) = 0;
            fVar2 = *(float *)(iVar9 + 0xdf0);
            *(float *)(arg1 + 0x8c) = fVar2;
            fVar3 = *(float *)(arg1 + 0x44);
            *(undefined8 *)(arg1 + 0x90) = *(undefined8 *)(iVar9 + 0xddc);
            *(undefined4 *)(arg1 + 0x88) = 0xffff0000;
            *(undefined *)(arg1 + 0x82) = 1;
            *(undefined4 *)(iVar13 + 0x158) = *(undefined4 *)(arg1 + 0x38);
            *(float *)(iVar13 + 0x15c) = fVar2 + fVar3;
            iVar13 = 0x3b0;
            if ((uVar15 >> 0x15 & 1) != 0) {
                iVar13 = 0x380;
            }
            puVar1 = (undefined4 *)(iVar13 + 0xd90 + iVar10);
            var_58h._0_4_ = *puVar1;
            var_58h._4_4_ = puVar1[1];
            uStack_50 = puVar1[2];
            var_4ch = (float)puVar1[3] * *(float *)(iVar10 + 0xd9c);
            if (0.0 < *(float *)(iVar9 + 0xe4c)) {
                fcn.1800f5fa0(&var_58h);
                fcn.180126550((uint64_t)var_78h._4_4_ << 0x20, unaff_retaddr);
            }
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180148dc8
// Address: 0x180148dc8
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_10eh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

undefined8 fcn.180148ad0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_158h)
{
    undefined4 *puVar1;
    float fVar2;
    float fVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int32_t iVar11;
    undefined8 uVar12;
    int64_t iVar13;
    int32_t iVar14;
    uint32_t uVar15;
    int32_t iVar16;
    uint32_t uVar17;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_24h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    float var_4ch;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar9 = *(int64_t *)0x180781f28;
    uVar17 = (uint32_t)arg3;
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar13 + 0x10e) == '\0') {
        if ((arg3 & 0x100000U) == 0) {
            fcn.1801076d0(*(undefined4 *)(arg1 + 0x1c));
        }
        uVar4 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x2548);
        if (((uint64_t)arg1 < uVar4) ||
           ((int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2540) * 0xb0 + uVar4 <= (uint64_t)arg1)) {
            var_60h._0_4_ = 0xffffffff;
            var_68h = arg1;
        } else {
            var_68h = 0;
            var_60h._0_4_ = (undefined4)((int64_t)(arg1 - uVar4) / 0xb0);
        }
        iVar14 = *(int32_t *)(iVar9 + 0x256c);
        if (*(int32_t *)(iVar9 + 0x2568) == iVar14) {
            iVar16 = *(int32_t *)(iVar9 + 0x2568) + 1;
            if (iVar14 == 0) {
                iVar11 = 8;
            } else {
                iVar11 = iVar14 / 2 + iVar14;
            }
            if (iVar16 < iVar11) {
                iVar16 = iVar11;
            }
            if (iVar14 < iVar16) {
                uVar12 = fcn.18046d050((int64_t)iVar16 << 4);
                if (*(int64_t *)(iVar9 + 0x2570) != 0) {
                    fcn.180498030(uVar12, *(int64_t *)(iVar9 + 0x2570), (int64_t)*(int32_t *)(iVar9 + 0x2568) << 4);
                    fcn.180460d90(*(undefined8 *)(iVar9 + 0x2570));
                }
                *(undefined8 *)(iVar9 + 0x2570) = uVar12;
                *(int32_t *)(iVar9 + 0x256c) = iVar16;
            }
        }
        puVar1 = (undefined4 *)(*(int64_t *)(iVar9 + 0x2570) + (int64_t)*(int32_t *)(iVar9 + 0x2568) * 0x10);
        *puVar1 = (undefined4)var_68h;
        puVar1[1] = var_68h._4_4_;
        puVar1[2] = (undefined4)var_60h;
        puVar1[3] = var_60h._4_4_;
        *(int32_t *)(iVar9 + 0x2568) = *(int32_t *)(iVar9 + 0x2568) + 1;
        *(int64_t *)(iVar9 + 0x2538) = arg1;
        iVar14 = *(int32_t *)(arg1 + 0x30);
        *(int64_t *)arg1 = iVar13;
        *(undefined8 *)(arg1 + 0x98) = *(undefined8 *)(iVar13 + 0x158);
        if (iVar14 == *(int32_t *)(iVar9 + 4)) {
            fVar2 = *(float *)(arg1 + 0x8c);
            fVar3 = *(float *)(arg1 + 0x44);
            *(undefined4 *)(iVar13 + 0x158) = *(undefined4 *)(arg1 + 0x38);
            *(float *)(iVar13 + 0x15c) = fVar2 + fVar3;
            *(char *)(arg1 + 0x82) = *(char *)(arg1 + 0x82) + '\x01';
        } else {
            if (((((uVar17 & 1) != (*(uint32_t *)(arg1 + 0x18) & 1)) ||
                 ((*(char *)(arg1 + 0x85) != '\0' && ((arg3 & 1U) == 0)))) && ((arg3 & 0x100000U) == 0)) &&
               (1 < *(uint32_t *)(arg1 + 8))) {
                fcn.18046f0d0(var_68h);
                iVar14 = *(int32_t *)(arg1 + 0x30);
            }
            *(char *)(arg1 + 0x85) = '\0';
            uVar15 = uVar17 | 0x80;
            if ((arg3 & 0x380U) != 0) {
                uVar15 = uVar17;
            }
            *(uint32_t *)(arg1 + 0x18) = uVar15;
            uVar5 = *(undefined4 *)arg2;
            uVar6 = *(undefined4 *)(arg2 + 4);
            uVar7 = *(undefined4 *)(arg2 + 8);
            uVar8 = *(undefined4 *)(arg2 + 0xc);
            *(int32_t *)(arg1 + 0x34) = iVar14;
            iVar10 = *(int64_t *)0x180781f28;
            *(undefined4 *)(arg1 + 0x38) = uVar5;
            *(undefined4 *)(arg1 + 0x3c) = uVar6;
            *(undefined4 *)(arg1 + 0x40) = uVar7;
            *(undefined4 *)(arg1 + 0x44) = uVar8;
            *(undefined *)(arg1 + 0x83) = 1;
            *(undefined4 *)(arg1 + 0x30) = *(undefined4 *)(iVar9 + 4);
            *(undefined4 *)(arg1 + 0x50) = *(undefined4 *)(arg1 + 0x4c);
            *(undefined4 *)(arg1 + 0x4c) = 0;
            fVar2 = *(float *)(iVar9 + 0xdf0);
            *(float *)(arg1 + 0x8c) = fVar2;
            fVar3 = *(float *)(arg1 + 0x44);
            *(undefined8 *)(arg1 + 0x90) = *(undefined8 *)(iVar9 + 0xddc);
            *(undefined4 *)(arg1 + 0x88) = 0xffff0000;
            *(undefined *)(arg1 + 0x82) = 1;
            *(undefined4 *)(iVar13 + 0x158) = *(undefined4 *)(arg1 + 0x38);
            *(float *)(iVar13 + 0x15c) = fVar2 + fVar3;
            iVar13 = 0x3b0;
            if ((uVar15 >> 0x15 & 1) != 0) {
                iVar13 = 0x380;
            }
            puVar1 = (undefined4 *)(iVar13 + 0xd90 + iVar10);
            var_58h._0_4_ = *puVar1;
            var_58h._4_4_ = puVar1[1];
            uStack_50 = puVar1[2];
            var_4ch = (float)puVar1[3] * *(float *)(iVar10 + 0xd9c);
            if (0.0 < *(float *)(iVar9 + 0xe4c)) {
                fcn.1800f5fa0(&var_58h);
                fcn.180126550((uint64_t)var_78h._4_4_ << 0x20, unaff_retaddr);
            }
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180148e2f
// Address: 0x180148e2f
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_10eh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

undefined8 fcn.180148ad0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_158h)
{
    undefined4 *puVar1;
    float fVar2;
    float fVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int32_t iVar11;
    undefined8 uVar12;
    int64_t iVar13;
    int32_t iVar14;
    uint32_t uVar15;
    int32_t iVar16;
    uint32_t uVar17;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_24h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    float var_4ch;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar9 = *(int64_t *)0x180781f28;
    uVar17 = (uint32_t)arg3;
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar13 + 0x10e) == '\0') {
        if ((arg3 & 0x100000U) == 0) {
            fcn.1801076d0(*(undefined4 *)(arg1 + 0x1c));
        }
        uVar4 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x2548);
        if (((uint64_t)arg1 < uVar4) ||
           ((int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2540) * 0xb0 + uVar4 <= (uint64_t)arg1)) {
            var_60h._0_4_ = 0xffffffff;
            var_68h = arg1;
        } else {
            var_68h = 0;
            var_60h._0_4_ = (undefined4)((int64_t)(arg1 - uVar4) / 0xb0);
        }
        iVar14 = *(int32_t *)(iVar9 + 0x256c);
        if (*(int32_t *)(iVar9 + 0x2568) == iVar14) {
            iVar16 = *(int32_t *)(iVar9 + 0x2568) + 1;
            if (iVar14 == 0) {
                iVar11 = 8;
            } else {
                iVar11 = iVar14 / 2 + iVar14;
            }
            if (iVar16 < iVar11) {
                iVar16 = iVar11;
            }
            if (iVar14 < iVar16) {
                uVar12 = fcn.18046d050((int64_t)iVar16 << 4);
                if (*(int64_t *)(iVar9 + 0x2570) != 0) {
                    fcn.180498030(uVar12, *(int64_t *)(iVar9 + 0x2570), (int64_t)*(int32_t *)(iVar9 + 0x2568) << 4);
                    fcn.180460d90(*(undefined8 *)(iVar9 + 0x2570));
                }
                *(undefined8 *)(iVar9 + 0x2570) = uVar12;
                *(int32_t *)(iVar9 + 0x256c) = iVar16;
            }
        }
        puVar1 = (undefined4 *)(*(int64_t *)(iVar9 + 0x2570) + (int64_t)*(int32_t *)(iVar9 + 0x2568) * 0x10);
        *puVar1 = (undefined4)var_68h;
        puVar1[1] = var_68h._4_4_;
        puVar1[2] = (undefined4)var_60h;
        puVar1[3] = var_60h._4_4_;
        *(int32_t *)(iVar9 + 0x2568) = *(int32_t *)(iVar9 + 0x2568) + 1;
        *(int64_t *)(iVar9 + 0x2538) = arg1;
        iVar14 = *(int32_t *)(arg1 + 0x30);
        *(int64_t *)arg1 = iVar13;
        *(undefined8 *)(arg1 + 0x98) = *(undefined8 *)(iVar13 + 0x158);
        if (iVar14 == *(int32_t *)(iVar9 + 4)) {
            fVar2 = *(float *)(arg1 + 0x8c);
            fVar3 = *(float *)(arg1 + 0x44);
            *(undefined4 *)(iVar13 + 0x158) = *(undefined4 *)(arg1 + 0x38);
            *(float *)(iVar13 + 0x15c) = fVar2 + fVar3;
            *(char *)(arg1 + 0x82) = *(char *)(arg1 + 0x82) + '\x01';
        } else {
            if (((((uVar17 & 1) != (*(uint32_t *)(arg1 + 0x18) & 1)) ||
                 ((*(char *)(arg1 + 0x85) != '\0' && ((arg3 & 1U) == 0)))) && ((arg3 & 0x100000U) == 0)) &&
               (1 < *(uint32_t *)(arg1 + 8))) {
                fcn.18046f0d0(var_68h);
                iVar14 = *(int32_t *)(arg1 + 0x30);
            }
            *(char *)(arg1 + 0x85) = '\0';
            uVar15 = uVar17 | 0x80;
            if ((arg3 & 0x380U) != 0) {
                uVar15 = uVar17;
            }
            *(uint32_t *)(arg1 + 0x18) = uVar15;
            uVar5 = *(undefined4 *)arg2;
            uVar6 = *(undefined4 *)(arg2 + 4);
            uVar7 = *(undefined4 *)(arg2 + 8);
            uVar8 = *(undefined4 *)(arg2 + 0xc);
            *(int32_t *)(arg1 + 0x34) = iVar14;
            iVar10 = *(int64_t *)0x180781f28;
            *(undefined4 *)(arg1 + 0x38) = uVar5;
            *(undefined4 *)(arg1 + 0x3c) = uVar6;
            *(undefined4 *)(arg1 + 0x40) = uVar7;
            *(undefined4 *)(arg1 + 0x44) = uVar8;
            *(undefined *)(arg1 + 0x83) = 1;
            *(undefined4 *)(arg1 + 0x30) = *(undefined4 *)(iVar9 + 4);
            *(undefined4 *)(arg1 + 0x50) = *(undefined4 *)(arg1 + 0x4c);
            *(undefined4 *)(arg1 + 0x4c) = 0;
            fVar2 = *(float *)(iVar9 + 0xdf0);
            *(float *)(arg1 + 0x8c) = fVar2;
            fVar3 = *(float *)(arg1 + 0x44);
            *(undefined8 *)(arg1 + 0x90) = *(undefined8 *)(iVar9 + 0xddc);
            *(undefined4 *)(arg1 + 0x88) = 0xffff0000;
            *(undefined *)(arg1 + 0x82) = 1;
            *(undefined4 *)(iVar13 + 0x158) = *(undefined4 *)(arg1 + 0x38);
            *(float *)(iVar13 + 0x15c) = fVar2 + fVar3;
            iVar13 = 0x3b0;
            if ((uVar15 >> 0x15 & 1) != 0) {
                iVar13 = 0x380;
            }
            puVar1 = (undefined4 *)(iVar13 + 0xd90 + iVar10);
            var_58h._0_4_ = *puVar1;
            var_58h._4_4_ = puVar1[1];
            uStack_50 = puVar1[2];
            var_4ch = (float)puVar1[3] * *(float *)(iVar10 + 0xd9c);
            if (0.0 < *(float *)(iVar9 + 0xe4c)) {
                fcn.1800f5fa0(&var_58h);
                fcn.180126550((uint64_t)var_78h._4_4_ << 0x20, unaff_retaddr);
            }
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180148e50
// Address: 0x180148e50
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180148e50(int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    float fVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar2 + 0x10e) == '\0') {
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2538);
        if (iVar5 == 0) {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180148eb6. Too many branches
    // WARNING: Treating indirect jump as call
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180645b78);
                return;
            }
        } else {
            if (*(char *)(iVar5 + 0x83) != '\0') {
                func_0x000180148fa0(iVar5);
            }
            if (((*(char *)(iVar5 + 0x84) == '\0') && (*(int32_t *)(iVar5 + 0x2c) != 0)) &&
               (*(int32_t *)(iVar3 + 4) <= *(int32_t *)(iVar5 + 0x34) + 1)) {
                fVar6 = *(float *)(iVar5 + 0x50);
            } else {
                fVar6 = *(float *)(iVar2 + 0x15c) - *(float *)(iVar5 + 0x44);
                if (fVar6 <= *(float *)(iVar5 + 0x4c)) {
                    fVar6 = *(float *)(iVar5 + 0x4c);
                }
                *(float *)(iVar5 + 0x4c) = fVar6;
            }
            *(float *)(iVar2 + 0x15c) = fVar6 + *(float *)(iVar5 + 0x44);
            if ('\x01' < *(char *)(iVar5 + 0x82)) {
                *(undefined8 *)(iVar2 + 0x158) = *(undefined8 *)(iVar5 + 0x98);
            }
            *(undefined2 *)(iVar5 + 0x8a) = 0xffff;
            if ((*(uint32_t *)(iVar5 + 0x18) & 0x100000) == 0) {
                func_0x000180107740();
            }
            iVar1 = *(int32_t *)(iVar3 + 0x2568);
            iVar4 = iVar1 + -1;
            *(int32_t *)(iVar3 + 0x2568) = iVar4;
            if (iVar4 == 0) {
                iVar5 = 0;
            } else {
                iVar2 = (int64_t)iVar1 + -2;
                iVar5 = *(int64_t *)(*(int64_t *)(iVar3 + 0x2570) + iVar2 * 0x10);
                if (iVar5 == 0) {
                    iVar5 = (int64_t)*(int32_t *)(*(int64_t *)(iVar3 + 0x2570) + 8 + iVar2 * 0x10) * 0xb0 +
                            *(int64_t *)(*(int64_t *)0x180781f28 + 0x2548);
                }
            }
            *(int64_t *)(iVar3 + 0x2538) = iVar5;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180148e75
// Address: 0x180148e75
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180148e50(int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    float fVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar2 + 0x10e) == '\0') {
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2538);
        if (iVar5 == 0) {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180148eb6. Too many branches
    // WARNING: Treating indirect jump as call
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180645b78);
                return;
            }
        } else {
            if (*(char *)(iVar5 + 0x83) != '\0') {
                func_0x000180148fa0(iVar5);
            }
            if (((*(char *)(iVar5 + 0x84) == '\0') && (*(int32_t *)(iVar5 + 0x2c) != 0)) &&
               (*(int32_t *)(iVar3 + 4) <= *(int32_t *)(iVar5 + 0x34) + 1)) {
                fVar6 = *(float *)(iVar5 + 0x50);
            } else {
                fVar6 = *(float *)(iVar2 + 0x15c) - *(float *)(iVar5 + 0x44);
                if (fVar6 <= *(float *)(iVar5 + 0x4c)) {
                    fVar6 = *(float *)(iVar5 + 0x4c);
                }
                *(float *)(iVar5 + 0x4c) = fVar6;
            }
            *(float *)(iVar2 + 0x15c) = fVar6 + *(float *)(iVar5 + 0x44);
            if ('\x01' < *(char *)(iVar5 + 0x82)) {
                *(undefined8 *)(iVar2 + 0x158) = *(undefined8 *)(iVar5 + 0x98);
            }
            *(undefined2 *)(iVar5 + 0x8a) = 0xffff;
            if ((*(uint32_t *)(iVar5 + 0x18) & 0x100000) == 0) {
                func_0x000180107740();
            }
            iVar1 = *(int32_t *)(iVar3 + 0x2568);
            iVar4 = iVar1 + -1;
            *(int32_t *)(iVar3 + 0x2568) = iVar4;
            if (iVar4 == 0) {
                iVar5 = 0;
            } else {
                iVar2 = (int64_t)iVar1 + -2;
                iVar5 = *(int64_t *)(*(int64_t *)(iVar3 + 0x2570) + iVar2 * 0x10);
                if (iVar5 == 0) {
                    iVar5 = (int64_t)*(int32_t *)(*(int64_t *)(iVar3 + 0x2570) + 8 + iVar2 * 0x10) * 0xb0 +
                            *(int64_t *)(*(int64_t *)0x180781f28 + 0x2548);
                }
            }
            *(int64_t *)(iVar3 + 0x2538) = iVar5;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180148eb9
// Address: 0x180148eb9
// Size: 218 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180148e50(int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    float fVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar2 + 0x10e) == '\0') {
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2538);
        if (iVar5 == 0) {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180148eb6. Too many branches
    // WARNING: Treating indirect jump as call
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180645b78);
                return;
            }
        } else {
            if (*(char *)(iVar5 + 0x83) != '\0') {
                func_0x000180148fa0(iVar5);
            }
            if (((*(char *)(iVar5 + 0x84) == '\0') && (*(int32_t *)(iVar5 + 0x2c) != 0)) &&
               (*(int32_t *)(iVar3 + 4) <= *(int32_t *)(iVar5 + 0x34) + 1)) {
                fVar6 = *(float *)(iVar5 + 0x50);
            } else {
                fVar6 = *(float *)(iVar2 + 0x15c) - *(float *)(iVar5 + 0x44);
                if (fVar6 <= *(float *)(iVar5 + 0x4c)) {
                    fVar6 = *(float *)(iVar5 + 0x4c);
                }
                *(float *)(iVar5 + 0x4c) = fVar6;
            }
            *(float *)(iVar2 + 0x15c) = fVar6 + *(float *)(iVar5 + 0x44);
            if ('\x01' < *(char *)(iVar5 + 0x82)) {
                *(undefined8 *)(iVar2 + 0x158) = *(undefined8 *)(iVar5 + 0x98);
            }
            *(undefined2 *)(iVar5 + 0x8a) = 0xffff;
            if ((*(uint32_t *)(iVar5 + 0x18) & 0x100000) == 0) {
                func_0x000180107740();
            }
            iVar1 = *(int32_t *)(iVar3 + 0x2568);
            iVar4 = iVar1 + -1;
            *(int32_t *)(iVar3 + 0x2568) = iVar4;
            if (iVar4 == 0) {
                iVar5 = 0;
            } else {
                iVar2 = (int64_t)iVar1 + -2;
                iVar5 = *(int64_t *)(*(int64_t *)(iVar3 + 0x2570) + iVar2 * 0x10);
                if (iVar5 == 0) {
                    iVar5 = (int64_t)*(int32_t *)(*(int64_t *)(iVar3 + 0x2570) + 8 + iVar2 * 0x10) * 0xb0 +
                            *(int64_t *)(*(int64_t *)0x180781f28 + 0x2548);
                }
            }
            *(int64_t *)(iVar3 + 0x2538) = iVar5;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180148f93
// Address: 0x180148f93
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180148e50(int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    float fVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar2 + 0x10e) == '\0') {
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2538);
        if (iVar5 == 0) {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180148eb6. Too many branches
    // WARNING: Treating indirect jump as call
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180645b78);
                return;
            }
        } else {
            if (*(char *)(iVar5 + 0x83) != '\0') {
                func_0x000180148fa0(iVar5);
            }
            if (((*(char *)(iVar5 + 0x84) == '\0') && (*(int32_t *)(iVar5 + 0x2c) != 0)) &&
               (*(int32_t *)(iVar3 + 4) <= *(int32_t *)(iVar5 + 0x34) + 1)) {
                fVar6 = *(float *)(iVar5 + 0x50);
            } else {
                fVar6 = *(float *)(iVar2 + 0x15c) - *(float *)(iVar5 + 0x44);
                if (fVar6 <= *(float *)(iVar5 + 0x4c)) {
                    fVar6 = *(float *)(iVar5 + 0x4c);
                }
                *(float *)(iVar5 + 0x4c) = fVar6;
            }
            *(float *)(iVar2 + 0x15c) = fVar6 + *(float *)(iVar5 + 0x44);
            if ('\x01' < *(char *)(iVar5 + 0x82)) {
                *(undefined8 *)(iVar2 + 0x158) = *(undefined8 *)(iVar5 + 0x98);
            }
            *(undefined2 *)(iVar5 + 0x8a) = 0xffff;
            if ((*(uint32_t *)(iVar5 + 0x18) & 0x100000) == 0) {
                func_0x000180107740();
            }
            iVar1 = *(int32_t *)(iVar3 + 0x2568);
            iVar4 = iVar1 + -1;
            *(int32_t *)(iVar3 + 0x2568) = iVar4;
            if (iVar4 == 0) {
                iVar5 = 0;
            } else {
                iVar2 = (int64_t)iVar1 + -2;
                iVar5 = *(int64_t *)(*(int64_t *)(iVar3 + 0x2570) + iVar2 * 0x10);
                if (iVar5 == 0) {
                    iVar5 = (int64_t)*(int32_t *)(*(int64_t *)(iVar3 + 0x2570) + 8 + iVar2 * 0x10) * 0xb0 +
                            *(int64_t *)(*(int64_t *)0x180781f28 + 0x2548);
                }
            }
            *(int64_t *)(iVar3 + 0x2538) = iVar5;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180148fa0
// Address: 0x180148fa0
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_144h
// WARNING: Variable defined which should be unmapped: var_178h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180148fa0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined auVar3 [16];
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    bool bVar13;
    bool bVar14;
    char cVar15;
    uint8_t uVar16;
    int32_t iVar17;
    undefined8 uVar18;
    int64_t iVar19;
    int32_t *piVar20;
    uint32_t uVar21;
    uint32_t uVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    uint64_t uVar26;
    undefined4 *puVar27;
    uint32_t uVar28;
    undefined4 *puVar29;
    uint32_t *puVar30;
    float *pfVar31;
    int32_t iVar32;
    uint32_t *puVar33;
    undefined8 *puVar34;
    uint32_t uVar35;
    int32_t iVar36;
    undefined4 *puVar37;
    int64_t iVar38;
    int32_t iVar39;
    char *pcVar40;
    int32_t iVar41;
    int64_t *piVar42;
    float *pfVar43;
    bool bVar44;
    float fVar45;
    float fVar46;
    float fVar47;
    float fVar48;
    float fVar49;
    float fVar50;
    float fVar51;
    undefined auVar52 [16];
    undefined auVar53 [16];
    float fVar54;
    undefined4 unaff_XMM12_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    float fVar55;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_198 [32];
    int64_t var_178h;
    undefined4 in_stack_fffffffffffffe98;
    undefined4 in_stack_fffffffffffffe9c;
    undefined4 uVar56;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int32_t var_148h;
    int64_t var_144h;
    undefined4 uStack_13c;
    undefined4 uVar57;
    undefined4 in_stack_fffffffffffffecc;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    float var_100h [2];
    int64_t var_f8h;
    float var_f0h;
    float var_ech;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar38 = *(int64_t *)0x180781f28;
    var_d8h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_198;
    fVar51 = *(float *)(arg1 + 0x48);
    var_118h = arg1 + 0x38;
    *(undefined *)(arg1 + 0x83) = 0;
    fVar49 = *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38);
    var_110h = arg1 + 0x40;
    uVar22 = *(uint32_t *)(arg1 + 8);
    *(float *)(arg1 + 0x48) = fVar49;
    uVar56 = CONCAT31((unkint3)((uint32_t)in_stack_fffffffffffffe9c >> 8), fVar49 < fVar51);
    auVar3._4_4_ = unaff_XMM12_Dc;
    auVar3._0_4_ = unaff_XMM12_Db;
    auVar3._8_4_ = unaff_XMM12_Dd;
    auVar3._12_4_ = 0;
    _var_98h = auVar3 << 0x20;
    bVar44 = false;
    uVar28 = 0;
    uVar35 = 0;
    _var_108h = ZEXT816(0);
    _var_f8h = ZEXT816(0);
    _var_e8h = ZEXT816(0);
    bVar13 = false;
    if (0 < (int32_t)uVar22) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)(arg1 + 0x10);
            iVar23 = (int64_t)(int32_t)uVar35 * 0x38;
            if ((*(int32_t *)(iVar23 + 0x10 + iVar25) < *(int32_t *)(arg1 + 0x34)) ||
               (*(char *)(iVar23 + 0x30 + iVar25) != '\0')) {
                if (*(int32_t *)(arg1 + 0x2c) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x2c) = 0;
                }
                if (*(int32_t *)(arg1 + 0x20) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x20) = 0;
                }
                if (*(int32_t *)(arg1 + 0x24) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x24) = 0;
                }
            } else {
                if (uVar28 != uVar35) {
                    auVar3 = *(undefined (*) [16])(iVar23 + 0x10 + iVar25);
                    puVar37 = (undefined4 *)(iVar23 + 0x20 + iVar25);
                    uVar57 = *puVar37;
                    uVar1 = puVar37[1];
                    uVar2 = puVar37[2];
                    uVar4 = puVar37[3];
                    uVar18 = *(undefined8 *)(iVar23 + 0x30 + iVar25);
                    iVar24 = (int64_t)(int32_t)uVar28 * 0x38;
                    *(undefined (*) [16])(iVar24 + iVar25) = *(undefined (*) [16])(iVar23 + iVar25);
                    *(undefined (*) [16])(iVar24 + 0x10 + iVar25) = auVar3;
                    puVar37 = (undefined4 *)(iVar24 + 0x20 + iVar25);
                    *puVar37 = uVar57;
                    puVar37[1] = uVar1;
                    puVar37[2] = uVar2;
                    puVar37[3] = uVar4;
                    *(undefined8 *)(iVar24 + 0x30 + iVar25) = uVar18;
                }
                iVar23 = (int64_t)(int32_t)uVar28 * 0x38;
                iVar25 = *(int64_t *)(arg1 + 0x10);
                uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                *(int16_t *)(iVar23 + 0x2e + iVar25) = (int16_t)uVar28;
                if ((uVar22 & 0x40) == 0) {
                    uVar26 = (uint64_t)(((uVar22 & 0x80) != 0) + 1);
                } else {
                    uVar26 = 0;
                }
                if (0 < (int32_t)uVar28) {
                    uVar22 = *(uint32_t *)(*(int64_t *)(arg1 + 0x10) + -0x34 + iVar23);
                    cVar15 = '\0';
                    if ((uVar22 & 0x40) == 0) {
                        cVar15 = ((uVar22 & 0x80) != 0) + '\x01';
                    }
                    if ((int32_t)uVar26 == 0) {
                        if (cVar15 == '\0') goto code_r0x000180149140;
                        bVar44 = true;
                    }
                    if (cVar15 == '\x02') {
                        if ((int32_t)uVar26 != 2) {
                            bVar44 = true;
                        }
                        var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                        uVar28 = uVar28 + 1;
                        goto code_r0x000180149172;
                    }
                }
code_r0x000180149140:
                var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                uVar28 = uVar28 + 1;
            }
code_r0x000180149172:
            uVar22 = *(uint32_t *)(arg1 + 8);
            uVar35 = uVar35 + 1;
            bVar13 = bVar44;
        } while ((int32_t)uVar35 < (int32_t)uVar22);
    }
    uVar35 = 8;
    var_128h = arg1;
    if (uVar22 != uVar28) {
        iVar32 = *(int32_t *)(arg1 + 0xc);
        if (iVar32 < (int32_t)uVar28) {
            uVar22 = uVar35;
            if (iVar32 != 0) {
                uVar22 = iVar32 / 2 + iVar32;
            }
            uVar21 = uVar28;
            if ((int32_t)uVar28 < (int32_t)uVar22) {
                uVar21 = uVar22;
            }
            func_0x00018011f970(arg1 + 8, uVar21);
        }
        *(uint32_t *)(arg1 + 8) = uVar28;
        uVar22 = uVar28;
    }
    piVar42 = (int64_t *)(arg1 + 0x10);
    if ((bVar44) && (1 < uVar22)) {
        fcn.18046f0d0(CONCAT44(uVar56, in_stack_fffffffffffffe98));
    }
    fVar51 = *(float *)(iVar38 + 0xdf4);
    if (((int32_t)var_108h < 1) || (var_100h[1] = fVar51, (int32_t)((int32_t)var_e8h + (uint32_t)var_f8h) < 1)) {
        var_100h[1] = 0.0;
    }
    if (((int32_t)(uint32_t)var_f8h < 1) || (var_ech = fVar51, (int32_t)var_e8h < 1)) {
        var_ech = 0.0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x28);
    uVar21 = 0;
    uVar28 = 0;
    if (uVar22 != 0) {
        *(undefined4 *)(arg1 + 0x28) = 0;
        uVar28 = uVar22;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x24);
    if (uVar22 != 0) {
        *(uint32_t *)(arg1 + 0x20) = uVar22;
        *(undefined4 *)(arg1 + 0x24) = 0;
        uVar28 = uVar22;
    }
    if (*(int32_t *)(arg1 + 0x7c) != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (iVar32 < 1) {
code_r0x00018014939d:
            *(undefined4 *)(arg1 + 0x7c) = 0;
        } else {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar21 * 0x38;
                puVar37 = (undefined4 *)(uVar26 + iVar25);
                if (*(int32_t *)(uVar26 + iVar25) == *(int32_t *)(arg1 + 0x7c)) {
                    if ((puVar37[1] & 0x20) == 0) {
                        iVar41 = (int32_t)(uVar26 / 0x38) + (int32_t)*(int16_t *)(arg1 + 0x80);
                        if ((-1 < iVar41) && (iVar41 < iVar32)) {
                            puVar29 = (undefined4 *)((int64_t)iVar41 * 0x38 + iVar25);
                            if (((puVar29[1] & 0x20) == 0) && (((puVar29[1] ^ puVar37[1]) & 0xc0) == 0)) {
                                uVar18 = *(undefined8 *)(puVar37 + 0xc);
                                uVar57 = *puVar37;
                                uVar1 = puVar37[1];
                                uVar2 = puVar37[2];
                                uVar4 = puVar37[3];
                                uVar5 = puVar37[4];
                                uVar6 = puVar37[5];
                                uVar7 = puVar37[6];
                                uVar8 = puVar37[7];
                                uVar9 = puVar37[8];
                                uVar10 = puVar37[9];
                                uVar11 = puVar37[10];
                                uVar12 = puVar37[0xb];
                                if (*(int16_t *)(arg1 + 0x80) < 1) {
                                    puVar37 = puVar29 + 0xe;
                                    puVar27 = puVar29;
                                } else {
                                    puVar27 = puVar37 + 0xe;
                                }
                                fcn.180498030(puVar37, puVar27);
                                *puVar29 = uVar57;
                                puVar29[1] = uVar1;
                                puVar29[2] = uVar2;
                                puVar29[3] = uVar4;
                                puVar29[4] = uVar5;
                                puVar29[5] = uVar6;
                                puVar29[6] = uVar7;
                                puVar29[7] = uVar8;
                                puVar29[8] = uVar9;
                                puVar29[9] = uVar10;
                                puVar29[10] = uVar11;
                                puVar29[0xb] = uVar12;
                                *(undefined8 *)(puVar29 + 0xc) = uVar18;
                                if (((*(uint32_t *)(arg1 + 0x18) & 0x400000) != 0) &&
                                   (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)) {
                                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) =
                                         *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
                                }
                                if (*(uint32_t *)(arg1 + 0x7c) == *(uint32_t *)(arg1 + 0x20)) {
                                    uVar28 = *(uint32_t *)(arg1 + 0x7c);
                                }
                            }
                        }
                    }
                    goto code_r0x00018014939d;
                }
                uVar21 = uVar21 + 1;
            } while ((int32_t)uVar21 < iVar32);
            *(undefined4 *)(arg1 + 0x7c) = 0;
        }
    }
    iVar25 = *(int64_t *)0x180781f28;
    puVar33 = (uint32_t *)0x0;
    if ((*(uint8_t *)(arg1 + 0x18) & 4) != 0) {
        uVar57 = *(undefined4 *)(arg1 + 0x3c);
        var_148h = 0;
        fVar49 = *(float *)(*(int64_t *)0x180781f28 + 0xde0);
        iVar23 = *(int64_t *)0x180781f28 + 0x20c0;
        iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
        uVar1 = *(undefined4 *)(iVar24 + 0x158);
        uVar2 = *(undefined4 *)(iVar24 + 0x15c);
        *(float *)(iVar24 + 0x158) = *(float *)(arg1 + 0x38) - fVar49;
        *(undefined4 *)(iVar24 + 0x15c) = uVar57;
        *(float *)(arg1 + 0x38) = fVar49 + fVar45 + *(float *)(arg1 + 0x38);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        uVar57 = *(undefined4 *)(iVar25 + 0xed8);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        fVar49 = *(float *)(iVar25 + 0xedc);
        fcn.18011f2b0(iVar23, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar57;
            *(float *)(iVar25 + 0xedc) = fVar49 * 0.5;
        }
        iVar25 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        uVar57 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x102c);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar25 + 0x1020) = 0;
            *(undefined8 *)(iVar25 + 0x1028) = 0;
        }
        cVar15 = func_0x00018013d0a0();
        fcn.1800f6770(2);
        if (cVar15 != '\0') {
            iVar32 = 0;
            if (0 < *(int32_t *)(arg1 + 8)) {
                do {
                    puVar30 = (uint32_t *)((int64_t)iVar32 * 0x38 + *piVar42);
                    if (((puVar30[1] & 0x200000) == 0) &&
                       (cVar15 = fcn.180146c70(CONCAT44(uStack_13c, var_144h._4_4_), 
                                               CONCAT44(in_stack_fffffffffffffecc, uVar57)), cVar15 != '\0')) {
                        puVar33 = puVar30;
                    }
                    iVar32 = iVar32 + 1;
                } while (iVar32 < *(int32_t *)(arg1 + 8));
            }
            iVar25 = *(int64_t *)0x180781f28;
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) + -1;
            iVar32 = func_0x000180498f10(*(undefined8 *)(*(int64_t *)(iVar25 + 0x15e0) + 8), &var_148h);
            if (iVar32 == 0) {
                func_0x00018010d5c0();
            } else if (*(code **)(iVar25 + 0x2a40) != (code *)0x0) {
                (**(code **)(iVar25 + 0x2a40))(iVar25, *(undefined8 *)(iVar25 + 0x2a48));
            }
        }
        *(undefined4 *)(iVar24 + 0x158) = uVar1;
        *(undefined4 *)(iVar24 + 0x15c) = uVar2;
        if (puVar33 != (uint32_t *)0x0) {
            uVar28 = *puVar33;
            *(uint32_t *)(arg1 + 0x20) = uVar28;
        }
    }
    iVar41 = 1;
    uVar22 = *(uint32_t *)(arg1 + 8);
    var_144h._0_4_ = (int32_t)var_e8h + (int32_t)var_108h;
    var_148h = 0;
    iVar32 = *(int32_t *)(iVar38 + 0x257c);
    var_144h._4_4_ = (int32_t)var_108h;
    if (iVar32 < (int32_t)uVar22) {
        if (iVar32 != 0) {
            uVar35 = iVar32 / 2 + iVar32;
        }
        uVar21 = uVar22;
        if ((int32_t)uVar22 < (int32_t)uVar35) {
            uVar21 = uVar35;
        }
        if (iVar32 < (int32_t)uVar21) {
            uVar18 = fcn.18046d050((int64_t)(int32_t)uVar21 * 0xc);
            if (*(int64_t *)(iVar38 + 0x2580) != 0) {
                fcn.180498030(uVar18);
                fcn.180460d90(*(undefined8 *)(iVar38 + 0x2580));
            }
            *(undefined8 *)(iVar38 + 0x2580) = uVar18;
            *(uint32_t *)(iVar38 + 0x257c) = uVar21;
        }
    }
    *(uint32_t *)(iVar38 + 0x2578) = uVar22;
    if ((*(uint8_t *)(arg1 + 0x18) & 0x80) == 0) {
        fVar49 = 1.0;
    } else {
        fVar49 = *(float *)(iVar38 + 0xe40);
    }
    iVar32 = *(int32_t *)(arg1 + 8);
    iVar39 = 0;
    var_130h = 0;
    bVar44 = false;
    uVar22 = 0xffffffff;
    bVar13 = false;
    if (0 < iVar32) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)0x180781f28;
            puVar33 = (uint32_t *)((int64_t)iVar39 * 0x38 + *piVar42);
            if (((var_130h == 0) || (*(int32_t *)(var_130h + 0x14) < (int32_t)puVar33[5])) &&
               ((puVar33[1] & 0x200000) == 0)) {
                var_130h = (int64_t)puVar33;
            }
            uVar35 = *puVar33;
            if (uVar35 == *(uint32_t *)(arg1 + 0x20)) {
                bVar44 = true;
            }
            if ((uVar28 == 0) && (*(uint32_t *)(iVar38 + 0x23a4) == uVar35)) {
                uVar28 = uVar35;
            }
            auVar52 = ZEXT416(puVar33[9]);
            if ((float)puVar33[9] < 0.0) {
                uVar35 = puVar33[1];
                var_178h._0_4_ = 0xbf800000;
                fcn.1800fe0a0(CONCAT44(var_178h._4_4_, 0xbf800000), SUB168(_var_98h, 8));
                fVar45 = *(float *)(iVar25 + 0xddc);
                if ((uVar35 & 0x100001) == 0x100000) {
                    fVar50 = fVar45 + 1.0;
                } else {
                    fVar50 = *(float *)(iVar25 + 0x12f8) + *(float *)(iVar25 + 0xdf4) + fVar45;
                }
                fVar50 = fVar50 + var_120h + fVar45;
                auVar52 = ZEXT416((uint32_t)fVar50);
                fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 20.0;
                if (fVar45 <= fVar50) {
                    auVar52 = ZEXT416((uint32_t)fVar45);
                }
            }
            uVar35 = puVar33[1];
            puVar33[8] = (uint32_t)auVar52._0_4_;
            if ((uVar35 >> 0x15 & 1) == 0) {
                if (auVar52._0_4_ <= *(float *)(iVar38 + 0xe3c)) {
                    auVar52._0_4_ = *(float *)(iVar38 + 0xe3c);
                }
                puVar33[8] = auVar52._0_4_;
            }
            if ((uVar35 & 0x40) == 0) {
                uVar35 = ((uVar35 & 0x80) != 0) + 1;
            } else {
                uVar35 = 0;
            }
            uVar26 = (uint64_t)uVar35;
            if (uVar35 == uVar22) {
                fVar50 = auVar52._0_4_ + fVar51;
                fVar45 = fVar51;
            } else {
                fVar50 = auVar52._0_4_ + 0.0;
                fVar45 = 0.0;
            }
            var_100h[uVar26 * 4 + -1] = fVar50 + var_100h[uVar26 * 4 + -1];
            fVar50 = (float)puVar33[8];
            if (fVar49 <= (float)puVar33[8]) {
                fVar50 = fVar49;
            }
            var_100h[uVar26 * 4] = fVar50 + fVar45 + var_100h[uVar26 * 4];
            iVar23 = (int64_t)(&var_148h)[uVar26];
            (&var_148h)[uVar26] = (&var_148h)[uVar26] + 1;
            iVar25 = *(int64_t *)(iVar38 + 0x2580);
            *(int32_t *)(iVar25 + iVar23 * 0xc) = iVar39;
            iVar39 = iVar39 + 1;
            uVar22 = puVar33[8];
            *(uint32_t *)(iVar25 + 8 + iVar23 * 0xc) = uVar22;
            *(uint32_t *)(iVar25 + 4 + iVar23 * 0xc) = uVar22;
            fVar45 = (float)puVar33[8];
            if (fVar45 <= 1.0) {
                fVar45 = 1.0;
            }
            puVar33[7] = (uint32_t)fVar45;
            iVar32 = *(int32_t *)(arg1 + 8);
            uVar22 = uVar35;
            bVar13 = bVar44;
        } while (iVar39 < iVar32);
    }
    uVar22 = *(uint32_t *)(arg1 + 0x18);
    *(float *)(arg1 + 0x58) = var_100h[1] + var_108h._4_4_ + 0.0 + var_f8h._4_4_ + var_ech + var_e8h._4_4_ + var_dch;
    iVar25 = *(int64_t *)0x180781f28;
    if (((uVar22 & 0x200) == 0) && (-1 < (char)uVar22)) {
        bVar14 = false;
code_r0x00018014992e:
        bVar13 = bVar14;
        fVar51 = var_e0h + var_dch + var_100h[0] + var_100h[1] + 0.0 + var_f0h + var_ech;
    } else {
        bVar13 = true;
        bVar14 = true;
        if ((uVar22 & 0x200) == 0) goto code_r0x00018014992e;
        fVar51 = *(float *)(arg1 + 0x54);
    }
    if ((((fVar51 <= *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38)) || (iVar32 < 2)) || ((uVar22 & 0x10) != 0)) ||
       (!bVar13)) {
        *(undefined *)(arg1 + 0x86) = 0;
    } else {
        *(undefined *)(arg1 + 0x86) = 1;
        var_148h = 0;
        fVar51 = *(float *)(iVar25 + 0x12f8);
        iVar23 = *(int64_t *)(iVar25 + 0x15e0);
        fVar54 = fVar51 - 2.0;
        fVar45 = *(float *)(iVar25 + 0xde0);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        uVar57 = *(undefined4 *)(iVar23 + 0x158);
        uVar1 = *(undefined4 *)(iVar25 + 0xed8);
        fVar50 = *(float *)(iVar25 + 0xedc);
        fVar55 = fVar54 + fVar54;
        var_120h = *(float *)(iVar23 + 0x15c);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        fcn.18011f2b0(iVar25 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar1;
            *(float *)(iVar25 + 0xedc) = fVar50 * 0.5;
        }
        iVar24 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar24 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar24 + 0x1020) = 0;
            *(undefined8 *)(iVar24 + 0x1028) = 0;
        }
        iVar24 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 10;
        piVar20 = (int32_t *)(iVar24 + 0x2100);
        iVar32 = *(int32_t *)(iVar24 + 0x2104);
        uVar1 = *(undefined4 *)(iVar24 + 0x1f78);
        if (*piVar20 == iVar32) {
            iVar39 = *piVar20 + 1;
            if (iVar32 == 0) {
                iVar32 = 8;
            } else {
                iVar32 = iVar32 / 2 + iVar32;
            }
            if (iVar39 < iVar32) {
                iVar39 = iVar32;
            }
            fcn.18011fb10(piVar20, iVar39);
        }
        *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + (int64_t)*piVar20 * 4) = uVar1;
        *piVar20 = *piVar20 + 1;
        uVar1 = *(undefined4 *)(iVar25 + 0xa8);
        uVar2 = *(undefined4 *)(iVar25 + 0xac);
        *(undefined4 *)(iVar25 + 0xa8) = 0x3e800000;
        *(undefined4 *)(iVar25 + 0xac) = 0x3e4ccccd;
        fVar46 = *(float *)(arg1 + 0x40) - fVar55;
        fVar50 = *(float *)(arg1 + 0x38);
        if (*(float *)(arg1 + 0x38) <= fVar46) {
            fVar50 = fVar46;
        }
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50;
        uVar16 = func_0x00018013a9f0(0x180645ba0, 0, CONCAT44(fVar45 + fVar45 + fVar51, fVar54));
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50 + fVar54;
        cVar15 = func_0x00018013a9f0(0x180645ba4, 1);
        iVar24 = *(int64_t *)0x180781f28;
        if (cVar15 == '\0') {
            iVar32 = (uVar16 ^ 1) - 1;
        } else {
            iVar32 = 1;
        }
        iVar39 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
        if (iVar39 < 2) {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48));
            }
        } else {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar39 + -1;
            *(undefined4 *)(iVar24 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + -8 + (int64_t)iVar39 * 4)
            ;
        }
        fcn.1800f6770();
        *(undefined4 *)(iVar25 + 0xac) = uVar2;
        *(undefined4 *)(iVar25 + 0xa8) = uVar1;
        if (iVar32 == 0) {
            puVar33 = (uint32_t *)0x0;
code_r0x000180149cf6:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
            if ((puVar33 != (uint32_t *)0x0) && (uVar28 = *puVar33, (puVar33[1] & 0x200000) == 0)) {
                *(uint32_t *)(arg1 + 0x20) = uVar28;
            }
        } else {
            if ((*(int32_t *)(arg1 + 0x20) != 0) && (iVar39 = *(int32_t *)(arg1 + 8), 0 < iVar39)) {
                uVar26 = 0;
                iVar25 = *piVar42;
code_r0x000180149c50:
                if (*(int32_t *)(uVar26 * 0x38 + iVar25) != *(int32_t *)(arg1 + 0x20)) goto code_r0x000180149c5c;
                uVar26 = (uVar26 * 0x38) / 0x38;
                iVar36 = (int32_t)uVar26 + iVar32;
                do {
                    if ((iVar36 < 0) || (iVar17 = iVar36, iVar39 <= iVar36)) {
                        iVar17 = (int32_t)uVar26;
                    }
                    puVar33 = (uint32_t *)((int64_t)iVar17 * 0x38 + iVar25);
                } while ((((*(uint32_t *)(iVar25 + 4 + (int64_t)iVar17 * 0x38) & 0x200000) != 0) &&
                         (iVar36 = iVar36 + iVar32, -1 < iVar36)) &&
                        (uVar26 = (uint64_t)(uint32_t)((int32_t)uVar26 + iVar32), iVar36 < iVar39));
                goto code_r0x000180149cf6;
            }
code_r0x000180149c63:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
        }
    }
    pfVar43 = (float *)(arg1 + 0x40);
    pcVar40 = (char *)(arg1 + 0x86);
    puVar34 = (undefined8 *)(arg1 + 0x38);
    if ((uVar28 == 0) && ((char)uVar56 != '\0')) {
        uVar28 = *(uint32_t *)(arg1 + 0x20);
    }
    fVar51 = *pfVar43 - *(float *)puVar34;
    fVar45 = var_e8h._4_4_ + var_dch + var_108h._4_4_ + var_100h[1];
    if (fVar51 <= fVar45) {
        fVar50 = fVar45 - fVar51;
    } else {
        fVar50 = (var_f8h._4_4_ + var_ech) - ((fVar51 - (var_108h._4_4_ + var_100h[1])) - (var_e8h._4_4_ + var_dch));
        if (fVar50 <= 0.0) {
            fVar50 = 0.0;
        }
    }
    if (1.0 <= fVar50) {
        if ((*(uint32_t *)(arg1 + 0x18) & 0x180) == 0) {
            if (fVar45 < fVar51) goto code_r0x00018014a4db;
code_r0x000180149e0c:
            uVar22 = (int32_t)var_e8h + (int32_t)var_108h;
            if (fVar51 <= fVar45) {
                iVar32 = 0;
            } else {
                iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            }
        } else {
            if (fVar51 <= fVar45) goto code_r0x000180149e0c;
            iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            uVar22 = (uint32_t)var_f8h;
        }
        iVar25 = *(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc;
        if (uVar22 == 1) {
            if (0.0 <= *(float *)(iVar25 + 4)) {
                fVar50 = *(float *)(iVar25 + 4) - fVar50;
                if (fVar50 <= fVar49) {
                    fVar50 = fVar49;
                }
                *(float *)(iVar25 + 4) = fVar50;
            }
        } else {
            if (1 < uVar22) {
                fcn.18046f0d0(CONCAT44(uVar56, uVar28));
            }
            while ((0.001 < fVar50 && (iVar41 < (int32_t)uVar22))) {
                fVar51 = *(float *)(iVar25 + 4);
                do {
                    fVar45 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                    if (fVar45 < fVar51) {
                        if (0.0 <= fVar45) {
                            fVar45 = fVar51 - fVar45;
                            goto code_r0x000180149ee6;
                        }
                        break;
                    }
                    iVar41 = iVar41 + 1;
                } while (iVar41 < (int32_t)uVar22);
                fVar45 = fVar51 - 1.0;
code_r0x000180149ee6:
                fVar54 = fVar51 - fVar49;
                if (fVar45 <= fVar51 - fVar49) {
                    fVar54 = fVar45;
                }
                if (fVar54 <= 0.0) break;
                iVar39 = 0;
                fVar51 = fVar50 / (float)iVar41;
                if (fVar54 <= fVar50 / (float)iVar41) {
                    fVar51 = fVar54;
                }
                if (3 < iVar41) {
                    do {
                        iVar23 = (int64_t)iVar39;
                        iVar39 = iVar39 + 4;
                        fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar55 = fVar45 - fVar49;
                        fVar54 = fVar51;
                        if (fVar55 <= fVar51) {
                            fVar54 = fVar55;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                        fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar46 = fVar45 - fVar49;
                        fVar55 = fVar51;
                        if (fVar46 <= fVar51) {
                            fVar55 = fVar46;
                        }
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar45 - fVar55;
                        fVar45 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar47 = fVar45 - fVar49;
                        fVar46 = fVar51;
                        if (fVar47 <= fVar51) {
                            fVar46 = fVar47;
                        }
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar45 - fVar46;
                        fVar45 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar48 = fVar45 - fVar49;
                        fVar47 = fVar51;
                        if (fVar48 <= fVar51) {
                            fVar47 = fVar48;
                        }
                        fVar50 = (((fVar50 - fVar54) - fVar55) - fVar46) - fVar47;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar45 - fVar47;
                    } while (iVar39 < iVar41 + -3);
                }
                while (iVar39 < iVar41) {
                    iVar23 = (int64_t)iVar39;
                    iVar39 = iVar39 + 1;
                    fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar55 = fVar45 - fVar49;
                    fVar54 = fVar51;
                    if (fVar55 <= fVar51) {
                        fVar54 = fVar55;
                    }
                    fVar50 = fVar50 - fVar54;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                }
            }
            iVar41 = 0;
            fVar51 = 0.0;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 4;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar48 = (float)(int32_t)fVar49;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar48;
                    fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                    fVar46 = (float)(int32_t)fVar45;
                    *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar46;
                    fVar50 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                    fVar55 = (float)(int32_t)fVar50;
                    *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar55;
                    fVar54 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                    fVar47 = (float)(int32_t)fVar54;
                    *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar47;
                    fVar51 = (fVar49 - fVar48) + fVar51 + (fVar45 - fVar46) + (fVar50 - fVar55) + (fVar54 - fVar47);
                } while (iVar41 < (int32_t)(uVar22 - 3));
            }
            for (; iVar41 < (int32_t)uVar22; iVar41 = iVar41 + 1) {
                fVar49 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                fVar45 = (float)(int32_t)fVar49;
                *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc) = fVar45;
                fVar51 = fVar51 + (fVar49 - fVar45);
            }
            while (0.0 < fVar51) {
                iVar41 = 0;
                if (3 < (int32_t)uVar22) {
                    do {
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar23 = (int64_t)iVar41;
                        fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 - fVar45 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar50 = *(float *)(iVar25 + 0x14 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar50) {
                            fVar50 = 1.0;
                        }
                        fVar51 = (fVar51 - fVar45) - fVar50;
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar49 + fVar50;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x20 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar41 = iVar41 + 4;
                        fVar49 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x2c + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar49 + fVar45;
                    } while (iVar41 < (int32_t)(uVar22 - 3));
                }
                while (iVar41 < (int32_t)uVar22) {
                    if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 1;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                    if (1.0 <= fVar45) {
                        fVar45 = 1.0;
                    }
                    fVar51 = fVar51 - fVar45;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                }
            }
        }
code_r0x00018014a22a:
        iVar41 = iVar32 + uVar22;
        if (iVar32 < iVar41) {
            arg1 = var_128h;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar25 = (int64_t)iVar32;
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x10 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0xc + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x1c + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x18 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x28 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar25 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x24 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar25 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar24 = 0;
                        }
                        var_100h[iVar24 * 4 + -1] =
                             var_100h[iVar24 * 4 + -1] - (*(float *)(iVar25 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar25 + 0x1c + iVar23) = fVar49;
                    }
                    iVar32 = iVar32 + 4;
                } while (iVar32 < iVar41 + -3);
                if (iVar41 <= iVar32) goto code_r0x00018014a4d3;
            }
            do {
                fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + (int64_t)iVar32 * 0xc);
                if (0.0 <= fVar51) {
                    iVar25 = *piVar42;
                    fVar49 = 1.0;
                    if (1.0 <= fVar51) {
                        fVar49 = fVar51;
                    }
                    iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc) * 0x38;
                    uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                    if ((uVar22 & 0x40) == 0) {
                        iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                    } else {
                        iVar24 = 0;
                    }
                    var_100h[iVar24 * 4 + -1] =
                         var_100h[iVar24 * 4 + -1] - (*(float *)(iVar23 + 0x1c + iVar25) - fVar49);
                    *(float *)(iVar23 + 0x1c + iVar25) = fVar49;
                }
                iVar32 = iVar32 + 1;
                puVar34 = (undefined8 *)var_118h;
                pfVar43 = (float *)var_110h;
            } while (iVar32 < iVar41);
        } else {
code_r0x00018014a4d3:
            puVar34 = (undefined8 *)(arg1 + 0x38);
            pfVar43 = (float *)(arg1 + 0x40);
        }
    }
code_r0x00018014a4db:
    uVar35 = 0;
    auVar53 = ZEXT816(0);
    *(undefined4 *)(arg1 + 0x54) = 0;
    uVar22 = uVar35;
    if (0 < (int32_t)var_108h) {
        do {
            iVar25 = *piVar42;
            iVar23 = (int64_t)(int32_t)uVar22 * 0x38;
            *(float *)(iVar23 + 0x18 + iVar25) = auVar53._0_4_;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_108h + -1) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            auVar53._0_4_ = auVar53._0_4_ + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_108h);
    }
    fVar49 = auVar53._0_4_ + var_100h[1];
    fVar51 = var_100h[1] + var_108h._4_4_;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    uVar22 = uVar35;
    if (0 < (int32_t)(uint32_t)var_f8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar49;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)((uint32_t)var_f8h + -1)) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar49 = fVar49 + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)(uint32_t)var_f8h);
    }
    fVar51 = var_f8h._4_4_ + var_ech;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    fVar45 = (*(float *)(arg1 + 0x40) - *(float *)puVar34) - var_e8h._4_4_;
    fVar51 = 0.0;
    if (0.0 <= fVar45) {
        fVar51 = fVar45;
    }
    if (var_ech + fVar49 <= fVar51) {
        fVar51 = var_ech + fVar49;
    }
    uVar22 = uVar35;
    if (0 < (int32_t)var_e8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h + (uint32_t)var_f8h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar51;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_e8h + -1) {
                fVar49 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar49 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar51 = fVar51 + fVar49 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_e8h);
    }
    fVar51 = var_e8h._4_4_ + var_dch;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    func_0x00018011f640(arg1 + 0xa0, 0);
    if ((!bVar44) && (*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1)) {
        *(undefined4 *)(arg1 + 0x20) = 0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x20);
    if (((*(uint32_t *)(arg1 + 0x20) == 0) && (uVar22 = uVar35, *(int32_t *)(arg1 + 0x24) == 0)) && (var_130h != 0)) {
        uVar28 = *(uint32_t *)var_130h;
        *(uint32_t *)(arg1 + 0x20) = uVar28;
        uVar22 = uVar28;
    }
    *(uint32_t *)(arg1 + 0x2c) = uVar22;
    *(undefined *)(arg1 + 0x84) = 0;
    iVar25 = *(int64_t *)(iVar38 + 0x23c0);
    if (((iVar25 != 0) && (*(int64_t *)(iVar25 + 0x4c0) != 0)) &&
       (*(int64_t *)(*(int64_t *)(iVar25 + 0x4c0) + 0x40) == arg1)) {
        uVar28 = *(uint32_t *)(iVar25 + 200);
        *(uint32_t *)(arg1 + 0x2c) = uVar28;
    }
    if (uVar28 != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (0 < iVar32) {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar35 * 0x38;
                if (*(uint32_t *)(uVar26 + iVar25) == uVar28) {
                    if ((*(uint8_t *)(uVar26 + 4 + iVar25) & 0xc0) != 0) break;
                    fVar51 = *pfVar43;
                    fVar49 = *(float *)puVar34;
                    fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
                    iVar41 = (int32_t)(uVar26 / 0x38);
                    if ((int32_t)var_108h + -1 < iVar41) {
                        fVar50 = (float)((uint32_t)fVar45 ^ 0x80000000);
                    } else {
                        fVar50 = 0.0;
                    }
                    fVar54 = *(float *)(uVar26 + 0x18 + iVar25) - var_108h._4_4_;
                    fVar50 = fVar54 + fVar50;
                    if (iVar32 - (int32_t)var_e8h <= iVar41 + 1) {
                        fVar45 = 1.0;
                    }
                    fVar55 = *(float *)(uVar26 + 0x1c + iVar25);
                    *(undefined4 *)(arg1 + 100) = 0;
                    fVar45 = fVar54 + fVar55 + fVar45;
                    if (*(float *)(arg1 + 0x60) <= fVar50) {
                        fVar51 = (((fVar51 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech;
                        if (fVar45 - fVar50 < fVar51) {
                            if (*(float *)(arg1 + 0x60) < fVar45 - fVar51) {
                                *(float *)(arg1 + 0x60) = fVar45 - fVar51;
                                fVar51 = (fVar50 - fVar51) - *(float *)(arg1 + 0x5c);
                                if (fVar51 <= 0.0) {
                                    fVar51 = 0.0;
                                }
                                *(float *)(arg1 + 100) = fVar51;
                            }
                            break;
                        }
                    }
                    fVar45 = *(float *)(arg1 + 0x5c) - fVar45;
                    *(float *)(arg1 + 0x60) = fVar50;
                    if (fVar45 <= 0.0) {
                        fVar45 = 0.0;
                    }
                    *(float *)(arg1 + 100) = fVar45;
                    break;
                }
                uVar35 = uVar35 + 1;
            } while ((int32_t)uVar35 < iVar32);
        }
        goto code_r0x00018014a9b6;
    }
    if ((*pcVar40 == '\0') || (cVar15 = func_0x000180108120(puVar34, pfVar43, 1), cVar15 == '\0'))
    goto code_r0x00018014a9b6;
    iVar25 = *(int64_t *)(iVar38 + 0x15e0);
    if (((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) != 0) &&
        ((((iVar23 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) + 0x428), iVar23 != 0 &&
           (*(char *)(iVar23 + 0x10a) != '\0')) && (iVar23 != *(int64_t *)(iVar25 + 0x428))) &&
         (((*(uint32_t *)(iVar23 + 0x14) >> 0x1b & 1) != 0 || ((*(uint32_t *)(iVar23 + 0x14) >> 0x1a & 1) != 0)))))) &&
       (iVar24 = *(int64_t *)(iVar25 + 0x418), *(int64_t *)(iVar24 + 0x418) != iVar23)) {
        do {
            if (iVar24 == iVar23) goto code_r0x00018014a8ae;
            iVar24 = *(int64_t *)(iVar24 + 0x410);
        } while (iVar24 != 0);
        goto code_r0x00018014a9b6;
    }
code_r0x00018014a8ae:
    if ((*(int64_t *)(iVar25 + 0x48) != *(int64_t *)(*(int64_t *)0x180781f28 + 0x2168)) &&
       ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) == 0 ||
        (*(int64_t *)(iVar25 + 0x428) != *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) + 0x428)))))
    goto code_r0x00018014a9b6;
    pfVar31 = (float *)(iVar38 + 0x128);
    if (*(char *)(iVar38 + 0xbaa) == '\0') {
        pfVar31 = (float *)(iVar38 + 300);
    }
    iVar32 = *(int32_t *)(arg1 + 0x1c);
    uVar26 = (uint64_t)((*(char *)(iVar38 + 0xbaa) != '\0') + 0x295);
    iVar25 = *(int64_t *)0x180781f28;
    piVar20 = (int32_t *)func_0x0001800f45c0(*(int64_t *)0x180781f28, uVar26);
    if (iVar32 == 0) {
        bVar44 = *(char *)(piVar20 + 2) == '\0';
code_r0x00018014a936:
        if (bVar44) {
code_r0x00018014a938:
            fVar51 = *pfVar31;
            if (fVar51 != 0.0) {
                fVar49 = *(float *)puVar34;
                fVar45 = *pfVar43;
                *(undefined4 *)(arg1 + 100) = 0;
                fVar51 = *(float *)(arg1 + 0x60) -
                         (((((fVar45 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech) * fVar51) / 3.0;
                fVar49 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar49);
                if (fVar49 <= fVar51) {
                    fVar51 = fVar49;
                }
                if (fVar51 <= 0.0) {
                    fVar51 = 0.0;
                }
                *(float *)(arg1 + 0x60) = fVar51;
            }
        }
    } else {
        if (*piVar20 == iVar32) goto code_r0x00018014a938;
        if (*(char *)(piVar20 + 2) == '\0') {
            bVar44 = *piVar20 == -1;
            goto code_r0x00018014a936;
        }
    }
    *(int32_t *)(iVar25 + -0x130 + uVar26 * 0xc) = iVar32;
    *(int32_t *)(iVar25 + -0x134 + uVar26 * 0xc) = iVar32;
    *(undefined2 *)(iVar25 + -300 + uVar26 * 0xc) = 0;
code_r0x00018014a9b6:
    fVar51 = *(float *)puVar34;
    fVar45 = *(float *)(arg1 + 0x54) - (*pfVar43 - fVar51);
    fVar49 = *(float *)(arg1 + 0x5c);
    if (fVar45 <= *(float *)(arg1 + 0x5c)) {
        fVar49 = fVar45;
    }
    if (fVar49 <= 0.0) {
        fVar49 = 0.0;
    }
    *(float *)(arg1 + 0x5c) = fVar49;
    fVar50 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar51);
    fVar45 = *(float *)(arg1 + 0x60);
    if (fVar50 <= *(float *)(arg1 + 0x60)) {
        fVar45 = fVar50;
    }
    if (fVar45 <= 0.0) {
        fVar45 = 0.0;
    }
    *(float *)(arg1 + 0x60) = fVar45;
    if (fVar49 == fVar45) {
        *(undefined4 *)(arg1 + 0x68) = 0;
    } else {
        fVar54 = *(float *)(iVar38 + 0x12f8) * 70.0;
        fVar50 = *(float *)(arg1 + 0x68);
        if (*(float *)(arg1 + 0x68) <= fVar54) {
            fVar50 = fVar54;
        }
        fVar54 = (float)((uint32_t)(fVar45 - fVar49) & 0x7fffffff) / 0.3;
        if (fVar50 <= fVar54) {
            fVar50 = fVar54;
        }
        *(float *)(arg1 + 0x68) = fVar50;
        fVar54 = fVar45;
        if ((*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1) &&
           (*(float *)(arg1 + 100) <= *(float *)(iVar38 + 0x12f8) * 10.0)) {
            fVar50 = fVar50 * *(float *)(iVar38 + 0x48);
            if (fVar45 <= fVar49) {
                fVar54 = fVar49;
                if ((fVar45 < fVar49) && (fVar54 = fVar49 - fVar50, fVar54 <= fVar45)) {
                    fVar54 = fVar45;
                }
            } else {
                fVar54 = fVar50 + fVar49;
                if (fVar45 <= fVar54) {
                    fVar54 = fVar45;
                }
            }
        }
        *(float *)(arg1 + 0x5c) = fVar54;
    }
    uVar18 = *puVar34;
    *(float *)(arg1 + 0x6c) = fVar51 + var_108h._4_4_ + var_100h[1];
    *(float *)(arg1 + 0x70) = (*(float *)(arg1 + 0x40) - var_e8h._4_4_) - var_ech;
    iVar38 = *(int64_t *)(iVar38 + 0x15e0);
    *(undefined8 *)(iVar38 + 0x158) = uVar18;
    var_128h = CONCAT44(*(float *)(arg1 + 0x44) - *(float *)(arg1 + 0x3c), *(undefined4 *)(arg1 + 0x54));
    func_0x00018010bbf0(&var_128h);
    fVar49 = *(float *)(arg1 + 0x58) + *(float *)puVar34;
    fVar51 = *(float *)(iVar38 + 0x178);
    if (*(float *)(iVar38 + 0x178) <= fVar49) {
        fVar51 = fVar49;
    }
    *(float *)(iVar38 + 0x178) = fVar51;
    func_0x000180459870(var_d8h ^ (uint64_t)auStackY_198);
    return;
code_r0x000180149c5c:
    uVar22 = (int32_t)uVar26 + 1;
    uVar26 = (uint64_t)uVar22;
    if (iVar39 <= (int32_t)uVar22) goto code_r0x000180149c63;
    goto code_r0x000180149c50;
}

// ============================================================
// Function: FUN_180148fdd
// Address: 0x180148fdd
// Size: 96 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_144h
// WARNING: Variable defined which should be unmapped: var_178h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180148fa0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined auVar3 [16];
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    bool bVar13;
    bool bVar14;
    char cVar15;
    uint8_t uVar16;
    int32_t iVar17;
    undefined8 uVar18;
    int64_t iVar19;
    int32_t *piVar20;
    uint32_t uVar21;
    uint32_t uVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    uint64_t uVar26;
    undefined4 *puVar27;
    uint32_t uVar28;
    undefined4 *puVar29;
    uint32_t *puVar30;
    float *pfVar31;
    int32_t iVar32;
    uint32_t *puVar33;
    undefined8 *puVar34;
    uint32_t uVar35;
    int32_t iVar36;
    undefined4 *puVar37;
    int64_t iVar38;
    int32_t iVar39;
    char *pcVar40;
    int32_t iVar41;
    int64_t *piVar42;
    float *pfVar43;
    bool bVar44;
    float fVar45;
    float fVar46;
    float fVar47;
    float fVar48;
    float fVar49;
    float fVar50;
    float fVar51;
    undefined auVar52 [16];
    undefined auVar53 [16];
    float fVar54;
    undefined4 unaff_XMM12_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    float fVar55;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_198 [32];
    int64_t var_178h;
    undefined4 in_stack_fffffffffffffe98;
    undefined4 in_stack_fffffffffffffe9c;
    undefined4 uVar56;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int32_t var_148h;
    int64_t var_144h;
    undefined4 uStack_13c;
    undefined4 uVar57;
    undefined4 in_stack_fffffffffffffecc;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    float var_100h [2];
    int64_t var_f8h;
    float var_f0h;
    float var_ech;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar38 = *(int64_t *)0x180781f28;
    var_d8h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_198;
    fVar51 = *(float *)(arg1 + 0x48);
    var_118h = arg1 + 0x38;
    *(undefined *)(arg1 + 0x83) = 0;
    fVar49 = *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38);
    var_110h = arg1 + 0x40;
    uVar22 = *(uint32_t *)(arg1 + 8);
    *(float *)(arg1 + 0x48) = fVar49;
    uVar56 = CONCAT31((unkint3)((uint32_t)in_stack_fffffffffffffe9c >> 8), fVar49 < fVar51);
    auVar3._4_4_ = unaff_XMM12_Dc;
    auVar3._0_4_ = unaff_XMM12_Db;
    auVar3._8_4_ = unaff_XMM12_Dd;
    auVar3._12_4_ = 0;
    _var_98h = auVar3 << 0x20;
    bVar44 = false;
    uVar28 = 0;
    uVar35 = 0;
    _var_108h = ZEXT816(0);
    _var_f8h = ZEXT816(0);
    _var_e8h = ZEXT816(0);
    bVar13 = false;
    if (0 < (int32_t)uVar22) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)(arg1 + 0x10);
            iVar23 = (int64_t)(int32_t)uVar35 * 0x38;
            if ((*(int32_t *)(iVar23 + 0x10 + iVar25) < *(int32_t *)(arg1 + 0x34)) ||
               (*(char *)(iVar23 + 0x30 + iVar25) != '\0')) {
                if (*(int32_t *)(arg1 + 0x2c) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x2c) = 0;
                }
                if (*(int32_t *)(arg1 + 0x20) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x20) = 0;
                }
                if (*(int32_t *)(arg1 + 0x24) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x24) = 0;
                }
            } else {
                if (uVar28 != uVar35) {
                    auVar3 = *(undefined (*) [16])(iVar23 + 0x10 + iVar25);
                    puVar37 = (undefined4 *)(iVar23 + 0x20 + iVar25);
                    uVar57 = *puVar37;
                    uVar1 = puVar37[1];
                    uVar2 = puVar37[2];
                    uVar4 = puVar37[3];
                    uVar18 = *(undefined8 *)(iVar23 + 0x30 + iVar25);
                    iVar24 = (int64_t)(int32_t)uVar28 * 0x38;
                    *(undefined (*) [16])(iVar24 + iVar25) = *(undefined (*) [16])(iVar23 + iVar25);
                    *(undefined (*) [16])(iVar24 + 0x10 + iVar25) = auVar3;
                    puVar37 = (undefined4 *)(iVar24 + 0x20 + iVar25);
                    *puVar37 = uVar57;
                    puVar37[1] = uVar1;
                    puVar37[2] = uVar2;
                    puVar37[3] = uVar4;
                    *(undefined8 *)(iVar24 + 0x30 + iVar25) = uVar18;
                }
                iVar23 = (int64_t)(int32_t)uVar28 * 0x38;
                iVar25 = *(int64_t *)(arg1 + 0x10);
                uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                *(int16_t *)(iVar23 + 0x2e + iVar25) = (int16_t)uVar28;
                if ((uVar22 & 0x40) == 0) {
                    uVar26 = (uint64_t)(((uVar22 & 0x80) != 0) + 1);
                } else {
                    uVar26 = 0;
                }
                if (0 < (int32_t)uVar28) {
                    uVar22 = *(uint32_t *)(*(int64_t *)(arg1 + 0x10) + -0x34 + iVar23);
                    cVar15 = '\0';
                    if ((uVar22 & 0x40) == 0) {
                        cVar15 = ((uVar22 & 0x80) != 0) + '\x01';
                    }
                    if ((int32_t)uVar26 == 0) {
                        if (cVar15 == '\0') goto code_r0x000180149140;
                        bVar44 = true;
                    }
                    if (cVar15 == '\x02') {
                        if ((int32_t)uVar26 != 2) {
                            bVar44 = true;
                        }
                        var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                        uVar28 = uVar28 + 1;
                        goto code_r0x000180149172;
                    }
                }
code_r0x000180149140:
                var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                uVar28 = uVar28 + 1;
            }
code_r0x000180149172:
            uVar22 = *(uint32_t *)(arg1 + 8);
            uVar35 = uVar35 + 1;
            bVar13 = bVar44;
        } while ((int32_t)uVar35 < (int32_t)uVar22);
    }
    uVar35 = 8;
    var_128h = arg1;
    if (uVar22 != uVar28) {
        iVar32 = *(int32_t *)(arg1 + 0xc);
        if (iVar32 < (int32_t)uVar28) {
            uVar22 = uVar35;
            if (iVar32 != 0) {
                uVar22 = iVar32 / 2 + iVar32;
            }
            uVar21 = uVar28;
            if ((int32_t)uVar28 < (int32_t)uVar22) {
                uVar21 = uVar22;
            }
            func_0x00018011f970(arg1 + 8, uVar21);
        }
        *(uint32_t *)(arg1 + 8) = uVar28;
        uVar22 = uVar28;
    }
    piVar42 = (int64_t *)(arg1 + 0x10);
    if ((bVar44) && (1 < uVar22)) {
        fcn.18046f0d0(CONCAT44(uVar56, in_stack_fffffffffffffe98));
    }
    fVar51 = *(float *)(iVar38 + 0xdf4);
    if (((int32_t)var_108h < 1) || (var_100h[1] = fVar51, (int32_t)((int32_t)var_e8h + (uint32_t)var_f8h) < 1)) {
        var_100h[1] = 0.0;
    }
    if (((int32_t)(uint32_t)var_f8h < 1) || (var_ech = fVar51, (int32_t)var_e8h < 1)) {
        var_ech = 0.0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x28);
    uVar21 = 0;
    uVar28 = 0;
    if (uVar22 != 0) {
        *(undefined4 *)(arg1 + 0x28) = 0;
        uVar28 = uVar22;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x24);
    if (uVar22 != 0) {
        *(uint32_t *)(arg1 + 0x20) = uVar22;
        *(undefined4 *)(arg1 + 0x24) = 0;
        uVar28 = uVar22;
    }
    if (*(int32_t *)(arg1 + 0x7c) != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (iVar32 < 1) {
code_r0x00018014939d:
            *(undefined4 *)(arg1 + 0x7c) = 0;
        } else {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar21 * 0x38;
                puVar37 = (undefined4 *)(uVar26 + iVar25);
                if (*(int32_t *)(uVar26 + iVar25) == *(int32_t *)(arg1 + 0x7c)) {
                    if ((puVar37[1] & 0x20) == 0) {
                        iVar41 = (int32_t)(uVar26 / 0x38) + (int32_t)*(int16_t *)(arg1 + 0x80);
                        if ((-1 < iVar41) && (iVar41 < iVar32)) {
                            puVar29 = (undefined4 *)((int64_t)iVar41 * 0x38 + iVar25);
                            if (((puVar29[1] & 0x20) == 0) && (((puVar29[1] ^ puVar37[1]) & 0xc0) == 0)) {
                                uVar18 = *(undefined8 *)(puVar37 + 0xc);
                                uVar57 = *puVar37;
                                uVar1 = puVar37[1];
                                uVar2 = puVar37[2];
                                uVar4 = puVar37[3];
                                uVar5 = puVar37[4];
                                uVar6 = puVar37[5];
                                uVar7 = puVar37[6];
                                uVar8 = puVar37[7];
                                uVar9 = puVar37[8];
                                uVar10 = puVar37[9];
                                uVar11 = puVar37[10];
                                uVar12 = puVar37[0xb];
                                if (*(int16_t *)(arg1 + 0x80) < 1) {
                                    puVar37 = puVar29 + 0xe;
                                    puVar27 = puVar29;
                                } else {
                                    puVar27 = puVar37 + 0xe;
                                }
                                fcn.180498030(puVar37, puVar27);
                                *puVar29 = uVar57;
                                puVar29[1] = uVar1;
                                puVar29[2] = uVar2;
                                puVar29[3] = uVar4;
                                puVar29[4] = uVar5;
                                puVar29[5] = uVar6;
                                puVar29[6] = uVar7;
                                puVar29[7] = uVar8;
                                puVar29[8] = uVar9;
                                puVar29[9] = uVar10;
                                puVar29[10] = uVar11;
                                puVar29[0xb] = uVar12;
                                *(undefined8 *)(puVar29 + 0xc) = uVar18;
                                if (((*(uint32_t *)(arg1 + 0x18) & 0x400000) != 0) &&
                                   (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)) {
                                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) =
                                         *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
                                }
                                if (*(uint32_t *)(arg1 + 0x7c) == *(uint32_t *)(arg1 + 0x20)) {
                                    uVar28 = *(uint32_t *)(arg1 + 0x7c);
                                }
                            }
                        }
                    }
                    goto code_r0x00018014939d;
                }
                uVar21 = uVar21 + 1;
            } while ((int32_t)uVar21 < iVar32);
            *(undefined4 *)(arg1 + 0x7c) = 0;
        }
    }
    iVar25 = *(int64_t *)0x180781f28;
    puVar33 = (uint32_t *)0x0;
    if ((*(uint8_t *)(arg1 + 0x18) & 4) != 0) {
        uVar57 = *(undefined4 *)(arg1 + 0x3c);
        var_148h = 0;
        fVar49 = *(float *)(*(int64_t *)0x180781f28 + 0xde0);
        iVar23 = *(int64_t *)0x180781f28 + 0x20c0;
        iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
        uVar1 = *(undefined4 *)(iVar24 + 0x158);
        uVar2 = *(undefined4 *)(iVar24 + 0x15c);
        *(float *)(iVar24 + 0x158) = *(float *)(arg1 + 0x38) - fVar49;
        *(undefined4 *)(iVar24 + 0x15c) = uVar57;
        *(float *)(arg1 + 0x38) = fVar49 + fVar45 + *(float *)(arg1 + 0x38);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        uVar57 = *(undefined4 *)(iVar25 + 0xed8);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        fVar49 = *(float *)(iVar25 + 0xedc);
        fcn.18011f2b0(iVar23, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar57;
            *(float *)(iVar25 + 0xedc) = fVar49 * 0.5;
        }
        iVar25 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        uVar57 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x102c);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar25 + 0x1020) = 0;
            *(undefined8 *)(iVar25 + 0x1028) = 0;
        }
        cVar15 = func_0x00018013d0a0();
        fcn.1800f6770(2);
        if (cVar15 != '\0') {
            iVar32 = 0;
            if (0 < *(int32_t *)(arg1 + 8)) {
                do {
                    puVar30 = (uint32_t *)((int64_t)iVar32 * 0x38 + *piVar42);
                    if (((puVar30[1] & 0x200000) == 0) &&
                       (cVar15 = fcn.180146c70(CONCAT44(uStack_13c, var_144h._4_4_), 
                                               CONCAT44(in_stack_fffffffffffffecc, uVar57)), cVar15 != '\0')) {
                        puVar33 = puVar30;
                    }
                    iVar32 = iVar32 + 1;
                } while (iVar32 < *(int32_t *)(arg1 + 8));
            }
            iVar25 = *(int64_t *)0x180781f28;
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) + -1;
            iVar32 = func_0x000180498f10(*(undefined8 *)(*(int64_t *)(iVar25 + 0x15e0) + 8), &var_148h);
            if (iVar32 == 0) {
                func_0x00018010d5c0();
            } else if (*(code **)(iVar25 + 0x2a40) != (code *)0x0) {
                (**(code **)(iVar25 + 0x2a40))(iVar25, *(undefined8 *)(iVar25 + 0x2a48));
            }
        }
        *(undefined4 *)(iVar24 + 0x158) = uVar1;
        *(undefined4 *)(iVar24 + 0x15c) = uVar2;
        if (puVar33 != (uint32_t *)0x0) {
            uVar28 = *puVar33;
            *(uint32_t *)(arg1 + 0x20) = uVar28;
        }
    }
    iVar41 = 1;
    uVar22 = *(uint32_t *)(arg1 + 8);
    var_144h._0_4_ = (int32_t)var_e8h + (int32_t)var_108h;
    var_148h = 0;
    iVar32 = *(int32_t *)(iVar38 + 0x257c);
    var_144h._4_4_ = (int32_t)var_108h;
    if (iVar32 < (int32_t)uVar22) {
        if (iVar32 != 0) {
            uVar35 = iVar32 / 2 + iVar32;
        }
        uVar21 = uVar22;
        if ((int32_t)uVar22 < (int32_t)uVar35) {
            uVar21 = uVar35;
        }
        if (iVar32 < (int32_t)uVar21) {
            uVar18 = fcn.18046d050((int64_t)(int32_t)uVar21 * 0xc);
            if (*(int64_t *)(iVar38 + 0x2580) != 0) {
                fcn.180498030(uVar18);
                fcn.180460d90(*(undefined8 *)(iVar38 + 0x2580));
            }
            *(undefined8 *)(iVar38 + 0x2580) = uVar18;
            *(uint32_t *)(iVar38 + 0x257c) = uVar21;
        }
    }
    *(uint32_t *)(iVar38 + 0x2578) = uVar22;
    if ((*(uint8_t *)(arg1 + 0x18) & 0x80) == 0) {
        fVar49 = 1.0;
    } else {
        fVar49 = *(float *)(iVar38 + 0xe40);
    }
    iVar32 = *(int32_t *)(arg1 + 8);
    iVar39 = 0;
    var_130h = 0;
    bVar44 = false;
    uVar22 = 0xffffffff;
    bVar13 = false;
    if (0 < iVar32) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)0x180781f28;
            puVar33 = (uint32_t *)((int64_t)iVar39 * 0x38 + *piVar42);
            if (((var_130h == 0) || (*(int32_t *)(var_130h + 0x14) < (int32_t)puVar33[5])) &&
               ((puVar33[1] & 0x200000) == 0)) {
                var_130h = (int64_t)puVar33;
            }
            uVar35 = *puVar33;
            if (uVar35 == *(uint32_t *)(arg1 + 0x20)) {
                bVar44 = true;
            }
            if ((uVar28 == 0) && (*(uint32_t *)(iVar38 + 0x23a4) == uVar35)) {
                uVar28 = uVar35;
            }
            auVar52 = ZEXT416(puVar33[9]);
            if ((float)puVar33[9] < 0.0) {
                uVar35 = puVar33[1];
                var_178h._0_4_ = 0xbf800000;
                fcn.1800fe0a0(CONCAT44(var_178h._4_4_, 0xbf800000), SUB168(_var_98h, 8));
                fVar45 = *(float *)(iVar25 + 0xddc);
                if ((uVar35 & 0x100001) == 0x100000) {
                    fVar50 = fVar45 + 1.0;
                } else {
                    fVar50 = *(float *)(iVar25 + 0x12f8) + *(float *)(iVar25 + 0xdf4) + fVar45;
                }
                fVar50 = fVar50 + var_120h + fVar45;
                auVar52 = ZEXT416((uint32_t)fVar50);
                fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 20.0;
                if (fVar45 <= fVar50) {
                    auVar52 = ZEXT416((uint32_t)fVar45);
                }
            }
            uVar35 = puVar33[1];
            puVar33[8] = (uint32_t)auVar52._0_4_;
            if ((uVar35 >> 0x15 & 1) == 0) {
                if (auVar52._0_4_ <= *(float *)(iVar38 + 0xe3c)) {
                    auVar52._0_4_ = *(float *)(iVar38 + 0xe3c);
                }
                puVar33[8] = auVar52._0_4_;
            }
            if ((uVar35 & 0x40) == 0) {
                uVar35 = ((uVar35 & 0x80) != 0) + 1;
            } else {
                uVar35 = 0;
            }
            uVar26 = (uint64_t)uVar35;
            if (uVar35 == uVar22) {
                fVar50 = auVar52._0_4_ + fVar51;
                fVar45 = fVar51;
            } else {
                fVar50 = auVar52._0_4_ + 0.0;
                fVar45 = 0.0;
            }
            var_100h[uVar26 * 4 + -1] = fVar50 + var_100h[uVar26 * 4 + -1];
            fVar50 = (float)puVar33[8];
            if (fVar49 <= (float)puVar33[8]) {
                fVar50 = fVar49;
            }
            var_100h[uVar26 * 4] = fVar50 + fVar45 + var_100h[uVar26 * 4];
            iVar23 = (int64_t)(&var_148h)[uVar26];
            (&var_148h)[uVar26] = (&var_148h)[uVar26] + 1;
            iVar25 = *(int64_t *)(iVar38 + 0x2580);
            *(int32_t *)(iVar25 + iVar23 * 0xc) = iVar39;
            iVar39 = iVar39 + 1;
            uVar22 = puVar33[8];
            *(uint32_t *)(iVar25 + 8 + iVar23 * 0xc) = uVar22;
            *(uint32_t *)(iVar25 + 4 + iVar23 * 0xc) = uVar22;
            fVar45 = (float)puVar33[8];
            if (fVar45 <= 1.0) {
                fVar45 = 1.0;
            }
            puVar33[7] = (uint32_t)fVar45;
            iVar32 = *(int32_t *)(arg1 + 8);
            uVar22 = uVar35;
            bVar13 = bVar44;
        } while (iVar39 < iVar32);
    }
    uVar22 = *(uint32_t *)(arg1 + 0x18);
    *(float *)(arg1 + 0x58) = var_100h[1] + var_108h._4_4_ + 0.0 + var_f8h._4_4_ + var_ech + var_e8h._4_4_ + var_dch;
    iVar25 = *(int64_t *)0x180781f28;
    if (((uVar22 & 0x200) == 0) && (-1 < (char)uVar22)) {
        bVar14 = false;
code_r0x00018014992e:
        bVar13 = bVar14;
        fVar51 = var_e0h + var_dch + var_100h[0] + var_100h[1] + 0.0 + var_f0h + var_ech;
    } else {
        bVar13 = true;
        bVar14 = true;
        if ((uVar22 & 0x200) == 0) goto code_r0x00018014992e;
        fVar51 = *(float *)(arg1 + 0x54);
    }
    if ((((fVar51 <= *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38)) || (iVar32 < 2)) || ((uVar22 & 0x10) != 0)) ||
       (!bVar13)) {
        *(undefined *)(arg1 + 0x86) = 0;
    } else {
        *(undefined *)(arg1 + 0x86) = 1;
        var_148h = 0;
        fVar51 = *(float *)(iVar25 + 0x12f8);
        iVar23 = *(int64_t *)(iVar25 + 0x15e0);
        fVar54 = fVar51 - 2.0;
        fVar45 = *(float *)(iVar25 + 0xde0);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        uVar57 = *(undefined4 *)(iVar23 + 0x158);
        uVar1 = *(undefined4 *)(iVar25 + 0xed8);
        fVar50 = *(float *)(iVar25 + 0xedc);
        fVar55 = fVar54 + fVar54;
        var_120h = *(float *)(iVar23 + 0x15c);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        fcn.18011f2b0(iVar25 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar1;
            *(float *)(iVar25 + 0xedc) = fVar50 * 0.5;
        }
        iVar24 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar24 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar24 + 0x1020) = 0;
            *(undefined8 *)(iVar24 + 0x1028) = 0;
        }
        iVar24 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 10;
        piVar20 = (int32_t *)(iVar24 + 0x2100);
        iVar32 = *(int32_t *)(iVar24 + 0x2104);
        uVar1 = *(undefined4 *)(iVar24 + 0x1f78);
        if (*piVar20 == iVar32) {
            iVar39 = *piVar20 + 1;
            if (iVar32 == 0) {
                iVar32 = 8;
            } else {
                iVar32 = iVar32 / 2 + iVar32;
            }
            if (iVar39 < iVar32) {
                iVar39 = iVar32;
            }
            fcn.18011fb10(piVar20, iVar39);
        }
        *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + (int64_t)*piVar20 * 4) = uVar1;
        *piVar20 = *piVar20 + 1;
        uVar1 = *(undefined4 *)(iVar25 + 0xa8);
        uVar2 = *(undefined4 *)(iVar25 + 0xac);
        *(undefined4 *)(iVar25 + 0xa8) = 0x3e800000;
        *(undefined4 *)(iVar25 + 0xac) = 0x3e4ccccd;
        fVar46 = *(float *)(arg1 + 0x40) - fVar55;
        fVar50 = *(float *)(arg1 + 0x38);
        if (*(float *)(arg1 + 0x38) <= fVar46) {
            fVar50 = fVar46;
        }
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50;
        uVar16 = func_0x00018013a9f0(0x180645ba0, 0, CONCAT44(fVar45 + fVar45 + fVar51, fVar54));
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50 + fVar54;
        cVar15 = func_0x00018013a9f0(0x180645ba4, 1);
        iVar24 = *(int64_t *)0x180781f28;
        if (cVar15 == '\0') {
            iVar32 = (uVar16 ^ 1) - 1;
        } else {
            iVar32 = 1;
        }
        iVar39 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
        if (iVar39 < 2) {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48));
            }
        } else {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar39 + -1;
            *(undefined4 *)(iVar24 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + -8 + (int64_t)iVar39 * 4)
            ;
        }
        fcn.1800f6770();
        *(undefined4 *)(iVar25 + 0xac) = uVar2;
        *(undefined4 *)(iVar25 + 0xa8) = uVar1;
        if (iVar32 == 0) {
            puVar33 = (uint32_t *)0x0;
code_r0x000180149cf6:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
            if ((puVar33 != (uint32_t *)0x0) && (uVar28 = *puVar33, (puVar33[1] & 0x200000) == 0)) {
                *(uint32_t *)(arg1 + 0x20) = uVar28;
            }
        } else {
            if ((*(int32_t *)(arg1 + 0x20) != 0) && (iVar39 = *(int32_t *)(arg1 + 8), 0 < iVar39)) {
                uVar26 = 0;
                iVar25 = *piVar42;
code_r0x000180149c50:
                if (*(int32_t *)(uVar26 * 0x38 + iVar25) != *(int32_t *)(arg1 + 0x20)) goto code_r0x000180149c5c;
                uVar26 = (uVar26 * 0x38) / 0x38;
                iVar36 = (int32_t)uVar26 + iVar32;
                do {
                    if ((iVar36 < 0) || (iVar17 = iVar36, iVar39 <= iVar36)) {
                        iVar17 = (int32_t)uVar26;
                    }
                    puVar33 = (uint32_t *)((int64_t)iVar17 * 0x38 + iVar25);
                } while ((((*(uint32_t *)(iVar25 + 4 + (int64_t)iVar17 * 0x38) & 0x200000) != 0) &&
                         (iVar36 = iVar36 + iVar32, -1 < iVar36)) &&
                        (uVar26 = (uint64_t)(uint32_t)((int32_t)uVar26 + iVar32), iVar36 < iVar39));
                goto code_r0x000180149cf6;
            }
code_r0x000180149c63:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
        }
    }
    pfVar43 = (float *)(arg1 + 0x40);
    pcVar40 = (char *)(arg1 + 0x86);
    puVar34 = (undefined8 *)(arg1 + 0x38);
    if ((uVar28 == 0) && ((char)uVar56 != '\0')) {
        uVar28 = *(uint32_t *)(arg1 + 0x20);
    }
    fVar51 = *pfVar43 - *(float *)puVar34;
    fVar45 = var_e8h._4_4_ + var_dch + var_108h._4_4_ + var_100h[1];
    if (fVar51 <= fVar45) {
        fVar50 = fVar45 - fVar51;
    } else {
        fVar50 = (var_f8h._4_4_ + var_ech) - ((fVar51 - (var_108h._4_4_ + var_100h[1])) - (var_e8h._4_4_ + var_dch));
        if (fVar50 <= 0.0) {
            fVar50 = 0.0;
        }
    }
    if (1.0 <= fVar50) {
        if ((*(uint32_t *)(arg1 + 0x18) & 0x180) == 0) {
            if (fVar45 < fVar51) goto code_r0x00018014a4db;
code_r0x000180149e0c:
            uVar22 = (int32_t)var_e8h + (int32_t)var_108h;
            if (fVar51 <= fVar45) {
                iVar32 = 0;
            } else {
                iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            }
        } else {
            if (fVar51 <= fVar45) goto code_r0x000180149e0c;
            iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            uVar22 = (uint32_t)var_f8h;
        }
        iVar25 = *(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc;
        if (uVar22 == 1) {
            if (0.0 <= *(float *)(iVar25 + 4)) {
                fVar50 = *(float *)(iVar25 + 4) - fVar50;
                if (fVar50 <= fVar49) {
                    fVar50 = fVar49;
                }
                *(float *)(iVar25 + 4) = fVar50;
            }
        } else {
            if (1 < uVar22) {
                fcn.18046f0d0(CONCAT44(uVar56, uVar28));
            }
            while ((0.001 < fVar50 && (iVar41 < (int32_t)uVar22))) {
                fVar51 = *(float *)(iVar25 + 4);
                do {
                    fVar45 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                    if (fVar45 < fVar51) {
                        if (0.0 <= fVar45) {
                            fVar45 = fVar51 - fVar45;
                            goto code_r0x000180149ee6;
                        }
                        break;
                    }
                    iVar41 = iVar41 + 1;
                } while (iVar41 < (int32_t)uVar22);
                fVar45 = fVar51 - 1.0;
code_r0x000180149ee6:
                fVar54 = fVar51 - fVar49;
                if (fVar45 <= fVar51 - fVar49) {
                    fVar54 = fVar45;
                }
                if (fVar54 <= 0.0) break;
                iVar39 = 0;
                fVar51 = fVar50 / (float)iVar41;
                if (fVar54 <= fVar50 / (float)iVar41) {
                    fVar51 = fVar54;
                }
                if (3 < iVar41) {
                    do {
                        iVar23 = (int64_t)iVar39;
                        iVar39 = iVar39 + 4;
                        fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar55 = fVar45 - fVar49;
                        fVar54 = fVar51;
                        if (fVar55 <= fVar51) {
                            fVar54 = fVar55;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                        fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar46 = fVar45 - fVar49;
                        fVar55 = fVar51;
                        if (fVar46 <= fVar51) {
                            fVar55 = fVar46;
                        }
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar45 - fVar55;
                        fVar45 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar47 = fVar45 - fVar49;
                        fVar46 = fVar51;
                        if (fVar47 <= fVar51) {
                            fVar46 = fVar47;
                        }
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar45 - fVar46;
                        fVar45 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar48 = fVar45 - fVar49;
                        fVar47 = fVar51;
                        if (fVar48 <= fVar51) {
                            fVar47 = fVar48;
                        }
                        fVar50 = (((fVar50 - fVar54) - fVar55) - fVar46) - fVar47;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar45 - fVar47;
                    } while (iVar39 < iVar41 + -3);
                }
                while (iVar39 < iVar41) {
                    iVar23 = (int64_t)iVar39;
                    iVar39 = iVar39 + 1;
                    fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar55 = fVar45 - fVar49;
                    fVar54 = fVar51;
                    if (fVar55 <= fVar51) {
                        fVar54 = fVar55;
                    }
                    fVar50 = fVar50 - fVar54;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                }
            }
            iVar41 = 0;
            fVar51 = 0.0;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 4;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar48 = (float)(int32_t)fVar49;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar48;
                    fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                    fVar46 = (float)(int32_t)fVar45;
                    *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar46;
                    fVar50 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                    fVar55 = (float)(int32_t)fVar50;
                    *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar55;
                    fVar54 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                    fVar47 = (float)(int32_t)fVar54;
                    *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar47;
                    fVar51 = (fVar49 - fVar48) + fVar51 + (fVar45 - fVar46) + (fVar50 - fVar55) + (fVar54 - fVar47);
                } while (iVar41 < (int32_t)(uVar22 - 3));
            }
            for (; iVar41 < (int32_t)uVar22; iVar41 = iVar41 + 1) {
                fVar49 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                fVar45 = (float)(int32_t)fVar49;
                *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc) = fVar45;
                fVar51 = fVar51 + (fVar49 - fVar45);
            }
            while (0.0 < fVar51) {
                iVar41 = 0;
                if (3 < (int32_t)uVar22) {
                    do {
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar23 = (int64_t)iVar41;
                        fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 - fVar45 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar50 = *(float *)(iVar25 + 0x14 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar50) {
                            fVar50 = 1.0;
                        }
                        fVar51 = (fVar51 - fVar45) - fVar50;
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar49 + fVar50;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x20 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar41 = iVar41 + 4;
                        fVar49 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x2c + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar49 + fVar45;
                    } while (iVar41 < (int32_t)(uVar22 - 3));
                }
                while (iVar41 < (int32_t)uVar22) {
                    if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 1;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                    if (1.0 <= fVar45) {
                        fVar45 = 1.0;
                    }
                    fVar51 = fVar51 - fVar45;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                }
            }
        }
code_r0x00018014a22a:
        iVar41 = iVar32 + uVar22;
        if (iVar32 < iVar41) {
            arg1 = var_128h;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar25 = (int64_t)iVar32;
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x10 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0xc + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x1c + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x18 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x28 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar25 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x24 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar25 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar24 = 0;
                        }
                        var_100h[iVar24 * 4 + -1] =
                             var_100h[iVar24 * 4 + -1] - (*(float *)(iVar25 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar25 + 0x1c + iVar23) = fVar49;
                    }
                    iVar32 = iVar32 + 4;
                } while (iVar32 < iVar41 + -3);
                if (iVar41 <= iVar32) goto code_r0x00018014a4d3;
            }
            do {
                fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + (int64_t)iVar32 * 0xc);
                if (0.0 <= fVar51) {
                    iVar25 = *piVar42;
                    fVar49 = 1.0;
                    if (1.0 <= fVar51) {
                        fVar49 = fVar51;
                    }
                    iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc) * 0x38;
                    uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                    if ((uVar22 & 0x40) == 0) {
                        iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                    } else {
                        iVar24 = 0;
                    }
                    var_100h[iVar24 * 4 + -1] =
                         var_100h[iVar24 * 4 + -1] - (*(float *)(iVar23 + 0x1c + iVar25) - fVar49);
                    *(float *)(iVar23 + 0x1c + iVar25) = fVar49;
                }
                iVar32 = iVar32 + 1;
                puVar34 = (undefined8 *)var_118h;
                pfVar43 = (float *)var_110h;
            } while (iVar32 < iVar41);
        } else {
code_r0x00018014a4d3:
            puVar34 = (undefined8 *)(arg1 + 0x38);
            pfVar43 = (float *)(arg1 + 0x40);
        }
    }
code_r0x00018014a4db:
    uVar35 = 0;
    auVar53 = ZEXT816(0);
    *(undefined4 *)(arg1 + 0x54) = 0;
    uVar22 = uVar35;
    if (0 < (int32_t)var_108h) {
        do {
            iVar25 = *piVar42;
            iVar23 = (int64_t)(int32_t)uVar22 * 0x38;
            *(float *)(iVar23 + 0x18 + iVar25) = auVar53._0_4_;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_108h + -1) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            auVar53._0_4_ = auVar53._0_4_ + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_108h);
    }
    fVar49 = auVar53._0_4_ + var_100h[1];
    fVar51 = var_100h[1] + var_108h._4_4_;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    uVar22 = uVar35;
    if (0 < (int32_t)(uint32_t)var_f8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar49;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)((uint32_t)var_f8h + -1)) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar49 = fVar49 + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)(uint32_t)var_f8h);
    }
    fVar51 = var_f8h._4_4_ + var_ech;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    fVar45 = (*(float *)(arg1 + 0x40) - *(float *)puVar34) - var_e8h._4_4_;
    fVar51 = 0.0;
    if (0.0 <= fVar45) {
        fVar51 = fVar45;
    }
    if (var_ech + fVar49 <= fVar51) {
        fVar51 = var_ech + fVar49;
    }
    uVar22 = uVar35;
    if (0 < (int32_t)var_e8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h + (uint32_t)var_f8h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar51;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_e8h + -1) {
                fVar49 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar49 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar51 = fVar51 + fVar49 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_e8h);
    }
    fVar51 = var_e8h._4_4_ + var_dch;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    func_0x00018011f640(arg1 + 0xa0, 0);
    if ((!bVar44) && (*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1)) {
        *(undefined4 *)(arg1 + 0x20) = 0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x20);
    if (((*(uint32_t *)(arg1 + 0x20) == 0) && (uVar22 = uVar35, *(int32_t *)(arg1 + 0x24) == 0)) && (var_130h != 0)) {
        uVar28 = *(uint32_t *)var_130h;
        *(uint32_t *)(arg1 + 0x20) = uVar28;
        uVar22 = uVar28;
    }
    *(uint32_t *)(arg1 + 0x2c) = uVar22;
    *(undefined *)(arg1 + 0x84) = 0;
    iVar25 = *(int64_t *)(iVar38 + 0x23c0);
    if (((iVar25 != 0) && (*(int64_t *)(iVar25 + 0x4c0) != 0)) &&
       (*(int64_t *)(*(int64_t *)(iVar25 + 0x4c0) + 0x40) == arg1)) {
        uVar28 = *(uint32_t *)(iVar25 + 200);
        *(uint32_t *)(arg1 + 0x2c) = uVar28;
    }
    if (uVar28 != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (0 < iVar32) {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar35 * 0x38;
                if (*(uint32_t *)(uVar26 + iVar25) == uVar28) {
                    if ((*(uint8_t *)(uVar26 + 4 + iVar25) & 0xc0) != 0) break;
                    fVar51 = *pfVar43;
                    fVar49 = *(float *)puVar34;
                    fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
                    iVar41 = (int32_t)(uVar26 / 0x38);
                    if ((int32_t)var_108h + -1 < iVar41) {
                        fVar50 = (float)((uint32_t)fVar45 ^ 0x80000000);
                    } else {
                        fVar50 = 0.0;
                    }
                    fVar54 = *(float *)(uVar26 + 0x18 + iVar25) - var_108h._4_4_;
                    fVar50 = fVar54 + fVar50;
                    if (iVar32 - (int32_t)var_e8h <= iVar41 + 1) {
                        fVar45 = 1.0;
                    }
                    fVar55 = *(float *)(uVar26 + 0x1c + iVar25);
                    *(undefined4 *)(arg1 + 100) = 0;
                    fVar45 = fVar54 + fVar55 + fVar45;
                    if (*(float *)(arg1 + 0x60) <= fVar50) {
                        fVar51 = (((fVar51 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech;
                        if (fVar45 - fVar50 < fVar51) {
                            if (*(float *)(arg1 + 0x60) < fVar45 - fVar51) {
                                *(float *)(arg1 + 0x60) = fVar45 - fVar51;
                                fVar51 = (fVar50 - fVar51) - *(float *)(arg1 + 0x5c);
                                if (fVar51 <= 0.0) {
                                    fVar51 = 0.0;
                                }
                                *(float *)(arg1 + 100) = fVar51;
                            }
                            break;
                        }
                    }
                    fVar45 = *(float *)(arg1 + 0x5c) - fVar45;
                    *(float *)(arg1 + 0x60) = fVar50;
                    if (fVar45 <= 0.0) {
                        fVar45 = 0.0;
                    }
                    *(float *)(arg1 + 100) = fVar45;
                    break;
                }
                uVar35 = uVar35 + 1;
            } while ((int32_t)uVar35 < iVar32);
        }
        goto code_r0x00018014a9b6;
    }
    if ((*pcVar40 == '\0') || (cVar15 = func_0x000180108120(puVar34, pfVar43, 1), cVar15 == '\0'))
    goto code_r0x00018014a9b6;
    iVar25 = *(int64_t *)(iVar38 + 0x15e0);
    if (((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) != 0) &&
        ((((iVar23 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) + 0x428), iVar23 != 0 &&
           (*(char *)(iVar23 + 0x10a) != '\0')) && (iVar23 != *(int64_t *)(iVar25 + 0x428))) &&
         (((*(uint32_t *)(iVar23 + 0x14) >> 0x1b & 1) != 0 || ((*(uint32_t *)(iVar23 + 0x14) >> 0x1a & 1) != 0)))))) &&
       (iVar24 = *(int64_t *)(iVar25 + 0x418), *(int64_t *)(iVar24 + 0x418) != iVar23)) {
        do {
            if (iVar24 == iVar23) goto code_r0x00018014a8ae;
            iVar24 = *(int64_t *)(iVar24 + 0x410);
        } while (iVar24 != 0);
        goto code_r0x00018014a9b6;
    }
code_r0x00018014a8ae:
    if ((*(int64_t *)(iVar25 + 0x48) != *(int64_t *)(*(int64_t *)0x180781f28 + 0x2168)) &&
       ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) == 0 ||
        (*(int64_t *)(iVar25 + 0x428) != *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) + 0x428)))))
    goto code_r0x00018014a9b6;
    pfVar31 = (float *)(iVar38 + 0x128);
    if (*(char *)(iVar38 + 0xbaa) == '\0') {
        pfVar31 = (float *)(iVar38 + 300);
    }
    iVar32 = *(int32_t *)(arg1 + 0x1c);
    uVar26 = (uint64_t)((*(char *)(iVar38 + 0xbaa) != '\0') + 0x295);
    iVar25 = *(int64_t *)0x180781f28;
    piVar20 = (int32_t *)func_0x0001800f45c0(*(int64_t *)0x180781f28, uVar26);
    if (iVar32 == 0) {
        bVar44 = *(char *)(piVar20 + 2) == '\0';
code_r0x00018014a936:
        if (bVar44) {
code_r0x00018014a938:
            fVar51 = *pfVar31;
            if (fVar51 != 0.0) {
                fVar49 = *(float *)puVar34;
                fVar45 = *pfVar43;
                *(undefined4 *)(arg1 + 100) = 0;
                fVar51 = *(float *)(arg1 + 0x60) -
                         (((((fVar45 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech) * fVar51) / 3.0;
                fVar49 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar49);
                if (fVar49 <= fVar51) {
                    fVar51 = fVar49;
                }
                if (fVar51 <= 0.0) {
                    fVar51 = 0.0;
                }
                *(float *)(arg1 + 0x60) = fVar51;
            }
        }
    } else {
        if (*piVar20 == iVar32) goto code_r0x00018014a938;
        if (*(char *)(piVar20 + 2) == '\0') {
            bVar44 = *piVar20 == -1;
            goto code_r0x00018014a936;
        }
    }
    *(int32_t *)(iVar25 + -0x130 + uVar26 * 0xc) = iVar32;
    *(int32_t *)(iVar25 + -0x134 + uVar26 * 0xc) = iVar32;
    *(undefined2 *)(iVar25 + -300 + uVar26 * 0xc) = 0;
code_r0x00018014a9b6:
    fVar51 = *(float *)puVar34;
    fVar45 = *(float *)(arg1 + 0x54) - (*pfVar43 - fVar51);
    fVar49 = *(float *)(arg1 + 0x5c);
    if (fVar45 <= *(float *)(arg1 + 0x5c)) {
        fVar49 = fVar45;
    }
    if (fVar49 <= 0.0) {
        fVar49 = 0.0;
    }
    *(float *)(arg1 + 0x5c) = fVar49;
    fVar50 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar51);
    fVar45 = *(float *)(arg1 + 0x60);
    if (fVar50 <= *(float *)(arg1 + 0x60)) {
        fVar45 = fVar50;
    }
    if (fVar45 <= 0.0) {
        fVar45 = 0.0;
    }
    *(float *)(arg1 + 0x60) = fVar45;
    if (fVar49 == fVar45) {
        *(undefined4 *)(arg1 + 0x68) = 0;
    } else {
        fVar54 = *(float *)(iVar38 + 0x12f8) * 70.0;
        fVar50 = *(float *)(arg1 + 0x68);
        if (*(float *)(arg1 + 0x68) <= fVar54) {
            fVar50 = fVar54;
        }
        fVar54 = (float)((uint32_t)(fVar45 - fVar49) & 0x7fffffff) / 0.3;
        if (fVar50 <= fVar54) {
            fVar50 = fVar54;
        }
        *(float *)(arg1 + 0x68) = fVar50;
        fVar54 = fVar45;
        if ((*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1) &&
           (*(float *)(arg1 + 100) <= *(float *)(iVar38 + 0x12f8) * 10.0)) {
            fVar50 = fVar50 * *(float *)(iVar38 + 0x48);
            if (fVar45 <= fVar49) {
                fVar54 = fVar49;
                if ((fVar45 < fVar49) && (fVar54 = fVar49 - fVar50, fVar54 <= fVar45)) {
                    fVar54 = fVar45;
                }
            } else {
                fVar54 = fVar50 + fVar49;
                if (fVar45 <= fVar54) {
                    fVar54 = fVar45;
                }
            }
        }
        *(float *)(arg1 + 0x5c) = fVar54;
    }
    uVar18 = *puVar34;
    *(float *)(arg1 + 0x6c) = fVar51 + var_108h._4_4_ + var_100h[1];
    *(float *)(arg1 + 0x70) = (*(float *)(arg1 + 0x40) - var_e8h._4_4_) - var_ech;
    iVar38 = *(int64_t *)(iVar38 + 0x15e0);
    *(undefined8 *)(iVar38 + 0x158) = uVar18;
    var_128h = CONCAT44(*(float *)(arg1 + 0x44) - *(float *)(arg1 + 0x3c), *(undefined4 *)(arg1 + 0x54));
    func_0x00018010bbf0(&var_128h);
    fVar49 = *(float *)(arg1 + 0x58) + *(float *)puVar34;
    fVar51 = *(float *)(iVar38 + 0x178);
    if (*(float *)(iVar38 + 0x178) <= fVar49) {
        fVar51 = fVar49;
    }
    *(float *)(iVar38 + 0x178) = fVar51;
    func_0x000180459870(var_d8h ^ (uint64_t)auStackY_198);
    return;
code_r0x000180149c5c:
    uVar22 = (int32_t)uVar26 + 1;
    uVar26 = (uint64_t)uVar22;
    if (iVar39 <= (int32_t)uVar22) goto code_r0x000180149c63;
    goto code_r0x000180149c50;
}

// ============================================================
// Function: FUN_18014903d
// Address: 0x18014903d
// Size: 570 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_144h
// WARNING: Variable defined which should be unmapped: var_178h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180148fa0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined auVar3 [16];
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    bool bVar13;
    bool bVar14;
    char cVar15;
    uint8_t uVar16;
    int32_t iVar17;
    undefined8 uVar18;
    int64_t iVar19;
    int32_t *piVar20;
    uint32_t uVar21;
    uint32_t uVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    uint64_t uVar26;
    undefined4 *puVar27;
    uint32_t uVar28;
    undefined4 *puVar29;
    uint32_t *puVar30;
    float *pfVar31;
    int32_t iVar32;
    uint32_t *puVar33;
    undefined8 *puVar34;
    uint32_t uVar35;
    int32_t iVar36;
    undefined4 *puVar37;
    int64_t iVar38;
    int32_t iVar39;
    char *pcVar40;
    int32_t iVar41;
    int64_t *piVar42;
    float *pfVar43;
    bool bVar44;
    float fVar45;
    float fVar46;
    float fVar47;
    float fVar48;
    float fVar49;
    float fVar50;
    float fVar51;
    undefined auVar52 [16];
    undefined auVar53 [16];
    float fVar54;
    undefined4 unaff_XMM12_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    float fVar55;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_198 [32];
    int64_t var_178h;
    undefined4 in_stack_fffffffffffffe98;
    undefined4 in_stack_fffffffffffffe9c;
    undefined4 uVar56;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int32_t var_148h;
    int64_t var_144h;
    undefined4 uStack_13c;
    undefined4 uVar57;
    undefined4 in_stack_fffffffffffffecc;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    float var_100h [2];
    int64_t var_f8h;
    float var_f0h;
    float var_ech;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar38 = *(int64_t *)0x180781f28;
    var_d8h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_198;
    fVar51 = *(float *)(arg1 + 0x48);
    var_118h = arg1 + 0x38;
    *(undefined *)(arg1 + 0x83) = 0;
    fVar49 = *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38);
    var_110h = arg1 + 0x40;
    uVar22 = *(uint32_t *)(arg1 + 8);
    *(float *)(arg1 + 0x48) = fVar49;
    uVar56 = CONCAT31((unkint3)((uint32_t)in_stack_fffffffffffffe9c >> 8), fVar49 < fVar51);
    auVar3._4_4_ = unaff_XMM12_Dc;
    auVar3._0_4_ = unaff_XMM12_Db;
    auVar3._8_4_ = unaff_XMM12_Dd;
    auVar3._12_4_ = 0;
    _var_98h = auVar3 << 0x20;
    bVar44 = false;
    uVar28 = 0;
    uVar35 = 0;
    _var_108h = ZEXT816(0);
    _var_f8h = ZEXT816(0);
    _var_e8h = ZEXT816(0);
    bVar13 = false;
    if (0 < (int32_t)uVar22) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)(arg1 + 0x10);
            iVar23 = (int64_t)(int32_t)uVar35 * 0x38;
            if ((*(int32_t *)(iVar23 + 0x10 + iVar25) < *(int32_t *)(arg1 + 0x34)) ||
               (*(char *)(iVar23 + 0x30 + iVar25) != '\0')) {
                if (*(int32_t *)(arg1 + 0x2c) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x2c) = 0;
                }
                if (*(int32_t *)(arg1 + 0x20) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x20) = 0;
                }
                if (*(int32_t *)(arg1 + 0x24) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x24) = 0;
                }
            } else {
                if (uVar28 != uVar35) {
                    auVar3 = *(undefined (*) [16])(iVar23 + 0x10 + iVar25);
                    puVar37 = (undefined4 *)(iVar23 + 0x20 + iVar25);
                    uVar57 = *puVar37;
                    uVar1 = puVar37[1];
                    uVar2 = puVar37[2];
                    uVar4 = puVar37[3];
                    uVar18 = *(undefined8 *)(iVar23 + 0x30 + iVar25);
                    iVar24 = (int64_t)(int32_t)uVar28 * 0x38;
                    *(undefined (*) [16])(iVar24 + iVar25) = *(undefined (*) [16])(iVar23 + iVar25);
                    *(undefined (*) [16])(iVar24 + 0x10 + iVar25) = auVar3;
                    puVar37 = (undefined4 *)(iVar24 + 0x20 + iVar25);
                    *puVar37 = uVar57;
                    puVar37[1] = uVar1;
                    puVar37[2] = uVar2;
                    puVar37[3] = uVar4;
                    *(undefined8 *)(iVar24 + 0x30 + iVar25) = uVar18;
                }
                iVar23 = (int64_t)(int32_t)uVar28 * 0x38;
                iVar25 = *(int64_t *)(arg1 + 0x10);
                uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                *(int16_t *)(iVar23 + 0x2e + iVar25) = (int16_t)uVar28;
                if ((uVar22 & 0x40) == 0) {
                    uVar26 = (uint64_t)(((uVar22 & 0x80) != 0) + 1);
                } else {
                    uVar26 = 0;
                }
                if (0 < (int32_t)uVar28) {
                    uVar22 = *(uint32_t *)(*(int64_t *)(arg1 + 0x10) + -0x34 + iVar23);
                    cVar15 = '\0';
                    if ((uVar22 & 0x40) == 0) {
                        cVar15 = ((uVar22 & 0x80) != 0) + '\x01';
                    }
                    if ((int32_t)uVar26 == 0) {
                        if (cVar15 == '\0') goto code_r0x000180149140;
                        bVar44 = true;
                    }
                    if (cVar15 == '\x02') {
                        if ((int32_t)uVar26 != 2) {
                            bVar44 = true;
                        }
                        var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                        uVar28 = uVar28 + 1;
                        goto code_r0x000180149172;
                    }
                }
code_r0x000180149140:
                var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                uVar28 = uVar28 + 1;
            }
code_r0x000180149172:
            uVar22 = *(uint32_t *)(arg1 + 8);
            uVar35 = uVar35 + 1;
            bVar13 = bVar44;
        } while ((int32_t)uVar35 < (int32_t)uVar22);
    }
    uVar35 = 8;
    var_128h = arg1;
    if (uVar22 != uVar28) {
        iVar32 = *(int32_t *)(arg1 + 0xc);
        if (iVar32 < (int32_t)uVar28) {
            uVar22 = uVar35;
            if (iVar32 != 0) {
                uVar22 = iVar32 / 2 + iVar32;
            }
            uVar21 = uVar28;
            if ((int32_t)uVar28 < (int32_t)uVar22) {
                uVar21 = uVar22;
            }
            func_0x00018011f970(arg1 + 8, uVar21);
        }
        *(uint32_t *)(arg1 + 8) = uVar28;
        uVar22 = uVar28;
    }
    piVar42 = (int64_t *)(arg1 + 0x10);
    if ((bVar44) && (1 < uVar22)) {
        fcn.18046f0d0(CONCAT44(uVar56, in_stack_fffffffffffffe98));
    }
    fVar51 = *(float *)(iVar38 + 0xdf4);
    if (((int32_t)var_108h < 1) || (var_100h[1] = fVar51, (int32_t)((int32_t)var_e8h + (uint32_t)var_f8h) < 1)) {
        var_100h[1] = 0.0;
    }
    if (((int32_t)(uint32_t)var_f8h < 1) || (var_ech = fVar51, (int32_t)var_e8h < 1)) {
        var_ech = 0.0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x28);
    uVar21 = 0;
    uVar28 = 0;
    if (uVar22 != 0) {
        *(undefined4 *)(arg1 + 0x28) = 0;
        uVar28 = uVar22;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x24);
    if (uVar22 != 0) {
        *(uint32_t *)(arg1 + 0x20) = uVar22;
        *(undefined4 *)(arg1 + 0x24) = 0;
        uVar28 = uVar22;
    }
    if (*(int32_t *)(arg1 + 0x7c) != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (iVar32 < 1) {
code_r0x00018014939d:
            *(undefined4 *)(arg1 + 0x7c) = 0;
        } else {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar21 * 0x38;
                puVar37 = (undefined4 *)(uVar26 + iVar25);
                if (*(int32_t *)(uVar26 + iVar25) == *(int32_t *)(arg1 + 0x7c)) {
                    if ((puVar37[1] & 0x20) == 0) {
                        iVar41 = (int32_t)(uVar26 / 0x38) + (int32_t)*(int16_t *)(arg1 + 0x80);
                        if ((-1 < iVar41) && (iVar41 < iVar32)) {
                            puVar29 = (undefined4 *)((int64_t)iVar41 * 0x38 + iVar25);
                            if (((puVar29[1] & 0x20) == 0) && (((puVar29[1] ^ puVar37[1]) & 0xc0) == 0)) {
                                uVar18 = *(undefined8 *)(puVar37 + 0xc);
                                uVar57 = *puVar37;
                                uVar1 = puVar37[1];
                                uVar2 = puVar37[2];
                                uVar4 = puVar37[3];
                                uVar5 = puVar37[4];
                                uVar6 = puVar37[5];
                                uVar7 = puVar37[6];
                                uVar8 = puVar37[7];
                                uVar9 = puVar37[8];
                                uVar10 = puVar37[9];
                                uVar11 = puVar37[10];
                                uVar12 = puVar37[0xb];
                                if (*(int16_t *)(arg1 + 0x80) < 1) {
                                    puVar37 = puVar29 + 0xe;
                                    puVar27 = puVar29;
                                } else {
                                    puVar27 = puVar37 + 0xe;
                                }
                                fcn.180498030(puVar37, puVar27);
                                *puVar29 = uVar57;
                                puVar29[1] = uVar1;
                                puVar29[2] = uVar2;
                                puVar29[3] = uVar4;
                                puVar29[4] = uVar5;
                                puVar29[5] = uVar6;
                                puVar29[6] = uVar7;
                                puVar29[7] = uVar8;
                                puVar29[8] = uVar9;
                                puVar29[9] = uVar10;
                                puVar29[10] = uVar11;
                                puVar29[0xb] = uVar12;
                                *(undefined8 *)(puVar29 + 0xc) = uVar18;
                                if (((*(uint32_t *)(arg1 + 0x18) & 0x400000) != 0) &&
                                   (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)) {
                                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) =
                                         *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
                                }
                                if (*(uint32_t *)(arg1 + 0x7c) == *(uint32_t *)(arg1 + 0x20)) {
                                    uVar28 = *(uint32_t *)(arg1 + 0x7c);
                                }
                            }
                        }
                    }
                    goto code_r0x00018014939d;
                }
                uVar21 = uVar21 + 1;
            } while ((int32_t)uVar21 < iVar32);
            *(undefined4 *)(arg1 + 0x7c) = 0;
        }
    }
    iVar25 = *(int64_t *)0x180781f28;
    puVar33 = (uint32_t *)0x0;
    if ((*(uint8_t *)(arg1 + 0x18) & 4) != 0) {
        uVar57 = *(undefined4 *)(arg1 + 0x3c);
        var_148h = 0;
        fVar49 = *(float *)(*(int64_t *)0x180781f28 + 0xde0);
        iVar23 = *(int64_t *)0x180781f28 + 0x20c0;
        iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
        uVar1 = *(undefined4 *)(iVar24 + 0x158);
        uVar2 = *(undefined4 *)(iVar24 + 0x15c);
        *(float *)(iVar24 + 0x158) = *(float *)(arg1 + 0x38) - fVar49;
        *(undefined4 *)(iVar24 + 0x15c) = uVar57;
        *(float *)(arg1 + 0x38) = fVar49 + fVar45 + *(float *)(arg1 + 0x38);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        uVar57 = *(undefined4 *)(iVar25 + 0xed8);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        fVar49 = *(float *)(iVar25 + 0xedc);
        fcn.18011f2b0(iVar23, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar57;
            *(float *)(iVar25 + 0xedc) = fVar49 * 0.5;
        }
        iVar25 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        uVar57 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x102c);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar25 + 0x1020) = 0;
            *(undefined8 *)(iVar25 + 0x1028) = 0;
        }
        cVar15 = func_0x00018013d0a0();
        fcn.1800f6770(2);
        if (cVar15 != '\0') {
            iVar32 = 0;
            if (0 < *(int32_t *)(arg1 + 8)) {
                do {
                    puVar30 = (uint32_t *)((int64_t)iVar32 * 0x38 + *piVar42);
                    if (((puVar30[1] & 0x200000) == 0) &&
                       (cVar15 = fcn.180146c70(CONCAT44(uStack_13c, var_144h._4_4_), 
                                               CONCAT44(in_stack_fffffffffffffecc, uVar57)), cVar15 != '\0')) {
                        puVar33 = puVar30;
                    }
                    iVar32 = iVar32 + 1;
                } while (iVar32 < *(int32_t *)(arg1 + 8));
            }
            iVar25 = *(int64_t *)0x180781f28;
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) + -1;
            iVar32 = func_0x000180498f10(*(undefined8 *)(*(int64_t *)(iVar25 + 0x15e0) + 8), &var_148h);
            if (iVar32 == 0) {
                func_0x00018010d5c0();
            } else if (*(code **)(iVar25 + 0x2a40) != (code *)0x0) {
                (**(code **)(iVar25 + 0x2a40))(iVar25, *(undefined8 *)(iVar25 + 0x2a48));
            }
        }
        *(undefined4 *)(iVar24 + 0x158) = uVar1;
        *(undefined4 *)(iVar24 + 0x15c) = uVar2;
        if (puVar33 != (uint32_t *)0x0) {
            uVar28 = *puVar33;
            *(uint32_t *)(arg1 + 0x20) = uVar28;
        }
    }
    iVar41 = 1;
    uVar22 = *(uint32_t *)(arg1 + 8);
    var_144h._0_4_ = (int32_t)var_e8h + (int32_t)var_108h;
    var_148h = 0;
    iVar32 = *(int32_t *)(iVar38 + 0x257c);
    var_144h._4_4_ = (int32_t)var_108h;
    if (iVar32 < (int32_t)uVar22) {
        if (iVar32 != 0) {
            uVar35 = iVar32 / 2 + iVar32;
        }
        uVar21 = uVar22;
        if ((int32_t)uVar22 < (int32_t)uVar35) {
            uVar21 = uVar35;
        }
        if (iVar32 < (int32_t)uVar21) {
            uVar18 = fcn.18046d050((int64_t)(int32_t)uVar21 * 0xc);
            if (*(int64_t *)(iVar38 + 0x2580) != 0) {
                fcn.180498030(uVar18);
                fcn.180460d90(*(undefined8 *)(iVar38 + 0x2580));
            }
            *(undefined8 *)(iVar38 + 0x2580) = uVar18;
            *(uint32_t *)(iVar38 + 0x257c) = uVar21;
        }
    }
    *(uint32_t *)(iVar38 + 0x2578) = uVar22;
    if ((*(uint8_t *)(arg1 + 0x18) & 0x80) == 0) {
        fVar49 = 1.0;
    } else {
        fVar49 = *(float *)(iVar38 + 0xe40);
    }
    iVar32 = *(int32_t *)(arg1 + 8);
    iVar39 = 0;
    var_130h = 0;
    bVar44 = false;
    uVar22 = 0xffffffff;
    bVar13 = false;
    if (0 < iVar32) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)0x180781f28;
            puVar33 = (uint32_t *)((int64_t)iVar39 * 0x38 + *piVar42);
            if (((var_130h == 0) || (*(int32_t *)(var_130h + 0x14) < (int32_t)puVar33[5])) &&
               ((puVar33[1] & 0x200000) == 0)) {
                var_130h = (int64_t)puVar33;
            }
            uVar35 = *puVar33;
            if (uVar35 == *(uint32_t *)(arg1 + 0x20)) {
                bVar44 = true;
            }
            if ((uVar28 == 0) && (*(uint32_t *)(iVar38 + 0x23a4) == uVar35)) {
                uVar28 = uVar35;
            }
            auVar52 = ZEXT416(puVar33[9]);
            if ((float)puVar33[9] < 0.0) {
                uVar35 = puVar33[1];
                var_178h._0_4_ = 0xbf800000;
                fcn.1800fe0a0(CONCAT44(var_178h._4_4_, 0xbf800000), SUB168(_var_98h, 8));
                fVar45 = *(float *)(iVar25 + 0xddc);
                if ((uVar35 & 0x100001) == 0x100000) {
                    fVar50 = fVar45 + 1.0;
                } else {
                    fVar50 = *(float *)(iVar25 + 0x12f8) + *(float *)(iVar25 + 0xdf4) + fVar45;
                }
                fVar50 = fVar50 + var_120h + fVar45;
                auVar52 = ZEXT416((uint32_t)fVar50);
                fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 20.0;
                if (fVar45 <= fVar50) {
                    auVar52 = ZEXT416((uint32_t)fVar45);
                }
            }
            uVar35 = puVar33[1];
            puVar33[8] = (uint32_t)auVar52._0_4_;
            if ((uVar35 >> 0x15 & 1) == 0) {
                if (auVar52._0_4_ <= *(float *)(iVar38 + 0xe3c)) {
                    auVar52._0_4_ = *(float *)(iVar38 + 0xe3c);
                }
                puVar33[8] = auVar52._0_4_;
            }
            if ((uVar35 & 0x40) == 0) {
                uVar35 = ((uVar35 & 0x80) != 0) + 1;
            } else {
                uVar35 = 0;
            }
            uVar26 = (uint64_t)uVar35;
            if (uVar35 == uVar22) {
                fVar50 = auVar52._0_4_ + fVar51;
                fVar45 = fVar51;
            } else {
                fVar50 = auVar52._0_4_ + 0.0;
                fVar45 = 0.0;
            }
            var_100h[uVar26 * 4 + -1] = fVar50 + var_100h[uVar26 * 4 + -1];
            fVar50 = (float)puVar33[8];
            if (fVar49 <= (float)puVar33[8]) {
                fVar50 = fVar49;
            }
            var_100h[uVar26 * 4] = fVar50 + fVar45 + var_100h[uVar26 * 4];
            iVar23 = (int64_t)(&var_148h)[uVar26];
            (&var_148h)[uVar26] = (&var_148h)[uVar26] + 1;
            iVar25 = *(int64_t *)(iVar38 + 0x2580);
            *(int32_t *)(iVar25 + iVar23 * 0xc) = iVar39;
            iVar39 = iVar39 + 1;
            uVar22 = puVar33[8];
            *(uint32_t *)(iVar25 + 8 + iVar23 * 0xc) = uVar22;
            *(uint32_t *)(iVar25 + 4 + iVar23 * 0xc) = uVar22;
            fVar45 = (float)puVar33[8];
            if (fVar45 <= 1.0) {
                fVar45 = 1.0;
            }
            puVar33[7] = (uint32_t)fVar45;
            iVar32 = *(int32_t *)(arg1 + 8);
            uVar22 = uVar35;
            bVar13 = bVar44;
        } while (iVar39 < iVar32);
    }
    uVar22 = *(uint32_t *)(arg1 + 0x18);
    *(float *)(arg1 + 0x58) = var_100h[1] + var_108h._4_4_ + 0.0 + var_f8h._4_4_ + var_ech + var_e8h._4_4_ + var_dch;
    iVar25 = *(int64_t *)0x180781f28;
    if (((uVar22 & 0x200) == 0) && (-1 < (char)uVar22)) {
        bVar14 = false;
code_r0x00018014992e:
        bVar13 = bVar14;
        fVar51 = var_e0h + var_dch + var_100h[0] + var_100h[1] + 0.0 + var_f0h + var_ech;
    } else {
        bVar13 = true;
        bVar14 = true;
        if ((uVar22 & 0x200) == 0) goto code_r0x00018014992e;
        fVar51 = *(float *)(arg1 + 0x54);
    }
    if ((((fVar51 <= *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38)) || (iVar32 < 2)) || ((uVar22 & 0x10) != 0)) ||
       (!bVar13)) {
        *(undefined *)(arg1 + 0x86) = 0;
    } else {
        *(undefined *)(arg1 + 0x86) = 1;
        var_148h = 0;
        fVar51 = *(float *)(iVar25 + 0x12f8);
        iVar23 = *(int64_t *)(iVar25 + 0x15e0);
        fVar54 = fVar51 - 2.0;
        fVar45 = *(float *)(iVar25 + 0xde0);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        uVar57 = *(undefined4 *)(iVar23 + 0x158);
        uVar1 = *(undefined4 *)(iVar25 + 0xed8);
        fVar50 = *(float *)(iVar25 + 0xedc);
        fVar55 = fVar54 + fVar54;
        var_120h = *(float *)(iVar23 + 0x15c);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        fcn.18011f2b0(iVar25 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar1;
            *(float *)(iVar25 + 0xedc) = fVar50 * 0.5;
        }
        iVar24 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar24 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar24 + 0x1020) = 0;
            *(undefined8 *)(iVar24 + 0x1028) = 0;
        }
        iVar24 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 10;
        piVar20 = (int32_t *)(iVar24 + 0x2100);
        iVar32 = *(int32_t *)(iVar24 + 0x2104);
        uVar1 = *(undefined4 *)(iVar24 + 0x1f78);
        if (*piVar20 == iVar32) {
            iVar39 = *piVar20 + 1;
            if (iVar32 == 0) {
                iVar32 = 8;
            } else {
                iVar32 = iVar32 / 2 + iVar32;
            }
            if (iVar39 < iVar32) {
                iVar39 = iVar32;
            }
            fcn.18011fb10(piVar20, iVar39);
        }
        *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + (int64_t)*piVar20 * 4) = uVar1;
        *piVar20 = *piVar20 + 1;
        uVar1 = *(undefined4 *)(iVar25 + 0xa8);
        uVar2 = *(undefined4 *)(iVar25 + 0xac);
        *(undefined4 *)(iVar25 + 0xa8) = 0x3e800000;
        *(undefined4 *)(iVar25 + 0xac) = 0x3e4ccccd;
        fVar46 = *(float *)(arg1 + 0x40) - fVar55;
        fVar50 = *(float *)(arg1 + 0x38);
        if (*(float *)(arg1 + 0x38) <= fVar46) {
            fVar50 = fVar46;
        }
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50;
        uVar16 = func_0x00018013a9f0(0x180645ba0, 0, CONCAT44(fVar45 + fVar45 + fVar51, fVar54));
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50 + fVar54;
        cVar15 = func_0x00018013a9f0(0x180645ba4, 1);
        iVar24 = *(int64_t *)0x180781f28;
        if (cVar15 == '\0') {
            iVar32 = (uVar16 ^ 1) - 1;
        } else {
            iVar32 = 1;
        }
        iVar39 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
        if (iVar39 < 2) {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48));
            }
        } else {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar39 + -1;
            *(undefined4 *)(iVar24 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + -8 + (int64_t)iVar39 * 4)
            ;
        }
        fcn.1800f6770();
        *(undefined4 *)(iVar25 + 0xac) = uVar2;
        *(undefined4 *)(iVar25 + 0xa8) = uVar1;
        if (iVar32 == 0) {
            puVar33 = (uint32_t *)0x0;
code_r0x000180149cf6:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
            if ((puVar33 != (uint32_t *)0x0) && (uVar28 = *puVar33, (puVar33[1] & 0x200000) == 0)) {
                *(uint32_t *)(arg1 + 0x20) = uVar28;
            }
        } else {
            if ((*(int32_t *)(arg1 + 0x20) != 0) && (iVar39 = *(int32_t *)(arg1 + 8), 0 < iVar39)) {
                uVar26 = 0;
                iVar25 = *piVar42;
code_r0x000180149c50:
                if (*(int32_t *)(uVar26 * 0x38 + iVar25) != *(int32_t *)(arg1 + 0x20)) goto code_r0x000180149c5c;
                uVar26 = (uVar26 * 0x38) / 0x38;
                iVar36 = (int32_t)uVar26 + iVar32;
                do {
                    if ((iVar36 < 0) || (iVar17 = iVar36, iVar39 <= iVar36)) {
                        iVar17 = (int32_t)uVar26;
                    }
                    puVar33 = (uint32_t *)((int64_t)iVar17 * 0x38 + iVar25);
                } while ((((*(uint32_t *)(iVar25 + 4 + (int64_t)iVar17 * 0x38) & 0x200000) != 0) &&
                         (iVar36 = iVar36 + iVar32, -1 < iVar36)) &&
                        (uVar26 = (uint64_t)(uint32_t)((int32_t)uVar26 + iVar32), iVar36 < iVar39));
                goto code_r0x000180149cf6;
            }
code_r0x000180149c63:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
        }
    }
    pfVar43 = (float *)(arg1 + 0x40);
    pcVar40 = (char *)(arg1 + 0x86);
    puVar34 = (undefined8 *)(arg1 + 0x38);
    if ((uVar28 == 0) && ((char)uVar56 != '\0')) {
        uVar28 = *(uint32_t *)(arg1 + 0x20);
    }
    fVar51 = *pfVar43 - *(float *)puVar34;
    fVar45 = var_e8h._4_4_ + var_dch + var_108h._4_4_ + var_100h[1];
    if (fVar51 <= fVar45) {
        fVar50 = fVar45 - fVar51;
    } else {
        fVar50 = (var_f8h._4_4_ + var_ech) - ((fVar51 - (var_108h._4_4_ + var_100h[1])) - (var_e8h._4_4_ + var_dch));
        if (fVar50 <= 0.0) {
            fVar50 = 0.0;
        }
    }
    if (1.0 <= fVar50) {
        if ((*(uint32_t *)(arg1 + 0x18) & 0x180) == 0) {
            if (fVar45 < fVar51) goto code_r0x00018014a4db;
code_r0x000180149e0c:
            uVar22 = (int32_t)var_e8h + (int32_t)var_108h;
            if (fVar51 <= fVar45) {
                iVar32 = 0;
            } else {
                iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            }
        } else {
            if (fVar51 <= fVar45) goto code_r0x000180149e0c;
            iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            uVar22 = (uint32_t)var_f8h;
        }
        iVar25 = *(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc;
        if (uVar22 == 1) {
            if (0.0 <= *(float *)(iVar25 + 4)) {
                fVar50 = *(float *)(iVar25 + 4) - fVar50;
                if (fVar50 <= fVar49) {
                    fVar50 = fVar49;
                }
                *(float *)(iVar25 + 4) = fVar50;
            }
        } else {
            if (1 < uVar22) {
                fcn.18046f0d0(CONCAT44(uVar56, uVar28));
            }
            while ((0.001 < fVar50 && (iVar41 < (int32_t)uVar22))) {
                fVar51 = *(float *)(iVar25 + 4);
                do {
                    fVar45 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                    if (fVar45 < fVar51) {
                        if (0.0 <= fVar45) {
                            fVar45 = fVar51 - fVar45;
                            goto code_r0x000180149ee6;
                        }
                        break;
                    }
                    iVar41 = iVar41 + 1;
                } while (iVar41 < (int32_t)uVar22);
                fVar45 = fVar51 - 1.0;
code_r0x000180149ee6:
                fVar54 = fVar51 - fVar49;
                if (fVar45 <= fVar51 - fVar49) {
                    fVar54 = fVar45;
                }
                if (fVar54 <= 0.0) break;
                iVar39 = 0;
                fVar51 = fVar50 / (float)iVar41;
                if (fVar54 <= fVar50 / (float)iVar41) {
                    fVar51 = fVar54;
                }
                if (3 < iVar41) {
                    do {
                        iVar23 = (int64_t)iVar39;
                        iVar39 = iVar39 + 4;
                        fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar55 = fVar45 - fVar49;
                        fVar54 = fVar51;
                        if (fVar55 <= fVar51) {
                            fVar54 = fVar55;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                        fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar46 = fVar45 - fVar49;
                        fVar55 = fVar51;
                        if (fVar46 <= fVar51) {
                            fVar55 = fVar46;
                        }
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar45 - fVar55;
                        fVar45 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar47 = fVar45 - fVar49;
                        fVar46 = fVar51;
                        if (fVar47 <= fVar51) {
                            fVar46 = fVar47;
                        }
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar45 - fVar46;
                        fVar45 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar48 = fVar45 - fVar49;
                        fVar47 = fVar51;
                        if (fVar48 <= fVar51) {
                            fVar47 = fVar48;
                        }
                        fVar50 = (((fVar50 - fVar54) - fVar55) - fVar46) - fVar47;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar45 - fVar47;
                    } while (iVar39 < iVar41 + -3);
                }
                while (iVar39 < iVar41) {
                    iVar23 = (int64_t)iVar39;
                    iVar39 = iVar39 + 1;
                    fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar55 = fVar45 - fVar49;
                    fVar54 = fVar51;
                    if (fVar55 <= fVar51) {
                        fVar54 = fVar55;
                    }
                    fVar50 = fVar50 - fVar54;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                }
            }
            iVar41 = 0;
            fVar51 = 0.0;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 4;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar48 = (float)(int32_t)fVar49;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar48;
                    fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                    fVar46 = (float)(int32_t)fVar45;
                    *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar46;
                    fVar50 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                    fVar55 = (float)(int32_t)fVar50;
                    *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar55;
                    fVar54 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                    fVar47 = (float)(int32_t)fVar54;
                    *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar47;
                    fVar51 = (fVar49 - fVar48) + fVar51 + (fVar45 - fVar46) + (fVar50 - fVar55) + (fVar54 - fVar47);
                } while (iVar41 < (int32_t)(uVar22 - 3));
            }
            for (; iVar41 < (int32_t)uVar22; iVar41 = iVar41 + 1) {
                fVar49 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                fVar45 = (float)(int32_t)fVar49;
                *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc) = fVar45;
                fVar51 = fVar51 + (fVar49 - fVar45);
            }
            while (0.0 < fVar51) {
                iVar41 = 0;
                if (3 < (int32_t)uVar22) {
                    do {
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar23 = (int64_t)iVar41;
                        fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 - fVar45 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar50 = *(float *)(iVar25 + 0x14 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar50) {
                            fVar50 = 1.0;
                        }
                        fVar51 = (fVar51 - fVar45) - fVar50;
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar49 + fVar50;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x20 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar41 = iVar41 + 4;
                        fVar49 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x2c + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar49 + fVar45;
                    } while (iVar41 < (int32_t)(uVar22 - 3));
                }
                while (iVar41 < (int32_t)uVar22) {
                    if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 1;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                    if (1.0 <= fVar45) {
                        fVar45 = 1.0;
                    }
                    fVar51 = fVar51 - fVar45;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                }
            }
        }
code_r0x00018014a22a:
        iVar41 = iVar32 + uVar22;
        if (iVar32 < iVar41) {
            arg1 = var_128h;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar25 = (int64_t)iVar32;
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x10 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0xc + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x1c + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x18 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x28 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar25 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x24 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar25 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar24 = 0;
                        }
                        var_100h[iVar24 * 4 + -1] =
                             var_100h[iVar24 * 4 + -1] - (*(float *)(iVar25 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar25 + 0x1c + iVar23) = fVar49;
                    }
                    iVar32 = iVar32 + 4;
                } while (iVar32 < iVar41 + -3);
                if (iVar41 <= iVar32) goto code_r0x00018014a4d3;
            }
            do {
                fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + (int64_t)iVar32 * 0xc);
                if (0.0 <= fVar51) {
                    iVar25 = *piVar42;
                    fVar49 = 1.0;
                    if (1.0 <= fVar51) {
                        fVar49 = fVar51;
                    }
                    iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc) * 0x38;
                    uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                    if ((uVar22 & 0x40) == 0) {
                        iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                    } else {
                        iVar24 = 0;
                    }
                    var_100h[iVar24 * 4 + -1] =
                         var_100h[iVar24 * 4 + -1] - (*(float *)(iVar23 + 0x1c + iVar25) - fVar49);
                    *(float *)(iVar23 + 0x1c + iVar25) = fVar49;
                }
                iVar32 = iVar32 + 1;
                puVar34 = (undefined8 *)var_118h;
                pfVar43 = (float *)var_110h;
            } while (iVar32 < iVar41);
        } else {
code_r0x00018014a4d3:
            puVar34 = (undefined8 *)(arg1 + 0x38);
            pfVar43 = (float *)(arg1 + 0x40);
        }
    }
code_r0x00018014a4db:
    uVar35 = 0;
    auVar53 = ZEXT816(0);
    *(undefined4 *)(arg1 + 0x54) = 0;
    uVar22 = uVar35;
    if (0 < (int32_t)var_108h) {
        do {
            iVar25 = *piVar42;
            iVar23 = (int64_t)(int32_t)uVar22 * 0x38;
            *(float *)(iVar23 + 0x18 + iVar25) = auVar53._0_4_;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_108h + -1) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            auVar53._0_4_ = auVar53._0_4_ + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_108h);
    }
    fVar49 = auVar53._0_4_ + var_100h[1];
    fVar51 = var_100h[1] + var_108h._4_4_;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    uVar22 = uVar35;
    if (0 < (int32_t)(uint32_t)var_f8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar49;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)((uint32_t)var_f8h + -1)) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar49 = fVar49 + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)(uint32_t)var_f8h);
    }
    fVar51 = var_f8h._4_4_ + var_ech;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    fVar45 = (*(float *)(arg1 + 0x40) - *(float *)puVar34) - var_e8h._4_4_;
    fVar51 = 0.0;
    if (0.0 <= fVar45) {
        fVar51 = fVar45;
    }
    if (var_ech + fVar49 <= fVar51) {
        fVar51 = var_ech + fVar49;
    }
    uVar22 = uVar35;
    if (0 < (int32_t)var_e8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h + (uint32_t)var_f8h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar51;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_e8h + -1) {
                fVar49 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar49 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar51 = fVar51 + fVar49 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_e8h);
    }
    fVar51 = var_e8h._4_4_ + var_dch;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    func_0x00018011f640(arg1 + 0xa0, 0);
    if ((!bVar44) && (*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1)) {
        *(undefined4 *)(arg1 + 0x20) = 0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x20);
    if (((*(uint32_t *)(arg1 + 0x20) == 0) && (uVar22 = uVar35, *(int32_t *)(arg1 + 0x24) == 0)) && (var_130h != 0)) {
        uVar28 = *(uint32_t *)var_130h;
        *(uint32_t *)(arg1 + 0x20) = uVar28;
        uVar22 = uVar28;
    }
    *(uint32_t *)(arg1 + 0x2c) = uVar22;
    *(undefined *)(arg1 + 0x84) = 0;
    iVar25 = *(int64_t *)(iVar38 + 0x23c0);
    if (((iVar25 != 0) && (*(int64_t *)(iVar25 + 0x4c0) != 0)) &&
       (*(int64_t *)(*(int64_t *)(iVar25 + 0x4c0) + 0x40) == arg1)) {
        uVar28 = *(uint32_t *)(iVar25 + 200);
        *(uint32_t *)(arg1 + 0x2c) = uVar28;
    }
    if (uVar28 != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (0 < iVar32) {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar35 * 0x38;
                if (*(uint32_t *)(uVar26 + iVar25) == uVar28) {
                    if ((*(uint8_t *)(uVar26 + 4 + iVar25) & 0xc0) != 0) break;
                    fVar51 = *pfVar43;
                    fVar49 = *(float *)puVar34;
                    fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
                    iVar41 = (int32_t)(uVar26 / 0x38);
                    if ((int32_t)var_108h + -1 < iVar41) {
                        fVar50 = (float)((uint32_t)fVar45 ^ 0x80000000);
                    } else {
                        fVar50 = 0.0;
                    }
                    fVar54 = *(float *)(uVar26 + 0x18 + iVar25) - var_108h._4_4_;
                    fVar50 = fVar54 + fVar50;
                    if (iVar32 - (int32_t)var_e8h <= iVar41 + 1) {
                        fVar45 = 1.0;
                    }
                    fVar55 = *(float *)(uVar26 + 0x1c + iVar25);
                    *(undefined4 *)(arg1 + 100) = 0;
                    fVar45 = fVar54 + fVar55 + fVar45;
                    if (*(float *)(arg1 + 0x60) <= fVar50) {
                        fVar51 = (((fVar51 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech;
                        if (fVar45 - fVar50 < fVar51) {
                            if (*(float *)(arg1 + 0x60) < fVar45 - fVar51) {
                                *(float *)(arg1 + 0x60) = fVar45 - fVar51;
                                fVar51 = (fVar50 - fVar51) - *(float *)(arg1 + 0x5c);
                                if (fVar51 <= 0.0) {
                                    fVar51 = 0.0;
                                }
                                *(float *)(arg1 + 100) = fVar51;
                            }
                            break;
                        }
                    }
                    fVar45 = *(float *)(arg1 + 0x5c) - fVar45;
                    *(float *)(arg1 + 0x60) = fVar50;
                    if (fVar45 <= 0.0) {
                        fVar45 = 0.0;
                    }
                    *(float *)(arg1 + 100) = fVar45;
                    break;
                }
                uVar35 = uVar35 + 1;
            } while ((int32_t)uVar35 < iVar32);
        }
        goto code_r0x00018014a9b6;
    }
    if ((*pcVar40 == '\0') || (cVar15 = func_0x000180108120(puVar34, pfVar43, 1), cVar15 == '\0'))
    goto code_r0x00018014a9b6;
    iVar25 = *(int64_t *)(iVar38 + 0x15e0);
    if (((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) != 0) &&
        ((((iVar23 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) + 0x428), iVar23 != 0 &&
           (*(char *)(iVar23 + 0x10a) != '\0')) && (iVar23 != *(int64_t *)(iVar25 + 0x428))) &&
         (((*(uint32_t *)(iVar23 + 0x14) >> 0x1b & 1) != 0 || ((*(uint32_t *)(iVar23 + 0x14) >> 0x1a & 1) != 0)))))) &&
       (iVar24 = *(int64_t *)(iVar25 + 0x418), *(int64_t *)(iVar24 + 0x418) != iVar23)) {
        do {
            if (iVar24 == iVar23) goto code_r0x00018014a8ae;
            iVar24 = *(int64_t *)(iVar24 + 0x410);
        } while (iVar24 != 0);
        goto code_r0x00018014a9b6;
    }
code_r0x00018014a8ae:
    if ((*(int64_t *)(iVar25 + 0x48) != *(int64_t *)(*(int64_t *)0x180781f28 + 0x2168)) &&
       ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) == 0 ||
        (*(int64_t *)(iVar25 + 0x428) != *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) + 0x428)))))
    goto code_r0x00018014a9b6;
    pfVar31 = (float *)(iVar38 + 0x128);
    if (*(char *)(iVar38 + 0xbaa) == '\0') {
        pfVar31 = (float *)(iVar38 + 300);
    }
    iVar32 = *(int32_t *)(arg1 + 0x1c);
    uVar26 = (uint64_t)((*(char *)(iVar38 + 0xbaa) != '\0') + 0x295);
    iVar25 = *(int64_t *)0x180781f28;
    piVar20 = (int32_t *)func_0x0001800f45c0(*(int64_t *)0x180781f28, uVar26);
    if (iVar32 == 0) {
        bVar44 = *(char *)(piVar20 + 2) == '\0';
code_r0x00018014a936:
        if (bVar44) {
code_r0x00018014a938:
            fVar51 = *pfVar31;
            if (fVar51 != 0.0) {
                fVar49 = *(float *)puVar34;
                fVar45 = *pfVar43;
                *(undefined4 *)(arg1 + 100) = 0;
                fVar51 = *(float *)(arg1 + 0x60) -
                         (((((fVar45 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech) * fVar51) / 3.0;
                fVar49 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar49);
                if (fVar49 <= fVar51) {
                    fVar51 = fVar49;
                }
                if (fVar51 <= 0.0) {
                    fVar51 = 0.0;
                }
                *(float *)(arg1 + 0x60) = fVar51;
            }
        }
    } else {
        if (*piVar20 == iVar32) goto code_r0x00018014a938;
        if (*(char *)(piVar20 + 2) == '\0') {
            bVar44 = *piVar20 == -1;
            goto code_r0x00018014a936;
        }
    }
    *(int32_t *)(iVar25 + -0x130 + uVar26 * 0xc) = iVar32;
    *(int32_t *)(iVar25 + -0x134 + uVar26 * 0xc) = iVar32;
    *(undefined2 *)(iVar25 + -300 + uVar26 * 0xc) = 0;
code_r0x00018014a9b6:
    fVar51 = *(float *)puVar34;
    fVar45 = *(float *)(arg1 + 0x54) - (*pfVar43 - fVar51);
    fVar49 = *(float *)(arg1 + 0x5c);
    if (fVar45 <= *(float *)(arg1 + 0x5c)) {
        fVar49 = fVar45;
    }
    if (fVar49 <= 0.0) {
        fVar49 = 0.0;
    }
    *(float *)(arg1 + 0x5c) = fVar49;
    fVar50 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar51);
    fVar45 = *(float *)(arg1 + 0x60);
    if (fVar50 <= *(float *)(arg1 + 0x60)) {
        fVar45 = fVar50;
    }
    if (fVar45 <= 0.0) {
        fVar45 = 0.0;
    }
    *(float *)(arg1 + 0x60) = fVar45;
    if (fVar49 == fVar45) {
        *(undefined4 *)(arg1 + 0x68) = 0;
    } else {
        fVar54 = *(float *)(iVar38 + 0x12f8) * 70.0;
        fVar50 = *(float *)(arg1 + 0x68);
        if (*(float *)(arg1 + 0x68) <= fVar54) {
            fVar50 = fVar54;
        }
        fVar54 = (float)((uint32_t)(fVar45 - fVar49) & 0x7fffffff) / 0.3;
        if (fVar50 <= fVar54) {
            fVar50 = fVar54;
        }
        *(float *)(arg1 + 0x68) = fVar50;
        fVar54 = fVar45;
        if ((*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1) &&
           (*(float *)(arg1 + 100) <= *(float *)(iVar38 + 0x12f8) * 10.0)) {
            fVar50 = fVar50 * *(float *)(iVar38 + 0x48);
            if (fVar45 <= fVar49) {
                fVar54 = fVar49;
                if ((fVar45 < fVar49) && (fVar54 = fVar49 - fVar50, fVar54 <= fVar45)) {
                    fVar54 = fVar45;
                }
            } else {
                fVar54 = fVar50 + fVar49;
                if (fVar45 <= fVar54) {
                    fVar54 = fVar45;
                }
            }
        }
        *(float *)(arg1 + 0x5c) = fVar54;
    }
    uVar18 = *puVar34;
    *(float *)(arg1 + 0x6c) = fVar51 + var_108h._4_4_ + var_100h[1];
    *(float *)(arg1 + 0x70) = (*(float *)(arg1 + 0x40) - var_e8h._4_4_) - var_ech;
    iVar38 = *(int64_t *)(iVar38 + 0x15e0);
    *(undefined8 *)(iVar38 + 0x158) = uVar18;
    var_128h = CONCAT44(*(float *)(arg1 + 0x44) - *(float *)(arg1 + 0x3c), *(undefined4 *)(arg1 + 0x54));
    func_0x00018010bbf0(&var_128h);
    fVar49 = *(float *)(arg1 + 0x58) + *(float *)puVar34;
    fVar51 = *(float *)(iVar38 + 0x178);
    if (*(float *)(iVar38 + 0x178) <= fVar49) {
        fVar51 = fVar49;
    }
    *(float *)(iVar38 + 0x178) = fVar51;
    func_0x000180459870(var_d8h ^ (uint64_t)auStackY_198);
    return;
code_r0x000180149c5c:
    uVar22 = (int32_t)uVar26 + 1;
    uVar26 = (uint64_t)uVar22;
    if (iVar39 <= (int32_t)uVar22) goto code_r0x000180149c63;
    goto code_r0x000180149c50;
}

// ============================================================
// Function: FUN_180149277
// Address: 0x180149277
// Size: 1750 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_144h
// WARNING: Variable defined which should be unmapped: var_178h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180148fa0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined auVar3 [16];
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    bool bVar13;
    bool bVar14;
    char cVar15;
    uint8_t uVar16;
    int32_t iVar17;
    undefined8 uVar18;
    int64_t iVar19;
    int32_t *piVar20;
    uint32_t uVar21;
    uint32_t uVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    uint64_t uVar26;
    undefined4 *puVar27;
    uint32_t uVar28;
    undefined4 *puVar29;
    uint32_t *puVar30;
    float *pfVar31;
    int32_t iVar32;
    uint32_t *puVar33;
    undefined8 *puVar34;
    uint32_t uVar35;
    int32_t iVar36;
    undefined4 *puVar37;
    int64_t iVar38;
    int32_t iVar39;
    char *pcVar40;
    int32_t iVar41;
    int64_t *piVar42;
    float *pfVar43;
    bool bVar44;
    float fVar45;
    float fVar46;
    float fVar47;
    float fVar48;
    float fVar49;
    float fVar50;
    float fVar51;
    undefined auVar52 [16];
    undefined auVar53 [16];
    float fVar54;
    undefined4 unaff_XMM12_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    float fVar55;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_198 [32];
    int64_t var_178h;
    undefined4 in_stack_fffffffffffffe98;
    undefined4 in_stack_fffffffffffffe9c;
    undefined4 uVar56;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int32_t var_148h;
    int64_t var_144h;
    undefined4 uStack_13c;
    undefined4 uVar57;
    undefined4 in_stack_fffffffffffffecc;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    float var_100h [2];
    int64_t var_f8h;
    float var_f0h;
    float var_ech;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar38 = *(int64_t *)0x180781f28;
    var_d8h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_198;
    fVar51 = *(float *)(arg1 + 0x48);
    var_118h = arg1 + 0x38;
    *(undefined *)(arg1 + 0x83) = 0;
    fVar49 = *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38);
    var_110h = arg1 + 0x40;
    uVar22 = *(uint32_t *)(arg1 + 8);
    *(float *)(arg1 + 0x48) = fVar49;
    uVar56 = CONCAT31((unkint3)((uint32_t)in_stack_fffffffffffffe9c >> 8), fVar49 < fVar51);
    auVar3._4_4_ = unaff_XMM12_Dc;
    auVar3._0_4_ = unaff_XMM12_Db;
    auVar3._8_4_ = unaff_XMM12_Dd;
    auVar3._12_4_ = 0;
    _var_98h = auVar3 << 0x20;
    bVar44 = false;
    uVar28 = 0;
    uVar35 = 0;
    _var_108h = ZEXT816(0);
    _var_f8h = ZEXT816(0);
    _var_e8h = ZEXT816(0);
    bVar13 = false;
    if (0 < (int32_t)uVar22) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)(arg1 + 0x10);
            iVar23 = (int64_t)(int32_t)uVar35 * 0x38;
            if ((*(int32_t *)(iVar23 + 0x10 + iVar25) < *(int32_t *)(arg1 + 0x34)) ||
               (*(char *)(iVar23 + 0x30 + iVar25) != '\0')) {
                if (*(int32_t *)(arg1 + 0x2c) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x2c) = 0;
                }
                if (*(int32_t *)(arg1 + 0x20) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x20) = 0;
                }
                if (*(int32_t *)(arg1 + 0x24) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x24) = 0;
                }
            } else {
                if (uVar28 != uVar35) {
                    auVar3 = *(undefined (*) [16])(iVar23 + 0x10 + iVar25);
                    puVar37 = (undefined4 *)(iVar23 + 0x20 + iVar25);
                    uVar57 = *puVar37;
                    uVar1 = puVar37[1];
                    uVar2 = puVar37[2];
                    uVar4 = puVar37[3];
                    uVar18 = *(undefined8 *)(iVar23 + 0x30 + iVar25);
                    iVar24 = (int64_t)(int32_t)uVar28 * 0x38;
                    *(undefined (*) [16])(iVar24 + iVar25) = *(undefined (*) [16])(iVar23 + iVar25);
                    *(undefined (*) [16])(iVar24 + 0x10 + iVar25) = auVar3;
                    puVar37 = (undefined4 *)(iVar24 + 0x20 + iVar25);
                    *puVar37 = uVar57;
                    puVar37[1] = uVar1;
                    puVar37[2] = uVar2;
                    puVar37[3] = uVar4;
                    *(undefined8 *)(iVar24 + 0x30 + iVar25) = uVar18;
                }
                iVar23 = (int64_t)(int32_t)uVar28 * 0x38;
                iVar25 = *(int64_t *)(arg1 + 0x10);
                uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                *(int16_t *)(iVar23 + 0x2e + iVar25) = (int16_t)uVar28;
                if ((uVar22 & 0x40) == 0) {
                    uVar26 = (uint64_t)(((uVar22 & 0x80) != 0) + 1);
                } else {
                    uVar26 = 0;
                }
                if (0 < (int32_t)uVar28) {
                    uVar22 = *(uint32_t *)(*(int64_t *)(arg1 + 0x10) + -0x34 + iVar23);
                    cVar15 = '\0';
                    if ((uVar22 & 0x40) == 0) {
                        cVar15 = ((uVar22 & 0x80) != 0) + '\x01';
                    }
                    if ((int32_t)uVar26 == 0) {
                        if (cVar15 == '\0') goto code_r0x000180149140;
                        bVar44 = true;
                    }
                    if (cVar15 == '\x02') {
                        if ((int32_t)uVar26 != 2) {
                            bVar44 = true;
                        }
                        var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                        uVar28 = uVar28 + 1;
                        goto code_r0x000180149172;
                    }
                }
code_r0x000180149140:
                var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                uVar28 = uVar28 + 1;
            }
code_r0x000180149172:
            uVar22 = *(uint32_t *)(arg1 + 8);
            uVar35 = uVar35 + 1;
            bVar13 = bVar44;
        } while ((int32_t)uVar35 < (int32_t)uVar22);
    }
    uVar35 = 8;
    var_128h = arg1;
    if (uVar22 != uVar28) {
        iVar32 = *(int32_t *)(arg1 + 0xc);
        if (iVar32 < (int32_t)uVar28) {
            uVar22 = uVar35;
            if (iVar32 != 0) {
                uVar22 = iVar32 / 2 + iVar32;
            }
            uVar21 = uVar28;
            if ((int32_t)uVar28 < (int32_t)uVar22) {
                uVar21 = uVar22;
            }
            func_0x00018011f970(arg1 + 8, uVar21);
        }
        *(uint32_t *)(arg1 + 8) = uVar28;
        uVar22 = uVar28;
    }
    piVar42 = (int64_t *)(arg1 + 0x10);
    if ((bVar44) && (1 < uVar22)) {
        fcn.18046f0d0(CONCAT44(uVar56, in_stack_fffffffffffffe98));
    }
    fVar51 = *(float *)(iVar38 + 0xdf4);
    if (((int32_t)var_108h < 1) || (var_100h[1] = fVar51, (int32_t)((int32_t)var_e8h + (uint32_t)var_f8h) < 1)) {
        var_100h[1] = 0.0;
    }
    if (((int32_t)(uint32_t)var_f8h < 1) || (var_ech = fVar51, (int32_t)var_e8h < 1)) {
        var_ech = 0.0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x28);
    uVar21 = 0;
    uVar28 = 0;
    if (uVar22 != 0) {
        *(undefined4 *)(arg1 + 0x28) = 0;
        uVar28 = uVar22;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x24);
    if (uVar22 != 0) {
        *(uint32_t *)(arg1 + 0x20) = uVar22;
        *(undefined4 *)(arg1 + 0x24) = 0;
        uVar28 = uVar22;
    }
    if (*(int32_t *)(arg1 + 0x7c) != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (iVar32 < 1) {
code_r0x00018014939d:
            *(undefined4 *)(arg1 + 0x7c) = 0;
        } else {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar21 * 0x38;
                puVar37 = (undefined4 *)(uVar26 + iVar25);
                if (*(int32_t *)(uVar26 + iVar25) == *(int32_t *)(arg1 + 0x7c)) {
                    if ((puVar37[1] & 0x20) == 0) {
                        iVar41 = (int32_t)(uVar26 / 0x38) + (int32_t)*(int16_t *)(arg1 + 0x80);
                        if ((-1 < iVar41) && (iVar41 < iVar32)) {
                            puVar29 = (undefined4 *)((int64_t)iVar41 * 0x38 + iVar25);
                            if (((puVar29[1] & 0x20) == 0) && (((puVar29[1] ^ puVar37[1]) & 0xc0) == 0)) {
                                uVar18 = *(undefined8 *)(puVar37 + 0xc);
                                uVar57 = *puVar37;
                                uVar1 = puVar37[1];
                                uVar2 = puVar37[2];
                                uVar4 = puVar37[3];
                                uVar5 = puVar37[4];
                                uVar6 = puVar37[5];
                                uVar7 = puVar37[6];
                                uVar8 = puVar37[7];
                                uVar9 = puVar37[8];
                                uVar10 = puVar37[9];
                                uVar11 = puVar37[10];
                                uVar12 = puVar37[0xb];
                                if (*(int16_t *)(arg1 + 0x80) < 1) {
                                    puVar37 = puVar29 + 0xe;
                                    puVar27 = puVar29;
                                } else {
                                    puVar27 = puVar37 + 0xe;
                                }
                                fcn.180498030(puVar37, puVar27);
                                *puVar29 = uVar57;
                                puVar29[1] = uVar1;
                                puVar29[2] = uVar2;
                                puVar29[3] = uVar4;
                                puVar29[4] = uVar5;
                                puVar29[5] = uVar6;
                                puVar29[6] = uVar7;
                                puVar29[7] = uVar8;
                                puVar29[8] = uVar9;
                                puVar29[9] = uVar10;
                                puVar29[10] = uVar11;
                                puVar29[0xb] = uVar12;
                                *(undefined8 *)(puVar29 + 0xc) = uVar18;
                                if (((*(uint32_t *)(arg1 + 0x18) & 0x400000) != 0) &&
                                   (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)) {
                                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) =
                                         *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
                                }
                                if (*(uint32_t *)(arg1 + 0x7c) == *(uint32_t *)(arg1 + 0x20)) {
                                    uVar28 = *(uint32_t *)(arg1 + 0x7c);
                                }
                            }
                        }
                    }
                    goto code_r0x00018014939d;
                }
                uVar21 = uVar21 + 1;
            } while ((int32_t)uVar21 < iVar32);
            *(undefined4 *)(arg1 + 0x7c) = 0;
        }
    }
    iVar25 = *(int64_t *)0x180781f28;
    puVar33 = (uint32_t *)0x0;
    if ((*(uint8_t *)(arg1 + 0x18) & 4) != 0) {
        uVar57 = *(undefined4 *)(arg1 + 0x3c);
        var_148h = 0;
        fVar49 = *(float *)(*(int64_t *)0x180781f28 + 0xde0);
        iVar23 = *(int64_t *)0x180781f28 + 0x20c0;
        iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
        uVar1 = *(undefined4 *)(iVar24 + 0x158);
        uVar2 = *(undefined4 *)(iVar24 + 0x15c);
        *(float *)(iVar24 + 0x158) = *(float *)(arg1 + 0x38) - fVar49;
        *(undefined4 *)(iVar24 + 0x15c) = uVar57;
        *(float *)(arg1 + 0x38) = fVar49 + fVar45 + *(float *)(arg1 + 0x38);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        uVar57 = *(undefined4 *)(iVar25 + 0xed8);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        fVar49 = *(float *)(iVar25 + 0xedc);
        fcn.18011f2b0(iVar23, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar57;
            *(float *)(iVar25 + 0xedc) = fVar49 * 0.5;
        }
        iVar25 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        uVar57 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x102c);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar25 + 0x1020) = 0;
            *(undefined8 *)(iVar25 + 0x1028) = 0;
        }
        cVar15 = func_0x00018013d0a0();
        fcn.1800f6770(2);
        if (cVar15 != '\0') {
            iVar32 = 0;
            if (0 < *(int32_t *)(arg1 + 8)) {
                do {
                    puVar30 = (uint32_t *)((int64_t)iVar32 * 0x38 + *piVar42);
                    if (((puVar30[1] & 0x200000) == 0) &&
                       (cVar15 = fcn.180146c70(CONCAT44(uStack_13c, var_144h._4_4_), 
                                               CONCAT44(in_stack_fffffffffffffecc, uVar57)), cVar15 != '\0')) {
                        puVar33 = puVar30;
                    }
                    iVar32 = iVar32 + 1;
                } while (iVar32 < *(int32_t *)(arg1 + 8));
            }
            iVar25 = *(int64_t *)0x180781f28;
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) + -1;
            iVar32 = func_0x000180498f10(*(undefined8 *)(*(int64_t *)(iVar25 + 0x15e0) + 8), &var_148h);
            if (iVar32 == 0) {
                func_0x00018010d5c0();
            } else if (*(code **)(iVar25 + 0x2a40) != (code *)0x0) {
                (**(code **)(iVar25 + 0x2a40))(iVar25, *(undefined8 *)(iVar25 + 0x2a48));
            }
        }
        *(undefined4 *)(iVar24 + 0x158) = uVar1;
        *(undefined4 *)(iVar24 + 0x15c) = uVar2;
        if (puVar33 != (uint32_t *)0x0) {
            uVar28 = *puVar33;
            *(uint32_t *)(arg1 + 0x20) = uVar28;
        }
    }
    iVar41 = 1;
    uVar22 = *(uint32_t *)(arg1 + 8);
    var_144h._0_4_ = (int32_t)var_e8h + (int32_t)var_108h;
    var_148h = 0;
    iVar32 = *(int32_t *)(iVar38 + 0x257c);
    var_144h._4_4_ = (int32_t)var_108h;
    if (iVar32 < (int32_t)uVar22) {
        if (iVar32 != 0) {
            uVar35 = iVar32 / 2 + iVar32;
        }
        uVar21 = uVar22;
        if ((int32_t)uVar22 < (int32_t)uVar35) {
            uVar21 = uVar35;
        }
        if (iVar32 < (int32_t)uVar21) {
            uVar18 = fcn.18046d050((int64_t)(int32_t)uVar21 * 0xc);
            if (*(int64_t *)(iVar38 + 0x2580) != 0) {
                fcn.180498030(uVar18);
                fcn.180460d90(*(undefined8 *)(iVar38 + 0x2580));
            }
            *(undefined8 *)(iVar38 + 0x2580) = uVar18;
            *(uint32_t *)(iVar38 + 0x257c) = uVar21;
        }
    }
    *(uint32_t *)(iVar38 + 0x2578) = uVar22;
    if ((*(uint8_t *)(arg1 + 0x18) & 0x80) == 0) {
        fVar49 = 1.0;
    } else {
        fVar49 = *(float *)(iVar38 + 0xe40);
    }
    iVar32 = *(int32_t *)(arg1 + 8);
    iVar39 = 0;
    var_130h = 0;
    bVar44 = false;
    uVar22 = 0xffffffff;
    bVar13 = false;
    if (0 < iVar32) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)0x180781f28;
            puVar33 = (uint32_t *)((int64_t)iVar39 * 0x38 + *piVar42);
            if (((var_130h == 0) || (*(int32_t *)(var_130h + 0x14) < (int32_t)puVar33[5])) &&
               ((puVar33[1] & 0x200000) == 0)) {
                var_130h = (int64_t)puVar33;
            }
            uVar35 = *puVar33;
            if (uVar35 == *(uint32_t *)(arg1 + 0x20)) {
                bVar44 = true;
            }
            if ((uVar28 == 0) && (*(uint32_t *)(iVar38 + 0x23a4) == uVar35)) {
                uVar28 = uVar35;
            }
            auVar52 = ZEXT416(puVar33[9]);
            if ((float)puVar33[9] < 0.0) {
                uVar35 = puVar33[1];
                var_178h._0_4_ = 0xbf800000;
                fcn.1800fe0a0(CONCAT44(var_178h._4_4_, 0xbf800000), SUB168(_var_98h, 8));
                fVar45 = *(float *)(iVar25 + 0xddc);
                if ((uVar35 & 0x100001) == 0x100000) {
                    fVar50 = fVar45 + 1.0;
                } else {
                    fVar50 = *(float *)(iVar25 + 0x12f8) + *(float *)(iVar25 + 0xdf4) + fVar45;
                }
                fVar50 = fVar50 + var_120h + fVar45;
                auVar52 = ZEXT416((uint32_t)fVar50);
                fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 20.0;
                if (fVar45 <= fVar50) {
                    auVar52 = ZEXT416((uint32_t)fVar45);
                }
            }
            uVar35 = puVar33[1];
            puVar33[8] = (uint32_t)auVar52._0_4_;
            if ((uVar35 >> 0x15 & 1) == 0) {
                if (auVar52._0_4_ <= *(float *)(iVar38 + 0xe3c)) {
                    auVar52._0_4_ = *(float *)(iVar38 + 0xe3c);
                }
                puVar33[8] = auVar52._0_4_;
            }
            if ((uVar35 & 0x40) == 0) {
                uVar35 = ((uVar35 & 0x80) != 0) + 1;
            } else {
                uVar35 = 0;
            }
            uVar26 = (uint64_t)uVar35;
            if (uVar35 == uVar22) {
                fVar50 = auVar52._0_4_ + fVar51;
                fVar45 = fVar51;
            } else {
                fVar50 = auVar52._0_4_ + 0.0;
                fVar45 = 0.0;
            }
            var_100h[uVar26 * 4 + -1] = fVar50 + var_100h[uVar26 * 4 + -1];
            fVar50 = (float)puVar33[8];
            if (fVar49 <= (float)puVar33[8]) {
                fVar50 = fVar49;
            }
            var_100h[uVar26 * 4] = fVar50 + fVar45 + var_100h[uVar26 * 4];
            iVar23 = (int64_t)(&var_148h)[uVar26];
            (&var_148h)[uVar26] = (&var_148h)[uVar26] + 1;
            iVar25 = *(int64_t *)(iVar38 + 0x2580);
            *(int32_t *)(iVar25 + iVar23 * 0xc) = iVar39;
            iVar39 = iVar39 + 1;
            uVar22 = puVar33[8];
            *(uint32_t *)(iVar25 + 8 + iVar23 * 0xc) = uVar22;
            *(uint32_t *)(iVar25 + 4 + iVar23 * 0xc) = uVar22;
            fVar45 = (float)puVar33[8];
            if (fVar45 <= 1.0) {
                fVar45 = 1.0;
            }
            puVar33[7] = (uint32_t)fVar45;
            iVar32 = *(int32_t *)(arg1 + 8);
            uVar22 = uVar35;
            bVar13 = bVar44;
        } while (iVar39 < iVar32);
    }
    uVar22 = *(uint32_t *)(arg1 + 0x18);
    *(float *)(arg1 + 0x58) = var_100h[1] + var_108h._4_4_ + 0.0 + var_f8h._4_4_ + var_ech + var_e8h._4_4_ + var_dch;
    iVar25 = *(int64_t *)0x180781f28;
    if (((uVar22 & 0x200) == 0) && (-1 < (char)uVar22)) {
        bVar14 = false;
code_r0x00018014992e:
        bVar13 = bVar14;
        fVar51 = var_e0h + var_dch + var_100h[0] + var_100h[1] + 0.0 + var_f0h + var_ech;
    } else {
        bVar13 = true;
        bVar14 = true;
        if ((uVar22 & 0x200) == 0) goto code_r0x00018014992e;
        fVar51 = *(float *)(arg1 + 0x54);
    }
    if ((((fVar51 <= *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38)) || (iVar32 < 2)) || ((uVar22 & 0x10) != 0)) ||
       (!bVar13)) {
        *(undefined *)(arg1 + 0x86) = 0;
    } else {
        *(undefined *)(arg1 + 0x86) = 1;
        var_148h = 0;
        fVar51 = *(float *)(iVar25 + 0x12f8);
        iVar23 = *(int64_t *)(iVar25 + 0x15e0);
        fVar54 = fVar51 - 2.0;
        fVar45 = *(float *)(iVar25 + 0xde0);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        uVar57 = *(undefined4 *)(iVar23 + 0x158);
        uVar1 = *(undefined4 *)(iVar25 + 0xed8);
        fVar50 = *(float *)(iVar25 + 0xedc);
        fVar55 = fVar54 + fVar54;
        var_120h = *(float *)(iVar23 + 0x15c);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        fcn.18011f2b0(iVar25 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar1;
            *(float *)(iVar25 + 0xedc) = fVar50 * 0.5;
        }
        iVar24 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar24 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar24 + 0x1020) = 0;
            *(undefined8 *)(iVar24 + 0x1028) = 0;
        }
        iVar24 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 10;
        piVar20 = (int32_t *)(iVar24 + 0x2100);
        iVar32 = *(int32_t *)(iVar24 + 0x2104);
        uVar1 = *(undefined4 *)(iVar24 + 0x1f78);
        if (*piVar20 == iVar32) {
            iVar39 = *piVar20 + 1;
            if (iVar32 == 0) {
                iVar32 = 8;
            } else {
                iVar32 = iVar32 / 2 + iVar32;
            }
            if (iVar39 < iVar32) {
                iVar39 = iVar32;
            }
            fcn.18011fb10(piVar20, iVar39);
        }
        *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + (int64_t)*piVar20 * 4) = uVar1;
        *piVar20 = *piVar20 + 1;
        uVar1 = *(undefined4 *)(iVar25 + 0xa8);
        uVar2 = *(undefined4 *)(iVar25 + 0xac);
        *(undefined4 *)(iVar25 + 0xa8) = 0x3e800000;
        *(undefined4 *)(iVar25 + 0xac) = 0x3e4ccccd;
        fVar46 = *(float *)(arg1 + 0x40) - fVar55;
        fVar50 = *(float *)(arg1 + 0x38);
        if (*(float *)(arg1 + 0x38) <= fVar46) {
            fVar50 = fVar46;
        }
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50;
        uVar16 = func_0x00018013a9f0(0x180645ba0, 0, CONCAT44(fVar45 + fVar45 + fVar51, fVar54));
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50 + fVar54;
        cVar15 = func_0x00018013a9f0(0x180645ba4, 1);
        iVar24 = *(int64_t *)0x180781f28;
        if (cVar15 == '\0') {
            iVar32 = (uVar16 ^ 1) - 1;
        } else {
            iVar32 = 1;
        }
        iVar39 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
        if (iVar39 < 2) {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48));
            }
        } else {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar39 + -1;
            *(undefined4 *)(iVar24 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + -8 + (int64_t)iVar39 * 4)
            ;
        }
        fcn.1800f6770();
        *(undefined4 *)(iVar25 + 0xac) = uVar2;
        *(undefined4 *)(iVar25 + 0xa8) = uVar1;
        if (iVar32 == 0) {
            puVar33 = (uint32_t *)0x0;
code_r0x000180149cf6:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
            if ((puVar33 != (uint32_t *)0x0) && (uVar28 = *puVar33, (puVar33[1] & 0x200000) == 0)) {
                *(uint32_t *)(arg1 + 0x20) = uVar28;
            }
        } else {
            if ((*(int32_t *)(arg1 + 0x20) != 0) && (iVar39 = *(int32_t *)(arg1 + 8), 0 < iVar39)) {
                uVar26 = 0;
                iVar25 = *piVar42;
code_r0x000180149c50:
                if (*(int32_t *)(uVar26 * 0x38 + iVar25) != *(int32_t *)(arg1 + 0x20)) goto code_r0x000180149c5c;
                uVar26 = (uVar26 * 0x38) / 0x38;
                iVar36 = (int32_t)uVar26 + iVar32;
                do {
                    if ((iVar36 < 0) || (iVar17 = iVar36, iVar39 <= iVar36)) {
                        iVar17 = (int32_t)uVar26;
                    }
                    puVar33 = (uint32_t *)((int64_t)iVar17 * 0x38 + iVar25);
                } while ((((*(uint32_t *)(iVar25 + 4 + (int64_t)iVar17 * 0x38) & 0x200000) != 0) &&
                         (iVar36 = iVar36 + iVar32, -1 < iVar36)) &&
                        (uVar26 = (uint64_t)(uint32_t)((int32_t)uVar26 + iVar32), iVar36 < iVar39));
                goto code_r0x000180149cf6;
            }
code_r0x000180149c63:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
        }
    }
    pfVar43 = (float *)(arg1 + 0x40);
    pcVar40 = (char *)(arg1 + 0x86);
    puVar34 = (undefined8 *)(arg1 + 0x38);
    if ((uVar28 == 0) && ((char)uVar56 != '\0')) {
        uVar28 = *(uint32_t *)(arg1 + 0x20);
    }
    fVar51 = *pfVar43 - *(float *)puVar34;
    fVar45 = var_e8h._4_4_ + var_dch + var_108h._4_4_ + var_100h[1];
    if (fVar51 <= fVar45) {
        fVar50 = fVar45 - fVar51;
    } else {
        fVar50 = (var_f8h._4_4_ + var_ech) - ((fVar51 - (var_108h._4_4_ + var_100h[1])) - (var_e8h._4_4_ + var_dch));
        if (fVar50 <= 0.0) {
            fVar50 = 0.0;
        }
    }
    if (1.0 <= fVar50) {
        if ((*(uint32_t *)(arg1 + 0x18) & 0x180) == 0) {
            if (fVar45 < fVar51) goto code_r0x00018014a4db;
code_r0x000180149e0c:
            uVar22 = (int32_t)var_e8h + (int32_t)var_108h;
            if (fVar51 <= fVar45) {
                iVar32 = 0;
            } else {
                iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            }
        } else {
            if (fVar51 <= fVar45) goto code_r0x000180149e0c;
            iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            uVar22 = (uint32_t)var_f8h;
        }
        iVar25 = *(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc;
        if (uVar22 == 1) {
            if (0.0 <= *(float *)(iVar25 + 4)) {
                fVar50 = *(float *)(iVar25 + 4) - fVar50;
                if (fVar50 <= fVar49) {
                    fVar50 = fVar49;
                }
                *(float *)(iVar25 + 4) = fVar50;
            }
        } else {
            if (1 < uVar22) {
                fcn.18046f0d0(CONCAT44(uVar56, uVar28));
            }
            while ((0.001 < fVar50 && (iVar41 < (int32_t)uVar22))) {
                fVar51 = *(float *)(iVar25 + 4);
                do {
                    fVar45 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                    if (fVar45 < fVar51) {
                        if (0.0 <= fVar45) {
                            fVar45 = fVar51 - fVar45;
                            goto code_r0x000180149ee6;
                        }
                        break;
                    }
                    iVar41 = iVar41 + 1;
                } while (iVar41 < (int32_t)uVar22);
                fVar45 = fVar51 - 1.0;
code_r0x000180149ee6:
                fVar54 = fVar51 - fVar49;
                if (fVar45 <= fVar51 - fVar49) {
                    fVar54 = fVar45;
                }
                if (fVar54 <= 0.0) break;
                iVar39 = 0;
                fVar51 = fVar50 / (float)iVar41;
                if (fVar54 <= fVar50 / (float)iVar41) {
                    fVar51 = fVar54;
                }
                if (3 < iVar41) {
                    do {
                        iVar23 = (int64_t)iVar39;
                        iVar39 = iVar39 + 4;
                        fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar55 = fVar45 - fVar49;
                        fVar54 = fVar51;
                        if (fVar55 <= fVar51) {
                            fVar54 = fVar55;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                        fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar46 = fVar45 - fVar49;
                        fVar55 = fVar51;
                        if (fVar46 <= fVar51) {
                            fVar55 = fVar46;
                        }
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar45 - fVar55;
                        fVar45 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar47 = fVar45 - fVar49;
                        fVar46 = fVar51;
                        if (fVar47 <= fVar51) {
                            fVar46 = fVar47;
                        }
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar45 - fVar46;
                        fVar45 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar48 = fVar45 - fVar49;
                        fVar47 = fVar51;
                        if (fVar48 <= fVar51) {
                            fVar47 = fVar48;
                        }
                        fVar50 = (((fVar50 - fVar54) - fVar55) - fVar46) - fVar47;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar45 - fVar47;
                    } while (iVar39 < iVar41 + -3);
                }
                while (iVar39 < iVar41) {
                    iVar23 = (int64_t)iVar39;
                    iVar39 = iVar39 + 1;
                    fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar55 = fVar45 - fVar49;
                    fVar54 = fVar51;
                    if (fVar55 <= fVar51) {
                        fVar54 = fVar55;
                    }
                    fVar50 = fVar50 - fVar54;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                }
            }
            iVar41 = 0;
            fVar51 = 0.0;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 4;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar48 = (float)(int32_t)fVar49;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar48;
                    fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                    fVar46 = (float)(int32_t)fVar45;
                    *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar46;
                    fVar50 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                    fVar55 = (float)(int32_t)fVar50;
                    *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar55;
                    fVar54 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                    fVar47 = (float)(int32_t)fVar54;
                    *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar47;
                    fVar51 = (fVar49 - fVar48) + fVar51 + (fVar45 - fVar46) + (fVar50 - fVar55) + (fVar54 - fVar47);
                } while (iVar41 < (int32_t)(uVar22 - 3));
            }
            for (; iVar41 < (int32_t)uVar22; iVar41 = iVar41 + 1) {
                fVar49 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                fVar45 = (float)(int32_t)fVar49;
                *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc) = fVar45;
                fVar51 = fVar51 + (fVar49 - fVar45);
            }
            while (0.0 < fVar51) {
                iVar41 = 0;
                if (3 < (int32_t)uVar22) {
                    do {
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar23 = (int64_t)iVar41;
                        fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 - fVar45 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar50 = *(float *)(iVar25 + 0x14 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar50) {
                            fVar50 = 1.0;
                        }
                        fVar51 = (fVar51 - fVar45) - fVar50;
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar49 + fVar50;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x20 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar41 = iVar41 + 4;
                        fVar49 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x2c + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar49 + fVar45;
                    } while (iVar41 < (int32_t)(uVar22 - 3));
                }
                while (iVar41 < (int32_t)uVar22) {
                    if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 1;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                    if (1.0 <= fVar45) {
                        fVar45 = 1.0;
                    }
                    fVar51 = fVar51 - fVar45;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                }
            }
        }
code_r0x00018014a22a:
        iVar41 = iVar32 + uVar22;
        if (iVar32 < iVar41) {
            arg1 = var_128h;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar25 = (int64_t)iVar32;
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x10 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0xc + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x1c + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x18 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x28 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar25 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x24 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar25 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar24 = 0;
                        }
                        var_100h[iVar24 * 4 + -1] =
                             var_100h[iVar24 * 4 + -1] - (*(float *)(iVar25 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar25 + 0x1c + iVar23) = fVar49;
                    }
                    iVar32 = iVar32 + 4;
                } while (iVar32 < iVar41 + -3);
                if (iVar41 <= iVar32) goto code_r0x00018014a4d3;
            }
            do {
                fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + (int64_t)iVar32 * 0xc);
                if (0.0 <= fVar51) {
                    iVar25 = *piVar42;
                    fVar49 = 1.0;
                    if (1.0 <= fVar51) {
                        fVar49 = fVar51;
                    }
                    iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc) * 0x38;
                    uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                    if ((uVar22 & 0x40) == 0) {
                        iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                    } else {
                        iVar24 = 0;
                    }
                    var_100h[iVar24 * 4 + -1] =
                         var_100h[iVar24 * 4 + -1] - (*(float *)(iVar23 + 0x1c + iVar25) - fVar49);
                    *(float *)(iVar23 + 0x1c + iVar25) = fVar49;
                }
                iVar32 = iVar32 + 1;
                puVar34 = (undefined8 *)var_118h;
                pfVar43 = (float *)var_110h;
            } while (iVar32 < iVar41);
        } else {
code_r0x00018014a4d3:
            puVar34 = (undefined8 *)(arg1 + 0x38);
            pfVar43 = (float *)(arg1 + 0x40);
        }
    }
code_r0x00018014a4db:
    uVar35 = 0;
    auVar53 = ZEXT816(0);
    *(undefined4 *)(arg1 + 0x54) = 0;
    uVar22 = uVar35;
    if (0 < (int32_t)var_108h) {
        do {
            iVar25 = *piVar42;
            iVar23 = (int64_t)(int32_t)uVar22 * 0x38;
            *(float *)(iVar23 + 0x18 + iVar25) = auVar53._0_4_;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_108h + -1) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            auVar53._0_4_ = auVar53._0_4_ + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_108h);
    }
    fVar49 = auVar53._0_4_ + var_100h[1];
    fVar51 = var_100h[1] + var_108h._4_4_;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    uVar22 = uVar35;
    if (0 < (int32_t)(uint32_t)var_f8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar49;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)((uint32_t)var_f8h + -1)) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar49 = fVar49 + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)(uint32_t)var_f8h);
    }
    fVar51 = var_f8h._4_4_ + var_ech;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    fVar45 = (*(float *)(arg1 + 0x40) - *(float *)puVar34) - var_e8h._4_4_;
    fVar51 = 0.0;
    if (0.0 <= fVar45) {
        fVar51 = fVar45;
    }
    if (var_ech + fVar49 <= fVar51) {
        fVar51 = var_ech + fVar49;
    }
    uVar22 = uVar35;
    if (0 < (int32_t)var_e8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h + (uint32_t)var_f8h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar51;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_e8h + -1) {
                fVar49 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar49 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar51 = fVar51 + fVar49 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_e8h);
    }
    fVar51 = var_e8h._4_4_ + var_dch;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    func_0x00018011f640(arg1 + 0xa0, 0);
    if ((!bVar44) && (*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1)) {
        *(undefined4 *)(arg1 + 0x20) = 0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x20);
    if (((*(uint32_t *)(arg1 + 0x20) == 0) && (uVar22 = uVar35, *(int32_t *)(arg1 + 0x24) == 0)) && (var_130h != 0)) {
        uVar28 = *(uint32_t *)var_130h;
        *(uint32_t *)(arg1 + 0x20) = uVar28;
        uVar22 = uVar28;
    }
    *(uint32_t *)(arg1 + 0x2c) = uVar22;
    *(undefined *)(arg1 + 0x84) = 0;
    iVar25 = *(int64_t *)(iVar38 + 0x23c0);
    if (((iVar25 != 0) && (*(int64_t *)(iVar25 + 0x4c0) != 0)) &&
       (*(int64_t *)(*(int64_t *)(iVar25 + 0x4c0) + 0x40) == arg1)) {
        uVar28 = *(uint32_t *)(iVar25 + 200);
        *(uint32_t *)(arg1 + 0x2c) = uVar28;
    }
    if (uVar28 != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (0 < iVar32) {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar35 * 0x38;
                if (*(uint32_t *)(uVar26 + iVar25) == uVar28) {
                    if ((*(uint8_t *)(uVar26 + 4 + iVar25) & 0xc0) != 0) break;
                    fVar51 = *pfVar43;
                    fVar49 = *(float *)puVar34;
                    fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
                    iVar41 = (int32_t)(uVar26 / 0x38);
                    if ((int32_t)var_108h + -1 < iVar41) {
                        fVar50 = (float)((uint32_t)fVar45 ^ 0x80000000);
                    } else {
                        fVar50 = 0.0;
                    }
                    fVar54 = *(float *)(uVar26 + 0x18 + iVar25) - var_108h._4_4_;
                    fVar50 = fVar54 + fVar50;
                    if (iVar32 - (int32_t)var_e8h <= iVar41 + 1) {
                        fVar45 = 1.0;
                    }
                    fVar55 = *(float *)(uVar26 + 0x1c + iVar25);
                    *(undefined4 *)(arg1 + 100) = 0;
                    fVar45 = fVar54 + fVar55 + fVar45;
                    if (*(float *)(arg1 + 0x60) <= fVar50) {
                        fVar51 = (((fVar51 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech;
                        if (fVar45 - fVar50 < fVar51) {
                            if (*(float *)(arg1 + 0x60) < fVar45 - fVar51) {
                                *(float *)(arg1 + 0x60) = fVar45 - fVar51;
                                fVar51 = (fVar50 - fVar51) - *(float *)(arg1 + 0x5c);
                                if (fVar51 <= 0.0) {
                                    fVar51 = 0.0;
                                }
                                *(float *)(arg1 + 100) = fVar51;
                            }
                            break;
                        }
                    }
                    fVar45 = *(float *)(arg1 + 0x5c) - fVar45;
                    *(float *)(arg1 + 0x60) = fVar50;
                    if (fVar45 <= 0.0) {
                        fVar45 = 0.0;
                    }
                    *(float *)(arg1 + 100) = fVar45;
                    break;
                }
                uVar35 = uVar35 + 1;
            } while ((int32_t)uVar35 < iVar32);
        }
        goto code_r0x00018014a9b6;
    }
    if ((*pcVar40 == '\0') || (cVar15 = func_0x000180108120(puVar34, pfVar43, 1), cVar15 == '\0'))
    goto code_r0x00018014a9b6;
    iVar25 = *(int64_t *)(iVar38 + 0x15e0);
    if (((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) != 0) &&
        ((((iVar23 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) + 0x428), iVar23 != 0 &&
           (*(char *)(iVar23 + 0x10a) != '\0')) && (iVar23 != *(int64_t *)(iVar25 + 0x428))) &&
         (((*(uint32_t *)(iVar23 + 0x14) >> 0x1b & 1) != 0 || ((*(uint32_t *)(iVar23 + 0x14) >> 0x1a & 1) != 0)))))) &&
       (iVar24 = *(int64_t *)(iVar25 + 0x418), *(int64_t *)(iVar24 + 0x418) != iVar23)) {
        do {
            if (iVar24 == iVar23) goto code_r0x00018014a8ae;
            iVar24 = *(int64_t *)(iVar24 + 0x410);
        } while (iVar24 != 0);
        goto code_r0x00018014a9b6;
    }
code_r0x00018014a8ae:
    if ((*(int64_t *)(iVar25 + 0x48) != *(int64_t *)(*(int64_t *)0x180781f28 + 0x2168)) &&
       ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) == 0 ||
        (*(int64_t *)(iVar25 + 0x428) != *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) + 0x428)))))
    goto code_r0x00018014a9b6;
    pfVar31 = (float *)(iVar38 + 0x128);
    if (*(char *)(iVar38 + 0xbaa) == '\0') {
        pfVar31 = (float *)(iVar38 + 300);
    }
    iVar32 = *(int32_t *)(arg1 + 0x1c);
    uVar26 = (uint64_t)((*(char *)(iVar38 + 0xbaa) != '\0') + 0x295);
    iVar25 = *(int64_t *)0x180781f28;
    piVar20 = (int32_t *)func_0x0001800f45c0(*(int64_t *)0x180781f28, uVar26);
    if (iVar32 == 0) {
        bVar44 = *(char *)(piVar20 + 2) == '\0';
code_r0x00018014a936:
        if (bVar44) {
code_r0x00018014a938:
            fVar51 = *pfVar31;
            if (fVar51 != 0.0) {
                fVar49 = *(float *)puVar34;
                fVar45 = *pfVar43;
                *(undefined4 *)(arg1 + 100) = 0;
                fVar51 = *(float *)(arg1 + 0x60) -
                         (((((fVar45 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech) * fVar51) / 3.0;
                fVar49 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar49);
                if (fVar49 <= fVar51) {
                    fVar51 = fVar49;
                }
                if (fVar51 <= 0.0) {
                    fVar51 = 0.0;
                }
                *(float *)(arg1 + 0x60) = fVar51;
            }
        }
    } else {
        if (*piVar20 == iVar32) goto code_r0x00018014a938;
        if (*(char *)(piVar20 + 2) == '\0') {
            bVar44 = *piVar20 == -1;
            goto code_r0x00018014a936;
        }
    }
    *(int32_t *)(iVar25 + -0x130 + uVar26 * 0xc) = iVar32;
    *(int32_t *)(iVar25 + -0x134 + uVar26 * 0xc) = iVar32;
    *(undefined2 *)(iVar25 + -300 + uVar26 * 0xc) = 0;
code_r0x00018014a9b6:
    fVar51 = *(float *)puVar34;
    fVar45 = *(float *)(arg1 + 0x54) - (*pfVar43 - fVar51);
    fVar49 = *(float *)(arg1 + 0x5c);
    if (fVar45 <= *(float *)(arg1 + 0x5c)) {
        fVar49 = fVar45;
    }
    if (fVar49 <= 0.0) {
        fVar49 = 0.0;
    }
    *(float *)(arg1 + 0x5c) = fVar49;
    fVar50 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar51);
    fVar45 = *(float *)(arg1 + 0x60);
    if (fVar50 <= *(float *)(arg1 + 0x60)) {
        fVar45 = fVar50;
    }
    if (fVar45 <= 0.0) {
        fVar45 = 0.0;
    }
    *(float *)(arg1 + 0x60) = fVar45;
    if (fVar49 == fVar45) {
        *(undefined4 *)(arg1 + 0x68) = 0;
    } else {
        fVar54 = *(float *)(iVar38 + 0x12f8) * 70.0;
        fVar50 = *(float *)(arg1 + 0x68);
        if (*(float *)(arg1 + 0x68) <= fVar54) {
            fVar50 = fVar54;
        }
        fVar54 = (float)((uint32_t)(fVar45 - fVar49) & 0x7fffffff) / 0.3;
        if (fVar50 <= fVar54) {
            fVar50 = fVar54;
        }
        *(float *)(arg1 + 0x68) = fVar50;
        fVar54 = fVar45;
        if ((*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1) &&
           (*(float *)(arg1 + 100) <= *(float *)(iVar38 + 0x12f8) * 10.0)) {
            fVar50 = fVar50 * *(float *)(iVar38 + 0x48);
            if (fVar45 <= fVar49) {
                fVar54 = fVar49;
                if ((fVar45 < fVar49) && (fVar54 = fVar49 - fVar50, fVar54 <= fVar45)) {
                    fVar54 = fVar45;
                }
            } else {
                fVar54 = fVar50 + fVar49;
                if (fVar45 <= fVar54) {
                    fVar54 = fVar45;
                }
            }
        }
        *(float *)(arg1 + 0x5c) = fVar54;
    }
    uVar18 = *puVar34;
    *(float *)(arg1 + 0x6c) = fVar51 + var_108h._4_4_ + var_100h[1];
    *(float *)(arg1 + 0x70) = (*(float *)(arg1 + 0x40) - var_e8h._4_4_) - var_ech;
    iVar38 = *(int64_t *)(iVar38 + 0x15e0);
    *(undefined8 *)(iVar38 + 0x158) = uVar18;
    var_128h = CONCAT44(*(float *)(arg1 + 0x44) - *(float *)(arg1 + 0x3c), *(undefined4 *)(arg1 + 0x54));
    func_0x00018010bbf0(&var_128h);
    fVar49 = *(float *)(arg1 + 0x58) + *(float *)puVar34;
    fVar51 = *(float *)(iVar38 + 0x178);
    if (*(float *)(iVar38 + 0x178) <= fVar49) {
        fVar51 = fVar49;
    }
    *(float *)(iVar38 + 0x178) = fVar51;
    func_0x000180459870(var_d8h ^ (uint64_t)auStackY_198);
    return;
code_r0x000180149c5c:
    uVar22 = (int32_t)uVar26 + 1;
    uVar26 = (uint64_t)uVar22;
    if (iVar39 <= (int32_t)uVar22) goto code_r0x000180149c63;
    goto code_r0x000180149c50;
}

// ============================================================
// Function: FUN_18014994d
// Address: 0x18014994d
// Size: 385 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_144h
// WARNING: Variable defined which should be unmapped: var_178h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180148fa0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined auVar3 [16];
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    bool bVar13;
    bool bVar14;
    char cVar15;
    uint8_t uVar16;
    int32_t iVar17;
    undefined8 uVar18;
    int64_t iVar19;
    int32_t *piVar20;
    uint32_t uVar21;
    uint32_t uVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    uint64_t uVar26;
    undefined4 *puVar27;
    uint32_t uVar28;
    undefined4 *puVar29;
    uint32_t *puVar30;
    float *pfVar31;
    int32_t iVar32;
    uint32_t *puVar33;
    undefined8 *puVar34;
    uint32_t uVar35;
    int32_t iVar36;
    undefined4 *puVar37;
    int64_t iVar38;
    int32_t iVar39;
    char *pcVar40;
    int32_t iVar41;
    int64_t *piVar42;
    float *pfVar43;
    bool bVar44;
    float fVar45;
    float fVar46;
    float fVar47;
    float fVar48;
    float fVar49;
    float fVar50;
    float fVar51;
    undefined auVar52 [16];
    undefined auVar53 [16];
    float fVar54;
    undefined4 unaff_XMM12_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    float fVar55;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_198 [32];
    int64_t var_178h;
    undefined4 in_stack_fffffffffffffe98;
    undefined4 in_stack_fffffffffffffe9c;
    undefined4 uVar56;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int32_t var_148h;
    int64_t var_144h;
    undefined4 uStack_13c;
    undefined4 uVar57;
    undefined4 in_stack_fffffffffffffecc;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    float var_100h [2];
    int64_t var_f8h;
    float var_f0h;
    float var_ech;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar38 = *(int64_t *)0x180781f28;
    var_d8h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_198;
    fVar51 = *(float *)(arg1 + 0x48);
    var_118h = arg1 + 0x38;
    *(undefined *)(arg1 + 0x83) = 0;
    fVar49 = *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38);
    var_110h = arg1 + 0x40;
    uVar22 = *(uint32_t *)(arg1 + 8);
    *(float *)(arg1 + 0x48) = fVar49;
    uVar56 = CONCAT31((unkint3)((uint32_t)in_stack_fffffffffffffe9c >> 8), fVar49 < fVar51);
    auVar3._4_4_ = unaff_XMM12_Dc;
    auVar3._0_4_ = unaff_XMM12_Db;
    auVar3._8_4_ = unaff_XMM12_Dd;
    auVar3._12_4_ = 0;
    _var_98h = auVar3 << 0x20;
    bVar44 = false;
    uVar28 = 0;
    uVar35 = 0;
    _var_108h = ZEXT816(0);
    _var_f8h = ZEXT816(0);
    _var_e8h = ZEXT816(0);
    bVar13 = false;
    if (0 < (int32_t)uVar22) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)(arg1 + 0x10);
            iVar23 = (int64_t)(int32_t)uVar35 * 0x38;
            if ((*(int32_t *)(iVar23 + 0x10 + iVar25) < *(int32_t *)(arg1 + 0x34)) ||
               (*(char *)(iVar23 + 0x30 + iVar25) != '\0')) {
                if (*(int32_t *)(arg1 + 0x2c) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x2c) = 0;
                }
                if (*(int32_t *)(arg1 + 0x20) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x20) = 0;
                }
                if (*(int32_t *)(arg1 + 0x24) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x24) = 0;
                }
            } else {
                if (uVar28 != uVar35) {
                    auVar3 = *(undefined (*) [16])(iVar23 + 0x10 + iVar25);
                    puVar37 = (undefined4 *)(iVar23 + 0x20 + iVar25);
                    uVar57 = *puVar37;
                    uVar1 = puVar37[1];
                    uVar2 = puVar37[2];
                    uVar4 = puVar37[3];
                    uVar18 = *(undefined8 *)(iVar23 + 0x30 + iVar25);
                    iVar24 = (int64_t)(int32_t)uVar28 * 0x38;
                    *(undefined (*) [16])(iVar24 + iVar25) = *(undefined (*) [16])(iVar23 + iVar25);
                    *(undefined (*) [16])(iVar24 + 0x10 + iVar25) = auVar3;
                    puVar37 = (undefined4 *)(iVar24 + 0x20 + iVar25);
                    *puVar37 = uVar57;
                    puVar37[1] = uVar1;
                    puVar37[2] = uVar2;
                    puVar37[3] = uVar4;
                    *(undefined8 *)(iVar24 + 0x30 + iVar25) = uVar18;
                }
                iVar23 = (int64_t)(int32_t)uVar28 * 0x38;
                iVar25 = *(int64_t *)(arg1 + 0x10);
                uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                *(int16_t *)(iVar23 + 0x2e + iVar25) = (int16_t)uVar28;
                if ((uVar22 & 0x40) == 0) {
                    uVar26 = (uint64_t)(((uVar22 & 0x80) != 0) + 1);
                } else {
                    uVar26 = 0;
                }
                if (0 < (int32_t)uVar28) {
                    uVar22 = *(uint32_t *)(*(int64_t *)(arg1 + 0x10) + -0x34 + iVar23);
                    cVar15 = '\0';
                    if ((uVar22 & 0x40) == 0) {
                        cVar15 = ((uVar22 & 0x80) != 0) + '\x01';
                    }
                    if ((int32_t)uVar26 == 0) {
                        if (cVar15 == '\0') goto code_r0x000180149140;
                        bVar44 = true;
                    }
                    if (cVar15 == '\x02') {
                        if ((int32_t)uVar26 != 2) {
                            bVar44 = true;
                        }
                        var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                        uVar28 = uVar28 + 1;
                        goto code_r0x000180149172;
                    }
                }
code_r0x000180149140:
                var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                uVar28 = uVar28 + 1;
            }
code_r0x000180149172:
            uVar22 = *(uint32_t *)(arg1 + 8);
            uVar35 = uVar35 + 1;
            bVar13 = bVar44;
        } while ((int32_t)uVar35 < (int32_t)uVar22);
    }
    uVar35 = 8;
    var_128h = arg1;
    if (uVar22 != uVar28) {
        iVar32 = *(int32_t *)(arg1 + 0xc);
        if (iVar32 < (int32_t)uVar28) {
            uVar22 = uVar35;
            if (iVar32 != 0) {
                uVar22 = iVar32 / 2 + iVar32;
            }
            uVar21 = uVar28;
            if ((int32_t)uVar28 < (int32_t)uVar22) {
                uVar21 = uVar22;
            }
            func_0x00018011f970(arg1 + 8, uVar21);
        }
        *(uint32_t *)(arg1 + 8) = uVar28;
        uVar22 = uVar28;
    }
    piVar42 = (int64_t *)(arg1 + 0x10);
    if ((bVar44) && (1 < uVar22)) {
        fcn.18046f0d0(CONCAT44(uVar56, in_stack_fffffffffffffe98));
    }
    fVar51 = *(float *)(iVar38 + 0xdf4);
    if (((int32_t)var_108h < 1) || (var_100h[1] = fVar51, (int32_t)((int32_t)var_e8h + (uint32_t)var_f8h) < 1)) {
        var_100h[1] = 0.0;
    }
    if (((int32_t)(uint32_t)var_f8h < 1) || (var_ech = fVar51, (int32_t)var_e8h < 1)) {
        var_ech = 0.0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x28);
    uVar21 = 0;
    uVar28 = 0;
    if (uVar22 != 0) {
        *(undefined4 *)(arg1 + 0x28) = 0;
        uVar28 = uVar22;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x24);
    if (uVar22 != 0) {
        *(uint32_t *)(arg1 + 0x20) = uVar22;
        *(undefined4 *)(arg1 + 0x24) = 0;
        uVar28 = uVar22;
    }
    if (*(int32_t *)(arg1 + 0x7c) != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (iVar32 < 1) {
code_r0x00018014939d:
            *(undefined4 *)(arg1 + 0x7c) = 0;
        } else {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar21 * 0x38;
                puVar37 = (undefined4 *)(uVar26 + iVar25);
                if (*(int32_t *)(uVar26 + iVar25) == *(int32_t *)(arg1 + 0x7c)) {
                    if ((puVar37[1] & 0x20) == 0) {
                        iVar41 = (int32_t)(uVar26 / 0x38) + (int32_t)*(int16_t *)(arg1 + 0x80);
                        if ((-1 < iVar41) && (iVar41 < iVar32)) {
                            puVar29 = (undefined4 *)((int64_t)iVar41 * 0x38 + iVar25);
                            if (((puVar29[1] & 0x20) == 0) && (((puVar29[1] ^ puVar37[1]) & 0xc0) == 0)) {
                                uVar18 = *(undefined8 *)(puVar37 + 0xc);
                                uVar57 = *puVar37;
                                uVar1 = puVar37[1];
                                uVar2 = puVar37[2];
                                uVar4 = puVar37[3];
                                uVar5 = puVar37[4];
                                uVar6 = puVar37[5];
                                uVar7 = puVar37[6];
                                uVar8 = puVar37[7];
                                uVar9 = puVar37[8];
                                uVar10 = puVar37[9];
                                uVar11 = puVar37[10];
                                uVar12 = puVar37[0xb];
                                if (*(int16_t *)(arg1 + 0x80) < 1) {
                                    puVar37 = puVar29 + 0xe;
                                    puVar27 = puVar29;
                                } else {
                                    puVar27 = puVar37 + 0xe;
                                }
                                fcn.180498030(puVar37, puVar27);
                                *puVar29 = uVar57;
                                puVar29[1] = uVar1;
                                puVar29[2] = uVar2;
                                puVar29[3] = uVar4;
                                puVar29[4] = uVar5;
                                puVar29[5] = uVar6;
                                puVar29[6] = uVar7;
                                puVar29[7] = uVar8;
                                puVar29[8] = uVar9;
                                puVar29[9] = uVar10;
                                puVar29[10] = uVar11;
                                puVar29[0xb] = uVar12;
                                *(undefined8 *)(puVar29 + 0xc) = uVar18;
                                if (((*(uint32_t *)(arg1 + 0x18) & 0x400000) != 0) &&
                                   (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)) {
                                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) =
                                         *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
                                }
                                if (*(uint32_t *)(arg1 + 0x7c) == *(uint32_t *)(arg1 + 0x20)) {
                                    uVar28 = *(uint32_t *)(arg1 + 0x7c);
                                }
                            }
                        }
                    }
                    goto code_r0x00018014939d;
                }
                uVar21 = uVar21 + 1;
            } while ((int32_t)uVar21 < iVar32);
            *(undefined4 *)(arg1 + 0x7c) = 0;
        }
    }
    iVar25 = *(int64_t *)0x180781f28;
    puVar33 = (uint32_t *)0x0;
    if ((*(uint8_t *)(arg1 + 0x18) & 4) != 0) {
        uVar57 = *(undefined4 *)(arg1 + 0x3c);
        var_148h = 0;
        fVar49 = *(float *)(*(int64_t *)0x180781f28 + 0xde0);
        iVar23 = *(int64_t *)0x180781f28 + 0x20c0;
        iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
        uVar1 = *(undefined4 *)(iVar24 + 0x158);
        uVar2 = *(undefined4 *)(iVar24 + 0x15c);
        *(float *)(iVar24 + 0x158) = *(float *)(arg1 + 0x38) - fVar49;
        *(undefined4 *)(iVar24 + 0x15c) = uVar57;
        *(float *)(arg1 + 0x38) = fVar49 + fVar45 + *(float *)(arg1 + 0x38);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        uVar57 = *(undefined4 *)(iVar25 + 0xed8);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        fVar49 = *(float *)(iVar25 + 0xedc);
        fcn.18011f2b0(iVar23, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar57;
            *(float *)(iVar25 + 0xedc) = fVar49 * 0.5;
        }
        iVar25 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        uVar57 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x102c);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar25 + 0x1020) = 0;
            *(undefined8 *)(iVar25 + 0x1028) = 0;
        }
        cVar15 = func_0x00018013d0a0();
        fcn.1800f6770(2);
        if (cVar15 != '\0') {
            iVar32 = 0;
            if (0 < *(int32_t *)(arg1 + 8)) {
                do {
                    puVar30 = (uint32_t *)((int64_t)iVar32 * 0x38 + *piVar42);
                    if (((puVar30[1] & 0x200000) == 0) &&
                       (cVar15 = fcn.180146c70(CONCAT44(uStack_13c, var_144h._4_4_), 
                                               CONCAT44(in_stack_fffffffffffffecc, uVar57)), cVar15 != '\0')) {
                        puVar33 = puVar30;
                    }
                    iVar32 = iVar32 + 1;
                } while (iVar32 < *(int32_t *)(arg1 + 8));
            }
            iVar25 = *(int64_t *)0x180781f28;
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) + -1;
            iVar32 = func_0x000180498f10(*(undefined8 *)(*(int64_t *)(iVar25 + 0x15e0) + 8), &var_148h);
            if (iVar32 == 0) {
                func_0x00018010d5c0();
            } else if (*(code **)(iVar25 + 0x2a40) != (code *)0x0) {
                (**(code **)(iVar25 + 0x2a40))(iVar25, *(undefined8 *)(iVar25 + 0x2a48));
            }
        }
        *(undefined4 *)(iVar24 + 0x158) = uVar1;
        *(undefined4 *)(iVar24 + 0x15c) = uVar2;
        if (puVar33 != (uint32_t *)0x0) {
            uVar28 = *puVar33;
            *(uint32_t *)(arg1 + 0x20) = uVar28;
        }
    }
    iVar41 = 1;
    uVar22 = *(uint32_t *)(arg1 + 8);
    var_144h._0_4_ = (int32_t)var_e8h + (int32_t)var_108h;
    var_148h = 0;
    iVar32 = *(int32_t *)(iVar38 + 0x257c);
    var_144h._4_4_ = (int32_t)var_108h;
    if (iVar32 < (int32_t)uVar22) {
        if (iVar32 != 0) {
            uVar35 = iVar32 / 2 + iVar32;
        }
        uVar21 = uVar22;
        if ((int32_t)uVar22 < (int32_t)uVar35) {
            uVar21 = uVar35;
        }
        if (iVar32 < (int32_t)uVar21) {
            uVar18 = fcn.18046d050((int64_t)(int32_t)uVar21 * 0xc);
            if (*(int64_t *)(iVar38 + 0x2580) != 0) {
                fcn.180498030(uVar18);
                fcn.180460d90(*(undefined8 *)(iVar38 + 0x2580));
            }
            *(undefined8 *)(iVar38 + 0x2580) = uVar18;
            *(uint32_t *)(iVar38 + 0x257c) = uVar21;
        }
    }
    *(uint32_t *)(iVar38 + 0x2578) = uVar22;
    if ((*(uint8_t *)(arg1 + 0x18) & 0x80) == 0) {
        fVar49 = 1.0;
    } else {
        fVar49 = *(float *)(iVar38 + 0xe40);
    }
    iVar32 = *(int32_t *)(arg1 + 8);
    iVar39 = 0;
    var_130h = 0;
    bVar44 = false;
    uVar22 = 0xffffffff;
    bVar13 = false;
    if (0 < iVar32) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)0x180781f28;
            puVar33 = (uint32_t *)((int64_t)iVar39 * 0x38 + *piVar42);
            if (((var_130h == 0) || (*(int32_t *)(var_130h + 0x14) < (int32_t)puVar33[5])) &&
               ((puVar33[1] & 0x200000) == 0)) {
                var_130h = (int64_t)puVar33;
            }
            uVar35 = *puVar33;
            if (uVar35 == *(uint32_t *)(arg1 + 0x20)) {
                bVar44 = true;
            }
            if ((uVar28 == 0) && (*(uint32_t *)(iVar38 + 0x23a4) == uVar35)) {
                uVar28 = uVar35;
            }
            auVar52 = ZEXT416(puVar33[9]);
            if ((float)puVar33[9] < 0.0) {
                uVar35 = puVar33[1];
                var_178h._0_4_ = 0xbf800000;
                fcn.1800fe0a0(CONCAT44(var_178h._4_4_, 0xbf800000), SUB168(_var_98h, 8));
                fVar45 = *(float *)(iVar25 + 0xddc);
                if ((uVar35 & 0x100001) == 0x100000) {
                    fVar50 = fVar45 + 1.0;
                } else {
                    fVar50 = *(float *)(iVar25 + 0x12f8) + *(float *)(iVar25 + 0xdf4) + fVar45;
                }
                fVar50 = fVar50 + var_120h + fVar45;
                auVar52 = ZEXT416((uint32_t)fVar50);
                fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 20.0;
                if (fVar45 <= fVar50) {
                    auVar52 = ZEXT416((uint32_t)fVar45);
                }
            }
            uVar35 = puVar33[1];
            puVar33[8] = (uint32_t)auVar52._0_4_;
            if ((uVar35 >> 0x15 & 1) == 0) {
                if (auVar52._0_4_ <= *(float *)(iVar38 + 0xe3c)) {
                    auVar52._0_4_ = *(float *)(iVar38 + 0xe3c);
                }
                puVar33[8] = auVar52._0_4_;
            }
            if ((uVar35 & 0x40) == 0) {
                uVar35 = ((uVar35 & 0x80) != 0) + 1;
            } else {
                uVar35 = 0;
            }
            uVar26 = (uint64_t)uVar35;
            if (uVar35 == uVar22) {
                fVar50 = auVar52._0_4_ + fVar51;
                fVar45 = fVar51;
            } else {
                fVar50 = auVar52._0_4_ + 0.0;
                fVar45 = 0.0;
            }
            var_100h[uVar26 * 4 + -1] = fVar50 + var_100h[uVar26 * 4 + -1];
            fVar50 = (float)puVar33[8];
            if (fVar49 <= (float)puVar33[8]) {
                fVar50 = fVar49;
            }
            var_100h[uVar26 * 4] = fVar50 + fVar45 + var_100h[uVar26 * 4];
            iVar23 = (int64_t)(&var_148h)[uVar26];
            (&var_148h)[uVar26] = (&var_148h)[uVar26] + 1;
            iVar25 = *(int64_t *)(iVar38 + 0x2580);
            *(int32_t *)(iVar25 + iVar23 * 0xc) = iVar39;
            iVar39 = iVar39 + 1;
            uVar22 = puVar33[8];
            *(uint32_t *)(iVar25 + 8 + iVar23 * 0xc) = uVar22;
            *(uint32_t *)(iVar25 + 4 + iVar23 * 0xc) = uVar22;
            fVar45 = (float)puVar33[8];
            if (fVar45 <= 1.0) {
                fVar45 = 1.0;
            }
            puVar33[7] = (uint32_t)fVar45;
            iVar32 = *(int32_t *)(arg1 + 8);
            uVar22 = uVar35;
            bVar13 = bVar44;
        } while (iVar39 < iVar32);
    }
    uVar22 = *(uint32_t *)(arg1 + 0x18);
    *(float *)(arg1 + 0x58) = var_100h[1] + var_108h._4_4_ + 0.0 + var_f8h._4_4_ + var_ech + var_e8h._4_4_ + var_dch;
    iVar25 = *(int64_t *)0x180781f28;
    if (((uVar22 & 0x200) == 0) && (-1 < (char)uVar22)) {
        bVar14 = false;
code_r0x00018014992e:
        bVar13 = bVar14;
        fVar51 = var_e0h + var_dch + var_100h[0] + var_100h[1] + 0.0 + var_f0h + var_ech;
    } else {
        bVar13 = true;
        bVar14 = true;
        if ((uVar22 & 0x200) == 0) goto code_r0x00018014992e;
        fVar51 = *(float *)(arg1 + 0x54);
    }
    if ((((fVar51 <= *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38)) || (iVar32 < 2)) || ((uVar22 & 0x10) != 0)) ||
       (!bVar13)) {
        *(undefined *)(arg1 + 0x86) = 0;
    } else {
        *(undefined *)(arg1 + 0x86) = 1;
        var_148h = 0;
        fVar51 = *(float *)(iVar25 + 0x12f8);
        iVar23 = *(int64_t *)(iVar25 + 0x15e0);
        fVar54 = fVar51 - 2.0;
        fVar45 = *(float *)(iVar25 + 0xde0);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        uVar57 = *(undefined4 *)(iVar23 + 0x158);
        uVar1 = *(undefined4 *)(iVar25 + 0xed8);
        fVar50 = *(float *)(iVar25 + 0xedc);
        fVar55 = fVar54 + fVar54;
        var_120h = *(float *)(iVar23 + 0x15c);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        fcn.18011f2b0(iVar25 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar1;
            *(float *)(iVar25 + 0xedc) = fVar50 * 0.5;
        }
        iVar24 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar24 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar24 + 0x1020) = 0;
            *(undefined8 *)(iVar24 + 0x1028) = 0;
        }
        iVar24 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 10;
        piVar20 = (int32_t *)(iVar24 + 0x2100);
        iVar32 = *(int32_t *)(iVar24 + 0x2104);
        uVar1 = *(undefined4 *)(iVar24 + 0x1f78);
        if (*piVar20 == iVar32) {
            iVar39 = *piVar20 + 1;
            if (iVar32 == 0) {
                iVar32 = 8;
            } else {
                iVar32 = iVar32 / 2 + iVar32;
            }
            if (iVar39 < iVar32) {
                iVar39 = iVar32;
            }
            fcn.18011fb10(piVar20, iVar39);
        }
        *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + (int64_t)*piVar20 * 4) = uVar1;
        *piVar20 = *piVar20 + 1;
        uVar1 = *(undefined4 *)(iVar25 + 0xa8);
        uVar2 = *(undefined4 *)(iVar25 + 0xac);
        *(undefined4 *)(iVar25 + 0xa8) = 0x3e800000;
        *(undefined4 *)(iVar25 + 0xac) = 0x3e4ccccd;
        fVar46 = *(float *)(arg1 + 0x40) - fVar55;
        fVar50 = *(float *)(arg1 + 0x38);
        if (*(float *)(arg1 + 0x38) <= fVar46) {
            fVar50 = fVar46;
        }
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50;
        uVar16 = func_0x00018013a9f0(0x180645ba0, 0, CONCAT44(fVar45 + fVar45 + fVar51, fVar54));
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50 + fVar54;
        cVar15 = func_0x00018013a9f0(0x180645ba4, 1);
        iVar24 = *(int64_t *)0x180781f28;
        if (cVar15 == '\0') {
            iVar32 = (uVar16 ^ 1) - 1;
        } else {
            iVar32 = 1;
        }
        iVar39 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
        if (iVar39 < 2) {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48));
            }
        } else {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar39 + -1;
            *(undefined4 *)(iVar24 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + -8 + (int64_t)iVar39 * 4)
            ;
        }
        fcn.1800f6770();
        *(undefined4 *)(iVar25 + 0xac) = uVar2;
        *(undefined4 *)(iVar25 + 0xa8) = uVar1;
        if (iVar32 == 0) {
            puVar33 = (uint32_t *)0x0;
code_r0x000180149cf6:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
            if ((puVar33 != (uint32_t *)0x0) && (uVar28 = *puVar33, (puVar33[1] & 0x200000) == 0)) {
                *(uint32_t *)(arg1 + 0x20) = uVar28;
            }
        } else {
            if ((*(int32_t *)(arg1 + 0x20) != 0) && (iVar39 = *(int32_t *)(arg1 + 8), 0 < iVar39)) {
                uVar26 = 0;
                iVar25 = *piVar42;
code_r0x000180149c50:
                if (*(int32_t *)(uVar26 * 0x38 + iVar25) != *(int32_t *)(arg1 + 0x20)) goto code_r0x000180149c5c;
                uVar26 = (uVar26 * 0x38) / 0x38;
                iVar36 = (int32_t)uVar26 + iVar32;
                do {
                    if ((iVar36 < 0) || (iVar17 = iVar36, iVar39 <= iVar36)) {
                        iVar17 = (int32_t)uVar26;
                    }
                    puVar33 = (uint32_t *)((int64_t)iVar17 * 0x38 + iVar25);
                } while ((((*(uint32_t *)(iVar25 + 4 + (int64_t)iVar17 * 0x38) & 0x200000) != 0) &&
                         (iVar36 = iVar36 + iVar32, -1 < iVar36)) &&
                        (uVar26 = (uint64_t)(uint32_t)((int32_t)uVar26 + iVar32), iVar36 < iVar39));
                goto code_r0x000180149cf6;
            }
code_r0x000180149c63:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
        }
    }
    pfVar43 = (float *)(arg1 + 0x40);
    pcVar40 = (char *)(arg1 + 0x86);
    puVar34 = (undefined8 *)(arg1 + 0x38);
    if ((uVar28 == 0) && ((char)uVar56 != '\0')) {
        uVar28 = *(uint32_t *)(arg1 + 0x20);
    }
    fVar51 = *pfVar43 - *(float *)puVar34;
    fVar45 = var_e8h._4_4_ + var_dch + var_108h._4_4_ + var_100h[1];
    if (fVar51 <= fVar45) {
        fVar50 = fVar45 - fVar51;
    } else {
        fVar50 = (var_f8h._4_4_ + var_ech) - ((fVar51 - (var_108h._4_4_ + var_100h[1])) - (var_e8h._4_4_ + var_dch));
        if (fVar50 <= 0.0) {
            fVar50 = 0.0;
        }
    }
    if (1.0 <= fVar50) {
        if ((*(uint32_t *)(arg1 + 0x18) & 0x180) == 0) {
            if (fVar45 < fVar51) goto code_r0x00018014a4db;
code_r0x000180149e0c:
            uVar22 = (int32_t)var_e8h + (int32_t)var_108h;
            if (fVar51 <= fVar45) {
                iVar32 = 0;
            } else {
                iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            }
        } else {
            if (fVar51 <= fVar45) goto code_r0x000180149e0c;
            iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            uVar22 = (uint32_t)var_f8h;
        }
        iVar25 = *(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc;
        if (uVar22 == 1) {
            if (0.0 <= *(float *)(iVar25 + 4)) {
                fVar50 = *(float *)(iVar25 + 4) - fVar50;
                if (fVar50 <= fVar49) {
                    fVar50 = fVar49;
                }
                *(float *)(iVar25 + 4) = fVar50;
            }
        } else {
            if (1 < uVar22) {
                fcn.18046f0d0(CONCAT44(uVar56, uVar28));
            }
            while ((0.001 < fVar50 && (iVar41 < (int32_t)uVar22))) {
                fVar51 = *(float *)(iVar25 + 4);
                do {
                    fVar45 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                    if (fVar45 < fVar51) {
                        if (0.0 <= fVar45) {
                            fVar45 = fVar51 - fVar45;
                            goto code_r0x000180149ee6;
                        }
                        break;
                    }
                    iVar41 = iVar41 + 1;
                } while (iVar41 < (int32_t)uVar22);
                fVar45 = fVar51 - 1.0;
code_r0x000180149ee6:
                fVar54 = fVar51 - fVar49;
                if (fVar45 <= fVar51 - fVar49) {
                    fVar54 = fVar45;
                }
                if (fVar54 <= 0.0) break;
                iVar39 = 0;
                fVar51 = fVar50 / (float)iVar41;
                if (fVar54 <= fVar50 / (float)iVar41) {
                    fVar51 = fVar54;
                }
                if (3 < iVar41) {
                    do {
                        iVar23 = (int64_t)iVar39;
                        iVar39 = iVar39 + 4;
                        fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar55 = fVar45 - fVar49;
                        fVar54 = fVar51;
                        if (fVar55 <= fVar51) {
                            fVar54 = fVar55;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                        fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar46 = fVar45 - fVar49;
                        fVar55 = fVar51;
                        if (fVar46 <= fVar51) {
                            fVar55 = fVar46;
                        }
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar45 - fVar55;
                        fVar45 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar47 = fVar45 - fVar49;
                        fVar46 = fVar51;
                        if (fVar47 <= fVar51) {
                            fVar46 = fVar47;
                        }
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar45 - fVar46;
                        fVar45 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar48 = fVar45 - fVar49;
                        fVar47 = fVar51;
                        if (fVar48 <= fVar51) {
                            fVar47 = fVar48;
                        }
                        fVar50 = (((fVar50 - fVar54) - fVar55) - fVar46) - fVar47;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar45 - fVar47;
                    } while (iVar39 < iVar41 + -3);
                }
                while (iVar39 < iVar41) {
                    iVar23 = (int64_t)iVar39;
                    iVar39 = iVar39 + 1;
                    fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar55 = fVar45 - fVar49;
                    fVar54 = fVar51;
                    if (fVar55 <= fVar51) {
                        fVar54 = fVar55;
                    }
                    fVar50 = fVar50 - fVar54;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                }
            }
            iVar41 = 0;
            fVar51 = 0.0;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 4;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar48 = (float)(int32_t)fVar49;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar48;
                    fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                    fVar46 = (float)(int32_t)fVar45;
                    *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar46;
                    fVar50 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                    fVar55 = (float)(int32_t)fVar50;
                    *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar55;
                    fVar54 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                    fVar47 = (float)(int32_t)fVar54;
                    *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar47;
                    fVar51 = (fVar49 - fVar48) + fVar51 + (fVar45 - fVar46) + (fVar50 - fVar55) + (fVar54 - fVar47);
                } while (iVar41 < (int32_t)(uVar22 - 3));
            }
            for (; iVar41 < (int32_t)uVar22; iVar41 = iVar41 + 1) {
                fVar49 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                fVar45 = (float)(int32_t)fVar49;
                *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc) = fVar45;
                fVar51 = fVar51 + (fVar49 - fVar45);
            }
            while (0.0 < fVar51) {
                iVar41 = 0;
                if (3 < (int32_t)uVar22) {
                    do {
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar23 = (int64_t)iVar41;
                        fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 - fVar45 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar50 = *(float *)(iVar25 + 0x14 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar50) {
                            fVar50 = 1.0;
                        }
                        fVar51 = (fVar51 - fVar45) - fVar50;
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar49 + fVar50;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x20 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar41 = iVar41 + 4;
                        fVar49 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x2c + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar49 + fVar45;
                    } while (iVar41 < (int32_t)(uVar22 - 3));
                }
                while (iVar41 < (int32_t)uVar22) {
                    if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 1;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                    if (1.0 <= fVar45) {
                        fVar45 = 1.0;
                    }
                    fVar51 = fVar51 - fVar45;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                }
            }
        }
code_r0x00018014a22a:
        iVar41 = iVar32 + uVar22;
        if (iVar32 < iVar41) {
            arg1 = var_128h;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar25 = (int64_t)iVar32;
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x10 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0xc + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x1c + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x18 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x28 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar25 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x24 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar25 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar24 = 0;
                        }
                        var_100h[iVar24 * 4 + -1] =
                             var_100h[iVar24 * 4 + -1] - (*(float *)(iVar25 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar25 + 0x1c + iVar23) = fVar49;
                    }
                    iVar32 = iVar32 + 4;
                } while (iVar32 < iVar41 + -3);
                if (iVar41 <= iVar32) goto code_r0x00018014a4d3;
            }
            do {
                fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + (int64_t)iVar32 * 0xc);
                if (0.0 <= fVar51) {
                    iVar25 = *piVar42;
                    fVar49 = 1.0;
                    if (1.0 <= fVar51) {
                        fVar49 = fVar51;
                    }
                    iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc) * 0x38;
                    uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                    if ((uVar22 & 0x40) == 0) {
                        iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                    } else {
                        iVar24 = 0;
                    }
                    var_100h[iVar24 * 4 + -1] =
                         var_100h[iVar24 * 4 + -1] - (*(float *)(iVar23 + 0x1c + iVar25) - fVar49);
                    *(float *)(iVar23 + 0x1c + iVar25) = fVar49;
                }
                iVar32 = iVar32 + 1;
                puVar34 = (undefined8 *)var_118h;
                pfVar43 = (float *)var_110h;
            } while (iVar32 < iVar41);
        } else {
code_r0x00018014a4d3:
            puVar34 = (undefined8 *)(arg1 + 0x38);
            pfVar43 = (float *)(arg1 + 0x40);
        }
    }
code_r0x00018014a4db:
    uVar35 = 0;
    auVar53 = ZEXT816(0);
    *(undefined4 *)(arg1 + 0x54) = 0;
    uVar22 = uVar35;
    if (0 < (int32_t)var_108h) {
        do {
            iVar25 = *piVar42;
            iVar23 = (int64_t)(int32_t)uVar22 * 0x38;
            *(float *)(iVar23 + 0x18 + iVar25) = auVar53._0_4_;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_108h + -1) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            auVar53._0_4_ = auVar53._0_4_ + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_108h);
    }
    fVar49 = auVar53._0_4_ + var_100h[1];
    fVar51 = var_100h[1] + var_108h._4_4_;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    uVar22 = uVar35;
    if (0 < (int32_t)(uint32_t)var_f8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar49;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)((uint32_t)var_f8h + -1)) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar49 = fVar49 + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)(uint32_t)var_f8h);
    }
    fVar51 = var_f8h._4_4_ + var_ech;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    fVar45 = (*(float *)(arg1 + 0x40) - *(float *)puVar34) - var_e8h._4_4_;
    fVar51 = 0.0;
    if (0.0 <= fVar45) {
        fVar51 = fVar45;
    }
    if (var_ech + fVar49 <= fVar51) {
        fVar51 = var_ech + fVar49;
    }
    uVar22 = uVar35;
    if (0 < (int32_t)var_e8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h + (uint32_t)var_f8h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar51;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_e8h + -1) {
                fVar49 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar49 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar51 = fVar51 + fVar49 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_e8h);
    }
    fVar51 = var_e8h._4_4_ + var_dch;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    func_0x00018011f640(arg1 + 0xa0, 0);
    if ((!bVar44) && (*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1)) {
        *(undefined4 *)(arg1 + 0x20) = 0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x20);
    if (((*(uint32_t *)(arg1 + 0x20) == 0) && (uVar22 = uVar35, *(int32_t *)(arg1 + 0x24) == 0)) && (var_130h != 0)) {
        uVar28 = *(uint32_t *)var_130h;
        *(uint32_t *)(arg1 + 0x20) = uVar28;
        uVar22 = uVar28;
    }
    *(uint32_t *)(arg1 + 0x2c) = uVar22;
    *(undefined *)(arg1 + 0x84) = 0;
    iVar25 = *(int64_t *)(iVar38 + 0x23c0);
    if (((iVar25 != 0) && (*(int64_t *)(iVar25 + 0x4c0) != 0)) &&
       (*(int64_t *)(*(int64_t *)(iVar25 + 0x4c0) + 0x40) == arg1)) {
        uVar28 = *(uint32_t *)(iVar25 + 200);
        *(uint32_t *)(arg1 + 0x2c) = uVar28;
    }
    if (uVar28 != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (0 < iVar32) {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar35 * 0x38;
                if (*(uint32_t *)(uVar26 + iVar25) == uVar28) {
                    if ((*(uint8_t *)(uVar26 + 4 + iVar25) & 0xc0) != 0) break;
                    fVar51 = *pfVar43;
                    fVar49 = *(float *)puVar34;
                    fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
                    iVar41 = (int32_t)(uVar26 / 0x38);
                    if ((int32_t)var_108h + -1 < iVar41) {
                        fVar50 = (float)((uint32_t)fVar45 ^ 0x80000000);
                    } else {
                        fVar50 = 0.0;
                    }
                    fVar54 = *(float *)(uVar26 + 0x18 + iVar25) - var_108h._4_4_;
                    fVar50 = fVar54 + fVar50;
                    if (iVar32 - (int32_t)var_e8h <= iVar41 + 1) {
                        fVar45 = 1.0;
                    }
                    fVar55 = *(float *)(uVar26 + 0x1c + iVar25);
                    *(undefined4 *)(arg1 + 100) = 0;
                    fVar45 = fVar54 + fVar55 + fVar45;
                    if (*(float *)(arg1 + 0x60) <= fVar50) {
                        fVar51 = (((fVar51 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech;
                        if (fVar45 - fVar50 < fVar51) {
                            if (*(float *)(arg1 + 0x60) < fVar45 - fVar51) {
                                *(float *)(arg1 + 0x60) = fVar45 - fVar51;
                                fVar51 = (fVar50 - fVar51) - *(float *)(arg1 + 0x5c);
                                if (fVar51 <= 0.0) {
                                    fVar51 = 0.0;
                                }
                                *(float *)(arg1 + 100) = fVar51;
                            }
                            break;
                        }
                    }
                    fVar45 = *(float *)(arg1 + 0x5c) - fVar45;
                    *(float *)(arg1 + 0x60) = fVar50;
                    if (fVar45 <= 0.0) {
                        fVar45 = 0.0;
                    }
                    *(float *)(arg1 + 100) = fVar45;
                    break;
                }
                uVar35 = uVar35 + 1;
            } while ((int32_t)uVar35 < iVar32);
        }
        goto code_r0x00018014a9b6;
    }
    if ((*pcVar40 == '\0') || (cVar15 = func_0x000180108120(puVar34, pfVar43, 1), cVar15 == '\0'))
    goto code_r0x00018014a9b6;
    iVar25 = *(int64_t *)(iVar38 + 0x15e0);
    if (((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) != 0) &&
        ((((iVar23 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) + 0x428), iVar23 != 0 &&
           (*(char *)(iVar23 + 0x10a) != '\0')) && (iVar23 != *(int64_t *)(iVar25 + 0x428))) &&
         (((*(uint32_t *)(iVar23 + 0x14) >> 0x1b & 1) != 0 || ((*(uint32_t *)(iVar23 + 0x14) >> 0x1a & 1) != 0)))))) &&
       (iVar24 = *(int64_t *)(iVar25 + 0x418), *(int64_t *)(iVar24 + 0x418) != iVar23)) {
        do {
            if (iVar24 == iVar23) goto code_r0x00018014a8ae;
            iVar24 = *(int64_t *)(iVar24 + 0x410);
        } while (iVar24 != 0);
        goto code_r0x00018014a9b6;
    }
code_r0x00018014a8ae:
    if ((*(int64_t *)(iVar25 + 0x48) != *(int64_t *)(*(int64_t *)0x180781f28 + 0x2168)) &&
       ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) == 0 ||
        (*(int64_t *)(iVar25 + 0x428) != *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) + 0x428)))))
    goto code_r0x00018014a9b6;
    pfVar31 = (float *)(iVar38 + 0x128);
    if (*(char *)(iVar38 + 0xbaa) == '\0') {
        pfVar31 = (float *)(iVar38 + 300);
    }
    iVar32 = *(int32_t *)(arg1 + 0x1c);
    uVar26 = (uint64_t)((*(char *)(iVar38 + 0xbaa) != '\0') + 0x295);
    iVar25 = *(int64_t *)0x180781f28;
    piVar20 = (int32_t *)func_0x0001800f45c0(*(int64_t *)0x180781f28, uVar26);
    if (iVar32 == 0) {
        bVar44 = *(char *)(piVar20 + 2) == '\0';
code_r0x00018014a936:
        if (bVar44) {
code_r0x00018014a938:
            fVar51 = *pfVar31;
            if (fVar51 != 0.0) {
                fVar49 = *(float *)puVar34;
                fVar45 = *pfVar43;
                *(undefined4 *)(arg1 + 100) = 0;
                fVar51 = *(float *)(arg1 + 0x60) -
                         (((((fVar45 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech) * fVar51) / 3.0;
                fVar49 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar49);
                if (fVar49 <= fVar51) {
                    fVar51 = fVar49;
                }
                if (fVar51 <= 0.0) {
                    fVar51 = 0.0;
                }
                *(float *)(arg1 + 0x60) = fVar51;
            }
        }
    } else {
        if (*piVar20 == iVar32) goto code_r0x00018014a938;
        if (*(char *)(piVar20 + 2) == '\0') {
            bVar44 = *piVar20 == -1;
            goto code_r0x00018014a936;
        }
    }
    *(int32_t *)(iVar25 + -0x130 + uVar26 * 0xc) = iVar32;
    *(int32_t *)(iVar25 + -0x134 + uVar26 * 0xc) = iVar32;
    *(undefined2 *)(iVar25 + -300 + uVar26 * 0xc) = 0;
code_r0x00018014a9b6:
    fVar51 = *(float *)puVar34;
    fVar45 = *(float *)(arg1 + 0x54) - (*pfVar43 - fVar51);
    fVar49 = *(float *)(arg1 + 0x5c);
    if (fVar45 <= *(float *)(arg1 + 0x5c)) {
        fVar49 = fVar45;
    }
    if (fVar49 <= 0.0) {
        fVar49 = 0.0;
    }
    *(float *)(arg1 + 0x5c) = fVar49;
    fVar50 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar51);
    fVar45 = *(float *)(arg1 + 0x60);
    if (fVar50 <= *(float *)(arg1 + 0x60)) {
        fVar45 = fVar50;
    }
    if (fVar45 <= 0.0) {
        fVar45 = 0.0;
    }
    *(float *)(arg1 + 0x60) = fVar45;
    if (fVar49 == fVar45) {
        *(undefined4 *)(arg1 + 0x68) = 0;
    } else {
        fVar54 = *(float *)(iVar38 + 0x12f8) * 70.0;
        fVar50 = *(float *)(arg1 + 0x68);
        if (*(float *)(arg1 + 0x68) <= fVar54) {
            fVar50 = fVar54;
        }
        fVar54 = (float)((uint32_t)(fVar45 - fVar49) & 0x7fffffff) / 0.3;
        if (fVar50 <= fVar54) {
            fVar50 = fVar54;
        }
        *(float *)(arg1 + 0x68) = fVar50;
        fVar54 = fVar45;
        if ((*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1) &&
           (*(float *)(arg1 + 100) <= *(float *)(iVar38 + 0x12f8) * 10.0)) {
            fVar50 = fVar50 * *(float *)(iVar38 + 0x48);
            if (fVar45 <= fVar49) {
                fVar54 = fVar49;
                if ((fVar45 < fVar49) && (fVar54 = fVar49 - fVar50, fVar54 <= fVar45)) {
                    fVar54 = fVar45;
                }
            } else {
                fVar54 = fVar50 + fVar49;
                if (fVar45 <= fVar54) {
                    fVar54 = fVar45;
                }
            }
        }
        *(float *)(arg1 + 0x5c) = fVar54;
    }
    uVar18 = *puVar34;
    *(float *)(arg1 + 0x6c) = fVar51 + var_108h._4_4_ + var_100h[1];
    *(float *)(arg1 + 0x70) = (*(float *)(arg1 + 0x40) - var_e8h._4_4_) - var_ech;
    iVar38 = *(int64_t *)(iVar38 + 0x15e0);
    *(undefined8 *)(iVar38 + 0x158) = uVar18;
    var_128h = CONCAT44(*(float *)(arg1 + 0x44) - *(float *)(arg1 + 0x3c), *(undefined4 *)(arg1 + 0x54));
    func_0x00018010bbf0(&var_128h);
    fVar49 = *(float *)(arg1 + 0x58) + *(float *)puVar34;
    fVar51 = *(float *)(iVar38 + 0x178);
    if (*(float *)(iVar38 + 0x178) <= fVar49) {
        fVar51 = fVar49;
    }
    *(float *)(iVar38 + 0x178) = fVar51;
    func_0x000180459870(var_d8h ^ (uint64_t)auStackY_198);
    return;
code_r0x000180149c5c:
    uVar22 = (int32_t)uVar26 + 1;
    uVar26 = (uint64_t)uVar22;
    if (iVar39 <= (int32_t)uVar22) goto code_r0x000180149c63;
    goto code_r0x000180149c50;
}

// ============================================================
// Function: FUN_180149ace
// Address: 0x180149ace
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_144h
// WARNING: Variable defined which should be unmapped: var_178h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180148fa0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined auVar3 [16];
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    bool bVar13;
    bool bVar14;
    char cVar15;
    uint8_t uVar16;
    int32_t iVar17;
    undefined8 uVar18;
    int64_t iVar19;
    int32_t *piVar20;
    uint32_t uVar21;
    uint32_t uVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    uint64_t uVar26;
    undefined4 *puVar27;
    uint32_t uVar28;
    undefined4 *puVar29;
    uint32_t *puVar30;
    float *pfVar31;
    int32_t iVar32;
    uint32_t *puVar33;
    undefined8 *puVar34;
    uint32_t uVar35;
    int32_t iVar36;
    undefined4 *puVar37;
    int64_t iVar38;
    int32_t iVar39;
    char *pcVar40;
    int32_t iVar41;
    int64_t *piVar42;
    float *pfVar43;
    bool bVar44;
    float fVar45;
    float fVar46;
    float fVar47;
    float fVar48;
    float fVar49;
    float fVar50;
    float fVar51;
    undefined auVar52 [16];
    undefined auVar53 [16];
    float fVar54;
    undefined4 unaff_XMM12_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    float fVar55;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_198 [32];
    int64_t var_178h;
    undefined4 in_stack_fffffffffffffe98;
    undefined4 in_stack_fffffffffffffe9c;
    undefined4 uVar56;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int32_t var_148h;
    int64_t var_144h;
    undefined4 uStack_13c;
    undefined4 uVar57;
    undefined4 in_stack_fffffffffffffecc;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    float var_100h [2];
    int64_t var_f8h;
    float var_f0h;
    float var_ech;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar38 = *(int64_t *)0x180781f28;
    var_d8h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_198;
    fVar51 = *(float *)(arg1 + 0x48);
    var_118h = arg1 + 0x38;
    *(undefined *)(arg1 + 0x83) = 0;
    fVar49 = *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38);
    var_110h = arg1 + 0x40;
    uVar22 = *(uint32_t *)(arg1 + 8);
    *(float *)(arg1 + 0x48) = fVar49;
    uVar56 = CONCAT31((unkint3)((uint32_t)in_stack_fffffffffffffe9c >> 8), fVar49 < fVar51);
    auVar3._4_4_ = unaff_XMM12_Dc;
    auVar3._0_4_ = unaff_XMM12_Db;
    auVar3._8_4_ = unaff_XMM12_Dd;
    auVar3._12_4_ = 0;
    _var_98h = auVar3 << 0x20;
    bVar44 = false;
    uVar28 = 0;
    uVar35 = 0;
    _var_108h = ZEXT816(0);
    _var_f8h = ZEXT816(0);
    _var_e8h = ZEXT816(0);
    bVar13 = false;
    if (0 < (int32_t)uVar22) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)(arg1 + 0x10);
            iVar23 = (int64_t)(int32_t)uVar35 * 0x38;
            if ((*(int32_t *)(iVar23 + 0x10 + iVar25) < *(int32_t *)(arg1 + 0x34)) ||
               (*(char *)(iVar23 + 0x30 + iVar25) != '\0')) {
                if (*(int32_t *)(arg1 + 0x2c) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x2c) = 0;
                }
                if (*(int32_t *)(arg1 + 0x20) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x20) = 0;
                }
                if (*(int32_t *)(arg1 + 0x24) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x24) = 0;
                }
            } else {
                if (uVar28 != uVar35) {
                    auVar3 = *(undefined (*) [16])(iVar23 + 0x10 + iVar25);
                    puVar37 = (undefined4 *)(iVar23 + 0x20 + iVar25);
                    uVar57 = *puVar37;
                    uVar1 = puVar37[1];
                    uVar2 = puVar37[2];
                    uVar4 = puVar37[3];
                    uVar18 = *(undefined8 *)(iVar23 + 0x30 + iVar25);
                    iVar24 = (int64_t)(int32_t)uVar28 * 0x38;
                    *(undefined (*) [16])(iVar24 + iVar25) = *(undefined (*) [16])(iVar23 + iVar25);
                    *(undefined (*) [16])(iVar24 + 0x10 + iVar25) = auVar3;
                    puVar37 = (undefined4 *)(iVar24 + 0x20 + iVar25);
                    *puVar37 = uVar57;
                    puVar37[1] = uVar1;
                    puVar37[2] = uVar2;
                    puVar37[3] = uVar4;
                    *(undefined8 *)(iVar24 + 0x30 + iVar25) = uVar18;
                }
                iVar23 = (int64_t)(int32_t)uVar28 * 0x38;
                iVar25 = *(int64_t *)(arg1 + 0x10);
                uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                *(int16_t *)(iVar23 + 0x2e + iVar25) = (int16_t)uVar28;
                if ((uVar22 & 0x40) == 0) {
                    uVar26 = (uint64_t)(((uVar22 & 0x80) != 0) + 1);
                } else {
                    uVar26 = 0;
                }
                if (0 < (int32_t)uVar28) {
                    uVar22 = *(uint32_t *)(*(int64_t *)(arg1 + 0x10) + -0x34 + iVar23);
                    cVar15 = '\0';
                    if ((uVar22 & 0x40) == 0) {
                        cVar15 = ((uVar22 & 0x80) != 0) + '\x01';
                    }
                    if ((int32_t)uVar26 == 0) {
                        if (cVar15 == '\0') goto code_r0x000180149140;
                        bVar44 = true;
                    }
                    if (cVar15 == '\x02') {
                        if ((int32_t)uVar26 != 2) {
                            bVar44 = true;
                        }
                        var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                        uVar28 = uVar28 + 1;
                        goto code_r0x000180149172;
                    }
                }
code_r0x000180149140:
                var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                uVar28 = uVar28 + 1;
            }
code_r0x000180149172:
            uVar22 = *(uint32_t *)(arg1 + 8);
            uVar35 = uVar35 + 1;
            bVar13 = bVar44;
        } while ((int32_t)uVar35 < (int32_t)uVar22);
    }
    uVar35 = 8;
    var_128h = arg1;
    if (uVar22 != uVar28) {
        iVar32 = *(int32_t *)(arg1 + 0xc);
        if (iVar32 < (int32_t)uVar28) {
            uVar22 = uVar35;
            if (iVar32 != 0) {
                uVar22 = iVar32 / 2 + iVar32;
            }
            uVar21 = uVar28;
            if ((int32_t)uVar28 < (int32_t)uVar22) {
                uVar21 = uVar22;
            }
            func_0x00018011f970(arg1 + 8, uVar21);
        }
        *(uint32_t *)(arg1 + 8) = uVar28;
        uVar22 = uVar28;
    }
    piVar42 = (int64_t *)(arg1 + 0x10);
    if ((bVar44) && (1 < uVar22)) {
        fcn.18046f0d0(CONCAT44(uVar56, in_stack_fffffffffffffe98));
    }
    fVar51 = *(float *)(iVar38 + 0xdf4);
    if (((int32_t)var_108h < 1) || (var_100h[1] = fVar51, (int32_t)((int32_t)var_e8h + (uint32_t)var_f8h) < 1)) {
        var_100h[1] = 0.0;
    }
    if (((int32_t)(uint32_t)var_f8h < 1) || (var_ech = fVar51, (int32_t)var_e8h < 1)) {
        var_ech = 0.0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x28);
    uVar21 = 0;
    uVar28 = 0;
    if (uVar22 != 0) {
        *(undefined4 *)(arg1 + 0x28) = 0;
        uVar28 = uVar22;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x24);
    if (uVar22 != 0) {
        *(uint32_t *)(arg1 + 0x20) = uVar22;
        *(undefined4 *)(arg1 + 0x24) = 0;
        uVar28 = uVar22;
    }
    if (*(int32_t *)(arg1 + 0x7c) != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (iVar32 < 1) {
code_r0x00018014939d:
            *(undefined4 *)(arg1 + 0x7c) = 0;
        } else {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar21 * 0x38;
                puVar37 = (undefined4 *)(uVar26 + iVar25);
                if (*(int32_t *)(uVar26 + iVar25) == *(int32_t *)(arg1 + 0x7c)) {
                    if ((puVar37[1] & 0x20) == 0) {
                        iVar41 = (int32_t)(uVar26 / 0x38) + (int32_t)*(int16_t *)(arg1 + 0x80);
                        if ((-1 < iVar41) && (iVar41 < iVar32)) {
                            puVar29 = (undefined4 *)((int64_t)iVar41 * 0x38 + iVar25);
                            if (((puVar29[1] & 0x20) == 0) && (((puVar29[1] ^ puVar37[1]) & 0xc0) == 0)) {
                                uVar18 = *(undefined8 *)(puVar37 + 0xc);
                                uVar57 = *puVar37;
                                uVar1 = puVar37[1];
                                uVar2 = puVar37[2];
                                uVar4 = puVar37[3];
                                uVar5 = puVar37[4];
                                uVar6 = puVar37[5];
                                uVar7 = puVar37[6];
                                uVar8 = puVar37[7];
                                uVar9 = puVar37[8];
                                uVar10 = puVar37[9];
                                uVar11 = puVar37[10];
                                uVar12 = puVar37[0xb];
                                if (*(int16_t *)(arg1 + 0x80) < 1) {
                                    puVar37 = puVar29 + 0xe;
                                    puVar27 = puVar29;
                                } else {
                                    puVar27 = puVar37 + 0xe;
                                }
                                fcn.180498030(puVar37, puVar27);
                                *puVar29 = uVar57;
                                puVar29[1] = uVar1;
                                puVar29[2] = uVar2;
                                puVar29[3] = uVar4;
                                puVar29[4] = uVar5;
                                puVar29[5] = uVar6;
                                puVar29[6] = uVar7;
                                puVar29[7] = uVar8;
                                puVar29[8] = uVar9;
                                puVar29[9] = uVar10;
                                puVar29[10] = uVar11;
                                puVar29[0xb] = uVar12;
                                *(undefined8 *)(puVar29 + 0xc) = uVar18;
                                if (((*(uint32_t *)(arg1 + 0x18) & 0x400000) != 0) &&
                                   (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)) {
                                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) =
                                         *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
                                }
                                if (*(uint32_t *)(arg1 + 0x7c) == *(uint32_t *)(arg1 + 0x20)) {
                                    uVar28 = *(uint32_t *)(arg1 + 0x7c);
                                }
                            }
                        }
                    }
                    goto code_r0x00018014939d;
                }
                uVar21 = uVar21 + 1;
            } while ((int32_t)uVar21 < iVar32);
            *(undefined4 *)(arg1 + 0x7c) = 0;
        }
    }
    iVar25 = *(int64_t *)0x180781f28;
    puVar33 = (uint32_t *)0x0;
    if ((*(uint8_t *)(arg1 + 0x18) & 4) != 0) {
        uVar57 = *(undefined4 *)(arg1 + 0x3c);
        var_148h = 0;
        fVar49 = *(float *)(*(int64_t *)0x180781f28 + 0xde0);
        iVar23 = *(int64_t *)0x180781f28 + 0x20c0;
        iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
        uVar1 = *(undefined4 *)(iVar24 + 0x158);
        uVar2 = *(undefined4 *)(iVar24 + 0x15c);
        *(float *)(iVar24 + 0x158) = *(float *)(arg1 + 0x38) - fVar49;
        *(undefined4 *)(iVar24 + 0x15c) = uVar57;
        *(float *)(arg1 + 0x38) = fVar49 + fVar45 + *(float *)(arg1 + 0x38);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        uVar57 = *(undefined4 *)(iVar25 + 0xed8);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        fVar49 = *(float *)(iVar25 + 0xedc);
        fcn.18011f2b0(iVar23, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar57;
            *(float *)(iVar25 + 0xedc) = fVar49 * 0.5;
        }
        iVar25 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        uVar57 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x102c);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar25 + 0x1020) = 0;
            *(undefined8 *)(iVar25 + 0x1028) = 0;
        }
        cVar15 = func_0x00018013d0a0();
        fcn.1800f6770(2);
        if (cVar15 != '\0') {
            iVar32 = 0;
            if (0 < *(int32_t *)(arg1 + 8)) {
                do {
                    puVar30 = (uint32_t *)((int64_t)iVar32 * 0x38 + *piVar42);
                    if (((puVar30[1] & 0x200000) == 0) &&
                       (cVar15 = fcn.180146c70(CONCAT44(uStack_13c, var_144h._4_4_), 
                                               CONCAT44(in_stack_fffffffffffffecc, uVar57)), cVar15 != '\0')) {
                        puVar33 = puVar30;
                    }
                    iVar32 = iVar32 + 1;
                } while (iVar32 < *(int32_t *)(arg1 + 8));
            }
            iVar25 = *(int64_t *)0x180781f28;
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) + -1;
            iVar32 = func_0x000180498f10(*(undefined8 *)(*(int64_t *)(iVar25 + 0x15e0) + 8), &var_148h);
            if (iVar32 == 0) {
                func_0x00018010d5c0();
            } else if (*(code **)(iVar25 + 0x2a40) != (code *)0x0) {
                (**(code **)(iVar25 + 0x2a40))(iVar25, *(undefined8 *)(iVar25 + 0x2a48));
            }
        }
        *(undefined4 *)(iVar24 + 0x158) = uVar1;
        *(undefined4 *)(iVar24 + 0x15c) = uVar2;
        if (puVar33 != (uint32_t *)0x0) {
            uVar28 = *puVar33;
            *(uint32_t *)(arg1 + 0x20) = uVar28;
        }
    }
    iVar41 = 1;
    uVar22 = *(uint32_t *)(arg1 + 8);
    var_144h._0_4_ = (int32_t)var_e8h + (int32_t)var_108h;
    var_148h = 0;
    iVar32 = *(int32_t *)(iVar38 + 0x257c);
    var_144h._4_4_ = (int32_t)var_108h;
    if (iVar32 < (int32_t)uVar22) {
        if (iVar32 != 0) {
            uVar35 = iVar32 / 2 + iVar32;
        }
        uVar21 = uVar22;
        if ((int32_t)uVar22 < (int32_t)uVar35) {
            uVar21 = uVar35;
        }
        if (iVar32 < (int32_t)uVar21) {
            uVar18 = fcn.18046d050((int64_t)(int32_t)uVar21 * 0xc);
            if (*(int64_t *)(iVar38 + 0x2580) != 0) {
                fcn.180498030(uVar18);
                fcn.180460d90(*(undefined8 *)(iVar38 + 0x2580));
            }
            *(undefined8 *)(iVar38 + 0x2580) = uVar18;
            *(uint32_t *)(iVar38 + 0x257c) = uVar21;
        }
    }
    *(uint32_t *)(iVar38 + 0x2578) = uVar22;
    if ((*(uint8_t *)(arg1 + 0x18) & 0x80) == 0) {
        fVar49 = 1.0;
    } else {
        fVar49 = *(float *)(iVar38 + 0xe40);
    }
    iVar32 = *(int32_t *)(arg1 + 8);
    iVar39 = 0;
    var_130h = 0;
    bVar44 = false;
    uVar22 = 0xffffffff;
    bVar13 = false;
    if (0 < iVar32) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)0x180781f28;
            puVar33 = (uint32_t *)((int64_t)iVar39 * 0x38 + *piVar42);
            if (((var_130h == 0) || (*(int32_t *)(var_130h + 0x14) < (int32_t)puVar33[5])) &&
               ((puVar33[1] & 0x200000) == 0)) {
                var_130h = (int64_t)puVar33;
            }
            uVar35 = *puVar33;
            if (uVar35 == *(uint32_t *)(arg1 + 0x20)) {
                bVar44 = true;
            }
            if ((uVar28 == 0) && (*(uint32_t *)(iVar38 + 0x23a4) == uVar35)) {
                uVar28 = uVar35;
            }
            auVar52 = ZEXT416(puVar33[9]);
            if ((float)puVar33[9] < 0.0) {
                uVar35 = puVar33[1];
                var_178h._0_4_ = 0xbf800000;
                fcn.1800fe0a0(CONCAT44(var_178h._4_4_, 0xbf800000), SUB168(_var_98h, 8));
                fVar45 = *(float *)(iVar25 + 0xddc);
                if ((uVar35 & 0x100001) == 0x100000) {
                    fVar50 = fVar45 + 1.0;
                } else {
                    fVar50 = *(float *)(iVar25 + 0x12f8) + *(float *)(iVar25 + 0xdf4) + fVar45;
                }
                fVar50 = fVar50 + var_120h + fVar45;
                auVar52 = ZEXT416((uint32_t)fVar50);
                fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 20.0;
                if (fVar45 <= fVar50) {
                    auVar52 = ZEXT416((uint32_t)fVar45);
                }
            }
            uVar35 = puVar33[1];
            puVar33[8] = (uint32_t)auVar52._0_4_;
            if ((uVar35 >> 0x15 & 1) == 0) {
                if (auVar52._0_4_ <= *(float *)(iVar38 + 0xe3c)) {
                    auVar52._0_4_ = *(float *)(iVar38 + 0xe3c);
                }
                puVar33[8] = auVar52._0_4_;
            }
            if ((uVar35 & 0x40) == 0) {
                uVar35 = ((uVar35 & 0x80) != 0) + 1;
            } else {
                uVar35 = 0;
            }
            uVar26 = (uint64_t)uVar35;
            if (uVar35 == uVar22) {
                fVar50 = auVar52._0_4_ + fVar51;
                fVar45 = fVar51;
            } else {
                fVar50 = auVar52._0_4_ + 0.0;
                fVar45 = 0.0;
            }
            var_100h[uVar26 * 4 + -1] = fVar50 + var_100h[uVar26 * 4 + -1];
            fVar50 = (float)puVar33[8];
            if (fVar49 <= (float)puVar33[8]) {
                fVar50 = fVar49;
            }
            var_100h[uVar26 * 4] = fVar50 + fVar45 + var_100h[uVar26 * 4];
            iVar23 = (int64_t)(&var_148h)[uVar26];
            (&var_148h)[uVar26] = (&var_148h)[uVar26] + 1;
            iVar25 = *(int64_t *)(iVar38 + 0x2580);
            *(int32_t *)(iVar25 + iVar23 * 0xc) = iVar39;
            iVar39 = iVar39 + 1;
            uVar22 = puVar33[8];
            *(uint32_t *)(iVar25 + 8 + iVar23 * 0xc) = uVar22;
            *(uint32_t *)(iVar25 + 4 + iVar23 * 0xc) = uVar22;
            fVar45 = (float)puVar33[8];
            if (fVar45 <= 1.0) {
                fVar45 = 1.0;
            }
            puVar33[7] = (uint32_t)fVar45;
            iVar32 = *(int32_t *)(arg1 + 8);
            uVar22 = uVar35;
            bVar13 = bVar44;
        } while (iVar39 < iVar32);
    }
    uVar22 = *(uint32_t *)(arg1 + 0x18);
    *(float *)(arg1 + 0x58) = var_100h[1] + var_108h._4_4_ + 0.0 + var_f8h._4_4_ + var_ech + var_e8h._4_4_ + var_dch;
    iVar25 = *(int64_t *)0x180781f28;
    if (((uVar22 & 0x200) == 0) && (-1 < (char)uVar22)) {
        bVar14 = false;
code_r0x00018014992e:
        bVar13 = bVar14;
        fVar51 = var_e0h + var_dch + var_100h[0] + var_100h[1] + 0.0 + var_f0h + var_ech;
    } else {
        bVar13 = true;
        bVar14 = true;
        if ((uVar22 & 0x200) == 0) goto code_r0x00018014992e;
        fVar51 = *(float *)(arg1 + 0x54);
    }
    if ((((fVar51 <= *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38)) || (iVar32 < 2)) || ((uVar22 & 0x10) != 0)) ||
       (!bVar13)) {
        *(undefined *)(arg1 + 0x86) = 0;
    } else {
        *(undefined *)(arg1 + 0x86) = 1;
        var_148h = 0;
        fVar51 = *(float *)(iVar25 + 0x12f8);
        iVar23 = *(int64_t *)(iVar25 + 0x15e0);
        fVar54 = fVar51 - 2.0;
        fVar45 = *(float *)(iVar25 + 0xde0);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        uVar57 = *(undefined4 *)(iVar23 + 0x158);
        uVar1 = *(undefined4 *)(iVar25 + 0xed8);
        fVar50 = *(float *)(iVar25 + 0xedc);
        fVar55 = fVar54 + fVar54;
        var_120h = *(float *)(iVar23 + 0x15c);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        fcn.18011f2b0(iVar25 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar1;
            *(float *)(iVar25 + 0xedc) = fVar50 * 0.5;
        }
        iVar24 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar24 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar24 + 0x1020) = 0;
            *(undefined8 *)(iVar24 + 0x1028) = 0;
        }
        iVar24 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 10;
        piVar20 = (int32_t *)(iVar24 + 0x2100);
        iVar32 = *(int32_t *)(iVar24 + 0x2104);
        uVar1 = *(undefined4 *)(iVar24 + 0x1f78);
        if (*piVar20 == iVar32) {
            iVar39 = *piVar20 + 1;
            if (iVar32 == 0) {
                iVar32 = 8;
            } else {
                iVar32 = iVar32 / 2 + iVar32;
            }
            if (iVar39 < iVar32) {
                iVar39 = iVar32;
            }
            fcn.18011fb10(piVar20, iVar39);
        }
        *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + (int64_t)*piVar20 * 4) = uVar1;
        *piVar20 = *piVar20 + 1;
        uVar1 = *(undefined4 *)(iVar25 + 0xa8);
        uVar2 = *(undefined4 *)(iVar25 + 0xac);
        *(undefined4 *)(iVar25 + 0xa8) = 0x3e800000;
        *(undefined4 *)(iVar25 + 0xac) = 0x3e4ccccd;
        fVar46 = *(float *)(arg1 + 0x40) - fVar55;
        fVar50 = *(float *)(arg1 + 0x38);
        if (*(float *)(arg1 + 0x38) <= fVar46) {
            fVar50 = fVar46;
        }
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50;
        uVar16 = func_0x00018013a9f0(0x180645ba0, 0, CONCAT44(fVar45 + fVar45 + fVar51, fVar54));
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50 + fVar54;
        cVar15 = func_0x00018013a9f0(0x180645ba4, 1);
        iVar24 = *(int64_t *)0x180781f28;
        if (cVar15 == '\0') {
            iVar32 = (uVar16 ^ 1) - 1;
        } else {
            iVar32 = 1;
        }
        iVar39 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
        if (iVar39 < 2) {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48));
            }
        } else {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar39 + -1;
            *(undefined4 *)(iVar24 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + -8 + (int64_t)iVar39 * 4)
            ;
        }
        fcn.1800f6770();
        *(undefined4 *)(iVar25 + 0xac) = uVar2;
        *(undefined4 *)(iVar25 + 0xa8) = uVar1;
        if (iVar32 == 0) {
            puVar33 = (uint32_t *)0x0;
code_r0x000180149cf6:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
            if ((puVar33 != (uint32_t *)0x0) && (uVar28 = *puVar33, (puVar33[1] & 0x200000) == 0)) {
                *(uint32_t *)(arg1 + 0x20) = uVar28;
            }
        } else {
            if ((*(int32_t *)(arg1 + 0x20) != 0) && (iVar39 = *(int32_t *)(arg1 + 8), 0 < iVar39)) {
                uVar26 = 0;
                iVar25 = *piVar42;
code_r0x000180149c50:
                if (*(int32_t *)(uVar26 * 0x38 + iVar25) != *(int32_t *)(arg1 + 0x20)) goto code_r0x000180149c5c;
                uVar26 = (uVar26 * 0x38) / 0x38;
                iVar36 = (int32_t)uVar26 + iVar32;
                do {
                    if ((iVar36 < 0) || (iVar17 = iVar36, iVar39 <= iVar36)) {
                        iVar17 = (int32_t)uVar26;
                    }
                    puVar33 = (uint32_t *)((int64_t)iVar17 * 0x38 + iVar25);
                } while ((((*(uint32_t *)(iVar25 + 4 + (int64_t)iVar17 * 0x38) & 0x200000) != 0) &&
                         (iVar36 = iVar36 + iVar32, -1 < iVar36)) &&
                        (uVar26 = (uint64_t)(uint32_t)((int32_t)uVar26 + iVar32), iVar36 < iVar39));
                goto code_r0x000180149cf6;
            }
code_r0x000180149c63:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
        }
    }
    pfVar43 = (float *)(arg1 + 0x40);
    pcVar40 = (char *)(arg1 + 0x86);
    puVar34 = (undefined8 *)(arg1 + 0x38);
    if ((uVar28 == 0) && ((char)uVar56 != '\0')) {
        uVar28 = *(uint32_t *)(arg1 + 0x20);
    }
    fVar51 = *pfVar43 - *(float *)puVar34;
    fVar45 = var_e8h._4_4_ + var_dch + var_108h._4_4_ + var_100h[1];
    if (fVar51 <= fVar45) {
        fVar50 = fVar45 - fVar51;
    } else {
        fVar50 = (var_f8h._4_4_ + var_ech) - ((fVar51 - (var_108h._4_4_ + var_100h[1])) - (var_e8h._4_4_ + var_dch));
        if (fVar50 <= 0.0) {
            fVar50 = 0.0;
        }
    }
    if (1.0 <= fVar50) {
        if ((*(uint32_t *)(arg1 + 0x18) & 0x180) == 0) {
            if (fVar45 < fVar51) goto code_r0x00018014a4db;
code_r0x000180149e0c:
            uVar22 = (int32_t)var_e8h + (int32_t)var_108h;
            if (fVar51 <= fVar45) {
                iVar32 = 0;
            } else {
                iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            }
        } else {
            if (fVar51 <= fVar45) goto code_r0x000180149e0c;
            iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            uVar22 = (uint32_t)var_f8h;
        }
        iVar25 = *(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc;
        if (uVar22 == 1) {
            if (0.0 <= *(float *)(iVar25 + 4)) {
                fVar50 = *(float *)(iVar25 + 4) - fVar50;
                if (fVar50 <= fVar49) {
                    fVar50 = fVar49;
                }
                *(float *)(iVar25 + 4) = fVar50;
            }
        } else {
            if (1 < uVar22) {
                fcn.18046f0d0(CONCAT44(uVar56, uVar28));
            }
            while ((0.001 < fVar50 && (iVar41 < (int32_t)uVar22))) {
                fVar51 = *(float *)(iVar25 + 4);
                do {
                    fVar45 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                    if (fVar45 < fVar51) {
                        if (0.0 <= fVar45) {
                            fVar45 = fVar51 - fVar45;
                            goto code_r0x000180149ee6;
                        }
                        break;
                    }
                    iVar41 = iVar41 + 1;
                } while (iVar41 < (int32_t)uVar22);
                fVar45 = fVar51 - 1.0;
code_r0x000180149ee6:
                fVar54 = fVar51 - fVar49;
                if (fVar45 <= fVar51 - fVar49) {
                    fVar54 = fVar45;
                }
                if (fVar54 <= 0.0) break;
                iVar39 = 0;
                fVar51 = fVar50 / (float)iVar41;
                if (fVar54 <= fVar50 / (float)iVar41) {
                    fVar51 = fVar54;
                }
                if (3 < iVar41) {
                    do {
                        iVar23 = (int64_t)iVar39;
                        iVar39 = iVar39 + 4;
                        fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar55 = fVar45 - fVar49;
                        fVar54 = fVar51;
                        if (fVar55 <= fVar51) {
                            fVar54 = fVar55;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                        fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar46 = fVar45 - fVar49;
                        fVar55 = fVar51;
                        if (fVar46 <= fVar51) {
                            fVar55 = fVar46;
                        }
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar45 - fVar55;
                        fVar45 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar47 = fVar45 - fVar49;
                        fVar46 = fVar51;
                        if (fVar47 <= fVar51) {
                            fVar46 = fVar47;
                        }
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar45 - fVar46;
                        fVar45 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar48 = fVar45 - fVar49;
                        fVar47 = fVar51;
                        if (fVar48 <= fVar51) {
                            fVar47 = fVar48;
                        }
                        fVar50 = (((fVar50 - fVar54) - fVar55) - fVar46) - fVar47;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar45 - fVar47;
                    } while (iVar39 < iVar41 + -3);
                }
                while (iVar39 < iVar41) {
                    iVar23 = (int64_t)iVar39;
                    iVar39 = iVar39 + 1;
                    fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar55 = fVar45 - fVar49;
                    fVar54 = fVar51;
                    if (fVar55 <= fVar51) {
                        fVar54 = fVar55;
                    }
                    fVar50 = fVar50 - fVar54;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                }
            }
            iVar41 = 0;
            fVar51 = 0.0;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 4;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar48 = (float)(int32_t)fVar49;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar48;
                    fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                    fVar46 = (float)(int32_t)fVar45;
                    *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar46;
                    fVar50 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                    fVar55 = (float)(int32_t)fVar50;
                    *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar55;
                    fVar54 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                    fVar47 = (float)(int32_t)fVar54;
                    *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar47;
                    fVar51 = (fVar49 - fVar48) + fVar51 + (fVar45 - fVar46) + (fVar50 - fVar55) + (fVar54 - fVar47);
                } while (iVar41 < (int32_t)(uVar22 - 3));
            }
            for (; iVar41 < (int32_t)uVar22; iVar41 = iVar41 + 1) {
                fVar49 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                fVar45 = (float)(int32_t)fVar49;
                *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc) = fVar45;
                fVar51 = fVar51 + (fVar49 - fVar45);
            }
            while (0.0 < fVar51) {
                iVar41 = 0;
                if (3 < (int32_t)uVar22) {
                    do {
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar23 = (int64_t)iVar41;
                        fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 - fVar45 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar50 = *(float *)(iVar25 + 0x14 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar50) {
                            fVar50 = 1.0;
                        }
                        fVar51 = (fVar51 - fVar45) - fVar50;
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar49 + fVar50;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x20 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar41 = iVar41 + 4;
                        fVar49 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x2c + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar49 + fVar45;
                    } while (iVar41 < (int32_t)(uVar22 - 3));
                }
                while (iVar41 < (int32_t)uVar22) {
                    if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 1;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                    if (1.0 <= fVar45) {
                        fVar45 = 1.0;
                    }
                    fVar51 = fVar51 - fVar45;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                }
            }
        }
code_r0x00018014a22a:
        iVar41 = iVar32 + uVar22;
        if (iVar32 < iVar41) {
            arg1 = var_128h;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar25 = (int64_t)iVar32;
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x10 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0xc + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x1c + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x18 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x28 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar25 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x24 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar25 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar24 = 0;
                        }
                        var_100h[iVar24 * 4 + -1] =
                             var_100h[iVar24 * 4 + -1] - (*(float *)(iVar25 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar25 + 0x1c + iVar23) = fVar49;
                    }
                    iVar32 = iVar32 + 4;
                } while (iVar32 < iVar41 + -3);
                if (iVar41 <= iVar32) goto code_r0x00018014a4d3;
            }
            do {
                fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + (int64_t)iVar32 * 0xc);
                if (0.0 <= fVar51) {
                    iVar25 = *piVar42;
                    fVar49 = 1.0;
                    if (1.0 <= fVar51) {
                        fVar49 = fVar51;
                    }
                    iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc) * 0x38;
                    uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                    if ((uVar22 & 0x40) == 0) {
                        iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                    } else {
                        iVar24 = 0;
                    }
                    var_100h[iVar24 * 4 + -1] =
                         var_100h[iVar24 * 4 + -1] - (*(float *)(iVar23 + 0x1c + iVar25) - fVar49);
                    *(float *)(iVar23 + 0x1c + iVar25) = fVar49;
                }
                iVar32 = iVar32 + 1;
                puVar34 = (undefined8 *)var_118h;
                pfVar43 = (float *)var_110h;
            } while (iVar32 < iVar41);
        } else {
code_r0x00018014a4d3:
            puVar34 = (undefined8 *)(arg1 + 0x38);
            pfVar43 = (float *)(arg1 + 0x40);
        }
    }
code_r0x00018014a4db:
    uVar35 = 0;
    auVar53 = ZEXT816(0);
    *(undefined4 *)(arg1 + 0x54) = 0;
    uVar22 = uVar35;
    if (0 < (int32_t)var_108h) {
        do {
            iVar25 = *piVar42;
            iVar23 = (int64_t)(int32_t)uVar22 * 0x38;
            *(float *)(iVar23 + 0x18 + iVar25) = auVar53._0_4_;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_108h + -1) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            auVar53._0_4_ = auVar53._0_4_ + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_108h);
    }
    fVar49 = auVar53._0_4_ + var_100h[1];
    fVar51 = var_100h[1] + var_108h._4_4_;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    uVar22 = uVar35;
    if (0 < (int32_t)(uint32_t)var_f8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar49;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)((uint32_t)var_f8h + -1)) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar49 = fVar49 + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)(uint32_t)var_f8h);
    }
    fVar51 = var_f8h._4_4_ + var_ech;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    fVar45 = (*(float *)(arg1 + 0x40) - *(float *)puVar34) - var_e8h._4_4_;
    fVar51 = 0.0;
    if (0.0 <= fVar45) {
        fVar51 = fVar45;
    }
    if (var_ech + fVar49 <= fVar51) {
        fVar51 = var_ech + fVar49;
    }
    uVar22 = uVar35;
    if (0 < (int32_t)var_e8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h + (uint32_t)var_f8h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar51;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_e8h + -1) {
                fVar49 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar49 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar51 = fVar51 + fVar49 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_e8h);
    }
    fVar51 = var_e8h._4_4_ + var_dch;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    func_0x00018011f640(arg1 + 0xa0, 0);
    if ((!bVar44) && (*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1)) {
        *(undefined4 *)(arg1 + 0x20) = 0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x20);
    if (((*(uint32_t *)(arg1 + 0x20) == 0) && (uVar22 = uVar35, *(int32_t *)(arg1 + 0x24) == 0)) && (var_130h != 0)) {
        uVar28 = *(uint32_t *)var_130h;
        *(uint32_t *)(arg1 + 0x20) = uVar28;
        uVar22 = uVar28;
    }
    *(uint32_t *)(arg1 + 0x2c) = uVar22;
    *(undefined *)(arg1 + 0x84) = 0;
    iVar25 = *(int64_t *)(iVar38 + 0x23c0);
    if (((iVar25 != 0) && (*(int64_t *)(iVar25 + 0x4c0) != 0)) &&
       (*(int64_t *)(*(int64_t *)(iVar25 + 0x4c0) + 0x40) == arg1)) {
        uVar28 = *(uint32_t *)(iVar25 + 200);
        *(uint32_t *)(arg1 + 0x2c) = uVar28;
    }
    if (uVar28 != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (0 < iVar32) {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar35 * 0x38;
                if (*(uint32_t *)(uVar26 + iVar25) == uVar28) {
                    if ((*(uint8_t *)(uVar26 + 4 + iVar25) & 0xc0) != 0) break;
                    fVar51 = *pfVar43;
                    fVar49 = *(float *)puVar34;
                    fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
                    iVar41 = (int32_t)(uVar26 / 0x38);
                    if ((int32_t)var_108h + -1 < iVar41) {
                        fVar50 = (float)((uint32_t)fVar45 ^ 0x80000000);
                    } else {
                        fVar50 = 0.0;
                    }
                    fVar54 = *(float *)(uVar26 + 0x18 + iVar25) - var_108h._4_4_;
                    fVar50 = fVar54 + fVar50;
                    if (iVar32 - (int32_t)var_e8h <= iVar41 + 1) {
                        fVar45 = 1.0;
                    }
                    fVar55 = *(float *)(uVar26 + 0x1c + iVar25);
                    *(undefined4 *)(arg1 + 100) = 0;
                    fVar45 = fVar54 + fVar55 + fVar45;
                    if (*(float *)(arg1 + 0x60) <= fVar50) {
                        fVar51 = (((fVar51 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech;
                        if (fVar45 - fVar50 < fVar51) {
                            if (*(float *)(arg1 + 0x60) < fVar45 - fVar51) {
                                *(float *)(arg1 + 0x60) = fVar45 - fVar51;
                                fVar51 = (fVar50 - fVar51) - *(float *)(arg1 + 0x5c);
                                if (fVar51 <= 0.0) {
                                    fVar51 = 0.0;
                                }
                                *(float *)(arg1 + 100) = fVar51;
                            }
                            break;
                        }
                    }
                    fVar45 = *(float *)(arg1 + 0x5c) - fVar45;
                    *(float *)(arg1 + 0x60) = fVar50;
                    if (fVar45 <= 0.0) {
                        fVar45 = 0.0;
                    }
                    *(float *)(arg1 + 100) = fVar45;
                    break;
                }
                uVar35 = uVar35 + 1;
            } while ((int32_t)uVar35 < iVar32);
        }
        goto code_r0x00018014a9b6;
    }
    if ((*pcVar40 == '\0') || (cVar15 = func_0x000180108120(puVar34, pfVar43, 1), cVar15 == '\0'))
    goto code_r0x00018014a9b6;
    iVar25 = *(int64_t *)(iVar38 + 0x15e0);
    if (((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) != 0) &&
        ((((iVar23 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) + 0x428), iVar23 != 0 &&
           (*(char *)(iVar23 + 0x10a) != '\0')) && (iVar23 != *(int64_t *)(iVar25 + 0x428))) &&
         (((*(uint32_t *)(iVar23 + 0x14) >> 0x1b & 1) != 0 || ((*(uint32_t *)(iVar23 + 0x14) >> 0x1a & 1) != 0)))))) &&
       (iVar24 = *(int64_t *)(iVar25 + 0x418), *(int64_t *)(iVar24 + 0x418) != iVar23)) {
        do {
            if (iVar24 == iVar23) goto code_r0x00018014a8ae;
            iVar24 = *(int64_t *)(iVar24 + 0x410);
        } while (iVar24 != 0);
        goto code_r0x00018014a9b6;
    }
code_r0x00018014a8ae:
    if ((*(int64_t *)(iVar25 + 0x48) != *(int64_t *)(*(int64_t *)0x180781f28 + 0x2168)) &&
       ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) == 0 ||
        (*(int64_t *)(iVar25 + 0x428) != *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) + 0x428)))))
    goto code_r0x00018014a9b6;
    pfVar31 = (float *)(iVar38 + 0x128);
    if (*(char *)(iVar38 + 0xbaa) == '\0') {
        pfVar31 = (float *)(iVar38 + 300);
    }
    iVar32 = *(int32_t *)(arg1 + 0x1c);
    uVar26 = (uint64_t)((*(char *)(iVar38 + 0xbaa) != '\0') + 0x295);
    iVar25 = *(int64_t *)0x180781f28;
    piVar20 = (int32_t *)func_0x0001800f45c0(*(int64_t *)0x180781f28, uVar26);
    if (iVar32 == 0) {
        bVar44 = *(char *)(piVar20 + 2) == '\0';
code_r0x00018014a936:
        if (bVar44) {
code_r0x00018014a938:
            fVar51 = *pfVar31;
            if (fVar51 != 0.0) {
                fVar49 = *(float *)puVar34;
                fVar45 = *pfVar43;
                *(undefined4 *)(arg1 + 100) = 0;
                fVar51 = *(float *)(arg1 + 0x60) -
                         (((((fVar45 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech) * fVar51) / 3.0;
                fVar49 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar49);
                if (fVar49 <= fVar51) {
                    fVar51 = fVar49;
                }
                if (fVar51 <= 0.0) {
                    fVar51 = 0.0;
                }
                *(float *)(arg1 + 0x60) = fVar51;
            }
        }
    } else {
        if (*piVar20 == iVar32) goto code_r0x00018014a938;
        if (*(char *)(piVar20 + 2) == '\0') {
            bVar44 = *piVar20 == -1;
            goto code_r0x00018014a936;
        }
    }
    *(int32_t *)(iVar25 + -0x130 + uVar26 * 0xc) = iVar32;
    *(int32_t *)(iVar25 + -0x134 + uVar26 * 0xc) = iVar32;
    *(undefined2 *)(iVar25 + -300 + uVar26 * 0xc) = 0;
code_r0x00018014a9b6:
    fVar51 = *(float *)puVar34;
    fVar45 = *(float *)(arg1 + 0x54) - (*pfVar43 - fVar51);
    fVar49 = *(float *)(arg1 + 0x5c);
    if (fVar45 <= *(float *)(arg1 + 0x5c)) {
        fVar49 = fVar45;
    }
    if (fVar49 <= 0.0) {
        fVar49 = 0.0;
    }
    *(float *)(arg1 + 0x5c) = fVar49;
    fVar50 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar51);
    fVar45 = *(float *)(arg1 + 0x60);
    if (fVar50 <= *(float *)(arg1 + 0x60)) {
        fVar45 = fVar50;
    }
    if (fVar45 <= 0.0) {
        fVar45 = 0.0;
    }
    *(float *)(arg1 + 0x60) = fVar45;
    if (fVar49 == fVar45) {
        *(undefined4 *)(arg1 + 0x68) = 0;
    } else {
        fVar54 = *(float *)(iVar38 + 0x12f8) * 70.0;
        fVar50 = *(float *)(arg1 + 0x68);
        if (*(float *)(arg1 + 0x68) <= fVar54) {
            fVar50 = fVar54;
        }
        fVar54 = (float)((uint32_t)(fVar45 - fVar49) & 0x7fffffff) / 0.3;
        if (fVar50 <= fVar54) {
            fVar50 = fVar54;
        }
        *(float *)(arg1 + 0x68) = fVar50;
        fVar54 = fVar45;
        if ((*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1) &&
           (*(float *)(arg1 + 100) <= *(float *)(iVar38 + 0x12f8) * 10.0)) {
            fVar50 = fVar50 * *(float *)(iVar38 + 0x48);
            if (fVar45 <= fVar49) {
                fVar54 = fVar49;
                if ((fVar45 < fVar49) && (fVar54 = fVar49 - fVar50, fVar54 <= fVar45)) {
                    fVar54 = fVar45;
                }
            } else {
                fVar54 = fVar50 + fVar49;
                if (fVar45 <= fVar54) {
                    fVar54 = fVar45;
                }
            }
        }
        *(float *)(arg1 + 0x5c) = fVar54;
    }
    uVar18 = *puVar34;
    *(float *)(arg1 + 0x6c) = fVar51 + var_108h._4_4_ + var_100h[1];
    *(float *)(arg1 + 0x70) = (*(float *)(arg1 + 0x40) - var_e8h._4_4_) - var_ech;
    iVar38 = *(int64_t *)(iVar38 + 0x15e0);
    *(undefined8 *)(iVar38 + 0x158) = uVar18;
    var_128h = CONCAT44(*(float *)(arg1 + 0x44) - *(float *)(arg1 + 0x3c), *(undefined4 *)(arg1 + 0x54));
    func_0x00018010bbf0(&var_128h);
    fVar49 = *(float *)(arg1 + 0x58) + *(float *)puVar34;
    fVar51 = *(float *)(iVar38 + 0x178);
    if (*(float *)(iVar38 + 0x178) <= fVar49) {
        fVar51 = fVar49;
    }
    *(float *)(iVar38 + 0x178) = fVar51;
    func_0x000180459870(var_d8h ^ (uint64_t)auStackY_198);
    return;
code_r0x000180149c5c:
    uVar22 = (int32_t)uVar26 + 1;
    uVar26 = (uint64_t)uVar22;
    if (iVar39 <= (int32_t)uVar22) goto code_r0x000180149c63;
    goto code_r0x000180149c50;
}

// ============================================================
// Function: FUN_180149ae2
// Address: 0x180149ae2
// Size: 332 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_144h
// WARNING: Variable defined which should be unmapped: var_178h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180148fa0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined auVar3 [16];
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    bool bVar13;
    bool bVar14;
    char cVar15;
    uint8_t uVar16;
    int32_t iVar17;
    undefined8 uVar18;
    int64_t iVar19;
    int32_t *piVar20;
    uint32_t uVar21;
    uint32_t uVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    uint64_t uVar26;
    undefined4 *puVar27;
    uint32_t uVar28;
    undefined4 *puVar29;
    uint32_t *puVar30;
    float *pfVar31;
    int32_t iVar32;
    uint32_t *puVar33;
    undefined8 *puVar34;
    uint32_t uVar35;
    int32_t iVar36;
    undefined4 *puVar37;
    int64_t iVar38;
    int32_t iVar39;
    char *pcVar40;
    int32_t iVar41;
    int64_t *piVar42;
    float *pfVar43;
    bool bVar44;
    float fVar45;
    float fVar46;
    float fVar47;
    float fVar48;
    float fVar49;
    float fVar50;
    float fVar51;
    undefined auVar52 [16];
    undefined auVar53 [16];
    float fVar54;
    undefined4 unaff_XMM12_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    float fVar55;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_198 [32];
    int64_t var_178h;
    undefined4 in_stack_fffffffffffffe98;
    undefined4 in_stack_fffffffffffffe9c;
    undefined4 uVar56;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int32_t var_148h;
    int64_t var_144h;
    undefined4 uStack_13c;
    undefined4 uVar57;
    undefined4 in_stack_fffffffffffffecc;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    float var_100h [2];
    int64_t var_f8h;
    float var_f0h;
    float var_ech;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar38 = *(int64_t *)0x180781f28;
    var_d8h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_198;
    fVar51 = *(float *)(arg1 + 0x48);
    var_118h = arg1 + 0x38;
    *(undefined *)(arg1 + 0x83) = 0;
    fVar49 = *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38);
    var_110h = arg1 + 0x40;
    uVar22 = *(uint32_t *)(arg1 + 8);
    *(float *)(arg1 + 0x48) = fVar49;
    uVar56 = CONCAT31((unkint3)((uint32_t)in_stack_fffffffffffffe9c >> 8), fVar49 < fVar51);
    auVar3._4_4_ = unaff_XMM12_Dc;
    auVar3._0_4_ = unaff_XMM12_Db;
    auVar3._8_4_ = unaff_XMM12_Dd;
    auVar3._12_4_ = 0;
    _var_98h = auVar3 << 0x20;
    bVar44 = false;
    uVar28 = 0;
    uVar35 = 0;
    _var_108h = ZEXT816(0);
    _var_f8h = ZEXT816(0);
    _var_e8h = ZEXT816(0);
    bVar13 = false;
    if (0 < (int32_t)uVar22) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)(arg1 + 0x10);
            iVar23 = (int64_t)(int32_t)uVar35 * 0x38;
            if ((*(int32_t *)(iVar23 + 0x10 + iVar25) < *(int32_t *)(arg1 + 0x34)) ||
               (*(char *)(iVar23 + 0x30 + iVar25) != '\0')) {
                if (*(int32_t *)(arg1 + 0x2c) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x2c) = 0;
                }
                if (*(int32_t *)(arg1 + 0x20) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x20) = 0;
                }
                if (*(int32_t *)(arg1 + 0x24) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x24) = 0;
                }
            } else {
                if (uVar28 != uVar35) {
                    auVar3 = *(undefined (*) [16])(iVar23 + 0x10 + iVar25);
                    puVar37 = (undefined4 *)(iVar23 + 0x20 + iVar25);
                    uVar57 = *puVar37;
                    uVar1 = puVar37[1];
                    uVar2 = puVar37[2];
                    uVar4 = puVar37[3];
                    uVar18 = *(undefined8 *)(iVar23 + 0x30 + iVar25);
                    iVar24 = (int64_t)(int32_t)uVar28 * 0x38;
                    *(undefined (*) [16])(iVar24 + iVar25) = *(undefined (*) [16])(iVar23 + iVar25);
                    *(undefined (*) [16])(iVar24 + 0x10 + iVar25) = auVar3;
                    puVar37 = (undefined4 *)(iVar24 + 0x20 + iVar25);
                    *puVar37 = uVar57;
                    puVar37[1] = uVar1;
                    puVar37[2] = uVar2;
                    puVar37[3] = uVar4;
                    *(undefined8 *)(iVar24 + 0x30 + iVar25) = uVar18;
                }
                iVar23 = (int64_t)(int32_t)uVar28 * 0x38;
                iVar25 = *(int64_t *)(arg1 + 0x10);
                uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                *(int16_t *)(iVar23 + 0x2e + iVar25) = (int16_t)uVar28;
                if ((uVar22 & 0x40) == 0) {
                    uVar26 = (uint64_t)(((uVar22 & 0x80) != 0) + 1);
                } else {
                    uVar26 = 0;
                }
                if (0 < (int32_t)uVar28) {
                    uVar22 = *(uint32_t *)(*(int64_t *)(arg1 + 0x10) + -0x34 + iVar23);
                    cVar15 = '\0';
                    if ((uVar22 & 0x40) == 0) {
                        cVar15 = ((uVar22 & 0x80) != 0) + '\x01';
                    }
                    if ((int32_t)uVar26 == 0) {
                        if (cVar15 == '\0') goto code_r0x000180149140;
                        bVar44 = true;
                    }
                    if (cVar15 == '\x02') {
                        if ((int32_t)uVar26 != 2) {
                            bVar44 = true;
                        }
                        var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                        uVar28 = uVar28 + 1;
                        goto code_r0x000180149172;
                    }
                }
code_r0x000180149140:
                var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                uVar28 = uVar28 + 1;
            }
code_r0x000180149172:
            uVar22 = *(uint32_t *)(arg1 + 8);
            uVar35 = uVar35 + 1;
            bVar13 = bVar44;
        } while ((int32_t)uVar35 < (int32_t)uVar22);
    }
    uVar35 = 8;
    var_128h = arg1;
    if (uVar22 != uVar28) {
        iVar32 = *(int32_t *)(arg1 + 0xc);
        if (iVar32 < (int32_t)uVar28) {
            uVar22 = uVar35;
            if (iVar32 != 0) {
                uVar22 = iVar32 / 2 + iVar32;
            }
            uVar21 = uVar28;
            if ((int32_t)uVar28 < (int32_t)uVar22) {
                uVar21 = uVar22;
            }
            func_0x00018011f970(arg1 + 8, uVar21);
        }
        *(uint32_t *)(arg1 + 8) = uVar28;
        uVar22 = uVar28;
    }
    piVar42 = (int64_t *)(arg1 + 0x10);
    if ((bVar44) && (1 < uVar22)) {
        fcn.18046f0d0(CONCAT44(uVar56, in_stack_fffffffffffffe98));
    }
    fVar51 = *(float *)(iVar38 + 0xdf4);
    if (((int32_t)var_108h < 1) || (var_100h[1] = fVar51, (int32_t)((int32_t)var_e8h + (uint32_t)var_f8h) < 1)) {
        var_100h[1] = 0.0;
    }
    if (((int32_t)(uint32_t)var_f8h < 1) || (var_ech = fVar51, (int32_t)var_e8h < 1)) {
        var_ech = 0.0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x28);
    uVar21 = 0;
    uVar28 = 0;
    if (uVar22 != 0) {
        *(undefined4 *)(arg1 + 0x28) = 0;
        uVar28 = uVar22;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x24);
    if (uVar22 != 0) {
        *(uint32_t *)(arg1 + 0x20) = uVar22;
        *(undefined4 *)(arg1 + 0x24) = 0;
        uVar28 = uVar22;
    }
    if (*(int32_t *)(arg1 + 0x7c) != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (iVar32 < 1) {
code_r0x00018014939d:
            *(undefined4 *)(arg1 + 0x7c) = 0;
        } else {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar21 * 0x38;
                puVar37 = (undefined4 *)(uVar26 + iVar25);
                if (*(int32_t *)(uVar26 + iVar25) == *(int32_t *)(arg1 + 0x7c)) {
                    if ((puVar37[1] & 0x20) == 0) {
                        iVar41 = (int32_t)(uVar26 / 0x38) + (int32_t)*(int16_t *)(arg1 + 0x80);
                        if ((-1 < iVar41) && (iVar41 < iVar32)) {
                            puVar29 = (undefined4 *)((int64_t)iVar41 * 0x38 + iVar25);
                            if (((puVar29[1] & 0x20) == 0) && (((puVar29[1] ^ puVar37[1]) & 0xc0) == 0)) {
                                uVar18 = *(undefined8 *)(puVar37 + 0xc);
                                uVar57 = *puVar37;
                                uVar1 = puVar37[1];
                                uVar2 = puVar37[2];
                                uVar4 = puVar37[3];
                                uVar5 = puVar37[4];
                                uVar6 = puVar37[5];
                                uVar7 = puVar37[6];
                                uVar8 = puVar37[7];
                                uVar9 = puVar37[8];
                                uVar10 = puVar37[9];
                                uVar11 = puVar37[10];
                                uVar12 = puVar37[0xb];
                                if (*(int16_t *)(arg1 + 0x80) < 1) {
                                    puVar37 = puVar29 + 0xe;
                                    puVar27 = puVar29;
                                } else {
                                    puVar27 = puVar37 + 0xe;
                                }
                                fcn.180498030(puVar37, puVar27);
                                *puVar29 = uVar57;
                                puVar29[1] = uVar1;
                                puVar29[2] = uVar2;
                                puVar29[3] = uVar4;
                                puVar29[4] = uVar5;
                                puVar29[5] = uVar6;
                                puVar29[6] = uVar7;
                                puVar29[7] = uVar8;
                                puVar29[8] = uVar9;
                                puVar29[9] = uVar10;
                                puVar29[10] = uVar11;
                                puVar29[0xb] = uVar12;
                                *(undefined8 *)(puVar29 + 0xc) = uVar18;
                                if (((*(uint32_t *)(arg1 + 0x18) & 0x400000) != 0) &&
                                   (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)) {
                                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) =
                                         *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
                                }
                                if (*(uint32_t *)(arg1 + 0x7c) == *(uint32_t *)(arg1 + 0x20)) {
                                    uVar28 = *(uint32_t *)(arg1 + 0x7c);
                                }
                            }
                        }
                    }
                    goto code_r0x00018014939d;
                }
                uVar21 = uVar21 + 1;
            } while ((int32_t)uVar21 < iVar32);
            *(undefined4 *)(arg1 + 0x7c) = 0;
        }
    }
    iVar25 = *(int64_t *)0x180781f28;
    puVar33 = (uint32_t *)0x0;
    if ((*(uint8_t *)(arg1 + 0x18) & 4) != 0) {
        uVar57 = *(undefined4 *)(arg1 + 0x3c);
        var_148h = 0;
        fVar49 = *(float *)(*(int64_t *)0x180781f28 + 0xde0);
        iVar23 = *(int64_t *)0x180781f28 + 0x20c0;
        iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
        uVar1 = *(undefined4 *)(iVar24 + 0x158);
        uVar2 = *(undefined4 *)(iVar24 + 0x15c);
        *(float *)(iVar24 + 0x158) = *(float *)(arg1 + 0x38) - fVar49;
        *(undefined4 *)(iVar24 + 0x15c) = uVar57;
        *(float *)(arg1 + 0x38) = fVar49 + fVar45 + *(float *)(arg1 + 0x38);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        uVar57 = *(undefined4 *)(iVar25 + 0xed8);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        fVar49 = *(float *)(iVar25 + 0xedc);
        fcn.18011f2b0(iVar23, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar57;
            *(float *)(iVar25 + 0xedc) = fVar49 * 0.5;
        }
        iVar25 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        uVar57 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x102c);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar25 + 0x1020) = 0;
            *(undefined8 *)(iVar25 + 0x1028) = 0;
        }
        cVar15 = func_0x00018013d0a0();
        fcn.1800f6770(2);
        if (cVar15 != '\0') {
            iVar32 = 0;
            if (0 < *(int32_t *)(arg1 + 8)) {
                do {
                    puVar30 = (uint32_t *)((int64_t)iVar32 * 0x38 + *piVar42);
                    if (((puVar30[1] & 0x200000) == 0) &&
                       (cVar15 = fcn.180146c70(CONCAT44(uStack_13c, var_144h._4_4_), 
                                               CONCAT44(in_stack_fffffffffffffecc, uVar57)), cVar15 != '\0')) {
                        puVar33 = puVar30;
                    }
                    iVar32 = iVar32 + 1;
                } while (iVar32 < *(int32_t *)(arg1 + 8));
            }
            iVar25 = *(int64_t *)0x180781f28;
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) + -1;
            iVar32 = func_0x000180498f10(*(undefined8 *)(*(int64_t *)(iVar25 + 0x15e0) + 8), &var_148h);
            if (iVar32 == 0) {
                func_0x00018010d5c0();
            } else if (*(code **)(iVar25 + 0x2a40) != (code *)0x0) {
                (**(code **)(iVar25 + 0x2a40))(iVar25, *(undefined8 *)(iVar25 + 0x2a48));
            }
        }
        *(undefined4 *)(iVar24 + 0x158) = uVar1;
        *(undefined4 *)(iVar24 + 0x15c) = uVar2;
        if (puVar33 != (uint32_t *)0x0) {
            uVar28 = *puVar33;
            *(uint32_t *)(arg1 + 0x20) = uVar28;
        }
    }
    iVar41 = 1;
    uVar22 = *(uint32_t *)(arg1 + 8);
    var_144h._0_4_ = (int32_t)var_e8h + (int32_t)var_108h;
    var_148h = 0;
    iVar32 = *(int32_t *)(iVar38 + 0x257c);
    var_144h._4_4_ = (int32_t)var_108h;
    if (iVar32 < (int32_t)uVar22) {
        if (iVar32 != 0) {
            uVar35 = iVar32 / 2 + iVar32;
        }
        uVar21 = uVar22;
        if ((int32_t)uVar22 < (int32_t)uVar35) {
            uVar21 = uVar35;
        }
        if (iVar32 < (int32_t)uVar21) {
            uVar18 = fcn.18046d050((int64_t)(int32_t)uVar21 * 0xc);
            if (*(int64_t *)(iVar38 + 0x2580) != 0) {
                fcn.180498030(uVar18);
                fcn.180460d90(*(undefined8 *)(iVar38 + 0x2580));
            }
            *(undefined8 *)(iVar38 + 0x2580) = uVar18;
            *(uint32_t *)(iVar38 + 0x257c) = uVar21;
        }
    }
    *(uint32_t *)(iVar38 + 0x2578) = uVar22;
    if ((*(uint8_t *)(arg1 + 0x18) & 0x80) == 0) {
        fVar49 = 1.0;
    } else {
        fVar49 = *(float *)(iVar38 + 0xe40);
    }
    iVar32 = *(int32_t *)(arg1 + 8);
    iVar39 = 0;
    var_130h = 0;
    bVar44 = false;
    uVar22 = 0xffffffff;
    bVar13 = false;
    if (0 < iVar32) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)0x180781f28;
            puVar33 = (uint32_t *)((int64_t)iVar39 * 0x38 + *piVar42);
            if (((var_130h == 0) || (*(int32_t *)(var_130h + 0x14) < (int32_t)puVar33[5])) &&
               ((puVar33[1] & 0x200000) == 0)) {
                var_130h = (int64_t)puVar33;
            }
            uVar35 = *puVar33;
            if (uVar35 == *(uint32_t *)(arg1 + 0x20)) {
                bVar44 = true;
            }
            if ((uVar28 == 0) && (*(uint32_t *)(iVar38 + 0x23a4) == uVar35)) {
                uVar28 = uVar35;
            }
            auVar52 = ZEXT416(puVar33[9]);
            if ((float)puVar33[9] < 0.0) {
                uVar35 = puVar33[1];
                var_178h._0_4_ = 0xbf800000;
                fcn.1800fe0a0(CONCAT44(var_178h._4_4_, 0xbf800000), SUB168(_var_98h, 8));
                fVar45 = *(float *)(iVar25 + 0xddc);
                if ((uVar35 & 0x100001) == 0x100000) {
                    fVar50 = fVar45 + 1.0;
                } else {
                    fVar50 = *(float *)(iVar25 + 0x12f8) + *(float *)(iVar25 + 0xdf4) + fVar45;
                }
                fVar50 = fVar50 + var_120h + fVar45;
                auVar52 = ZEXT416((uint32_t)fVar50);
                fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 20.0;
                if (fVar45 <= fVar50) {
                    auVar52 = ZEXT416((uint32_t)fVar45);
                }
            }
            uVar35 = puVar33[1];
            puVar33[8] = (uint32_t)auVar52._0_4_;
            if ((uVar35 >> 0x15 & 1) == 0) {
                if (auVar52._0_4_ <= *(float *)(iVar38 + 0xe3c)) {
                    auVar52._0_4_ = *(float *)(iVar38 + 0xe3c);
                }
                puVar33[8] = auVar52._0_4_;
            }
            if ((uVar35 & 0x40) == 0) {
                uVar35 = ((uVar35 & 0x80) != 0) + 1;
            } else {
                uVar35 = 0;
            }
            uVar26 = (uint64_t)uVar35;
            if (uVar35 == uVar22) {
                fVar50 = auVar52._0_4_ + fVar51;
                fVar45 = fVar51;
            } else {
                fVar50 = auVar52._0_4_ + 0.0;
                fVar45 = 0.0;
            }
            var_100h[uVar26 * 4 + -1] = fVar50 + var_100h[uVar26 * 4 + -1];
            fVar50 = (float)puVar33[8];
            if (fVar49 <= (float)puVar33[8]) {
                fVar50 = fVar49;
            }
            var_100h[uVar26 * 4] = fVar50 + fVar45 + var_100h[uVar26 * 4];
            iVar23 = (int64_t)(&var_148h)[uVar26];
            (&var_148h)[uVar26] = (&var_148h)[uVar26] + 1;
            iVar25 = *(int64_t *)(iVar38 + 0x2580);
            *(int32_t *)(iVar25 + iVar23 * 0xc) = iVar39;
            iVar39 = iVar39 + 1;
            uVar22 = puVar33[8];
            *(uint32_t *)(iVar25 + 8 + iVar23 * 0xc) = uVar22;
            *(uint32_t *)(iVar25 + 4 + iVar23 * 0xc) = uVar22;
            fVar45 = (float)puVar33[8];
            if (fVar45 <= 1.0) {
                fVar45 = 1.0;
            }
            puVar33[7] = (uint32_t)fVar45;
            iVar32 = *(int32_t *)(arg1 + 8);
            uVar22 = uVar35;
            bVar13 = bVar44;
        } while (iVar39 < iVar32);
    }
    uVar22 = *(uint32_t *)(arg1 + 0x18);
    *(float *)(arg1 + 0x58) = var_100h[1] + var_108h._4_4_ + 0.0 + var_f8h._4_4_ + var_ech + var_e8h._4_4_ + var_dch;
    iVar25 = *(int64_t *)0x180781f28;
    if (((uVar22 & 0x200) == 0) && (-1 < (char)uVar22)) {
        bVar14 = false;
code_r0x00018014992e:
        bVar13 = bVar14;
        fVar51 = var_e0h + var_dch + var_100h[0] + var_100h[1] + 0.0 + var_f0h + var_ech;
    } else {
        bVar13 = true;
        bVar14 = true;
        if ((uVar22 & 0x200) == 0) goto code_r0x00018014992e;
        fVar51 = *(float *)(arg1 + 0x54);
    }
    if ((((fVar51 <= *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38)) || (iVar32 < 2)) || ((uVar22 & 0x10) != 0)) ||
       (!bVar13)) {
        *(undefined *)(arg1 + 0x86) = 0;
    } else {
        *(undefined *)(arg1 + 0x86) = 1;
        var_148h = 0;
        fVar51 = *(float *)(iVar25 + 0x12f8);
        iVar23 = *(int64_t *)(iVar25 + 0x15e0);
        fVar54 = fVar51 - 2.0;
        fVar45 = *(float *)(iVar25 + 0xde0);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        uVar57 = *(undefined4 *)(iVar23 + 0x158);
        uVar1 = *(undefined4 *)(iVar25 + 0xed8);
        fVar50 = *(float *)(iVar25 + 0xedc);
        fVar55 = fVar54 + fVar54;
        var_120h = *(float *)(iVar23 + 0x15c);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        fcn.18011f2b0(iVar25 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar1;
            *(float *)(iVar25 + 0xedc) = fVar50 * 0.5;
        }
        iVar24 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar24 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar24 + 0x1020) = 0;
            *(undefined8 *)(iVar24 + 0x1028) = 0;
        }
        iVar24 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 10;
        piVar20 = (int32_t *)(iVar24 + 0x2100);
        iVar32 = *(int32_t *)(iVar24 + 0x2104);
        uVar1 = *(undefined4 *)(iVar24 + 0x1f78);
        if (*piVar20 == iVar32) {
            iVar39 = *piVar20 + 1;
            if (iVar32 == 0) {
                iVar32 = 8;
            } else {
                iVar32 = iVar32 / 2 + iVar32;
            }
            if (iVar39 < iVar32) {
                iVar39 = iVar32;
            }
            fcn.18011fb10(piVar20, iVar39);
        }
        *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + (int64_t)*piVar20 * 4) = uVar1;
        *piVar20 = *piVar20 + 1;
        uVar1 = *(undefined4 *)(iVar25 + 0xa8);
        uVar2 = *(undefined4 *)(iVar25 + 0xac);
        *(undefined4 *)(iVar25 + 0xa8) = 0x3e800000;
        *(undefined4 *)(iVar25 + 0xac) = 0x3e4ccccd;
        fVar46 = *(float *)(arg1 + 0x40) - fVar55;
        fVar50 = *(float *)(arg1 + 0x38);
        if (*(float *)(arg1 + 0x38) <= fVar46) {
            fVar50 = fVar46;
        }
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50;
        uVar16 = func_0x00018013a9f0(0x180645ba0, 0, CONCAT44(fVar45 + fVar45 + fVar51, fVar54));
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50 + fVar54;
        cVar15 = func_0x00018013a9f0(0x180645ba4, 1);
        iVar24 = *(int64_t *)0x180781f28;
        if (cVar15 == '\0') {
            iVar32 = (uVar16 ^ 1) - 1;
        } else {
            iVar32 = 1;
        }
        iVar39 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
        if (iVar39 < 2) {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48));
            }
        } else {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar39 + -1;
            *(undefined4 *)(iVar24 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + -8 + (int64_t)iVar39 * 4)
            ;
        }
        fcn.1800f6770();
        *(undefined4 *)(iVar25 + 0xac) = uVar2;
        *(undefined4 *)(iVar25 + 0xa8) = uVar1;
        if (iVar32 == 0) {
            puVar33 = (uint32_t *)0x0;
code_r0x000180149cf6:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
            if ((puVar33 != (uint32_t *)0x0) && (uVar28 = *puVar33, (puVar33[1] & 0x200000) == 0)) {
                *(uint32_t *)(arg1 + 0x20) = uVar28;
            }
        } else {
            if ((*(int32_t *)(arg1 + 0x20) != 0) && (iVar39 = *(int32_t *)(arg1 + 8), 0 < iVar39)) {
                uVar26 = 0;
                iVar25 = *piVar42;
code_r0x000180149c50:
                if (*(int32_t *)(uVar26 * 0x38 + iVar25) != *(int32_t *)(arg1 + 0x20)) goto code_r0x000180149c5c;
                uVar26 = (uVar26 * 0x38) / 0x38;
                iVar36 = (int32_t)uVar26 + iVar32;
                do {
                    if ((iVar36 < 0) || (iVar17 = iVar36, iVar39 <= iVar36)) {
                        iVar17 = (int32_t)uVar26;
                    }
                    puVar33 = (uint32_t *)((int64_t)iVar17 * 0x38 + iVar25);
                } while ((((*(uint32_t *)(iVar25 + 4 + (int64_t)iVar17 * 0x38) & 0x200000) != 0) &&
                         (iVar36 = iVar36 + iVar32, -1 < iVar36)) &&
                        (uVar26 = (uint64_t)(uint32_t)((int32_t)uVar26 + iVar32), iVar36 < iVar39));
                goto code_r0x000180149cf6;
            }
code_r0x000180149c63:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
        }
    }
    pfVar43 = (float *)(arg1 + 0x40);
    pcVar40 = (char *)(arg1 + 0x86);
    puVar34 = (undefined8 *)(arg1 + 0x38);
    if ((uVar28 == 0) && ((char)uVar56 != '\0')) {
        uVar28 = *(uint32_t *)(arg1 + 0x20);
    }
    fVar51 = *pfVar43 - *(float *)puVar34;
    fVar45 = var_e8h._4_4_ + var_dch + var_108h._4_4_ + var_100h[1];
    if (fVar51 <= fVar45) {
        fVar50 = fVar45 - fVar51;
    } else {
        fVar50 = (var_f8h._4_4_ + var_ech) - ((fVar51 - (var_108h._4_4_ + var_100h[1])) - (var_e8h._4_4_ + var_dch));
        if (fVar50 <= 0.0) {
            fVar50 = 0.0;
        }
    }
    if (1.0 <= fVar50) {
        if ((*(uint32_t *)(arg1 + 0x18) & 0x180) == 0) {
            if (fVar45 < fVar51) goto code_r0x00018014a4db;
code_r0x000180149e0c:
            uVar22 = (int32_t)var_e8h + (int32_t)var_108h;
            if (fVar51 <= fVar45) {
                iVar32 = 0;
            } else {
                iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            }
        } else {
            if (fVar51 <= fVar45) goto code_r0x000180149e0c;
            iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            uVar22 = (uint32_t)var_f8h;
        }
        iVar25 = *(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc;
        if (uVar22 == 1) {
            if (0.0 <= *(float *)(iVar25 + 4)) {
                fVar50 = *(float *)(iVar25 + 4) - fVar50;
                if (fVar50 <= fVar49) {
                    fVar50 = fVar49;
                }
                *(float *)(iVar25 + 4) = fVar50;
            }
        } else {
            if (1 < uVar22) {
                fcn.18046f0d0(CONCAT44(uVar56, uVar28));
            }
            while ((0.001 < fVar50 && (iVar41 < (int32_t)uVar22))) {
                fVar51 = *(float *)(iVar25 + 4);
                do {
                    fVar45 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                    if (fVar45 < fVar51) {
                        if (0.0 <= fVar45) {
                            fVar45 = fVar51 - fVar45;
                            goto code_r0x000180149ee6;
                        }
                        break;
                    }
                    iVar41 = iVar41 + 1;
                } while (iVar41 < (int32_t)uVar22);
                fVar45 = fVar51 - 1.0;
code_r0x000180149ee6:
                fVar54 = fVar51 - fVar49;
                if (fVar45 <= fVar51 - fVar49) {
                    fVar54 = fVar45;
                }
                if (fVar54 <= 0.0) break;
                iVar39 = 0;
                fVar51 = fVar50 / (float)iVar41;
                if (fVar54 <= fVar50 / (float)iVar41) {
                    fVar51 = fVar54;
                }
                if (3 < iVar41) {
                    do {
                        iVar23 = (int64_t)iVar39;
                        iVar39 = iVar39 + 4;
                        fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar55 = fVar45 - fVar49;
                        fVar54 = fVar51;
                        if (fVar55 <= fVar51) {
                            fVar54 = fVar55;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                        fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar46 = fVar45 - fVar49;
                        fVar55 = fVar51;
                        if (fVar46 <= fVar51) {
                            fVar55 = fVar46;
                        }
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar45 - fVar55;
                        fVar45 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar47 = fVar45 - fVar49;
                        fVar46 = fVar51;
                        if (fVar47 <= fVar51) {
                            fVar46 = fVar47;
                        }
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar45 - fVar46;
                        fVar45 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar48 = fVar45 - fVar49;
                        fVar47 = fVar51;
                        if (fVar48 <= fVar51) {
                            fVar47 = fVar48;
                        }
                        fVar50 = (((fVar50 - fVar54) - fVar55) - fVar46) - fVar47;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar45 - fVar47;
                    } while (iVar39 < iVar41 + -3);
                }
                while (iVar39 < iVar41) {
                    iVar23 = (int64_t)iVar39;
                    iVar39 = iVar39 + 1;
                    fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar55 = fVar45 - fVar49;
                    fVar54 = fVar51;
                    if (fVar55 <= fVar51) {
                        fVar54 = fVar55;
                    }
                    fVar50 = fVar50 - fVar54;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                }
            }
            iVar41 = 0;
            fVar51 = 0.0;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 4;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar48 = (float)(int32_t)fVar49;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar48;
                    fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                    fVar46 = (float)(int32_t)fVar45;
                    *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar46;
                    fVar50 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                    fVar55 = (float)(int32_t)fVar50;
                    *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar55;
                    fVar54 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                    fVar47 = (float)(int32_t)fVar54;
                    *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar47;
                    fVar51 = (fVar49 - fVar48) + fVar51 + (fVar45 - fVar46) + (fVar50 - fVar55) + (fVar54 - fVar47);
                } while (iVar41 < (int32_t)(uVar22 - 3));
            }
            for (; iVar41 < (int32_t)uVar22; iVar41 = iVar41 + 1) {
                fVar49 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                fVar45 = (float)(int32_t)fVar49;
                *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc) = fVar45;
                fVar51 = fVar51 + (fVar49 - fVar45);
            }
            while (0.0 < fVar51) {
                iVar41 = 0;
                if (3 < (int32_t)uVar22) {
                    do {
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar23 = (int64_t)iVar41;
                        fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 - fVar45 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar50 = *(float *)(iVar25 + 0x14 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar50) {
                            fVar50 = 1.0;
                        }
                        fVar51 = (fVar51 - fVar45) - fVar50;
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar49 + fVar50;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x20 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar41 = iVar41 + 4;
                        fVar49 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x2c + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar49 + fVar45;
                    } while (iVar41 < (int32_t)(uVar22 - 3));
                }
                while (iVar41 < (int32_t)uVar22) {
                    if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 1;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                    if (1.0 <= fVar45) {
                        fVar45 = 1.0;
                    }
                    fVar51 = fVar51 - fVar45;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                }
            }
        }
code_r0x00018014a22a:
        iVar41 = iVar32 + uVar22;
        if (iVar32 < iVar41) {
            arg1 = var_128h;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar25 = (int64_t)iVar32;
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x10 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0xc + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x1c + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x18 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x28 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar25 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x24 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar25 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar24 = 0;
                        }
                        var_100h[iVar24 * 4 + -1] =
                             var_100h[iVar24 * 4 + -1] - (*(float *)(iVar25 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar25 + 0x1c + iVar23) = fVar49;
                    }
                    iVar32 = iVar32 + 4;
                } while (iVar32 < iVar41 + -3);
                if (iVar41 <= iVar32) goto code_r0x00018014a4d3;
            }
            do {
                fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + (int64_t)iVar32 * 0xc);
                if (0.0 <= fVar51) {
                    iVar25 = *piVar42;
                    fVar49 = 1.0;
                    if (1.0 <= fVar51) {
                        fVar49 = fVar51;
                    }
                    iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc) * 0x38;
                    uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                    if ((uVar22 & 0x40) == 0) {
                        iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                    } else {
                        iVar24 = 0;
                    }
                    var_100h[iVar24 * 4 + -1] =
                         var_100h[iVar24 * 4 + -1] - (*(float *)(iVar23 + 0x1c + iVar25) - fVar49);
                    *(float *)(iVar23 + 0x1c + iVar25) = fVar49;
                }
                iVar32 = iVar32 + 1;
                puVar34 = (undefined8 *)var_118h;
                pfVar43 = (float *)var_110h;
            } while (iVar32 < iVar41);
        } else {
code_r0x00018014a4d3:
            puVar34 = (undefined8 *)(arg1 + 0x38);
            pfVar43 = (float *)(arg1 + 0x40);
        }
    }
code_r0x00018014a4db:
    uVar35 = 0;
    auVar53 = ZEXT816(0);
    *(undefined4 *)(arg1 + 0x54) = 0;
    uVar22 = uVar35;
    if (0 < (int32_t)var_108h) {
        do {
            iVar25 = *piVar42;
            iVar23 = (int64_t)(int32_t)uVar22 * 0x38;
            *(float *)(iVar23 + 0x18 + iVar25) = auVar53._0_4_;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_108h + -1) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            auVar53._0_4_ = auVar53._0_4_ + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_108h);
    }
    fVar49 = auVar53._0_4_ + var_100h[1];
    fVar51 = var_100h[1] + var_108h._4_4_;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    uVar22 = uVar35;
    if (0 < (int32_t)(uint32_t)var_f8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar49;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)((uint32_t)var_f8h + -1)) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar49 = fVar49 + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)(uint32_t)var_f8h);
    }
    fVar51 = var_f8h._4_4_ + var_ech;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    fVar45 = (*(float *)(arg1 + 0x40) - *(float *)puVar34) - var_e8h._4_4_;
    fVar51 = 0.0;
    if (0.0 <= fVar45) {
        fVar51 = fVar45;
    }
    if (var_ech + fVar49 <= fVar51) {
        fVar51 = var_ech + fVar49;
    }
    uVar22 = uVar35;
    if (0 < (int32_t)var_e8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h + (uint32_t)var_f8h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar51;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_e8h + -1) {
                fVar49 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar49 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar51 = fVar51 + fVar49 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_e8h);
    }
    fVar51 = var_e8h._4_4_ + var_dch;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    func_0x00018011f640(arg1 + 0xa0, 0);
    if ((!bVar44) && (*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1)) {
        *(undefined4 *)(arg1 + 0x20) = 0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x20);
    if (((*(uint32_t *)(arg1 + 0x20) == 0) && (uVar22 = uVar35, *(int32_t *)(arg1 + 0x24) == 0)) && (var_130h != 0)) {
        uVar28 = *(uint32_t *)var_130h;
        *(uint32_t *)(arg1 + 0x20) = uVar28;
        uVar22 = uVar28;
    }
    *(uint32_t *)(arg1 + 0x2c) = uVar22;
    *(undefined *)(arg1 + 0x84) = 0;
    iVar25 = *(int64_t *)(iVar38 + 0x23c0);
    if (((iVar25 != 0) && (*(int64_t *)(iVar25 + 0x4c0) != 0)) &&
       (*(int64_t *)(*(int64_t *)(iVar25 + 0x4c0) + 0x40) == arg1)) {
        uVar28 = *(uint32_t *)(iVar25 + 200);
        *(uint32_t *)(arg1 + 0x2c) = uVar28;
    }
    if (uVar28 != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (0 < iVar32) {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar35 * 0x38;
                if (*(uint32_t *)(uVar26 + iVar25) == uVar28) {
                    if ((*(uint8_t *)(uVar26 + 4 + iVar25) & 0xc0) != 0) break;
                    fVar51 = *pfVar43;
                    fVar49 = *(float *)puVar34;
                    fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
                    iVar41 = (int32_t)(uVar26 / 0x38);
                    if ((int32_t)var_108h + -1 < iVar41) {
                        fVar50 = (float)((uint32_t)fVar45 ^ 0x80000000);
                    } else {
                        fVar50 = 0.0;
                    }
                    fVar54 = *(float *)(uVar26 + 0x18 + iVar25) - var_108h._4_4_;
                    fVar50 = fVar54 + fVar50;
                    if (iVar32 - (int32_t)var_e8h <= iVar41 + 1) {
                        fVar45 = 1.0;
                    }
                    fVar55 = *(float *)(uVar26 + 0x1c + iVar25);
                    *(undefined4 *)(arg1 + 100) = 0;
                    fVar45 = fVar54 + fVar55 + fVar45;
                    if (*(float *)(arg1 + 0x60) <= fVar50) {
                        fVar51 = (((fVar51 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech;
                        if (fVar45 - fVar50 < fVar51) {
                            if (*(float *)(arg1 + 0x60) < fVar45 - fVar51) {
                                *(float *)(arg1 + 0x60) = fVar45 - fVar51;
                                fVar51 = (fVar50 - fVar51) - *(float *)(arg1 + 0x5c);
                                if (fVar51 <= 0.0) {
                                    fVar51 = 0.0;
                                }
                                *(float *)(arg1 + 100) = fVar51;
                            }
                            break;
                        }
                    }
                    fVar45 = *(float *)(arg1 + 0x5c) - fVar45;
                    *(float *)(arg1 + 0x60) = fVar50;
                    if (fVar45 <= 0.0) {
                        fVar45 = 0.0;
                    }
                    *(float *)(arg1 + 100) = fVar45;
                    break;
                }
                uVar35 = uVar35 + 1;
            } while ((int32_t)uVar35 < iVar32);
        }
        goto code_r0x00018014a9b6;
    }
    if ((*pcVar40 == '\0') || (cVar15 = func_0x000180108120(puVar34, pfVar43, 1), cVar15 == '\0'))
    goto code_r0x00018014a9b6;
    iVar25 = *(int64_t *)(iVar38 + 0x15e0);
    if (((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) != 0) &&
        ((((iVar23 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) + 0x428), iVar23 != 0 &&
           (*(char *)(iVar23 + 0x10a) != '\0')) && (iVar23 != *(int64_t *)(iVar25 + 0x428))) &&
         (((*(uint32_t *)(iVar23 + 0x14) >> 0x1b & 1) != 0 || ((*(uint32_t *)(iVar23 + 0x14) >> 0x1a & 1) != 0)))))) &&
       (iVar24 = *(int64_t *)(iVar25 + 0x418), *(int64_t *)(iVar24 + 0x418) != iVar23)) {
        do {
            if (iVar24 == iVar23) goto code_r0x00018014a8ae;
            iVar24 = *(int64_t *)(iVar24 + 0x410);
        } while (iVar24 != 0);
        goto code_r0x00018014a9b6;
    }
code_r0x00018014a8ae:
    if ((*(int64_t *)(iVar25 + 0x48) != *(int64_t *)(*(int64_t *)0x180781f28 + 0x2168)) &&
       ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) == 0 ||
        (*(int64_t *)(iVar25 + 0x428) != *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) + 0x428)))))
    goto code_r0x00018014a9b6;
    pfVar31 = (float *)(iVar38 + 0x128);
    if (*(char *)(iVar38 + 0xbaa) == '\0') {
        pfVar31 = (float *)(iVar38 + 300);
    }
    iVar32 = *(int32_t *)(arg1 + 0x1c);
    uVar26 = (uint64_t)((*(char *)(iVar38 + 0xbaa) != '\0') + 0x295);
    iVar25 = *(int64_t *)0x180781f28;
    piVar20 = (int32_t *)func_0x0001800f45c0(*(int64_t *)0x180781f28, uVar26);
    if (iVar32 == 0) {
        bVar44 = *(char *)(piVar20 + 2) == '\0';
code_r0x00018014a936:
        if (bVar44) {
code_r0x00018014a938:
            fVar51 = *pfVar31;
            if (fVar51 != 0.0) {
                fVar49 = *(float *)puVar34;
                fVar45 = *pfVar43;
                *(undefined4 *)(arg1 + 100) = 0;
                fVar51 = *(float *)(arg1 + 0x60) -
                         (((((fVar45 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech) * fVar51) / 3.0;
                fVar49 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar49);
                if (fVar49 <= fVar51) {
                    fVar51 = fVar49;
                }
                if (fVar51 <= 0.0) {
                    fVar51 = 0.0;
                }
                *(float *)(arg1 + 0x60) = fVar51;
            }
        }
    } else {
        if (*piVar20 == iVar32) goto code_r0x00018014a938;
        if (*(char *)(piVar20 + 2) == '\0') {
            bVar44 = *piVar20 == -1;
            goto code_r0x00018014a936;
        }
    }
    *(int32_t *)(iVar25 + -0x130 + uVar26 * 0xc) = iVar32;
    *(int32_t *)(iVar25 + -0x134 + uVar26 * 0xc) = iVar32;
    *(undefined2 *)(iVar25 + -300 + uVar26 * 0xc) = 0;
code_r0x00018014a9b6:
    fVar51 = *(float *)puVar34;
    fVar45 = *(float *)(arg1 + 0x54) - (*pfVar43 - fVar51);
    fVar49 = *(float *)(arg1 + 0x5c);
    if (fVar45 <= *(float *)(arg1 + 0x5c)) {
        fVar49 = fVar45;
    }
    if (fVar49 <= 0.0) {
        fVar49 = 0.0;
    }
    *(float *)(arg1 + 0x5c) = fVar49;
    fVar50 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar51);
    fVar45 = *(float *)(arg1 + 0x60);
    if (fVar50 <= *(float *)(arg1 + 0x60)) {
        fVar45 = fVar50;
    }
    if (fVar45 <= 0.0) {
        fVar45 = 0.0;
    }
    *(float *)(arg1 + 0x60) = fVar45;
    if (fVar49 == fVar45) {
        *(undefined4 *)(arg1 + 0x68) = 0;
    } else {
        fVar54 = *(float *)(iVar38 + 0x12f8) * 70.0;
        fVar50 = *(float *)(arg1 + 0x68);
        if (*(float *)(arg1 + 0x68) <= fVar54) {
            fVar50 = fVar54;
        }
        fVar54 = (float)((uint32_t)(fVar45 - fVar49) & 0x7fffffff) / 0.3;
        if (fVar50 <= fVar54) {
            fVar50 = fVar54;
        }
        *(float *)(arg1 + 0x68) = fVar50;
        fVar54 = fVar45;
        if ((*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1) &&
           (*(float *)(arg1 + 100) <= *(float *)(iVar38 + 0x12f8) * 10.0)) {
            fVar50 = fVar50 * *(float *)(iVar38 + 0x48);
            if (fVar45 <= fVar49) {
                fVar54 = fVar49;
                if ((fVar45 < fVar49) && (fVar54 = fVar49 - fVar50, fVar54 <= fVar45)) {
                    fVar54 = fVar45;
                }
            } else {
                fVar54 = fVar50 + fVar49;
                if (fVar45 <= fVar54) {
                    fVar54 = fVar45;
                }
            }
        }
        *(float *)(arg1 + 0x5c) = fVar54;
    }
    uVar18 = *puVar34;
    *(float *)(arg1 + 0x6c) = fVar51 + var_108h._4_4_ + var_100h[1];
    *(float *)(arg1 + 0x70) = (*(float *)(arg1 + 0x40) - var_e8h._4_4_) - var_ech;
    iVar38 = *(int64_t *)(iVar38 + 0x15e0);
    *(undefined8 *)(iVar38 + 0x158) = uVar18;
    var_128h = CONCAT44(*(float *)(arg1 + 0x44) - *(float *)(arg1 + 0x3c), *(undefined4 *)(arg1 + 0x54));
    func_0x00018010bbf0(&var_128h);
    fVar49 = *(float *)(arg1 + 0x58) + *(float *)puVar34;
    fVar51 = *(float *)(iVar38 + 0x178);
    if (*(float *)(iVar38 + 0x178) <= fVar49) {
        fVar51 = fVar49;
    }
    *(float *)(iVar38 + 0x178) = fVar51;
    func_0x000180459870(var_d8h ^ (uint64_t)auStackY_198);
    return;
code_r0x000180149c5c:
    uVar22 = (int32_t)uVar26 + 1;
    uVar26 = (uint64_t)uVar22;
    if (iVar39 <= (int32_t)uVar22) goto code_r0x000180149c63;
    goto code_r0x000180149c50;
}

// ============================================================
// Function: FUN_180149c2e
// Address: 0x180149c2e
// Size: 359 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_144h
// WARNING: Variable defined which should be unmapped: var_178h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180148fa0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined auVar3 [16];
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    bool bVar13;
    bool bVar14;
    char cVar15;
    uint8_t uVar16;
    int32_t iVar17;
    undefined8 uVar18;
    int64_t iVar19;
    int32_t *piVar20;
    uint32_t uVar21;
    uint32_t uVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    uint64_t uVar26;
    undefined4 *puVar27;
    uint32_t uVar28;
    undefined4 *puVar29;
    uint32_t *puVar30;
    float *pfVar31;
    int32_t iVar32;
    uint32_t *puVar33;
    undefined8 *puVar34;
    uint32_t uVar35;
    int32_t iVar36;
    undefined4 *puVar37;
    int64_t iVar38;
    int32_t iVar39;
    char *pcVar40;
    int32_t iVar41;
    int64_t *piVar42;
    float *pfVar43;
    bool bVar44;
    float fVar45;
    float fVar46;
    float fVar47;
    float fVar48;
    float fVar49;
    float fVar50;
    float fVar51;
    undefined auVar52 [16];
    undefined auVar53 [16];
    float fVar54;
    undefined4 unaff_XMM12_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    float fVar55;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_198 [32];
    int64_t var_178h;
    undefined4 in_stack_fffffffffffffe98;
    undefined4 in_stack_fffffffffffffe9c;
    undefined4 uVar56;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int32_t var_148h;
    int64_t var_144h;
    undefined4 uStack_13c;
    undefined4 uVar57;
    undefined4 in_stack_fffffffffffffecc;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    float var_100h [2];
    int64_t var_f8h;
    float var_f0h;
    float var_ech;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar38 = *(int64_t *)0x180781f28;
    var_d8h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_198;
    fVar51 = *(float *)(arg1 + 0x48);
    var_118h = arg1 + 0x38;
    *(undefined *)(arg1 + 0x83) = 0;
    fVar49 = *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38);
    var_110h = arg1 + 0x40;
    uVar22 = *(uint32_t *)(arg1 + 8);
    *(float *)(arg1 + 0x48) = fVar49;
    uVar56 = CONCAT31((unkint3)((uint32_t)in_stack_fffffffffffffe9c >> 8), fVar49 < fVar51);
    auVar3._4_4_ = unaff_XMM12_Dc;
    auVar3._0_4_ = unaff_XMM12_Db;
    auVar3._8_4_ = unaff_XMM12_Dd;
    auVar3._12_4_ = 0;
    _var_98h = auVar3 << 0x20;
    bVar44 = false;
    uVar28 = 0;
    uVar35 = 0;
    _var_108h = ZEXT816(0);
    _var_f8h = ZEXT816(0);
    _var_e8h = ZEXT816(0);
    bVar13 = false;
    if (0 < (int32_t)uVar22) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)(arg1 + 0x10);
            iVar23 = (int64_t)(int32_t)uVar35 * 0x38;
            if ((*(int32_t *)(iVar23 + 0x10 + iVar25) < *(int32_t *)(arg1 + 0x34)) ||
               (*(char *)(iVar23 + 0x30 + iVar25) != '\0')) {
                if (*(int32_t *)(arg1 + 0x2c) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x2c) = 0;
                }
                if (*(int32_t *)(arg1 + 0x20) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x20) = 0;
                }
                if (*(int32_t *)(arg1 + 0x24) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x24) = 0;
                }
            } else {
                if (uVar28 != uVar35) {
                    auVar3 = *(undefined (*) [16])(iVar23 + 0x10 + iVar25);
                    puVar37 = (undefined4 *)(iVar23 + 0x20 + iVar25);
                    uVar57 = *puVar37;
                    uVar1 = puVar37[1];
                    uVar2 = puVar37[2];
                    uVar4 = puVar37[3];
                    uVar18 = *(undefined8 *)(iVar23 + 0x30 + iVar25);
                    iVar24 = (int64_t)(int32_t)uVar28 * 0x38;
                    *(undefined (*) [16])(iVar24 + iVar25) = *(undefined (*) [16])(iVar23 + iVar25);
                    *(undefined (*) [16])(iVar24 + 0x10 + iVar25) = auVar3;
                    puVar37 = (undefined4 *)(iVar24 + 0x20 + iVar25);
                    *puVar37 = uVar57;
                    puVar37[1] = uVar1;
                    puVar37[2] = uVar2;
                    puVar37[3] = uVar4;
                    *(undefined8 *)(iVar24 + 0x30 + iVar25) = uVar18;
                }
                iVar23 = (int64_t)(int32_t)uVar28 * 0x38;
                iVar25 = *(int64_t *)(arg1 + 0x10);
                uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                *(int16_t *)(iVar23 + 0x2e + iVar25) = (int16_t)uVar28;
                if ((uVar22 & 0x40) == 0) {
                    uVar26 = (uint64_t)(((uVar22 & 0x80) != 0) + 1);
                } else {
                    uVar26 = 0;
                }
                if (0 < (int32_t)uVar28) {
                    uVar22 = *(uint32_t *)(*(int64_t *)(arg1 + 0x10) + -0x34 + iVar23);
                    cVar15 = '\0';
                    if ((uVar22 & 0x40) == 0) {
                        cVar15 = ((uVar22 & 0x80) != 0) + '\x01';
                    }
                    if ((int32_t)uVar26 == 0) {
                        if (cVar15 == '\0') goto code_r0x000180149140;
                        bVar44 = true;
                    }
                    if (cVar15 == '\x02') {
                        if ((int32_t)uVar26 != 2) {
                            bVar44 = true;
                        }
                        var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                        uVar28 = uVar28 + 1;
                        goto code_r0x000180149172;
                    }
                }
code_r0x000180149140:
                var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                uVar28 = uVar28 + 1;
            }
code_r0x000180149172:
            uVar22 = *(uint32_t *)(arg1 + 8);
            uVar35 = uVar35 + 1;
            bVar13 = bVar44;
        } while ((int32_t)uVar35 < (int32_t)uVar22);
    }
    uVar35 = 8;
    var_128h = arg1;
    if (uVar22 != uVar28) {
        iVar32 = *(int32_t *)(arg1 + 0xc);
        if (iVar32 < (int32_t)uVar28) {
            uVar22 = uVar35;
            if (iVar32 != 0) {
                uVar22 = iVar32 / 2 + iVar32;
            }
            uVar21 = uVar28;
            if ((int32_t)uVar28 < (int32_t)uVar22) {
                uVar21 = uVar22;
            }
            func_0x00018011f970(arg1 + 8, uVar21);
        }
        *(uint32_t *)(arg1 + 8) = uVar28;
        uVar22 = uVar28;
    }
    piVar42 = (int64_t *)(arg1 + 0x10);
    if ((bVar44) && (1 < uVar22)) {
        fcn.18046f0d0(CONCAT44(uVar56, in_stack_fffffffffffffe98));
    }
    fVar51 = *(float *)(iVar38 + 0xdf4);
    if (((int32_t)var_108h < 1) || (var_100h[1] = fVar51, (int32_t)((int32_t)var_e8h + (uint32_t)var_f8h) < 1)) {
        var_100h[1] = 0.0;
    }
    if (((int32_t)(uint32_t)var_f8h < 1) || (var_ech = fVar51, (int32_t)var_e8h < 1)) {
        var_ech = 0.0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x28);
    uVar21 = 0;
    uVar28 = 0;
    if (uVar22 != 0) {
        *(undefined4 *)(arg1 + 0x28) = 0;
        uVar28 = uVar22;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x24);
    if (uVar22 != 0) {
        *(uint32_t *)(arg1 + 0x20) = uVar22;
        *(undefined4 *)(arg1 + 0x24) = 0;
        uVar28 = uVar22;
    }
    if (*(int32_t *)(arg1 + 0x7c) != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (iVar32 < 1) {
code_r0x00018014939d:
            *(undefined4 *)(arg1 + 0x7c) = 0;
        } else {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar21 * 0x38;
                puVar37 = (undefined4 *)(uVar26 + iVar25);
                if (*(int32_t *)(uVar26 + iVar25) == *(int32_t *)(arg1 + 0x7c)) {
                    if ((puVar37[1] & 0x20) == 0) {
                        iVar41 = (int32_t)(uVar26 / 0x38) + (int32_t)*(int16_t *)(arg1 + 0x80);
                        if ((-1 < iVar41) && (iVar41 < iVar32)) {
                            puVar29 = (undefined4 *)((int64_t)iVar41 * 0x38 + iVar25);
                            if (((puVar29[1] & 0x20) == 0) && (((puVar29[1] ^ puVar37[1]) & 0xc0) == 0)) {
                                uVar18 = *(undefined8 *)(puVar37 + 0xc);
                                uVar57 = *puVar37;
                                uVar1 = puVar37[1];
                                uVar2 = puVar37[2];
                                uVar4 = puVar37[3];
                                uVar5 = puVar37[4];
                                uVar6 = puVar37[5];
                                uVar7 = puVar37[6];
                                uVar8 = puVar37[7];
                                uVar9 = puVar37[8];
                                uVar10 = puVar37[9];
                                uVar11 = puVar37[10];
                                uVar12 = puVar37[0xb];
                                if (*(int16_t *)(arg1 + 0x80) < 1) {
                                    puVar37 = puVar29 + 0xe;
                                    puVar27 = puVar29;
                                } else {
                                    puVar27 = puVar37 + 0xe;
                                }
                                fcn.180498030(puVar37, puVar27);
                                *puVar29 = uVar57;
                                puVar29[1] = uVar1;
                                puVar29[2] = uVar2;
                                puVar29[3] = uVar4;
                                puVar29[4] = uVar5;
                                puVar29[5] = uVar6;
                                puVar29[6] = uVar7;
                                puVar29[7] = uVar8;
                                puVar29[8] = uVar9;
                                puVar29[9] = uVar10;
                                puVar29[10] = uVar11;
                                puVar29[0xb] = uVar12;
                                *(undefined8 *)(puVar29 + 0xc) = uVar18;
                                if (((*(uint32_t *)(arg1 + 0x18) & 0x400000) != 0) &&
                                   (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)) {
                                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) =
                                         *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
                                }
                                if (*(uint32_t *)(arg1 + 0x7c) == *(uint32_t *)(arg1 + 0x20)) {
                                    uVar28 = *(uint32_t *)(arg1 + 0x7c);
                                }
                            }
                        }
                    }
                    goto code_r0x00018014939d;
                }
                uVar21 = uVar21 + 1;
            } while ((int32_t)uVar21 < iVar32);
            *(undefined4 *)(arg1 + 0x7c) = 0;
        }
    }
    iVar25 = *(int64_t *)0x180781f28;
    puVar33 = (uint32_t *)0x0;
    if ((*(uint8_t *)(arg1 + 0x18) & 4) != 0) {
        uVar57 = *(undefined4 *)(arg1 + 0x3c);
        var_148h = 0;
        fVar49 = *(float *)(*(int64_t *)0x180781f28 + 0xde0);
        iVar23 = *(int64_t *)0x180781f28 + 0x20c0;
        iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
        uVar1 = *(undefined4 *)(iVar24 + 0x158);
        uVar2 = *(undefined4 *)(iVar24 + 0x15c);
        *(float *)(iVar24 + 0x158) = *(float *)(arg1 + 0x38) - fVar49;
        *(undefined4 *)(iVar24 + 0x15c) = uVar57;
        *(float *)(arg1 + 0x38) = fVar49 + fVar45 + *(float *)(arg1 + 0x38);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        uVar57 = *(undefined4 *)(iVar25 + 0xed8);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        fVar49 = *(float *)(iVar25 + 0xedc);
        fcn.18011f2b0(iVar23, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar57;
            *(float *)(iVar25 + 0xedc) = fVar49 * 0.5;
        }
        iVar25 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        uVar57 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x102c);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar25 + 0x1020) = 0;
            *(undefined8 *)(iVar25 + 0x1028) = 0;
        }
        cVar15 = func_0x00018013d0a0();
        fcn.1800f6770(2);
        if (cVar15 != '\0') {
            iVar32 = 0;
            if (0 < *(int32_t *)(arg1 + 8)) {
                do {
                    puVar30 = (uint32_t *)((int64_t)iVar32 * 0x38 + *piVar42);
                    if (((puVar30[1] & 0x200000) == 0) &&
                       (cVar15 = fcn.180146c70(CONCAT44(uStack_13c, var_144h._4_4_), 
                                               CONCAT44(in_stack_fffffffffffffecc, uVar57)), cVar15 != '\0')) {
                        puVar33 = puVar30;
                    }
                    iVar32 = iVar32 + 1;
                } while (iVar32 < *(int32_t *)(arg1 + 8));
            }
            iVar25 = *(int64_t *)0x180781f28;
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) + -1;
            iVar32 = func_0x000180498f10(*(undefined8 *)(*(int64_t *)(iVar25 + 0x15e0) + 8), &var_148h);
            if (iVar32 == 0) {
                func_0x00018010d5c0();
            } else if (*(code **)(iVar25 + 0x2a40) != (code *)0x0) {
                (**(code **)(iVar25 + 0x2a40))(iVar25, *(undefined8 *)(iVar25 + 0x2a48));
            }
        }
        *(undefined4 *)(iVar24 + 0x158) = uVar1;
        *(undefined4 *)(iVar24 + 0x15c) = uVar2;
        if (puVar33 != (uint32_t *)0x0) {
            uVar28 = *puVar33;
            *(uint32_t *)(arg1 + 0x20) = uVar28;
        }
    }
    iVar41 = 1;
    uVar22 = *(uint32_t *)(arg1 + 8);
    var_144h._0_4_ = (int32_t)var_e8h + (int32_t)var_108h;
    var_148h = 0;
    iVar32 = *(int32_t *)(iVar38 + 0x257c);
    var_144h._4_4_ = (int32_t)var_108h;
    if (iVar32 < (int32_t)uVar22) {
        if (iVar32 != 0) {
            uVar35 = iVar32 / 2 + iVar32;
        }
        uVar21 = uVar22;
        if ((int32_t)uVar22 < (int32_t)uVar35) {
            uVar21 = uVar35;
        }
        if (iVar32 < (int32_t)uVar21) {
            uVar18 = fcn.18046d050((int64_t)(int32_t)uVar21 * 0xc);
            if (*(int64_t *)(iVar38 + 0x2580) != 0) {
                fcn.180498030(uVar18);
                fcn.180460d90(*(undefined8 *)(iVar38 + 0x2580));
            }
            *(undefined8 *)(iVar38 + 0x2580) = uVar18;
            *(uint32_t *)(iVar38 + 0x257c) = uVar21;
        }
    }
    *(uint32_t *)(iVar38 + 0x2578) = uVar22;
    if ((*(uint8_t *)(arg1 + 0x18) & 0x80) == 0) {
        fVar49 = 1.0;
    } else {
        fVar49 = *(float *)(iVar38 + 0xe40);
    }
    iVar32 = *(int32_t *)(arg1 + 8);
    iVar39 = 0;
    var_130h = 0;
    bVar44 = false;
    uVar22 = 0xffffffff;
    bVar13 = false;
    if (0 < iVar32) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)0x180781f28;
            puVar33 = (uint32_t *)((int64_t)iVar39 * 0x38 + *piVar42);
            if (((var_130h == 0) || (*(int32_t *)(var_130h + 0x14) < (int32_t)puVar33[5])) &&
               ((puVar33[1] & 0x200000) == 0)) {
                var_130h = (int64_t)puVar33;
            }
            uVar35 = *puVar33;
            if (uVar35 == *(uint32_t *)(arg1 + 0x20)) {
                bVar44 = true;
            }
            if ((uVar28 == 0) && (*(uint32_t *)(iVar38 + 0x23a4) == uVar35)) {
                uVar28 = uVar35;
            }
            auVar52 = ZEXT416(puVar33[9]);
            if ((float)puVar33[9] < 0.0) {
                uVar35 = puVar33[1];
                var_178h._0_4_ = 0xbf800000;
                fcn.1800fe0a0(CONCAT44(var_178h._4_4_, 0xbf800000), SUB168(_var_98h, 8));
                fVar45 = *(float *)(iVar25 + 0xddc);
                if ((uVar35 & 0x100001) == 0x100000) {
                    fVar50 = fVar45 + 1.0;
                } else {
                    fVar50 = *(float *)(iVar25 + 0x12f8) + *(float *)(iVar25 + 0xdf4) + fVar45;
                }
                fVar50 = fVar50 + var_120h + fVar45;
                auVar52 = ZEXT416((uint32_t)fVar50);
                fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 20.0;
                if (fVar45 <= fVar50) {
                    auVar52 = ZEXT416((uint32_t)fVar45);
                }
            }
            uVar35 = puVar33[1];
            puVar33[8] = (uint32_t)auVar52._0_4_;
            if ((uVar35 >> 0x15 & 1) == 0) {
                if (auVar52._0_4_ <= *(float *)(iVar38 + 0xe3c)) {
                    auVar52._0_4_ = *(float *)(iVar38 + 0xe3c);
                }
                puVar33[8] = auVar52._0_4_;
            }
            if ((uVar35 & 0x40) == 0) {
                uVar35 = ((uVar35 & 0x80) != 0) + 1;
            } else {
                uVar35 = 0;
            }
            uVar26 = (uint64_t)uVar35;
            if (uVar35 == uVar22) {
                fVar50 = auVar52._0_4_ + fVar51;
                fVar45 = fVar51;
            } else {
                fVar50 = auVar52._0_4_ + 0.0;
                fVar45 = 0.0;
            }
            var_100h[uVar26 * 4 + -1] = fVar50 + var_100h[uVar26 * 4 + -1];
            fVar50 = (float)puVar33[8];
            if (fVar49 <= (float)puVar33[8]) {
                fVar50 = fVar49;
            }
            var_100h[uVar26 * 4] = fVar50 + fVar45 + var_100h[uVar26 * 4];
            iVar23 = (int64_t)(&var_148h)[uVar26];
            (&var_148h)[uVar26] = (&var_148h)[uVar26] + 1;
            iVar25 = *(int64_t *)(iVar38 + 0x2580);
            *(int32_t *)(iVar25 + iVar23 * 0xc) = iVar39;
            iVar39 = iVar39 + 1;
            uVar22 = puVar33[8];
            *(uint32_t *)(iVar25 + 8 + iVar23 * 0xc) = uVar22;
            *(uint32_t *)(iVar25 + 4 + iVar23 * 0xc) = uVar22;
            fVar45 = (float)puVar33[8];
            if (fVar45 <= 1.0) {
                fVar45 = 1.0;
            }
            puVar33[7] = (uint32_t)fVar45;
            iVar32 = *(int32_t *)(arg1 + 8);
            uVar22 = uVar35;
            bVar13 = bVar44;
        } while (iVar39 < iVar32);
    }
    uVar22 = *(uint32_t *)(arg1 + 0x18);
    *(float *)(arg1 + 0x58) = var_100h[1] + var_108h._4_4_ + 0.0 + var_f8h._4_4_ + var_ech + var_e8h._4_4_ + var_dch;
    iVar25 = *(int64_t *)0x180781f28;
    if (((uVar22 & 0x200) == 0) && (-1 < (char)uVar22)) {
        bVar14 = false;
code_r0x00018014992e:
        bVar13 = bVar14;
        fVar51 = var_e0h + var_dch + var_100h[0] + var_100h[1] + 0.0 + var_f0h + var_ech;
    } else {
        bVar13 = true;
        bVar14 = true;
        if ((uVar22 & 0x200) == 0) goto code_r0x00018014992e;
        fVar51 = *(float *)(arg1 + 0x54);
    }
    if ((((fVar51 <= *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38)) || (iVar32 < 2)) || ((uVar22 & 0x10) != 0)) ||
       (!bVar13)) {
        *(undefined *)(arg1 + 0x86) = 0;
    } else {
        *(undefined *)(arg1 + 0x86) = 1;
        var_148h = 0;
        fVar51 = *(float *)(iVar25 + 0x12f8);
        iVar23 = *(int64_t *)(iVar25 + 0x15e0);
        fVar54 = fVar51 - 2.0;
        fVar45 = *(float *)(iVar25 + 0xde0);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        uVar57 = *(undefined4 *)(iVar23 + 0x158);
        uVar1 = *(undefined4 *)(iVar25 + 0xed8);
        fVar50 = *(float *)(iVar25 + 0xedc);
        fVar55 = fVar54 + fVar54;
        var_120h = *(float *)(iVar23 + 0x15c);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        fcn.18011f2b0(iVar25 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar1;
            *(float *)(iVar25 + 0xedc) = fVar50 * 0.5;
        }
        iVar24 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar24 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar24 + 0x1020) = 0;
            *(undefined8 *)(iVar24 + 0x1028) = 0;
        }
        iVar24 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 10;
        piVar20 = (int32_t *)(iVar24 + 0x2100);
        iVar32 = *(int32_t *)(iVar24 + 0x2104);
        uVar1 = *(undefined4 *)(iVar24 + 0x1f78);
        if (*piVar20 == iVar32) {
            iVar39 = *piVar20 + 1;
            if (iVar32 == 0) {
                iVar32 = 8;
            } else {
                iVar32 = iVar32 / 2 + iVar32;
            }
            if (iVar39 < iVar32) {
                iVar39 = iVar32;
            }
            fcn.18011fb10(piVar20, iVar39);
        }
        *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + (int64_t)*piVar20 * 4) = uVar1;
        *piVar20 = *piVar20 + 1;
        uVar1 = *(undefined4 *)(iVar25 + 0xa8);
        uVar2 = *(undefined4 *)(iVar25 + 0xac);
        *(undefined4 *)(iVar25 + 0xa8) = 0x3e800000;
        *(undefined4 *)(iVar25 + 0xac) = 0x3e4ccccd;
        fVar46 = *(float *)(arg1 + 0x40) - fVar55;
        fVar50 = *(float *)(arg1 + 0x38);
        if (*(float *)(arg1 + 0x38) <= fVar46) {
            fVar50 = fVar46;
        }
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50;
        uVar16 = func_0x00018013a9f0(0x180645ba0, 0, CONCAT44(fVar45 + fVar45 + fVar51, fVar54));
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50 + fVar54;
        cVar15 = func_0x00018013a9f0(0x180645ba4, 1);
        iVar24 = *(int64_t *)0x180781f28;
        if (cVar15 == '\0') {
            iVar32 = (uVar16 ^ 1) - 1;
        } else {
            iVar32 = 1;
        }
        iVar39 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
        if (iVar39 < 2) {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48));
            }
        } else {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar39 + -1;
            *(undefined4 *)(iVar24 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + -8 + (int64_t)iVar39 * 4)
            ;
        }
        fcn.1800f6770();
        *(undefined4 *)(iVar25 + 0xac) = uVar2;
        *(undefined4 *)(iVar25 + 0xa8) = uVar1;
        if (iVar32 == 0) {
            puVar33 = (uint32_t *)0x0;
code_r0x000180149cf6:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
            if ((puVar33 != (uint32_t *)0x0) && (uVar28 = *puVar33, (puVar33[1] & 0x200000) == 0)) {
                *(uint32_t *)(arg1 + 0x20) = uVar28;
            }
        } else {
            if ((*(int32_t *)(arg1 + 0x20) != 0) && (iVar39 = *(int32_t *)(arg1 + 8), 0 < iVar39)) {
                uVar26 = 0;
                iVar25 = *piVar42;
code_r0x000180149c50:
                if (*(int32_t *)(uVar26 * 0x38 + iVar25) != *(int32_t *)(arg1 + 0x20)) goto code_r0x000180149c5c;
                uVar26 = (uVar26 * 0x38) / 0x38;
                iVar36 = (int32_t)uVar26 + iVar32;
                do {
                    if ((iVar36 < 0) || (iVar17 = iVar36, iVar39 <= iVar36)) {
                        iVar17 = (int32_t)uVar26;
                    }
                    puVar33 = (uint32_t *)((int64_t)iVar17 * 0x38 + iVar25);
                } while ((((*(uint32_t *)(iVar25 + 4 + (int64_t)iVar17 * 0x38) & 0x200000) != 0) &&
                         (iVar36 = iVar36 + iVar32, -1 < iVar36)) &&
                        (uVar26 = (uint64_t)(uint32_t)((int32_t)uVar26 + iVar32), iVar36 < iVar39));
                goto code_r0x000180149cf6;
            }
code_r0x000180149c63:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
        }
    }
    pfVar43 = (float *)(arg1 + 0x40);
    pcVar40 = (char *)(arg1 + 0x86);
    puVar34 = (undefined8 *)(arg1 + 0x38);
    if ((uVar28 == 0) && ((char)uVar56 != '\0')) {
        uVar28 = *(uint32_t *)(arg1 + 0x20);
    }
    fVar51 = *pfVar43 - *(float *)puVar34;
    fVar45 = var_e8h._4_4_ + var_dch + var_108h._4_4_ + var_100h[1];
    if (fVar51 <= fVar45) {
        fVar50 = fVar45 - fVar51;
    } else {
        fVar50 = (var_f8h._4_4_ + var_ech) - ((fVar51 - (var_108h._4_4_ + var_100h[1])) - (var_e8h._4_4_ + var_dch));
        if (fVar50 <= 0.0) {
            fVar50 = 0.0;
        }
    }
    if (1.0 <= fVar50) {
        if ((*(uint32_t *)(arg1 + 0x18) & 0x180) == 0) {
            if (fVar45 < fVar51) goto code_r0x00018014a4db;
code_r0x000180149e0c:
            uVar22 = (int32_t)var_e8h + (int32_t)var_108h;
            if (fVar51 <= fVar45) {
                iVar32 = 0;
            } else {
                iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            }
        } else {
            if (fVar51 <= fVar45) goto code_r0x000180149e0c;
            iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            uVar22 = (uint32_t)var_f8h;
        }
        iVar25 = *(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc;
        if (uVar22 == 1) {
            if (0.0 <= *(float *)(iVar25 + 4)) {
                fVar50 = *(float *)(iVar25 + 4) - fVar50;
                if (fVar50 <= fVar49) {
                    fVar50 = fVar49;
                }
                *(float *)(iVar25 + 4) = fVar50;
            }
        } else {
            if (1 < uVar22) {
                fcn.18046f0d0(CONCAT44(uVar56, uVar28));
            }
            while ((0.001 < fVar50 && (iVar41 < (int32_t)uVar22))) {
                fVar51 = *(float *)(iVar25 + 4);
                do {
                    fVar45 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                    if (fVar45 < fVar51) {
                        if (0.0 <= fVar45) {
                            fVar45 = fVar51 - fVar45;
                            goto code_r0x000180149ee6;
                        }
                        break;
                    }
                    iVar41 = iVar41 + 1;
                } while (iVar41 < (int32_t)uVar22);
                fVar45 = fVar51 - 1.0;
code_r0x000180149ee6:
                fVar54 = fVar51 - fVar49;
                if (fVar45 <= fVar51 - fVar49) {
                    fVar54 = fVar45;
                }
                if (fVar54 <= 0.0) break;
                iVar39 = 0;
                fVar51 = fVar50 / (float)iVar41;
                if (fVar54 <= fVar50 / (float)iVar41) {
                    fVar51 = fVar54;
                }
                if (3 < iVar41) {
                    do {
                        iVar23 = (int64_t)iVar39;
                        iVar39 = iVar39 + 4;
                        fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar55 = fVar45 - fVar49;
                        fVar54 = fVar51;
                        if (fVar55 <= fVar51) {
                            fVar54 = fVar55;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                        fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar46 = fVar45 - fVar49;
                        fVar55 = fVar51;
                        if (fVar46 <= fVar51) {
                            fVar55 = fVar46;
                        }
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar45 - fVar55;
                        fVar45 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar47 = fVar45 - fVar49;
                        fVar46 = fVar51;
                        if (fVar47 <= fVar51) {
                            fVar46 = fVar47;
                        }
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar45 - fVar46;
                        fVar45 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar48 = fVar45 - fVar49;
                        fVar47 = fVar51;
                        if (fVar48 <= fVar51) {
                            fVar47 = fVar48;
                        }
                        fVar50 = (((fVar50 - fVar54) - fVar55) - fVar46) - fVar47;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar45 - fVar47;
                    } while (iVar39 < iVar41 + -3);
                }
                while (iVar39 < iVar41) {
                    iVar23 = (int64_t)iVar39;
                    iVar39 = iVar39 + 1;
                    fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar55 = fVar45 - fVar49;
                    fVar54 = fVar51;
                    if (fVar55 <= fVar51) {
                        fVar54 = fVar55;
                    }
                    fVar50 = fVar50 - fVar54;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                }
            }
            iVar41 = 0;
            fVar51 = 0.0;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 4;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar48 = (float)(int32_t)fVar49;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar48;
                    fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                    fVar46 = (float)(int32_t)fVar45;
                    *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar46;
                    fVar50 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                    fVar55 = (float)(int32_t)fVar50;
                    *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar55;
                    fVar54 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                    fVar47 = (float)(int32_t)fVar54;
                    *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar47;
                    fVar51 = (fVar49 - fVar48) + fVar51 + (fVar45 - fVar46) + (fVar50 - fVar55) + (fVar54 - fVar47);
                } while (iVar41 < (int32_t)(uVar22 - 3));
            }
            for (; iVar41 < (int32_t)uVar22; iVar41 = iVar41 + 1) {
                fVar49 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                fVar45 = (float)(int32_t)fVar49;
                *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc) = fVar45;
                fVar51 = fVar51 + (fVar49 - fVar45);
            }
            while (0.0 < fVar51) {
                iVar41 = 0;
                if (3 < (int32_t)uVar22) {
                    do {
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar23 = (int64_t)iVar41;
                        fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 - fVar45 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar50 = *(float *)(iVar25 + 0x14 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar50) {
                            fVar50 = 1.0;
                        }
                        fVar51 = (fVar51 - fVar45) - fVar50;
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar49 + fVar50;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x20 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar41 = iVar41 + 4;
                        fVar49 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x2c + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar49 + fVar45;
                    } while (iVar41 < (int32_t)(uVar22 - 3));
                }
                while (iVar41 < (int32_t)uVar22) {
                    if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 1;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                    if (1.0 <= fVar45) {
                        fVar45 = 1.0;
                    }
                    fVar51 = fVar51 - fVar45;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                }
            }
        }
code_r0x00018014a22a:
        iVar41 = iVar32 + uVar22;
        if (iVar32 < iVar41) {
            arg1 = var_128h;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar25 = (int64_t)iVar32;
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x10 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0xc + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x1c + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x18 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x28 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar25 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x24 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar25 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar24 = 0;
                        }
                        var_100h[iVar24 * 4 + -1] =
                             var_100h[iVar24 * 4 + -1] - (*(float *)(iVar25 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar25 + 0x1c + iVar23) = fVar49;
                    }
                    iVar32 = iVar32 + 4;
                } while (iVar32 < iVar41 + -3);
                if (iVar41 <= iVar32) goto code_r0x00018014a4d3;
            }
            do {
                fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + (int64_t)iVar32 * 0xc);
                if (0.0 <= fVar51) {
                    iVar25 = *piVar42;
                    fVar49 = 1.0;
                    if (1.0 <= fVar51) {
                        fVar49 = fVar51;
                    }
                    iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc) * 0x38;
                    uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                    if ((uVar22 & 0x40) == 0) {
                        iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                    } else {
                        iVar24 = 0;
                    }
                    var_100h[iVar24 * 4 + -1] =
                         var_100h[iVar24 * 4 + -1] - (*(float *)(iVar23 + 0x1c + iVar25) - fVar49);
                    *(float *)(iVar23 + 0x1c + iVar25) = fVar49;
                }
                iVar32 = iVar32 + 1;
                puVar34 = (undefined8 *)var_118h;
                pfVar43 = (float *)var_110h;
            } while (iVar32 < iVar41);
        } else {
code_r0x00018014a4d3:
            puVar34 = (undefined8 *)(arg1 + 0x38);
            pfVar43 = (float *)(arg1 + 0x40);
        }
    }
code_r0x00018014a4db:
    uVar35 = 0;
    auVar53 = ZEXT816(0);
    *(undefined4 *)(arg1 + 0x54) = 0;
    uVar22 = uVar35;
    if (0 < (int32_t)var_108h) {
        do {
            iVar25 = *piVar42;
            iVar23 = (int64_t)(int32_t)uVar22 * 0x38;
            *(float *)(iVar23 + 0x18 + iVar25) = auVar53._0_4_;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_108h + -1) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            auVar53._0_4_ = auVar53._0_4_ + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_108h);
    }
    fVar49 = auVar53._0_4_ + var_100h[1];
    fVar51 = var_100h[1] + var_108h._4_4_;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    uVar22 = uVar35;
    if (0 < (int32_t)(uint32_t)var_f8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar49;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)((uint32_t)var_f8h + -1)) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar49 = fVar49 + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)(uint32_t)var_f8h);
    }
    fVar51 = var_f8h._4_4_ + var_ech;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    fVar45 = (*(float *)(arg1 + 0x40) - *(float *)puVar34) - var_e8h._4_4_;
    fVar51 = 0.0;
    if (0.0 <= fVar45) {
        fVar51 = fVar45;
    }
    if (var_ech + fVar49 <= fVar51) {
        fVar51 = var_ech + fVar49;
    }
    uVar22 = uVar35;
    if (0 < (int32_t)var_e8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h + (uint32_t)var_f8h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar51;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_e8h + -1) {
                fVar49 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar49 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar51 = fVar51 + fVar49 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_e8h);
    }
    fVar51 = var_e8h._4_4_ + var_dch;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    func_0x00018011f640(arg1 + 0xa0, 0);
    if ((!bVar44) && (*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1)) {
        *(undefined4 *)(arg1 + 0x20) = 0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x20);
    if (((*(uint32_t *)(arg1 + 0x20) == 0) && (uVar22 = uVar35, *(int32_t *)(arg1 + 0x24) == 0)) && (var_130h != 0)) {
        uVar28 = *(uint32_t *)var_130h;
        *(uint32_t *)(arg1 + 0x20) = uVar28;
        uVar22 = uVar28;
    }
    *(uint32_t *)(arg1 + 0x2c) = uVar22;
    *(undefined *)(arg1 + 0x84) = 0;
    iVar25 = *(int64_t *)(iVar38 + 0x23c0);
    if (((iVar25 != 0) && (*(int64_t *)(iVar25 + 0x4c0) != 0)) &&
       (*(int64_t *)(*(int64_t *)(iVar25 + 0x4c0) + 0x40) == arg1)) {
        uVar28 = *(uint32_t *)(iVar25 + 200);
        *(uint32_t *)(arg1 + 0x2c) = uVar28;
    }
    if (uVar28 != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (0 < iVar32) {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar35 * 0x38;
                if (*(uint32_t *)(uVar26 + iVar25) == uVar28) {
                    if ((*(uint8_t *)(uVar26 + 4 + iVar25) & 0xc0) != 0) break;
                    fVar51 = *pfVar43;
                    fVar49 = *(float *)puVar34;
                    fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
                    iVar41 = (int32_t)(uVar26 / 0x38);
                    if ((int32_t)var_108h + -1 < iVar41) {
                        fVar50 = (float)((uint32_t)fVar45 ^ 0x80000000);
                    } else {
                        fVar50 = 0.0;
                    }
                    fVar54 = *(float *)(uVar26 + 0x18 + iVar25) - var_108h._4_4_;
                    fVar50 = fVar54 + fVar50;
                    if (iVar32 - (int32_t)var_e8h <= iVar41 + 1) {
                        fVar45 = 1.0;
                    }
                    fVar55 = *(float *)(uVar26 + 0x1c + iVar25);
                    *(undefined4 *)(arg1 + 100) = 0;
                    fVar45 = fVar54 + fVar55 + fVar45;
                    if (*(float *)(arg1 + 0x60) <= fVar50) {
                        fVar51 = (((fVar51 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech;
                        if (fVar45 - fVar50 < fVar51) {
                            if (*(float *)(arg1 + 0x60) < fVar45 - fVar51) {
                                *(float *)(arg1 + 0x60) = fVar45 - fVar51;
                                fVar51 = (fVar50 - fVar51) - *(float *)(arg1 + 0x5c);
                                if (fVar51 <= 0.0) {
                                    fVar51 = 0.0;
                                }
                                *(float *)(arg1 + 100) = fVar51;
                            }
                            break;
                        }
                    }
                    fVar45 = *(float *)(arg1 + 0x5c) - fVar45;
                    *(float *)(arg1 + 0x60) = fVar50;
                    if (fVar45 <= 0.0) {
                        fVar45 = 0.0;
                    }
                    *(float *)(arg1 + 100) = fVar45;
                    break;
                }
                uVar35 = uVar35 + 1;
            } while ((int32_t)uVar35 < iVar32);
        }
        goto code_r0x00018014a9b6;
    }
    if ((*pcVar40 == '\0') || (cVar15 = func_0x000180108120(puVar34, pfVar43, 1), cVar15 == '\0'))
    goto code_r0x00018014a9b6;
    iVar25 = *(int64_t *)(iVar38 + 0x15e0);
    if (((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) != 0) &&
        ((((iVar23 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) + 0x428), iVar23 != 0 &&
           (*(char *)(iVar23 + 0x10a) != '\0')) && (iVar23 != *(int64_t *)(iVar25 + 0x428))) &&
         (((*(uint32_t *)(iVar23 + 0x14) >> 0x1b & 1) != 0 || ((*(uint32_t *)(iVar23 + 0x14) >> 0x1a & 1) != 0)))))) &&
       (iVar24 = *(int64_t *)(iVar25 + 0x418), *(int64_t *)(iVar24 + 0x418) != iVar23)) {
        do {
            if (iVar24 == iVar23) goto code_r0x00018014a8ae;
            iVar24 = *(int64_t *)(iVar24 + 0x410);
        } while (iVar24 != 0);
        goto code_r0x00018014a9b6;
    }
code_r0x00018014a8ae:
    if ((*(int64_t *)(iVar25 + 0x48) != *(int64_t *)(*(int64_t *)0x180781f28 + 0x2168)) &&
       ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) == 0 ||
        (*(int64_t *)(iVar25 + 0x428) != *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) + 0x428)))))
    goto code_r0x00018014a9b6;
    pfVar31 = (float *)(iVar38 + 0x128);
    if (*(char *)(iVar38 + 0xbaa) == '\0') {
        pfVar31 = (float *)(iVar38 + 300);
    }
    iVar32 = *(int32_t *)(arg1 + 0x1c);
    uVar26 = (uint64_t)((*(char *)(iVar38 + 0xbaa) != '\0') + 0x295);
    iVar25 = *(int64_t *)0x180781f28;
    piVar20 = (int32_t *)func_0x0001800f45c0(*(int64_t *)0x180781f28, uVar26);
    if (iVar32 == 0) {
        bVar44 = *(char *)(piVar20 + 2) == '\0';
code_r0x00018014a936:
        if (bVar44) {
code_r0x00018014a938:
            fVar51 = *pfVar31;
            if (fVar51 != 0.0) {
                fVar49 = *(float *)puVar34;
                fVar45 = *pfVar43;
                *(undefined4 *)(arg1 + 100) = 0;
                fVar51 = *(float *)(arg1 + 0x60) -
                         (((((fVar45 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech) * fVar51) / 3.0;
                fVar49 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar49);
                if (fVar49 <= fVar51) {
                    fVar51 = fVar49;
                }
                if (fVar51 <= 0.0) {
                    fVar51 = 0.0;
                }
                *(float *)(arg1 + 0x60) = fVar51;
            }
        }
    } else {
        if (*piVar20 == iVar32) goto code_r0x00018014a938;
        if (*(char *)(piVar20 + 2) == '\0') {
            bVar44 = *piVar20 == -1;
            goto code_r0x00018014a936;
        }
    }
    *(int32_t *)(iVar25 + -0x130 + uVar26 * 0xc) = iVar32;
    *(int32_t *)(iVar25 + -0x134 + uVar26 * 0xc) = iVar32;
    *(undefined2 *)(iVar25 + -300 + uVar26 * 0xc) = 0;
code_r0x00018014a9b6:
    fVar51 = *(float *)puVar34;
    fVar45 = *(float *)(arg1 + 0x54) - (*pfVar43 - fVar51);
    fVar49 = *(float *)(arg1 + 0x5c);
    if (fVar45 <= *(float *)(arg1 + 0x5c)) {
        fVar49 = fVar45;
    }
    if (fVar49 <= 0.0) {
        fVar49 = 0.0;
    }
    *(float *)(arg1 + 0x5c) = fVar49;
    fVar50 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar51);
    fVar45 = *(float *)(arg1 + 0x60);
    if (fVar50 <= *(float *)(arg1 + 0x60)) {
        fVar45 = fVar50;
    }
    if (fVar45 <= 0.0) {
        fVar45 = 0.0;
    }
    *(float *)(arg1 + 0x60) = fVar45;
    if (fVar49 == fVar45) {
        *(undefined4 *)(arg1 + 0x68) = 0;
    } else {
        fVar54 = *(float *)(iVar38 + 0x12f8) * 70.0;
        fVar50 = *(float *)(arg1 + 0x68);
        if (*(float *)(arg1 + 0x68) <= fVar54) {
            fVar50 = fVar54;
        }
        fVar54 = (float)((uint32_t)(fVar45 - fVar49) & 0x7fffffff) / 0.3;
        if (fVar50 <= fVar54) {
            fVar50 = fVar54;
        }
        *(float *)(arg1 + 0x68) = fVar50;
        fVar54 = fVar45;
        if ((*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1) &&
           (*(float *)(arg1 + 100) <= *(float *)(iVar38 + 0x12f8) * 10.0)) {
            fVar50 = fVar50 * *(float *)(iVar38 + 0x48);
            if (fVar45 <= fVar49) {
                fVar54 = fVar49;
                if ((fVar45 < fVar49) && (fVar54 = fVar49 - fVar50, fVar54 <= fVar45)) {
                    fVar54 = fVar45;
                }
            } else {
                fVar54 = fVar50 + fVar49;
                if (fVar45 <= fVar54) {
                    fVar54 = fVar45;
                }
            }
        }
        *(float *)(arg1 + 0x5c) = fVar54;
    }
    uVar18 = *puVar34;
    *(float *)(arg1 + 0x6c) = fVar51 + var_108h._4_4_ + var_100h[1];
    *(float *)(arg1 + 0x70) = (*(float *)(arg1 + 0x40) - var_e8h._4_4_) - var_ech;
    iVar38 = *(int64_t *)(iVar38 + 0x15e0);
    *(undefined8 *)(iVar38 + 0x158) = uVar18;
    var_128h = CONCAT44(*(float *)(arg1 + 0x44) - *(float *)(arg1 + 0x3c), *(undefined4 *)(arg1 + 0x54));
    func_0x00018010bbf0(&var_128h);
    fVar49 = *(float *)(arg1 + 0x58) + *(float *)puVar34;
    fVar51 = *(float *)(iVar38 + 0x178);
    if (*(float *)(iVar38 + 0x178) <= fVar49) {
        fVar51 = fVar49;
    }
    *(float *)(iVar38 + 0x178) = fVar51;
    func_0x000180459870(var_d8h ^ (uint64_t)auStackY_198);
    return;
code_r0x000180149c5c:
    uVar22 = (int32_t)uVar26 + 1;
    uVar26 = (uint64_t)uVar22;
    if (iVar39 <= (int32_t)uVar22) goto code_r0x000180149c63;
    goto code_r0x000180149c50;
}

// ============================================================
// Function: FUN_180149d95
// Address: 0x180149d95
// Size: 1904 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_144h
// WARNING: Variable defined which should be unmapped: var_178h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180148fa0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined auVar3 [16];
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    bool bVar13;
    bool bVar14;
    char cVar15;
    uint8_t uVar16;
    int32_t iVar17;
    undefined8 uVar18;
    int64_t iVar19;
    int32_t *piVar20;
    uint32_t uVar21;
    uint32_t uVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    uint64_t uVar26;
    undefined4 *puVar27;
    uint32_t uVar28;
    undefined4 *puVar29;
    uint32_t *puVar30;
    float *pfVar31;
    int32_t iVar32;
    uint32_t *puVar33;
    undefined8 *puVar34;
    uint32_t uVar35;
    int32_t iVar36;
    undefined4 *puVar37;
    int64_t iVar38;
    int32_t iVar39;
    char *pcVar40;
    int32_t iVar41;
    int64_t *piVar42;
    float *pfVar43;
    bool bVar44;
    float fVar45;
    float fVar46;
    float fVar47;
    float fVar48;
    float fVar49;
    float fVar50;
    float fVar51;
    undefined auVar52 [16];
    undefined auVar53 [16];
    float fVar54;
    undefined4 unaff_XMM12_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    float fVar55;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_198 [32];
    int64_t var_178h;
    undefined4 in_stack_fffffffffffffe98;
    undefined4 in_stack_fffffffffffffe9c;
    undefined4 uVar56;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int32_t var_148h;
    int64_t var_144h;
    undefined4 uStack_13c;
    undefined4 uVar57;
    undefined4 in_stack_fffffffffffffecc;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    float var_100h [2];
    int64_t var_f8h;
    float var_f0h;
    float var_ech;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar38 = *(int64_t *)0x180781f28;
    var_d8h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_198;
    fVar51 = *(float *)(arg1 + 0x48);
    var_118h = arg1 + 0x38;
    *(undefined *)(arg1 + 0x83) = 0;
    fVar49 = *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38);
    var_110h = arg1 + 0x40;
    uVar22 = *(uint32_t *)(arg1 + 8);
    *(float *)(arg1 + 0x48) = fVar49;
    uVar56 = CONCAT31((unkint3)((uint32_t)in_stack_fffffffffffffe9c >> 8), fVar49 < fVar51);
    auVar3._4_4_ = unaff_XMM12_Dc;
    auVar3._0_4_ = unaff_XMM12_Db;
    auVar3._8_4_ = unaff_XMM12_Dd;
    auVar3._12_4_ = 0;
    _var_98h = auVar3 << 0x20;
    bVar44 = false;
    uVar28 = 0;
    uVar35 = 0;
    _var_108h = ZEXT816(0);
    _var_f8h = ZEXT816(0);
    _var_e8h = ZEXT816(0);
    bVar13 = false;
    if (0 < (int32_t)uVar22) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)(arg1 + 0x10);
            iVar23 = (int64_t)(int32_t)uVar35 * 0x38;
            if ((*(int32_t *)(iVar23 + 0x10 + iVar25) < *(int32_t *)(arg1 + 0x34)) ||
               (*(char *)(iVar23 + 0x30 + iVar25) != '\0')) {
                if (*(int32_t *)(arg1 + 0x2c) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x2c) = 0;
                }
                if (*(int32_t *)(arg1 + 0x20) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x20) = 0;
                }
                if (*(int32_t *)(arg1 + 0x24) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x24) = 0;
                }
            } else {
                if (uVar28 != uVar35) {
                    auVar3 = *(undefined (*) [16])(iVar23 + 0x10 + iVar25);
                    puVar37 = (undefined4 *)(iVar23 + 0x20 + iVar25);
                    uVar57 = *puVar37;
                    uVar1 = puVar37[1];
                    uVar2 = puVar37[2];
                    uVar4 = puVar37[3];
                    uVar18 = *(undefined8 *)(iVar23 + 0x30 + iVar25);
                    iVar24 = (int64_t)(int32_t)uVar28 * 0x38;
                    *(undefined (*) [16])(iVar24 + iVar25) = *(undefined (*) [16])(iVar23 + iVar25);
                    *(undefined (*) [16])(iVar24 + 0x10 + iVar25) = auVar3;
                    puVar37 = (undefined4 *)(iVar24 + 0x20 + iVar25);
                    *puVar37 = uVar57;
                    puVar37[1] = uVar1;
                    puVar37[2] = uVar2;
                    puVar37[3] = uVar4;
                    *(undefined8 *)(iVar24 + 0x30 + iVar25) = uVar18;
                }
                iVar23 = (int64_t)(int32_t)uVar28 * 0x38;
                iVar25 = *(int64_t *)(arg1 + 0x10);
                uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                *(int16_t *)(iVar23 + 0x2e + iVar25) = (int16_t)uVar28;
                if ((uVar22 & 0x40) == 0) {
                    uVar26 = (uint64_t)(((uVar22 & 0x80) != 0) + 1);
                } else {
                    uVar26 = 0;
                }
                if (0 < (int32_t)uVar28) {
                    uVar22 = *(uint32_t *)(*(int64_t *)(arg1 + 0x10) + -0x34 + iVar23);
                    cVar15 = '\0';
                    if ((uVar22 & 0x40) == 0) {
                        cVar15 = ((uVar22 & 0x80) != 0) + '\x01';
                    }
                    if ((int32_t)uVar26 == 0) {
                        if (cVar15 == '\0') goto code_r0x000180149140;
                        bVar44 = true;
                    }
                    if (cVar15 == '\x02') {
                        if ((int32_t)uVar26 != 2) {
                            bVar44 = true;
                        }
                        var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                        uVar28 = uVar28 + 1;
                        goto code_r0x000180149172;
                    }
                }
code_r0x000180149140:
                var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                uVar28 = uVar28 + 1;
            }
code_r0x000180149172:
            uVar22 = *(uint32_t *)(arg1 + 8);
            uVar35 = uVar35 + 1;
            bVar13 = bVar44;
        } while ((int32_t)uVar35 < (int32_t)uVar22);
    }
    uVar35 = 8;
    var_128h = arg1;
    if (uVar22 != uVar28) {
        iVar32 = *(int32_t *)(arg1 + 0xc);
        if (iVar32 < (int32_t)uVar28) {
            uVar22 = uVar35;
            if (iVar32 != 0) {
                uVar22 = iVar32 / 2 + iVar32;
            }
            uVar21 = uVar28;
            if ((int32_t)uVar28 < (int32_t)uVar22) {
                uVar21 = uVar22;
            }
            func_0x00018011f970(arg1 + 8, uVar21);
        }
        *(uint32_t *)(arg1 + 8) = uVar28;
        uVar22 = uVar28;
    }
    piVar42 = (int64_t *)(arg1 + 0x10);
    if ((bVar44) && (1 < uVar22)) {
        fcn.18046f0d0(CONCAT44(uVar56, in_stack_fffffffffffffe98));
    }
    fVar51 = *(float *)(iVar38 + 0xdf4);
    if (((int32_t)var_108h < 1) || (var_100h[1] = fVar51, (int32_t)((int32_t)var_e8h + (uint32_t)var_f8h) < 1)) {
        var_100h[1] = 0.0;
    }
    if (((int32_t)(uint32_t)var_f8h < 1) || (var_ech = fVar51, (int32_t)var_e8h < 1)) {
        var_ech = 0.0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x28);
    uVar21 = 0;
    uVar28 = 0;
    if (uVar22 != 0) {
        *(undefined4 *)(arg1 + 0x28) = 0;
        uVar28 = uVar22;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x24);
    if (uVar22 != 0) {
        *(uint32_t *)(arg1 + 0x20) = uVar22;
        *(undefined4 *)(arg1 + 0x24) = 0;
        uVar28 = uVar22;
    }
    if (*(int32_t *)(arg1 + 0x7c) != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (iVar32 < 1) {
code_r0x00018014939d:
            *(undefined4 *)(arg1 + 0x7c) = 0;
        } else {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar21 * 0x38;
                puVar37 = (undefined4 *)(uVar26 + iVar25);
                if (*(int32_t *)(uVar26 + iVar25) == *(int32_t *)(arg1 + 0x7c)) {
                    if ((puVar37[1] & 0x20) == 0) {
                        iVar41 = (int32_t)(uVar26 / 0x38) + (int32_t)*(int16_t *)(arg1 + 0x80);
                        if ((-1 < iVar41) && (iVar41 < iVar32)) {
                            puVar29 = (undefined4 *)((int64_t)iVar41 * 0x38 + iVar25);
                            if (((puVar29[1] & 0x20) == 0) && (((puVar29[1] ^ puVar37[1]) & 0xc0) == 0)) {
                                uVar18 = *(undefined8 *)(puVar37 + 0xc);
                                uVar57 = *puVar37;
                                uVar1 = puVar37[1];
                                uVar2 = puVar37[2];
                                uVar4 = puVar37[3];
                                uVar5 = puVar37[4];
                                uVar6 = puVar37[5];
                                uVar7 = puVar37[6];
                                uVar8 = puVar37[7];
                                uVar9 = puVar37[8];
                                uVar10 = puVar37[9];
                                uVar11 = puVar37[10];
                                uVar12 = puVar37[0xb];
                                if (*(int16_t *)(arg1 + 0x80) < 1) {
                                    puVar37 = puVar29 + 0xe;
                                    puVar27 = puVar29;
                                } else {
                                    puVar27 = puVar37 + 0xe;
                                }
                                fcn.180498030(puVar37, puVar27);
                                *puVar29 = uVar57;
                                puVar29[1] = uVar1;
                                puVar29[2] = uVar2;
                                puVar29[3] = uVar4;
                                puVar29[4] = uVar5;
                                puVar29[5] = uVar6;
                                puVar29[6] = uVar7;
                                puVar29[7] = uVar8;
                                puVar29[8] = uVar9;
                                puVar29[9] = uVar10;
                                puVar29[10] = uVar11;
                                puVar29[0xb] = uVar12;
                                *(undefined8 *)(puVar29 + 0xc) = uVar18;
                                if (((*(uint32_t *)(arg1 + 0x18) & 0x400000) != 0) &&
                                   (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)) {
                                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) =
                                         *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
                                }
                                if (*(uint32_t *)(arg1 + 0x7c) == *(uint32_t *)(arg1 + 0x20)) {
                                    uVar28 = *(uint32_t *)(arg1 + 0x7c);
                                }
                            }
                        }
                    }
                    goto code_r0x00018014939d;
                }
                uVar21 = uVar21 + 1;
            } while ((int32_t)uVar21 < iVar32);
            *(undefined4 *)(arg1 + 0x7c) = 0;
        }
    }
    iVar25 = *(int64_t *)0x180781f28;
    puVar33 = (uint32_t *)0x0;
    if ((*(uint8_t *)(arg1 + 0x18) & 4) != 0) {
        uVar57 = *(undefined4 *)(arg1 + 0x3c);
        var_148h = 0;
        fVar49 = *(float *)(*(int64_t *)0x180781f28 + 0xde0);
        iVar23 = *(int64_t *)0x180781f28 + 0x20c0;
        iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
        uVar1 = *(undefined4 *)(iVar24 + 0x158);
        uVar2 = *(undefined4 *)(iVar24 + 0x15c);
        *(float *)(iVar24 + 0x158) = *(float *)(arg1 + 0x38) - fVar49;
        *(undefined4 *)(iVar24 + 0x15c) = uVar57;
        *(float *)(arg1 + 0x38) = fVar49 + fVar45 + *(float *)(arg1 + 0x38);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        uVar57 = *(undefined4 *)(iVar25 + 0xed8);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        fVar49 = *(float *)(iVar25 + 0xedc);
        fcn.18011f2b0(iVar23, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar57;
            *(float *)(iVar25 + 0xedc) = fVar49 * 0.5;
        }
        iVar25 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        uVar57 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x102c);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar25 + 0x1020) = 0;
            *(undefined8 *)(iVar25 + 0x1028) = 0;
        }
        cVar15 = func_0x00018013d0a0();
        fcn.1800f6770(2);
        if (cVar15 != '\0') {
            iVar32 = 0;
            if (0 < *(int32_t *)(arg1 + 8)) {
                do {
                    puVar30 = (uint32_t *)((int64_t)iVar32 * 0x38 + *piVar42);
                    if (((puVar30[1] & 0x200000) == 0) &&
                       (cVar15 = fcn.180146c70(CONCAT44(uStack_13c, var_144h._4_4_), 
                                               CONCAT44(in_stack_fffffffffffffecc, uVar57)), cVar15 != '\0')) {
                        puVar33 = puVar30;
                    }
                    iVar32 = iVar32 + 1;
                } while (iVar32 < *(int32_t *)(arg1 + 8));
            }
            iVar25 = *(int64_t *)0x180781f28;
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) + -1;
            iVar32 = func_0x000180498f10(*(undefined8 *)(*(int64_t *)(iVar25 + 0x15e0) + 8), &var_148h);
            if (iVar32 == 0) {
                func_0x00018010d5c0();
            } else if (*(code **)(iVar25 + 0x2a40) != (code *)0x0) {
                (**(code **)(iVar25 + 0x2a40))(iVar25, *(undefined8 *)(iVar25 + 0x2a48));
            }
        }
        *(undefined4 *)(iVar24 + 0x158) = uVar1;
        *(undefined4 *)(iVar24 + 0x15c) = uVar2;
        if (puVar33 != (uint32_t *)0x0) {
            uVar28 = *puVar33;
            *(uint32_t *)(arg1 + 0x20) = uVar28;
        }
    }
    iVar41 = 1;
    uVar22 = *(uint32_t *)(arg1 + 8);
    var_144h._0_4_ = (int32_t)var_e8h + (int32_t)var_108h;
    var_148h = 0;
    iVar32 = *(int32_t *)(iVar38 + 0x257c);
    var_144h._4_4_ = (int32_t)var_108h;
    if (iVar32 < (int32_t)uVar22) {
        if (iVar32 != 0) {
            uVar35 = iVar32 / 2 + iVar32;
        }
        uVar21 = uVar22;
        if ((int32_t)uVar22 < (int32_t)uVar35) {
            uVar21 = uVar35;
        }
        if (iVar32 < (int32_t)uVar21) {
            uVar18 = fcn.18046d050((int64_t)(int32_t)uVar21 * 0xc);
            if (*(int64_t *)(iVar38 + 0x2580) != 0) {
                fcn.180498030(uVar18);
                fcn.180460d90(*(undefined8 *)(iVar38 + 0x2580));
            }
            *(undefined8 *)(iVar38 + 0x2580) = uVar18;
            *(uint32_t *)(iVar38 + 0x257c) = uVar21;
        }
    }
    *(uint32_t *)(iVar38 + 0x2578) = uVar22;
    if ((*(uint8_t *)(arg1 + 0x18) & 0x80) == 0) {
        fVar49 = 1.0;
    } else {
        fVar49 = *(float *)(iVar38 + 0xe40);
    }
    iVar32 = *(int32_t *)(arg1 + 8);
    iVar39 = 0;
    var_130h = 0;
    bVar44 = false;
    uVar22 = 0xffffffff;
    bVar13 = false;
    if (0 < iVar32) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)0x180781f28;
            puVar33 = (uint32_t *)((int64_t)iVar39 * 0x38 + *piVar42);
            if (((var_130h == 0) || (*(int32_t *)(var_130h + 0x14) < (int32_t)puVar33[5])) &&
               ((puVar33[1] & 0x200000) == 0)) {
                var_130h = (int64_t)puVar33;
            }
            uVar35 = *puVar33;
            if (uVar35 == *(uint32_t *)(arg1 + 0x20)) {
                bVar44 = true;
            }
            if ((uVar28 == 0) && (*(uint32_t *)(iVar38 + 0x23a4) == uVar35)) {
                uVar28 = uVar35;
            }
            auVar52 = ZEXT416(puVar33[9]);
            if ((float)puVar33[9] < 0.0) {
                uVar35 = puVar33[1];
                var_178h._0_4_ = 0xbf800000;
                fcn.1800fe0a0(CONCAT44(var_178h._4_4_, 0xbf800000), SUB168(_var_98h, 8));
                fVar45 = *(float *)(iVar25 + 0xddc);
                if ((uVar35 & 0x100001) == 0x100000) {
                    fVar50 = fVar45 + 1.0;
                } else {
                    fVar50 = *(float *)(iVar25 + 0x12f8) + *(float *)(iVar25 + 0xdf4) + fVar45;
                }
                fVar50 = fVar50 + var_120h + fVar45;
                auVar52 = ZEXT416((uint32_t)fVar50);
                fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 20.0;
                if (fVar45 <= fVar50) {
                    auVar52 = ZEXT416((uint32_t)fVar45);
                }
            }
            uVar35 = puVar33[1];
            puVar33[8] = (uint32_t)auVar52._0_4_;
            if ((uVar35 >> 0x15 & 1) == 0) {
                if (auVar52._0_4_ <= *(float *)(iVar38 + 0xe3c)) {
                    auVar52._0_4_ = *(float *)(iVar38 + 0xe3c);
                }
                puVar33[8] = auVar52._0_4_;
            }
            if ((uVar35 & 0x40) == 0) {
                uVar35 = ((uVar35 & 0x80) != 0) + 1;
            } else {
                uVar35 = 0;
            }
            uVar26 = (uint64_t)uVar35;
            if (uVar35 == uVar22) {
                fVar50 = auVar52._0_4_ + fVar51;
                fVar45 = fVar51;
            } else {
                fVar50 = auVar52._0_4_ + 0.0;
                fVar45 = 0.0;
            }
            var_100h[uVar26 * 4 + -1] = fVar50 + var_100h[uVar26 * 4 + -1];
            fVar50 = (float)puVar33[8];
            if (fVar49 <= (float)puVar33[8]) {
                fVar50 = fVar49;
            }
            var_100h[uVar26 * 4] = fVar50 + fVar45 + var_100h[uVar26 * 4];
            iVar23 = (int64_t)(&var_148h)[uVar26];
            (&var_148h)[uVar26] = (&var_148h)[uVar26] + 1;
            iVar25 = *(int64_t *)(iVar38 + 0x2580);
            *(int32_t *)(iVar25 + iVar23 * 0xc) = iVar39;
            iVar39 = iVar39 + 1;
            uVar22 = puVar33[8];
            *(uint32_t *)(iVar25 + 8 + iVar23 * 0xc) = uVar22;
            *(uint32_t *)(iVar25 + 4 + iVar23 * 0xc) = uVar22;
            fVar45 = (float)puVar33[8];
            if (fVar45 <= 1.0) {
                fVar45 = 1.0;
            }
            puVar33[7] = (uint32_t)fVar45;
            iVar32 = *(int32_t *)(arg1 + 8);
            uVar22 = uVar35;
            bVar13 = bVar44;
        } while (iVar39 < iVar32);
    }
    uVar22 = *(uint32_t *)(arg1 + 0x18);
    *(float *)(arg1 + 0x58) = var_100h[1] + var_108h._4_4_ + 0.0 + var_f8h._4_4_ + var_ech + var_e8h._4_4_ + var_dch;
    iVar25 = *(int64_t *)0x180781f28;
    if (((uVar22 & 0x200) == 0) && (-1 < (char)uVar22)) {
        bVar14 = false;
code_r0x00018014992e:
        bVar13 = bVar14;
        fVar51 = var_e0h + var_dch + var_100h[0] + var_100h[1] + 0.0 + var_f0h + var_ech;
    } else {
        bVar13 = true;
        bVar14 = true;
        if ((uVar22 & 0x200) == 0) goto code_r0x00018014992e;
        fVar51 = *(float *)(arg1 + 0x54);
    }
    if ((((fVar51 <= *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38)) || (iVar32 < 2)) || ((uVar22 & 0x10) != 0)) ||
       (!bVar13)) {
        *(undefined *)(arg1 + 0x86) = 0;
    } else {
        *(undefined *)(arg1 + 0x86) = 1;
        var_148h = 0;
        fVar51 = *(float *)(iVar25 + 0x12f8);
        iVar23 = *(int64_t *)(iVar25 + 0x15e0);
        fVar54 = fVar51 - 2.0;
        fVar45 = *(float *)(iVar25 + 0xde0);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        uVar57 = *(undefined4 *)(iVar23 + 0x158);
        uVar1 = *(undefined4 *)(iVar25 + 0xed8);
        fVar50 = *(float *)(iVar25 + 0xedc);
        fVar55 = fVar54 + fVar54;
        var_120h = *(float *)(iVar23 + 0x15c);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        fcn.18011f2b0(iVar25 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar1;
            *(float *)(iVar25 + 0xedc) = fVar50 * 0.5;
        }
        iVar24 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar24 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar24 + 0x1020) = 0;
            *(undefined8 *)(iVar24 + 0x1028) = 0;
        }
        iVar24 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 10;
        piVar20 = (int32_t *)(iVar24 + 0x2100);
        iVar32 = *(int32_t *)(iVar24 + 0x2104);
        uVar1 = *(undefined4 *)(iVar24 + 0x1f78);
        if (*piVar20 == iVar32) {
            iVar39 = *piVar20 + 1;
            if (iVar32 == 0) {
                iVar32 = 8;
            } else {
                iVar32 = iVar32 / 2 + iVar32;
            }
            if (iVar39 < iVar32) {
                iVar39 = iVar32;
            }
            fcn.18011fb10(piVar20, iVar39);
        }
        *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + (int64_t)*piVar20 * 4) = uVar1;
        *piVar20 = *piVar20 + 1;
        uVar1 = *(undefined4 *)(iVar25 + 0xa8);
        uVar2 = *(undefined4 *)(iVar25 + 0xac);
        *(undefined4 *)(iVar25 + 0xa8) = 0x3e800000;
        *(undefined4 *)(iVar25 + 0xac) = 0x3e4ccccd;
        fVar46 = *(float *)(arg1 + 0x40) - fVar55;
        fVar50 = *(float *)(arg1 + 0x38);
        if (*(float *)(arg1 + 0x38) <= fVar46) {
            fVar50 = fVar46;
        }
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50;
        uVar16 = func_0x00018013a9f0(0x180645ba0, 0, CONCAT44(fVar45 + fVar45 + fVar51, fVar54));
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50 + fVar54;
        cVar15 = func_0x00018013a9f0(0x180645ba4, 1);
        iVar24 = *(int64_t *)0x180781f28;
        if (cVar15 == '\0') {
            iVar32 = (uVar16 ^ 1) - 1;
        } else {
            iVar32 = 1;
        }
        iVar39 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
        if (iVar39 < 2) {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48));
            }
        } else {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar39 + -1;
            *(undefined4 *)(iVar24 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + -8 + (int64_t)iVar39 * 4)
            ;
        }
        fcn.1800f6770();
        *(undefined4 *)(iVar25 + 0xac) = uVar2;
        *(undefined4 *)(iVar25 + 0xa8) = uVar1;
        if (iVar32 == 0) {
            puVar33 = (uint32_t *)0x0;
code_r0x000180149cf6:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
            if ((puVar33 != (uint32_t *)0x0) && (uVar28 = *puVar33, (puVar33[1] & 0x200000) == 0)) {
                *(uint32_t *)(arg1 + 0x20) = uVar28;
            }
        } else {
            if ((*(int32_t *)(arg1 + 0x20) != 0) && (iVar39 = *(int32_t *)(arg1 + 8), 0 < iVar39)) {
                uVar26 = 0;
                iVar25 = *piVar42;
code_r0x000180149c50:
                if (*(int32_t *)(uVar26 * 0x38 + iVar25) != *(int32_t *)(arg1 + 0x20)) goto code_r0x000180149c5c;
                uVar26 = (uVar26 * 0x38) / 0x38;
                iVar36 = (int32_t)uVar26 + iVar32;
                do {
                    if ((iVar36 < 0) || (iVar17 = iVar36, iVar39 <= iVar36)) {
                        iVar17 = (int32_t)uVar26;
                    }
                    puVar33 = (uint32_t *)((int64_t)iVar17 * 0x38 + iVar25);
                } while ((((*(uint32_t *)(iVar25 + 4 + (int64_t)iVar17 * 0x38) & 0x200000) != 0) &&
                         (iVar36 = iVar36 + iVar32, -1 < iVar36)) &&
                        (uVar26 = (uint64_t)(uint32_t)((int32_t)uVar26 + iVar32), iVar36 < iVar39));
                goto code_r0x000180149cf6;
            }
code_r0x000180149c63:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
        }
    }
    pfVar43 = (float *)(arg1 + 0x40);
    pcVar40 = (char *)(arg1 + 0x86);
    puVar34 = (undefined8 *)(arg1 + 0x38);
    if ((uVar28 == 0) && ((char)uVar56 != '\0')) {
        uVar28 = *(uint32_t *)(arg1 + 0x20);
    }
    fVar51 = *pfVar43 - *(float *)puVar34;
    fVar45 = var_e8h._4_4_ + var_dch + var_108h._4_4_ + var_100h[1];
    if (fVar51 <= fVar45) {
        fVar50 = fVar45 - fVar51;
    } else {
        fVar50 = (var_f8h._4_4_ + var_ech) - ((fVar51 - (var_108h._4_4_ + var_100h[1])) - (var_e8h._4_4_ + var_dch));
        if (fVar50 <= 0.0) {
            fVar50 = 0.0;
        }
    }
    if (1.0 <= fVar50) {
        if ((*(uint32_t *)(arg1 + 0x18) & 0x180) == 0) {
            if (fVar45 < fVar51) goto code_r0x00018014a4db;
code_r0x000180149e0c:
            uVar22 = (int32_t)var_e8h + (int32_t)var_108h;
            if (fVar51 <= fVar45) {
                iVar32 = 0;
            } else {
                iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            }
        } else {
            if (fVar51 <= fVar45) goto code_r0x000180149e0c;
            iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            uVar22 = (uint32_t)var_f8h;
        }
        iVar25 = *(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc;
        if (uVar22 == 1) {
            if (0.0 <= *(float *)(iVar25 + 4)) {
                fVar50 = *(float *)(iVar25 + 4) - fVar50;
                if (fVar50 <= fVar49) {
                    fVar50 = fVar49;
                }
                *(float *)(iVar25 + 4) = fVar50;
            }
        } else {
            if (1 < uVar22) {
                fcn.18046f0d0(CONCAT44(uVar56, uVar28));
            }
            while ((0.001 < fVar50 && (iVar41 < (int32_t)uVar22))) {
                fVar51 = *(float *)(iVar25 + 4);
                do {
                    fVar45 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                    if (fVar45 < fVar51) {
                        if (0.0 <= fVar45) {
                            fVar45 = fVar51 - fVar45;
                            goto code_r0x000180149ee6;
                        }
                        break;
                    }
                    iVar41 = iVar41 + 1;
                } while (iVar41 < (int32_t)uVar22);
                fVar45 = fVar51 - 1.0;
code_r0x000180149ee6:
                fVar54 = fVar51 - fVar49;
                if (fVar45 <= fVar51 - fVar49) {
                    fVar54 = fVar45;
                }
                if (fVar54 <= 0.0) break;
                iVar39 = 0;
                fVar51 = fVar50 / (float)iVar41;
                if (fVar54 <= fVar50 / (float)iVar41) {
                    fVar51 = fVar54;
                }
                if (3 < iVar41) {
                    do {
                        iVar23 = (int64_t)iVar39;
                        iVar39 = iVar39 + 4;
                        fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar55 = fVar45 - fVar49;
                        fVar54 = fVar51;
                        if (fVar55 <= fVar51) {
                            fVar54 = fVar55;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                        fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar46 = fVar45 - fVar49;
                        fVar55 = fVar51;
                        if (fVar46 <= fVar51) {
                            fVar55 = fVar46;
                        }
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar45 - fVar55;
                        fVar45 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar47 = fVar45 - fVar49;
                        fVar46 = fVar51;
                        if (fVar47 <= fVar51) {
                            fVar46 = fVar47;
                        }
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar45 - fVar46;
                        fVar45 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar48 = fVar45 - fVar49;
                        fVar47 = fVar51;
                        if (fVar48 <= fVar51) {
                            fVar47 = fVar48;
                        }
                        fVar50 = (((fVar50 - fVar54) - fVar55) - fVar46) - fVar47;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar45 - fVar47;
                    } while (iVar39 < iVar41 + -3);
                }
                while (iVar39 < iVar41) {
                    iVar23 = (int64_t)iVar39;
                    iVar39 = iVar39 + 1;
                    fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar55 = fVar45 - fVar49;
                    fVar54 = fVar51;
                    if (fVar55 <= fVar51) {
                        fVar54 = fVar55;
                    }
                    fVar50 = fVar50 - fVar54;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                }
            }
            iVar41 = 0;
            fVar51 = 0.0;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 4;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar48 = (float)(int32_t)fVar49;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar48;
                    fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                    fVar46 = (float)(int32_t)fVar45;
                    *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar46;
                    fVar50 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                    fVar55 = (float)(int32_t)fVar50;
                    *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar55;
                    fVar54 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                    fVar47 = (float)(int32_t)fVar54;
                    *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar47;
                    fVar51 = (fVar49 - fVar48) + fVar51 + (fVar45 - fVar46) + (fVar50 - fVar55) + (fVar54 - fVar47);
                } while (iVar41 < (int32_t)(uVar22 - 3));
            }
            for (; iVar41 < (int32_t)uVar22; iVar41 = iVar41 + 1) {
                fVar49 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                fVar45 = (float)(int32_t)fVar49;
                *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc) = fVar45;
                fVar51 = fVar51 + (fVar49 - fVar45);
            }
            while (0.0 < fVar51) {
                iVar41 = 0;
                if (3 < (int32_t)uVar22) {
                    do {
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar23 = (int64_t)iVar41;
                        fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 - fVar45 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar50 = *(float *)(iVar25 + 0x14 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar50) {
                            fVar50 = 1.0;
                        }
                        fVar51 = (fVar51 - fVar45) - fVar50;
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar49 + fVar50;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x20 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar41 = iVar41 + 4;
                        fVar49 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x2c + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar49 + fVar45;
                    } while (iVar41 < (int32_t)(uVar22 - 3));
                }
                while (iVar41 < (int32_t)uVar22) {
                    if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 1;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                    if (1.0 <= fVar45) {
                        fVar45 = 1.0;
                    }
                    fVar51 = fVar51 - fVar45;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                }
            }
        }
code_r0x00018014a22a:
        iVar41 = iVar32 + uVar22;
        if (iVar32 < iVar41) {
            arg1 = var_128h;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar25 = (int64_t)iVar32;
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x10 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0xc + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x1c + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x18 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x28 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar25 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x24 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar25 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar24 = 0;
                        }
                        var_100h[iVar24 * 4 + -1] =
                             var_100h[iVar24 * 4 + -1] - (*(float *)(iVar25 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar25 + 0x1c + iVar23) = fVar49;
                    }
                    iVar32 = iVar32 + 4;
                } while (iVar32 < iVar41 + -3);
                if (iVar41 <= iVar32) goto code_r0x00018014a4d3;
            }
            do {
                fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + (int64_t)iVar32 * 0xc);
                if (0.0 <= fVar51) {
                    iVar25 = *piVar42;
                    fVar49 = 1.0;
                    if (1.0 <= fVar51) {
                        fVar49 = fVar51;
                    }
                    iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc) * 0x38;
                    uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                    if ((uVar22 & 0x40) == 0) {
                        iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                    } else {
                        iVar24 = 0;
                    }
                    var_100h[iVar24 * 4 + -1] =
                         var_100h[iVar24 * 4 + -1] - (*(float *)(iVar23 + 0x1c + iVar25) - fVar49);
                    *(float *)(iVar23 + 0x1c + iVar25) = fVar49;
                }
                iVar32 = iVar32 + 1;
                puVar34 = (undefined8 *)var_118h;
                pfVar43 = (float *)var_110h;
            } while (iVar32 < iVar41);
        } else {
code_r0x00018014a4d3:
            puVar34 = (undefined8 *)(arg1 + 0x38);
            pfVar43 = (float *)(arg1 + 0x40);
        }
    }
code_r0x00018014a4db:
    uVar35 = 0;
    auVar53 = ZEXT816(0);
    *(undefined4 *)(arg1 + 0x54) = 0;
    uVar22 = uVar35;
    if (0 < (int32_t)var_108h) {
        do {
            iVar25 = *piVar42;
            iVar23 = (int64_t)(int32_t)uVar22 * 0x38;
            *(float *)(iVar23 + 0x18 + iVar25) = auVar53._0_4_;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_108h + -1) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            auVar53._0_4_ = auVar53._0_4_ + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_108h);
    }
    fVar49 = auVar53._0_4_ + var_100h[1];
    fVar51 = var_100h[1] + var_108h._4_4_;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    uVar22 = uVar35;
    if (0 < (int32_t)(uint32_t)var_f8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar49;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)((uint32_t)var_f8h + -1)) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar49 = fVar49 + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)(uint32_t)var_f8h);
    }
    fVar51 = var_f8h._4_4_ + var_ech;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    fVar45 = (*(float *)(arg1 + 0x40) - *(float *)puVar34) - var_e8h._4_4_;
    fVar51 = 0.0;
    if (0.0 <= fVar45) {
        fVar51 = fVar45;
    }
    if (var_ech + fVar49 <= fVar51) {
        fVar51 = var_ech + fVar49;
    }
    uVar22 = uVar35;
    if (0 < (int32_t)var_e8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h + (uint32_t)var_f8h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar51;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_e8h + -1) {
                fVar49 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar49 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar51 = fVar51 + fVar49 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_e8h);
    }
    fVar51 = var_e8h._4_4_ + var_dch;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    func_0x00018011f640(arg1 + 0xa0, 0);
    if ((!bVar44) && (*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1)) {
        *(undefined4 *)(arg1 + 0x20) = 0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x20);
    if (((*(uint32_t *)(arg1 + 0x20) == 0) && (uVar22 = uVar35, *(int32_t *)(arg1 + 0x24) == 0)) && (var_130h != 0)) {
        uVar28 = *(uint32_t *)var_130h;
        *(uint32_t *)(arg1 + 0x20) = uVar28;
        uVar22 = uVar28;
    }
    *(uint32_t *)(arg1 + 0x2c) = uVar22;
    *(undefined *)(arg1 + 0x84) = 0;
    iVar25 = *(int64_t *)(iVar38 + 0x23c0);
    if (((iVar25 != 0) && (*(int64_t *)(iVar25 + 0x4c0) != 0)) &&
       (*(int64_t *)(*(int64_t *)(iVar25 + 0x4c0) + 0x40) == arg1)) {
        uVar28 = *(uint32_t *)(iVar25 + 200);
        *(uint32_t *)(arg1 + 0x2c) = uVar28;
    }
    if (uVar28 != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (0 < iVar32) {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar35 * 0x38;
                if (*(uint32_t *)(uVar26 + iVar25) == uVar28) {
                    if ((*(uint8_t *)(uVar26 + 4 + iVar25) & 0xc0) != 0) break;
                    fVar51 = *pfVar43;
                    fVar49 = *(float *)puVar34;
                    fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
                    iVar41 = (int32_t)(uVar26 / 0x38);
                    if ((int32_t)var_108h + -1 < iVar41) {
                        fVar50 = (float)((uint32_t)fVar45 ^ 0x80000000);
                    } else {
                        fVar50 = 0.0;
                    }
                    fVar54 = *(float *)(uVar26 + 0x18 + iVar25) - var_108h._4_4_;
                    fVar50 = fVar54 + fVar50;
                    if (iVar32 - (int32_t)var_e8h <= iVar41 + 1) {
                        fVar45 = 1.0;
                    }
                    fVar55 = *(float *)(uVar26 + 0x1c + iVar25);
                    *(undefined4 *)(arg1 + 100) = 0;
                    fVar45 = fVar54 + fVar55 + fVar45;
                    if (*(float *)(arg1 + 0x60) <= fVar50) {
                        fVar51 = (((fVar51 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech;
                        if (fVar45 - fVar50 < fVar51) {
                            if (*(float *)(arg1 + 0x60) < fVar45 - fVar51) {
                                *(float *)(arg1 + 0x60) = fVar45 - fVar51;
                                fVar51 = (fVar50 - fVar51) - *(float *)(arg1 + 0x5c);
                                if (fVar51 <= 0.0) {
                                    fVar51 = 0.0;
                                }
                                *(float *)(arg1 + 100) = fVar51;
                            }
                            break;
                        }
                    }
                    fVar45 = *(float *)(arg1 + 0x5c) - fVar45;
                    *(float *)(arg1 + 0x60) = fVar50;
                    if (fVar45 <= 0.0) {
                        fVar45 = 0.0;
                    }
                    *(float *)(arg1 + 100) = fVar45;
                    break;
                }
                uVar35 = uVar35 + 1;
            } while ((int32_t)uVar35 < iVar32);
        }
        goto code_r0x00018014a9b6;
    }
    if ((*pcVar40 == '\0') || (cVar15 = func_0x000180108120(puVar34, pfVar43, 1), cVar15 == '\0'))
    goto code_r0x00018014a9b6;
    iVar25 = *(int64_t *)(iVar38 + 0x15e0);
    if (((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) != 0) &&
        ((((iVar23 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) + 0x428), iVar23 != 0 &&
           (*(char *)(iVar23 + 0x10a) != '\0')) && (iVar23 != *(int64_t *)(iVar25 + 0x428))) &&
         (((*(uint32_t *)(iVar23 + 0x14) >> 0x1b & 1) != 0 || ((*(uint32_t *)(iVar23 + 0x14) >> 0x1a & 1) != 0)))))) &&
       (iVar24 = *(int64_t *)(iVar25 + 0x418), *(int64_t *)(iVar24 + 0x418) != iVar23)) {
        do {
            if (iVar24 == iVar23) goto code_r0x00018014a8ae;
            iVar24 = *(int64_t *)(iVar24 + 0x410);
        } while (iVar24 != 0);
        goto code_r0x00018014a9b6;
    }
code_r0x00018014a8ae:
    if ((*(int64_t *)(iVar25 + 0x48) != *(int64_t *)(*(int64_t *)0x180781f28 + 0x2168)) &&
       ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) == 0 ||
        (*(int64_t *)(iVar25 + 0x428) != *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) + 0x428)))))
    goto code_r0x00018014a9b6;
    pfVar31 = (float *)(iVar38 + 0x128);
    if (*(char *)(iVar38 + 0xbaa) == '\0') {
        pfVar31 = (float *)(iVar38 + 300);
    }
    iVar32 = *(int32_t *)(arg1 + 0x1c);
    uVar26 = (uint64_t)((*(char *)(iVar38 + 0xbaa) != '\0') + 0x295);
    iVar25 = *(int64_t *)0x180781f28;
    piVar20 = (int32_t *)func_0x0001800f45c0(*(int64_t *)0x180781f28, uVar26);
    if (iVar32 == 0) {
        bVar44 = *(char *)(piVar20 + 2) == '\0';
code_r0x00018014a936:
        if (bVar44) {
code_r0x00018014a938:
            fVar51 = *pfVar31;
            if (fVar51 != 0.0) {
                fVar49 = *(float *)puVar34;
                fVar45 = *pfVar43;
                *(undefined4 *)(arg1 + 100) = 0;
                fVar51 = *(float *)(arg1 + 0x60) -
                         (((((fVar45 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech) * fVar51) / 3.0;
                fVar49 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar49);
                if (fVar49 <= fVar51) {
                    fVar51 = fVar49;
                }
                if (fVar51 <= 0.0) {
                    fVar51 = 0.0;
                }
                *(float *)(arg1 + 0x60) = fVar51;
            }
        }
    } else {
        if (*piVar20 == iVar32) goto code_r0x00018014a938;
        if (*(char *)(piVar20 + 2) == '\0') {
            bVar44 = *piVar20 == -1;
            goto code_r0x00018014a936;
        }
    }
    *(int32_t *)(iVar25 + -0x130 + uVar26 * 0xc) = iVar32;
    *(int32_t *)(iVar25 + -0x134 + uVar26 * 0xc) = iVar32;
    *(undefined2 *)(iVar25 + -300 + uVar26 * 0xc) = 0;
code_r0x00018014a9b6:
    fVar51 = *(float *)puVar34;
    fVar45 = *(float *)(arg1 + 0x54) - (*pfVar43 - fVar51);
    fVar49 = *(float *)(arg1 + 0x5c);
    if (fVar45 <= *(float *)(arg1 + 0x5c)) {
        fVar49 = fVar45;
    }
    if (fVar49 <= 0.0) {
        fVar49 = 0.0;
    }
    *(float *)(arg1 + 0x5c) = fVar49;
    fVar50 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar51);
    fVar45 = *(float *)(arg1 + 0x60);
    if (fVar50 <= *(float *)(arg1 + 0x60)) {
        fVar45 = fVar50;
    }
    if (fVar45 <= 0.0) {
        fVar45 = 0.0;
    }
    *(float *)(arg1 + 0x60) = fVar45;
    if (fVar49 == fVar45) {
        *(undefined4 *)(arg1 + 0x68) = 0;
    } else {
        fVar54 = *(float *)(iVar38 + 0x12f8) * 70.0;
        fVar50 = *(float *)(arg1 + 0x68);
        if (*(float *)(arg1 + 0x68) <= fVar54) {
            fVar50 = fVar54;
        }
        fVar54 = (float)((uint32_t)(fVar45 - fVar49) & 0x7fffffff) / 0.3;
        if (fVar50 <= fVar54) {
            fVar50 = fVar54;
        }
        *(float *)(arg1 + 0x68) = fVar50;
        fVar54 = fVar45;
        if ((*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1) &&
           (*(float *)(arg1 + 100) <= *(float *)(iVar38 + 0x12f8) * 10.0)) {
            fVar50 = fVar50 * *(float *)(iVar38 + 0x48);
            if (fVar45 <= fVar49) {
                fVar54 = fVar49;
                if ((fVar45 < fVar49) && (fVar54 = fVar49 - fVar50, fVar54 <= fVar45)) {
                    fVar54 = fVar45;
                }
            } else {
                fVar54 = fVar50 + fVar49;
                if (fVar45 <= fVar54) {
                    fVar54 = fVar45;
                }
            }
        }
        *(float *)(arg1 + 0x5c) = fVar54;
    }
    uVar18 = *puVar34;
    *(float *)(arg1 + 0x6c) = fVar51 + var_108h._4_4_ + var_100h[1];
    *(float *)(arg1 + 0x70) = (*(float *)(arg1 + 0x40) - var_e8h._4_4_) - var_ech;
    iVar38 = *(int64_t *)(iVar38 + 0x15e0);
    *(undefined8 *)(iVar38 + 0x158) = uVar18;
    var_128h = CONCAT44(*(float *)(arg1 + 0x44) - *(float *)(arg1 + 0x3c), *(undefined4 *)(arg1 + 0x54));
    func_0x00018010bbf0(&var_128h);
    fVar49 = *(float *)(arg1 + 0x58) + *(float *)puVar34;
    fVar51 = *(float *)(iVar38 + 0x178);
    if (*(float *)(iVar38 + 0x178) <= fVar49) {
        fVar51 = fVar49;
    }
    *(float *)(iVar38 + 0x178) = fVar51;
    func_0x000180459870(var_d8h ^ (uint64_t)auStackY_198);
    return;
code_r0x000180149c5c:
    uVar22 = (int32_t)uVar26 + 1;
    uVar26 = (uint64_t)uVar22;
    if (iVar39 <= (int32_t)uVar22) goto code_r0x000180149c63;
    goto code_r0x000180149c50;
}

// ============================================================
// Function: FUN_18014a505
// Address: 0x18014a505
// Size: 1327 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_144h
// WARNING: Variable defined which should be unmapped: var_178h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180148fa0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined auVar3 [16];
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    bool bVar13;
    bool bVar14;
    char cVar15;
    uint8_t uVar16;
    int32_t iVar17;
    undefined8 uVar18;
    int64_t iVar19;
    int32_t *piVar20;
    uint32_t uVar21;
    uint32_t uVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    uint64_t uVar26;
    undefined4 *puVar27;
    uint32_t uVar28;
    undefined4 *puVar29;
    uint32_t *puVar30;
    float *pfVar31;
    int32_t iVar32;
    uint32_t *puVar33;
    undefined8 *puVar34;
    uint32_t uVar35;
    int32_t iVar36;
    undefined4 *puVar37;
    int64_t iVar38;
    int32_t iVar39;
    char *pcVar40;
    int32_t iVar41;
    int64_t *piVar42;
    float *pfVar43;
    bool bVar44;
    float fVar45;
    float fVar46;
    float fVar47;
    float fVar48;
    float fVar49;
    float fVar50;
    float fVar51;
    undefined auVar52 [16];
    undefined auVar53 [16];
    float fVar54;
    undefined4 unaff_XMM12_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    float fVar55;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_198 [32];
    int64_t var_178h;
    undefined4 in_stack_fffffffffffffe98;
    undefined4 in_stack_fffffffffffffe9c;
    undefined4 uVar56;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int32_t var_148h;
    int64_t var_144h;
    undefined4 uStack_13c;
    undefined4 uVar57;
    undefined4 in_stack_fffffffffffffecc;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    float var_100h [2];
    int64_t var_f8h;
    float var_f0h;
    float var_ech;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar38 = *(int64_t *)0x180781f28;
    var_d8h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_198;
    fVar51 = *(float *)(arg1 + 0x48);
    var_118h = arg1 + 0x38;
    *(undefined *)(arg1 + 0x83) = 0;
    fVar49 = *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38);
    var_110h = arg1 + 0x40;
    uVar22 = *(uint32_t *)(arg1 + 8);
    *(float *)(arg1 + 0x48) = fVar49;
    uVar56 = CONCAT31((unkint3)((uint32_t)in_stack_fffffffffffffe9c >> 8), fVar49 < fVar51);
    auVar3._4_4_ = unaff_XMM12_Dc;
    auVar3._0_4_ = unaff_XMM12_Db;
    auVar3._8_4_ = unaff_XMM12_Dd;
    auVar3._12_4_ = 0;
    _var_98h = auVar3 << 0x20;
    bVar44 = false;
    uVar28 = 0;
    uVar35 = 0;
    _var_108h = ZEXT816(0);
    _var_f8h = ZEXT816(0);
    _var_e8h = ZEXT816(0);
    bVar13 = false;
    if (0 < (int32_t)uVar22) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)(arg1 + 0x10);
            iVar23 = (int64_t)(int32_t)uVar35 * 0x38;
            if ((*(int32_t *)(iVar23 + 0x10 + iVar25) < *(int32_t *)(arg1 + 0x34)) ||
               (*(char *)(iVar23 + 0x30 + iVar25) != '\0')) {
                if (*(int32_t *)(arg1 + 0x2c) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x2c) = 0;
                }
                if (*(int32_t *)(arg1 + 0x20) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x20) = 0;
                }
                if (*(int32_t *)(arg1 + 0x24) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x24) = 0;
                }
            } else {
                if (uVar28 != uVar35) {
                    auVar3 = *(undefined (*) [16])(iVar23 + 0x10 + iVar25);
                    puVar37 = (undefined4 *)(iVar23 + 0x20 + iVar25);
                    uVar57 = *puVar37;
                    uVar1 = puVar37[1];
                    uVar2 = puVar37[2];
                    uVar4 = puVar37[3];
                    uVar18 = *(undefined8 *)(iVar23 + 0x30 + iVar25);
                    iVar24 = (int64_t)(int32_t)uVar28 * 0x38;
                    *(undefined (*) [16])(iVar24 + iVar25) = *(undefined (*) [16])(iVar23 + iVar25);
                    *(undefined (*) [16])(iVar24 + 0x10 + iVar25) = auVar3;
                    puVar37 = (undefined4 *)(iVar24 + 0x20 + iVar25);
                    *puVar37 = uVar57;
                    puVar37[1] = uVar1;
                    puVar37[2] = uVar2;
                    puVar37[3] = uVar4;
                    *(undefined8 *)(iVar24 + 0x30 + iVar25) = uVar18;
                }
                iVar23 = (int64_t)(int32_t)uVar28 * 0x38;
                iVar25 = *(int64_t *)(arg1 + 0x10);
                uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                *(int16_t *)(iVar23 + 0x2e + iVar25) = (int16_t)uVar28;
                if ((uVar22 & 0x40) == 0) {
                    uVar26 = (uint64_t)(((uVar22 & 0x80) != 0) + 1);
                } else {
                    uVar26 = 0;
                }
                if (0 < (int32_t)uVar28) {
                    uVar22 = *(uint32_t *)(*(int64_t *)(arg1 + 0x10) + -0x34 + iVar23);
                    cVar15 = '\0';
                    if ((uVar22 & 0x40) == 0) {
                        cVar15 = ((uVar22 & 0x80) != 0) + '\x01';
                    }
                    if ((int32_t)uVar26 == 0) {
                        if (cVar15 == '\0') goto code_r0x000180149140;
                        bVar44 = true;
                    }
                    if (cVar15 == '\x02') {
                        if ((int32_t)uVar26 != 2) {
                            bVar44 = true;
                        }
                        var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                        uVar28 = uVar28 + 1;
                        goto code_r0x000180149172;
                    }
                }
code_r0x000180149140:
                var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                uVar28 = uVar28 + 1;
            }
code_r0x000180149172:
            uVar22 = *(uint32_t *)(arg1 + 8);
            uVar35 = uVar35 + 1;
            bVar13 = bVar44;
        } while ((int32_t)uVar35 < (int32_t)uVar22);
    }
    uVar35 = 8;
    var_128h = arg1;
    if (uVar22 != uVar28) {
        iVar32 = *(int32_t *)(arg1 + 0xc);
        if (iVar32 < (int32_t)uVar28) {
            uVar22 = uVar35;
            if (iVar32 != 0) {
                uVar22 = iVar32 / 2 + iVar32;
            }
            uVar21 = uVar28;
            if ((int32_t)uVar28 < (int32_t)uVar22) {
                uVar21 = uVar22;
            }
            func_0x00018011f970(arg1 + 8, uVar21);
        }
        *(uint32_t *)(arg1 + 8) = uVar28;
        uVar22 = uVar28;
    }
    piVar42 = (int64_t *)(arg1 + 0x10);
    if ((bVar44) && (1 < uVar22)) {
        fcn.18046f0d0(CONCAT44(uVar56, in_stack_fffffffffffffe98));
    }
    fVar51 = *(float *)(iVar38 + 0xdf4);
    if (((int32_t)var_108h < 1) || (var_100h[1] = fVar51, (int32_t)((int32_t)var_e8h + (uint32_t)var_f8h) < 1)) {
        var_100h[1] = 0.0;
    }
    if (((int32_t)(uint32_t)var_f8h < 1) || (var_ech = fVar51, (int32_t)var_e8h < 1)) {
        var_ech = 0.0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x28);
    uVar21 = 0;
    uVar28 = 0;
    if (uVar22 != 0) {
        *(undefined4 *)(arg1 + 0x28) = 0;
        uVar28 = uVar22;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x24);
    if (uVar22 != 0) {
        *(uint32_t *)(arg1 + 0x20) = uVar22;
        *(undefined4 *)(arg1 + 0x24) = 0;
        uVar28 = uVar22;
    }
    if (*(int32_t *)(arg1 + 0x7c) != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (iVar32 < 1) {
code_r0x00018014939d:
            *(undefined4 *)(arg1 + 0x7c) = 0;
        } else {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar21 * 0x38;
                puVar37 = (undefined4 *)(uVar26 + iVar25);
                if (*(int32_t *)(uVar26 + iVar25) == *(int32_t *)(arg1 + 0x7c)) {
                    if ((puVar37[1] & 0x20) == 0) {
                        iVar41 = (int32_t)(uVar26 / 0x38) + (int32_t)*(int16_t *)(arg1 + 0x80);
                        if ((-1 < iVar41) && (iVar41 < iVar32)) {
                            puVar29 = (undefined4 *)((int64_t)iVar41 * 0x38 + iVar25);
                            if (((puVar29[1] & 0x20) == 0) && (((puVar29[1] ^ puVar37[1]) & 0xc0) == 0)) {
                                uVar18 = *(undefined8 *)(puVar37 + 0xc);
                                uVar57 = *puVar37;
                                uVar1 = puVar37[1];
                                uVar2 = puVar37[2];
                                uVar4 = puVar37[3];
                                uVar5 = puVar37[4];
                                uVar6 = puVar37[5];
                                uVar7 = puVar37[6];
                                uVar8 = puVar37[7];
                                uVar9 = puVar37[8];
                                uVar10 = puVar37[9];
                                uVar11 = puVar37[10];
                                uVar12 = puVar37[0xb];
                                if (*(int16_t *)(arg1 + 0x80) < 1) {
                                    puVar37 = puVar29 + 0xe;
                                    puVar27 = puVar29;
                                } else {
                                    puVar27 = puVar37 + 0xe;
                                }
                                fcn.180498030(puVar37, puVar27);
                                *puVar29 = uVar57;
                                puVar29[1] = uVar1;
                                puVar29[2] = uVar2;
                                puVar29[3] = uVar4;
                                puVar29[4] = uVar5;
                                puVar29[5] = uVar6;
                                puVar29[6] = uVar7;
                                puVar29[7] = uVar8;
                                puVar29[8] = uVar9;
                                puVar29[9] = uVar10;
                                puVar29[10] = uVar11;
                                puVar29[0xb] = uVar12;
                                *(undefined8 *)(puVar29 + 0xc) = uVar18;
                                if (((*(uint32_t *)(arg1 + 0x18) & 0x400000) != 0) &&
                                   (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)) {
                                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) =
                                         *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
                                }
                                if (*(uint32_t *)(arg1 + 0x7c) == *(uint32_t *)(arg1 + 0x20)) {
                                    uVar28 = *(uint32_t *)(arg1 + 0x7c);
                                }
                            }
                        }
                    }
                    goto code_r0x00018014939d;
                }
                uVar21 = uVar21 + 1;
            } while ((int32_t)uVar21 < iVar32);
            *(undefined4 *)(arg1 + 0x7c) = 0;
        }
    }
    iVar25 = *(int64_t *)0x180781f28;
    puVar33 = (uint32_t *)0x0;
    if ((*(uint8_t *)(arg1 + 0x18) & 4) != 0) {
        uVar57 = *(undefined4 *)(arg1 + 0x3c);
        var_148h = 0;
        fVar49 = *(float *)(*(int64_t *)0x180781f28 + 0xde0);
        iVar23 = *(int64_t *)0x180781f28 + 0x20c0;
        iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
        uVar1 = *(undefined4 *)(iVar24 + 0x158);
        uVar2 = *(undefined4 *)(iVar24 + 0x15c);
        *(float *)(iVar24 + 0x158) = *(float *)(arg1 + 0x38) - fVar49;
        *(undefined4 *)(iVar24 + 0x15c) = uVar57;
        *(float *)(arg1 + 0x38) = fVar49 + fVar45 + *(float *)(arg1 + 0x38);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        uVar57 = *(undefined4 *)(iVar25 + 0xed8);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        fVar49 = *(float *)(iVar25 + 0xedc);
        fcn.18011f2b0(iVar23, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar57;
            *(float *)(iVar25 + 0xedc) = fVar49 * 0.5;
        }
        iVar25 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        uVar57 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x102c);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar25 + 0x1020) = 0;
            *(undefined8 *)(iVar25 + 0x1028) = 0;
        }
        cVar15 = func_0x00018013d0a0();
        fcn.1800f6770(2);
        if (cVar15 != '\0') {
            iVar32 = 0;
            if (0 < *(int32_t *)(arg1 + 8)) {
                do {
                    puVar30 = (uint32_t *)((int64_t)iVar32 * 0x38 + *piVar42);
                    if (((puVar30[1] & 0x200000) == 0) &&
                       (cVar15 = fcn.180146c70(CONCAT44(uStack_13c, var_144h._4_4_), 
                                               CONCAT44(in_stack_fffffffffffffecc, uVar57)), cVar15 != '\0')) {
                        puVar33 = puVar30;
                    }
                    iVar32 = iVar32 + 1;
                } while (iVar32 < *(int32_t *)(arg1 + 8));
            }
            iVar25 = *(int64_t *)0x180781f28;
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) + -1;
            iVar32 = func_0x000180498f10(*(undefined8 *)(*(int64_t *)(iVar25 + 0x15e0) + 8), &var_148h);
            if (iVar32 == 0) {
                func_0x00018010d5c0();
            } else if (*(code **)(iVar25 + 0x2a40) != (code *)0x0) {
                (**(code **)(iVar25 + 0x2a40))(iVar25, *(undefined8 *)(iVar25 + 0x2a48));
            }
        }
        *(undefined4 *)(iVar24 + 0x158) = uVar1;
        *(undefined4 *)(iVar24 + 0x15c) = uVar2;
        if (puVar33 != (uint32_t *)0x0) {
            uVar28 = *puVar33;
            *(uint32_t *)(arg1 + 0x20) = uVar28;
        }
    }
    iVar41 = 1;
    uVar22 = *(uint32_t *)(arg1 + 8);
    var_144h._0_4_ = (int32_t)var_e8h + (int32_t)var_108h;
    var_148h = 0;
    iVar32 = *(int32_t *)(iVar38 + 0x257c);
    var_144h._4_4_ = (int32_t)var_108h;
    if (iVar32 < (int32_t)uVar22) {
        if (iVar32 != 0) {
            uVar35 = iVar32 / 2 + iVar32;
        }
        uVar21 = uVar22;
        if ((int32_t)uVar22 < (int32_t)uVar35) {
            uVar21 = uVar35;
        }
        if (iVar32 < (int32_t)uVar21) {
            uVar18 = fcn.18046d050((int64_t)(int32_t)uVar21 * 0xc);
            if (*(int64_t *)(iVar38 + 0x2580) != 0) {
                fcn.180498030(uVar18);
                fcn.180460d90(*(undefined8 *)(iVar38 + 0x2580));
            }
            *(undefined8 *)(iVar38 + 0x2580) = uVar18;
            *(uint32_t *)(iVar38 + 0x257c) = uVar21;
        }
    }
    *(uint32_t *)(iVar38 + 0x2578) = uVar22;
    if ((*(uint8_t *)(arg1 + 0x18) & 0x80) == 0) {
        fVar49 = 1.0;
    } else {
        fVar49 = *(float *)(iVar38 + 0xe40);
    }
    iVar32 = *(int32_t *)(arg1 + 8);
    iVar39 = 0;
    var_130h = 0;
    bVar44 = false;
    uVar22 = 0xffffffff;
    bVar13 = false;
    if (0 < iVar32) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)0x180781f28;
            puVar33 = (uint32_t *)((int64_t)iVar39 * 0x38 + *piVar42);
            if (((var_130h == 0) || (*(int32_t *)(var_130h + 0x14) < (int32_t)puVar33[5])) &&
               ((puVar33[1] & 0x200000) == 0)) {
                var_130h = (int64_t)puVar33;
            }
            uVar35 = *puVar33;
            if (uVar35 == *(uint32_t *)(arg1 + 0x20)) {
                bVar44 = true;
            }
            if ((uVar28 == 0) && (*(uint32_t *)(iVar38 + 0x23a4) == uVar35)) {
                uVar28 = uVar35;
            }
            auVar52 = ZEXT416(puVar33[9]);
            if ((float)puVar33[9] < 0.0) {
                uVar35 = puVar33[1];
                var_178h._0_4_ = 0xbf800000;
                fcn.1800fe0a0(CONCAT44(var_178h._4_4_, 0xbf800000), SUB168(_var_98h, 8));
                fVar45 = *(float *)(iVar25 + 0xddc);
                if ((uVar35 & 0x100001) == 0x100000) {
                    fVar50 = fVar45 + 1.0;
                } else {
                    fVar50 = *(float *)(iVar25 + 0x12f8) + *(float *)(iVar25 + 0xdf4) + fVar45;
                }
                fVar50 = fVar50 + var_120h + fVar45;
                auVar52 = ZEXT416((uint32_t)fVar50);
                fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 20.0;
                if (fVar45 <= fVar50) {
                    auVar52 = ZEXT416((uint32_t)fVar45);
                }
            }
            uVar35 = puVar33[1];
            puVar33[8] = (uint32_t)auVar52._0_4_;
            if ((uVar35 >> 0x15 & 1) == 0) {
                if (auVar52._0_4_ <= *(float *)(iVar38 + 0xe3c)) {
                    auVar52._0_4_ = *(float *)(iVar38 + 0xe3c);
                }
                puVar33[8] = auVar52._0_4_;
            }
            if ((uVar35 & 0x40) == 0) {
                uVar35 = ((uVar35 & 0x80) != 0) + 1;
            } else {
                uVar35 = 0;
            }
            uVar26 = (uint64_t)uVar35;
            if (uVar35 == uVar22) {
                fVar50 = auVar52._0_4_ + fVar51;
                fVar45 = fVar51;
            } else {
                fVar50 = auVar52._0_4_ + 0.0;
                fVar45 = 0.0;
            }
            var_100h[uVar26 * 4 + -1] = fVar50 + var_100h[uVar26 * 4 + -1];
            fVar50 = (float)puVar33[8];
            if (fVar49 <= (float)puVar33[8]) {
                fVar50 = fVar49;
            }
            var_100h[uVar26 * 4] = fVar50 + fVar45 + var_100h[uVar26 * 4];
            iVar23 = (int64_t)(&var_148h)[uVar26];
            (&var_148h)[uVar26] = (&var_148h)[uVar26] + 1;
            iVar25 = *(int64_t *)(iVar38 + 0x2580);
            *(int32_t *)(iVar25 + iVar23 * 0xc) = iVar39;
            iVar39 = iVar39 + 1;
            uVar22 = puVar33[8];
            *(uint32_t *)(iVar25 + 8 + iVar23 * 0xc) = uVar22;
            *(uint32_t *)(iVar25 + 4 + iVar23 * 0xc) = uVar22;
            fVar45 = (float)puVar33[8];
            if (fVar45 <= 1.0) {
                fVar45 = 1.0;
            }
            puVar33[7] = (uint32_t)fVar45;
            iVar32 = *(int32_t *)(arg1 + 8);
            uVar22 = uVar35;
            bVar13 = bVar44;
        } while (iVar39 < iVar32);
    }
    uVar22 = *(uint32_t *)(arg1 + 0x18);
    *(float *)(arg1 + 0x58) = var_100h[1] + var_108h._4_4_ + 0.0 + var_f8h._4_4_ + var_ech + var_e8h._4_4_ + var_dch;
    iVar25 = *(int64_t *)0x180781f28;
    if (((uVar22 & 0x200) == 0) && (-1 < (char)uVar22)) {
        bVar14 = false;
code_r0x00018014992e:
        bVar13 = bVar14;
        fVar51 = var_e0h + var_dch + var_100h[0] + var_100h[1] + 0.0 + var_f0h + var_ech;
    } else {
        bVar13 = true;
        bVar14 = true;
        if ((uVar22 & 0x200) == 0) goto code_r0x00018014992e;
        fVar51 = *(float *)(arg1 + 0x54);
    }
    if ((((fVar51 <= *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38)) || (iVar32 < 2)) || ((uVar22 & 0x10) != 0)) ||
       (!bVar13)) {
        *(undefined *)(arg1 + 0x86) = 0;
    } else {
        *(undefined *)(arg1 + 0x86) = 1;
        var_148h = 0;
        fVar51 = *(float *)(iVar25 + 0x12f8);
        iVar23 = *(int64_t *)(iVar25 + 0x15e0);
        fVar54 = fVar51 - 2.0;
        fVar45 = *(float *)(iVar25 + 0xde0);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        uVar57 = *(undefined4 *)(iVar23 + 0x158);
        uVar1 = *(undefined4 *)(iVar25 + 0xed8);
        fVar50 = *(float *)(iVar25 + 0xedc);
        fVar55 = fVar54 + fVar54;
        var_120h = *(float *)(iVar23 + 0x15c);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        fcn.18011f2b0(iVar25 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar1;
            *(float *)(iVar25 + 0xedc) = fVar50 * 0.5;
        }
        iVar24 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar24 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar24 + 0x1020) = 0;
            *(undefined8 *)(iVar24 + 0x1028) = 0;
        }
        iVar24 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 10;
        piVar20 = (int32_t *)(iVar24 + 0x2100);
        iVar32 = *(int32_t *)(iVar24 + 0x2104);
        uVar1 = *(undefined4 *)(iVar24 + 0x1f78);
        if (*piVar20 == iVar32) {
            iVar39 = *piVar20 + 1;
            if (iVar32 == 0) {
                iVar32 = 8;
            } else {
                iVar32 = iVar32 / 2 + iVar32;
            }
            if (iVar39 < iVar32) {
                iVar39 = iVar32;
            }
            fcn.18011fb10(piVar20, iVar39);
        }
        *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + (int64_t)*piVar20 * 4) = uVar1;
        *piVar20 = *piVar20 + 1;
        uVar1 = *(undefined4 *)(iVar25 + 0xa8);
        uVar2 = *(undefined4 *)(iVar25 + 0xac);
        *(undefined4 *)(iVar25 + 0xa8) = 0x3e800000;
        *(undefined4 *)(iVar25 + 0xac) = 0x3e4ccccd;
        fVar46 = *(float *)(arg1 + 0x40) - fVar55;
        fVar50 = *(float *)(arg1 + 0x38);
        if (*(float *)(arg1 + 0x38) <= fVar46) {
            fVar50 = fVar46;
        }
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50;
        uVar16 = func_0x00018013a9f0(0x180645ba0, 0, CONCAT44(fVar45 + fVar45 + fVar51, fVar54));
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50 + fVar54;
        cVar15 = func_0x00018013a9f0(0x180645ba4, 1);
        iVar24 = *(int64_t *)0x180781f28;
        if (cVar15 == '\0') {
            iVar32 = (uVar16 ^ 1) - 1;
        } else {
            iVar32 = 1;
        }
        iVar39 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
        if (iVar39 < 2) {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48));
            }
        } else {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar39 + -1;
            *(undefined4 *)(iVar24 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + -8 + (int64_t)iVar39 * 4)
            ;
        }
        fcn.1800f6770();
        *(undefined4 *)(iVar25 + 0xac) = uVar2;
        *(undefined4 *)(iVar25 + 0xa8) = uVar1;
        if (iVar32 == 0) {
            puVar33 = (uint32_t *)0x0;
code_r0x000180149cf6:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
            if ((puVar33 != (uint32_t *)0x0) && (uVar28 = *puVar33, (puVar33[1] & 0x200000) == 0)) {
                *(uint32_t *)(arg1 + 0x20) = uVar28;
            }
        } else {
            if ((*(int32_t *)(arg1 + 0x20) != 0) && (iVar39 = *(int32_t *)(arg1 + 8), 0 < iVar39)) {
                uVar26 = 0;
                iVar25 = *piVar42;
code_r0x000180149c50:
                if (*(int32_t *)(uVar26 * 0x38 + iVar25) != *(int32_t *)(arg1 + 0x20)) goto code_r0x000180149c5c;
                uVar26 = (uVar26 * 0x38) / 0x38;
                iVar36 = (int32_t)uVar26 + iVar32;
                do {
                    if ((iVar36 < 0) || (iVar17 = iVar36, iVar39 <= iVar36)) {
                        iVar17 = (int32_t)uVar26;
                    }
                    puVar33 = (uint32_t *)((int64_t)iVar17 * 0x38 + iVar25);
                } while ((((*(uint32_t *)(iVar25 + 4 + (int64_t)iVar17 * 0x38) & 0x200000) != 0) &&
                         (iVar36 = iVar36 + iVar32, -1 < iVar36)) &&
                        (uVar26 = (uint64_t)(uint32_t)((int32_t)uVar26 + iVar32), iVar36 < iVar39));
                goto code_r0x000180149cf6;
            }
code_r0x000180149c63:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
        }
    }
    pfVar43 = (float *)(arg1 + 0x40);
    pcVar40 = (char *)(arg1 + 0x86);
    puVar34 = (undefined8 *)(arg1 + 0x38);
    if ((uVar28 == 0) && ((char)uVar56 != '\0')) {
        uVar28 = *(uint32_t *)(arg1 + 0x20);
    }
    fVar51 = *pfVar43 - *(float *)puVar34;
    fVar45 = var_e8h._4_4_ + var_dch + var_108h._4_4_ + var_100h[1];
    if (fVar51 <= fVar45) {
        fVar50 = fVar45 - fVar51;
    } else {
        fVar50 = (var_f8h._4_4_ + var_ech) - ((fVar51 - (var_108h._4_4_ + var_100h[1])) - (var_e8h._4_4_ + var_dch));
        if (fVar50 <= 0.0) {
            fVar50 = 0.0;
        }
    }
    if (1.0 <= fVar50) {
        if ((*(uint32_t *)(arg1 + 0x18) & 0x180) == 0) {
            if (fVar45 < fVar51) goto code_r0x00018014a4db;
code_r0x000180149e0c:
            uVar22 = (int32_t)var_e8h + (int32_t)var_108h;
            if (fVar51 <= fVar45) {
                iVar32 = 0;
            } else {
                iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            }
        } else {
            if (fVar51 <= fVar45) goto code_r0x000180149e0c;
            iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            uVar22 = (uint32_t)var_f8h;
        }
        iVar25 = *(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc;
        if (uVar22 == 1) {
            if (0.0 <= *(float *)(iVar25 + 4)) {
                fVar50 = *(float *)(iVar25 + 4) - fVar50;
                if (fVar50 <= fVar49) {
                    fVar50 = fVar49;
                }
                *(float *)(iVar25 + 4) = fVar50;
            }
        } else {
            if (1 < uVar22) {
                fcn.18046f0d0(CONCAT44(uVar56, uVar28));
            }
            while ((0.001 < fVar50 && (iVar41 < (int32_t)uVar22))) {
                fVar51 = *(float *)(iVar25 + 4);
                do {
                    fVar45 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                    if (fVar45 < fVar51) {
                        if (0.0 <= fVar45) {
                            fVar45 = fVar51 - fVar45;
                            goto code_r0x000180149ee6;
                        }
                        break;
                    }
                    iVar41 = iVar41 + 1;
                } while (iVar41 < (int32_t)uVar22);
                fVar45 = fVar51 - 1.0;
code_r0x000180149ee6:
                fVar54 = fVar51 - fVar49;
                if (fVar45 <= fVar51 - fVar49) {
                    fVar54 = fVar45;
                }
                if (fVar54 <= 0.0) break;
                iVar39 = 0;
                fVar51 = fVar50 / (float)iVar41;
                if (fVar54 <= fVar50 / (float)iVar41) {
                    fVar51 = fVar54;
                }
                if (3 < iVar41) {
                    do {
                        iVar23 = (int64_t)iVar39;
                        iVar39 = iVar39 + 4;
                        fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar55 = fVar45 - fVar49;
                        fVar54 = fVar51;
                        if (fVar55 <= fVar51) {
                            fVar54 = fVar55;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                        fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar46 = fVar45 - fVar49;
                        fVar55 = fVar51;
                        if (fVar46 <= fVar51) {
                            fVar55 = fVar46;
                        }
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar45 - fVar55;
                        fVar45 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar47 = fVar45 - fVar49;
                        fVar46 = fVar51;
                        if (fVar47 <= fVar51) {
                            fVar46 = fVar47;
                        }
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar45 - fVar46;
                        fVar45 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar48 = fVar45 - fVar49;
                        fVar47 = fVar51;
                        if (fVar48 <= fVar51) {
                            fVar47 = fVar48;
                        }
                        fVar50 = (((fVar50 - fVar54) - fVar55) - fVar46) - fVar47;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar45 - fVar47;
                    } while (iVar39 < iVar41 + -3);
                }
                while (iVar39 < iVar41) {
                    iVar23 = (int64_t)iVar39;
                    iVar39 = iVar39 + 1;
                    fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar55 = fVar45 - fVar49;
                    fVar54 = fVar51;
                    if (fVar55 <= fVar51) {
                        fVar54 = fVar55;
                    }
                    fVar50 = fVar50 - fVar54;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                }
            }
            iVar41 = 0;
            fVar51 = 0.0;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 4;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar48 = (float)(int32_t)fVar49;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar48;
                    fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                    fVar46 = (float)(int32_t)fVar45;
                    *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar46;
                    fVar50 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                    fVar55 = (float)(int32_t)fVar50;
                    *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar55;
                    fVar54 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                    fVar47 = (float)(int32_t)fVar54;
                    *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar47;
                    fVar51 = (fVar49 - fVar48) + fVar51 + (fVar45 - fVar46) + (fVar50 - fVar55) + (fVar54 - fVar47);
                } while (iVar41 < (int32_t)(uVar22 - 3));
            }
            for (; iVar41 < (int32_t)uVar22; iVar41 = iVar41 + 1) {
                fVar49 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                fVar45 = (float)(int32_t)fVar49;
                *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc) = fVar45;
                fVar51 = fVar51 + (fVar49 - fVar45);
            }
            while (0.0 < fVar51) {
                iVar41 = 0;
                if (3 < (int32_t)uVar22) {
                    do {
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar23 = (int64_t)iVar41;
                        fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 - fVar45 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar50 = *(float *)(iVar25 + 0x14 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar50) {
                            fVar50 = 1.0;
                        }
                        fVar51 = (fVar51 - fVar45) - fVar50;
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar49 + fVar50;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x20 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar41 = iVar41 + 4;
                        fVar49 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x2c + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar49 + fVar45;
                    } while (iVar41 < (int32_t)(uVar22 - 3));
                }
                while (iVar41 < (int32_t)uVar22) {
                    if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 1;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                    if (1.0 <= fVar45) {
                        fVar45 = 1.0;
                    }
                    fVar51 = fVar51 - fVar45;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                }
            }
        }
code_r0x00018014a22a:
        iVar41 = iVar32 + uVar22;
        if (iVar32 < iVar41) {
            arg1 = var_128h;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar25 = (int64_t)iVar32;
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x10 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0xc + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x1c + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x18 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x28 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar25 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x24 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar25 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar24 = 0;
                        }
                        var_100h[iVar24 * 4 + -1] =
                             var_100h[iVar24 * 4 + -1] - (*(float *)(iVar25 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar25 + 0x1c + iVar23) = fVar49;
                    }
                    iVar32 = iVar32 + 4;
                } while (iVar32 < iVar41 + -3);
                if (iVar41 <= iVar32) goto code_r0x00018014a4d3;
            }
            do {
                fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + (int64_t)iVar32 * 0xc);
                if (0.0 <= fVar51) {
                    iVar25 = *piVar42;
                    fVar49 = 1.0;
                    if (1.0 <= fVar51) {
                        fVar49 = fVar51;
                    }
                    iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc) * 0x38;
                    uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                    if ((uVar22 & 0x40) == 0) {
                        iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                    } else {
                        iVar24 = 0;
                    }
                    var_100h[iVar24 * 4 + -1] =
                         var_100h[iVar24 * 4 + -1] - (*(float *)(iVar23 + 0x1c + iVar25) - fVar49);
                    *(float *)(iVar23 + 0x1c + iVar25) = fVar49;
                }
                iVar32 = iVar32 + 1;
                puVar34 = (undefined8 *)var_118h;
                pfVar43 = (float *)var_110h;
            } while (iVar32 < iVar41);
        } else {
code_r0x00018014a4d3:
            puVar34 = (undefined8 *)(arg1 + 0x38);
            pfVar43 = (float *)(arg1 + 0x40);
        }
    }
code_r0x00018014a4db:
    uVar35 = 0;
    auVar53 = ZEXT816(0);
    *(undefined4 *)(arg1 + 0x54) = 0;
    uVar22 = uVar35;
    if (0 < (int32_t)var_108h) {
        do {
            iVar25 = *piVar42;
            iVar23 = (int64_t)(int32_t)uVar22 * 0x38;
            *(float *)(iVar23 + 0x18 + iVar25) = auVar53._0_4_;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_108h + -1) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            auVar53._0_4_ = auVar53._0_4_ + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_108h);
    }
    fVar49 = auVar53._0_4_ + var_100h[1];
    fVar51 = var_100h[1] + var_108h._4_4_;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    uVar22 = uVar35;
    if (0 < (int32_t)(uint32_t)var_f8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar49;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)((uint32_t)var_f8h + -1)) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar49 = fVar49 + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)(uint32_t)var_f8h);
    }
    fVar51 = var_f8h._4_4_ + var_ech;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    fVar45 = (*(float *)(arg1 + 0x40) - *(float *)puVar34) - var_e8h._4_4_;
    fVar51 = 0.0;
    if (0.0 <= fVar45) {
        fVar51 = fVar45;
    }
    if (var_ech + fVar49 <= fVar51) {
        fVar51 = var_ech + fVar49;
    }
    uVar22 = uVar35;
    if (0 < (int32_t)var_e8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h + (uint32_t)var_f8h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar51;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_e8h + -1) {
                fVar49 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar49 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar51 = fVar51 + fVar49 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_e8h);
    }
    fVar51 = var_e8h._4_4_ + var_dch;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    func_0x00018011f640(arg1 + 0xa0, 0);
    if ((!bVar44) && (*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1)) {
        *(undefined4 *)(arg1 + 0x20) = 0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x20);
    if (((*(uint32_t *)(arg1 + 0x20) == 0) && (uVar22 = uVar35, *(int32_t *)(arg1 + 0x24) == 0)) && (var_130h != 0)) {
        uVar28 = *(uint32_t *)var_130h;
        *(uint32_t *)(arg1 + 0x20) = uVar28;
        uVar22 = uVar28;
    }
    *(uint32_t *)(arg1 + 0x2c) = uVar22;
    *(undefined *)(arg1 + 0x84) = 0;
    iVar25 = *(int64_t *)(iVar38 + 0x23c0);
    if (((iVar25 != 0) && (*(int64_t *)(iVar25 + 0x4c0) != 0)) &&
       (*(int64_t *)(*(int64_t *)(iVar25 + 0x4c0) + 0x40) == arg1)) {
        uVar28 = *(uint32_t *)(iVar25 + 200);
        *(uint32_t *)(arg1 + 0x2c) = uVar28;
    }
    if (uVar28 != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (0 < iVar32) {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar35 * 0x38;
                if (*(uint32_t *)(uVar26 + iVar25) == uVar28) {
                    if ((*(uint8_t *)(uVar26 + 4 + iVar25) & 0xc0) != 0) break;
                    fVar51 = *pfVar43;
                    fVar49 = *(float *)puVar34;
                    fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
                    iVar41 = (int32_t)(uVar26 / 0x38);
                    if ((int32_t)var_108h + -1 < iVar41) {
                        fVar50 = (float)((uint32_t)fVar45 ^ 0x80000000);
                    } else {
                        fVar50 = 0.0;
                    }
                    fVar54 = *(float *)(uVar26 + 0x18 + iVar25) - var_108h._4_4_;
                    fVar50 = fVar54 + fVar50;
                    if (iVar32 - (int32_t)var_e8h <= iVar41 + 1) {
                        fVar45 = 1.0;
                    }
                    fVar55 = *(float *)(uVar26 + 0x1c + iVar25);
                    *(undefined4 *)(arg1 + 100) = 0;
                    fVar45 = fVar54 + fVar55 + fVar45;
                    if (*(float *)(arg1 + 0x60) <= fVar50) {
                        fVar51 = (((fVar51 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech;
                        if (fVar45 - fVar50 < fVar51) {
                            if (*(float *)(arg1 + 0x60) < fVar45 - fVar51) {
                                *(float *)(arg1 + 0x60) = fVar45 - fVar51;
                                fVar51 = (fVar50 - fVar51) - *(float *)(arg1 + 0x5c);
                                if (fVar51 <= 0.0) {
                                    fVar51 = 0.0;
                                }
                                *(float *)(arg1 + 100) = fVar51;
                            }
                            break;
                        }
                    }
                    fVar45 = *(float *)(arg1 + 0x5c) - fVar45;
                    *(float *)(arg1 + 0x60) = fVar50;
                    if (fVar45 <= 0.0) {
                        fVar45 = 0.0;
                    }
                    *(float *)(arg1 + 100) = fVar45;
                    break;
                }
                uVar35 = uVar35 + 1;
            } while ((int32_t)uVar35 < iVar32);
        }
        goto code_r0x00018014a9b6;
    }
    if ((*pcVar40 == '\0') || (cVar15 = func_0x000180108120(puVar34, pfVar43, 1), cVar15 == '\0'))
    goto code_r0x00018014a9b6;
    iVar25 = *(int64_t *)(iVar38 + 0x15e0);
    if (((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) != 0) &&
        ((((iVar23 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) + 0x428), iVar23 != 0 &&
           (*(char *)(iVar23 + 0x10a) != '\0')) && (iVar23 != *(int64_t *)(iVar25 + 0x428))) &&
         (((*(uint32_t *)(iVar23 + 0x14) >> 0x1b & 1) != 0 || ((*(uint32_t *)(iVar23 + 0x14) >> 0x1a & 1) != 0)))))) &&
       (iVar24 = *(int64_t *)(iVar25 + 0x418), *(int64_t *)(iVar24 + 0x418) != iVar23)) {
        do {
            if (iVar24 == iVar23) goto code_r0x00018014a8ae;
            iVar24 = *(int64_t *)(iVar24 + 0x410);
        } while (iVar24 != 0);
        goto code_r0x00018014a9b6;
    }
code_r0x00018014a8ae:
    if ((*(int64_t *)(iVar25 + 0x48) != *(int64_t *)(*(int64_t *)0x180781f28 + 0x2168)) &&
       ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) == 0 ||
        (*(int64_t *)(iVar25 + 0x428) != *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) + 0x428)))))
    goto code_r0x00018014a9b6;
    pfVar31 = (float *)(iVar38 + 0x128);
    if (*(char *)(iVar38 + 0xbaa) == '\0') {
        pfVar31 = (float *)(iVar38 + 300);
    }
    iVar32 = *(int32_t *)(arg1 + 0x1c);
    uVar26 = (uint64_t)((*(char *)(iVar38 + 0xbaa) != '\0') + 0x295);
    iVar25 = *(int64_t *)0x180781f28;
    piVar20 = (int32_t *)func_0x0001800f45c0(*(int64_t *)0x180781f28, uVar26);
    if (iVar32 == 0) {
        bVar44 = *(char *)(piVar20 + 2) == '\0';
code_r0x00018014a936:
        if (bVar44) {
code_r0x00018014a938:
            fVar51 = *pfVar31;
            if (fVar51 != 0.0) {
                fVar49 = *(float *)puVar34;
                fVar45 = *pfVar43;
                *(undefined4 *)(arg1 + 100) = 0;
                fVar51 = *(float *)(arg1 + 0x60) -
                         (((((fVar45 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech) * fVar51) / 3.0;
                fVar49 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar49);
                if (fVar49 <= fVar51) {
                    fVar51 = fVar49;
                }
                if (fVar51 <= 0.0) {
                    fVar51 = 0.0;
                }
                *(float *)(arg1 + 0x60) = fVar51;
            }
        }
    } else {
        if (*piVar20 == iVar32) goto code_r0x00018014a938;
        if (*(char *)(piVar20 + 2) == '\0') {
            bVar44 = *piVar20 == -1;
            goto code_r0x00018014a936;
        }
    }
    *(int32_t *)(iVar25 + -0x130 + uVar26 * 0xc) = iVar32;
    *(int32_t *)(iVar25 + -0x134 + uVar26 * 0xc) = iVar32;
    *(undefined2 *)(iVar25 + -300 + uVar26 * 0xc) = 0;
code_r0x00018014a9b6:
    fVar51 = *(float *)puVar34;
    fVar45 = *(float *)(arg1 + 0x54) - (*pfVar43 - fVar51);
    fVar49 = *(float *)(arg1 + 0x5c);
    if (fVar45 <= *(float *)(arg1 + 0x5c)) {
        fVar49 = fVar45;
    }
    if (fVar49 <= 0.0) {
        fVar49 = 0.0;
    }
    *(float *)(arg1 + 0x5c) = fVar49;
    fVar50 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar51);
    fVar45 = *(float *)(arg1 + 0x60);
    if (fVar50 <= *(float *)(arg1 + 0x60)) {
        fVar45 = fVar50;
    }
    if (fVar45 <= 0.0) {
        fVar45 = 0.0;
    }
    *(float *)(arg1 + 0x60) = fVar45;
    if (fVar49 == fVar45) {
        *(undefined4 *)(arg1 + 0x68) = 0;
    } else {
        fVar54 = *(float *)(iVar38 + 0x12f8) * 70.0;
        fVar50 = *(float *)(arg1 + 0x68);
        if (*(float *)(arg1 + 0x68) <= fVar54) {
            fVar50 = fVar54;
        }
        fVar54 = (float)((uint32_t)(fVar45 - fVar49) & 0x7fffffff) / 0.3;
        if (fVar50 <= fVar54) {
            fVar50 = fVar54;
        }
        *(float *)(arg1 + 0x68) = fVar50;
        fVar54 = fVar45;
        if ((*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1) &&
           (*(float *)(arg1 + 100) <= *(float *)(iVar38 + 0x12f8) * 10.0)) {
            fVar50 = fVar50 * *(float *)(iVar38 + 0x48);
            if (fVar45 <= fVar49) {
                fVar54 = fVar49;
                if ((fVar45 < fVar49) && (fVar54 = fVar49 - fVar50, fVar54 <= fVar45)) {
                    fVar54 = fVar45;
                }
            } else {
                fVar54 = fVar50 + fVar49;
                if (fVar45 <= fVar54) {
                    fVar54 = fVar45;
                }
            }
        }
        *(float *)(arg1 + 0x5c) = fVar54;
    }
    uVar18 = *puVar34;
    *(float *)(arg1 + 0x6c) = fVar51 + var_108h._4_4_ + var_100h[1];
    *(float *)(arg1 + 0x70) = (*(float *)(arg1 + 0x40) - var_e8h._4_4_) - var_ech;
    iVar38 = *(int64_t *)(iVar38 + 0x15e0);
    *(undefined8 *)(iVar38 + 0x158) = uVar18;
    var_128h = CONCAT44(*(float *)(arg1 + 0x44) - *(float *)(arg1 + 0x3c), *(undefined4 *)(arg1 + 0x54));
    func_0x00018010bbf0(&var_128h);
    fVar49 = *(float *)(arg1 + 0x58) + *(float *)puVar34;
    fVar51 = *(float *)(iVar38 + 0x178);
    if (*(float *)(iVar38 + 0x178) <= fVar49) {
        fVar51 = fVar49;
    }
    *(float *)(iVar38 + 0x178) = fVar51;
    func_0x000180459870(var_d8h ^ (uint64_t)auStackY_198);
    return;
code_r0x000180149c5c:
    uVar22 = (int32_t)uVar26 + 1;
    uVar26 = (uint64_t)uVar22;
    if (iVar39 <= (int32_t)uVar22) goto code_r0x000180149c63;
    goto code_r0x000180149c50;
}

// ============================================================
// Function: FUN_18014aa34
// Address: 0x18014aa34
// Size: 324 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_144h
// WARNING: Variable defined which should be unmapped: var_178h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180148fa0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined auVar3 [16];
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    bool bVar13;
    bool bVar14;
    char cVar15;
    uint8_t uVar16;
    int32_t iVar17;
    undefined8 uVar18;
    int64_t iVar19;
    int32_t *piVar20;
    uint32_t uVar21;
    uint32_t uVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    uint64_t uVar26;
    undefined4 *puVar27;
    uint32_t uVar28;
    undefined4 *puVar29;
    uint32_t *puVar30;
    float *pfVar31;
    int32_t iVar32;
    uint32_t *puVar33;
    undefined8 *puVar34;
    uint32_t uVar35;
    int32_t iVar36;
    undefined4 *puVar37;
    int64_t iVar38;
    int32_t iVar39;
    char *pcVar40;
    int32_t iVar41;
    int64_t *piVar42;
    float *pfVar43;
    bool bVar44;
    float fVar45;
    float fVar46;
    float fVar47;
    float fVar48;
    float fVar49;
    float fVar50;
    float fVar51;
    undefined auVar52 [16];
    undefined auVar53 [16];
    float fVar54;
    undefined4 unaff_XMM12_Db;
    undefined4 unaff_XMM12_Dc;
    undefined4 unaff_XMM12_Dd;
    float fVar55;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_198 [32];
    int64_t var_178h;
    undefined4 in_stack_fffffffffffffe98;
    undefined4 in_stack_fffffffffffffe9c;
    undefined4 uVar56;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int32_t var_148h;
    int64_t var_144h;
    undefined4 uStack_13c;
    undefined4 uVar57;
    undefined4 in_stack_fffffffffffffecc;
    int64_t var_130h;
    int64_t var_128h;
    float var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    float var_100h [2];
    int64_t var_f8h;
    float var_f0h;
    float var_ech;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar38 = *(int64_t *)0x180781f28;
    var_d8h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_198;
    fVar51 = *(float *)(arg1 + 0x48);
    var_118h = arg1 + 0x38;
    *(undefined *)(arg1 + 0x83) = 0;
    fVar49 = *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38);
    var_110h = arg1 + 0x40;
    uVar22 = *(uint32_t *)(arg1 + 8);
    *(float *)(arg1 + 0x48) = fVar49;
    uVar56 = CONCAT31((unkint3)((uint32_t)in_stack_fffffffffffffe9c >> 8), fVar49 < fVar51);
    auVar3._4_4_ = unaff_XMM12_Dc;
    auVar3._0_4_ = unaff_XMM12_Db;
    auVar3._8_4_ = unaff_XMM12_Dd;
    auVar3._12_4_ = 0;
    _var_98h = auVar3 << 0x20;
    bVar44 = false;
    uVar28 = 0;
    uVar35 = 0;
    _var_108h = ZEXT816(0);
    _var_f8h = ZEXT816(0);
    _var_e8h = ZEXT816(0);
    bVar13 = false;
    if (0 < (int32_t)uVar22) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)(arg1 + 0x10);
            iVar23 = (int64_t)(int32_t)uVar35 * 0x38;
            if ((*(int32_t *)(iVar23 + 0x10 + iVar25) < *(int32_t *)(arg1 + 0x34)) ||
               (*(char *)(iVar23 + 0x30 + iVar25) != '\0')) {
                if (*(int32_t *)(arg1 + 0x2c) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x2c) = 0;
                }
                if (*(int32_t *)(arg1 + 0x20) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x20) = 0;
                }
                if (*(int32_t *)(arg1 + 0x24) == *(int32_t *)(iVar23 + iVar25)) {
                    *(undefined4 *)(arg1 + 0x24) = 0;
                }
            } else {
                if (uVar28 != uVar35) {
                    auVar3 = *(undefined (*) [16])(iVar23 + 0x10 + iVar25);
                    puVar37 = (undefined4 *)(iVar23 + 0x20 + iVar25);
                    uVar57 = *puVar37;
                    uVar1 = puVar37[1];
                    uVar2 = puVar37[2];
                    uVar4 = puVar37[3];
                    uVar18 = *(undefined8 *)(iVar23 + 0x30 + iVar25);
                    iVar24 = (int64_t)(int32_t)uVar28 * 0x38;
                    *(undefined (*) [16])(iVar24 + iVar25) = *(undefined (*) [16])(iVar23 + iVar25);
                    *(undefined (*) [16])(iVar24 + 0x10 + iVar25) = auVar3;
                    puVar37 = (undefined4 *)(iVar24 + 0x20 + iVar25);
                    *puVar37 = uVar57;
                    puVar37[1] = uVar1;
                    puVar37[2] = uVar2;
                    puVar37[3] = uVar4;
                    *(undefined8 *)(iVar24 + 0x30 + iVar25) = uVar18;
                }
                iVar23 = (int64_t)(int32_t)uVar28 * 0x38;
                iVar25 = *(int64_t *)(arg1 + 0x10);
                uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                *(int16_t *)(iVar23 + 0x2e + iVar25) = (int16_t)uVar28;
                if ((uVar22 & 0x40) == 0) {
                    uVar26 = (uint64_t)(((uVar22 & 0x80) != 0) + 1);
                } else {
                    uVar26 = 0;
                }
                if (0 < (int32_t)uVar28) {
                    uVar22 = *(uint32_t *)(*(int64_t *)(arg1 + 0x10) + -0x34 + iVar23);
                    cVar15 = '\0';
                    if ((uVar22 & 0x40) == 0) {
                        cVar15 = ((uVar22 & 0x80) != 0) + '\x01';
                    }
                    if ((int32_t)uVar26 == 0) {
                        if (cVar15 == '\0') goto code_r0x000180149140;
                        bVar44 = true;
                    }
                    if (cVar15 == '\x02') {
                        if ((int32_t)uVar26 != 2) {
                            bVar44 = true;
                        }
                        var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                        uVar28 = uVar28 + 1;
                        goto code_r0x000180149172;
                    }
                }
code_r0x000180149140:
                var_100h[uVar26 * 4 + -2] = (float)((int32_t)var_100h[uVar26 * 4 + -2] + 1);
                uVar28 = uVar28 + 1;
            }
code_r0x000180149172:
            uVar22 = *(uint32_t *)(arg1 + 8);
            uVar35 = uVar35 + 1;
            bVar13 = bVar44;
        } while ((int32_t)uVar35 < (int32_t)uVar22);
    }
    uVar35 = 8;
    var_128h = arg1;
    if (uVar22 != uVar28) {
        iVar32 = *(int32_t *)(arg1 + 0xc);
        if (iVar32 < (int32_t)uVar28) {
            uVar22 = uVar35;
            if (iVar32 != 0) {
                uVar22 = iVar32 / 2 + iVar32;
            }
            uVar21 = uVar28;
            if ((int32_t)uVar28 < (int32_t)uVar22) {
                uVar21 = uVar22;
            }
            func_0x00018011f970(arg1 + 8, uVar21);
        }
        *(uint32_t *)(arg1 + 8) = uVar28;
        uVar22 = uVar28;
    }
    piVar42 = (int64_t *)(arg1 + 0x10);
    if ((bVar44) && (1 < uVar22)) {
        fcn.18046f0d0(CONCAT44(uVar56, in_stack_fffffffffffffe98));
    }
    fVar51 = *(float *)(iVar38 + 0xdf4);
    if (((int32_t)var_108h < 1) || (var_100h[1] = fVar51, (int32_t)((int32_t)var_e8h + (uint32_t)var_f8h) < 1)) {
        var_100h[1] = 0.0;
    }
    if (((int32_t)(uint32_t)var_f8h < 1) || (var_ech = fVar51, (int32_t)var_e8h < 1)) {
        var_ech = 0.0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x28);
    uVar21 = 0;
    uVar28 = 0;
    if (uVar22 != 0) {
        *(undefined4 *)(arg1 + 0x28) = 0;
        uVar28 = uVar22;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x24);
    if (uVar22 != 0) {
        *(uint32_t *)(arg1 + 0x20) = uVar22;
        *(undefined4 *)(arg1 + 0x24) = 0;
        uVar28 = uVar22;
    }
    if (*(int32_t *)(arg1 + 0x7c) != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (iVar32 < 1) {
code_r0x00018014939d:
            *(undefined4 *)(arg1 + 0x7c) = 0;
        } else {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar21 * 0x38;
                puVar37 = (undefined4 *)(uVar26 + iVar25);
                if (*(int32_t *)(uVar26 + iVar25) == *(int32_t *)(arg1 + 0x7c)) {
                    if ((puVar37[1] & 0x20) == 0) {
                        iVar41 = (int32_t)(uVar26 / 0x38) + (int32_t)*(int16_t *)(arg1 + 0x80);
                        if ((-1 < iVar41) && (iVar41 < iVar32)) {
                            puVar29 = (undefined4 *)((int64_t)iVar41 * 0x38 + iVar25);
                            if (((puVar29[1] & 0x20) == 0) && (((puVar29[1] ^ puVar37[1]) & 0xc0) == 0)) {
                                uVar18 = *(undefined8 *)(puVar37 + 0xc);
                                uVar57 = *puVar37;
                                uVar1 = puVar37[1];
                                uVar2 = puVar37[2];
                                uVar4 = puVar37[3];
                                uVar5 = puVar37[4];
                                uVar6 = puVar37[5];
                                uVar7 = puVar37[6];
                                uVar8 = puVar37[7];
                                uVar9 = puVar37[8];
                                uVar10 = puVar37[9];
                                uVar11 = puVar37[10];
                                uVar12 = puVar37[0xb];
                                if (*(int16_t *)(arg1 + 0x80) < 1) {
                                    puVar37 = puVar29 + 0xe;
                                    puVar27 = puVar29;
                                } else {
                                    puVar27 = puVar37 + 0xe;
                                }
                                fcn.180498030(puVar37, puVar27);
                                *puVar29 = uVar57;
                                puVar29[1] = uVar1;
                                puVar29[2] = uVar2;
                                puVar29[3] = uVar4;
                                puVar29[4] = uVar5;
                                puVar29[5] = uVar6;
                                puVar29[6] = uVar7;
                                puVar29[7] = uVar8;
                                puVar29[8] = uVar9;
                                puVar29[9] = uVar10;
                                puVar29[10] = uVar11;
                                puVar29[0xb] = uVar12;
                                *(undefined8 *)(puVar29 + 0xc) = uVar18;
                                if (((*(uint32_t *)(arg1 + 0x18) & 0x400000) != 0) &&
                                   (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0)) {
                                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) =
                                         *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
                                }
                                if (*(uint32_t *)(arg1 + 0x7c) == *(uint32_t *)(arg1 + 0x20)) {
                                    uVar28 = *(uint32_t *)(arg1 + 0x7c);
                                }
                            }
                        }
                    }
                    goto code_r0x00018014939d;
                }
                uVar21 = uVar21 + 1;
            } while ((int32_t)uVar21 < iVar32);
            *(undefined4 *)(arg1 + 0x7c) = 0;
        }
    }
    iVar25 = *(int64_t *)0x180781f28;
    puVar33 = (uint32_t *)0x0;
    if ((*(uint8_t *)(arg1 + 0x18) & 4) != 0) {
        uVar57 = *(undefined4 *)(arg1 + 0x3c);
        var_148h = 0;
        fVar49 = *(float *)(*(int64_t *)0x180781f28 + 0xde0);
        iVar23 = *(int64_t *)0x180781f28 + 0x20c0;
        iVar24 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
        uVar1 = *(undefined4 *)(iVar24 + 0x158);
        uVar2 = *(undefined4 *)(iVar24 + 0x15c);
        *(float *)(iVar24 + 0x158) = *(float *)(arg1 + 0x38) - fVar49;
        *(undefined4 *)(iVar24 + 0x15c) = uVar57;
        *(float *)(arg1 + 0x38) = fVar49 + fVar45 + *(float *)(arg1 + 0x38);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        uVar57 = *(undefined4 *)(iVar25 + 0xed8);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        fVar49 = *(float *)(iVar25 + 0xedc);
        fcn.18011f2b0(iVar23, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar57;
            *(float *)(iVar25 + 0xedc) = fVar49 * 0.5;
        }
        iVar25 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        uVar57 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x102c);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar25 + 0x1020) = 0;
            *(undefined8 *)(iVar25 + 0x1028) = 0;
        }
        cVar15 = func_0x00018013d0a0();
        fcn.1800f6770(2);
        if (cVar15 != '\0') {
            iVar32 = 0;
            if (0 < *(int32_t *)(arg1 + 8)) {
                do {
                    puVar30 = (uint32_t *)((int64_t)iVar32 * 0x38 + *piVar42);
                    if (((puVar30[1] & 0x200000) == 0) &&
                       (cVar15 = fcn.180146c70(CONCAT44(uStack_13c, var_144h._4_4_), 
                                               CONCAT44(in_stack_fffffffffffffecc, uVar57)), cVar15 != '\0')) {
                        puVar33 = puVar30;
                    }
                    iVar32 = iVar32 + 1;
                } while (iVar32 < *(int32_t *)(arg1 + 8));
            }
            iVar25 = *(int64_t *)0x180781f28;
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2790) + -1;
            iVar32 = func_0x000180498f10(*(undefined8 *)(*(int64_t *)(iVar25 + 0x15e0) + 8), &var_148h);
            if (iVar32 == 0) {
                func_0x00018010d5c0();
            } else if (*(code **)(iVar25 + 0x2a40) != (code *)0x0) {
                (**(code **)(iVar25 + 0x2a40))(iVar25, *(undefined8 *)(iVar25 + 0x2a48));
            }
        }
        *(undefined4 *)(iVar24 + 0x158) = uVar1;
        *(undefined4 *)(iVar24 + 0x15c) = uVar2;
        if (puVar33 != (uint32_t *)0x0) {
            uVar28 = *puVar33;
            *(uint32_t *)(arg1 + 0x20) = uVar28;
        }
    }
    iVar41 = 1;
    uVar22 = *(uint32_t *)(arg1 + 8);
    var_144h._0_4_ = (int32_t)var_e8h + (int32_t)var_108h;
    var_148h = 0;
    iVar32 = *(int32_t *)(iVar38 + 0x257c);
    var_144h._4_4_ = (int32_t)var_108h;
    if (iVar32 < (int32_t)uVar22) {
        if (iVar32 != 0) {
            uVar35 = iVar32 / 2 + iVar32;
        }
        uVar21 = uVar22;
        if ((int32_t)uVar22 < (int32_t)uVar35) {
            uVar21 = uVar35;
        }
        if (iVar32 < (int32_t)uVar21) {
            uVar18 = fcn.18046d050((int64_t)(int32_t)uVar21 * 0xc);
            if (*(int64_t *)(iVar38 + 0x2580) != 0) {
                fcn.180498030(uVar18);
                fcn.180460d90(*(undefined8 *)(iVar38 + 0x2580));
            }
            *(undefined8 *)(iVar38 + 0x2580) = uVar18;
            *(uint32_t *)(iVar38 + 0x257c) = uVar21;
        }
    }
    *(uint32_t *)(iVar38 + 0x2578) = uVar22;
    if ((*(uint8_t *)(arg1 + 0x18) & 0x80) == 0) {
        fVar49 = 1.0;
    } else {
        fVar49 = *(float *)(iVar38 + 0xe40);
    }
    iVar32 = *(int32_t *)(arg1 + 8);
    iVar39 = 0;
    var_130h = 0;
    bVar44 = false;
    uVar22 = 0xffffffff;
    bVar13 = false;
    if (0 < iVar32) {
        do {
            bVar44 = bVar13;
            iVar25 = *(int64_t *)0x180781f28;
            puVar33 = (uint32_t *)((int64_t)iVar39 * 0x38 + *piVar42);
            if (((var_130h == 0) || (*(int32_t *)(var_130h + 0x14) < (int32_t)puVar33[5])) &&
               ((puVar33[1] & 0x200000) == 0)) {
                var_130h = (int64_t)puVar33;
            }
            uVar35 = *puVar33;
            if (uVar35 == *(uint32_t *)(arg1 + 0x20)) {
                bVar44 = true;
            }
            if ((uVar28 == 0) && (*(uint32_t *)(iVar38 + 0x23a4) == uVar35)) {
                uVar28 = uVar35;
            }
            auVar52 = ZEXT416(puVar33[9]);
            if ((float)puVar33[9] < 0.0) {
                uVar35 = puVar33[1];
                var_178h._0_4_ = 0xbf800000;
                fcn.1800fe0a0(CONCAT44(var_178h._4_4_, 0xbf800000), SUB168(_var_98h, 8));
                fVar45 = *(float *)(iVar25 + 0xddc);
                if ((uVar35 & 0x100001) == 0x100000) {
                    fVar50 = fVar45 + 1.0;
                } else {
                    fVar50 = *(float *)(iVar25 + 0x12f8) + *(float *)(iVar25 + 0xdf4) + fVar45;
                }
                fVar50 = fVar50 + var_120h + fVar45;
                auVar52 = ZEXT416((uint32_t)fVar50);
                fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8) * 20.0;
                if (fVar45 <= fVar50) {
                    auVar52 = ZEXT416((uint32_t)fVar45);
                }
            }
            uVar35 = puVar33[1];
            puVar33[8] = (uint32_t)auVar52._0_4_;
            if ((uVar35 >> 0x15 & 1) == 0) {
                if (auVar52._0_4_ <= *(float *)(iVar38 + 0xe3c)) {
                    auVar52._0_4_ = *(float *)(iVar38 + 0xe3c);
                }
                puVar33[8] = auVar52._0_4_;
            }
            if ((uVar35 & 0x40) == 0) {
                uVar35 = ((uVar35 & 0x80) != 0) + 1;
            } else {
                uVar35 = 0;
            }
            uVar26 = (uint64_t)uVar35;
            if (uVar35 == uVar22) {
                fVar50 = auVar52._0_4_ + fVar51;
                fVar45 = fVar51;
            } else {
                fVar50 = auVar52._0_4_ + 0.0;
                fVar45 = 0.0;
            }
            var_100h[uVar26 * 4 + -1] = fVar50 + var_100h[uVar26 * 4 + -1];
            fVar50 = (float)puVar33[8];
            if (fVar49 <= (float)puVar33[8]) {
                fVar50 = fVar49;
            }
            var_100h[uVar26 * 4] = fVar50 + fVar45 + var_100h[uVar26 * 4];
            iVar23 = (int64_t)(&var_148h)[uVar26];
            (&var_148h)[uVar26] = (&var_148h)[uVar26] + 1;
            iVar25 = *(int64_t *)(iVar38 + 0x2580);
            *(int32_t *)(iVar25 + iVar23 * 0xc) = iVar39;
            iVar39 = iVar39 + 1;
            uVar22 = puVar33[8];
            *(uint32_t *)(iVar25 + 8 + iVar23 * 0xc) = uVar22;
            *(uint32_t *)(iVar25 + 4 + iVar23 * 0xc) = uVar22;
            fVar45 = (float)puVar33[8];
            if (fVar45 <= 1.0) {
                fVar45 = 1.0;
            }
            puVar33[7] = (uint32_t)fVar45;
            iVar32 = *(int32_t *)(arg1 + 8);
            uVar22 = uVar35;
            bVar13 = bVar44;
        } while (iVar39 < iVar32);
    }
    uVar22 = *(uint32_t *)(arg1 + 0x18);
    *(float *)(arg1 + 0x58) = var_100h[1] + var_108h._4_4_ + 0.0 + var_f8h._4_4_ + var_ech + var_e8h._4_4_ + var_dch;
    iVar25 = *(int64_t *)0x180781f28;
    if (((uVar22 & 0x200) == 0) && (-1 < (char)uVar22)) {
        bVar14 = false;
code_r0x00018014992e:
        bVar13 = bVar14;
        fVar51 = var_e0h + var_dch + var_100h[0] + var_100h[1] + 0.0 + var_f0h + var_ech;
    } else {
        bVar13 = true;
        bVar14 = true;
        if ((uVar22 & 0x200) == 0) goto code_r0x00018014992e;
        fVar51 = *(float *)(arg1 + 0x54);
    }
    if ((((fVar51 <= *(float *)(arg1 + 0x40) - *(float *)(arg1 + 0x38)) || (iVar32 < 2)) || ((uVar22 & 0x10) != 0)) ||
       (!bVar13)) {
        *(undefined *)(arg1 + 0x86) = 0;
    } else {
        *(undefined *)(arg1 + 0x86) = 1;
        var_148h = 0;
        fVar51 = *(float *)(iVar25 + 0x12f8);
        iVar23 = *(int64_t *)(iVar25 + 0x15e0);
        fVar54 = fVar51 - 2.0;
        fVar45 = *(float *)(iVar25 + 0xde0);
        uVar18 = *(undefined8 *)(iVar25 + 0xed0);
        uVar57 = *(undefined4 *)(iVar23 + 0x158);
        uVar1 = *(undefined4 *)(iVar25 + 0xed8);
        fVar50 = *(float *)(iVar25 + 0xedc);
        fVar55 = fVar54 + fVar54;
        var_120h = *(float *)(iVar23 + 0x15c);
        var_144h._0_4_ = *(undefined4 *)(iVar25 + 0xed0);
        var_144h._4_4_ = *(undefined4 *)(iVar25 + 0xed4);
        uStack_13c = *(undefined4 *)(iVar25 + 0xed8);
        fcn.18011f2b0(iVar25 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar25 + 0x20bc) != 0) {
            *(undefined8 *)(iVar25 + 0xed0) = uVar18;
            *(undefined4 *)(iVar25 + 0xed8) = uVar1;
            *(float *)(iVar25 + 0xedc) = fVar50 * 0.5;
        }
        iVar24 = *(int64_t *)0x180781f28;
        var_148h = 0x15;
        var_144h._0_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1020);
        var_144h._4_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1024);
        uStack_13c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1028);
        fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_148h);
        if (*(int32_t *)(iVar24 + 0x20bc) != 0x15) {
            *(undefined8 *)(iVar24 + 0x1020) = 0;
            *(undefined8 *)(iVar24 + 0x1028) = 0;
        }
        iVar24 = *(int64_t *)0x180781f28;
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 10;
        piVar20 = (int32_t *)(iVar24 + 0x2100);
        iVar32 = *(int32_t *)(iVar24 + 0x2104);
        uVar1 = *(undefined4 *)(iVar24 + 0x1f78);
        if (*piVar20 == iVar32) {
            iVar39 = *piVar20 + 1;
            if (iVar32 == 0) {
                iVar32 = 8;
            } else {
                iVar32 = iVar32 / 2 + iVar32;
            }
            if (iVar39 < iVar32) {
                iVar39 = iVar32;
            }
            fcn.18011fb10(piVar20, iVar39);
        }
        *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + (int64_t)*piVar20 * 4) = uVar1;
        *piVar20 = *piVar20 + 1;
        uVar1 = *(undefined4 *)(iVar25 + 0xa8);
        uVar2 = *(undefined4 *)(iVar25 + 0xac);
        *(undefined4 *)(iVar25 + 0xa8) = 0x3e800000;
        *(undefined4 *)(iVar25 + 0xac) = 0x3e4ccccd;
        fVar46 = *(float *)(arg1 + 0x40) - fVar55;
        fVar50 = *(float *)(arg1 + 0x38);
        if (*(float *)(arg1 + 0x38) <= fVar46) {
            fVar50 = fVar46;
        }
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50;
        uVar16 = func_0x00018013a9f0(0x180645ba0, 0, CONCAT44(fVar45 + fVar45 + fVar51, fVar54));
        *(undefined4 *)(iVar23 + 0x15c) = *(undefined4 *)(arg1 + 0x3c);
        *(float *)(iVar23 + 0x158) = fVar50 + fVar54;
        cVar15 = func_0x00018013a9f0(0x180645ba4, 1);
        iVar24 = *(int64_t *)0x180781f28;
        if (cVar15 == '\0') {
            iVar32 = (uVar16 ^ 1) - 1;
        } else {
            iVar32 = 1;
        }
        iVar39 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
        if (iVar39 < 2) {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48));
            }
        } else {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar39 + -1;
            *(undefined4 *)(iVar24 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar24 + 0x2108) + -8 + (int64_t)iVar39 * 4)
            ;
        }
        fcn.1800f6770();
        *(undefined4 *)(iVar25 + 0xac) = uVar2;
        *(undefined4 *)(iVar25 + 0xa8) = uVar1;
        if (iVar32 == 0) {
            puVar33 = (uint32_t *)0x0;
code_r0x000180149cf6:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
            if ((puVar33 != (uint32_t *)0x0) && (uVar28 = *puVar33, (puVar33[1] & 0x200000) == 0)) {
                *(uint32_t *)(arg1 + 0x20) = uVar28;
            }
        } else {
            if ((*(int32_t *)(arg1 + 0x20) != 0) && (iVar39 = *(int32_t *)(arg1 + 8), 0 < iVar39)) {
                uVar26 = 0;
                iVar25 = *piVar42;
code_r0x000180149c50:
                if (*(int32_t *)(uVar26 * 0x38 + iVar25) != *(int32_t *)(arg1 + 0x20)) goto code_r0x000180149c5c;
                uVar26 = (uVar26 * 0x38) / 0x38;
                iVar36 = (int32_t)uVar26 + iVar32;
                do {
                    if ((iVar36 < 0) || (iVar17 = iVar36, iVar39 <= iVar36)) {
                        iVar17 = (int32_t)uVar26;
                    }
                    puVar33 = (uint32_t *)((int64_t)iVar17 * 0x38 + iVar25);
                } while ((((*(uint32_t *)(iVar25 + 4 + (int64_t)iVar17 * 0x38) & 0x200000) != 0) &&
                         (iVar36 = iVar36 + iVar32, -1 < iVar36)) &&
                        (uVar26 = (uint64_t)(uint32_t)((int32_t)uVar26 + iVar32), iVar36 < iVar39));
                goto code_r0x000180149cf6;
            }
code_r0x000180149c63:
            *(float *)(iVar23 + 0x15c) = var_120h;
            *(undefined4 *)(iVar23 + 0x158) = uVar57;
            *(float *)(arg1 + 0x40) = *(float *)(arg1 + 0x40) - (fVar55 + 1.0);
        }
    }
    pfVar43 = (float *)(arg1 + 0x40);
    pcVar40 = (char *)(arg1 + 0x86);
    puVar34 = (undefined8 *)(arg1 + 0x38);
    if ((uVar28 == 0) && ((char)uVar56 != '\0')) {
        uVar28 = *(uint32_t *)(arg1 + 0x20);
    }
    fVar51 = *pfVar43 - *(float *)puVar34;
    fVar45 = var_e8h._4_4_ + var_dch + var_108h._4_4_ + var_100h[1];
    if (fVar51 <= fVar45) {
        fVar50 = fVar45 - fVar51;
    } else {
        fVar50 = (var_f8h._4_4_ + var_ech) - ((fVar51 - (var_108h._4_4_ + var_100h[1])) - (var_e8h._4_4_ + var_dch));
        if (fVar50 <= 0.0) {
            fVar50 = 0.0;
        }
    }
    if (1.0 <= fVar50) {
        if ((*(uint32_t *)(arg1 + 0x18) & 0x180) == 0) {
            if (fVar45 < fVar51) goto code_r0x00018014a4db;
code_r0x000180149e0c:
            uVar22 = (int32_t)var_e8h + (int32_t)var_108h;
            if (fVar51 <= fVar45) {
                iVar32 = 0;
            } else {
                iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            }
        } else {
            if (fVar51 <= fVar45) goto code_r0x000180149e0c;
            iVar32 = (int32_t)var_e8h + (int32_t)var_108h;
            uVar22 = (uint32_t)var_f8h;
        }
        iVar25 = *(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc;
        if (uVar22 == 1) {
            if (0.0 <= *(float *)(iVar25 + 4)) {
                fVar50 = *(float *)(iVar25 + 4) - fVar50;
                if (fVar50 <= fVar49) {
                    fVar50 = fVar49;
                }
                *(float *)(iVar25 + 4) = fVar50;
            }
        } else {
            if (1 < uVar22) {
                fcn.18046f0d0(CONCAT44(uVar56, uVar28));
            }
            while ((0.001 < fVar50 && (iVar41 < (int32_t)uVar22))) {
                fVar51 = *(float *)(iVar25 + 4);
                do {
                    fVar45 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                    if (fVar45 < fVar51) {
                        if (0.0 <= fVar45) {
                            fVar45 = fVar51 - fVar45;
                            goto code_r0x000180149ee6;
                        }
                        break;
                    }
                    iVar41 = iVar41 + 1;
                } while (iVar41 < (int32_t)uVar22);
                fVar45 = fVar51 - 1.0;
code_r0x000180149ee6:
                fVar54 = fVar51 - fVar49;
                if (fVar45 <= fVar51 - fVar49) {
                    fVar54 = fVar45;
                }
                if (fVar54 <= 0.0) break;
                iVar39 = 0;
                fVar51 = fVar50 / (float)iVar41;
                if (fVar54 <= fVar50 / (float)iVar41) {
                    fVar51 = fVar54;
                }
                if (3 < iVar41) {
                    do {
                        iVar23 = (int64_t)iVar39;
                        iVar39 = iVar39 + 4;
                        fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar55 = fVar45 - fVar49;
                        fVar54 = fVar51;
                        if (fVar55 <= fVar51) {
                            fVar54 = fVar55;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                        fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar46 = fVar45 - fVar49;
                        fVar55 = fVar51;
                        if (fVar46 <= fVar51) {
                            fVar55 = fVar46;
                        }
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar45 - fVar55;
                        fVar45 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar47 = fVar45 - fVar49;
                        fVar46 = fVar51;
                        if (fVar47 <= fVar51) {
                            fVar46 = fVar47;
                        }
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar45 - fVar46;
                        fVar45 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar48 = fVar45 - fVar49;
                        fVar47 = fVar51;
                        if (fVar48 <= fVar51) {
                            fVar47 = fVar48;
                        }
                        fVar50 = (((fVar50 - fVar54) - fVar55) - fVar46) - fVar47;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar45 - fVar47;
                    } while (iVar39 < iVar41 + -3);
                }
                while (iVar39 < iVar41) {
                    iVar23 = (int64_t)iVar39;
                    iVar39 = iVar39 + 1;
                    fVar45 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar55 = fVar45 - fVar49;
                    fVar54 = fVar51;
                    if (fVar55 <= fVar51) {
                        fVar54 = fVar55;
                    }
                    fVar50 = fVar50 - fVar54;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar45 - fVar54;
                }
            }
            iVar41 = 0;
            fVar51 = 0.0;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 4;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar48 = (float)(int32_t)fVar49;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar48;
                    fVar45 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                    fVar46 = (float)(int32_t)fVar45;
                    *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar46;
                    fVar50 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                    fVar55 = (float)(int32_t)fVar50;
                    *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar55;
                    fVar54 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                    fVar47 = (float)(int32_t)fVar54;
                    *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar47;
                    fVar51 = (fVar49 - fVar48) + fVar51 + (fVar45 - fVar46) + (fVar50 - fVar55) + (fVar54 - fVar47);
                } while (iVar41 < (int32_t)(uVar22 - 3));
            }
            for (; iVar41 < (int32_t)uVar22; iVar41 = iVar41 + 1) {
                fVar49 = *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc);
                fVar45 = (float)(int32_t)fVar49;
                *(float *)(iVar25 + 4 + (int64_t)iVar41 * 0xc) = fVar45;
                fVar51 = fVar51 + (fVar49 - fVar45);
            }
            while (0.0 < fVar51) {
                iVar41 = 0;
                if (3 < (int32_t)uVar22) {
                    do {
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar23 = (int64_t)iVar41;
                        fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 - fVar45 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x10 + iVar23 * 0xc);
                        fVar50 = *(float *)(iVar25 + 0x14 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar50) {
                            fVar50 = 1.0;
                        }
                        fVar51 = (fVar51 - fVar45) - fVar50;
                        *(float *)(iVar25 + 0x10 + iVar23 * 0xc) = fVar49 + fVar50;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        fVar49 = *(float *)(iVar25 + 0x1c + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x20 + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x1c + iVar23 * 0xc) = fVar49 + fVar45;
                        if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                        iVar41 = iVar41 + 4;
                        fVar49 = *(float *)(iVar25 + 0x28 + iVar23 * 0xc);
                        fVar45 = *(float *)(iVar25 + 0x2c + iVar23 * 0xc) - fVar49;
                        if (1.0 <= fVar45) {
                            fVar45 = 1.0;
                        }
                        fVar51 = fVar51 - fVar45;
                        *(float *)(iVar25 + 0x28 + iVar23 * 0xc) = fVar49 + fVar45;
                    } while (iVar41 < (int32_t)(uVar22 - 3));
                }
                while (iVar41 < (int32_t)uVar22) {
                    if (fVar51 <= 0.0) goto code_r0x00018014a22a;
                    iVar23 = (int64_t)iVar41;
                    iVar41 = iVar41 + 1;
                    fVar49 = *(float *)(iVar25 + 4 + iVar23 * 0xc);
                    fVar45 = *(float *)(iVar25 + 8 + iVar23 * 0xc) - fVar49;
                    if (1.0 <= fVar45) {
                        fVar45 = 1.0;
                    }
                    fVar51 = fVar51 - fVar45;
                    *(float *)(iVar25 + 4 + iVar23 * 0xc) = fVar49 + fVar45;
                }
            }
        }
code_r0x00018014a22a:
        iVar41 = iVar32 + uVar22;
        if (iVar32 < iVar41) {
            arg1 = var_128h;
            if (3 < (int32_t)uVar22) {
                do {
                    iVar25 = (int64_t)iVar32;
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x10 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0xc + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x1c + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar24 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x18 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar24 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar19 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar19 = 0;
                        }
                        var_100h[iVar19 * 4 + -1] =
                             var_100h[iVar19 * 4 + -1] - (*(float *)(iVar24 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar24 + 0x1c + iVar23) = fVar49;
                    }
                    fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 0x28 + iVar25 * 0xc);
                    if (0.0 <= fVar51) {
                        iVar23 = *piVar42;
                        fVar49 = 1.0;
                        if (1.0 <= fVar51) {
                            fVar49 = fVar51;
                        }
                        iVar25 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + 0x24 + iVar25 * 0xc) * 0x38;
                        uVar22 = *(uint32_t *)(iVar25 + 4 + iVar23);
                        if ((uVar22 & 0x40) == 0) {
                            iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                        } else {
                            iVar24 = 0;
                        }
                        var_100h[iVar24 * 4 + -1] =
                             var_100h[iVar24 * 4 + -1] - (*(float *)(iVar25 + 0x1c + iVar23) - fVar49);
                        *(float *)(iVar25 + 0x1c + iVar23) = fVar49;
                    }
                    iVar32 = iVar32 + 4;
                } while (iVar32 < iVar41 + -3);
                if (iVar41 <= iVar32) goto code_r0x00018014a4d3;
            }
            do {
                fVar51 = (float)(int32_t)*(float *)(*(int64_t *)(iVar38 + 0x2580) + 4 + (int64_t)iVar32 * 0xc);
                if (0.0 <= fVar51) {
                    iVar25 = *piVar42;
                    fVar49 = 1.0;
                    if (1.0 <= fVar51) {
                        fVar49 = fVar51;
                    }
                    iVar23 = (int64_t)*(int32_t *)(*(int64_t *)(iVar38 + 0x2580) + (int64_t)iVar32 * 0xc) * 0x38;
                    uVar22 = *(uint32_t *)(iVar23 + 4 + iVar25);
                    if ((uVar22 & 0x40) == 0) {
                        iVar24 = (uint64_t)((uVar22 & 0x80) != 0) + 1;
                    } else {
                        iVar24 = 0;
                    }
                    var_100h[iVar24 * 4 + -1] =
                         var_100h[iVar24 * 4 + -1] - (*(float *)(iVar23 + 0x1c + iVar25) - fVar49);
                    *(float *)(iVar23 + 0x1c + iVar25) = fVar49;
                }
                iVar32 = iVar32 + 1;
                puVar34 = (undefined8 *)var_118h;
                pfVar43 = (float *)var_110h;
            } while (iVar32 < iVar41);
        } else {
code_r0x00018014a4d3:
            puVar34 = (undefined8 *)(arg1 + 0x38);
            pfVar43 = (float *)(arg1 + 0x40);
        }
    }
code_r0x00018014a4db:
    uVar35 = 0;
    auVar53 = ZEXT816(0);
    *(undefined4 *)(arg1 + 0x54) = 0;
    uVar22 = uVar35;
    if (0 < (int32_t)var_108h) {
        do {
            iVar25 = *piVar42;
            iVar23 = (int64_t)(int32_t)uVar22 * 0x38;
            *(float *)(iVar23 + 0x18 + iVar25) = auVar53._0_4_;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_108h + -1) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            auVar53._0_4_ = auVar53._0_4_ + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_108h);
    }
    fVar49 = auVar53._0_4_ + var_100h[1];
    fVar51 = var_100h[1] + var_108h._4_4_;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    uVar22 = uVar35;
    if (0 < (int32_t)(uint32_t)var_f8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar49;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)((uint32_t)var_f8h + -1)) {
                fVar51 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar51 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar49 = fVar49 + fVar51 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)(uint32_t)var_f8h);
    }
    fVar51 = var_f8h._4_4_ + var_ech;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    fVar45 = (*(float *)(arg1 + 0x40) - *(float *)puVar34) - var_e8h._4_4_;
    fVar51 = 0.0;
    if (0.0 <= fVar45) {
        fVar51 = fVar45;
    }
    if (var_ech + fVar49 <= fVar51) {
        fVar51 = var_ech + fVar49;
    }
    uVar22 = uVar35;
    if (0 < (int32_t)var_e8h) {
        do {
            iVar23 = (int64_t)(int32_t)(uVar22 + (int32_t)var_108h + (uint32_t)var_f8h) * 0x38;
            iVar25 = *piVar42;
            *(float *)(iVar23 + 0x18 + iVar25) = fVar51;
            *(undefined4 *)(iVar23 + 0x28 + iVar25) = 0xffffffff;
            if ((int32_t)uVar22 < (int32_t)var_e8h + -1) {
                fVar49 = *(float *)(iVar38 + 0xdf4);
            } else {
                fVar49 = 0.0;
            }
            uVar22 = uVar22 + 1;
            fVar51 = fVar51 + fVar49 + *(float *)(iVar23 + 0x1c + iVar25);
        } while ((int32_t)uVar22 < (int32_t)var_e8h);
    }
    fVar51 = var_e8h._4_4_ + var_dch;
    if (fVar51 <= 0.0) {
        fVar51 = 0.0;
    }
    *(float *)(arg1 + 0x54) = fVar51 + *(float *)(arg1 + 0x54);
    func_0x00018011f640(arg1 + 0xa0, 0);
    if ((!bVar44) && (*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1)) {
        *(undefined4 *)(arg1 + 0x20) = 0;
    }
    uVar22 = *(uint32_t *)(arg1 + 0x20);
    if (((*(uint32_t *)(arg1 + 0x20) == 0) && (uVar22 = uVar35, *(int32_t *)(arg1 + 0x24) == 0)) && (var_130h != 0)) {
        uVar28 = *(uint32_t *)var_130h;
        *(uint32_t *)(arg1 + 0x20) = uVar28;
        uVar22 = uVar28;
    }
    *(uint32_t *)(arg1 + 0x2c) = uVar22;
    *(undefined *)(arg1 + 0x84) = 0;
    iVar25 = *(int64_t *)(iVar38 + 0x23c0);
    if (((iVar25 != 0) && (*(int64_t *)(iVar25 + 0x4c0) != 0)) &&
       (*(int64_t *)(*(int64_t *)(iVar25 + 0x4c0) + 0x40) == arg1)) {
        uVar28 = *(uint32_t *)(iVar25 + 200);
        *(uint32_t *)(arg1 + 0x2c) = uVar28;
    }
    if (uVar28 != 0) {
        iVar32 = *(int32_t *)(arg1 + 8);
        if (0 < iVar32) {
            iVar25 = *piVar42;
            do {
                uVar26 = (uint64_t)uVar35 * 0x38;
                if (*(uint32_t *)(uVar26 + iVar25) == uVar28) {
                    if ((*(uint8_t *)(uVar26 + 4 + iVar25) & 0xc0) != 0) break;
                    fVar51 = *pfVar43;
                    fVar49 = *(float *)puVar34;
                    fVar45 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
                    iVar41 = (int32_t)(uVar26 / 0x38);
                    if ((int32_t)var_108h + -1 < iVar41) {
                        fVar50 = (float)((uint32_t)fVar45 ^ 0x80000000);
                    } else {
                        fVar50 = 0.0;
                    }
                    fVar54 = *(float *)(uVar26 + 0x18 + iVar25) - var_108h._4_4_;
                    fVar50 = fVar54 + fVar50;
                    if (iVar32 - (int32_t)var_e8h <= iVar41 + 1) {
                        fVar45 = 1.0;
                    }
                    fVar55 = *(float *)(uVar26 + 0x1c + iVar25);
                    *(undefined4 *)(arg1 + 100) = 0;
                    fVar45 = fVar54 + fVar55 + fVar45;
                    if (*(float *)(arg1 + 0x60) <= fVar50) {
                        fVar51 = (((fVar51 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech;
                        if (fVar45 - fVar50 < fVar51) {
                            if (*(float *)(arg1 + 0x60) < fVar45 - fVar51) {
                                *(float *)(arg1 + 0x60) = fVar45 - fVar51;
                                fVar51 = (fVar50 - fVar51) - *(float *)(arg1 + 0x5c);
                                if (fVar51 <= 0.0) {
                                    fVar51 = 0.0;
                                }
                                *(float *)(arg1 + 100) = fVar51;
                            }
                            break;
                        }
                    }
                    fVar45 = *(float *)(arg1 + 0x5c) - fVar45;
                    *(float *)(arg1 + 0x60) = fVar50;
                    if (fVar45 <= 0.0) {
                        fVar45 = 0.0;
                    }
                    *(float *)(arg1 + 100) = fVar45;
                    break;
                }
                uVar35 = uVar35 + 1;
            } while ((int32_t)uVar35 < iVar32);
        }
        goto code_r0x00018014a9b6;
    }
    if ((*pcVar40 == '\0') || (cVar15 = func_0x000180108120(puVar34, pfVar43, 1), cVar15 == '\0'))
    goto code_r0x00018014a9b6;
    iVar25 = *(int64_t *)(iVar38 + 0x15e0);
    if (((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) != 0) &&
        ((((iVar23 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) + 0x428), iVar23 != 0 &&
           (*(char *)(iVar23 + 0x10a) != '\0')) && (iVar23 != *(int64_t *)(iVar25 + 0x428))) &&
         (((*(uint32_t *)(iVar23 + 0x14) >> 0x1b & 1) != 0 || ((*(uint32_t *)(iVar23 + 0x14) >> 0x1a & 1) != 0)))))) &&
       (iVar24 = *(int64_t *)(iVar25 + 0x418), *(int64_t *)(iVar24 + 0x418) != iVar23)) {
        do {
            if (iVar24 == iVar23) goto code_r0x00018014a8ae;
            iVar24 = *(int64_t *)(iVar24 + 0x410);
        } while (iVar24 != 0);
        goto code_r0x00018014a9b6;
    }
code_r0x00018014a8ae:
    if ((*(int64_t *)(iVar25 + 0x48) != *(int64_t *)(*(int64_t *)0x180781f28 + 0x2168)) &&
       ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) == 0 ||
        (*(int64_t *)(iVar25 + 0x428) != *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1600) + 0x428)))))
    goto code_r0x00018014a9b6;
    pfVar31 = (float *)(iVar38 + 0x128);
    if (*(char *)(iVar38 + 0xbaa) == '\0') {
        pfVar31 = (float *)(iVar38 + 300);
    }
    iVar32 = *(int32_t *)(arg1 + 0x1c);
    uVar26 = (uint64_t)((*(char *)(iVar38 + 0xbaa) != '\0') + 0x295);
    iVar25 = *(int64_t *)0x180781f28;
    piVar20 = (int32_t *)func_0x0001800f45c0(*(int64_t *)0x180781f28, uVar26);
    if (iVar32 == 0) {
        bVar44 = *(char *)(piVar20 + 2) == '\0';
code_r0x00018014a936:
        if (bVar44) {
code_r0x00018014a938:
            fVar51 = *pfVar31;
            if (fVar51 != 0.0) {
                fVar49 = *(float *)puVar34;
                fVar45 = *pfVar43;
                *(undefined4 *)(arg1 + 100) = 0;
                fVar51 = *(float *)(arg1 + 0x60) -
                         (((((fVar45 - fVar49) - var_108h._4_4_) - var_e8h._4_4_) - var_ech) * fVar51) / 3.0;
                fVar49 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar49);
                if (fVar49 <= fVar51) {
                    fVar51 = fVar49;
                }
                if (fVar51 <= 0.0) {
                    fVar51 = 0.0;
                }
                *(float *)(arg1 + 0x60) = fVar51;
            }
        }
    } else {
        if (*piVar20 == iVar32) goto code_r0x00018014a938;
        if (*(char *)(piVar20 + 2) == '\0') {
            bVar44 = *piVar20 == -1;
            goto code_r0x00018014a936;
        }
    }
    *(int32_t *)(iVar25 + -0x130 + uVar26 * 0xc) = iVar32;
    *(int32_t *)(iVar25 + -0x134 + uVar26 * 0xc) = iVar32;
    *(undefined2 *)(iVar25 + -300 + uVar26 * 0xc) = 0;
code_r0x00018014a9b6:
    fVar51 = *(float *)puVar34;
    fVar45 = *(float *)(arg1 + 0x54) - (*pfVar43 - fVar51);
    fVar49 = *(float *)(arg1 + 0x5c);
    if (fVar45 <= *(float *)(arg1 + 0x5c)) {
        fVar49 = fVar45;
    }
    if (fVar49 <= 0.0) {
        fVar49 = 0.0;
    }
    *(float *)(arg1 + 0x5c) = fVar49;
    fVar50 = *(float *)(arg1 + 0x54) - (*(float *)(arg1 + 0x40) - fVar51);
    fVar45 = *(float *)(arg1 + 0x60);
    if (fVar50 <= *(float *)(arg1 + 0x60)) {
        fVar45 = fVar50;
    }
    if (fVar45 <= 0.0) {
        fVar45 = 0.0;
    }
    *(float *)(arg1 + 0x60) = fVar45;
    if (fVar49 == fVar45) {
        *(undefined4 *)(arg1 + 0x68) = 0;
    } else {
        fVar54 = *(float *)(iVar38 + 0x12f8) * 70.0;
        fVar50 = *(float *)(arg1 + 0x68);
        if (*(float *)(arg1 + 0x68) <= fVar54) {
            fVar50 = fVar54;
        }
        fVar54 = (float)((uint32_t)(fVar45 - fVar49) & 0x7fffffff) / 0.3;
        if (fVar50 <= fVar54) {
            fVar50 = fVar54;
        }
        *(float *)(arg1 + 0x68) = fVar50;
        fVar54 = fVar45;
        if ((*(int32_t *)(iVar38 + 4) <= *(int32_t *)(arg1 + 0x34) + 1) &&
           (*(float *)(arg1 + 100) <= *(float *)(iVar38 + 0x12f8) * 10.0)) {
            fVar50 = fVar50 * *(float *)(iVar38 + 0x48);
            if (fVar45 <= fVar49) {
                fVar54 = fVar49;
                if ((fVar45 < fVar49) && (fVar54 = fVar49 - fVar50, fVar54 <= fVar45)) {
                    fVar54 = fVar45;
                }
            } else {
                fVar54 = fVar50 + fVar49;
                if (fVar45 <= fVar54) {
                    fVar54 = fVar45;
                }
            }
        }
        *(float *)(arg1 + 0x5c) = fVar54;
    }
    uVar18 = *puVar34;
    *(float *)(arg1 + 0x6c) = fVar51 + var_108h._4_4_ + var_100h[1];
    *(float *)(arg1 + 0x70) = (*(float *)(arg1 + 0x40) - var_e8h._4_4_) - var_ech;
    iVar38 = *(int64_t *)(iVar38 + 0x15e0);
    *(undefined8 *)(iVar38 + 0x158) = uVar18;
    var_128h = CONCAT44(*(float *)(arg1 + 0x44) - *(float *)(arg1 + 0x3c), *(undefined4 *)(arg1 + 0x54));
    func_0x00018010bbf0(&var_128h);
    fVar49 = *(float *)(arg1 + 0x58) + *(float *)puVar34;
    fVar51 = *(float *)(iVar38 + 0x178);
    if (*(float *)(iVar38 + 0x178) <= fVar49) {
        fVar51 = fVar49;
    }
    *(float *)(iVar38 + 0x178) = fVar51;
    func_0x000180459870(var_d8h ^ (uint64_t)auStackY_198);
    return;
code_r0x000180149c5c:
    uVar22 = (int32_t)uVar26 + 1;
    uVar26 = (uint64_t)uVar22;
    if (iVar39 <= (int32_t)uVar22) goto code_r0x000180149c63;
    goto code_r0x000180149c50;
}

// ============================================================
// Function: FUN_18014ab80
// Address: 0x18014ab80
// Size: 228 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h

void fcn.18014ab80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    int32_t *piVar2;
    undefined4 uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    int64_t var_8h;
    int64_t var_48h;
    int32_t var_38h;
    int64_t var_30h;
    int64_t var_24h;
    int64_t var_1ch;
    
    uVar3 = *(undefined4 *)(arg3 + 200);
    uVar5 = (uint32_t)arg2 | 0x100000;
    if (*(char *)(arg3 + 0x114) != '\0') {
        uVar5 = (uint32_t)arg2;
    }
    var_38h = *(int32_t *)(arg1 + 0x30);
    if (var_38h == -1) {
        var_38h = *(int32_t *)(*(int64_t *)0x180781f28 + 4) + -1;
    }
    iVar6 = *(int32_t *)(arg1 + 0xc);
    if (*(int32_t *)(arg1 + 8) == iVar6) {
        iVar8 = *(int32_t *)(arg1 + 8) + 1;
        if (iVar6 == 0) {
            iVar6 = 8;
        } else {
            iVar6 = iVar6 / 2 + iVar6;
        }
        if (iVar8 < iVar6) {
            iVar8 = iVar6;
        }
        func_0x00018011f970(arg1 + 8, iVar8);
    }
    iVar7 = (int64_t)*(int32_t *)(arg1 + 8) * 0x38;
    iVar4 = *(int64_t *)(arg1 + 0x10);
    puVar1 = (undefined4 *)(iVar7 + iVar4);
    *puVar1 = uVar3;
    puVar1[1] = uVar5;
    *(int64_t *)(puVar1 + 2) = arg3;
    piVar2 = (int32_t *)(iVar7 + 0x10 + iVar4);
    *piVar2 = var_38h;
    piVar2[1] = -1;
    piVar2[2] = 0;
    piVar2[3] = 0;
    puVar1 = (undefined4 *)(iVar7 + 0x20 + iVar4);
    *puVar1 = 0;
    puVar1[1] = 0xbf800000;
    puVar1[2] = 0xffffffff;
    puVar1[3] = 0xffffffff;
    *(undefined8 *)(iVar7 + 0x30 + iVar4) = 0;
    *(int32_t *)(arg1 + 8) = *(int32_t *)(arg1 + 8) + 1;
    return;
}

// ============================================================
// Function: FUN_18014ac70
// Address: 0x18014ac70
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014ac70(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int32_t iVar5;
    int32_t *piVar6;
    int64_t var_8h;
    
    iVar5 = (int32_t)arg2;
    if (iVar5 != 0) {
        iVar1 = *(int32_t *)(arg1 + 8);
        if (0 < iVar1) {
            iVar4 = *(int64_t *)(arg1 + 0x10);
            uVar3 = 0;
            do {
                piVar6 = (int32_t *)((uint64_t)uVar3 * 0x38 + iVar4);
                if (*piVar6 == iVar5) {
                    iVar2 = ((int64_t)piVar6 - iVar4) / 0x38;
                    iVar4 = iVar2 * 0x38 + iVar4;
                    fcn.180498030(iVar4, iVar4 + 0x38, (iVar1 - iVar2) * 0x38 + -0x38);
                    *(int32_t *)(arg1 + 8) = *(int32_t *)(arg1 + 8) + -1;
                    break;
                }
                uVar3 = uVar3 + 1;
            } while ((int32_t)uVar3 < iVar1);
        }
    }
    if (*(int32_t *)(arg1 + 0x2c) == iVar5) {
        *(undefined4 *)(arg1 + 0x2c) = 0;
    }
    if (*(int32_t *)(arg1 + 0x20) == iVar5) {
        *(undefined4 *)(arg1 + 0x20) = 0;
    }
    if (*(int32_t *)(arg1 + 0x24) == iVar5) {
        *(undefined4 *)(arg1 + 0x24) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18014ad20
// Address: 0x18014ad20
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18014ad20(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint32_t uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar9;
    uint32_t uVar10;
    int32_t iVar11;
    float fVar13;
    float fVar14;
    float fVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    uint64_t uVar8;
    uint64_t uVar12;
    
    if ((*(uint8_t *)(arg1 + 0x18) & 1) != 0) {
        uVar10 = *(uint32_t *)(arg2 + 4) & 0xc0;
        if (uVar10 == 0) {
            fVar15 = *(float *)(arg1 + 0x60);
        } else {
            fVar15 = 0.0;
        }
        iVar3 = *(int64_t *)(arg1 + 0x10);
        fVar15 = *(float *)(arg1 + 0x38) - fVar15;
        fVar14 = (float)arg3;
        iVar6 = 1;
        if (fVar14 < fVar15 + *(float *)(arg2 + 0x18)) {
            iVar6 = -1;
        }
        uVar4 = (arg2 - iVar3) / 0x38;
        if (-1 < (int32_t)uVar4) {
            uVar5 = uVar4 & 0xffffffff;
            uVar12 = uVar4 & 0xffffffff;
            while( true ) {
                uVar8 = uVar5;
                iVar11 = (int32_t)uVar12;
                iVar7 = (int32_t)uVar8;
                if (*(int32_t *)(arg1 + 8) <= iVar7) break;
                iVar9 = uVar8 * 0x38;
                uVar1 = *(uint32_t *)(iVar9 + 4 + iVar3);
                if (((((uVar1 & 0x20) != 0) || ((uVar1 & 0xc0) != uVar10)) ||
                    ((fVar13 = fVar15 + *(float *)(iVar9 + 0x18 + iVar3), iVar11 = iVar7, iVar6 < 0 &&
                     (fVar13 - *(float *)(*(int64_t *)0x180781f28 + 0xdf4) < fVar14)))) ||
                   (((0 < iVar6 &&
                     (fVar14 < fVar13 + *(float *)(iVar9 + 0x1c + iVar3) + *(float *)(*(int64_t *)0x180781f28 + 0xdf4)))
                    || (uVar5 = (uint64_t)(uint32_t)(iVar7 + iVar6), uVar12 = uVar8, iVar7 + iVar6 < 0)))) break;
            }
            if (iVar11 != (int32_t)uVar4) {
                uVar2 = *(undefined4 *)arg2;
                *(int16_t *)(arg1 + 0x80) = (int16_t)iVar11 - (int16_t)uVar4;
                *(undefined4 *)(arg1 + 0x7c) = uVar2;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18014ad37
// Address: 0x18014ad37
// Size: 124 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18014ad20(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint32_t uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar9;
    uint32_t uVar10;
    int32_t iVar11;
    float fVar13;
    float fVar14;
    float fVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    uint64_t uVar8;
    uint64_t uVar12;
    
    if ((*(uint8_t *)(arg1 + 0x18) & 1) != 0) {
        uVar10 = *(uint32_t *)(arg2 + 4) & 0xc0;
        if (uVar10 == 0) {
            fVar15 = *(float *)(arg1 + 0x60);
        } else {
            fVar15 = 0.0;
        }
        iVar3 = *(int64_t *)(arg1 + 0x10);
        fVar15 = *(float *)(arg1 + 0x38) - fVar15;
        fVar14 = (float)arg3;
        iVar6 = 1;
        if (fVar14 < fVar15 + *(float *)(arg2 + 0x18)) {
            iVar6 = -1;
        }
        uVar4 = (arg2 - iVar3) / 0x38;
        if (-1 < (int32_t)uVar4) {
            uVar5 = uVar4 & 0xffffffff;
            uVar12 = uVar4 & 0xffffffff;
            while( true ) {
                uVar8 = uVar5;
                iVar11 = (int32_t)uVar12;
                iVar7 = (int32_t)uVar8;
                if (*(int32_t *)(arg1 + 8) <= iVar7) break;
                iVar9 = uVar8 * 0x38;
                uVar1 = *(uint32_t *)(iVar9 + 4 + iVar3);
                if (((((uVar1 & 0x20) != 0) || ((uVar1 & 0xc0) != uVar10)) ||
                    ((fVar13 = fVar15 + *(float *)(iVar9 + 0x18 + iVar3), iVar11 = iVar7, iVar6 < 0 &&
                     (fVar13 - *(float *)(*(int64_t *)0x180781f28 + 0xdf4) < fVar14)))) ||
                   (((0 < iVar6 &&
                     (fVar14 < fVar13 + *(float *)(iVar9 + 0x1c + iVar3) + *(float *)(*(int64_t *)0x180781f28 + 0xdf4)))
                    || (uVar5 = (uint64_t)(uint32_t)(iVar7 + iVar6), uVar12 = uVar8, iVar7 + iVar6 < 0)))) break;
            }
            if (iVar11 != (int32_t)uVar4) {
                uVar2 = *(undefined4 *)arg2;
                *(int16_t *)(arg1 + 0x80) = (int16_t)iVar11 - (int16_t)uVar4;
                *(undefined4 *)(arg1 + 0x7c) = uVar2;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18014adb3
// Address: 0x18014adb3
// Size: 113 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18014ad20(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint32_t uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar9;
    uint32_t uVar10;
    int32_t iVar11;
    float fVar13;
    float fVar14;
    float fVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    uint64_t uVar8;
    uint64_t uVar12;
    
    if ((*(uint8_t *)(arg1 + 0x18) & 1) != 0) {
        uVar10 = *(uint32_t *)(arg2 + 4) & 0xc0;
        if (uVar10 == 0) {
            fVar15 = *(float *)(arg1 + 0x60);
        } else {
            fVar15 = 0.0;
        }
        iVar3 = *(int64_t *)(arg1 + 0x10);
        fVar15 = *(float *)(arg1 + 0x38) - fVar15;
        fVar14 = (float)arg3;
        iVar6 = 1;
        if (fVar14 < fVar15 + *(float *)(arg2 + 0x18)) {
            iVar6 = -1;
        }
        uVar4 = (arg2 - iVar3) / 0x38;
        if (-1 < (int32_t)uVar4) {
            uVar5 = uVar4 & 0xffffffff;
            uVar12 = uVar4 & 0xffffffff;
            while( true ) {
                uVar8 = uVar5;
                iVar11 = (int32_t)uVar12;
                iVar7 = (int32_t)uVar8;
                if (*(int32_t *)(arg1 + 8) <= iVar7) break;
                iVar9 = uVar8 * 0x38;
                uVar1 = *(uint32_t *)(iVar9 + 4 + iVar3);
                if (((((uVar1 & 0x20) != 0) || ((uVar1 & 0xc0) != uVar10)) ||
                    ((fVar13 = fVar15 + *(float *)(iVar9 + 0x18 + iVar3), iVar11 = iVar7, iVar6 < 0 &&
                     (fVar13 - *(float *)(*(int64_t *)0x180781f28 + 0xdf4) < fVar14)))) ||
                   (((0 < iVar6 &&
                     (fVar14 < fVar13 + *(float *)(iVar9 + 0x1c + iVar3) + *(float *)(*(int64_t *)0x180781f28 + 0xdf4)))
                    || (uVar5 = (uint64_t)(uint32_t)(iVar7 + iVar6), uVar12 = uVar8, iVar7 + iVar6 < 0)))) break;
            }
            if (iVar11 != (int32_t)uVar4) {
                uVar2 = *(undefined4 *)arg2;
                *(int16_t *)(arg1 + 0x80) = (int16_t)iVar11 - (int16_t)uVar4;
                *(undefined4 *)(arg1 + 0x7c) = uVar2;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18014ae24
// Address: 0x18014ae24
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18014ad20(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint32_t uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar9;
    uint32_t uVar10;
    int32_t iVar11;
    float fVar13;
    float fVar14;
    float fVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    uint64_t uVar8;
    uint64_t uVar12;
    
    if ((*(uint8_t *)(arg1 + 0x18) & 1) != 0) {
        uVar10 = *(uint32_t *)(arg2 + 4) & 0xc0;
        if (uVar10 == 0) {
            fVar15 = *(float *)(arg1 + 0x60);
        } else {
            fVar15 = 0.0;
        }
        iVar3 = *(int64_t *)(arg1 + 0x10);
        fVar15 = *(float *)(arg1 + 0x38) - fVar15;
        fVar14 = (float)arg3;
        iVar6 = 1;
        if (fVar14 < fVar15 + *(float *)(arg2 + 0x18)) {
            iVar6 = -1;
        }
        uVar4 = (arg2 - iVar3) / 0x38;
        if (-1 < (int32_t)uVar4) {
            uVar5 = uVar4 & 0xffffffff;
            uVar12 = uVar4 & 0xffffffff;
            while( true ) {
                uVar8 = uVar5;
                iVar11 = (int32_t)uVar12;
                iVar7 = (int32_t)uVar8;
                if (*(int32_t *)(arg1 + 8) <= iVar7) break;
                iVar9 = uVar8 * 0x38;
                uVar1 = *(uint32_t *)(iVar9 + 4 + iVar3);
                if (((((uVar1 & 0x20) != 0) || ((uVar1 & 0xc0) != uVar10)) ||
                    ((fVar13 = fVar15 + *(float *)(iVar9 + 0x18 + iVar3), iVar11 = iVar7, iVar6 < 0 &&
                     (fVar13 - *(float *)(*(int64_t *)0x180781f28 + 0xdf4) < fVar14)))) ||
                   (((0 < iVar6 &&
                     (fVar14 < fVar13 + *(float *)(iVar9 + 0x1c + iVar3) + *(float *)(*(int64_t *)0x180781f28 + 0xdf4)))
                    || (uVar5 = (uint64_t)(uint32_t)(iVar7 + iVar6), uVar12 = uVar8, iVar7 + iVar6 < 0)))) break;
            }
            if (iVar11 != (int32_t)uVar4) {
                uVar2 = *(undefined4 *)arg2;
                *(int16_t *)(arg1 + 0x80) = (int16_t)iVar11 - (int16_t)uVar4;
                *(undefined4 *)(arg1 + 0x7c) = uVar2;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18014ae41
// Address: 0x18014ae41
// Size: 3 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18014ad20(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint32_t uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar9;
    uint32_t uVar10;
    int32_t iVar11;
    float fVar13;
    float fVar14;
    float fVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    uint64_t uVar8;
    uint64_t uVar12;
    
    if ((*(uint8_t *)(arg1 + 0x18) & 1) != 0) {
        uVar10 = *(uint32_t *)(arg2 + 4) & 0xc0;
        if (uVar10 == 0) {
            fVar15 = *(float *)(arg1 + 0x60);
        } else {
            fVar15 = 0.0;
        }
        iVar3 = *(int64_t *)(arg1 + 0x10);
        fVar15 = *(float *)(arg1 + 0x38) - fVar15;
        fVar14 = (float)arg3;
        iVar6 = 1;
        if (fVar14 < fVar15 + *(float *)(arg2 + 0x18)) {
            iVar6 = -1;
        }
        uVar4 = (arg2 - iVar3) / 0x38;
        if (-1 < (int32_t)uVar4) {
            uVar5 = uVar4 & 0xffffffff;
            uVar12 = uVar4 & 0xffffffff;
            while( true ) {
                uVar8 = uVar5;
                iVar11 = (int32_t)uVar12;
                iVar7 = (int32_t)uVar8;
                if (*(int32_t *)(arg1 + 8) <= iVar7) break;
                iVar9 = uVar8 * 0x38;
                uVar1 = *(uint32_t *)(iVar9 + 4 + iVar3);
                if (((((uVar1 & 0x20) != 0) || ((uVar1 & 0xc0) != uVar10)) ||
                    ((fVar13 = fVar15 + *(float *)(iVar9 + 0x18 + iVar3), iVar11 = iVar7, iVar6 < 0 &&
                     (fVar13 - *(float *)(*(int64_t *)0x180781f28 + 0xdf4) < fVar14)))) ||
                   (((0 < iVar6 &&
                     (fVar14 < fVar13 + *(float *)(iVar9 + 0x1c + iVar3) + *(float *)(*(int64_t *)0x180781f28 + 0xdf4)))
                    || (uVar5 = (uint64_t)(uint32_t)(iVar7 + iVar6), uVar12 = uVar8, iVar7 + iVar6 < 0)))) break;
            }
            if (iVar11 != (int32_t)uVar4) {
                uVar2 = *(undefined4 *)arg2;
                *(int16_t *)(arg1 + 0x80) = (int16_t)iVar11 - (int16_t)uVar4;
                *(undefined4 *)(arg1 + 0x7c) = uVar2;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18014ae50
// Address: 0x18014ae50
// Size: 1082 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_198h
// WARNING: Variable defined which should be unmapped: var_190h
// WARNING: Variable defined which should be unmapped: var_188h
// WARNING: Variable defined which should be unmapped: var_180h
// WARNING: Variable defined which should be unmapped: var_178h
// WARNING: Variable defined which should be unmapped: var_170h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_154h
// WARNING: [rz-ghidra] Detected overlap for variable var_150h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_166h
// WARNING: [rz-ghidra] Detected overlap for variable var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable var_167h
// WARNING: [rz-ghidra] Detected overlap for variable var_165h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_27h
// WARNING: [rz-ghidra] Detected overlap for variable var_23h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h

uint64_t fcn.18014ae50(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_c0h, int64_t arg_c8h,
                      int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h)
{
    int32_t *piVar1;
    undefined (*pauVar2) [12];
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int16_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    char *pcVar15;
    int64_t iVar16;
    char cVar17;
    int32_t iVar18;
    uint32_t uVar19;
    undefined4 uVar20;
    int64_t iVar21;
    int64_t iVar22;
    uint32_t uVar23;
    int64_t iVar24;
    uint32_t uVar25;
    int32_t *arg2_00;
    int32_t iVar27;
    undefined8 uVar28;
    int32_t iVar29;
    uint64_t uVar30;
    bool bVar31;
    bool bVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    float fVar37;
    char acStackX_8 [8];
    char *pcStackX_10;
    undefined *puStackX_18;
    uint32_t uStackX_20;
    int64_t in_stack_00000028;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    float var_150h;
    float var_14ch;
    undefined var_148h [4];
    undefined var_144h [8];
    int64_t var_13ch;
    float fStack_130;
    float fStack_12c;
    uint64_t uStack_128;
    uint32_t uStack_120;
    int32_t iStack_11c;
    int32_t iStack_118;
    undefined8 uStack_108;
    undefined8 uStack_100;
    undefined8 uStack_f8;
    undefined8 uStack_f0;
    undefined4 uStack_e8;
    unkbyte5 Stack_e4;
    undefined4 uStack_df;
    undefined2 uStack_db;
    undefined uStack_d9;
    undefined8 uStack_d8;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uVar26;
    
    iVar16 = *(int64_t *)0x180781f28;
    stack0xfffffffffffffec0 = _var_148h;
    uVar25 = (uint32_t)arg4;
    uVar30 = arg4 & 0xffffffff;
    iVar24 = *(int64_t *)0x180781f28;
    pcStackX_10 = (char *)arg2;
    puStackX_18 = (undefined *)arg3;
    uStackX_20 = uVar25;
    if (*(char *)(arg1 + 0x83) != '\0') {
        uVar3 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f80);
        uVar4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f84);
        uVar20 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f88);
        uVar5 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f8c);
        uVar7 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f90);
        uVar8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f94);
        uVar9 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f98);
        uVar10 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f9c);
        uVar11 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fa0);
        uVar12 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fa4);
        uVar13 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fa8);
        uVar14 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fac);
        uVar28 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x1fb0);
        fcn.180148fa0(arg1, arg2);
        iVar24 = *(int64_t *)0x180781f28;
        *(undefined4 *)(iVar16 + 0x1f80) = uVar3;
        *(undefined4 *)(iVar16 + 0x1f84) = uVar4;
        *(undefined4 *)(iVar16 + 0x1f88) = uVar20;
        *(undefined4 *)(iVar16 + 0x1f8c) = uVar5;
        *(undefined4 *)(iVar16 + 0x1f90) = uVar7;
        *(undefined4 *)(iVar16 + 0x1f94) = uVar8;
        *(undefined4 *)(iVar16 + 0x1f98) = uVar9;
        *(undefined4 *)(iVar16 + 0x1f9c) = uVar10;
        *(undefined4 *)(iVar16 + 0x1fa0) = uVar11;
        *(undefined4 *)(iVar16 + 0x1fa4) = uVar12;
        *(undefined4 *)(iVar16 + 0x1fa8) = uVar13;
        *(undefined4 *)(iVar16 + 0x1fac) = uVar14;
        *(undefined8 *)(iVar16 + 0x1fb0) = uVar28;
    }
    iVar22 = in_stack_00000028;
    uStack_128 = *(uint64_t *)(iVar16 + 0x15e0);
    if (*(char *)(uStack_128 + 0x10e) != '\0') {
code_r0x00018014afb2:
        return uStack_128 & 0xffffffffffffff00;
    }
    if (in_stack_00000028 == 0) {
        iVar18 = fcn.1800f5a90(pcStackX_10, 0, 
                               *(undefined4 *)
                                (*(int64_t *)(*(int64_t *)(iVar24 + 0x15e0) + 0x150) + -4 +
                                (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 0x15e0) + 0x148) * 4));
    } else {
        iVar18 = *(int32_t *)(in_stack_00000028 + 200);
        if (*(int32_t *)(iVar24 + 0x1654) == iVar18) {
            *(int32_t *)(iVar24 + 0x1658) = iVar18;
        }
        if (*(int32_t *)(iVar24 + 0x1684) == iVar18) {
            *(undefined *)(iVar24 + 0x168d) = 1;
        }
    }
    if ((arg3 != 0) && (*(char *)arg3 == '\0')) {
        _var_148h = ZEXT816(0);
        uStack_128 = func_0x00018010b530(var_148h, iVar18, 0, 2);
        goto code_r0x00018014afb2;
    }
    uVar26 = 0;
    if ((uVar25 >> 0x14 & 1) == 0) {
        if (arg3 == 0) {
            uStackX_20 = uVar25 | 0x100000;
            uVar30 = (uint64_t)uStackX_20;
        }
    } else {
        puStackX_18 = (undefined *)0x0;
    }
    if ((iVar18 != 0) && (0 < *(int32_t *)(arg1 + 8))) {
        do {
            arg2_00 = (int32_t *)(uVar26 * 0x38 + *(int64_t *)(arg1 + 0x10));
            if (*arg2_00 == iVar18) {
                bVar32 = false;
                goto code_r0x00018014b075;
            }
            uVar25 = (int32_t)uVar26 + 1;
            uVar26 = (uint64_t)uVar25;
        } while ((int32_t)uVar25 < *(int32_t *)(arg1 + 8));
    }
    uStack_108 = 0;
    uStack_100 = 0;
    uStack_f0 = 0;
    uStack_e8 = 0;
    uStack_d8 = 0;
    uStack_f8 = 0xffffffffffffffff;
    Stack_e4 = 0xffbf800000;
    uStack_df = 0xffffffff;
    uStack_db = 0xffff;
    uStack_d9 = 0xff;
    func_0x00018011f0c0(arg1 + 8, &uStack_108);
    bVar32 = true;
    arg2_00 = (int32_t *)(*(int64_t *)(arg1 + 0x10) + -0x38 + (int64_t)*(int32_t *)(arg1 + 8) * 0x38);
    *arg2_00 = iVar18;
    *(undefined *)(arg1 + 0x85) = 1;
code_r0x00018014b075:
    *(int16_t *)(arg1 + 0x8a) = (int16_t)(((int64_t)arg2_00 - *(int64_t *)(arg1 + 0x10)) / 0x38);
    if ((puStackX_18 == (undefined *)0x0) && ((uVar30 & 1) == 0)) {
        uVar28 = 0;
    } else {
        uVar28 = 1;
    }
    func_0x00018014be50(&fStack_130, pcStackX_10, uVar28);
    arg2_00[9] = -0x40800000;
    fVar34 = fStack_130;
    if ((*(uint8_t *)(iVar16 + 0x1f80) & 1) != 0) {
        fVar34 = *(float *)(iVar16 + 0x1f98);
        arg2_00[9] = (int32_t)fVar34;
    }
    if (bVar32) {
        fVar35 = 1.0;
        if (1.0 <= fVar34) {
            fVar35 = fVar34;
        }
        arg2_00[7] = (int32_t)fVar35;
    }
    arg2_00[8] = (int32_t)fVar34;
    iVar6 = *(int16_t *)(arg1 + 0x88);
    *(int16_t *)(arg1 + 0x88) = iVar6 + 1;
    *(int16_t *)(arg2_00 + 0xb) = iVar6;
    iStack_11c = arg2_00[4] + 1;
    uStack_120 = *(uint32_t *)(arg1 + 0x18);
    iStack_118 = *(int32_t *)(iVar16 + 4);
    iVar29 = *(int32_t *)(arg1 + 0x34) + 1;
    if (((uStackX_20 & 1) == 0) || (var_168h._0_1_ = '\x01', (*(uint8_t *)(arg2_00 + 1) & 1) != 0)) {
        var_168h._0_1_ = '\0';
    }
    arg2_00[4] = iStack_118;
    var_13ch._4_4_ = uStackX_20 & 0x200000;
    arg2_00[1] = uStackX_20;
    *(int64_t *)(arg2_00 + 2) = iVar22;
    if (iVar22 == 0) {
        iVar27 = *(int32_t *)(arg1 + 0xa0) + -1;
        if (*(int32_t *)(arg1 + 0xa0) == 0) {
            iVar27 = 0;
        }
        arg2_00[10] = iVar27;
        iVar24 = func_0x000180498cd0(pcStackX_10);
        func_0x0001800f64c0(arg1 + 0xa0, pcStackX_10, pcStackX_10 + iVar24 + 1);
        iVar22 = in_stack_00000028;
    } else {
        arg2_00[10] = -1;
    }
    uVar30 = uStack_128;
    if (var_13ch._4_4_ == 0) {
        if ((((iStack_11c < iStack_118) && ((*(uint8_t *)(arg1 + 0x18) & 2) != 0)) && (*(int32_t *)(arg1 + 0x24) == 0))
           && ((iStack_118 <= iVar29 || (*(int32_t *)(arg1 + 0x20) == 0)))) {
            *(int32_t *)(arg1 + 0x24) = *arg2_00;
        }
        if (((uStackX_20 & 2) != 0) && (*(int32_t *)(arg1 + 0x20) != iVar18)) {
            *(int32_t *)(arg1 + 0x24) = *arg2_00;
        }
    }
    bVar31 = *(int32_t *)(arg1 + 0x2c) == iVar18;
    var_160h._0_4_ = CONCAT31((unkint3)(uStackX_20 >> 8), bVar31);
    if (bVar31) {
        *(undefined *)(arg1 + 0x84) = 1;
    } else if ((((*(int32_t *)(arg1 + 0x20) == 0) && (iVar29 < iStack_118)) && (iVar22 == 0)) &&
              ((*(int32_t *)(arg1 + 8) == 1 && (var_160h._0_4_ = (uint32_t)bVar31, (*(uint8_t *)(arg1 + 0x18) & 2) == 0)
               ))) {
        var_160h._0_4_ = 1;
    }
    if ((iStack_11c < iStack_118) && ((iStack_118 <= iVar29 || (bVar32)))) {
        _var_148h = ZEXT816(0);
        uStack_128 = func_0x00018010b530(var_148h, iVar18, 0, 2);
        if (var_13ch._4_4_ == 0) {
            return (uint64_t)(uint8_t)var_160h;
        }
        goto code_r0x00018014afb2;
    }
    if (*(int32_t *)(arg1 + 0x20) == iVar18) {
        arg2_00[5] = *(int32_t *)(iVar16 + 4);
    }
    var_150h = (float)arg2_00[7];
    uVar3 = *(undefined4 *)(uStack_128 + 0x158);
    var_158h._4_4_ = *(float *)(arg1 + 0x3c) + 0.0;
    uVar4 = *(undefined4 *)(uStack_128 + 0x15c);
    if ((*(uint8_t *)(arg2_00 + 1) & 0xc0) == 0) {
        var_158h._0_4_ = (float)(int32_t)((float)arg2_00[6] - *(float *)(arg1 + 0x5c)) + *(float *)(arg1 + 0x38);
        *(float *)(uStack_128 + 0x158) = (float)var_158h;
        var_150h = var_150h + (float)var_158h;
        *(float *)(uStack_128 + 0x15c) = var_158h._4_4_;
        var_14ch = var_158h._4_4_ + fStack_12c;
        fVar34 = *(float *)(arg1 + 0x6c);
        if ((fVar34 <= (float)var_158h) && (var_150h < *(float *)(arg1 + 0x70) || var_150h == *(float *)(arg1 + 0x70)))
        goto code_r0x00018014b3e0;
        bVar32 = true;
        var_168h._2_1_ = '\x01';
        fStack_130 = *(float *)(arg1 + 0x70);
        if ((fVar34 <= (float)var_158h) && (fVar34 = fStack_130, (float)var_158h <= fStack_130)) {
            fVar34 = (float)var_158h;
        }
        _var_148h = CONCAT44(var_158h._4_4_ - 1.0, fVar34);
        fStack_12c = var_14ch;
        func_0x0001800fc860(var_148h, &fStack_130, 1);
    } else {
        var_158h._0_4_ = (float)arg2_00[6] + *(float *)(arg1 + 0x38);
        *(float *)(uStack_128 + 0x158) = (float)var_158h;
        var_150h = var_150h + (float)var_158h;
        *(float *)(uStack_128 + 0x15c) = var_158h._4_4_;
code_r0x00018014b3e0:
        var_14ch = var_158h._4_4_ + fStack_12c;
        bVar32 = false;
        var_168h._2_1_ = '\0';
    }
    uVar20 = *(undefined4 *)(uVar30 + 0x170);
    uVar5 = *(undefined4 *)(uVar30 + 0x174);
    var_144h._0_4_ = var_14ch - var_158h._4_4_;
    var_148h = (undefined  [4])(var_150h - (float)var_158h);
    func_0x00018010bbf0(var_148h, *(undefined4 *)(iVar16 + 0xde0));
    *(undefined4 *)(uVar30 + 0x170) = uVar20;
    *(undefined4 *)(uVar30 + 0x174) = uVar5;
    cVar17 = func_0x00018010b530(&var_158h, iVar18, 0, 0);
    uVar25 = var_13ch._4_4_;
    if (cVar17 == '\0') {
        if (bVar32) {
            func_0x0001800fc8f0();
        }
        *(undefined4 *)(uVar30 + 0x158) = uVar3;
        *(undefined4 *)(uVar30 + 0x15c) = uVar4;
        return (uint64_t)(uint8_t)var_160h;
    }
    uVar19 = 0x1010;
    if (var_13ch._4_4_ != 0) {
        uVar19 = 0x1020;
    }
    uVar23 = uVar19;
    if (*(char *)(iVar16 + 0x2400) != '\0') {
        cVar17 = func_0x0001800f3aa0(iVar16 + 0x2410);
        uVar23 = uVar19 | 0x200;
        if (cVar17 != '\0') {
            uVar23 = uVar19;
        }
    }
    if ((uStackX_20 & 0x400000) == 0) {
        var_198h = CONCAT44(var_198h._4_4_, uVar23);
        var_168h._3_1_ = func_0x000180139d40(&var_158h, iVar18, (int64_t)&var_168h + 1, acStackX_8, var_198h);
        if ((var_168h._3_1_ != 0) && (uVar25 == 0)) {
            *(int32_t *)(arg1 + 0x24) = *arg2_00;
        }
        if (acStackX_8[0] == '\0') goto code_r0x00018014b4c3;
        if (in_stack_00000028 == 0) goto code_r0x00018014b56d;
        if ((*(int32_t *)(iVar16 + 0x1654) == iVar18) && (*(char *)(iVar16 + 0x1660) != '\0')) {
            *(int64_t *)(iVar16 + 0x1678) = in_stack_00000028;
        }
code_r0x00018014b4d3:
        iVar24 = *(int64_t *)(in_stack_00000028 + 0x4c0);
        if ((((iVar24 == 0) || (*(int64_t *)(iVar24 + 0x18) != 0)) || ((*(uint32_t *)(iVar24 + 0x10) & 0x400) != 0)) ||
           (*(int32_t *)(iVar24 + 0x30) != 1)) goto code_r0x00018014b570;
        bVar32 = true;
    } else {
        var_168h._3_1_ = 0;
        acStackX_8[0] = '\0';
        var_168h._1_1_ = '\0';
code_r0x00018014b4c3:
        if (in_stack_00000028 != 0) goto code_r0x00018014b4d3;
code_r0x00018014b56d:
        iVar24 = 0;
code_r0x00018014b570:
        bVar32 = false;
    }
    iVar22 = *(int64_t *)0x180781f28;
    if (acStackX_8[0] == '\0') goto code_r0x00018014b8e9;
    if (((bVar32) && (*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0')) &&
       (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbfc))) {
        func_0x0001800faa00();
        iVar22 = *(int64_t *)0x180781f28;
        goto code_r0x00018014b8e9;
    }
    if (((iStack_11c < iStack_118) || (*(char *)(*(int64_t *)0x180781f28 + 0x120) == '\0')) ||
       (*(float *)(*(int64_t *)0x180781f28 + 0xbfc) <
        *(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4)))
    goto code_r0x00018014b8e9;
    fVar34 = 0.0;
    iVar29 = 0;
    if (*(char *)(iVar16 + 0x2400) == '\0') {
        if (((*(uint8_t *)(arg1 + 0x18) & 1) == 0) && (uVar30 = uStack_128, in_stack_00000028 == 0))
        goto code_r0x00018014b8e9;
        if ((0.0 <= *(float *)(iVar16 + 0x104)) || ((float)var_158h <= *(float *)(iVar16 + 0x118))) {
            iVar29 = 0;
            if ((*(float *)(iVar16 + 0x104) <= 0.0) || (fVar35 = *(float *)(iVar16 + 0x118), fVar35 <= var_150h))
            goto code_r0x00018014b679;
            iVar29 = 1;
            fVar34 = var_150h;
        } else {
            iVar29 = -1;
            fVar34 = *(float *)(iVar16 + 0x118);
            fVar35 = (float)var_158h;
        }
        fVar34 = fVar35 - fVar34;
        fcn.18014ad20(arg1, (int64_t)arg2_00, *(int64_t *)(iVar16 + 0x118));
    }
code_r0x00018014b679:
    uVar30 = uStack_128;
    if (((in_stack_00000028 == 0) || ((*(uint8_t *)(in_stack_00000028 + 0x14) & 4) != 0)) ||
       ((*(uint8_t *)(iVar24 + 0x10) & 0x80) != 0)) goto code_r0x00018014b8e9;
    if ((*(char *)(iVar16 + 0x2400) == '\0') || (*(int32_t *)(iVar16 + 0x241c) != iVar18)) {
        fVar35 = *(float *)(iVar16 + 0x12f8);
        fVar33 = ((float)(*(uint32_t *)(iVar16 + 0xbd4) & 0x7fffffff) - (fVar35 + fVar35)) * 0.2;
        if (0.0 <= fVar33) {
            fVar36 = fVar35 * 4.0;
            if (fVar33 <= fVar35 * 4.0) {
                fVar36 = fVar33;
            }
        } else {
            fVar36 = 0.0;
        }
        fVar33 = var_158h._4_4_ - *(float *)(iVar16 + 0x11c);
        fVar37 = *(float *)(iVar16 + 0x11c) - var_14ch;
        if (fVar33 <= fVar37) {
            fVar33 = fVar37;
        }
        if (fVar35 * 2.2 < fVar34) {
            if (iVar29 < 0) {
                iVar24 = (int64_t)arg2_00 - *(int64_t *)(arg1 + 0x10);
                iVar29 = (int32_t)(iVar24 >> 0x3f);
                bVar32 = (int32_t)(iVar24 / 0x38) + iVar29 == iVar29;
            } else {
                if (iVar29 < 1) goto code_r0x00018014b7a0;
                bVar32 = (int32_t)(((int64_t)arg2_00 - *(int64_t *)(arg1 + 0x10)) / 0x38) == *(int32_t *)(arg1 + 8) + -1
                ;
            }
            if (bVar32) goto code_r0x00018014b7a9;
        }
code_r0x00018014b7a0:
        if (fVar33 < fVar35 * 1.5 + fVar36) goto code_r0x00018014b8e9;
    }
code_r0x00018014b7a9:
    piVar1 = (int32_t *)(iVar16 + 0x28f8);
    iVar29 = *(int32_t *)(iVar16 + 0x28fc);
    if (*piVar1 == iVar29) {
        iVar27 = *piVar1 + 1;
        if (iVar29 == 0) {
            iVar29 = 8;
        } else {
            iVar29 = iVar29 / 2 + iVar29;
        }
        if (iVar27 < iVar29) {
            iVar27 = iVar29;
        }
        func_0x00018011fa30(piVar1, iVar27);
    }
    iVar24 = *(int64_t *)(iVar16 + 0x2900);
    iVar22 = (int64_t)*piVar1 * 0x40;
    *(undefined4 *)(iVar22 + iVar24) = 2;
    *(undefined4 *)(iVar22 + 4 + iVar24) = uStack_108._4_4_;
    *(undefined8 *)(iVar22 + 8 + iVar24) = 0;
    *(undefined8 *)(iVar22 + 0x10 + iVar24) = 0;
    *(undefined8 *)(iVar22 + 0x18 + iVar24) = 0;
    *(undefined4 *)(iVar22 + 0x20 + iVar24) = 0xffffffff;
    *(undefined4 *)(iVar22 + 0x24 + iVar24) = 0x3f000000;
    *(undefined *)(iVar22 + 0x28 + iVar24) = 0;
    *(undefined4 *)(iVar22 + 0x29 + iVar24) = uStack_df;
    *(undefined2 *)(iVar22 + 0x2d + iVar24) = uStack_db;
    *(undefined *)(iVar22 + 0x2f + iVar24) = uStack_d9;
    *(int64_t *)(iVar22 + 0x30 + iVar24) = in_stack_00000028;
    *(undefined8 *)(iVar22 + 0x38 + iVar24) = 0;
    *piVar1 = *piVar1 + 1;
    *(int64_t *)(iVar16 + 0x1600) = in_stack_00000028;
    func_0x0001800f9f30(*(undefined4 *)(in_stack_00000028 + 0xc4), in_stack_00000028);
    iVar22 = *(int64_t *)0x180781f28;
    fVar34 = *(float *)(*(int64_t *)(iVar16 + 0x1600) + 0x60);
    fVar35 = *(float *)(*(int64_t *)(iVar16 + 0x1600) + 100);
    *(undefined *)(iVar16 + 0x1662) = 1;
    *(float *)(iVar16 + 0x166c) = *(float *)(iVar16 + 0x166c) - (fVar34 - (float)var_158h);
    *(float *)(iVar16 + 0x1670) = *(float *)(iVar16 + 0x1670) - (fVar35 - var_158h._4_4_);
    *(undefined4 *)(iVar22 + 0x1f68) = 0xf;
    *(undefined *)(iVar22 + 0x1f6c) = 1;
    *(bool *)(iVar22 + 0x2239) = *(char *)(iVar22 + 0x223a) != '\0';
    *(undefined2 *)(iVar22 + 0x2278) = 0;
    uVar30 = uStack_128;
code_r0x00018014b8e9:
    uVar25 = uStackX_20;
    if (((*(uint32_t *)(iVar16 + 0x1fc0) & 0x100) != 0) && ((uStackX_20 >> 0x16 & 1) == 0)) {
        iVar24 = *(int64_t *)(uVar30 + 800);
        uStack_120 = uStack_120 & 0x200000;
        if ((acStackX_8[0] == '\0') && (var_168h._1_1_ == '\0')) {
            if ((uint8_t)var_160h == '\0') {
                iVar21 = 0x26;
                if (uStack_120 != 0) {
                    iVar21 = 0x23;
                }
            } else {
                iVar21 = 0x27;
                if (uStack_120 != 0) {
                    iVar21 = 0x24;
                }
            }
        } else {
            iVar21 = 0x22;
        }
        pauVar2 = (undefined (*) [12])(iVar22 + 0xd90 + (iVar21 + 0x14) * 0x10);
        var_13ch._0_4_ = *(float *)pauVar2[1] * *(float *)(iVar22 + 0xd9c);
        _var_148h = *pauVar2;
        uVar20 = fcn.1800f5fa0(var_148h);
        func_0x00018014bf10(iVar24, &var_158h, uVar25, uVar20);
        if ((((uint8_t)var_160h != '\0') && ((*(uint8_t *)(arg1 + 0x18) & 0x40) != 0)) &&
           (fVar34 = *(float *)(iVar16 + 0xe50), 0.0 < fVar34)) {
            fVar35 = (float)var_158h + 0.0;
            iVar22 = 0x3c0;
            if (uStack_120 != 0) {
                iVar22 = 0x390;
            }
            fVar37 = var_158h._4_4_ + *(float *)(iVar16 + 0x1308);
            fVar36 = var_150h + 0.0;
            pauVar2 = (undefined (*) [12])(iVar22 + 0xd90 + *(int64_t *)0x180781f28);
            var_13ch._0_4_ = *(float *)pauVar2[1] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            _var_148h = *pauVar2;
            uVar20 = fcn.1800f5fa0(var_148h);
            fVar33 = *(float *)(iVar16 + 0xe34);
            if (fVar33 <= 0.0) {
                fStack_12c = fVar37 - 0.5;
                var_198h = CONCAT44(var_198h._4_4_, fVar34);
                fStack_130 = fVar35 - 0.5;
                var_144h._0_4_ = fStack_12c;
                var_148h = (undefined  [4])(fVar36 - 0.5);
                func_0x000180126300(iVar24, &fStack_130, var_148h, uVar20, var_198h);
                uVar25 = uStackX_20;
            } else {
                fVar35 = fVar35 + fVar33;
                fVar37 = fVar33 + fVar37;
                var_144h._0_4_ = fVar37;
                var_148h = (undefined  [4])fVar35;
                if (0.5 <= fVar33) {
                    var_198h = CONCAT44(var_198h._4_4_, 0x24);
                    func_0x0001801257a0(iVar24, var_148h, fVar33, 0x1c, var_198h);
                } else {
                    iVar29 = *(int32_t *)(iVar24 + 0x54);
                    if (*(int32_t *)(iVar24 + 0x50) == iVar29) {
                        iVar27 = *(int32_t *)(iVar24 + 0x50) + 1;
                        if (iVar29 == 0) {
                            iVar29 = 8;
                        } else {
                            iVar29 = iVar29 / 2 + iVar29;
                        }
                        if (iVar27 < iVar29) {
                            iVar27 = iVar29;
                        }
                        func_0x00018011f4f0(iVar24 + 0x50, iVar27);
                    }
                    iVar29 = *(int32_t *)(iVar24 + 0x50);
                    iVar22 = *(int64_t *)(iVar24 + 0x58);
                    *(float *)(iVar22 + (int64_t)iVar29 * 8) = fVar35;
                    *(float *)(iVar22 + 4 + (int64_t)iVar29 * 8) = fVar37;
                    *(int32_t *)(iVar24 + 0x50) = *(int32_t *)(iVar24 + 0x50) + 1;
                }
                fVar36 = fVar36 - fVar33;
                var_148h = (undefined  [4])fVar36;
                if (0.5 <= fVar33) {
                    var_198h = CONCAT44(var_198h._4_4_, 0x2c);
                    func_0x0001801257a0(iVar24, var_148h, fVar33, 0x24, var_198h);
                } else {
                    iVar29 = *(int32_t *)(iVar24 + 0x54);
                    if (*(int32_t *)(iVar24 + 0x50) == iVar29) {
                        iVar27 = *(int32_t *)(iVar24 + 0x50) + 1;
                        if (iVar29 == 0) {
                            iVar29 = 8;
                        } else {
                            iVar29 = iVar29 / 2 + iVar29;
                        }
                        if (iVar27 < iVar29) {
                            iVar27 = iVar29;
                        }
                        func_0x00018011f4f0(iVar24 + 0x50, iVar27);
                    }
                    iVar29 = *(int32_t *)(iVar24 + 0x50);
                    iVar22 = *(int64_t *)(iVar24 + 0x58);
                    *(float *)(iVar22 + (int64_t)iVar29 * 8) = fVar36;
                    *(float *)(iVar22 + 4 + (int64_t)iVar29 * 8) = fVar37;
                    *(int32_t *)(iVar24 + 0x50) = *(int32_t *)(iVar24 + 0x50) + 1;
                }
                var_198h = var_198h & 0xffffffff00000000;
                func_0x0001801248e0(iVar24, *(undefined8 *)(iVar24 + 0x58), *(undefined4 *)(iVar24 + 0x50), uVar20, 
                                    var_198h, *(undefined4 *)(iVar16 + 0xe50));
                *(undefined4 *)(iVar24 + 0x50) = 0;
                uVar25 = uStackX_20;
            }
        }
        func_0x0001800f7d00(&var_158h, iVar18, 0);
        cVar17 = func_0x0001800fa150(0x20);
        iVar29 = *arg2_00;
        if ((((*(int32_t *)(arg1 + 0x20) != iVar29) && (cVar17 != '\0')) &&
            ((cVar17 = func_0x000180107ff0(1, 0, 0), cVar17 != '\0' || (cVar17 = func_0x000180108070(1), cVar17 != '\0')
             ))) && (var_13ch._4_4_ == 0)) {
            *(int32_t *)(arg1 + 0x24) = iVar29;
        }
        if ((*(uint8_t *)(arg1 + 0x18) & 8) != 0) {
            uStackX_20 = uVar25 | 4;
        }
        if (puStackX_18 == (undefined *)0x0) {
            iVar29 = 0;
        } else {
            iVar29 = iVar18;
            if (in_stack_00000028 != 0) {
                iVar29 = *(int32_t *)(in_stack_00000028 + 0x10);
            }
            iVar29 = fcn.1800f5a90(0x1806445a0, 0, iVar29);
        }
        uVar25 = uStackX_20;
        if ((char)var_168h != '\0') {
            uVar25 = uStackX_20 & 0xfffffffe;
        }
        func_0x00018014c270(iVar24, &var_158h, uVar25, *(undefined8 *)(arg1 + 0x90), pcStackX_10, iVar18, iVar29, 
                            (char)(uint32_t)var_160h, &var_168h, (int64_t)&var_168h + 4);
        if (((char)var_168h != '\0') && (puStackX_18 != (undefined *)0x0)) {
            *puStackX_18 = 0;
            if (((uint32_t)arg2_00[1] >> 0x15 & 1) == 0) {
                iVar27 = *arg2_00;
                if ((arg2_00[1] & 0x101U) == 0) {
                    *(undefined *)(arg2_00 + 0xc) = 1;
                    if (*(int32_t *)(arg1 + 0x2c) == iVar27) {
                        arg2_00[4] = -1;
                        *(undefined8 *)(arg1 + 0x20) = 0;
                    }
                } else if (*(int32_t *)(arg1 + 0x2c) != iVar27) {
                    *(int32_t *)(arg1 + 0x24) = iVar27;
                }
            }
        }
        if ((in_stack_00000028 != 0) && ((var_168h._1_1_ != '\0' || (*(int32_t *)(iVar16 + 0x163c) == iVar29)))) {
            *(uint32_t *)(iVar16 + 0x1fc0) = *(uint32_t *)(iVar16 + 0x1fc0) | 0x80;
        }
        if ((((var_168h._4_1_ != '\0') && (*(int32_t *)(iVar16 + 0x163c) == iVar18)) && (acStackX_8[0] == '\0')) &&
           (((*(uint8_t *)(arg1 + 0x18) & 0x20) == 0 && (pcVar15 = pcStackX_10, (*(uint8_t *)(arg2_00 + 1) & 0x10) == 0)
            ))) {
            for (; ((pcVar15 != (char *)0xffffffffffffffff && (*pcVar15 != '\0')) &&
                   ((*pcVar15 != '#' || (pcVar15[1] != '#')))); pcVar15 = pcVar15 + 1) {
            }
            func_0x00018010ceb0(0x180641920, (int32_t)pcVar15 - (int32_t)pcStackX_10, pcStackX_10);
        }
    }
    if (var_168h._2_1_ != '\0') {
        func_0x0001800fc8f0();
    }
    *(undefined4 *)(uStack_128 + 0x158) = uVar3;
    *(undefined4 *)(uStack_128 + 0x15c) = uVar4;
    if (var_13ch._4_4_ == 0) {
        return (uint64_t)(uint8_t)var_160h;
    }
    return (uint64_t)var_168h._3_1_;
}

// ============================================================
// Function: FUN_18014b28a
// Address: 0x18014b28a
// Size: 1835 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_198h
// WARNING: Variable defined which should be unmapped: var_190h
// WARNING: Variable defined which should be unmapped: var_188h
// WARNING: Variable defined which should be unmapped: var_180h
// WARNING: Variable defined which should be unmapped: var_178h
// WARNING: Variable defined which should be unmapped: var_170h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_154h
// WARNING: [rz-ghidra] Detected overlap for variable var_150h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_166h
// WARNING: [rz-ghidra] Detected overlap for variable var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable var_167h
// WARNING: [rz-ghidra] Detected overlap for variable var_165h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_27h
// WARNING: [rz-ghidra] Detected overlap for variable var_23h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h

uint64_t fcn.18014ae50(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_c0h, int64_t arg_c8h,
                      int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h)
{
    int32_t *piVar1;
    undefined (*pauVar2) [12];
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int16_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    char *pcVar15;
    int64_t iVar16;
    char cVar17;
    int32_t iVar18;
    uint32_t uVar19;
    undefined4 uVar20;
    int64_t iVar21;
    int64_t iVar22;
    uint32_t uVar23;
    int64_t iVar24;
    uint32_t uVar25;
    int32_t *arg2_00;
    int32_t iVar27;
    undefined8 uVar28;
    int32_t iVar29;
    uint64_t uVar30;
    bool bVar31;
    bool bVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    float fVar37;
    char acStackX_8 [8];
    char *pcStackX_10;
    undefined *puStackX_18;
    uint32_t uStackX_20;
    int64_t in_stack_00000028;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    float var_150h;
    float var_14ch;
    undefined var_148h [4];
    undefined var_144h [8];
    int64_t var_13ch;
    float fStack_130;
    float fStack_12c;
    uint64_t uStack_128;
    uint32_t uStack_120;
    int32_t iStack_11c;
    int32_t iStack_118;
    undefined8 uStack_108;
    undefined8 uStack_100;
    undefined8 uStack_f8;
    undefined8 uStack_f0;
    undefined4 uStack_e8;
    unkbyte5 Stack_e4;
    undefined4 uStack_df;
    undefined2 uStack_db;
    undefined uStack_d9;
    undefined8 uStack_d8;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uVar26;
    
    iVar16 = *(int64_t *)0x180781f28;
    stack0xfffffffffffffec0 = _var_148h;
    uVar25 = (uint32_t)arg4;
    uVar30 = arg4 & 0xffffffff;
    iVar24 = *(int64_t *)0x180781f28;
    pcStackX_10 = (char *)arg2;
    puStackX_18 = (undefined *)arg3;
    uStackX_20 = uVar25;
    if (*(char *)(arg1 + 0x83) != '\0') {
        uVar3 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f80);
        uVar4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f84);
        uVar20 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f88);
        uVar5 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f8c);
        uVar7 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f90);
        uVar8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f94);
        uVar9 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f98);
        uVar10 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f9c);
        uVar11 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fa0);
        uVar12 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fa4);
        uVar13 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fa8);
        uVar14 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fac);
        uVar28 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x1fb0);
        fcn.180148fa0(arg1, arg2);
        iVar24 = *(int64_t *)0x180781f28;
        *(undefined4 *)(iVar16 + 0x1f80) = uVar3;
        *(undefined4 *)(iVar16 + 0x1f84) = uVar4;
        *(undefined4 *)(iVar16 + 0x1f88) = uVar20;
        *(undefined4 *)(iVar16 + 0x1f8c) = uVar5;
        *(undefined4 *)(iVar16 + 0x1f90) = uVar7;
        *(undefined4 *)(iVar16 + 0x1f94) = uVar8;
        *(undefined4 *)(iVar16 + 0x1f98) = uVar9;
        *(undefined4 *)(iVar16 + 0x1f9c) = uVar10;
        *(undefined4 *)(iVar16 + 0x1fa0) = uVar11;
        *(undefined4 *)(iVar16 + 0x1fa4) = uVar12;
        *(undefined4 *)(iVar16 + 0x1fa8) = uVar13;
        *(undefined4 *)(iVar16 + 0x1fac) = uVar14;
        *(undefined8 *)(iVar16 + 0x1fb0) = uVar28;
    }
    iVar22 = in_stack_00000028;
    uStack_128 = *(uint64_t *)(iVar16 + 0x15e0);
    if (*(char *)(uStack_128 + 0x10e) != '\0') {
code_r0x00018014afb2:
        return uStack_128 & 0xffffffffffffff00;
    }
    if (in_stack_00000028 == 0) {
        iVar18 = fcn.1800f5a90(pcStackX_10, 0, 
                               *(undefined4 *)
                                (*(int64_t *)(*(int64_t *)(iVar24 + 0x15e0) + 0x150) + -4 +
                                (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 0x15e0) + 0x148) * 4));
    } else {
        iVar18 = *(int32_t *)(in_stack_00000028 + 200);
        if (*(int32_t *)(iVar24 + 0x1654) == iVar18) {
            *(int32_t *)(iVar24 + 0x1658) = iVar18;
        }
        if (*(int32_t *)(iVar24 + 0x1684) == iVar18) {
            *(undefined *)(iVar24 + 0x168d) = 1;
        }
    }
    if ((arg3 != 0) && (*(char *)arg3 == '\0')) {
        _var_148h = ZEXT816(0);
        uStack_128 = func_0x00018010b530(var_148h, iVar18, 0, 2);
        goto code_r0x00018014afb2;
    }
    uVar26 = 0;
    if ((uVar25 >> 0x14 & 1) == 0) {
        if (arg3 == 0) {
            uStackX_20 = uVar25 | 0x100000;
            uVar30 = (uint64_t)uStackX_20;
        }
    } else {
        puStackX_18 = (undefined *)0x0;
    }
    if ((iVar18 != 0) && (0 < *(int32_t *)(arg1 + 8))) {
        do {
            arg2_00 = (int32_t *)(uVar26 * 0x38 + *(int64_t *)(arg1 + 0x10));
            if (*arg2_00 == iVar18) {
                bVar32 = false;
                goto code_r0x00018014b075;
            }
            uVar25 = (int32_t)uVar26 + 1;
            uVar26 = (uint64_t)uVar25;
        } while ((int32_t)uVar25 < *(int32_t *)(arg1 + 8));
    }
    uStack_108 = 0;
    uStack_100 = 0;
    uStack_f0 = 0;
    uStack_e8 = 0;
    uStack_d8 = 0;
    uStack_f8 = 0xffffffffffffffff;
    Stack_e4 = 0xffbf800000;
    uStack_df = 0xffffffff;
    uStack_db = 0xffff;
    uStack_d9 = 0xff;
    func_0x00018011f0c0(arg1 + 8, &uStack_108);
    bVar32 = true;
    arg2_00 = (int32_t *)(*(int64_t *)(arg1 + 0x10) + -0x38 + (int64_t)*(int32_t *)(arg1 + 8) * 0x38);
    *arg2_00 = iVar18;
    *(undefined *)(arg1 + 0x85) = 1;
code_r0x00018014b075:
    *(int16_t *)(arg1 + 0x8a) = (int16_t)(((int64_t)arg2_00 - *(int64_t *)(arg1 + 0x10)) / 0x38);
    if ((puStackX_18 == (undefined *)0x0) && ((uVar30 & 1) == 0)) {
        uVar28 = 0;
    } else {
        uVar28 = 1;
    }
    func_0x00018014be50(&fStack_130, pcStackX_10, uVar28);
    arg2_00[9] = -0x40800000;
    fVar34 = fStack_130;
    if ((*(uint8_t *)(iVar16 + 0x1f80) & 1) != 0) {
        fVar34 = *(float *)(iVar16 + 0x1f98);
        arg2_00[9] = (int32_t)fVar34;
    }
    if (bVar32) {
        fVar35 = 1.0;
        if (1.0 <= fVar34) {
            fVar35 = fVar34;
        }
        arg2_00[7] = (int32_t)fVar35;
    }
    arg2_00[8] = (int32_t)fVar34;
    iVar6 = *(int16_t *)(arg1 + 0x88);
    *(int16_t *)(arg1 + 0x88) = iVar6 + 1;
    *(int16_t *)(arg2_00 + 0xb) = iVar6;
    iStack_11c = arg2_00[4] + 1;
    uStack_120 = *(uint32_t *)(arg1 + 0x18);
    iStack_118 = *(int32_t *)(iVar16 + 4);
    iVar29 = *(int32_t *)(arg1 + 0x34) + 1;
    if (((uStackX_20 & 1) == 0) || (var_168h._0_1_ = '\x01', (*(uint8_t *)(arg2_00 + 1) & 1) != 0)) {
        var_168h._0_1_ = '\0';
    }
    arg2_00[4] = iStack_118;
    var_13ch._4_4_ = uStackX_20 & 0x200000;
    arg2_00[1] = uStackX_20;
    *(int64_t *)(arg2_00 + 2) = iVar22;
    if (iVar22 == 0) {
        iVar27 = *(int32_t *)(arg1 + 0xa0) + -1;
        if (*(int32_t *)(arg1 + 0xa0) == 0) {
            iVar27 = 0;
        }
        arg2_00[10] = iVar27;
        iVar24 = func_0x000180498cd0(pcStackX_10);
        func_0x0001800f64c0(arg1 + 0xa0, pcStackX_10, pcStackX_10 + iVar24 + 1);
        iVar22 = in_stack_00000028;
    } else {
        arg2_00[10] = -1;
    }
    uVar30 = uStack_128;
    if (var_13ch._4_4_ == 0) {
        if ((((iStack_11c < iStack_118) && ((*(uint8_t *)(arg1 + 0x18) & 2) != 0)) && (*(int32_t *)(arg1 + 0x24) == 0))
           && ((iStack_118 <= iVar29 || (*(int32_t *)(arg1 + 0x20) == 0)))) {
            *(int32_t *)(arg1 + 0x24) = *arg2_00;
        }
        if (((uStackX_20 & 2) != 0) && (*(int32_t *)(arg1 + 0x20) != iVar18)) {
            *(int32_t *)(arg1 + 0x24) = *arg2_00;
        }
    }
    bVar31 = *(int32_t *)(arg1 + 0x2c) == iVar18;
    var_160h._0_4_ = CONCAT31((unkint3)(uStackX_20 >> 8), bVar31);
    if (bVar31) {
        *(undefined *)(arg1 + 0x84) = 1;
    } else if ((((*(int32_t *)(arg1 + 0x20) == 0) && (iVar29 < iStack_118)) && (iVar22 == 0)) &&
              ((*(int32_t *)(arg1 + 8) == 1 && (var_160h._0_4_ = (uint32_t)bVar31, (*(uint8_t *)(arg1 + 0x18) & 2) == 0)
               ))) {
        var_160h._0_4_ = 1;
    }
    if ((iStack_11c < iStack_118) && ((iStack_118 <= iVar29 || (bVar32)))) {
        _var_148h = ZEXT816(0);
        uStack_128 = func_0x00018010b530(var_148h, iVar18, 0, 2);
        if (var_13ch._4_4_ == 0) {
            return (uint64_t)(uint8_t)var_160h;
        }
        goto code_r0x00018014afb2;
    }
    if (*(int32_t *)(arg1 + 0x20) == iVar18) {
        arg2_00[5] = *(int32_t *)(iVar16 + 4);
    }
    var_150h = (float)arg2_00[7];
    uVar3 = *(undefined4 *)(uStack_128 + 0x158);
    var_158h._4_4_ = *(float *)(arg1 + 0x3c) + 0.0;
    uVar4 = *(undefined4 *)(uStack_128 + 0x15c);
    if ((*(uint8_t *)(arg2_00 + 1) & 0xc0) == 0) {
        var_158h._0_4_ = (float)(int32_t)((float)arg2_00[6] - *(float *)(arg1 + 0x5c)) + *(float *)(arg1 + 0x38);
        *(float *)(uStack_128 + 0x158) = (float)var_158h;
        var_150h = var_150h + (float)var_158h;
        *(float *)(uStack_128 + 0x15c) = var_158h._4_4_;
        var_14ch = var_158h._4_4_ + fStack_12c;
        fVar34 = *(float *)(arg1 + 0x6c);
        if ((fVar34 <= (float)var_158h) && (var_150h < *(float *)(arg1 + 0x70) || var_150h == *(float *)(arg1 + 0x70)))
        goto code_r0x00018014b3e0;
        bVar32 = true;
        var_168h._2_1_ = '\x01';
        fStack_130 = *(float *)(arg1 + 0x70);
        if ((fVar34 <= (float)var_158h) && (fVar34 = fStack_130, (float)var_158h <= fStack_130)) {
            fVar34 = (float)var_158h;
        }
        _var_148h = CONCAT44(var_158h._4_4_ - 1.0, fVar34);
        fStack_12c = var_14ch;
        func_0x0001800fc860(var_148h, &fStack_130, 1);
    } else {
        var_158h._0_4_ = (float)arg2_00[6] + *(float *)(arg1 + 0x38);
        *(float *)(uStack_128 + 0x158) = (float)var_158h;
        var_150h = var_150h + (float)var_158h;
        *(float *)(uStack_128 + 0x15c) = var_158h._4_4_;
code_r0x00018014b3e0:
        var_14ch = var_158h._4_4_ + fStack_12c;
        bVar32 = false;
        var_168h._2_1_ = '\0';
    }
    uVar20 = *(undefined4 *)(uVar30 + 0x170);
    uVar5 = *(undefined4 *)(uVar30 + 0x174);
    var_144h._0_4_ = var_14ch - var_158h._4_4_;
    var_148h = (undefined  [4])(var_150h - (float)var_158h);
    func_0x00018010bbf0(var_148h, *(undefined4 *)(iVar16 + 0xde0));
    *(undefined4 *)(uVar30 + 0x170) = uVar20;
    *(undefined4 *)(uVar30 + 0x174) = uVar5;
    cVar17 = func_0x00018010b530(&var_158h, iVar18, 0, 0);
    uVar25 = var_13ch._4_4_;
    if (cVar17 == '\0') {
        if (bVar32) {
            func_0x0001800fc8f0();
        }
        *(undefined4 *)(uVar30 + 0x158) = uVar3;
        *(undefined4 *)(uVar30 + 0x15c) = uVar4;
        return (uint64_t)(uint8_t)var_160h;
    }
    uVar19 = 0x1010;
    if (var_13ch._4_4_ != 0) {
        uVar19 = 0x1020;
    }
    uVar23 = uVar19;
    if (*(char *)(iVar16 + 0x2400) != '\0') {
        cVar17 = func_0x0001800f3aa0(iVar16 + 0x2410);
        uVar23 = uVar19 | 0x200;
        if (cVar17 != '\0') {
            uVar23 = uVar19;
        }
    }
    if ((uStackX_20 & 0x400000) == 0) {
        var_198h = CONCAT44(var_198h._4_4_, uVar23);
        var_168h._3_1_ = func_0x000180139d40(&var_158h, iVar18, (int64_t)&var_168h + 1, acStackX_8, var_198h);
        if ((var_168h._3_1_ != 0) && (uVar25 == 0)) {
            *(int32_t *)(arg1 + 0x24) = *arg2_00;
        }
        if (acStackX_8[0] == '\0') goto code_r0x00018014b4c3;
        if (in_stack_00000028 == 0) goto code_r0x00018014b56d;
        if ((*(int32_t *)(iVar16 + 0x1654) == iVar18) && (*(char *)(iVar16 + 0x1660) != '\0')) {
            *(int64_t *)(iVar16 + 0x1678) = in_stack_00000028;
        }
code_r0x00018014b4d3:
        iVar24 = *(int64_t *)(in_stack_00000028 + 0x4c0);
        if ((((iVar24 == 0) || (*(int64_t *)(iVar24 + 0x18) != 0)) || ((*(uint32_t *)(iVar24 + 0x10) & 0x400) != 0)) ||
           (*(int32_t *)(iVar24 + 0x30) != 1)) goto code_r0x00018014b570;
        bVar32 = true;
    } else {
        var_168h._3_1_ = 0;
        acStackX_8[0] = '\0';
        var_168h._1_1_ = '\0';
code_r0x00018014b4c3:
        if (in_stack_00000028 != 0) goto code_r0x00018014b4d3;
code_r0x00018014b56d:
        iVar24 = 0;
code_r0x00018014b570:
        bVar32 = false;
    }
    iVar22 = *(int64_t *)0x180781f28;
    if (acStackX_8[0] == '\0') goto code_r0x00018014b8e9;
    if (((bVar32) && (*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0')) &&
       (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbfc))) {
        func_0x0001800faa00();
        iVar22 = *(int64_t *)0x180781f28;
        goto code_r0x00018014b8e9;
    }
    if (((iStack_11c < iStack_118) || (*(char *)(*(int64_t *)0x180781f28 + 0x120) == '\0')) ||
       (*(float *)(*(int64_t *)0x180781f28 + 0xbfc) <
        *(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4)))
    goto code_r0x00018014b8e9;
    fVar34 = 0.0;
    iVar29 = 0;
    if (*(char *)(iVar16 + 0x2400) == '\0') {
        if (((*(uint8_t *)(arg1 + 0x18) & 1) == 0) && (uVar30 = uStack_128, in_stack_00000028 == 0))
        goto code_r0x00018014b8e9;
        if ((0.0 <= *(float *)(iVar16 + 0x104)) || ((float)var_158h <= *(float *)(iVar16 + 0x118))) {
            iVar29 = 0;
            if ((*(float *)(iVar16 + 0x104) <= 0.0) || (fVar35 = *(float *)(iVar16 + 0x118), fVar35 <= var_150h))
            goto code_r0x00018014b679;
            iVar29 = 1;
            fVar34 = var_150h;
        } else {
            iVar29 = -1;
            fVar34 = *(float *)(iVar16 + 0x118);
            fVar35 = (float)var_158h;
        }
        fVar34 = fVar35 - fVar34;
        fcn.18014ad20(arg1, (int64_t)arg2_00, *(int64_t *)(iVar16 + 0x118));
    }
code_r0x00018014b679:
    uVar30 = uStack_128;
    if (((in_stack_00000028 == 0) || ((*(uint8_t *)(in_stack_00000028 + 0x14) & 4) != 0)) ||
       ((*(uint8_t *)(iVar24 + 0x10) & 0x80) != 0)) goto code_r0x00018014b8e9;
    if ((*(char *)(iVar16 + 0x2400) == '\0') || (*(int32_t *)(iVar16 + 0x241c) != iVar18)) {
        fVar35 = *(float *)(iVar16 + 0x12f8);
        fVar33 = ((float)(*(uint32_t *)(iVar16 + 0xbd4) & 0x7fffffff) - (fVar35 + fVar35)) * 0.2;
        if (0.0 <= fVar33) {
            fVar36 = fVar35 * 4.0;
            if (fVar33 <= fVar35 * 4.0) {
                fVar36 = fVar33;
            }
        } else {
            fVar36 = 0.0;
        }
        fVar33 = var_158h._4_4_ - *(float *)(iVar16 + 0x11c);
        fVar37 = *(float *)(iVar16 + 0x11c) - var_14ch;
        if (fVar33 <= fVar37) {
            fVar33 = fVar37;
        }
        if (fVar35 * 2.2 < fVar34) {
            if (iVar29 < 0) {
                iVar24 = (int64_t)arg2_00 - *(int64_t *)(arg1 + 0x10);
                iVar29 = (int32_t)(iVar24 >> 0x3f);
                bVar32 = (int32_t)(iVar24 / 0x38) + iVar29 == iVar29;
            } else {
                if (iVar29 < 1) goto code_r0x00018014b7a0;
                bVar32 = (int32_t)(((int64_t)arg2_00 - *(int64_t *)(arg1 + 0x10)) / 0x38) == *(int32_t *)(arg1 + 8) + -1
                ;
            }
            if (bVar32) goto code_r0x00018014b7a9;
        }
code_r0x00018014b7a0:
        if (fVar33 < fVar35 * 1.5 + fVar36) goto code_r0x00018014b8e9;
    }
code_r0x00018014b7a9:
    piVar1 = (int32_t *)(iVar16 + 0x28f8);
    iVar29 = *(int32_t *)(iVar16 + 0x28fc);
    if (*piVar1 == iVar29) {
        iVar27 = *piVar1 + 1;
        if (iVar29 == 0) {
            iVar29 = 8;
        } else {
            iVar29 = iVar29 / 2 + iVar29;
        }
        if (iVar27 < iVar29) {
            iVar27 = iVar29;
        }
        func_0x00018011fa30(piVar1, iVar27);
    }
    iVar24 = *(int64_t *)(iVar16 + 0x2900);
    iVar22 = (int64_t)*piVar1 * 0x40;
    *(undefined4 *)(iVar22 + iVar24) = 2;
    *(undefined4 *)(iVar22 + 4 + iVar24) = uStack_108._4_4_;
    *(undefined8 *)(iVar22 + 8 + iVar24) = 0;
    *(undefined8 *)(iVar22 + 0x10 + iVar24) = 0;
    *(undefined8 *)(iVar22 + 0x18 + iVar24) = 0;
    *(undefined4 *)(iVar22 + 0x20 + iVar24) = 0xffffffff;
    *(undefined4 *)(iVar22 + 0x24 + iVar24) = 0x3f000000;
    *(undefined *)(iVar22 + 0x28 + iVar24) = 0;
    *(undefined4 *)(iVar22 + 0x29 + iVar24) = uStack_df;
    *(undefined2 *)(iVar22 + 0x2d + iVar24) = uStack_db;
    *(undefined *)(iVar22 + 0x2f + iVar24) = uStack_d9;
    *(int64_t *)(iVar22 + 0x30 + iVar24) = in_stack_00000028;
    *(undefined8 *)(iVar22 + 0x38 + iVar24) = 0;
    *piVar1 = *piVar1 + 1;
    *(int64_t *)(iVar16 + 0x1600) = in_stack_00000028;
    func_0x0001800f9f30(*(undefined4 *)(in_stack_00000028 + 0xc4), in_stack_00000028);
    iVar22 = *(int64_t *)0x180781f28;
    fVar34 = *(float *)(*(int64_t *)(iVar16 + 0x1600) + 0x60);
    fVar35 = *(float *)(*(int64_t *)(iVar16 + 0x1600) + 100);
    *(undefined *)(iVar16 + 0x1662) = 1;
    *(float *)(iVar16 + 0x166c) = *(float *)(iVar16 + 0x166c) - (fVar34 - (float)var_158h);
    *(float *)(iVar16 + 0x1670) = *(float *)(iVar16 + 0x1670) - (fVar35 - var_158h._4_4_);
    *(undefined4 *)(iVar22 + 0x1f68) = 0xf;
    *(undefined *)(iVar22 + 0x1f6c) = 1;
    *(bool *)(iVar22 + 0x2239) = *(char *)(iVar22 + 0x223a) != '\0';
    *(undefined2 *)(iVar22 + 0x2278) = 0;
    uVar30 = uStack_128;
code_r0x00018014b8e9:
    uVar25 = uStackX_20;
    if (((*(uint32_t *)(iVar16 + 0x1fc0) & 0x100) != 0) && ((uStackX_20 >> 0x16 & 1) == 0)) {
        iVar24 = *(int64_t *)(uVar30 + 800);
        uStack_120 = uStack_120 & 0x200000;
        if ((acStackX_8[0] == '\0') && (var_168h._1_1_ == '\0')) {
            if ((uint8_t)var_160h == '\0') {
                iVar21 = 0x26;
                if (uStack_120 != 0) {
                    iVar21 = 0x23;
                }
            } else {
                iVar21 = 0x27;
                if (uStack_120 != 0) {
                    iVar21 = 0x24;
                }
            }
        } else {
            iVar21 = 0x22;
        }
        pauVar2 = (undefined (*) [12])(iVar22 + 0xd90 + (iVar21 + 0x14) * 0x10);
        var_13ch._0_4_ = *(float *)pauVar2[1] * *(float *)(iVar22 + 0xd9c);
        _var_148h = *pauVar2;
        uVar20 = fcn.1800f5fa0(var_148h);
        func_0x00018014bf10(iVar24, &var_158h, uVar25, uVar20);
        if ((((uint8_t)var_160h != '\0') && ((*(uint8_t *)(arg1 + 0x18) & 0x40) != 0)) &&
           (fVar34 = *(float *)(iVar16 + 0xe50), 0.0 < fVar34)) {
            fVar35 = (float)var_158h + 0.0;
            iVar22 = 0x3c0;
            if (uStack_120 != 0) {
                iVar22 = 0x390;
            }
            fVar37 = var_158h._4_4_ + *(float *)(iVar16 + 0x1308);
            fVar36 = var_150h + 0.0;
            pauVar2 = (undefined (*) [12])(iVar22 + 0xd90 + *(int64_t *)0x180781f28);
            var_13ch._0_4_ = *(float *)pauVar2[1] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            _var_148h = *pauVar2;
            uVar20 = fcn.1800f5fa0(var_148h);
            fVar33 = *(float *)(iVar16 + 0xe34);
            if (fVar33 <= 0.0) {
                fStack_12c = fVar37 - 0.5;
                var_198h = CONCAT44(var_198h._4_4_, fVar34);
                fStack_130 = fVar35 - 0.5;
                var_144h._0_4_ = fStack_12c;
                var_148h = (undefined  [4])(fVar36 - 0.5);
                func_0x000180126300(iVar24, &fStack_130, var_148h, uVar20, var_198h);
                uVar25 = uStackX_20;
            } else {
                fVar35 = fVar35 + fVar33;
                fVar37 = fVar33 + fVar37;
                var_144h._0_4_ = fVar37;
                var_148h = (undefined  [4])fVar35;
                if (0.5 <= fVar33) {
                    var_198h = CONCAT44(var_198h._4_4_, 0x24);
                    func_0x0001801257a0(iVar24, var_148h, fVar33, 0x1c, var_198h);
                } else {
                    iVar29 = *(int32_t *)(iVar24 + 0x54);
                    if (*(int32_t *)(iVar24 + 0x50) == iVar29) {
                        iVar27 = *(int32_t *)(iVar24 + 0x50) + 1;
                        if (iVar29 == 0) {
                            iVar29 = 8;
                        } else {
                            iVar29 = iVar29 / 2 + iVar29;
                        }
                        if (iVar27 < iVar29) {
                            iVar27 = iVar29;
                        }
                        func_0x00018011f4f0(iVar24 + 0x50, iVar27);
                    }
                    iVar29 = *(int32_t *)(iVar24 + 0x50);
                    iVar22 = *(int64_t *)(iVar24 + 0x58);
                    *(float *)(iVar22 + (int64_t)iVar29 * 8) = fVar35;
                    *(float *)(iVar22 + 4 + (int64_t)iVar29 * 8) = fVar37;
                    *(int32_t *)(iVar24 + 0x50) = *(int32_t *)(iVar24 + 0x50) + 1;
                }
                fVar36 = fVar36 - fVar33;
                var_148h = (undefined  [4])fVar36;
                if (0.5 <= fVar33) {
                    var_198h = CONCAT44(var_198h._4_4_, 0x2c);
                    func_0x0001801257a0(iVar24, var_148h, fVar33, 0x24, var_198h);
                } else {
                    iVar29 = *(int32_t *)(iVar24 + 0x54);
                    if (*(int32_t *)(iVar24 + 0x50) == iVar29) {
                        iVar27 = *(int32_t *)(iVar24 + 0x50) + 1;
                        if (iVar29 == 0) {
                            iVar29 = 8;
                        } else {
                            iVar29 = iVar29 / 2 + iVar29;
                        }
                        if (iVar27 < iVar29) {
                            iVar27 = iVar29;
                        }
                        func_0x00018011f4f0(iVar24 + 0x50, iVar27);
                    }
                    iVar29 = *(int32_t *)(iVar24 + 0x50);
                    iVar22 = *(int64_t *)(iVar24 + 0x58);
                    *(float *)(iVar22 + (int64_t)iVar29 * 8) = fVar36;
                    *(float *)(iVar22 + 4 + (int64_t)iVar29 * 8) = fVar37;
                    *(int32_t *)(iVar24 + 0x50) = *(int32_t *)(iVar24 + 0x50) + 1;
                }
                var_198h = var_198h & 0xffffffff00000000;
                func_0x0001801248e0(iVar24, *(undefined8 *)(iVar24 + 0x58), *(undefined4 *)(iVar24 + 0x50), uVar20, 
                                    var_198h, *(undefined4 *)(iVar16 + 0xe50));
                *(undefined4 *)(iVar24 + 0x50) = 0;
                uVar25 = uStackX_20;
            }
        }
        func_0x0001800f7d00(&var_158h, iVar18, 0);
        cVar17 = func_0x0001800fa150(0x20);
        iVar29 = *arg2_00;
        if ((((*(int32_t *)(arg1 + 0x20) != iVar29) && (cVar17 != '\0')) &&
            ((cVar17 = func_0x000180107ff0(1, 0, 0), cVar17 != '\0' || (cVar17 = func_0x000180108070(1), cVar17 != '\0')
             ))) && (var_13ch._4_4_ == 0)) {
            *(int32_t *)(arg1 + 0x24) = iVar29;
        }
        if ((*(uint8_t *)(arg1 + 0x18) & 8) != 0) {
            uStackX_20 = uVar25 | 4;
        }
        if (puStackX_18 == (undefined *)0x0) {
            iVar29 = 0;
        } else {
            iVar29 = iVar18;
            if (in_stack_00000028 != 0) {
                iVar29 = *(int32_t *)(in_stack_00000028 + 0x10);
            }
            iVar29 = fcn.1800f5a90(0x1806445a0, 0, iVar29);
        }
        uVar25 = uStackX_20;
        if ((char)var_168h != '\0') {
            uVar25 = uStackX_20 & 0xfffffffe;
        }
        func_0x00018014c270(iVar24, &var_158h, uVar25, *(undefined8 *)(arg1 + 0x90), pcStackX_10, iVar18, iVar29, 
                            (char)(uint32_t)var_160h, &var_168h, (int64_t)&var_168h + 4);
        if (((char)var_168h != '\0') && (puStackX_18 != (undefined *)0x0)) {
            *puStackX_18 = 0;
            if (((uint32_t)arg2_00[1] >> 0x15 & 1) == 0) {
                iVar27 = *arg2_00;
                if ((arg2_00[1] & 0x101U) == 0) {
                    *(undefined *)(arg2_00 + 0xc) = 1;
                    if (*(int32_t *)(arg1 + 0x2c) == iVar27) {
                        arg2_00[4] = -1;
                        *(undefined8 *)(arg1 + 0x20) = 0;
                    }
                } else if (*(int32_t *)(arg1 + 0x2c) != iVar27) {
                    *(int32_t *)(arg1 + 0x24) = iVar27;
                }
            }
        }
        if ((in_stack_00000028 != 0) && ((var_168h._1_1_ != '\0' || (*(int32_t *)(iVar16 + 0x163c) == iVar29)))) {
            *(uint32_t *)(iVar16 + 0x1fc0) = *(uint32_t *)(iVar16 + 0x1fc0) | 0x80;
        }
        if ((((var_168h._4_1_ != '\0') && (*(int32_t *)(iVar16 + 0x163c) == iVar18)) && (acStackX_8[0] == '\0')) &&
           (((*(uint8_t *)(arg1 + 0x18) & 0x20) == 0 && (pcVar15 = pcStackX_10, (*(uint8_t *)(arg2_00 + 1) & 0x10) == 0)
            ))) {
            for (; ((pcVar15 != (char *)0xffffffffffffffff && (*pcVar15 != '\0')) &&
                   ((*pcVar15 != '#' || (pcVar15[1] != '#')))); pcVar15 = pcVar15 + 1) {
            }
            func_0x00018010ceb0(0x180641920, (int32_t)pcVar15 - (int32_t)pcStackX_10, pcStackX_10);
        }
    }
    if (var_168h._2_1_ != '\0') {
        func_0x0001800fc8f0();
    }
    *(undefined4 *)(uStack_128 + 0x158) = uVar3;
    *(undefined4 *)(uStack_128 + 0x15c) = uVar4;
    if (var_13ch._4_4_ == 0) {
        return (uint64_t)(uint8_t)var_160h;
    }
    return (uint64_t)var_168h._3_1_;
}

// ============================================================
// Function: FUN_18014b9b5
// Address: 0x18014b9b5
// Size: 587 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_198h
// WARNING: Variable defined which should be unmapped: var_190h
// WARNING: Variable defined which should be unmapped: var_188h
// WARNING: Variable defined which should be unmapped: var_180h
// WARNING: Variable defined which should be unmapped: var_178h
// WARNING: Variable defined which should be unmapped: var_170h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_154h
// WARNING: [rz-ghidra] Detected overlap for variable var_150h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_166h
// WARNING: [rz-ghidra] Detected overlap for variable var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable var_167h
// WARNING: [rz-ghidra] Detected overlap for variable var_165h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_27h
// WARNING: [rz-ghidra] Detected overlap for variable var_23h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h

uint64_t fcn.18014ae50(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_c0h, int64_t arg_c8h,
                      int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h)
{
    int32_t *piVar1;
    undefined (*pauVar2) [12];
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int16_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    char *pcVar15;
    int64_t iVar16;
    char cVar17;
    int32_t iVar18;
    uint32_t uVar19;
    undefined4 uVar20;
    int64_t iVar21;
    int64_t iVar22;
    uint32_t uVar23;
    int64_t iVar24;
    uint32_t uVar25;
    int32_t *arg2_00;
    int32_t iVar27;
    undefined8 uVar28;
    int32_t iVar29;
    uint64_t uVar30;
    bool bVar31;
    bool bVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    float fVar37;
    char acStackX_8 [8];
    char *pcStackX_10;
    undefined *puStackX_18;
    uint32_t uStackX_20;
    int64_t in_stack_00000028;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    float var_150h;
    float var_14ch;
    undefined var_148h [4];
    undefined var_144h [8];
    int64_t var_13ch;
    float fStack_130;
    float fStack_12c;
    uint64_t uStack_128;
    uint32_t uStack_120;
    int32_t iStack_11c;
    int32_t iStack_118;
    undefined8 uStack_108;
    undefined8 uStack_100;
    undefined8 uStack_f8;
    undefined8 uStack_f0;
    undefined4 uStack_e8;
    unkbyte5 Stack_e4;
    undefined4 uStack_df;
    undefined2 uStack_db;
    undefined uStack_d9;
    undefined8 uStack_d8;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uVar26;
    
    iVar16 = *(int64_t *)0x180781f28;
    stack0xfffffffffffffec0 = _var_148h;
    uVar25 = (uint32_t)arg4;
    uVar30 = arg4 & 0xffffffff;
    iVar24 = *(int64_t *)0x180781f28;
    pcStackX_10 = (char *)arg2;
    puStackX_18 = (undefined *)arg3;
    uStackX_20 = uVar25;
    if (*(char *)(arg1 + 0x83) != '\0') {
        uVar3 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f80);
        uVar4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f84);
        uVar20 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f88);
        uVar5 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f8c);
        uVar7 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f90);
        uVar8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f94);
        uVar9 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f98);
        uVar10 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f9c);
        uVar11 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fa0);
        uVar12 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fa4);
        uVar13 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fa8);
        uVar14 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fac);
        uVar28 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x1fb0);
        fcn.180148fa0(arg1, arg2);
        iVar24 = *(int64_t *)0x180781f28;
        *(undefined4 *)(iVar16 + 0x1f80) = uVar3;
        *(undefined4 *)(iVar16 + 0x1f84) = uVar4;
        *(undefined4 *)(iVar16 + 0x1f88) = uVar20;
        *(undefined4 *)(iVar16 + 0x1f8c) = uVar5;
        *(undefined4 *)(iVar16 + 0x1f90) = uVar7;
        *(undefined4 *)(iVar16 + 0x1f94) = uVar8;
        *(undefined4 *)(iVar16 + 0x1f98) = uVar9;
        *(undefined4 *)(iVar16 + 0x1f9c) = uVar10;
        *(undefined4 *)(iVar16 + 0x1fa0) = uVar11;
        *(undefined4 *)(iVar16 + 0x1fa4) = uVar12;
        *(undefined4 *)(iVar16 + 0x1fa8) = uVar13;
        *(undefined4 *)(iVar16 + 0x1fac) = uVar14;
        *(undefined8 *)(iVar16 + 0x1fb0) = uVar28;
    }
    iVar22 = in_stack_00000028;
    uStack_128 = *(uint64_t *)(iVar16 + 0x15e0);
    if (*(char *)(uStack_128 + 0x10e) != '\0') {
code_r0x00018014afb2:
        return uStack_128 & 0xffffffffffffff00;
    }
    if (in_stack_00000028 == 0) {
        iVar18 = fcn.1800f5a90(pcStackX_10, 0, 
                               *(undefined4 *)
                                (*(int64_t *)(*(int64_t *)(iVar24 + 0x15e0) + 0x150) + -4 +
                                (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 0x15e0) + 0x148) * 4));
    } else {
        iVar18 = *(int32_t *)(in_stack_00000028 + 200);
        if (*(int32_t *)(iVar24 + 0x1654) == iVar18) {
            *(int32_t *)(iVar24 + 0x1658) = iVar18;
        }
        if (*(int32_t *)(iVar24 + 0x1684) == iVar18) {
            *(undefined *)(iVar24 + 0x168d) = 1;
        }
    }
    if ((arg3 != 0) && (*(char *)arg3 == '\0')) {
        _var_148h = ZEXT816(0);
        uStack_128 = func_0x00018010b530(var_148h, iVar18, 0, 2);
        goto code_r0x00018014afb2;
    }
    uVar26 = 0;
    if ((uVar25 >> 0x14 & 1) == 0) {
        if (arg3 == 0) {
            uStackX_20 = uVar25 | 0x100000;
            uVar30 = (uint64_t)uStackX_20;
        }
    } else {
        puStackX_18 = (undefined *)0x0;
    }
    if ((iVar18 != 0) && (0 < *(int32_t *)(arg1 + 8))) {
        do {
            arg2_00 = (int32_t *)(uVar26 * 0x38 + *(int64_t *)(arg1 + 0x10));
            if (*arg2_00 == iVar18) {
                bVar32 = false;
                goto code_r0x00018014b075;
            }
            uVar25 = (int32_t)uVar26 + 1;
            uVar26 = (uint64_t)uVar25;
        } while ((int32_t)uVar25 < *(int32_t *)(arg1 + 8));
    }
    uStack_108 = 0;
    uStack_100 = 0;
    uStack_f0 = 0;
    uStack_e8 = 0;
    uStack_d8 = 0;
    uStack_f8 = 0xffffffffffffffff;
    Stack_e4 = 0xffbf800000;
    uStack_df = 0xffffffff;
    uStack_db = 0xffff;
    uStack_d9 = 0xff;
    func_0x00018011f0c0(arg1 + 8, &uStack_108);
    bVar32 = true;
    arg2_00 = (int32_t *)(*(int64_t *)(arg1 + 0x10) + -0x38 + (int64_t)*(int32_t *)(arg1 + 8) * 0x38);
    *arg2_00 = iVar18;
    *(undefined *)(arg1 + 0x85) = 1;
code_r0x00018014b075:
    *(int16_t *)(arg1 + 0x8a) = (int16_t)(((int64_t)arg2_00 - *(int64_t *)(arg1 + 0x10)) / 0x38);
    if ((puStackX_18 == (undefined *)0x0) && ((uVar30 & 1) == 0)) {
        uVar28 = 0;
    } else {
        uVar28 = 1;
    }
    func_0x00018014be50(&fStack_130, pcStackX_10, uVar28);
    arg2_00[9] = -0x40800000;
    fVar34 = fStack_130;
    if ((*(uint8_t *)(iVar16 + 0x1f80) & 1) != 0) {
        fVar34 = *(float *)(iVar16 + 0x1f98);
        arg2_00[9] = (int32_t)fVar34;
    }
    if (bVar32) {
        fVar35 = 1.0;
        if (1.0 <= fVar34) {
            fVar35 = fVar34;
        }
        arg2_00[7] = (int32_t)fVar35;
    }
    arg2_00[8] = (int32_t)fVar34;
    iVar6 = *(int16_t *)(arg1 + 0x88);
    *(int16_t *)(arg1 + 0x88) = iVar6 + 1;
    *(int16_t *)(arg2_00 + 0xb) = iVar6;
    iStack_11c = arg2_00[4] + 1;
    uStack_120 = *(uint32_t *)(arg1 + 0x18);
    iStack_118 = *(int32_t *)(iVar16 + 4);
    iVar29 = *(int32_t *)(arg1 + 0x34) + 1;
    if (((uStackX_20 & 1) == 0) || (var_168h._0_1_ = '\x01', (*(uint8_t *)(arg2_00 + 1) & 1) != 0)) {
        var_168h._0_1_ = '\0';
    }
    arg2_00[4] = iStack_118;
    var_13ch._4_4_ = uStackX_20 & 0x200000;
    arg2_00[1] = uStackX_20;
    *(int64_t *)(arg2_00 + 2) = iVar22;
    if (iVar22 == 0) {
        iVar27 = *(int32_t *)(arg1 + 0xa0) + -1;
        if (*(int32_t *)(arg1 + 0xa0) == 0) {
            iVar27 = 0;
        }
        arg2_00[10] = iVar27;
        iVar24 = func_0x000180498cd0(pcStackX_10);
        func_0x0001800f64c0(arg1 + 0xa0, pcStackX_10, pcStackX_10 + iVar24 + 1);
        iVar22 = in_stack_00000028;
    } else {
        arg2_00[10] = -1;
    }
    uVar30 = uStack_128;
    if (var_13ch._4_4_ == 0) {
        if ((((iStack_11c < iStack_118) && ((*(uint8_t *)(arg1 + 0x18) & 2) != 0)) && (*(int32_t *)(arg1 + 0x24) == 0))
           && ((iStack_118 <= iVar29 || (*(int32_t *)(arg1 + 0x20) == 0)))) {
            *(int32_t *)(arg1 + 0x24) = *arg2_00;
        }
        if (((uStackX_20 & 2) != 0) && (*(int32_t *)(arg1 + 0x20) != iVar18)) {
            *(int32_t *)(arg1 + 0x24) = *arg2_00;
        }
    }
    bVar31 = *(int32_t *)(arg1 + 0x2c) == iVar18;
    var_160h._0_4_ = CONCAT31((unkint3)(uStackX_20 >> 8), bVar31);
    if (bVar31) {
        *(undefined *)(arg1 + 0x84) = 1;
    } else if ((((*(int32_t *)(arg1 + 0x20) == 0) && (iVar29 < iStack_118)) && (iVar22 == 0)) &&
              ((*(int32_t *)(arg1 + 8) == 1 && (var_160h._0_4_ = (uint32_t)bVar31, (*(uint8_t *)(arg1 + 0x18) & 2) == 0)
               ))) {
        var_160h._0_4_ = 1;
    }
    if ((iStack_11c < iStack_118) && ((iStack_118 <= iVar29 || (bVar32)))) {
        _var_148h = ZEXT816(0);
        uStack_128 = func_0x00018010b530(var_148h, iVar18, 0, 2);
        if (var_13ch._4_4_ == 0) {
            return (uint64_t)(uint8_t)var_160h;
        }
        goto code_r0x00018014afb2;
    }
    if (*(int32_t *)(arg1 + 0x20) == iVar18) {
        arg2_00[5] = *(int32_t *)(iVar16 + 4);
    }
    var_150h = (float)arg2_00[7];
    uVar3 = *(undefined4 *)(uStack_128 + 0x158);
    var_158h._4_4_ = *(float *)(arg1 + 0x3c) + 0.0;
    uVar4 = *(undefined4 *)(uStack_128 + 0x15c);
    if ((*(uint8_t *)(arg2_00 + 1) & 0xc0) == 0) {
        var_158h._0_4_ = (float)(int32_t)((float)arg2_00[6] - *(float *)(arg1 + 0x5c)) + *(float *)(arg1 + 0x38);
        *(float *)(uStack_128 + 0x158) = (float)var_158h;
        var_150h = var_150h + (float)var_158h;
        *(float *)(uStack_128 + 0x15c) = var_158h._4_4_;
        var_14ch = var_158h._4_4_ + fStack_12c;
        fVar34 = *(float *)(arg1 + 0x6c);
        if ((fVar34 <= (float)var_158h) && (var_150h < *(float *)(arg1 + 0x70) || var_150h == *(float *)(arg1 + 0x70)))
        goto code_r0x00018014b3e0;
        bVar32 = true;
        var_168h._2_1_ = '\x01';
        fStack_130 = *(float *)(arg1 + 0x70);
        if ((fVar34 <= (float)var_158h) && (fVar34 = fStack_130, (float)var_158h <= fStack_130)) {
            fVar34 = (float)var_158h;
        }
        _var_148h = CONCAT44(var_158h._4_4_ - 1.0, fVar34);
        fStack_12c = var_14ch;
        func_0x0001800fc860(var_148h, &fStack_130, 1);
    } else {
        var_158h._0_4_ = (float)arg2_00[6] + *(float *)(arg1 + 0x38);
        *(float *)(uStack_128 + 0x158) = (float)var_158h;
        var_150h = var_150h + (float)var_158h;
        *(float *)(uStack_128 + 0x15c) = var_158h._4_4_;
code_r0x00018014b3e0:
        var_14ch = var_158h._4_4_ + fStack_12c;
        bVar32 = false;
        var_168h._2_1_ = '\0';
    }
    uVar20 = *(undefined4 *)(uVar30 + 0x170);
    uVar5 = *(undefined4 *)(uVar30 + 0x174);
    var_144h._0_4_ = var_14ch - var_158h._4_4_;
    var_148h = (undefined  [4])(var_150h - (float)var_158h);
    func_0x00018010bbf0(var_148h, *(undefined4 *)(iVar16 + 0xde0));
    *(undefined4 *)(uVar30 + 0x170) = uVar20;
    *(undefined4 *)(uVar30 + 0x174) = uVar5;
    cVar17 = func_0x00018010b530(&var_158h, iVar18, 0, 0);
    uVar25 = var_13ch._4_4_;
    if (cVar17 == '\0') {
        if (bVar32) {
            func_0x0001800fc8f0();
        }
        *(undefined4 *)(uVar30 + 0x158) = uVar3;
        *(undefined4 *)(uVar30 + 0x15c) = uVar4;
        return (uint64_t)(uint8_t)var_160h;
    }
    uVar19 = 0x1010;
    if (var_13ch._4_4_ != 0) {
        uVar19 = 0x1020;
    }
    uVar23 = uVar19;
    if (*(char *)(iVar16 + 0x2400) != '\0') {
        cVar17 = func_0x0001800f3aa0(iVar16 + 0x2410);
        uVar23 = uVar19 | 0x200;
        if (cVar17 != '\0') {
            uVar23 = uVar19;
        }
    }
    if ((uStackX_20 & 0x400000) == 0) {
        var_198h = CONCAT44(var_198h._4_4_, uVar23);
        var_168h._3_1_ = func_0x000180139d40(&var_158h, iVar18, (int64_t)&var_168h + 1, acStackX_8, var_198h);
        if ((var_168h._3_1_ != 0) && (uVar25 == 0)) {
            *(int32_t *)(arg1 + 0x24) = *arg2_00;
        }
        if (acStackX_8[0] == '\0') goto code_r0x00018014b4c3;
        if (in_stack_00000028 == 0) goto code_r0x00018014b56d;
        if ((*(int32_t *)(iVar16 + 0x1654) == iVar18) && (*(char *)(iVar16 + 0x1660) != '\0')) {
            *(int64_t *)(iVar16 + 0x1678) = in_stack_00000028;
        }
code_r0x00018014b4d3:
        iVar24 = *(int64_t *)(in_stack_00000028 + 0x4c0);
        if ((((iVar24 == 0) || (*(int64_t *)(iVar24 + 0x18) != 0)) || ((*(uint32_t *)(iVar24 + 0x10) & 0x400) != 0)) ||
           (*(int32_t *)(iVar24 + 0x30) != 1)) goto code_r0x00018014b570;
        bVar32 = true;
    } else {
        var_168h._3_1_ = 0;
        acStackX_8[0] = '\0';
        var_168h._1_1_ = '\0';
code_r0x00018014b4c3:
        if (in_stack_00000028 != 0) goto code_r0x00018014b4d3;
code_r0x00018014b56d:
        iVar24 = 0;
code_r0x00018014b570:
        bVar32 = false;
    }
    iVar22 = *(int64_t *)0x180781f28;
    if (acStackX_8[0] == '\0') goto code_r0x00018014b8e9;
    if (((bVar32) && (*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0')) &&
       (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbfc))) {
        func_0x0001800faa00();
        iVar22 = *(int64_t *)0x180781f28;
        goto code_r0x00018014b8e9;
    }
    if (((iStack_11c < iStack_118) || (*(char *)(*(int64_t *)0x180781f28 + 0x120) == '\0')) ||
       (*(float *)(*(int64_t *)0x180781f28 + 0xbfc) <
        *(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4)))
    goto code_r0x00018014b8e9;
    fVar34 = 0.0;
    iVar29 = 0;
    if (*(char *)(iVar16 + 0x2400) == '\0') {
        if (((*(uint8_t *)(arg1 + 0x18) & 1) == 0) && (uVar30 = uStack_128, in_stack_00000028 == 0))
        goto code_r0x00018014b8e9;
        if ((0.0 <= *(float *)(iVar16 + 0x104)) || ((float)var_158h <= *(float *)(iVar16 + 0x118))) {
            iVar29 = 0;
            if ((*(float *)(iVar16 + 0x104) <= 0.0) || (fVar35 = *(float *)(iVar16 + 0x118), fVar35 <= var_150h))
            goto code_r0x00018014b679;
            iVar29 = 1;
            fVar34 = var_150h;
        } else {
            iVar29 = -1;
            fVar34 = *(float *)(iVar16 + 0x118);
            fVar35 = (float)var_158h;
        }
        fVar34 = fVar35 - fVar34;
        fcn.18014ad20(arg1, (int64_t)arg2_00, *(int64_t *)(iVar16 + 0x118));
    }
code_r0x00018014b679:
    uVar30 = uStack_128;
    if (((in_stack_00000028 == 0) || ((*(uint8_t *)(in_stack_00000028 + 0x14) & 4) != 0)) ||
       ((*(uint8_t *)(iVar24 + 0x10) & 0x80) != 0)) goto code_r0x00018014b8e9;
    if ((*(char *)(iVar16 + 0x2400) == '\0') || (*(int32_t *)(iVar16 + 0x241c) != iVar18)) {
        fVar35 = *(float *)(iVar16 + 0x12f8);
        fVar33 = ((float)(*(uint32_t *)(iVar16 + 0xbd4) & 0x7fffffff) - (fVar35 + fVar35)) * 0.2;
        if (0.0 <= fVar33) {
            fVar36 = fVar35 * 4.0;
            if (fVar33 <= fVar35 * 4.0) {
                fVar36 = fVar33;
            }
        } else {
            fVar36 = 0.0;
        }
        fVar33 = var_158h._4_4_ - *(float *)(iVar16 + 0x11c);
        fVar37 = *(float *)(iVar16 + 0x11c) - var_14ch;
        if (fVar33 <= fVar37) {
            fVar33 = fVar37;
        }
        if (fVar35 * 2.2 < fVar34) {
            if (iVar29 < 0) {
                iVar24 = (int64_t)arg2_00 - *(int64_t *)(arg1 + 0x10);
                iVar29 = (int32_t)(iVar24 >> 0x3f);
                bVar32 = (int32_t)(iVar24 / 0x38) + iVar29 == iVar29;
            } else {
                if (iVar29 < 1) goto code_r0x00018014b7a0;
                bVar32 = (int32_t)(((int64_t)arg2_00 - *(int64_t *)(arg1 + 0x10)) / 0x38) == *(int32_t *)(arg1 + 8) + -1
                ;
            }
            if (bVar32) goto code_r0x00018014b7a9;
        }
code_r0x00018014b7a0:
        if (fVar33 < fVar35 * 1.5 + fVar36) goto code_r0x00018014b8e9;
    }
code_r0x00018014b7a9:
    piVar1 = (int32_t *)(iVar16 + 0x28f8);
    iVar29 = *(int32_t *)(iVar16 + 0x28fc);
    if (*piVar1 == iVar29) {
        iVar27 = *piVar1 + 1;
        if (iVar29 == 0) {
            iVar29 = 8;
        } else {
            iVar29 = iVar29 / 2 + iVar29;
        }
        if (iVar27 < iVar29) {
            iVar27 = iVar29;
        }
        func_0x00018011fa30(piVar1, iVar27);
    }
    iVar24 = *(int64_t *)(iVar16 + 0x2900);
    iVar22 = (int64_t)*piVar1 * 0x40;
    *(undefined4 *)(iVar22 + iVar24) = 2;
    *(undefined4 *)(iVar22 + 4 + iVar24) = uStack_108._4_4_;
    *(undefined8 *)(iVar22 + 8 + iVar24) = 0;
    *(undefined8 *)(iVar22 + 0x10 + iVar24) = 0;
    *(undefined8 *)(iVar22 + 0x18 + iVar24) = 0;
    *(undefined4 *)(iVar22 + 0x20 + iVar24) = 0xffffffff;
    *(undefined4 *)(iVar22 + 0x24 + iVar24) = 0x3f000000;
    *(undefined *)(iVar22 + 0x28 + iVar24) = 0;
    *(undefined4 *)(iVar22 + 0x29 + iVar24) = uStack_df;
    *(undefined2 *)(iVar22 + 0x2d + iVar24) = uStack_db;
    *(undefined *)(iVar22 + 0x2f + iVar24) = uStack_d9;
    *(int64_t *)(iVar22 + 0x30 + iVar24) = in_stack_00000028;
    *(undefined8 *)(iVar22 + 0x38 + iVar24) = 0;
    *piVar1 = *piVar1 + 1;
    *(int64_t *)(iVar16 + 0x1600) = in_stack_00000028;
    func_0x0001800f9f30(*(undefined4 *)(in_stack_00000028 + 0xc4), in_stack_00000028);
    iVar22 = *(int64_t *)0x180781f28;
    fVar34 = *(float *)(*(int64_t *)(iVar16 + 0x1600) + 0x60);
    fVar35 = *(float *)(*(int64_t *)(iVar16 + 0x1600) + 100);
    *(undefined *)(iVar16 + 0x1662) = 1;
    *(float *)(iVar16 + 0x166c) = *(float *)(iVar16 + 0x166c) - (fVar34 - (float)var_158h);
    *(float *)(iVar16 + 0x1670) = *(float *)(iVar16 + 0x1670) - (fVar35 - var_158h._4_4_);
    *(undefined4 *)(iVar22 + 0x1f68) = 0xf;
    *(undefined *)(iVar22 + 0x1f6c) = 1;
    *(bool *)(iVar22 + 0x2239) = *(char *)(iVar22 + 0x223a) != '\0';
    *(undefined2 *)(iVar22 + 0x2278) = 0;
    uVar30 = uStack_128;
code_r0x00018014b8e9:
    uVar25 = uStackX_20;
    if (((*(uint32_t *)(iVar16 + 0x1fc0) & 0x100) != 0) && ((uStackX_20 >> 0x16 & 1) == 0)) {
        iVar24 = *(int64_t *)(uVar30 + 800);
        uStack_120 = uStack_120 & 0x200000;
        if ((acStackX_8[0] == '\0') && (var_168h._1_1_ == '\0')) {
            if ((uint8_t)var_160h == '\0') {
                iVar21 = 0x26;
                if (uStack_120 != 0) {
                    iVar21 = 0x23;
                }
            } else {
                iVar21 = 0x27;
                if (uStack_120 != 0) {
                    iVar21 = 0x24;
                }
            }
        } else {
            iVar21 = 0x22;
        }
        pauVar2 = (undefined (*) [12])(iVar22 + 0xd90 + (iVar21 + 0x14) * 0x10);
        var_13ch._0_4_ = *(float *)pauVar2[1] * *(float *)(iVar22 + 0xd9c);
        _var_148h = *pauVar2;
        uVar20 = fcn.1800f5fa0(var_148h);
        func_0x00018014bf10(iVar24, &var_158h, uVar25, uVar20);
        if ((((uint8_t)var_160h != '\0') && ((*(uint8_t *)(arg1 + 0x18) & 0x40) != 0)) &&
           (fVar34 = *(float *)(iVar16 + 0xe50), 0.0 < fVar34)) {
            fVar35 = (float)var_158h + 0.0;
            iVar22 = 0x3c0;
            if (uStack_120 != 0) {
                iVar22 = 0x390;
            }
            fVar37 = var_158h._4_4_ + *(float *)(iVar16 + 0x1308);
            fVar36 = var_150h + 0.0;
            pauVar2 = (undefined (*) [12])(iVar22 + 0xd90 + *(int64_t *)0x180781f28);
            var_13ch._0_4_ = *(float *)pauVar2[1] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            _var_148h = *pauVar2;
            uVar20 = fcn.1800f5fa0(var_148h);
            fVar33 = *(float *)(iVar16 + 0xe34);
            if (fVar33 <= 0.0) {
                fStack_12c = fVar37 - 0.5;
                var_198h = CONCAT44(var_198h._4_4_, fVar34);
                fStack_130 = fVar35 - 0.5;
                var_144h._0_4_ = fStack_12c;
                var_148h = (undefined  [4])(fVar36 - 0.5);
                func_0x000180126300(iVar24, &fStack_130, var_148h, uVar20, var_198h);
                uVar25 = uStackX_20;
            } else {
                fVar35 = fVar35 + fVar33;
                fVar37 = fVar33 + fVar37;
                var_144h._0_4_ = fVar37;
                var_148h = (undefined  [4])fVar35;
                if (0.5 <= fVar33) {
                    var_198h = CONCAT44(var_198h._4_4_, 0x24);
                    func_0x0001801257a0(iVar24, var_148h, fVar33, 0x1c, var_198h);
                } else {
                    iVar29 = *(int32_t *)(iVar24 + 0x54);
                    if (*(int32_t *)(iVar24 + 0x50) == iVar29) {
                        iVar27 = *(int32_t *)(iVar24 + 0x50) + 1;
                        if (iVar29 == 0) {
                            iVar29 = 8;
                        } else {
                            iVar29 = iVar29 / 2 + iVar29;
                        }
                        if (iVar27 < iVar29) {
                            iVar27 = iVar29;
                        }
                        func_0x00018011f4f0(iVar24 + 0x50, iVar27);
                    }
                    iVar29 = *(int32_t *)(iVar24 + 0x50);
                    iVar22 = *(int64_t *)(iVar24 + 0x58);
                    *(float *)(iVar22 + (int64_t)iVar29 * 8) = fVar35;
                    *(float *)(iVar22 + 4 + (int64_t)iVar29 * 8) = fVar37;
                    *(int32_t *)(iVar24 + 0x50) = *(int32_t *)(iVar24 + 0x50) + 1;
                }
                fVar36 = fVar36 - fVar33;
                var_148h = (undefined  [4])fVar36;
                if (0.5 <= fVar33) {
                    var_198h = CONCAT44(var_198h._4_4_, 0x2c);
                    func_0x0001801257a0(iVar24, var_148h, fVar33, 0x24, var_198h);
                } else {
                    iVar29 = *(int32_t *)(iVar24 + 0x54);
                    if (*(int32_t *)(iVar24 + 0x50) == iVar29) {
                        iVar27 = *(int32_t *)(iVar24 + 0x50) + 1;
                        if (iVar29 == 0) {
                            iVar29 = 8;
                        } else {
                            iVar29 = iVar29 / 2 + iVar29;
                        }
                        if (iVar27 < iVar29) {
                            iVar27 = iVar29;
                        }
                        func_0x00018011f4f0(iVar24 + 0x50, iVar27);
                    }
                    iVar29 = *(int32_t *)(iVar24 + 0x50);
                    iVar22 = *(int64_t *)(iVar24 + 0x58);
                    *(float *)(iVar22 + (int64_t)iVar29 * 8) = fVar36;
                    *(float *)(iVar22 + 4 + (int64_t)iVar29 * 8) = fVar37;
                    *(int32_t *)(iVar24 + 0x50) = *(int32_t *)(iVar24 + 0x50) + 1;
                }
                var_198h = var_198h & 0xffffffff00000000;
                func_0x0001801248e0(iVar24, *(undefined8 *)(iVar24 + 0x58), *(undefined4 *)(iVar24 + 0x50), uVar20, 
                                    var_198h, *(undefined4 *)(iVar16 + 0xe50));
                *(undefined4 *)(iVar24 + 0x50) = 0;
                uVar25 = uStackX_20;
            }
        }
        func_0x0001800f7d00(&var_158h, iVar18, 0);
        cVar17 = func_0x0001800fa150(0x20);
        iVar29 = *arg2_00;
        if ((((*(int32_t *)(arg1 + 0x20) != iVar29) && (cVar17 != '\0')) &&
            ((cVar17 = func_0x000180107ff0(1, 0, 0), cVar17 != '\0' || (cVar17 = func_0x000180108070(1), cVar17 != '\0')
             ))) && (var_13ch._4_4_ == 0)) {
            *(int32_t *)(arg1 + 0x24) = iVar29;
        }
        if ((*(uint8_t *)(arg1 + 0x18) & 8) != 0) {
            uStackX_20 = uVar25 | 4;
        }
        if (puStackX_18 == (undefined *)0x0) {
            iVar29 = 0;
        } else {
            iVar29 = iVar18;
            if (in_stack_00000028 != 0) {
                iVar29 = *(int32_t *)(in_stack_00000028 + 0x10);
            }
            iVar29 = fcn.1800f5a90(0x1806445a0, 0, iVar29);
        }
        uVar25 = uStackX_20;
        if ((char)var_168h != '\0') {
            uVar25 = uStackX_20 & 0xfffffffe;
        }
        func_0x00018014c270(iVar24, &var_158h, uVar25, *(undefined8 *)(arg1 + 0x90), pcStackX_10, iVar18, iVar29, 
                            (char)(uint32_t)var_160h, &var_168h, (int64_t)&var_168h + 4);
        if (((char)var_168h != '\0') && (puStackX_18 != (undefined *)0x0)) {
            *puStackX_18 = 0;
            if (((uint32_t)arg2_00[1] >> 0x15 & 1) == 0) {
                iVar27 = *arg2_00;
                if ((arg2_00[1] & 0x101U) == 0) {
                    *(undefined *)(arg2_00 + 0xc) = 1;
                    if (*(int32_t *)(arg1 + 0x2c) == iVar27) {
                        arg2_00[4] = -1;
                        *(undefined8 *)(arg1 + 0x20) = 0;
                    }
                } else if (*(int32_t *)(arg1 + 0x2c) != iVar27) {
                    *(int32_t *)(arg1 + 0x24) = iVar27;
                }
            }
        }
        if ((in_stack_00000028 != 0) && ((var_168h._1_1_ != '\0' || (*(int32_t *)(iVar16 + 0x163c) == iVar29)))) {
            *(uint32_t *)(iVar16 + 0x1fc0) = *(uint32_t *)(iVar16 + 0x1fc0) | 0x80;
        }
        if ((((var_168h._4_1_ != '\0') && (*(int32_t *)(iVar16 + 0x163c) == iVar18)) && (acStackX_8[0] == '\0')) &&
           (((*(uint8_t *)(arg1 + 0x18) & 0x20) == 0 && (pcVar15 = pcStackX_10, (*(uint8_t *)(arg2_00 + 1) & 0x10) == 0)
            ))) {
            for (; ((pcVar15 != (char *)0xffffffffffffffff && (*pcVar15 != '\0')) &&
                   ((*pcVar15 != '#' || (pcVar15[1] != '#')))); pcVar15 = pcVar15 + 1) {
            }
            func_0x00018010ceb0(0x180641920, (int32_t)pcVar15 - (int32_t)pcStackX_10, pcStackX_10);
        }
    }
    if (var_168h._2_1_ != '\0') {
        func_0x0001800fc8f0();
    }
    *(undefined4 *)(uStack_128 + 0x158) = uVar3;
    *(undefined4 *)(uStack_128 + 0x15c) = uVar4;
    if (var_13ch._4_4_ == 0) {
        return (uint64_t)(uint8_t)var_160h;
    }
    return (uint64_t)var_168h._3_1_;
}

// ============================================================
// Function: FUN_18014bc00
// Address: 0x18014bc00
// Size: 520 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_198h
// WARNING: Variable defined which should be unmapped: var_190h
// WARNING: Variable defined which should be unmapped: var_188h
// WARNING: Variable defined which should be unmapped: var_180h
// WARNING: Variable defined which should be unmapped: var_178h
// WARNING: Variable defined which should be unmapped: var_170h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_154h
// WARNING: [rz-ghidra] Detected overlap for variable var_150h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_166h
// WARNING: [rz-ghidra] Detected overlap for variable var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable var_167h
// WARNING: [rz-ghidra] Detected overlap for variable var_165h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_27h
// WARNING: [rz-ghidra] Detected overlap for variable var_23h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h

uint64_t fcn.18014ae50(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_c0h, int64_t arg_c8h,
                      int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h)
{
    int32_t *piVar1;
    undefined (*pauVar2) [12];
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int16_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    char *pcVar15;
    int64_t iVar16;
    char cVar17;
    int32_t iVar18;
    uint32_t uVar19;
    undefined4 uVar20;
    int64_t iVar21;
    int64_t iVar22;
    uint32_t uVar23;
    int64_t iVar24;
    uint32_t uVar25;
    int32_t *arg2_00;
    int32_t iVar27;
    undefined8 uVar28;
    int32_t iVar29;
    uint64_t uVar30;
    bool bVar31;
    bool bVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    float fVar37;
    char acStackX_8 [8];
    char *pcStackX_10;
    undefined *puStackX_18;
    uint32_t uStackX_20;
    int64_t in_stack_00000028;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    float var_150h;
    float var_14ch;
    undefined var_148h [4];
    undefined var_144h [8];
    int64_t var_13ch;
    float fStack_130;
    float fStack_12c;
    uint64_t uStack_128;
    uint32_t uStack_120;
    int32_t iStack_11c;
    int32_t iStack_118;
    undefined8 uStack_108;
    undefined8 uStack_100;
    undefined8 uStack_f8;
    undefined8 uStack_f0;
    undefined4 uStack_e8;
    unkbyte5 Stack_e4;
    undefined4 uStack_df;
    undefined2 uStack_db;
    undefined uStack_d9;
    undefined8 uStack_d8;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uVar26;
    
    iVar16 = *(int64_t *)0x180781f28;
    stack0xfffffffffffffec0 = _var_148h;
    uVar25 = (uint32_t)arg4;
    uVar30 = arg4 & 0xffffffff;
    iVar24 = *(int64_t *)0x180781f28;
    pcStackX_10 = (char *)arg2;
    puStackX_18 = (undefined *)arg3;
    uStackX_20 = uVar25;
    if (*(char *)(arg1 + 0x83) != '\0') {
        uVar3 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f80);
        uVar4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f84);
        uVar20 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f88);
        uVar5 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f8c);
        uVar7 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f90);
        uVar8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f94);
        uVar9 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f98);
        uVar10 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f9c);
        uVar11 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fa0);
        uVar12 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fa4);
        uVar13 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fa8);
        uVar14 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fac);
        uVar28 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x1fb0);
        fcn.180148fa0(arg1, arg2);
        iVar24 = *(int64_t *)0x180781f28;
        *(undefined4 *)(iVar16 + 0x1f80) = uVar3;
        *(undefined4 *)(iVar16 + 0x1f84) = uVar4;
        *(undefined4 *)(iVar16 + 0x1f88) = uVar20;
        *(undefined4 *)(iVar16 + 0x1f8c) = uVar5;
        *(undefined4 *)(iVar16 + 0x1f90) = uVar7;
        *(undefined4 *)(iVar16 + 0x1f94) = uVar8;
        *(undefined4 *)(iVar16 + 0x1f98) = uVar9;
        *(undefined4 *)(iVar16 + 0x1f9c) = uVar10;
        *(undefined4 *)(iVar16 + 0x1fa0) = uVar11;
        *(undefined4 *)(iVar16 + 0x1fa4) = uVar12;
        *(undefined4 *)(iVar16 + 0x1fa8) = uVar13;
        *(undefined4 *)(iVar16 + 0x1fac) = uVar14;
        *(undefined8 *)(iVar16 + 0x1fb0) = uVar28;
    }
    iVar22 = in_stack_00000028;
    uStack_128 = *(uint64_t *)(iVar16 + 0x15e0);
    if (*(char *)(uStack_128 + 0x10e) != '\0') {
code_r0x00018014afb2:
        return uStack_128 & 0xffffffffffffff00;
    }
    if (in_stack_00000028 == 0) {
        iVar18 = fcn.1800f5a90(pcStackX_10, 0, 
                               *(undefined4 *)
                                (*(int64_t *)(*(int64_t *)(iVar24 + 0x15e0) + 0x150) + -4 +
                                (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 0x15e0) + 0x148) * 4));
    } else {
        iVar18 = *(int32_t *)(in_stack_00000028 + 200);
        if (*(int32_t *)(iVar24 + 0x1654) == iVar18) {
            *(int32_t *)(iVar24 + 0x1658) = iVar18;
        }
        if (*(int32_t *)(iVar24 + 0x1684) == iVar18) {
            *(undefined *)(iVar24 + 0x168d) = 1;
        }
    }
    if ((arg3 != 0) && (*(char *)arg3 == '\0')) {
        _var_148h = ZEXT816(0);
        uStack_128 = func_0x00018010b530(var_148h, iVar18, 0, 2);
        goto code_r0x00018014afb2;
    }
    uVar26 = 0;
    if ((uVar25 >> 0x14 & 1) == 0) {
        if (arg3 == 0) {
            uStackX_20 = uVar25 | 0x100000;
            uVar30 = (uint64_t)uStackX_20;
        }
    } else {
        puStackX_18 = (undefined *)0x0;
    }
    if ((iVar18 != 0) && (0 < *(int32_t *)(arg1 + 8))) {
        do {
            arg2_00 = (int32_t *)(uVar26 * 0x38 + *(int64_t *)(arg1 + 0x10));
            if (*arg2_00 == iVar18) {
                bVar32 = false;
                goto code_r0x00018014b075;
            }
            uVar25 = (int32_t)uVar26 + 1;
            uVar26 = (uint64_t)uVar25;
        } while ((int32_t)uVar25 < *(int32_t *)(arg1 + 8));
    }
    uStack_108 = 0;
    uStack_100 = 0;
    uStack_f0 = 0;
    uStack_e8 = 0;
    uStack_d8 = 0;
    uStack_f8 = 0xffffffffffffffff;
    Stack_e4 = 0xffbf800000;
    uStack_df = 0xffffffff;
    uStack_db = 0xffff;
    uStack_d9 = 0xff;
    func_0x00018011f0c0(arg1 + 8, &uStack_108);
    bVar32 = true;
    arg2_00 = (int32_t *)(*(int64_t *)(arg1 + 0x10) + -0x38 + (int64_t)*(int32_t *)(arg1 + 8) * 0x38);
    *arg2_00 = iVar18;
    *(undefined *)(arg1 + 0x85) = 1;
code_r0x00018014b075:
    *(int16_t *)(arg1 + 0x8a) = (int16_t)(((int64_t)arg2_00 - *(int64_t *)(arg1 + 0x10)) / 0x38);
    if ((puStackX_18 == (undefined *)0x0) && ((uVar30 & 1) == 0)) {
        uVar28 = 0;
    } else {
        uVar28 = 1;
    }
    func_0x00018014be50(&fStack_130, pcStackX_10, uVar28);
    arg2_00[9] = -0x40800000;
    fVar34 = fStack_130;
    if ((*(uint8_t *)(iVar16 + 0x1f80) & 1) != 0) {
        fVar34 = *(float *)(iVar16 + 0x1f98);
        arg2_00[9] = (int32_t)fVar34;
    }
    if (bVar32) {
        fVar35 = 1.0;
        if (1.0 <= fVar34) {
            fVar35 = fVar34;
        }
        arg2_00[7] = (int32_t)fVar35;
    }
    arg2_00[8] = (int32_t)fVar34;
    iVar6 = *(int16_t *)(arg1 + 0x88);
    *(int16_t *)(arg1 + 0x88) = iVar6 + 1;
    *(int16_t *)(arg2_00 + 0xb) = iVar6;
    iStack_11c = arg2_00[4] + 1;
    uStack_120 = *(uint32_t *)(arg1 + 0x18);
    iStack_118 = *(int32_t *)(iVar16 + 4);
    iVar29 = *(int32_t *)(arg1 + 0x34) + 1;
    if (((uStackX_20 & 1) == 0) || (var_168h._0_1_ = '\x01', (*(uint8_t *)(arg2_00 + 1) & 1) != 0)) {
        var_168h._0_1_ = '\0';
    }
    arg2_00[4] = iStack_118;
    var_13ch._4_4_ = uStackX_20 & 0x200000;
    arg2_00[1] = uStackX_20;
    *(int64_t *)(arg2_00 + 2) = iVar22;
    if (iVar22 == 0) {
        iVar27 = *(int32_t *)(arg1 + 0xa0) + -1;
        if (*(int32_t *)(arg1 + 0xa0) == 0) {
            iVar27 = 0;
        }
        arg2_00[10] = iVar27;
        iVar24 = func_0x000180498cd0(pcStackX_10);
        func_0x0001800f64c0(arg1 + 0xa0, pcStackX_10, pcStackX_10 + iVar24 + 1);
        iVar22 = in_stack_00000028;
    } else {
        arg2_00[10] = -1;
    }
    uVar30 = uStack_128;
    if (var_13ch._4_4_ == 0) {
        if ((((iStack_11c < iStack_118) && ((*(uint8_t *)(arg1 + 0x18) & 2) != 0)) && (*(int32_t *)(arg1 + 0x24) == 0))
           && ((iStack_118 <= iVar29 || (*(int32_t *)(arg1 + 0x20) == 0)))) {
            *(int32_t *)(arg1 + 0x24) = *arg2_00;
        }
        if (((uStackX_20 & 2) != 0) && (*(int32_t *)(arg1 + 0x20) != iVar18)) {
            *(int32_t *)(arg1 + 0x24) = *arg2_00;
        }
    }
    bVar31 = *(int32_t *)(arg1 + 0x2c) == iVar18;
    var_160h._0_4_ = CONCAT31((unkint3)(uStackX_20 >> 8), bVar31);
    if (bVar31) {
        *(undefined *)(arg1 + 0x84) = 1;
    } else if ((((*(int32_t *)(arg1 + 0x20) == 0) && (iVar29 < iStack_118)) && (iVar22 == 0)) &&
              ((*(int32_t *)(arg1 + 8) == 1 && (var_160h._0_4_ = (uint32_t)bVar31, (*(uint8_t *)(arg1 + 0x18) & 2) == 0)
               ))) {
        var_160h._0_4_ = 1;
    }
    if ((iStack_11c < iStack_118) && ((iStack_118 <= iVar29 || (bVar32)))) {
        _var_148h = ZEXT816(0);
        uStack_128 = func_0x00018010b530(var_148h, iVar18, 0, 2);
        if (var_13ch._4_4_ == 0) {
            return (uint64_t)(uint8_t)var_160h;
        }
        goto code_r0x00018014afb2;
    }
    if (*(int32_t *)(arg1 + 0x20) == iVar18) {
        arg2_00[5] = *(int32_t *)(iVar16 + 4);
    }
    var_150h = (float)arg2_00[7];
    uVar3 = *(undefined4 *)(uStack_128 + 0x158);
    var_158h._4_4_ = *(float *)(arg1 + 0x3c) + 0.0;
    uVar4 = *(undefined4 *)(uStack_128 + 0x15c);
    if ((*(uint8_t *)(arg2_00 + 1) & 0xc0) == 0) {
        var_158h._0_4_ = (float)(int32_t)((float)arg2_00[6] - *(float *)(arg1 + 0x5c)) + *(float *)(arg1 + 0x38);
        *(float *)(uStack_128 + 0x158) = (float)var_158h;
        var_150h = var_150h + (float)var_158h;
        *(float *)(uStack_128 + 0x15c) = var_158h._4_4_;
        var_14ch = var_158h._4_4_ + fStack_12c;
        fVar34 = *(float *)(arg1 + 0x6c);
        if ((fVar34 <= (float)var_158h) && (var_150h < *(float *)(arg1 + 0x70) || var_150h == *(float *)(arg1 + 0x70)))
        goto code_r0x00018014b3e0;
        bVar32 = true;
        var_168h._2_1_ = '\x01';
        fStack_130 = *(float *)(arg1 + 0x70);
        if ((fVar34 <= (float)var_158h) && (fVar34 = fStack_130, (float)var_158h <= fStack_130)) {
            fVar34 = (float)var_158h;
        }
        _var_148h = CONCAT44(var_158h._4_4_ - 1.0, fVar34);
        fStack_12c = var_14ch;
        func_0x0001800fc860(var_148h, &fStack_130, 1);
    } else {
        var_158h._0_4_ = (float)arg2_00[6] + *(float *)(arg1 + 0x38);
        *(float *)(uStack_128 + 0x158) = (float)var_158h;
        var_150h = var_150h + (float)var_158h;
        *(float *)(uStack_128 + 0x15c) = var_158h._4_4_;
code_r0x00018014b3e0:
        var_14ch = var_158h._4_4_ + fStack_12c;
        bVar32 = false;
        var_168h._2_1_ = '\0';
    }
    uVar20 = *(undefined4 *)(uVar30 + 0x170);
    uVar5 = *(undefined4 *)(uVar30 + 0x174);
    var_144h._0_4_ = var_14ch - var_158h._4_4_;
    var_148h = (undefined  [4])(var_150h - (float)var_158h);
    func_0x00018010bbf0(var_148h, *(undefined4 *)(iVar16 + 0xde0));
    *(undefined4 *)(uVar30 + 0x170) = uVar20;
    *(undefined4 *)(uVar30 + 0x174) = uVar5;
    cVar17 = func_0x00018010b530(&var_158h, iVar18, 0, 0);
    uVar25 = var_13ch._4_4_;
    if (cVar17 == '\0') {
        if (bVar32) {
            func_0x0001800fc8f0();
        }
        *(undefined4 *)(uVar30 + 0x158) = uVar3;
        *(undefined4 *)(uVar30 + 0x15c) = uVar4;
        return (uint64_t)(uint8_t)var_160h;
    }
    uVar19 = 0x1010;
    if (var_13ch._4_4_ != 0) {
        uVar19 = 0x1020;
    }
    uVar23 = uVar19;
    if (*(char *)(iVar16 + 0x2400) != '\0') {
        cVar17 = func_0x0001800f3aa0(iVar16 + 0x2410);
        uVar23 = uVar19 | 0x200;
        if (cVar17 != '\0') {
            uVar23 = uVar19;
        }
    }
    if ((uStackX_20 & 0x400000) == 0) {
        var_198h = CONCAT44(var_198h._4_4_, uVar23);
        var_168h._3_1_ = func_0x000180139d40(&var_158h, iVar18, (int64_t)&var_168h + 1, acStackX_8, var_198h);
        if ((var_168h._3_1_ != 0) && (uVar25 == 0)) {
            *(int32_t *)(arg1 + 0x24) = *arg2_00;
        }
        if (acStackX_8[0] == '\0') goto code_r0x00018014b4c3;
        if (in_stack_00000028 == 0) goto code_r0x00018014b56d;
        if ((*(int32_t *)(iVar16 + 0x1654) == iVar18) && (*(char *)(iVar16 + 0x1660) != '\0')) {
            *(int64_t *)(iVar16 + 0x1678) = in_stack_00000028;
        }
code_r0x00018014b4d3:
        iVar24 = *(int64_t *)(in_stack_00000028 + 0x4c0);
        if ((((iVar24 == 0) || (*(int64_t *)(iVar24 + 0x18) != 0)) || ((*(uint32_t *)(iVar24 + 0x10) & 0x400) != 0)) ||
           (*(int32_t *)(iVar24 + 0x30) != 1)) goto code_r0x00018014b570;
        bVar32 = true;
    } else {
        var_168h._3_1_ = 0;
        acStackX_8[0] = '\0';
        var_168h._1_1_ = '\0';
code_r0x00018014b4c3:
        if (in_stack_00000028 != 0) goto code_r0x00018014b4d3;
code_r0x00018014b56d:
        iVar24 = 0;
code_r0x00018014b570:
        bVar32 = false;
    }
    iVar22 = *(int64_t *)0x180781f28;
    if (acStackX_8[0] == '\0') goto code_r0x00018014b8e9;
    if (((bVar32) && (*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0')) &&
       (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbfc))) {
        func_0x0001800faa00();
        iVar22 = *(int64_t *)0x180781f28;
        goto code_r0x00018014b8e9;
    }
    if (((iStack_11c < iStack_118) || (*(char *)(*(int64_t *)0x180781f28 + 0x120) == '\0')) ||
       (*(float *)(*(int64_t *)0x180781f28 + 0xbfc) <
        *(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4)))
    goto code_r0x00018014b8e9;
    fVar34 = 0.0;
    iVar29 = 0;
    if (*(char *)(iVar16 + 0x2400) == '\0') {
        if (((*(uint8_t *)(arg1 + 0x18) & 1) == 0) && (uVar30 = uStack_128, in_stack_00000028 == 0))
        goto code_r0x00018014b8e9;
        if ((0.0 <= *(float *)(iVar16 + 0x104)) || ((float)var_158h <= *(float *)(iVar16 + 0x118))) {
            iVar29 = 0;
            if ((*(float *)(iVar16 + 0x104) <= 0.0) || (fVar35 = *(float *)(iVar16 + 0x118), fVar35 <= var_150h))
            goto code_r0x00018014b679;
            iVar29 = 1;
            fVar34 = var_150h;
        } else {
            iVar29 = -1;
            fVar34 = *(float *)(iVar16 + 0x118);
            fVar35 = (float)var_158h;
        }
        fVar34 = fVar35 - fVar34;
        fcn.18014ad20(arg1, (int64_t)arg2_00, *(int64_t *)(iVar16 + 0x118));
    }
code_r0x00018014b679:
    uVar30 = uStack_128;
    if (((in_stack_00000028 == 0) || ((*(uint8_t *)(in_stack_00000028 + 0x14) & 4) != 0)) ||
       ((*(uint8_t *)(iVar24 + 0x10) & 0x80) != 0)) goto code_r0x00018014b8e9;
    if ((*(char *)(iVar16 + 0x2400) == '\0') || (*(int32_t *)(iVar16 + 0x241c) != iVar18)) {
        fVar35 = *(float *)(iVar16 + 0x12f8);
        fVar33 = ((float)(*(uint32_t *)(iVar16 + 0xbd4) & 0x7fffffff) - (fVar35 + fVar35)) * 0.2;
        if (0.0 <= fVar33) {
            fVar36 = fVar35 * 4.0;
            if (fVar33 <= fVar35 * 4.0) {
                fVar36 = fVar33;
            }
        } else {
            fVar36 = 0.0;
        }
        fVar33 = var_158h._4_4_ - *(float *)(iVar16 + 0x11c);
        fVar37 = *(float *)(iVar16 + 0x11c) - var_14ch;
        if (fVar33 <= fVar37) {
            fVar33 = fVar37;
        }
        if (fVar35 * 2.2 < fVar34) {
            if (iVar29 < 0) {
                iVar24 = (int64_t)arg2_00 - *(int64_t *)(arg1 + 0x10);
                iVar29 = (int32_t)(iVar24 >> 0x3f);
                bVar32 = (int32_t)(iVar24 / 0x38) + iVar29 == iVar29;
            } else {
                if (iVar29 < 1) goto code_r0x00018014b7a0;
                bVar32 = (int32_t)(((int64_t)arg2_00 - *(int64_t *)(arg1 + 0x10)) / 0x38) == *(int32_t *)(arg1 + 8) + -1
                ;
            }
            if (bVar32) goto code_r0x00018014b7a9;
        }
code_r0x00018014b7a0:
        if (fVar33 < fVar35 * 1.5 + fVar36) goto code_r0x00018014b8e9;
    }
code_r0x00018014b7a9:
    piVar1 = (int32_t *)(iVar16 + 0x28f8);
    iVar29 = *(int32_t *)(iVar16 + 0x28fc);
    if (*piVar1 == iVar29) {
        iVar27 = *piVar1 + 1;
        if (iVar29 == 0) {
            iVar29 = 8;
        } else {
            iVar29 = iVar29 / 2 + iVar29;
        }
        if (iVar27 < iVar29) {
            iVar27 = iVar29;
        }
        func_0x00018011fa30(piVar1, iVar27);
    }
    iVar24 = *(int64_t *)(iVar16 + 0x2900);
    iVar22 = (int64_t)*piVar1 * 0x40;
    *(undefined4 *)(iVar22 + iVar24) = 2;
    *(undefined4 *)(iVar22 + 4 + iVar24) = uStack_108._4_4_;
    *(undefined8 *)(iVar22 + 8 + iVar24) = 0;
    *(undefined8 *)(iVar22 + 0x10 + iVar24) = 0;
    *(undefined8 *)(iVar22 + 0x18 + iVar24) = 0;
    *(undefined4 *)(iVar22 + 0x20 + iVar24) = 0xffffffff;
    *(undefined4 *)(iVar22 + 0x24 + iVar24) = 0x3f000000;
    *(undefined *)(iVar22 + 0x28 + iVar24) = 0;
    *(undefined4 *)(iVar22 + 0x29 + iVar24) = uStack_df;
    *(undefined2 *)(iVar22 + 0x2d + iVar24) = uStack_db;
    *(undefined *)(iVar22 + 0x2f + iVar24) = uStack_d9;
    *(int64_t *)(iVar22 + 0x30 + iVar24) = in_stack_00000028;
    *(undefined8 *)(iVar22 + 0x38 + iVar24) = 0;
    *piVar1 = *piVar1 + 1;
    *(int64_t *)(iVar16 + 0x1600) = in_stack_00000028;
    func_0x0001800f9f30(*(undefined4 *)(in_stack_00000028 + 0xc4), in_stack_00000028);
    iVar22 = *(int64_t *)0x180781f28;
    fVar34 = *(float *)(*(int64_t *)(iVar16 + 0x1600) + 0x60);
    fVar35 = *(float *)(*(int64_t *)(iVar16 + 0x1600) + 100);
    *(undefined *)(iVar16 + 0x1662) = 1;
    *(float *)(iVar16 + 0x166c) = *(float *)(iVar16 + 0x166c) - (fVar34 - (float)var_158h);
    *(float *)(iVar16 + 0x1670) = *(float *)(iVar16 + 0x1670) - (fVar35 - var_158h._4_4_);
    *(undefined4 *)(iVar22 + 0x1f68) = 0xf;
    *(undefined *)(iVar22 + 0x1f6c) = 1;
    *(bool *)(iVar22 + 0x2239) = *(char *)(iVar22 + 0x223a) != '\0';
    *(undefined2 *)(iVar22 + 0x2278) = 0;
    uVar30 = uStack_128;
code_r0x00018014b8e9:
    uVar25 = uStackX_20;
    if (((*(uint32_t *)(iVar16 + 0x1fc0) & 0x100) != 0) && ((uStackX_20 >> 0x16 & 1) == 0)) {
        iVar24 = *(int64_t *)(uVar30 + 800);
        uStack_120 = uStack_120 & 0x200000;
        if ((acStackX_8[0] == '\0') && (var_168h._1_1_ == '\0')) {
            if ((uint8_t)var_160h == '\0') {
                iVar21 = 0x26;
                if (uStack_120 != 0) {
                    iVar21 = 0x23;
                }
            } else {
                iVar21 = 0x27;
                if (uStack_120 != 0) {
                    iVar21 = 0x24;
                }
            }
        } else {
            iVar21 = 0x22;
        }
        pauVar2 = (undefined (*) [12])(iVar22 + 0xd90 + (iVar21 + 0x14) * 0x10);
        var_13ch._0_4_ = *(float *)pauVar2[1] * *(float *)(iVar22 + 0xd9c);
        _var_148h = *pauVar2;
        uVar20 = fcn.1800f5fa0(var_148h);
        func_0x00018014bf10(iVar24, &var_158h, uVar25, uVar20);
        if ((((uint8_t)var_160h != '\0') && ((*(uint8_t *)(arg1 + 0x18) & 0x40) != 0)) &&
           (fVar34 = *(float *)(iVar16 + 0xe50), 0.0 < fVar34)) {
            fVar35 = (float)var_158h + 0.0;
            iVar22 = 0x3c0;
            if (uStack_120 != 0) {
                iVar22 = 0x390;
            }
            fVar37 = var_158h._4_4_ + *(float *)(iVar16 + 0x1308);
            fVar36 = var_150h + 0.0;
            pauVar2 = (undefined (*) [12])(iVar22 + 0xd90 + *(int64_t *)0x180781f28);
            var_13ch._0_4_ = *(float *)pauVar2[1] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            _var_148h = *pauVar2;
            uVar20 = fcn.1800f5fa0(var_148h);
            fVar33 = *(float *)(iVar16 + 0xe34);
            if (fVar33 <= 0.0) {
                fStack_12c = fVar37 - 0.5;
                var_198h = CONCAT44(var_198h._4_4_, fVar34);
                fStack_130 = fVar35 - 0.5;
                var_144h._0_4_ = fStack_12c;
                var_148h = (undefined  [4])(fVar36 - 0.5);
                func_0x000180126300(iVar24, &fStack_130, var_148h, uVar20, var_198h);
                uVar25 = uStackX_20;
            } else {
                fVar35 = fVar35 + fVar33;
                fVar37 = fVar33 + fVar37;
                var_144h._0_4_ = fVar37;
                var_148h = (undefined  [4])fVar35;
                if (0.5 <= fVar33) {
                    var_198h = CONCAT44(var_198h._4_4_, 0x24);
                    func_0x0001801257a0(iVar24, var_148h, fVar33, 0x1c, var_198h);
                } else {
                    iVar29 = *(int32_t *)(iVar24 + 0x54);
                    if (*(int32_t *)(iVar24 + 0x50) == iVar29) {
                        iVar27 = *(int32_t *)(iVar24 + 0x50) + 1;
                        if (iVar29 == 0) {
                            iVar29 = 8;
                        } else {
                            iVar29 = iVar29 / 2 + iVar29;
                        }
                        if (iVar27 < iVar29) {
                            iVar27 = iVar29;
                        }
                        func_0x00018011f4f0(iVar24 + 0x50, iVar27);
                    }
                    iVar29 = *(int32_t *)(iVar24 + 0x50);
                    iVar22 = *(int64_t *)(iVar24 + 0x58);
                    *(float *)(iVar22 + (int64_t)iVar29 * 8) = fVar35;
                    *(float *)(iVar22 + 4 + (int64_t)iVar29 * 8) = fVar37;
                    *(int32_t *)(iVar24 + 0x50) = *(int32_t *)(iVar24 + 0x50) + 1;
                }
                fVar36 = fVar36 - fVar33;
                var_148h = (undefined  [4])fVar36;
                if (0.5 <= fVar33) {
                    var_198h = CONCAT44(var_198h._4_4_, 0x2c);
                    func_0x0001801257a0(iVar24, var_148h, fVar33, 0x24, var_198h);
                } else {
                    iVar29 = *(int32_t *)(iVar24 + 0x54);
                    if (*(int32_t *)(iVar24 + 0x50) == iVar29) {
                        iVar27 = *(int32_t *)(iVar24 + 0x50) + 1;
                        if (iVar29 == 0) {
                            iVar29 = 8;
                        } else {
                            iVar29 = iVar29 / 2 + iVar29;
                        }
                        if (iVar27 < iVar29) {
                            iVar27 = iVar29;
                        }
                        func_0x00018011f4f0(iVar24 + 0x50, iVar27);
                    }
                    iVar29 = *(int32_t *)(iVar24 + 0x50);
                    iVar22 = *(int64_t *)(iVar24 + 0x58);
                    *(float *)(iVar22 + (int64_t)iVar29 * 8) = fVar36;
                    *(float *)(iVar22 + 4 + (int64_t)iVar29 * 8) = fVar37;
                    *(int32_t *)(iVar24 + 0x50) = *(int32_t *)(iVar24 + 0x50) + 1;
                }
                var_198h = var_198h & 0xffffffff00000000;
                func_0x0001801248e0(iVar24, *(undefined8 *)(iVar24 + 0x58), *(undefined4 *)(iVar24 + 0x50), uVar20, 
                                    var_198h, *(undefined4 *)(iVar16 + 0xe50));
                *(undefined4 *)(iVar24 + 0x50) = 0;
                uVar25 = uStackX_20;
            }
        }
        func_0x0001800f7d00(&var_158h, iVar18, 0);
        cVar17 = func_0x0001800fa150(0x20);
        iVar29 = *arg2_00;
        if ((((*(int32_t *)(arg1 + 0x20) != iVar29) && (cVar17 != '\0')) &&
            ((cVar17 = func_0x000180107ff0(1, 0, 0), cVar17 != '\0' || (cVar17 = func_0x000180108070(1), cVar17 != '\0')
             ))) && (var_13ch._4_4_ == 0)) {
            *(int32_t *)(arg1 + 0x24) = iVar29;
        }
        if ((*(uint8_t *)(arg1 + 0x18) & 8) != 0) {
            uStackX_20 = uVar25 | 4;
        }
        if (puStackX_18 == (undefined *)0x0) {
            iVar29 = 0;
        } else {
            iVar29 = iVar18;
            if (in_stack_00000028 != 0) {
                iVar29 = *(int32_t *)(in_stack_00000028 + 0x10);
            }
            iVar29 = fcn.1800f5a90(0x1806445a0, 0, iVar29);
        }
        uVar25 = uStackX_20;
        if ((char)var_168h != '\0') {
            uVar25 = uStackX_20 & 0xfffffffe;
        }
        func_0x00018014c270(iVar24, &var_158h, uVar25, *(undefined8 *)(arg1 + 0x90), pcStackX_10, iVar18, iVar29, 
                            (char)(uint32_t)var_160h, &var_168h, (int64_t)&var_168h + 4);
        if (((char)var_168h != '\0') && (puStackX_18 != (undefined *)0x0)) {
            *puStackX_18 = 0;
            if (((uint32_t)arg2_00[1] >> 0x15 & 1) == 0) {
                iVar27 = *arg2_00;
                if ((arg2_00[1] & 0x101U) == 0) {
                    *(undefined *)(arg2_00 + 0xc) = 1;
                    if (*(int32_t *)(arg1 + 0x2c) == iVar27) {
                        arg2_00[4] = -1;
                        *(undefined8 *)(arg1 + 0x20) = 0;
                    }
                } else if (*(int32_t *)(arg1 + 0x2c) != iVar27) {
                    *(int32_t *)(arg1 + 0x24) = iVar27;
                }
            }
        }
        if ((in_stack_00000028 != 0) && ((var_168h._1_1_ != '\0' || (*(int32_t *)(iVar16 + 0x163c) == iVar29)))) {
            *(uint32_t *)(iVar16 + 0x1fc0) = *(uint32_t *)(iVar16 + 0x1fc0) | 0x80;
        }
        if ((((var_168h._4_1_ != '\0') && (*(int32_t *)(iVar16 + 0x163c) == iVar18)) && (acStackX_8[0] == '\0')) &&
           (((*(uint8_t *)(arg1 + 0x18) & 0x20) == 0 && (pcVar15 = pcStackX_10, (*(uint8_t *)(arg2_00 + 1) & 0x10) == 0)
            ))) {
            for (; ((pcVar15 != (char *)0xffffffffffffffff && (*pcVar15 != '\0')) &&
                   ((*pcVar15 != '#' || (pcVar15[1] != '#')))); pcVar15 = pcVar15 + 1) {
            }
            func_0x00018010ceb0(0x180641920, (int32_t)pcVar15 - (int32_t)pcStackX_10, pcStackX_10);
        }
    }
    if (var_168h._2_1_ != '\0') {
        func_0x0001800fc8f0();
    }
    *(undefined4 *)(uStack_128 + 0x158) = uVar3;
    *(undefined4 *)(uStack_128 + 0x15c) = uVar4;
    if (var_13ch._4_4_ == 0) {
        return (uint64_t)(uint8_t)var_160h;
    }
    return (uint64_t)var_168h._3_1_;
}

// ============================================================
// Function: FUN_18014be08
// Address: 0x18014be08
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_198h
// WARNING: Variable defined which should be unmapped: var_190h
// WARNING: Variable defined which should be unmapped: var_188h
// WARNING: Variable defined which should be unmapped: var_180h
// WARNING: Variable defined which should be unmapped: var_178h
// WARNING: Variable defined which should be unmapped: var_170h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_154h
// WARNING: [rz-ghidra] Detected overlap for variable var_150h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_166h
// WARNING: [rz-ghidra] Detected overlap for variable var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_144h
// WARNING: [rz-ghidra] Detected overlap for variable var_167h
// WARNING: [rz-ghidra] Detected overlap for variable var_165h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_27h
// WARNING: [rz-ghidra] Detected overlap for variable var_23h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_120h

uint64_t fcn.18014ae50(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_c0h, int64_t arg_c8h,
                      int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h)
{
    int32_t *piVar1;
    undefined (*pauVar2) [12];
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int16_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    char *pcVar15;
    int64_t iVar16;
    char cVar17;
    int32_t iVar18;
    uint32_t uVar19;
    undefined4 uVar20;
    int64_t iVar21;
    int64_t iVar22;
    uint32_t uVar23;
    int64_t iVar24;
    uint32_t uVar25;
    int32_t *arg2_00;
    int32_t iVar27;
    undefined8 uVar28;
    int32_t iVar29;
    uint64_t uVar30;
    bool bVar31;
    bool bVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    float fVar37;
    char acStackX_8 [8];
    char *pcStackX_10;
    undefined *puStackX_18;
    uint32_t uStackX_20;
    int64_t in_stack_00000028;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    float var_150h;
    float var_14ch;
    undefined var_148h [4];
    undefined var_144h [8];
    int64_t var_13ch;
    float fStack_130;
    float fStack_12c;
    uint64_t uStack_128;
    uint32_t uStack_120;
    int32_t iStack_11c;
    int32_t iStack_118;
    undefined8 uStack_108;
    undefined8 uStack_100;
    undefined8 uStack_f8;
    undefined8 uStack_f0;
    undefined4 uStack_e8;
    unkbyte5 Stack_e4;
    undefined4 uStack_df;
    undefined2 uStack_db;
    undefined uStack_d9;
    undefined8 uStack_d8;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uVar26;
    
    iVar16 = *(int64_t *)0x180781f28;
    stack0xfffffffffffffec0 = _var_148h;
    uVar25 = (uint32_t)arg4;
    uVar30 = arg4 & 0xffffffff;
    iVar24 = *(int64_t *)0x180781f28;
    pcStackX_10 = (char *)arg2;
    puStackX_18 = (undefined *)arg3;
    uStackX_20 = uVar25;
    if (*(char *)(arg1 + 0x83) != '\0') {
        uVar3 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f80);
        uVar4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f84);
        uVar20 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f88);
        uVar5 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f8c);
        uVar7 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f90);
        uVar8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f94);
        uVar9 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f98);
        uVar10 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1f9c);
        uVar11 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fa0);
        uVar12 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fa4);
        uVar13 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fa8);
        uVar14 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fac);
        uVar28 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x1fb0);
        fcn.180148fa0(arg1, arg2);
        iVar24 = *(int64_t *)0x180781f28;
        *(undefined4 *)(iVar16 + 0x1f80) = uVar3;
        *(undefined4 *)(iVar16 + 0x1f84) = uVar4;
        *(undefined4 *)(iVar16 + 0x1f88) = uVar20;
        *(undefined4 *)(iVar16 + 0x1f8c) = uVar5;
        *(undefined4 *)(iVar16 + 0x1f90) = uVar7;
        *(undefined4 *)(iVar16 + 0x1f94) = uVar8;
        *(undefined4 *)(iVar16 + 0x1f98) = uVar9;
        *(undefined4 *)(iVar16 + 0x1f9c) = uVar10;
        *(undefined4 *)(iVar16 + 0x1fa0) = uVar11;
        *(undefined4 *)(iVar16 + 0x1fa4) = uVar12;
        *(undefined4 *)(iVar16 + 0x1fa8) = uVar13;
        *(undefined4 *)(iVar16 + 0x1fac) = uVar14;
        *(undefined8 *)(iVar16 + 0x1fb0) = uVar28;
    }
    iVar22 = in_stack_00000028;
    uStack_128 = *(uint64_t *)(iVar16 + 0x15e0);
    if (*(char *)(uStack_128 + 0x10e) != '\0') {
code_r0x00018014afb2:
        return uStack_128 & 0xffffffffffffff00;
    }
    if (in_stack_00000028 == 0) {
        iVar18 = fcn.1800f5a90(pcStackX_10, 0, 
                               *(undefined4 *)
                                (*(int64_t *)(*(int64_t *)(iVar24 + 0x15e0) + 0x150) + -4 +
                                (int64_t)*(int32_t *)(*(int64_t *)(iVar24 + 0x15e0) + 0x148) * 4));
    } else {
        iVar18 = *(int32_t *)(in_stack_00000028 + 200);
        if (*(int32_t *)(iVar24 + 0x1654) == iVar18) {
            *(int32_t *)(iVar24 + 0x1658) = iVar18;
        }
        if (*(int32_t *)(iVar24 + 0x1684) == iVar18) {
            *(undefined *)(iVar24 + 0x168d) = 1;
        }
    }
    if ((arg3 != 0) && (*(char *)arg3 == '\0')) {
        _var_148h = ZEXT816(0);
        uStack_128 = func_0x00018010b530(var_148h, iVar18, 0, 2);
        goto code_r0x00018014afb2;
    }
    uVar26 = 0;
    if ((uVar25 >> 0x14 & 1) == 0) {
        if (arg3 == 0) {
            uStackX_20 = uVar25 | 0x100000;
            uVar30 = (uint64_t)uStackX_20;
        }
    } else {
        puStackX_18 = (undefined *)0x0;
    }
    if ((iVar18 != 0) && (0 < *(int32_t *)(arg1 + 8))) {
        do {
            arg2_00 = (int32_t *)(uVar26 * 0x38 + *(int64_t *)(arg1 + 0x10));
            if (*arg2_00 == iVar18) {
                bVar32 = false;
                goto code_r0x00018014b075;
            }
            uVar25 = (int32_t)uVar26 + 1;
            uVar26 = (uint64_t)uVar25;
        } while ((int32_t)uVar25 < *(int32_t *)(arg1 + 8));
    }
    uStack_108 = 0;
    uStack_100 = 0;
    uStack_f0 = 0;
    uStack_e8 = 0;
    uStack_d8 = 0;
    uStack_f8 = 0xffffffffffffffff;
    Stack_e4 = 0xffbf800000;
    uStack_df = 0xffffffff;
    uStack_db = 0xffff;
    uStack_d9 = 0xff;
    func_0x00018011f0c0(arg1 + 8, &uStack_108);
    bVar32 = true;
    arg2_00 = (int32_t *)(*(int64_t *)(arg1 + 0x10) + -0x38 + (int64_t)*(int32_t *)(arg1 + 8) * 0x38);
    *arg2_00 = iVar18;
    *(undefined *)(arg1 + 0x85) = 1;
code_r0x00018014b075:
    *(int16_t *)(arg1 + 0x8a) = (int16_t)(((int64_t)arg2_00 - *(int64_t *)(arg1 + 0x10)) / 0x38);
    if ((puStackX_18 == (undefined *)0x0) && ((uVar30 & 1) == 0)) {
        uVar28 = 0;
    } else {
        uVar28 = 1;
    }
    func_0x00018014be50(&fStack_130, pcStackX_10, uVar28);
    arg2_00[9] = -0x40800000;
    fVar34 = fStack_130;
    if ((*(uint8_t *)(iVar16 + 0x1f80) & 1) != 0) {
        fVar34 = *(float *)(iVar16 + 0x1f98);
        arg2_00[9] = (int32_t)fVar34;
    }
    if (bVar32) {
        fVar35 = 1.0;
        if (1.0 <= fVar34) {
            fVar35 = fVar34;
        }
        arg2_00[7] = (int32_t)fVar35;
    }
    arg2_00[8] = (int32_t)fVar34;
    iVar6 = *(int16_t *)(arg1 + 0x88);
    *(int16_t *)(arg1 + 0x88) = iVar6 + 1;
    *(int16_t *)(arg2_00 + 0xb) = iVar6;
    iStack_11c = arg2_00[4] + 1;
    uStack_120 = *(uint32_t *)(arg1 + 0x18);
    iStack_118 = *(int32_t *)(iVar16 + 4);
    iVar29 = *(int32_t *)(arg1 + 0x34) + 1;
    if (((uStackX_20 & 1) == 0) || (var_168h._0_1_ = '\x01', (*(uint8_t *)(arg2_00 + 1) & 1) != 0)) {
        var_168h._0_1_ = '\0';
    }
    arg2_00[4] = iStack_118;
    var_13ch._4_4_ = uStackX_20 & 0x200000;
    arg2_00[1] = uStackX_20;
    *(int64_t *)(arg2_00 + 2) = iVar22;
    if (iVar22 == 0) {
        iVar27 = *(int32_t *)(arg1 + 0xa0) + -1;
        if (*(int32_t *)(arg1 + 0xa0) == 0) {
            iVar27 = 0;
        }
        arg2_00[10] = iVar27;
        iVar24 = func_0x000180498cd0(pcStackX_10);
        func_0x0001800f64c0(arg1 + 0xa0, pcStackX_10, pcStackX_10 + iVar24 + 1);
        iVar22 = in_stack_00000028;
    } else {
        arg2_00[10] = -1;
    }
    uVar30 = uStack_128;
    if (var_13ch._4_4_ == 0) {
        if ((((iStack_11c < iStack_118) && ((*(uint8_t *)(arg1 + 0x18) & 2) != 0)) && (*(int32_t *)(arg1 + 0x24) == 0))
           && ((iStack_118 <= iVar29 || (*(int32_t *)(arg1 + 0x20) == 0)))) {
            *(int32_t *)(arg1 + 0x24) = *arg2_00;
        }
        if (((uStackX_20 & 2) != 0) && (*(int32_t *)(arg1 + 0x20) != iVar18)) {
            *(int32_t *)(arg1 + 0x24) = *arg2_00;
        }
    }
    bVar31 = *(int32_t *)(arg1 + 0x2c) == iVar18;
    var_160h._0_4_ = CONCAT31((unkint3)(uStackX_20 >> 8), bVar31);
    if (bVar31) {
        *(undefined *)(arg1 + 0x84) = 1;
    } else if ((((*(int32_t *)(arg1 + 0x20) == 0) && (iVar29 < iStack_118)) && (iVar22 == 0)) &&
              ((*(int32_t *)(arg1 + 8) == 1 && (var_160h._0_4_ = (uint32_t)bVar31, (*(uint8_t *)(arg1 + 0x18) & 2) == 0)
               ))) {
        var_160h._0_4_ = 1;
    }
    if ((iStack_11c < iStack_118) && ((iStack_118 <= iVar29 || (bVar32)))) {
        _var_148h = ZEXT816(0);
        uStack_128 = func_0x00018010b530(var_148h, iVar18, 0, 2);
        if (var_13ch._4_4_ == 0) {
            return (uint64_t)(uint8_t)var_160h;
        }
        goto code_r0x00018014afb2;
    }
    if (*(int32_t *)(arg1 + 0x20) == iVar18) {
        arg2_00[5] = *(int32_t *)(iVar16 + 4);
    }
    var_150h = (float)arg2_00[7];
    uVar3 = *(undefined4 *)(uStack_128 + 0x158);
    var_158h._4_4_ = *(float *)(arg1 + 0x3c) + 0.0;
    uVar4 = *(undefined4 *)(uStack_128 + 0x15c);
    if ((*(uint8_t *)(arg2_00 + 1) & 0xc0) == 0) {
        var_158h._0_4_ = (float)(int32_t)((float)arg2_00[6] - *(float *)(arg1 + 0x5c)) + *(float *)(arg1 + 0x38);
        *(float *)(uStack_128 + 0x158) = (float)var_158h;
        var_150h = var_150h + (float)var_158h;
        *(float *)(uStack_128 + 0x15c) = var_158h._4_4_;
        var_14ch = var_158h._4_4_ + fStack_12c;
        fVar34 = *(float *)(arg1 + 0x6c);
        if ((fVar34 <= (float)var_158h) && (var_150h < *(float *)(arg1 + 0x70) || var_150h == *(float *)(arg1 + 0x70)))
        goto code_r0x00018014b3e0;
        bVar32 = true;
        var_168h._2_1_ = '\x01';
        fStack_130 = *(float *)(arg1 + 0x70);
        if ((fVar34 <= (float)var_158h) && (fVar34 = fStack_130, (float)var_158h <= fStack_130)) {
            fVar34 = (float)var_158h;
        }
        _var_148h = CONCAT44(var_158h._4_4_ - 1.0, fVar34);
        fStack_12c = var_14ch;
        func_0x0001800fc860(var_148h, &fStack_130, 1);
    } else {
        var_158h._0_4_ = (float)arg2_00[6] + *(float *)(arg1 + 0x38);
        *(float *)(uStack_128 + 0x158) = (float)var_158h;
        var_150h = var_150h + (float)var_158h;
        *(float *)(uStack_128 + 0x15c) = var_158h._4_4_;
code_r0x00018014b3e0:
        var_14ch = var_158h._4_4_ + fStack_12c;
        bVar32 = false;
        var_168h._2_1_ = '\0';
    }
    uVar20 = *(undefined4 *)(uVar30 + 0x170);
    uVar5 = *(undefined4 *)(uVar30 + 0x174);
    var_144h._0_4_ = var_14ch - var_158h._4_4_;
    var_148h = (undefined  [4])(var_150h - (float)var_158h);
    func_0x00018010bbf0(var_148h, *(undefined4 *)(iVar16 + 0xde0));
    *(undefined4 *)(uVar30 + 0x170) = uVar20;
    *(undefined4 *)(uVar30 + 0x174) = uVar5;
    cVar17 = func_0x00018010b530(&var_158h, iVar18, 0, 0);
    uVar25 = var_13ch._4_4_;
    if (cVar17 == '\0') {
        if (bVar32) {
            func_0x0001800fc8f0();
        }
        *(undefined4 *)(uVar30 + 0x158) = uVar3;
        *(undefined4 *)(uVar30 + 0x15c) = uVar4;
        return (uint64_t)(uint8_t)var_160h;
    }
    uVar19 = 0x1010;
    if (var_13ch._4_4_ != 0) {
        uVar19 = 0x1020;
    }
    uVar23 = uVar19;
    if (*(char *)(iVar16 + 0x2400) != '\0') {
        cVar17 = func_0x0001800f3aa0(iVar16 + 0x2410);
        uVar23 = uVar19 | 0x200;
        if (cVar17 != '\0') {
            uVar23 = uVar19;
        }
    }
    if ((uStackX_20 & 0x400000) == 0) {
        var_198h = CONCAT44(var_198h._4_4_, uVar23);
        var_168h._3_1_ = func_0x000180139d40(&var_158h, iVar18, (int64_t)&var_168h + 1, acStackX_8, var_198h);
        if ((var_168h._3_1_ != 0) && (uVar25 == 0)) {
            *(int32_t *)(arg1 + 0x24) = *arg2_00;
        }
        if (acStackX_8[0] == '\0') goto code_r0x00018014b4c3;
        if (in_stack_00000028 == 0) goto code_r0x00018014b56d;
        if ((*(int32_t *)(iVar16 + 0x1654) == iVar18) && (*(char *)(iVar16 + 0x1660) != '\0')) {
            *(int64_t *)(iVar16 + 0x1678) = in_stack_00000028;
        }
code_r0x00018014b4d3:
        iVar24 = *(int64_t *)(in_stack_00000028 + 0x4c0);
        if ((((iVar24 == 0) || (*(int64_t *)(iVar24 + 0x18) != 0)) || ((*(uint32_t *)(iVar24 + 0x10) & 0x400) != 0)) ||
           (*(int32_t *)(iVar24 + 0x30) != 1)) goto code_r0x00018014b570;
        bVar32 = true;
    } else {
        var_168h._3_1_ = 0;
        acStackX_8[0] = '\0';
        var_168h._1_1_ = '\0';
code_r0x00018014b4c3:
        if (in_stack_00000028 != 0) goto code_r0x00018014b4d3;
code_r0x00018014b56d:
        iVar24 = 0;
code_r0x00018014b570:
        bVar32 = false;
    }
    iVar22 = *(int64_t *)0x180781f28;
    if (acStackX_8[0] == '\0') goto code_r0x00018014b8e9;
    if (((bVar32) && (*(char *)(*(int64_t *)0x180781f28 + 0x120) != '\0')) &&
       (0.0 <= *(float *)(*(int64_t *)0x180781f28 + 0xbfc))) {
        func_0x0001800faa00();
        iVar22 = *(int64_t *)0x180781f28;
        goto code_r0x00018014b8e9;
    }
    if (((iStack_11c < iStack_118) || (*(char *)(*(int64_t *)0x180781f28 + 0x120) == '\0')) ||
       (*(float *)(*(int64_t *)0x180781f28 + 0xbfc) <
        *(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4)))
    goto code_r0x00018014b8e9;
    fVar34 = 0.0;
    iVar29 = 0;
    if (*(char *)(iVar16 + 0x2400) == '\0') {
        if (((*(uint8_t *)(arg1 + 0x18) & 1) == 0) && (uVar30 = uStack_128, in_stack_00000028 == 0))
        goto code_r0x00018014b8e9;
        if ((0.0 <= *(float *)(iVar16 + 0x104)) || ((float)var_158h <= *(float *)(iVar16 + 0x118))) {
            iVar29 = 0;
            if ((*(float *)(iVar16 + 0x104) <= 0.0) || (fVar35 = *(float *)(iVar16 + 0x118), fVar35 <= var_150h))
            goto code_r0x00018014b679;
            iVar29 = 1;
            fVar34 = var_150h;
        } else {
            iVar29 = -1;
            fVar34 = *(float *)(iVar16 + 0x118);
            fVar35 = (float)var_158h;
        }
        fVar34 = fVar35 - fVar34;
        fcn.18014ad20(arg1, (int64_t)arg2_00, *(int64_t *)(iVar16 + 0x118));
    }
code_r0x00018014b679:
    uVar30 = uStack_128;
    if (((in_stack_00000028 == 0) || ((*(uint8_t *)(in_stack_00000028 + 0x14) & 4) != 0)) ||
       ((*(uint8_t *)(iVar24 + 0x10) & 0x80) != 0)) goto code_r0x00018014b8e9;
    if ((*(char *)(iVar16 + 0x2400) == '\0') || (*(int32_t *)(iVar16 + 0x241c) != iVar18)) {
        fVar35 = *(float *)(iVar16 + 0x12f8);
        fVar33 = ((float)(*(uint32_t *)(iVar16 + 0xbd4) & 0x7fffffff) - (fVar35 + fVar35)) * 0.2;
        if (0.0 <= fVar33) {
            fVar36 = fVar35 * 4.0;
            if (fVar33 <= fVar35 * 4.0) {
                fVar36 = fVar33;
            }
        } else {
            fVar36 = 0.0;
        }
        fVar33 = var_158h._4_4_ - *(float *)(iVar16 + 0x11c);
        fVar37 = *(float *)(iVar16 + 0x11c) - var_14ch;
        if (fVar33 <= fVar37) {
            fVar33 = fVar37;
        }
        if (fVar35 * 2.2 < fVar34) {
            if (iVar29 < 0) {
                iVar24 = (int64_t)arg2_00 - *(int64_t *)(arg1 + 0x10);
                iVar29 = (int32_t)(iVar24 >> 0x3f);
                bVar32 = (int32_t)(iVar24 / 0x38) + iVar29 == iVar29;
            } else {
                if (iVar29 < 1) goto code_r0x00018014b7a0;
                bVar32 = (int32_t)(((int64_t)arg2_00 - *(int64_t *)(arg1 + 0x10)) / 0x38) == *(int32_t *)(arg1 + 8) + -1
                ;
            }
            if (bVar32) goto code_r0x00018014b7a9;
        }
code_r0x00018014b7a0:
        if (fVar33 < fVar35 * 1.5 + fVar36) goto code_r0x00018014b8e9;
    }
code_r0x00018014b7a9:
    piVar1 = (int32_t *)(iVar16 + 0x28f8);
    iVar29 = *(int32_t *)(iVar16 + 0x28fc);
    if (*piVar1 == iVar29) {
        iVar27 = *piVar1 + 1;
        if (iVar29 == 0) {
            iVar29 = 8;
        } else {
            iVar29 = iVar29 / 2 + iVar29;
        }
        if (iVar27 < iVar29) {
            iVar27 = iVar29;
        }
        func_0x00018011fa30(piVar1, iVar27);
    }
    iVar24 = *(int64_t *)(iVar16 + 0x2900);
    iVar22 = (int64_t)*piVar1 * 0x40;
    *(undefined4 *)(iVar22 + iVar24) = 2;
    *(undefined4 *)(iVar22 + 4 + iVar24) = uStack_108._4_4_;
    *(undefined8 *)(iVar22 + 8 + iVar24) = 0;
    *(undefined8 *)(iVar22 + 0x10 + iVar24) = 0;
    *(undefined8 *)(iVar22 + 0x18 + iVar24) = 0;
    *(undefined4 *)(iVar22 + 0x20 + iVar24) = 0xffffffff;
    *(undefined4 *)(iVar22 + 0x24 + iVar24) = 0x3f000000;
    *(undefined *)(iVar22 + 0x28 + iVar24) = 0;
    *(undefined4 *)(iVar22 + 0x29 + iVar24) = uStack_df;
    *(undefined2 *)(iVar22 + 0x2d + iVar24) = uStack_db;
    *(undefined *)(iVar22 + 0x2f + iVar24) = uStack_d9;
    *(int64_t *)(iVar22 + 0x30 + iVar24) = in_stack_00000028;
    *(undefined8 *)(iVar22 + 0x38 + iVar24) = 0;
    *piVar1 = *piVar1 + 1;
    *(int64_t *)(iVar16 + 0x1600) = in_stack_00000028;
    func_0x0001800f9f30(*(undefined4 *)(in_stack_00000028 + 0xc4), in_stack_00000028);
    iVar22 = *(int64_t *)0x180781f28;
    fVar34 = *(float *)(*(int64_t *)(iVar16 + 0x1600) + 0x60);
    fVar35 = *(float *)(*(int64_t *)(iVar16 + 0x1600) + 100);
    *(undefined *)(iVar16 + 0x1662) = 1;
    *(float *)(iVar16 + 0x166c) = *(float *)(iVar16 + 0x166c) - (fVar34 - (float)var_158h);
    *(float *)(iVar16 + 0x1670) = *(float *)(iVar16 + 0x1670) - (fVar35 - var_158h._4_4_);
    *(undefined4 *)(iVar22 + 0x1f68) = 0xf;
    *(undefined *)(iVar22 + 0x1f6c) = 1;
    *(bool *)(iVar22 + 0x2239) = *(char *)(iVar22 + 0x223a) != '\0';
    *(undefined2 *)(iVar22 + 0x2278) = 0;
    uVar30 = uStack_128;
code_r0x00018014b8e9:
    uVar25 = uStackX_20;
    if (((*(uint32_t *)(iVar16 + 0x1fc0) & 0x100) != 0) && ((uStackX_20 >> 0x16 & 1) == 0)) {
        iVar24 = *(int64_t *)(uVar30 + 800);
        uStack_120 = uStack_120 & 0x200000;
        if ((acStackX_8[0] == '\0') && (var_168h._1_1_ == '\0')) {
            if ((uint8_t)var_160h == '\0') {
                iVar21 = 0x26;
                if (uStack_120 != 0) {
                    iVar21 = 0x23;
                }
            } else {
                iVar21 = 0x27;
                if (uStack_120 != 0) {
                    iVar21 = 0x24;
                }
            }
        } else {
            iVar21 = 0x22;
        }
        pauVar2 = (undefined (*) [12])(iVar22 + 0xd90 + (iVar21 + 0x14) * 0x10);
        var_13ch._0_4_ = *(float *)pauVar2[1] * *(float *)(iVar22 + 0xd9c);
        _var_148h = *pauVar2;
        uVar20 = fcn.1800f5fa0(var_148h);
        func_0x00018014bf10(iVar24, &var_158h, uVar25, uVar20);
        if ((((uint8_t)var_160h != '\0') && ((*(uint8_t *)(arg1 + 0x18) & 0x40) != 0)) &&
           (fVar34 = *(float *)(iVar16 + 0xe50), 0.0 < fVar34)) {
            fVar35 = (float)var_158h + 0.0;
            iVar22 = 0x3c0;
            if (uStack_120 != 0) {
                iVar22 = 0x390;
            }
            fVar37 = var_158h._4_4_ + *(float *)(iVar16 + 0x1308);
            fVar36 = var_150h + 0.0;
            pauVar2 = (undefined (*) [12])(iVar22 + 0xd90 + *(int64_t *)0x180781f28);
            var_13ch._0_4_ = *(float *)pauVar2[1] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            _var_148h = *pauVar2;
            uVar20 = fcn.1800f5fa0(var_148h);
            fVar33 = *(float *)(iVar16 + 0xe34);
            if (fVar33 <= 0.0) {
                fStack_12c = fVar37 - 0.5;
                var_198h = CONCAT44(var_198h._4_4_, fVar34);
                fStack_130 = fVar35 - 0.5;
                var_144h._0_4_ = fStack_12c;
                var_148h = (undefined  [4])(fVar36 - 0.5);
                func_0x000180126300(iVar24, &fStack_130, var_148h, uVar20, var_198h);
                uVar25 = uStackX_20;
            } else {
                fVar35 = fVar35 + fVar33;
                fVar37 = fVar33 + fVar37;
                var_144h._0_4_ = fVar37;
                var_148h = (undefined  [4])fVar35;
                if (0.5 <= fVar33) {
                    var_198h = CONCAT44(var_198h._4_4_, 0x24);
                    func_0x0001801257a0(iVar24, var_148h, fVar33, 0x1c, var_198h);
                } else {
                    iVar29 = *(int32_t *)(iVar24 + 0x54);
                    if (*(int32_t *)(iVar24 + 0x50) == iVar29) {
                        iVar27 = *(int32_t *)(iVar24 + 0x50) + 1;
                        if (iVar29 == 0) {
                            iVar29 = 8;
                        } else {
                            iVar29 = iVar29 / 2 + iVar29;
                        }
                        if (iVar27 < iVar29) {
                            iVar27 = iVar29;
                        }
                        func_0x00018011f4f0(iVar24 + 0x50, iVar27);
                    }
                    iVar29 = *(int32_t *)(iVar24 + 0x50);
                    iVar22 = *(int64_t *)(iVar24 + 0x58);
                    *(float *)(iVar22 + (int64_t)iVar29 * 8) = fVar35;
                    *(float *)(iVar22 + 4 + (int64_t)iVar29 * 8) = fVar37;
                    *(int32_t *)(iVar24 + 0x50) = *(int32_t *)(iVar24 + 0x50) + 1;
                }
                fVar36 = fVar36 - fVar33;
                var_148h = (undefined  [4])fVar36;
                if (0.5 <= fVar33) {
                    var_198h = CONCAT44(var_198h._4_4_, 0x2c);
                    func_0x0001801257a0(iVar24, var_148h, fVar33, 0x24, var_198h);
                } else {
                    iVar29 = *(int32_t *)(iVar24 + 0x54);
                    if (*(int32_t *)(iVar24 + 0x50) == iVar29) {
                        iVar27 = *(int32_t *)(iVar24 + 0x50) + 1;
                        if (iVar29 == 0) {
                            iVar29 = 8;
                        } else {
                            iVar29 = iVar29 / 2 + iVar29;
                        }
                        if (iVar27 < iVar29) {
                            iVar27 = iVar29;
                        }
                        func_0x00018011f4f0(iVar24 + 0x50, iVar27);
                    }
                    iVar29 = *(int32_t *)(iVar24 + 0x50);
                    iVar22 = *(int64_t *)(iVar24 + 0x58);
                    *(float *)(iVar22 + (int64_t)iVar29 * 8) = fVar36;
                    *(float *)(iVar22 + 4 + (int64_t)iVar29 * 8) = fVar37;
                    *(int32_t *)(iVar24 + 0x50) = *(int32_t *)(iVar24 + 0x50) + 1;
                }
                var_198h = var_198h & 0xffffffff00000000;
                func_0x0001801248e0(iVar24, *(undefined8 *)(iVar24 + 0x58), *(undefined4 *)(iVar24 + 0x50), uVar20, 
                                    var_198h, *(undefined4 *)(iVar16 + 0xe50));
                *(undefined4 *)(iVar24 + 0x50) = 0;
                uVar25 = uStackX_20;
            }
        }
        func_0x0001800f7d00(&var_158h, iVar18, 0);
        cVar17 = func_0x0001800fa150(0x20);
        iVar29 = *arg2_00;
        if ((((*(int32_t *)(arg1 + 0x20) != iVar29) && (cVar17 != '\0')) &&
            ((cVar17 = func_0x000180107ff0(1, 0, 0), cVar17 != '\0' || (cVar17 = func_0x000180108070(1), cVar17 != '\0')
             ))) && (var_13ch._4_4_ == 0)) {
            *(int32_t *)(arg1 + 0x24) = iVar29;
        }
        if ((*(uint8_t *)(arg1 + 0x18) & 8) != 0) {
            uStackX_20 = uVar25 | 4;
        }
        if (puStackX_18 == (undefined *)0x0) {
            iVar29 = 0;
        } else {
            iVar29 = iVar18;
            if (in_stack_00000028 != 0) {
                iVar29 = *(int32_t *)(in_stack_00000028 + 0x10);
            }
            iVar29 = fcn.1800f5a90(0x1806445a0, 0, iVar29);
        }
        uVar25 = uStackX_20;
        if ((char)var_168h != '\0') {
            uVar25 = uStackX_20 & 0xfffffffe;
        }
        func_0x00018014c270(iVar24, &var_158h, uVar25, *(undefined8 *)(arg1 + 0x90), pcStackX_10, iVar18, iVar29, 
                            (char)(uint32_t)var_160h, &var_168h, (int64_t)&var_168h + 4);
        if (((char)var_168h != '\0') && (puStackX_18 != (undefined *)0x0)) {
            *puStackX_18 = 0;
            if (((uint32_t)arg2_00[1] >> 0x15 & 1) == 0) {
                iVar27 = *arg2_00;
                if ((arg2_00[1] & 0x101U) == 0) {
                    *(undefined *)(arg2_00 + 0xc) = 1;
                    if (*(int32_t *)(arg1 + 0x2c) == iVar27) {
                        arg2_00[4] = -1;
                        *(undefined8 *)(arg1 + 0x20) = 0;
                    }
                } else if (*(int32_t *)(arg1 + 0x2c) != iVar27) {
                    *(int32_t *)(arg1 + 0x24) = iVar27;
                }
            }
        }
        if ((in_stack_00000028 != 0) && ((var_168h._1_1_ != '\0' || (*(int32_t *)(iVar16 + 0x163c) == iVar29)))) {
            *(uint32_t *)(iVar16 + 0x1fc0) = *(uint32_t *)(iVar16 + 0x1fc0) | 0x80;
        }
        if ((((var_168h._4_1_ != '\0') && (*(int32_t *)(iVar16 + 0x163c) == iVar18)) && (acStackX_8[0] == '\0')) &&
           (((*(uint8_t *)(arg1 + 0x18) & 0x20) == 0 && (pcVar15 = pcStackX_10, (*(uint8_t *)(arg2_00 + 1) & 0x10) == 0)
            ))) {
            for (; ((pcVar15 != (char *)0xffffffffffffffff && (*pcVar15 != '\0')) &&
                   ((*pcVar15 != '#' || (pcVar15[1] != '#')))); pcVar15 = pcVar15 + 1) {
            }
            func_0x00018010ceb0(0x180641920, (int32_t)pcVar15 - (int32_t)pcStackX_10, pcStackX_10);
        }
    }
    if (var_168h._2_1_ != '\0') {
        func_0x0001800fc8f0();
    }
    *(undefined4 *)(uStack_128 + 0x158) = uVar3;
    *(undefined4 *)(uStack_128 + 0x15c) = uVar4;
    if (var_13ch._4_4_ == 0) {
        return (uint64_t)(uint8_t)var_160h;
    }
    return (uint64_t)var_168h._3_1_;
}

// ============================================================
// Function: FUN_18014be50
// Address: 0x18014be50
// Size: 187 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

int64_t fcn.18014be50(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    char in_R8B;
    float fVar3;
    float fVar4;
    float fVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_000000d0;
    undefined4 in_stack_ffffffffffffffec;
    
    iVar1 = *(int64_t *)0x180781f28;
    fcn.1800fe0a0(CONCAT44(in_stack_ffffffffffffffec, 0xbf800000), in_stack_000000d0);
    iVar2 = *(int64_t *)0x180781f28;
    fVar5 = *(float *)(iVar1 + 0xddc);
    if (in_R8B == '\0') {
        fVar3 = 1.0;
    } else {
        fVar3 = *(float *)(iVar1 + 0x12f8) + *(float *)(iVar1 + 0xdf4);
    }
    *(float *)(arg1 + 4) = *(float *)(iVar1 + 0xde0) + *(float *)(iVar1 + 0xde0) + var_8h._4_4_;
    fVar4 = *(float *)(iVar2 + 0x12f8) * 20.0;
    fVar5 = fVar5 + fVar3 + fVar5 + (float)var_8h;
    if (fVar4 <= fVar5) {
        fVar5 = fVar4;
    }
    *(float *)arg1 = fVar5;
    return arg1;
}

// ============================================================
// Function: FUN_18014bf10
// Address: 0x18014bf10
// Size: 855 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_a8h
// WARNING: Variable defined which should be unmapped: var_a0h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Removing arg arg_67h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6bh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_2dh

void fcn.18014bf10(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    float fVar1;
    int64_t iVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fStackX_8;
    float fStackX_c;
    int64_t var_a8h;
    int64_t var_a0h;
    undefined4 uStack_98;
    undefined4 uStack_94;
    undefined4 uStack_90;
    float fStack_8c;
    int64_t var_88h;
    int64_t var_39h;
    int64_t var_28h;
    
    iVar2 = *(int64_t *)0x180781f28;
    iVar3 = *(int32_t *)(arg1 + 0x54);
    iVar7 = 8;
    fVar10 = *(float *)arg2;
    fVar11 = *(float *)(arg2 + 0xc) - *(float *)(*(int64_t *)0x180781f28 + 0xe4c);
    fVar1 = *(float *)(arg2 + 4);
    iVar5 = 0xde4;
    if (((uint32_t)arg3 >> 0x15 & 1) == 0) {
        iVar5 = 0xe34;
    }
    fVar9 = (*(float *)(arg2 + 8) - fVar10) * 0.5 - 1.0;
    fVar8 = *(float *)(iVar5 + *(int64_t *)0x180781f28);
    if (fVar9 <= *(float *)(iVar5 + *(int64_t *)0x180781f28)) {
        fVar8 = fVar9;
    }
    fVar9 = 0.0;
    if (0.0 <= fVar8) {
        fVar9 = fVar8;
    }
    if (*(int32_t *)(arg1 + 0x50) == iVar3) {
        iVar6 = *(int32_t *)(arg1 + 0x50) + 1;
        if (iVar3 == 0) {
            iVar3 = 8;
        } else {
            iVar3 = iVar3 / 2 + iVar3;
        }
        if (iVar6 < iVar3) {
            iVar6 = iVar3;
        }
        func_0x00018011f4f0(arg1 + 0x50, iVar6);
    }
    iVar3 = *(int32_t *)(arg1 + 0x50);
    iVar5 = *(int64_t *)(arg1 + 0x58);
    *(float *)(iVar5 + (int64_t)iVar3 * 8) = fVar10;
    *(float *)(iVar5 + 4 + (int64_t)iVar3 * 8) = fVar11;
    fVar10 = fVar9 + fVar1 + 1.0;
    *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
    fStackX_8 = fVar9 + *(float *)arg2;
    fStackX_c = fVar10;
    if (0.5 <= fVar9) {
        func_0x0001801257a0(arg1, &fStackX_8, fVar9, 0x18, 0x24);
    } else {
        func_0x00018011f490(arg1 + 0x50);
    }
    fStackX_8 = *(float *)(arg2 + 8) - fVar9;
    if (0.5 <= fVar9) {
        fStackX_c = fVar10;
        func_0x0001801257a0(arg1, &fStackX_8, fVar9, 0x24, 0x30);
    } else {
        fStackX_c = fVar10;
        func_0x00018011f490(arg1 + 0x50);
    }
    iVar3 = *(int32_t *)(arg1 + 0x54);
    uVar4 = *(undefined4 *)(arg2 + 8);
    if (*(int32_t *)(arg1 + 0x50) == iVar3) {
        iVar6 = *(int32_t *)(arg1 + 0x50) + 1;
        if (iVar3 != 0) {
            iVar7 = iVar3 + iVar3 / 2;
        }
        if (iVar6 < iVar7) {
            iVar6 = iVar7;
        }
        func_0x00018011f4f0(arg1 + 0x50, iVar6);
    }
    iVar7 = *(int32_t *)(arg1 + 0x50);
    iVar5 = *(int64_t *)(arg1 + 0x58);
    *(undefined4 *)(iVar5 + (int64_t)iVar7 * 8) = uVar4;
    *(float *)(iVar5 + 4 + (int64_t)iVar7 * 8) = fVar11;
    *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + 1;
    func_0x0001800f3bc0(arg1, arg4 & 0xffffffff);
    if (0.0 < *(float *)(iVar2 + 0xe38)) {
        fStackX_8 = *(float *)arg2 + 0.5;
        fStackX_c = fVar11;
        func_0x0001800f3b50(arg1, &fStackX_8);
        fVar10 = fVar10 + 0.5;
        fStackX_8 = fVar9 + *(float *)arg2 + 0.5;
        fStackX_c = fVar10;
        if (0.5 <= fVar9) {
            func_0x0001801257a0(arg1, &fStackX_8, fVar9, 0x18, 0x24);
        } else {
            func_0x00018011f490(arg1 + 0x50);
        }
        fStackX_8 = (*(float *)(arg2 + 8) - fVar9) - 0.5;
        if (0.5 <= fVar9) {
            fStackX_c = fVar10;
            func_0x0001801257a0(arg1, &fStackX_8, fVar9, 0x24, 0x30);
        } else {
            fStackX_c = fVar10;
            func_0x00018011f490(arg1 + 0x50);
        }
        fStackX_8 = *(float *)(arg2 + 8) - 0.5;
        fStackX_c = fVar11;
        func_0x0001800f3b50(arg1, &fStackX_8);
        uStack_98 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf20);
        uStack_94 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf24);
        uStack_90 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf28);
        fStack_8c = *(float *)(*(int64_t *)0x180781f28 + 0xf2c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar4 = fcn.1800f5fa0(&uStack_98);
        func_0x0001801248e0(arg1, *(undefined8 *)(arg1 + 0x58), *(undefined4 *)(arg1 + 0x50), uVar4, 0, 
                            *(undefined4 *)(iVar2 + 0xe38));
        *(undefined4 *)(arg1 + 0x50) = 0;
    }
    return;
}

