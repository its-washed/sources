// Chunk 107 - 50 functions

// ============================================================
// Function: FUN_1801746a0
// Address: 0x1801746a0
// Size: 239 bytes
// ============================================================
int64_t fcn.1801746a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t var_8h;
    int64_t var_58h;
    
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    iVar3 = func_0x000180498cd0(arg4);
    iVar4 = func_0x000180498cd0(arg2);
    piVar1 = (int64_t *)(arg3 + 0x10);
    piVar2 = (int64_t *)(arg_28h + 0x10);
    func_0x00018000b240(arg1, *piVar1 + iVar4 + iVar3 + *piVar2);
    uVar5 = func_0x000180498cd0(arg2);
    func_0x00018000d970(arg1, arg2, uVar5);
    if (0xf < *(uint64_t *)(arg3 + 0x18)) {
        arg3 = *(int64_t *)arg3;
    }
    func_0x00018000d970(arg1, arg3, *piVar1);
    uVar5 = func_0x000180498cd0(arg4);
    func_0x00018000d970(arg1, arg4, uVar5);
    if (0xf < *(uint64_t *)(arg_28h + 0x18)) {
        arg_28h = *(int64_t *)arg_28h;
    }
    func_0x00018000d970(arg1, arg_28h, *piVar2);
    return arg1;
}

// ============================================================
// Function: FUN_180174790
// Address: 0x180174790
// Size: 143 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

int64_t fcn.180174790(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t unaff_RSI;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_38h;
    
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    fcn.180498cd0(arg2);
    fcn.18000b240(unaff_RDI);
    fcn.180498cd0(arg2);
    fcn.18000d970(unaff_RSI);
    fcn.18000d970(unaff_RSI);
    return arg1;
}

// ============================================================
// Function: FUN_180174820
// Address: 0x180174820
// Size: 202 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

int64_t fcn.180174820(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t unaff_RDI;
    int64_t unaff_R12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_38h;
    
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    fcn.18000b240(unaff_R12);
    fcn.18000d970(unaff_RDI);
    fcn.18000d970(unaff_RDI);
    fcn.18000d970(unaff_RDI);
    return arg1;
}

// ============================================================
// Function: FUN_1801748f0
// Address: 0x1801748f0
// Size: 557 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_99h
// WARNING: [rz-ghidra] Detected overlap for variable var_95h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h

void fcn.1801748f0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int64_t iVar2;
    undefined auVar3 [16];
    int64_t iVar4;
    uint64_t uVar5;
    undefined *puVar6;
    int64_t var_20h;
    undefined8 uStack_d0;
    undefined auStack_c8 [8];
    undefined auStack_c0 [32];
    int64_t var_a0h;
    undefined8 var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_28h;
    uint64_t uStack_20;
    
    puVar6 = auStack_c8;
    uStack_20 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_c8;
    var_90h = 0xb;
    var_88h = 0xf;
    _var_a0h = ZEXT816(0x72655f726568746f);
    stack0xffffffffffffff67 = 0x726f7272;
    var_98h._3_5_ = 0;
    var_70h = 0;
    var_68h = 0xf;
    stack0xffffffffffffff81 = SUB1615(ZEXT816(0), 1);
    auVar3[15] = 0;
    auVar3._0_15_ = stack0xffffffffffffff81;
    _var_80h = auVar3 << 8;
    iVar4 = func_0x00018017b260(&var_60h, &var_a0h, arg2 & 0xffffffff);
    fcn.180174820((int64_t)&var_40h, iVar4, (int64_t)&var_80h, arg3);
    if (0xf < (uint64_t)var_48h) {
        iVar2 = CONCAT71(var_60h._1_7_, (undefined)var_60h);
        iVar4 = iVar2;
        puVar6 = auStack_c8;
        if ((0xfff < var_48h + 1U) &&
           (iVar4 = *(int64_t *)(iVar2 + -8), puVar6 = auStack_c8, 0x1f < (iVar2 - iVar4) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar4 = (*pcVar1)(5);
            puVar6 = auStack_c0;
        }
        *(undefined8 *)(puVar6 + -8) = 0x1801749cf;
        func_0x000180459c3c(iVar4);
    }
    var_50h = 0;
    var_48h = 0xf;
    var_60h._0_1_ = 0;
    if (0xf < (uint64_t)var_68h) {
        iVar4 = var_80h;
        if ((0xfff < var_68h + 1U) && (iVar4 = *(int64_t *)(var_80h + -8), 0x1f < (var_80h - iVar4) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar4 = (*pcVar1)(5);
            puVar6 = puVar6 + 8;
        }
        *(undefined8 *)(puVar6 + -8) = 0x180174a23;
        func_0x000180459c3c(iVar4);
    }
    if ((uint64_t)var_88h < 0x10) {
code_r0x000180174a61:
        var_a0h = (int64_t)&var_40h;
        if (0xf < (uint64_t)var_28h) {
            var_a0h = var_40h;
        }
        *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
        *(undefined8 *)arg1 = 0x1804a5b48;
        *(int32_t *)(arg1 + 0x18) = (int32_t)arg2;
        *(undefined8 *)(arg1 + 0x20) = 0x1804a5358;
        *(undefined (*) [16])(arg1 + 0x28) = ZEXT816(0);
        var_98h._0_1_ = 1;
        *(undefined8 *)(puVar6 + -8) = 0x180174aa6;
        func_0x00018045b4e4(&var_a0h);
        *(undefined8 *)(arg1 + 0x20) = 0x1804a53a0;
        *(undefined8 *)arg1 = 0x1804a5b90;
        if ((uint64_t)var_28h < 0x10) goto code_r0x000180174afb;
        if ((0xfff < var_28h + 1U) &&
           (iVar4 = var_40h - *(int64_t *)(var_40h + -8), var_40h = *(int64_t *)(var_40h + -8), 0x1f < iVar4 - 8U))
        goto code_r0x000180174aec;
    } else {
        uVar5 = var_88h + 1;
        iVar4 = var_a0h;
        if (uVar5 < 0x1000) {
code_r0x000180174a5c:
            *(undefined8 *)(puVar6 + -8) = 0x180174a61;
            func_0x000180459c3c(iVar4, uVar5);
            goto code_r0x000180174a61;
        }
        if ((var_a0h - *(int64_t *)(var_a0h + -8)) - 8U < 0x20) {
            uVar5 = var_88h + 0x28;
            iVar4 = *(int64_t *)(var_a0h + -8);
            goto code_r0x000180174a5c;
        }
code_r0x000180174aec:
        pcVar1 = (code *)swi(0x29);
        var_40h = (*pcVar1)(5);
        puVar6 = puVar6 + 8;
    }
    *(undefined8 *)(puVar6 + -8) = 0x180174afb;
    func_0x000180459c3c(var_40h);
code_r0x000180174afb:
    *(undefined8 *)(puVar6 + -8) = 0x180174b0a;
    func_0x000180459870(uStack_20 ^ (uint64_t)puVar6);
    return;
}

// ============================================================
// Function: FUN_180174b20
// Address: 0x180174b20
// Size: 559 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_96h

void fcn.180174b20(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int64_t iVar2;
    undefined auVar3 [16];
    int64_t iVar4;
    uint64_t uVar5;
    undefined *puVar6;
    int64_t var_20h;
    undefined8 uStack_d0;
    undefined auStack_c8 [8];
    undefined auStack_c0 [32];
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_28h;
    uint64_t uStack_20;
    
    puVar6 = auStack_c8;
    uStack_20 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_c8;
    var_90h = 10;
    var_88h = 0xf;
    var_98h._0_2_ = 0x726f;
    var_a0h = 0x7272655f65707974;
    var_98h._2_6_ = 0;
    var_70h = 0;
    var_68h = 0xf;
    stack0xffffffffffffff81 = SUB1615(ZEXT816(0), 1);
    auVar3[15] = 0;
    auVar3._0_15_ = stack0xffffffffffffff81;
    _var_80h = auVar3 << 8;
    iVar4 = func_0x00018017b260(&var_60h, &var_a0h, arg2 & 0xffffffff);
    fcn.180174820((int64_t)&var_40h, iVar4, (int64_t)&var_80h, arg3);
    if (0xf < (uint64_t)var_48h) {
        iVar2 = CONCAT71(var_60h._1_7_, (undefined)var_60h);
        iVar4 = iVar2;
        puVar6 = auStack_c8;
        if ((0xfff < var_48h + 1U) &&
           (iVar4 = *(int64_t *)(iVar2 + -8), puVar6 = auStack_c8, 0x1f < (iVar2 - iVar4) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar4 = (*pcVar1)(5);
            puVar6 = auStack_c0;
        }
        *(undefined8 *)(puVar6 + -8) = 0x180174c01;
        func_0x000180459c3c(iVar4);
    }
    var_50h = 0;
    var_48h = 0xf;
    var_60h._0_1_ = 0;
    if (0xf < (uint64_t)var_68h) {
        iVar4 = var_80h;
        if ((0xfff < var_68h + 1U) && (iVar4 = *(int64_t *)(var_80h + -8), 0x1f < (var_80h - iVar4) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar4 = (*pcVar1)(5);
            puVar6 = puVar6 + 8;
        }
        *(undefined8 *)(puVar6 + -8) = 0x180174c55;
        func_0x000180459c3c(iVar4);
    }
    if ((uint64_t)var_88h < 0x10) {
code_r0x000180174c93:
        var_a0h = (int64_t)&var_40h;
        if (0xf < (uint64_t)var_28h) {
            var_a0h = var_40h;
        }
        *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
        *(undefined8 *)arg1 = 0x1804a5b48;
        *(int32_t *)(arg1 + 0x18) = (int32_t)arg2;
        *(undefined8 *)(arg1 + 0x20) = 0x1804a5358;
        *(undefined (*) [16])(arg1 + 0x28) = ZEXT816(0);
        var_98h._0_1_ = 1;
        *(undefined8 *)(puVar6 + -8) = 0x180174cd8;
        func_0x00018045b4e4(&var_a0h);
        *(undefined8 *)(arg1 + 0x20) = 0x1804a53a0;
        *(undefined8 *)arg1 = 0x1804a5b78;
        if ((uint64_t)var_28h < 0x10) goto code_r0x000180174d2d;
        if ((0xfff < var_28h + 1U) &&
           (iVar4 = var_40h - *(int64_t *)(var_40h + -8), var_40h = *(int64_t *)(var_40h + -8), 0x1f < iVar4 - 8U))
        goto code_r0x000180174d1e;
    } else {
        uVar5 = var_88h + 1;
        iVar4 = var_a0h;
        if (uVar5 < 0x1000) {
code_r0x000180174c8e:
            *(undefined8 *)(puVar6 + -8) = 0x180174c93;
            func_0x000180459c3c(iVar4, uVar5);
            goto code_r0x000180174c93;
        }
        if ((var_a0h - *(int64_t *)(var_a0h + -8)) - 8U < 0x20) {
            uVar5 = var_88h + 0x28;
            iVar4 = *(int64_t *)(var_a0h + -8);
            goto code_r0x000180174c8e;
        }
code_r0x000180174d1e:
        pcVar1 = (code *)swi(0x29);
        var_40h = (*pcVar1)(5);
        puVar6 = puVar6 + 8;
    }
    *(undefined8 *)(puVar6 + -8) = 0x180174d2d;
    func_0x000180459c3c(var_40h);
code_r0x000180174d2d:
    *(undefined8 *)(puVar6 + -8) = 0x180174d3c;
    func_0x000180459870(uStack_20 ^ (uint64_t)puVar6);
    return;
}

// ============================================================
// Function: FUN_180174d50
// Address: 0x180174d50
// Size: 82 bytes
// ============================================================
int64_t * fcn.180174d50(void)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_10h;
    
    piVar1 = (int64_t *)fcn.180459890(0x10);
    *piVar1 = 0;
    piVar1[1] = 0;
    iVar2 = fcn.180459890(0x50);
    *(int64_t *)iVar2 = iVar2;
    *(int64_t *)(iVar2 + 8) = iVar2;
    *(int64_t *)(iVar2 + 0x10) = iVar2;
    *(undefined2 *)(iVar2 + 0x18) = 0x101;
    *piVar1 = iVar2;
    return piVar1;
}

// ============================================================
// Function: FUN_180174db0
// Address: 0x180174db0
// Size: 149 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180174db0(int64_t arg1)
{
    undefined auVar1 [16];
    undefined *puVar2;
    uint8_t in_DL;
    int64_t iVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    if (in_DL != 0) {
        uVar5 = (uint64_t)in_DL;
        uVar4 = 1;
        if (9 < uVar5) {
            if (uVar5 < 100) {
                uVar4 = 2;
            } else if (uVar5 < 1000) {
                uVar4 = 3;
            } else if (uVar5 < 10000) {
                uVar4 = 4;
            } else {
                uVar4 = 5;
            }
        }
        puVar2 = (undefined *)(arg1 + 0x10 + (uint64_t)uVar4);
        while (99 < uVar5) {
            auVar1._8_8_ = 0;
            auVar1._0_8_ = uVar5;
            iVar3 = SUB168(ZEXT816(0x47ae147ae147ae15) * auVar1, 8);
            uVar6 = (uVar5 - iVar3 >> 1) + iVar3 >> 6;
            iVar3 = (uVar5 + uVar6 * -100 & 0xffffffff) * 2;
            puVar2[-1] = *(undefined *)(iVar3 + 0x1804a6581);
            puVar2 = puVar2 + -2;
            *puVar2 = *(undefined *)(iVar3 + 0x1804a6580);
            uVar5 = uVar6;
        }
        if (uVar5 < 10) {
            puVar2[-1] = (char)uVar5 + '0';
        } else {
            iVar3 = (uVar5 & 0xffffffff) * 2;
            puVar2[-1] = *(undefined *)(iVar3 + 0x1804a6581);
            puVar2[-2] = *(undefined *)(iVar3 + 0x1804a6580);
        }
    // WARNING: Could not recover jumptable at 0x000180174ee2. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, arg1 + 0x10, (uint64_t)uVar4);
        return;
    }
    // WARNING: Could not recover jumptable at 0x000180174dc7. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x30);
    return;
}

// ============================================================
// Function: FUN_180174e45
// Address: 0x180174e45
// Size: 92 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180174db0(int64_t arg1)
{
    undefined auVar1 [16];
    undefined *puVar2;
    uint8_t in_DL;
    int64_t iVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    if (in_DL != 0) {
        uVar5 = (uint64_t)in_DL;
        uVar4 = 1;
        if (9 < uVar5) {
            if (uVar5 < 100) {
                uVar4 = 2;
            } else if (uVar5 < 1000) {
                uVar4 = 3;
            } else if (uVar5 < 10000) {
                uVar4 = 4;
            } else {
                uVar4 = 5;
            }
        }
        puVar2 = (undefined *)(arg1 + 0x10 + (uint64_t)uVar4);
        while (99 < uVar5) {
            auVar1._8_8_ = 0;
            auVar1._0_8_ = uVar5;
            iVar3 = SUB168(ZEXT816(0x47ae147ae147ae15) * auVar1, 8);
            uVar6 = (uVar5 - iVar3 >> 1) + iVar3 >> 6;
            iVar3 = (uVar5 + uVar6 * -100 & 0xffffffff) * 2;
            puVar2[-1] = *(undefined *)(iVar3 + 0x1804a6581);
            puVar2 = puVar2 + -2;
            *puVar2 = *(undefined *)(iVar3 + 0x1804a6580);
            uVar5 = uVar6;
        }
        if (uVar5 < 10) {
            puVar2[-1] = (char)uVar5 + '0';
        } else {
            iVar3 = (uVar5 & 0xffffffff) * 2;
            puVar2[-1] = *(undefined *)(iVar3 + 0x1804a6581);
            puVar2[-2] = *(undefined *)(iVar3 + 0x1804a6580);
        }
    // WARNING: Could not recover jumptable at 0x000180174ee2. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, arg1 + 0x10, (uint64_t)uVar4);
        return;
    }
    // WARNING: Could not recover jumptable at 0x000180174dc7. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x30);
    return;
}

// ============================================================
// Function: FUN_180174ea1
// Address: 0x180174ea1
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180174db0(int64_t arg1)
{
    undefined auVar1 [16];
    undefined *puVar2;
    uint8_t in_DL;
    int64_t iVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    if (in_DL != 0) {
        uVar5 = (uint64_t)in_DL;
        uVar4 = 1;
        if (9 < uVar5) {
            if (uVar5 < 100) {
                uVar4 = 2;
            } else if (uVar5 < 1000) {
                uVar4 = 3;
            } else if (uVar5 < 10000) {
                uVar4 = 4;
            } else {
                uVar4 = 5;
            }
        }
        puVar2 = (undefined *)(arg1 + 0x10 + (uint64_t)uVar4);
        while (99 < uVar5) {
            auVar1._8_8_ = 0;
            auVar1._0_8_ = uVar5;
            iVar3 = SUB168(ZEXT816(0x47ae147ae147ae15) * auVar1, 8);
            uVar6 = (uVar5 - iVar3 >> 1) + iVar3 >> 6;
            iVar3 = (uVar5 + uVar6 * -100 & 0xffffffff) * 2;
            puVar2[-1] = *(undefined *)(iVar3 + 0x1804a6581);
            puVar2 = puVar2 + -2;
            *puVar2 = *(undefined *)(iVar3 + 0x1804a6580);
            uVar5 = uVar6;
        }
        if (uVar5 < 10) {
            puVar2[-1] = (char)uVar5 + '0';
        } else {
            iVar3 = (uVar5 & 0xffffffff) * 2;
            puVar2[-1] = *(undefined *)(iVar3 + 0x1804a6581);
            puVar2[-2] = *(undefined *)(iVar3 + 0x1804a6580);
        }
    // WARNING: Could not recover jumptable at 0x000180174ee2. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, arg1 + 0x10, (uint64_t)uVar4);
        return;
    }
    // WARNING: Could not recover jumptable at 0x000180174dc7. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x30);
    return;
}

// ============================================================
// Function: FUN_180174ef0
// Address: 0x180174ef0
// Size: 174 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180174ef0(int64_t arg1, int64_t arg2)
{
    undefined auVar1 [16];
    undefined *puVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    if (arg2 == 0) {
    // WARNING: Could not recover jumptable at 0x000180174f08. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x30);
        return;
    }
    uVar5 = 1;
    if (arg2 < 0) {
        *(undefined *)(arg1 + 0x10) = 0x2d;
        arg2 = -arg2;
        for (uVar3 = arg2; 9 < uVar3; uVar3 = uVar3 / 10000) {
            if (uVar3 < 100) {
                uVar5 = uVar5 + 1;
                break;
            }
            if (uVar3 < 1000) {
                uVar5 = uVar5 + 2;
                break;
            }
            if (uVar3 < 10000) {
                uVar5 = uVar5 + 3;
                break;
            }
            uVar5 = uVar5 + 4;
        }
code_r0x000180174f88:
        uVar5 = uVar5 + 1;
    } else {
        uVar3 = arg2;
        if (9 < (uint64_t)arg2) {
            do {
                if (uVar3 < 100) goto code_r0x000180174f88;
                if (uVar3 < 1000) {
                    uVar5 = uVar5 + 2;
                    break;
                }
                if (uVar3 < 10000) {
                    uVar5 = uVar5 + 3;
                    break;
                }
                uVar5 = uVar5 + 4;
                uVar3 = uVar3 / 10000;
            } while (9 < uVar3);
        }
    }
    puVar2 = (undefined *)(arg1 + 0x10 + (uint64_t)uVar5);
    while (99 < (uint64_t)arg2) {
        auVar1._8_8_ = 0;
        auVar1._0_8_ = arg2;
        iVar4 = SUB168(ZEXT816(0x47ae147ae147ae15) * auVar1, 8);
        uVar3 = ((uint64_t)(arg2 - iVar4) >> 1) + iVar4 >> 6;
        iVar4 = (arg2 + uVar3 * -100 & 0xffffffff) * 2;
        puVar2[-1] = *(undefined *)(iVar4 + 0x1804a6721);
        puVar2 = puVar2 + -2;
        *puVar2 = *(undefined *)(iVar4 + 0x1804a6720);
        arg2 = uVar3;
    }
    if ((uint64_t)arg2 < 10) {
        puVar2[-1] = (char)arg2 + '0';
    } else {
        iVar4 = (arg2 & 0xffffffffU) * 2;
        puVar2[-1] = *(undefined *)(iVar4 + 0x1804a6721);
        puVar2[-2] = *(undefined *)(iVar4 + 0x1804a6720);
    }
    // WARNING: Could not recover jumptable at 0x0001801750ba. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, arg1 + 0x10, (uint64_t)uVar5);
    return;
}

// ============================================================
// Function: FUN_180174f9e
// Address: 0x180174f9e
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180174ef0(int64_t arg1, int64_t arg2)
{
    undefined auVar1 [16];
    undefined *puVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    if (arg2 == 0) {
    // WARNING: Could not recover jumptable at 0x000180174f08. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x30);
        return;
    }
    uVar5 = 1;
    if (arg2 < 0) {
        *(undefined *)(arg1 + 0x10) = 0x2d;
        arg2 = -arg2;
        for (uVar3 = arg2; 9 < uVar3; uVar3 = uVar3 / 10000) {
            if (uVar3 < 100) {
                uVar5 = uVar5 + 1;
                break;
            }
            if (uVar3 < 1000) {
                uVar5 = uVar5 + 2;
                break;
            }
            if (uVar3 < 10000) {
                uVar5 = uVar5 + 3;
                break;
            }
            uVar5 = uVar5 + 4;
        }
code_r0x000180174f88:
        uVar5 = uVar5 + 1;
    } else {
        uVar3 = arg2;
        if (9 < (uint64_t)arg2) {
            do {
                if (uVar3 < 100) goto code_r0x000180174f88;
                if (uVar3 < 1000) {
                    uVar5 = uVar5 + 2;
                    break;
                }
                if (uVar3 < 10000) {
                    uVar5 = uVar5 + 3;
                    break;
                }
                uVar5 = uVar5 + 4;
                uVar3 = uVar3 / 10000;
            } while (9 < uVar3);
        }
    }
    puVar2 = (undefined *)(arg1 + 0x10 + (uint64_t)uVar5);
    while (99 < (uint64_t)arg2) {
        auVar1._8_8_ = 0;
        auVar1._0_8_ = arg2;
        iVar4 = SUB168(ZEXT816(0x47ae147ae147ae15) * auVar1, 8);
        uVar3 = ((uint64_t)(arg2 - iVar4) >> 1) + iVar4 >> 6;
        iVar4 = (arg2 + uVar3 * -100 & 0xffffffff) * 2;
        puVar2[-1] = *(undefined *)(iVar4 + 0x1804a6721);
        puVar2 = puVar2 + -2;
        *puVar2 = *(undefined *)(iVar4 + 0x1804a6720);
        arg2 = uVar3;
    }
    if ((uint64_t)arg2 < 10) {
        puVar2[-1] = (char)arg2 + '0';
    } else {
        iVar4 = (arg2 & 0xffffffffU) * 2;
        puVar2[-1] = *(undefined *)(iVar4 + 0x1804a6721);
        puVar2[-2] = *(undefined *)(iVar4 + 0x1804a6720);
    }
    // WARNING: Could not recover jumptable at 0x0001801750ba. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, arg1 + 0x10, (uint64_t)uVar5);
    return;
}

// ============================================================
// Function: FUN_180174ff1
// Address: 0x180174ff1
// Size: 205 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180174ef0(int64_t arg1, int64_t arg2)
{
    undefined auVar1 [16];
    undefined *puVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    if (arg2 == 0) {
    // WARNING: Could not recover jumptable at 0x000180174f08. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x30);
        return;
    }
    uVar5 = 1;
    if (arg2 < 0) {
        *(undefined *)(arg1 + 0x10) = 0x2d;
        arg2 = -arg2;
        for (uVar3 = arg2; 9 < uVar3; uVar3 = uVar3 / 10000) {
            if (uVar3 < 100) {
                uVar5 = uVar5 + 1;
                break;
            }
            if (uVar3 < 1000) {
                uVar5 = uVar5 + 2;
                break;
            }
            if (uVar3 < 10000) {
                uVar5 = uVar5 + 3;
                break;
            }
            uVar5 = uVar5 + 4;
        }
code_r0x000180174f88:
        uVar5 = uVar5 + 1;
    } else {
        uVar3 = arg2;
        if (9 < (uint64_t)arg2) {
            do {
                if (uVar3 < 100) goto code_r0x000180174f88;
                if (uVar3 < 1000) {
                    uVar5 = uVar5 + 2;
                    break;
                }
                if (uVar3 < 10000) {
                    uVar5 = uVar5 + 3;
                    break;
                }
                uVar5 = uVar5 + 4;
                uVar3 = uVar3 / 10000;
            } while (9 < uVar3);
        }
    }
    puVar2 = (undefined *)(arg1 + 0x10 + (uint64_t)uVar5);
    while (99 < (uint64_t)arg2) {
        auVar1._8_8_ = 0;
        auVar1._0_8_ = arg2;
        iVar4 = SUB168(ZEXT816(0x47ae147ae147ae15) * auVar1, 8);
        uVar3 = ((uint64_t)(arg2 - iVar4) >> 1) + iVar4 >> 6;
        iVar4 = (arg2 + uVar3 * -100 & 0xffffffff) * 2;
        puVar2[-1] = *(undefined *)(iVar4 + 0x1804a6721);
        puVar2 = puVar2 + -2;
        *puVar2 = *(undefined *)(iVar4 + 0x1804a6720);
        arg2 = uVar3;
    }
    if ((uint64_t)arg2 < 10) {
        puVar2[-1] = (char)arg2 + '0';
    } else {
        iVar4 = (arg2 & 0xffffffffU) * 2;
        puVar2[-1] = *(undefined *)(iVar4 + 0x1804a6721);
        puVar2[-2] = *(undefined *)(iVar4 + 0x1804a6720);
    }
    // WARNING: Could not recover jumptable at 0x0001801750ba. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, arg1 + 0x10, (uint64_t)uVar5);
    return;
}

// ============================================================
// Function: FUN_1801750c0
// Address: 0x1801750c0
// Size: 146 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801750c0(int64_t arg1, int64_t arg2)
{
    undefined auVar1 [16];
    undefined *puVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    if (arg2 == 0) {
    // WARNING: Could not recover jumptable at 0x0001801750db. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x30);
        return;
    }
    uVar5 = 1;
    uVar3 = arg2;
    if (9 < (uint64_t)arg2) {
        do {
            if (uVar3 < 100) {
                uVar5 = uVar5 + 1;
                break;
            }
            if (uVar3 < 1000) {
                uVar5 = uVar5 + 2;
                break;
            }
            if (uVar3 < 10000) {
                uVar5 = uVar5 + 3;
                break;
            }
            uVar5 = uVar5 + 4;
            uVar3 = uVar3 / 10000;
        } while (9 < uVar3);
    }
    puVar2 = (undefined *)(arg1 + 0x10 + (uint64_t)uVar5);
    uVar3 = arg2;
    if (99 < (uint64_t)arg2) {
        do {
            auVar1._8_8_ = 0;
            auVar1._0_8_ = arg2;
            iVar4 = SUB168(ZEXT816(0x47ae147ae147ae15) * auVar1, 8);
            uVar3 = ((uint64_t)(arg2 - iVar4) >> 1) + iVar4 >> 6;
            iVar4 = (arg2 + uVar3 * -100 & 0xffffffff) * 2;
            puVar2[-1] = *(undefined *)(iVar4 + 0x1804a6651);
            puVar2 = puVar2 + -2;
            *puVar2 = *(undefined *)(iVar4 + 0x1804a6650);
            arg2 = uVar3;
        } while (99 < uVar3);
    }
    if (uVar3 < 10) {
        puVar2[-1] = (char)uVar3 + '0';
    } else {
        iVar4 = (uVar3 & 0xffffffff) * 2;
        puVar2[-1] = *(undefined *)(iVar4 + 0x1804a6651);
        puVar2[-2] = *(undefined *)(iVar4 + 0x1804a6650);
    }
    // WARNING: Could not recover jumptable at 0x0001801751e3. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, arg1 + 0x10, (uint64_t)uVar5);
    return;
}

// ============================================================
// Function: FUN_180175152
// Address: 0x180175152
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801750c0(int64_t arg1, int64_t arg2)
{
    undefined auVar1 [16];
    undefined *puVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    if (arg2 == 0) {
    // WARNING: Could not recover jumptable at 0x0001801750db. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x30);
        return;
    }
    uVar5 = 1;
    uVar3 = arg2;
    if (9 < (uint64_t)arg2) {
        do {
            if (uVar3 < 100) {
                uVar5 = uVar5 + 1;
                break;
            }
            if (uVar3 < 1000) {
                uVar5 = uVar5 + 2;
                break;
            }
            if (uVar3 < 10000) {
                uVar5 = uVar5 + 3;
                break;
            }
            uVar5 = uVar5 + 4;
            uVar3 = uVar3 / 10000;
        } while (9 < uVar3);
    }
    puVar2 = (undefined *)(arg1 + 0x10 + (uint64_t)uVar5);
    uVar3 = arg2;
    if (99 < (uint64_t)arg2) {
        do {
            auVar1._8_8_ = 0;
            auVar1._0_8_ = arg2;
            iVar4 = SUB168(ZEXT816(0x47ae147ae147ae15) * auVar1, 8);
            uVar3 = ((uint64_t)(arg2 - iVar4) >> 1) + iVar4 >> 6;
            iVar4 = (arg2 + uVar3 * -100 & 0xffffffff) * 2;
            puVar2[-1] = *(undefined *)(iVar4 + 0x1804a6651);
            puVar2 = puVar2 + -2;
            *puVar2 = *(undefined *)(iVar4 + 0x1804a6650);
            arg2 = uVar3;
        } while (99 < uVar3);
    }
    if (uVar3 < 10) {
        puVar2[-1] = (char)uVar3 + '0';
    } else {
        iVar4 = (uVar3 & 0xffffffff) * 2;
        puVar2[-1] = *(undefined *)(iVar4 + 0x1804a6651);
        puVar2[-2] = *(undefined *)(iVar4 + 0x1804a6650);
    }
    // WARNING: Could not recover jumptable at 0x0001801751e3. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, arg1 + 0x10, (uint64_t)uVar5);
    return;
}

// ============================================================
// Function: FUN_1801751a2
// Address: 0x1801751a2
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801750c0(int64_t arg1, int64_t arg2)
{
    undefined auVar1 [16];
    undefined *puVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    if (arg2 == 0) {
    // WARNING: Could not recover jumptable at 0x0001801750db. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)**(undefined8 **)arg1)(*(undefined8 **)arg1, 0x30);
        return;
    }
    uVar5 = 1;
    uVar3 = arg2;
    if (9 < (uint64_t)arg2) {
        do {
            if (uVar3 < 100) {
                uVar5 = uVar5 + 1;
                break;
            }
            if (uVar3 < 1000) {
                uVar5 = uVar5 + 2;
                break;
            }
            if (uVar3 < 10000) {
                uVar5 = uVar5 + 3;
                break;
            }
            uVar5 = uVar5 + 4;
            uVar3 = uVar3 / 10000;
        } while (9 < uVar3);
    }
    puVar2 = (undefined *)(arg1 + 0x10 + (uint64_t)uVar5);
    uVar3 = arg2;
    if (99 < (uint64_t)arg2) {
        do {
            auVar1._8_8_ = 0;
            auVar1._0_8_ = arg2;
            iVar4 = SUB168(ZEXT816(0x47ae147ae147ae15) * auVar1, 8);
            uVar3 = ((uint64_t)(arg2 - iVar4) >> 1) + iVar4 >> 6;
            iVar4 = (arg2 + uVar3 * -100 & 0xffffffff) * 2;
            puVar2[-1] = *(undefined *)(iVar4 + 0x1804a6651);
            puVar2 = puVar2 + -2;
            *puVar2 = *(undefined *)(iVar4 + 0x1804a6650);
            arg2 = uVar3;
        } while (99 < uVar3);
    }
    if (uVar3 < 10) {
        puVar2[-1] = (char)uVar3 + '0';
    } else {
        iVar4 = (uVar3 & 0xffffffff) * 2;
        puVar2[-1] = *(undefined *)(iVar4 + 0x1804a6651);
        puVar2[-2] = *(undefined *)(iVar4 + 0x1804a6650);
    }
    // WARNING: Could not recover jumptable at 0x0001801751e3. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(**(int64_t **)arg1 + 8))(*(int64_t **)arg1, arg1 + 0x10, (uint64_t)uVar5);
    return;
}

// ============================================================
// Function: FUN_1801751f0
// Address: 0x1801751f0
// Size: 88 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h

int64_t fcn.1801751f0(int64_t arg1)
{
    int32_t iVar1;
    uint64_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined4 in_XMM2_Da;
    uint32_t in_XMM2_Db;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 auStackX_18 [2];
    int64_t var_20h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int32_t iStack_a0;
    int64_t var_9ch;
    int64_t var_90h;
    undefined8 var_88h;
    int32_t var_80h;
    int64_t var_7ch;
    undefined4 uStack_74;
    int32_t iStack_70;
    int64_t var_68h;
    int32_t iStack_60;
    undefined4 uStack_5c;
    int64_t var_58h;
    int32_t iStack_50;
    undefined4 uStack_4c;
    int64_t var_2ch;
    undefined4 uStack_24;
    int32_t iStack_20;
    undefined4 var_1ch;
    int64_t var_18h;
    
    iVar1 = func_0x00018046ea20();
    if (iVar1 != 0) {
        in_XMM2_Db = in_XMM2_Db ^ 0x80000000;
        *(undefined *)arg1 = 0x2d;
        arg1 = arg1 + 1;
    }
    if ((double)CONCAT44(in_XMM2_Db, in_XMM2_Da) == 0.0) {
        *(undefined2 *)arg1 = 0x2e30;
        iVar4 = arg1 + 3;
        *(undefined *)(arg1 + 2) = 0x30;
    } else {
        var_20h._0_4_ = 0;
        auStackX_18[0] = 0;
        uVar2 = CONCAT44(in_XMM2_Db, in_XMM2_Da) & 0xfffffffffffff;
        if (in_XMM2_Db >> 0x14 == 0) {
            var_90h._0_4_ = -0x432;
            unique0x10000308 = uVar2;
        } else {
            var_90h._0_4_ = (in_XMM2_Db >> 0x14) - 0x433;
            *(uint64_t *)0x80 = uVar2 + 0x10000000000000;
        }
        if ((uVar2 == 0) && (1 < in_XMM2_Db >> 0x14)) {
            cVar3 = (char)(int32_t)var_90h + -2;
            iVar4 = *(uint64_t *)0x80 * 4;
        } else {
            iVar4 = *(uint64_t *)0x80 * 2;
            cVar3 = (char)(int32_t)var_90h + -1;
        }
        iStack_a0 = (int32_t)var_90h + -1;
        var_68h = *(uint64_t *)0x80 * 2 + 1;
        do {
            iStack_a0 = iStack_a0 + -1;
            var_68h = var_68h * 2;
        } while (-1 < var_68h);
        iVar4 = iVar4 + -1 << (cVar3 - (char)iStack_a0 & 0x3fU);
        do {
            var_90h._0_4_ = (int32_t)var_90h + -1;
            unique0x1000016b = *(uint64_t *)0x80 * 2;
        } while (-1 < (int64_t)unique0x1000016b);
        var_2ch._0_4_ = (undefined4)var_9ch;
        var_1ch = (undefined4)var_9ch;
        var_2ch._4_4_ = (undefined4)var_68h;
        uStack_24 = (undefined4)((uint64_t)var_68h >> 0x20);
        var_7ch._0_4_ = (undefined4)var_9ch;
        var_7ch._4_4_ = var_2ch._4_4_;
        uStack_74 = uStack_24;
        var_90h._4_4_ = (undefined4)var_9ch;
        uStack_5c = (undefined4)var_9ch;
        var_88h._0_4_ = (undefined4)iVar4;
        var_88h._4_4_ = (undefined4)((uint64_t)iVar4 >> 0x20);
        uStack_4c = (undefined4)var_9ch;
        var_a8h._0_4_ = (undefined4)var_88h;
        var_a8h._4_4_ = var_88h._4_4_;
        var_88h = iVar4;
        var_80h = iStack_a0;
        iStack_70 = iStack_a0;
        iStack_60 = iStack_a0;
        iStack_50 = (int32_t)var_90h;
        unique0x10000328 = var_68h;
        iStack_20 = iStack_a0;
        var_58h = unique0x1000016b;
        func_0x00018017ace0(arg1, &var_20h, auStackX_18, &var_a8h, &var_58h, &var_68h);
        var_b8h = CONCAT44((int32_t)((uint64_t)&var_58h >> 0x20), 0xf);
        iVar4 = func_0x00018017ab10(arg1, (undefined4)var_20h, auStackX_18[0], 0xfffffffc, var_b8h);
    }
    return iVar4;
}

// ============================================================
// Function: FUN_180175248
// Address: 0x180175248
// Size: 306 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h

int64_t fcn.1801751f0(int64_t arg1)
{
    int32_t iVar1;
    uint64_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined4 in_XMM2_Da;
    uint32_t in_XMM2_Db;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 auStackX_18 [2];
    int64_t var_20h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int32_t iStack_a0;
    int64_t var_9ch;
    int64_t var_90h;
    undefined8 var_88h;
    int32_t var_80h;
    int64_t var_7ch;
    undefined4 uStack_74;
    int32_t iStack_70;
    int64_t var_68h;
    int32_t iStack_60;
    undefined4 uStack_5c;
    int64_t var_58h;
    int32_t iStack_50;
    undefined4 uStack_4c;
    int64_t var_2ch;
    undefined4 uStack_24;
    int32_t iStack_20;
    undefined4 var_1ch;
    int64_t var_18h;
    
    iVar1 = func_0x00018046ea20();
    if (iVar1 != 0) {
        in_XMM2_Db = in_XMM2_Db ^ 0x80000000;
        *(undefined *)arg1 = 0x2d;
        arg1 = arg1 + 1;
    }
    if ((double)CONCAT44(in_XMM2_Db, in_XMM2_Da) == 0.0) {
        *(undefined2 *)arg1 = 0x2e30;
        iVar4 = arg1 + 3;
        *(undefined *)(arg1 + 2) = 0x30;
    } else {
        var_20h._0_4_ = 0;
        auStackX_18[0] = 0;
        uVar2 = CONCAT44(in_XMM2_Db, in_XMM2_Da) & 0xfffffffffffff;
        if (in_XMM2_Db >> 0x14 == 0) {
            var_90h._0_4_ = -0x432;
            unique0x10000308 = uVar2;
        } else {
            var_90h._0_4_ = (in_XMM2_Db >> 0x14) - 0x433;
            *(uint64_t *)0x80 = uVar2 + 0x10000000000000;
        }
        if ((uVar2 == 0) && (1 < in_XMM2_Db >> 0x14)) {
            cVar3 = (char)(int32_t)var_90h + -2;
            iVar4 = *(uint64_t *)0x80 * 4;
        } else {
            iVar4 = *(uint64_t *)0x80 * 2;
            cVar3 = (char)(int32_t)var_90h + -1;
        }
        iStack_a0 = (int32_t)var_90h + -1;
        var_68h = *(uint64_t *)0x80 * 2 + 1;
        do {
            iStack_a0 = iStack_a0 + -1;
            var_68h = var_68h * 2;
        } while (-1 < var_68h);
        iVar4 = iVar4 + -1 << (cVar3 - (char)iStack_a0 & 0x3fU);
        do {
            var_90h._0_4_ = (int32_t)var_90h + -1;
            unique0x1000016b = *(uint64_t *)0x80 * 2;
        } while (-1 < (int64_t)unique0x1000016b);
        var_2ch._0_4_ = (undefined4)var_9ch;
        var_1ch = (undefined4)var_9ch;
        var_2ch._4_4_ = (undefined4)var_68h;
        uStack_24 = (undefined4)((uint64_t)var_68h >> 0x20);
        var_7ch._0_4_ = (undefined4)var_9ch;
        var_7ch._4_4_ = var_2ch._4_4_;
        uStack_74 = uStack_24;
        var_90h._4_4_ = (undefined4)var_9ch;
        uStack_5c = (undefined4)var_9ch;
        var_88h._0_4_ = (undefined4)iVar4;
        var_88h._4_4_ = (undefined4)((uint64_t)iVar4 >> 0x20);
        uStack_4c = (undefined4)var_9ch;
        var_a8h._0_4_ = (undefined4)var_88h;
        var_a8h._4_4_ = var_88h._4_4_;
        var_88h = iVar4;
        var_80h = iStack_a0;
        iStack_70 = iStack_a0;
        iStack_60 = iStack_a0;
        iStack_50 = (int32_t)var_90h;
        unique0x10000328 = var_68h;
        iStack_20 = iStack_a0;
        var_58h = unique0x1000016b;
        func_0x00018017ace0(arg1, &var_20h, auStackX_18, &var_a8h, &var_58h, &var_68h);
        var_b8h = CONCAT44((int32_t)((uint64_t)&var_58h >> 0x20), 0xf);
        iVar4 = func_0x00018017ab10(arg1, (undefined4)var_20h, auStackX_18[0], 0xfffffffc, var_b8h);
    }
    return iVar4;
}

// ============================================================
// Function: FUN_18017537a
// Address: 0x18017537a
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h

int64_t fcn.1801751f0(int64_t arg1)
{
    int32_t iVar1;
    uint64_t uVar2;
    char cVar3;
    int64_t iVar4;
    undefined4 in_XMM2_Da;
    uint32_t in_XMM2_Db;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 auStackX_18 [2];
    int64_t var_20h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int32_t iStack_a0;
    int64_t var_9ch;
    int64_t var_90h;
    undefined8 var_88h;
    int32_t var_80h;
    int64_t var_7ch;
    undefined4 uStack_74;
    int32_t iStack_70;
    int64_t var_68h;
    int32_t iStack_60;
    undefined4 uStack_5c;
    int64_t var_58h;
    int32_t iStack_50;
    undefined4 uStack_4c;
    int64_t var_2ch;
    undefined4 uStack_24;
    int32_t iStack_20;
    undefined4 var_1ch;
    int64_t var_18h;
    
    iVar1 = func_0x00018046ea20();
    if (iVar1 != 0) {
        in_XMM2_Db = in_XMM2_Db ^ 0x80000000;
        *(undefined *)arg1 = 0x2d;
        arg1 = arg1 + 1;
    }
    if ((double)CONCAT44(in_XMM2_Db, in_XMM2_Da) == 0.0) {
        *(undefined2 *)arg1 = 0x2e30;
        iVar4 = arg1 + 3;
        *(undefined *)(arg1 + 2) = 0x30;
    } else {
        var_20h._0_4_ = 0;
        auStackX_18[0] = 0;
        uVar2 = CONCAT44(in_XMM2_Db, in_XMM2_Da) & 0xfffffffffffff;
        if (in_XMM2_Db >> 0x14 == 0) {
            var_90h._0_4_ = -0x432;
            unique0x10000308 = uVar2;
        } else {
            var_90h._0_4_ = (in_XMM2_Db >> 0x14) - 0x433;
            *(uint64_t *)0x80 = uVar2 + 0x10000000000000;
        }
        if ((uVar2 == 0) && (1 < in_XMM2_Db >> 0x14)) {
            cVar3 = (char)(int32_t)var_90h + -2;
            iVar4 = *(uint64_t *)0x80 * 4;
        } else {
            iVar4 = *(uint64_t *)0x80 * 2;
            cVar3 = (char)(int32_t)var_90h + -1;
        }
        iStack_a0 = (int32_t)var_90h + -1;
        var_68h = *(uint64_t *)0x80 * 2 + 1;
        do {
            iStack_a0 = iStack_a0 + -1;
            var_68h = var_68h * 2;
        } while (-1 < var_68h);
        iVar4 = iVar4 + -1 << (cVar3 - (char)iStack_a0 & 0x3fU);
        do {
            var_90h._0_4_ = (int32_t)var_90h + -1;
            unique0x1000016b = *(uint64_t *)0x80 * 2;
        } while (-1 < (int64_t)unique0x1000016b);
        var_2ch._0_4_ = (undefined4)var_9ch;
        var_1ch = (undefined4)var_9ch;
        var_2ch._4_4_ = (undefined4)var_68h;
        uStack_24 = (undefined4)((uint64_t)var_68h >> 0x20);
        var_7ch._0_4_ = (undefined4)var_9ch;
        var_7ch._4_4_ = var_2ch._4_4_;
        uStack_74 = uStack_24;
        var_90h._4_4_ = (undefined4)var_9ch;
        uStack_5c = (undefined4)var_9ch;
        var_88h._0_4_ = (undefined4)iVar4;
        var_88h._4_4_ = (undefined4)((uint64_t)iVar4 >> 0x20);
        uStack_4c = (undefined4)var_9ch;
        var_a8h._0_4_ = (undefined4)var_88h;
        var_a8h._4_4_ = var_88h._4_4_;
        var_88h = iVar4;
        var_80h = iStack_a0;
        iStack_70 = iStack_a0;
        iStack_60 = iStack_a0;
        iStack_50 = (int32_t)var_90h;
        unique0x10000328 = var_68h;
        iStack_20 = iStack_a0;
        var_58h = unique0x1000016b;
        func_0x00018017ace0(arg1, &var_20h, auStackX_18, &var_a8h, &var_58h, &var_68h);
        var_b8h = CONCAT44((int32_t)((uint64_t)&var_58h >> 0x20), 0xf);
        iVar4 = func_0x00018017ab10(arg1, (undefined4)var_20h, auStackX_18[0], 0xfffffffc, var_b8h);
    }
    return iVar4;
}

// ============================================================
// Function: FUN_1801753a0
// Address: 0x1801753a0
// Size: 328 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_99h
// WARNING: [rz-ghidra] Detected overlap for variable var_95h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h

void fcn.1801753a0(int64_t arg1)
{
    code *pcVar1;
    undefined (*pauVar2) [16];
    char in_DL;
    undefined auStackY_a8 [32];
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_48h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_a8;
    *(char *)arg1 = in_DL;
    var_88h = arg1;
    // switch table (10 cases) at 0x1801754c0
    switch(in_DL) {
    case '\0':
    case '\x05':
    case '\x06':
    case '\a':
        *(undefined8 *)(arg1 + 8) = 0;
        goto code_r0x0001801753ee;
    case '\x01':
        pauVar2 = (undefined (*) [16])fcn.180174d50();
        break;
    case '\x02':
        pauVar2 = (undefined (*) [16])fcn.180459890();
        *(undefined8 *)*pauVar2 = 0;
        *(undefined8 *)(*pauVar2 + 8) = 0;
        *(undefined8 *)pauVar2[1] = 0;
        break;
    case '\x03':
        pauVar2 = (undefined (*) [16])fcn.180459890();
        *pauVar2 = ZEXT816(0);
        *(undefined8 *)pauVar2[1] = 0;
        *(undefined8 *)(pauVar2[1] + 8) = 0xf;
        (*pauVar2)[0] = 0;
        break;
    case '\x04':
        *(undefined *)(arg1 + 8) = 0;
        goto code_r0x0001801753ee;
    case '\b':
        pauVar2 = (undefined (*) [16])fcn.180459890();
        *(undefined8 *)*pauVar2 = 0;
        *(undefined8 *)(*pauVar2 + 8) = 0;
        *(undefined8 *)pauVar2[1] = 0;
        *(undefined8 *)(pauVar2[1] + 8) = 0;
        pauVar2[2][0] = 0;
        break;
    default:
        *(undefined8 *)(arg1 + 8) = 0;
        if (in_DL == '\0') {
            func_0x0001800047e0(&var_48h, 0x1804a67e8);
            fcn.1801748f0((int64_t)&var_80h, 500, (int64_t)&var_48h);
            fcn.18045bae0(var_88h);
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        goto code_r0x0001801753ee;
    }
    *(undefined (**) [16])(arg1 + 8) = pauVar2;
code_r0x0001801753ee:
    func_0x000180459870(var_18h ^ (uint64_t)auStackY_a8);
    return;
}

// ============================================================
// Function: FUN_1801754f0
// Address: 0x1801754f0
// Size: 448 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1801754f0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    uVar3 = *(undefined4 *)(arg2 + 4);
    uVar4 = *(undefined4 *)(arg2 + 8);
    uVar5 = *(undefined4 *)(arg2 + 0xc);
    *(undefined4 *)arg1 = *(undefined4 *)arg2;
    *(undefined4 *)(arg1 + 4) = uVar3;
    *(undefined4 *)(arg1 + 8) = uVar4;
    *(undefined4 *)(arg1 + 0xc) = uVar5;
    uVar3 = *(undefined4 *)(arg2 + 0x14);
    uVar4 = *(undefined4 *)(arg2 + 0x18);
    uVar5 = *(undefined4 *)(arg2 + 0x1c);
    *(undefined4 *)(arg1 + 0x10) = *(undefined4 *)(arg2 + 0x10);
    *(undefined4 *)(arg1 + 0x14) = uVar3;
    *(undefined4 *)(arg1 + 0x18) = uVar4;
    *(undefined4 *)(arg1 + 0x1c) = uVar5;
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    *(undefined (*) [16])(arg1 + 0x20) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x30) = 0;
    *(undefined8 *)(arg1 + 0x38) = 0;
    uVar3 = *(undefined4 *)(arg2 + 0x24);
    uVar4 = *(undefined4 *)(arg2 + 0x28);
    uVar5 = *(undefined4 *)(arg2 + 0x2c);
    *(undefined4 *)(arg1 + 0x20) = *(undefined4 *)(arg2 + 0x20);
    *(undefined4 *)(arg1 + 0x24) = uVar3;
    *(undefined4 *)(arg1 + 0x28) = uVar4;
    *(undefined4 *)(arg1 + 0x2c) = uVar5;
    uVar3 = *(undefined4 *)(arg2 + 0x34);
    uVar4 = *(undefined4 *)(arg2 + 0x38);
    uVar5 = *(undefined4 *)(arg2 + 0x3c);
    *(undefined4 *)(arg1 + 0x30) = *(undefined4 *)(arg2 + 0x30);
    *(undefined4 *)(arg1 + 0x34) = uVar3;
    *(undefined4 *)(arg1 + 0x38) = uVar4;
    *(undefined4 *)(arg1 + 0x3c) = uVar5;
    *(undefined8 *)(arg2 + 0x30) = 0;
    *(undefined8 *)(arg2 + 0x38) = 0xf;
    *(undefined *)(arg2 + 0x20) = 0;
    *(undefined (*) [16])(arg1 + 0x40) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x50) = 0;
    *(undefined8 *)(arg1 + 0x58) = 0;
    uVar3 = *(undefined4 *)(arg2 + 0x44);
    uVar4 = *(undefined4 *)(arg2 + 0x48);
    uVar5 = *(undefined4 *)(arg2 + 0x4c);
    *(undefined4 *)(arg1 + 0x40) = *(undefined4 *)(arg2 + 0x40);
    *(undefined4 *)(arg1 + 0x44) = uVar3;
    *(undefined4 *)(arg1 + 0x48) = uVar4;
    *(undefined4 *)(arg1 + 0x4c) = uVar5;
    uVar3 = *(undefined4 *)(arg2 + 0x54);
    uVar4 = *(undefined4 *)(arg2 + 0x58);
    uVar5 = *(undefined4 *)(arg2 + 0x5c);
    *(undefined4 *)(arg1 + 0x50) = *(undefined4 *)(arg2 + 0x50);
    *(undefined4 *)(arg1 + 0x54) = uVar3;
    *(undefined4 *)(arg1 + 0x58) = uVar4;
    *(undefined4 *)(arg1 + 0x5c) = uVar5;
    *(undefined8 *)(arg2 + 0x50) = 0;
    *(undefined8 *)(arg2 + 0x58) = 0xf;
    *(undefined *)(arg2 + 0x40) = 0;
    *(undefined (*) [16])(arg1 + 0x60) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x70) = 0;
    *(undefined8 *)(arg1 + 0x78) = 0;
    uVar3 = *(undefined4 *)(arg2 + 100);
    uVar4 = *(undefined4 *)(arg2 + 0x68);
    uVar5 = *(undefined4 *)(arg2 + 0x6c);
    *(undefined4 *)(arg1 + 0x60) = *(undefined4 *)(arg2 + 0x60);
    *(undefined4 *)(arg1 + 100) = uVar3;
    *(undefined4 *)(arg1 + 0x68) = uVar4;
    *(undefined4 *)(arg1 + 0x6c) = uVar5;
    uVar3 = *(undefined4 *)(arg2 + 0x74);
    uVar4 = *(undefined4 *)(arg2 + 0x78);
    uVar5 = *(undefined4 *)(arg2 + 0x7c);
    *(undefined4 *)(arg1 + 0x70) = *(undefined4 *)(arg2 + 0x70);
    *(undefined4 *)(arg1 + 0x74) = uVar3;
    *(undefined4 *)(arg1 + 0x78) = uVar4;
    *(undefined4 *)(arg1 + 0x7c) = uVar5;
    *(undefined8 *)(arg2 + 0x70) = 0;
    *(undefined8 *)(arg2 + 0x78) = 0xf;
    *(undefined *)(arg2 + 0x60) = 0;
    *(undefined (*) [16])(arg1 + 0x80) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x90) = 0;
    *(undefined8 *)(arg1 + 0x98) = 0;
    uVar3 = *(undefined4 *)(arg2 + 0x84);
    uVar4 = *(undefined4 *)(arg2 + 0x88);
    uVar5 = *(undefined4 *)(arg2 + 0x8c);
    *(undefined4 *)(arg1 + 0x80) = *(undefined4 *)(arg2 + 0x80);
    *(undefined4 *)(arg1 + 0x84) = uVar3;
    *(undefined4 *)(arg1 + 0x88) = uVar4;
    *(undefined4 *)(arg1 + 0x8c) = uVar5;
    uVar3 = *(undefined4 *)(arg2 + 0x94);
    uVar4 = *(undefined4 *)(arg2 + 0x98);
    uVar5 = *(undefined4 *)(arg2 + 0x9c);
    *(undefined4 *)(arg1 + 0x90) = *(undefined4 *)(arg2 + 0x90);
    *(undefined4 *)(arg1 + 0x94) = uVar3;
    *(undefined4 *)(arg1 + 0x98) = uVar4;
    *(undefined4 *)(arg1 + 0x9c) = uVar5;
    *(undefined8 *)(arg2 + 0x90) = 0;
    *(undefined8 *)(arg2 + 0x98) = 0xf;
    *(undefined *)(arg2 + 0x80) = 0;
    *(undefined4 *)(arg1 + 0xa0) = *(undefined4 *)(arg2 + 0xa0);
    *(undefined *)(arg1 + 0xa4) = *(undefined *)(arg2 + 0xa4);
    *(undefined *)(arg1 + 0xa5) = *(undefined *)(arg2 + 0xa5);
    *(undefined4 *)(arg1 + 0xa8) = *(undefined4 *)(arg2 + 0xa8);
    *(undefined4 *)(arg1 + 0xac) = *(undefined4 *)(arg2 + 0xac);
    piVar1 = (int64_t *)(arg1 + 0xb0);
    *piVar1 = 0;
    *(undefined8 *)(arg1 + 0xb8) = 0;
    iVar6 = fcn.180459890(0x60);
    *(int64_t *)iVar6 = iVar6;
    *(int64_t *)(iVar6 + 8) = iVar6;
    *(int64_t *)(iVar6 + 0x10) = iVar6;
    *(undefined2 *)(iVar6 + 0x18) = 0x101;
    *piVar1 = iVar6;
    *piVar1 = *(int64_t *)(arg2 + 0xb0);
    *(int64_t *)(arg2 + 0xb0) = iVar6;
    uVar2 = *(undefined8 *)(arg1 + 0xb8);
    *(undefined8 *)(arg1 + 0xb8) = *(undefined8 *)(arg2 + 0xb8);
    *(undefined8 *)(arg2 + 0xb8) = uVar2;
    return arg1;
}

// ============================================================
// Function: FUN_1801756b0
// Address: 0x1801756b0
// Size: 385 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1801756b0(int64_t arg1, int64_t arg2)
{
    int64_t **ppiVar1;
    char cVar2;
    int64_t *piVar3;
    int64_t iVar4;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t **ppiVar5;
    int64_t **ppiVar6;
    
    func_0x00018000b4d0();
    func_0x00018000b4d0(arg1 + 0x20, arg2 + 0x20);
    func_0x00018000b4d0(arg1 + 0x40, arg2 + 0x40);
    func_0x00018000b4d0(arg1 + 0x60, arg2 + 0x60);
    func_0x00018000b4d0(arg1 + 0x80, arg2 + 0x80);
    *(undefined4 *)(arg1 + 0xa0) = *(undefined4 *)(arg2 + 0xa0);
    *(undefined *)(arg1 + 0xa4) = *(undefined *)(arg2 + 0xa4);
    *(undefined *)(arg1 + 0xa5) = *(undefined *)(arg2 + 0xa5);
    *(undefined4 *)(arg1 + 0xa8) = *(undefined4 *)(arg2 + 0xa8);
    *(undefined4 *)(arg1 + 0xac) = *(undefined4 *)(arg2 + 0xac);
    ppiVar1 = (int64_t **)(arg1 + 0xb0);
    *ppiVar1 = (int64_t *)0x0;
    *(undefined8 *)(arg1 + 0xb8) = 0;
    ppiVar5 = ppiVar1;
    ppiVar6 = ppiVar1;
    piVar3 = (int64_t *)fcn.180459890(0x60);
    *piVar3 = (int64_t)piVar3;
    piVar3[1] = (int64_t)piVar3;
    piVar3[2] = (int64_t)piVar3;
    *(undefined2 *)(piVar3 + 3) = 0x101;
    *ppiVar1 = piVar3;
    iVar4 = func_0x000180015950(ppiVar1, *(undefined8 *)(*(int64_t *)(arg2 + 0xb0) + 8), piVar3, in_R9, ppiVar5, ppiVar6
                               );
    (*ppiVar1)[1] = iVar4;
    *(undefined8 *)(arg1 + 0xb8) = *(undefined8 *)(arg2 + 0xb8);
    piVar3 = *ppiVar1;
    ppiVar5 = (int64_t **)piVar3[1];
    if (*(char *)((int64_t)ppiVar5 + 0x19) == '\0') {
        cVar2 = *(char *)((int64_t)*ppiVar5 + 0x19);
        ppiVar6 = (int64_t **)*ppiVar5;
        while (cVar2 == '\0') {
            cVar2 = *(char *)((int64_t)*ppiVar6 + 0x19);
            ppiVar5 = ppiVar6;
            ppiVar6 = (int64_t **)*ppiVar6;
        }
        **ppiVar1 = (int64_t)ppiVar5;
        iVar4 = (*ppiVar1)[1];
        cVar2 = *(char *)(*(int64_t *)(iVar4 + 0x10) + 0x19);
        while (cVar2 == '\0') {
            iVar4 = *(int64_t *)(iVar4 + 0x10);
            cVar2 = *(char *)(*(int64_t *)(iVar4 + 0x10) + 0x19);
        }
        (*ppiVar1)[2] = iVar4;
    } else {
        *piVar3 = (int64_t)piVar3;
        (*ppiVar1)[2] = (int64_t)*ppiVar1;
    }
    return arg1;
}

// ============================================================
// Function: FUN_180175840
// Address: 0x180175840
// Size: 225 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.180175840(int64_t arg1)
{
    int64_t iVar1;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    *(undefined (*) [16])(arg1 + 0x20) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x30) = 0;
    *(undefined8 *)(arg1 + 0x38) = 0xf;
    *(undefined *)(arg1 + 0x20) = 0;
    *(undefined (*) [16])(arg1 + 0x40) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x50) = 0;
    *(undefined8 *)(arg1 + 0x58) = 0xf;
    *(undefined *)(arg1 + 0x40) = 0;
    *(undefined (*) [16])(arg1 + 0x60) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x70) = 0;
    *(undefined8 *)(arg1 + 0x78) = 0xf;
    *(undefined *)(arg1 + 0x60) = 0;
    *(undefined (*) [16])(arg1 + 0x80) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x90) = 0;
    *(undefined8 *)(arg1 + 0x98) = 0xf;
    *(undefined *)(arg1 + 0x80) = 0;
    *(undefined8 *)(arg1 + 0xb0) = 0;
    *(undefined8 *)(arg1 + 0xb8) = 0;
    iVar1 = fcn.180459890(0x60);
    *(int64_t *)iVar1 = iVar1;
    *(int64_t *)(iVar1 + 8) = iVar1;
    *(int64_t *)(iVar1 + 0x10) = iVar1;
    *(undefined2 *)(iVar1 + 0x18) = 0x101;
    *(int64_t *)(arg1 + 0xb0) = iVar1;
    *(undefined4 *)(arg1 + 0xa0) = 0;
    *(undefined2 *)(arg1 + 0xa4) = 0;
    *(undefined8 *)(arg1 + 0xa8) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_180175930
// Address: 0x180175930
// Size: 280 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.180175930(int64_t arg1)
{
    int64_t iVar1;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    
    *(undefined8 *)arg1 = 0x1804a6098;
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    iVar1 = fcn.180459890(0x60);
    *(int64_t *)iVar1 = iVar1;
    *(int64_t *)(iVar1 + 8) = iVar1;
    *(int64_t *)(iVar1 + 0x10) = iVar1;
    *(undefined2 *)(iVar1 + 0x18) = 0x101;
    *(int64_t *)(arg1 + 0x10) = iVar1;
    *(undefined8 *)(arg1 + 0x20) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined8 *)(arg1 + 0x30) = 0;
    *(undefined (*) [16])(arg1 + 0x38) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x48) = 0;
    *(undefined8 *)(arg1 + 0x50) = 0xf;
    *(undefined *)(arg1 + 0x38) = 0;
    *(undefined8 *)(arg1 + 0x90) = 0;
    fcn.1801753a0(arg1 + 0xb0);
    *(undefined8 *)(arg1 + 0xc0) = 0;
    *(undefined8 *)(arg1 + 200) = 0;
    iVar1 = fcn.180459890(0x80);
    *(int64_t *)iVar1 = iVar1;
    *(int64_t *)(iVar1 + 8) = iVar1;
    *(int64_t *)(iVar1 + 0x10) = iVar1;
    *(undefined2 *)(iVar1 + 0x18) = 0x101;
    *(int64_t *)(arg1 + 0xc0) = iVar1;
    *(undefined8 *)(arg1 + 0xd0) = 0;
    *(undefined8 *)(arg1 + 0xd8) = 0;
    iVar1 = fcn.180459890(0x60);
    *(int64_t *)iVar1 = iVar1;
    *(int64_t *)(iVar1 + 8) = iVar1;
    *(int64_t *)(iVar1 + 0x10) = iVar1;
    *(undefined2 *)(iVar1 + 0x18) = 0x101;
    *(int64_t *)(arg1 + 0xd0) = iVar1;
    *(undefined4 *)(arg1 + 8) = 2;
    *(undefined4 *)(arg1 + 0xc) = 0x10001;
    *(undefined8 *)(arg1 + 0x98) = 0;
    *(undefined8 *)(arg1 + 0xa0) = 0;
    *(undefined4 *)(arg1 + 0xa8) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_180175a50
// Address: 0x180175a50
// Size: 292 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_2eh
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_32h

int64_t fcn.180175a50(int64_t arg1)
{
    int64_t iVar1;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    
    fcn.180175930(arg1);
    *(undefined8 *)arg1 = 0x1804a60b8;
    *(undefined (*) [16])(arg1 + 0xe8) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0xf8) = 0;
    *(undefined8 *)(arg1 + 0x100) = 0xf;
    *(undefined *)(arg1 + 0xe8) = 0;
    *(undefined (*) [16])(arg1 + 0x108) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x118) = 0;
    *(undefined8 *)(arg1 + 0x120) = 0xf;
    *(undefined *)(arg1 + 0x108) = 0;
    *(undefined (*) [16])(arg1 + 0x128) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x138) = 0;
    *(undefined8 *)(arg1 + 0x140) = 0xf;
    *(undefined *)(arg1 + 0x128) = 0;
    *(undefined (*) [16])(arg1 + 0x150) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x160) = 0;
    *(undefined8 *)(arg1 + 0x168) = 0xf;
    *(undefined *)(arg1 + 0x150) = 0;
    *(undefined8 *)(arg1 + 0x170) = 0;
    *(undefined8 *)(arg1 + 0x178) = 0;
    iVar1 = fcn.180459890(0x60);
    *(int64_t *)iVar1 = iVar1;
    *(int64_t *)(iVar1 + 8) = iVar1;
    *(int64_t *)(iVar1 + 0x10) = iVar1;
    *(undefined2 *)(iVar1 + 0x18) = 0x101;
    *(int64_t *)(arg1 + 0x170) = iVar1;
    *(undefined (*) [16])(arg1 + 0x180) = ZEXT816(0);
    *(undefined8 *)(arg1 + 400) = 0;
    *(undefined8 *)(arg1 + 0x198) = 0xf;
    *(undefined *)(arg1 + 0x180) = 0;
    *(undefined4 *)(arg1 + 0x1a0) = 0;
    *(undefined4 *)(arg1 + 8) = 0;
    fcn.1801783e0(arg1);
    return arg1;
}

// ============================================================
// Function: FUN_180175b80
// Address: 0x180175b80
// Size: 50 bytes
// ============================================================
int64_t fcn.180175b80(int64_t arg1)
{
    fcn.180175930(arg1);
    *(undefined4 *)(arg1 + 8) = 1;
    *(undefined8 *)arg1 = 0x1804a60e8;
    *(undefined4 *)(arg1 + 0xe0) = 200;
    return arg1;
}

// ============================================================
// Function: FUN_180175bc0
// Address: 0x180175bc0
// Size: 119 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180175bc0(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    fcn.18045b4e4(arg2 + 8);
    *(undefined8 *)arg1 = 0x1804a5b48;
    *(undefined4 *)(arg1 + 0x18) = *(undefined4 *)(arg2 + 0x18);
    *(undefined8 *)(arg1 + 0x20) = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 0x28) = ZEXT816(0);
    fcn.18045b4e4(arg2 + 0x28);
    *(undefined8 *)(arg1 + 0x20) = 0x1804a53a0;
    return arg1;
}

// ============================================================
// Function: FUN_180175c40
// Address: 0x180175c40
// Size: 33 bytes
// ============================================================
int64_t fcn.180175c40(int64_t arg1, int64_t arg2)
{
    fcn.180175bc0(arg1, arg2);
    *(undefined8 *)arg1 = 0x1804a5b90;
    return arg1;
}

// ============================================================
// Function: FUN_180175c70
// Address: 0x180175c70
// Size: 33 bytes
// ============================================================
int64_t fcn.180175c70(int64_t arg1, int64_t arg2)
{
    fcn.180175bc0(arg1, arg2);
    *(undefined8 *)arg1 = 0x1804a5b78;
    return arg1;
}

// ============================================================
// Function: FUN_180175ca0
// Address: 0x180175ca0
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180175ca0(int64_t arg1)
{
    int64_t iVar1;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    for (arg1 = *(int64_t *)arg1; arg1 != iVar1; arg1 = arg1 + 0xc0) {
        func_0x000180175e80(arg1);
    }
    return;
}

// ============================================================
// Function: FUN_180175ce0
// Address: 0x180175ce0
// Size: 22 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_67h
// WARNING: [rz-ghidra] Detected overlap for variable var_63h
// WARNING: [rz-ghidra] Detected overlap for variable var_61h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h

void fcn.180175ce0(int64_t arg1)
{
    fcn.180178f50(arg1 + 8, *(undefined *)arg1);
    return;
}

// ============================================================
// Function: FUN_180175d00
// Address: 0x180175d00
// Size: 42 bytes
// ============================================================
void fcn.180175d00(int64_t arg1)
{
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t in_stack_00000010;
    int64_t in_stack_00000018;
    int64_t in_stack_00000030;
    
    fcn.180174530(in_stack_00000010, in_stack_00000018, in_stack_00000030);
    if ((*(int64_t *)arg1 != 0) &&
       (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)arg1, in_R9, unaff_RBX), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar1 = (undefined4 *)fcn.18046b77c();
        *puVar1 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_180175d30
// Address: 0x180175d30
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180175d30(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    fcn.180004e40(arg1 + 0x260);
    piVar4 = *(int64_t **)(arg1 + 8);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180175d4e
// Address: 0x180175d4e
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180175d30(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    fcn.180004e40(arg1 + 0x260);
    piVar4 = *(int64_t **)(arg1 + 8);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180175d84
// Address: 0x180175d84
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180175d30(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    fcn.180004e40(arg1 + 0x260);
    piVar4 = *(int64_t **)(arg1 + 8);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180175db0
// Address: 0x180175db0
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180175db0(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined *puVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar4 = *(int64_t *)arg1;
    if (iVar4 != 0) {
        iVar1 = *(int64_t *)(arg1 + 8);
        for (; iVar4 != iVar1; iVar4 = iVar4 + 0xc0) {
            func_0x000180175e80(iVar4);
        }
        uVar6 = *(uint64_t *)arg1;
        uVar3 = uVar6;
        puVar5 = auStack_28;
        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar6) / 0xc0) * 0xc0)) {
            uVar3 = *(uint64_t *)(uVar6 - 8);
            uVar6 = (uVar6 - uVar3) - 8;
            puVar5 = auStack_28;
            if (0x1f < uVar6) {
                pcVar2 = (code *)swi(0x29);
                uVar3 = uVar6;
                (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x180175e4c;
        fcn.180459c3c(uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180175dc9
// Address: 0x180175dc9
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180175db0(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined *puVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar4 = *(int64_t *)arg1;
    if (iVar4 != 0) {
        iVar1 = *(int64_t *)(arg1 + 8);
        for (; iVar4 != iVar1; iVar4 = iVar4 + 0xc0) {
            func_0x000180175e80(iVar4);
        }
        uVar6 = *(uint64_t *)arg1;
        uVar3 = uVar6;
        puVar5 = auStack_28;
        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar6) / 0xc0) * 0xc0)) {
            uVar3 = *(uint64_t *)(uVar6 - 8);
            uVar6 = (uVar6 - uVar3) - 8;
            puVar5 = auStack_28;
            if (0x1f < uVar6) {
                pcVar2 = (code *)swi(0x29);
                uVar3 = uVar6;
                (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x180175e4c;
        fcn.180459c3c(uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180175e26
// Address: 0x180175e26
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180175db0(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined *puVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar4 = *(int64_t *)arg1;
    if (iVar4 != 0) {
        iVar1 = *(int64_t *)(arg1 + 8);
        for (; iVar4 != iVar1; iVar4 = iVar4 + 0xc0) {
            func_0x000180175e80(iVar4);
        }
        uVar6 = *(uint64_t *)arg1;
        uVar3 = uVar6;
        puVar5 = auStack_28;
        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar6) / 0xc0) * 0xc0)) {
            uVar3 = *(uint64_t *)(uVar6 - 8);
            uVar6 = (uVar6 - uVar3) - 8;
            puVar5 = auStack_28;
            if (0x1f < uVar6) {
                pcVar2 = (code *)swi(0x29);
                uVar3 = uVar6;
                (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x180175e4c;
        fcn.180459c3c(uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180175e80
// Address: 0x180175e80
// Size: 117 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180175e80(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    func_0x000180015170(arg1 + 0xb0, arg1 + 0xb0, *(undefined8 *)(*(int64_t *)(arg1 + 0xb0) + 8));
    fcn.180459c3c(*(undefined8 *)(arg1 + 0xb0), 0x60);
    fcn.180004e40(arg1 + 0x80);
    fcn.180004e40(arg1 + 0x60);
    fcn.180004e40(arg1 + 0x40);
    fcn.180004e40(arg1 + 0x20);
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar1 = *(int64_t *)arg1;
        iVar3 = iVar1;
        puVar4 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg1 + 0x18) + 1) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_28, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180004e88;
        fcn.180459c3c(iVar3);
    }
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    return;
}

// ============================================================
// Function: FUN_180175f00
// Address: 0x180175f00
// Size: 234 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_67h
// WARNING: [rz-ghidra] Detected overlap for variable var_63h
// WARNING: [rz-ghidra] Detected overlap for variable var_61h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h

void fcn.180175f00(int64_t arg1)
{
    int64_t *piVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    uint64_t arg2;
    int64_t unaff_RBX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t in_stack_00000010;
    int64_t in_stack_00000018;
    int64_t in_stack_00000030;
    
    *(undefined8 *)arg1 = 0x1804a6098;
    func_0x000180015170(arg1 + 0xd0, arg1 + 0xd0, *(undefined8 *)(*(int64_t *)(arg1 + 0xd0) + 8));
    fcn.180459c3c(*(undefined8 *)(arg1 + 0xd0), 0x60);
    fcn.180174530(in_stack_00000010, in_stack_00000018, in_stack_00000030);
    fcn.180459c3c(*(undefined8 *)(arg1 + 0xc0), 0x80);
    arg2 = (uint64_t)*(uint8_t *)(arg1 + 0xb0);
    fcn.180178f50(arg1 + 0xb8);
    piVar1 = *(int64_t **)(arg1 + 0x90);
    if (piVar1 != (int64_t *)0x0) {
        arg2 = CONCAT71((unkint7)(arg2 >> 8), piVar1 != (int64_t *)(arg1 + 0x58));
        (**(code **)(*piVar1 + 0x20))();
        *(undefined8 *)(arg1 + 0x90) = 0;
    }
    fcn.180004e40(arg1 + 0x38);
    fcn.180175db0(arg1 + 0x20, arg2, unaff_RBX);
    func_0x000180015170(arg1 + 0x10, arg1 + 0x10, *(undefined8 *)(*(int64_t *)(arg1 + 0x10) + 8));
    if ((*(int64_t *)(arg1 + 0x10) != 0) &&
       (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)(arg1 + 0x10), in_R9, unaff_RBX),
       iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar4 = (undefined4 *)fcn.18046b77c();
        *puVar4 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_180175ff0
// Address: 0x180175ff0
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 * fcn.180175ff0(int64_t arg1, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 *in_RAX;
    undefined4 *puVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    int64_t arg1_00;
    undefined *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar6 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return in_RAX;
    }
    iVar1 = *(int64_t *)(arg1 + 0x20);
    for (arg1_00 = *(int64_t *)(arg1 + 0x18); arg1_00 != iVar1; arg1_00 = arg1_00 + 0xc0) {
        fcn.180175e80(arg1_00);
    }
    puVar5 = *(undefined4 **)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0xc0)) {
        puVar4 = *(undefined4 **)(puVar5 + -2);
        if ((uint64_t)((int64_t)puVar5 + (-8 - (int64_t)puVar4)) < 0x20) goto code_r0x0001800f4640;
        puVar5 = (undefined4 *)0x5;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)();
        puVar6 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar6 + 0x28);
    puVar4 = puVar5;
code_r0x0001800f4640:
    if (puVar4 != (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        puVar4 = (undefined4 *)(*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, puVar4);
        if ((int32_t)puVar4 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return puVar4;
}

// ============================================================
// Function: FUN_180176004
// Address: 0x180176004
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 * fcn.180175ff0(int64_t arg1, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 *in_RAX;
    undefined4 *puVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    int64_t arg1_00;
    undefined *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar6 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return in_RAX;
    }
    iVar1 = *(int64_t *)(arg1 + 0x20);
    for (arg1_00 = *(int64_t *)(arg1 + 0x18); arg1_00 != iVar1; arg1_00 = arg1_00 + 0xc0) {
        fcn.180175e80(arg1_00);
    }
    puVar5 = *(undefined4 **)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0xc0)) {
        puVar4 = *(undefined4 **)(puVar5 + -2);
        if ((uint64_t)((int64_t)puVar5 + (-8 - (int64_t)puVar4)) < 0x20) goto code_r0x0001800f4640;
        puVar5 = (undefined4 *)0x5;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)();
        puVar6 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar6 + 0x28);
    puVar4 = puVar5;
code_r0x0001800f4640:
    if (puVar4 != (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        puVar4 = (undefined4 *)(*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, puVar4);
        if ((int32_t)puVar4 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return puVar4;
}

// ============================================================
// Function: FUN_180176057
// Address: 0x180176057
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 * fcn.180175ff0(int64_t arg1, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 *in_RAX;
    undefined4 *puVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    int64_t arg1_00;
    undefined *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar6 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return in_RAX;
    }
    iVar1 = *(int64_t *)(arg1 + 0x20);
    for (arg1_00 = *(int64_t *)(arg1 + 0x18); arg1_00 != iVar1; arg1_00 = arg1_00 + 0xc0) {
        fcn.180175e80(arg1_00);
    }
    puVar5 = *(undefined4 **)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0xc0)) {
        puVar4 = *(undefined4 **)(puVar5 + -2);
        if ((uint64_t)((int64_t)puVar5 + (-8 - (int64_t)puVar4)) < 0x20) goto code_r0x0001800f4640;
        puVar5 = (undefined4 *)0x5;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)();
        puVar6 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar6 + 0x28);
    puVar4 = puVar5;
code_r0x0001800f4640:
    if (puVar4 != (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        puVar4 = (undefined4 *)(*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, puVar4);
        if ((int32_t)puVar4 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return puVar4;
}

// ============================================================
// Function: FUN_1801760a0
// Address: 0x1801760a0
// Size: 55 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001801760bc: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001801760c1)
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801760a0(int64_t arg1)
{
    int64_t var_8h;
    
    *(undefined8 *)(arg1 + 0x20) = 0x1804a5358;
    if (*(char *)(arg1 + 0x30) != '\0') {
        fcn.180460d90(*(undefined8 *)(arg1 + 0x28));
    }
    *(undefined *)(arg1 + 0x30) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0;
    return;
}

// ============================================================
// Function: FUN_1801760e0
// Address: 0x1801760e0
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1801760e0(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    fcn.180175f00(arg1);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0xe0);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180176120
// Address: 0x180176120
// Size: 173 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180176120(int64_t arg1, int64_t arg2)
{
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t var_10h;
    
    fcn.180004e40(arg1 + 0x180);
    fcn.180015170(unaff_RBX);
    fcn.180459c3c(*(undefined8 *)(arg1 + 0x170), 0x60);
    fcn.180004e40(arg1 + 0x150);
    fcn.180004e40(arg1 + 0x128);
    fcn.180004e40(arg1 + 0x108);
    fcn.180004e40(arg1 + 0xe8);
    fcn.180175f00(arg1);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x1b8);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1801761d0
// Address: 0x1801761d0
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1801761d0(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    fcn.180175f00(arg1);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0xe8);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180176210
// Address: 0x180176210
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180176210(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)(arg1 + 0x20) = 0x1804a5358;
    fcn.18045b56c(arg1 + 0x28);
    *(undefined8 *)arg1 = 0x1804a5358;
    fcn.18045b56c(arg1 + 8);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x38);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180176270
// Address: 0x180176270
// Size: 208 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180176270(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    char in_R8B;
    char in_R9B;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    if (in_R8B != '\0') {
        func_0x000180176b40();
    }
    iVar1 = *(int64_t *)(arg2 + 0x10);
    if (*(uint64_t *)(arg2 + 0x18) - iVar1 < 2) {
        func_0x00018000ee80(arg2, 2, 0, 0x180644f68, 2);
    } else {
        *(int64_t *)(arg2 + 0x10) = iVar1 + 2;
        if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
            *(undefined2 *)(iVar1 + arg2) = 0xa0d;
            *(undefined *)(iVar1 + 2 + arg2) = 0;
        } else {
            iVar2 = *(int64_t *)arg2;
            *(undefined2 *)(iVar1 + iVar2) = 0xa0d;
            *(undefined *)(iVar1 + 2 + iVar2) = 0;
        }
    }
    if (in_R9B != '\0') {
        func_0x0001801767f0(arg1, arg2);
    }
    return arg2;
}

// ============================================================
// Function: FUN_180176340
// Address: 0x180176340
// Size: 549 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_1b4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.180176340(int64_t arg1, int64_t arg2, int64_t arg_e0h, int64_t arg_e8h, int64_t arg_150h, int64_t arg_160h)
{
    uint16_t uVar1;
    uint16_t uVar2;
    uint64_t uVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined8 uVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t iVar12;
    undefined *puVar13;
    char in_R8B;
    char in_R9B;
    undefined8 *puVar14;
    int64_t var_eh;
    int64_t var_18h;
    undefined auStackY_a8 [8];
    undefined auStackY_a0 [24];
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar13 = auStackY_a8;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_a8;
    var_78h._0_4_ = 0;
    var_70h = arg2;
    func_0x0001801787a0();
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    var_78h._0_4_ = 1;
    fcn.18000b240(var_68h);
    puVar14 = (undefined8 *)(arg1 + 0xe8);
    if ((*(uint8_t *)(arg1 + 0x1b4) & 2) == 0) {
        puVar14 = (undefined8 *)(arg1 + 0x150);
    }
    if (0xf < (uint64_t)puVar14[3]) {
        puVar14 = (undefined8 *)*puVar14;
    }
    uVar1 = *(uint16_t *)(arg1 + 0xe);
    uVar2 = *(uint16_t *)(arg1 + 0xc);
    uVar8 = func_0x0001801877f0(*(undefined4 *)(arg1 + 0xe0));
    var_80h._0_4_ = (uint32_t)uVar1;
    var_88h._0_4_ = (uint32_t)uVar2;
    puVar9 = (undefined4 *)func_0x0001801858c0(&var_68h, 0x1804a63f8, uVar8, puVar14);
    if ((undefined4 *)arg2 == puVar9) {
code_r0x00018017647e:
        if ((uint64_t)var_50h < 0x10) goto code_r0x0001801764c0;
        puVar13 = auStackY_a8;
        if ((0xfff < var_50h + 1U) &&
           (iVar10 = var_68h - *(int64_t *)(var_68h + -8), var_68h = *(int64_t *)(var_68h + -8), puVar13 = auStackY_a8,
           0x1f < iVar10 - 8U)) goto code_r0x0001801764b1;
    } else {
        uVar3 = *(uint64_t *)(arg2 + 0x18);
        if (uVar3 < 0x10) {
code_r0x000180176452:
            *(undefined8 *)(arg2 + 0x10) = 0;
            *(undefined8 *)(arg2 + 0x18) = 0xf;
            *(undefined *)arg2 = 0;
            uVar5 = puVar9[1];
            uVar6 = puVar9[2];
            uVar7 = puVar9[3];
            *(undefined4 *)arg2 = *puVar9;
            *(undefined4 *)(arg2 + 4) = uVar5;
            *(undefined4 *)(arg2 + 8) = uVar6;
            *(undefined4 *)(arg2 + 0xc) = uVar7;
            uVar5 = puVar9[5];
            uVar6 = puVar9[6];
            uVar7 = puVar9[7];
            *(undefined4 *)(arg2 + 0x10) = puVar9[4];
            *(undefined4 *)(arg2 + 0x14) = uVar5;
            *(undefined4 *)(arg2 + 0x18) = uVar6;
            *(undefined4 *)(arg2 + 0x1c) = uVar7;
            *(undefined8 *)(puVar9 + 4) = 0;
            *(undefined8 *)(puVar9 + 6) = 0xf;
            *(undefined *)puVar9 = 0;
            goto code_r0x00018017647e;
        }
        iVar10 = *(int64_t *)arg2;
        uVar11 = uVar3 + 1;
        if (uVar11 < 0x1000) {
code_r0x00018017644d:
            fcn.180459c3c(iVar10, uVar11);
            goto code_r0x000180176452;
        }
        if ((iVar10 - *(int64_t *)(iVar10 + -8)) - 8U < 0x20) {
            uVar11 = uVar3 + 0x28;
            iVar10 = *(int64_t *)(iVar10 + -8);
            goto code_r0x00018017644d;
        }
code_r0x0001801764b1:
        pcVar4 = (code *)swi(0x29);
        var_68h = (*pcVar4)(5);
        puVar13 = auStackY_a0;
    }
    *(undefined8 *)(puVar13 + -8) = 0x1801764c0;
    fcn.180459c3c(var_68h);
code_r0x0001801764c0:
    if (in_R8B != '\0') {
        *(undefined8 *)(puVar13 + -8) = 0x1801764d0;
        func_0x000180176b40(arg1, arg2);
    }
    iVar10 = *(int64_t *)(arg2 + 0x10);
    if (*(uint64_t *)(arg2 + 0x18) - iVar10 < 2) {
        *(undefined8 *)(puVar13 + 0x20) = 2;
        *(undefined8 *)(puVar13 + -8) = 0x18017652c;
        func_0x00018000ee80(arg2, 2, 0, 0x180644f68);
    } else {
        *(int64_t *)(arg2 + 0x10) = iVar10 + 2;
        iVar12 = arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            iVar12 = *(int64_t *)arg2;
        }
        *(undefined2 *)(iVar10 + iVar12) = 0xa0d;
        *(undefined *)(iVar10 + 2 + iVar12) = 0;
    }
    if (in_R9B != '\0') {
        *(undefined8 *)(puVar13 + -8) = 0x18017653c;
        func_0x0001801767f0(arg1, arg2);
    }
    *(undefined8 *)(puVar13 + -8) = 0x18017654c;
    func_0x000180459870(*(uint64_t *)(puVar13 + 0x60) ^ (uint64_t)puVar13);
    return;
}

// ============================================================
// Function: FUN_180176570
// Address: 0x180176570
// Size: 635 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_188h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

void fcn.180176570(int64_t arg1, int64_t arg2)
{
    uint16_t uVar1;
    undefined2 uVar2;
    undefined4 uVar3;
    code *pcVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined *puVar10;
    undefined *puVar11;
    char in_R8B;
    char in_R9B;
    int64_t var_18h;
    undefined auStackY_1c8 [8];
    undefined auStackY_1c0 [24];
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_168h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_48h;
    
    puVar10 = auStackY_1c8;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_1c8;
    var_188h._0_4_ = 0;
    var_180h = arg2;
    func_0x0001804986e0(&var_148h, 0, 0x100);
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    var_188h._0_4_ = 1;
    fcn.18000b240(CONCAT44(var_188h._4_4_, 1));
    uVar3 = *(undefined4 *)(arg1 + 0xe0);
    uVar1 = *(uint16_t *)(arg1 + 0xe);
    uVar2 = *(undefined2 *)(arg1 + 0xc);
    var_198h = func_0x0001801879b0(uVar3);
    var_1a8h._0_4_ = (uint32_t)uVar1;
    var_1a0h._0_4_ = uVar3;
    func_0x000180065f60(&var_148h, 0x100, 0x1804a6410, uVar2);
    uVar5 = fcn.180498cd0(&var_148h);
    func_0x00018000f180(arg2, &var_148h, uVar5);
    puVar11 = auStackY_1c8;
    if (in_R8B != '\0') {
        var_158h = 4;
        var_150h = 0xf;
        stack0xfffffffffffffe9d = SUB1611(ZEXT816(0), 5);
        var_168h._0_5_ = 0x65746144;
        if (*(char *)0x18077e0c0 == '\0') {
            uVar5 = func_0x000180467bd4(0);
            piVar6 = (int64_t *)func_0x000180014c60(arg1 + 0x10, &var_178h, &var_168h);
            iVar8 = *piVar6;
            uVar5 = func_0x0001801892a0(uVar5, &var_148h);
            uVar7 = fcn.180498cd0(uVar5);
            func_0x00018000f180(iVar8 + 0x40, uVar5, uVar7);
        } else {
            piVar6 = (int64_t *)func_0x000180014c60(arg1 + 0x10, &var_178h, &var_168h);
            iVar8 = *piVar6;
            uVar5 = fcn.180498cd0(0x18077e0c0);
            func_0x00018000f180(iVar8 + 0x40, 0x18077e0c0, uVar5);
        }
        if (0xf < (uint64_t)var_150h) {
            iVar8 = var_168h;
            puVar10 = auStackY_1c8;
            if ((0xfff < var_150h + 1U) &&
               (iVar8 = *(int64_t *)(var_168h + -8), puVar10 = auStackY_1c8, 0x1f < (var_168h - iVar8) - 8U)) {
                pcVar4 = (code *)swi(0x29);
                iVar8 = (*pcVar4)(5);
                puVar10 = auStackY_1c0;
            }
            *(undefined8 *)(puVar10 + -8) = 0x180176746;
            fcn.180459c3c(iVar8);
        }
        *(undefined8 *)(puVar10 + -8) = 0x180176751;
        func_0x000180176b40(arg1, arg2);
        puVar11 = puVar10;
    }
    iVar8 = *(int64_t *)(arg2 + 0x10);
    if (*(uint64_t *)(arg2 + 0x18) - iVar8 < 2) {
        *(undefined8 *)(puVar11 + 0x20) = 2;
        *(undefined8 *)(puVar11 + -8) = 0x1801767ad;
        func_0x00018000ee80(arg2, 2, 0, 0x180644f68);
    } else {
        *(int64_t *)(arg2 + 0x10) = iVar8 + 2;
        iVar9 = arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            iVar9 = *(int64_t *)arg2;
        }
        *(undefined2 *)(iVar8 + iVar9) = 0xa0d;
        *(undefined *)(iVar8 + 2 + iVar9) = 0;
    }
    if (in_R9B != '\0') {
        *(undefined8 *)(puVar11 + -8) = 0x1801767bd;
        func_0x0001801767f0(arg1, arg2);
    }
    *(undefined8 *)(puVar11 + -8) = 0x1801767cf;
    func_0x000180459870(var_48h ^ (uint64_t)puVar11);
    return;
}

