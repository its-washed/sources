// Chunk 112 - 50 functions

// ============================================================
// Function: FUN_180183a50
// Address: 0x180183a50
// Size: 58 bytes
// ============================================================
void fcn.180183a50(int64_t arg1)
{
    int64_t var_8h;
    
    if (((*(uint8_t *)(arg1 + 0x50) & 1) != 0) && ((*(uint8_t *)(arg1 + 0x54) & 1) != 0)) {
        if ((*(uint8_t *)(arg1 + 0x3c) & 0x40) == 0) {
            func_0x0001801843a0();
        } else {
            func_0x000180184000();
        }
    }
    if (((*(uint8_t *)(arg1 + 0x50) & 4) != 0) && ((*(uint8_t *)(arg1 + 0x54) & 4) != 0)) {
        (*(code *)0x699f1c)(arg1 + 200);
        if (*(int64_t *)(arg1 + 0xb0) == 0) {
            func_0x000180181d70(arg1, 4);
        }
        (*(code *)0x699f34)(arg1 + 200);
        if ((char)*(uint32_t *)(arg1 + 0x3c) < '\0') {
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xffffff7f;
            func_0x0001801841d0();
            *(undefined4 *)(arg1 + 0x54) = 0;
            return;
        }
        func_0x000180184520(arg1);
    }
    *(undefined4 *)(arg1 + 0x54) = 0;
    return;
}

// ============================================================
// Function: FUN_180183a8a
// Address: 0x180183a8a
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180183a50(int64_t arg1)
{
    int64_t var_8h;
    
    if (((*(uint8_t *)(arg1 + 0x50) & 1) != 0) && ((*(uint8_t *)(arg1 + 0x54) & 1) != 0)) {
        if ((*(uint8_t *)(arg1 + 0x3c) & 0x40) == 0) {
            func_0x0001801843a0();
        } else {
            func_0x000180184000();
        }
    }
    if (((*(uint8_t *)(arg1 + 0x50) & 4) != 0) && ((*(uint8_t *)(arg1 + 0x54) & 4) != 0)) {
        (*(code *)0x699f1c)(arg1 + 200);
        if (*(int64_t *)(arg1 + 0xb0) == 0) {
            func_0x000180181d70(arg1, 4);
        }
        (*(code *)0x699f34)(arg1 + 200);
        if ((char)*(uint32_t *)(arg1 + 0x3c) < '\0') {
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xffffff7f;
            func_0x0001801841d0();
            *(undefined4 *)(arg1 + 0x54) = 0;
            return;
        }
        func_0x000180184520(arg1);
    }
    *(undefined4 *)(arg1 + 0x54) = 0;
    return;
}

// ============================================================
// Function: FUN_180183ac8
// Address: 0x180183ac8
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180183a50(int64_t arg1)
{
    int64_t var_8h;
    
    if (((*(uint8_t *)(arg1 + 0x50) & 1) != 0) && ((*(uint8_t *)(arg1 + 0x54) & 1) != 0)) {
        if ((*(uint8_t *)(arg1 + 0x3c) & 0x40) == 0) {
            func_0x0001801843a0();
        } else {
            func_0x000180184000();
        }
    }
    if (((*(uint8_t *)(arg1 + 0x50) & 4) != 0) && ((*(uint8_t *)(arg1 + 0x54) & 4) != 0)) {
        (*(code *)0x699f1c)(arg1 + 200);
        if (*(int64_t *)(arg1 + 0xb0) == 0) {
            func_0x000180181d70(arg1, 4);
        }
        (*(code *)0x699f34)(arg1 + 200);
        if ((char)*(uint32_t *)(arg1 + 0x3c) < '\0') {
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xffffff7f;
            func_0x0001801841d0();
            *(undefined4 *)(arg1 + 0x54) = 0;
            return;
        }
        func_0x000180184520(arg1);
    }
    *(undefined4 *)(arg1 + 0x54) = 0;
    return;
}

// ============================================================
// Function: FUN_180183b00
// Address: 0x180183b00
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

undefined8 fcn.180183b00(int64_t arg1)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t in_stack_fffffffffffffff0;
    
    if ((*(uint8_t *)(arg1 + 0x3c) & 0x20) != 0) {
        iVar2 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar1 = *(undefined4 *)(arg1 + 0x48);
        uVar3 = fcn.1801723e0(in_stack_fffffffffffffff0);
        fcn.180172b00(uVar3, 4, 0x1804a79d8, uVar1, iVar2 + 1, 0x1e1, 0x1804a79c8);
        return 0xffffffff;
    }
    fcn.180181c40(arg1, fcn.180183a50, 1);
    if (((*(uint64_t *)(arg1 + 0x88) < *(uint64_t *)(arg1 + 0x90)) && (*(int64_t *)(arg1 + 0x178) == 0)) &&
       (*(int32_t *)(arg1 + 0x98) == 0)) {
        fcn.180173d60(arg1);
    }
    return 0;
}

// ============================================================
// Function: FUN_180183b14
// Address: 0x180183b14
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

undefined8 fcn.180183b00(int64_t arg1)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t in_stack_fffffffffffffff0;
    
    if ((*(uint8_t *)(arg1 + 0x3c) & 0x20) != 0) {
        iVar2 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar1 = *(undefined4 *)(arg1 + 0x48);
        uVar3 = fcn.1801723e0(in_stack_fffffffffffffff0);
        fcn.180172b00(uVar3, 4, 0x1804a79d8, uVar1, iVar2 + 1, 0x1e1, 0x1804a79c8);
        return 0xffffffff;
    }
    fcn.180181c40(arg1, fcn.180183a50, 1);
    if (((*(uint64_t *)(arg1 + 0x88) < *(uint64_t *)(arg1 + 0x90)) && (*(int64_t *)(arg1 + 0x178) == 0)) &&
       (*(int32_t *)(arg1 + 0x98) == 0)) {
        fcn.180173d60(arg1);
    }
    return 0;
}

// ============================================================
// Function: FUN_180183b71
// Address: 0x180183b71
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

undefined8 fcn.180183b00(int64_t arg1)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t in_stack_fffffffffffffff0;
    
    if ((*(uint8_t *)(arg1 + 0x3c) & 0x20) != 0) {
        iVar2 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar1 = *(undefined4 *)(arg1 + 0x48);
        uVar3 = fcn.1801723e0(in_stack_fffffffffffffff0);
        fcn.180172b00(uVar3, 4, 0x1804a79d8, uVar1, iVar2 + 1, 0x1e1, 0x1804a79c8);
        return 0xffffffff;
    }
    fcn.180181c40(arg1, fcn.180183a50, 1);
    if (((*(uint64_t *)(arg1 + 0x88) < *(uint64_t *)(arg1 + 0x90)) && (*(int64_t *)(arg1 + 0x178) == 0)) &&
       (*(int32_t *)(arg1 + 0x98) == 0)) {
        fcn.180173d60(arg1);
    }
    return 0;
}

// ============================================================
// Function: FUN_180183bd0
// Address: 0x180183bd0
// Size: 509 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int32_t fcn.180183bd0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined4 uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t unaff_R15;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if ((*(uint8_t *)(arg1 + 0x3c) & 0x20) != 0) {
        iVar6 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar1 = *(undefined4 *)(arg1 + 0x48);
        uVar7 = fcn.1801723e0(var_50h);
        fcn.180172b00(uVar7, 4, 0x1804a7a20, uVar1, iVar6 + 1, 0x1ef, 0x1804a7a10);
        return -1;
    }
    iVar4 = 0;
    (*(code *)0x699f1c)(arg1 + 200);
    if (*(int64_t *)(arg1 + 0xb0) == 0) {
        iVar4 = fcn.180183630(unaff_R15);
        if (-1 < iVar4) {
            if (iVar4 == arg3) goto code_r0x000180183fb0;
            if ((iVar4 == 0) && ((*(uint32_t *)(arg1 + 0x40) & 0xff00000) != 0)) goto code_r0x000180183d99;
code_r0x000180183d0d:
            fcn.180181c40(arg1, fcn.180183a50, 4);
            goto code_r0x000180183d22;
        }
        iVar5 = (*(code *)0x800000000000006f)();
        if ((iVar5 == 0x2733) || (iVar5 == 0x2714)) {
            iVar4 = 0;
            iVar6 = fcn.18045b9a8(0x1804a77e0, 0x5c);
            uVar7 = fcn.1801723e0(var_50h);
            fcn.180172b00(uVar7, 3, 0x1804a7a58, iVar6 + 1, 0x203, 0x1804a7a10);
            goto code_r0x000180183d0d;
        }
code_r0x000180183d96:
        *(int32_t *)(arg1 + 0x4c) = iVar5;
code_r0x000180183d99:
        (*(code *)0x699f34)(arg1 + 200);
        if ((*(uint32_t *)(arg1 + 0x40) & 0xff00000) != 0) {
            fcn.180181d00(arg1);
        }
        if (-1 < iVar4) {
            return -1;
        }
        return iVar4;
    }
code_r0x000180183d22:
    uVar9 = (uint64_t)iVar4;
    if ((uint64_t)arg3 <= uVar9) goto code_r0x000180183fb0;
    uVar10 = arg3 - uVar9;
    if ((uint64_t)*(uint32_t *)(arg1 + 0xf4) < *(uint32_t *)(arg1 + 0xf0) + uVar10) {
        iVar6 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar1 = *(undefined4 *)(arg1 + 0xf4);
        uVar7 = fcn.1801723e0(var_50h);
        fcn.180172b00(uVar7, 4, 0x1804a7a80, uVar1, iVar6 + 1, 0x217, 0x1804a7a10);
        iVar5 = 0x3fe;
        goto code_r0x000180183d96;
    }
    if (((*(uint32_t *)(arg1 + 0x40) & 0xfff00) == 0) || (arg4 == 0)) {
        iVar6 = fcn.1801813b0(uVar10);
        iVar11 = 0;
        var_8h = uVar10;
        if (arg4 != 0) goto code_r0x000180183e18;
    } else {
        iVar5 = fcn.180184b50(arg4);
        iVar11 = (int64_t)iVar5;
        iVar6 = fcn.1801813b0(iVar11 + uVar10);
        var_8h = iVar11 + uVar10;
code_r0x000180183e18:
        if (iVar11 != 0) {
            fcn.180498030(iVar6, arg4, iVar11);
        }
    }
    fcn.180498030(iVar11 + iVar6, arg2 + uVar9, uVar10);
    if (*(int64_t *)(arg1 + 0xb8) == 0) {
        *(undefined8 *)(arg1 + 0xc0) = 0;
        *(undefined8 *)(arg1 + 0xb0) = 0;
        *(undefined8 *)(arg1 + 0xb8) = 4;
        uVar7 = fcn.1801813b0(0x60);
        *(undefined8 *)(arg1 + 0xa8) = uVar7;
    }
    iVar3 = *(int64_t *)(arg1 + 0xb8);
    iVar8 = *(int64_t *)(arg1 + 0xb0);
    if (iVar8 == iVar3) {
        iVar5 = (int32_t)iVar3 * 2;
        if (iVar5 == 0) {
            iVar5 = 0x10;
        }
        uVar7 = fcn.180181320(*(undefined8 *)(arg1 + 0xa8), (int64_t)iVar5 * 0x18, iVar3 * 0x18);
        *(undefined8 *)(arg1 + 0xa8) = uVar7;
        *(int64_t *)(arg1 + 0xb8) = (int64_t)iVar5;
    } else if (*(int64_t *)(arg1 + 0xc0) + iVar8 == iVar3) {
        fcn.180498030(*(int64_t *)(arg1 + 0xa8), *(int64_t *)(arg1 + 0xa8) + *(int64_t *)(arg1 + 0xc0) * 0x18, 
                      iVar8 * 0x18);
        *(undefined8 *)(arg1 + 0xc0) = 0;
    }
    iVar8 = *(int64_t *)(arg1 + 0xb0) + *(int64_t *)(arg1 + 0xc0);
    iVar3 = *(int64_t *)(arg1 + 0xa8);
    *(int64_t *)(iVar3 + iVar8 * 0x18) = iVar6;
    *(int64_t *)(iVar3 + 8 + iVar8 * 0x18) = var_8h;
    *(int64_t *)(iVar3 + 0x10 + iVar8 * 0x18) = iVar11;
    *(int64_t *)(arg1 + 0xb0) = *(int64_t *)(arg1 + 0xb0) + 1;
    *(int32_t *)(arg1 + 0xf0) = *(int32_t *)(arg1 + 0xf0) + (int32_t)uVar10;
    if (0x800000 < *(uint32_t *)(arg1 + 0xf0)) {
        iVar6 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar2 = *(uint32_t *)(arg1 + 0xf0);
        uVar7 = fcn.1801723e0(var_50h);
        var_60h = (int64_t)uVar2;
        var_68h = uVar10 & 0xffffffff;
        fcn.180172b00(uVar7, 3, 0x1804a7ab0, arg3 & 0xffffffff, var_68h, var_60h, 0x800000, iVar6 + 1, 0x232, 
                      0x1804a7a10);
    }
code_r0x000180183fb0:
    (*(code *)0x699f34)(arg1 + 200);
    if (0 < iVar4) {
        *(undefined8 *)(arg1 + 0x70) = *(undefined8 *)(*(int64_t *)arg1 + 0x20);
        fcn.180174330(arg1, arg2, iVar4);
    }
    return iVar4;
}

// ============================================================
// Function: FUN_180183dcd
// Address: 0x180183dcd
// Size: 378 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int32_t fcn.180183bd0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined4 uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t unaff_R15;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if ((*(uint8_t *)(arg1 + 0x3c) & 0x20) != 0) {
        iVar6 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar1 = *(undefined4 *)(arg1 + 0x48);
        uVar7 = fcn.1801723e0(var_50h);
        fcn.180172b00(uVar7, 4, 0x1804a7a20, uVar1, iVar6 + 1, 0x1ef, 0x1804a7a10);
        return -1;
    }
    iVar4 = 0;
    (*(code *)0x699f1c)(arg1 + 200);
    if (*(int64_t *)(arg1 + 0xb0) == 0) {
        iVar4 = fcn.180183630(unaff_R15);
        if (-1 < iVar4) {
            if (iVar4 == arg3) goto code_r0x000180183fb0;
            if ((iVar4 == 0) && ((*(uint32_t *)(arg1 + 0x40) & 0xff00000) != 0)) goto code_r0x000180183d99;
code_r0x000180183d0d:
            fcn.180181c40(arg1, fcn.180183a50, 4);
            goto code_r0x000180183d22;
        }
        iVar5 = (*(code *)0x800000000000006f)();
        if ((iVar5 == 0x2733) || (iVar5 == 0x2714)) {
            iVar4 = 0;
            iVar6 = fcn.18045b9a8(0x1804a77e0, 0x5c);
            uVar7 = fcn.1801723e0(var_50h);
            fcn.180172b00(uVar7, 3, 0x1804a7a58, iVar6 + 1, 0x203, 0x1804a7a10);
            goto code_r0x000180183d0d;
        }
code_r0x000180183d96:
        *(int32_t *)(arg1 + 0x4c) = iVar5;
code_r0x000180183d99:
        (*(code *)0x699f34)(arg1 + 200);
        if ((*(uint32_t *)(arg1 + 0x40) & 0xff00000) != 0) {
            fcn.180181d00(arg1);
        }
        if (-1 < iVar4) {
            return -1;
        }
        return iVar4;
    }
code_r0x000180183d22:
    uVar9 = (uint64_t)iVar4;
    if ((uint64_t)arg3 <= uVar9) goto code_r0x000180183fb0;
    uVar10 = arg3 - uVar9;
    if ((uint64_t)*(uint32_t *)(arg1 + 0xf4) < *(uint32_t *)(arg1 + 0xf0) + uVar10) {
        iVar6 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar1 = *(undefined4 *)(arg1 + 0xf4);
        uVar7 = fcn.1801723e0(var_50h);
        fcn.180172b00(uVar7, 4, 0x1804a7a80, uVar1, iVar6 + 1, 0x217, 0x1804a7a10);
        iVar5 = 0x3fe;
        goto code_r0x000180183d96;
    }
    if (((*(uint32_t *)(arg1 + 0x40) & 0xfff00) == 0) || (arg4 == 0)) {
        iVar6 = fcn.1801813b0(uVar10);
        iVar11 = 0;
        var_8h = uVar10;
        if (arg4 != 0) goto code_r0x000180183e18;
    } else {
        iVar5 = fcn.180184b50(arg4);
        iVar11 = (int64_t)iVar5;
        iVar6 = fcn.1801813b0(iVar11 + uVar10);
        var_8h = iVar11 + uVar10;
code_r0x000180183e18:
        if (iVar11 != 0) {
            fcn.180498030(iVar6, arg4, iVar11);
        }
    }
    fcn.180498030(iVar11 + iVar6, arg2 + uVar9, uVar10);
    if (*(int64_t *)(arg1 + 0xb8) == 0) {
        *(undefined8 *)(arg1 + 0xc0) = 0;
        *(undefined8 *)(arg1 + 0xb0) = 0;
        *(undefined8 *)(arg1 + 0xb8) = 4;
        uVar7 = fcn.1801813b0(0x60);
        *(undefined8 *)(arg1 + 0xa8) = uVar7;
    }
    iVar3 = *(int64_t *)(arg1 + 0xb8);
    iVar8 = *(int64_t *)(arg1 + 0xb0);
    if (iVar8 == iVar3) {
        iVar5 = (int32_t)iVar3 * 2;
        if (iVar5 == 0) {
            iVar5 = 0x10;
        }
        uVar7 = fcn.180181320(*(undefined8 *)(arg1 + 0xa8), (int64_t)iVar5 * 0x18, iVar3 * 0x18);
        *(undefined8 *)(arg1 + 0xa8) = uVar7;
        *(int64_t *)(arg1 + 0xb8) = (int64_t)iVar5;
    } else if (*(int64_t *)(arg1 + 0xc0) + iVar8 == iVar3) {
        fcn.180498030(*(int64_t *)(arg1 + 0xa8), *(int64_t *)(arg1 + 0xa8) + *(int64_t *)(arg1 + 0xc0) * 0x18, 
                      iVar8 * 0x18);
        *(undefined8 *)(arg1 + 0xc0) = 0;
    }
    iVar8 = *(int64_t *)(arg1 + 0xb0) + *(int64_t *)(arg1 + 0xc0);
    iVar3 = *(int64_t *)(arg1 + 0xa8);
    *(int64_t *)(iVar3 + iVar8 * 0x18) = iVar6;
    *(int64_t *)(iVar3 + 8 + iVar8 * 0x18) = var_8h;
    *(int64_t *)(iVar3 + 0x10 + iVar8 * 0x18) = iVar11;
    *(int64_t *)(arg1 + 0xb0) = *(int64_t *)(arg1 + 0xb0) + 1;
    *(int32_t *)(arg1 + 0xf0) = *(int32_t *)(arg1 + 0xf0) + (int32_t)uVar10;
    if (0x800000 < *(uint32_t *)(arg1 + 0xf0)) {
        iVar6 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar2 = *(uint32_t *)(arg1 + 0xf0);
        uVar7 = fcn.1801723e0(var_50h);
        var_60h = (int64_t)uVar2;
        var_68h = uVar10 & 0xffffffff;
        fcn.180172b00(uVar7, 3, 0x1804a7ab0, arg3 & 0xffffffff, var_68h, var_60h, 0x800000, iVar6 + 1, 0x232, 
                      0x1804a7a10);
    }
code_r0x000180183fb0:
    (*(code *)0x699f34)(arg1 + 200);
    if (0 < iVar4) {
        *(undefined8 *)(arg1 + 0x70) = *(undefined8 *)(*(int64_t *)arg1 + 0x20);
        fcn.180174330(arg1, arg2, iVar4);
    }
    return iVar4;
}

// ============================================================
// Function: FUN_180183f47
// Address: 0x180183f47
// Size: 177 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int32_t fcn.180183bd0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined4 uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t unaff_R15;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if ((*(uint8_t *)(arg1 + 0x3c) & 0x20) != 0) {
        iVar6 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar1 = *(undefined4 *)(arg1 + 0x48);
        uVar7 = fcn.1801723e0(var_50h);
        fcn.180172b00(uVar7, 4, 0x1804a7a20, uVar1, iVar6 + 1, 0x1ef, 0x1804a7a10);
        return -1;
    }
    iVar4 = 0;
    (*(code *)0x699f1c)(arg1 + 200);
    if (*(int64_t *)(arg1 + 0xb0) == 0) {
        iVar4 = fcn.180183630(unaff_R15);
        if (-1 < iVar4) {
            if (iVar4 == arg3) goto code_r0x000180183fb0;
            if ((iVar4 == 0) && ((*(uint32_t *)(arg1 + 0x40) & 0xff00000) != 0)) goto code_r0x000180183d99;
code_r0x000180183d0d:
            fcn.180181c40(arg1, fcn.180183a50, 4);
            goto code_r0x000180183d22;
        }
        iVar5 = (*(code *)0x800000000000006f)();
        if ((iVar5 == 0x2733) || (iVar5 == 0x2714)) {
            iVar4 = 0;
            iVar6 = fcn.18045b9a8(0x1804a77e0, 0x5c);
            uVar7 = fcn.1801723e0(var_50h);
            fcn.180172b00(uVar7, 3, 0x1804a7a58, iVar6 + 1, 0x203, 0x1804a7a10);
            goto code_r0x000180183d0d;
        }
code_r0x000180183d96:
        *(int32_t *)(arg1 + 0x4c) = iVar5;
code_r0x000180183d99:
        (*(code *)0x699f34)(arg1 + 200);
        if ((*(uint32_t *)(arg1 + 0x40) & 0xff00000) != 0) {
            fcn.180181d00(arg1);
        }
        if (-1 < iVar4) {
            return -1;
        }
        return iVar4;
    }
code_r0x000180183d22:
    uVar9 = (uint64_t)iVar4;
    if ((uint64_t)arg3 <= uVar9) goto code_r0x000180183fb0;
    uVar10 = arg3 - uVar9;
    if ((uint64_t)*(uint32_t *)(arg1 + 0xf4) < *(uint32_t *)(arg1 + 0xf0) + uVar10) {
        iVar6 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar1 = *(undefined4 *)(arg1 + 0xf4);
        uVar7 = fcn.1801723e0(var_50h);
        fcn.180172b00(uVar7, 4, 0x1804a7a80, uVar1, iVar6 + 1, 0x217, 0x1804a7a10);
        iVar5 = 0x3fe;
        goto code_r0x000180183d96;
    }
    if (((*(uint32_t *)(arg1 + 0x40) & 0xfff00) == 0) || (arg4 == 0)) {
        iVar6 = fcn.1801813b0(uVar10);
        iVar11 = 0;
        var_8h = uVar10;
        if (arg4 != 0) goto code_r0x000180183e18;
    } else {
        iVar5 = fcn.180184b50(arg4);
        iVar11 = (int64_t)iVar5;
        iVar6 = fcn.1801813b0(iVar11 + uVar10);
        var_8h = iVar11 + uVar10;
code_r0x000180183e18:
        if (iVar11 != 0) {
            fcn.180498030(iVar6, arg4, iVar11);
        }
    }
    fcn.180498030(iVar11 + iVar6, arg2 + uVar9, uVar10);
    if (*(int64_t *)(arg1 + 0xb8) == 0) {
        *(undefined8 *)(arg1 + 0xc0) = 0;
        *(undefined8 *)(arg1 + 0xb0) = 0;
        *(undefined8 *)(arg1 + 0xb8) = 4;
        uVar7 = fcn.1801813b0(0x60);
        *(undefined8 *)(arg1 + 0xa8) = uVar7;
    }
    iVar3 = *(int64_t *)(arg1 + 0xb8);
    iVar8 = *(int64_t *)(arg1 + 0xb0);
    if (iVar8 == iVar3) {
        iVar5 = (int32_t)iVar3 * 2;
        if (iVar5 == 0) {
            iVar5 = 0x10;
        }
        uVar7 = fcn.180181320(*(undefined8 *)(arg1 + 0xa8), (int64_t)iVar5 * 0x18, iVar3 * 0x18);
        *(undefined8 *)(arg1 + 0xa8) = uVar7;
        *(int64_t *)(arg1 + 0xb8) = (int64_t)iVar5;
    } else if (*(int64_t *)(arg1 + 0xc0) + iVar8 == iVar3) {
        fcn.180498030(*(int64_t *)(arg1 + 0xa8), *(int64_t *)(arg1 + 0xa8) + *(int64_t *)(arg1 + 0xc0) * 0x18, 
                      iVar8 * 0x18);
        *(undefined8 *)(arg1 + 0xc0) = 0;
    }
    iVar8 = *(int64_t *)(arg1 + 0xb0) + *(int64_t *)(arg1 + 0xc0);
    iVar3 = *(int64_t *)(arg1 + 0xa8);
    *(int64_t *)(iVar3 + iVar8 * 0x18) = iVar6;
    *(int64_t *)(iVar3 + 8 + iVar8 * 0x18) = var_8h;
    *(int64_t *)(iVar3 + 0x10 + iVar8 * 0x18) = iVar11;
    *(int64_t *)(arg1 + 0xb0) = *(int64_t *)(arg1 + 0xb0) + 1;
    *(int32_t *)(arg1 + 0xf0) = *(int32_t *)(arg1 + 0xf0) + (int32_t)uVar10;
    if (0x800000 < *(uint32_t *)(arg1 + 0xf0)) {
        iVar6 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar2 = *(uint32_t *)(arg1 + 0xf0);
        uVar7 = fcn.1801723e0(var_50h);
        var_60h = (int64_t)uVar2;
        var_68h = uVar10 & 0xffffffff;
        fcn.180172b00(uVar7, 3, 0x1804a7ab0, arg3 & 0xffffffff, var_68h, var_60h, 0x800000, iVar6 + 1, 0x232, 
                      0x1804a7a10);
    }
code_r0x000180183fb0:
    (*(code *)0x699f34)(arg1 + 200);
    if (0 < iVar4) {
        *(undefined8 *)(arg1 + 0x70) = *(undefined8 *)(*(int64_t *)arg1 + 0x20);
        fcn.180174330(arg1, arg2, iVar4);
    }
    return iVar4;
}

// ============================================================
// Function: FUN_180184000
// Address: 0x180184000
// Size: 452 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.180184000(int64_t arg1)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    undefined4 in_stack_ffffffffffffffe0;
    undefined4 in_stack_ffffffffffffffe4;
    
    iVar7 = 0;
    do {
        var_10h._0_4_ = 0x1c;
        iVar2 = (*(code *)0x8000000000000001)
                          ((int64_t)*(int32_t *)(arg1 + 0x48), *(undefined8 *)(arg1 + 0x60), &var_10h);
        if (iVar2 < 0) {
            iVar7 = (*(code *)0x800000000000006f)();
            if (iVar7 == 0x2733) {
                return;
            }
            if (iVar7 == 0x2714) {
                return;
            }
            func_0x00018047208c(0x1804a793c);
code_r0x00018018414c:
            *(int32_t *)(arg1 + 0x4c) = iVar7;
            iVar3 = fcn.18045b9a8(0x1804a77e0, 0x5c);
            uVar1 = *(undefined4 *)(arg1 + 0x48);
            uVar5 = func_0x000180184da0(iVar7);
            uVar6 = fcn.1801723e0(CONCAT44(in_stack_ffffffffffffffe4, in_stack_ffffffffffffffe0));
            fcn.180172b00(uVar6, 4, 0x1804a7958, uVar1, uVar5, iVar7, iVar3 + 1, 0xac, 0x1804a7948);
            return;
        }
        var_10h._0_4_ = 0x1c;
        (*(code *)0x8000000000000006)((int64_t)iVar2, *(undefined8 *)(arg1 + 0x58), &var_10h);
        iVar3 = func_0x000180181e00(*(undefined8 *)arg1, iVar2);
        *(undefined8 *)(iVar3 + 0x110) = *(undefined8 *)(arg1 + 0x110);
        *(undefined8 *)(iVar3 + 0x20) = *(undefined8 *)(arg1 + 0x20);
        if (*(int64_t *)(arg1 + 0x178) != 0) {
            func_0x0001801741e0(iVar3);
        }
        if (*(int32_t *)(arg1 + 0x40) == 0x1000000) {
            if (*(int64_t *)(iVar3 + 0x180) == 0) {
                iVar4 = *(int64_t *)(arg1 + 0x188);
                if ((*(int64_t *)(arg1 + 0x188) == 0) && (iVar4 = *(int64_t *)0x18077e208, *(int64_t *)0x18077e208 == 0)
                   ) {
                    iVar4 = func_0x000180183180(0);
                    *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 0x8000;
                    *(int64_t *)(arg1 + 0x188) = iVar4;
                    if (iVar4 == 0) {
                        iVar7 = 0x411;
                        goto code_r0x00018018414c;
                    }
                }
                iVar4 = func_0x000180183350(iVar4, iVar2);
                if (iVar4 == 0) {
                    iVar7 = 0x412;
                    goto code_r0x00018018414c;
                }
                *(int64_t *)(iVar3 + 0x180) = iVar4;
            }
            func_0x000180173960(iVar3);
            func_0x0001801847b0(iVar3);
        } else {
            func_0x0001801735a0(iVar3);
        }
        iVar7 = iVar7 + 1;
        if (2 < iVar7) {
            return;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1801841d0
// Address: 0x1801841d0
// Size: 196 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.1801841d0(int64_t arg1, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_180h,
                  int64_t arg_188h, int64_t arg_190h)
{
    undefined4 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_8h._0_4_ = 0x1c;
    iVar2 = (*(code *)0x8000000000000005)((int64_t)*(int32_t *)(arg1 + 0x48), *(undefined8 *)(arg1 + 0x60), &var_8h);
    if (iVar2 < 0) {
        uVar3 = (*(code *)0x800000000000006f)();
code_r0x000180184294:
        *(undefined4 *)(arg1 + 0x4c) = uVar3;
        iVar4 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar1 = *(undefined4 *)(arg1 + 0x48);
        uVar5 = func_0x000180184da0(uVar3);
        uVar6 = fcn.1801723e0(CONCAT44(var_30h._4_4_, (undefined4)var_30h));
        fcn.180172b00(uVar6, 3, 0x1804a7998, uVar1, uVar5, uVar3, iVar4 + 1, 0xe2, 0x1804a7988);
        func_0x000180183710(arg1);
        return;
    }
    var_8h._0_4_ = 0x1c;
    (*(code *)0x8000000000000006)((int64_t)*(int32_t *)(arg1 + 0x48), *(undefined8 *)(arg1 + 0x58), &var_8h);
    if (*(int32_t *)(arg1 + 0x40) != 0x1000000) {
        func_0x000180173710(arg1);
        func_0x0001801736b0(arg1);
        return;
    }
    iVar4 = *(int64_t *)(arg1 + 0x180);
    if (iVar4 == 0) {
        iVar4 = *(int64_t *)(arg1 + 0x188);
        if ((*(int64_t *)(arg1 + 0x188) == 0) && (iVar4 = *(int64_t *)0x18077e208, *(int64_t *)0x18077e208 == 0)) {
            iVar4 = func_0x000180183180(0);
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 0x8000;
            *(int64_t *)(arg1 + 0x188) = iVar4;
            if (iVar4 == 0) {
                uVar3 = 0x411;
                goto code_r0x000180184294;
            }
        }
        iVar4 = func_0x000180183350(iVar4, *(undefined4 *)(arg1 + 0x48));
        if (iVar4 == 0) {
            uVar3 = 0x412;
            goto code_r0x000180184294;
        }
        *(int64_t *)(arg1 + 0x180) = iVar4;
    }
    if (*(int64_t *)(arg1 + 400) != 0) {
        func_0x0001801833a0(iVar4);
    }
    func_0x0001801846c0(arg1);
    return;
}

// ============================================================
// Function: FUN_180184294
// Address: 0x180184294
// Size: 154 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.1801841d0(int64_t arg1, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_180h,
                  int64_t arg_188h, int64_t arg_190h)
{
    undefined4 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_8h._0_4_ = 0x1c;
    iVar2 = (*(code *)0x8000000000000005)((int64_t)*(int32_t *)(arg1 + 0x48), *(undefined8 *)(arg1 + 0x60), &var_8h);
    if (iVar2 < 0) {
        uVar3 = (*(code *)0x800000000000006f)();
code_r0x000180184294:
        *(undefined4 *)(arg1 + 0x4c) = uVar3;
        iVar4 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar1 = *(undefined4 *)(arg1 + 0x48);
        uVar5 = func_0x000180184da0(uVar3);
        uVar6 = fcn.1801723e0(CONCAT44(var_30h._4_4_, (undefined4)var_30h));
        fcn.180172b00(uVar6, 3, 0x1804a7998, uVar1, uVar5, uVar3, iVar4 + 1, 0xe2, 0x1804a7988);
        func_0x000180183710(arg1);
        return;
    }
    var_8h._0_4_ = 0x1c;
    (*(code *)0x8000000000000006)((int64_t)*(int32_t *)(arg1 + 0x48), *(undefined8 *)(arg1 + 0x58), &var_8h);
    if (*(int32_t *)(arg1 + 0x40) != 0x1000000) {
        func_0x000180173710(arg1);
        func_0x0001801736b0(arg1);
        return;
    }
    iVar4 = *(int64_t *)(arg1 + 0x180);
    if (iVar4 == 0) {
        iVar4 = *(int64_t *)(arg1 + 0x188);
        if ((*(int64_t *)(arg1 + 0x188) == 0) && (iVar4 = *(int64_t *)0x18077e208, *(int64_t *)0x18077e208 == 0)) {
            iVar4 = func_0x000180183180(0);
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 0x8000;
            *(int64_t *)(arg1 + 0x188) = iVar4;
            if (iVar4 == 0) {
                uVar3 = 0x411;
                goto code_r0x000180184294;
            }
        }
        iVar4 = func_0x000180183350(iVar4, *(undefined4 *)(arg1 + 0x48));
        if (iVar4 == 0) {
            uVar3 = 0x412;
            goto code_r0x000180184294;
        }
        *(int64_t *)(arg1 + 0x180) = iVar4;
    }
    if (*(int64_t *)(arg1 + 400) != 0) {
        func_0x0001801833a0(iVar4);
    }
    func_0x0001801846c0(arg1);
    return;
}

// ============================================================
// Function: FUN_18018432e
// Address: 0x18018432e
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

void fcn.1801841d0(int64_t arg1, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_180h,
                  int64_t arg_188h, int64_t arg_190h)
{
    undefined4 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_8h._0_4_ = 0x1c;
    iVar2 = (*(code *)0x8000000000000005)((int64_t)*(int32_t *)(arg1 + 0x48), *(undefined8 *)(arg1 + 0x60), &var_8h);
    if (iVar2 < 0) {
        uVar3 = (*(code *)0x800000000000006f)();
code_r0x000180184294:
        *(undefined4 *)(arg1 + 0x4c) = uVar3;
        iVar4 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar1 = *(undefined4 *)(arg1 + 0x48);
        uVar5 = func_0x000180184da0(uVar3);
        uVar6 = fcn.1801723e0(CONCAT44(var_30h._4_4_, (undefined4)var_30h));
        fcn.180172b00(uVar6, 3, 0x1804a7998, uVar1, uVar5, uVar3, iVar4 + 1, 0xe2, 0x1804a7988);
        func_0x000180183710(arg1);
        return;
    }
    var_8h._0_4_ = 0x1c;
    (*(code *)0x8000000000000006)((int64_t)*(int32_t *)(arg1 + 0x48), *(undefined8 *)(arg1 + 0x58), &var_8h);
    if (*(int32_t *)(arg1 + 0x40) != 0x1000000) {
        func_0x000180173710(arg1);
        func_0x0001801736b0(arg1);
        return;
    }
    iVar4 = *(int64_t *)(arg1 + 0x180);
    if (iVar4 == 0) {
        iVar4 = *(int64_t *)(arg1 + 0x188);
        if ((*(int64_t *)(arg1 + 0x188) == 0) && (iVar4 = *(int64_t *)0x18077e208, *(int64_t *)0x18077e208 == 0)) {
            iVar4 = func_0x000180183180(0);
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 0x8000;
            *(int64_t *)(arg1 + 0x188) = iVar4;
            if (iVar4 == 0) {
                uVar3 = 0x411;
                goto code_r0x000180184294;
            }
        }
        iVar4 = func_0x000180183350(iVar4, *(undefined4 *)(arg1 + 0x48));
        if (iVar4 == 0) {
            uVar3 = 0x412;
            goto code_r0x000180184294;
        }
        *(int64_t *)(arg1 + 0x180) = iVar4;
    }
    if (*(int64_t *)(arg1 + 400) != 0) {
        func_0x0001801833a0(iVar4);
    }
    func_0x0001801846c0(arg1);
    return;
}

// ============================================================
// Function: FUN_1801843a0
// Address: 0x1801843a0
// Size: 372 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801843a0(int64_t arg1)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar1 = *(int32_t *)(arg1 + 0x40);
    do {
        iVar3 = *(int64_t *)(arg1 + 0x78) + *(int64_t *)(arg1 + 0x90);
        if ((*(uint8_t *)(arg1 + 0x98) & 2) == 0) {
            iVar4 = *(int32_t *)(arg1 + 0x80);
        } else {
            iVar4 = *(int32_t *)(arg1 + 0x9c) + *(int32_t *)(arg1 + 0x88);
        }
        iVar4 = iVar4 - (int32_t)*(int64_t *)(arg1 + 0x90);
        if (((iVar1 == 0x100) || (iVar1 == 0x1000)) || (iVar1 == 0x2000)) {
            var_8h._0_4_ = 0x1c;
            iVar1 = (*(code *)0x8000000000000011)
                              ((int64_t)*(int32_t *)(arg1 + 0x48), iVar3, iVar4, 0, *(undefined8 *)(arg1 + 0x60), 
                               &var_8h);
        } else if (iVar1 == 0x100000) {
            iVar1 = (*(code *)0x8000000000000010)((int64_t)*(int32_t *)(arg1 + 0x48), iVar3, iVar4);
        } else if (iVar1 == 0x1000000) {
            iVar1 = func_0x000180183390(*(undefined8 *)(arg1 + 0x180));
        } else {
            iVar1 = func_0x000180474f60(*(undefined4 *)(arg1 + 0x48));
        }
        if (iVar1 < 0) {
            iVar2 = (*(code *)0x800000000000006f)();
            if (iVar2 == 0x2733) {
                return;
            }
            if (iVar2 == 0x2714) {
                return;
            }
            iVar1 = iVar4;
            if (iVar2 != 0x2738) {
                *(int32_t *)(arg1 + 0x4c) = iVar2;
                if ((*(uint32_t *)(arg1 + 0x40) & 0xff00000) == 0) {
                    return;
                }
                goto code_r0x0001801844f7;
            }
        }
        if ((iVar1 == 0) && ((*(uint32_t *)(arg1 + 0x40) & 0xff00000) != 0)) {
code_r0x0001801844f7:
            func_0x000180183710(arg1);
            return;
        }
        if (iVar1 < iVar4) {
            *(undefined *)(iVar1 + iVar3) = 0;
        }
        *(int64_t *)(arg1 + 0x90) = *(int64_t *)(arg1 + 0x90) + (int64_t)iVar1;
        *(undefined8 *)(arg1 + 0x68) = *(undefined8 *)(*(int64_t *)arg1 + 0x20);
        func_0x000180173a20(arg1, iVar3, iVar1);
        if (iVar1 != iVar4) {
            return;
        }
        if ((*(uint8_t *)(arg1 + 0x3c) & 0x20) != 0) {
            return;
        }
        if (*(int32_t *)(arg1 + 0x40) != 0x1000000) {
            return;
        }
        iVar1 = 0x1000000;
    } while( true );
}

// ============================================================
// Function: FUN_180184520
// Address: 0x180184520
// Size: 405 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.180184520(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t unaff_RBP;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    (*(code *)0x699f1c)(arg1 + 200);
    do {
        if (*(int64_t *)(arg1 + 0xb0) == 0) {
            (*(code *)0x699f34)(arg1 + 200);
            if ((*(uint32_t *)(arg1 + 0x3c) >> 0xd & 1) == 0) {
                return;
            }
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xffffdfff;
            goto code_r0x00018018468a;
        }
        iVar3 = *(int64_t *)(arg1 + 0xc0);
        iVar4 = *(int64_t *)(arg1 + 0xa8);
        iVar5 = *(int64_t *)(iVar4 + iVar3 * 0x18);
        iVar2 = iVar4 + iVar3 * 0x18;
        iVar3 = *(int64_t *)(iVar4 + 0x10 + iVar3 * 0x18);
        iVar7 = *(int32_t *)(iVar2 + 8);
        iVar6 = fcn.180183630(unaff_RBP);
        if (iVar6 < 0) {
            iVar7 = (*(code *)0x800000000000006f)();
            if ((iVar7 != 0x2733) && (iVar7 != 0x2714)) {
                *(int32_t *)(arg1 + 0x4c) = iVar7;
code_r0x000180184655:
                (*(code *)0x699f34)(arg1 + 200);
                if ((*(uint32_t *)(arg1 + 0x40) & 0xff00000) == 0) {
                    return;
                }
code_r0x00018018468a:
                func_0x000180183710(arg1);
                return;
            }
            break;
        }
        if ((iVar6 == 0) && ((*(uint32_t *)(arg1 + 0x40) & 0xff00000) != 0)) goto code_r0x000180184655;
        piVar1 = (int64_t *)(iVar2 + 0x10);
        *piVar1 = *piVar1 + (int64_t)iVar6;
        *(int32_t *)(arg1 + 0xf0) = *(int32_t *)(arg1 + 0xf0) - iVar6;
        *(undefined8 *)(arg1 + 0x70) = *(undefined8 *)(*(int64_t *)arg1 + 0x20);
        fcn.180174330(arg1, iVar3 + iVar5, iVar6);
        if (iVar6 != iVar7 - (int32_t)iVar3) break;
        if (iVar5 != 0) {
            func_0x000180180fe0(iVar5);
        }
        *(int64_t *)(arg1 + 0xc0) = *(int64_t *)(arg1 + 0xc0) + 1;
        *(int64_t *)(arg1 + 0xb0) = *(int64_t *)(arg1 + 0xb0) + -1;
        if (*(int64_t *)(arg1 + 0xc0) == *(int64_t *)(arg1 + 0xb8)) {
            *(undefined8 *)(arg1 + 0xc0) = 0;
        }
    } while ((*(uint8_t *)(arg1 + 0x3c) & 0x20) == 0);
    (*(code *)0x699f34)(arg1 + 200);
    return;
}

// ============================================================
// Function: FUN_1801846c0
// Address: 0x1801846c0
// Size: 121 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

code * fcn.1801846c0(int64_t arg1)
{
    int32_t *piVar1;
    undefined8 uVar2;
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar3;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t in_stack_00000028;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t in_stack_fffffffffffffff0;
    
    UNRECOVERED_JUMPTABLE = (code *)fcn.180183020(var_8h, unaff_RSI);
    if ((int32_t)UNRECOVERED_JUMPTABLE != 0) {
        if ((int32_t)UNRECOVERED_JUMPTABLE == -2) {
            if ((*(uint8_t *)(arg1 + 0x50) & 1) == 0) {
                if (2 < *(int32_t *)(arg1 + 0x48)) {
                    iVar3 = *(int64_t *)arg1;
                    if ((*(uint8_t *)(arg1 + 0x3c) & 2) == 0) {
                        uVar2 = fcn.180174350();
                        *(undefined8 *)(arg1 + 0x10) = uVar2;
                        *(code **)(arg1 + 0x18) = fcn.1801846c0;
                        if ((*(uint32_t *)(arg1 + 0x3c) & 2) == 0) {
                            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 2;
                            *(int32_t *)(*(int64_t *)arg1 + 0x44) = *(int32_t *)(*(int64_t *)arg1 + 0x44) + 1;
                        }
                        piVar1 = (int32_t *)(iVar3 + 0x130);
                        *piVar1 = *piVar1 + 1;
                    }
                    if ((*(uint8_t *)(arg1 + 0x3c) & 8) == 0) {
                        fcn.180173db0(in_stack_00000028);
                    }
                    *(code **)(arg1 + 0x18) = fcn.1801846c0;
                    if ((*(uint32_t *)(arg1 + 0x50) & 1) == 0) {
                        fcn.18018a050(iVar3, *(undefined4 *)(arg1 + 0x48), 1);
                        *(uint32_t *)(arg1 + 0x50) = *(uint32_t *)(arg1 + 0x50) | 1;
                    }
                    return (code *)0x0;
                }
                return (code *)0xffffffff;
            }
        } else {
            iVar3 = fcn.18045b9a8(0x1804a77e0, 0x5c);
            uVar2 = fcn.1801723e0(in_stack_fffffffffffffff0);
            fcn.180172b00(uVar2, 4, 0x1804a7910, (uint64_t)UNRECOVERED_JUMPTABLE & 0xffffffff, iVar3 + 1, 0x68, 
                          0x1804a78f8);
            *(undefined4 *)(arg1 + 0x4c) = 0x413;
            UNRECOVERED_JUMPTABLE = (code *)fcn.180183710(arg1);
        }
        return UNRECOVERED_JUMPTABLE;
    }
    fcn.180181d70(arg1, 1);
    fcn.180173710(arg1);
    *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 0x10;
    UNRECOVERED_JUMPTABLE = *(code **)(arg1 + 0x118);
    if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
        return UNRECOVERED_JUMPTABLE;
    }
    // WARNING: Could not recover jumptable at 0x0001801736c0. Too many branches
    // WARNING: Treating indirect jump as call
    UNRECOVERED_JUMPTABLE = (code *)(*UNRECOVERED_JUMPTABLE)();
    return UNRECOVERED_JUMPTABLE;
}

// ============================================================
// Function: FUN_180184739
// Address: 0x180184739
// Size: 94 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

code * fcn.1801846c0(int64_t arg1)
{
    int32_t *piVar1;
    undefined8 uVar2;
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar3;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t in_stack_00000028;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t in_stack_fffffffffffffff0;
    
    UNRECOVERED_JUMPTABLE = (code *)fcn.180183020(var_8h, unaff_RSI);
    if ((int32_t)UNRECOVERED_JUMPTABLE != 0) {
        if ((int32_t)UNRECOVERED_JUMPTABLE == -2) {
            if ((*(uint8_t *)(arg1 + 0x50) & 1) == 0) {
                if (2 < *(int32_t *)(arg1 + 0x48)) {
                    iVar3 = *(int64_t *)arg1;
                    if ((*(uint8_t *)(arg1 + 0x3c) & 2) == 0) {
                        uVar2 = fcn.180174350();
                        *(undefined8 *)(arg1 + 0x10) = uVar2;
                        *(code **)(arg1 + 0x18) = fcn.1801846c0;
                        if ((*(uint32_t *)(arg1 + 0x3c) & 2) == 0) {
                            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 2;
                            *(int32_t *)(*(int64_t *)arg1 + 0x44) = *(int32_t *)(*(int64_t *)arg1 + 0x44) + 1;
                        }
                        piVar1 = (int32_t *)(iVar3 + 0x130);
                        *piVar1 = *piVar1 + 1;
                    }
                    if ((*(uint8_t *)(arg1 + 0x3c) & 8) == 0) {
                        fcn.180173db0(in_stack_00000028);
                    }
                    *(code **)(arg1 + 0x18) = fcn.1801846c0;
                    if ((*(uint32_t *)(arg1 + 0x50) & 1) == 0) {
                        fcn.18018a050(iVar3, *(undefined4 *)(arg1 + 0x48), 1);
                        *(uint32_t *)(arg1 + 0x50) = *(uint32_t *)(arg1 + 0x50) | 1;
                    }
                    return (code *)0x0;
                }
                return (code *)0xffffffff;
            }
        } else {
            iVar3 = fcn.18045b9a8(0x1804a77e0, 0x5c);
            uVar2 = fcn.1801723e0(in_stack_fffffffffffffff0);
            fcn.180172b00(uVar2, 4, 0x1804a7910, (uint64_t)UNRECOVERED_JUMPTABLE & 0xffffffff, iVar3 + 1, 0x68, 
                          0x1804a78f8);
            *(undefined4 *)(arg1 + 0x4c) = 0x413;
            UNRECOVERED_JUMPTABLE = (code *)fcn.180183710(arg1);
        }
        return UNRECOVERED_JUMPTABLE;
    }
    fcn.180181d70(arg1, 1);
    fcn.180173710(arg1);
    *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 0x10;
    UNRECOVERED_JUMPTABLE = *(code **)(arg1 + 0x118);
    if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
        return UNRECOVERED_JUMPTABLE;
    }
    // WARNING: Could not recover jumptable at 0x0001801736c0. Too many branches
    // WARNING: Treating indirect jump as call
    UNRECOVERED_JUMPTABLE = (code *)(*UNRECOVERED_JUMPTABLE)();
    return UNRECOVERED_JUMPTABLE;
}

// ============================================================
// Function: FUN_180184797
// Address: 0x180184797
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

code * fcn.1801846c0(int64_t arg1)
{
    int32_t *piVar1;
    undefined8 uVar2;
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar3;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t in_stack_00000028;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t in_stack_fffffffffffffff0;
    
    UNRECOVERED_JUMPTABLE = (code *)fcn.180183020(var_8h, unaff_RSI);
    if ((int32_t)UNRECOVERED_JUMPTABLE != 0) {
        if ((int32_t)UNRECOVERED_JUMPTABLE == -2) {
            if ((*(uint8_t *)(arg1 + 0x50) & 1) == 0) {
                if (2 < *(int32_t *)(arg1 + 0x48)) {
                    iVar3 = *(int64_t *)arg1;
                    if ((*(uint8_t *)(arg1 + 0x3c) & 2) == 0) {
                        uVar2 = fcn.180174350();
                        *(undefined8 *)(arg1 + 0x10) = uVar2;
                        *(code **)(arg1 + 0x18) = fcn.1801846c0;
                        if ((*(uint32_t *)(arg1 + 0x3c) & 2) == 0) {
                            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 2;
                            *(int32_t *)(*(int64_t *)arg1 + 0x44) = *(int32_t *)(*(int64_t *)arg1 + 0x44) + 1;
                        }
                        piVar1 = (int32_t *)(iVar3 + 0x130);
                        *piVar1 = *piVar1 + 1;
                    }
                    if ((*(uint8_t *)(arg1 + 0x3c) & 8) == 0) {
                        fcn.180173db0(in_stack_00000028);
                    }
                    *(code **)(arg1 + 0x18) = fcn.1801846c0;
                    if ((*(uint32_t *)(arg1 + 0x50) & 1) == 0) {
                        fcn.18018a050(iVar3, *(undefined4 *)(arg1 + 0x48), 1);
                        *(uint32_t *)(arg1 + 0x50) = *(uint32_t *)(arg1 + 0x50) | 1;
                    }
                    return (code *)0x0;
                }
                return (code *)0xffffffff;
            }
        } else {
            iVar3 = fcn.18045b9a8(0x1804a77e0, 0x5c);
            uVar2 = fcn.1801723e0(in_stack_fffffffffffffff0);
            fcn.180172b00(uVar2, 4, 0x1804a7910, (uint64_t)UNRECOVERED_JUMPTABLE & 0xffffffff, iVar3 + 1, 0x68, 
                          0x1804a78f8);
            *(undefined4 *)(arg1 + 0x4c) = 0x413;
            UNRECOVERED_JUMPTABLE = (code *)fcn.180183710(arg1);
        }
        return UNRECOVERED_JUMPTABLE;
    }
    fcn.180181d70(arg1, 1);
    fcn.180173710(arg1);
    *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 0x10;
    UNRECOVERED_JUMPTABLE = *(code **)(arg1 + 0x118);
    if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
        return UNRECOVERED_JUMPTABLE;
    }
    // WARNING: Could not recover jumptable at 0x0001801736c0. Too many branches
    // WARNING: Treating indirect jump as call
    UNRECOVERED_JUMPTABLE = (code *)(*UNRECOVERED_JUMPTABLE)();
    return UNRECOVERED_JUMPTABLE;
}

// ============================================================
// Function: FUN_1801847b0
// Address: 0x1801847b0
// Size: 113 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

code * fcn.1801847b0(int64_t arg1)
{
    int32_t *piVar1;
    undefined8 uVar2;
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar3;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t in_stack_00000028;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t in_stack_fffffffffffffff0;
    
    UNRECOVERED_JUMPTABLE = (code *)fcn.180182ed0(var_8h, unaff_RSI);
    if ((int32_t)UNRECOVERED_JUMPTABLE != 0) {
        if ((int32_t)UNRECOVERED_JUMPTABLE == -2) {
            if ((*(uint8_t *)(arg1 + 0x50) & 1) == 0) {
                if (2 < *(int32_t *)(arg1 + 0x48)) {
                    iVar3 = *(int64_t *)arg1;
                    if ((*(uint8_t *)(arg1 + 0x3c) & 2) == 0) {
                        uVar2 = fcn.180174350();
                        *(undefined8 *)(arg1 + 0x10) = uVar2;
                        *(code **)(arg1 + 0x18) = fcn.1801847b0;
                        if ((*(uint32_t *)(arg1 + 0x3c) & 2) == 0) {
                            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 2;
                            *(int32_t *)(*(int64_t *)arg1 + 0x44) = *(int32_t *)(*(int64_t *)arg1 + 0x44) + 1;
                        }
                        piVar1 = (int32_t *)(iVar3 + 0x130);
                        *piVar1 = *piVar1 + 1;
                    }
                    if ((*(uint8_t *)(arg1 + 0x3c) & 8) == 0) {
                        fcn.180173db0(in_stack_00000028);
                    }
                    *(code **)(arg1 + 0x18) = fcn.1801847b0;
                    if ((*(uint32_t *)(arg1 + 0x50) & 1) == 0) {
                        fcn.18018a050(iVar3, *(undefined4 *)(arg1 + 0x48), 1);
                        *(uint32_t *)(arg1 + 0x50) = *(uint32_t *)(arg1 + 0x50) | 1;
                    }
                    return (code *)0x0;
                }
                return (code *)0xffffffff;
            }
        } else {
            iVar3 = fcn.18045b9a8(0x1804a77e0, 0x5c);
            uVar2 = fcn.1801723e0(in_stack_fffffffffffffff0);
            fcn.180172b00(uVar2, 4, 0x1804a78c8, (uint64_t)UNRECOVERED_JUMPTABLE & 0xffffffff, iVar3 + 1, 0x53, 
                          0x1804a78b0);
            *(undefined4 *)(arg1 + 0x4c) = 0x413;
            UNRECOVERED_JUMPTABLE = (code *)fcn.180183710(arg1);
        }
        return UNRECOVERED_JUMPTABLE;
    }
    fcn.180181d70(arg1, 1);
    UNRECOVERED_JUMPTABLE = *(code **)(arg1 + 0x110);
    if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
        return UNRECOVERED_JUMPTABLE;
    }
    // WARNING: Could not recover jumptable at 0x0001801735ac. Too many branches
    // WARNING: Treating indirect jump as call
    UNRECOVERED_JUMPTABLE = (code *)(*UNRECOVERED_JUMPTABLE)();
    return UNRECOVERED_JUMPTABLE;
}

// ============================================================
// Function: FUN_180184821
// Address: 0x180184821
// Size: 94 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

code * fcn.1801847b0(int64_t arg1)
{
    int32_t *piVar1;
    undefined8 uVar2;
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar3;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t in_stack_00000028;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t in_stack_fffffffffffffff0;
    
    UNRECOVERED_JUMPTABLE = (code *)fcn.180182ed0(var_8h, unaff_RSI);
    if ((int32_t)UNRECOVERED_JUMPTABLE != 0) {
        if ((int32_t)UNRECOVERED_JUMPTABLE == -2) {
            if ((*(uint8_t *)(arg1 + 0x50) & 1) == 0) {
                if (2 < *(int32_t *)(arg1 + 0x48)) {
                    iVar3 = *(int64_t *)arg1;
                    if ((*(uint8_t *)(arg1 + 0x3c) & 2) == 0) {
                        uVar2 = fcn.180174350();
                        *(undefined8 *)(arg1 + 0x10) = uVar2;
                        *(code **)(arg1 + 0x18) = fcn.1801847b0;
                        if ((*(uint32_t *)(arg1 + 0x3c) & 2) == 0) {
                            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 2;
                            *(int32_t *)(*(int64_t *)arg1 + 0x44) = *(int32_t *)(*(int64_t *)arg1 + 0x44) + 1;
                        }
                        piVar1 = (int32_t *)(iVar3 + 0x130);
                        *piVar1 = *piVar1 + 1;
                    }
                    if ((*(uint8_t *)(arg1 + 0x3c) & 8) == 0) {
                        fcn.180173db0(in_stack_00000028);
                    }
                    *(code **)(arg1 + 0x18) = fcn.1801847b0;
                    if ((*(uint32_t *)(arg1 + 0x50) & 1) == 0) {
                        fcn.18018a050(iVar3, *(undefined4 *)(arg1 + 0x48), 1);
                        *(uint32_t *)(arg1 + 0x50) = *(uint32_t *)(arg1 + 0x50) | 1;
                    }
                    return (code *)0x0;
                }
                return (code *)0xffffffff;
            }
        } else {
            iVar3 = fcn.18045b9a8(0x1804a77e0, 0x5c);
            uVar2 = fcn.1801723e0(in_stack_fffffffffffffff0);
            fcn.180172b00(uVar2, 4, 0x1804a78c8, (uint64_t)UNRECOVERED_JUMPTABLE & 0xffffffff, iVar3 + 1, 0x53, 
                          0x1804a78b0);
            *(undefined4 *)(arg1 + 0x4c) = 0x413;
            UNRECOVERED_JUMPTABLE = (code *)fcn.180183710(arg1);
        }
        return UNRECOVERED_JUMPTABLE;
    }
    fcn.180181d70(arg1, 1);
    UNRECOVERED_JUMPTABLE = *(code **)(arg1 + 0x110);
    if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
        return UNRECOVERED_JUMPTABLE;
    }
    // WARNING: Could not recover jumptable at 0x0001801735ac. Too many branches
    // WARNING: Treating indirect jump as call
    UNRECOVERED_JUMPTABLE = (code *)(*UNRECOVERED_JUMPTABLE)();
    return UNRECOVERED_JUMPTABLE;
}

// ============================================================
// Function: FUN_18018487f
// Address: 0x18018487f
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

code * fcn.1801847b0(int64_t arg1)
{
    int32_t *piVar1;
    undefined8 uVar2;
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar3;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t in_stack_00000028;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t in_stack_fffffffffffffff0;
    
    UNRECOVERED_JUMPTABLE = (code *)fcn.180182ed0(var_8h, unaff_RSI);
    if ((int32_t)UNRECOVERED_JUMPTABLE != 0) {
        if ((int32_t)UNRECOVERED_JUMPTABLE == -2) {
            if ((*(uint8_t *)(arg1 + 0x50) & 1) == 0) {
                if (2 < *(int32_t *)(arg1 + 0x48)) {
                    iVar3 = *(int64_t *)arg1;
                    if ((*(uint8_t *)(arg1 + 0x3c) & 2) == 0) {
                        uVar2 = fcn.180174350();
                        *(undefined8 *)(arg1 + 0x10) = uVar2;
                        *(code **)(arg1 + 0x18) = fcn.1801847b0;
                        if ((*(uint32_t *)(arg1 + 0x3c) & 2) == 0) {
                            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 2;
                            *(int32_t *)(*(int64_t *)arg1 + 0x44) = *(int32_t *)(*(int64_t *)arg1 + 0x44) + 1;
                        }
                        piVar1 = (int32_t *)(iVar3 + 0x130);
                        *piVar1 = *piVar1 + 1;
                    }
                    if ((*(uint8_t *)(arg1 + 0x3c) & 8) == 0) {
                        fcn.180173db0(in_stack_00000028);
                    }
                    *(code **)(arg1 + 0x18) = fcn.1801847b0;
                    if ((*(uint32_t *)(arg1 + 0x50) & 1) == 0) {
                        fcn.18018a050(iVar3, *(undefined4 *)(arg1 + 0x48), 1);
                        *(uint32_t *)(arg1 + 0x50) = *(uint32_t *)(arg1 + 0x50) | 1;
                    }
                    return (code *)0x0;
                }
                return (code *)0xffffffff;
            }
        } else {
            iVar3 = fcn.18045b9a8(0x1804a77e0, 0x5c);
            uVar2 = fcn.1801723e0(in_stack_fffffffffffffff0);
            fcn.180172b00(uVar2, 4, 0x1804a78c8, (uint64_t)UNRECOVERED_JUMPTABLE & 0xffffffff, iVar3 + 1, 0x53, 
                          0x1804a78b0);
            *(undefined4 *)(arg1 + 0x4c) = 0x413;
            UNRECOVERED_JUMPTABLE = (code *)fcn.180183710(arg1);
        }
        return UNRECOVERED_JUMPTABLE;
    }
    fcn.180181d70(arg1, 1);
    UNRECOVERED_JUMPTABLE = *(code **)(arg1 + 0x110);
    if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
        return UNRECOVERED_JUMPTABLE;
    }
    // WARNING: Could not recover jumptable at 0x0001801735ac. Too many branches
    // WARNING: Treating indirect jump as call
    UNRECOVERED_JUMPTABLE = (code *)(*UNRECOVERED_JUMPTABLE)();
    return UNRECOVERED_JUMPTABLE;
}

// ============================================================
// Function: FUN_180184890
// Address: 0x180184890
// Size: 466 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_2eh

void fcn.180184890(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    undefined4 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_58 [32];
    int64_t var_38h;
    int64_t var_30h;
    undefined8 uStack_28;
    int64_t var_20h;
    
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    if (((int32_t)arg1 == 2) && ((int32_t)arg2 == 1)) {
        func_0x000180184a70();
        var_38h._0_4_ = 0x10;
        stack0xffffffffffffffd2 = SUB1614(ZEXT816(0), 2);
        var_30h._0_2_ = 2;
        uVar1 = (*(code *)0x8000000000000008)(0x7f000001);
        var_30h = CONCAT44(uVar1, (uint32_t)var_30h);
        var_30h._0_4_ = (uint32_t)var_30h & 0xffff;
        iVar2 = (*(code *)0x8000000000000017)(2, 1, 0);
        iVar6 = (int64_t)iVar2;
        if (iVar2 < 0) {
            func_0x00018047208c(0x1804a70dc);
            if (iVar2 == -1) goto code_r0x000180184a2e;
            iVar2 = -1;
            iVar4 = -1;
        } else {
            iVar4 = -1;
            iVar2 = -1;
            iVar3 = (*(code *)0x8000000000000002)(iVar6, &var_30h, (undefined4)var_38h);
            if (iVar3 < 0) {
                uVar5 = 0x1804a7610;
                iVar2 = -1;
            } else {
                iVar3 = (*(code *)0x800000000000000d)(iVar6, 1);
                if (iVar3 < 0) {
                    uVar5 = 0x1804a7618;
                } else {
                    iVar3 = (*(code *)0x8000000000000006)(iVar6, &var_30h, &var_38h);
                    if (iVar3 < 0) {
                        uVar5 = 0x1804a7b40;
                    } else {
                        iVar2 = (*(code *)0x8000000000000017)(2, 1, 0);
                        if (iVar2 < 0) {
                            uVar5 = 0x1804a70dc;
                        } else {
                            iVar3 = (*(code *)0x8000000000000004)((int64_t)iVar2, &var_30h, (undefined4)var_38h);
                            if (iVar3 < 0) {
                                uVar5 = 0x180624fe0;
                            } else {
                                iVar4 = (*(code *)0x8000000000000001)(iVar6, &var_30h, &var_38h);
                                if (-1 < iVar4) {
                                    (*(code *)0x8000000000000003)(iVar6);
                                    *(int32_t *)arg4 = iVar2;
                                    *(int32_t *)(arg4 + 4) = iVar4;
                                    goto code_r0x000180184a2e;
                                }
                                uVar5 = 0x1804a793c;
                            }
                        }
                    }
                }
            }
            func_0x00018047208c(uVar5);
        }
        (*(code *)0x8000000000000003)(iVar6);
        if (iVar2 != -1) {
            (*(code *)0x8000000000000003)((int64_t)iVar2);
        }
        if (iVar4 != -1) {
            (*(code *)0x8000000000000003)((int64_t)iVar4);
        }
    }
code_r0x000180184a2e:
    func_0x000180459870(var_20h ^ (uint64_t)auStack_58);
    return;
}

// ============================================================
// Function: FUN_180184a70
// Address: 0x180184a70
// Size: 82 bytes
// ============================================================
void fcn.180184a70(void)
{
    bool bVar1;
    undefined auStack_1d8 [32];
    int64_t var_1b8h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1d8;
    LOCK();
    bVar1 = *(int32_t *)0x18077e160 == 0;
    if (bVar1) {
        *(int32_t *)0x18077e160 = 1;
    }
    UNLOCK();
    if (bVar1) {
        (*(code *)0x8000000000000073)(0x202, &var_1b8h);
    }
    fcn.180459870(var_18h ^ (uint64_t)auStack_1d8);
    return;
}

// ============================================================
// Function: FUN_180184ad0
// Address: 0x180184ad0
// Size: 62 bytes
// ============================================================
void fcn.180184ad0(int64_t arg1)
{
    undefined auStack_48 [32];
    int64_t var_28h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_48;
    (*(code *)0x69aa1e)(2, arg1, &var_28h);
    fcn.180459870(var_18h ^ (uint64_t)auStack_48);
    return;
}

// ============================================================
// Function: FUN_180184b10
// Address: 0x180184b10
// Size: 62 bytes
// ============================================================
void fcn.180184b10(int64_t arg1)
{
    undefined auStack_58 [32];
    int64_t var_38h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    (*(code *)0x69aa1e)(0x17, arg1, &var_38h);
    fcn.180459870(var_18h ^ (uint64_t)auStack_58);
    return;
}

// ============================================================
// Function: FUN_180184b70
// Address: 0x180184b70
// Size: 352 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180184b70(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined2 uVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t iVar6;
    bool bVar7;
    int64_t var_20h;
    undefined auStack_1f8 [32];
    int64_t var_1d8h;
    int64_t var_1c8h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1f8;
    if ((arg2 == 0) || (*(char *)arg2 == '\0')) {
        *(undefined2 *)arg1 = 2;
        uVar5 = (*(code *)0x8000000000000008)(0);
        *(undefined4 *)(arg1 + 4) = uVar5;
    } else {
        LOCK();
        bVar7 = *(int32_t *)0x18077e160 == 0;
        if (bVar7) {
            *(int32_t *)0x18077e160 = 1;
        }
        UNLOCK();
        if (bVar7) {
            (*(code *)0x8000000000000073)(0x202, &var_1c8h);
        }
        iVar4 = (*(code *)0x69aa1e)(2, arg2, arg1 + 4);
        if (iVar4 == 1) {
            *(undefined2 *)arg1 = 2;
            iVar4 = 0;
        } else {
            iVar4 = (*(code *)0x69aa1e)(0x17, arg2, arg1 + 8);
            if (iVar4 == 1) {
                *(undefined2 *)arg1 = 0x17;
            }
            var_1d8h = 0;
            iVar4 = (*(code *)0x69aa00)(arg2, 0, 0, &var_1d8h);
            iVar2 = var_1d8h;
            if ((((iVar4 == 0) && (var_1d8h != 0)) && (*(int64_t *)(var_1d8h + 0x20) != 0)) &&
               (iVar1 = var_1d8h, *(int64_t *)(var_1d8h + 0x10) != 0)) {
                for (; (iVar6 = var_1d8h, iVar1 != 0 && (iVar6 = iVar1, *(int32_t *)(iVar1 + 4) != 2));
                    iVar1 = *(int64_t *)(iVar1 + 0x28)) {
                }
                fcn.180498030(arg1, *(undefined8 *)(iVar6 + 0x20), *(undefined8 *)(iVar6 + 0x10));
                (*(code *)0x69aa0e)(iVar2);
                iVar4 = 0;
            }
        }
        if (iVar4 != 0) goto code_r0x000180184cad;
    }
    if ((*(int16_t *)arg1 == 2) || (*(int16_t *)arg1 == 0x17)) {
        uVar3 = (*(code *)0x8000000000000009)(arg3 & 0xffff);
        *(undefined2 *)(arg1 + 2) = uVar3;
    }
code_r0x000180184cad:
    fcn.180459870(var_28h ^ (uint64_t)auStack_1f8);
    return;
}

// ============================================================
// Function: FUN_180184cd0
// Address: 0x180184cd0
// Size: 206 bytes
// ============================================================
void fcn.180184cd0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint16_t uVar1;
    int32_t iVar2;
    undefined8 uVar3;
    undefined auStack_98 [32];
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    _var_68h = ZEXT816(0);
    _var_58h = ZEXT816(0);
    _var_48h = ZEXT816(0);
    _var_38h = ZEXT816(0);
    iVar2 = (int32_t)arg3;
    if (*(int16_t *)arg1 == 2) {
        func_0x00018048e3a2(2, arg1 + 4, &var_68h, (int64_t)iVar2);
        uVar1 = (*(code *)0x800000000000000f)(*(undefined2 *)(arg1 + 2));
        uVar3 = 0x18063e190;
    } else {
        if (*(int16_t *)arg1 != 0x17) goto code_r0x000180184d83;
        func_0x00018048e3a2(0x17, arg1 + 8, &var_68h, (int64_t)iVar2);
        uVar1 = (*(code *)0x800000000000000f)(*(undefined2 *)(arg1 + 2));
        uVar3 = 0x1804a7b38;
    }
    var_78h._0_4_ = (uint32_t)uVar1;
    func_0x000180065f60(arg2, (int64_t)iVar2, uVar3, &var_68h);
code_r0x000180184d83:
    fcn.180459870(var_28h ^ (uint64_t)auStack_98);
    return;
}

// ============================================================
// Function: FUN_180184da0
// Address: 0x180184da0
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180184da0(int64_t arg1)
{
    uint64_t uVar1;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    uVar1 = (uint64_t)(uint32_t)-(int32_t)arg1;
    if (0 < (int32_t)arg1) {
        uVar1 = arg1 & 0xffffffff;
    }
    (*(code *)0x699fbc)(0x12ff, 0, uVar1, 0, 0x18077e170, 0x80, 0);
    return 0x18077e170;
}

// ============================================================
// Function: FUN_180184df0
// Address: 0x180184df0
// Size: 142 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_1ch
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

uint64_t fcn.180184df0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
                      int64_t arg_50h, int64_t arg_78h, int64_t arg_88h, int64_t arg_90h)
{
    uint16_t uVar1;
    undefined4 uVar2;
    uint8_t *puVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint8_t uVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    uint64_t uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb0;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t in_stack_ffffffffffffffd0;
    int64_t var_1ch;
    
    iVar7 = **(int32_t **)(arg1 + 0x178);
    iVar12 = (int32_t)arg3;
    iVar15 = (int32_t)arg2;
    if (iVar7 == 1) {
        iVar7 = (*(int32_t **)(arg1 + 0x178))[2];
        iVar5 = *(int64_t *)(arg1 + 0x78) + *(int64_t *)(arg1 + 0x88);
        uVar14 = 0;
        for (iVar12 = (iVar15 - (int32_t)iVar5) + iVar12; iVar7 <= iVar12; iVar12 = iVar12 - iVar7) {
            fcn.180173cb0(arg1, iVar5, iVar7);
            uVar14 = uVar14 + iVar7;
            iVar5 = iVar5 + iVar7;
        }
        *(int64_t *)(arg1 + 0x90) = (int64_t)iVar12;
        *(undefined8 *)(arg1 + 0x88) = 0;
        if ((iVar12 != 0) && (iVar5 != *(int64_t *)(arg1 + 0x78))) {
            fcn.180498030(*(int64_t *)(arg1 + 0x78), iVar5);
        }
        return (uint64_t)uVar14;
    }
    if (iVar7 == 2) {
        iVar5 = *(int64_t *)(arg1 + 0x178);
        uVar13 = *(int64_t *)(arg1 + 0x78) + *(int64_t *)(arg1 + 0x88);
        uVar1 = *(uint16_t *)(iVar5 + 0x10);
        uVar11 = (arg2 - (int32_t)(uint32_t)uVar1) + 1;
        uVar9 = uVar13;
        if (uVar13 <= uVar11) {
            uVar9 = uVar11;
        }
        uVar14 = 0;
        iVar7 = (iVar15 + iVar12) - (int32_t)uVar9;
        if ((int32_t)(uint32_t)uVar1 <= iVar7) {
            do {
                uVar11 = 0;
                if (uVar1 != 0) {
                    do {
                        if (*(char *)(uVar9 + uVar11) != *(char *)(iVar5 + 8 + uVar11)) {
                            uVar9 = uVar9 + 1;
                            iVar7 = iVar7 + -1;
                            goto code_r0x000180184f93;
                        }
                        uVar16 = (int32_t)uVar11 + 1;
                        uVar11 = (uint64_t)uVar16;
                    } while ((int32_t)uVar16 < (int32_t)(uint32_t)uVar1);
                }
                uVar9 = uVar9 + uVar1;
                iVar8 = (int32_t)uVar9 - (int32_t)uVar13;
                iVar7 = iVar7 - (uint32_t)uVar1;
                fcn.180173cb0(arg1, uVar13, iVar8);
                uVar14 = uVar14 + iVar8;
                uVar13 = uVar9;
code_r0x000180184f93:
            } while ((int32_t)(uint32_t)uVar1 <= iVar7);
        }
        iVar7 = (iVar15 + iVar12) - (int32_t)uVar13;
        *(int64_t *)(arg1 + 0x90) = (int64_t)iVar7;
        *(undefined8 *)(arg1 + 0x88) = 0;
        if (iVar7 != 0) {
            if (uVar13 != *(uint64_t *)(arg1 + 0x78)) {
                fcn.180498030(*(uint64_t *)(arg1 + 0x78), uVar13);
            }
            uVar9 = *(uint64_t *)(arg1 + 0x80);
            if (*(uint64_t *)(arg1 + 0x90) == uVar9) {
                uVar13 = (uint64_t)*(uint32_t *)(iVar5 + 4);
                if (uVar13 <= uVar9) {
                    iVar17 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar2 = *(undefined4 *)(iVar5 + 4);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffd0);
                    fcn.180172b00(uVar4, 4, 0x1804a7bd8, uVar2, iVar17 + 1, 0x5d, 0x1804a7b50);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                if (uVar9 * 2 < uVar13) {
                    uVar13 = uVar9 * 2 & 0xffffffff;
                }
                fcn.1801735b0(arg1, uVar13);
            }
        }
        return (uint64_t)uVar14;
    }
    if (iVar7 != 3) {
        fcn.180173cb0();
        return arg3 & 0xffffffff;
    }
    iVar5 = *(int64_t *)(arg1 + 0x178);
    iVar15 = iVar15 + iVar12;
    iVar17 = *(int64_t *)(arg1 + 0x88) + *(int64_t *)(arg1 + 0x78);
    uVar14 = 0;
    uVar16 = iVar15 - (int32_t)iVar17;
    uVar9 = (uint64_t)*(uint16_t *)(iVar5 + 8);
    uVar13 = uVar9;
    if ((int32_t)(uint32_t)*(uint16_t *)(iVar5 + 8) <= (int32_t)uVar16) {
        do {
            uVar11 = 0;
            uVar10 = 0;
            iVar7 = *(int32_t *)(iVar5 + 0x10);
            puVar3 = (uint8_t *)((uint64_t)*(uint16_t *)(iVar5 + 10) + iVar17);
            if (iVar7 == 0x10e1) {
                iVar7 = 0;
                if (*(uint16_t *)(iVar5 + 0xc) != 0) {
                    do {
                        uVar6 = *puVar3;
                        puVar3 = puVar3 + 1;
                        iVar7 = iVar7 + 1;
                        uVar10 = (int32_t)uVar11 << 8 | (uint32_t)uVar6;
                        uVar11 = (uint64_t)uVar10;
                    } while (iVar7 < (int32_t)(uint32_t)*(uint16_t *)(iVar5 + 0xc));
                }
            } else if (iVar7 == 0x4d2) {
                iVar7 = 0;
                if (*(uint16_t *)(iVar5 + 0xc) != 0) {
                    do {
                        uVar6 = *puVar3;
                        puVar3 = puVar3 + 1;
                        uVar10 = (uint32_t)uVar11 | (uint32_t)uVar6 << ((char)iVar7 * '\b' & 0x1fU);
                        uVar11 = (uint64_t)uVar10;
                        iVar7 = iVar7 + 1;
                    } while (iVar7 < (int32_t)(uint32_t)*(uint16_t *)(iVar5 + 0xc));
                }
            } else {
                if (iVar7 != 0x11) {
                    iVar5 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                    fcn.180172b00(uVar4, 4, 0x1804a7c40, iVar5 + 1, 0x8f, 0x1804a7c00);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3f3;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                iVar12 = 0;
                iVar7 = (int32_t)puVar3;
                uVar6 = 0;
                while( true ) {
                    if ((iVar15 != iVar7) && (iVar12 == iVar15 - iVar7)) goto code_r0x0001801851e9;
                    iVar12 = iVar12 + 1;
                    uVar11 = uVar11 | (uint64_t)(*puVar3 & 0x7f) << (uVar6 & 0x3f);
                    uVar10 = (uint32_t)uVar11;
                    if (-1 < (char)*puVar3) break;
                    if (9 < iVar12) goto code_r0x00018018529b;
                    puVar3 = puVar3 + 1;
                    uVar6 = uVar6 + 7;
                }
                if (iVar12 == 0) break;
                if (iVar12 == -1) {
code_r0x00018018529b:
                    iVar5 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                    fcn.180172b00(uVar4, 4, 0x1804a7c20, iVar5 + 1, 0x88, 0x1804a7c00);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                uVar13 = (uint64_t)
                         (((uint32_t)*(uint16_t *)(iVar5 + 8) - (uint32_t)*(uint16_t *)(iVar5 + 0xc)) + iVar12);
            }
            uVar10 = (int32_t)*(int16_t *)(iVar5 + 0xe) + uVar10 + (int32_t)uVar13;
            uVar9 = (uint64_t)uVar10;
            if (uVar16 < uVar10) break;
            fcn.180173cb0(arg1);
            uVar14 = uVar14 + uVar10;
            iVar17 = iVar17 + uVar9;
            uVar16 = uVar16 - uVar10;
        } while ((int32_t)(uint32_t)*(uint16_t *)(iVar5 + 8) <= (int32_t)uVar16);
    }
code_r0x0001801851e9:
    *(int64_t *)(arg1 + 0x90) = (int64_t)(int32_t)uVar16;
    *(undefined8 *)(arg1 + 0x88) = 0;
    if (uVar16 != 0) {
        if (iVar17 != *(int64_t *)(arg1 + 0x78)) {
            fcn.180498030(*(int64_t *)(arg1 + 0x78), iVar17);
        }
        if (*(uint64_t *)(arg1 + 0x80) < uVar9) {
            uVar16 = *(uint32_t *)(iVar5 + 4);
            if (uVar16 < (uint32_t)uVar9) {
                iVar17 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                uVar2 = *(undefined4 *)(iVar5 + 4);
                uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                fcn.180172b00(uVar4, 4, 0x1804a7c68, uVar2, iVar17 + 1, 0xa8, 0x1804a7c00);
                *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                fcn.180183710(arg1);
                return 0xffffffff;
            }
            uVar13 = *(uint64_t *)(arg1 + 0x80) * 2;
            if ((uVar9 <= uVar13) && (uVar9 = (uint64_t)uVar16, uVar13 <= uVar16)) {
                uVar9 = uVar13 & 0xffffffff;
            }
            fcn.1801735b0(arg1, uVar9);
        }
    }
    return (uint64_t)uVar14;
}

// ============================================================
// Function: FUN_180184e7e
// Address: 0x180184e7e
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_1ch
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

uint64_t fcn.180184df0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
                      int64_t arg_50h, int64_t arg_78h, int64_t arg_88h, int64_t arg_90h)
{
    uint16_t uVar1;
    undefined4 uVar2;
    uint8_t *puVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint8_t uVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    uint64_t uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb0;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t in_stack_ffffffffffffffd0;
    int64_t var_1ch;
    
    iVar7 = **(int32_t **)(arg1 + 0x178);
    iVar12 = (int32_t)arg3;
    iVar15 = (int32_t)arg2;
    if (iVar7 == 1) {
        iVar7 = (*(int32_t **)(arg1 + 0x178))[2];
        iVar5 = *(int64_t *)(arg1 + 0x78) + *(int64_t *)(arg1 + 0x88);
        uVar14 = 0;
        for (iVar12 = (iVar15 - (int32_t)iVar5) + iVar12; iVar7 <= iVar12; iVar12 = iVar12 - iVar7) {
            fcn.180173cb0(arg1, iVar5, iVar7);
            uVar14 = uVar14 + iVar7;
            iVar5 = iVar5 + iVar7;
        }
        *(int64_t *)(arg1 + 0x90) = (int64_t)iVar12;
        *(undefined8 *)(arg1 + 0x88) = 0;
        if ((iVar12 != 0) && (iVar5 != *(int64_t *)(arg1 + 0x78))) {
            fcn.180498030(*(int64_t *)(arg1 + 0x78), iVar5);
        }
        return (uint64_t)uVar14;
    }
    if (iVar7 == 2) {
        iVar5 = *(int64_t *)(arg1 + 0x178);
        uVar13 = *(int64_t *)(arg1 + 0x78) + *(int64_t *)(arg1 + 0x88);
        uVar1 = *(uint16_t *)(iVar5 + 0x10);
        uVar11 = (arg2 - (int32_t)(uint32_t)uVar1) + 1;
        uVar9 = uVar13;
        if (uVar13 <= uVar11) {
            uVar9 = uVar11;
        }
        uVar14 = 0;
        iVar7 = (iVar15 + iVar12) - (int32_t)uVar9;
        if ((int32_t)(uint32_t)uVar1 <= iVar7) {
            do {
                uVar11 = 0;
                if (uVar1 != 0) {
                    do {
                        if (*(char *)(uVar9 + uVar11) != *(char *)(iVar5 + 8 + uVar11)) {
                            uVar9 = uVar9 + 1;
                            iVar7 = iVar7 + -1;
                            goto code_r0x000180184f93;
                        }
                        uVar16 = (int32_t)uVar11 + 1;
                        uVar11 = (uint64_t)uVar16;
                    } while ((int32_t)uVar16 < (int32_t)(uint32_t)uVar1);
                }
                uVar9 = uVar9 + uVar1;
                iVar8 = (int32_t)uVar9 - (int32_t)uVar13;
                iVar7 = iVar7 - (uint32_t)uVar1;
                fcn.180173cb0(arg1, uVar13, iVar8);
                uVar14 = uVar14 + iVar8;
                uVar13 = uVar9;
code_r0x000180184f93:
            } while ((int32_t)(uint32_t)uVar1 <= iVar7);
        }
        iVar7 = (iVar15 + iVar12) - (int32_t)uVar13;
        *(int64_t *)(arg1 + 0x90) = (int64_t)iVar7;
        *(undefined8 *)(arg1 + 0x88) = 0;
        if (iVar7 != 0) {
            if (uVar13 != *(uint64_t *)(arg1 + 0x78)) {
                fcn.180498030(*(uint64_t *)(arg1 + 0x78), uVar13);
            }
            uVar9 = *(uint64_t *)(arg1 + 0x80);
            if (*(uint64_t *)(arg1 + 0x90) == uVar9) {
                uVar13 = (uint64_t)*(uint32_t *)(iVar5 + 4);
                if (uVar13 <= uVar9) {
                    iVar17 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar2 = *(undefined4 *)(iVar5 + 4);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffd0);
                    fcn.180172b00(uVar4, 4, 0x1804a7bd8, uVar2, iVar17 + 1, 0x5d, 0x1804a7b50);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                if (uVar9 * 2 < uVar13) {
                    uVar13 = uVar9 * 2 & 0xffffffff;
                }
                fcn.1801735b0(arg1, uVar13);
            }
        }
        return (uint64_t)uVar14;
    }
    if (iVar7 != 3) {
        fcn.180173cb0();
        return arg3 & 0xffffffff;
    }
    iVar5 = *(int64_t *)(arg1 + 0x178);
    iVar15 = iVar15 + iVar12;
    iVar17 = *(int64_t *)(arg1 + 0x88) + *(int64_t *)(arg1 + 0x78);
    uVar14 = 0;
    uVar16 = iVar15 - (int32_t)iVar17;
    uVar9 = (uint64_t)*(uint16_t *)(iVar5 + 8);
    uVar13 = uVar9;
    if ((int32_t)(uint32_t)*(uint16_t *)(iVar5 + 8) <= (int32_t)uVar16) {
        do {
            uVar11 = 0;
            uVar10 = 0;
            iVar7 = *(int32_t *)(iVar5 + 0x10);
            puVar3 = (uint8_t *)((uint64_t)*(uint16_t *)(iVar5 + 10) + iVar17);
            if (iVar7 == 0x10e1) {
                iVar7 = 0;
                if (*(uint16_t *)(iVar5 + 0xc) != 0) {
                    do {
                        uVar6 = *puVar3;
                        puVar3 = puVar3 + 1;
                        iVar7 = iVar7 + 1;
                        uVar10 = (int32_t)uVar11 << 8 | (uint32_t)uVar6;
                        uVar11 = (uint64_t)uVar10;
                    } while (iVar7 < (int32_t)(uint32_t)*(uint16_t *)(iVar5 + 0xc));
                }
            } else if (iVar7 == 0x4d2) {
                iVar7 = 0;
                if (*(uint16_t *)(iVar5 + 0xc) != 0) {
                    do {
                        uVar6 = *puVar3;
                        puVar3 = puVar3 + 1;
                        uVar10 = (uint32_t)uVar11 | (uint32_t)uVar6 << ((char)iVar7 * '\b' & 0x1fU);
                        uVar11 = (uint64_t)uVar10;
                        iVar7 = iVar7 + 1;
                    } while (iVar7 < (int32_t)(uint32_t)*(uint16_t *)(iVar5 + 0xc));
                }
            } else {
                if (iVar7 != 0x11) {
                    iVar5 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                    fcn.180172b00(uVar4, 4, 0x1804a7c40, iVar5 + 1, 0x8f, 0x1804a7c00);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3f3;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                iVar12 = 0;
                iVar7 = (int32_t)puVar3;
                uVar6 = 0;
                while( true ) {
                    if ((iVar15 != iVar7) && (iVar12 == iVar15 - iVar7)) goto code_r0x0001801851e9;
                    iVar12 = iVar12 + 1;
                    uVar11 = uVar11 | (uint64_t)(*puVar3 & 0x7f) << (uVar6 & 0x3f);
                    uVar10 = (uint32_t)uVar11;
                    if (-1 < (char)*puVar3) break;
                    if (9 < iVar12) goto code_r0x00018018529b;
                    puVar3 = puVar3 + 1;
                    uVar6 = uVar6 + 7;
                }
                if (iVar12 == 0) break;
                if (iVar12 == -1) {
code_r0x00018018529b:
                    iVar5 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                    fcn.180172b00(uVar4, 4, 0x1804a7c20, iVar5 + 1, 0x88, 0x1804a7c00);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                uVar13 = (uint64_t)
                         (((uint32_t)*(uint16_t *)(iVar5 + 8) - (uint32_t)*(uint16_t *)(iVar5 + 0xc)) + iVar12);
            }
            uVar10 = (int32_t)*(int16_t *)(iVar5 + 0xe) + uVar10 + (int32_t)uVar13;
            uVar9 = (uint64_t)uVar10;
            if (uVar16 < uVar10) break;
            fcn.180173cb0(arg1);
            uVar14 = uVar14 + uVar10;
            iVar17 = iVar17 + uVar9;
            uVar16 = uVar16 - uVar10;
        } while ((int32_t)(uint32_t)*(uint16_t *)(iVar5 + 8) <= (int32_t)uVar16);
    }
code_r0x0001801851e9:
    *(int64_t *)(arg1 + 0x90) = (int64_t)(int32_t)uVar16;
    *(undefined8 *)(arg1 + 0x88) = 0;
    if (uVar16 != 0) {
        if (iVar17 != *(int64_t *)(arg1 + 0x78)) {
            fcn.180498030(*(int64_t *)(arg1 + 0x78), iVar17);
        }
        if (*(uint64_t *)(arg1 + 0x80) < uVar9) {
            uVar16 = *(uint32_t *)(iVar5 + 4);
            if (uVar16 < (uint32_t)uVar9) {
                iVar17 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                uVar2 = *(undefined4 *)(iVar5 + 4);
                uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                fcn.180172b00(uVar4, 4, 0x1804a7c68, uVar2, iVar17 + 1, 0xa8, 0x1804a7c00);
                *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                fcn.180183710(arg1);
                return 0xffffffff;
            }
            uVar13 = *(uint64_t *)(arg1 + 0x80) * 2;
            if ((uVar9 <= uVar13) && (uVar9 = (uint64_t)uVar16, uVar13 <= uVar16)) {
                uVar9 = uVar13 & 0xffffffff;
            }
            fcn.1801735b0(arg1, uVar9);
        }
    }
    return (uint64_t)uVar14;
}

// ============================================================
// Function: FUN_180184eaf
// Address: 0x180184eaf
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_1ch
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

uint64_t fcn.180184df0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
                      int64_t arg_50h, int64_t arg_78h, int64_t arg_88h, int64_t arg_90h)
{
    uint16_t uVar1;
    undefined4 uVar2;
    uint8_t *puVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint8_t uVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    uint64_t uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb0;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t in_stack_ffffffffffffffd0;
    int64_t var_1ch;
    
    iVar7 = **(int32_t **)(arg1 + 0x178);
    iVar12 = (int32_t)arg3;
    iVar15 = (int32_t)arg2;
    if (iVar7 == 1) {
        iVar7 = (*(int32_t **)(arg1 + 0x178))[2];
        iVar5 = *(int64_t *)(arg1 + 0x78) + *(int64_t *)(arg1 + 0x88);
        uVar14 = 0;
        for (iVar12 = (iVar15 - (int32_t)iVar5) + iVar12; iVar7 <= iVar12; iVar12 = iVar12 - iVar7) {
            fcn.180173cb0(arg1, iVar5, iVar7);
            uVar14 = uVar14 + iVar7;
            iVar5 = iVar5 + iVar7;
        }
        *(int64_t *)(arg1 + 0x90) = (int64_t)iVar12;
        *(undefined8 *)(arg1 + 0x88) = 0;
        if ((iVar12 != 0) && (iVar5 != *(int64_t *)(arg1 + 0x78))) {
            fcn.180498030(*(int64_t *)(arg1 + 0x78), iVar5);
        }
        return (uint64_t)uVar14;
    }
    if (iVar7 == 2) {
        iVar5 = *(int64_t *)(arg1 + 0x178);
        uVar13 = *(int64_t *)(arg1 + 0x78) + *(int64_t *)(arg1 + 0x88);
        uVar1 = *(uint16_t *)(iVar5 + 0x10);
        uVar11 = (arg2 - (int32_t)(uint32_t)uVar1) + 1;
        uVar9 = uVar13;
        if (uVar13 <= uVar11) {
            uVar9 = uVar11;
        }
        uVar14 = 0;
        iVar7 = (iVar15 + iVar12) - (int32_t)uVar9;
        if ((int32_t)(uint32_t)uVar1 <= iVar7) {
            do {
                uVar11 = 0;
                if (uVar1 != 0) {
                    do {
                        if (*(char *)(uVar9 + uVar11) != *(char *)(iVar5 + 8 + uVar11)) {
                            uVar9 = uVar9 + 1;
                            iVar7 = iVar7 + -1;
                            goto code_r0x000180184f93;
                        }
                        uVar16 = (int32_t)uVar11 + 1;
                        uVar11 = (uint64_t)uVar16;
                    } while ((int32_t)uVar16 < (int32_t)(uint32_t)uVar1);
                }
                uVar9 = uVar9 + uVar1;
                iVar8 = (int32_t)uVar9 - (int32_t)uVar13;
                iVar7 = iVar7 - (uint32_t)uVar1;
                fcn.180173cb0(arg1, uVar13, iVar8);
                uVar14 = uVar14 + iVar8;
                uVar13 = uVar9;
code_r0x000180184f93:
            } while ((int32_t)(uint32_t)uVar1 <= iVar7);
        }
        iVar7 = (iVar15 + iVar12) - (int32_t)uVar13;
        *(int64_t *)(arg1 + 0x90) = (int64_t)iVar7;
        *(undefined8 *)(arg1 + 0x88) = 0;
        if (iVar7 != 0) {
            if (uVar13 != *(uint64_t *)(arg1 + 0x78)) {
                fcn.180498030(*(uint64_t *)(arg1 + 0x78), uVar13);
            }
            uVar9 = *(uint64_t *)(arg1 + 0x80);
            if (*(uint64_t *)(arg1 + 0x90) == uVar9) {
                uVar13 = (uint64_t)*(uint32_t *)(iVar5 + 4);
                if (uVar13 <= uVar9) {
                    iVar17 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar2 = *(undefined4 *)(iVar5 + 4);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffd0);
                    fcn.180172b00(uVar4, 4, 0x1804a7bd8, uVar2, iVar17 + 1, 0x5d, 0x1804a7b50);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                if (uVar9 * 2 < uVar13) {
                    uVar13 = uVar9 * 2 & 0xffffffff;
                }
                fcn.1801735b0(arg1, uVar13);
            }
        }
        return (uint64_t)uVar14;
    }
    if (iVar7 != 3) {
        fcn.180173cb0();
        return arg3 & 0xffffffff;
    }
    iVar5 = *(int64_t *)(arg1 + 0x178);
    iVar15 = iVar15 + iVar12;
    iVar17 = *(int64_t *)(arg1 + 0x88) + *(int64_t *)(arg1 + 0x78);
    uVar14 = 0;
    uVar16 = iVar15 - (int32_t)iVar17;
    uVar9 = (uint64_t)*(uint16_t *)(iVar5 + 8);
    uVar13 = uVar9;
    if ((int32_t)(uint32_t)*(uint16_t *)(iVar5 + 8) <= (int32_t)uVar16) {
        do {
            uVar11 = 0;
            uVar10 = 0;
            iVar7 = *(int32_t *)(iVar5 + 0x10);
            puVar3 = (uint8_t *)((uint64_t)*(uint16_t *)(iVar5 + 10) + iVar17);
            if (iVar7 == 0x10e1) {
                iVar7 = 0;
                if (*(uint16_t *)(iVar5 + 0xc) != 0) {
                    do {
                        uVar6 = *puVar3;
                        puVar3 = puVar3 + 1;
                        iVar7 = iVar7 + 1;
                        uVar10 = (int32_t)uVar11 << 8 | (uint32_t)uVar6;
                        uVar11 = (uint64_t)uVar10;
                    } while (iVar7 < (int32_t)(uint32_t)*(uint16_t *)(iVar5 + 0xc));
                }
            } else if (iVar7 == 0x4d2) {
                iVar7 = 0;
                if (*(uint16_t *)(iVar5 + 0xc) != 0) {
                    do {
                        uVar6 = *puVar3;
                        puVar3 = puVar3 + 1;
                        uVar10 = (uint32_t)uVar11 | (uint32_t)uVar6 << ((char)iVar7 * '\b' & 0x1fU);
                        uVar11 = (uint64_t)uVar10;
                        iVar7 = iVar7 + 1;
                    } while (iVar7 < (int32_t)(uint32_t)*(uint16_t *)(iVar5 + 0xc));
                }
            } else {
                if (iVar7 != 0x11) {
                    iVar5 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                    fcn.180172b00(uVar4, 4, 0x1804a7c40, iVar5 + 1, 0x8f, 0x1804a7c00);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3f3;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                iVar12 = 0;
                iVar7 = (int32_t)puVar3;
                uVar6 = 0;
                while( true ) {
                    if ((iVar15 != iVar7) && (iVar12 == iVar15 - iVar7)) goto code_r0x0001801851e9;
                    iVar12 = iVar12 + 1;
                    uVar11 = uVar11 | (uint64_t)(*puVar3 & 0x7f) << (uVar6 & 0x3f);
                    uVar10 = (uint32_t)uVar11;
                    if (-1 < (char)*puVar3) break;
                    if (9 < iVar12) goto code_r0x00018018529b;
                    puVar3 = puVar3 + 1;
                    uVar6 = uVar6 + 7;
                }
                if (iVar12 == 0) break;
                if (iVar12 == -1) {
code_r0x00018018529b:
                    iVar5 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                    fcn.180172b00(uVar4, 4, 0x1804a7c20, iVar5 + 1, 0x88, 0x1804a7c00);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                uVar13 = (uint64_t)
                         (((uint32_t)*(uint16_t *)(iVar5 + 8) - (uint32_t)*(uint16_t *)(iVar5 + 0xc)) + iVar12);
            }
            uVar10 = (int32_t)*(int16_t *)(iVar5 + 0xe) + uVar10 + (int32_t)uVar13;
            uVar9 = (uint64_t)uVar10;
            if (uVar16 < uVar10) break;
            fcn.180173cb0(arg1);
            uVar14 = uVar14 + uVar10;
            iVar17 = iVar17 + uVar9;
            uVar16 = uVar16 - uVar10;
        } while ((int32_t)(uint32_t)*(uint16_t *)(iVar5 + 8) <= (int32_t)uVar16);
    }
code_r0x0001801851e9:
    *(int64_t *)(arg1 + 0x90) = (int64_t)(int32_t)uVar16;
    *(undefined8 *)(arg1 + 0x88) = 0;
    if (uVar16 != 0) {
        if (iVar17 != *(int64_t *)(arg1 + 0x78)) {
            fcn.180498030(*(int64_t *)(arg1 + 0x78), iVar17);
        }
        if (*(uint64_t *)(arg1 + 0x80) < uVar9) {
            uVar16 = *(uint32_t *)(iVar5 + 4);
            if (uVar16 < (uint32_t)uVar9) {
                iVar17 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                uVar2 = *(undefined4 *)(iVar5 + 4);
                uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                fcn.180172b00(uVar4, 4, 0x1804a7c68, uVar2, iVar17 + 1, 0xa8, 0x1804a7c00);
                *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                fcn.180183710(arg1);
                return 0xffffffff;
            }
            uVar13 = *(uint64_t *)(arg1 + 0x80) * 2;
            if ((uVar9 <= uVar13) && (uVar9 = (uint64_t)uVar16, uVar13 <= uVar16)) {
                uVar9 = uVar13 & 0xffffffff;
            }
            fcn.1801735b0(arg1, uVar9);
        }
    }
    return (uint64_t)uVar14;
}

// ============================================================
// Function: FUN_180184ef0
// Address: 0x180184ef0
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_1ch
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

uint64_t fcn.180184df0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
                      int64_t arg_50h, int64_t arg_78h, int64_t arg_88h, int64_t arg_90h)
{
    uint16_t uVar1;
    undefined4 uVar2;
    uint8_t *puVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint8_t uVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    uint64_t uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb0;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t in_stack_ffffffffffffffd0;
    int64_t var_1ch;
    
    iVar7 = **(int32_t **)(arg1 + 0x178);
    iVar12 = (int32_t)arg3;
    iVar15 = (int32_t)arg2;
    if (iVar7 == 1) {
        iVar7 = (*(int32_t **)(arg1 + 0x178))[2];
        iVar5 = *(int64_t *)(arg1 + 0x78) + *(int64_t *)(arg1 + 0x88);
        uVar14 = 0;
        for (iVar12 = (iVar15 - (int32_t)iVar5) + iVar12; iVar7 <= iVar12; iVar12 = iVar12 - iVar7) {
            fcn.180173cb0(arg1, iVar5, iVar7);
            uVar14 = uVar14 + iVar7;
            iVar5 = iVar5 + iVar7;
        }
        *(int64_t *)(arg1 + 0x90) = (int64_t)iVar12;
        *(undefined8 *)(arg1 + 0x88) = 0;
        if ((iVar12 != 0) && (iVar5 != *(int64_t *)(arg1 + 0x78))) {
            fcn.180498030(*(int64_t *)(arg1 + 0x78), iVar5);
        }
        return (uint64_t)uVar14;
    }
    if (iVar7 == 2) {
        iVar5 = *(int64_t *)(arg1 + 0x178);
        uVar13 = *(int64_t *)(arg1 + 0x78) + *(int64_t *)(arg1 + 0x88);
        uVar1 = *(uint16_t *)(iVar5 + 0x10);
        uVar11 = (arg2 - (int32_t)(uint32_t)uVar1) + 1;
        uVar9 = uVar13;
        if (uVar13 <= uVar11) {
            uVar9 = uVar11;
        }
        uVar14 = 0;
        iVar7 = (iVar15 + iVar12) - (int32_t)uVar9;
        if ((int32_t)(uint32_t)uVar1 <= iVar7) {
            do {
                uVar11 = 0;
                if (uVar1 != 0) {
                    do {
                        if (*(char *)(uVar9 + uVar11) != *(char *)(iVar5 + 8 + uVar11)) {
                            uVar9 = uVar9 + 1;
                            iVar7 = iVar7 + -1;
                            goto code_r0x000180184f93;
                        }
                        uVar16 = (int32_t)uVar11 + 1;
                        uVar11 = (uint64_t)uVar16;
                    } while ((int32_t)uVar16 < (int32_t)(uint32_t)uVar1);
                }
                uVar9 = uVar9 + uVar1;
                iVar8 = (int32_t)uVar9 - (int32_t)uVar13;
                iVar7 = iVar7 - (uint32_t)uVar1;
                fcn.180173cb0(arg1, uVar13, iVar8);
                uVar14 = uVar14 + iVar8;
                uVar13 = uVar9;
code_r0x000180184f93:
            } while ((int32_t)(uint32_t)uVar1 <= iVar7);
        }
        iVar7 = (iVar15 + iVar12) - (int32_t)uVar13;
        *(int64_t *)(arg1 + 0x90) = (int64_t)iVar7;
        *(undefined8 *)(arg1 + 0x88) = 0;
        if (iVar7 != 0) {
            if (uVar13 != *(uint64_t *)(arg1 + 0x78)) {
                fcn.180498030(*(uint64_t *)(arg1 + 0x78), uVar13);
            }
            uVar9 = *(uint64_t *)(arg1 + 0x80);
            if (*(uint64_t *)(arg1 + 0x90) == uVar9) {
                uVar13 = (uint64_t)*(uint32_t *)(iVar5 + 4);
                if (uVar13 <= uVar9) {
                    iVar17 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar2 = *(undefined4 *)(iVar5 + 4);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffd0);
                    fcn.180172b00(uVar4, 4, 0x1804a7bd8, uVar2, iVar17 + 1, 0x5d, 0x1804a7b50);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                if (uVar9 * 2 < uVar13) {
                    uVar13 = uVar9 * 2 & 0xffffffff;
                }
                fcn.1801735b0(arg1, uVar13);
            }
        }
        return (uint64_t)uVar14;
    }
    if (iVar7 != 3) {
        fcn.180173cb0();
        return arg3 & 0xffffffff;
    }
    iVar5 = *(int64_t *)(arg1 + 0x178);
    iVar15 = iVar15 + iVar12;
    iVar17 = *(int64_t *)(arg1 + 0x88) + *(int64_t *)(arg1 + 0x78);
    uVar14 = 0;
    uVar16 = iVar15 - (int32_t)iVar17;
    uVar9 = (uint64_t)*(uint16_t *)(iVar5 + 8);
    uVar13 = uVar9;
    if ((int32_t)(uint32_t)*(uint16_t *)(iVar5 + 8) <= (int32_t)uVar16) {
        do {
            uVar11 = 0;
            uVar10 = 0;
            iVar7 = *(int32_t *)(iVar5 + 0x10);
            puVar3 = (uint8_t *)((uint64_t)*(uint16_t *)(iVar5 + 10) + iVar17);
            if (iVar7 == 0x10e1) {
                iVar7 = 0;
                if (*(uint16_t *)(iVar5 + 0xc) != 0) {
                    do {
                        uVar6 = *puVar3;
                        puVar3 = puVar3 + 1;
                        iVar7 = iVar7 + 1;
                        uVar10 = (int32_t)uVar11 << 8 | (uint32_t)uVar6;
                        uVar11 = (uint64_t)uVar10;
                    } while (iVar7 < (int32_t)(uint32_t)*(uint16_t *)(iVar5 + 0xc));
                }
            } else if (iVar7 == 0x4d2) {
                iVar7 = 0;
                if (*(uint16_t *)(iVar5 + 0xc) != 0) {
                    do {
                        uVar6 = *puVar3;
                        puVar3 = puVar3 + 1;
                        uVar10 = (uint32_t)uVar11 | (uint32_t)uVar6 << ((char)iVar7 * '\b' & 0x1fU);
                        uVar11 = (uint64_t)uVar10;
                        iVar7 = iVar7 + 1;
                    } while (iVar7 < (int32_t)(uint32_t)*(uint16_t *)(iVar5 + 0xc));
                }
            } else {
                if (iVar7 != 0x11) {
                    iVar5 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                    fcn.180172b00(uVar4, 4, 0x1804a7c40, iVar5 + 1, 0x8f, 0x1804a7c00);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3f3;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                iVar12 = 0;
                iVar7 = (int32_t)puVar3;
                uVar6 = 0;
                while( true ) {
                    if ((iVar15 != iVar7) && (iVar12 == iVar15 - iVar7)) goto code_r0x0001801851e9;
                    iVar12 = iVar12 + 1;
                    uVar11 = uVar11 | (uint64_t)(*puVar3 & 0x7f) << (uVar6 & 0x3f);
                    uVar10 = (uint32_t)uVar11;
                    if (-1 < (char)*puVar3) break;
                    if (9 < iVar12) goto code_r0x00018018529b;
                    puVar3 = puVar3 + 1;
                    uVar6 = uVar6 + 7;
                }
                if (iVar12 == 0) break;
                if (iVar12 == -1) {
code_r0x00018018529b:
                    iVar5 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                    fcn.180172b00(uVar4, 4, 0x1804a7c20, iVar5 + 1, 0x88, 0x1804a7c00);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                uVar13 = (uint64_t)
                         (((uint32_t)*(uint16_t *)(iVar5 + 8) - (uint32_t)*(uint16_t *)(iVar5 + 0xc)) + iVar12);
            }
            uVar10 = (int32_t)*(int16_t *)(iVar5 + 0xe) + uVar10 + (int32_t)uVar13;
            uVar9 = (uint64_t)uVar10;
            if (uVar16 < uVar10) break;
            fcn.180173cb0(arg1);
            uVar14 = uVar14 + uVar10;
            iVar17 = iVar17 + uVar9;
            uVar16 = uVar16 - uVar10;
        } while ((int32_t)(uint32_t)*(uint16_t *)(iVar5 + 8) <= (int32_t)uVar16);
    }
code_r0x0001801851e9:
    *(int64_t *)(arg1 + 0x90) = (int64_t)(int32_t)uVar16;
    *(undefined8 *)(arg1 + 0x88) = 0;
    if (uVar16 != 0) {
        if (iVar17 != *(int64_t *)(arg1 + 0x78)) {
            fcn.180498030(*(int64_t *)(arg1 + 0x78), iVar17);
        }
        if (*(uint64_t *)(arg1 + 0x80) < uVar9) {
            uVar16 = *(uint32_t *)(iVar5 + 4);
            if (uVar16 < (uint32_t)uVar9) {
                iVar17 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                uVar2 = *(undefined4 *)(iVar5 + 4);
                uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                fcn.180172b00(uVar4, 4, 0x1804a7c68, uVar2, iVar17 + 1, 0xa8, 0x1804a7c00);
                *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                fcn.180183710(arg1);
                return 0xffffffff;
            }
            uVar13 = *(uint64_t *)(arg1 + 0x80) * 2;
            if ((uVar9 <= uVar13) && (uVar9 = (uint64_t)uVar16, uVar13 <= uVar16)) {
                uVar9 = uVar13 & 0xffffffff;
            }
            fcn.1801735b0(arg1, uVar9);
        }
    }
    return (uint64_t)uVar14;
}

// ============================================================
// Function: FUN_180184f15
// Address: 0x180184f15
// Size: 178 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_1ch
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

uint64_t fcn.180184df0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
                      int64_t arg_50h, int64_t arg_78h, int64_t arg_88h, int64_t arg_90h)
{
    uint16_t uVar1;
    undefined4 uVar2;
    uint8_t *puVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint8_t uVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    uint64_t uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb0;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t in_stack_ffffffffffffffd0;
    int64_t var_1ch;
    
    iVar7 = **(int32_t **)(arg1 + 0x178);
    iVar12 = (int32_t)arg3;
    iVar15 = (int32_t)arg2;
    if (iVar7 == 1) {
        iVar7 = (*(int32_t **)(arg1 + 0x178))[2];
        iVar5 = *(int64_t *)(arg1 + 0x78) + *(int64_t *)(arg1 + 0x88);
        uVar14 = 0;
        for (iVar12 = (iVar15 - (int32_t)iVar5) + iVar12; iVar7 <= iVar12; iVar12 = iVar12 - iVar7) {
            fcn.180173cb0(arg1, iVar5, iVar7);
            uVar14 = uVar14 + iVar7;
            iVar5 = iVar5 + iVar7;
        }
        *(int64_t *)(arg1 + 0x90) = (int64_t)iVar12;
        *(undefined8 *)(arg1 + 0x88) = 0;
        if ((iVar12 != 0) && (iVar5 != *(int64_t *)(arg1 + 0x78))) {
            fcn.180498030(*(int64_t *)(arg1 + 0x78), iVar5);
        }
        return (uint64_t)uVar14;
    }
    if (iVar7 == 2) {
        iVar5 = *(int64_t *)(arg1 + 0x178);
        uVar13 = *(int64_t *)(arg1 + 0x78) + *(int64_t *)(arg1 + 0x88);
        uVar1 = *(uint16_t *)(iVar5 + 0x10);
        uVar11 = (arg2 - (int32_t)(uint32_t)uVar1) + 1;
        uVar9 = uVar13;
        if (uVar13 <= uVar11) {
            uVar9 = uVar11;
        }
        uVar14 = 0;
        iVar7 = (iVar15 + iVar12) - (int32_t)uVar9;
        if ((int32_t)(uint32_t)uVar1 <= iVar7) {
            do {
                uVar11 = 0;
                if (uVar1 != 0) {
                    do {
                        if (*(char *)(uVar9 + uVar11) != *(char *)(iVar5 + 8 + uVar11)) {
                            uVar9 = uVar9 + 1;
                            iVar7 = iVar7 + -1;
                            goto code_r0x000180184f93;
                        }
                        uVar16 = (int32_t)uVar11 + 1;
                        uVar11 = (uint64_t)uVar16;
                    } while ((int32_t)uVar16 < (int32_t)(uint32_t)uVar1);
                }
                uVar9 = uVar9 + uVar1;
                iVar8 = (int32_t)uVar9 - (int32_t)uVar13;
                iVar7 = iVar7 - (uint32_t)uVar1;
                fcn.180173cb0(arg1, uVar13, iVar8);
                uVar14 = uVar14 + iVar8;
                uVar13 = uVar9;
code_r0x000180184f93:
            } while ((int32_t)(uint32_t)uVar1 <= iVar7);
        }
        iVar7 = (iVar15 + iVar12) - (int32_t)uVar13;
        *(int64_t *)(arg1 + 0x90) = (int64_t)iVar7;
        *(undefined8 *)(arg1 + 0x88) = 0;
        if (iVar7 != 0) {
            if (uVar13 != *(uint64_t *)(arg1 + 0x78)) {
                fcn.180498030(*(uint64_t *)(arg1 + 0x78), uVar13);
            }
            uVar9 = *(uint64_t *)(arg1 + 0x80);
            if (*(uint64_t *)(arg1 + 0x90) == uVar9) {
                uVar13 = (uint64_t)*(uint32_t *)(iVar5 + 4);
                if (uVar13 <= uVar9) {
                    iVar17 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar2 = *(undefined4 *)(iVar5 + 4);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffd0);
                    fcn.180172b00(uVar4, 4, 0x1804a7bd8, uVar2, iVar17 + 1, 0x5d, 0x1804a7b50);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                if (uVar9 * 2 < uVar13) {
                    uVar13 = uVar9 * 2 & 0xffffffff;
                }
                fcn.1801735b0(arg1, uVar13);
            }
        }
        return (uint64_t)uVar14;
    }
    if (iVar7 != 3) {
        fcn.180173cb0();
        return arg3 & 0xffffffff;
    }
    iVar5 = *(int64_t *)(arg1 + 0x178);
    iVar15 = iVar15 + iVar12;
    iVar17 = *(int64_t *)(arg1 + 0x88) + *(int64_t *)(arg1 + 0x78);
    uVar14 = 0;
    uVar16 = iVar15 - (int32_t)iVar17;
    uVar9 = (uint64_t)*(uint16_t *)(iVar5 + 8);
    uVar13 = uVar9;
    if ((int32_t)(uint32_t)*(uint16_t *)(iVar5 + 8) <= (int32_t)uVar16) {
        do {
            uVar11 = 0;
            uVar10 = 0;
            iVar7 = *(int32_t *)(iVar5 + 0x10);
            puVar3 = (uint8_t *)((uint64_t)*(uint16_t *)(iVar5 + 10) + iVar17);
            if (iVar7 == 0x10e1) {
                iVar7 = 0;
                if (*(uint16_t *)(iVar5 + 0xc) != 0) {
                    do {
                        uVar6 = *puVar3;
                        puVar3 = puVar3 + 1;
                        iVar7 = iVar7 + 1;
                        uVar10 = (int32_t)uVar11 << 8 | (uint32_t)uVar6;
                        uVar11 = (uint64_t)uVar10;
                    } while (iVar7 < (int32_t)(uint32_t)*(uint16_t *)(iVar5 + 0xc));
                }
            } else if (iVar7 == 0x4d2) {
                iVar7 = 0;
                if (*(uint16_t *)(iVar5 + 0xc) != 0) {
                    do {
                        uVar6 = *puVar3;
                        puVar3 = puVar3 + 1;
                        uVar10 = (uint32_t)uVar11 | (uint32_t)uVar6 << ((char)iVar7 * '\b' & 0x1fU);
                        uVar11 = (uint64_t)uVar10;
                        iVar7 = iVar7 + 1;
                    } while (iVar7 < (int32_t)(uint32_t)*(uint16_t *)(iVar5 + 0xc));
                }
            } else {
                if (iVar7 != 0x11) {
                    iVar5 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                    fcn.180172b00(uVar4, 4, 0x1804a7c40, iVar5 + 1, 0x8f, 0x1804a7c00);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3f3;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                iVar12 = 0;
                iVar7 = (int32_t)puVar3;
                uVar6 = 0;
                while( true ) {
                    if ((iVar15 != iVar7) && (iVar12 == iVar15 - iVar7)) goto code_r0x0001801851e9;
                    iVar12 = iVar12 + 1;
                    uVar11 = uVar11 | (uint64_t)(*puVar3 & 0x7f) << (uVar6 & 0x3f);
                    uVar10 = (uint32_t)uVar11;
                    if (-1 < (char)*puVar3) break;
                    if (9 < iVar12) goto code_r0x00018018529b;
                    puVar3 = puVar3 + 1;
                    uVar6 = uVar6 + 7;
                }
                if (iVar12 == 0) break;
                if (iVar12 == -1) {
code_r0x00018018529b:
                    iVar5 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                    fcn.180172b00(uVar4, 4, 0x1804a7c20, iVar5 + 1, 0x88, 0x1804a7c00);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                uVar13 = (uint64_t)
                         (((uint32_t)*(uint16_t *)(iVar5 + 8) - (uint32_t)*(uint16_t *)(iVar5 + 0xc)) + iVar12);
            }
            uVar10 = (int32_t)*(int16_t *)(iVar5 + 0xe) + uVar10 + (int32_t)uVar13;
            uVar9 = (uint64_t)uVar10;
            if (uVar16 < uVar10) break;
            fcn.180173cb0(arg1);
            uVar14 = uVar14 + uVar10;
            iVar17 = iVar17 + uVar9;
            uVar16 = uVar16 - uVar10;
        } while ((int32_t)(uint32_t)*(uint16_t *)(iVar5 + 8) <= (int32_t)uVar16);
    }
code_r0x0001801851e9:
    *(int64_t *)(arg1 + 0x90) = (int64_t)(int32_t)uVar16;
    *(undefined8 *)(arg1 + 0x88) = 0;
    if (uVar16 != 0) {
        if (iVar17 != *(int64_t *)(arg1 + 0x78)) {
            fcn.180498030(*(int64_t *)(arg1 + 0x78), iVar17);
        }
        if (*(uint64_t *)(arg1 + 0x80) < uVar9) {
            uVar16 = *(uint32_t *)(iVar5 + 4);
            if (uVar16 < (uint32_t)uVar9) {
                iVar17 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                uVar2 = *(undefined4 *)(iVar5 + 4);
                uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                fcn.180172b00(uVar4, 4, 0x1804a7c68, uVar2, iVar17 + 1, 0xa8, 0x1804a7c00);
                *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                fcn.180183710(arg1);
                return 0xffffffff;
            }
            uVar13 = *(uint64_t *)(arg1 + 0x80) * 2;
            if ((uVar9 <= uVar13) && (uVar9 = (uint64_t)uVar16, uVar13 <= uVar16)) {
                uVar9 = uVar13 & 0xffffffff;
            }
            fcn.1801735b0(arg1, uVar9);
        }
    }
    return (uint64_t)uVar14;
}

// ============================================================
// Function: FUN_180184fc7
// Address: 0x180184fc7
// Size: 158 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_1ch
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

uint64_t fcn.180184df0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
                      int64_t arg_50h, int64_t arg_78h, int64_t arg_88h, int64_t arg_90h)
{
    uint16_t uVar1;
    undefined4 uVar2;
    uint8_t *puVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint8_t uVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    uint64_t uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb0;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t in_stack_ffffffffffffffd0;
    int64_t var_1ch;
    
    iVar7 = **(int32_t **)(arg1 + 0x178);
    iVar12 = (int32_t)arg3;
    iVar15 = (int32_t)arg2;
    if (iVar7 == 1) {
        iVar7 = (*(int32_t **)(arg1 + 0x178))[2];
        iVar5 = *(int64_t *)(arg1 + 0x78) + *(int64_t *)(arg1 + 0x88);
        uVar14 = 0;
        for (iVar12 = (iVar15 - (int32_t)iVar5) + iVar12; iVar7 <= iVar12; iVar12 = iVar12 - iVar7) {
            fcn.180173cb0(arg1, iVar5, iVar7);
            uVar14 = uVar14 + iVar7;
            iVar5 = iVar5 + iVar7;
        }
        *(int64_t *)(arg1 + 0x90) = (int64_t)iVar12;
        *(undefined8 *)(arg1 + 0x88) = 0;
        if ((iVar12 != 0) && (iVar5 != *(int64_t *)(arg1 + 0x78))) {
            fcn.180498030(*(int64_t *)(arg1 + 0x78), iVar5);
        }
        return (uint64_t)uVar14;
    }
    if (iVar7 == 2) {
        iVar5 = *(int64_t *)(arg1 + 0x178);
        uVar13 = *(int64_t *)(arg1 + 0x78) + *(int64_t *)(arg1 + 0x88);
        uVar1 = *(uint16_t *)(iVar5 + 0x10);
        uVar11 = (arg2 - (int32_t)(uint32_t)uVar1) + 1;
        uVar9 = uVar13;
        if (uVar13 <= uVar11) {
            uVar9 = uVar11;
        }
        uVar14 = 0;
        iVar7 = (iVar15 + iVar12) - (int32_t)uVar9;
        if ((int32_t)(uint32_t)uVar1 <= iVar7) {
            do {
                uVar11 = 0;
                if (uVar1 != 0) {
                    do {
                        if (*(char *)(uVar9 + uVar11) != *(char *)(iVar5 + 8 + uVar11)) {
                            uVar9 = uVar9 + 1;
                            iVar7 = iVar7 + -1;
                            goto code_r0x000180184f93;
                        }
                        uVar16 = (int32_t)uVar11 + 1;
                        uVar11 = (uint64_t)uVar16;
                    } while ((int32_t)uVar16 < (int32_t)(uint32_t)uVar1);
                }
                uVar9 = uVar9 + uVar1;
                iVar8 = (int32_t)uVar9 - (int32_t)uVar13;
                iVar7 = iVar7 - (uint32_t)uVar1;
                fcn.180173cb0(arg1, uVar13, iVar8);
                uVar14 = uVar14 + iVar8;
                uVar13 = uVar9;
code_r0x000180184f93:
            } while ((int32_t)(uint32_t)uVar1 <= iVar7);
        }
        iVar7 = (iVar15 + iVar12) - (int32_t)uVar13;
        *(int64_t *)(arg1 + 0x90) = (int64_t)iVar7;
        *(undefined8 *)(arg1 + 0x88) = 0;
        if (iVar7 != 0) {
            if (uVar13 != *(uint64_t *)(arg1 + 0x78)) {
                fcn.180498030(*(uint64_t *)(arg1 + 0x78), uVar13);
            }
            uVar9 = *(uint64_t *)(arg1 + 0x80);
            if (*(uint64_t *)(arg1 + 0x90) == uVar9) {
                uVar13 = (uint64_t)*(uint32_t *)(iVar5 + 4);
                if (uVar13 <= uVar9) {
                    iVar17 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar2 = *(undefined4 *)(iVar5 + 4);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffd0);
                    fcn.180172b00(uVar4, 4, 0x1804a7bd8, uVar2, iVar17 + 1, 0x5d, 0x1804a7b50);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                if (uVar9 * 2 < uVar13) {
                    uVar13 = uVar9 * 2 & 0xffffffff;
                }
                fcn.1801735b0(arg1, uVar13);
            }
        }
        return (uint64_t)uVar14;
    }
    if (iVar7 != 3) {
        fcn.180173cb0();
        return arg3 & 0xffffffff;
    }
    iVar5 = *(int64_t *)(arg1 + 0x178);
    iVar15 = iVar15 + iVar12;
    iVar17 = *(int64_t *)(arg1 + 0x88) + *(int64_t *)(arg1 + 0x78);
    uVar14 = 0;
    uVar16 = iVar15 - (int32_t)iVar17;
    uVar9 = (uint64_t)*(uint16_t *)(iVar5 + 8);
    uVar13 = uVar9;
    if ((int32_t)(uint32_t)*(uint16_t *)(iVar5 + 8) <= (int32_t)uVar16) {
        do {
            uVar11 = 0;
            uVar10 = 0;
            iVar7 = *(int32_t *)(iVar5 + 0x10);
            puVar3 = (uint8_t *)((uint64_t)*(uint16_t *)(iVar5 + 10) + iVar17);
            if (iVar7 == 0x10e1) {
                iVar7 = 0;
                if (*(uint16_t *)(iVar5 + 0xc) != 0) {
                    do {
                        uVar6 = *puVar3;
                        puVar3 = puVar3 + 1;
                        iVar7 = iVar7 + 1;
                        uVar10 = (int32_t)uVar11 << 8 | (uint32_t)uVar6;
                        uVar11 = (uint64_t)uVar10;
                    } while (iVar7 < (int32_t)(uint32_t)*(uint16_t *)(iVar5 + 0xc));
                }
            } else if (iVar7 == 0x4d2) {
                iVar7 = 0;
                if (*(uint16_t *)(iVar5 + 0xc) != 0) {
                    do {
                        uVar6 = *puVar3;
                        puVar3 = puVar3 + 1;
                        uVar10 = (uint32_t)uVar11 | (uint32_t)uVar6 << ((char)iVar7 * '\b' & 0x1fU);
                        uVar11 = (uint64_t)uVar10;
                        iVar7 = iVar7 + 1;
                    } while (iVar7 < (int32_t)(uint32_t)*(uint16_t *)(iVar5 + 0xc));
                }
            } else {
                if (iVar7 != 0x11) {
                    iVar5 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                    fcn.180172b00(uVar4, 4, 0x1804a7c40, iVar5 + 1, 0x8f, 0x1804a7c00);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3f3;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                iVar12 = 0;
                iVar7 = (int32_t)puVar3;
                uVar6 = 0;
                while( true ) {
                    if ((iVar15 != iVar7) && (iVar12 == iVar15 - iVar7)) goto code_r0x0001801851e9;
                    iVar12 = iVar12 + 1;
                    uVar11 = uVar11 | (uint64_t)(*puVar3 & 0x7f) << (uVar6 & 0x3f);
                    uVar10 = (uint32_t)uVar11;
                    if (-1 < (char)*puVar3) break;
                    if (9 < iVar12) goto code_r0x00018018529b;
                    puVar3 = puVar3 + 1;
                    uVar6 = uVar6 + 7;
                }
                if (iVar12 == 0) break;
                if (iVar12 == -1) {
code_r0x00018018529b:
                    iVar5 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                    fcn.180172b00(uVar4, 4, 0x1804a7c20, iVar5 + 1, 0x88, 0x1804a7c00);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                uVar13 = (uint64_t)
                         (((uint32_t)*(uint16_t *)(iVar5 + 8) - (uint32_t)*(uint16_t *)(iVar5 + 0xc)) + iVar12);
            }
            uVar10 = (int32_t)*(int16_t *)(iVar5 + 0xe) + uVar10 + (int32_t)uVar13;
            uVar9 = (uint64_t)uVar10;
            if (uVar16 < uVar10) break;
            fcn.180173cb0(arg1);
            uVar14 = uVar14 + uVar10;
            iVar17 = iVar17 + uVar9;
            uVar16 = uVar16 - uVar10;
        } while ((int32_t)(uint32_t)*(uint16_t *)(iVar5 + 8) <= (int32_t)uVar16);
    }
code_r0x0001801851e9:
    *(int64_t *)(arg1 + 0x90) = (int64_t)(int32_t)uVar16;
    *(undefined8 *)(arg1 + 0x88) = 0;
    if (uVar16 != 0) {
        if (iVar17 != *(int64_t *)(arg1 + 0x78)) {
            fcn.180498030(*(int64_t *)(arg1 + 0x78), iVar17);
        }
        if (*(uint64_t *)(arg1 + 0x80) < uVar9) {
            uVar16 = *(uint32_t *)(iVar5 + 4);
            if (uVar16 < (uint32_t)uVar9) {
                iVar17 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                uVar2 = *(undefined4 *)(iVar5 + 4);
                uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                fcn.180172b00(uVar4, 4, 0x1804a7c68, uVar2, iVar17 + 1, 0xa8, 0x1804a7c00);
                *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                fcn.180183710(arg1);
                return 0xffffffff;
            }
            uVar13 = *(uint64_t *)(arg1 + 0x80) * 2;
            if ((uVar9 <= uVar13) && (uVar9 = (uint64_t)uVar16, uVar13 <= uVar16)) {
                uVar9 = uVar13 & 0xffffffff;
            }
            fcn.1801735b0(arg1, uVar9);
        }
    }
    return (uint64_t)uVar14;
}

// ============================================================
// Function: FUN_180185065
// Address: 0x180185065
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_1ch
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

uint64_t fcn.180184df0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
                      int64_t arg_50h, int64_t arg_78h, int64_t arg_88h, int64_t arg_90h)
{
    uint16_t uVar1;
    undefined4 uVar2;
    uint8_t *puVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint8_t uVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    uint64_t uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb0;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t in_stack_ffffffffffffffd0;
    int64_t var_1ch;
    
    iVar7 = **(int32_t **)(arg1 + 0x178);
    iVar12 = (int32_t)arg3;
    iVar15 = (int32_t)arg2;
    if (iVar7 == 1) {
        iVar7 = (*(int32_t **)(arg1 + 0x178))[2];
        iVar5 = *(int64_t *)(arg1 + 0x78) + *(int64_t *)(arg1 + 0x88);
        uVar14 = 0;
        for (iVar12 = (iVar15 - (int32_t)iVar5) + iVar12; iVar7 <= iVar12; iVar12 = iVar12 - iVar7) {
            fcn.180173cb0(arg1, iVar5, iVar7);
            uVar14 = uVar14 + iVar7;
            iVar5 = iVar5 + iVar7;
        }
        *(int64_t *)(arg1 + 0x90) = (int64_t)iVar12;
        *(undefined8 *)(arg1 + 0x88) = 0;
        if ((iVar12 != 0) && (iVar5 != *(int64_t *)(arg1 + 0x78))) {
            fcn.180498030(*(int64_t *)(arg1 + 0x78), iVar5);
        }
        return (uint64_t)uVar14;
    }
    if (iVar7 == 2) {
        iVar5 = *(int64_t *)(arg1 + 0x178);
        uVar13 = *(int64_t *)(arg1 + 0x78) + *(int64_t *)(arg1 + 0x88);
        uVar1 = *(uint16_t *)(iVar5 + 0x10);
        uVar11 = (arg2 - (int32_t)(uint32_t)uVar1) + 1;
        uVar9 = uVar13;
        if (uVar13 <= uVar11) {
            uVar9 = uVar11;
        }
        uVar14 = 0;
        iVar7 = (iVar15 + iVar12) - (int32_t)uVar9;
        if ((int32_t)(uint32_t)uVar1 <= iVar7) {
            do {
                uVar11 = 0;
                if (uVar1 != 0) {
                    do {
                        if (*(char *)(uVar9 + uVar11) != *(char *)(iVar5 + 8 + uVar11)) {
                            uVar9 = uVar9 + 1;
                            iVar7 = iVar7 + -1;
                            goto code_r0x000180184f93;
                        }
                        uVar16 = (int32_t)uVar11 + 1;
                        uVar11 = (uint64_t)uVar16;
                    } while ((int32_t)uVar16 < (int32_t)(uint32_t)uVar1);
                }
                uVar9 = uVar9 + uVar1;
                iVar8 = (int32_t)uVar9 - (int32_t)uVar13;
                iVar7 = iVar7 - (uint32_t)uVar1;
                fcn.180173cb0(arg1, uVar13, iVar8);
                uVar14 = uVar14 + iVar8;
                uVar13 = uVar9;
code_r0x000180184f93:
            } while ((int32_t)(uint32_t)uVar1 <= iVar7);
        }
        iVar7 = (iVar15 + iVar12) - (int32_t)uVar13;
        *(int64_t *)(arg1 + 0x90) = (int64_t)iVar7;
        *(undefined8 *)(arg1 + 0x88) = 0;
        if (iVar7 != 0) {
            if (uVar13 != *(uint64_t *)(arg1 + 0x78)) {
                fcn.180498030(*(uint64_t *)(arg1 + 0x78), uVar13);
            }
            uVar9 = *(uint64_t *)(arg1 + 0x80);
            if (*(uint64_t *)(arg1 + 0x90) == uVar9) {
                uVar13 = (uint64_t)*(uint32_t *)(iVar5 + 4);
                if (uVar13 <= uVar9) {
                    iVar17 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar2 = *(undefined4 *)(iVar5 + 4);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffd0);
                    fcn.180172b00(uVar4, 4, 0x1804a7bd8, uVar2, iVar17 + 1, 0x5d, 0x1804a7b50);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                if (uVar9 * 2 < uVar13) {
                    uVar13 = uVar9 * 2 & 0xffffffff;
                }
                fcn.1801735b0(arg1, uVar13);
            }
        }
        return (uint64_t)uVar14;
    }
    if (iVar7 != 3) {
        fcn.180173cb0();
        return arg3 & 0xffffffff;
    }
    iVar5 = *(int64_t *)(arg1 + 0x178);
    iVar15 = iVar15 + iVar12;
    iVar17 = *(int64_t *)(arg1 + 0x88) + *(int64_t *)(arg1 + 0x78);
    uVar14 = 0;
    uVar16 = iVar15 - (int32_t)iVar17;
    uVar9 = (uint64_t)*(uint16_t *)(iVar5 + 8);
    uVar13 = uVar9;
    if ((int32_t)(uint32_t)*(uint16_t *)(iVar5 + 8) <= (int32_t)uVar16) {
        do {
            uVar11 = 0;
            uVar10 = 0;
            iVar7 = *(int32_t *)(iVar5 + 0x10);
            puVar3 = (uint8_t *)((uint64_t)*(uint16_t *)(iVar5 + 10) + iVar17);
            if (iVar7 == 0x10e1) {
                iVar7 = 0;
                if (*(uint16_t *)(iVar5 + 0xc) != 0) {
                    do {
                        uVar6 = *puVar3;
                        puVar3 = puVar3 + 1;
                        iVar7 = iVar7 + 1;
                        uVar10 = (int32_t)uVar11 << 8 | (uint32_t)uVar6;
                        uVar11 = (uint64_t)uVar10;
                    } while (iVar7 < (int32_t)(uint32_t)*(uint16_t *)(iVar5 + 0xc));
                }
            } else if (iVar7 == 0x4d2) {
                iVar7 = 0;
                if (*(uint16_t *)(iVar5 + 0xc) != 0) {
                    do {
                        uVar6 = *puVar3;
                        puVar3 = puVar3 + 1;
                        uVar10 = (uint32_t)uVar11 | (uint32_t)uVar6 << ((char)iVar7 * '\b' & 0x1fU);
                        uVar11 = (uint64_t)uVar10;
                        iVar7 = iVar7 + 1;
                    } while (iVar7 < (int32_t)(uint32_t)*(uint16_t *)(iVar5 + 0xc));
                }
            } else {
                if (iVar7 != 0x11) {
                    iVar5 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                    fcn.180172b00(uVar4, 4, 0x1804a7c40, iVar5 + 1, 0x8f, 0x1804a7c00);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3f3;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                iVar12 = 0;
                iVar7 = (int32_t)puVar3;
                uVar6 = 0;
                while( true ) {
                    if ((iVar15 != iVar7) && (iVar12 == iVar15 - iVar7)) goto code_r0x0001801851e9;
                    iVar12 = iVar12 + 1;
                    uVar11 = uVar11 | (uint64_t)(*puVar3 & 0x7f) << (uVar6 & 0x3f);
                    uVar10 = (uint32_t)uVar11;
                    if (-1 < (char)*puVar3) break;
                    if (9 < iVar12) goto code_r0x00018018529b;
                    puVar3 = puVar3 + 1;
                    uVar6 = uVar6 + 7;
                }
                if (iVar12 == 0) break;
                if (iVar12 == -1) {
code_r0x00018018529b:
                    iVar5 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                    fcn.180172b00(uVar4, 4, 0x1804a7c20, iVar5 + 1, 0x88, 0x1804a7c00);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                uVar13 = (uint64_t)
                         (((uint32_t)*(uint16_t *)(iVar5 + 8) - (uint32_t)*(uint16_t *)(iVar5 + 0xc)) + iVar12);
            }
            uVar10 = (int32_t)*(int16_t *)(iVar5 + 0xe) + uVar10 + (int32_t)uVar13;
            uVar9 = (uint64_t)uVar10;
            if (uVar16 < uVar10) break;
            fcn.180173cb0(arg1);
            uVar14 = uVar14 + uVar10;
            iVar17 = iVar17 + uVar9;
            uVar16 = uVar16 - uVar10;
        } while ((int32_t)(uint32_t)*(uint16_t *)(iVar5 + 8) <= (int32_t)uVar16);
    }
code_r0x0001801851e9:
    *(int64_t *)(arg1 + 0x90) = (int64_t)(int32_t)uVar16;
    *(undefined8 *)(arg1 + 0x88) = 0;
    if (uVar16 != 0) {
        if (iVar17 != *(int64_t *)(arg1 + 0x78)) {
            fcn.180498030(*(int64_t *)(arg1 + 0x78), iVar17);
        }
        if (*(uint64_t *)(arg1 + 0x80) < uVar9) {
            uVar16 = *(uint32_t *)(iVar5 + 4);
            if (uVar16 < (uint32_t)uVar9) {
                iVar17 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                uVar2 = *(undefined4 *)(iVar5 + 4);
                uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                fcn.180172b00(uVar4, 4, 0x1804a7c68, uVar2, iVar17 + 1, 0xa8, 0x1804a7c00);
                *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                fcn.180183710(arg1);
                return 0xffffffff;
            }
            uVar13 = *(uint64_t *)(arg1 + 0x80) * 2;
            if ((uVar9 <= uVar13) && (uVar9 = (uint64_t)uVar16, uVar13 <= uVar16)) {
                uVar9 = uVar13 & 0xffffffff;
            }
            fcn.1801735b0(arg1, uVar9);
        }
    }
    return (uint64_t)uVar14;
}

// ============================================================
// Function: FUN_18018506f
// Address: 0x18018506f
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_1ch
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

uint64_t fcn.180184df0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
                      int64_t arg_50h, int64_t arg_78h, int64_t arg_88h, int64_t arg_90h)
{
    uint16_t uVar1;
    undefined4 uVar2;
    uint8_t *puVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint8_t uVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    uint64_t uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb0;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t in_stack_ffffffffffffffd0;
    int64_t var_1ch;
    
    iVar7 = **(int32_t **)(arg1 + 0x178);
    iVar12 = (int32_t)arg3;
    iVar15 = (int32_t)arg2;
    if (iVar7 == 1) {
        iVar7 = (*(int32_t **)(arg1 + 0x178))[2];
        iVar5 = *(int64_t *)(arg1 + 0x78) + *(int64_t *)(arg1 + 0x88);
        uVar14 = 0;
        for (iVar12 = (iVar15 - (int32_t)iVar5) + iVar12; iVar7 <= iVar12; iVar12 = iVar12 - iVar7) {
            fcn.180173cb0(arg1, iVar5, iVar7);
            uVar14 = uVar14 + iVar7;
            iVar5 = iVar5 + iVar7;
        }
        *(int64_t *)(arg1 + 0x90) = (int64_t)iVar12;
        *(undefined8 *)(arg1 + 0x88) = 0;
        if ((iVar12 != 0) && (iVar5 != *(int64_t *)(arg1 + 0x78))) {
            fcn.180498030(*(int64_t *)(arg1 + 0x78), iVar5);
        }
        return (uint64_t)uVar14;
    }
    if (iVar7 == 2) {
        iVar5 = *(int64_t *)(arg1 + 0x178);
        uVar13 = *(int64_t *)(arg1 + 0x78) + *(int64_t *)(arg1 + 0x88);
        uVar1 = *(uint16_t *)(iVar5 + 0x10);
        uVar11 = (arg2 - (int32_t)(uint32_t)uVar1) + 1;
        uVar9 = uVar13;
        if (uVar13 <= uVar11) {
            uVar9 = uVar11;
        }
        uVar14 = 0;
        iVar7 = (iVar15 + iVar12) - (int32_t)uVar9;
        if ((int32_t)(uint32_t)uVar1 <= iVar7) {
            do {
                uVar11 = 0;
                if (uVar1 != 0) {
                    do {
                        if (*(char *)(uVar9 + uVar11) != *(char *)(iVar5 + 8 + uVar11)) {
                            uVar9 = uVar9 + 1;
                            iVar7 = iVar7 + -1;
                            goto code_r0x000180184f93;
                        }
                        uVar16 = (int32_t)uVar11 + 1;
                        uVar11 = (uint64_t)uVar16;
                    } while ((int32_t)uVar16 < (int32_t)(uint32_t)uVar1);
                }
                uVar9 = uVar9 + uVar1;
                iVar8 = (int32_t)uVar9 - (int32_t)uVar13;
                iVar7 = iVar7 - (uint32_t)uVar1;
                fcn.180173cb0(arg1, uVar13, iVar8);
                uVar14 = uVar14 + iVar8;
                uVar13 = uVar9;
code_r0x000180184f93:
            } while ((int32_t)(uint32_t)uVar1 <= iVar7);
        }
        iVar7 = (iVar15 + iVar12) - (int32_t)uVar13;
        *(int64_t *)(arg1 + 0x90) = (int64_t)iVar7;
        *(undefined8 *)(arg1 + 0x88) = 0;
        if (iVar7 != 0) {
            if (uVar13 != *(uint64_t *)(arg1 + 0x78)) {
                fcn.180498030(*(uint64_t *)(arg1 + 0x78), uVar13);
            }
            uVar9 = *(uint64_t *)(arg1 + 0x80);
            if (*(uint64_t *)(arg1 + 0x90) == uVar9) {
                uVar13 = (uint64_t)*(uint32_t *)(iVar5 + 4);
                if (uVar13 <= uVar9) {
                    iVar17 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar2 = *(undefined4 *)(iVar5 + 4);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffd0);
                    fcn.180172b00(uVar4, 4, 0x1804a7bd8, uVar2, iVar17 + 1, 0x5d, 0x1804a7b50);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                if (uVar9 * 2 < uVar13) {
                    uVar13 = uVar9 * 2 & 0xffffffff;
                }
                fcn.1801735b0(arg1, uVar13);
            }
        }
        return (uint64_t)uVar14;
    }
    if (iVar7 != 3) {
        fcn.180173cb0();
        return arg3 & 0xffffffff;
    }
    iVar5 = *(int64_t *)(arg1 + 0x178);
    iVar15 = iVar15 + iVar12;
    iVar17 = *(int64_t *)(arg1 + 0x88) + *(int64_t *)(arg1 + 0x78);
    uVar14 = 0;
    uVar16 = iVar15 - (int32_t)iVar17;
    uVar9 = (uint64_t)*(uint16_t *)(iVar5 + 8);
    uVar13 = uVar9;
    if ((int32_t)(uint32_t)*(uint16_t *)(iVar5 + 8) <= (int32_t)uVar16) {
        do {
            uVar11 = 0;
            uVar10 = 0;
            iVar7 = *(int32_t *)(iVar5 + 0x10);
            puVar3 = (uint8_t *)((uint64_t)*(uint16_t *)(iVar5 + 10) + iVar17);
            if (iVar7 == 0x10e1) {
                iVar7 = 0;
                if (*(uint16_t *)(iVar5 + 0xc) != 0) {
                    do {
                        uVar6 = *puVar3;
                        puVar3 = puVar3 + 1;
                        iVar7 = iVar7 + 1;
                        uVar10 = (int32_t)uVar11 << 8 | (uint32_t)uVar6;
                        uVar11 = (uint64_t)uVar10;
                    } while (iVar7 < (int32_t)(uint32_t)*(uint16_t *)(iVar5 + 0xc));
                }
            } else if (iVar7 == 0x4d2) {
                iVar7 = 0;
                if (*(uint16_t *)(iVar5 + 0xc) != 0) {
                    do {
                        uVar6 = *puVar3;
                        puVar3 = puVar3 + 1;
                        uVar10 = (uint32_t)uVar11 | (uint32_t)uVar6 << ((char)iVar7 * '\b' & 0x1fU);
                        uVar11 = (uint64_t)uVar10;
                        iVar7 = iVar7 + 1;
                    } while (iVar7 < (int32_t)(uint32_t)*(uint16_t *)(iVar5 + 0xc));
                }
            } else {
                if (iVar7 != 0x11) {
                    iVar5 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                    fcn.180172b00(uVar4, 4, 0x1804a7c40, iVar5 + 1, 0x8f, 0x1804a7c00);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3f3;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                iVar12 = 0;
                iVar7 = (int32_t)puVar3;
                uVar6 = 0;
                while( true ) {
                    if ((iVar15 != iVar7) && (iVar12 == iVar15 - iVar7)) goto code_r0x0001801851e9;
                    iVar12 = iVar12 + 1;
                    uVar11 = uVar11 | (uint64_t)(*puVar3 & 0x7f) << (uVar6 & 0x3f);
                    uVar10 = (uint32_t)uVar11;
                    if (-1 < (char)*puVar3) break;
                    if (9 < iVar12) goto code_r0x00018018529b;
                    puVar3 = puVar3 + 1;
                    uVar6 = uVar6 + 7;
                }
                if (iVar12 == 0) break;
                if (iVar12 == -1) {
code_r0x00018018529b:
                    iVar5 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                    fcn.180172b00(uVar4, 4, 0x1804a7c20, iVar5 + 1, 0x88, 0x1804a7c00);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                uVar13 = (uint64_t)
                         (((uint32_t)*(uint16_t *)(iVar5 + 8) - (uint32_t)*(uint16_t *)(iVar5 + 0xc)) + iVar12);
            }
            uVar10 = (int32_t)*(int16_t *)(iVar5 + 0xe) + uVar10 + (int32_t)uVar13;
            uVar9 = (uint64_t)uVar10;
            if (uVar16 < uVar10) break;
            fcn.180173cb0(arg1);
            uVar14 = uVar14 + uVar10;
            iVar17 = iVar17 + uVar9;
            uVar16 = uVar16 - uVar10;
        } while ((int32_t)(uint32_t)*(uint16_t *)(iVar5 + 8) <= (int32_t)uVar16);
    }
code_r0x0001801851e9:
    *(int64_t *)(arg1 + 0x90) = (int64_t)(int32_t)uVar16;
    *(undefined8 *)(arg1 + 0x88) = 0;
    if (uVar16 != 0) {
        if (iVar17 != *(int64_t *)(arg1 + 0x78)) {
            fcn.180498030(*(int64_t *)(arg1 + 0x78), iVar17);
        }
        if (*(uint64_t *)(arg1 + 0x80) < uVar9) {
            uVar16 = *(uint32_t *)(iVar5 + 4);
            if (uVar16 < (uint32_t)uVar9) {
                iVar17 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                uVar2 = *(undefined4 *)(iVar5 + 4);
                uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                fcn.180172b00(uVar4, 4, 0x1804a7c68, uVar2, iVar17 + 1, 0xa8, 0x1804a7c00);
                *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                fcn.180183710(arg1);
                return 0xffffffff;
            }
            uVar13 = *(uint64_t *)(arg1 + 0x80) * 2;
            if ((uVar9 <= uVar13) && (uVar9 = (uint64_t)uVar16, uVar13 <= uVar16)) {
                uVar9 = uVar13 & 0xffffffff;
            }
            fcn.1801735b0(arg1, uVar9);
        }
    }
    return (uint64_t)uVar14;
}

// ============================================================
// Function: FUN_180185090
// Address: 0x180185090
// Size: 753 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_1ch
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel

uint64_t fcn.180184df0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
                      int64_t arg_50h, int64_t arg_78h, int64_t arg_88h, int64_t arg_90h)
{
    uint16_t uVar1;
    undefined4 uVar2;
    uint8_t *puVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint8_t uVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    uint64_t uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t in_stack_ffffffffffffffb0;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t in_stack_ffffffffffffffd0;
    int64_t var_1ch;
    
    iVar7 = **(int32_t **)(arg1 + 0x178);
    iVar12 = (int32_t)arg3;
    iVar15 = (int32_t)arg2;
    if (iVar7 == 1) {
        iVar7 = (*(int32_t **)(arg1 + 0x178))[2];
        iVar5 = *(int64_t *)(arg1 + 0x78) + *(int64_t *)(arg1 + 0x88);
        uVar14 = 0;
        for (iVar12 = (iVar15 - (int32_t)iVar5) + iVar12; iVar7 <= iVar12; iVar12 = iVar12 - iVar7) {
            fcn.180173cb0(arg1, iVar5, iVar7);
            uVar14 = uVar14 + iVar7;
            iVar5 = iVar5 + iVar7;
        }
        *(int64_t *)(arg1 + 0x90) = (int64_t)iVar12;
        *(undefined8 *)(arg1 + 0x88) = 0;
        if ((iVar12 != 0) && (iVar5 != *(int64_t *)(arg1 + 0x78))) {
            fcn.180498030(*(int64_t *)(arg1 + 0x78), iVar5);
        }
        return (uint64_t)uVar14;
    }
    if (iVar7 == 2) {
        iVar5 = *(int64_t *)(arg1 + 0x178);
        uVar13 = *(int64_t *)(arg1 + 0x78) + *(int64_t *)(arg1 + 0x88);
        uVar1 = *(uint16_t *)(iVar5 + 0x10);
        uVar11 = (arg2 - (int32_t)(uint32_t)uVar1) + 1;
        uVar9 = uVar13;
        if (uVar13 <= uVar11) {
            uVar9 = uVar11;
        }
        uVar14 = 0;
        iVar7 = (iVar15 + iVar12) - (int32_t)uVar9;
        if ((int32_t)(uint32_t)uVar1 <= iVar7) {
            do {
                uVar11 = 0;
                if (uVar1 != 0) {
                    do {
                        if (*(char *)(uVar9 + uVar11) != *(char *)(iVar5 + 8 + uVar11)) {
                            uVar9 = uVar9 + 1;
                            iVar7 = iVar7 + -1;
                            goto code_r0x000180184f93;
                        }
                        uVar16 = (int32_t)uVar11 + 1;
                        uVar11 = (uint64_t)uVar16;
                    } while ((int32_t)uVar16 < (int32_t)(uint32_t)uVar1);
                }
                uVar9 = uVar9 + uVar1;
                iVar8 = (int32_t)uVar9 - (int32_t)uVar13;
                iVar7 = iVar7 - (uint32_t)uVar1;
                fcn.180173cb0(arg1, uVar13, iVar8);
                uVar14 = uVar14 + iVar8;
                uVar13 = uVar9;
code_r0x000180184f93:
            } while ((int32_t)(uint32_t)uVar1 <= iVar7);
        }
        iVar7 = (iVar15 + iVar12) - (int32_t)uVar13;
        *(int64_t *)(arg1 + 0x90) = (int64_t)iVar7;
        *(undefined8 *)(arg1 + 0x88) = 0;
        if (iVar7 != 0) {
            if (uVar13 != *(uint64_t *)(arg1 + 0x78)) {
                fcn.180498030(*(uint64_t *)(arg1 + 0x78), uVar13);
            }
            uVar9 = *(uint64_t *)(arg1 + 0x80);
            if (*(uint64_t *)(arg1 + 0x90) == uVar9) {
                uVar13 = (uint64_t)*(uint32_t *)(iVar5 + 4);
                if (uVar13 <= uVar9) {
                    iVar17 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar2 = *(undefined4 *)(iVar5 + 4);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffd0);
                    fcn.180172b00(uVar4, 4, 0x1804a7bd8, uVar2, iVar17 + 1, 0x5d, 0x1804a7b50);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                if (uVar9 * 2 < uVar13) {
                    uVar13 = uVar9 * 2 & 0xffffffff;
                }
                fcn.1801735b0(arg1, uVar13);
            }
        }
        return (uint64_t)uVar14;
    }
    if (iVar7 != 3) {
        fcn.180173cb0();
        return arg3 & 0xffffffff;
    }
    iVar5 = *(int64_t *)(arg1 + 0x178);
    iVar15 = iVar15 + iVar12;
    iVar17 = *(int64_t *)(arg1 + 0x88) + *(int64_t *)(arg1 + 0x78);
    uVar14 = 0;
    uVar16 = iVar15 - (int32_t)iVar17;
    uVar9 = (uint64_t)*(uint16_t *)(iVar5 + 8);
    uVar13 = uVar9;
    if ((int32_t)(uint32_t)*(uint16_t *)(iVar5 + 8) <= (int32_t)uVar16) {
        do {
            uVar11 = 0;
            uVar10 = 0;
            iVar7 = *(int32_t *)(iVar5 + 0x10);
            puVar3 = (uint8_t *)((uint64_t)*(uint16_t *)(iVar5 + 10) + iVar17);
            if (iVar7 == 0x10e1) {
                iVar7 = 0;
                if (*(uint16_t *)(iVar5 + 0xc) != 0) {
                    do {
                        uVar6 = *puVar3;
                        puVar3 = puVar3 + 1;
                        iVar7 = iVar7 + 1;
                        uVar10 = (int32_t)uVar11 << 8 | (uint32_t)uVar6;
                        uVar11 = (uint64_t)uVar10;
                    } while (iVar7 < (int32_t)(uint32_t)*(uint16_t *)(iVar5 + 0xc));
                }
            } else if (iVar7 == 0x4d2) {
                iVar7 = 0;
                if (*(uint16_t *)(iVar5 + 0xc) != 0) {
                    do {
                        uVar6 = *puVar3;
                        puVar3 = puVar3 + 1;
                        uVar10 = (uint32_t)uVar11 | (uint32_t)uVar6 << ((char)iVar7 * '\b' & 0x1fU);
                        uVar11 = (uint64_t)uVar10;
                        iVar7 = iVar7 + 1;
                    } while (iVar7 < (int32_t)(uint32_t)*(uint16_t *)(iVar5 + 0xc));
                }
            } else {
                if (iVar7 != 0x11) {
                    iVar5 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                    fcn.180172b00(uVar4, 4, 0x1804a7c40, iVar5 + 1, 0x8f, 0x1804a7c00);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3f3;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                iVar12 = 0;
                iVar7 = (int32_t)puVar3;
                uVar6 = 0;
                while( true ) {
                    if ((iVar15 != iVar7) && (iVar12 == iVar15 - iVar7)) goto code_r0x0001801851e9;
                    iVar12 = iVar12 + 1;
                    uVar11 = uVar11 | (uint64_t)(*puVar3 & 0x7f) << (uVar6 & 0x3f);
                    uVar10 = (uint32_t)uVar11;
                    if (-1 < (char)*puVar3) break;
                    if (9 < iVar12) goto code_r0x00018018529b;
                    puVar3 = puVar3 + 1;
                    uVar6 = uVar6 + 7;
                }
                if (iVar12 == 0) break;
                if (iVar12 == -1) {
code_r0x00018018529b:
                    iVar5 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                    uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                    fcn.180172b00(uVar4, 4, 0x1804a7c20, iVar5 + 1, 0x88, 0x1804a7c00);
                    *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                    fcn.180183710(arg1);
                    return 0xffffffff;
                }
                uVar13 = (uint64_t)
                         (((uint32_t)*(uint16_t *)(iVar5 + 8) - (uint32_t)*(uint16_t *)(iVar5 + 0xc)) + iVar12);
            }
            uVar10 = (int32_t)*(int16_t *)(iVar5 + 0xe) + uVar10 + (int32_t)uVar13;
            uVar9 = (uint64_t)uVar10;
            if (uVar16 < uVar10) break;
            fcn.180173cb0(arg1);
            uVar14 = uVar14 + uVar10;
            iVar17 = iVar17 + uVar9;
            uVar16 = uVar16 - uVar10;
        } while ((int32_t)(uint32_t)*(uint16_t *)(iVar5 + 8) <= (int32_t)uVar16);
    }
code_r0x0001801851e9:
    *(int64_t *)(arg1 + 0x90) = (int64_t)(int32_t)uVar16;
    *(undefined8 *)(arg1 + 0x88) = 0;
    if (uVar16 != 0) {
        if (iVar17 != *(int64_t *)(arg1 + 0x78)) {
            fcn.180498030(*(int64_t *)(arg1 + 0x78), iVar17);
        }
        if (*(uint64_t *)(arg1 + 0x80) < uVar9) {
            uVar16 = *(uint32_t *)(iVar5 + 4);
            if (uVar16 < (uint32_t)uVar9) {
                iVar17 = fcn.18045b9a8(0x1804a7b70, 0x5c);
                uVar2 = *(undefined4 *)(iVar5 + 4);
                uVar4 = fcn.1801723e0(in_stack_ffffffffffffffb0);
                fcn.180172b00(uVar4, 4, 0x1804a7c68, uVar2, iVar17 + 1, 0xa8, 0x1804a7c00);
                *(undefined4 *)(arg1 + 0x4c) = 0x3fe;
                fcn.180183710(arg1);
                return 0xffffffff;
            }
            uVar13 = *(uint64_t *)(arg1 + 0x80) * 2;
            if ((uVar9 <= uVar13) && (uVar9 = (uint64_t)uVar16, uVar13 <= uVar16)) {
                uVar9 = uVar13 & 0xffffffff;
            }
            fcn.1801735b0(arg1, uVar9);
        }
    }
    return (uint64_t)uVar14;
}

// ============================================================
// Function: FUN_180185390
// Address: 0x180185390
// Size: 46 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180185390(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    func_0x000180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x000180185433;
            }
            unaff_RDI = func_0x000180459890(uVar2);
        }
code_r0x00018018545a:
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        iVar6 = unaff_RDI + arg4;
        iVar3 = ((iVar3 - arg4) - arg_28h) + 1;
        if (uVar4 < 0x10) {
            fcn.180498030(unaff_RDI, arg1, arg4);
            fcn.180498030(iVar6, arg_30h, arg_38h);
            fcn.180498030(arg_38h + iVar6, arg4 + arg_28h + arg1, iVar3);
            goto code_r0x000180185523;
        }
        uVar8 = *(uint64_t *)arg1;
        fcn.180498030(unaff_RDI, uVar8, arg4);
        fcn.180498030(iVar6, arg_30h, arg_38h);
        fcn.180498030(arg_38h + iVar6, uVar8 + arg4 + arg_28h, iVar3);
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x000180185523;
            }
            goto code_r0x0001801854e7;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x000180185433:
        iVar6 = func_0x000180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018018545a;
        }
code_r0x0001801854e7:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x1801854f6;
    func_0x000180459c3c(uVar8);
code_r0x000180185523:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_1801853be
// Address: 0x1801853be
// Size: 394 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180185390(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    func_0x000180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x000180185433;
            }
            unaff_RDI = func_0x000180459890(uVar2);
        }
code_r0x00018018545a:
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        iVar6 = unaff_RDI + arg4;
        iVar3 = ((iVar3 - arg4) - arg_28h) + 1;
        if (uVar4 < 0x10) {
            fcn.180498030(unaff_RDI, arg1, arg4);
            fcn.180498030(iVar6, arg_30h, arg_38h);
            fcn.180498030(arg_38h + iVar6, arg4 + arg_28h + arg1, iVar3);
            goto code_r0x000180185523;
        }
        uVar8 = *(uint64_t *)arg1;
        fcn.180498030(unaff_RDI, uVar8, arg4);
        fcn.180498030(iVar6, arg_30h, arg_38h);
        fcn.180498030(arg_38h + iVar6, uVar8 + arg4 + arg_28h, iVar3);
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x000180185523;
            }
            goto code_r0x0001801854e7;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x000180185433:
        iVar6 = func_0x000180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018018545a;
        }
code_r0x0001801854e7:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x1801854f6;
    func_0x000180459c3c(uVar8);
code_r0x000180185523:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_180185548
// Address: 0x180185548
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180185390(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    func_0x000180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x000180185433;
            }
            unaff_RDI = func_0x000180459890(uVar2);
        }
code_r0x00018018545a:
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        iVar6 = unaff_RDI + arg4;
        iVar3 = ((iVar3 - arg4) - arg_28h) + 1;
        if (uVar4 < 0x10) {
            fcn.180498030(unaff_RDI, arg1, arg4);
            fcn.180498030(iVar6, arg_30h, arg_38h);
            fcn.180498030(arg_38h + iVar6, arg4 + arg_28h + arg1, iVar3);
            goto code_r0x000180185523;
        }
        uVar8 = *(uint64_t *)arg1;
        fcn.180498030(unaff_RDI, uVar8, arg4);
        fcn.180498030(iVar6, arg_30h, arg_38h);
        fcn.180498030(arg_38h + iVar6, uVar8 + arg4 + arg_28h, iVar3);
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x000180185523;
            }
            goto code_r0x0001801854e7;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x000180185433:
        iVar6 = func_0x000180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018018545a;
        }
code_r0x0001801854e7:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x1801854f6;
    func_0x000180459c3c(uVar8);
code_r0x000180185523:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18018554e
// Address: 0x18018554e
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180185390(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    func_0x000180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x000180185433;
            }
            unaff_RDI = func_0x000180459890(uVar2);
        }
code_r0x00018018545a:
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        iVar6 = unaff_RDI + arg4;
        iVar3 = ((iVar3 - arg4) - arg_28h) + 1;
        if (uVar4 < 0x10) {
            fcn.180498030(unaff_RDI, arg1, arg4);
            fcn.180498030(iVar6, arg_30h, arg_38h);
            fcn.180498030(arg_38h + iVar6, arg4 + arg_28h + arg1, iVar3);
            goto code_r0x000180185523;
        }
        uVar8 = *(uint64_t *)arg1;
        fcn.180498030(unaff_RDI, uVar8, arg4);
        fcn.180498030(iVar6, arg_30h, arg_38h);
        fcn.180498030(arg_38h + iVar6, uVar8 + arg4 + arg_28h, iVar3);
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x000180185523;
            }
            goto code_r0x0001801854e7;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x000180185433:
        iVar6 = func_0x000180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018018545a;
        }
code_r0x0001801854e7:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x1801854f6;
    func_0x000180459c3c(uVar8);
code_r0x000180185523:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_180185560
// Address: 0x180185560
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.180185560(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_48h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    code *pcVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x10);
    if (uVar2 < (uint64_t)arg2) {
        func_0x00018000f930();
        pcVar4 = (code *)swi(3);
        iVar6 = (*pcVar4)();
        return iVar6;
    }
    uVar3 = *(uint64_t *)(arg1 + 0x18);
    uVar5 = uVar2 - arg2;
    if (uVar5 < (uint64_t)arg3) {
        arg3 = uVar5;
    }
    if (arg3 == arg_28h) {
        iVar6 = arg1;
        if (0xf < uVar3) {
            iVar6 = *(int64_t *)arg1;
        }
        fcn.180498030(iVar6 + arg2, arg4, arg_28h);
    } else if ((uint64_t)arg_28h < (uint64_t)arg3) {
        iVar6 = arg1;
        if (0xf < uVar3) {
            iVar6 = *(int64_t *)arg1;
        }
        iVar6 = iVar6 + arg2;
        fcn.180498030(iVar6, arg4, arg_28h);
        fcn.180498030(iVar6 + arg_28h, iVar6 + arg3, (uVar5 - arg3) + 1);
        *(uint64_t *)(arg1 + 0x10) = (uVar2 - arg3) + arg_28h;
    } else {
        uVar5 = arg_28h - arg3;
        if (uVar3 - uVar2 < uVar5) {
            arg1 = fcn.180185390(arg1, uVar5, 0, arg2, arg3, arg4, arg_28h);
        } else {
            *(uint64_t *)(arg1 + 0x10) = uVar5 + uVar2;
            iVar6 = arg1;
            if (0xf < uVar3) {
                iVar6 = *(int64_t *)arg1;
            }
            uVar3 = iVar6 + arg2;
            uVar1 = arg3 + uVar3;
            iVar7 = arg_28h;
            if ((uVar3 < (uint64_t)(arg4 + arg_28h)) && ((uint64_t)arg4 <= uVar2 + iVar6)) {
                if ((uint64_t)arg4 < uVar1) {
                    iVar7 = uVar1 - arg4;
                } else {
                    iVar7 = 0;
                }
            }
            fcn.180498030(uVar1 + uVar5);
            fcn.180498030(uVar3, arg4, iVar7);
            fcn.180498030(iVar7 + uVar3, uVar5 + iVar7 + arg4, arg_28h - iVar7);
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_18018558b
// Address: 0x18018558b
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.180185560(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_48h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    code *pcVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x10);
    if (uVar2 < (uint64_t)arg2) {
        func_0x00018000f930();
        pcVar4 = (code *)swi(3);
        iVar6 = (*pcVar4)();
        return iVar6;
    }
    uVar3 = *(uint64_t *)(arg1 + 0x18);
    uVar5 = uVar2 - arg2;
    if (uVar5 < (uint64_t)arg3) {
        arg3 = uVar5;
    }
    if (arg3 == arg_28h) {
        iVar6 = arg1;
        if (0xf < uVar3) {
            iVar6 = *(int64_t *)arg1;
        }
        fcn.180498030(iVar6 + arg2, arg4, arg_28h);
    } else if ((uint64_t)arg_28h < (uint64_t)arg3) {
        iVar6 = arg1;
        if (0xf < uVar3) {
            iVar6 = *(int64_t *)arg1;
        }
        iVar6 = iVar6 + arg2;
        fcn.180498030(iVar6, arg4, arg_28h);
        fcn.180498030(iVar6 + arg_28h, iVar6 + arg3, (uVar5 - arg3) + 1);
        *(uint64_t *)(arg1 + 0x10) = (uVar2 - arg3) + arg_28h;
    } else {
        uVar5 = arg_28h - arg3;
        if (uVar3 - uVar2 < uVar5) {
            arg1 = fcn.180185390(arg1, uVar5, 0, arg2, arg3, arg4, arg_28h);
        } else {
            *(uint64_t *)(arg1 + 0x10) = uVar5 + uVar2;
            iVar6 = arg1;
            if (0xf < uVar3) {
                iVar6 = *(int64_t *)arg1;
            }
            uVar3 = iVar6 + arg2;
            uVar1 = arg3 + uVar3;
            iVar7 = arg_28h;
            if ((uVar3 < (uint64_t)(arg4 + arg_28h)) && ((uint64_t)arg4 <= uVar2 + iVar6)) {
                if ((uint64_t)arg4 < uVar1) {
                    iVar7 = uVar1 - arg4;
                } else {
                    iVar7 = 0;
                }
            }
            fcn.180498030(uVar1 + uVar5);
            fcn.180498030(uVar3, arg4, iVar7);
            fcn.180498030(iVar7 + uVar3, uVar5 + iVar7 + arg4, arg_28h - iVar7);
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_1801855cf
// Address: 0x1801855cf
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.180185560(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_48h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    code *pcVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x10);
    if (uVar2 < (uint64_t)arg2) {
        func_0x00018000f930();
        pcVar4 = (code *)swi(3);
        iVar6 = (*pcVar4)();
        return iVar6;
    }
    uVar3 = *(uint64_t *)(arg1 + 0x18);
    uVar5 = uVar2 - arg2;
    if (uVar5 < (uint64_t)arg3) {
        arg3 = uVar5;
    }
    if (arg3 == arg_28h) {
        iVar6 = arg1;
        if (0xf < uVar3) {
            iVar6 = *(int64_t *)arg1;
        }
        fcn.180498030(iVar6 + arg2, arg4, arg_28h);
    } else if ((uint64_t)arg_28h < (uint64_t)arg3) {
        iVar6 = arg1;
        if (0xf < uVar3) {
            iVar6 = *(int64_t *)arg1;
        }
        iVar6 = iVar6 + arg2;
        fcn.180498030(iVar6, arg4, arg_28h);
        fcn.180498030(iVar6 + arg_28h, iVar6 + arg3, (uVar5 - arg3) + 1);
        *(uint64_t *)(arg1 + 0x10) = (uVar2 - arg3) + arg_28h;
    } else {
        uVar5 = arg_28h - arg3;
        if (uVar3 - uVar2 < uVar5) {
            arg1 = fcn.180185390(arg1, uVar5, 0, arg2, arg3, arg4, arg_28h);
        } else {
            *(uint64_t *)(arg1 + 0x10) = uVar5 + uVar2;
            iVar6 = arg1;
            if (0xf < uVar3) {
                iVar6 = *(int64_t *)arg1;
            }
            uVar3 = iVar6 + arg2;
            uVar1 = arg3 + uVar3;
            iVar7 = arg_28h;
            if ((uVar3 < (uint64_t)(arg4 + arg_28h)) && ((uint64_t)arg4 <= uVar2 + iVar6)) {
                if ((uint64_t)arg4 < uVar1) {
                    iVar7 = uVar1 - arg4;
                } else {
                    iVar7 = 0;
                }
            }
            fcn.180498030(uVar1 + uVar5);
            fcn.180498030(uVar3, arg4, iVar7);
            fcn.180498030(iVar7 + uVar3, uVar5 + iVar7 + arg4, arg_28h - iVar7);
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_180185626
// Address: 0x180185626
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.180185560(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_48h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    code *pcVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x10);
    if (uVar2 < (uint64_t)arg2) {
        func_0x00018000f930();
        pcVar4 = (code *)swi(3);
        iVar6 = (*pcVar4)();
        return iVar6;
    }
    uVar3 = *(uint64_t *)(arg1 + 0x18);
    uVar5 = uVar2 - arg2;
    if (uVar5 < (uint64_t)arg3) {
        arg3 = uVar5;
    }
    if (arg3 == arg_28h) {
        iVar6 = arg1;
        if (0xf < uVar3) {
            iVar6 = *(int64_t *)arg1;
        }
        fcn.180498030(iVar6 + arg2, arg4, arg_28h);
    } else if ((uint64_t)arg_28h < (uint64_t)arg3) {
        iVar6 = arg1;
        if (0xf < uVar3) {
            iVar6 = *(int64_t *)arg1;
        }
        iVar6 = iVar6 + arg2;
        fcn.180498030(iVar6, arg4, arg_28h);
        fcn.180498030(iVar6 + arg_28h, iVar6 + arg3, (uVar5 - arg3) + 1);
        *(uint64_t *)(arg1 + 0x10) = (uVar2 - arg3) + arg_28h;
    } else {
        uVar5 = arg_28h - arg3;
        if (uVar3 - uVar2 < uVar5) {
            arg1 = fcn.180185390(arg1, uVar5, 0, arg2, arg3, arg4, arg_28h);
        } else {
            *(uint64_t *)(arg1 + 0x10) = uVar5 + uVar2;
            iVar6 = arg1;
            if (0xf < uVar3) {
                iVar6 = *(int64_t *)arg1;
            }
            uVar3 = iVar6 + arg2;
            uVar1 = arg3 + uVar3;
            iVar7 = arg_28h;
            if ((uVar3 < (uint64_t)(arg4 + arg_28h)) && ((uint64_t)arg4 <= uVar2 + iVar6)) {
                if ((uint64_t)arg4 < uVar1) {
                    iVar7 = uVar1 - arg4;
                } else {
                    iVar7 = 0;
                }
            }
            fcn.180498030(uVar1 + uVar5);
            fcn.180498030(uVar3, arg4, iVar7);
            fcn.180498030(iVar7 + uVar3, uVar5 + iVar7 + arg4, arg_28h - iVar7);
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_180185643
// Address: 0x180185643
// Size: 128 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.180185560(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_48h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    code *pcVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x10);
    if (uVar2 < (uint64_t)arg2) {
        func_0x00018000f930();
        pcVar4 = (code *)swi(3);
        iVar6 = (*pcVar4)();
        return iVar6;
    }
    uVar3 = *(uint64_t *)(arg1 + 0x18);
    uVar5 = uVar2 - arg2;
    if (uVar5 < (uint64_t)arg3) {
        arg3 = uVar5;
    }
    if (arg3 == arg_28h) {
        iVar6 = arg1;
        if (0xf < uVar3) {
            iVar6 = *(int64_t *)arg1;
        }
        fcn.180498030(iVar6 + arg2, arg4, arg_28h);
    } else if ((uint64_t)arg_28h < (uint64_t)arg3) {
        iVar6 = arg1;
        if (0xf < uVar3) {
            iVar6 = *(int64_t *)arg1;
        }
        iVar6 = iVar6 + arg2;
        fcn.180498030(iVar6, arg4, arg_28h);
        fcn.180498030(iVar6 + arg_28h, iVar6 + arg3, (uVar5 - arg3) + 1);
        *(uint64_t *)(arg1 + 0x10) = (uVar2 - arg3) + arg_28h;
    } else {
        uVar5 = arg_28h - arg3;
        if (uVar3 - uVar2 < uVar5) {
            arg1 = fcn.180185390(arg1, uVar5, 0, arg2, arg3, arg4, arg_28h);
        } else {
            *(uint64_t *)(arg1 + 0x10) = uVar5 + uVar2;
            iVar6 = arg1;
            if (0xf < uVar3) {
                iVar6 = *(int64_t *)arg1;
            }
            uVar3 = iVar6 + arg2;
            uVar1 = arg3 + uVar3;
            iVar7 = arg_28h;
            if ((uVar3 < (uint64_t)(arg4 + arg_28h)) && ((uint64_t)arg4 <= uVar2 + iVar6)) {
                if ((uint64_t)arg4 < uVar1) {
                    iVar7 = uVar1 - arg4;
                } else {
                    iVar7 = 0;
                }
            }
            fcn.180498030(uVar1 + uVar5);
            fcn.180498030(uVar3, arg4, iVar7);
            fcn.180498030(iVar7 + uVar3, uVar5 + iVar7 + arg4, arg_28h - iVar7);
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_1801856c3
// Address: 0x1801856c3
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.180185560(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_48h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    code *pcVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x10);
    if (uVar2 < (uint64_t)arg2) {
        func_0x00018000f930();
        pcVar4 = (code *)swi(3);
        iVar6 = (*pcVar4)();
        return iVar6;
    }
    uVar3 = *(uint64_t *)(arg1 + 0x18);
    uVar5 = uVar2 - arg2;
    if (uVar5 < (uint64_t)arg3) {
        arg3 = uVar5;
    }
    if (arg3 == arg_28h) {
        iVar6 = arg1;
        if (0xf < uVar3) {
            iVar6 = *(int64_t *)arg1;
        }
        fcn.180498030(iVar6 + arg2, arg4, arg_28h);
    } else if ((uint64_t)arg_28h < (uint64_t)arg3) {
        iVar6 = arg1;
        if (0xf < uVar3) {
            iVar6 = *(int64_t *)arg1;
        }
        iVar6 = iVar6 + arg2;
        fcn.180498030(iVar6, arg4, arg_28h);
        fcn.180498030(iVar6 + arg_28h, iVar6 + arg3, (uVar5 - arg3) + 1);
        *(uint64_t *)(arg1 + 0x10) = (uVar2 - arg3) + arg_28h;
    } else {
        uVar5 = arg_28h - arg3;
        if (uVar3 - uVar2 < uVar5) {
            arg1 = fcn.180185390(arg1, uVar5, 0, arg2, arg3, arg4, arg_28h);
        } else {
            *(uint64_t *)(arg1 + 0x10) = uVar5 + uVar2;
            iVar6 = arg1;
            if (0xf < uVar3) {
                iVar6 = *(int64_t *)arg1;
            }
            uVar3 = iVar6 + arg2;
            uVar1 = arg3 + uVar3;
            iVar7 = arg_28h;
            if ((uVar3 < (uint64_t)(arg4 + arg_28h)) && ((uint64_t)arg4 <= uVar2 + iVar6)) {
                if ((uint64_t)arg4 < uVar1) {
                    iVar7 = uVar1 - arg4;
                } else {
                    iVar7 = 0;
                }
            }
            fcn.180498030(uVar1 + uVar5);
            fcn.180498030(uVar3, arg4, iVar7);
            fcn.180498030(iVar7 + uVar3, uVar5 + iVar7 + arg4, arg_28h - iVar7);
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_1801856eb
// Address: 0x1801856eb
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.180185560(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_48h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    code *pcVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x10);
    if (uVar2 < (uint64_t)arg2) {
        func_0x00018000f930();
        pcVar4 = (code *)swi(3);
        iVar6 = (*pcVar4)();
        return iVar6;
    }
    uVar3 = *(uint64_t *)(arg1 + 0x18);
    uVar5 = uVar2 - arg2;
    if (uVar5 < (uint64_t)arg3) {
        arg3 = uVar5;
    }
    if (arg3 == arg_28h) {
        iVar6 = arg1;
        if (0xf < uVar3) {
            iVar6 = *(int64_t *)arg1;
        }
        fcn.180498030(iVar6 + arg2, arg4, arg_28h);
    } else if ((uint64_t)arg_28h < (uint64_t)arg3) {
        iVar6 = arg1;
        if (0xf < uVar3) {
            iVar6 = *(int64_t *)arg1;
        }
        iVar6 = iVar6 + arg2;
        fcn.180498030(iVar6, arg4, arg_28h);
        fcn.180498030(iVar6 + arg_28h, iVar6 + arg3, (uVar5 - arg3) + 1);
        *(uint64_t *)(arg1 + 0x10) = (uVar2 - arg3) + arg_28h;
    } else {
        uVar5 = arg_28h - arg3;
        if (uVar3 - uVar2 < uVar5) {
            arg1 = fcn.180185390(arg1, uVar5, 0, arg2, arg3, arg4, arg_28h);
        } else {
            *(uint64_t *)(arg1 + 0x10) = uVar5 + uVar2;
            iVar6 = arg1;
            if (0xf < uVar3) {
                iVar6 = *(int64_t *)arg1;
            }
            uVar3 = iVar6 + arg2;
            uVar1 = arg3 + uVar3;
            iVar7 = arg_28h;
            if ((uVar3 < (uint64_t)(arg4 + arg_28h)) && ((uint64_t)arg4 <= uVar2 + iVar6)) {
                if ((uint64_t)arg4 < uVar1) {
                    iVar7 = uVar1 - arg4;
                } else {
                    iVar7 = 0;
                }
            }
            fcn.180498030(uVar1 + uVar5);
            fcn.180498030(uVar3, arg4, iVar7);
            fcn.180498030(iVar7 + uVar3, uVar5 + iVar7 + arg4, arg_28h - iVar7);
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_1801856f0
// Address: 0x1801856f0
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.180185560(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_48h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    code *pcVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x10);
    if (uVar2 < (uint64_t)arg2) {
        func_0x00018000f930();
        pcVar4 = (code *)swi(3);
        iVar6 = (*pcVar4)();
        return iVar6;
    }
    uVar3 = *(uint64_t *)(arg1 + 0x18);
    uVar5 = uVar2 - arg2;
    if (uVar5 < (uint64_t)arg3) {
        arg3 = uVar5;
    }
    if (arg3 == arg_28h) {
        iVar6 = arg1;
        if (0xf < uVar3) {
            iVar6 = *(int64_t *)arg1;
        }
        fcn.180498030(iVar6 + arg2, arg4, arg_28h);
    } else if ((uint64_t)arg_28h < (uint64_t)arg3) {
        iVar6 = arg1;
        if (0xf < uVar3) {
            iVar6 = *(int64_t *)arg1;
        }
        iVar6 = iVar6 + arg2;
        fcn.180498030(iVar6, arg4, arg_28h);
        fcn.180498030(iVar6 + arg_28h, iVar6 + arg3, (uVar5 - arg3) + 1);
        *(uint64_t *)(arg1 + 0x10) = (uVar2 - arg3) + arg_28h;
    } else {
        uVar5 = arg_28h - arg3;
        if (uVar3 - uVar2 < uVar5) {
            arg1 = fcn.180185390(arg1, uVar5, 0, arg2, arg3, arg4, arg_28h);
        } else {
            *(uint64_t *)(arg1 + 0x10) = uVar5 + uVar2;
            iVar6 = arg1;
            if (0xf < uVar3) {
                iVar6 = *(int64_t *)arg1;
            }
            uVar3 = iVar6 + arg2;
            uVar1 = arg3 + uVar3;
            iVar7 = arg_28h;
            if ((uVar3 < (uint64_t)(arg4 + arg_28h)) && ((uint64_t)arg4 <= uVar2 + iVar6)) {
                if ((uint64_t)arg4 < uVar1) {
                    iVar7 = uVar1 - arg4;
                } else {
                    iVar7 = 0;
                }
            }
            fcn.180498030(uVar1 + uVar5);
            fcn.180498030(uVar3, arg4, iVar7);
            fcn.180498030(iVar7 + uVar3, uVar5 + iVar7 + arg4, arg_28h - iVar7);
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_180185703
// Address: 0x180185703
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.180185560(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_48h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    code *pcVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x10);
    if (uVar2 < (uint64_t)arg2) {
        func_0x00018000f930();
        pcVar4 = (code *)swi(3);
        iVar6 = (*pcVar4)();
        return iVar6;
    }
    uVar3 = *(uint64_t *)(arg1 + 0x18);
    uVar5 = uVar2 - arg2;
    if (uVar5 < (uint64_t)arg3) {
        arg3 = uVar5;
    }
    if (arg3 == arg_28h) {
        iVar6 = arg1;
        if (0xf < uVar3) {
            iVar6 = *(int64_t *)arg1;
        }
        fcn.180498030(iVar6 + arg2, arg4, arg_28h);
    } else if ((uint64_t)arg_28h < (uint64_t)arg3) {
        iVar6 = arg1;
        if (0xf < uVar3) {
            iVar6 = *(int64_t *)arg1;
        }
        iVar6 = iVar6 + arg2;
        fcn.180498030(iVar6, arg4, arg_28h);
        fcn.180498030(iVar6 + arg_28h, iVar6 + arg3, (uVar5 - arg3) + 1);
        *(uint64_t *)(arg1 + 0x10) = (uVar2 - arg3) + arg_28h;
    } else {
        uVar5 = arg_28h - arg3;
        if (uVar3 - uVar2 < uVar5) {
            arg1 = fcn.180185390(arg1, uVar5, 0, arg2, arg3, arg4, arg_28h);
        } else {
            *(uint64_t *)(arg1 + 0x10) = uVar5 + uVar2;
            iVar6 = arg1;
            if (0xf < uVar3) {
                iVar6 = *(int64_t *)arg1;
            }
            uVar3 = iVar6 + arg2;
            uVar1 = arg3 + uVar3;
            iVar7 = arg_28h;
            if ((uVar3 < (uint64_t)(arg4 + arg_28h)) && ((uint64_t)arg4 <= uVar2 + iVar6)) {
                if ((uint64_t)arg4 < uVar1) {
                    iVar7 = uVar1 - arg4;
                } else {
                    iVar7 = 0;
                }
            }
            fcn.180498030(uVar1 + uVar5);
            fcn.180498030(uVar3, arg4, iVar7);
            fcn.180498030(iVar7 + uVar3, uVar5 + iVar7 + arg4, arg_28h - iVar7);
        }
    }
    return arg1;
}

