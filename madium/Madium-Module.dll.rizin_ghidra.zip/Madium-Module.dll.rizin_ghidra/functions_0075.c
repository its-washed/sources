// Chunk 75 - 50 functions

// ============================================================
// Function: FUN_1800f8096
// Address: 0x1800f8096
// Size: 1476 bytes
// ============================================================
void fcn.1800f8096(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_68h, int64_t arg_70h,
                  int64_t arg_78h, int64_t arg_f0h, int64_t arg_100h, int64_t arg_110h, int64_t arg_120h,
                  int64_t arg_130h, int64_t arg_140h, int64_t arg_150h, int64_t arg_160h, int64_t arg_170h,
                  int64_t arg_180h, int64_t arg_190h, int64_t arg_1e0h)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    float fVar3;
    float fVar4;
    undefined auVar5 [16];
    undefined auVar6 [16];
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    int32_t iVar14;
    int64_t unaff_RBP;
    int64_t *unaff_RSI;
    int64_t iVar15;
    int64_t iVar16;
    int64_t in_R10;
    int64_t in_R11;
    int64_t *unaff_R12;
    int64_t unaff_R13;
    uint8_t *unaff_R14;
    uint32_t unaff_R15D;
    float fVar17;
    undefined auVar18 [16];
    undefined auVar19 [16];
    float fVar20;
    float fVar21;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    float unaff_XMM8_Da;
    undefined4 unaff_XMM8_Db;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    float fVar22;
    float fVar23;
    float fVar24;
    undefined4 unaff_XMM15_Da;
    undefined4 unaff_XMM15_Db;
    undefined4 unaff_XMM15_Dc;
    undefined4 unaff_XMM15_Dd;
    undefined4 uVar26;
    uint64_t uVar25;
    undefined4 in_stack_00000058;
    undefined4 in_stack_0000005c;
    int64_t var_7ch;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_30h;
    int64_t var_20h;
    
    auVar5._4_4_ = unaff_XMM7_Db;
    auVar5._0_4_ = unaff_XMM7_Da;
    auVar5._8_4_ = unaff_XMM7_Dc;
    auVar5._12_4_ = unaff_XMM7_Dd;
    *(undefined (*) [16])(in_R11 + -0x58) = auVar5;
    auVar6._4_4_ = unaff_XMM15_Db;
    auVar6._0_4_ = unaff_XMM15_Da;
    auVar6._8_4_ = unaff_XMM15_Dc;
    auVar6._12_4_ = unaff_XMM15_Dd;
    *(undefined (*) [16])(in_R11 + -0xd8) = auVar6;
    do {
        *(undefined (*) [16])(unaff_RBP + -0x40) = ZEXT816(0);
        *(undefined (*) [16])(unaff_RBP + -0x30) = ZEXT816(0);
        if ((unaff_R15D < 0xb) && ((*unaff_R14 & 2) == 0)) {
            iVar12 = *(int64_t *)(unaff_R14 + 0x2b0);
            fVar22 = *(float *)(unaff_R14 + 0x54);
            iVar16 = *unaff_RSI;
            iVar15 = (int64_t)(*(int32_t *)
                                (*(int64_t *)(iVar12 + 0x78) + (uint64_t)(*(uint32_t *)(iVar12 + 0xec) & 0x7ffff) * 4)
                              << 0xc) >> 0xc;
            iVar11 = (int64_t)(int32_t)unaff_R15D;
            fVar3 = *(float *)(iVar11 * 0x18 + 0x18061ee58);
            fVar23 = arg_60h._4_4_ - *(float *)(iVar11 * 0x18 + 0x18061ee64);
            fVar4 = *(float *)(iVar11 * 0x18 + 0x18061ee5c);
            fVar24 = (float)arg_60h - *(float *)(iVar11 * 0x18 + 0x18061ee60);
            fVar21 = (float)(uint32_t)*(uint16_t *)(*(int64_t *)(iVar12 + 0x68) + iVar15 * 8) +
                     *(float *)(iVar11 * 0x18 + 0x18061ee50);
            fVar17 = (float)(uint32_t)*(uint16_t *)(*(int64_t *)(iVar12 + 0x68) + 2 + iVar15 * 8) +
                     *(float *)(iVar11 * 0x18 + 0x18061ee54);
            arg_48h = CONCAT44(fVar23, fVar24);
            *(float *)(unaff_RBP + -0x40) = fVar21 * fVar22;
            fVar20 = fVar17 * *(float *)(unaff_R14 + 0x58);
            fVar17 = (fVar4 + fVar17) * *(float *)(unaff_R14 + 0x58);
            *(float *)(unaff_RBP + -0x3c) = fVar20;
            *(float *)(unaff_RBP + -0x34) = fVar17;
            *(float *)(unaff_RBP + -0x38) = (fVar3 + fVar21) * fVar22;
            *(float *)(unaff_RBP + -0x30) = (fVar21 + 123.0) * fVar22;
            *(float *)(unaff_RBP + -0x2c) = fVar20;
            *(float *)(unaff_RBP + -0x28) = (fVar3 + fVar21 + 123.0) * fVar22;
            fVar22 = *(float *)(iVar16 + 0xc);
            *(float *)(unaff_RBP + -0x24) = fVar17;
            if (fVar23 < fVar22 + *(float *)(iVar16 + 0x14)) {
                fVar17 = unaff_XMM8_Da * *(float *)(iVar16 + 0x30);
                arg_48h._0_4_ = fVar24;
                arg_48h._4_4_ = fVar23;
                if (((fVar22 < (fVar4 + 2.0) * fVar17 + fVar23) &&
                    (fVar24 < *(float *)(iVar16 + 8) + *(float *)(iVar16 + 0x10))) &&
                   (fVar22 = (fVar3 + 2.0) * fVar17 + fVar24, *(float *)(iVar16 + 8) < fVar22)) {
                    if (iVar16 == 0) {
                        iVar16 = *(int64_t *)(*(int64_t *)(in_R10 + 0x15e0) + 0x48);
                    }
                    iVar12 = func_0x0001800fa7f0(iVar16, 1, 0x1806444d0);
                    uVar26 = *(undefined4 *)(unaff_R14 + 0x28);
                    uVar7 = *(undefined4 *)(unaff_R14 + 0x2c);
                    uVar8 = *(undefined4 *)(unaff_R14 + 0x30);
                    uVar9 = *(undefined4 *)(unaff_R14 + 0x34);
                    iVar10 = *(int32_t *)(iVar12 + 0xb4);
                    piVar1 = (int32_t *)(iVar12 + 0xb0);
                    if (*piVar1 == iVar10) {
                        iVar14 = *piVar1 + 1;
                        if (iVar10 == 0) {
                            iVar10 = 8;
                        } else {
                            iVar10 = iVar10 / 2 + iVar10;
                        }
                        if (iVar14 < iVar10) {
                            iVar14 = iVar10;
                        }
                        func_0x00018011faa0(piVar1, iVar14);
                    }
                    puVar13 = (undefined4 *)(*(int64_t *)(iVar12 + 0xb8) + (int64_t)*piVar1 * 0x10);
                    *puVar13 = uVar26;
                    puVar13[1] = uVar7;
                    puVar13[2] = uVar8;
                    puVar13[3] = uVar9;
                    *piVar1 = *piVar1 + 1;
                    *(undefined4 *)(iVar12 + 0x70) = uVar26;
                    *(undefined4 *)(iVar12 + 0x74) = uVar7;
                    *(undefined4 *)(iVar12 + 0x78) = uVar8;
                    *(undefined4 *)(iVar12 + 0x7c) = uVar9;
                    func_0x000180124360(iVar12);
                    arg_68h._0_4_ = (fVar3 + 1.0) * fVar17 + fVar24;
                    fVar20 = fVar17 * 0.0 + fVar23;
                    fVar21 = (fVar4 + 0.0) * fVar17 + fVar23;
                    arg_70h._0_4_ = fVar17 + fVar24;
                    arg_50h._0_4_ = uVar26;
                    arg_50h._4_4_ = uVar7;
                    in_stack_00000058 = uVar8;
                    in_stack_0000005c = uVar9;
                    arg_68h._4_4_ = fVar21;
                    arg_70h._4_4_ = fVar20;
                    func_0x0001801268f0(iVar12, &arg_50h, &arg_70h, &arg_68h, unaff_RBP + -0x30);
                    *(float *)(unaff_RBP + -0x7c) = fVar20;
                    *(float *)(unaff_RBP + -0x80) = fVar17 + fVar17 + fVar24;
                    arg_50h._0_4_ = uVar26;
                    arg_50h._4_4_ = uVar7;
                    in_stack_00000058 = uVar8;
                    in_stack_0000005c = uVar9;
                    arg_78h._0_4_ = fVar22;
                    arg_78h._4_4_ = fVar21;
                    func_0x0001801268f0(iVar12, &arg_50h, unaff_RBP + -0x80, &arg_78h, unaff_RBP + -0x30);
                    *(float *)(unaff_RBP + -0x78) = fVar17 * fVar3 + fVar24;
                    *(float *)(unaff_RBP + -0x74) = fVar17 * fVar4 + fVar23;
                    arg_50h._0_4_ = uVar26;
                    arg_50h._4_4_ = uVar7;
                    in_stack_00000058 = uVar8;
                    in_stack_0000005c = uVar9;
                    func_0x0001801268f0(iVar12, &arg_50h, &arg_48h, unaff_RBP + -0x78, unaff_RBP + -0x30);
                    *(float *)(unaff_RBP + -0x70) = fVar17 * fVar3 + fVar24;
                    *(float *)(unaff_RBP + -0x6c) = fVar17 * fVar4 + fVar23;
                    iVar16 = unaff_RBP + -0x40;
                    arg_50h._0_4_ = uVar26;
                    arg_50h._4_4_ = uVar7;
                    in_stack_00000058 = uVar8;
                    in_stack_0000005c = uVar9;
                    func_0x0001801268f0(iVar12, &arg_50h, &arg_48h, unaff_RBP + -0x70, iVar16);
                    uVar26 = (undefined4)((uint64_t)iVar16 >> 0x20);
                    if (unaff_R15D - 8 < 2) {
                        fVar22 = (float)func_0x000180490df0((float)*(double *)(unaff_R13 + 0x18) * 5.0, 0x40c90fdb);
                        auVar18._4_4_ = unaff_XMM8_Db;
                        auVar18._0_4_ = fVar17;
                        auVar18._8_4_ = unaff_XMM8_Dc;
                        auVar18._12_4_ = unaff_XMM8_Dd;
                        auVar19._4_12_ = auVar18._4_12_;
                        auVar19._0_4_ = fVar17 * 6.0;
                        *(float *)(unaff_RBP + -0x68) = fVar17 * 14.0 + fVar24;
                        *(float *)(unaff_RBP + -100) = fVar23 - fVar17 * 1.0;
                        uVar25 = CONCAT44(uVar26, fVar22 + 5.183628);
                        func_0x000180125bc0(iVar12, unaff_RBP + -0x68, auVar19._0_8_, fVar22, uVar25);
                        func_0x0001801248e0(iVar12, *(undefined8 *)(iVar12 + 0x58), *(undefined4 *)(iVar12 + 0x50), 
                                            0xffffffff, uVar25 & 0xffffffff00000000);
                        *(undefined4 *)(iVar12 + 0x50) = 0;
                    }
                    iVar10 = *piVar1;
                    iVar14 = iVar10 + -1;
                    *piVar1 = iVar14;
                    if (iVar14 == 0) {
                        *(undefined8 *)(unaff_RBP + -0x60) = 0;
                        puVar13 = (undefined4 *)(unaff_RBP + -0x60);
                        *(undefined8 *)(unaff_RBP + -0x58) = 0;
                    } else {
                        puVar2 = (undefined4 *)(*(int64_t *)(iVar12 + 0xb8) + ((int64_t)iVar10 + -2) * 0x10);
                        uVar26 = puVar2[1];
                        uVar7 = puVar2[2];
                        uVar8 = puVar2[3];
                        puVar13 = (undefined4 *)(unaff_RBP + -0x50);
                        *(undefined4 *)(unaff_RBP + -0x50) = *puVar2;
                        *(undefined4 *)(unaff_RBP + -0x4c) = uVar26;
                        *(undefined4 *)(unaff_RBP + -0x48) = uVar7;
                        *(undefined4 *)(unaff_RBP + -0x44) = uVar8;
                    }
                    uVar26 = puVar13[1];
                    uVar7 = puVar13[2];
                    uVar8 = puVar13[3];
                    *(undefined4 *)(iVar12 + 0x70) = *puVar13;
                    *(undefined4 *)(iVar12 + 0x74) = uVar26;
                    *(undefined4 *)(iVar12 + 0x78) = uVar7;
                    *(undefined4 *)(iVar12 + 0x7c) = uVar8;
                    func_0x000180124360(iVar12);
                    in_R10 = *(int64_t *)0x180781f28;
                }
                unaff_XMM8_Db = 0;
                unaff_XMM8_Dc = 0;
                unaff_XMM8_Dd = 0;
                unaff_XMM8_Da = (float)arg_40h;
            }
        }
        unaff_RSI = unaff_RSI + 1;
    } while (unaff_RSI != unaff_R12);
    func_0x000180459870(*(uint64_t *)(unaff_RBP + -0x20) ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_1800f865a
// Address: 0x1800f865a
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_1e0h
// WARNING: Variable defined which should be unmapped: arg_190h
// WARNING: [rz-ghidra] Removing arg arg_64h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable arg_74h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.1800f8096(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_68h, int64_t arg_70h,
                  int64_t arg_78h, int64_t arg_f0h, int64_t arg_100h, int64_t arg_110h, int64_t arg_120h,
                  int64_t arg_130h, int64_t arg_140h, int64_t arg_150h, int64_t arg_160h, int64_t arg_170h,
                  int64_t arg_180h, int64_t arg_190h, int64_t arg_1e0h)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    float fVar3;
    float fVar4;
    undefined auVar5 [16];
    undefined auVar6 [16];
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined4 *puVar13;
    int32_t iVar14;
    int64_t unaff_RBP;
    int64_t *unaff_RSI;
    int64_t iVar15;
    int64_t iVar16;
    int64_t in_R10;
    int64_t in_R11;
    int64_t *unaff_R12;
    int64_t unaff_R13;
    uint8_t *unaff_R14;
    uint32_t unaff_R15D;
    float fVar17;
    undefined auVar18 [16];
    undefined auVar19 [16];
    float fVar20;
    float fVar21;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    float unaff_XMM8_Da;
    undefined4 unaff_XMM8_Db;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    float fVar22;
    float fVar23;
    float fVar24;
    undefined4 unaff_XMM15_Da;
    undefined4 unaff_XMM15_Db;
    undefined4 unaff_XMM15_Dc;
    undefined4 unaff_XMM15_Dd;
    undefined4 uVar26;
    uint64_t uVar25;
    undefined4 in_stack_00000058;
    undefined4 in_stack_0000005c;
    int64_t var_7ch;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_30h;
    int64_t var_20h;
    
    auVar5._4_4_ = unaff_XMM7_Db;
    auVar5._0_4_ = unaff_XMM7_Da;
    auVar5._8_4_ = unaff_XMM7_Dc;
    auVar5._12_4_ = unaff_XMM7_Dd;
    *(undefined (*) [16])(in_R11 + -0x58) = auVar5;
    auVar6._4_4_ = unaff_XMM15_Db;
    auVar6._0_4_ = unaff_XMM15_Da;
    auVar6._8_4_ = unaff_XMM15_Dc;
    auVar6._12_4_ = unaff_XMM15_Dd;
    *(undefined (*) [16])(in_R11 + -0xd8) = auVar6;
    do {
        *(undefined (*) [16])(unaff_RBP + -0x40) = ZEXT816(0);
        *(undefined (*) [16])(unaff_RBP + -0x30) = ZEXT816(0);
        if ((unaff_R15D < 0xb) && ((*unaff_R14 & 2) == 0)) {
            iVar12 = *(int64_t *)(unaff_R14 + 0x2b0);
            fVar22 = *(float *)(unaff_R14 + 0x54);
            iVar16 = *unaff_RSI;
            iVar15 = (int64_t)(*(int32_t *)
                                (*(int64_t *)(iVar12 + 0x78) + (uint64_t)(*(uint32_t *)(iVar12 + 0xec) & 0x7ffff) * 4)
                              << 0xc) >> 0xc;
            iVar11 = (int64_t)(int32_t)unaff_R15D;
            fVar3 = *(float *)(iVar11 * 0x18 + 0x18061ee58);
            fVar23 = arg_60h._4_4_ - *(float *)(iVar11 * 0x18 + 0x18061ee64);
            fVar4 = *(float *)(iVar11 * 0x18 + 0x18061ee5c);
            fVar24 = (float)arg_60h - *(float *)(iVar11 * 0x18 + 0x18061ee60);
            fVar21 = (float)(uint32_t)*(uint16_t *)(*(int64_t *)(iVar12 + 0x68) + iVar15 * 8) +
                     *(float *)(iVar11 * 0x18 + 0x18061ee50);
            fVar17 = (float)(uint32_t)*(uint16_t *)(*(int64_t *)(iVar12 + 0x68) + 2 + iVar15 * 8) +
                     *(float *)(iVar11 * 0x18 + 0x18061ee54);
            arg_48h = CONCAT44(fVar23, fVar24);
            *(float *)(unaff_RBP + -0x40) = fVar21 * fVar22;
            fVar20 = fVar17 * *(float *)(unaff_R14 + 0x58);
            fVar17 = (fVar4 + fVar17) * *(float *)(unaff_R14 + 0x58);
            *(float *)(unaff_RBP + -0x3c) = fVar20;
            *(float *)(unaff_RBP + -0x34) = fVar17;
            *(float *)(unaff_RBP + -0x38) = (fVar3 + fVar21) * fVar22;
            *(float *)(unaff_RBP + -0x30) = (fVar21 + 123.0) * fVar22;
            *(float *)(unaff_RBP + -0x2c) = fVar20;
            *(float *)(unaff_RBP + -0x28) = (fVar3 + fVar21 + 123.0) * fVar22;
            fVar22 = *(float *)(iVar16 + 0xc);
            *(float *)(unaff_RBP + -0x24) = fVar17;
            if (fVar23 < fVar22 + *(float *)(iVar16 + 0x14)) {
                fVar17 = unaff_XMM8_Da * *(float *)(iVar16 + 0x30);
                arg_48h._0_4_ = fVar24;
                arg_48h._4_4_ = fVar23;
                if (((fVar22 < (fVar4 + 2.0) * fVar17 + fVar23) &&
                    (fVar24 < *(float *)(iVar16 + 8) + *(float *)(iVar16 + 0x10))) &&
                   (fVar22 = (fVar3 + 2.0) * fVar17 + fVar24, *(float *)(iVar16 + 8) < fVar22)) {
                    if (iVar16 == 0) {
                        iVar16 = *(int64_t *)(*(int64_t *)(in_R10 + 0x15e0) + 0x48);
                    }
                    iVar12 = func_0x0001800fa7f0(iVar16, 1, 0x1806444d0);
                    uVar26 = *(undefined4 *)(unaff_R14 + 0x28);
                    uVar7 = *(undefined4 *)(unaff_R14 + 0x2c);
                    uVar8 = *(undefined4 *)(unaff_R14 + 0x30);
                    uVar9 = *(undefined4 *)(unaff_R14 + 0x34);
                    iVar10 = *(int32_t *)(iVar12 + 0xb4);
                    piVar1 = (int32_t *)(iVar12 + 0xb0);
                    if (*piVar1 == iVar10) {
                        iVar14 = *piVar1 + 1;
                        if (iVar10 == 0) {
                            iVar10 = 8;
                        } else {
                            iVar10 = iVar10 / 2 + iVar10;
                        }
                        if (iVar14 < iVar10) {
                            iVar14 = iVar10;
                        }
                        func_0x00018011faa0(piVar1, iVar14);
                    }
                    puVar13 = (undefined4 *)(*(int64_t *)(iVar12 + 0xb8) + (int64_t)*piVar1 * 0x10);
                    *puVar13 = uVar26;
                    puVar13[1] = uVar7;
                    puVar13[2] = uVar8;
                    puVar13[3] = uVar9;
                    *piVar1 = *piVar1 + 1;
                    *(undefined4 *)(iVar12 + 0x70) = uVar26;
                    *(undefined4 *)(iVar12 + 0x74) = uVar7;
                    *(undefined4 *)(iVar12 + 0x78) = uVar8;
                    *(undefined4 *)(iVar12 + 0x7c) = uVar9;
                    func_0x000180124360(iVar12);
                    arg_68h._0_4_ = (fVar3 + 1.0) * fVar17 + fVar24;
                    fVar20 = fVar17 * 0.0 + fVar23;
                    fVar21 = (fVar4 + 0.0) * fVar17 + fVar23;
                    arg_70h._0_4_ = fVar17 + fVar24;
                    arg_50h._0_4_ = uVar26;
                    arg_50h._4_4_ = uVar7;
                    in_stack_00000058 = uVar8;
                    in_stack_0000005c = uVar9;
                    arg_68h._4_4_ = fVar21;
                    arg_70h._4_4_ = fVar20;
                    func_0x0001801268f0(iVar12, &arg_50h, &arg_70h, &arg_68h, unaff_RBP + -0x30);
                    *(float *)(unaff_RBP + -0x7c) = fVar20;
                    *(float *)(unaff_RBP + -0x80) = fVar17 + fVar17 + fVar24;
                    arg_50h._0_4_ = uVar26;
                    arg_50h._4_4_ = uVar7;
                    in_stack_00000058 = uVar8;
                    in_stack_0000005c = uVar9;
                    arg_78h._0_4_ = fVar22;
                    arg_78h._4_4_ = fVar21;
                    func_0x0001801268f0(iVar12, &arg_50h, unaff_RBP + -0x80, &arg_78h, unaff_RBP + -0x30);
                    *(float *)(unaff_RBP + -0x78) = fVar17 * fVar3 + fVar24;
                    *(float *)(unaff_RBP + -0x74) = fVar17 * fVar4 + fVar23;
                    arg_50h._0_4_ = uVar26;
                    arg_50h._4_4_ = uVar7;
                    in_stack_00000058 = uVar8;
                    in_stack_0000005c = uVar9;
                    func_0x0001801268f0(iVar12, &arg_50h, &arg_48h, unaff_RBP + -0x78, unaff_RBP + -0x30);
                    *(float *)(unaff_RBP + -0x70) = fVar17 * fVar3 + fVar24;
                    *(float *)(unaff_RBP + -0x6c) = fVar17 * fVar4 + fVar23;
                    iVar16 = unaff_RBP + -0x40;
                    arg_50h._0_4_ = uVar26;
                    arg_50h._4_4_ = uVar7;
                    in_stack_00000058 = uVar8;
                    in_stack_0000005c = uVar9;
                    func_0x0001801268f0(iVar12, &arg_50h, &arg_48h, unaff_RBP + -0x70, iVar16);
                    uVar26 = (undefined4)((uint64_t)iVar16 >> 0x20);
                    if (unaff_R15D - 8 < 2) {
                        fVar22 = (float)func_0x000180490df0((float)*(double *)(unaff_R13 + 0x18) * 5.0, 0x40c90fdb);
                        auVar18._4_4_ = unaff_XMM8_Db;
                        auVar18._0_4_ = fVar17;
                        auVar18._8_4_ = unaff_XMM8_Dc;
                        auVar18._12_4_ = unaff_XMM8_Dd;
                        auVar19._4_12_ = auVar18._4_12_;
                        auVar19._0_4_ = fVar17 * 6.0;
                        *(float *)(unaff_RBP + -0x68) = fVar17 * 14.0 + fVar24;
                        *(float *)(unaff_RBP + -100) = fVar23 - fVar17 * 1.0;
                        uVar25 = CONCAT44(uVar26, fVar22 + 5.183628);
                        func_0x000180125bc0(iVar12, unaff_RBP + -0x68, auVar19._0_8_, fVar22, uVar25);
                        func_0x0001801248e0(iVar12, *(undefined8 *)(iVar12 + 0x58), *(undefined4 *)(iVar12 + 0x50), 
                                            0xffffffff, uVar25 & 0xffffffff00000000);
                        *(undefined4 *)(iVar12 + 0x50) = 0;
                    }
                    iVar10 = *piVar1;
                    iVar14 = iVar10 + -1;
                    *piVar1 = iVar14;
                    if (iVar14 == 0) {
                        *(undefined8 *)(unaff_RBP + -0x60) = 0;
                        puVar13 = (undefined4 *)(unaff_RBP + -0x60);
                        *(undefined8 *)(unaff_RBP + -0x58) = 0;
                    } else {
                        puVar2 = (undefined4 *)(*(int64_t *)(iVar12 + 0xb8) + ((int64_t)iVar10 + -2) * 0x10);
                        uVar26 = puVar2[1];
                        uVar7 = puVar2[2];
                        uVar8 = puVar2[3];
                        puVar13 = (undefined4 *)(unaff_RBP + -0x50);
                        *(undefined4 *)(unaff_RBP + -0x50) = *puVar2;
                        *(undefined4 *)(unaff_RBP + -0x4c) = uVar26;
                        *(undefined4 *)(unaff_RBP + -0x48) = uVar7;
                        *(undefined4 *)(unaff_RBP + -0x44) = uVar8;
                    }
                    uVar26 = puVar13[1];
                    uVar7 = puVar13[2];
                    uVar8 = puVar13[3];
                    *(undefined4 *)(iVar12 + 0x70) = *puVar13;
                    *(undefined4 *)(iVar12 + 0x74) = uVar26;
                    *(undefined4 *)(iVar12 + 0x78) = uVar7;
                    *(undefined4 *)(iVar12 + 0x7c) = uVar8;
                    func_0x000180124360(iVar12);
                    in_R10 = *(int64_t *)0x180781f28;
                }
                unaff_XMM8_Db = 0;
                unaff_XMM8_Dc = 0;
                unaff_XMM8_Dd = 0;
                unaff_XMM8_Da = (float)arg_40h;
            }
        }
        unaff_RSI = unaff_RSI + 1;
    } while (unaff_RSI != unaff_R12);
    func_0x000180459870(*(uint64_t *)(unaff_RBP + -0x20) ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_1800f8690
// Address: 0x1800f8690
// Size: 3965 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800f8690(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    uint64_t uVar2;
    undefined8 *puVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint32_t uVar6;
    bool bVar7;
    undefined4 uVar8;
    float fVar9;
    int64_t var_10h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    func_0x0001800f4f10(arg1 + 0x30);
    func_0x0001804986e0(arg1 + 0xc48, 0, 0x148);
    *(undefined2 *)(arg1 + 0xc80) = 0x2e;
    func_0x0001800f4650(arg1 + 0xd90);
    uVar5 = 0;
    *(undefined8 *)(arg1 + 0x12d8) = 0;
    *(undefined8 *)(arg1 + 0x12e0) = 0;
    *(undefined8 *)(arg1 + 0x1310) = 0;
    *(undefined8 *)(arg1 + 0x1348) = 0;
    *(undefined8 *)(arg1 + 0x1350) = 0;
    *(undefined8 *)(arg1 + 0x1358) = 0;
    *(undefined8 *)(arg1 + 0x1360) = 0;
    *(undefined8 *)(arg1 + 0x1368) = 0;
    *(undefined8 *)(arg1 + 0x1370) = 0;
    puVar3 = (undefined8 *)(arg1 + 0x1380);
    iVar4 = 0x30;
    do {
        *puVar3 = 0;
        puVar3 = puVar3 + 1;
        iVar4 = iVar4 + -1;
    } while (iVar4 != 0);
    func_0x0001804986e0((undefined8 *)(arg1 + 0x1310), 0, 0x238);
    *(undefined4 *)(arg1 + 0x1340) = 0x3f800000;
    uVar2 = uVar5;
    do {
        fVar9 = (float)(int32_t)uVar2;
        fVar9 = ((fVar9 + fVar9) * 3.141593) / 48.0;
        uVar8 = func_0x00018048ffb0(fVar9);
        *(undefined4 *)(arg1 + 0x1380 + uVar2 * 8) = uVar8;
        uVar8 = func_0x000180493d20(fVar9);
        *(undefined4 *)(arg1 + 0x1384 + uVar2 * 8) = uVar8;
        uVar6 = (int32_t)uVar2 + 1;
        uVar2 = (uint64_t)uVar6;
    } while ((int32_t)uVar6 < 0x30);
    fVar9 = (float)func_0x00018048ffb0(0x3d860a92);
    *(float *)(arg1 + 0x1500) = *(float *)(arg1 + 0x133c) / (1.0 - fVar9);
    *(undefined8 *)(arg1 + 0x1558) = 0;
    *(undefined8 *)(arg1 + 0x1560) = 0;
    *(undefined8 *)(arg1 + 0x1568) = 0;
    *(undefined8 *)(arg1 + 0x1570) = 0;
    *(undefined8 *)(arg1 + 0x1580) = 0;
    *(undefined8 *)(arg1 + 0x1588) = 0;
    *(undefined8 *)(arg1 + 0x1590) = 0;
    *(undefined8 *)(arg1 + 0x1598) = 0;
    *(undefined8 *)(arg1 + 0x15a0) = 0;
    *(undefined8 *)(arg1 + 0x15a8) = 0;
    *(undefined8 *)(arg1 + 0x15b0) = 0;
    *(undefined8 *)(arg1 + 0x15b8) = 0;
    *(undefined8 *)(arg1 + 0x15c0) = 0;
    *(undefined8 *)(arg1 + 0x15c8) = 0;
    *(undefined8 *)(arg1 + 0x1610) = 0;
    *(undefined8 *)(arg1 + 0x1624) = 0;
    *(undefined8 *)(arg1 + 0x162c) = 0;
    *(undefined8 *)(arg1 + 0x166c) = 0;
    *(undefined (*) [16])(arg1 + 0x16b8) = ZEXT816(0);
    *(undefined4 *)(arg1 + 0x16c8) = 0;
    puVar3 = (undefined8 *)(arg1 + 0x16cc);
    iVar4 = 0x9b;
    do {
        *puVar3 = 0xffffffffffffffff;
        *(undefined2 *)(puVar3 + 1) = 0;
        puVar3 = (undefined8 *)((int64_t)puVar3 + 0xc);
        iVar4 = iVar4 + -1;
    } while (iVar4 != 0);
    *(undefined8 *)(arg1 + 0x1f48) = 0;
    *(undefined8 *)(arg1 + 0x1f50) = 0;
    *(undefined8 *)(arg1 + 0x1f58) = 0;
    *(undefined8 *)(arg1 + 0x1f60) = 0;
    func_0x0001800f4230();
    *(undefined8 *)(arg1 + 0x1f80) = 0;
    *(undefined8 *)(arg1 + 0x1f88) = 0;
    *(undefined8 *)(arg1 + 0x1f98) = 0;
    *(undefined8 *)(arg1 + 0x1fa0) = 0;
    *(undefined8 *)(arg1 + 0x1fa8) = 0;
    *(undefined8 *)(arg1 + 0x1fb0) = 0;
    *(undefined8 *)(arg1 + 0x1f90) = 0xffffffffffffffff;
    *(undefined (*) [16])(arg1 + 0x1fb8) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x1fc8) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x1fd8) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x1fe8) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x1ff8) = ZEXT816(0);
    func_0x0001804986e0(arg1 + 0x2008, 0, 0xb0);
    *(undefined8 *)(arg1 + 0x20c0) = 0;
    *(undefined8 *)(arg1 + 0x20c8) = 0;
    *(undefined8 *)(arg1 + 0x20d0) = 0;
    *(undefined8 *)(arg1 + 0x20d8) = 0;
    *(undefined8 *)(arg1 + 0x20e0) = 0;
    *(undefined8 *)(arg1 + 0x20e8) = 0;
    *(undefined8 *)(arg1 + 0x20f0) = 0;
    *(undefined8 *)(arg1 + 0x20f8) = 0;
    *(undefined8 *)(arg1 + 0x2100) = 0;
    *(undefined8 *)(arg1 + 0x2108) = 0;
    *(undefined8 *)(arg1 + 0x2110) = 0;
    *(undefined8 *)(arg1 + 0x2118) = 0;
    *(undefined8 *)(arg1 + 0x2120) = 0;
    *(undefined8 *)(arg1 + 0x2128) = 0;
    *(undefined8 *)(arg1 + 0x2130) = 0;
    *(undefined8 *)(arg1 + 0x2138) = 0;
    *(undefined8 *)(arg1 + 0x2140) = 0;
    *(undefined8 *)(arg1 + 0x2148) = 0;
    *(undefined8 *)(arg1 + 0x2150) = 0;
    *(undefined8 *)(arg1 + 0x2158) = 0;
    *(undefined8 *)(arg1 + 0x2198) = 0;
    *(undefined8 *)(arg1 + 0x2190) = 0;
    *(undefined8 *)(arg1 + 0x2188) = 0;
    *(undefined8 *)(arg1 + 0x2180) = 0;
    *(undefined4 *)(arg1 + 0x21a0) = 0x3f800000;
    *(undefined8 *)(arg1 + 0x21a8) = 0;
    *(undefined8 *)(arg1 + 0x21b0) = 0;
    *(undefined8 *)(arg1 + 0x21b8) = 0;
    *(undefined8 *)(arg1 + 0x2200) = 0;
    *(undefined8 *)(arg1 + 0x2208) = 0;
    *(undefined8 *)(arg1 + 0x2250) = 0;
    *(undefined8 *)(arg1 + 0x2258) = 0;
    *(undefined8 *)(arg1 + 0x2240) = 0;
    *(undefined8 *)(arg1 + 0x2248) = 0;
    *(undefined4 *)(arg1 + 0x2260) = 0;
    *(undefined8 *)(arg1 + 0x2270) = 0xffffffffffffffff;
    *(undefined4 *)(arg1 + 0x226c) = 0x7f7fffff;
    *(undefined4 *)(arg1 + 0x2268) = 0x7f7fffff;
    *(undefined4 *)(arg1 + 0x2264) = 0x7f7fffff;
    *(undefined8 *)(arg1 + 0x2294) = 0;
    *(undefined8 *)(arg1 + 0x229c) = 0;
    *(undefined8 *)(arg1 + 0x22a4) = 0;
    *(undefined8 *)(arg1 + 0x22ac) = 0;
    *(undefined8 *)(arg1 + 0x22d0) = 0;
    *(undefined8 *)(arg1 + 0x22d8) = 0;
    *(undefined8 *)(arg1 + 0x22c0) = 0;
    *(undefined8 *)(arg1 + 0x22c8) = 0;
    *(undefined4 *)(arg1 + 0x22e0) = 0;
    *(undefined8 *)(arg1 + 0x22f0) = 0xffffffffffffffff;
    *(undefined4 *)(arg1 + 0x22ec) = 0x7f7fffff;
    *(undefined4 *)(arg1 + 0x22e8) = 0x7f7fffff;
    *(undefined4 *)(arg1 + 0x22e4) = 0x7f7fffff;
    *(undefined8 *)(arg1 + 0x2308) = 0;
    *(undefined8 *)(arg1 + 0x2310) = 0;
    *(undefined8 *)(arg1 + 0x22f8) = 0;
    *(undefined8 *)(arg1 + 0x2300) = 0;
    *(undefined4 *)(arg1 + 0x2318) = 0;
    *(undefined8 *)(arg1 + 9000) = 0xffffffffffffffff;
    *(undefined4 *)(arg1 + 0x2324) = 0x7f7fffff;
    *(undefined4 *)(arg1 + 0x2320) = 0x7f7fffff;
    *(undefined4 *)(arg1 + 0x231c) = 0x7f7fffff;
    *(undefined8 *)(arg1 + 0x2340) = 0;
    *(undefined8 *)(arg1 + 0x2348) = 0;
    *(undefined8 *)(arg1 + 0x2330) = 0;
    *(undefined8 *)(arg1 + 0x2338) = 0;
    *(undefined4 *)(arg1 + 0x2350) = 0;
    *(undefined8 *)(arg1 + 0x2360) = 0xffffffffffffffff;
    *(undefined4 *)(arg1 + 0x235c) = 0x7f7fffff;
    *(undefined4 *)(arg1 + 0x2358) = 0x7f7fffff;
    *(undefined4 *)(arg1 + 0x2354) = 0x7f7fffff;
    *(undefined8 *)(arg1 + 0x2378) = 0;
    *(undefined8 *)(arg1 + 0x2380) = 0;
    *(undefined8 *)(arg1 + 0x2368) = 0;
    *(undefined8 *)(arg1 + 0x2370) = 0;
    *(undefined4 *)(arg1 + 0x2388) = 0;
    *(undefined8 *)(arg1 + 0x2398) = 0xffffffffffffffff;
    *(undefined4 *)(arg1 + 0x2394) = 0x7f7fffff;
    *(undefined4 *)(arg1 + 0x2390) = 0x7f7fffff;
    *(undefined4 *)(arg1 + 0x238c) = 0x7f7fffff;
    *(undefined8 *)(arg1 + 0x23ec) = 0;
    *(undefined8 *)(arg1 + 0x23f4) = 0;
    *(undefined8 *)(arg1 + 0x241c) = 0;
    *(undefined8 *)(arg1 + 0x2410) = 0;
    *(undefined4 *)(arg1 + 0x2418) = 0;
    *(undefined (*) [16])(arg1 + 0x2428) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2438) = ZEXT816(0);
    *(undefined2 *)(arg1 + 0x2448) = 0;
    *(undefined4 *)(arg1 + 0x2424) = 0xffffffff;
    *(undefined *)(arg1 + 0x244a) = 0;
    *(undefined8 *)(arg1 + 0x2450) = 0;
    *(undefined8 *)(arg1 + 0x2458) = 0;
    *(undefined8 *)(arg1 + 0x2460) = 0;
    *(undefined8 *)(arg1 + 0x2468) = 0;
    *(undefined8 *)(arg1 + 0x2498) = 0;
    *(undefined8 *)(arg1 + 0x24a0) = 0;
    *(undefined8 *)(arg1 + 0x24c0) = 0;
    *(undefined8 *)(arg1 + 0x24c8) = 0;
    *(undefined8 *)(arg1 + 0x24e0) = 0;
    *(undefined8 *)(arg1 + 0x24e8) = 0;
    *(undefined8 *)(arg1 + 0x24f0) = 0;
    *(undefined8 *)(arg1 + 0x24f8) = 0;
    *(undefined8 *)(arg1 + 0x2500) = 0;
    *(undefined8 *)(arg1 + 0x2508) = 0;
    *(undefined8 *)(arg1 + 0x2510) = 0;
    *(undefined8 *)(arg1 + 0x2518) = 0;
    *(undefined8 *)(arg1 + 0x2520) = 0;
    *(undefined8 *)(arg1 + 0x2528) = 0;
    *(undefined8 *)(arg1 + 0x2530) = 0;
    *(undefined8 *)(arg1 + 0x2540) = 0;
    *(undefined8 *)(arg1 + 0x2548) = 0;
    *(undefined8 *)(arg1 + 0x2550) = 0;
    *(undefined8 *)(arg1 + 0x2558) = 0;
    *(undefined8 *)(arg1 + 0x2560) = 0;
    *(undefined8 *)(arg1 + 0x2568) = 0;
    *(undefined8 *)(arg1 + 0x2570) = 0;
    *(undefined8 *)(arg1 + 0x2578) = 0;
    *(undefined8 *)(arg1 + 0x2580) = 0;
    *(undefined (*) [16])(arg1 + 0x2588) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2598) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x25a8) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x25b8) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x25c8) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x25d8) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x25e8) = 0;
    *(undefined8 *)(arg1 + 0x2600) = 0;
    *(undefined8 *)(arg1 + 0x2608) = 0;
    *(undefined8 *)(arg1 + 0x2610) = 0;
    *(undefined8 *)(arg1 + 0x2618) = 0;
    *(undefined8 *)(arg1 + 0x2620) = 0;
    *(undefined8 *)(arg1 + 0x2628) = 0;
    *(undefined8 *)(arg1 + 0x2630) = 0;
    *(undefined8 *)(arg1 + 0x2658) = 0;
    *(undefined (*) [16])(arg1 + 0x2660) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2670) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2680) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2690) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x26a0) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x26b0) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x26c0) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x26d0) = ZEXT816(0);
    uVar1 = func_0x00018046d050(0xa44);
    *(undefined8 *)(arg1 + 0x2668) = uVar1;
    func_0x0001804986e0(uVar1, 0, 0xa44);
    *(undefined8 *)(arg1 + 0x26e0) = 0;
    *(undefined8 *)(arg1 + 0x26e8) = 0;
    *(undefined4 *)(arg1 + 0x26f0) = 0;
    *(undefined (*) [16])(arg1 + 0x26f8) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x2708) = 0;
    *(undefined (*) [16])(arg1 + 10000) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2720) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2730) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2740) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2750) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2760) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x2770) = 0;
    *(undefined4 *)(arg1 + 0x2750) = 0xffffffff;
    *(undefined8 *)(arg1 + 0x27ac) = 0;
    *(undefined8 *)(arg1 + 0x27b4) = 0;
    *(undefined (*) [16])(arg1 + 0x27bc) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x27cc) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x27dc) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x27ec) = 0;
    *(undefined8 *)(arg1 + 0x27f4) = 0;
    *(undefined8 *)(arg1 + 0x2828) = 0;
    *(undefined8 *)(arg1 + 0x2830) = 0;
    *(undefined8 *)(arg1 + 0x2838) = 0;
    *(undefined8 *)(arg1 + 0x2840) = 0;
    *(undefined (*) [16])(arg1 + 0x2848) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2858) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2868) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2878) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2888) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2898) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x28a8) = 0;
    *(undefined (*) [16])(arg1 + 0x28b0) = ZEXT816(0);
    *(undefined4 *)(arg1 + 0x28c0) = 0;
    *(undefined (*) [16])(arg1 + 0x28c4) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x28d4) = 0;
    *(undefined4 *)(arg1 + 0x28dc) = 0;
    *(undefined8 *)(arg1 + 0x28e0) = 0;
    *(undefined (*) [16])(arg1 + 0x28e8) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x28f8) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2908) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x2918) = 0;
    *(undefined8 *)(arg1 + 0x2930) = 0;
    *(undefined8 *)(arg1 + 0x2938) = 0;
    *(undefined8 *)(arg1 + 0x2940) = 0;
    *(undefined8 *)(arg1 + 0x2948) = 0;
    *(undefined8 *)(arg1 + 0x2950) = 0;
    *(undefined8 *)(arg1 + 0x2958) = 0;
    *(undefined8 *)(arg1 + 0x2960) = 0;
    *(undefined8 *)(arg1 + 0x2968) = 0;
    *(undefined8 *)(arg1 + 0x2970) = 0;
    *(undefined8 *)(arg1 + 0x2978) = 0;
    *(undefined8 *)(arg1 + 0x2a10) = 0;
    *(undefined8 *)(arg1 + 0x2a18) = 0;
    *(undefined8 *)(arg1 + 0x2a50) = 0;
    *(undefined (*) [16])(arg1 + 0x2a60) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x2a6e) = 0;
    *(undefined8 *)(arg1 + 0x2a88) = 0;
    *(undefined8 *)(arg1 + 0x2a90) = 0;
    *(undefined8 *)(arg1 + 0x2a98) = 0;
    *(undefined8 *)(arg1 + 0x2aa0) = 0;
    *(undefined4 *)(arg1 + 0x2aa8) = 0;
    *(undefined8 *)(arg1 + 0x2acc) = 0;
    *(undefined8 *)(arg1 + 0x2ad4) = 0;
    *(undefined4 *)(arg1 + 0x2adc) = 0;
    *(undefined4 *)(arg1 + 0x2ae0) = 0x10100;
    *(undefined2 *)(arg1 + 0x2ae4) = 0;
    *(undefined8 *)(arg1 + 0x2ae8) = 0xffffffffffffffff;
    *(undefined4 *)(arg1 + 0x2af0) = 0xffffffff;
    *(undefined4 *)(arg1 + 0x2af4) = 0;
    *(undefined *)(arg1 + 11000) = 1;
    *(undefined (*) [16])(arg1 + 0x2b00) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2b10) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2b20) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x2b30) = 0;
    *(undefined8 *)(arg1 + 0x2b38) = 0;
    *(undefined4 *)(arg1 + 0x2b3c) = 0xffffffff;
    *(undefined *)(arg1 + 0x2b38) = 1;
    *(undefined4 *)(arg1 + 0x2b40) = 0xff7fffff;
    *(undefined (*) [16])(arg1 + 0x2b44) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2b54) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2b64) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2b70) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x2c90) = 0;
    *(undefined8 *)(arg1 + 0x2c98) = 0;
    *(int64_t *)(arg1 + 0x110) = arg1;
    *(int64_t *)*(undefined (*) [16])(arg1 + 0x2660) = arg1;
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 0xc) = 0xffffffffffffffff;
    *(undefined4 *)(arg1 + 8) = 0xffffffff;
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined (*) [16])(arg1 + 0x20) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x12cc) = 0;
    *(undefined8 *)(arg1 + 0x12e8) = 0;
    *(undefined8 *)(arg1 + 0x12f0) = 0;
    *(undefined8 *)(arg1 + 0x1304) = 0x3f800000;
    *(undefined8 *)(arg1 + 0x12fc) = 0;
    *(undefined4 *)(arg1 + 0x12f8) = 0;
    uVar2 = func_0x00018046d050(0x2f8);
    if (uVar2 != 0) {
        puVar3 = (undefined8 *)(uVar2 + 0x88);
        iVar4 = 0x21;
        do {
            *puVar3 = 0;
            puVar3[1] = 0;
            puVar3 = puVar3 + 2;
            iVar4 = iVar4 + -1;
        } while (iVar4 != 0);
        func_0x0001804986e0(uVar2, 0, 0x2f8);
        *(undefined4 *)(uVar2 + 8) = 1;
        *(undefined4 *)(uVar2 + 0xc) = 0x200;
        *(undefined4 *)(uVar2 + 0x10) = 0x80;
        *(undefined4 *)(uVar2 + 0x14) = 0x2000;
        *(undefined4 *)(uVar2 + 0x18) = 0x2000;
        *(undefined4 *)(uVar2 + 0x298) = 1;
        *(undefined4 *)(uVar2 + 0x29c) = 1;
        uVar5 = uVar2;
    }
    *(uint64_t *)(arg1 + 0x68) = uVar5;
    *(int64_t *)(uVar5 + 0x2d8) = arg1;
    *(undefined8 *)(arg1 + 0x1548) = 0;
    *(undefined8 *)(arg1 + 0x1550) = 0;
    *(undefined4 *)(arg1 + 0x1578) = 0;
    *(undefined4 *)(arg1 + 0x157c) = 1;
    *(undefined8 *)(arg1 + 0x15d0) = 0;
    *(undefined8 *)(arg1 + 0x15e0) = 0;
    *(undefined8 *)(arg1 + 0x15e8) = 0;
    *(undefined8 *)(arg1 + 0x15f0) = 0;
    *(undefined8 *)(arg1 + 0x15f8) = 0;
    *(undefined8 *)(arg1 + 0x1600) = 0;
    *(undefined8 *)(arg1 + 0x1608) = 0;
    *(undefined8 *)(arg1 + 0x1618) = 0xffffffffffffffff;
    *(undefined4 *)(arg1 + 0x1620) = 0;
    *(undefined8 *)(arg1 + 0x1634) = 0;
    *(undefined8 *)(arg1 + 0x163c) = 0;
    *(undefined8 *)(arg1 + 0x1644) = 0;
    *(undefined2 *)(arg1 + 0x1650) = 0;
    *(undefined4 *)(arg1 + 0x164c) = 0;
    *(undefined *)(arg1 + 0x1652) = 0;
    *(undefined8 *)(arg1 + 0x1654) = 0;
    *(undefined8 *)(arg1 + 0x165c) = 0;
    *(undefined4 *)(arg1 + 0x1664) = 0xff000000;
    *(undefined4 *)(arg1 + 0x166c) = 0xbf800000;
    *(undefined4 *)(arg1 + 0x1670) = 0xbf800000;
    *(undefined4 *)(arg1 + 0x1674) = 0;
    *(undefined8 *)(arg1 + 0x1678) = 0;
    *(undefined4 *)(arg1 + 0x1668) = 0;
    *(undefined4 *)(arg1 + 0x1680) = 0;
    *(undefined8 *)(arg1 + 0x1684) = 0;
    *(undefined4 *)(arg1 + 0x168c) = 0;
    *(undefined8 *)(arg1 + 0x1690) = 0;
    *(undefined8 *)(arg1 + 0x1698) = 0;
    *(undefined8 *)(arg1 + 0x16a8) = 0xbff0000000000000;
    *(undefined8 *)(arg1 + 0x16a0) = 0xbff0000000000000;
    *(undefined8 *)(arg1 + 0x16b0) = 0xbff0000000000000;
    *(undefined4 *)(arg1 + 0x1f68) = 0;
    *(undefined *)(arg1 + 0x1f6c) = 0;
    *(undefined8 *)(arg1 + 0x1f74) = 0;
    *(undefined2 *)(arg1 + 0x20b8) = 0;
    *(undefined8 *)(arg1 + 0x2160) = 0;
    *(undefined8 *)(arg1 + 0x2170) = 0;
    *(undefined8 *)(arg1 + 0x2168) = 0;
    *(undefined4 *)(arg1 + 0x2178) = 0;
    *(undefined8 *)(arg1 + 0x21c0) = 0;
    *(undefined4 *)(arg1 + 0x21c8) = 0;
    *(undefined8 *)(arg1 + 0x21cc) = 0;
    *(undefined8 *)(arg1 + 0x21d8) = 0;
    *(undefined8 *)(arg1 + 0x21f0) = 0;
    *(undefined8 *)(arg1 + 0x21e8) = 0;
    *(undefined8 *)(arg1 + 0x21e0) = 0;
    *(undefined8 *)(arg1 + 0x2218) = 0;
    *(undefined8 *)(arg1 + 0x2220) = 0;
    *(undefined4 *)(arg1 + 0x21f8) = 0;
    *(undefined8 *)(arg1 + 0x2210) = 0;
    *(undefined4 *)(arg1 + 0x2228) = 2;
    *(undefined8 *)(arg1 + 0x2230) = 0xffffffffffffffff;
    *(undefined4 *)(arg1 + 0x2238) = 0;
    *(undefined2 *)(arg1 + 0x2278) = 0;
    *(undefined *)(arg1 + 0x227a) = 0;
    *(undefined8 *)(arg1 + 0x227c) = 0;
    *(undefined4 *)(arg1 + 0x2284) = 0;
    *(undefined8 *)(arg1 + 0x228c) = 0xffffffffffffffff;
    *(undefined4 *)(arg1 + 0x2288) = 0xffffffff;
    *(undefined8 *)(arg1 + 0x22b4) = 0;
    *(undefined4 *)(arg1 + 0x22bc) = 0;
    *(undefined8 *)(arg1 + 0x23a4) = 0;
    *(undefined4 *)(arg1 + 0x23a0) = 0;
    *(undefined4 *)(arg1 + 0x23ac) = 0;
    *(undefined4 *)(arg1 + 0x23b0) = 0x1010000;
    bVar7 = *(char *)(arg1 + 0x8d) != '\0';
    uVar8 = 0x1200;
    if (bVar7) {
        uVar8 = 0x8200;
    }
    *(undefined4 *)(arg1 + 0x23b4) = uVar8;
    uVar8 = 0x3200;
    if (bVar7) {
        uVar8 = 0xa200;
    }
    *(undefined4 *)(arg1 + 0x23b8) = uVar8;
    *(undefined8 *)(arg1 + 0x23d0) = 0;
    *(undefined8 *)(arg1 + 0x23c8) = 0;
    *(undefined8 *)(arg1 + 0x23c0) = 0;
    *(undefined8 *)(arg1 + 0x23dc) = 0;
    *(undefined4 *)(arg1 + 0x23d8) = 0;
    *(undefined *)(arg1 + 0x23e4) = 0;
    *(undefined4 *)(arg1 + 0x23e8) = 0;
    *(undefined4 *)(arg1 + 0x23fc) = 0;
    *(undefined2 *)(arg1 + 0x2401) = 0;
    *(undefined *)(arg1 + 0x2400) = 0;
    *(undefined4 *)(arg1 + 0x2404) = 0;
    *(undefined8 *)(arg1 + 0x2408) = 0xffffffffffffffff;
    *(undefined8 *)(arg1 + 0x2470) = 0;
    *(undefined8 *)(arg1 + 0x2478) = 0;
    *(undefined8 *)(arg1 + 0x2480) = 0;
    *(undefined4 *)(arg1 + 0x2488) = 0;
    *(undefined4 *)(arg1 + 0x248c) = 0xffffffff;
    *(undefined4 *)(arg1 + 0x2490) = 0;
    *(undefined (*) [16])(arg1 + 0x24a8) = ZEXT816(0);
    *(undefined4 *)(arg1 + 0x24b8) = 0;
    *(undefined8 *)(arg1 + 0x24d0) = 0;
    *(undefined4 *)(arg1 + 0x24dc) = 0;
    *(undefined8 *)(arg1 + 0x2538) = 0;
    *(undefined8 *)(arg1 + 0x25f0) = 0;
    *(undefined4 *)(arg1 + 0x25f8) = 0;
    *(undefined8 *)(arg1 + 0x2648) = 0;
    *(undefined8 *)(arg1 + 0x2638) = 0;
    *(undefined8 *)(arg1 + 0x2640) = 0;
    *(undefined8 *)(arg1 + 0x2650) = 0;
    *(undefined8 *)(arg1 + 0x2778) = 0;
    *(undefined4 *)(arg1 + 0x2780) = 0;
    *(undefined8 *)(arg1 + 0x2784) = 0;
    *(undefined8 *)(arg1 + 0x278c) = 0;
    *(undefined8 *)(arg1 + 0x2794) = 0xa900000;
    *(undefined8 *)(arg1 + 0x279c) = 0;
    *(undefined8 *)(arg1 + 0x27a4) = 0;
    *(undefined *)(arg1 + 0x27fc) = 0;
    *(undefined2 *)(arg1 + 0x27fe) = 0;
    *(undefined8 *)(arg1 + 0x2800) = 0;
    *(undefined4 *)(arg1 + 0x2808) = 0;
    *(undefined2 *)(arg1 + 0x280c) = 0;
    *(undefined4 *)(arg1 + 0x2810) = 0;
    *(undefined8 *)(arg1 + 0x2814) = 0x3c23d70a;
    *(undefined4 *)(arg1 + 0x281c) = 0;
    *(undefined8 *)(arg1 + 0x2820) = 0;
    *(undefined8 *)(arg1 + 0x28b4) = 0;
    *(undefined4 *)(arg1 + 0x28c8) = 0xbf800000;
    *(undefined4 *)(arg1 + 0x28cc) = 0xbf800000;
    *(undefined8 *)(arg1 + 0x2920) = 0;
    *(undefined *)(arg1 + 0x2928) = 0;
    *(undefined4 *)(arg1 + 0x292c) = 0;
    *(undefined4 *)(arg1 + 0x2980) = 0;
    *(undefined8 *)(arg1 + 0x2988) = 0;
    *(undefined (*) [16])(arg1 + 0x2990) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x29a0) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x29b0) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x29c0) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x29d0) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x29e0) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x29f0) = 0;
    *(undefined2 *)(arg1 + 0x29f8) = 0;
    *(undefined4 *)(arg1 + 0x29fc) = 0;
    *(undefined8 *)(arg1 + 0x2a00) = 0;
    *(undefined8 *)(arg1 + 0x2a28) = 0;
    *(undefined8 *)(arg1 + 0x2a20) = 0;
    *(undefined8 *)(arg1 + 0x2a08) = 0;
    *(undefined8 *)(arg1 + 0x2a30) = 0x7f7fffff;
    *(undefined4 *)(arg1 + 0x2a3c) = 2;
    *(undefined4 *)(arg1 + 0x2a38) = 2;
    *(undefined8 *)(arg1 + 0x2a40) = 0;
    *(undefined8 *)(arg1 + 0x2a48) = 0;
    *(undefined *)(arg1 + 0x2a58) = 1;
    *(undefined4 *)(arg1 + 0x2a5c) = 0;
    *(undefined8 *)(arg1 + 0x2a78) = 0;
    *(undefined4 *)(arg1 + 0x2a80) = 0;
    *(undefined4 *)(arg1 + 0x2a84) = 0x100001;
    *(undefined4 *)(arg1 + 0x1f7c) = 0;
    *(undefined8 *)(arg1 + 0x2ab0) = 0;
    *(undefined2 *)(arg1 + 0x2ab8) = 0;
    *(undefined2 *)(arg1 + 0x2ac0) = 0xff;
    *(undefined *)(arg1 + 0x2ac2) = 0;
    *(undefined8 *)(arg1 + 0x2ac4) = 0;
    *(undefined4 *)(arg1 + 0x20bc) = 0x3e;
    *(undefined8 *)(arg1 + 0x2b80) = 0;
    *(undefined4 *)(arg1 + 0x15d8) = 0;
    *(undefined4 *)(arg1 + 0x24d8) = 0;
    *(undefined *)(arg1 + 0x2aba) = 0;
    *(undefined4 *)(arg1 + 0x2abc) = 0x263;
    *(undefined4 *)(arg1 + 0x1f70) = 0;
    func_0x0001804986e0(arg1 + 0x2b88, 0, 0xf0);
    *(undefined8 *)(arg1 + 0x2c78) = 0;
    *(undefined4 *)(arg1 + 0x2c80) = 0;
    *(undefined8 *)(arg1 + 0x2c88) = 0xffffffffffffffff;
    *(undefined4 *)(arg1 + 0x2c84) = 0xffffffff;
    *(undefined (*) [16])(arg1 + 0x2ca0) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2cb0) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2cc0) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x2cd0) = ZEXT816(0);
    return arg1;
}

// ============================================================
// Function: FUN_1800f9610
// Address: 0x1800f9610
// Size: 27 bytes
// ============================================================
void fcn.1800f9610(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 0xbf0) != 0) {
        fcn.180460d90();
    }
    return;
}

// ============================================================
// Function: FUN_1800f9630
// Address: 0x1800f9630
// Size: 69 bytes
// ============================================================
void fcn.1800f9630(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 0x140) != 0) {
        fcn.180460d90();
    }
    if (*(int64_t *)(arg1 + 0x130) != 0) {
        fcn.180460d90();
    }
    if (*(int64_t *)(arg1 + 0x120) != 0) {
        fcn.180460d90();
    }
    return;
}

// ============================================================
// Function: FUN_1800f9680
// Address: 0x1800f9680
// Size: 51 bytes
// ============================================================
void fcn.1800f9680(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 0x150) != 0) {
        fcn.180460d90();
    }
    if (*(int64_t *)(arg1 + 0x140) != 0) {
        fcn.180460d90();
    }
    return;
}

// ============================================================
// Function: FUN_1800f96c0
// Address: 0x1800f96c0
// Size: 24 bytes
// ============================================================
void fcn.1800f96c0(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        fcn.180460d90();
    }
    return;
}

// ============================================================
// Function: FUN_1800f96e0
// Address: 0x1800f96e0
// Size: 60 bytes
// ============================================================
void fcn.1800f96e0(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 0x38) != 0) {
        fcn.180460d90();
    }
    if (*(int64_t *)(arg1 + 0x28) != 0) {
        fcn.180460d90();
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        fcn.180460d90();
    }
    return;
}

// ============================================================
// Function: FUN_1800f9720
// Address: 0x1800f9720
// Size: 60 bytes
// ============================================================
void fcn.1800f9720(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 0x28) != 0) {
        fcn.180460d90();
    }
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        fcn.180460d90();
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        fcn.180460d90();
    }
    return;
}

// ============================================================
// Function: FUN_1800f9760
// Address: 0x1800f9760
// Size: 60 bytes
// ============================================================
void fcn.1800f9760(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 0x30) != 0) {
        fcn.180460d90();
    }
    if (*(int64_t *)(arg1 + 0x20) != 0) {
        fcn.180460d90();
    }
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        fcn.180460d90();
    }
    return;
}

// ============================================================
// Function: FUN_1800f97a0
// Address: 0x1800f97a0
// Size: 1571 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h

void fcn.1800f97a0(void)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t *piVar3;
    uint8_t uVar4;
    undefined *puVar5;
    undefined *puVar6;
    int32_t iVar7;
    int32_t iVar8;
    undefined4 *puVar9;
    undefined8 uVar10;
    int64_t iVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    uint64_t uVar14;
    int32_t iVar15;
    uint8_t *puVar16;
    uint64_t uVar17;
    int32_t iVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_98h;
    uint32_t var_90h;
    int64_t var_8ch;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar5 = *(undefined **)0x180781f28;
    puVar9 = (undefined4 *)0x0;
    var_8ch._0_4_ = 0;
    var_80h = 0;
    var_58h = 0;
    var_98h = 0x18064446c;
    uVar14 = 0xffffffff;
    puVar16 = (uint8_t *)0x18064446d;
    uVar17 = 0x57;
    do {
        if ((((char)uVar17 == '#') && (*puVar16 == 0x23)) && (puVar16[1] == 0x23)) {
            uVar14 = 0xffffffff;
            puVar16 = puVar16 + 2;
        } else {
            uVar14 = (uint64_t)((uint32_t)(uVar14 >> 8) ^ *(uint32_t *)((uVar14 & 0xff ^ uVar17) * 4 + 0x180618620));
        }
        uVar4 = *puVar16;
        uVar17 = (uint64_t)uVar4;
        puVar16 = puVar16 + 1;
    } while (uVar4 != 0);
    var_90h = ~(uint32_t)uVar14;
    stack0xffffffffffffff78 = 0x180112d50;
    var_78h = 0x180112dc0;
    var_70h = 0x180112ec0;
    var_68h = 0x1801130c0;
    var_60h = 0x180113160;
    func_0x00018011ed90(*(undefined **)0x180781f28 + 0x2940, &var_98h);
    var_8ch._0_4_ = 0;
    var_80h = 0;
    var_58h = 0;
    var_98h = 0x180645a4c;
    uVar14 = 0xffffffff;
    puVar16 = (uint8_t *)0x180645a4d;
    uVar17 = 0x54;
    do {
        if ((((char)uVar17 == '#') && (*puVar16 == 0x23)) && (puVar16[1] == 0x23)) {
            uVar14 = 0xffffffff;
            puVar16 = puVar16 + 2;
        } else {
            uVar14 = (uint64_t)((uint32_t)(uVar14 >> 8) ^ *(uint32_t *)((uVar14 & 0xff ^ uVar17) * 4 + 0x180618620));
        }
        uVar4 = *puVar16;
        uVar17 = (uint64_t)uVar4;
        puVar16 = puVar16 + 1;
    } while (uVar4 != 0);
    var_90h = ~(uint32_t)uVar14;
    stack0xffffffffffffff78 = 0x1801380b0;
    var_78h = 0x180138190;
    var_70h = 0x180138270;
    var_68h = 0x180138130;
    var_60h = 0x180138500;
    func_0x00018011ed90(*(undefined **)0x180781f28 + 0x2940, &var_98h);
    puVar6 = *(undefined **)0x180781f28;
    *(undefined8 *)(*(undefined **)0x180781f28 + 0x2990) = 0x1805aadb1;
    *(undefined8 *)(puVar6 + 0x2998) = 0x1806442e0;
    *(undefined8 *)(puVar6 + 0x29a0) = 0x180644300;
    *(undefined8 *)(puVar6 + 0x29a8) = 0x180644328;
    *(undefined8 *)(puVar6 + 0x29b0) = 0x180644350;
    *(undefined8 *)(puVar6 + 0x29b8) = 0x180644400;
    *(undefined8 *)(puVar6 + 0x29c0) = 0x180644410;
    *(undefined8 *)(puVar6 + 0x29c8) = 0x180644418;
    *(undefined8 *)(puVar6 + 0x29d0) = 0x180644428;
    *(undefined8 *)(puVar6 + 0x29d8) = 0x180644370;
    *(undefined8 *)(puVar6 + 0x29e0) = 0x180644388;
    *(undefined8 *)(puVar6 + 0x29e8) = 0x1806443a8;
    *(undefined8 *)(puVar6 + 0x29f0) = 0x1806443d0;
    *(undefined8 *)(puVar5 + 0xc48) = 0x18011e8a0;
    *(undefined8 *)(puVar5 + 0xc50) = 0x18011e9d0;
    *(undefined8 *)(puVar5 + 0xc60) = 0x18011eaa0;
    *(undefined8 *)(puVar5 + 0xc70) = 0x18011eb70;
    var_10h = func_0x00018046d050(0x168);
    var_18h = (int64_t)&var_8h;
    var_20h = var_10h;
    if (var_10h != 0) {
        puVar9 = (undefined4 *)func_0x0001800f42c0(var_10h);
    }
    *puVar9 = 0x11111111;
    puVar9[0x20] = 0;
    *(undefined *)(puVar9 + 0x1c) = 1;
    puVar9[1] = 4;
    iVar8 = *(int32_t *)(puVar5 + 0x2154);
    iVar18 = 8;
    if (*(int32_t *)(puVar5 + 0x2150) == iVar8) {
        iVar15 = *(int32_t *)(puVar5 + 0x2150) + 1;
        if (iVar8 == 0) {
            iVar7 = 8;
        } else {
            iVar7 = iVar8 / 2 + iVar8;
        }
        if (iVar15 < iVar7) {
            iVar15 = iVar7;
        }
        if (iVar8 < iVar15) {
            uVar10 = func_0x00018046d050((int64_t)iVar15 << 3);
            if (*(int64_t *)(puVar5 + 0x2158) != 0) {
                func_0x000180498030(uVar10, *(int64_t *)(puVar5 + 0x2158), (int64_t)*(int32_t *)(puVar5 + 0x2150) << 3);
                fcn.180460d90(*(undefined8 *)(puVar5 + 0x2158));
            }
            *(undefined8 *)(puVar5 + 0x2158) = uVar10;
            *(int32_t *)(puVar5 + 0x2154) = iVar15;
        }
    }
    *(undefined4 **)(*(int64_t *)(puVar5 + 0x2158) + (int64_t)*(int32_t *)(puVar5 + 0x2150) * 8) = puVar9;
    *(int32_t *)(puVar5 + 0x2150) = *(int32_t *)(puVar5 + 0x2150) + 1;
    iVar8 = *(int32_t *)(puVar5 + 0x2c94);
    if (iVar8 < 0xc01) {
        iVar15 = 0xc01;
        if (iVar8 != 0) {
            iVar7 = iVar8 / 2 + iVar8;
            iVar15 = 0xc01;
            if (0xc01 < iVar7) {
                iVar15 = iVar7;
            }
            if (iVar15 <= iVar8) goto code_r0x0001800f9b6e;
        }
        uVar10 = func_0x00018046d050((int64_t)iVar15);
        if (*(int64_t *)(puVar5 + 0x2c98) != 0) {
            func_0x000180498030(uVar10, *(int64_t *)(puVar5 + 0x2c98), (int64_t)*(int32_t *)(puVar5 + 0x2c90));
            fcn.180460d90(*(undefined8 *)(puVar5 + 0x2c98));
        }
        *(undefined8 *)(puVar5 + 0x2c98) = uVar10;
        *(int32_t *)(puVar5 + 0x2c94) = iVar15;
    }
code_r0x0001800f9b6e:
    iVar8 = *(int32_t *)(puVar5 + 0x2c90);
    uVar14 = (uint64_t)iVar8;
    if (iVar8 < 0xc01) {
        if (0xf < 0xc01U - iVar8) {
            piVar1 = (int64_t *)(puVar5 + 0x2c98);
            piVar3 = (int64_t *)(*piVar1 + uVar14);
            if ((piVar1 < piVar3) || ((int64_t *)(*piVar1 + 0xc00) < piVar1)) {
                uVar12 = 0xc01U - iVar8 & 0x8000000f;
                if ((int32_t)uVar12 < 0) {
                    uVar12 = (uVar12 - 1 | 0xfffffff0) + 1;
                }
                do {
                    uVar13 = (int32_t)uVar14 + 0x10;
                    uVar14 = (uint64_t)uVar13;
                } while ((int32_t)uVar13 < (int32_t)(0xc01 - uVar12));
                iVar8 = ((0xc01 - uVar12) - iVar8) + 0xf;
                func_0x0001804986e0(piVar3, 0, (int64_t)((int32_t)(iVar8 + (iVar8 >> 0x1f & 0xfU)) >> 4) << 4);
                uVar14 = (uint64_t)uVar13;
                if (0xc00 < (int32_t)uVar13) goto code_r0x0001800f9c18;
            }
        }
        do {
            *(undefined *)((int64_t)(int32_t)uVar14 + *(int64_t *)(puVar5 + 0x2c98)) = 0;
            uVar12 = (int32_t)uVar14 + 1;
            uVar14 = (uint64_t)uVar12;
        } while ((int32_t)uVar12 < 0xc01);
    }
code_r0x0001800f9c18:
    *(undefined4 *)(puVar5 + 0x2c90) = 0xc01;
    *(int32_t *)(puVar5 + 0x21c0) = *(int32_t *)(puVar5 + 0x21c0) + 1;
    piVar2 = (int32_t *)(puVar5 + 0xd80);
    uVar10 = **(undefined8 **)(puVar5 + 0x2158);
    iVar8 = *(int32_t *)(puVar5 + 0xd84);
    if (*piVar2 == iVar8) {
        iVar15 = *piVar2 + 1;
        if (iVar8 != 0) {
            iVar18 = iVar8 + iVar8 / 2;
        }
        if (iVar15 < iVar18) {
            iVar15 = iVar18;
        }
        func_0x00018011f4f0(piVar2, iVar15);
    }
    *(undefined8 *)(*(int64_t *)(puVar5 + 0xd88) + (int64_t)*piVar2 * 8) = uVar10;
    *piVar2 = *piVar2 + 1;
    uVar12 = 0x200;
    do {
        if (((uVar12 - 0x200 < 0x3c) && ((0xfffffffff001001U >> ((uint64_t)(uVar12 - 0x200) & 0x3f) & 1) != 0)) ||
           ((uVar12 - 0x254 < 0x21 && ((0x17fff06ffU >> ((uint64_t)(uVar12 - 0x254) & 0x3f) & 1) != 0)))) {
            iVar11 = (int64_t)((uint64_t)uVar12 - 0x200) >> 5;
            *(uint32_t *)(puVar5 + iVar11 * 4 + 0x16b8) =
                 *(uint32_t *)(puVar5 + iVar11 * 4 + 0x16b8) | 1 << (uVar12 & 0x1f);
        }
        uVar12 = uVar12 + 1;
    } while ((int32_t)uVar12 < 0x29b);
    var_8ch._0_4_ = 0;
    var_58h = 0;
    var_98h = 0x180645110;
    uVar14 = 0xffffffff;
    puVar16 = (uint8_t *)0x180645111;
    uVar17 = 0x44;
    do {
        if ((((char)uVar17 == '#') && (*puVar16 == 0x23)) && (puVar16[1] == 0x23)) {
            uVar14 = 0xffffffff;
            puVar16 = puVar16 + 2;
        } else {
            uVar14 = (uint64_t)((uint32_t)(uVar14 >> 8) ^ *(uint32_t *)((uVar14 & 0xff ^ uVar17) * 4 + 0x180618620));
        }
        uVar4 = *puVar16;
        uVar17 = (uint64_t)uVar4;
        puVar16 = puVar16 + 1;
    } while (uVar4 != 0);
    var_90h = ~(uint32_t)uVar14;
    stack0xffffffffffffff78 = 0x18011d620;
    var_80h = 0x18011d620;
    var_78h = 0x18011dec0;
    var_70h = 0x18011df00;
    var_68h = 0x18011d6f0;
    var_60h = 0x18011e480;
    func_0x00018011ed90(puVar5 + 0x2940, &var_98h);
    *(undefined8 *)(puVar5 + 0x2920) = 0x180117b20;
    *(undefined **)(puVar5 + 0x1378) = puVar5;
    func_0x000180107140(*(undefined8 *)(puVar5 + 0x68));
    *puVar5 = 1;
    return;
}

// ============================================================
// Function: FUN_1800f9dd0
// Address: 0x1800f9dd0
// Size: 69 bytes
// ============================================================
void fcn.1800f9dd0(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 0x108) != 0) {
        fcn.180460d90();
    }
    if (*(int64_t *)(arg1 + 0xf8) != 0) {
        fcn.180460d90();
    }
    if (*(int64_t *)(arg1 + 0xa0) != 0) {
        fcn.180460d90();
    }
    return;
}

// ============================================================
// Function: FUN_1800f9e20
// Address: 0x1800f9e20
// Size: 133 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800f9e20(int64_t arg1, int64_t arg2)
{
    undefined uVar1;
    int64_t iVar2;
    int64_t iVar3;
    float fVar4;
    int64_t var_8h;
    
    iVar2 = *(int64_t *)0x180781f28;
    *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) = arg1;
    if (arg1 == 0) {
        *(undefined8 *)(iVar2 + 0x2a78) = 0;
    } else {
        arg2 = (int64_t)(*(int32_t *)(iVar2 + 0x15b0) + -1) * 0x78;
        *(int64_t *)(iVar2 + 0x2a78) = *(int64_t *)(iVar2 + 0x15b8) + 0x58 + arg2;
        if (*(int32_t *)(arg1 + 0x210) != -1) {
            *(int64_t *)(iVar2 + 0x24d0) = (int64_t)*(int32_t *)(arg1 + 0x210) * 0x250 + *(int64_t *)(iVar2 + 0x24f8);
            goto code_r0x0001800f9e9d;
        }
    }
    *(undefined8 *)(iVar2 + 0x24d0) = 0;
    if (arg1 == 0) {
        return;
    }
code_r0x0001800f9e9d:
    if ((*(uint8_t *)(iVar2 + 0x34) & 0x10) != 0) {
        fVar4 = *(float *)(*(int64_t *)(arg1 + 0x48) + 0x18);
        if (fVar4 == 0.0) {
            fVar4 = *(float *)(iVar2 + 0x40);
        }
        *(float *)(iVar2 + 0x1304) = fVar4;
    }
    uVar1 = *(undefined *)(arg1 + 0x10e);
    *(undefined *)(arg1 + 0x10e) = 0;
    func_0x0001801073c0(0, arg2);
    iVar3 = *(int64_t *)0x180781f28;
    *(undefined *)(arg1 + 0x10e) = uVar1;
    iVar2 = *(int64_t *)(iVar3 + 0x15e0);
    if ((*(int64_t *)(iVar3 + 0x24d0) == 0) && (*(int64_t *)(iVar2 + 0x208) == 0)) {
        *(undefined *)(iVar2 + 0x1b8) = 1;
        return;
    }
    *(undefined *)(iVar2 + 0x1b8) = 0;
    return;
}

// ============================================================
// Function: FUN_1800f9ea5
// Address: 0x1800f9ea5
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800f9e20(int64_t arg1, int64_t arg2)
{
    undefined uVar1;
    int64_t iVar2;
    int64_t iVar3;
    float fVar4;
    int64_t var_8h;
    
    iVar2 = *(int64_t *)0x180781f28;
    *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) = arg1;
    if (arg1 == 0) {
        *(undefined8 *)(iVar2 + 0x2a78) = 0;
    } else {
        arg2 = (int64_t)(*(int32_t *)(iVar2 + 0x15b0) + -1) * 0x78;
        *(int64_t *)(iVar2 + 0x2a78) = *(int64_t *)(iVar2 + 0x15b8) + 0x58 + arg2;
        if (*(int32_t *)(arg1 + 0x210) != -1) {
            *(int64_t *)(iVar2 + 0x24d0) = (int64_t)*(int32_t *)(arg1 + 0x210) * 0x250 + *(int64_t *)(iVar2 + 0x24f8);
            goto code_r0x0001800f9e9d;
        }
    }
    *(undefined8 *)(iVar2 + 0x24d0) = 0;
    if (arg1 == 0) {
        return;
    }
code_r0x0001800f9e9d:
    if ((*(uint8_t *)(iVar2 + 0x34) & 0x10) != 0) {
        fVar4 = *(float *)(*(int64_t *)(arg1 + 0x48) + 0x18);
        if (fVar4 == 0.0) {
            fVar4 = *(float *)(iVar2 + 0x40);
        }
        *(float *)(iVar2 + 0x1304) = fVar4;
    }
    uVar1 = *(undefined *)(arg1 + 0x10e);
    *(undefined *)(arg1 + 0x10e) = 0;
    func_0x0001801073c0(0, arg2);
    iVar3 = *(int64_t *)0x180781f28;
    *(undefined *)(arg1 + 0x10e) = uVar1;
    iVar2 = *(int64_t *)(iVar3 + 0x15e0);
    if ((*(int64_t *)(iVar3 + 0x24d0) == 0) && (*(int64_t *)(iVar2 + 0x208) == 0)) {
        *(undefined *)(iVar2 + 0x1b8) = 1;
        return;
    }
    *(undefined *)(iVar2 + 0x1b8) = 0;
    return;
}

// ============================================================
// Function: FUN_1800f9f04
// Address: 0x1800f9f04
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800f9e20(int64_t arg1, int64_t arg2)
{
    undefined uVar1;
    int64_t iVar2;
    int64_t iVar3;
    float fVar4;
    int64_t var_8h;
    
    iVar2 = *(int64_t *)0x180781f28;
    *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) = arg1;
    if (arg1 == 0) {
        *(undefined8 *)(iVar2 + 0x2a78) = 0;
    } else {
        arg2 = (int64_t)(*(int32_t *)(iVar2 + 0x15b0) + -1) * 0x78;
        *(int64_t *)(iVar2 + 0x2a78) = *(int64_t *)(iVar2 + 0x15b8) + 0x58 + arg2;
        if (*(int32_t *)(arg1 + 0x210) != -1) {
            *(int64_t *)(iVar2 + 0x24d0) = (int64_t)*(int32_t *)(arg1 + 0x210) * 0x250 + *(int64_t *)(iVar2 + 0x24f8);
            goto code_r0x0001800f9e9d;
        }
    }
    *(undefined8 *)(iVar2 + 0x24d0) = 0;
    if (arg1 == 0) {
        return;
    }
code_r0x0001800f9e9d:
    if ((*(uint8_t *)(iVar2 + 0x34) & 0x10) != 0) {
        fVar4 = *(float *)(*(int64_t *)(arg1 + 0x48) + 0x18);
        if (fVar4 == 0.0) {
            fVar4 = *(float *)(iVar2 + 0x40);
        }
        *(float *)(iVar2 + 0x1304) = fVar4;
    }
    uVar1 = *(undefined *)(arg1 + 0x10e);
    *(undefined *)(arg1 + 0x10e) = 0;
    func_0x0001801073c0(0, arg2);
    iVar3 = *(int64_t *)0x180781f28;
    *(undefined *)(arg1 + 0x10e) = uVar1;
    iVar2 = *(int64_t *)(iVar3 + 0x15e0);
    if ((*(int64_t *)(iVar3 + 0x24d0) == 0) && (*(int64_t *)(iVar2 + 0x208) == 0)) {
        *(undefined *)(iVar2 + 0x1b8) = 1;
        return;
    }
    *(undefined *)(iVar2 + 0x1b8) = 0;
    return;
}

// ============================================================
// Function: FUN_1800f9f30
// Address: 0x1800f9f30
// Size: 303 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800f9f30(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar5 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1654);
    if (iVar5 != 0) {
        piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8);
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1684) = iVar5;
        iVar2 = *(int32_t *)(iVar3 + 4);
        if (*piVar1 != iVar5) {
            iVar2 = *(int32_t *)(iVar3 + 4) + 1;
        }
        *(int32_t *)(iVar3 + 0x1688) = iVar2;
        *(undefined *)(iVar3 + 0x168c) = *(undefined *)(iVar3 + 0x1664);
        *(bool *)(iVar3 + 0x168d) = *(int32_t *)(iVar3 + 0x1658) == iVar5;
        if (*(int32_t *)(iVar3 + 0x2674) == iVar5) {
            func_0x000180143150();
        }
        if ((*(int64_t *)(iVar3 + 0x1600) != 0) &&
           (*(int32_t *)(iVar3 + 0x1654) == *(int32_t *)(*(int64_t *)(iVar3 + 0x1600) + 0xc4))) {
            func_0x0001800fac90();
        }
    }
    iVar5 = (int32_t)arg1;
    *(bool *)(iVar3 + 0x1660) = *(int32_t *)(iVar3 + 0x1654) != iVar5;
    if (*(int32_t *)(iVar3 + 0x1654) != iVar5) {
        *(undefined4 *)(iVar3 + 0x165c) = 0;
        *(undefined2 *)(iVar3 + 0x1663) = 0;
        *(undefined *)(iVar3 + 0x1667) = 0xff;
        if (iVar5 != 0) {
            *(int32_t *)(iVar3 + 0x1698) = iVar5;
            *(undefined4 *)(iVar3 + 0x169c) = 0;
        }
    }
    *(int32_t *)(iVar3 + 0x1654) = iVar5;
    *(undefined2 *)(iVar3 + 0x1661) = 0;
    *(int64_t *)(iVar3 + 0x1678) = arg2;
    *(undefined2 *)(iVar3 + 0x1665) = 0;
    *(undefined4 *)(iVar3 + 0x1668) = 0;
    if (iVar5 != 0) {
        *(int32_t *)(iVar3 + 0x1658) = iVar5;
        if ((*(int32_t *)(iVar3 + 0x21ec) == iVar5) || (uVar4 = 1, *(int32_t *)(iVar3 + 0x23a4) == iVar5)) {
            uVar4 = *(undefined4 *)(iVar3 + 0x2228);
        }
        *(undefined4 *)(iVar3 + 0x1674) = uVar4;
    }
    *(undefined *)(iVar3 + 0x1f6c) = 0;
    *(undefined4 *)(iVar3 + 0x1f68) = 0;
    return;
}

// ============================================================
// Function: FUN_1800fa150
// Address: 0x1800fa150
// Size: 741 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Removing arg arg_10bh because it doesn't fit into ProtoModel

uint64_t fcn.1800fa150(int64_t arg1, int64_t arg_c8h, int64_t arg_150h)
{
    code cVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *in_RAX;
    uint32_t uVar6;
    uint32_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint32_t *puVar10;
    float fVar11;
    int64_t var_38h;
    int64_t var_30h [2];
    
    iVar4 = *(int64_t *)0x180781f28;
    uVar7 = (uint32_t)arg1;
    uVar8 = arg1 & 0xffffffff;
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (((arg1 & 0xfffc005fU) != 0) &&
       (in_RAX = *(int64_t **)(*(int64_t *)0x180781f28 + 0x2a40), in_RAX != (int64_t *)0x0)) {
        in_RAX = (int64_t *)
                 (*(code *)in_RAX)(*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644448);
    }
    iVar5 = *(int64_t *)0x180781f28;
    if (((*(char *)(iVar4 + 0x21cd) == '\0') || (*(char *)(iVar4 + 0x21cc) == '\0')) || ((uVar7 >> 0xb & 1) != 0)) {
        if ((*(uint32_t *)(iVar4 + 0x1fc0) & 1) == 0) goto code_r0x0001800fa42a;
        if ((uVar7 >> 0xc & 1) != 0) {
            uVar6 = *(uint32_t *)(iVar4 + 0x12bc) & 0xfffe3fff;
            if ((arg1 & 0x1c000U) == 0) {
                uVar6 = *(uint32_t *)(iVar4 + 0x12bc);
            }
            in_RAX = (int64_t *)(uint64_t)uVar6;
            uVar8 = (uint64_t)(uVar7 | uVar6);
        }
        uVar7 = (uint32_t)uVar8;
        if (((*(int64_t *)(iVar4 + 0x15e8) != iVar3) && (-1 < (char)*(uint32_t *)(iVar4 + 0x1fc0))) &&
           ((uVar7 >> 9 & 1) == 0)) goto code_r0x0001800fa42a;
        puVar10 = (uint32_t *)(iVar4 + 0x1fb8);
        uVar6 = *puVar10;
        if ((((((-1 < (char)uVar8) && (uVar2 = *(uint32_t *)(iVar4 + 0x1654), uVar2 != 0)) &&
              ((uVar2 != uVar6 && ((*(char *)(iVar4 + 0x1661) == '\0' && (*(char *)(iVar4 + 0x1666) == '\0')))))) &&
             ((uVar2 != *(uint32_t *)(iVar3 + 0xc4) || ((uVar6 != 0 && (*(uint32_t *)(iVar4 + 0x1668) != uVar6)))))) &&
            (in_RAX = (int64_t *)0x0, uVar2 != *(uint32_t *)(iVar3 + 200))) ||
           ((in_RAX = (int64_t *)func_0x0001800fa0b0(iVar3, uVar8), (char)in_RAX == '\0' &&
            ((*(uint32_t *)(iVar4 + 0x1fbc) & 0x2000) == 0)))) goto code_r0x0001800fa42a;
        uVar2 = *(uint32_t *)(iVar4 + 0x1fbc);
        in_RAX = (int64_t *)(uint64_t)uVar2;
        if (((((uVar2 & 0x40) != 0) && ((uVar7 >> 10 & 1) == 0)) ||
            ((uVar6 == *(uint32_t *)(iVar3 + 0xc4) && (*(char *)(iVar3 + 0x10b) != '\0')))) ||
           (((uVar2 >> 0xe & 1) != 0 &&
            (((uVar6 != 0 && ((uVar7 >> 8 & 1) == 0)) && (*(uint32_t *)(iVar4 + 0x1640) != uVar6))))))
        goto code_r0x0001800fa42a;
    } else {
        uVar6 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x21d0);
        in_RAX = (int64_t *)(uint64_t)uVar6;
        if ((((uVar6 != *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fb8)) || (uVar6 == 0)) ||
            ((in_RAX = *(int64_t **)(*(int64_t *)0x180781f28 + 0x15e0),
             *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fb8) == *(uint32_t *)(in_RAX + 2) &&
             (*(code *)((int64_t)in_RAX + 0x10b) != (code)0x0)))) ||
           (((*(uint8_t *)(iVar4 + 0x1fbc) & 0x40) != 0 && ((uVar7 >> 10 & 1) == 0)))) goto code_r0x0001800fa42a;
        if ((uVar7 >> 0xc & 1) != 0) {
            uVar6 = *(uint32_t *)(iVar4 + 0x12c0) & 0xfffe3fff;
            if ((arg1 & 0x1c000U) == 0) {
                uVar6 = *(uint32_t *)(iVar4 + 0x12c0);
            }
            in_RAX = (int64_t *)(uint64_t)uVar6;
            uVar7 = uVar7 | uVar6;
        }
        puVar10 = (uint32_t *)(iVar4 + 0x1fb8);
    }
    if ((uVar7 >> 0x10 & 1) == 0) {
        if ((uVar7 >> 0xf & 1) != 0) {
            fVar11 = *(float *)(iVar5 + 0x12b4);
            goto code_r0x0001800fa351;
        }
        fVar11 = 0.0;
code_r0x0001800fa35e:
        if ((uVar7 >> 0xd & 1) == 0) {
            return CONCAT71((unkint7)((uint64_t)in_RAX >> 8), 1);
        }
    } else {
        fVar11 = *(float *)(iVar5 + 0x12b8);
code_r0x0001800fa351:
        if (fVar11 <= 0.0) goto code_r0x0001800fa35e;
    }
    uVar6 = *puVar10;
    if (uVar6 == 0) {
        piVar9 = &var_38h;
        uVar6 = ~*(uint32_t *)(*(int64_t *)(iVar3 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar3 + 0x148) * 4);
        var_38h._0_4_ = *(float *)(iVar4 + 0x1fc4) - *(float *)(iVar3 + 0x168);
        var_38h._4_4_ = *(float *)(iVar4 + 0x1fc8) - *(float *)(iVar3 + 0x16c);
        do {
            cVar1 = *(code *)piVar9;
            piVar9 = (int64_t *)((int64_t)piVar9 + 1);
            in_RAX = var_30h;
            uVar6 = uVar6 >> 8 ^ *(uint32_t *)(((uint64_t)(uVar6 & 0xff) ^ (uint64_t)(uint8_t)cVar1) * 4 + 0x180618620);
        } while (piVar9 < in_RAX);
        uVar6 = ~uVar6;
    }
    if (((uVar7 >> 0x11 & 1) != 0) && (*(uint32_t *)(iVar4 + 0x263c) != uVar6)) {
        *(undefined4 *)(iVar4 + 0x2640) = 0;
    }
    *(uint32_t *)(iVar4 + 0x2638) = uVar6;
    if (((uVar7 >> 0xd & 1) == 0) || (*(uint32_t *)(iVar4 + 0x2648) == uVar6)) {
        return CONCAT71((unkint7)((uint64_t)in_RAX >> 8), 
                        fVar11 < *(float *)(iVar4 + 0x2640) || fVar11 == *(float *)(iVar4 + 0x2640));
    }
code_r0x0001800fa42a:
    return (uint64_t)in_RAX & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800fa440
// Address: 0x1800fa440
// Size: 313 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Removing arg arg_10bh because it doesn't fit into ProtoModel

uint8_t fcn.1800fa440(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    char cVar3;
    uint32_t uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int32_t iVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    int32_t iVar12;
    uint32_t uVar13;
    uint32_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000068;
    int64_t in_stack_000000f0;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar1 = *(int64_t *)0x180781f28;
    if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e8) == *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0)) &&
       (cVar3 = func_0x000180108120(arg1, arg1 + 8, 1), cVar3 != '\0')) {
        iVar9 = (int32_t)arg2;
        if (((*(int32_t *)(iVar1 + 0x163c) == 0) ||
            ((*(int32_t *)(iVar1 + 0x163c) == iVar9 || (*(char *)(iVar1 + 0x1650) != '\0')))) &&
           ((iVar12 = *(int32_t *)(iVar1 + 0x1654), iVar12 == 0 ||
            (((iVar12 == iVar9 || (*(char *)(iVar1 + 0x1661) != '\0')) || (*(char *)(iVar1 + 0x1666) != '\0')))))) {
            if ((((uint32_t)arg3 >> 0xd & 1) != 0) || (cVar3 = func_0x0001800fa0b0(), cVar3 != '\0')) {
                if (iVar9 != 0) {
                    if (((*(char *)(iVar1 + 0x2400) != '\0') && (*(int32_t *)(iVar1 + 0x241c) == iVar9)) &&
                       ((*(uint8_t *)(iVar1 + 0x2404) & 2) == 0)) {
                        return 0;
                    }
                    *(int32_t *)(iVar1 + 0x163c) = iVar9;
                    *(undefined *)(iVar1 + 0x1650) = 0;
                    if (*(int32_t *)(iVar1 + 0x1640) != iVar9) {
                        *(undefined8 *)(iVar1 + 0x1648) = 0;
                    }
                    if ((((uint32_t)arg3 >> 0xe & 1) != 0) &&
                       (*(undefined *)(iVar1 + 0x1650) = 1, *(int32_t *)(iVar1 + 0x1640) != iVar9)) {
                        return 0;
                    }
                    if ((((iVar9 == *(int32_t *)(iVar1 + 0x1fb8)) && ((*(uint32_t *)(iVar1 + 0x1fc0) & 0x400) != 0)) &&
                        (iVar12 != iVar9)) &&
                       (cVar3 = fcn.1800fa150(0x11000, in_stack_00000068, in_stack_000000f0),
                       iVar2 = *(int64_t *)0x180781f28, cVar3 != '\0')) {
                        uVar14 = *(uint32_t *)(iVar1 + 0x2004);
                        uVar13 = uVar14 & 0xffff0fff;
                        if (uVar13 - 0x20f < 8) {
                            if ((uVar13 - 0x20f & 0xfffffffb) == 0) {
                                uVar4 = 0xffffefff;
                            } else if ((uVar13 - 0x210 & 0xfffffffb) == 0) {
                                uVar4 = 0xffffdfff;
                            } else if ((uVar13 - 0x211 & 0xfffffffb) == 0) {
                                uVar4 = 0xffffbfff;
                            } else {
                                uVar4 = 0xffff7fff;
                                if ((uVar13 - 0x212 & 0xfffffffb) != 0) {
                                    uVar4 = 0xffffffff;
                                }
                            }
                            uVar14 = uVar14 & uVar4;
                        }
                        uVar11 = 0x1805aadb1;
                        if (uVar13 == 0) {
                            if (uVar14 == 0) {
                                uVar10 = 0x180644c8c;
                            } else {
                                uVar10 = 0x1805aadb1;
                            }
                        } else if (uVar13 - 0x200 < 0x9b) {
                            uVar10 = *(undefined8 *)((int64_t)(int32_t)uVar13 * 8 + 0x180617a60);
                        } else {
                            uVar10 = 0x1806229f8;
                        }
                        uVar8 = 0x1805aadb1;
                        if ((uVar14 >> 0xf & 1) != 0) {
                            uVar8 = 0x180644c48;
                        }
                        uVar7 = 0x1805aadb1;
                        if ((uVar14 >> 0xe & 1) != 0) {
                            uVar7 = 0x180644c50;
                        }
                        uVar5 = 0x1805aadb1;
                        if ((uVar14 >> 0xd & 1) != 0) {
                            uVar5 = 0x180644c58;
                        }
                        if ((uVar14 >> 0xc & 1) != 0) {
                            uVar11 = 0x180644c60;
                        }
                        func_0x0001800f4620(*(int64_t *)0x180781f28 + 0x2ca0, 0x40, 0x180644cf8, uVar11, uVar5, uVar7, 
                                            uVar8, uVar10);
                        if (((uVar13 == 0) && (uVar14 != 0)) &&
                           (iVar6 = func_0x000180498cd0(iVar2 + 0x2ca0), iVar6 != 0)) {
                            *(undefined *)(iVar6 + 0x2c9f + iVar2) = 0;
                        }
                        func_0x00018010ce60();
                    }
                }
                if ((arg3 & 0x40U) == 0) {
                    if (*(char *)(iVar1 + 0x21cd) != '\0') {
                        return (uint8_t)((uint64_t)arg3 >> 0xf) & 1;
                    }
                    return 1;
                }
                if ((*(int32_t *)(iVar1 + 0x1654) == iVar9) && (iVar9 != 0)) {
                    fcn.1800f9f30(0, 0);
                }
            }
            *(undefined *)(iVar1 + 0x1651) = 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1800fa579
// Address: 0x1800fa579
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Removing arg arg_10bh because it doesn't fit into ProtoModel

uint8_t fcn.1800fa440(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    char cVar3;
    uint32_t uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int32_t iVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    int32_t iVar12;
    uint32_t uVar13;
    uint32_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000068;
    int64_t in_stack_000000f0;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar1 = *(int64_t *)0x180781f28;
    if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e8) == *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0)) &&
       (cVar3 = func_0x000180108120(arg1, arg1 + 8, 1), cVar3 != '\0')) {
        iVar9 = (int32_t)arg2;
        if (((*(int32_t *)(iVar1 + 0x163c) == 0) ||
            ((*(int32_t *)(iVar1 + 0x163c) == iVar9 || (*(char *)(iVar1 + 0x1650) != '\0')))) &&
           ((iVar12 = *(int32_t *)(iVar1 + 0x1654), iVar12 == 0 ||
            (((iVar12 == iVar9 || (*(char *)(iVar1 + 0x1661) != '\0')) || (*(char *)(iVar1 + 0x1666) != '\0')))))) {
            if ((((uint32_t)arg3 >> 0xd & 1) != 0) || (cVar3 = func_0x0001800fa0b0(), cVar3 != '\0')) {
                if (iVar9 != 0) {
                    if (((*(char *)(iVar1 + 0x2400) != '\0') && (*(int32_t *)(iVar1 + 0x241c) == iVar9)) &&
                       ((*(uint8_t *)(iVar1 + 0x2404) & 2) == 0)) {
                        return 0;
                    }
                    *(int32_t *)(iVar1 + 0x163c) = iVar9;
                    *(undefined *)(iVar1 + 0x1650) = 0;
                    if (*(int32_t *)(iVar1 + 0x1640) != iVar9) {
                        *(undefined8 *)(iVar1 + 0x1648) = 0;
                    }
                    if ((((uint32_t)arg3 >> 0xe & 1) != 0) &&
                       (*(undefined *)(iVar1 + 0x1650) = 1, *(int32_t *)(iVar1 + 0x1640) != iVar9)) {
                        return 0;
                    }
                    if ((((iVar9 == *(int32_t *)(iVar1 + 0x1fb8)) && ((*(uint32_t *)(iVar1 + 0x1fc0) & 0x400) != 0)) &&
                        (iVar12 != iVar9)) &&
                       (cVar3 = fcn.1800fa150(0x11000, in_stack_00000068, in_stack_000000f0),
                       iVar2 = *(int64_t *)0x180781f28, cVar3 != '\0')) {
                        uVar14 = *(uint32_t *)(iVar1 + 0x2004);
                        uVar13 = uVar14 & 0xffff0fff;
                        if (uVar13 - 0x20f < 8) {
                            if ((uVar13 - 0x20f & 0xfffffffb) == 0) {
                                uVar4 = 0xffffefff;
                            } else if ((uVar13 - 0x210 & 0xfffffffb) == 0) {
                                uVar4 = 0xffffdfff;
                            } else if ((uVar13 - 0x211 & 0xfffffffb) == 0) {
                                uVar4 = 0xffffbfff;
                            } else {
                                uVar4 = 0xffff7fff;
                                if ((uVar13 - 0x212 & 0xfffffffb) != 0) {
                                    uVar4 = 0xffffffff;
                                }
                            }
                            uVar14 = uVar14 & uVar4;
                        }
                        uVar11 = 0x1805aadb1;
                        if (uVar13 == 0) {
                            if (uVar14 == 0) {
                                uVar10 = 0x180644c8c;
                            } else {
                                uVar10 = 0x1805aadb1;
                            }
                        } else if (uVar13 - 0x200 < 0x9b) {
                            uVar10 = *(undefined8 *)((int64_t)(int32_t)uVar13 * 8 + 0x180617a60);
                        } else {
                            uVar10 = 0x1806229f8;
                        }
                        uVar8 = 0x1805aadb1;
                        if ((uVar14 >> 0xf & 1) != 0) {
                            uVar8 = 0x180644c48;
                        }
                        uVar7 = 0x1805aadb1;
                        if ((uVar14 >> 0xe & 1) != 0) {
                            uVar7 = 0x180644c50;
                        }
                        uVar5 = 0x1805aadb1;
                        if ((uVar14 >> 0xd & 1) != 0) {
                            uVar5 = 0x180644c58;
                        }
                        if ((uVar14 >> 0xc & 1) != 0) {
                            uVar11 = 0x180644c60;
                        }
                        func_0x0001800f4620(*(int64_t *)0x180781f28 + 0x2ca0, 0x40, 0x180644cf8, uVar11, uVar5, uVar7, 
                                            uVar8, uVar10);
                        if (((uVar13 == 0) && (uVar14 != 0)) &&
                           (iVar6 = func_0x000180498cd0(iVar2 + 0x2ca0), iVar6 != 0)) {
                            *(undefined *)(iVar6 + 0x2c9f + iVar2) = 0;
                        }
                        func_0x00018010ce60();
                    }
                }
                if ((arg3 & 0x40U) == 0) {
                    if (*(char *)(iVar1 + 0x21cd) != '\0') {
                        return (uint8_t)((uint64_t)arg3 >> 0xf) & 1;
                    }
                    return 1;
                }
                if ((*(int32_t *)(iVar1 + 0x1654) == iVar9) && (iVar9 != 0)) {
                    fcn.1800f9f30(0, 0);
                }
            }
            *(undefined *)(iVar1 + 0x1651) = 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1800fa58a
// Address: 0x1800fa58a
// Size: 307 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Removing arg arg_10bh because it doesn't fit into ProtoModel

uint8_t fcn.1800fa440(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    char cVar3;
    uint32_t uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int32_t iVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    int32_t iVar12;
    uint32_t uVar13;
    uint32_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000068;
    int64_t in_stack_000000f0;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar1 = *(int64_t *)0x180781f28;
    if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e8) == *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0)) &&
       (cVar3 = func_0x000180108120(arg1, arg1 + 8, 1), cVar3 != '\0')) {
        iVar9 = (int32_t)arg2;
        if (((*(int32_t *)(iVar1 + 0x163c) == 0) ||
            ((*(int32_t *)(iVar1 + 0x163c) == iVar9 || (*(char *)(iVar1 + 0x1650) != '\0')))) &&
           ((iVar12 = *(int32_t *)(iVar1 + 0x1654), iVar12 == 0 ||
            (((iVar12 == iVar9 || (*(char *)(iVar1 + 0x1661) != '\0')) || (*(char *)(iVar1 + 0x1666) != '\0')))))) {
            if ((((uint32_t)arg3 >> 0xd & 1) != 0) || (cVar3 = func_0x0001800fa0b0(), cVar3 != '\0')) {
                if (iVar9 != 0) {
                    if (((*(char *)(iVar1 + 0x2400) != '\0') && (*(int32_t *)(iVar1 + 0x241c) == iVar9)) &&
                       ((*(uint8_t *)(iVar1 + 0x2404) & 2) == 0)) {
                        return 0;
                    }
                    *(int32_t *)(iVar1 + 0x163c) = iVar9;
                    *(undefined *)(iVar1 + 0x1650) = 0;
                    if (*(int32_t *)(iVar1 + 0x1640) != iVar9) {
                        *(undefined8 *)(iVar1 + 0x1648) = 0;
                    }
                    if ((((uint32_t)arg3 >> 0xe & 1) != 0) &&
                       (*(undefined *)(iVar1 + 0x1650) = 1, *(int32_t *)(iVar1 + 0x1640) != iVar9)) {
                        return 0;
                    }
                    if ((((iVar9 == *(int32_t *)(iVar1 + 0x1fb8)) && ((*(uint32_t *)(iVar1 + 0x1fc0) & 0x400) != 0)) &&
                        (iVar12 != iVar9)) &&
                       (cVar3 = fcn.1800fa150(0x11000, in_stack_00000068, in_stack_000000f0),
                       iVar2 = *(int64_t *)0x180781f28, cVar3 != '\0')) {
                        uVar14 = *(uint32_t *)(iVar1 + 0x2004);
                        uVar13 = uVar14 & 0xffff0fff;
                        if (uVar13 - 0x20f < 8) {
                            if ((uVar13 - 0x20f & 0xfffffffb) == 0) {
                                uVar4 = 0xffffefff;
                            } else if ((uVar13 - 0x210 & 0xfffffffb) == 0) {
                                uVar4 = 0xffffdfff;
                            } else if ((uVar13 - 0x211 & 0xfffffffb) == 0) {
                                uVar4 = 0xffffbfff;
                            } else {
                                uVar4 = 0xffff7fff;
                                if ((uVar13 - 0x212 & 0xfffffffb) != 0) {
                                    uVar4 = 0xffffffff;
                                }
                            }
                            uVar14 = uVar14 & uVar4;
                        }
                        uVar11 = 0x1805aadb1;
                        if (uVar13 == 0) {
                            if (uVar14 == 0) {
                                uVar10 = 0x180644c8c;
                            } else {
                                uVar10 = 0x1805aadb1;
                            }
                        } else if (uVar13 - 0x200 < 0x9b) {
                            uVar10 = *(undefined8 *)((int64_t)(int32_t)uVar13 * 8 + 0x180617a60);
                        } else {
                            uVar10 = 0x1806229f8;
                        }
                        uVar8 = 0x1805aadb1;
                        if ((uVar14 >> 0xf & 1) != 0) {
                            uVar8 = 0x180644c48;
                        }
                        uVar7 = 0x1805aadb1;
                        if ((uVar14 >> 0xe & 1) != 0) {
                            uVar7 = 0x180644c50;
                        }
                        uVar5 = 0x1805aadb1;
                        if ((uVar14 >> 0xd & 1) != 0) {
                            uVar5 = 0x180644c58;
                        }
                        if ((uVar14 >> 0xc & 1) != 0) {
                            uVar11 = 0x180644c60;
                        }
                        func_0x0001800f4620(*(int64_t *)0x180781f28 + 0x2ca0, 0x40, 0x180644cf8, uVar11, uVar5, uVar7, 
                                            uVar8, uVar10);
                        if (((uVar13 == 0) && (uVar14 != 0)) &&
                           (iVar6 = func_0x000180498cd0(iVar2 + 0x2ca0), iVar6 != 0)) {
                            *(undefined *)(iVar6 + 0x2c9f + iVar2) = 0;
                        }
                        func_0x00018010ce60();
                    }
                }
                if ((arg3 & 0x40U) == 0) {
                    if (*(char *)(iVar1 + 0x21cd) != '\0') {
                        return (uint8_t)((uint64_t)arg3 >> 0xf) & 1;
                    }
                    return 1;
                }
                if ((*(int32_t *)(iVar1 + 0x1654) == iVar9) && (iVar9 != 0)) {
                    fcn.1800f9f30(0, 0);
                }
            }
            *(undefined *)(iVar1 + 0x1651) = 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1800fa6bd
// Address: 0x1800fa6bd
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Removing arg arg_10bh because it doesn't fit into ProtoModel

uint8_t fcn.1800fa440(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    char cVar3;
    uint32_t uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int32_t iVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    int32_t iVar12;
    uint32_t uVar13;
    uint32_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000068;
    int64_t in_stack_000000f0;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar1 = *(int64_t *)0x180781f28;
    if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e8) == *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0)) &&
       (cVar3 = func_0x000180108120(arg1, arg1 + 8, 1), cVar3 != '\0')) {
        iVar9 = (int32_t)arg2;
        if (((*(int32_t *)(iVar1 + 0x163c) == 0) ||
            ((*(int32_t *)(iVar1 + 0x163c) == iVar9 || (*(char *)(iVar1 + 0x1650) != '\0')))) &&
           ((iVar12 = *(int32_t *)(iVar1 + 0x1654), iVar12 == 0 ||
            (((iVar12 == iVar9 || (*(char *)(iVar1 + 0x1661) != '\0')) || (*(char *)(iVar1 + 0x1666) != '\0')))))) {
            if ((((uint32_t)arg3 >> 0xd & 1) != 0) || (cVar3 = func_0x0001800fa0b0(), cVar3 != '\0')) {
                if (iVar9 != 0) {
                    if (((*(char *)(iVar1 + 0x2400) != '\0') && (*(int32_t *)(iVar1 + 0x241c) == iVar9)) &&
                       ((*(uint8_t *)(iVar1 + 0x2404) & 2) == 0)) {
                        return 0;
                    }
                    *(int32_t *)(iVar1 + 0x163c) = iVar9;
                    *(undefined *)(iVar1 + 0x1650) = 0;
                    if (*(int32_t *)(iVar1 + 0x1640) != iVar9) {
                        *(undefined8 *)(iVar1 + 0x1648) = 0;
                    }
                    if ((((uint32_t)arg3 >> 0xe & 1) != 0) &&
                       (*(undefined *)(iVar1 + 0x1650) = 1, *(int32_t *)(iVar1 + 0x1640) != iVar9)) {
                        return 0;
                    }
                    if ((((iVar9 == *(int32_t *)(iVar1 + 0x1fb8)) && ((*(uint32_t *)(iVar1 + 0x1fc0) & 0x400) != 0)) &&
                        (iVar12 != iVar9)) &&
                       (cVar3 = fcn.1800fa150(0x11000, in_stack_00000068, in_stack_000000f0),
                       iVar2 = *(int64_t *)0x180781f28, cVar3 != '\0')) {
                        uVar14 = *(uint32_t *)(iVar1 + 0x2004);
                        uVar13 = uVar14 & 0xffff0fff;
                        if (uVar13 - 0x20f < 8) {
                            if ((uVar13 - 0x20f & 0xfffffffb) == 0) {
                                uVar4 = 0xffffefff;
                            } else if ((uVar13 - 0x210 & 0xfffffffb) == 0) {
                                uVar4 = 0xffffdfff;
                            } else if ((uVar13 - 0x211 & 0xfffffffb) == 0) {
                                uVar4 = 0xffffbfff;
                            } else {
                                uVar4 = 0xffff7fff;
                                if ((uVar13 - 0x212 & 0xfffffffb) != 0) {
                                    uVar4 = 0xffffffff;
                                }
                            }
                            uVar14 = uVar14 & uVar4;
                        }
                        uVar11 = 0x1805aadb1;
                        if (uVar13 == 0) {
                            if (uVar14 == 0) {
                                uVar10 = 0x180644c8c;
                            } else {
                                uVar10 = 0x1805aadb1;
                            }
                        } else if (uVar13 - 0x200 < 0x9b) {
                            uVar10 = *(undefined8 *)((int64_t)(int32_t)uVar13 * 8 + 0x180617a60);
                        } else {
                            uVar10 = 0x1806229f8;
                        }
                        uVar8 = 0x1805aadb1;
                        if ((uVar14 >> 0xf & 1) != 0) {
                            uVar8 = 0x180644c48;
                        }
                        uVar7 = 0x1805aadb1;
                        if ((uVar14 >> 0xe & 1) != 0) {
                            uVar7 = 0x180644c50;
                        }
                        uVar5 = 0x1805aadb1;
                        if ((uVar14 >> 0xd & 1) != 0) {
                            uVar5 = 0x180644c58;
                        }
                        if ((uVar14 >> 0xc & 1) != 0) {
                            uVar11 = 0x180644c60;
                        }
                        func_0x0001800f4620(*(int64_t *)0x180781f28 + 0x2ca0, 0x40, 0x180644cf8, uVar11, uVar5, uVar7, 
                                            uVar8, uVar10);
                        if (((uVar13 == 0) && (uVar14 != 0)) &&
                           (iVar6 = func_0x000180498cd0(iVar2 + 0x2ca0), iVar6 != 0)) {
                            *(undefined *)(iVar6 + 0x2c9f + iVar2) = 0;
                        }
                        func_0x00018010ce60();
                    }
                }
                if ((arg3 & 0x40U) == 0) {
                    if (*(char *)(iVar1 + 0x21cd) != '\0') {
                        return (uint8_t)((uint64_t)arg3 >> 0xf) & 1;
                    }
                    return 1;
                }
                if ((*(int32_t *)(iVar1 + 0x1654) == iVar9) && (iVar9 != 0)) {
                    fcn.1800f9f30(0, 0);
                }
            }
            *(undefined *)(iVar1 + 0x1651) = 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1800fa6f9
// Address: 0x1800fa6f9
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Removing arg arg_10bh because it doesn't fit into ProtoModel

uint8_t fcn.1800fa440(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    char cVar3;
    uint32_t uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    undefined8 uVar8;
    int32_t iVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    int32_t iVar12;
    uint32_t uVar13;
    uint32_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000068;
    int64_t in_stack_000000f0;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar1 = *(int64_t *)0x180781f28;
    if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e8) == *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0)) &&
       (cVar3 = func_0x000180108120(arg1, arg1 + 8, 1), cVar3 != '\0')) {
        iVar9 = (int32_t)arg2;
        if (((*(int32_t *)(iVar1 + 0x163c) == 0) ||
            ((*(int32_t *)(iVar1 + 0x163c) == iVar9 || (*(char *)(iVar1 + 0x1650) != '\0')))) &&
           ((iVar12 = *(int32_t *)(iVar1 + 0x1654), iVar12 == 0 ||
            (((iVar12 == iVar9 || (*(char *)(iVar1 + 0x1661) != '\0')) || (*(char *)(iVar1 + 0x1666) != '\0')))))) {
            if ((((uint32_t)arg3 >> 0xd & 1) != 0) || (cVar3 = func_0x0001800fa0b0(), cVar3 != '\0')) {
                if (iVar9 != 0) {
                    if (((*(char *)(iVar1 + 0x2400) != '\0') && (*(int32_t *)(iVar1 + 0x241c) == iVar9)) &&
                       ((*(uint8_t *)(iVar1 + 0x2404) & 2) == 0)) {
                        return 0;
                    }
                    *(int32_t *)(iVar1 + 0x163c) = iVar9;
                    *(undefined *)(iVar1 + 0x1650) = 0;
                    if (*(int32_t *)(iVar1 + 0x1640) != iVar9) {
                        *(undefined8 *)(iVar1 + 0x1648) = 0;
                    }
                    if ((((uint32_t)arg3 >> 0xe & 1) != 0) &&
                       (*(undefined *)(iVar1 + 0x1650) = 1, *(int32_t *)(iVar1 + 0x1640) != iVar9)) {
                        return 0;
                    }
                    if ((((iVar9 == *(int32_t *)(iVar1 + 0x1fb8)) && ((*(uint32_t *)(iVar1 + 0x1fc0) & 0x400) != 0)) &&
                        (iVar12 != iVar9)) &&
                       (cVar3 = fcn.1800fa150(0x11000, in_stack_00000068, in_stack_000000f0),
                       iVar2 = *(int64_t *)0x180781f28, cVar3 != '\0')) {
                        uVar14 = *(uint32_t *)(iVar1 + 0x2004);
                        uVar13 = uVar14 & 0xffff0fff;
                        if (uVar13 - 0x20f < 8) {
                            if ((uVar13 - 0x20f & 0xfffffffb) == 0) {
                                uVar4 = 0xffffefff;
                            } else if ((uVar13 - 0x210 & 0xfffffffb) == 0) {
                                uVar4 = 0xffffdfff;
                            } else if ((uVar13 - 0x211 & 0xfffffffb) == 0) {
                                uVar4 = 0xffffbfff;
                            } else {
                                uVar4 = 0xffff7fff;
                                if ((uVar13 - 0x212 & 0xfffffffb) != 0) {
                                    uVar4 = 0xffffffff;
                                }
                            }
                            uVar14 = uVar14 & uVar4;
                        }
                        uVar11 = 0x1805aadb1;
                        if (uVar13 == 0) {
                            if (uVar14 == 0) {
                                uVar10 = 0x180644c8c;
                            } else {
                                uVar10 = 0x1805aadb1;
                            }
                        } else if (uVar13 - 0x200 < 0x9b) {
                            uVar10 = *(undefined8 *)((int64_t)(int32_t)uVar13 * 8 + 0x180617a60);
                        } else {
                            uVar10 = 0x1806229f8;
                        }
                        uVar8 = 0x1805aadb1;
                        if ((uVar14 >> 0xf & 1) != 0) {
                            uVar8 = 0x180644c48;
                        }
                        uVar7 = 0x1805aadb1;
                        if ((uVar14 >> 0xe & 1) != 0) {
                            uVar7 = 0x180644c50;
                        }
                        uVar5 = 0x1805aadb1;
                        if ((uVar14 >> 0xd & 1) != 0) {
                            uVar5 = 0x180644c58;
                        }
                        if ((uVar14 >> 0xc & 1) != 0) {
                            uVar11 = 0x180644c60;
                        }
                        func_0x0001800f4620(*(int64_t *)0x180781f28 + 0x2ca0, 0x40, 0x180644cf8, uVar11, uVar5, uVar7, 
                                            uVar8, uVar10);
                        if (((uVar13 == 0) && (uVar14 != 0)) &&
                           (iVar6 = func_0x000180498cd0(iVar2 + 0x2ca0), iVar6 != 0)) {
                            *(undefined *)(iVar6 + 0x2c9f + iVar2) = 0;
                        }
                        func_0x00018010ce60();
                    }
                }
                if ((arg3 & 0x40U) == 0) {
                    if (*(char *)(iVar1 + 0x21cd) != '\0') {
                        return (uint8_t)((uint64_t)arg3 >> 0xf) & 1;
                    }
                    return 1;
                }
                if ((*(int32_t *)(iVar1 + 0x1654) == iVar9) && (iVar9 != 0)) {
                    fcn.1800f9f30(0, 0);
                }
            }
            *(undefined *)(iVar1 + 0x1651) = 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1800fa7f0
// Address: 0x1800fa7f0
// Size: 513 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800fa7f0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    float fVar3;
    float fVar4;
    int64_t iVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t iVar10;
    int32_t iVar11;
    int64_t iVar12;
    int32_t iVar13;
    int64_t iVar14;
    int32_t iVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar10 = *(int64_t *)0x180781f28;
    iVar12 = *(int64_t *)(arg1 + 0xb8 + arg2 * 8);
    if (iVar12 == 0) {
        var_10h = func_0x00018046d050(0xe0);
        var_20h = (int64_t)&var_8h;
        if (var_10h == 0) {
            iVar12 = 0;
        } else {
            iVar12 = func_0x000180123d20(var_10h, iVar10 + 0x1310);
        }
        *(int64_t *)(iVar12 + 0xd8) = arg3;
        *(int64_t *)(arg1 + 0xb8 + arg2 * 8) = iVar12;
    }
    if (*(float *)(arg1 + 0xac + arg2 * 4) != (float)*(double *)(iVar10 + 0x18)) {
        func_0x000180123f80(iVar12);
        iVar5 = *(int64_t *)(iVar10 + 0x68);
        uVar6 = *(undefined4 *)(iVar5 + 0x28);
        uVar7 = *(undefined4 *)(iVar5 + 0x2c);
        uVar8 = *(undefined4 *)(iVar5 + 0x30);
        uVar9 = *(undefined4 *)(iVar5 + 0x34);
        piVar1 = (int32_t *)(iVar12 + 0xb0);
        iVar11 = *(int32_t *)(iVar12 + 0xb4);
        iVar15 = 8;
        if (*piVar1 == iVar11) {
            iVar13 = *piVar1 + 1;
            if (iVar11 == 0) {
                iVar11 = 8;
            } else {
                iVar11 = iVar11 / 2 + iVar11;
            }
            if (iVar13 < iVar11) {
                iVar13 = iVar11;
            }
            func_0x00018011faa0(piVar1, iVar13);
        }
        puVar2 = (undefined4 *)(*(int64_t *)(iVar12 + 0xb8) + (int64_t)*piVar1 * 0x10);
        *puVar2 = uVar6;
        puVar2[1] = uVar7;
        puVar2[2] = uVar8;
        puVar2[3] = uVar9;
        *piVar1 = *piVar1 + 1;
        *(undefined4 *)(iVar12 + 0x70) = uVar6;
        *(undefined4 *)(iVar12 + 0x74) = uVar7;
        *(undefined4 *)(iVar12 + 0x78) = uVar8;
        *(undefined4 *)(iVar12 + 0x7c) = uVar9;
        func_0x000180124360(iVar12);
        fVar3 = *(float *)(arg1 + 8);
        fVar4 = *(float *)(arg1 + 0xc);
        fVar16 = fVar3 + *(float *)(arg1 + 0x10);
        fVar18 = fVar3;
        if (fVar3 <= fVar16) {
            fVar18 = fVar16;
        }
        fVar17 = fVar4 + *(float *)(arg1 + 0x14);
        fVar16 = fVar4;
        if (fVar4 <= fVar17) {
            fVar16 = fVar17;
        }
        piVar1 = (int32_t *)(iVar12 + 0xa0);
        iVar11 = *(int32_t *)(iVar12 + 0xa4);
        if (*piVar1 == iVar11) {
            iVar13 = *piVar1 + 1;
            if (iVar11 != 0) {
                iVar15 = iVar11 + iVar11 / 2;
            }
            if (iVar13 < iVar15) {
                iVar13 = iVar15;
            }
            func_0x00018011faa0(piVar1, iVar13);
        }
        iVar14 = (int64_t)*piVar1;
        iVar5 = *(int64_t *)(iVar12 + 0xa8);
        *(float *)(iVar5 + iVar14 * 0x10) = fVar3;
        *(float *)(iVar5 + 4 + iVar14 * 0x10) = fVar4;
        *(float *)(iVar5 + 8 + iVar14 * 0x10) = fVar18;
        *(float *)(iVar5 + 0xc + iVar14 * 0x10) = fVar16;
        *piVar1 = *piVar1 + 1;
        *(float *)(iVar12 + 0x60) = fVar3;
        *(float *)(iVar12 + 100) = fVar4;
        *(float *)(iVar12 + 0x68) = fVar18;
        *(float *)(iVar12 + 0x6c) = fVar16;
        func_0x0001801242c0(iVar12);
        *(float *)(arg1 + 0xac + arg2 * 4) = (float)*(double *)(iVar10 + 0x18);
    }
    return iVar12;
}

// ============================================================
// Function: FUN_1800faa00
// Address: 0x1800faa00
// Size: 234 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800faa00(int64_t arg1)
{
    float fVar1;
    float fVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    iVar5 = *(int64_t *)0x180781f28;
    func_0x00018010e050(arg1, 0);
    fcn.1800f9f30((uint64_t)*(uint32_t *)(arg1 + 0xc4), arg1);
    if (*(char *)(iVar5 + 0x7e) != '\0') {
        *(undefined *)(iVar5 + 0x21cc) = 0;
    }
    iVar3 = *(int64_t *)0x180781f28;
    fVar1 = *(float *)(*(int64_t *)(arg1 + 0x428) + 100);
    fVar2 = *(float *)(*(int64_t *)(arg1 + 0x428) + 0x60);
    *(undefined *)(iVar5 + 0x1662) = 1;
    *(float *)(iVar5 + 0x1670) = *(float *)(iVar5 + 0xb00) - fVar1;
    *(float *)(iVar5 + 0x166c) = *(float *)(iVar5 + 0xafc) - fVar2;
    *(undefined4 *)(iVar3 + 0x1f68) = 0xf;
    *(undefined *)(iVar3 + 0x1f6c) = 1;
    *(bool *)(iVar3 + 0x2239) = *(char *)(iVar3 + 0x223a) != '\0';
    *(undefined2 *)(iVar3 + 0x2278) = 0;
    if (((*(uint8_t *)(arg1 + 0x14) & 4) != 0) ||
       (bVar4 = true, (*(uint8_t *)(*(int64_t *)(arg1 + 0x428) + 0x14) & 4) != 0)) {
        bVar4 = false;
    }
    if ((((*(int64_t *)(arg1 + 0x4c8) == 0) || (iVar3 = *(int64_t *)(*(int64_t *)(arg1 + 0x4c8) + 0xa0), iVar3 == 0)) ||
        ((*(uint8_t *)(iVar3 + 0x14) & 4) == 0)) && (bVar4)) {
        *(int64_t *)(iVar5 + 0x1600) = arg1;
    }
    return;
}

// ============================================================
// Function: FUN_1800faaf0
// Address: 0x1800faaf0
// Size: 404 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1bh
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.1800faaf0(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    bool bVar2;
    bool bVar3;
    char cVar4;
    int32_t iVar5;
    int64_t iVar6;
    char in_R8B;
    int32_t iVar7;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_44h;
    int64_t var_1fh;
    
    bVar3 = false;
    if ((((in_R8B != '\0') && (arg2 != 0)) && (*(int64_t *)(arg2 + 0xa0) != 0)) &&
       (((*(uint8_t *)(*(int64_t *)(arg2 + 0xa0) + 0x14) & 4) == 0 && ((*(uint8_t *)(arg2 + 0x10) & 0x80) == 0)))) {
        iVar6 = *(int64_t *)(arg2 + 0x18);
        iVar8 = arg2;
        while (iVar6 != 0) {
            iVar8 = *(int64_t *)(iVar8 + 0x18);
            iVar6 = *(int64_t *)(iVar8 + 0x18);
        }
        if ((*(int64_t *)(iVar8 + 0xb0) != arg2) || (*(int64_t *)(iVar8 + 0xa8) != 0)) {
            bVar3 = true;
        }
    }
    iVar8 = *(int64_t *)0x180781f28;
    cVar4 = func_0x000180107ff0(0, 0, 0);
    if (*(char *)(iVar8 + 0x120) == '\0') {
        bVar2 = false;
    } else {
        bVar2 = *(float *)(iVar8 + 0xa4) * *(float *)(iVar8 + 0xa4) <= *(float *)(iVar8 + 0xbfc);
    }
    if (bVar3) {
        if (bVar2) {
            piVar1 = (int32_t *)(iVar8 + 0x28f8);
            iVar5 = *(int32_t *)(iVar8 + 0x28fc);
            if (*piVar1 == iVar5) {
                iVar7 = *piVar1 + 1;
                if (iVar5 == 0) {
                    iVar5 = 8;
                } else {
                    iVar5 = iVar5 / 2 + iVar5;
                }
                if (iVar7 < iVar5) {
                    iVar7 = iVar5;
                }
                func_0x00018011fa30(piVar1, iVar7);
            }
            iVar8 = *(int64_t *)(iVar8 + 0x2900);
            iVar6 = (int64_t)*piVar1 * 0x40;
            *(undefined4 *)(iVar6 + iVar8) = 2;
            *(undefined4 *)(iVar6 + 4 + iVar8) = (undefined4)var_44h;
            *(undefined8 *)(iVar6 + 8 + iVar8) = 0;
            *(undefined8 *)(iVar6 + 0x10 + iVar8) = 0;
            *(undefined8 *)(iVar6 + 0x18 + iVar8) = 0;
            *(undefined4 *)(iVar6 + 0x20 + iVar8) = 0xffffffff;
            *(undefined4 *)(iVar6 + 0x24 + iVar8) = 0x3f000000;
            *(undefined *)(iVar6 + 0x28 + iVar8) = 0;
            *(undefined4 *)(iVar6 + 0x29 + iVar8) = (undefined4)var_1fh;
            *(undefined2 *)(iVar6 + 0x2d + iVar8) = var_1fh._4_2_;
            *(undefined *)(iVar6 + 0x2f + iVar8) = var_1fh._6_1_;
            *(undefined8 *)(iVar6 + 0x30 + iVar8) = 0;
            *(int64_t *)(iVar6 + 0x38 + iVar8) = arg2;
            *piVar1 = *piVar1 + 1;
            return;
        }
    } else if (((cVar4 != '\0') || (bVar2)) && (*(int64_t *)(iVar8 + 0x1600) != arg1)) {
        fcn.1800faa00(arg1);
    }
    return;
}

// ============================================================
// Function: FUN_1800fac90
// Address: 0x1800fac90
// Size: 176 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800fac90(void)
{
    uint32_t *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t var_8h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1600);
    if ((iVar2 != 0) && (*(int64_t *)(iVar2 + 0x48) != 0)) {
        if ((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x12cc) & 0x400) != 0) {
            func_0x000180113580(*(undefined8 *)(iVar2 + 0x428), *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2168));
        }
        if ((*(char *)(*(int64_t *)0x180781f28 + 0x2400) == '\0') ||
           (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2488) == 0)) {
            *(undefined8 *)(iVar3 + 0x2168) = *(undefined8 *)(iVar2 + 0x48);
        }
        if ((*(uint32_t *)(iVar2 + 0x14) & 0x10200) != 0x10200) {
            puVar1 = (uint32_t *)(*(int64_t *)(iVar2 + 0x48) + 4);
            *puVar1 = *puVar1 & 0xffffff7f;
        }
        *(undefined8 *)(iVar3 + 0x1600) = 0;
        return;
    }
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x1600) = 0;
    return;
}

// ============================================================
// Function: FUN_1800fae50
// Address: 0x1800fae50
// Size: 1072 bytes
// ============================================================
void fcn.1800fae50(void)
{
    int64_t *piVar1;
    float fVar2;
    double dVar3;
    uint8_t uVar4;
    uint8_t uVar5;
    uint8_t uVar6;
    uint8_t uVar7;
    int32_t iVar8;
    bool bVar9;
    bool bVar10;
    bool bVar11;
    int64_t iVar12;
    undefined uVar13;
    int64_t iVar14;
    uint8_t uVar15;
    uint32_t uVar16;
    int32_t iVar17;
    int64_t iVar18;
    int64_t iVar19;
    bool bVar20;
    
    iVar12 = *(int64_t *)0x180781f28;
    bVar20 = false;
    piVar1 = (int64_t *)(*(int64_t *)0x180781f28 + 0x15e8);
    fVar2 = *(float *)(*(int64_t *)0x180781f28 + 0xe04);
    if (*(float *)(*(int64_t *)0x180781f28 + 0xe04) <= *(float *)(*(int64_t *)0x180781f28 + 0xe08)) {
        fVar2 = *(float *)(*(int64_t *)0x180781f28 + 0xe08);
    }
    if (fVar2 <= *(float *)(*(int64_t *)0x180781f28 + 0xdb4)) {
        fVar2 = *(float *)(*(int64_t *)0x180781f28 + 0xdb4);
    }
    *(float *)(*(int64_t *)0x180781f28 + 0x15d4) = fVar2;
    func_0x0001800fe3c0();
    iVar19 = *piVar1;
    *(int64_t *)(iVar12 + 0x15f8) = iVar19;
    iVar8 = *(int32_t *)(iVar12 + 0x2120);
    uVar16 = iVar8 - 1;
    if (-1 < (int32_t)uVar16) {
        do {
            iVar18 = *(int64_t *)((uint64_t)uVar16 * 0x38 + 8 + *(int64_t *)(iVar12 + 0x2128));
            if ((iVar18 != 0) && ((*(uint32_t *)(iVar18 + 0x14) & 0x8000000) != 0)) {
                if ((iVar19 == 0) || (iVar14 = *(int64_t *)(iVar19 + 0x418), *(int64_t *)(iVar14 + 0x418) == iVar18))
                goto code_r0x0001800faef2;
                goto code_r0x0001800faf30;
            }
            uVar16 = uVar16 - 1;
        } while (-1 < (int32_t)uVar16);
    }
    iVar18 = 0;
    goto code_r0x0001800faef2;
    while (iVar14 = *(int64_t *)(iVar14 + 0x410), iVar14 != 0) {
code_r0x0001800faf30:
        if (iVar14 == iVar18) goto code_r0x0001800faef2;
    }
    bVar20 = true;
code_r0x0001800faef2:
    if ((*(uint8_t *)(iVar12 + 0x30) & 0x10) != 0) {
        bVar20 = true;
    }
    if (*(char *)(iVar12 + 0xb50) != '\0') {
        if ((iVar19 == 0) && (iVar8 < 1)) {
            uVar13 = 0;
        } else {
            uVar13 = 1;
        }
        *(undefined *)(iVar12 + 0xba0) = uVar13;
        if ((*piVar1 == 0) && (iVar18 == 0)) {
            uVar13 = 0;
        } else {
            uVar13 = 1;
        }
        *(undefined *)(iVar12 + 0xba5) = uVar13;
    }
    uVar15 = *(uint8_t *)(iVar12 + 0x120);
    iVar19 = -1;
    if ((uVar15 != 0) || (iVar17 = -1, *(char *)(iVar12 + 0xb6e) != '\0')) {
        iVar17 = 0;
    }
    if (*(char *)(iVar12 + 0xb51) != '\0') {
        if ((*piVar1 == 0) && (iVar8 < 1)) {
            uVar13 = 0;
        } else {
            uVar13 = 1;
        }
        *(undefined *)(iVar12 + 0xba1) = uVar13;
        if ((*piVar1 == 0) && (iVar18 == 0)) {
            uVar13 = 0;
        } else {
            uVar13 = 1;
        }
        *(undefined *)(iVar12 + 0xba6) = uVar13;
    }
    uVar4 = *(uint8_t *)(iVar12 + 0x121);
    if (((uVar4 != 0) || (*(char *)(iVar12 + 0xb6f) != '\0')) &&
       ((iVar17 == -1 ||
        (dVar3 = *(double *)(iVar12 + 0xb28 + (int64_t)iVar17 * 8),
        *(double *)(iVar12 + 0xb30) <= dVar3 && dVar3 != *(double *)(iVar12 + 0xb30))))) {
        iVar17 = 1;
    }
    if (*(char *)(iVar12 + 0xb52) != '\0') {
        if ((*piVar1 == 0) && (iVar8 < 1)) {
            uVar13 = 0;
        } else {
            uVar13 = 1;
        }
        *(undefined *)(iVar12 + 0xba2) = uVar13;
        if ((*piVar1 == 0) && (iVar18 == 0)) {
            uVar13 = 0;
        } else {
            uVar13 = 1;
        }
        *(undefined *)(iVar12 + 0xba7) = uVar13;
    }
    uVar5 = *(uint8_t *)(iVar12 + 0x122);
    if (((uVar5 != 0) || (*(char *)(iVar12 + 0xb70) != '\0')) &&
       ((iVar17 == -1 ||
        (dVar3 = *(double *)(iVar12 + 0xb28 + (int64_t)iVar17 * 8),
        *(double *)(iVar12 + 0xb38) <= dVar3 && dVar3 != *(double *)(iVar12 + 0xb38))))) {
        iVar17 = 2;
    }
    if (*(char *)(iVar12 + 0xb53) != '\0') {
        if ((*piVar1 == 0) && (iVar8 < 1)) {
            uVar13 = 0;
        } else {
            uVar13 = 1;
        }
        *(undefined *)(iVar12 + 0xba3) = uVar13;
        if ((*piVar1 == 0) && (iVar18 == 0)) {
            uVar13 = 0;
        } else {
            uVar13 = 1;
        }
        *(undefined *)(iVar12 + 0xba8) = uVar13;
    }
    uVar6 = *(uint8_t *)(iVar12 + 0x123);
    if (((uVar6 != 0) || (*(char *)(iVar12 + 0xb71) != '\0')) &&
       ((iVar17 == -1 ||
        (dVar3 = *(double *)(iVar12 + 0xb28 + (int64_t)iVar17 * 8),
        *(double *)(iVar12 + 0xb40) <= dVar3 && dVar3 != *(double *)(iVar12 + 0xb40))))) {
        iVar17 = 3;
    }
    if (*(char *)(iVar12 + 0xb54) != '\0') {
        if ((*piVar1 == 0) && (iVar8 < 1)) {
            uVar13 = 0;
        } else {
            uVar13 = 1;
        }
        *(undefined *)(iVar12 + 0xba4) = uVar13;
        if ((*piVar1 == 0) && (iVar18 == 0)) {
            uVar13 = 0;
        } else {
            uVar13 = 1;
        }
        *(undefined *)(iVar12 + 0xba9) = uVar13;
    }
    uVar7 = *(uint8_t *)(iVar12 + 0x124);
    if ((uVar7 == 0) && (*(char *)(iVar12 + 0xb72) == '\0')) {
        if (iVar17 != -1) goto code_r0x0001800fb159;
    } else {
        if ((iVar17 == -1) ||
           (dVar3 = *(double *)(iVar12 + 0xb28 + (int64_t)iVar17 * 8),
           *(double *)(iVar12 + 0xb48) <= dVar3 && dVar3 != *(double *)(iVar12 + 0xb48))) {
            iVar17 = 4;
        }
code_r0x0001800fb159:
        iVar19 = (int64_t)iVar17;
        if (*(char *)(iVar19 + 0xba0 + iVar12) == '\0') {
            bVar9 = false;
            goto code_r0x0001800fb125;
        }
    }
    bVar9 = true;
code_r0x0001800fb125:
    if ((iVar17 == -1) || (*(char *)(iVar19 + 0xba5 + iVar12) != '\0')) {
        bVar11 = true;
    } else {
        bVar11 = false;
    }
    if ((*(char *)(iVar12 + 0x2400) == '\0') || ((*(uint8_t *)(iVar12 + 0x2404) & 0x10) == 0)) {
        bVar10 = false;
    } else {
        bVar10 = true;
    }
    if (((!bVar9) && (!bVar10)) || (bVar20)) {
        *(undefined8 *)(iVar12 + 0x15f0) = 0;
        *piVar1 = 0;
    }
    if (*(int32_t *)(iVar12 + 0x2c84) == -1) {
        uVar15 = uVar7 | uVar6 | uVar5 | uVar4 | uVar15;
        if (((bVar9) && ((*piVar1 != 0 || (uVar15 != 0)))) || (0 < iVar8)) {
            uVar13 = 1;
        } else {
            uVar13 = 0;
        }
        *(undefined *)(iVar12 + 0xe8) = uVar13;
        if (((bVar11) && ((*piVar1 != 0 || (uVar15 != 0)))) || (iVar18 != 0)) {
            bVar20 = true;
        } else {
            bVar20 = false;
        }
    } else {
        bVar20 = *(int32_t *)(iVar12 + 0x2c84) != 0;
        *(bool *)(iVar12 + 0xe8) = bVar20;
    }
    *(bool *)(iVar12 + 0xaf0) = bVar20;
    *(undefined *)(iVar12 + 0xe9) = 0;
    if (((*(uint32_t *)(iVar12 + 0x30) & 0x40) == 0) &&
       (((*(int32_t *)(iVar12 + 0x1654) != 0 || (iVar18 != 0)) ||
        ((*(char *)(iVar12 + 0xed) != '\0' &&
         (((*(uint32_t *)(iVar12 + 0x30) & 1) != 0 && (*(char *)(iVar12 + 0x7b) != '\0')))))))) {
        *(undefined *)(iVar12 + 0xe9) = 1;
    }
    if (*(int32_t *)(iVar12 + 0x2c88) != -1) {
        *(bool *)(iVar12 + 0xe9) = *(int32_t *)(iVar12 + 0x2c88) != 0;
    }
    *(bool *)(iVar12 + 0xea) = *(int32_t *)(iVar12 + 0x2c8c) != -1 && *(int32_t *)(iVar12 + 0x2c8c) != 0;
    return;
}

// ============================================================
// Function: FUN_1800fb280
// Address: 0x1800fb280
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800fb280(void)
{
    int64_t *piVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined uVar7;
    uint32_t uVar8;
    int64_t *piVar9;
    int32_t iVar10;
    uint64_t uVar11;
    bool bVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar6 = *(int64_t *)0x180781f28;
    fVar15 = -3.402823e+38;
    fVar16 = -3.402823e+38;
    fVar17 = 3.402823e+38;
    piVar9 = *(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
    fVar18 = 3.402823e+38;
    piVar1 = piVar9 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x2150);
    for (; piVar9 != piVar1; piVar9 = piVar9 + 1) {
        iVar4 = *piVar9;
        fVar2 = *(float *)(iVar4 + 8);
        fVar3 = *(float *)(iVar4 + 0xc);
        fVar13 = fVar2 + *(float *)(iVar4 + 0x10);
        fVar14 = fVar3 + *(float *)(iVar4 + 0x14);
        if (fVar2 < fVar17) {
            fVar17 = fVar2;
        }
        if (fVar3 < fVar18) {
            fVar18 = fVar3;
        }
        if (fVar15 < fVar13) {
            fVar15 = fVar13;
        }
        if (fVar16 < fVar14) {
            fVar16 = fVar14;
        }
    }
    *(float *)(*(int64_t *)0x180781f28 + 0x1348) = fVar17;
    *(float *)(iVar6 + 0x134c) = fVar18;
    *(float *)(iVar6 + 0x1350) = fVar15;
    *(float *)(iVar6 + 0x1354) = fVar16;
    *(undefined4 *)(iVar6 + 0x1338) = *(undefined4 *)(iVar6 + 0xec8);
    if (*(float *)(iVar6 + 0x133c) != *(float *)(iVar6 + 0xecc)) {
        uVar11 = 0;
        *(float *)(iVar6 + 0x133c) = *(float *)(iVar6 + 0xecc);
        do {
            iVar10 = (int32_t)uVar11;
            if (iVar10 == 0) {
                uVar7 = 0x30;
            } else {
                fVar16 = (float)iVar10;
                fVar15 = *(float *)(iVar6 + 0x133c);
                if (fVar16 <= *(float *)(iVar6 + 0x133c)) {
                    fVar15 = fVar16;
                }
                func_0x00018048e9f0(1.0 - fVar15 / fVar16);
                fVar15 = (float)func_0x000180471c90();
                iVar5 = (((int32_t)fVar15 + 1) / 2) * 2;
                if (iVar5 < 4) {
                    uVar7 = 4;
                } else {
                    if (0x200 < iVar5) {
                        iVar5 = 0;
                    }
                    uVar7 = (undefined)iVar5;
                }
            }
            *(undefined *)(uVar11 + 0x1504 + iVar6) = uVar7;
            uVar11 = (uint64_t)(iVar10 + 1U);
        } while ((int32_t)(iVar10 + 1U) < 0x40);
        fVar15 = (float)func_0x00018048ffb0();
        *(float *)(iVar6 + 0x1500) = *(float *)(iVar6 + 0x133c) / (1.0 - fVar15);
    }
    *(undefined4 *)(iVar6 + 0x1344) = 0;
    bVar12 = *(char *)(iVar6 + 0xec4) != '\0';
    if (bVar12) {
        *(undefined4 *)(iVar6 + 0x1344) = 1;
    }
    uVar8 = (uint32_t)bVar12;
    if ((*(char *)(iVar6 + 0xec5) != '\0') && ((**(uint8_t **)(iVar6 + 0x68) & 4) == 0)) {
        uVar8 = uVar8 | 2;
        *(uint32_t *)(iVar6 + 0x1344) = uVar8;
    }
    if (*(char *)(iVar6 + 0xec6) != '\0') {
        uVar8 = uVar8 | 4;
        *(uint32_t *)(iVar6 + 0x1344) = uVar8;
    }
    *(undefined4 *)(iVar6 + 0x1340) = 0x3f800000;
    if ((*(uint8_t *)(iVar6 + 0x34) & 8) != 0) {
        *(uint32_t *)(iVar6 + 0x1344) = uVar8 | 8;
    }
    return;
}

// ============================================================
// Function: FUN_1800fb295
// Address: 0x1800fb295
// Size: 216 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800fb280(void)
{
    int64_t *piVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined uVar7;
    uint32_t uVar8;
    int64_t *piVar9;
    int32_t iVar10;
    uint64_t uVar11;
    bool bVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar6 = *(int64_t *)0x180781f28;
    fVar15 = -3.402823e+38;
    fVar16 = -3.402823e+38;
    fVar17 = 3.402823e+38;
    piVar9 = *(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
    fVar18 = 3.402823e+38;
    piVar1 = piVar9 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x2150);
    for (; piVar9 != piVar1; piVar9 = piVar9 + 1) {
        iVar4 = *piVar9;
        fVar2 = *(float *)(iVar4 + 8);
        fVar3 = *(float *)(iVar4 + 0xc);
        fVar13 = fVar2 + *(float *)(iVar4 + 0x10);
        fVar14 = fVar3 + *(float *)(iVar4 + 0x14);
        if (fVar2 < fVar17) {
            fVar17 = fVar2;
        }
        if (fVar3 < fVar18) {
            fVar18 = fVar3;
        }
        if (fVar15 < fVar13) {
            fVar15 = fVar13;
        }
        if (fVar16 < fVar14) {
            fVar16 = fVar14;
        }
    }
    *(float *)(*(int64_t *)0x180781f28 + 0x1348) = fVar17;
    *(float *)(iVar6 + 0x134c) = fVar18;
    *(float *)(iVar6 + 0x1350) = fVar15;
    *(float *)(iVar6 + 0x1354) = fVar16;
    *(undefined4 *)(iVar6 + 0x1338) = *(undefined4 *)(iVar6 + 0xec8);
    if (*(float *)(iVar6 + 0x133c) != *(float *)(iVar6 + 0xecc)) {
        uVar11 = 0;
        *(float *)(iVar6 + 0x133c) = *(float *)(iVar6 + 0xecc);
        do {
            iVar10 = (int32_t)uVar11;
            if (iVar10 == 0) {
                uVar7 = 0x30;
            } else {
                fVar16 = (float)iVar10;
                fVar15 = *(float *)(iVar6 + 0x133c);
                if (fVar16 <= *(float *)(iVar6 + 0x133c)) {
                    fVar15 = fVar16;
                }
                func_0x00018048e9f0(1.0 - fVar15 / fVar16);
                fVar15 = (float)func_0x000180471c90();
                iVar5 = (((int32_t)fVar15 + 1) / 2) * 2;
                if (iVar5 < 4) {
                    uVar7 = 4;
                } else {
                    if (0x200 < iVar5) {
                        iVar5 = 0;
                    }
                    uVar7 = (undefined)iVar5;
                }
            }
            *(undefined *)(uVar11 + 0x1504 + iVar6) = uVar7;
            uVar11 = (uint64_t)(iVar10 + 1U);
        } while ((int32_t)(iVar10 + 1U) < 0x40);
        fVar15 = (float)func_0x00018048ffb0();
        *(float *)(iVar6 + 0x1500) = *(float *)(iVar6 + 0x133c) / (1.0 - fVar15);
    }
    *(undefined4 *)(iVar6 + 0x1344) = 0;
    bVar12 = *(char *)(iVar6 + 0xec4) != '\0';
    if (bVar12) {
        *(undefined4 *)(iVar6 + 0x1344) = 1;
    }
    uVar8 = (uint32_t)bVar12;
    if ((*(char *)(iVar6 + 0xec5) != '\0') && ((**(uint8_t **)(iVar6 + 0x68) & 4) == 0)) {
        uVar8 = uVar8 | 2;
        *(uint32_t *)(iVar6 + 0x1344) = uVar8;
    }
    if (*(char *)(iVar6 + 0xec6) != '\0') {
        uVar8 = uVar8 | 4;
        *(uint32_t *)(iVar6 + 0x1344) = uVar8;
    }
    *(undefined4 *)(iVar6 + 0x1340) = 0x3f800000;
    if ((*(uint8_t *)(iVar6 + 0x34) & 8) != 0) {
        *(uint32_t *)(iVar6 + 0x1344) = uVar8 | 8;
    }
    return;
}

// ============================================================
// Function: FUN_1800fb36d
// Address: 0x1800fb36d
// Size: 179 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800fb280(void)
{
    int64_t *piVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined uVar7;
    uint32_t uVar8;
    int64_t *piVar9;
    int32_t iVar10;
    uint64_t uVar11;
    bool bVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar6 = *(int64_t *)0x180781f28;
    fVar15 = -3.402823e+38;
    fVar16 = -3.402823e+38;
    fVar17 = 3.402823e+38;
    piVar9 = *(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
    fVar18 = 3.402823e+38;
    piVar1 = piVar9 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x2150);
    for (; piVar9 != piVar1; piVar9 = piVar9 + 1) {
        iVar4 = *piVar9;
        fVar2 = *(float *)(iVar4 + 8);
        fVar3 = *(float *)(iVar4 + 0xc);
        fVar13 = fVar2 + *(float *)(iVar4 + 0x10);
        fVar14 = fVar3 + *(float *)(iVar4 + 0x14);
        if (fVar2 < fVar17) {
            fVar17 = fVar2;
        }
        if (fVar3 < fVar18) {
            fVar18 = fVar3;
        }
        if (fVar15 < fVar13) {
            fVar15 = fVar13;
        }
        if (fVar16 < fVar14) {
            fVar16 = fVar14;
        }
    }
    *(float *)(*(int64_t *)0x180781f28 + 0x1348) = fVar17;
    *(float *)(iVar6 + 0x134c) = fVar18;
    *(float *)(iVar6 + 0x1350) = fVar15;
    *(float *)(iVar6 + 0x1354) = fVar16;
    *(undefined4 *)(iVar6 + 0x1338) = *(undefined4 *)(iVar6 + 0xec8);
    if (*(float *)(iVar6 + 0x133c) != *(float *)(iVar6 + 0xecc)) {
        uVar11 = 0;
        *(float *)(iVar6 + 0x133c) = *(float *)(iVar6 + 0xecc);
        do {
            iVar10 = (int32_t)uVar11;
            if (iVar10 == 0) {
                uVar7 = 0x30;
            } else {
                fVar16 = (float)iVar10;
                fVar15 = *(float *)(iVar6 + 0x133c);
                if (fVar16 <= *(float *)(iVar6 + 0x133c)) {
                    fVar15 = fVar16;
                }
                func_0x00018048e9f0(1.0 - fVar15 / fVar16);
                fVar15 = (float)func_0x000180471c90();
                iVar5 = (((int32_t)fVar15 + 1) / 2) * 2;
                if (iVar5 < 4) {
                    uVar7 = 4;
                } else {
                    if (0x200 < iVar5) {
                        iVar5 = 0;
                    }
                    uVar7 = (undefined)iVar5;
                }
            }
            *(undefined *)(uVar11 + 0x1504 + iVar6) = uVar7;
            uVar11 = (uint64_t)(iVar10 + 1U);
        } while ((int32_t)(iVar10 + 1U) < 0x40);
        fVar15 = (float)func_0x00018048ffb0();
        *(float *)(iVar6 + 0x1500) = *(float *)(iVar6 + 0x133c) / (1.0 - fVar15);
    }
    *(undefined4 *)(iVar6 + 0x1344) = 0;
    bVar12 = *(char *)(iVar6 + 0xec4) != '\0';
    if (bVar12) {
        *(undefined4 *)(iVar6 + 0x1344) = 1;
    }
    uVar8 = (uint32_t)bVar12;
    if ((*(char *)(iVar6 + 0xec5) != '\0') && ((**(uint8_t **)(iVar6 + 0x68) & 4) == 0)) {
        uVar8 = uVar8 | 2;
        *(uint32_t *)(iVar6 + 0x1344) = uVar8;
    }
    if (*(char *)(iVar6 + 0xec6) != '\0') {
        uVar8 = uVar8 | 4;
        *(uint32_t *)(iVar6 + 0x1344) = uVar8;
    }
    *(undefined4 *)(iVar6 + 0x1340) = 0x3f800000;
    if ((*(uint8_t *)(iVar6 + 0x34) & 8) != 0) {
        *(uint32_t *)(iVar6 + 0x1344) = uVar8 | 8;
    }
    return;
}

// ============================================================
// Function: FUN_1800fb420
// Address: 0x1800fb420
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800fb280(void)
{
    int64_t *piVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined uVar7;
    uint32_t uVar8;
    int64_t *piVar9;
    int32_t iVar10;
    uint64_t uVar11;
    bool bVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar6 = *(int64_t *)0x180781f28;
    fVar15 = -3.402823e+38;
    fVar16 = -3.402823e+38;
    fVar17 = 3.402823e+38;
    piVar9 = *(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
    fVar18 = 3.402823e+38;
    piVar1 = piVar9 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x2150);
    for (; piVar9 != piVar1; piVar9 = piVar9 + 1) {
        iVar4 = *piVar9;
        fVar2 = *(float *)(iVar4 + 8);
        fVar3 = *(float *)(iVar4 + 0xc);
        fVar13 = fVar2 + *(float *)(iVar4 + 0x10);
        fVar14 = fVar3 + *(float *)(iVar4 + 0x14);
        if (fVar2 < fVar17) {
            fVar17 = fVar2;
        }
        if (fVar3 < fVar18) {
            fVar18 = fVar3;
        }
        if (fVar15 < fVar13) {
            fVar15 = fVar13;
        }
        if (fVar16 < fVar14) {
            fVar16 = fVar14;
        }
    }
    *(float *)(*(int64_t *)0x180781f28 + 0x1348) = fVar17;
    *(float *)(iVar6 + 0x134c) = fVar18;
    *(float *)(iVar6 + 0x1350) = fVar15;
    *(float *)(iVar6 + 0x1354) = fVar16;
    *(undefined4 *)(iVar6 + 0x1338) = *(undefined4 *)(iVar6 + 0xec8);
    if (*(float *)(iVar6 + 0x133c) != *(float *)(iVar6 + 0xecc)) {
        uVar11 = 0;
        *(float *)(iVar6 + 0x133c) = *(float *)(iVar6 + 0xecc);
        do {
            iVar10 = (int32_t)uVar11;
            if (iVar10 == 0) {
                uVar7 = 0x30;
            } else {
                fVar16 = (float)iVar10;
                fVar15 = *(float *)(iVar6 + 0x133c);
                if (fVar16 <= *(float *)(iVar6 + 0x133c)) {
                    fVar15 = fVar16;
                }
                func_0x00018048e9f0(1.0 - fVar15 / fVar16);
                fVar15 = (float)func_0x000180471c90();
                iVar5 = (((int32_t)fVar15 + 1) / 2) * 2;
                if (iVar5 < 4) {
                    uVar7 = 4;
                } else {
                    if (0x200 < iVar5) {
                        iVar5 = 0;
                    }
                    uVar7 = (undefined)iVar5;
                }
            }
            *(undefined *)(uVar11 + 0x1504 + iVar6) = uVar7;
            uVar11 = (uint64_t)(iVar10 + 1U);
        } while ((int32_t)(iVar10 + 1U) < 0x40);
        fVar15 = (float)func_0x00018048ffb0();
        *(float *)(iVar6 + 0x1500) = *(float *)(iVar6 + 0x133c) / (1.0 - fVar15);
    }
    *(undefined4 *)(iVar6 + 0x1344) = 0;
    bVar12 = *(char *)(iVar6 + 0xec4) != '\0';
    if (bVar12) {
        *(undefined4 *)(iVar6 + 0x1344) = 1;
    }
    uVar8 = (uint32_t)bVar12;
    if ((*(char *)(iVar6 + 0xec5) != '\0') && ((**(uint8_t **)(iVar6 + 0x68) & 4) == 0)) {
        uVar8 = uVar8 | 2;
        *(uint32_t *)(iVar6 + 0x1344) = uVar8;
    }
    if (*(char *)(iVar6 + 0xec6) != '\0') {
        uVar8 = uVar8 | 4;
        *(uint32_t *)(iVar6 + 0x1344) = uVar8;
    }
    *(undefined4 *)(iVar6 + 0x1340) = 0x3f800000;
    if ((*(uint8_t *)(iVar6 + 0x34) & 8) != 0) {
        *(uint32_t *)(iVar6 + 0x1344) = uVar8 | 8;
    }
    return;
}

// ============================================================
// Function: FUN_1800fb43e
// Address: 0x1800fb43e
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800fb280(void)
{
    int64_t *piVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined uVar7;
    uint32_t uVar8;
    int64_t *piVar9;
    int32_t iVar10;
    uint64_t uVar11;
    bool bVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar6 = *(int64_t *)0x180781f28;
    fVar15 = -3.402823e+38;
    fVar16 = -3.402823e+38;
    fVar17 = 3.402823e+38;
    piVar9 = *(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
    fVar18 = 3.402823e+38;
    piVar1 = piVar9 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x2150);
    for (; piVar9 != piVar1; piVar9 = piVar9 + 1) {
        iVar4 = *piVar9;
        fVar2 = *(float *)(iVar4 + 8);
        fVar3 = *(float *)(iVar4 + 0xc);
        fVar13 = fVar2 + *(float *)(iVar4 + 0x10);
        fVar14 = fVar3 + *(float *)(iVar4 + 0x14);
        if (fVar2 < fVar17) {
            fVar17 = fVar2;
        }
        if (fVar3 < fVar18) {
            fVar18 = fVar3;
        }
        if (fVar15 < fVar13) {
            fVar15 = fVar13;
        }
        if (fVar16 < fVar14) {
            fVar16 = fVar14;
        }
    }
    *(float *)(*(int64_t *)0x180781f28 + 0x1348) = fVar17;
    *(float *)(iVar6 + 0x134c) = fVar18;
    *(float *)(iVar6 + 0x1350) = fVar15;
    *(float *)(iVar6 + 0x1354) = fVar16;
    *(undefined4 *)(iVar6 + 0x1338) = *(undefined4 *)(iVar6 + 0xec8);
    if (*(float *)(iVar6 + 0x133c) != *(float *)(iVar6 + 0xecc)) {
        uVar11 = 0;
        *(float *)(iVar6 + 0x133c) = *(float *)(iVar6 + 0xecc);
        do {
            iVar10 = (int32_t)uVar11;
            if (iVar10 == 0) {
                uVar7 = 0x30;
            } else {
                fVar16 = (float)iVar10;
                fVar15 = *(float *)(iVar6 + 0x133c);
                if (fVar16 <= *(float *)(iVar6 + 0x133c)) {
                    fVar15 = fVar16;
                }
                func_0x00018048e9f0(1.0 - fVar15 / fVar16);
                fVar15 = (float)func_0x000180471c90();
                iVar5 = (((int32_t)fVar15 + 1) / 2) * 2;
                if (iVar5 < 4) {
                    uVar7 = 4;
                } else {
                    if (0x200 < iVar5) {
                        iVar5 = 0;
                    }
                    uVar7 = (undefined)iVar5;
                }
            }
            *(undefined *)(uVar11 + 0x1504 + iVar6) = uVar7;
            uVar11 = (uint64_t)(iVar10 + 1U);
        } while ((int32_t)(iVar10 + 1U) < 0x40);
        fVar15 = (float)func_0x00018048ffb0();
        *(float *)(iVar6 + 0x1500) = *(float *)(iVar6 + 0x133c) / (1.0 - fVar15);
    }
    *(undefined4 *)(iVar6 + 0x1344) = 0;
    bVar12 = *(char *)(iVar6 + 0xec4) != '\0';
    if (bVar12) {
        *(undefined4 *)(iVar6 + 0x1344) = 1;
    }
    uVar8 = (uint32_t)bVar12;
    if ((*(char *)(iVar6 + 0xec5) != '\0') && ((**(uint8_t **)(iVar6 + 0x68) & 4) == 0)) {
        uVar8 = uVar8 | 2;
        *(uint32_t *)(iVar6 + 0x1344) = uVar8;
    }
    if (*(char *)(iVar6 + 0xec6) != '\0') {
        uVar8 = uVar8 | 4;
        *(uint32_t *)(iVar6 + 0x1344) = uVar8;
    }
    *(undefined4 *)(iVar6 + 0x1340) = 0x3f800000;
    if ((*(uint8_t *)(iVar6 + 0x34) & 8) != 0) {
        *(uint32_t *)(iVar6 + 0x1344) = uVar8 | 8;
    }
    return;
}

// ============================================================
// Function: FUN_1800fb4a0
// Address: 0x1800fb4a0
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Removing arg arg_2480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24a8h because it doesn't fit into ProtoModel

void fcn.1800fb4a0(undefined8 placeholder_0, int64_t arg2)
{
    float *pfVar1;
    int64_t *piVar2;
    bool bVar3;
    int64_t iVar4;
    char cVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    float *pfVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    int64_t iVar14;
    int64_t *piVar15;
    char *pcVar16;
    int64_t iVar17;
    int32_t *piVar18;
    int64_t iVar19;
    int32_t *piVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    uVar13 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2970);
    while (uVar13 = uVar13 - 1, -1 < (int32_t)uVar13) {
        iVar14 = (uint64_t)uVar13 * 0x20 + *(int64_t *)(iVar4 + 0x2978);
        if (*(int32_t *)(iVar14 + 4) == 7) {
            func_0x000180498030(iVar14, iVar14 + 0x20, 
                                ((int64_t)*(int32_t *)(iVar4 + 0x2970) - (uint64_t)uVar13) * 0x20 + -0x20);
            *(int32_t *)(iVar4 + 0x2970) = *(int32_t *)(iVar4 + 0x2970) + -1;
        }
    }
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    iVar17 = iVar4;
    for (; iVar14 != iVar19; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 0) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    *(undefined4 *)(iVar4 + 0x12d0) = *(undefined4 *)(iVar4 + 0x12cc);
    uVar13 = *(uint32_t *)(iVar17 + 0x30);
    if ((uVar13 & 4) != 0) {
        uVar13 = uVar13 & 0xfffffffb;
        *(undefined *)(iVar17 + 0x7a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 & 8) != 0) {
        uVar13 = uVar13 & 0xfffffff7;
        *(undefined *)(iVar17 + 0x7b) = 0;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xe & 1) != 0) {
        uVar13 = uVar13 & 0xffffbfff;
        *(undefined *)(iVar17 + 0x8a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xf & 1) != 0) {
        uVar13 = uVar13 & 0xffff7fff;
        *(undefined *)(iVar17 + 0x8b) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((*(int64_t *)(iVar17 + 0xc30) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc48) == 0 || (*(int64_t *)(iVar17 + 0xc48) == 0x18011e8a0)))) {
        *(undefined8 *)(iVar17 + 0xc48) = 0x18010a030;
    }
    if ((*(int64_t *)(iVar17 + 0xc38) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc50) == 0 || (*(int64_t *)(iVar17 + 0xc50) == 0x18011e9d0)))) {
        *(undefined8 *)(iVar17 + 0xc50) = 0x18010a050;
    }
    if (((uVar13 >> 10 & 1) != 0) && ((*(uint32_t *)(iVar17 + 0x34) & 0xc00) != 0xc00)) {
        *(uint32_t *)(iVar17 + 0x30) = uVar13 & 0xfffffbff;
    }
    *(undefined4 *)(iVar4 + 0x12cc) = *(undefined4 *)(iVar4 + 0x30);
    if (*(char *)(iVar17 + 0x2928) == '\0') {
        if ((*(int64_t *)(iVar17 + 0x50) != 0) &&
           (iVar14 = func_0x0001800f5b50(*(int64_t *)(iVar17 + 0x50), 0x180625030), iVar14 != 0)) {
            iVar6 = func_0x00018046d704(iVar14);
            if ((iVar6 != -1) && (iVar7 = func_0x000180461598(iVar14, 0, 2), iVar7 == 0)) {
                iVar7 = func_0x00018046d704(iVar14);
                iVar19 = (int64_t)iVar7;
                if ((((iVar7 != -1) && (iVar6 = func_0x000180461598(iVar14, iVar6, 0), iVar6 == 0)) && (iVar19 != -1))
                   && (iVar9 = func_0x00018046d050(iVar19), iVar9 != 0)) {
                    iVar10 = func_0x0001804611b4(iVar9, 1, iVar19, iVar14);
                    if (iVar10 == iVar19) {
                        func_0x00018045ff84(iVar14);
                        if (iVar19 != 0) {
                            func_0x000180112840(iVar9, iVar19);
                        }
                        fcn.180460d90(iVar9);
                    } else {
                        func_0x00018045ff84(iVar14);
                        fcn.180460d90(iVar9);
                    }
                    goto code_r0x0001800fb715;
                }
            }
            func_0x00018045ff84(iVar14);
        }
code_r0x0001800fb715:
        *(undefined *)(iVar17 + 0x2928) = 1;
    }
    iVar6 = 0;
    if ((0.0 < *(float *)(iVar17 + 0x292c)) &&
       (fVar21 = *(float *)(iVar17 + 0x292c) - *(float *)(iVar17 + 0x48), *(float *)(iVar17 + 0x292c) = fVar21,
       fVar21 <= 0.0)) {
        if (*(int64_t *)(iVar17 + 0x50) == 0) {
            *(undefined *)(iVar17 + 0xec) = 1;
        } else {
            func_0x000180112a70();
        }
        *(undefined4 *)(iVar17 + 0x292c) = 0;
    }
    *(int32_t *)(iVar4 + 4) = *(int32_t *)(iVar4 + 4) + 1;
    *(undefined2 *)(iVar4 + 0x281e) = 0;
    *(undefined4 *)(iVar4 + 0x15d0) = 0;
    *(double *)(iVar4 + 0x18) = (double)*(float *)(iVar4 + 0x48) + *(double *)(iVar4 + 0x18);
    iVar7 = *(int32_t *)(iVar4 + 0x283c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(iVar4 + 0x2838, iVar8);
    }
    fVar21 = 3.402823e+38;
    *(undefined4 *)(iVar4 + 0x2838) = 0;
    *(float *)(iVar4 + 0x2c80) =
         (*(float *)(iVar4 + 0x48) - *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4)) +
         *(float *)(iVar4 + 0x2c80);
    *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4) = *(float *)(iVar4 + 0x48);
    iVar8 = *(int32_t *)(iVar4 + 0x2c7c) + 1;
    *(int32_t *)(iVar4 + 0x2c78) = (*(int32_t *)(iVar4 + 0x2c78) + 1) % 0x3c;
    iVar7 = 0x3c;
    if (iVar8 < 0x3c) {
        iVar7 = iVar8;
    }
    *(int32_t *)(iVar4 + 0x2c7c) = iVar7;
    if (*(float *)(iVar4 + 0x2c80) <= 0.0) {
        fVar22 = 3.402823e+38;
    } else {
        fVar22 = 1.0 / (*(float *)(iVar4 + 0x2c80) / (float)iVar7);
    }
    *(float *)(iVar4 + 0xf0) = fVar22;
    iVar7 = *(int32_t *)(iVar4 + 0x156c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f9d0(iVar4 + 0x1568, iVar8);
    }
    *(undefined4 *)(iVar4 + 0x1568) = 0;
    func_0x0001801093d0(*(undefined *)(iVar4 + 0x8e));
    func_0x000180113b10();
    func_0x000180106aa0();
    fcn.1800fb280();
    func_0x000180106fa0();
    *(undefined *)(iVar4 + 1) = 1;
    piVar15 = *(int64_t **)(iVar4 + 0x2158);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x2150);
    iVar14 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar14, piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        *(undefined8 *)(iVar14 + 0x40) = 0;
        *(undefined *)(iVar14 + 200) = 0;
        iVar14 = *(int64_t *)0x180781f28;
    }
    if ((*(char *)(iVar4 + 0x2400) != '\0') &&
       (iVar7 = *(int32_t *)(iVar4 + 0x241c), iVar7 == *(int32_t *)(iVar4 + 0x1654))) {
        if (*(int32_t *)(iVar14 + 0x1654) == iVar7) {
            *(int32_t *)(iVar14 + 0x1658) = iVar7;
        }
        if (*(int32_t *)(iVar14 + 0x1684) == iVar7) {
            *(undefined *)(iVar14 + 0x168d) = 1;
        }
    }
    if ((((*(char *)(iVar4 + 0xb5) != '\0') && (*(char *)(iVar4 + 0x138) != '\0')) ||
        (*(undefined4 *)(iVar4 + 0x1634) = 0, *(char *)(iVar4 + 0xb5) != '\0')) && (1 < *(int32_t *)(iVar4 + 0x1644))) {
        *(undefined4 *)(iVar4 + 0x1634) = *(undefined4 *)(iVar4 + 0x1640);
    }
    piVar18 = (int32_t *)(iVar4 + 0x163c);
    if (*(int32_t *)(iVar4 + 0x1640) == 0) {
        *(undefined4 *)(iVar4 + 0x1648) = 0;
code_r0x0001800fb97d:
        *(undefined4 *)(iVar4 + 0x164c) = 0;
    } else if ((*piVar18 != 0) && (*(int32_t *)(iVar4 + 0x1654) == *piVar18)) goto code_r0x0001800fb97d;
    iVar7 = *piVar18;
    piVar20 = (int32_t *)(iVar4 + 0x1654);
    fVar22 = *(float *)(iVar4 + 0x48);
    if ((iVar7 != 0) && (*(float *)(iVar4 + 0x1648) = fVar22 + *(float *)(iVar4 + 0x1648), *piVar20 != iVar7)) {
        *(float *)(iVar4 + 0x164c) = fVar22 + *(float *)(iVar4 + 0x164c);
    }
    *piVar18 = 0;
    iVar8 = *piVar20;
    *(int32_t *)(iVar4 + 0x1640) = iVar7;
    *(undefined4 *)(iVar4 + 0x1644) = 0;
    *(undefined2 *)(iVar4 + 0x1650) = 0;
    if (((iVar8 != 0) && (*(int32_t *)(iVar4 + 0x1658) != iVar8)) && (*(int32_t *)(iVar4 + 0x1680) == iVar8)) {
        fcn.1800f9f30(0, 0);
        fVar22 = *(float *)(iVar4 + 0x48);
    }
    iVar7 = *piVar20;
    if (iVar7 != 0) {
        *(float *)(iVar4 + 0x165c) = fVar22 + *(float *)(iVar4 + 0x165c);
    }
    *(int32_t *)(iVar4 + 0x1680) = iVar7;
    *(int32_t *)(iVar4 + 0x1658) = 0;
    *(undefined *)(iVar4 + 0x1665) = 0;
    *(undefined *)(iVar4 + 0x1660) = 0;
    *(float *)(iVar4 + 0x169c) = fVar22 + *(float *)(iVar4 + 0x169c);
    if ((*(int32_t *)(iVar4 + 0x2780) != 0) && (iVar7 != *(int32_t *)(iVar4 + 0x2780))) {
        *(undefined4 *)(iVar4 + 0x2780) = 0;
    }
    if ((*(int32_t *)(iVar4 + 0x277c) != 0) && (*(int32_t *)(iVar4 + 0x277c) != *(int32_t *)(iVar4 + 0x1684))) {
        *(undefined4 *)(iVar4 + 0x277c) = 0;
    }
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x1f68) = 0;
        *(undefined *)(iVar4 + 0x1f6c) = 0;
    }
    if (*(int32_t *)(iVar4 + 0x1688) < *(int32_t *)(iVar4 + 4)) {
        *(undefined4 *)(iVar4 + 0x1684) = 0;
    }
    iVar7 = *(int32_t *)(iVar4 + 0x2638);
    *(undefined *)(iVar4 + 0x168d) = 0;
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x2648) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(int32_t *)(iVar4 + 0x2648) = iVar7;
    }
    if (*(int64_t *)(iVar4 + 0x15e8) == 0) {
        *(undefined4 *)(iVar4 + 0x264c) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(undefined4 *)(iVar4 + 0x264c) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x15e8) + 0x10);
    }
    *(int32_t *)(iVar4 + 0x263c) = iVar7;
    if (iVar7 == 0) {
        if (0.0 < *(float *)(iVar4 + 0x2640)) {
            fVar23 = fVar22 + *(float *)(iVar4 + 0x2644);
            *(float *)(iVar4 + 0x2644) = fVar23;
            fVar24 = 0.25;
            if (0.25 <= fVar22 + fVar22) {
                fVar24 = fVar22 + fVar22;
            }
            if (fVar24 <= fVar23) {
                *(undefined8 *)(iVar4 + 0x2640) = 0;
            }
        }
    } else {
        *(undefined4 *)(iVar4 + 0x2644) = 0;
        *(undefined4 *)(iVar4 + 0x2638) = 0;
        *(float *)(iVar4 + 0x2640) = *(float *)(iVar4 + 0x2640) + fVar22;
    }
    func_0x000180108270();
    *(undefined4 *)(iVar4 + 0x2488) = *(undefined4 *)(iVar4 + 0x2484);
    *(undefined4 *)(iVar4 + 0x247c) = *(undefined4 *)(iVar4 + 0x2478);
    *(undefined4 *)(iVar4 + 0x2478) = 0;
    *(undefined8 *)(iVar4 + 0x2480) = 0x7f7fffff;
    *(undefined2 *)(iVar4 + 0x2401) = 0;
    *(undefined4 *)(iVar4 + 0x2490) = 0;
    if (*(char *)(iVar4 + 0x2400) != '\0') {
        if (*piVar20 == 0) {
            pcVar16 = "#DragDropCancelHandler";
            cVar5 = '#';
            do {
                if (((cVar5 == '#') && (*pcVar16 == '#')) && (pcVar16[1] == '#')) {
                    pcVar16 = pcVar16 + 2;
                }
                cVar5 = *pcVar16;
                pcVar16 = pcVar16 + 1;
            } while (cVar5 != '\0');
        }
        cVar5 = func_0x000180109d80();
        if (cVar5 != '\0') {
            fcn.1800f9f30(0, 0);
            func_0x0001801120a0();
        }
    }
    *(undefined8 *)(iVar4 + 0x2820) = 0;
    func_0x00018010f2f0();
    func_0x000180108830();
    func_0x000180114da0(iVar4);
    if ((*(char *)(iVar4 + 0x20b9) != '\0') || (*(float *)(iVar4 + 0x98) < 0.0)) {
        bVar3 = true;
    } else {
        bVar3 = false;
        fVar21 = (float)*(double *)(iVar4 + 0x18) - *(float *)(iVar4 + 0x98);
    }
    piVar15 = *(int64_t **)(iVar4 + 0x1588);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x1580);
    for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        cVar5 = *(char *)(iVar14 + 0x109);
        *(char *)(iVar14 + 0x10a) = cVar5;
        *(undefined *)(iVar14 + 0x109) = 0;
        *(undefined *)(iVar14 + 0x10b) = 0;
        *(undefined2 *)(iVar14 + 0x11a) = *(undefined2 *)(iVar14 + 0x118);
        *(undefined2 *)(iVar14 + 0x118) = 0;
        if (((cVar5 == '\0') || (bVar3)) &&
           ((*(char *)(iVar14 + 0x494) == '\0' &&
            (*(float *)(iVar14 + 0x2e8) <= fVar21 && fVar21 != *(float *)(iVar14 + 0x2e8))))) {
            iVar17 = *(int64_t *)(iVar14 + 800);
            *(undefined *)(iVar14 + 0x494) = 1;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x10) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x14);
            if (iVar8 < *(int32_t *)(iVar17 + 0x14)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x48c) = iVar7;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x20) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x24);
            if (iVar8 < *(int32_t *)(iVar17 + 0x24)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x490) = iVar7;
            if (*(int64_t *)(iVar14 + 0x150) != 0) {
                *(undefined8 *)(iVar14 + 0x148) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x150) = 0;
            }
            func_0x000180124110(*(undefined8 *)(iVar14 + 800));
            if (*(int64_t *)(iVar14 + 0x1f8) != 0) {
                *(undefined8 *)(iVar14 + 0x1f0) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x1f8) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x250) != 0) {
                *(undefined8 *)(iVar14 + 0x248) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x250) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x260) != 0) {
                *(undefined8 *)(iVar14 + 600) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x260) = 0;
            }
        }
    }
    fcn.1800fae50(iVar4 + 0x118);
    iVar17 = *(int64_t *)0x180781f28;
    iVar14 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1600);
    if (iVar14 == 0) {
        if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) == 0) ||
           (iVar7 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1654),
           *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) + 0xc4) != iVar7)) goto code_r0x0001800fbfc6;
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar7;
        if (*(int32_t *)(iVar17 + 0x1684) == iVar7) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') goto code_r0x0001800fbfc6;
    } else {
        piVar18 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1654);
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = *piVar18;
        if (*(int32_t *)(iVar17 + 0x1684) == *piVar18) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        iVar14 = *(int64_t *)(iVar14 + 0x428);
        if ((*(char *)(iVar14 + 0x10a) == '\0') && (*(char *)(iVar14 + 0x109) == '\0')) {
            bVar3 = true;
        } else {
            bVar3 = false;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') {
            pfVar1 = (float *)(iVar17 + 0x118);
            pfVar11 = pfVar1;
            if (pfVar1 == (float *)0x0) {
                pfVar11 = (float *)(*(int64_t *)0x180781f28 + 0x118);
            }
            if (((-256000.0 <= *pfVar11) && (-256000.0 <= pfVar11[1])) && (!bVar3)) {
                fVar22 = *pfVar1 - *(float *)(iVar17 + 0x166c);
                fVar24 = *(float *)(iVar17 + 0x11c) - *(float *)(iVar17 + 0x1670);
                var_8h._0_4_ = fVar22;
                var_8h._4_4_ = fVar24;
                if ((*(float *)(iVar14 + 0x60) != fVar22) || (*(float *)(iVar14 + 100) != fVar24)) {
                    func_0x000180106470(iVar14, &var_8h, 1);
                    if ((*(int64_t *)(iVar14 + 0x48) != 0) && (*(char *)(iVar14 + 0x108) != '\0')) {
                        *(uint64_t *)(*(int64_t *)(iVar14 + 0x48) + 8) = CONCAT44(fVar24, fVar22);
                        iVar14 = *(int64_t *)(iVar14 + 0x48);
                        *(float *)(iVar14 + 0x20) = *(float *)(iVar14 + 0x148) + *(float *)(iVar14 + 8);
                        *(float *)(iVar14 + 0x24) = *(float *)(iVar14 + 0x14c) + *(float *)(iVar14 + 0xc);
                        fVar24 = (*(float *)(iVar14 + 0x14) - *(float *)(iVar14 + 0x14c)) - *(float *)(iVar14 + 0x154);
                        fVar23 = (*(float *)(iVar14 + 0x10) - *(float *)(iVar14 + 0x148)) - *(float *)(iVar14 + 0x150);
                        fVar22 = 0.0;
                        if (0.0 <= fVar24) {
                            fVar22 = fVar24;
                        }
                        fVar24 = 0.0;
                        if (0.0 <= fVar23) {
                            fVar24 = fVar23;
                        }
                        *(float *)(iVar14 + 0x2c) = fVar22;
                        *(float *)(iVar14 + 0x28) = fVar24;
                    }
                }
                func_0x00018010e050(*(undefined8 *)(iVar17 + 0x1600), 0);
                goto code_r0x0001800fbfc6;
            }
        }
        fcn.1800fac90();
    }
    fcn.1800f9f30(0, 0);
code_r0x0001800fbfc6:
    uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    if (-1 < (int32_t)uVar13) {
        do {
            iVar14 = *(int64_t *)((uint64_t)uVar13 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar14 != 0) && ((*(uint32_t *)(iVar14 + 0x14) & 0x8000000) != 0)) goto code_r0x0001800fc015;
            uVar13 = uVar13 - 1;
        } while (-1 < (int32_t)uVar13);
    }
    if ((*(int64_t *)(iVar4 + 0x23c0) == 0) || (*(float *)(iVar4 + 0x23dc) <= 0.0)) {
        fVar22 = *(float *)(iVar4 + 0x23fc) - *(float *)(iVar4 + 0x48) * 10.0;
        if (fVar22 <= 0.0) {
            fVar22 = 0.0;
        }
    } else {
code_r0x0001800fc015:
        fVar22 = *(float *)(iVar4 + 0x48) * 6.0 + *(float *)(iVar4 + 0x23fc);
        if (1.0 <= fVar22) {
            fVar22 = 1.0;
        }
    }
    *(float *)(iVar4 + 0x23fc) = fVar22;
    *(undefined4 *)(iVar4 + 0x2650) = 0;
    *(undefined4 *)(iVar4 + 0x28c4) = *(undefined4 *)(iVar4 + 0x28b0);
    *(undefined4 *)(iVar4 + 0x28c8) = *(undefined4 *)(iVar4 + 0x28b4);
    *(undefined4 *)(iVar4 + 0x28cc) = *(undefined4 *)(iVar4 + 0x28b8);
    *(undefined4 *)(iVar4 + 0x28d0) = *(undefined4 *)(iVar4 + 0x28bc);
    *(undefined4 *)(iVar4 + 0x28d4) = *(undefined4 *)(iVar4 + 0x28c0);
    *(undefined8 *)(iVar4 + 0x2c88) = 0xffffffffffffffff;
    *(undefined4 *)(iVar4 + 0x2c84) = 0xffffffff;
    *(undefined2 *)(iVar4 + 0x28b0) = 0;
    func_0x000180108de0();
    iVar7 = iVar6;
    if (0 < *(int32_t *)(iVar4 + 0x2518)) {
        do {
            iVar14 = *(int64_t *)0x180781f28;
            fVar22 = *(float *)(*(int64_t *)(iVar4 + 0x2520) + (int64_t)iVar7 * 4);
            if ((0.0 <= fVar22) && (fVar22 < fVar21)) {
                iVar17 = (int64_t)iVar7 * 0x250 + *(int64_t *)(iVar4 + 0x24f8);
                *(undefined8 *)(iVar17 + 0x1f0) = 0;
                if (*(int64_t *)(iVar17 + 0x1e8) != 0) {
                    *(undefined8 *)(iVar17 + 0x1e0) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x1e8) = 0;
                }
                *(undefined *)(iVar17 + 0x23c) = 1;
                if (*(int64_t *)(iVar17 + 0x198) != 0) {
                    *(undefined8 *)(iVar17 + 400) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x198) = 0;
                }
                *(undefined *)(iVar17 + 0x24b) = 1;
                iVar8 = iVar6;
                if (0 < *(int32_t *)(iVar17 + 0x6c)) {
                    do {
                        iVar19 = (int64_t)iVar8;
                        iVar8 = iVar8 + 1;
                        *(undefined2 *)(iVar19 * 0x74 + 0x54 + *(int64_t *)(iVar17 + 0x18)) = 0xffff;
                    } while (iVar8 < *(int32_t *)(iVar17 + 0x6c));
                }
                *(undefined4 *)
                 (*(int64_t *)(iVar14 + 0x2520) +
                 (int64_t)(int32_t)((iVar17 - *(int64_t *)(iVar14 + 0x24f8)) / 0x250) * 4) = 0xbf800000;
            }
            iVar7 = iVar7 + 1;
        } while (iVar7 < *(int32_t *)(iVar4 + 0x2518));
    }
    iVar14 = *(int64_t *)(iVar4 + 0x24e8);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x24e0) * 0x88 + iVar14;
    iVar17 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar17, iVar14 != iVar19; iVar14 = iVar14 + 0x88) {
        if ((0.0 <= *(float *)(iVar14 + 8)) && (*(float *)(iVar14 + 8) < fVar21)) {
            func_0x000180126a10(iVar14 + 0x28);
            *(undefined4 *)(iVar14 + 8) = 0xbf800000;
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    if (*(char *)(iVar4 + 0x20b9) != '\0') {
        if (*(int64_t *)(iVar17 + 0x2108) != 0) {
            *(undefined8 *)(iVar17 + 0x2100) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2108) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x2118) != 0) {
            *(undefined8 *)(iVar17 + 0x2110) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2118) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x26e8) != 0) {
            *(undefined8 *)(iVar17 + 0x26e0) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x26e8) = 0;
        }
        *(undefined4 *)(iVar17 + 0x26f0) = 0;
        *(undefined4 *)(iVar17 + 0x25f8) = 0;
        func_0x00018011ee60(iVar17 + 0x2600);
        func_0x0001801388c0();
        piVar15 = *(int64_t **)(iVar17 + 0x12e0);
        piVar2 = piVar15 + *(int32_t *)(iVar17 + 0x12d8);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            iVar14 = *piVar15;
            iVar17 = *(int64_t *)(iVar14 + 0x2b0);
            func_0x000180129630(iVar14, 1);
            func_0x000180129f40(&var_8h, iVar14);
            if (((*(int32_t *)(iVar17 + 0x9c) != 0) || ((float)var_8h != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x1c))
                ) || (var_8h._4_4_ != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x20))) {
                func_0x0001801299b0(iVar14);
            }
        }
    }
    *(undefined *)(iVar4 + 0x20b9) = 0;
    if ((*(int64_t *)(iVar4 + 0x21d8) != 0) && (*(char *)(*(int64_t *)(iVar4 + 0x21d8) + 0x10a) == '\0')) {
        uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1590) - 1;
        if (-1 < (int32_t)uVar13) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1598) + (uint64_t)uVar13 * 8);
                if (((iVar14 != 0) && (*(char *)(iVar14 + 0x10a) != '\0')) &&
                   ((*(uint32_t *)(iVar14 + 0x14) & 0x10200) != 0x10200)) goto code_r0x0001800fc388;
                uVar13 = uVar13 - 1;
            } while (-1 < (int32_t)uVar13);
        }
        iVar14 = 0;
code_r0x0001800fc388:
        func_0x00018010e050(iVar14, 1);
    }
    func_0x00018011f370(iVar4 + 0x15b0, 0);
    iVar7 = *(int32_t *)(iVar4 + 0x2134);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f970(iVar4 + 0x2130, iVar8);
    }
    piVar18 = (int32_t *)(iVar4 + 0x2100);
    *(undefined4 *)(iVar4 + 0x2130) = 0;
    iVar7 = *(int32_t *)(iVar4 + 0x2104);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(piVar18, iVar8);
    }
    *piVar18 = 0;
    if (*(int32_t *)(iVar4 + 0x2104) == 0) {
        func_0x00018011fb10(piVar18, 8);
    }
    *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)*piVar18 * 4) = 0x10;
    iVar7 = *piVar18;
    *piVar18 = iVar7 + 1;
    *(undefined4 *)(iVar4 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)iVar7 * 4);
    func_0x00018011f140(iVar4 + 0x2110, 0);
    if ((*(uint8_t *)(iVar4 + 0x30) & 0x80) != 0) {
        iVar14 = *(int64_t *)(iVar4 + 0x15f0);
        *(undefined8 *)(iVar4 + 0x2b80) = 0;
        if (iVar14 != 0) {
            if (*(int64_t *)(iVar14 + 0x4c8) == 0) {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar14 + 0x418) + 0x4c0);
                if (iVar14 != 0) {
                    *(int64_t *)(iVar4 + 0x2b80) = iVar14;
                }
            } else {
                uVar12 = func_0x00018011bfb0(*(int64_t *)(iVar14 + 0x4c8), *(undefined8 *)(iVar4 + 0x118));
                *(undefined8 *)(iVar4 + 0x2b80) = uVar12;
            }
        }
        piVar18 = *(int32_t **)(iVar4 + 0x2900);
        piVar20 = piVar18 + (int64_t)*(int32_t *)(iVar4 + 0x28f8) * 0x10;
        for (; piVar18 != piVar20; piVar18 = piVar18 + 0x10) {
            if (*piVar18 == 1) {
                func_0x000180115650(iVar4, piVar18);
            }
        }
        iVar7 = *(int32_t *)(iVar4 + 0x28fc);
        if (iVar7 < 0) {
            iVar7 = iVar7 + iVar7 / 2;
            iVar8 = iVar6;
            if (0 < iVar7) {
                iVar8 = iVar7;
            }
            func_0x00018011fa30(iVar4 + 0x28f8, iVar8);
        }
        *(undefined4 *)(iVar4 + 0x28f8) = 0;
        if (0 < *(int32_t *)(iVar4 + 0x28e8)) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar4 + 0x28f0) + 8 + (int64_t)iVar6 * 0x10);
                if (((iVar14 != 0) && (*(int64_t *)(iVar14 + 0x18) == 0)) &&
                   ((*(uint32_t *)(iVar14 + 0x10) & 0x400) == 0)) {
                    func_0x000180116d90();
                }
                iVar6 = iVar6 + 1;
            } while (iVar6 < *(int32_t *)(iVar4 + 0x28e8));
        }
    }
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(iVar4 + 2) = 1;
    *(uint32_t *)(iVar14 + 0x2008) = *(uint32_t *)(iVar14 + 0x2008) | 2;
    *(undefined4 *)(iVar14 + 0x202c) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2030) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2010) = 4;
    func_0x0001801019f0(0x1806444f8, 0, 0);
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined4 *)(iVar4 + 0x2a5c) = 0;
    *(undefined2 *)(iVar4 + 0x2a60) = *(undefined2 *)(iVar14 + 0x15b0);
    *(undefined2 *)(iVar4 + 0x2a62) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x148);
    *(undefined2 *)(iVar4 + 0x2a64) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x1e0);
    *(undefined2 *)(iVar4 + 0x2a66) = *(undefined2 *)(iVar14 + 0x20c0);
    *(undefined2 *)(iVar4 + 0x2a68) = *(undefined2 *)(iVar14 + 0x20d0);
    *(undefined2 *)(iVar4 + 0x2a6a) = *(undefined2 *)(iVar14 + 0x20e0);
    *(undefined2 *)(iVar4 + 0x2a6c) = *(undefined2 *)(iVar14 + 0x20f0);
    *(undefined2 *)(iVar4 + 0x2a6e) = *(undefined2 *)(iVar14 + 0x2110);
    *(undefined2 *)(iVar4 + 0x2a70) = *(undefined2 *)(iVar14 + 0x2100);
    *(undefined2 *)(iVar4 + 0x2a72) = *(undefined2 *)(iVar14 + 0x2130);
    *(undefined2 *)(iVar4 + 0x2a74) = *(undefined2 *)(iVar14 + 0x281c);
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar17 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    for (; iVar14 != iVar17; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 1) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fb4b1
// Address: 0x1800fb4b1
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Removing arg arg_2480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24a8h because it doesn't fit into ProtoModel

void fcn.1800fb4a0(undefined8 placeholder_0, int64_t arg2)
{
    float *pfVar1;
    int64_t *piVar2;
    bool bVar3;
    int64_t iVar4;
    char cVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    float *pfVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    int64_t iVar14;
    int64_t *piVar15;
    char *pcVar16;
    int64_t iVar17;
    int32_t *piVar18;
    int64_t iVar19;
    int32_t *piVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    uVar13 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2970);
    while (uVar13 = uVar13 - 1, -1 < (int32_t)uVar13) {
        iVar14 = (uint64_t)uVar13 * 0x20 + *(int64_t *)(iVar4 + 0x2978);
        if (*(int32_t *)(iVar14 + 4) == 7) {
            func_0x000180498030(iVar14, iVar14 + 0x20, 
                                ((int64_t)*(int32_t *)(iVar4 + 0x2970) - (uint64_t)uVar13) * 0x20 + -0x20);
            *(int32_t *)(iVar4 + 0x2970) = *(int32_t *)(iVar4 + 0x2970) + -1;
        }
    }
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    iVar17 = iVar4;
    for (; iVar14 != iVar19; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 0) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    *(undefined4 *)(iVar4 + 0x12d0) = *(undefined4 *)(iVar4 + 0x12cc);
    uVar13 = *(uint32_t *)(iVar17 + 0x30);
    if ((uVar13 & 4) != 0) {
        uVar13 = uVar13 & 0xfffffffb;
        *(undefined *)(iVar17 + 0x7a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 & 8) != 0) {
        uVar13 = uVar13 & 0xfffffff7;
        *(undefined *)(iVar17 + 0x7b) = 0;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xe & 1) != 0) {
        uVar13 = uVar13 & 0xffffbfff;
        *(undefined *)(iVar17 + 0x8a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xf & 1) != 0) {
        uVar13 = uVar13 & 0xffff7fff;
        *(undefined *)(iVar17 + 0x8b) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((*(int64_t *)(iVar17 + 0xc30) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc48) == 0 || (*(int64_t *)(iVar17 + 0xc48) == 0x18011e8a0)))) {
        *(undefined8 *)(iVar17 + 0xc48) = 0x18010a030;
    }
    if ((*(int64_t *)(iVar17 + 0xc38) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc50) == 0 || (*(int64_t *)(iVar17 + 0xc50) == 0x18011e9d0)))) {
        *(undefined8 *)(iVar17 + 0xc50) = 0x18010a050;
    }
    if (((uVar13 >> 10 & 1) != 0) && ((*(uint32_t *)(iVar17 + 0x34) & 0xc00) != 0xc00)) {
        *(uint32_t *)(iVar17 + 0x30) = uVar13 & 0xfffffbff;
    }
    *(undefined4 *)(iVar4 + 0x12cc) = *(undefined4 *)(iVar4 + 0x30);
    if (*(char *)(iVar17 + 0x2928) == '\0') {
        if ((*(int64_t *)(iVar17 + 0x50) != 0) &&
           (iVar14 = func_0x0001800f5b50(*(int64_t *)(iVar17 + 0x50), 0x180625030), iVar14 != 0)) {
            iVar6 = func_0x00018046d704(iVar14);
            if ((iVar6 != -1) && (iVar7 = func_0x000180461598(iVar14, 0, 2), iVar7 == 0)) {
                iVar7 = func_0x00018046d704(iVar14);
                iVar19 = (int64_t)iVar7;
                if ((((iVar7 != -1) && (iVar6 = func_0x000180461598(iVar14, iVar6, 0), iVar6 == 0)) && (iVar19 != -1))
                   && (iVar9 = func_0x00018046d050(iVar19), iVar9 != 0)) {
                    iVar10 = func_0x0001804611b4(iVar9, 1, iVar19, iVar14);
                    if (iVar10 == iVar19) {
                        func_0x00018045ff84(iVar14);
                        if (iVar19 != 0) {
                            func_0x000180112840(iVar9, iVar19);
                        }
                        fcn.180460d90(iVar9);
                    } else {
                        func_0x00018045ff84(iVar14);
                        fcn.180460d90(iVar9);
                    }
                    goto code_r0x0001800fb715;
                }
            }
            func_0x00018045ff84(iVar14);
        }
code_r0x0001800fb715:
        *(undefined *)(iVar17 + 0x2928) = 1;
    }
    iVar6 = 0;
    if ((0.0 < *(float *)(iVar17 + 0x292c)) &&
       (fVar21 = *(float *)(iVar17 + 0x292c) - *(float *)(iVar17 + 0x48), *(float *)(iVar17 + 0x292c) = fVar21,
       fVar21 <= 0.0)) {
        if (*(int64_t *)(iVar17 + 0x50) == 0) {
            *(undefined *)(iVar17 + 0xec) = 1;
        } else {
            func_0x000180112a70();
        }
        *(undefined4 *)(iVar17 + 0x292c) = 0;
    }
    *(int32_t *)(iVar4 + 4) = *(int32_t *)(iVar4 + 4) + 1;
    *(undefined2 *)(iVar4 + 0x281e) = 0;
    *(undefined4 *)(iVar4 + 0x15d0) = 0;
    *(double *)(iVar4 + 0x18) = (double)*(float *)(iVar4 + 0x48) + *(double *)(iVar4 + 0x18);
    iVar7 = *(int32_t *)(iVar4 + 0x283c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(iVar4 + 0x2838, iVar8);
    }
    fVar21 = 3.402823e+38;
    *(undefined4 *)(iVar4 + 0x2838) = 0;
    *(float *)(iVar4 + 0x2c80) =
         (*(float *)(iVar4 + 0x48) - *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4)) +
         *(float *)(iVar4 + 0x2c80);
    *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4) = *(float *)(iVar4 + 0x48);
    iVar8 = *(int32_t *)(iVar4 + 0x2c7c) + 1;
    *(int32_t *)(iVar4 + 0x2c78) = (*(int32_t *)(iVar4 + 0x2c78) + 1) % 0x3c;
    iVar7 = 0x3c;
    if (iVar8 < 0x3c) {
        iVar7 = iVar8;
    }
    *(int32_t *)(iVar4 + 0x2c7c) = iVar7;
    if (*(float *)(iVar4 + 0x2c80) <= 0.0) {
        fVar22 = 3.402823e+38;
    } else {
        fVar22 = 1.0 / (*(float *)(iVar4 + 0x2c80) / (float)iVar7);
    }
    *(float *)(iVar4 + 0xf0) = fVar22;
    iVar7 = *(int32_t *)(iVar4 + 0x156c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f9d0(iVar4 + 0x1568, iVar8);
    }
    *(undefined4 *)(iVar4 + 0x1568) = 0;
    func_0x0001801093d0(*(undefined *)(iVar4 + 0x8e));
    func_0x000180113b10();
    func_0x000180106aa0();
    fcn.1800fb280();
    func_0x000180106fa0();
    *(undefined *)(iVar4 + 1) = 1;
    piVar15 = *(int64_t **)(iVar4 + 0x2158);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x2150);
    iVar14 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar14, piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        *(undefined8 *)(iVar14 + 0x40) = 0;
        *(undefined *)(iVar14 + 200) = 0;
        iVar14 = *(int64_t *)0x180781f28;
    }
    if ((*(char *)(iVar4 + 0x2400) != '\0') &&
       (iVar7 = *(int32_t *)(iVar4 + 0x241c), iVar7 == *(int32_t *)(iVar4 + 0x1654))) {
        if (*(int32_t *)(iVar14 + 0x1654) == iVar7) {
            *(int32_t *)(iVar14 + 0x1658) = iVar7;
        }
        if (*(int32_t *)(iVar14 + 0x1684) == iVar7) {
            *(undefined *)(iVar14 + 0x168d) = 1;
        }
    }
    if ((((*(char *)(iVar4 + 0xb5) != '\0') && (*(char *)(iVar4 + 0x138) != '\0')) ||
        (*(undefined4 *)(iVar4 + 0x1634) = 0, *(char *)(iVar4 + 0xb5) != '\0')) && (1 < *(int32_t *)(iVar4 + 0x1644))) {
        *(undefined4 *)(iVar4 + 0x1634) = *(undefined4 *)(iVar4 + 0x1640);
    }
    piVar18 = (int32_t *)(iVar4 + 0x163c);
    if (*(int32_t *)(iVar4 + 0x1640) == 0) {
        *(undefined4 *)(iVar4 + 0x1648) = 0;
code_r0x0001800fb97d:
        *(undefined4 *)(iVar4 + 0x164c) = 0;
    } else if ((*piVar18 != 0) && (*(int32_t *)(iVar4 + 0x1654) == *piVar18)) goto code_r0x0001800fb97d;
    iVar7 = *piVar18;
    piVar20 = (int32_t *)(iVar4 + 0x1654);
    fVar22 = *(float *)(iVar4 + 0x48);
    if ((iVar7 != 0) && (*(float *)(iVar4 + 0x1648) = fVar22 + *(float *)(iVar4 + 0x1648), *piVar20 != iVar7)) {
        *(float *)(iVar4 + 0x164c) = fVar22 + *(float *)(iVar4 + 0x164c);
    }
    *piVar18 = 0;
    iVar8 = *piVar20;
    *(int32_t *)(iVar4 + 0x1640) = iVar7;
    *(undefined4 *)(iVar4 + 0x1644) = 0;
    *(undefined2 *)(iVar4 + 0x1650) = 0;
    if (((iVar8 != 0) && (*(int32_t *)(iVar4 + 0x1658) != iVar8)) && (*(int32_t *)(iVar4 + 0x1680) == iVar8)) {
        fcn.1800f9f30(0, 0);
        fVar22 = *(float *)(iVar4 + 0x48);
    }
    iVar7 = *piVar20;
    if (iVar7 != 0) {
        *(float *)(iVar4 + 0x165c) = fVar22 + *(float *)(iVar4 + 0x165c);
    }
    *(int32_t *)(iVar4 + 0x1680) = iVar7;
    *(int32_t *)(iVar4 + 0x1658) = 0;
    *(undefined *)(iVar4 + 0x1665) = 0;
    *(undefined *)(iVar4 + 0x1660) = 0;
    *(float *)(iVar4 + 0x169c) = fVar22 + *(float *)(iVar4 + 0x169c);
    if ((*(int32_t *)(iVar4 + 0x2780) != 0) && (iVar7 != *(int32_t *)(iVar4 + 0x2780))) {
        *(undefined4 *)(iVar4 + 0x2780) = 0;
    }
    if ((*(int32_t *)(iVar4 + 0x277c) != 0) && (*(int32_t *)(iVar4 + 0x277c) != *(int32_t *)(iVar4 + 0x1684))) {
        *(undefined4 *)(iVar4 + 0x277c) = 0;
    }
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x1f68) = 0;
        *(undefined *)(iVar4 + 0x1f6c) = 0;
    }
    if (*(int32_t *)(iVar4 + 0x1688) < *(int32_t *)(iVar4 + 4)) {
        *(undefined4 *)(iVar4 + 0x1684) = 0;
    }
    iVar7 = *(int32_t *)(iVar4 + 0x2638);
    *(undefined *)(iVar4 + 0x168d) = 0;
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x2648) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(int32_t *)(iVar4 + 0x2648) = iVar7;
    }
    if (*(int64_t *)(iVar4 + 0x15e8) == 0) {
        *(undefined4 *)(iVar4 + 0x264c) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(undefined4 *)(iVar4 + 0x264c) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x15e8) + 0x10);
    }
    *(int32_t *)(iVar4 + 0x263c) = iVar7;
    if (iVar7 == 0) {
        if (0.0 < *(float *)(iVar4 + 0x2640)) {
            fVar23 = fVar22 + *(float *)(iVar4 + 0x2644);
            *(float *)(iVar4 + 0x2644) = fVar23;
            fVar24 = 0.25;
            if (0.25 <= fVar22 + fVar22) {
                fVar24 = fVar22 + fVar22;
            }
            if (fVar24 <= fVar23) {
                *(undefined8 *)(iVar4 + 0x2640) = 0;
            }
        }
    } else {
        *(undefined4 *)(iVar4 + 0x2644) = 0;
        *(undefined4 *)(iVar4 + 0x2638) = 0;
        *(float *)(iVar4 + 0x2640) = *(float *)(iVar4 + 0x2640) + fVar22;
    }
    func_0x000180108270();
    *(undefined4 *)(iVar4 + 0x2488) = *(undefined4 *)(iVar4 + 0x2484);
    *(undefined4 *)(iVar4 + 0x247c) = *(undefined4 *)(iVar4 + 0x2478);
    *(undefined4 *)(iVar4 + 0x2478) = 0;
    *(undefined8 *)(iVar4 + 0x2480) = 0x7f7fffff;
    *(undefined2 *)(iVar4 + 0x2401) = 0;
    *(undefined4 *)(iVar4 + 0x2490) = 0;
    if (*(char *)(iVar4 + 0x2400) != '\0') {
        if (*piVar20 == 0) {
            pcVar16 = "#DragDropCancelHandler";
            cVar5 = '#';
            do {
                if (((cVar5 == '#') && (*pcVar16 == '#')) && (pcVar16[1] == '#')) {
                    pcVar16 = pcVar16 + 2;
                }
                cVar5 = *pcVar16;
                pcVar16 = pcVar16 + 1;
            } while (cVar5 != '\0');
        }
        cVar5 = func_0x000180109d80();
        if (cVar5 != '\0') {
            fcn.1800f9f30(0, 0);
            func_0x0001801120a0();
        }
    }
    *(undefined8 *)(iVar4 + 0x2820) = 0;
    func_0x00018010f2f0();
    func_0x000180108830();
    func_0x000180114da0(iVar4);
    if ((*(char *)(iVar4 + 0x20b9) != '\0') || (*(float *)(iVar4 + 0x98) < 0.0)) {
        bVar3 = true;
    } else {
        bVar3 = false;
        fVar21 = (float)*(double *)(iVar4 + 0x18) - *(float *)(iVar4 + 0x98);
    }
    piVar15 = *(int64_t **)(iVar4 + 0x1588);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x1580);
    for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        cVar5 = *(char *)(iVar14 + 0x109);
        *(char *)(iVar14 + 0x10a) = cVar5;
        *(undefined *)(iVar14 + 0x109) = 0;
        *(undefined *)(iVar14 + 0x10b) = 0;
        *(undefined2 *)(iVar14 + 0x11a) = *(undefined2 *)(iVar14 + 0x118);
        *(undefined2 *)(iVar14 + 0x118) = 0;
        if (((cVar5 == '\0') || (bVar3)) &&
           ((*(char *)(iVar14 + 0x494) == '\0' &&
            (*(float *)(iVar14 + 0x2e8) <= fVar21 && fVar21 != *(float *)(iVar14 + 0x2e8))))) {
            iVar17 = *(int64_t *)(iVar14 + 800);
            *(undefined *)(iVar14 + 0x494) = 1;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x10) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x14);
            if (iVar8 < *(int32_t *)(iVar17 + 0x14)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x48c) = iVar7;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x20) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x24);
            if (iVar8 < *(int32_t *)(iVar17 + 0x24)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x490) = iVar7;
            if (*(int64_t *)(iVar14 + 0x150) != 0) {
                *(undefined8 *)(iVar14 + 0x148) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x150) = 0;
            }
            func_0x000180124110(*(undefined8 *)(iVar14 + 800));
            if (*(int64_t *)(iVar14 + 0x1f8) != 0) {
                *(undefined8 *)(iVar14 + 0x1f0) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x1f8) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x250) != 0) {
                *(undefined8 *)(iVar14 + 0x248) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x250) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x260) != 0) {
                *(undefined8 *)(iVar14 + 600) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x260) = 0;
            }
        }
    }
    fcn.1800fae50(iVar4 + 0x118);
    iVar17 = *(int64_t *)0x180781f28;
    iVar14 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1600);
    if (iVar14 == 0) {
        if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) == 0) ||
           (iVar7 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1654),
           *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) + 0xc4) != iVar7)) goto code_r0x0001800fbfc6;
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar7;
        if (*(int32_t *)(iVar17 + 0x1684) == iVar7) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') goto code_r0x0001800fbfc6;
    } else {
        piVar18 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1654);
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = *piVar18;
        if (*(int32_t *)(iVar17 + 0x1684) == *piVar18) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        iVar14 = *(int64_t *)(iVar14 + 0x428);
        if ((*(char *)(iVar14 + 0x10a) == '\0') && (*(char *)(iVar14 + 0x109) == '\0')) {
            bVar3 = true;
        } else {
            bVar3 = false;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') {
            pfVar1 = (float *)(iVar17 + 0x118);
            pfVar11 = pfVar1;
            if (pfVar1 == (float *)0x0) {
                pfVar11 = (float *)(*(int64_t *)0x180781f28 + 0x118);
            }
            if (((-256000.0 <= *pfVar11) && (-256000.0 <= pfVar11[1])) && (!bVar3)) {
                fVar22 = *pfVar1 - *(float *)(iVar17 + 0x166c);
                fVar24 = *(float *)(iVar17 + 0x11c) - *(float *)(iVar17 + 0x1670);
                var_8h._0_4_ = fVar22;
                var_8h._4_4_ = fVar24;
                if ((*(float *)(iVar14 + 0x60) != fVar22) || (*(float *)(iVar14 + 100) != fVar24)) {
                    func_0x000180106470(iVar14, &var_8h, 1);
                    if ((*(int64_t *)(iVar14 + 0x48) != 0) && (*(char *)(iVar14 + 0x108) != '\0')) {
                        *(uint64_t *)(*(int64_t *)(iVar14 + 0x48) + 8) = CONCAT44(fVar24, fVar22);
                        iVar14 = *(int64_t *)(iVar14 + 0x48);
                        *(float *)(iVar14 + 0x20) = *(float *)(iVar14 + 0x148) + *(float *)(iVar14 + 8);
                        *(float *)(iVar14 + 0x24) = *(float *)(iVar14 + 0x14c) + *(float *)(iVar14 + 0xc);
                        fVar24 = (*(float *)(iVar14 + 0x14) - *(float *)(iVar14 + 0x14c)) - *(float *)(iVar14 + 0x154);
                        fVar23 = (*(float *)(iVar14 + 0x10) - *(float *)(iVar14 + 0x148)) - *(float *)(iVar14 + 0x150);
                        fVar22 = 0.0;
                        if (0.0 <= fVar24) {
                            fVar22 = fVar24;
                        }
                        fVar24 = 0.0;
                        if (0.0 <= fVar23) {
                            fVar24 = fVar23;
                        }
                        *(float *)(iVar14 + 0x2c) = fVar22;
                        *(float *)(iVar14 + 0x28) = fVar24;
                    }
                }
                func_0x00018010e050(*(undefined8 *)(iVar17 + 0x1600), 0);
                goto code_r0x0001800fbfc6;
            }
        }
        fcn.1800fac90();
    }
    fcn.1800f9f30(0, 0);
code_r0x0001800fbfc6:
    uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    if (-1 < (int32_t)uVar13) {
        do {
            iVar14 = *(int64_t *)((uint64_t)uVar13 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar14 != 0) && ((*(uint32_t *)(iVar14 + 0x14) & 0x8000000) != 0)) goto code_r0x0001800fc015;
            uVar13 = uVar13 - 1;
        } while (-1 < (int32_t)uVar13);
    }
    if ((*(int64_t *)(iVar4 + 0x23c0) == 0) || (*(float *)(iVar4 + 0x23dc) <= 0.0)) {
        fVar22 = *(float *)(iVar4 + 0x23fc) - *(float *)(iVar4 + 0x48) * 10.0;
        if (fVar22 <= 0.0) {
            fVar22 = 0.0;
        }
    } else {
code_r0x0001800fc015:
        fVar22 = *(float *)(iVar4 + 0x48) * 6.0 + *(float *)(iVar4 + 0x23fc);
        if (1.0 <= fVar22) {
            fVar22 = 1.0;
        }
    }
    *(float *)(iVar4 + 0x23fc) = fVar22;
    *(undefined4 *)(iVar4 + 0x2650) = 0;
    *(undefined4 *)(iVar4 + 0x28c4) = *(undefined4 *)(iVar4 + 0x28b0);
    *(undefined4 *)(iVar4 + 0x28c8) = *(undefined4 *)(iVar4 + 0x28b4);
    *(undefined4 *)(iVar4 + 0x28cc) = *(undefined4 *)(iVar4 + 0x28b8);
    *(undefined4 *)(iVar4 + 0x28d0) = *(undefined4 *)(iVar4 + 0x28bc);
    *(undefined4 *)(iVar4 + 0x28d4) = *(undefined4 *)(iVar4 + 0x28c0);
    *(undefined8 *)(iVar4 + 0x2c88) = 0xffffffffffffffff;
    *(undefined4 *)(iVar4 + 0x2c84) = 0xffffffff;
    *(undefined2 *)(iVar4 + 0x28b0) = 0;
    func_0x000180108de0();
    iVar7 = iVar6;
    if (0 < *(int32_t *)(iVar4 + 0x2518)) {
        do {
            iVar14 = *(int64_t *)0x180781f28;
            fVar22 = *(float *)(*(int64_t *)(iVar4 + 0x2520) + (int64_t)iVar7 * 4);
            if ((0.0 <= fVar22) && (fVar22 < fVar21)) {
                iVar17 = (int64_t)iVar7 * 0x250 + *(int64_t *)(iVar4 + 0x24f8);
                *(undefined8 *)(iVar17 + 0x1f0) = 0;
                if (*(int64_t *)(iVar17 + 0x1e8) != 0) {
                    *(undefined8 *)(iVar17 + 0x1e0) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x1e8) = 0;
                }
                *(undefined *)(iVar17 + 0x23c) = 1;
                if (*(int64_t *)(iVar17 + 0x198) != 0) {
                    *(undefined8 *)(iVar17 + 400) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x198) = 0;
                }
                *(undefined *)(iVar17 + 0x24b) = 1;
                iVar8 = iVar6;
                if (0 < *(int32_t *)(iVar17 + 0x6c)) {
                    do {
                        iVar19 = (int64_t)iVar8;
                        iVar8 = iVar8 + 1;
                        *(undefined2 *)(iVar19 * 0x74 + 0x54 + *(int64_t *)(iVar17 + 0x18)) = 0xffff;
                    } while (iVar8 < *(int32_t *)(iVar17 + 0x6c));
                }
                *(undefined4 *)
                 (*(int64_t *)(iVar14 + 0x2520) +
                 (int64_t)(int32_t)((iVar17 - *(int64_t *)(iVar14 + 0x24f8)) / 0x250) * 4) = 0xbf800000;
            }
            iVar7 = iVar7 + 1;
        } while (iVar7 < *(int32_t *)(iVar4 + 0x2518));
    }
    iVar14 = *(int64_t *)(iVar4 + 0x24e8);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x24e0) * 0x88 + iVar14;
    iVar17 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar17, iVar14 != iVar19; iVar14 = iVar14 + 0x88) {
        if ((0.0 <= *(float *)(iVar14 + 8)) && (*(float *)(iVar14 + 8) < fVar21)) {
            func_0x000180126a10(iVar14 + 0x28);
            *(undefined4 *)(iVar14 + 8) = 0xbf800000;
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    if (*(char *)(iVar4 + 0x20b9) != '\0') {
        if (*(int64_t *)(iVar17 + 0x2108) != 0) {
            *(undefined8 *)(iVar17 + 0x2100) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2108) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x2118) != 0) {
            *(undefined8 *)(iVar17 + 0x2110) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2118) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x26e8) != 0) {
            *(undefined8 *)(iVar17 + 0x26e0) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x26e8) = 0;
        }
        *(undefined4 *)(iVar17 + 0x26f0) = 0;
        *(undefined4 *)(iVar17 + 0x25f8) = 0;
        func_0x00018011ee60(iVar17 + 0x2600);
        func_0x0001801388c0();
        piVar15 = *(int64_t **)(iVar17 + 0x12e0);
        piVar2 = piVar15 + *(int32_t *)(iVar17 + 0x12d8);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            iVar14 = *piVar15;
            iVar17 = *(int64_t *)(iVar14 + 0x2b0);
            func_0x000180129630(iVar14, 1);
            func_0x000180129f40(&var_8h, iVar14);
            if (((*(int32_t *)(iVar17 + 0x9c) != 0) || ((float)var_8h != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x1c))
                ) || (var_8h._4_4_ != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x20))) {
                func_0x0001801299b0(iVar14);
            }
        }
    }
    *(undefined *)(iVar4 + 0x20b9) = 0;
    if ((*(int64_t *)(iVar4 + 0x21d8) != 0) && (*(char *)(*(int64_t *)(iVar4 + 0x21d8) + 0x10a) == '\0')) {
        uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1590) - 1;
        if (-1 < (int32_t)uVar13) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1598) + (uint64_t)uVar13 * 8);
                if (((iVar14 != 0) && (*(char *)(iVar14 + 0x10a) != '\0')) &&
                   ((*(uint32_t *)(iVar14 + 0x14) & 0x10200) != 0x10200)) goto code_r0x0001800fc388;
                uVar13 = uVar13 - 1;
            } while (-1 < (int32_t)uVar13);
        }
        iVar14 = 0;
code_r0x0001800fc388:
        func_0x00018010e050(iVar14, 1);
    }
    func_0x00018011f370(iVar4 + 0x15b0, 0);
    iVar7 = *(int32_t *)(iVar4 + 0x2134);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f970(iVar4 + 0x2130, iVar8);
    }
    piVar18 = (int32_t *)(iVar4 + 0x2100);
    *(undefined4 *)(iVar4 + 0x2130) = 0;
    iVar7 = *(int32_t *)(iVar4 + 0x2104);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(piVar18, iVar8);
    }
    *piVar18 = 0;
    if (*(int32_t *)(iVar4 + 0x2104) == 0) {
        func_0x00018011fb10(piVar18, 8);
    }
    *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)*piVar18 * 4) = 0x10;
    iVar7 = *piVar18;
    *piVar18 = iVar7 + 1;
    *(undefined4 *)(iVar4 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)iVar7 * 4);
    func_0x00018011f140(iVar4 + 0x2110, 0);
    if ((*(uint8_t *)(iVar4 + 0x30) & 0x80) != 0) {
        iVar14 = *(int64_t *)(iVar4 + 0x15f0);
        *(undefined8 *)(iVar4 + 0x2b80) = 0;
        if (iVar14 != 0) {
            if (*(int64_t *)(iVar14 + 0x4c8) == 0) {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar14 + 0x418) + 0x4c0);
                if (iVar14 != 0) {
                    *(int64_t *)(iVar4 + 0x2b80) = iVar14;
                }
            } else {
                uVar12 = func_0x00018011bfb0(*(int64_t *)(iVar14 + 0x4c8), *(undefined8 *)(iVar4 + 0x118));
                *(undefined8 *)(iVar4 + 0x2b80) = uVar12;
            }
        }
        piVar18 = *(int32_t **)(iVar4 + 0x2900);
        piVar20 = piVar18 + (int64_t)*(int32_t *)(iVar4 + 0x28f8) * 0x10;
        for (; piVar18 != piVar20; piVar18 = piVar18 + 0x10) {
            if (*piVar18 == 1) {
                func_0x000180115650(iVar4, piVar18);
            }
        }
        iVar7 = *(int32_t *)(iVar4 + 0x28fc);
        if (iVar7 < 0) {
            iVar7 = iVar7 + iVar7 / 2;
            iVar8 = iVar6;
            if (0 < iVar7) {
                iVar8 = iVar7;
            }
            func_0x00018011fa30(iVar4 + 0x28f8, iVar8);
        }
        *(undefined4 *)(iVar4 + 0x28f8) = 0;
        if (0 < *(int32_t *)(iVar4 + 0x28e8)) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar4 + 0x28f0) + 8 + (int64_t)iVar6 * 0x10);
                if (((iVar14 != 0) && (*(int64_t *)(iVar14 + 0x18) == 0)) &&
                   ((*(uint32_t *)(iVar14 + 0x10) & 0x400) == 0)) {
                    func_0x000180116d90();
                }
                iVar6 = iVar6 + 1;
            } while (iVar6 < *(int32_t *)(iVar4 + 0x28e8));
        }
    }
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(iVar4 + 2) = 1;
    *(uint32_t *)(iVar14 + 0x2008) = *(uint32_t *)(iVar14 + 0x2008) | 2;
    *(undefined4 *)(iVar14 + 0x202c) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2030) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2010) = 4;
    func_0x0001801019f0(0x1806444f8, 0, 0);
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined4 *)(iVar4 + 0x2a5c) = 0;
    *(undefined2 *)(iVar4 + 0x2a60) = *(undefined2 *)(iVar14 + 0x15b0);
    *(undefined2 *)(iVar4 + 0x2a62) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x148);
    *(undefined2 *)(iVar4 + 0x2a64) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x1e0);
    *(undefined2 *)(iVar4 + 0x2a66) = *(undefined2 *)(iVar14 + 0x20c0);
    *(undefined2 *)(iVar4 + 0x2a68) = *(undefined2 *)(iVar14 + 0x20d0);
    *(undefined2 *)(iVar4 + 0x2a6a) = *(undefined2 *)(iVar14 + 0x20e0);
    *(undefined2 *)(iVar4 + 0x2a6c) = *(undefined2 *)(iVar14 + 0x20f0);
    *(undefined2 *)(iVar4 + 0x2a6e) = *(undefined2 *)(iVar14 + 0x2110);
    *(undefined2 *)(iVar4 + 0x2a70) = *(undefined2 *)(iVar14 + 0x2100);
    *(undefined2 *)(iVar4 + 0x2a72) = *(undefined2 *)(iVar14 + 0x2130);
    *(undefined2 *)(iVar4 + 0x2a74) = *(undefined2 *)(iVar14 + 0x281c);
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar17 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    for (; iVar14 != iVar17; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 1) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fb4cd
// Address: 0x1800fb4cd
// Size: 1971 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Removing arg arg_2480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24a8h because it doesn't fit into ProtoModel

void fcn.1800fb4a0(undefined8 placeholder_0, int64_t arg2)
{
    float *pfVar1;
    int64_t *piVar2;
    bool bVar3;
    int64_t iVar4;
    char cVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    float *pfVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    int64_t iVar14;
    int64_t *piVar15;
    char *pcVar16;
    int64_t iVar17;
    int32_t *piVar18;
    int64_t iVar19;
    int32_t *piVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    uVar13 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2970);
    while (uVar13 = uVar13 - 1, -1 < (int32_t)uVar13) {
        iVar14 = (uint64_t)uVar13 * 0x20 + *(int64_t *)(iVar4 + 0x2978);
        if (*(int32_t *)(iVar14 + 4) == 7) {
            func_0x000180498030(iVar14, iVar14 + 0x20, 
                                ((int64_t)*(int32_t *)(iVar4 + 0x2970) - (uint64_t)uVar13) * 0x20 + -0x20);
            *(int32_t *)(iVar4 + 0x2970) = *(int32_t *)(iVar4 + 0x2970) + -1;
        }
    }
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    iVar17 = iVar4;
    for (; iVar14 != iVar19; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 0) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    *(undefined4 *)(iVar4 + 0x12d0) = *(undefined4 *)(iVar4 + 0x12cc);
    uVar13 = *(uint32_t *)(iVar17 + 0x30);
    if ((uVar13 & 4) != 0) {
        uVar13 = uVar13 & 0xfffffffb;
        *(undefined *)(iVar17 + 0x7a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 & 8) != 0) {
        uVar13 = uVar13 & 0xfffffff7;
        *(undefined *)(iVar17 + 0x7b) = 0;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xe & 1) != 0) {
        uVar13 = uVar13 & 0xffffbfff;
        *(undefined *)(iVar17 + 0x8a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xf & 1) != 0) {
        uVar13 = uVar13 & 0xffff7fff;
        *(undefined *)(iVar17 + 0x8b) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((*(int64_t *)(iVar17 + 0xc30) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc48) == 0 || (*(int64_t *)(iVar17 + 0xc48) == 0x18011e8a0)))) {
        *(undefined8 *)(iVar17 + 0xc48) = 0x18010a030;
    }
    if ((*(int64_t *)(iVar17 + 0xc38) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc50) == 0 || (*(int64_t *)(iVar17 + 0xc50) == 0x18011e9d0)))) {
        *(undefined8 *)(iVar17 + 0xc50) = 0x18010a050;
    }
    if (((uVar13 >> 10 & 1) != 0) && ((*(uint32_t *)(iVar17 + 0x34) & 0xc00) != 0xc00)) {
        *(uint32_t *)(iVar17 + 0x30) = uVar13 & 0xfffffbff;
    }
    *(undefined4 *)(iVar4 + 0x12cc) = *(undefined4 *)(iVar4 + 0x30);
    if (*(char *)(iVar17 + 0x2928) == '\0') {
        if ((*(int64_t *)(iVar17 + 0x50) != 0) &&
           (iVar14 = func_0x0001800f5b50(*(int64_t *)(iVar17 + 0x50), 0x180625030), iVar14 != 0)) {
            iVar6 = func_0x00018046d704(iVar14);
            if ((iVar6 != -1) && (iVar7 = func_0x000180461598(iVar14, 0, 2), iVar7 == 0)) {
                iVar7 = func_0x00018046d704(iVar14);
                iVar19 = (int64_t)iVar7;
                if ((((iVar7 != -1) && (iVar6 = func_0x000180461598(iVar14, iVar6, 0), iVar6 == 0)) && (iVar19 != -1))
                   && (iVar9 = func_0x00018046d050(iVar19), iVar9 != 0)) {
                    iVar10 = func_0x0001804611b4(iVar9, 1, iVar19, iVar14);
                    if (iVar10 == iVar19) {
                        func_0x00018045ff84(iVar14);
                        if (iVar19 != 0) {
                            func_0x000180112840(iVar9, iVar19);
                        }
                        fcn.180460d90(iVar9);
                    } else {
                        func_0x00018045ff84(iVar14);
                        fcn.180460d90(iVar9);
                    }
                    goto code_r0x0001800fb715;
                }
            }
            func_0x00018045ff84(iVar14);
        }
code_r0x0001800fb715:
        *(undefined *)(iVar17 + 0x2928) = 1;
    }
    iVar6 = 0;
    if ((0.0 < *(float *)(iVar17 + 0x292c)) &&
       (fVar21 = *(float *)(iVar17 + 0x292c) - *(float *)(iVar17 + 0x48), *(float *)(iVar17 + 0x292c) = fVar21,
       fVar21 <= 0.0)) {
        if (*(int64_t *)(iVar17 + 0x50) == 0) {
            *(undefined *)(iVar17 + 0xec) = 1;
        } else {
            func_0x000180112a70();
        }
        *(undefined4 *)(iVar17 + 0x292c) = 0;
    }
    *(int32_t *)(iVar4 + 4) = *(int32_t *)(iVar4 + 4) + 1;
    *(undefined2 *)(iVar4 + 0x281e) = 0;
    *(undefined4 *)(iVar4 + 0x15d0) = 0;
    *(double *)(iVar4 + 0x18) = (double)*(float *)(iVar4 + 0x48) + *(double *)(iVar4 + 0x18);
    iVar7 = *(int32_t *)(iVar4 + 0x283c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(iVar4 + 0x2838, iVar8);
    }
    fVar21 = 3.402823e+38;
    *(undefined4 *)(iVar4 + 0x2838) = 0;
    *(float *)(iVar4 + 0x2c80) =
         (*(float *)(iVar4 + 0x48) - *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4)) +
         *(float *)(iVar4 + 0x2c80);
    *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4) = *(float *)(iVar4 + 0x48);
    iVar8 = *(int32_t *)(iVar4 + 0x2c7c) + 1;
    *(int32_t *)(iVar4 + 0x2c78) = (*(int32_t *)(iVar4 + 0x2c78) + 1) % 0x3c;
    iVar7 = 0x3c;
    if (iVar8 < 0x3c) {
        iVar7 = iVar8;
    }
    *(int32_t *)(iVar4 + 0x2c7c) = iVar7;
    if (*(float *)(iVar4 + 0x2c80) <= 0.0) {
        fVar22 = 3.402823e+38;
    } else {
        fVar22 = 1.0 / (*(float *)(iVar4 + 0x2c80) / (float)iVar7);
    }
    *(float *)(iVar4 + 0xf0) = fVar22;
    iVar7 = *(int32_t *)(iVar4 + 0x156c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f9d0(iVar4 + 0x1568, iVar8);
    }
    *(undefined4 *)(iVar4 + 0x1568) = 0;
    func_0x0001801093d0(*(undefined *)(iVar4 + 0x8e));
    func_0x000180113b10();
    func_0x000180106aa0();
    fcn.1800fb280();
    func_0x000180106fa0();
    *(undefined *)(iVar4 + 1) = 1;
    piVar15 = *(int64_t **)(iVar4 + 0x2158);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x2150);
    iVar14 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar14, piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        *(undefined8 *)(iVar14 + 0x40) = 0;
        *(undefined *)(iVar14 + 200) = 0;
        iVar14 = *(int64_t *)0x180781f28;
    }
    if ((*(char *)(iVar4 + 0x2400) != '\0') &&
       (iVar7 = *(int32_t *)(iVar4 + 0x241c), iVar7 == *(int32_t *)(iVar4 + 0x1654))) {
        if (*(int32_t *)(iVar14 + 0x1654) == iVar7) {
            *(int32_t *)(iVar14 + 0x1658) = iVar7;
        }
        if (*(int32_t *)(iVar14 + 0x1684) == iVar7) {
            *(undefined *)(iVar14 + 0x168d) = 1;
        }
    }
    if ((((*(char *)(iVar4 + 0xb5) != '\0') && (*(char *)(iVar4 + 0x138) != '\0')) ||
        (*(undefined4 *)(iVar4 + 0x1634) = 0, *(char *)(iVar4 + 0xb5) != '\0')) && (1 < *(int32_t *)(iVar4 + 0x1644))) {
        *(undefined4 *)(iVar4 + 0x1634) = *(undefined4 *)(iVar4 + 0x1640);
    }
    piVar18 = (int32_t *)(iVar4 + 0x163c);
    if (*(int32_t *)(iVar4 + 0x1640) == 0) {
        *(undefined4 *)(iVar4 + 0x1648) = 0;
code_r0x0001800fb97d:
        *(undefined4 *)(iVar4 + 0x164c) = 0;
    } else if ((*piVar18 != 0) && (*(int32_t *)(iVar4 + 0x1654) == *piVar18)) goto code_r0x0001800fb97d;
    iVar7 = *piVar18;
    piVar20 = (int32_t *)(iVar4 + 0x1654);
    fVar22 = *(float *)(iVar4 + 0x48);
    if ((iVar7 != 0) && (*(float *)(iVar4 + 0x1648) = fVar22 + *(float *)(iVar4 + 0x1648), *piVar20 != iVar7)) {
        *(float *)(iVar4 + 0x164c) = fVar22 + *(float *)(iVar4 + 0x164c);
    }
    *piVar18 = 0;
    iVar8 = *piVar20;
    *(int32_t *)(iVar4 + 0x1640) = iVar7;
    *(undefined4 *)(iVar4 + 0x1644) = 0;
    *(undefined2 *)(iVar4 + 0x1650) = 0;
    if (((iVar8 != 0) && (*(int32_t *)(iVar4 + 0x1658) != iVar8)) && (*(int32_t *)(iVar4 + 0x1680) == iVar8)) {
        fcn.1800f9f30(0, 0);
        fVar22 = *(float *)(iVar4 + 0x48);
    }
    iVar7 = *piVar20;
    if (iVar7 != 0) {
        *(float *)(iVar4 + 0x165c) = fVar22 + *(float *)(iVar4 + 0x165c);
    }
    *(int32_t *)(iVar4 + 0x1680) = iVar7;
    *(int32_t *)(iVar4 + 0x1658) = 0;
    *(undefined *)(iVar4 + 0x1665) = 0;
    *(undefined *)(iVar4 + 0x1660) = 0;
    *(float *)(iVar4 + 0x169c) = fVar22 + *(float *)(iVar4 + 0x169c);
    if ((*(int32_t *)(iVar4 + 0x2780) != 0) && (iVar7 != *(int32_t *)(iVar4 + 0x2780))) {
        *(undefined4 *)(iVar4 + 0x2780) = 0;
    }
    if ((*(int32_t *)(iVar4 + 0x277c) != 0) && (*(int32_t *)(iVar4 + 0x277c) != *(int32_t *)(iVar4 + 0x1684))) {
        *(undefined4 *)(iVar4 + 0x277c) = 0;
    }
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x1f68) = 0;
        *(undefined *)(iVar4 + 0x1f6c) = 0;
    }
    if (*(int32_t *)(iVar4 + 0x1688) < *(int32_t *)(iVar4 + 4)) {
        *(undefined4 *)(iVar4 + 0x1684) = 0;
    }
    iVar7 = *(int32_t *)(iVar4 + 0x2638);
    *(undefined *)(iVar4 + 0x168d) = 0;
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x2648) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(int32_t *)(iVar4 + 0x2648) = iVar7;
    }
    if (*(int64_t *)(iVar4 + 0x15e8) == 0) {
        *(undefined4 *)(iVar4 + 0x264c) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(undefined4 *)(iVar4 + 0x264c) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x15e8) + 0x10);
    }
    *(int32_t *)(iVar4 + 0x263c) = iVar7;
    if (iVar7 == 0) {
        if (0.0 < *(float *)(iVar4 + 0x2640)) {
            fVar23 = fVar22 + *(float *)(iVar4 + 0x2644);
            *(float *)(iVar4 + 0x2644) = fVar23;
            fVar24 = 0.25;
            if (0.25 <= fVar22 + fVar22) {
                fVar24 = fVar22 + fVar22;
            }
            if (fVar24 <= fVar23) {
                *(undefined8 *)(iVar4 + 0x2640) = 0;
            }
        }
    } else {
        *(undefined4 *)(iVar4 + 0x2644) = 0;
        *(undefined4 *)(iVar4 + 0x2638) = 0;
        *(float *)(iVar4 + 0x2640) = *(float *)(iVar4 + 0x2640) + fVar22;
    }
    func_0x000180108270();
    *(undefined4 *)(iVar4 + 0x2488) = *(undefined4 *)(iVar4 + 0x2484);
    *(undefined4 *)(iVar4 + 0x247c) = *(undefined4 *)(iVar4 + 0x2478);
    *(undefined4 *)(iVar4 + 0x2478) = 0;
    *(undefined8 *)(iVar4 + 0x2480) = 0x7f7fffff;
    *(undefined2 *)(iVar4 + 0x2401) = 0;
    *(undefined4 *)(iVar4 + 0x2490) = 0;
    if (*(char *)(iVar4 + 0x2400) != '\0') {
        if (*piVar20 == 0) {
            pcVar16 = "#DragDropCancelHandler";
            cVar5 = '#';
            do {
                if (((cVar5 == '#') && (*pcVar16 == '#')) && (pcVar16[1] == '#')) {
                    pcVar16 = pcVar16 + 2;
                }
                cVar5 = *pcVar16;
                pcVar16 = pcVar16 + 1;
            } while (cVar5 != '\0');
        }
        cVar5 = func_0x000180109d80();
        if (cVar5 != '\0') {
            fcn.1800f9f30(0, 0);
            func_0x0001801120a0();
        }
    }
    *(undefined8 *)(iVar4 + 0x2820) = 0;
    func_0x00018010f2f0();
    func_0x000180108830();
    func_0x000180114da0(iVar4);
    if ((*(char *)(iVar4 + 0x20b9) != '\0') || (*(float *)(iVar4 + 0x98) < 0.0)) {
        bVar3 = true;
    } else {
        bVar3 = false;
        fVar21 = (float)*(double *)(iVar4 + 0x18) - *(float *)(iVar4 + 0x98);
    }
    piVar15 = *(int64_t **)(iVar4 + 0x1588);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x1580);
    for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        cVar5 = *(char *)(iVar14 + 0x109);
        *(char *)(iVar14 + 0x10a) = cVar5;
        *(undefined *)(iVar14 + 0x109) = 0;
        *(undefined *)(iVar14 + 0x10b) = 0;
        *(undefined2 *)(iVar14 + 0x11a) = *(undefined2 *)(iVar14 + 0x118);
        *(undefined2 *)(iVar14 + 0x118) = 0;
        if (((cVar5 == '\0') || (bVar3)) &&
           ((*(char *)(iVar14 + 0x494) == '\0' &&
            (*(float *)(iVar14 + 0x2e8) <= fVar21 && fVar21 != *(float *)(iVar14 + 0x2e8))))) {
            iVar17 = *(int64_t *)(iVar14 + 800);
            *(undefined *)(iVar14 + 0x494) = 1;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x10) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x14);
            if (iVar8 < *(int32_t *)(iVar17 + 0x14)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x48c) = iVar7;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x20) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x24);
            if (iVar8 < *(int32_t *)(iVar17 + 0x24)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x490) = iVar7;
            if (*(int64_t *)(iVar14 + 0x150) != 0) {
                *(undefined8 *)(iVar14 + 0x148) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x150) = 0;
            }
            func_0x000180124110(*(undefined8 *)(iVar14 + 800));
            if (*(int64_t *)(iVar14 + 0x1f8) != 0) {
                *(undefined8 *)(iVar14 + 0x1f0) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x1f8) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x250) != 0) {
                *(undefined8 *)(iVar14 + 0x248) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x250) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x260) != 0) {
                *(undefined8 *)(iVar14 + 600) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x260) = 0;
            }
        }
    }
    fcn.1800fae50(iVar4 + 0x118);
    iVar17 = *(int64_t *)0x180781f28;
    iVar14 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1600);
    if (iVar14 == 0) {
        if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) == 0) ||
           (iVar7 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1654),
           *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) + 0xc4) != iVar7)) goto code_r0x0001800fbfc6;
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar7;
        if (*(int32_t *)(iVar17 + 0x1684) == iVar7) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') goto code_r0x0001800fbfc6;
    } else {
        piVar18 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1654);
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = *piVar18;
        if (*(int32_t *)(iVar17 + 0x1684) == *piVar18) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        iVar14 = *(int64_t *)(iVar14 + 0x428);
        if ((*(char *)(iVar14 + 0x10a) == '\0') && (*(char *)(iVar14 + 0x109) == '\0')) {
            bVar3 = true;
        } else {
            bVar3 = false;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') {
            pfVar1 = (float *)(iVar17 + 0x118);
            pfVar11 = pfVar1;
            if (pfVar1 == (float *)0x0) {
                pfVar11 = (float *)(*(int64_t *)0x180781f28 + 0x118);
            }
            if (((-256000.0 <= *pfVar11) && (-256000.0 <= pfVar11[1])) && (!bVar3)) {
                fVar22 = *pfVar1 - *(float *)(iVar17 + 0x166c);
                fVar24 = *(float *)(iVar17 + 0x11c) - *(float *)(iVar17 + 0x1670);
                var_8h._0_4_ = fVar22;
                var_8h._4_4_ = fVar24;
                if ((*(float *)(iVar14 + 0x60) != fVar22) || (*(float *)(iVar14 + 100) != fVar24)) {
                    func_0x000180106470(iVar14, &var_8h, 1);
                    if ((*(int64_t *)(iVar14 + 0x48) != 0) && (*(char *)(iVar14 + 0x108) != '\0')) {
                        *(uint64_t *)(*(int64_t *)(iVar14 + 0x48) + 8) = CONCAT44(fVar24, fVar22);
                        iVar14 = *(int64_t *)(iVar14 + 0x48);
                        *(float *)(iVar14 + 0x20) = *(float *)(iVar14 + 0x148) + *(float *)(iVar14 + 8);
                        *(float *)(iVar14 + 0x24) = *(float *)(iVar14 + 0x14c) + *(float *)(iVar14 + 0xc);
                        fVar24 = (*(float *)(iVar14 + 0x14) - *(float *)(iVar14 + 0x14c)) - *(float *)(iVar14 + 0x154);
                        fVar23 = (*(float *)(iVar14 + 0x10) - *(float *)(iVar14 + 0x148)) - *(float *)(iVar14 + 0x150);
                        fVar22 = 0.0;
                        if (0.0 <= fVar24) {
                            fVar22 = fVar24;
                        }
                        fVar24 = 0.0;
                        if (0.0 <= fVar23) {
                            fVar24 = fVar23;
                        }
                        *(float *)(iVar14 + 0x2c) = fVar22;
                        *(float *)(iVar14 + 0x28) = fVar24;
                    }
                }
                func_0x00018010e050(*(undefined8 *)(iVar17 + 0x1600), 0);
                goto code_r0x0001800fbfc6;
            }
        }
        fcn.1800fac90();
    }
    fcn.1800f9f30(0, 0);
code_r0x0001800fbfc6:
    uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    if (-1 < (int32_t)uVar13) {
        do {
            iVar14 = *(int64_t *)((uint64_t)uVar13 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar14 != 0) && ((*(uint32_t *)(iVar14 + 0x14) & 0x8000000) != 0)) goto code_r0x0001800fc015;
            uVar13 = uVar13 - 1;
        } while (-1 < (int32_t)uVar13);
    }
    if ((*(int64_t *)(iVar4 + 0x23c0) == 0) || (*(float *)(iVar4 + 0x23dc) <= 0.0)) {
        fVar22 = *(float *)(iVar4 + 0x23fc) - *(float *)(iVar4 + 0x48) * 10.0;
        if (fVar22 <= 0.0) {
            fVar22 = 0.0;
        }
    } else {
code_r0x0001800fc015:
        fVar22 = *(float *)(iVar4 + 0x48) * 6.0 + *(float *)(iVar4 + 0x23fc);
        if (1.0 <= fVar22) {
            fVar22 = 1.0;
        }
    }
    *(float *)(iVar4 + 0x23fc) = fVar22;
    *(undefined4 *)(iVar4 + 0x2650) = 0;
    *(undefined4 *)(iVar4 + 0x28c4) = *(undefined4 *)(iVar4 + 0x28b0);
    *(undefined4 *)(iVar4 + 0x28c8) = *(undefined4 *)(iVar4 + 0x28b4);
    *(undefined4 *)(iVar4 + 0x28cc) = *(undefined4 *)(iVar4 + 0x28b8);
    *(undefined4 *)(iVar4 + 0x28d0) = *(undefined4 *)(iVar4 + 0x28bc);
    *(undefined4 *)(iVar4 + 0x28d4) = *(undefined4 *)(iVar4 + 0x28c0);
    *(undefined8 *)(iVar4 + 0x2c88) = 0xffffffffffffffff;
    *(undefined4 *)(iVar4 + 0x2c84) = 0xffffffff;
    *(undefined2 *)(iVar4 + 0x28b0) = 0;
    func_0x000180108de0();
    iVar7 = iVar6;
    if (0 < *(int32_t *)(iVar4 + 0x2518)) {
        do {
            iVar14 = *(int64_t *)0x180781f28;
            fVar22 = *(float *)(*(int64_t *)(iVar4 + 0x2520) + (int64_t)iVar7 * 4);
            if ((0.0 <= fVar22) && (fVar22 < fVar21)) {
                iVar17 = (int64_t)iVar7 * 0x250 + *(int64_t *)(iVar4 + 0x24f8);
                *(undefined8 *)(iVar17 + 0x1f0) = 0;
                if (*(int64_t *)(iVar17 + 0x1e8) != 0) {
                    *(undefined8 *)(iVar17 + 0x1e0) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x1e8) = 0;
                }
                *(undefined *)(iVar17 + 0x23c) = 1;
                if (*(int64_t *)(iVar17 + 0x198) != 0) {
                    *(undefined8 *)(iVar17 + 400) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x198) = 0;
                }
                *(undefined *)(iVar17 + 0x24b) = 1;
                iVar8 = iVar6;
                if (0 < *(int32_t *)(iVar17 + 0x6c)) {
                    do {
                        iVar19 = (int64_t)iVar8;
                        iVar8 = iVar8 + 1;
                        *(undefined2 *)(iVar19 * 0x74 + 0x54 + *(int64_t *)(iVar17 + 0x18)) = 0xffff;
                    } while (iVar8 < *(int32_t *)(iVar17 + 0x6c));
                }
                *(undefined4 *)
                 (*(int64_t *)(iVar14 + 0x2520) +
                 (int64_t)(int32_t)((iVar17 - *(int64_t *)(iVar14 + 0x24f8)) / 0x250) * 4) = 0xbf800000;
            }
            iVar7 = iVar7 + 1;
        } while (iVar7 < *(int32_t *)(iVar4 + 0x2518));
    }
    iVar14 = *(int64_t *)(iVar4 + 0x24e8);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x24e0) * 0x88 + iVar14;
    iVar17 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar17, iVar14 != iVar19; iVar14 = iVar14 + 0x88) {
        if ((0.0 <= *(float *)(iVar14 + 8)) && (*(float *)(iVar14 + 8) < fVar21)) {
            func_0x000180126a10(iVar14 + 0x28);
            *(undefined4 *)(iVar14 + 8) = 0xbf800000;
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    if (*(char *)(iVar4 + 0x20b9) != '\0') {
        if (*(int64_t *)(iVar17 + 0x2108) != 0) {
            *(undefined8 *)(iVar17 + 0x2100) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2108) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x2118) != 0) {
            *(undefined8 *)(iVar17 + 0x2110) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2118) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x26e8) != 0) {
            *(undefined8 *)(iVar17 + 0x26e0) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x26e8) = 0;
        }
        *(undefined4 *)(iVar17 + 0x26f0) = 0;
        *(undefined4 *)(iVar17 + 0x25f8) = 0;
        func_0x00018011ee60(iVar17 + 0x2600);
        func_0x0001801388c0();
        piVar15 = *(int64_t **)(iVar17 + 0x12e0);
        piVar2 = piVar15 + *(int32_t *)(iVar17 + 0x12d8);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            iVar14 = *piVar15;
            iVar17 = *(int64_t *)(iVar14 + 0x2b0);
            func_0x000180129630(iVar14, 1);
            func_0x000180129f40(&var_8h, iVar14);
            if (((*(int32_t *)(iVar17 + 0x9c) != 0) || ((float)var_8h != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x1c))
                ) || (var_8h._4_4_ != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x20))) {
                func_0x0001801299b0(iVar14);
            }
        }
    }
    *(undefined *)(iVar4 + 0x20b9) = 0;
    if ((*(int64_t *)(iVar4 + 0x21d8) != 0) && (*(char *)(*(int64_t *)(iVar4 + 0x21d8) + 0x10a) == '\0')) {
        uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1590) - 1;
        if (-1 < (int32_t)uVar13) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1598) + (uint64_t)uVar13 * 8);
                if (((iVar14 != 0) && (*(char *)(iVar14 + 0x10a) != '\0')) &&
                   ((*(uint32_t *)(iVar14 + 0x14) & 0x10200) != 0x10200)) goto code_r0x0001800fc388;
                uVar13 = uVar13 - 1;
            } while (-1 < (int32_t)uVar13);
        }
        iVar14 = 0;
code_r0x0001800fc388:
        func_0x00018010e050(iVar14, 1);
    }
    func_0x00018011f370(iVar4 + 0x15b0, 0);
    iVar7 = *(int32_t *)(iVar4 + 0x2134);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f970(iVar4 + 0x2130, iVar8);
    }
    piVar18 = (int32_t *)(iVar4 + 0x2100);
    *(undefined4 *)(iVar4 + 0x2130) = 0;
    iVar7 = *(int32_t *)(iVar4 + 0x2104);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(piVar18, iVar8);
    }
    *piVar18 = 0;
    if (*(int32_t *)(iVar4 + 0x2104) == 0) {
        func_0x00018011fb10(piVar18, 8);
    }
    *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)*piVar18 * 4) = 0x10;
    iVar7 = *piVar18;
    *piVar18 = iVar7 + 1;
    *(undefined4 *)(iVar4 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)iVar7 * 4);
    func_0x00018011f140(iVar4 + 0x2110, 0);
    if ((*(uint8_t *)(iVar4 + 0x30) & 0x80) != 0) {
        iVar14 = *(int64_t *)(iVar4 + 0x15f0);
        *(undefined8 *)(iVar4 + 0x2b80) = 0;
        if (iVar14 != 0) {
            if (*(int64_t *)(iVar14 + 0x4c8) == 0) {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar14 + 0x418) + 0x4c0);
                if (iVar14 != 0) {
                    *(int64_t *)(iVar4 + 0x2b80) = iVar14;
                }
            } else {
                uVar12 = func_0x00018011bfb0(*(int64_t *)(iVar14 + 0x4c8), *(undefined8 *)(iVar4 + 0x118));
                *(undefined8 *)(iVar4 + 0x2b80) = uVar12;
            }
        }
        piVar18 = *(int32_t **)(iVar4 + 0x2900);
        piVar20 = piVar18 + (int64_t)*(int32_t *)(iVar4 + 0x28f8) * 0x10;
        for (; piVar18 != piVar20; piVar18 = piVar18 + 0x10) {
            if (*piVar18 == 1) {
                func_0x000180115650(iVar4, piVar18);
            }
        }
        iVar7 = *(int32_t *)(iVar4 + 0x28fc);
        if (iVar7 < 0) {
            iVar7 = iVar7 + iVar7 / 2;
            iVar8 = iVar6;
            if (0 < iVar7) {
                iVar8 = iVar7;
            }
            func_0x00018011fa30(iVar4 + 0x28f8, iVar8);
        }
        *(undefined4 *)(iVar4 + 0x28f8) = 0;
        if (0 < *(int32_t *)(iVar4 + 0x28e8)) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar4 + 0x28f0) + 8 + (int64_t)iVar6 * 0x10);
                if (((iVar14 != 0) && (*(int64_t *)(iVar14 + 0x18) == 0)) &&
                   ((*(uint32_t *)(iVar14 + 0x10) & 0x400) == 0)) {
                    func_0x000180116d90();
                }
                iVar6 = iVar6 + 1;
            } while (iVar6 < *(int32_t *)(iVar4 + 0x28e8));
        }
    }
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(iVar4 + 2) = 1;
    *(uint32_t *)(iVar14 + 0x2008) = *(uint32_t *)(iVar14 + 0x2008) | 2;
    *(undefined4 *)(iVar14 + 0x202c) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2030) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2010) = 4;
    func_0x0001801019f0(0x1806444f8, 0, 0);
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined4 *)(iVar4 + 0x2a5c) = 0;
    *(undefined2 *)(iVar4 + 0x2a60) = *(undefined2 *)(iVar14 + 0x15b0);
    *(undefined2 *)(iVar4 + 0x2a62) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x148);
    *(undefined2 *)(iVar4 + 0x2a64) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x1e0);
    *(undefined2 *)(iVar4 + 0x2a66) = *(undefined2 *)(iVar14 + 0x20c0);
    *(undefined2 *)(iVar4 + 0x2a68) = *(undefined2 *)(iVar14 + 0x20d0);
    *(undefined2 *)(iVar4 + 0x2a6a) = *(undefined2 *)(iVar14 + 0x20e0);
    *(undefined2 *)(iVar4 + 0x2a6c) = *(undefined2 *)(iVar14 + 0x20f0);
    *(undefined2 *)(iVar4 + 0x2a6e) = *(undefined2 *)(iVar14 + 0x2110);
    *(undefined2 *)(iVar4 + 0x2a70) = *(undefined2 *)(iVar14 + 0x2100);
    *(undefined2 *)(iVar4 + 0x2a72) = *(undefined2 *)(iVar14 + 0x2130);
    *(undefined2 *)(iVar4 + 0x2a74) = *(undefined2 *)(iVar14 + 0x281c);
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar17 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    for (; iVar14 != iVar17; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 1) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fbc80
// Address: 0x1800fbc80
// Size: 335 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Removing arg arg_2480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24a8h because it doesn't fit into ProtoModel

void fcn.1800fb4a0(undefined8 placeholder_0, int64_t arg2)
{
    float *pfVar1;
    int64_t *piVar2;
    bool bVar3;
    int64_t iVar4;
    char cVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    float *pfVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    int64_t iVar14;
    int64_t *piVar15;
    char *pcVar16;
    int64_t iVar17;
    int32_t *piVar18;
    int64_t iVar19;
    int32_t *piVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    uVar13 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2970);
    while (uVar13 = uVar13 - 1, -1 < (int32_t)uVar13) {
        iVar14 = (uint64_t)uVar13 * 0x20 + *(int64_t *)(iVar4 + 0x2978);
        if (*(int32_t *)(iVar14 + 4) == 7) {
            func_0x000180498030(iVar14, iVar14 + 0x20, 
                                ((int64_t)*(int32_t *)(iVar4 + 0x2970) - (uint64_t)uVar13) * 0x20 + -0x20);
            *(int32_t *)(iVar4 + 0x2970) = *(int32_t *)(iVar4 + 0x2970) + -1;
        }
    }
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    iVar17 = iVar4;
    for (; iVar14 != iVar19; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 0) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    *(undefined4 *)(iVar4 + 0x12d0) = *(undefined4 *)(iVar4 + 0x12cc);
    uVar13 = *(uint32_t *)(iVar17 + 0x30);
    if ((uVar13 & 4) != 0) {
        uVar13 = uVar13 & 0xfffffffb;
        *(undefined *)(iVar17 + 0x7a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 & 8) != 0) {
        uVar13 = uVar13 & 0xfffffff7;
        *(undefined *)(iVar17 + 0x7b) = 0;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xe & 1) != 0) {
        uVar13 = uVar13 & 0xffffbfff;
        *(undefined *)(iVar17 + 0x8a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xf & 1) != 0) {
        uVar13 = uVar13 & 0xffff7fff;
        *(undefined *)(iVar17 + 0x8b) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((*(int64_t *)(iVar17 + 0xc30) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc48) == 0 || (*(int64_t *)(iVar17 + 0xc48) == 0x18011e8a0)))) {
        *(undefined8 *)(iVar17 + 0xc48) = 0x18010a030;
    }
    if ((*(int64_t *)(iVar17 + 0xc38) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc50) == 0 || (*(int64_t *)(iVar17 + 0xc50) == 0x18011e9d0)))) {
        *(undefined8 *)(iVar17 + 0xc50) = 0x18010a050;
    }
    if (((uVar13 >> 10 & 1) != 0) && ((*(uint32_t *)(iVar17 + 0x34) & 0xc00) != 0xc00)) {
        *(uint32_t *)(iVar17 + 0x30) = uVar13 & 0xfffffbff;
    }
    *(undefined4 *)(iVar4 + 0x12cc) = *(undefined4 *)(iVar4 + 0x30);
    if (*(char *)(iVar17 + 0x2928) == '\0') {
        if ((*(int64_t *)(iVar17 + 0x50) != 0) &&
           (iVar14 = func_0x0001800f5b50(*(int64_t *)(iVar17 + 0x50), 0x180625030), iVar14 != 0)) {
            iVar6 = func_0x00018046d704(iVar14);
            if ((iVar6 != -1) && (iVar7 = func_0x000180461598(iVar14, 0, 2), iVar7 == 0)) {
                iVar7 = func_0x00018046d704(iVar14);
                iVar19 = (int64_t)iVar7;
                if ((((iVar7 != -1) && (iVar6 = func_0x000180461598(iVar14, iVar6, 0), iVar6 == 0)) && (iVar19 != -1))
                   && (iVar9 = func_0x00018046d050(iVar19), iVar9 != 0)) {
                    iVar10 = func_0x0001804611b4(iVar9, 1, iVar19, iVar14);
                    if (iVar10 == iVar19) {
                        func_0x00018045ff84(iVar14);
                        if (iVar19 != 0) {
                            func_0x000180112840(iVar9, iVar19);
                        }
                        fcn.180460d90(iVar9);
                    } else {
                        func_0x00018045ff84(iVar14);
                        fcn.180460d90(iVar9);
                    }
                    goto code_r0x0001800fb715;
                }
            }
            func_0x00018045ff84(iVar14);
        }
code_r0x0001800fb715:
        *(undefined *)(iVar17 + 0x2928) = 1;
    }
    iVar6 = 0;
    if ((0.0 < *(float *)(iVar17 + 0x292c)) &&
       (fVar21 = *(float *)(iVar17 + 0x292c) - *(float *)(iVar17 + 0x48), *(float *)(iVar17 + 0x292c) = fVar21,
       fVar21 <= 0.0)) {
        if (*(int64_t *)(iVar17 + 0x50) == 0) {
            *(undefined *)(iVar17 + 0xec) = 1;
        } else {
            func_0x000180112a70();
        }
        *(undefined4 *)(iVar17 + 0x292c) = 0;
    }
    *(int32_t *)(iVar4 + 4) = *(int32_t *)(iVar4 + 4) + 1;
    *(undefined2 *)(iVar4 + 0x281e) = 0;
    *(undefined4 *)(iVar4 + 0x15d0) = 0;
    *(double *)(iVar4 + 0x18) = (double)*(float *)(iVar4 + 0x48) + *(double *)(iVar4 + 0x18);
    iVar7 = *(int32_t *)(iVar4 + 0x283c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(iVar4 + 0x2838, iVar8);
    }
    fVar21 = 3.402823e+38;
    *(undefined4 *)(iVar4 + 0x2838) = 0;
    *(float *)(iVar4 + 0x2c80) =
         (*(float *)(iVar4 + 0x48) - *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4)) +
         *(float *)(iVar4 + 0x2c80);
    *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4) = *(float *)(iVar4 + 0x48);
    iVar8 = *(int32_t *)(iVar4 + 0x2c7c) + 1;
    *(int32_t *)(iVar4 + 0x2c78) = (*(int32_t *)(iVar4 + 0x2c78) + 1) % 0x3c;
    iVar7 = 0x3c;
    if (iVar8 < 0x3c) {
        iVar7 = iVar8;
    }
    *(int32_t *)(iVar4 + 0x2c7c) = iVar7;
    if (*(float *)(iVar4 + 0x2c80) <= 0.0) {
        fVar22 = 3.402823e+38;
    } else {
        fVar22 = 1.0 / (*(float *)(iVar4 + 0x2c80) / (float)iVar7);
    }
    *(float *)(iVar4 + 0xf0) = fVar22;
    iVar7 = *(int32_t *)(iVar4 + 0x156c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f9d0(iVar4 + 0x1568, iVar8);
    }
    *(undefined4 *)(iVar4 + 0x1568) = 0;
    func_0x0001801093d0(*(undefined *)(iVar4 + 0x8e));
    func_0x000180113b10();
    func_0x000180106aa0();
    fcn.1800fb280();
    func_0x000180106fa0();
    *(undefined *)(iVar4 + 1) = 1;
    piVar15 = *(int64_t **)(iVar4 + 0x2158);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x2150);
    iVar14 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar14, piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        *(undefined8 *)(iVar14 + 0x40) = 0;
        *(undefined *)(iVar14 + 200) = 0;
        iVar14 = *(int64_t *)0x180781f28;
    }
    if ((*(char *)(iVar4 + 0x2400) != '\0') &&
       (iVar7 = *(int32_t *)(iVar4 + 0x241c), iVar7 == *(int32_t *)(iVar4 + 0x1654))) {
        if (*(int32_t *)(iVar14 + 0x1654) == iVar7) {
            *(int32_t *)(iVar14 + 0x1658) = iVar7;
        }
        if (*(int32_t *)(iVar14 + 0x1684) == iVar7) {
            *(undefined *)(iVar14 + 0x168d) = 1;
        }
    }
    if ((((*(char *)(iVar4 + 0xb5) != '\0') && (*(char *)(iVar4 + 0x138) != '\0')) ||
        (*(undefined4 *)(iVar4 + 0x1634) = 0, *(char *)(iVar4 + 0xb5) != '\0')) && (1 < *(int32_t *)(iVar4 + 0x1644))) {
        *(undefined4 *)(iVar4 + 0x1634) = *(undefined4 *)(iVar4 + 0x1640);
    }
    piVar18 = (int32_t *)(iVar4 + 0x163c);
    if (*(int32_t *)(iVar4 + 0x1640) == 0) {
        *(undefined4 *)(iVar4 + 0x1648) = 0;
code_r0x0001800fb97d:
        *(undefined4 *)(iVar4 + 0x164c) = 0;
    } else if ((*piVar18 != 0) && (*(int32_t *)(iVar4 + 0x1654) == *piVar18)) goto code_r0x0001800fb97d;
    iVar7 = *piVar18;
    piVar20 = (int32_t *)(iVar4 + 0x1654);
    fVar22 = *(float *)(iVar4 + 0x48);
    if ((iVar7 != 0) && (*(float *)(iVar4 + 0x1648) = fVar22 + *(float *)(iVar4 + 0x1648), *piVar20 != iVar7)) {
        *(float *)(iVar4 + 0x164c) = fVar22 + *(float *)(iVar4 + 0x164c);
    }
    *piVar18 = 0;
    iVar8 = *piVar20;
    *(int32_t *)(iVar4 + 0x1640) = iVar7;
    *(undefined4 *)(iVar4 + 0x1644) = 0;
    *(undefined2 *)(iVar4 + 0x1650) = 0;
    if (((iVar8 != 0) && (*(int32_t *)(iVar4 + 0x1658) != iVar8)) && (*(int32_t *)(iVar4 + 0x1680) == iVar8)) {
        fcn.1800f9f30(0, 0);
        fVar22 = *(float *)(iVar4 + 0x48);
    }
    iVar7 = *piVar20;
    if (iVar7 != 0) {
        *(float *)(iVar4 + 0x165c) = fVar22 + *(float *)(iVar4 + 0x165c);
    }
    *(int32_t *)(iVar4 + 0x1680) = iVar7;
    *(int32_t *)(iVar4 + 0x1658) = 0;
    *(undefined *)(iVar4 + 0x1665) = 0;
    *(undefined *)(iVar4 + 0x1660) = 0;
    *(float *)(iVar4 + 0x169c) = fVar22 + *(float *)(iVar4 + 0x169c);
    if ((*(int32_t *)(iVar4 + 0x2780) != 0) && (iVar7 != *(int32_t *)(iVar4 + 0x2780))) {
        *(undefined4 *)(iVar4 + 0x2780) = 0;
    }
    if ((*(int32_t *)(iVar4 + 0x277c) != 0) && (*(int32_t *)(iVar4 + 0x277c) != *(int32_t *)(iVar4 + 0x1684))) {
        *(undefined4 *)(iVar4 + 0x277c) = 0;
    }
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x1f68) = 0;
        *(undefined *)(iVar4 + 0x1f6c) = 0;
    }
    if (*(int32_t *)(iVar4 + 0x1688) < *(int32_t *)(iVar4 + 4)) {
        *(undefined4 *)(iVar4 + 0x1684) = 0;
    }
    iVar7 = *(int32_t *)(iVar4 + 0x2638);
    *(undefined *)(iVar4 + 0x168d) = 0;
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x2648) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(int32_t *)(iVar4 + 0x2648) = iVar7;
    }
    if (*(int64_t *)(iVar4 + 0x15e8) == 0) {
        *(undefined4 *)(iVar4 + 0x264c) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(undefined4 *)(iVar4 + 0x264c) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x15e8) + 0x10);
    }
    *(int32_t *)(iVar4 + 0x263c) = iVar7;
    if (iVar7 == 0) {
        if (0.0 < *(float *)(iVar4 + 0x2640)) {
            fVar23 = fVar22 + *(float *)(iVar4 + 0x2644);
            *(float *)(iVar4 + 0x2644) = fVar23;
            fVar24 = 0.25;
            if (0.25 <= fVar22 + fVar22) {
                fVar24 = fVar22 + fVar22;
            }
            if (fVar24 <= fVar23) {
                *(undefined8 *)(iVar4 + 0x2640) = 0;
            }
        }
    } else {
        *(undefined4 *)(iVar4 + 0x2644) = 0;
        *(undefined4 *)(iVar4 + 0x2638) = 0;
        *(float *)(iVar4 + 0x2640) = *(float *)(iVar4 + 0x2640) + fVar22;
    }
    func_0x000180108270();
    *(undefined4 *)(iVar4 + 0x2488) = *(undefined4 *)(iVar4 + 0x2484);
    *(undefined4 *)(iVar4 + 0x247c) = *(undefined4 *)(iVar4 + 0x2478);
    *(undefined4 *)(iVar4 + 0x2478) = 0;
    *(undefined8 *)(iVar4 + 0x2480) = 0x7f7fffff;
    *(undefined2 *)(iVar4 + 0x2401) = 0;
    *(undefined4 *)(iVar4 + 0x2490) = 0;
    if (*(char *)(iVar4 + 0x2400) != '\0') {
        if (*piVar20 == 0) {
            pcVar16 = "#DragDropCancelHandler";
            cVar5 = '#';
            do {
                if (((cVar5 == '#') && (*pcVar16 == '#')) && (pcVar16[1] == '#')) {
                    pcVar16 = pcVar16 + 2;
                }
                cVar5 = *pcVar16;
                pcVar16 = pcVar16 + 1;
            } while (cVar5 != '\0');
        }
        cVar5 = func_0x000180109d80();
        if (cVar5 != '\0') {
            fcn.1800f9f30(0, 0);
            func_0x0001801120a0();
        }
    }
    *(undefined8 *)(iVar4 + 0x2820) = 0;
    func_0x00018010f2f0();
    func_0x000180108830();
    func_0x000180114da0(iVar4);
    if ((*(char *)(iVar4 + 0x20b9) != '\0') || (*(float *)(iVar4 + 0x98) < 0.0)) {
        bVar3 = true;
    } else {
        bVar3 = false;
        fVar21 = (float)*(double *)(iVar4 + 0x18) - *(float *)(iVar4 + 0x98);
    }
    piVar15 = *(int64_t **)(iVar4 + 0x1588);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x1580);
    for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        cVar5 = *(char *)(iVar14 + 0x109);
        *(char *)(iVar14 + 0x10a) = cVar5;
        *(undefined *)(iVar14 + 0x109) = 0;
        *(undefined *)(iVar14 + 0x10b) = 0;
        *(undefined2 *)(iVar14 + 0x11a) = *(undefined2 *)(iVar14 + 0x118);
        *(undefined2 *)(iVar14 + 0x118) = 0;
        if (((cVar5 == '\0') || (bVar3)) &&
           ((*(char *)(iVar14 + 0x494) == '\0' &&
            (*(float *)(iVar14 + 0x2e8) <= fVar21 && fVar21 != *(float *)(iVar14 + 0x2e8))))) {
            iVar17 = *(int64_t *)(iVar14 + 800);
            *(undefined *)(iVar14 + 0x494) = 1;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x10) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x14);
            if (iVar8 < *(int32_t *)(iVar17 + 0x14)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x48c) = iVar7;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x20) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x24);
            if (iVar8 < *(int32_t *)(iVar17 + 0x24)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x490) = iVar7;
            if (*(int64_t *)(iVar14 + 0x150) != 0) {
                *(undefined8 *)(iVar14 + 0x148) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x150) = 0;
            }
            func_0x000180124110(*(undefined8 *)(iVar14 + 800));
            if (*(int64_t *)(iVar14 + 0x1f8) != 0) {
                *(undefined8 *)(iVar14 + 0x1f0) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x1f8) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x250) != 0) {
                *(undefined8 *)(iVar14 + 0x248) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x250) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x260) != 0) {
                *(undefined8 *)(iVar14 + 600) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x260) = 0;
            }
        }
    }
    fcn.1800fae50(iVar4 + 0x118);
    iVar17 = *(int64_t *)0x180781f28;
    iVar14 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1600);
    if (iVar14 == 0) {
        if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) == 0) ||
           (iVar7 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1654),
           *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) + 0xc4) != iVar7)) goto code_r0x0001800fbfc6;
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar7;
        if (*(int32_t *)(iVar17 + 0x1684) == iVar7) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') goto code_r0x0001800fbfc6;
    } else {
        piVar18 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1654);
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = *piVar18;
        if (*(int32_t *)(iVar17 + 0x1684) == *piVar18) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        iVar14 = *(int64_t *)(iVar14 + 0x428);
        if ((*(char *)(iVar14 + 0x10a) == '\0') && (*(char *)(iVar14 + 0x109) == '\0')) {
            bVar3 = true;
        } else {
            bVar3 = false;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') {
            pfVar1 = (float *)(iVar17 + 0x118);
            pfVar11 = pfVar1;
            if (pfVar1 == (float *)0x0) {
                pfVar11 = (float *)(*(int64_t *)0x180781f28 + 0x118);
            }
            if (((-256000.0 <= *pfVar11) && (-256000.0 <= pfVar11[1])) && (!bVar3)) {
                fVar22 = *pfVar1 - *(float *)(iVar17 + 0x166c);
                fVar24 = *(float *)(iVar17 + 0x11c) - *(float *)(iVar17 + 0x1670);
                var_8h._0_4_ = fVar22;
                var_8h._4_4_ = fVar24;
                if ((*(float *)(iVar14 + 0x60) != fVar22) || (*(float *)(iVar14 + 100) != fVar24)) {
                    func_0x000180106470(iVar14, &var_8h, 1);
                    if ((*(int64_t *)(iVar14 + 0x48) != 0) && (*(char *)(iVar14 + 0x108) != '\0')) {
                        *(uint64_t *)(*(int64_t *)(iVar14 + 0x48) + 8) = CONCAT44(fVar24, fVar22);
                        iVar14 = *(int64_t *)(iVar14 + 0x48);
                        *(float *)(iVar14 + 0x20) = *(float *)(iVar14 + 0x148) + *(float *)(iVar14 + 8);
                        *(float *)(iVar14 + 0x24) = *(float *)(iVar14 + 0x14c) + *(float *)(iVar14 + 0xc);
                        fVar24 = (*(float *)(iVar14 + 0x14) - *(float *)(iVar14 + 0x14c)) - *(float *)(iVar14 + 0x154);
                        fVar23 = (*(float *)(iVar14 + 0x10) - *(float *)(iVar14 + 0x148)) - *(float *)(iVar14 + 0x150);
                        fVar22 = 0.0;
                        if (0.0 <= fVar24) {
                            fVar22 = fVar24;
                        }
                        fVar24 = 0.0;
                        if (0.0 <= fVar23) {
                            fVar24 = fVar23;
                        }
                        *(float *)(iVar14 + 0x2c) = fVar22;
                        *(float *)(iVar14 + 0x28) = fVar24;
                    }
                }
                func_0x00018010e050(*(undefined8 *)(iVar17 + 0x1600), 0);
                goto code_r0x0001800fbfc6;
            }
        }
        fcn.1800fac90();
    }
    fcn.1800f9f30(0, 0);
code_r0x0001800fbfc6:
    uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    if (-1 < (int32_t)uVar13) {
        do {
            iVar14 = *(int64_t *)((uint64_t)uVar13 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar14 != 0) && ((*(uint32_t *)(iVar14 + 0x14) & 0x8000000) != 0)) goto code_r0x0001800fc015;
            uVar13 = uVar13 - 1;
        } while (-1 < (int32_t)uVar13);
    }
    if ((*(int64_t *)(iVar4 + 0x23c0) == 0) || (*(float *)(iVar4 + 0x23dc) <= 0.0)) {
        fVar22 = *(float *)(iVar4 + 0x23fc) - *(float *)(iVar4 + 0x48) * 10.0;
        if (fVar22 <= 0.0) {
            fVar22 = 0.0;
        }
    } else {
code_r0x0001800fc015:
        fVar22 = *(float *)(iVar4 + 0x48) * 6.0 + *(float *)(iVar4 + 0x23fc);
        if (1.0 <= fVar22) {
            fVar22 = 1.0;
        }
    }
    *(float *)(iVar4 + 0x23fc) = fVar22;
    *(undefined4 *)(iVar4 + 0x2650) = 0;
    *(undefined4 *)(iVar4 + 0x28c4) = *(undefined4 *)(iVar4 + 0x28b0);
    *(undefined4 *)(iVar4 + 0x28c8) = *(undefined4 *)(iVar4 + 0x28b4);
    *(undefined4 *)(iVar4 + 0x28cc) = *(undefined4 *)(iVar4 + 0x28b8);
    *(undefined4 *)(iVar4 + 0x28d0) = *(undefined4 *)(iVar4 + 0x28bc);
    *(undefined4 *)(iVar4 + 0x28d4) = *(undefined4 *)(iVar4 + 0x28c0);
    *(undefined8 *)(iVar4 + 0x2c88) = 0xffffffffffffffff;
    *(undefined4 *)(iVar4 + 0x2c84) = 0xffffffff;
    *(undefined2 *)(iVar4 + 0x28b0) = 0;
    func_0x000180108de0();
    iVar7 = iVar6;
    if (0 < *(int32_t *)(iVar4 + 0x2518)) {
        do {
            iVar14 = *(int64_t *)0x180781f28;
            fVar22 = *(float *)(*(int64_t *)(iVar4 + 0x2520) + (int64_t)iVar7 * 4);
            if ((0.0 <= fVar22) && (fVar22 < fVar21)) {
                iVar17 = (int64_t)iVar7 * 0x250 + *(int64_t *)(iVar4 + 0x24f8);
                *(undefined8 *)(iVar17 + 0x1f0) = 0;
                if (*(int64_t *)(iVar17 + 0x1e8) != 0) {
                    *(undefined8 *)(iVar17 + 0x1e0) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x1e8) = 0;
                }
                *(undefined *)(iVar17 + 0x23c) = 1;
                if (*(int64_t *)(iVar17 + 0x198) != 0) {
                    *(undefined8 *)(iVar17 + 400) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x198) = 0;
                }
                *(undefined *)(iVar17 + 0x24b) = 1;
                iVar8 = iVar6;
                if (0 < *(int32_t *)(iVar17 + 0x6c)) {
                    do {
                        iVar19 = (int64_t)iVar8;
                        iVar8 = iVar8 + 1;
                        *(undefined2 *)(iVar19 * 0x74 + 0x54 + *(int64_t *)(iVar17 + 0x18)) = 0xffff;
                    } while (iVar8 < *(int32_t *)(iVar17 + 0x6c));
                }
                *(undefined4 *)
                 (*(int64_t *)(iVar14 + 0x2520) +
                 (int64_t)(int32_t)((iVar17 - *(int64_t *)(iVar14 + 0x24f8)) / 0x250) * 4) = 0xbf800000;
            }
            iVar7 = iVar7 + 1;
        } while (iVar7 < *(int32_t *)(iVar4 + 0x2518));
    }
    iVar14 = *(int64_t *)(iVar4 + 0x24e8);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x24e0) * 0x88 + iVar14;
    iVar17 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar17, iVar14 != iVar19; iVar14 = iVar14 + 0x88) {
        if ((0.0 <= *(float *)(iVar14 + 8)) && (*(float *)(iVar14 + 8) < fVar21)) {
            func_0x000180126a10(iVar14 + 0x28);
            *(undefined4 *)(iVar14 + 8) = 0xbf800000;
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    if (*(char *)(iVar4 + 0x20b9) != '\0') {
        if (*(int64_t *)(iVar17 + 0x2108) != 0) {
            *(undefined8 *)(iVar17 + 0x2100) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2108) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x2118) != 0) {
            *(undefined8 *)(iVar17 + 0x2110) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2118) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x26e8) != 0) {
            *(undefined8 *)(iVar17 + 0x26e0) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x26e8) = 0;
        }
        *(undefined4 *)(iVar17 + 0x26f0) = 0;
        *(undefined4 *)(iVar17 + 0x25f8) = 0;
        func_0x00018011ee60(iVar17 + 0x2600);
        func_0x0001801388c0();
        piVar15 = *(int64_t **)(iVar17 + 0x12e0);
        piVar2 = piVar15 + *(int32_t *)(iVar17 + 0x12d8);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            iVar14 = *piVar15;
            iVar17 = *(int64_t *)(iVar14 + 0x2b0);
            func_0x000180129630(iVar14, 1);
            func_0x000180129f40(&var_8h, iVar14);
            if (((*(int32_t *)(iVar17 + 0x9c) != 0) || ((float)var_8h != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x1c))
                ) || (var_8h._4_4_ != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x20))) {
                func_0x0001801299b0(iVar14);
            }
        }
    }
    *(undefined *)(iVar4 + 0x20b9) = 0;
    if ((*(int64_t *)(iVar4 + 0x21d8) != 0) && (*(char *)(*(int64_t *)(iVar4 + 0x21d8) + 0x10a) == '\0')) {
        uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1590) - 1;
        if (-1 < (int32_t)uVar13) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1598) + (uint64_t)uVar13 * 8);
                if (((iVar14 != 0) && (*(char *)(iVar14 + 0x10a) != '\0')) &&
                   ((*(uint32_t *)(iVar14 + 0x14) & 0x10200) != 0x10200)) goto code_r0x0001800fc388;
                uVar13 = uVar13 - 1;
            } while (-1 < (int32_t)uVar13);
        }
        iVar14 = 0;
code_r0x0001800fc388:
        func_0x00018010e050(iVar14, 1);
    }
    func_0x00018011f370(iVar4 + 0x15b0, 0);
    iVar7 = *(int32_t *)(iVar4 + 0x2134);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f970(iVar4 + 0x2130, iVar8);
    }
    piVar18 = (int32_t *)(iVar4 + 0x2100);
    *(undefined4 *)(iVar4 + 0x2130) = 0;
    iVar7 = *(int32_t *)(iVar4 + 0x2104);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(piVar18, iVar8);
    }
    *piVar18 = 0;
    if (*(int32_t *)(iVar4 + 0x2104) == 0) {
        func_0x00018011fb10(piVar18, 8);
    }
    *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)*piVar18 * 4) = 0x10;
    iVar7 = *piVar18;
    *piVar18 = iVar7 + 1;
    *(undefined4 *)(iVar4 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)iVar7 * 4);
    func_0x00018011f140(iVar4 + 0x2110, 0);
    if ((*(uint8_t *)(iVar4 + 0x30) & 0x80) != 0) {
        iVar14 = *(int64_t *)(iVar4 + 0x15f0);
        *(undefined8 *)(iVar4 + 0x2b80) = 0;
        if (iVar14 != 0) {
            if (*(int64_t *)(iVar14 + 0x4c8) == 0) {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar14 + 0x418) + 0x4c0);
                if (iVar14 != 0) {
                    *(int64_t *)(iVar4 + 0x2b80) = iVar14;
                }
            } else {
                uVar12 = func_0x00018011bfb0(*(int64_t *)(iVar14 + 0x4c8), *(undefined8 *)(iVar4 + 0x118));
                *(undefined8 *)(iVar4 + 0x2b80) = uVar12;
            }
        }
        piVar18 = *(int32_t **)(iVar4 + 0x2900);
        piVar20 = piVar18 + (int64_t)*(int32_t *)(iVar4 + 0x28f8) * 0x10;
        for (; piVar18 != piVar20; piVar18 = piVar18 + 0x10) {
            if (*piVar18 == 1) {
                func_0x000180115650(iVar4, piVar18);
            }
        }
        iVar7 = *(int32_t *)(iVar4 + 0x28fc);
        if (iVar7 < 0) {
            iVar7 = iVar7 + iVar7 / 2;
            iVar8 = iVar6;
            if (0 < iVar7) {
                iVar8 = iVar7;
            }
            func_0x00018011fa30(iVar4 + 0x28f8, iVar8);
        }
        *(undefined4 *)(iVar4 + 0x28f8) = 0;
        if (0 < *(int32_t *)(iVar4 + 0x28e8)) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar4 + 0x28f0) + 8 + (int64_t)iVar6 * 0x10);
                if (((iVar14 != 0) && (*(int64_t *)(iVar14 + 0x18) == 0)) &&
                   ((*(uint32_t *)(iVar14 + 0x10) & 0x400) == 0)) {
                    func_0x000180116d90();
                }
                iVar6 = iVar6 + 1;
            } while (iVar6 < *(int32_t *)(iVar4 + 0x28e8));
        }
    }
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(iVar4 + 2) = 1;
    *(uint32_t *)(iVar14 + 0x2008) = *(uint32_t *)(iVar14 + 0x2008) | 2;
    *(undefined4 *)(iVar14 + 0x202c) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2030) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2010) = 4;
    func_0x0001801019f0(0x1806444f8, 0, 0);
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined4 *)(iVar4 + 0x2a5c) = 0;
    *(undefined2 *)(iVar4 + 0x2a60) = *(undefined2 *)(iVar14 + 0x15b0);
    *(undefined2 *)(iVar4 + 0x2a62) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x148);
    *(undefined2 *)(iVar4 + 0x2a64) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x1e0);
    *(undefined2 *)(iVar4 + 0x2a66) = *(undefined2 *)(iVar14 + 0x20c0);
    *(undefined2 *)(iVar4 + 0x2a68) = *(undefined2 *)(iVar14 + 0x20d0);
    *(undefined2 *)(iVar4 + 0x2a6a) = *(undefined2 *)(iVar14 + 0x20e0);
    *(undefined2 *)(iVar4 + 0x2a6c) = *(undefined2 *)(iVar14 + 0x20f0);
    *(undefined2 *)(iVar4 + 0x2a6e) = *(undefined2 *)(iVar14 + 0x2110);
    *(undefined2 *)(iVar4 + 0x2a70) = *(undefined2 *)(iVar14 + 0x2100);
    *(undefined2 *)(iVar4 + 0x2a72) = *(undefined2 *)(iVar14 + 0x2130);
    *(undefined2 *)(iVar4 + 0x2a74) = *(undefined2 *)(iVar14 + 0x281c);
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar17 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    for (; iVar14 != iVar17; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 1) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fbdcf
// Address: 0x1800fbdcf
// Size: 737 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Removing arg arg_2480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24a8h because it doesn't fit into ProtoModel

void fcn.1800fb4a0(undefined8 placeholder_0, int64_t arg2)
{
    float *pfVar1;
    int64_t *piVar2;
    bool bVar3;
    int64_t iVar4;
    char cVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    float *pfVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    int64_t iVar14;
    int64_t *piVar15;
    char *pcVar16;
    int64_t iVar17;
    int32_t *piVar18;
    int64_t iVar19;
    int32_t *piVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    uVar13 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2970);
    while (uVar13 = uVar13 - 1, -1 < (int32_t)uVar13) {
        iVar14 = (uint64_t)uVar13 * 0x20 + *(int64_t *)(iVar4 + 0x2978);
        if (*(int32_t *)(iVar14 + 4) == 7) {
            func_0x000180498030(iVar14, iVar14 + 0x20, 
                                ((int64_t)*(int32_t *)(iVar4 + 0x2970) - (uint64_t)uVar13) * 0x20 + -0x20);
            *(int32_t *)(iVar4 + 0x2970) = *(int32_t *)(iVar4 + 0x2970) + -1;
        }
    }
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    iVar17 = iVar4;
    for (; iVar14 != iVar19; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 0) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    *(undefined4 *)(iVar4 + 0x12d0) = *(undefined4 *)(iVar4 + 0x12cc);
    uVar13 = *(uint32_t *)(iVar17 + 0x30);
    if ((uVar13 & 4) != 0) {
        uVar13 = uVar13 & 0xfffffffb;
        *(undefined *)(iVar17 + 0x7a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 & 8) != 0) {
        uVar13 = uVar13 & 0xfffffff7;
        *(undefined *)(iVar17 + 0x7b) = 0;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xe & 1) != 0) {
        uVar13 = uVar13 & 0xffffbfff;
        *(undefined *)(iVar17 + 0x8a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xf & 1) != 0) {
        uVar13 = uVar13 & 0xffff7fff;
        *(undefined *)(iVar17 + 0x8b) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((*(int64_t *)(iVar17 + 0xc30) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc48) == 0 || (*(int64_t *)(iVar17 + 0xc48) == 0x18011e8a0)))) {
        *(undefined8 *)(iVar17 + 0xc48) = 0x18010a030;
    }
    if ((*(int64_t *)(iVar17 + 0xc38) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc50) == 0 || (*(int64_t *)(iVar17 + 0xc50) == 0x18011e9d0)))) {
        *(undefined8 *)(iVar17 + 0xc50) = 0x18010a050;
    }
    if (((uVar13 >> 10 & 1) != 0) && ((*(uint32_t *)(iVar17 + 0x34) & 0xc00) != 0xc00)) {
        *(uint32_t *)(iVar17 + 0x30) = uVar13 & 0xfffffbff;
    }
    *(undefined4 *)(iVar4 + 0x12cc) = *(undefined4 *)(iVar4 + 0x30);
    if (*(char *)(iVar17 + 0x2928) == '\0') {
        if ((*(int64_t *)(iVar17 + 0x50) != 0) &&
           (iVar14 = func_0x0001800f5b50(*(int64_t *)(iVar17 + 0x50), 0x180625030), iVar14 != 0)) {
            iVar6 = func_0x00018046d704(iVar14);
            if ((iVar6 != -1) && (iVar7 = func_0x000180461598(iVar14, 0, 2), iVar7 == 0)) {
                iVar7 = func_0x00018046d704(iVar14);
                iVar19 = (int64_t)iVar7;
                if ((((iVar7 != -1) && (iVar6 = func_0x000180461598(iVar14, iVar6, 0), iVar6 == 0)) && (iVar19 != -1))
                   && (iVar9 = func_0x00018046d050(iVar19), iVar9 != 0)) {
                    iVar10 = func_0x0001804611b4(iVar9, 1, iVar19, iVar14);
                    if (iVar10 == iVar19) {
                        func_0x00018045ff84(iVar14);
                        if (iVar19 != 0) {
                            func_0x000180112840(iVar9, iVar19);
                        }
                        fcn.180460d90(iVar9);
                    } else {
                        func_0x00018045ff84(iVar14);
                        fcn.180460d90(iVar9);
                    }
                    goto code_r0x0001800fb715;
                }
            }
            func_0x00018045ff84(iVar14);
        }
code_r0x0001800fb715:
        *(undefined *)(iVar17 + 0x2928) = 1;
    }
    iVar6 = 0;
    if ((0.0 < *(float *)(iVar17 + 0x292c)) &&
       (fVar21 = *(float *)(iVar17 + 0x292c) - *(float *)(iVar17 + 0x48), *(float *)(iVar17 + 0x292c) = fVar21,
       fVar21 <= 0.0)) {
        if (*(int64_t *)(iVar17 + 0x50) == 0) {
            *(undefined *)(iVar17 + 0xec) = 1;
        } else {
            func_0x000180112a70();
        }
        *(undefined4 *)(iVar17 + 0x292c) = 0;
    }
    *(int32_t *)(iVar4 + 4) = *(int32_t *)(iVar4 + 4) + 1;
    *(undefined2 *)(iVar4 + 0x281e) = 0;
    *(undefined4 *)(iVar4 + 0x15d0) = 0;
    *(double *)(iVar4 + 0x18) = (double)*(float *)(iVar4 + 0x48) + *(double *)(iVar4 + 0x18);
    iVar7 = *(int32_t *)(iVar4 + 0x283c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(iVar4 + 0x2838, iVar8);
    }
    fVar21 = 3.402823e+38;
    *(undefined4 *)(iVar4 + 0x2838) = 0;
    *(float *)(iVar4 + 0x2c80) =
         (*(float *)(iVar4 + 0x48) - *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4)) +
         *(float *)(iVar4 + 0x2c80);
    *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4) = *(float *)(iVar4 + 0x48);
    iVar8 = *(int32_t *)(iVar4 + 0x2c7c) + 1;
    *(int32_t *)(iVar4 + 0x2c78) = (*(int32_t *)(iVar4 + 0x2c78) + 1) % 0x3c;
    iVar7 = 0x3c;
    if (iVar8 < 0x3c) {
        iVar7 = iVar8;
    }
    *(int32_t *)(iVar4 + 0x2c7c) = iVar7;
    if (*(float *)(iVar4 + 0x2c80) <= 0.0) {
        fVar22 = 3.402823e+38;
    } else {
        fVar22 = 1.0 / (*(float *)(iVar4 + 0x2c80) / (float)iVar7);
    }
    *(float *)(iVar4 + 0xf0) = fVar22;
    iVar7 = *(int32_t *)(iVar4 + 0x156c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f9d0(iVar4 + 0x1568, iVar8);
    }
    *(undefined4 *)(iVar4 + 0x1568) = 0;
    func_0x0001801093d0(*(undefined *)(iVar4 + 0x8e));
    func_0x000180113b10();
    func_0x000180106aa0();
    fcn.1800fb280();
    func_0x000180106fa0();
    *(undefined *)(iVar4 + 1) = 1;
    piVar15 = *(int64_t **)(iVar4 + 0x2158);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x2150);
    iVar14 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar14, piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        *(undefined8 *)(iVar14 + 0x40) = 0;
        *(undefined *)(iVar14 + 200) = 0;
        iVar14 = *(int64_t *)0x180781f28;
    }
    if ((*(char *)(iVar4 + 0x2400) != '\0') &&
       (iVar7 = *(int32_t *)(iVar4 + 0x241c), iVar7 == *(int32_t *)(iVar4 + 0x1654))) {
        if (*(int32_t *)(iVar14 + 0x1654) == iVar7) {
            *(int32_t *)(iVar14 + 0x1658) = iVar7;
        }
        if (*(int32_t *)(iVar14 + 0x1684) == iVar7) {
            *(undefined *)(iVar14 + 0x168d) = 1;
        }
    }
    if ((((*(char *)(iVar4 + 0xb5) != '\0') && (*(char *)(iVar4 + 0x138) != '\0')) ||
        (*(undefined4 *)(iVar4 + 0x1634) = 0, *(char *)(iVar4 + 0xb5) != '\0')) && (1 < *(int32_t *)(iVar4 + 0x1644))) {
        *(undefined4 *)(iVar4 + 0x1634) = *(undefined4 *)(iVar4 + 0x1640);
    }
    piVar18 = (int32_t *)(iVar4 + 0x163c);
    if (*(int32_t *)(iVar4 + 0x1640) == 0) {
        *(undefined4 *)(iVar4 + 0x1648) = 0;
code_r0x0001800fb97d:
        *(undefined4 *)(iVar4 + 0x164c) = 0;
    } else if ((*piVar18 != 0) && (*(int32_t *)(iVar4 + 0x1654) == *piVar18)) goto code_r0x0001800fb97d;
    iVar7 = *piVar18;
    piVar20 = (int32_t *)(iVar4 + 0x1654);
    fVar22 = *(float *)(iVar4 + 0x48);
    if ((iVar7 != 0) && (*(float *)(iVar4 + 0x1648) = fVar22 + *(float *)(iVar4 + 0x1648), *piVar20 != iVar7)) {
        *(float *)(iVar4 + 0x164c) = fVar22 + *(float *)(iVar4 + 0x164c);
    }
    *piVar18 = 0;
    iVar8 = *piVar20;
    *(int32_t *)(iVar4 + 0x1640) = iVar7;
    *(undefined4 *)(iVar4 + 0x1644) = 0;
    *(undefined2 *)(iVar4 + 0x1650) = 0;
    if (((iVar8 != 0) && (*(int32_t *)(iVar4 + 0x1658) != iVar8)) && (*(int32_t *)(iVar4 + 0x1680) == iVar8)) {
        fcn.1800f9f30(0, 0);
        fVar22 = *(float *)(iVar4 + 0x48);
    }
    iVar7 = *piVar20;
    if (iVar7 != 0) {
        *(float *)(iVar4 + 0x165c) = fVar22 + *(float *)(iVar4 + 0x165c);
    }
    *(int32_t *)(iVar4 + 0x1680) = iVar7;
    *(int32_t *)(iVar4 + 0x1658) = 0;
    *(undefined *)(iVar4 + 0x1665) = 0;
    *(undefined *)(iVar4 + 0x1660) = 0;
    *(float *)(iVar4 + 0x169c) = fVar22 + *(float *)(iVar4 + 0x169c);
    if ((*(int32_t *)(iVar4 + 0x2780) != 0) && (iVar7 != *(int32_t *)(iVar4 + 0x2780))) {
        *(undefined4 *)(iVar4 + 0x2780) = 0;
    }
    if ((*(int32_t *)(iVar4 + 0x277c) != 0) && (*(int32_t *)(iVar4 + 0x277c) != *(int32_t *)(iVar4 + 0x1684))) {
        *(undefined4 *)(iVar4 + 0x277c) = 0;
    }
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x1f68) = 0;
        *(undefined *)(iVar4 + 0x1f6c) = 0;
    }
    if (*(int32_t *)(iVar4 + 0x1688) < *(int32_t *)(iVar4 + 4)) {
        *(undefined4 *)(iVar4 + 0x1684) = 0;
    }
    iVar7 = *(int32_t *)(iVar4 + 0x2638);
    *(undefined *)(iVar4 + 0x168d) = 0;
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x2648) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(int32_t *)(iVar4 + 0x2648) = iVar7;
    }
    if (*(int64_t *)(iVar4 + 0x15e8) == 0) {
        *(undefined4 *)(iVar4 + 0x264c) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(undefined4 *)(iVar4 + 0x264c) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x15e8) + 0x10);
    }
    *(int32_t *)(iVar4 + 0x263c) = iVar7;
    if (iVar7 == 0) {
        if (0.0 < *(float *)(iVar4 + 0x2640)) {
            fVar23 = fVar22 + *(float *)(iVar4 + 0x2644);
            *(float *)(iVar4 + 0x2644) = fVar23;
            fVar24 = 0.25;
            if (0.25 <= fVar22 + fVar22) {
                fVar24 = fVar22 + fVar22;
            }
            if (fVar24 <= fVar23) {
                *(undefined8 *)(iVar4 + 0x2640) = 0;
            }
        }
    } else {
        *(undefined4 *)(iVar4 + 0x2644) = 0;
        *(undefined4 *)(iVar4 + 0x2638) = 0;
        *(float *)(iVar4 + 0x2640) = *(float *)(iVar4 + 0x2640) + fVar22;
    }
    func_0x000180108270();
    *(undefined4 *)(iVar4 + 0x2488) = *(undefined4 *)(iVar4 + 0x2484);
    *(undefined4 *)(iVar4 + 0x247c) = *(undefined4 *)(iVar4 + 0x2478);
    *(undefined4 *)(iVar4 + 0x2478) = 0;
    *(undefined8 *)(iVar4 + 0x2480) = 0x7f7fffff;
    *(undefined2 *)(iVar4 + 0x2401) = 0;
    *(undefined4 *)(iVar4 + 0x2490) = 0;
    if (*(char *)(iVar4 + 0x2400) != '\0') {
        if (*piVar20 == 0) {
            pcVar16 = "#DragDropCancelHandler";
            cVar5 = '#';
            do {
                if (((cVar5 == '#') && (*pcVar16 == '#')) && (pcVar16[1] == '#')) {
                    pcVar16 = pcVar16 + 2;
                }
                cVar5 = *pcVar16;
                pcVar16 = pcVar16 + 1;
            } while (cVar5 != '\0');
        }
        cVar5 = func_0x000180109d80();
        if (cVar5 != '\0') {
            fcn.1800f9f30(0, 0);
            func_0x0001801120a0();
        }
    }
    *(undefined8 *)(iVar4 + 0x2820) = 0;
    func_0x00018010f2f0();
    func_0x000180108830();
    func_0x000180114da0(iVar4);
    if ((*(char *)(iVar4 + 0x20b9) != '\0') || (*(float *)(iVar4 + 0x98) < 0.0)) {
        bVar3 = true;
    } else {
        bVar3 = false;
        fVar21 = (float)*(double *)(iVar4 + 0x18) - *(float *)(iVar4 + 0x98);
    }
    piVar15 = *(int64_t **)(iVar4 + 0x1588);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x1580);
    for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        cVar5 = *(char *)(iVar14 + 0x109);
        *(char *)(iVar14 + 0x10a) = cVar5;
        *(undefined *)(iVar14 + 0x109) = 0;
        *(undefined *)(iVar14 + 0x10b) = 0;
        *(undefined2 *)(iVar14 + 0x11a) = *(undefined2 *)(iVar14 + 0x118);
        *(undefined2 *)(iVar14 + 0x118) = 0;
        if (((cVar5 == '\0') || (bVar3)) &&
           ((*(char *)(iVar14 + 0x494) == '\0' &&
            (*(float *)(iVar14 + 0x2e8) <= fVar21 && fVar21 != *(float *)(iVar14 + 0x2e8))))) {
            iVar17 = *(int64_t *)(iVar14 + 800);
            *(undefined *)(iVar14 + 0x494) = 1;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x10) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x14);
            if (iVar8 < *(int32_t *)(iVar17 + 0x14)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x48c) = iVar7;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x20) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x24);
            if (iVar8 < *(int32_t *)(iVar17 + 0x24)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x490) = iVar7;
            if (*(int64_t *)(iVar14 + 0x150) != 0) {
                *(undefined8 *)(iVar14 + 0x148) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x150) = 0;
            }
            func_0x000180124110(*(undefined8 *)(iVar14 + 800));
            if (*(int64_t *)(iVar14 + 0x1f8) != 0) {
                *(undefined8 *)(iVar14 + 0x1f0) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x1f8) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x250) != 0) {
                *(undefined8 *)(iVar14 + 0x248) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x250) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x260) != 0) {
                *(undefined8 *)(iVar14 + 600) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x260) = 0;
            }
        }
    }
    fcn.1800fae50(iVar4 + 0x118);
    iVar17 = *(int64_t *)0x180781f28;
    iVar14 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1600);
    if (iVar14 == 0) {
        if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) == 0) ||
           (iVar7 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1654),
           *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) + 0xc4) != iVar7)) goto code_r0x0001800fbfc6;
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar7;
        if (*(int32_t *)(iVar17 + 0x1684) == iVar7) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') goto code_r0x0001800fbfc6;
    } else {
        piVar18 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1654);
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = *piVar18;
        if (*(int32_t *)(iVar17 + 0x1684) == *piVar18) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        iVar14 = *(int64_t *)(iVar14 + 0x428);
        if ((*(char *)(iVar14 + 0x10a) == '\0') && (*(char *)(iVar14 + 0x109) == '\0')) {
            bVar3 = true;
        } else {
            bVar3 = false;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') {
            pfVar1 = (float *)(iVar17 + 0x118);
            pfVar11 = pfVar1;
            if (pfVar1 == (float *)0x0) {
                pfVar11 = (float *)(*(int64_t *)0x180781f28 + 0x118);
            }
            if (((-256000.0 <= *pfVar11) && (-256000.0 <= pfVar11[1])) && (!bVar3)) {
                fVar22 = *pfVar1 - *(float *)(iVar17 + 0x166c);
                fVar24 = *(float *)(iVar17 + 0x11c) - *(float *)(iVar17 + 0x1670);
                var_8h._0_4_ = fVar22;
                var_8h._4_4_ = fVar24;
                if ((*(float *)(iVar14 + 0x60) != fVar22) || (*(float *)(iVar14 + 100) != fVar24)) {
                    func_0x000180106470(iVar14, &var_8h, 1);
                    if ((*(int64_t *)(iVar14 + 0x48) != 0) && (*(char *)(iVar14 + 0x108) != '\0')) {
                        *(uint64_t *)(*(int64_t *)(iVar14 + 0x48) + 8) = CONCAT44(fVar24, fVar22);
                        iVar14 = *(int64_t *)(iVar14 + 0x48);
                        *(float *)(iVar14 + 0x20) = *(float *)(iVar14 + 0x148) + *(float *)(iVar14 + 8);
                        *(float *)(iVar14 + 0x24) = *(float *)(iVar14 + 0x14c) + *(float *)(iVar14 + 0xc);
                        fVar24 = (*(float *)(iVar14 + 0x14) - *(float *)(iVar14 + 0x14c)) - *(float *)(iVar14 + 0x154);
                        fVar23 = (*(float *)(iVar14 + 0x10) - *(float *)(iVar14 + 0x148)) - *(float *)(iVar14 + 0x150);
                        fVar22 = 0.0;
                        if (0.0 <= fVar24) {
                            fVar22 = fVar24;
                        }
                        fVar24 = 0.0;
                        if (0.0 <= fVar23) {
                            fVar24 = fVar23;
                        }
                        *(float *)(iVar14 + 0x2c) = fVar22;
                        *(float *)(iVar14 + 0x28) = fVar24;
                    }
                }
                func_0x00018010e050(*(undefined8 *)(iVar17 + 0x1600), 0);
                goto code_r0x0001800fbfc6;
            }
        }
        fcn.1800fac90();
    }
    fcn.1800f9f30(0, 0);
code_r0x0001800fbfc6:
    uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    if (-1 < (int32_t)uVar13) {
        do {
            iVar14 = *(int64_t *)((uint64_t)uVar13 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar14 != 0) && ((*(uint32_t *)(iVar14 + 0x14) & 0x8000000) != 0)) goto code_r0x0001800fc015;
            uVar13 = uVar13 - 1;
        } while (-1 < (int32_t)uVar13);
    }
    if ((*(int64_t *)(iVar4 + 0x23c0) == 0) || (*(float *)(iVar4 + 0x23dc) <= 0.0)) {
        fVar22 = *(float *)(iVar4 + 0x23fc) - *(float *)(iVar4 + 0x48) * 10.0;
        if (fVar22 <= 0.0) {
            fVar22 = 0.0;
        }
    } else {
code_r0x0001800fc015:
        fVar22 = *(float *)(iVar4 + 0x48) * 6.0 + *(float *)(iVar4 + 0x23fc);
        if (1.0 <= fVar22) {
            fVar22 = 1.0;
        }
    }
    *(float *)(iVar4 + 0x23fc) = fVar22;
    *(undefined4 *)(iVar4 + 0x2650) = 0;
    *(undefined4 *)(iVar4 + 0x28c4) = *(undefined4 *)(iVar4 + 0x28b0);
    *(undefined4 *)(iVar4 + 0x28c8) = *(undefined4 *)(iVar4 + 0x28b4);
    *(undefined4 *)(iVar4 + 0x28cc) = *(undefined4 *)(iVar4 + 0x28b8);
    *(undefined4 *)(iVar4 + 0x28d0) = *(undefined4 *)(iVar4 + 0x28bc);
    *(undefined4 *)(iVar4 + 0x28d4) = *(undefined4 *)(iVar4 + 0x28c0);
    *(undefined8 *)(iVar4 + 0x2c88) = 0xffffffffffffffff;
    *(undefined4 *)(iVar4 + 0x2c84) = 0xffffffff;
    *(undefined2 *)(iVar4 + 0x28b0) = 0;
    func_0x000180108de0();
    iVar7 = iVar6;
    if (0 < *(int32_t *)(iVar4 + 0x2518)) {
        do {
            iVar14 = *(int64_t *)0x180781f28;
            fVar22 = *(float *)(*(int64_t *)(iVar4 + 0x2520) + (int64_t)iVar7 * 4);
            if ((0.0 <= fVar22) && (fVar22 < fVar21)) {
                iVar17 = (int64_t)iVar7 * 0x250 + *(int64_t *)(iVar4 + 0x24f8);
                *(undefined8 *)(iVar17 + 0x1f0) = 0;
                if (*(int64_t *)(iVar17 + 0x1e8) != 0) {
                    *(undefined8 *)(iVar17 + 0x1e0) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x1e8) = 0;
                }
                *(undefined *)(iVar17 + 0x23c) = 1;
                if (*(int64_t *)(iVar17 + 0x198) != 0) {
                    *(undefined8 *)(iVar17 + 400) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x198) = 0;
                }
                *(undefined *)(iVar17 + 0x24b) = 1;
                iVar8 = iVar6;
                if (0 < *(int32_t *)(iVar17 + 0x6c)) {
                    do {
                        iVar19 = (int64_t)iVar8;
                        iVar8 = iVar8 + 1;
                        *(undefined2 *)(iVar19 * 0x74 + 0x54 + *(int64_t *)(iVar17 + 0x18)) = 0xffff;
                    } while (iVar8 < *(int32_t *)(iVar17 + 0x6c));
                }
                *(undefined4 *)
                 (*(int64_t *)(iVar14 + 0x2520) +
                 (int64_t)(int32_t)((iVar17 - *(int64_t *)(iVar14 + 0x24f8)) / 0x250) * 4) = 0xbf800000;
            }
            iVar7 = iVar7 + 1;
        } while (iVar7 < *(int32_t *)(iVar4 + 0x2518));
    }
    iVar14 = *(int64_t *)(iVar4 + 0x24e8);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x24e0) * 0x88 + iVar14;
    iVar17 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar17, iVar14 != iVar19; iVar14 = iVar14 + 0x88) {
        if ((0.0 <= *(float *)(iVar14 + 8)) && (*(float *)(iVar14 + 8) < fVar21)) {
            func_0x000180126a10(iVar14 + 0x28);
            *(undefined4 *)(iVar14 + 8) = 0xbf800000;
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    if (*(char *)(iVar4 + 0x20b9) != '\0') {
        if (*(int64_t *)(iVar17 + 0x2108) != 0) {
            *(undefined8 *)(iVar17 + 0x2100) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2108) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x2118) != 0) {
            *(undefined8 *)(iVar17 + 0x2110) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2118) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x26e8) != 0) {
            *(undefined8 *)(iVar17 + 0x26e0) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x26e8) = 0;
        }
        *(undefined4 *)(iVar17 + 0x26f0) = 0;
        *(undefined4 *)(iVar17 + 0x25f8) = 0;
        func_0x00018011ee60(iVar17 + 0x2600);
        func_0x0001801388c0();
        piVar15 = *(int64_t **)(iVar17 + 0x12e0);
        piVar2 = piVar15 + *(int32_t *)(iVar17 + 0x12d8);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            iVar14 = *piVar15;
            iVar17 = *(int64_t *)(iVar14 + 0x2b0);
            func_0x000180129630(iVar14, 1);
            func_0x000180129f40(&var_8h, iVar14);
            if (((*(int32_t *)(iVar17 + 0x9c) != 0) || ((float)var_8h != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x1c))
                ) || (var_8h._4_4_ != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x20))) {
                func_0x0001801299b0(iVar14);
            }
        }
    }
    *(undefined *)(iVar4 + 0x20b9) = 0;
    if ((*(int64_t *)(iVar4 + 0x21d8) != 0) && (*(char *)(*(int64_t *)(iVar4 + 0x21d8) + 0x10a) == '\0')) {
        uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1590) - 1;
        if (-1 < (int32_t)uVar13) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1598) + (uint64_t)uVar13 * 8);
                if (((iVar14 != 0) && (*(char *)(iVar14 + 0x10a) != '\0')) &&
                   ((*(uint32_t *)(iVar14 + 0x14) & 0x10200) != 0x10200)) goto code_r0x0001800fc388;
                uVar13 = uVar13 - 1;
            } while (-1 < (int32_t)uVar13);
        }
        iVar14 = 0;
code_r0x0001800fc388:
        func_0x00018010e050(iVar14, 1);
    }
    func_0x00018011f370(iVar4 + 0x15b0, 0);
    iVar7 = *(int32_t *)(iVar4 + 0x2134);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f970(iVar4 + 0x2130, iVar8);
    }
    piVar18 = (int32_t *)(iVar4 + 0x2100);
    *(undefined4 *)(iVar4 + 0x2130) = 0;
    iVar7 = *(int32_t *)(iVar4 + 0x2104);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(piVar18, iVar8);
    }
    *piVar18 = 0;
    if (*(int32_t *)(iVar4 + 0x2104) == 0) {
        func_0x00018011fb10(piVar18, 8);
    }
    *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)*piVar18 * 4) = 0x10;
    iVar7 = *piVar18;
    *piVar18 = iVar7 + 1;
    *(undefined4 *)(iVar4 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)iVar7 * 4);
    func_0x00018011f140(iVar4 + 0x2110, 0);
    if ((*(uint8_t *)(iVar4 + 0x30) & 0x80) != 0) {
        iVar14 = *(int64_t *)(iVar4 + 0x15f0);
        *(undefined8 *)(iVar4 + 0x2b80) = 0;
        if (iVar14 != 0) {
            if (*(int64_t *)(iVar14 + 0x4c8) == 0) {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar14 + 0x418) + 0x4c0);
                if (iVar14 != 0) {
                    *(int64_t *)(iVar4 + 0x2b80) = iVar14;
                }
            } else {
                uVar12 = func_0x00018011bfb0(*(int64_t *)(iVar14 + 0x4c8), *(undefined8 *)(iVar4 + 0x118));
                *(undefined8 *)(iVar4 + 0x2b80) = uVar12;
            }
        }
        piVar18 = *(int32_t **)(iVar4 + 0x2900);
        piVar20 = piVar18 + (int64_t)*(int32_t *)(iVar4 + 0x28f8) * 0x10;
        for (; piVar18 != piVar20; piVar18 = piVar18 + 0x10) {
            if (*piVar18 == 1) {
                func_0x000180115650(iVar4, piVar18);
            }
        }
        iVar7 = *(int32_t *)(iVar4 + 0x28fc);
        if (iVar7 < 0) {
            iVar7 = iVar7 + iVar7 / 2;
            iVar8 = iVar6;
            if (0 < iVar7) {
                iVar8 = iVar7;
            }
            func_0x00018011fa30(iVar4 + 0x28f8, iVar8);
        }
        *(undefined4 *)(iVar4 + 0x28f8) = 0;
        if (0 < *(int32_t *)(iVar4 + 0x28e8)) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar4 + 0x28f0) + 8 + (int64_t)iVar6 * 0x10);
                if (((iVar14 != 0) && (*(int64_t *)(iVar14 + 0x18) == 0)) &&
                   ((*(uint32_t *)(iVar14 + 0x10) & 0x400) == 0)) {
                    func_0x000180116d90();
                }
                iVar6 = iVar6 + 1;
            } while (iVar6 < *(int32_t *)(iVar4 + 0x28e8));
        }
    }
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(iVar4 + 2) = 1;
    *(uint32_t *)(iVar14 + 0x2008) = *(uint32_t *)(iVar14 + 0x2008) | 2;
    *(undefined4 *)(iVar14 + 0x202c) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2030) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2010) = 4;
    func_0x0001801019f0(0x1806444f8, 0, 0);
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined4 *)(iVar4 + 0x2a5c) = 0;
    *(undefined2 *)(iVar4 + 0x2a60) = *(undefined2 *)(iVar14 + 0x15b0);
    *(undefined2 *)(iVar4 + 0x2a62) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x148);
    *(undefined2 *)(iVar4 + 0x2a64) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x1e0);
    *(undefined2 *)(iVar4 + 0x2a66) = *(undefined2 *)(iVar14 + 0x20c0);
    *(undefined2 *)(iVar4 + 0x2a68) = *(undefined2 *)(iVar14 + 0x20d0);
    *(undefined2 *)(iVar4 + 0x2a6a) = *(undefined2 *)(iVar14 + 0x20e0);
    *(undefined2 *)(iVar4 + 0x2a6c) = *(undefined2 *)(iVar14 + 0x20f0);
    *(undefined2 *)(iVar4 + 0x2a6e) = *(undefined2 *)(iVar14 + 0x2110);
    *(undefined2 *)(iVar4 + 0x2a70) = *(undefined2 *)(iVar14 + 0x2100);
    *(undefined2 *)(iVar4 + 0x2a72) = *(undefined2 *)(iVar14 + 0x2130);
    *(undefined2 *)(iVar4 + 0x2a74) = *(undefined2 *)(iVar14 + 0x281c);
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar17 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    for (; iVar14 != iVar17; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 1) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fc0b0
// Address: 0x1800fc0b0
// Size: 269 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Removing arg arg_2480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24a8h because it doesn't fit into ProtoModel

void fcn.1800fb4a0(undefined8 placeholder_0, int64_t arg2)
{
    float *pfVar1;
    int64_t *piVar2;
    bool bVar3;
    int64_t iVar4;
    char cVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    float *pfVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    int64_t iVar14;
    int64_t *piVar15;
    char *pcVar16;
    int64_t iVar17;
    int32_t *piVar18;
    int64_t iVar19;
    int32_t *piVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    uVar13 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2970);
    while (uVar13 = uVar13 - 1, -1 < (int32_t)uVar13) {
        iVar14 = (uint64_t)uVar13 * 0x20 + *(int64_t *)(iVar4 + 0x2978);
        if (*(int32_t *)(iVar14 + 4) == 7) {
            func_0x000180498030(iVar14, iVar14 + 0x20, 
                                ((int64_t)*(int32_t *)(iVar4 + 0x2970) - (uint64_t)uVar13) * 0x20 + -0x20);
            *(int32_t *)(iVar4 + 0x2970) = *(int32_t *)(iVar4 + 0x2970) + -1;
        }
    }
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    iVar17 = iVar4;
    for (; iVar14 != iVar19; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 0) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    *(undefined4 *)(iVar4 + 0x12d0) = *(undefined4 *)(iVar4 + 0x12cc);
    uVar13 = *(uint32_t *)(iVar17 + 0x30);
    if ((uVar13 & 4) != 0) {
        uVar13 = uVar13 & 0xfffffffb;
        *(undefined *)(iVar17 + 0x7a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 & 8) != 0) {
        uVar13 = uVar13 & 0xfffffff7;
        *(undefined *)(iVar17 + 0x7b) = 0;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xe & 1) != 0) {
        uVar13 = uVar13 & 0xffffbfff;
        *(undefined *)(iVar17 + 0x8a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xf & 1) != 0) {
        uVar13 = uVar13 & 0xffff7fff;
        *(undefined *)(iVar17 + 0x8b) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((*(int64_t *)(iVar17 + 0xc30) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc48) == 0 || (*(int64_t *)(iVar17 + 0xc48) == 0x18011e8a0)))) {
        *(undefined8 *)(iVar17 + 0xc48) = 0x18010a030;
    }
    if ((*(int64_t *)(iVar17 + 0xc38) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc50) == 0 || (*(int64_t *)(iVar17 + 0xc50) == 0x18011e9d0)))) {
        *(undefined8 *)(iVar17 + 0xc50) = 0x18010a050;
    }
    if (((uVar13 >> 10 & 1) != 0) && ((*(uint32_t *)(iVar17 + 0x34) & 0xc00) != 0xc00)) {
        *(uint32_t *)(iVar17 + 0x30) = uVar13 & 0xfffffbff;
    }
    *(undefined4 *)(iVar4 + 0x12cc) = *(undefined4 *)(iVar4 + 0x30);
    if (*(char *)(iVar17 + 0x2928) == '\0') {
        if ((*(int64_t *)(iVar17 + 0x50) != 0) &&
           (iVar14 = func_0x0001800f5b50(*(int64_t *)(iVar17 + 0x50), 0x180625030), iVar14 != 0)) {
            iVar6 = func_0x00018046d704(iVar14);
            if ((iVar6 != -1) && (iVar7 = func_0x000180461598(iVar14, 0, 2), iVar7 == 0)) {
                iVar7 = func_0x00018046d704(iVar14);
                iVar19 = (int64_t)iVar7;
                if ((((iVar7 != -1) && (iVar6 = func_0x000180461598(iVar14, iVar6, 0), iVar6 == 0)) && (iVar19 != -1))
                   && (iVar9 = func_0x00018046d050(iVar19), iVar9 != 0)) {
                    iVar10 = func_0x0001804611b4(iVar9, 1, iVar19, iVar14);
                    if (iVar10 == iVar19) {
                        func_0x00018045ff84(iVar14);
                        if (iVar19 != 0) {
                            func_0x000180112840(iVar9, iVar19);
                        }
                        fcn.180460d90(iVar9);
                    } else {
                        func_0x00018045ff84(iVar14);
                        fcn.180460d90(iVar9);
                    }
                    goto code_r0x0001800fb715;
                }
            }
            func_0x00018045ff84(iVar14);
        }
code_r0x0001800fb715:
        *(undefined *)(iVar17 + 0x2928) = 1;
    }
    iVar6 = 0;
    if ((0.0 < *(float *)(iVar17 + 0x292c)) &&
       (fVar21 = *(float *)(iVar17 + 0x292c) - *(float *)(iVar17 + 0x48), *(float *)(iVar17 + 0x292c) = fVar21,
       fVar21 <= 0.0)) {
        if (*(int64_t *)(iVar17 + 0x50) == 0) {
            *(undefined *)(iVar17 + 0xec) = 1;
        } else {
            func_0x000180112a70();
        }
        *(undefined4 *)(iVar17 + 0x292c) = 0;
    }
    *(int32_t *)(iVar4 + 4) = *(int32_t *)(iVar4 + 4) + 1;
    *(undefined2 *)(iVar4 + 0x281e) = 0;
    *(undefined4 *)(iVar4 + 0x15d0) = 0;
    *(double *)(iVar4 + 0x18) = (double)*(float *)(iVar4 + 0x48) + *(double *)(iVar4 + 0x18);
    iVar7 = *(int32_t *)(iVar4 + 0x283c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(iVar4 + 0x2838, iVar8);
    }
    fVar21 = 3.402823e+38;
    *(undefined4 *)(iVar4 + 0x2838) = 0;
    *(float *)(iVar4 + 0x2c80) =
         (*(float *)(iVar4 + 0x48) - *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4)) +
         *(float *)(iVar4 + 0x2c80);
    *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4) = *(float *)(iVar4 + 0x48);
    iVar8 = *(int32_t *)(iVar4 + 0x2c7c) + 1;
    *(int32_t *)(iVar4 + 0x2c78) = (*(int32_t *)(iVar4 + 0x2c78) + 1) % 0x3c;
    iVar7 = 0x3c;
    if (iVar8 < 0x3c) {
        iVar7 = iVar8;
    }
    *(int32_t *)(iVar4 + 0x2c7c) = iVar7;
    if (*(float *)(iVar4 + 0x2c80) <= 0.0) {
        fVar22 = 3.402823e+38;
    } else {
        fVar22 = 1.0 / (*(float *)(iVar4 + 0x2c80) / (float)iVar7);
    }
    *(float *)(iVar4 + 0xf0) = fVar22;
    iVar7 = *(int32_t *)(iVar4 + 0x156c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f9d0(iVar4 + 0x1568, iVar8);
    }
    *(undefined4 *)(iVar4 + 0x1568) = 0;
    func_0x0001801093d0(*(undefined *)(iVar4 + 0x8e));
    func_0x000180113b10();
    func_0x000180106aa0();
    fcn.1800fb280();
    func_0x000180106fa0();
    *(undefined *)(iVar4 + 1) = 1;
    piVar15 = *(int64_t **)(iVar4 + 0x2158);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x2150);
    iVar14 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar14, piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        *(undefined8 *)(iVar14 + 0x40) = 0;
        *(undefined *)(iVar14 + 200) = 0;
        iVar14 = *(int64_t *)0x180781f28;
    }
    if ((*(char *)(iVar4 + 0x2400) != '\0') &&
       (iVar7 = *(int32_t *)(iVar4 + 0x241c), iVar7 == *(int32_t *)(iVar4 + 0x1654))) {
        if (*(int32_t *)(iVar14 + 0x1654) == iVar7) {
            *(int32_t *)(iVar14 + 0x1658) = iVar7;
        }
        if (*(int32_t *)(iVar14 + 0x1684) == iVar7) {
            *(undefined *)(iVar14 + 0x168d) = 1;
        }
    }
    if ((((*(char *)(iVar4 + 0xb5) != '\0') && (*(char *)(iVar4 + 0x138) != '\0')) ||
        (*(undefined4 *)(iVar4 + 0x1634) = 0, *(char *)(iVar4 + 0xb5) != '\0')) && (1 < *(int32_t *)(iVar4 + 0x1644))) {
        *(undefined4 *)(iVar4 + 0x1634) = *(undefined4 *)(iVar4 + 0x1640);
    }
    piVar18 = (int32_t *)(iVar4 + 0x163c);
    if (*(int32_t *)(iVar4 + 0x1640) == 0) {
        *(undefined4 *)(iVar4 + 0x1648) = 0;
code_r0x0001800fb97d:
        *(undefined4 *)(iVar4 + 0x164c) = 0;
    } else if ((*piVar18 != 0) && (*(int32_t *)(iVar4 + 0x1654) == *piVar18)) goto code_r0x0001800fb97d;
    iVar7 = *piVar18;
    piVar20 = (int32_t *)(iVar4 + 0x1654);
    fVar22 = *(float *)(iVar4 + 0x48);
    if ((iVar7 != 0) && (*(float *)(iVar4 + 0x1648) = fVar22 + *(float *)(iVar4 + 0x1648), *piVar20 != iVar7)) {
        *(float *)(iVar4 + 0x164c) = fVar22 + *(float *)(iVar4 + 0x164c);
    }
    *piVar18 = 0;
    iVar8 = *piVar20;
    *(int32_t *)(iVar4 + 0x1640) = iVar7;
    *(undefined4 *)(iVar4 + 0x1644) = 0;
    *(undefined2 *)(iVar4 + 0x1650) = 0;
    if (((iVar8 != 0) && (*(int32_t *)(iVar4 + 0x1658) != iVar8)) && (*(int32_t *)(iVar4 + 0x1680) == iVar8)) {
        fcn.1800f9f30(0, 0);
        fVar22 = *(float *)(iVar4 + 0x48);
    }
    iVar7 = *piVar20;
    if (iVar7 != 0) {
        *(float *)(iVar4 + 0x165c) = fVar22 + *(float *)(iVar4 + 0x165c);
    }
    *(int32_t *)(iVar4 + 0x1680) = iVar7;
    *(int32_t *)(iVar4 + 0x1658) = 0;
    *(undefined *)(iVar4 + 0x1665) = 0;
    *(undefined *)(iVar4 + 0x1660) = 0;
    *(float *)(iVar4 + 0x169c) = fVar22 + *(float *)(iVar4 + 0x169c);
    if ((*(int32_t *)(iVar4 + 0x2780) != 0) && (iVar7 != *(int32_t *)(iVar4 + 0x2780))) {
        *(undefined4 *)(iVar4 + 0x2780) = 0;
    }
    if ((*(int32_t *)(iVar4 + 0x277c) != 0) && (*(int32_t *)(iVar4 + 0x277c) != *(int32_t *)(iVar4 + 0x1684))) {
        *(undefined4 *)(iVar4 + 0x277c) = 0;
    }
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x1f68) = 0;
        *(undefined *)(iVar4 + 0x1f6c) = 0;
    }
    if (*(int32_t *)(iVar4 + 0x1688) < *(int32_t *)(iVar4 + 4)) {
        *(undefined4 *)(iVar4 + 0x1684) = 0;
    }
    iVar7 = *(int32_t *)(iVar4 + 0x2638);
    *(undefined *)(iVar4 + 0x168d) = 0;
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x2648) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(int32_t *)(iVar4 + 0x2648) = iVar7;
    }
    if (*(int64_t *)(iVar4 + 0x15e8) == 0) {
        *(undefined4 *)(iVar4 + 0x264c) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(undefined4 *)(iVar4 + 0x264c) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x15e8) + 0x10);
    }
    *(int32_t *)(iVar4 + 0x263c) = iVar7;
    if (iVar7 == 0) {
        if (0.0 < *(float *)(iVar4 + 0x2640)) {
            fVar23 = fVar22 + *(float *)(iVar4 + 0x2644);
            *(float *)(iVar4 + 0x2644) = fVar23;
            fVar24 = 0.25;
            if (0.25 <= fVar22 + fVar22) {
                fVar24 = fVar22 + fVar22;
            }
            if (fVar24 <= fVar23) {
                *(undefined8 *)(iVar4 + 0x2640) = 0;
            }
        }
    } else {
        *(undefined4 *)(iVar4 + 0x2644) = 0;
        *(undefined4 *)(iVar4 + 0x2638) = 0;
        *(float *)(iVar4 + 0x2640) = *(float *)(iVar4 + 0x2640) + fVar22;
    }
    func_0x000180108270();
    *(undefined4 *)(iVar4 + 0x2488) = *(undefined4 *)(iVar4 + 0x2484);
    *(undefined4 *)(iVar4 + 0x247c) = *(undefined4 *)(iVar4 + 0x2478);
    *(undefined4 *)(iVar4 + 0x2478) = 0;
    *(undefined8 *)(iVar4 + 0x2480) = 0x7f7fffff;
    *(undefined2 *)(iVar4 + 0x2401) = 0;
    *(undefined4 *)(iVar4 + 0x2490) = 0;
    if (*(char *)(iVar4 + 0x2400) != '\0') {
        if (*piVar20 == 0) {
            pcVar16 = "#DragDropCancelHandler";
            cVar5 = '#';
            do {
                if (((cVar5 == '#') && (*pcVar16 == '#')) && (pcVar16[1] == '#')) {
                    pcVar16 = pcVar16 + 2;
                }
                cVar5 = *pcVar16;
                pcVar16 = pcVar16 + 1;
            } while (cVar5 != '\0');
        }
        cVar5 = func_0x000180109d80();
        if (cVar5 != '\0') {
            fcn.1800f9f30(0, 0);
            func_0x0001801120a0();
        }
    }
    *(undefined8 *)(iVar4 + 0x2820) = 0;
    func_0x00018010f2f0();
    func_0x000180108830();
    func_0x000180114da0(iVar4);
    if ((*(char *)(iVar4 + 0x20b9) != '\0') || (*(float *)(iVar4 + 0x98) < 0.0)) {
        bVar3 = true;
    } else {
        bVar3 = false;
        fVar21 = (float)*(double *)(iVar4 + 0x18) - *(float *)(iVar4 + 0x98);
    }
    piVar15 = *(int64_t **)(iVar4 + 0x1588);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x1580);
    for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        cVar5 = *(char *)(iVar14 + 0x109);
        *(char *)(iVar14 + 0x10a) = cVar5;
        *(undefined *)(iVar14 + 0x109) = 0;
        *(undefined *)(iVar14 + 0x10b) = 0;
        *(undefined2 *)(iVar14 + 0x11a) = *(undefined2 *)(iVar14 + 0x118);
        *(undefined2 *)(iVar14 + 0x118) = 0;
        if (((cVar5 == '\0') || (bVar3)) &&
           ((*(char *)(iVar14 + 0x494) == '\0' &&
            (*(float *)(iVar14 + 0x2e8) <= fVar21 && fVar21 != *(float *)(iVar14 + 0x2e8))))) {
            iVar17 = *(int64_t *)(iVar14 + 800);
            *(undefined *)(iVar14 + 0x494) = 1;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x10) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x14);
            if (iVar8 < *(int32_t *)(iVar17 + 0x14)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x48c) = iVar7;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x20) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x24);
            if (iVar8 < *(int32_t *)(iVar17 + 0x24)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x490) = iVar7;
            if (*(int64_t *)(iVar14 + 0x150) != 0) {
                *(undefined8 *)(iVar14 + 0x148) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x150) = 0;
            }
            func_0x000180124110(*(undefined8 *)(iVar14 + 800));
            if (*(int64_t *)(iVar14 + 0x1f8) != 0) {
                *(undefined8 *)(iVar14 + 0x1f0) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x1f8) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x250) != 0) {
                *(undefined8 *)(iVar14 + 0x248) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x250) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x260) != 0) {
                *(undefined8 *)(iVar14 + 600) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x260) = 0;
            }
        }
    }
    fcn.1800fae50(iVar4 + 0x118);
    iVar17 = *(int64_t *)0x180781f28;
    iVar14 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1600);
    if (iVar14 == 0) {
        if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) == 0) ||
           (iVar7 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1654),
           *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) + 0xc4) != iVar7)) goto code_r0x0001800fbfc6;
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar7;
        if (*(int32_t *)(iVar17 + 0x1684) == iVar7) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') goto code_r0x0001800fbfc6;
    } else {
        piVar18 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1654);
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = *piVar18;
        if (*(int32_t *)(iVar17 + 0x1684) == *piVar18) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        iVar14 = *(int64_t *)(iVar14 + 0x428);
        if ((*(char *)(iVar14 + 0x10a) == '\0') && (*(char *)(iVar14 + 0x109) == '\0')) {
            bVar3 = true;
        } else {
            bVar3 = false;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') {
            pfVar1 = (float *)(iVar17 + 0x118);
            pfVar11 = pfVar1;
            if (pfVar1 == (float *)0x0) {
                pfVar11 = (float *)(*(int64_t *)0x180781f28 + 0x118);
            }
            if (((-256000.0 <= *pfVar11) && (-256000.0 <= pfVar11[1])) && (!bVar3)) {
                fVar22 = *pfVar1 - *(float *)(iVar17 + 0x166c);
                fVar24 = *(float *)(iVar17 + 0x11c) - *(float *)(iVar17 + 0x1670);
                var_8h._0_4_ = fVar22;
                var_8h._4_4_ = fVar24;
                if ((*(float *)(iVar14 + 0x60) != fVar22) || (*(float *)(iVar14 + 100) != fVar24)) {
                    func_0x000180106470(iVar14, &var_8h, 1);
                    if ((*(int64_t *)(iVar14 + 0x48) != 0) && (*(char *)(iVar14 + 0x108) != '\0')) {
                        *(uint64_t *)(*(int64_t *)(iVar14 + 0x48) + 8) = CONCAT44(fVar24, fVar22);
                        iVar14 = *(int64_t *)(iVar14 + 0x48);
                        *(float *)(iVar14 + 0x20) = *(float *)(iVar14 + 0x148) + *(float *)(iVar14 + 8);
                        *(float *)(iVar14 + 0x24) = *(float *)(iVar14 + 0x14c) + *(float *)(iVar14 + 0xc);
                        fVar24 = (*(float *)(iVar14 + 0x14) - *(float *)(iVar14 + 0x14c)) - *(float *)(iVar14 + 0x154);
                        fVar23 = (*(float *)(iVar14 + 0x10) - *(float *)(iVar14 + 0x148)) - *(float *)(iVar14 + 0x150);
                        fVar22 = 0.0;
                        if (0.0 <= fVar24) {
                            fVar22 = fVar24;
                        }
                        fVar24 = 0.0;
                        if (0.0 <= fVar23) {
                            fVar24 = fVar23;
                        }
                        *(float *)(iVar14 + 0x2c) = fVar22;
                        *(float *)(iVar14 + 0x28) = fVar24;
                    }
                }
                func_0x00018010e050(*(undefined8 *)(iVar17 + 0x1600), 0);
                goto code_r0x0001800fbfc6;
            }
        }
        fcn.1800fac90();
    }
    fcn.1800f9f30(0, 0);
code_r0x0001800fbfc6:
    uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    if (-1 < (int32_t)uVar13) {
        do {
            iVar14 = *(int64_t *)((uint64_t)uVar13 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar14 != 0) && ((*(uint32_t *)(iVar14 + 0x14) & 0x8000000) != 0)) goto code_r0x0001800fc015;
            uVar13 = uVar13 - 1;
        } while (-1 < (int32_t)uVar13);
    }
    if ((*(int64_t *)(iVar4 + 0x23c0) == 0) || (*(float *)(iVar4 + 0x23dc) <= 0.0)) {
        fVar22 = *(float *)(iVar4 + 0x23fc) - *(float *)(iVar4 + 0x48) * 10.0;
        if (fVar22 <= 0.0) {
            fVar22 = 0.0;
        }
    } else {
code_r0x0001800fc015:
        fVar22 = *(float *)(iVar4 + 0x48) * 6.0 + *(float *)(iVar4 + 0x23fc);
        if (1.0 <= fVar22) {
            fVar22 = 1.0;
        }
    }
    *(float *)(iVar4 + 0x23fc) = fVar22;
    *(undefined4 *)(iVar4 + 0x2650) = 0;
    *(undefined4 *)(iVar4 + 0x28c4) = *(undefined4 *)(iVar4 + 0x28b0);
    *(undefined4 *)(iVar4 + 0x28c8) = *(undefined4 *)(iVar4 + 0x28b4);
    *(undefined4 *)(iVar4 + 0x28cc) = *(undefined4 *)(iVar4 + 0x28b8);
    *(undefined4 *)(iVar4 + 0x28d0) = *(undefined4 *)(iVar4 + 0x28bc);
    *(undefined4 *)(iVar4 + 0x28d4) = *(undefined4 *)(iVar4 + 0x28c0);
    *(undefined8 *)(iVar4 + 0x2c88) = 0xffffffffffffffff;
    *(undefined4 *)(iVar4 + 0x2c84) = 0xffffffff;
    *(undefined2 *)(iVar4 + 0x28b0) = 0;
    func_0x000180108de0();
    iVar7 = iVar6;
    if (0 < *(int32_t *)(iVar4 + 0x2518)) {
        do {
            iVar14 = *(int64_t *)0x180781f28;
            fVar22 = *(float *)(*(int64_t *)(iVar4 + 0x2520) + (int64_t)iVar7 * 4);
            if ((0.0 <= fVar22) && (fVar22 < fVar21)) {
                iVar17 = (int64_t)iVar7 * 0x250 + *(int64_t *)(iVar4 + 0x24f8);
                *(undefined8 *)(iVar17 + 0x1f0) = 0;
                if (*(int64_t *)(iVar17 + 0x1e8) != 0) {
                    *(undefined8 *)(iVar17 + 0x1e0) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x1e8) = 0;
                }
                *(undefined *)(iVar17 + 0x23c) = 1;
                if (*(int64_t *)(iVar17 + 0x198) != 0) {
                    *(undefined8 *)(iVar17 + 400) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x198) = 0;
                }
                *(undefined *)(iVar17 + 0x24b) = 1;
                iVar8 = iVar6;
                if (0 < *(int32_t *)(iVar17 + 0x6c)) {
                    do {
                        iVar19 = (int64_t)iVar8;
                        iVar8 = iVar8 + 1;
                        *(undefined2 *)(iVar19 * 0x74 + 0x54 + *(int64_t *)(iVar17 + 0x18)) = 0xffff;
                    } while (iVar8 < *(int32_t *)(iVar17 + 0x6c));
                }
                *(undefined4 *)
                 (*(int64_t *)(iVar14 + 0x2520) +
                 (int64_t)(int32_t)((iVar17 - *(int64_t *)(iVar14 + 0x24f8)) / 0x250) * 4) = 0xbf800000;
            }
            iVar7 = iVar7 + 1;
        } while (iVar7 < *(int32_t *)(iVar4 + 0x2518));
    }
    iVar14 = *(int64_t *)(iVar4 + 0x24e8);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x24e0) * 0x88 + iVar14;
    iVar17 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar17, iVar14 != iVar19; iVar14 = iVar14 + 0x88) {
        if ((0.0 <= *(float *)(iVar14 + 8)) && (*(float *)(iVar14 + 8) < fVar21)) {
            func_0x000180126a10(iVar14 + 0x28);
            *(undefined4 *)(iVar14 + 8) = 0xbf800000;
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    if (*(char *)(iVar4 + 0x20b9) != '\0') {
        if (*(int64_t *)(iVar17 + 0x2108) != 0) {
            *(undefined8 *)(iVar17 + 0x2100) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2108) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x2118) != 0) {
            *(undefined8 *)(iVar17 + 0x2110) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2118) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x26e8) != 0) {
            *(undefined8 *)(iVar17 + 0x26e0) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x26e8) = 0;
        }
        *(undefined4 *)(iVar17 + 0x26f0) = 0;
        *(undefined4 *)(iVar17 + 0x25f8) = 0;
        func_0x00018011ee60(iVar17 + 0x2600);
        func_0x0001801388c0();
        piVar15 = *(int64_t **)(iVar17 + 0x12e0);
        piVar2 = piVar15 + *(int32_t *)(iVar17 + 0x12d8);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            iVar14 = *piVar15;
            iVar17 = *(int64_t *)(iVar14 + 0x2b0);
            func_0x000180129630(iVar14, 1);
            func_0x000180129f40(&var_8h, iVar14);
            if (((*(int32_t *)(iVar17 + 0x9c) != 0) || ((float)var_8h != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x1c))
                ) || (var_8h._4_4_ != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x20))) {
                func_0x0001801299b0(iVar14);
            }
        }
    }
    *(undefined *)(iVar4 + 0x20b9) = 0;
    if ((*(int64_t *)(iVar4 + 0x21d8) != 0) && (*(char *)(*(int64_t *)(iVar4 + 0x21d8) + 0x10a) == '\0')) {
        uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1590) - 1;
        if (-1 < (int32_t)uVar13) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1598) + (uint64_t)uVar13 * 8);
                if (((iVar14 != 0) && (*(char *)(iVar14 + 0x10a) != '\0')) &&
                   ((*(uint32_t *)(iVar14 + 0x14) & 0x10200) != 0x10200)) goto code_r0x0001800fc388;
                uVar13 = uVar13 - 1;
            } while (-1 < (int32_t)uVar13);
        }
        iVar14 = 0;
code_r0x0001800fc388:
        func_0x00018010e050(iVar14, 1);
    }
    func_0x00018011f370(iVar4 + 0x15b0, 0);
    iVar7 = *(int32_t *)(iVar4 + 0x2134);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f970(iVar4 + 0x2130, iVar8);
    }
    piVar18 = (int32_t *)(iVar4 + 0x2100);
    *(undefined4 *)(iVar4 + 0x2130) = 0;
    iVar7 = *(int32_t *)(iVar4 + 0x2104);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(piVar18, iVar8);
    }
    *piVar18 = 0;
    if (*(int32_t *)(iVar4 + 0x2104) == 0) {
        func_0x00018011fb10(piVar18, 8);
    }
    *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)*piVar18 * 4) = 0x10;
    iVar7 = *piVar18;
    *piVar18 = iVar7 + 1;
    *(undefined4 *)(iVar4 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)iVar7 * 4);
    func_0x00018011f140(iVar4 + 0x2110, 0);
    if ((*(uint8_t *)(iVar4 + 0x30) & 0x80) != 0) {
        iVar14 = *(int64_t *)(iVar4 + 0x15f0);
        *(undefined8 *)(iVar4 + 0x2b80) = 0;
        if (iVar14 != 0) {
            if (*(int64_t *)(iVar14 + 0x4c8) == 0) {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar14 + 0x418) + 0x4c0);
                if (iVar14 != 0) {
                    *(int64_t *)(iVar4 + 0x2b80) = iVar14;
                }
            } else {
                uVar12 = func_0x00018011bfb0(*(int64_t *)(iVar14 + 0x4c8), *(undefined8 *)(iVar4 + 0x118));
                *(undefined8 *)(iVar4 + 0x2b80) = uVar12;
            }
        }
        piVar18 = *(int32_t **)(iVar4 + 0x2900);
        piVar20 = piVar18 + (int64_t)*(int32_t *)(iVar4 + 0x28f8) * 0x10;
        for (; piVar18 != piVar20; piVar18 = piVar18 + 0x10) {
            if (*piVar18 == 1) {
                func_0x000180115650(iVar4, piVar18);
            }
        }
        iVar7 = *(int32_t *)(iVar4 + 0x28fc);
        if (iVar7 < 0) {
            iVar7 = iVar7 + iVar7 / 2;
            iVar8 = iVar6;
            if (0 < iVar7) {
                iVar8 = iVar7;
            }
            func_0x00018011fa30(iVar4 + 0x28f8, iVar8);
        }
        *(undefined4 *)(iVar4 + 0x28f8) = 0;
        if (0 < *(int32_t *)(iVar4 + 0x28e8)) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar4 + 0x28f0) + 8 + (int64_t)iVar6 * 0x10);
                if (((iVar14 != 0) && (*(int64_t *)(iVar14 + 0x18) == 0)) &&
                   ((*(uint32_t *)(iVar14 + 0x10) & 0x400) == 0)) {
                    func_0x000180116d90();
                }
                iVar6 = iVar6 + 1;
            } while (iVar6 < *(int32_t *)(iVar4 + 0x28e8));
        }
    }
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(iVar4 + 2) = 1;
    *(uint32_t *)(iVar14 + 0x2008) = *(uint32_t *)(iVar14 + 0x2008) | 2;
    *(undefined4 *)(iVar14 + 0x202c) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2030) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2010) = 4;
    func_0x0001801019f0(0x1806444f8, 0, 0);
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined4 *)(iVar4 + 0x2a5c) = 0;
    *(undefined2 *)(iVar4 + 0x2a60) = *(undefined2 *)(iVar14 + 0x15b0);
    *(undefined2 *)(iVar4 + 0x2a62) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x148);
    *(undefined2 *)(iVar4 + 0x2a64) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x1e0);
    *(undefined2 *)(iVar4 + 0x2a66) = *(undefined2 *)(iVar14 + 0x20c0);
    *(undefined2 *)(iVar4 + 0x2a68) = *(undefined2 *)(iVar14 + 0x20d0);
    *(undefined2 *)(iVar4 + 0x2a6a) = *(undefined2 *)(iVar14 + 0x20e0);
    *(undefined2 *)(iVar4 + 0x2a6c) = *(undefined2 *)(iVar14 + 0x20f0);
    *(undefined2 *)(iVar4 + 0x2a6e) = *(undefined2 *)(iVar14 + 0x2110);
    *(undefined2 *)(iVar4 + 0x2a70) = *(undefined2 *)(iVar14 + 0x2100);
    *(undefined2 *)(iVar4 + 0x2a72) = *(undefined2 *)(iVar14 + 0x2130);
    *(undefined2 *)(iVar4 + 0x2a74) = *(undefined2 *)(iVar14 + 0x281c);
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar17 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    for (; iVar14 != iVar17; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 1) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fc1bd
// Address: 0x1800fc1bd
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Removing arg arg_2480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24a8h because it doesn't fit into ProtoModel

void fcn.1800fb4a0(undefined8 placeholder_0, int64_t arg2)
{
    float *pfVar1;
    int64_t *piVar2;
    bool bVar3;
    int64_t iVar4;
    char cVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    float *pfVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    int64_t iVar14;
    int64_t *piVar15;
    char *pcVar16;
    int64_t iVar17;
    int32_t *piVar18;
    int64_t iVar19;
    int32_t *piVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    uVar13 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2970);
    while (uVar13 = uVar13 - 1, -1 < (int32_t)uVar13) {
        iVar14 = (uint64_t)uVar13 * 0x20 + *(int64_t *)(iVar4 + 0x2978);
        if (*(int32_t *)(iVar14 + 4) == 7) {
            func_0x000180498030(iVar14, iVar14 + 0x20, 
                                ((int64_t)*(int32_t *)(iVar4 + 0x2970) - (uint64_t)uVar13) * 0x20 + -0x20);
            *(int32_t *)(iVar4 + 0x2970) = *(int32_t *)(iVar4 + 0x2970) + -1;
        }
    }
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    iVar17 = iVar4;
    for (; iVar14 != iVar19; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 0) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    *(undefined4 *)(iVar4 + 0x12d0) = *(undefined4 *)(iVar4 + 0x12cc);
    uVar13 = *(uint32_t *)(iVar17 + 0x30);
    if ((uVar13 & 4) != 0) {
        uVar13 = uVar13 & 0xfffffffb;
        *(undefined *)(iVar17 + 0x7a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 & 8) != 0) {
        uVar13 = uVar13 & 0xfffffff7;
        *(undefined *)(iVar17 + 0x7b) = 0;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xe & 1) != 0) {
        uVar13 = uVar13 & 0xffffbfff;
        *(undefined *)(iVar17 + 0x8a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xf & 1) != 0) {
        uVar13 = uVar13 & 0xffff7fff;
        *(undefined *)(iVar17 + 0x8b) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((*(int64_t *)(iVar17 + 0xc30) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc48) == 0 || (*(int64_t *)(iVar17 + 0xc48) == 0x18011e8a0)))) {
        *(undefined8 *)(iVar17 + 0xc48) = 0x18010a030;
    }
    if ((*(int64_t *)(iVar17 + 0xc38) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc50) == 0 || (*(int64_t *)(iVar17 + 0xc50) == 0x18011e9d0)))) {
        *(undefined8 *)(iVar17 + 0xc50) = 0x18010a050;
    }
    if (((uVar13 >> 10 & 1) != 0) && ((*(uint32_t *)(iVar17 + 0x34) & 0xc00) != 0xc00)) {
        *(uint32_t *)(iVar17 + 0x30) = uVar13 & 0xfffffbff;
    }
    *(undefined4 *)(iVar4 + 0x12cc) = *(undefined4 *)(iVar4 + 0x30);
    if (*(char *)(iVar17 + 0x2928) == '\0') {
        if ((*(int64_t *)(iVar17 + 0x50) != 0) &&
           (iVar14 = func_0x0001800f5b50(*(int64_t *)(iVar17 + 0x50), 0x180625030), iVar14 != 0)) {
            iVar6 = func_0x00018046d704(iVar14);
            if ((iVar6 != -1) && (iVar7 = func_0x000180461598(iVar14, 0, 2), iVar7 == 0)) {
                iVar7 = func_0x00018046d704(iVar14);
                iVar19 = (int64_t)iVar7;
                if ((((iVar7 != -1) && (iVar6 = func_0x000180461598(iVar14, iVar6, 0), iVar6 == 0)) && (iVar19 != -1))
                   && (iVar9 = func_0x00018046d050(iVar19), iVar9 != 0)) {
                    iVar10 = func_0x0001804611b4(iVar9, 1, iVar19, iVar14);
                    if (iVar10 == iVar19) {
                        func_0x00018045ff84(iVar14);
                        if (iVar19 != 0) {
                            func_0x000180112840(iVar9, iVar19);
                        }
                        fcn.180460d90(iVar9);
                    } else {
                        func_0x00018045ff84(iVar14);
                        fcn.180460d90(iVar9);
                    }
                    goto code_r0x0001800fb715;
                }
            }
            func_0x00018045ff84(iVar14);
        }
code_r0x0001800fb715:
        *(undefined *)(iVar17 + 0x2928) = 1;
    }
    iVar6 = 0;
    if ((0.0 < *(float *)(iVar17 + 0x292c)) &&
       (fVar21 = *(float *)(iVar17 + 0x292c) - *(float *)(iVar17 + 0x48), *(float *)(iVar17 + 0x292c) = fVar21,
       fVar21 <= 0.0)) {
        if (*(int64_t *)(iVar17 + 0x50) == 0) {
            *(undefined *)(iVar17 + 0xec) = 1;
        } else {
            func_0x000180112a70();
        }
        *(undefined4 *)(iVar17 + 0x292c) = 0;
    }
    *(int32_t *)(iVar4 + 4) = *(int32_t *)(iVar4 + 4) + 1;
    *(undefined2 *)(iVar4 + 0x281e) = 0;
    *(undefined4 *)(iVar4 + 0x15d0) = 0;
    *(double *)(iVar4 + 0x18) = (double)*(float *)(iVar4 + 0x48) + *(double *)(iVar4 + 0x18);
    iVar7 = *(int32_t *)(iVar4 + 0x283c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(iVar4 + 0x2838, iVar8);
    }
    fVar21 = 3.402823e+38;
    *(undefined4 *)(iVar4 + 0x2838) = 0;
    *(float *)(iVar4 + 0x2c80) =
         (*(float *)(iVar4 + 0x48) - *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4)) +
         *(float *)(iVar4 + 0x2c80);
    *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4) = *(float *)(iVar4 + 0x48);
    iVar8 = *(int32_t *)(iVar4 + 0x2c7c) + 1;
    *(int32_t *)(iVar4 + 0x2c78) = (*(int32_t *)(iVar4 + 0x2c78) + 1) % 0x3c;
    iVar7 = 0x3c;
    if (iVar8 < 0x3c) {
        iVar7 = iVar8;
    }
    *(int32_t *)(iVar4 + 0x2c7c) = iVar7;
    if (*(float *)(iVar4 + 0x2c80) <= 0.0) {
        fVar22 = 3.402823e+38;
    } else {
        fVar22 = 1.0 / (*(float *)(iVar4 + 0x2c80) / (float)iVar7);
    }
    *(float *)(iVar4 + 0xf0) = fVar22;
    iVar7 = *(int32_t *)(iVar4 + 0x156c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f9d0(iVar4 + 0x1568, iVar8);
    }
    *(undefined4 *)(iVar4 + 0x1568) = 0;
    func_0x0001801093d0(*(undefined *)(iVar4 + 0x8e));
    func_0x000180113b10();
    func_0x000180106aa0();
    fcn.1800fb280();
    func_0x000180106fa0();
    *(undefined *)(iVar4 + 1) = 1;
    piVar15 = *(int64_t **)(iVar4 + 0x2158);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x2150);
    iVar14 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar14, piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        *(undefined8 *)(iVar14 + 0x40) = 0;
        *(undefined *)(iVar14 + 200) = 0;
        iVar14 = *(int64_t *)0x180781f28;
    }
    if ((*(char *)(iVar4 + 0x2400) != '\0') &&
       (iVar7 = *(int32_t *)(iVar4 + 0x241c), iVar7 == *(int32_t *)(iVar4 + 0x1654))) {
        if (*(int32_t *)(iVar14 + 0x1654) == iVar7) {
            *(int32_t *)(iVar14 + 0x1658) = iVar7;
        }
        if (*(int32_t *)(iVar14 + 0x1684) == iVar7) {
            *(undefined *)(iVar14 + 0x168d) = 1;
        }
    }
    if ((((*(char *)(iVar4 + 0xb5) != '\0') && (*(char *)(iVar4 + 0x138) != '\0')) ||
        (*(undefined4 *)(iVar4 + 0x1634) = 0, *(char *)(iVar4 + 0xb5) != '\0')) && (1 < *(int32_t *)(iVar4 + 0x1644))) {
        *(undefined4 *)(iVar4 + 0x1634) = *(undefined4 *)(iVar4 + 0x1640);
    }
    piVar18 = (int32_t *)(iVar4 + 0x163c);
    if (*(int32_t *)(iVar4 + 0x1640) == 0) {
        *(undefined4 *)(iVar4 + 0x1648) = 0;
code_r0x0001800fb97d:
        *(undefined4 *)(iVar4 + 0x164c) = 0;
    } else if ((*piVar18 != 0) && (*(int32_t *)(iVar4 + 0x1654) == *piVar18)) goto code_r0x0001800fb97d;
    iVar7 = *piVar18;
    piVar20 = (int32_t *)(iVar4 + 0x1654);
    fVar22 = *(float *)(iVar4 + 0x48);
    if ((iVar7 != 0) && (*(float *)(iVar4 + 0x1648) = fVar22 + *(float *)(iVar4 + 0x1648), *piVar20 != iVar7)) {
        *(float *)(iVar4 + 0x164c) = fVar22 + *(float *)(iVar4 + 0x164c);
    }
    *piVar18 = 0;
    iVar8 = *piVar20;
    *(int32_t *)(iVar4 + 0x1640) = iVar7;
    *(undefined4 *)(iVar4 + 0x1644) = 0;
    *(undefined2 *)(iVar4 + 0x1650) = 0;
    if (((iVar8 != 0) && (*(int32_t *)(iVar4 + 0x1658) != iVar8)) && (*(int32_t *)(iVar4 + 0x1680) == iVar8)) {
        fcn.1800f9f30(0, 0);
        fVar22 = *(float *)(iVar4 + 0x48);
    }
    iVar7 = *piVar20;
    if (iVar7 != 0) {
        *(float *)(iVar4 + 0x165c) = fVar22 + *(float *)(iVar4 + 0x165c);
    }
    *(int32_t *)(iVar4 + 0x1680) = iVar7;
    *(int32_t *)(iVar4 + 0x1658) = 0;
    *(undefined *)(iVar4 + 0x1665) = 0;
    *(undefined *)(iVar4 + 0x1660) = 0;
    *(float *)(iVar4 + 0x169c) = fVar22 + *(float *)(iVar4 + 0x169c);
    if ((*(int32_t *)(iVar4 + 0x2780) != 0) && (iVar7 != *(int32_t *)(iVar4 + 0x2780))) {
        *(undefined4 *)(iVar4 + 0x2780) = 0;
    }
    if ((*(int32_t *)(iVar4 + 0x277c) != 0) && (*(int32_t *)(iVar4 + 0x277c) != *(int32_t *)(iVar4 + 0x1684))) {
        *(undefined4 *)(iVar4 + 0x277c) = 0;
    }
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x1f68) = 0;
        *(undefined *)(iVar4 + 0x1f6c) = 0;
    }
    if (*(int32_t *)(iVar4 + 0x1688) < *(int32_t *)(iVar4 + 4)) {
        *(undefined4 *)(iVar4 + 0x1684) = 0;
    }
    iVar7 = *(int32_t *)(iVar4 + 0x2638);
    *(undefined *)(iVar4 + 0x168d) = 0;
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x2648) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(int32_t *)(iVar4 + 0x2648) = iVar7;
    }
    if (*(int64_t *)(iVar4 + 0x15e8) == 0) {
        *(undefined4 *)(iVar4 + 0x264c) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(undefined4 *)(iVar4 + 0x264c) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x15e8) + 0x10);
    }
    *(int32_t *)(iVar4 + 0x263c) = iVar7;
    if (iVar7 == 0) {
        if (0.0 < *(float *)(iVar4 + 0x2640)) {
            fVar23 = fVar22 + *(float *)(iVar4 + 0x2644);
            *(float *)(iVar4 + 0x2644) = fVar23;
            fVar24 = 0.25;
            if (0.25 <= fVar22 + fVar22) {
                fVar24 = fVar22 + fVar22;
            }
            if (fVar24 <= fVar23) {
                *(undefined8 *)(iVar4 + 0x2640) = 0;
            }
        }
    } else {
        *(undefined4 *)(iVar4 + 0x2644) = 0;
        *(undefined4 *)(iVar4 + 0x2638) = 0;
        *(float *)(iVar4 + 0x2640) = *(float *)(iVar4 + 0x2640) + fVar22;
    }
    func_0x000180108270();
    *(undefined4 *)(iVar4 + 0x2488) = *(undefined4 *)(iVar4 + 0x2484);
    *(undefined4 *)(iVar4 + 0x247c) = *(undefined4 *)(iVar4 + 0x2478);
    *(undefined4 *)(iVar4 + 0x2478) = 0;
    *(undefined8 *)(iVar4 + 0x2480) = 0x7f7fffff;
    *(undefined2 *)(iVar4 + 0x2401) = 0;
    *(undefined4 *)(iVar4 + 0x2490) = 0;
    if (*(char *)(iVar4 + 0x2400) != '\0') {
        if (*piVar20 == 0) {
            pcVar16 = "#DragDropCancelHandler";
            cVar5 = '#';
            do {
                if (((cVar5 == '#') && (*pcVar16 == '#')) && (pcVar16[1] == '#')) {
                    pcVar16 = pcVar16 + 2;
                }
                cVar5 = *pcVar16;
                pcVar16 = pcVar16 + 1;
            } while (cVar5 != '\0');
        }
        cVar5 = func_0x000180109d80();
        if (cVar5 != '\0') {
            fcn.1800f9f30(0, 0);
            func_0x0001801120a0();
        }
    }
    *(undefined8 *)(iVar4 + 0x2820) = 0;
    func_0x00018010f2f0();
    func_0x000180108830();
    func_0x000180114da0(iVar4);
    if ((*(char *)(iVar4 + 0x20b9) != '\0') || (*(float *)(iVar4 + 0x98) < 0.0)) {
        bVar3 = true;
    } else {
        bVar3 = false;
        fVar21 = (float)*(double *)(iVar4 + 0x18) - *(float *)(iVar4 + 0x98);
    }
    piVar15 = *(int64_t **)(iVar4 + 0x1588);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x1580);
    for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        cVar5 = *(char *)(iVar14 + 0x109);
        *(char *)(iVar14 + 0x10a) = cVar5;
        *(undefined *)(iVar14 + 0x109) = 0;
        *(undefined *)(iVar14 + 0x10b) = 0;
        *(undefined2 *)(iVar14 + 0x11a) = *(undefined2 *)(iVar14 + 0x118);
        *(undefined2 *)(iVar14 + 0x118) = 0;
        if (((cVar5 == '\0') || (bVar3)) &&
           ((*(char *)(iVar14 + 0x494) == '\0' &&
            (*(float *)(iVar14 + 0x2e8) <= fVar21 && fVar21 != *(float *)(iVar14 + 0x2e8))))) {
            iVar17 = *(int64_t *)(iVar14 + 800);
            *(undefined *)(iVar14 + 0x494) = 1;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x10) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x14);
            if (iVar8 < *(int32_t *)(iVar17 + 0x14)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x48c) = iVar7;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x20) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x24);
            if (iVar8 < *(int32_t *)(iVar17 + 0x24)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x490) = iVar7;
            if (*(int64_t *)(iVar14 + 0x150) != 0) {
                *(undefined8 *)(iVar14 + 0x148) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x150) = 0;
            }
            func_0x000180124110(*(undefined8 *)(iVar14 + 800));
            if (*(int64_t *)(iVar14 + 0x1f8) != 0) {
                *(undefined8 *)(iVar14 + 0x1f0) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x1f8) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x250) != 0) {
                *(undefined8 *)(iVar14 + 0x248) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x250) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x260) != 0) {
                *(undefined8 *)(iVar14 + 600) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x260) = 0;
            }
        }
    }
    fcn.1800fae50(iVar4 + 0x118);
    iVar17 = *(int64_t *)0x180781f28;
    iVar14 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1600);
    if (iVar14 == 0) {
        if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) == 0) ||
           (iVar7 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1654),
           *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) + 0xc4) != iVar7)) goto code_r0x0001800fbfc6;
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar7;
        if (*(int32_t *)(iVar17 + 0x1684) == iVar7) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') goto code_r0x0001800fbfc6;
    } else {
        piVar18 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1654);
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = *piVar18;
        if (*(int32_t *)(iVar17 + 0x1684) == *piVar18) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        iVar14 = *(int64_t *)(iVar14 + 0x428);
        if ((*(char *)(iVar14 + 0x10a) == '\0') && (*(char *)(iVar14 + 0x109) == '\0')) {
            bVar3 = true;
        } else {
            bVar3 = false;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') {
            pfVar1 = (float *)(iVar17 + 0x118);
            pfVar11 = pfVar1;
            if (pfVar1 == (float *)0x0) {
                pfVar11 = (float *)(*(int64_t *)0x180781f28 + 0x118);
            }
            if (((-256000.0 <= *pfVar11) && (-256000.0 <= pfVar11[1])) && (!bVar3)) {
                fVar22 = *pfVar1 - *(float *)(iVar17 + 0x166c);
                fVar24 = *(float *)(iVar17 + 0x11c) - *(float *)(iVar17 + 0x1670);
                var_8h._0_4_ = fVar22;
                var_8h._4_4_ = fVar24;
                if ((*(float *)(iVar14 + 0x60) != fVar22) || (*(float *)(iVar14 + 100) != fVar24)) {
                    func_0x000180106470(iVar14, &var_8h, 1);
                    if ((*(int64_t *)(iVar14 + 0x48) != 0) && (*(char *)(iVar14 + 0x108) != '\0')) {
                        *(uint64_t *)(*(int64_t *)(iVar14 + 0x48) + 8) = CONCAT44(fVar24, fVar22);
                        iVar14 = *(int64_t *)(iVar14 + 0x48);
                        *(float *)(iVar14 + 0x20) = *(float *)(iVar14 + 0x148) + *(float *)(iVar14 + 8);
                        *(float *)(iVar14 + 0x24) = *(float *)(iVar14 + 0x14c) + *(float *)(iVar14 + 0xc);
                        fVar24 = (*(float *)(iVar14 + 0x14) - *(float *)(iVar14 + 0x14c)) - *(float *)(iVar14 + 0x154);
                        fVar23 = (*(float *)(iVar14 + 0x10) - *(float *)(iVar14 + 0x148)) - *(float *)(iVar14 + 0x150);
                        fVar22 = 0.0;
                        if (0.0 <= fVar24) {
                            fVar22 = fVar24;
                        }
                        fVar24 = 0.0;
                        if (0.0 <= fVar23) {
                            fVar24 = fVar23;
                        }
                        *(float *)(iVar14 + 0x2c) = fVar22;
                        *(float *)(iVar14 + 0x28) = fVar24;
                    }
                }
                func_0x00018010e050(*(undefined8 *)(iVar17 + 0x1600), 0);
                goto code_r0x0001800fbfc6;
            }
        }
        fcn.1800fac90();
    }
    fcn.1800f9f30(0, 0);
code_r0x0001800fbfc6:
    uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    if (-1 < (int32_t)uVar13) {
        do {
            iVar14 = *(int64_t *)((uint64_t)uVar13 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar14 != 0) && ((*(uint32_t *)(iVar14 + 0x14) & 0x8000000) != 0)) goto code_r0x0001800fc015;
            uVar13 = uVar13 - 1;
        } while (-1 < (int32_t)uVar13);
    }
    if ((*(int64_t *)(iVar4 + 0x23c0) == 0) || (*(float *)(iVar4 + 0x23dc) <= 0.0)) {
        fVar22 = *(float *)(iVar4 + 0x23fc) - *(float *)(iVar4 + 0x48) * 10.0;
        if (fVar22 <= 0.0) {
            fVar22 = 0.0;
        }
    } else {
code_r0x0001800fc015:
        fVar22 = *(float *)(iVar4 + 0x48) * 6.0 + *(float *)(iVar4 + 0x23fc);
        if (1.0 <= fVar22) {
            fVar22 = 1.0;
        }
    }
    *(float *)(iVar4 + 0x23fc) = fVar22;
    *(undefined4 *)(iVar4 + 0x2650) = 0;
    *(undefined4 *)(iVar4 + 0x28c4) = *(undefined4 *)(iVar4 + 0x28b0);
    *(undefined4 *)(iVar4 + 0x28c8) = *(undefined4 *)(iVar4 + 0x28b4);
    *(undefined4 *)(iVar4 + 0x28cc) = *(undefined4 *)(iVar4 + 0x28b8);
    *(undefined4 *)(iVar4 + 0x28d0) = *(undefined4 *)(iVar4 + 0x28bc);
    *(undefined4 *)(iVar4 + 0x28d4) = *(undefined4 *)(iVar4 + 0x28c0);
    *(undefined8 *)(iVar4 + 0x2c88) = 0xffffffffffffffff;
    *(undefined4 *)(iVar4 + 0x2c84) = 0xffffffff;
    *(undefined2 *)(iVar4 + 0x28b0) = 0;
    func_0x000180108de0();
    iVar7 = iVar6;
    if (0 < *(int32_t *)(iVar4 + 0x2518)) {
        do {
            iVar14 = *(int64_t *)0x180781f28;
            fVar22 = *(float *)(*(int64_t *)(iVar4 + 0x2520) + (int64_t)iVar7 * 4);
            if ((0.0 <= fVar22) && (fVar22 < fVar21)) {
                iVar17 = (int64_t)iVar7 * 0x250 + *(int64_t *)(iVar4 + 0x24f8);
                *(undefined8 *)(iVar17 + 0x1f0) = 0;
                if (*(int64_t *)(iVar17 + 0x1e8) != 0) {
                    *(undefined8 *)(iVar17 + 0x1e0) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x1e8) = 0;
                }
                *(undefined *)(iVar17 + 0x23c) = 1;
                if (*(int64_t *)(iVar17 + 0x198) != 0) {
                    *(undefined8 *)(iVar17 + 400) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x198) = 0;
                }
                *(undefined *)(iVar17 + 0x24b) = 1;
                iVar8 = iVar6;
                if (0 < *(int32_t *)(iVar17 + 0x6c)) {
                    do {
                        iVar19 = (int64_t)iVar8;
                        iVar8 = iVar8 + 1;
                        *(undefined2 *)(iVar19 * 0x74 + 0x54 + *(int64_t *)(iVar17 + 0x18)) = 0xffff;
                    } while (iVar8 < *(int32_t *)(iVar17 + 0x6c));
                }
                *(undefined4 *)
                 (*(int64_t *)(iVar14 + 0x2520) +
                 (int64_t)(int32_t)((iVar17 - *(int64_t *)(iVar14 + 0x24f8)) / 0x250) * 4) = 0xbf800000;
            }
            iVar7 = iVar7 + 1;
        } while (iVar7 < *(int32_t *)(iVar4 + 0x2518));
    }
    iVar14 = *(int64_t *)(iVar4 + 0x24e8);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x24e0) * 0x88 + iVar14;
    iVar17 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar17, iVar14 != iVar19; iVar14 = iVar14 + 0x88) {
        if ((0.0 <= *(float *)(iVar14 + 8)) && (*(float *)(iVar14 + 8) < fVar21)) {
            func_0x000180126a10(iVar14 + 0x28);
            *(undefined4 *)(iVar14 + 8) = 0xbf800000;
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    if (*(char *)(iVar4 + 0x20b9) != '\0') {
        if (*(int64_t *)(iVar17 + 0x2108) != 0) {
            *(undefined8 *)(iVar17 + 0x2100) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2108) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x2118) != 0) {
            *(undefined8 *)(iVar17 + 0x2110) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2118) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x26e8) != 0) {
            *(undefined8 *)(iVar17 + 0x26e0) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x26e8) = 0;
        }
        *(undefined4 *)(iVar17 + 0x26f0) = 0;
        *(undefined4 *)(iVar17 + 0x25f8) = 0;
        func_0x00018011ee60(iVar17 + 0x2600);
        func_0x0001801388c0();
        piVar15 = *(int64_t **)(iVar17 + 0x12e0);
        piVar2 = piVar15 + *(int32_t *)(iVar17 + 0x12d8);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            iVar14 = *piVar15;
            iVar17 = *(int64_t *)(iVar14 + 0x2b0);
            func_0x000180129630(iVar14, 1);
            func_0x000180129f40(&var_8h, iVar14);
            if (((*(int32_t *)(iVar17 + 0x9c) != 0) || ((float)var_8h != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x1c))
                ) || (var_8h._4_4_ != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x20))) {
                func_0x0001801299b0(iVar14);
            }
        }
    }
    *(undefined *)(iVar4 + 0x20b9) = 0;
    if ((*(int64_t *)(iVar4 + 0x21d8) != 0) && (*(char *)(*(int64_t *)(iVar4 + 0x21d8) + 0x10a) == '\0')) {
        uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1590) - 1;
        if (-1 < (int32_t)uVar13) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1598) + (uint64_t)uVar13 * 8);
                if (((iVar14 != 0) && (*(char *)(iVar14 + 0x10a) != '\0')) &&
                   ((*(uint32_t *)(iVar14 + 0x14) & 0x10200) != 0x10200)) goto code_r0x0001800fc388;
                uVar13 = uVar13 - 1;
            } while (-1 < (int32_t)uVar13);
        }
        iVar14 = 0;
code_r0x0001800fc388:
        func_0x00018010e050(iVar14, 1);
    }
    func_0x00018011f370(iVar4 + 0x15b0, 0);
    iVar7 = *(int32_t *)(iVar4 + 0x2134);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f970(iVar4 + 0x2130, iVar8);
    }
    piVar18 = (int32_t *)(iVar4 + 0x2100);
    *(undefined4 *)(iVar4 + 0x2130) = 0;
    iVar7 = *(int32_t *)(iVar4 + 0x2104);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(piVar18, iVar8);
    }
    *piVar18 = 0;
    if (*(int32_t *)(iVar4 + 0x2104) == 0) {
        func_0x00018011fb10(piVar18, 8);
    }
    *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)*piVar18 * 4) = 0x10;
    iVar7 = *piVar18;
    *piVar18 = iVar7 + 1;
    *(undefined4 *)(iVar4 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)iVar7 * 4);
    func_0x00018011f140(iVar4 + 0x2110, 0);
    if ((*(uint8_t *)(iVar4 + 0x30) & 0x80) != 0) {
        iVar14 = *(int64_t *)(iVar4 + 0x15f0);
        *(undefined8 *)(iVar4 + 0x2b80) = 0;
        if (iVar14 != 0) {
            if (*(int64_t *)(iVar14 + 0x4c8) == 0) {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar14 + 0x418) + 0x4c0);
                if (iVar14 != 0) {
                    *(int64_t *)(iVar4 + 0x2b80) = iVar14;
                }
            } else {
                uVar12 = func_0x00018011bfb0(*(int64_t *)(iVar14 + 0x4c8), *(undefined8 *)(iVar4 + 0x118));
                *(undefined8 *)(iVar4 + 0x2b80) = uVar12;
            }
        }
        piVar18 = *(int32_t **)(iVar4 + 0x2900);
        piVar20 = piVar18 + (int64_t)*(int32_t *)(iVar4 + 0x28f8) * 0x10;
        for (; piVar18 != piVar20; piVar18 = piVar18 + 0x10) {
            if (*piVar18 == 1) {
                func_0x000180115650(iVar4, piVar18);
            }
        }
        iVar7 = *(int32_t *)(iVar4 + 0x28fc);
        if (iVar7 < 0) {
            iVar7 = iVar7 + iVar7 / 2;
            iVar8 = iVar6;
            if (0 < iVar7) {
                iVar8 = iVar7;
            }
            func_0x00018011fa30(iVar4 + 0x28f8, iVar8);
        }
        *(undefined4 *)(iVar4 + 0x28f8) = 0;
        if (0 < *(int32_t *)(iVar4 + 0x28e8)) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar4 + 0x28f0) + 8 + (int64_t)iVar6 * 0x10);
                if (((iVar14 != 0) && (*(int64_t *)(iVar14 + 0x18) == 0)) &&
                   ((*(uint32_t *)(iVar14 + 0x10) & 0x400) == 0)) {
                    func_0x000180116d90();
                }
                iVar6 = iVar6 + 1;
            } while (iVar6 < *(int32_t *)(iVar4 + 0x28e8));
        }
    }
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(iVar4 + 2) = 1;
    *(uint32_t *)(iVar14 + 0x2008) = *(uint32_t *)(iVar14 + 0x2008) | 2;
    *(undefined4 *)(iVar14 + 0x202c) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2030) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2010) = 4;
    func_0x0001801019f0(0x1806444f8, 0, 0);
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined4 *)(iVar4 + 0x2a5c) = 0;
    *(undefined2 *)(iVar4 + 0x2a60) = *(undefined2 *)(iVar14 + 0x15b0);
    *(undefined2 *)(iVar4 + 0x2a62) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x148);
    *(undefined2 *)(iVar4 + 0x2a64) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x1e0);
    *(undefined2 *)(iVar4 + 0x2a66) = *(undefined2 *)(iVar14 + 0x20c0);
    *(undefined2 *)(iVar4 + 0x2a68) = *(undefined2 *)(iVar14 + 0x20d0);
    *(undefined2 *)(iVar4 + 0x2a6a) = *(undefined2 *)(iVar14 + 0x20e0);
    *(undefined2 *)(iVar4 + 0x2a6c) = *(undefined2 *)(iVar14 + 0x20f0);
    *(undefined2 *)(iVar4 + 0x2a6e) = *(undefined2 *)(iVar14 + 0x2110);
    *(undefined2 *)(iVar4 + 0x2a70) = *(undefined2 *)(iVar14 + 0x2100);
    *(undefined2 *)(iVar4 + 0x2a72) = *(undefined2 *)(iVar14 + 0x2130);
    *(undefined2 *)(iVar4 + 0x2a74) = *(undefined2 *)(iVar14 + 0x281c);
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar17 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    for (; iVar14 != iVar17; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 1) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fc224
// Address: 0x1800fc224
// Size: 279 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Removing arg arg_2480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24a8h because it doesn't fit into ProtoModel

void fcn.1800fb4a0(undefined8 placeholder_0, int64_t arg2)
{
    float *pfVar1;
    int64_t *piVar2;
    bool bVar3;
    int64_t iVar4;
    char cVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    float *pfVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    int64_t iVar14;
    int64_t *piVar15;
    char *pcVar16;
    int64_t iVar17;
    int32_t *piVar18;
    int64_t iVar19;
    int32_t *piVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    uVar13 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2970);
    while (uVar13 = uVar13 - 1, -1 < (int32_t)uVar13) {
        iVar14 = (uint64_t)uVar13 * 0x20 + *(int64_t *)(iVar4 + 0x2978);
        if (*(int32_t *)(iVar14 + 4) == 7) {
            func_0x000180498030(iVar14, iVar14 + 0x20, 
                                ((int64_t)*(int32_t *)(iVar4 + 0x2970) - (uint64_t)uVar13) * 0x20 + -0x20);
            *(int32_t *)(iVar4 + 0x2970) = *(int32_t *)(iVar4 + 0x2970) + -1;
        }
    }
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    iVar17 = iVar4;
    for (; iVar14 != iVar19; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 0) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    *(undefined4 *)(iVar4 + 0x12d0) = *(undefined4 *)(iVar4 + 0x12cc);
    uVar13 = *(uint32_t *)(iVar17 + 0x30);
    if ((uVar13 & 4) != 0) {
        uVar13 = uVar13 & 0xfffffffb;
        *(undefined *)(iVar17 + 0x7a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 & 8) != 0) {
        uVar13 = uVar13 & 0xfffffff7;
        *(undefined *)(iVar17 + 0x7b) = 0;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xe & 1) != 0) {
        uVar13 = uVar13 & 0xffffbfff;
        *(undefined *)(iVar17 + 0x8a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xf & 1) != 0) {
        uVar13 = uVar13 & 0xffff7fff;
        *(undefined *)(iVar17 + 0x8b) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((*(int64_t *)(iVar17 + 0xc30) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc48) == 0 || (*(int64_t *)(iVar17 + 0xc48) == 0x18011e8a0)))) {
        *(undefined8 *)(iVar17 + 0xc48) = 0x18010a030;
    }
    if ((*(int64_t *)(iVar17 + 0xc38) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc50) == 0 || (*(int64_t *)(iVar17 + 0xc50) == 0x18011e9d0)))) {
        *(undefined8 *)(iVar17 + 0xc50) = 0x18010a050;
    }
    if (((uVar13 >> 10 & 1) != 0) && ((*(uint32_t *)(iVar17 + 0x34) & 0xc00) != 0xc00)) {
        *(uint32_t *)(iVar17 + 0x30) = uVar13 & 0xfffffbff;
    }
    *(undefined4 *)(iVar4 + 0x12cc) = *(undefined4 *)(iVar4 + 0x30);
    if (*(char *)(iVar17 + 0x2928) == '\0') {
        if ((*(int64_t *)(iVar17 + 0x50) != 0) &&
           (iVar14 = func_0x0001800f5b50(*(int64_t *)(iVar17 + 0x50), 0x180625030), iVar14 != 0)) {
            iVar6 = func_0x00018046d704(iVar14);
            if ((iVar6 != -1) && (iVar7 = func_0x000180461598(iVar14, 0, 2), iVar7 == 0)) {
                iVar7 = func_0x00018046d704(iVar14);
                iVar19 = (int64_t)iVar7;
                if ((((iVar7 != -1) && (iVar6 = func_0x000180461598(iVar14, iVar6, 0), iVar6 == 0)) && (iVar19 != -1))
                   && (iVar9 = func_0x00018046d050(iVar19), iVar9 != 0)) {
                    iVar10 = func_0x0001804611b4(iVar9, 1, iVar19, iVar14);
                    if (iVar10 == iVar19) {
                        func_0x00018045ff84(iVar14);
                        if (iVar19 != 0) {
                            func_0x000180112840(iVar9, iVar19);
                        }
                        fcn.180460d90(iVar9);
                    } else {
                        func_0x00018045ff84(iVar14);
                        fcn.180460d90(iVar9);
                    }
                    goto code_r0x0001800fb715;
                }
            }
            func_0x00018045ff84(iVar14);
        }
code_r0x0001800fb715:
        *(undefined *)(iVar17 + 0x2928) = 1;
    }
    iVar6 = 0;
    if ((0.0 < *(float *)(iVar17 + 0x292c)) &&
       (fVar21 = *(float *)(iVar17 + 0x292c) - *(float *)(iVar17 + 0x48), *(float *)(iVar17 + 0x292c) = fVar21,
       fVar21 <= 0.0)) {
        if (*(int64_t *)(iVar17 + 0x50) == 0) {
            *(undefined *)(iVar17 + 0xec) = 1;
        } else {
            func_0x000180112a70();
        }
        *(undefined4 *)(iVar17 + 0x292c) = 0;
    }
    *(int32_t *)(iVar4 + 4) = *(int32_t *)(iVar4 + 4) + 1;
    *(undefined2 *)(iVar4 + 0x281e) = 0;
    *(undefined4 *)(iVar4 + 0x15d0) = 0;
    *(double *)(iVar4 + 0x18) = (double)*(float *)(iVar4 + 0x48) + *(double *)(iVar4 + 0x18);
    iVar7 = *(int32_t *)(iVar4 + 0x283c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(iVar4 + 0x2838, iVar8);
    }
    fVar21 = 3.402823e+38;
    *(undefined4 *)(iVar4 + 0x2838) = 0;
    *(float *)(iVar4 + 0x2c80) =
         (*(float *)(iVar4 + 0x48) - *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4)) +
         *(float *)(iVar4 + 0x2c80);
    *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4) = *(float *)(iVar4 + 0x48);
    iVar8 = *(int32_t *)(iVar4 + 0x2c7c) + 1;
    *(int32_t *)(iVar4 + 0x2c78) = (*(int32_t *)(iVar4 + 0x2c78) + 1) % 0x3c;
    iVar7 = 0x3c;
    if (iVar8 < 0x3c) {
        iVar7 = iVar8;
    }
    *(int32_t *)(iVar4 + 0x2c7c) = iVar7;
    if (*(float *)(iVar4 + 0x2c80) <= 0.0) {
        fVar22 = 3.402823e+38;
    } else {
        fVar22 = 1.0 / (*(float *)(iVar4 + 0x2c80) / (float)iVar7);
    }
    *(float *)(iVar4 + 0xf0) = fVar22;
    iVar7 = *(int32_t *)(iVar4 + 0x156c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f9d0(iVar4 + 0x1568, iVar8);
    }
    *(undefined4 *)(iVar4 + 0x1568) = 0;
    func_0x0001801093d0(*(undefined *)(iVar4 + 0x8e));
    func_0x000180113b10();
    func_0x000180106aa0();
    fcn.1800fb280();
    func_0x000180106fa0();
    *(undefined *)(iVar4 + 1) = 1;
    piVar15 = *(int64_t **)(iVar4 + 0x2158);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x2150);
    iVar14 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar14, piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        *(undefined8 *)(iVar14 + 0x40) = 0;
        *(undefined *)(iVar14 + 200) = 0;
        iVar14 = *(int64_t *)0x180781f28;
    }
    if ((*(char *)(iVar4 + 0x2400) != '\0') &&
       (iVar7 = *(int32_t *)(iVar4 + 0x241c), iVar7 == *(int32_t *)(iVar4 + 0x1654))) {
        if (*(int32_t *)(iVar14 + 0x1654) == iVar7) {
            *(int32_t *)(iVar14 + 0x1658) = iVar7;
        }
        if (*(int32_t *)(iVar14 + 0x1684) == iVar7) {
            *(undefined *)(iVar14 + 0x168d) = 1;
        }
    }
    if ((((*(char *)(iVar4 + 0xb5) != '\0') && (*(char *)(iVar4 + 0x138) != '\0')) ||
        (*(undefined4 *)(iVar4 + 0x1634) = 0, *(char *)(iVar4 + 0xb5) != '\0')) && (1 < *(int32_t *)(iVar4 + 0x1644))) {
        *(undefined4 *)(iVar4 + 0x1634) = *(undefined4 *)(iVar4 + 0x1640);
    }
    piVar18 = (int32_t *)(iVar4 + 0x163c);
    if (*(int32_t *)(iVar4 + 0x1640) == 0) {
        *(undefined4 *)(iVar4 + 0x1648) = 0;
code_r0x0001800fb97d:
        *(undefined4 *)(iVar4 + 0x164c) = 0;
    } else if ((*piVar18 != 0) && (*(int32_t *)(iVar4 + 0x1654) == *piVar18)) goto code_r0x0001800fb97d;
    iVar7 = *piVar18;
    piVar20 = (int32_t *)(iVar4 + 0x1654);
    fVar22 = *(float *)(iVar4 + 0x48);
    if ((iVar7 != 0) && (*(float *)(iVar4 + 0x1648) = fVar22 + *(float *)(iVar4 + 0x1648), *piVar20 != iVar7)) {
        *(float *)(iVar4 + 0x164c) = fVar22 + *(float *)(iVar4 + 0x164c);
    }
    *piVar18 = 0;
    iVar8 = *piVar20;
    *(int32_t *)(iVar4 + 0x1640) = iVar7;
    *(undefined4 *)(iVar4 + 0x1644) = 0;
    *(undefined2 *)(iVar4 + 0x1650) = 0;
    if (((iVar8 != 0) && (*(int32_t *)(iVar4 + 0x1658) != iVar8)) && (*(int32_t *)(iVar4 + 0x1680) == iVar8)) {
        fcn.1800f9f30(0, 0);
        fVar22 = *(float *)(iVar4 + 0x48);
    }
    iVar7 = *piVar20;
    if (iVar7 != 0) {
        *(float *)(iVar4 + 0x165c) = fVar22 + *(float *)(iVar4 + 0x165c);
    }
    *(int32_t *)(iVar4 + 0x1680) = iVar7;
    *(int32_t *)(iVar4 + 0x1658) = 0;
    *(undefined *)(iVar4 + 0x1665) = 0;
    *(undefined *)(iVar4 + 0x1660) = 0;
    *(float *)(iVar4 + 0x169c) = fVar22 + *(float *)(iVar4 + 0x169c);
    if ((*(int32_t *)(iVar4 + 0x2780) != 0) && (iVar7 != *(int32_t *)(iVar4 + 0x2780))) {
        *(undefined4 *)(iVar4 + 0x2780) = 0;
    }
    if ((*(int32_t *)(iVar4 + 0x277c) != 0) && (*(int32_t *)(iVar4 + 0x277c) != *(int32_t *)(iVar4 + 0x1684))) {
        *(undefined4 *)(iVar4 + 0x277c) = 0;
    }
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x1f68) = 0;
        *(undefined *)(iVar4 + 0x1f6c) = 0;
    }
    if (*(int32_t *)(iVar4 + 0x1688) < *(int32_t *)(iVar4 + 4)) {
        *(undefined4 *)(iVar4 + 0x1684) = 0;
    }
    iVar7 = *(int32_t *)(iVar4 + 0x2638);
    *(undefined *)(iVar4 + 0x168d) = 0;
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x2648) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(int32_t *)(iVar4 + 0x2648) = iVar7;
    }
    if (*(int64_t *)(iVar4 + 0x15e8) == 0) {
        *(undefined4 *)(iVar4 + 0x264c) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(undefined4 *)(iVar4 + 0x264c) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x15e8) + 0x10);
    }
    *(int32_t *)(iVar4 + 0x263c) = iVar7;
    if (iVar7 == 0) {
        if (0.0 < *(float *)(iVar4 + 0x2640)) {
            fVar23 = fVar22 + *(float *)(iVar4 + 0x2644);
            *(float *)(iVar4 + 0x2644) = fVar23;
            fVar24 = 0.25;
            if (0.25 <= fVar22 + fVar22) {
                fVar24 = fVar22 + fVar22;
            }
            if (fVar24 <= fVar23) {
                *(undefined8 *)(iVar4 + 0x2640) = 0;
            }
        }
    } else {
        *(undefined4 *)(iVar4 + 0x2644) = 0;
        *(undefined4 *)(iVar4 + 0x2638) = 0;
        *(float *)(iVar4 + 0x2640) = *(float *)(iVar4 + 0x2640) + fVar22;
    }
    func_0x000180108270();
    *(undefined4 *)(iVar4 + 0x2488) = *(undefined4 *)(iVar4 + 0x2484);
    *(undefined4 *)(iVar4 + 0x247c) = *(undefined4 *)(iVar4 + 0x2478);
    *(undefined4 *)(iVar4 + 0x2478) = 0;
    *(undefined8 *)(iVar4 + 0x2480) = 0x7f7fffff;
    *(undefined2 *)(iVar4 + 0x2401) = 0;
    *(undefined4 *)(iVar4 + 0x2490) = 0;
    if (*(char *)(iVar4 + 0x2400) != '\0') {
        if (*piVar20 == 0) {
            pcVar16 = "#DragDropCancelHandler";
            cVar5 = '#';
            do {
                if (((cVar5 == '#') && (*pcVar16 == '#')) && (pcVar16[1] == '#')) {
                    pcVar16 = pcVar16 + 2;
                }
                cVar5 = *pcVar16;
                pcVar16 = pcVar16 + 1;
            } while (cVar5 != '\0');
        }
        cVar5 = func_0x000180109d80();
        if (cVar5 != '\0') {
            fcn.1800f9f30(0, 0);
            func_0x0001801120a0();
        }
    }
    *(undefined8 *)(iVar4 + 0x2820) = 0;
    func_0x00018010f2f0();
    func_0x000180108830();
    func_0x000180114da0(iVar4);
    if ((*(char *)(iVar4 + 0x20b9) != '\0') || (*(float *)(iVar4 + 0x98) < 0.0)) {
        bVar3 = true;
    } else {
        bVar3 = false;
        fVar21 = (float)*(double *)(iVar4 + 0x18) - *(float *)(iVar4 + 0x98);
    }
    piVar15 = *(int64_t **)(iVar4 + 0x1588);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x1580);
    for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        cVar5 = *(char *)(iVar14 + 0x109);
        *(char *)(iVar14 + 0x10a) = cVar5;
        *(undefined *)(iVar14 + 0x109) = 0;
        *(undefined *)(iVar14 + 0x10b) = 0;
        *(undefined2 *)(iVar14 + 0x11a) = *(undefined2 *)(iVar14 + 0x118);
        *(undefined2 *)(iVar14 + 0x118) = 0;
        if (((cVar5 == '\0') || (bVar3)) &&
           ((*(char *)(iVar14 + 0x494) == '\0' &&
            (*(float *)(iVar14 + 0x2e8) <= fVar21 && fVar21 != *(float *)(iVar14 + 0x2e8))))) {
            iVar17 = *(int64_t *)(iVar14 + 800);
            *(undefined *)(iVar14 + 0x494) = 1;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x10) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x14);
            if (iVar8 < *(int32_t *)(iVar17 + 0x14)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x48c) = iVar7;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x20) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x24);
            if (iVar8 < *(int32_t *)(iVar17 + 0x24)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x490) = iVar7;
            if (*(int64_t *)(iVar14 + 0x150) != 0) {
                *(undefined8 *)(iVar14 + 0x148) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x150) = 0;
            }
            func_0x000180124110(*(undefined8 *)(iVar14 + 800));
            if (*(int64_t *)(iVar14 + 0x1f8) != 0) {
                *(undefined8 *)(iVar14 + 0x1f0) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x1f8) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x250) != 0) {
                *(undefined8 *)(iVar14 + 0x248) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x250) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x260) != 0) {
                *(undefined8 *)(iVar14 + 600) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x260) = 0;
            }
        }
    }
    fcn.1800fae50(iVar4 + 0x118);
    iVar17 = *(int64_t *)0x180781f28;
    iVar14 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1600);
    if (iVar14 == 0) {
        if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) == 0) ||
           (iVar7 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1654),
           *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) + 0xc4) != iVar7)) goto code_r0x0001800fbfc6;
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar7;
        if (*(int32_t *)(iVar17 + 0x1684) == iVar7) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') goto code_r0x0001800fbfc6;
    } else {
        piVar18 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1654);
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = *piVar18;
        if (*(int32_t *)(iVar17 + 0x1684) == *piVar18) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        iVar14 = *(int64_t *)(iVar14 + 0x428);
        if ((*(char *)(iVar14 + 0x10a) == '\0') && (*(char *)(iVar14 + 0x109) == '\0')) {
            bVar3 = true;
        } else {
            bVar3 = false;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') {
            pfVar1 = (float *)(iVar17 + 0x118);
            pfVar11 = pfVar1;
            if (pfVar1 == (float *)0x0) {
                pfVar11 = (float *)(*(int64_t *)0x180781f28 + 0x118);
            }
            if (((-256000.0 <= *pfVar11) && (-256000.0 <= pfVar11[1])) && (!bVar3)) {
                fVar22 = *pfVar1 - *(float *)(iVar17 + 0x166c);
                fVar24 = *(float *)(iVar17 + 0x11c) - *(float *)(iVar17 + 0x1670);
                var_8h._0_4_ = fVar22;
                var_8h._4_4_ = fVar24;
                if ((*(float *)(iVar14 + 0x60) != fVar22) || (*(float *)(iVar14 + 100) != fVar24)) {
                    func_0x000180106470(iVar14, &var_8h, 1);
                    if ((*(int64_t *)(iVar14 + 0x48) != 0) && (*(char *)(iVar14 + 0x108) != '\0')) {
                        *(uint64_t *)(*(int64_t *)(iVar14 + 0x48) + 8) = CONCAT44(fVar24, fVar22);
                        iVar14 = *(int64_t *)(iVar14 + 0x48);
                        *(float *)(iVar14 + 0x20) = *(float *)(iVar14 + 0x148) + *(float *)(iVar14 + 8);
                        *(float *)(iVar14 + 0x24) = *(float *)(iVar14 + 0x14c) + *(float *)(iVar14 + 0xc);
                        fVar24 = (*(float *)(iVar14 + 0x14) - *(float *)(iVar14 + 0x14c)) - *(float *)(iVar14 + 0x154);
                        fVar23 = (*(float *)(iVar14 + 0x10) - *(float *)(iVar14 + 0x148)) - *(float *)(iVar14 + 0x150);
                        fVar22 = 0.0;
                        if (0.0 <= fVar24) {
                            fVar22 = fVar24;
                        }
                        fVar24 = 0.0;
                        if (0.0 <= fVar23) {
                            fVar24 = fVar23;
                        }
                        *(float *)(iVar14 + 0x2c) = fVar22;
                        *(float *)(iVar14 + 0x28) = fVar24;
                    }
                }
                func_0x00018010e050(*(undefined8 *)(iVar17 + 0x1600), 0);
                goto code_r0x0001800fbfc6;
            }
        }
        fcn.1800fac90();
    }
    fcn.1800f9f30(0, 0);
code_r0x0001800fbfc6:
    uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    if (-1 < (int32_t)uVar13) {
        do {
            iVar14 = *(int64_t *)((uint64_t)uVar13 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar14 != 0) && ((*(uint32_t *)(iVar14 + 0x14) & 0x8000000) != 0)) goto code_r0x0001800fc015;
            uVar13 = uVar13 - 1;
        } while (-1 < (int32_t)uVar13);
    }
    if ((*(int64_t *)(iVar4 + 0x23c0) == 0) || (*(float *)(iVar4 + 0x23dc) <= 0.0)) {
        fVar22 = *(float *)(iVar4 + 0x23fc) - *(float *)(iVar4 + 0x48) * 10.0;
        if (fVar22 <= 0.0) {
            fVar22 = 0.0;
        }
    } else {
code_r0x0001800fc015:
        fVar22 = *(float *)(iVar4 + 0x48) * 6.0 + *(float *)(iVar4 + 0x23fc);
        if (1.0 <= fVar22) {
            fVar22 = 1.0;
        }
    }
    *(float *)(iVar4 + 0x23fc) = fVar22;
    *(undefined4 *)(iVar4 + 0x2650) = 0;
    *(undefined4 *)(iVar4 + 0x28c4) = *(undefined4 *)(iVar4 + 0x28b0);
    *(undefined4 *)(iVar4 + 0x28c8) = *(undefined4 *)(iVar4 + 0x28b4);
    *(undefined4 *)(iVar4 + 0x28cc) = *(undefined4 *)(iVar4 + 0x28b8);
    *(undefined4 *)(iVar4 + 0x28d0) = *(undefined4 *)(iVar4 + 0x28bc);
    *(undefined4 *)(iVar4 + 0x28d4) = *(undefined4 *)(iVar4 + 0x28c0);
    *(undefined8 *)(iVar4 + 0x2c88) = 0xffffffffffffffff;
    *(undefined4 *)(iVar4 + 0x2c84) = 0xffffffff;
    *(undefined2 *)(iVar4 + 0x28b0) = 0;
    func_0x000180108de0();
    iVar7 = iVar6;
    if (0 < *(int32_t *)(iVar4 + 0x2518)) {
        do {
            iVar14 = *(int64_t *)0x180781f28;
            fVar22 = *(float *)(*(int64_t *)(iVar4 + 0x2520) + (int64_t)iVar7 * 4);
            if ((0.0 <= fVar22) && (fVar22 < fVar21)) {
                iVar17 = (int64_t)iVar7 * 0x250 + *(int64_t *)(iVar4 + 0x24f8);
                *(undefined8 *)(iVar17 + 0x1f0) = 0;
                if (*(int64_t *)(iVar17 + 0x1e8) != 0) {
                    *(undefined8 *)(iVar17 + 0x1e0) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x1e8) = 0;
                }
                *(undefined *)(iVar17 + 0x23c) = 1;
                if (*(int64_t *)(iVar17 + 0x198) != 0) {
                    *(undefined8 *)(iVar17 + 400) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x198) = 0;
                }
                *(undefined *)(iVar17 + 0x24b) = 1;
                iVar8 = iVar6;
                if (0 < *(int32_t *)(iVar17 + 0x6c)) {
                    do {
                        iVar19 = (int64_t)iVar8;
                        iVar8 = iVar8 + 1;
                        *(undefined2 *)(iVar19 * 0x74 + 0x54 + *(int64_t *)(iVar17 + 0x18)) = 0xffff;
                    } while (iVar8 < *(int32_t *)(iVar17 + 0x6c));
                }
                *(undefined4 *)
                 (*(int64_t *)(iVar14 + 0x2520) +
                 (int64_t)(int32_t)((iVar17 - *(int64_t *)(iVar14 + 0x24f8)) / 0x250) * 4) = 0xbf800000;
            }
            iVar7 = iVar7 + 1;
        } while (iVar7 < *(int32_t *)(iVar4 + 0x2518));
    }
    iVar14 = *(int64_t *)(iVar4 + 0x24e8);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x24e0) * 0x88 + iVar14;
    iVar17 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar17, iVar14 != iVar19; iVar14 = iVar14 + 0x88) {
        if ((0.0 <= *(float *)(iVar14 + 8)) && (*(float *)(iVar14 + 8) < fVar21)) {
            func_0x000180126a10(iVar14 + 0x28);
            *(undefined4 *)(iVar14 + 8) = 0xbf800000;
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    if (*(char *)(iVar4 + 0x20b9) != '\0') {
        if (*(int64_t *)(iVar17 + 0x2108) != 0) {
            *(undefined8 *)(iVar17 + 0x2100) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2108) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x2118) != 0) {
            *(undefined8 *)(iVar17 + 0x2110) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2118) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x26e8) != 0) {
            *(undefined8 *)(iVar17 + 0x26e0) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x26e8) = 0;
        }
        *(undefined4 *)(iVar17 + 0x26f0) = 0;
        *(undefined4 *)(iVar17 + 0x25f8) = 0;
        func_0x00018011ee60(iVar17 + 0x2600);
        func_0x0001801388c0();
        piVar15 = *(int64_t **)(iVar17 + 0x12e0);
        piVar2 = piVar15 + *(int32_t *)(iVar17 + 0x12d8);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            iVar14 = *piVar15;
            iVar17 = *(int64_t *)(iVar14 + 0x2b0);
            func_0x000180129630(iVar14, 1);
            func_0x000180129f40(&var_8h, iVar14);
            if (((*(int32_t *)(iVar17 + 0x9c) != 0) || ((float)var_8h != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x1c))
                ) || (var_8h._4_4_ != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x20))) {
                func_0x0001801299b0(iVar14);
            }
        }
    }
    *(undefined *)(iVar4 + 0x20b9) = 0;
    if ((*(int64_t *)(iVar4 + 0x21d8) != 0) && (*(char *)(*(int64_t *)(iVar4 + 0x21d8) + 0x10a) == '\0')) {
        uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1590) - 1;
        if (-1 < (int32_t)uVar13) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1598) + (uint64_t)uVar13 * 8);
                if (((iVar14 != 0) && (*(char *)(iVar14 + 0x10a) != '\0')) &&
                   ((*(uint32_t *)(iVar14 + 0x14) & 0x10200) != 0x10200)) goto code_r0x0001800fc388;
                uVar13 = uVar13 - 1;
            } while (-1 < (int32_t)uVar13);
        }
        iVar14 = 0;
code_r0x0001800fc388:
        func_0x00018010e050(iVar14, 1);
    }
    func_0x00018011f370(iVar4 + 0x15b0, 0);
    iVar7 = *(int32_t *)(iVar4 + 0x2134);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f970(iVar4 + 0x2130, iVar8);
    }
    piVar18 = (int32_t *)(iVar4 + 0x2100);
    *(undefined4 *)(iVar4 + 0x2130) = 0;
    iVar7 = *(int32_t *)(iVar4 + 0x2104);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(piVar18, iVar8);
    }
    *piVar18 = 0;
    if (*(int32_t *)(iVar4 + 0x2104) == 0) {
        func_0x00018011fb10(piVar18, 8);
    }
    *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)*piVar18 * 4) = 0x10;
    iVar7 = *piVar18;
    *piVar18 = iVar7 + 1;
    *(undefined4 *)(iVar4 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)iVar7 * 4);
    func_0x00018011f140(iVar4 + 0x2110, 0);
    if ((*(uint8_t *)(iVar4 + 0x30) & 0x80) != 0) {
        iVar14 = *(int64_t *)(iVar4 + 0x15f0);
        *(undefined8 *)(iVar4 + 0x2b80) = 0;
        if (iVar14 != 0) {
            if (*(int64_t *)(iVar14 + 0x4c8) == 0) {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar14 + 0x418) + 0x4c0);
                if (iVar14 != 0) {
                    *(int64_t *)(iVar4 + 0x2b80) = iVar14;
                }
            } else {
                uVar12 = func_0x00018011bfb0(*(int64_t *)(iVar14 + 0x4c8), *(undefined8 *)(iVar4 + 0x118));
                *(undefined8 *)(iVar4 + 0x2b80) = uVar12;
            }
        }
        piVar18 = *(int32_t **)(iVar4 + 0x2900);
        piVar20 = piVar18 + (int64_t)*(int32_t *)(iVar4 + 0x28f8) * 0x10;
        for (; piVar18 != piVar20; piVar18 = piVar18 + 0x10) {
            if (*piVar18 == 1) {
                func_0x000180115650(iVar4, piVar18);
            }
        }
        iVar7 = *(int32_t *)(iVar4 + 0x28fc);
        if (iVar7 < 0) {
            iVar7 = iVar7 + iVar7 / 2;
            iVar8 = iVar6;
            if (0 < iVar7) {
                iVar8 = iVar7;
            }
            func_0x00018011fa30(iVar4 + 0x28f8, iVar8);
        }
        *(undefined4 *)(iVar4 + 0x28f8) = 0;
        if (0 < *(int32_t *)(iVar4 + 0x28e8)) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar4 + 0x28f0) + 8 + (int64_t)iVar6 * 0x10);
                if (((iVar14 != 0) && (*(int64_t *)(iVar14 + 0x18) == 0)) &&
                   ((*(uint32_t *)(iVar14 + 0x10) & 0x400) == 0)) {
                    func_0x000180116d90();
                }
                iVar6 = iVar6 + 1;
            } while (iVar6 < *(int32_t *)(iVar4 + 0x28e8));
        }
    }
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(iVar4 + 2) = 1;
    *(uint32_t *)(iVar14 + 0x2008) = *(uint32_t *)(iVar14 + 0x2008) | 2;
    *(undefined4 *)(iVar14 + 0x202c) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2030) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2010) = 4;
    func_0x0001801019f0(0x1806444f8, 0, 0);
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined4 *)(iVar4 + 0x2a5c) = 0;
    *(undefined2 *)(iVar4 + 0x2a60) = *(undefined2 *)(iVar14 + 0x15b0);
    *(undefined2 *)(iVar4 + 0x2a62) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x148);
    *(undefined2 *)(iVar4 + 0x2a64) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x1e0);
    *(undefined2 *)(iVar4 + 0x2a66) = *(undefined2 *)(iVar14 + 0x20c0);
    *(undefined2 *)(iVar4 + 0x2a68) = *(undefined2 *)(iVar14 + 0x20d0);
    *(undefined2 *)(iVar4 + 0x2a6a) = *(undefined2 *)(iVar14 + 0x20e0);
    *(undefined2 *)(iVar4 + 0x2a6c) = *(undefined2 *)(iVar14 + 0x20f0);
    *(undefined2 *)(iVar4 + 0x2a6e) = *(undefined2 *)(iVar14 + 0x2110);
    *(undefined2 *)(iVar4 + 0x2a70) = *(undefined2 *)(iVar14 + 0x2100);
    *(undefined2 *)(iVar4 + 0x2a72) = *(undefined2 *)(iVar14 + 0x2130);
    *(undefined2 *)(iVar4 + 0x2a74) = *(undefined2 *)(iVar14 + 0x281c);
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar17 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    for (; iVar14 != iVar17; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 1) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fc33b
// Address: 0x1800fc33b
// Size: 813 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Removing arg arg_2480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24a8h because it doesn't fit into ProtoModel

void fcn.1800fb4a0(undefined8 placeholder_0, int64_t arg2)
{
    float *pfVar1;
    int64_t *piVar2;
    bool bVar3;
    int64_t iVar4;
    char cVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    float *pfVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    int64_t iVar14;
    int64_t *piVar15;
    char *pcVar16;
    int64_t iVar17;
    int32_t *piVar18;
    int64_t iVar19;
    int32_t *piVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    uVar13 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2970);
    while (uVar13 = uVar13 - 1, -1 < (int32_t)uVar13) {
        iVar14 = (uint64_t)uVar13 * 0x20 + *(int64_t *)(iVar4 + 0x2978);
        if (*(int32_t *)(iVar14 + 4) == 7) {
            func_0x000180498030(iVar14, iVar14 + 0x20, 
                                ((int64_t)*(int32_t *)(iVar4 + 0x2970) - (uint64_t)uVar13) * 0x20 + -0x20);
            *(int32_t *)(iVar4 + 0x2970) = *(int32_t *)(iVar4 + 0x2970) + -1;
        }
    }
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    iVar17 = iVar4;
    for (; iVar14 != iVar19; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 0) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    *(undefined4 *)(iVar4 + 0x12d0) = *(undefined4 *)(iVar4 + 0x12cc);
    uVar13 = *(uint32_t *)(iVar17 + 0x30);
    if ((uVar13 & 4) != 0) {
        uVar13 = uVar13 & 0xfffffffb;
        *(undefined *)(iVar17 + 0x7a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 & 8) != 0) {
        uVar13 = uVar13 & 0xfffffff7;
        *(undefined *)(iVar17 + 0x7b) = 0;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xe & 1) != 0) {
        uVar13 = uVar13 & 0xffffbfff;
        *(undefined *)(iVar17 + 0x8a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xf & 1) != 0) {
        uVar13 = uVar13 & 0xffff7fff;
        *(undefined *)(iVar17 + 0x8b) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((*(int64_t *)(iVar17 + 0xc30) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc48) == 0 || (*(int64_t *)(iVar17 + 0xc48) == 0x18011e8a0)))) {
        *(undefined8 *)(iVar17 + 0xc48) = 0x18010a030;
    }
    if ((*(int64_t *)(iVar17 + 0xc38) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc50) == 0 || (*(int64_t *)(iVar17 + 0xc50) == 0x18011e9d0)))) {
        *(undefined8 *)(iVar17 + 0xc50) = 0x18010a050;
    }
    if (((uVar13 >> 10 & 1) != 0) && ((*(uint32_t *)(iVar17 + 0x34) & 0xc00) != 0xc00)) {
        *(uint32_t *)(iVar17 + 0x30) = uVar13 & 0xfffffbff;
    }
    *(undefined4 *)(iVar4 + 0x12cc) = *(undefined4 *)(iVar4 + 0x30);
    if (*(char *)(iVar17 + 0x2928) == '\0') {
        if ((*(int64_t *)(iVar17 + 0x50) != 0) &&
           (iVar14 = func_0x0001800f5b50(*(int64_t *)(iVar17 + 0x50), 0x180625030), iVar14 != 0)) {
            iVar6 = func_0x00018046d704(iVar14);
            if ((iVar6 != -1) && (iVar7 = func_0x000180461598(iVar14, 0, 2), iVar7 == 0)) {
                iVar7 = func_0x00018046d704(iVar14);
                iVar19 = (int64_t)iVar7;
                if ((((iVar7 != -1) && (iVar6 = func_0x000180461598(iVar14, iVar6, 0), iVar6 == 0)) && (iVar19 != -1))
                   && (iVar9 = func_0x00018046d050(iVar19), iVar9 != 0)) {
                    iVar10 = func_0x0001804611b4(iVar9, 1, iVar19, iVar14);
                    if (iVar10 == iVar19) {
                        func_0x00018045ff84(iVar14);
                        if (iVar19 != 0) {
                            func_0x000180112840(iVar9, iVar19);
                        }
                        fcn.180460d90(iVar9);
                    } else {
                        func_0x00018045ff84(iVar14);
                        fcn.180460d90(iVar9);
                    }
                    goto code_r0x0001800fb715;
                }
            }
            func_0x00018045ff84(iVar14);
        }
code_r0x0001800fb715:
        *(undefined *)(iVar17 + 0x2928) = 1;
    }
    iVar6 = 0;
    if ((0.0 < *(float *)(iVar17 + 0x292c)) &&
       (fVar21 = *(float *)(iVar17 + 0x292c) - *(float *)(iVar17 + 0x48), *(float *)(iVar17 + 0x292c) = fVar21,
       fVar21 <= 0.0)) {
        if (*(int64_t *)(iVar17 + 0x50) == 0) {
            *(undefined *)(iVar17 + 0xec) = 1;
        } else {
            func_0x000180112a70();
        }
        *(undefined4 *)(iVar17 + 0x292c) = 0;
    }
    *(int32_t *)(iVar4 + 4) = *(int32_t *)(iVar4 + 4) + 1;
    *(undefined2 *)(iVar4 + 0x281e) = 0;
    *(undefined4 *)(iVar4 + 0x15d0) = 0;
    *(double *)(iVar4 + 0x18) = (double)*(float *)(iVar4 + 0x48) + *(double *)(iVar4 + 0x18);
    iVar7 = *(int32_t *)(iVar4 + 0x283c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(iVar4 + 0x2838, iVar8);
    }
    fVar21 = 3.402823e+38;
    *(undefined4 *)(iVar4 + 0x2838) = 0;
    *(float *)(iVar4 + 0x2c80) =
         (*(float *)(iVar4 + 0x48) - *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4)) +
         *(float *)(iVar4 + 0x2c80);
    *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4) = *(float *)(iVar4 + 0x48);
    iVar8 = *(int32_t *)(iVar4 + 0x2c7c) + 1;
    *(int32_t *)(iVar4 + 0x2c78) = (*(int32_t *)(iVar4 + 0x2c78) + 1) % 0x3c;
    iVar7 = 0x3c;
    if (iVar8 < 0x3c) {
        iVar7 = iVar8;
    }
    *(int32_t *)(iVar4 + 0x2c7c) = iVar7;
    if (*(float *)(iVar4 + 0x2c80) <= 0.0) {
        fVar22 = 3.402823e+38;
    } else {
        fVar22 = 1.0 / (*(float *)(iVar4 + 0x2c80) / (float)iVar7);
    }
    *(float *)(iVar4 + 0xf0) = fVar22;
    iVar7 = *(int32_t *)(iVar4 + 0x156c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f9d0(iVar4 + 0x1568, iVar8);
    }
    *(undefined4 *)(iVar4 + 0x1568) = 0;
    func_0x0001801093d0(*(undefined *)(iVar4 + 0x8e));
    func_0x000180113b10();
    func_0x000180106aa0();
    fcn.1800fb280();
    func_0x000180106fa0();
    *(undefined *)(iVar4 + 1) = 1;
    piVar15 = *(int64_t **)(iVar4 + 0x2158);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x2150);
    iVar14 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar14, piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        *(undefined8 *)(iVar14 + 0x40) = 0;
        *(undefined *)(iVar14 + 200) = 0;
        iVar14 = *(int64_t *)0x180781f28;
    }
    if ((*(char *)(iVar4 + 0x2400) != '\0') &&
       (iVar7 = *(int32_t *)(iVar4 + 0x241c), iVar7 == *(int32_t *)(iVar4 + 0x1654))) {
        if (*(int32_t *)(iVar14 + 0x1654) == iVar7) {
            *(int32_t *)(iVar14 + 0x1658) = iVar7;
        }
        if (*(int32_t *)(iVar14 + 0x1684) == iVar7) {
            *(undefined *)(iVar14 + 0x168d) = 1;
        }
    }
    if ((((*(char *)(iVar4 + 0xb5) != '\0') && (*(char *)(iVar4 + 0x138) != '\0')) ||
        (*(undefined4 *)(iVar4 + 0x1634) = 0, *(char *)(iVar4 + 0xb5) != '\0')) && (1 < *(int32_t *)(iVar4 + 0x1644))) {
        *(undefined4 *)(iVar4 + 0x1634) = *(undefined4 *)(iVar4 + 0x1640);
    }
    piVar18 = (int32_t *)(iVar4 + 0x163c);
    if (*(int32_t *)(iVar4 + 0x1640) == 0) {
        *(undefined4 *)(iVar4 + 0x1648) = 0;
code_r0x0001800fb97d:
        *(undefined4 *)(iVar4 + 0x164c) = 0;
    } else if ((*piVar18 != 0) && (*(int32_t *)(iVar4 + 0x1654) == *piVar18)) goto code_r0x0001800fb97d;
    iVar7 = *piVar18;
    piVar20 = (int32_t *)(iVar4 + 0x1654);
    fVar22 = *(float *)(iVar4 + 0x48);
    if ((iVar7 != 0) && (*(float *)(iVar4 + 0x1648) = fVar22 + *(float *)(iVar4 + 0x1648), *piVar20 != iVar7)) {
        *(float *)(iVar4 + 0x164c) = fVar22 + *(float *)(iVar4 + 0x164c);
    }
    *piVar18 = 0;
    iVar8 = *piVar20;
    *(int32_t *)(iVar4 + 0x1640) = iVar7;
    *(undefined4 *)(iVar4 + 0x1644) = 0;
    *(undefined2 *)(iVar4 + 0x1650) = 0;
    if (((iVar8 != 0) && (*(int32_t *)(iVar4 + 0x1658) != iVar8)) && (*(int32_t *)(iVar4 + 0x1680) == iVar8)) {
        fcn.1800f9f30(0, 0);
        fVar22 = *(float *)(iVar4 + 0x48);
    }
    iVar7 = *piVar20;
    if (iVar7 != 0) {
        *(float *)(iVar4 + 0x165c) = fVar22 + *(float *)(iVar4 + 0x165c);
    }
    *(int32_t *)(iVar4 + 0x1680) = iVar7;
    *(int32_t *)(iVar4 + 0x1658) = 0;
    *(undefined *)(iVar4 + 0x1665) = 0;
    *(undefined *)(iVar4 + 0x1660) = 0;
    *(float *)(iVar4 + 0x169c) = fVar22 + *(float *)(iVar4 + 0x169c);
    if ((*(int32_t *)(iVar4 + 0x2780) != 0) && (iVar7 != *(int32_t *)(iVar4 + 0x2780))) {
        *(undefined4 *)(iVar4 + 0x2780) = 0;
    }
    if ((*(int32_t *)(iVar4 + 0x277c) != 0) && (*(int32_t *)(iVar4 + 0x277c) != *(int32_t *)(iVar4 + 0x1684))) {
        *(undefined4 *)(iVar4 + 0x277c) = 0;
    }
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x1f68) = 0;
        *(undefined *)(iVar4 + 0x1f6c) = 0;
    }
    if (*(int32_t *)(iVar4 + 0x1688) < *(int32_t *)(iVar4 + 4)) {
        *(undefined4 *)(iVar4 + 0x1684) = 0;
    }
    iVar7 = *(int32_t *)(iVar4 + 0x2638);
    *(undefined *)(iVar4 + 0x168d) = 0;
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x2648) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(int32_t *)(iVar4 + 0x2648) = iVar7;
    }
    if (*(int64_t *)(iVar4 + 0x15e8) == 0) {
        *(undefined4 *)(iVar4 + 0x264c) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(undefined4 *)(iVar4 + 0x264c) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x15e8) + 0x10);
    }
    *(int32_t *)(iVar4 + 0x263c) = iVar7;
    if (iVar7 == 0) {
        if (0.0 < *(float *)(iVar4 + 0x2640)) {
            fVar23 = fVar22 + *(float *)(iVar4 + 0x2644);
            *(float *)(iVar4 + 0x2644) = fVar23;
            fVar24 = 0.25;
            if (0.25 <= fVar22 + fVar22) {
                fVar24 = fVar22 + fVar22;
            }
            if (fVar24 <= fVar23) {
                *(undefined8 *)(iVar4 + 0x2640) = 0;
            }
        }
    } else {
        *(undefined4 *)(iVar4 + 0x2644) = 0;
        *(undefined4 *)(iVar4 + 0x2638) = 0;
        *(float *)(iVar4 + 0x2640) = *(float *)(iVar4 + 0x2640) + fVar22;
    }
    func_0x000180108270();
    *(undefined4 *)(iVar4 + 0x2488) = *(undefined4 *)(iVar4 + 0x2484);
    *(undefined4 *)(iVar4 + 0x247c) = *(undefined4 *)(iVar4 + 0x2478);
    *(undefined4 *)(iVar4 + 0x2478) = 0;
    *(undefined8 *)(iVar4 + 0x2480) = 0x7f7fffff;
    *(undefined2 *)(iVar4 + 0x2401) = 0;
    *(undefined4 *)(iVar4 + 0x2490) = 0;
    if (*(char *)(iVar4 + 0x2400) != '\0') {
        if (*piVar20 == 0) {
            pcVar16 = "#DragDropCancelHandler";
            cVar5 = '#';
            do {
                if (((cVar5 == '#') && (*pcVar16 == '#')) && (pcVar16[1] == '#')) {
                    pcVar16 = pcVar16 + 2;
                }
                cVar5 = *pcVar16;
                pcVar16 = pcVar16 + 1;
            } while (cVar5 != '\0');
        }
        cVar5 = func_0x000180109d80();
        if (cVar5 != '\0') {
            fcn.1800f9f30(0, 0);
            func_0x0001801120a0();
        }
    }
    *(undefined8 *)(iVar4 + 0x2820) = 0;
    func_0x00018010f2f0();
    func_0x000180108830();
    func_0x000180114da0(iVar4);
    if ((*(char *)(iVar4 + 0x20b9) != '\0') || (*(float *)(iVar4 + 0x98) < 0.0)) {
        bVar3 = true;
    } else {
        bVar3 = false;
        fVar21 = (float)*(double *)(iVar4 + 0x18) - *(float *)(iVar4 + 0x98);
    }
    piVar15 = *(int64_t **)(iVar4 + 0x1588);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x1580);
    for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        cVar5 = *(char *)(iVar14 + 0x109);
        *(char *)(iVar14 + 0x10a) = cVar5;
        *(undefined *)(iVar14 + 0x109) = 0;
        *(undefined *)(iVar14 + 0x10b) = 0;
        *(undefined2 *)(iVar14 + 0x11a) = *(undefined2 *)(iVar14 + 0x118);
        *(undefined2 *)(iVar14 + 0x118) = 0;
        if (((cVar5 == '\0') || (bVar3)) &&
           ((*(char *)(iVar14 + 0x494) == '\0' &&
            (*(float *)(iVar14 + 0x2e8) <= fVar21 && fVar21 != *(float *)(iVar14 + 0x2e8))))) {
            iVar17 = *(int64_t *)(iVar14 + 800);
            *(undefined *)(iVar14 + 0x494) = 1;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x10) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x14);
            if (iVar8 < *(int32_t *)(iVar17 + 0x14)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x48c) = iVar7;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x20) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x24);
            if (iVar8 < *(int32_t *)(iVar17 + 0x24)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x490) = iVar7;
            if (*(int64_t *)(iVar14 + 0x150) != 0) {
                *(undefined8 *)(iVar14 + 0x148) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x150) = 0;
            }
            func_0x000180124110(*(undefined8 *)(iVar14 + 800));
            if (*(int64_t *)(iVar14 + 0x1f8) != 0) {
                *(undefined8 *)(iVar14 + 0x1f0) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x1f8) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x250) != 0) {
                *(undefined8 *)(iVar14 + 0x248) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x250) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x260) != 0) {
                *(undefined8 *)(iVar14 + 600) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x260) = 0;
            }
        }
    }
    fcn.1800fae50(iVar4 + 0x118);
    iVar17 = *(int64_t *)0x180781f28;
    iVar14 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1600);
    if (iVar14 == 0) {
        if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) == 0) ||
           (iVar7 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1654),
           *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) + 0xc4) != iVar7)) goto code_r0x0001800fbfc6;
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar7;
        if (*(int32_t *)(iVar17 + 0x1684) == iVar7) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') goto code_r0x0001800fbfc6;
    } else {
        piVar18 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1654);
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = *piVar18;
        if (*(int32_t *)(iVar17 + 0x1684) == *piVar18) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        iVar14 = *(int64_t *)(iVar14 + 0x428);
        if ((*(char *)(iVar14 + 0x10a) == '\0') && (*(char *)(iVar14 + 0x109) == '\0')) {
            bVar3 = true;
        } else {
            bVar3 = false;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') {
            pfVar1 = (float *)(iVar17 + 0x118);
            pfVar11 = pfVar1;
            if (pfVar1 == (float *)0x0) {
                pfVar11 = (float *)(*(int64_t *)0x180781f28 + 0x118);
            }
            if (((-256000.0 <= *pfVar11) && (-256000.0 <= pfVar11[1])) && (!bVar3)) {
                fVar22 = *pfVar1 - *(float *)(iVar17 + 0x166c);
                fVar24 = *(float *)(iVar17 + 0x11c) - *(float *)(iVar17 + 0x1670);
                var_8h._0_4_ = fVar22;
                var_8h._4_4_ = fVar24;
                if ((*(float *)(iVar14 + 0x60) != fVar22) || (*(float *)(iVar14 + 100) != fVar24)) {
                    func_0x000180106470(iVar14, &var_8h, 1);
                    if ((*(int64_t *)(iVar14 + 0x48) != 0) && (*(char *)(iVar14 + 0x108) != '\0')) {
                        *(uint64_t *)(*(int64_t *)(iVar14 + 0x48) + 8) = CONCAT44(fVar24, fVar22);
                        iVar14 = *(int64_t *)(iVar14 + 0x48);
                        *(float *)(iVar14 + 0x20) = *(float *)(iVar14 + 0x148) + *(float *)(iVar14 + 8);
                        *(float *)(iVar14 + 0x24) = *(float *)(iVar14 + 0x14c) + *(float *)(iVar14 + 0xc);
                        fVar24 = (*(float *)(iVar14 + 0x14) - *(float *)(iVar14 + 0x14c)) - *(float *)(iVar14 + 0x154);
                        fVar23 = (*(float *)(iVar14 + 0x10) - *(float *)(iVar14 + 0x148)) - *(float *)(iVar14 + 0x150);
                        fVar22 = 0.0;
                        if (0.0 <= fVar24) {
                            fVar22 = fVar24;
                        }
                        fVar24 = 0.0;
                        if (0.0 <= fVar23) {
                            fVar24 = fVar23;
                        }
                        *(float *)(iVar14 + 0x2c) = fVar22;
                        *(float *)(iVar14 + 0x28) = fVar24;
                    }
                }
                func_0x00018010e050(*(undefined8 *)(iVar17 + 0x1600), 0);
                goto code_r0x0001800fbfc6;
            }
        }
        fcn.1800fac90();
    }
    fcn.1800f9f30(0, 0);
code_r0x0001800fbfc6:
    uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    if (-1 < (int32_t)uVar13) {
        do {
            iVar14 = *(int64_t *)((uint64_t)uVar13 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar14 != 0) && ((*(uint32_t *)(iVar14 + 0x14) & 0x8000000) != 0)) goto code_r0x0001800fc015;
            uVar13 = uVar13 - 1;
        } while (-1 < (int32_t)uVar13);
    }
    if ((*(int64_t *)(iVar4 + 0x23c0) == 0) || (*(float *)(iVar4 + 0x23dc) <= 0.0)) {
        fVar22 = *(float *)(iVar4 + 0x23fc) - *(float *)(iVar4 + 0x48) * 10.0;
        if (fVar22 <= 0.0) {
            fVar22 = 0.0;
        }
    } else {
code_r0x0001800fc015:
        fVar22 = *(float *)(iVar4 + 0x48) * 6.0 + *(float *)(iVar4 + 0x23fc);
        if (1.0 <= fVar22) {
            fVar22 = 1.0;
        }
    }
    *(float *)(iVar4 + 0x23fc) = fVar22;
    *(undefined4 *)(iVar4 + 0x2650) = 0;
    *(undefined4 *)(iVar4 + 0x28c4) = *(undefined4 *)(iVar4 + 0x28b0);
    *(undefined4 *)(iVar4 + 0x28c8) = *(undefined4 *)(iVar4 + 0x28b4);
    *(undefined4 *)(iVar4 + 0x28cc) = *(undefined4 *)(iVar4 + 0x28b8);
    *(undefined4 *)(iVar4 + 0x28d0) = *(undefined4 *)(iVar4 + 0x28bc);
    *(undefined4 *)(iVar4 + 0x28d4) = *(undefined4 *)(iVar4 + 0x28c0);
    *(undefined8 *)(iVar4 + 0x2c88) = 0xffffffffffffffff;
    *(undefined4 *)(iVar4 + 0x2c84) = 0xffffffff;
    *(undefined2 *)(iVar4 + 0x28b0) = 0;
    func_0x000180108de0();
    iVar7 = iVar6;
    if (0 < *(int32_t *)(iVar4 + 0x2518)) {
        do {
            iVar14 = *(int64_t *)0x180781f28;
            fVar22 = *(float *)(*(int64_t *)(iVar4 + 0x2520) + (int64_t)iVar7 * 4);
            if ((0.0 <= fVar22) && (fVar22 < fVar21)) {
                iVar17 = (int64_t)iVar7 * 0x250 + *(int64_t *)(iVar4 + 0x24f8);
                *(undefined8 *)(iVar17 + 0x1f0) = 0;
                if (*(int64_t *)(iVar17 + 0x1e8) != 0) {
                    *(undefined8 *)(iVar17 + 0x1e0) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x1e8) = 0;
                }
                *(undefined *)(iVar17 + 0x23c) = 1;
                if (*(int64_t *)(iVar17 + 0x198) != 0) {
                    *(undefined8 *)(iVar17 + 400) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x198) = 0;
                }
                *(undefined *)(iVar17 + 0x24b) = 1;
                iVar8 = iVar6;
                if (0 < *(int32_t *)(iVar17 + 0x6c)) {
                    do {
                        iVar19 = (int64_t)iVar8;
                        iVar8 = iVar8 + 1;
                        *(undefined2 *)(iVar19 * 0x74 + 0x54 + *(int64_t *)(iVar17 + 0x18)) = 0xffff;
                    } while (iVar8 < *(int32_t *)(iVar17 + 0x6c));
                }
                *(undefined4 *)
                 (*(int64_t *)(iVar14 + 0x2520) +
                 (int64_t)(int32_t)((iVar17 - *(int64_t *)(iVar14 + 0x24f8)) / 0x250) * 4) = 0xbf800000;
            }
            iVar7 = iVar7 + 1;
        } while (iVar7 < *(int32_t *)(iVar4 + 0x2518));
    }
    iVar14 = *(int64_t *)(iVar4 + 0x24e8);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x24e0) * 0x88 + iVar14;
    iVar17 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar17, iVar14 != iVar19; iVar14 = iVar14 + 0x88) {
        if ((0.0 <= *(float *)(iVar14 + 8)) && (*(float *)(iVar14 + 8) < fVar21)) {
            func_0x000180126a10(iVar14 + 0x28);
            *(undefined4 *)(iVar14 + 8) = 0xbf800000;
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    if (*(char *)(iVar4 + 0x20b9) != '\0') {
        if (*(int64_t *)(iVar17 + 0x2108) != 0) {
            *(undefined8 *)(iVar17 + 0x2100) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2108) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x2118) != 0) {
            *(undefined8 *)(iVar17 + 0x2110) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2118) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x26e8) != 0) {
            *(undefined8 *)(iVar17 + 0x26e0) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x26e8) = 0;
        }
        *(undefined4 *)(iVar17 + 0x26f0) = 0;
        *(undefined4 *)(iVar17 + 0x25f8) = 0;
        func_0x00018011ee60(iVar17 + 0x2600);
        func_0x0001801388c0();
        piVar15 = *(int64_t **)(iVar17 + 0x12e0);
        piVar2 = piVar15 + *(int32_t *)(iVar17 + 0x12d8);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            iVar14 = *piVar15;
            iVar17 = *(int64_t *)(iVar14 + 0x2b0);
            func_0x000180129630(iVar14, 1);
            func_0x000180129f40(&var_8h, iVar14);
            if (((*(int32_t *)(iVar17 + 0x9c) != 0) || ((float)var_8h != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x1c))
                ) || (var_8h._4_4_ != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x20))) {
                func_0x0001801299b0(iVar14);
            }
        }
    }
    *(undefined *)(iVar4 + 0x20b9) = 0;
    if ((*(int64_t *)(iVar4 + 0x21d8) != 0) && (*(char *)(*(int64_t *)(iVar4 + 0x21d8) + 0x10a) == '\0')) {
        uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1590) - 1;
        if (-1 < (int32_t)uVar13) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1598) + (uint64_t)uVar13 * 8);
                if (((iVar14 != 0) && (*(char *)(iVar14 + 0x10a) != '\0')) &&
                   ((*(uint32_t *)(iVar14 + 0x14) & 0x10200) != 0x10200)) goto code_r0x0001800fc388;
                uVar13 = uVar13 - 1;
            } while (-1 < (int32_t)uVar13);
        }
        iVar14 = 0;
code_r0x0001800fc388:
        func_0x00018010e050(iVar14, 1);
    }
    func_0x00018011f370(iVar4 + 0x15b0, 0);
    iVar7 = *(int32_t *)(iVar4 + 0x2134);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f970(iVar4 + 0x2130, iVar8);
    }
    piVar18 = (int32_t *)(iVar4 + 0x2100);
    *(undefined4 *)(iVar4 + 0x2130) = 0;
    iVar7 = *(int32_t *)(iVar4 + 0x2104);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(piVar18, iVar8);
    }
    *piVar18 = 0;
    if (*(int32_t *)(iVar4 + 0x2104) == 0) {
        func_0x00018011fb10(piVar18, 8);
    }
    *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)*piVar18 * 4) = 0x10;
    iVar7 = *piVar18;
    *piVar18 = iVar7 + 1;
    *(undefined4 *)(iVar4 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)iVar7 * 4);
    func_0x00018011f140(iVar4 + 0x2110, 0);
    if ((*(uint8_t *)(iVar4 + 0x30) & 0x80) != 0) {
        iVar14 = *(int64_t *)(iVar4 + 0x15f0);
        *(undefined8 *)(iVar4 + 0x2b80) = 0;
        if (iVar14 != 0) {
            if (*(int64_t *)(iVar14 + 0x4c8) == 0) {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar14 + 0x418) + 0x4c0);
                if (iVar14 != 0) {
                    *(int64_t *)(iVar4 + 0x2b80) = iVar14;
                }
            } else {
                uVar12 = func_0x00018011bfb0(*(int64_t *)(iVar14 + 0x4c8), *(undefined8 *)(iVar4 + 0x118));
                *(undefined8 *)(iVar4 + 0x2b80) = uVar12;
            }
        }
        piVar18 = *(int32_t **)(iVar4 + 0x2900);
        piVar20 = piVar18 + (int64_t)*(int32_t *)(iVar4 + 0x28f8) * 0x10;
        for (; piVar18 != piVar20; piVar18 = piVar18 + 0x10) {
            if (*piVar18 == 1) {
                func_0x000180115650(iVar4, piVar18);
            }
        }
        iVar7 = *(int32_t *)(iVar4 + 0x28fc);
        if (iVar7 < 0) {
            iVar7 = iVar7 + iVar7 / 2;
            iVar8 = iVar6;
            if (0 < iVar7) {
                iVar8 = iVar7;
            }
            func_0x00018011fa30(iVar4 + 0x28f8, iVar8);
        }
        *(undefined4 *)(iVar4 + 0x28f8) = 0;
        if (0 < *(int32_t *)(iVar4 + 0x28e8)) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar4 + 0x28f0) + 8 + (int64_t)iVar6 * 0x10);
                if (((iVar14 != 0) && (*(int64_t *)(iVar14 + 0x18) == 0)) &&
                   ((*(uint32_t *)(iVar14 + 0x10) & 0x400) == 0)) {
                    func_0x000180116d90();
                }
                iVar6 = iVar6 + 1;
            } while (iVar6 < *(int32_t *)(iVar4 + 0x28e8));
        }
    }
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(iVar4 + 2) = 1;
    *(uint32_t *)(iVar14 + 0x2008) = *(uint32_t *)(iVar14 + 0x2008) | 2;
    *(undefined4 *)(iVar14 + 0x202c) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2030) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2010) = 4;
    func_0x0001801019f0(0x1806444f8, 0, 0);
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined4 *)(iVar4 + 0x2a5c) = 0;
    *(undefined2 *)(iVar4 + 0x2a60) = *(undefined2 *)(iVar14 + 0x15b0);
    *(undefined2 *)(iVar4 + 0x2a62) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x148);
    *(undefined2 *)(iVar4 + 0x2a64) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x1e0);
    *(undefined2 *)(iVar4 + 0x2a66) = *(undefined2 *)(iVar14 + 0x20c0);
    *(undefined2 *)(iVar4 + 0x2a68) = *(undefined2 *)(iVar14 + 0x20d0);
    *(undefined2 *)(iVar4 + 0x2a6a) = *(undefined2 *)(iVar14 + 0x20e0);
    *(undefined2 *)(iVar4 + 0x2a6c) = *(undefined2 *)(iVar14 + 0x20f0);
    *(undefined2 *)(iVar4 + 0x2a6e) = *(undefined2 *)(iVar14 + 0x2110);
    *(undefined2 *)(iVar4 + 0x2a70) = *(undefined2 *)(iVar14 + 0x2100);
    *(undefined2 *)(iVar4 + 0x2a72) = *(undefined2 *)(iVar14 + 0x2130);
    *(undefined2 *)(iVar4 + 0x2a74) = *(undefined2 *)(iVar14 + 0x281c);
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar17 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    for (; iVar14 != iVar17; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 1) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fc668
// Address: 0x1800fc668
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Removing arg arg_2480h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_24a8h because it doesn't fit into ProtoModel

void fcn.1800fb4a0(undefined8 placeholder_0, int64_t arg2)
{
    float *pfVar1;
    int64_t *piVar2;
    bool bVar3;
    int64_t iVar4;
    char cVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    float *pfVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    int64_t iVar14;
    int64_t *piVar15;
    char *pcVar16;
    int64_t iVar17;
    int32_t *piVar18;
    int64_t iVar19;
    int32_t *piVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)0x180781f28;
    uVar13 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2970);
    while (uVar13 = uVar13 - 1, -1 < (int32_t)uVar13) {
        iVar14 = (uint64_t)uVar13 * 0x20 + *(int64_t *)(iVar4 + 0x2978);
        if (*(int32_t *)(iVar14 + 4) == 7) {
            func_0x000180498030(iVar14, iVar14 + 0x20, 
                                ((int64_t)*(int32_t *)(iVar4 + 0x2970) - (uint64_t)uVar13) * 0x20 + -0x20);
            *(int32_t *)(iVar4 + 0x2970) = *(int32_t *)(iVar4 + 0x2970) + -1;
        }
    }
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    iVar17 = iVar4;
    for (; iVar14 != iVar19; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 0) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    *(undefined4 *)(iVar4 + 0x12d0) = *(undefined4 *)(iVar4 + 0x12cc);
    uVar13 = *(uint32_t *)(iVar17 + 0x30);
    if ((uVar13 & 4) != 0) {
        uVar13 = uVar13 & 0xfffffffb;
        *(undefined *)(iVar17 + 0x7a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 & 8) != 0) {
        uVar13 = uVar13 & 0xfffffff7;
        *(undefined *)(iVar17 + 0x7b) = 0;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xe & 1) != 0) {
        uVar13 = uVar13 & 0xffffbfff;
        *(undefined *)(iVar17 + 0x8a) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((uVar13 >> 0xf & 1) != 0) {
        uVar13 = uVar13 & 0xffff7fff;
        *(undefined *)(iVar17 + 0x8b) = 1;
        *(uint32_t *)(iVar17 + 0x30) = uVar13;
    }
    if ((*(int64_t *)(iVar17 + 0xc30) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc48) == 0 || (*(int64_t *)(iVar17 + 0xc48) == 0x18011e8a0)))) {
        *(undefined8 *)(iVar17 + 0xc48) = 0x18010a030;
    }
    if ((*(int64_t *)(iVar17 + 0xc38) != 0) &&
       ((*(int64_t *)(iVar17 + 0xc50) == 0 || (*(int64_t *)(iVar17 + 0xc50) == 0x18011e9d0)))) {
        *(undefined8 *)(iVar17 + 0xc50) = 0x18010a050;
    }
    if (((uVar13 >> 10 & 1) != 0) && ((*(uint32_t *)(iVar17 + 0x34) & 0xc00) != 0xc00)) {
        *(uint32_t *)(iVar17 + 0x30) = uVar13 & 0xfffffbff;
    }
    *(undefined4 *)(iVar4 + 0x12cc) = *(undefined4 *)(iVar4 + 0x30);
    if (*(char *)(iVar17 + 0x2928) == '\0') {
        if ((*(int64_t *)(iVar17 + 0x50) != 0) &&
           (iVar14 = func_0x0001800f5b50(*(int64_t *)(iVar17 + 0x50), 0x180625030), iVar14 != 0)) {
            iVar6 = func_0x00018046d704(iVar14);
            if ((iVar6 != -1) && (iVar7 = func_0x000180461598(iVar14, 0, 2), iVar7 == 0)) {
                iVar7 = func_0x00018046d704(iVar14);
                iVar19 = (int64_t)iVar7;
                if ((((iVar7 != -1) && (iVar6 = func_0x000180461598(iVar14, iVar6, 0), iVar6 == 0)) && (iVar19 != -1))
                   && (iVar9 = func_0x00018046d050(iVar19), iVar9 != 0)) {
                    iVar10 = func_0x0001804611b4(iVar9, 1, iVar19, iVar14);
                    if (iVar10 == iVar19) {
                        func_0x00018045ff84(iVar14);
                        if (iVar19 != 0) {
                            func_0x000180112840(iVar9, iVar19);
                        }
                        fcn.180460d90(iVar9);
                    } else {
                        func_0x00018045ff84(iVar14);
                        fcn.180460d90(iVar9);
                    }
                    goto code_r0x0001800fb715;
                }
            }
            func_0x00018045ff84(iVar14);
        }
code_r0x0001800fb715:
        *(undefined *)(iVar17 + 0x2928) = 1;
    }
    iVar6 = 0;
    if ((0.0 < *(float *)(iVar17 + 0x292c)) &&
       (fVar21 = *(float *)(iVar17 + 0x292c) - *(float *)(iVar17 + 0x48), *(float *)(iVar17 + 0x292c) = fVar21,
       fVar21 <= 0.0)) {
        if (*(int64_t *)(iVar17 + 0x50) == 0) {
            *(undefined *)(iVar17 + 0xec) = 1;
        } else {
            func_0x000180112a70();
        }
        *(undefined4 *)(iVar17 + 0x292c) = 0;
    }
    *(int32_t *)(iVar4 + 4) = *(int32_t *)(iVar4 + 4) + 1;
    *(undefined2 *)(iVar4 + 0x281e) = 0;
    *(undefined4 *)(iVar4 + 0x15d0) = 0;
    *(double *)(iVar4 + 0x18) = (double)*(float *)(iVar4 + 0x48) + *(double *)(iVar4 + 0x18);
    iVar7 = *(int32_t *)(iVar4 + 0x283c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(iVar4 + 0x2838, iVar8);
    }
    fVar21 = 3.402823e+38;
    *(undefined4 *)(iVar4 + 0x2838) = 0;
    *(float *)(iVar4 + 0x2c80) =
         (*(float *)(iVar4 + 0x48) - *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4)) +
         *(float *)(iVar4 + 0x2c80);
    *(float *)(iVar4 + 0x2b88 + (int64_t)*(int32_t *)(iVar4 + 0x2c78) * 4) = *(float *)(iVar4 + 0x48);
    iVar8 = *(int32_t *)(iVar4 + 0x2c7c) + 1;
    *(int32_t *)(iVar4 + 0x2c78) = (*(int32_t *)(iVar4 + 0x2c78) + 1) % 0x3c;
    iVar7 = 0x3c;
    if (iVar8 < 0x3c) {
        iVar7 = iVar8;
    }
    *(int32_t *)(iVar4 + 0x2c7c) = iVar7;
    if (*(float *)(iVar4 + 0x2c80) <= 0.0) {
        fVar22 = 3.402823e+38;
    } else {
        fVar22 = 1.0 / (*(float *)(iVar4 + 0x2c80) / (float)iVar7);
    }
    *(float *)(iVar4 + 0xf0) = fVar22;
    iVar7 = *(int32_t *)(iVar4 + 0x156c);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f9d0(iVar4 + 0x1568, iVar8);
    }
    *(undefined4 *)(iVar4 + 0x1568) = 0;
    func_0x0001801093d0(*(undefined *)(iVar4 + 0x8e));
    func_0x000180113b10();
    func_0x000180106aa0();
    fcn.1800fb280();
    func_0x000180106fa0();
    *(undefined *)(iVar4 + 1) = 1;
    piVar15 = *(int64_t **)(iVar4 + 0x2158);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x2150);
    iVar14 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar14, piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        *(undefined8 *)(iVar14 + 0x40) = 0;
        *(undefined *)(iVar14 + 200) = 0;
        iVar14 = *(int64_t *)0x180781f28;
    }
    if ((*(char *)(iVar4 + 0x2400) != '\0') &&
       (iVar7 = *(int32_t *)(iVar4 + 0x241c), iVar7 == *(int32_t *)(iVar4 + 0x1654))) {
        if (*(int32_t *)(iVar14 + 0x1654) == iVar7) {
            *(int32_t *)(iVar14 + 0x1658) = iVar7;
        }
        if (*(int32_t *)(iVar14 + 0x1684) == iVar7) {
            *(undefined *)(iVar14 + 0x168d) = 1;
        }
    }
    if ((((*(char *)(iVar4 + 0xb5) != '\0') && (*(char *)(iVar4 + 0x138) != '\0')) ||
        (*(undefined4 *)(iVar4 + 0x1634) = 0, *(char *)(iVar4 + 0xb5) != '\0')) && (1 < *(int32_t *)(iVar4 + 0x1644))) {
        *(undefined4 *)(iVar4 + 0x1634) = *(undefined4 *)(iVar4 + 0x1640);
    }
    piVar18 = (int32_t *)(iVar4 + 0x163c);
    if (*(int32_t *)(iVar4 + 0x1640) == 0) {
        *(undefined4 *)(iVar4 + 0x1648) = 0;
code_r0x0001800fb97d:
        *(undefined4 *)(iVar4 + 0x164c) = 0;
    } else if ((*piVar18 != 0) && (*(int32_t *)(iVar4 + 0x1654) == *piVar18)) goto code_r0x0001800fb97d;
    iVar7 = *piVar18;
    piVar20 = (int32_t *)(iVar4 + 0x1654);
    fVar22 = *(float *)(iVar4 + 0x48);
    if ((iVar7 != 0) && (*(float *)(iVar4 + 0x1648) = fVar22 + *(float *)(iVar4 + 0x1648), *piVar20 != iVar7)) {
        *(float *)(iVar4 + 0x164c) = fVar22 + *(float *)(iVar4 + 0x164c);
    }
    *piVar18 = 0;
    iVar8 = *piVar20;
    *(int32_t *)(iVar4 + 0x1640) = iVar7;
    *(undefined4 *)(iVar4 + 0x1644) = 0;
    *(undefined2 *)(iVar4 + 0x1650) = 0;
    if (((iVar8 != 0) && (*(int32_t *)(iVar4 + 0x1658) != iVar8)) && (*(int32_t *)(iVar4 + 0x1680) == iVar8)) {
        fcn.1800f9f30(0, 0);
        fVar22 = *(float *)(iVar4 + 0x48);
    }
    iVar7 = *piVar20;
    if (iVar7 != 0) {
        *(float *)(iVar4 + 0x165c) = fVar22 + *(float *)(iVar4 + 0x165c);
    }
    *(int32_t *)(iVar4 + 0x1680) = iVar7;
    *(int32_t *)(iVar4 + 0x1658) = 0;
    *(undefined *)(iVar4 + 0x1665) = 0;
    *(undefined *)(iVar4 + 0x1660) = 0;
    *(float *)(iVar4 + 0x169c) = fVar22 + *(float *)(iVar4 + 0x169c);
    if ((*(int32_t *)(iVar4 + 0x2780) != 0) && (iVar7 != *(int32_t *)(iVar4 + 0x2780))) {
        *(undefined4 *)(iVar4 + 0x2780) = 0;
    }
    if ((*(int32_t *)(iVar4 + 0x277c) != 0) && (*(int32_t *)(iVar4 + 0x277c) != *(int32_t *)(iVar4 + 0x1684))) {
        *(undefined4 *)(iVar4 + 0x277c) = 0;
    }
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x1f68) = 0;
        *(undefined *)(iVar4 + 0x1f6c) = 0;
    }
    if (*(int32_t *)(iVar4 + 0x1688) < *(int32_t *)(iVar4 + 4)) {
        *(undefined4 *)(iVar4 + 0x1684) = 0;
    }
    iVar7 = *(int32_t *)(iVar4 + 0x2638);
    *(undefined *)(iVar4 + 0x168d) = 0;
    if (iVar7 == 0) {
        *(undefined4 *)(iVar4 + 0x2648) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(int32_t *)(iVar4 + 0x2648) = iVar7;
    }
    if (*(int64_t *)(iVar4 + 0x15e8) == 0) {
        *(undefined4 *)(iVar4 + 0x264c) = 0;
    } else if (*(float *)(iVar4 + 0x12b0) <= *(float *)(iVar4 + 0x2654)) {
        *(undefined4 *)(iVar4 + 0x264c) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x15e8) + 0x10);
    }
    *(int32_t *)(iVar4 + 0x263c) = iVar7;
    if (iVar7 == 0) {
        if (0.0 < *(float *)(iVar4 + 0x2640)) {
            fVar23 = fVar22 + *(float *)(iVar4 + 0x2644);
            *(float *)(iVar4 + 0x2644) = fVar23;
            fVar24 = 0.25;
            if (0.25 <= fVar22 + fVar22) {
                fVar24 = fVar22 + fVar22;
            }
            if (fVar24 <= fVar23) {
                *(undefined8 *)(iVar4 + 0x2640) = 0;
            }
        }
    } else {
        *(undefined4 *)(iVar4 + 0x2644) = 0;
        *(undefined4 *)(iVar4 + 0x2638) = 0;
        *(float *)(iVar4 + 0x2640) = *(float *)(iVar4 + 0x2640) + fVar22;
    }
    func_0x000180108270();
    *(undefined4 *)(iVar4 + 0x2488) = *(undefined4 *)(iVar4 + 0x2484);
    *(undefined4 *)(iVar4 + 0x247c) = *(undefined4 *)(iVar4 + 0x2478);
    *(undefined4 *)(iVar4 + 0x2478) = 0;
    *(undefined8 *)(iVar4 + 0x2480) = 0x7f7fffff;
    *(undefined2 *)(iVar4 + 0x2401) = 0;
    *(undefined4 *)(iVar4 + 0x2490) = 0;
    if (*(char *)(iVar4 + 0x2400) != '\0') {
        if (*piVar20 == 0) {
            pcVar16 = "#DragDropCancelHandler";
            cVar5 = '#';
            do {
                if (((cVar5 == '#') && (*pcVar16 == '#')) && (pcVar16[1] == '#')) {
                    pcVar16 = pcVar16 + 2;
                }
                cVar5 = *pcVar16;
                pcVar16 = pcVar16 + 1;
            } while (cVar5 != '\0');
        }
        cVar5 = func_0x000180109d80();
        if (cVar5 != '\0') {
            fcn.1800f9f30(0, 0);
            func_0x0001801120a0();
        }
    }
    *(undefined8 *)(iVar4 + 0x2820) = 0;
    func_0x00018010f2f0();
    func_0x000180108830();
    func_0x000180114da0(iVar4);
    if ((*(char *)(iVar4 + 0x20b9) != '\0') || (*(float *)(iVar4 + 0x98) < 0.0)) {
        bVar3 = true;
    } else {
        bVar3 = false;
        fVar21 = (float)*(double *)(iVar4 + 0x18) - *(float *)(iVar4 + 0x98);
    }
    piVar15 = *(int64_t **)(iVar4 + 0x1588);
    piVar2 = piVar15 + *(int32_t *)(iVar4 + 0x1580);
    for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
        iVar14 = *piVar15;
        cVar5 = *(char *)(iVar14 + 0x109);
        *(char *)(iVar14 + 0x10a) = cVar5;
        *(undefined *)(iVar14 + 0x109) = 0;
        *(undefined *)(iVar14 + 0x10b) = 0;
        *(undefined2 *)(iVar14 + 0x11a) = *(undefined2 *)(iVar14 + 0x118);
        *(undefined2 *)(iVar14 + 0x118) = 0;
        if (((cVar5 == '\0') || (bVar3)) &&
           ((*(char *)(iVar14 + 0x494) == '\0' &&
            (*(float *)(iVar14 + 0x2e8) <= fVar21 && fVar21 != *(float *)(iVar14 + 0x2e8))))) {
            iVar17 = *(int64_t *)(iVar14 + 800);
            *(undefined *)(iVar14 + 0x494) = 1;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x10) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x14);
            if (iVar8 < *(int32_t *)(iVar17 + 0x14)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x48c) = iVar7;
            iVar8 = (int32_t)((float)*(int32_t *)(iVar17 + 0x20) * 1.05);
            iVar7 = *(int32_t *)(iVar17 + 0x24);
            if (iVar8 < *(int32_t *)(iVar17 + 0x24)) {
                iVar7 = iVar8;
            }
            *(int32_t *)(iVar14 + 0x490) = iVar7;
            if (*(int64_t *)(iVar14 + 0x150) != 0) {
                *(undefined8 *)(iVar14 + 0x148) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x150) = 0;
            }
            func_0x000180124110(*(undefined8 *)(iVar14 + 800));
            if (*(int64_t *)(iVar14 + 0x1f8) != 0) {
                *(undefined8 *)(iVar14 + 0x1f0) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x1f8) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x250) != 0) {
                *(undefined8 *)(iVar14 + 0x248) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x250) = 0;
            }
            if (*(int64_t *)(iVar14 + 0x260) != 0) {
                *(undefined8 *)(iVar14 + 600) = 0;
                fcn.180460d90();
                *(undefined8 *)(iVar14 + 0x260) = 0;
            }
        }
    }
    fcn.1800fae50(iVar4 + 0x118);
    iVar17 = *(int64_t *)0x180781f28;
    iVar14 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1600);
    if (iVar14 == 0) {
        if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) == 0) ||
           (iVar7 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1654),
           *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1678) + 0xc4) != iVar7)) goto code_r0x0001800fbfc6;
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar7;
        if (*(int32_t *)(iVar17 + 0x1684) == iVar7) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') goto code_r0x0001800fbfc6;
    } else {
        piVar18 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1654);
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = *piVar18;
        if (*(int32_t *)(iVar17 + 0x1684) == *piVar18) {
            *(undefined *)(iVar17 + 0x168d) = 1;
        }
        iVar14 = *(int64_t *)(iVar14 + 0x428);
        if ((*(char *)(iVar14 + 0x10a) == '\0') && (*(char *)(iVar14 + 0x109) == '\0')) {
            bVar3 = true;
        } else {
            bVar3 = false;
        }
        if (*(char *)(iVar17 + 0x120) != '\0') {
            pfVar1 = (float *)(iVar17 + 0x118);
            pfVar11 = pfVar1;
            if (pfVar1 == (float *)0x0) {
                pfVar11 = (float *)(*(int64_t *)0x180781f28 + 0x118);
            }
            if (((-256000.0 <= *pfVar11) && (-256000.0 <= pfVar11[1])) && (!bVar3)) {
                fVar22 = *pfVar1 - *(float *)(iVar17 + 0x166c);
                fVar24 = *(float *)(iVar17 + 0x11c) - *(float *)(iVar17 + 0x1670);
                var_8h._0_4_ = fVar22;
                var_8h._4_4_ = fVar24;
                if ((*(float *)(iVar14 + 0x60) != fVar22) || (*(float *)(iVar14 + 100) != fVar24)) {
                    func_0x000180106470(iVar14, &var_8h, 1);
                    if ((*(int64_t *)(iVar14 + 0x48) != 0) && (*(char *)(iVar14 + 0x108) != '\0')) {
                        *(uint64_t *)(*(int64_t *)(iVar14 + 0x48) + 8) = CONCAT44(fVar24, fVar22);
                        iVar14 = *(int64_t *)(iVar14 + 0x48);
                        *(float *)(iVar14 + 0x20) = *(float *)(iVar14 + 0x148) + *(float *)(iVar14 + 8);
                        *(float *)(iVar14 + 0x24) = *(float *)(iVar14 + 0x14c) + *(float *)(iVar14 + 0xc);
                        fVar24 = (*(float *)(iVar14 + 0x14) - *(float *)(iVar14 + 0x14c)) - *(float *)(iVar14 + 0x154);
                        fVar23 = (*(float *)(iVar14 + 0x10) - *(float *)(iVar14 + 0x148)) - *(float *)(iVar14 + 0x150);
                        fVar22 = 0.0;
                        if (0.0 <= fVar24) {
                            fVar22 = fVar24;
                        }
                        fVar24 = 0.0;
                        if (0.0 <= fVar23) {
                            fVar24 = fVar23;
                        }
                        *(float *)(iVar14 + 0x2c) = fVar22;
                        *(float *)(iVar14 + 0x28) = fVar24;
                    }
                }
                func_0x00018010e050(*(undefined8 *)(iVar17 + 0x1600), 0);
                goto code_r0x0001800fbfc6;
            }
        }
        fcn.1800fac90();
    }
    fcn.1800f9f30(0, 0);
code_r0x0001800fbfc6:
    uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    if (-1 < (int32_t)uVar13) {
        do {
            iVar14 = *(int64_t *)((uint64_t)uVar13 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar14 != 0) && ((*(uint32_t *)(iVar14 + 0x14) & 0x8000000) != 0)) goto code_r0x0001800fc015;
            uVar13 = uVar13 - 1;
        } while (-1 < (int32_t)uVar13);
    }
    if ((*(int64_t *)(iVar4 + 0x23c0) == 0) || (*(float *)(iVar4 + 0x23dc) <= 0.0)) {
        fVar22 = *(float *)(iVar4 + 0x23fc) - *(float *)(iVar4 + 0x48) * 10.0;
        if (fVar22 <= 0.0) {
            fVar22 = 0.0;
        }
    } else {
code_r0x0001800fc015:
        fVar22 = *(float *)(iVar4 + 0x48) * 6.0 + *(float *)(iVar4 + 0x23fc);
        if (1.0 <= fVar22) {
            fVar22 = 1.0;
        }
    }
    *(float *)(iVar4 + 0x23fc) = fVar22;
    *(undefined4 *)(iVar4 + 0x2650) = 0;
    *(undefined4 *)(iVar4 + 0x28c4) = *(undefined4 *)(iVar4 + 0x28b0);
    *(undefined4 *)(iVar4 + 0x28c8) = *(undefined4 *)(iVar4 + 0x28b4);
    *(undefined4 *)(iVar4 + 0x28cc) = *(undefined4 *)(iVar4 + 0x28b8);
    *(undefined4 *)(iVar4 + 0x28d0) = *(undefined4 *)(iVar4 + 0x28bc);
    *(undefined4 *)(iVar4 + 0x28d4) = *(undefined4 *)(iVar4 + 0x28c0);
    *(undefined8 *)(iVar4 + 0x2c88) = 0xffffffffffffffff;
    *(undefined4 *)(iVar4 + 0x2c84) = 0xffffffff;
    *(undefined2 *)(iVar4 + 0x28b0) = 0;
    func_0x000180108de0();
    iVar7 = iVar6;
    if (0 < *(int32_t *)(iVar4 + 0x2518)) {
        do {
            iVar14 = *(int64_t *)0x180781f28;
            fVar22 = *(float *)(*(int64_t *)(iVar4 + 0x2520) + (int64_t)iVar7 * 4);
            if ((0.0 <= fVar22) && (fVar22 < fVar21)) {
                iVar17 = (int64_t)iVar7 * 0x250 + *(int64_t *)(iVar4 + 0x24f8);
                *(undefined8 *)(iVar17 + 0x1f0) = 0;
                if (*(int64_t *)(iVar17 + 0x1e8) != 0) {
                    *(undefined8 *)(iVar17 + 0x1e0) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x1e8) = 0;
                }
                *(undefined *)(iVar17 + 0x23c) = 1;
                if (*(int64_t *)(iVar17 + 0x198) != 0) {
                    *(undefined8 *)(iVar17 + 400) = 0;
                    fcn.180460d90();
                    *(undefined8 *)(iVar17 + 0x198) = 0;
                }
                *(undefined *)(iVar17 + 0x24b) = 1;
                iVar8 = iVar6;
                if (0 < *(int32_t *)(iVar17 + 0x6c)) {
                    do {
                        iVar19 = (int64_t)iVar8;
                        iVar8 = iVar8 + 1;
                        *(undefined2 *)(iVar19 * 0x74 + 0x54 + *(int64_t *)(iVar17 + 0x18)) = 0xffff;
                    } while (iVar8 < *(int32_t *)(iVar17 + 0x6c));
                }
                *(undefined4 *)
                 (*(int64_t *)(iVar14 + 0x2520) +
                 (int64_t)(int32_t)((iVar17 - *(int64_t *)(iVar14 + 0x24f8)) / 0x250) * 4) = 0xbf800000;
            }
            iVar7 = iVar7 + 1;
        } while (iVar7 < *(int32_t *)(iVar4 + 0x2518));
    }
    iVar14 = *(int64_t *)(iVar4 + 0x24e8);
    iVar19 = (int64_t)*(int32_t *)(iVar4 + 0x24e0) * 0x88 + iVar14;
    iVar17 = *(int64_t *)0x180781f28;
    for (; *(int64_t *)0x180781f28 = iVar17, iVar14 != iVar19; iVar14 = iVar14 + 0x88) {
        if ((0.0 <= *(float *)(iVar14 + 8)) && (*(float *)(iVar14 + 8) < fVar21)) {
            func_0x000180126a10(iVar14 + 0x28);
            *(undefined4 *)(iVar14 + 8) = 0xbf800000;
        }
        iVar17 = *(int64_t *)0x180781f28;
    }
    if (*(char *)(iVar4 + 0x20b9) != '\0') {
        if (*(int64_t *)(iVar17 + 0x2108) != 0) {
            *(undefined8 *)(iVar17 + 0x2100) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2108) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x2118) != 0) {
            *(undefined8 *)(iVar17 + 0x2110) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x2118) = 0;
        }
        if (*(int64_t *)(iVar17 + 0x26e8) != 0) {
            *(undefined8 *)(iVar17 + 0x26e0) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar17 + 0x26e8) = 0;
        }
        *(undefined4 *)(iVar17 + 0x26f0) = 0;
        *(undefined4 *)(iVar17 + 0x25f8) = 0;
        func_0x00018011ee60(iVar17 + 0x2600);
        func_0x0001801388c0();
        piVar15 = *(int64_t **)(iVar17 + 0x12e0);
        piVar2 = piVar15 + *(int32_t *)(iVar17 + 0x12d8);
        for (; piVar15 != piVar2; piVar15 = piVar15 + 1) {
            iVar14 = *piVar15;
            iVar17 = *(int64_t *)(iVar14 + 0x2b0);
            func_0x000180129630(iVar14, 1);
            func_0x000180129f40(&var_8h, iVar14);
            if (((*(int32_t *)(iVar17 + 0x9c) != 0) || ((float)var_8h != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x1c))
                ) || (var_8h._4_4_ != *(float *)(*(int64_t *)(iVar14 + 0x38) + 0x20))) {
                func_0x0001801299b0(iVar14);
            }
        }
    }
    *(undefined *)(iVar4 + 0x20b9) = 0;
    if ((*(int64_t *)(iVar4 + 0x21d8) != 0) && (*(char *)(*(int64_t *)(iVar4 + 0x21d8) + 0x10a) == '\0')) {
        uVar13 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1590) - 1;
        if (-1 < (int32_t)uVar13) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1598) + (uint64_t)uVar13 * 8);
                if (((iVar14 != 0) && (*(char *)(iVar14 + 0x10a) != '\0')) &&
                   ((*(uint32_t *)(iVar14 + 0x14) & 0x10200) != 0x10200)) goto code_r0x0001800fc388;
                uVar13 = uVar13 - 1;
            } while (-1 < (int32_t)uVar13);
        }
        iVar14 = 0;
code_r0x0001800fc388:
        func_0x00018010e050(iVar14, 1);
    }
    func_0x00018011f370(iVar4 + 0x15b0, 0);
    iVar7 = *(int32_t *)(iVar4 + 0x2134);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011f970(iVar4 + 0x2130, iVar8);
    }
    piVar18 = (int32_t *)(iVar4 + 0x2100);
    *(undefined4 *)(iVar4 + 0x2130) = 0;
    iVar7 = *(int32_t *)(iVar4 + 0x2104);
    if (iVar7 < 0) {
        iVar7 = iVar7 + iVar7 / 2;
        iVar8 = iVar6;
        if (0 < iVar7) {
            iVar8 = iVar7;
        }
        func_0x00018011fb10(piVar18, iVar8);
    }
    *piVar18 = 0;
    if (*(int32_t *)(iVar4 + 0x2104) == 0) {
        func_0x00018011fb10(piVar18, 8);
    }
    *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)*piVar18 * 4) = 0x10;
    iVar7 = *piVar18;
    *piVar18 = iVar7 + 1;
    *(undefined4 *)(iVar4 + 0x1f78) = *(undefined4 *)(*(int64_t *)(iVar4 + 0x2108) + (int64_t)iVar7 * 4);
    func_0x00018011f140(iVar4 + 0x2110, 0);
    if ((*(uint8_t *)(iVar4 + 0x30) & 0x80) != 0) {
        iVar14 = *(int64_t *)(iVar4 + 0x15f0);
        *(undefined8 *)(iVar4 + 0x2b80) = 0;
        if (iVar14 != 0) {
            if (*(int64_t *)(iVar14 + 0x4c8) == 0) {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar14 + 0x418) + 0x4c0);
                if (iVar14 != 0) {
                    *(int64_t *)(iVar4 + 0x2b80) = iVar14;
                }
            } else {
                uVar12 = func_0x00018011bfb0(*(int64_t *)(iVar14 + 0x4c8), *(undefined8 *)(iVar4 + 0x118));
                *(undefined8 *)(iVar4 + 0x2b80) = uVar12;
            }
        }
        piVar18 = *(int32_t **)(iVar4 + 0x2900);
        piVar20 = piVar18 + (int64_t)*(int32_t *)(iVar4 + 0x28f8) * 0x10;
        for (; piVar18 != piVar20; piVar18 = piVar18 + 0x10) {
            if (*piVar18 == 1) {
                func_0x000180115650(iVar4, piVar18);
            }
        }
        iVar7 = *(int32_t *)(iVar4 + 0x28fc);
        if (iVar7 < 0) {
            iVar7 = iVar7 + iVar7 / 2;
            iVar8 = iVar6;
            if (0 < iVar7) {
                iVar8 = iVar7;
            }
            func_0x00018011fa30(iVar4 + 0x28f8, iVar8);
        }
        *(undefined4 *)(iVar4 + 0x28f8) = 0;
        if (0 < *(int32_t *)(iVar4 + 0x28e8)) {
            do {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar4 + 0x28f0) + 8 + (int64_t)iVar6 * 0x10);
                if (((iVar14 != 0) && (*(int64_t *)(iVar14 + 0x18) == 0)) &&
                   ((*(uint32_t *)(iVar14 + 0x10) & 0x400) == 0)) {
                    func_0x000180116d90();
                }
                iVar6 = iVar6 + 1;
            } while (iVar6 < *(int32_t *)(iVar4 + 0x28e8));
        }
    }
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined *)(iVar4 + 2) = 1;
    *(uint32_t *)(iVar14 + 0x2008) = *(uint32_t *)(iVar14 + 0x2008) | 2;
    *(undefined4 *)(iVar14 + 0x202c) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2030) = 0x43c80000;
    *(undefined4 *)(iVar14 + 0x2010) = 4;
    func_0x0001801019f0(0x1806444f8, 0, 0);
    iVar14 = *(int64_t *)0x180781f28;
    *(undefined4 *)(iVar4 + 0x2a5c) = 0;
    *(undefined2 *)(iVar4 + 0x2a60) = *(undefined2 *)(iVar14 + 0x15b0);
    *(undefined2 *)(iVar4 + 0x2a62) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x148);
    *(undefined2 *)(iVar4 + 0x2a64) = *(undefined2 *)(*(int64_t *)(iVar14 + 0x15e0) + 0x1e0);
    *(undefined2 *)(iVar4 + 0x2a66) = *(undefined2 *)(iVar14 + 0x20c0);
    *(undefined2 *)(iVar4 + 0x2a68) = *(undefined2 *)(iVar14 + 0x20d0);
    *(undefined2 *)(iVar4 + 0x2a6a) = *(undefined2 *)(iVar14 + 0x20e0);
    *(undefined2 *)(iVar4 + 0x2a6c) = *(undefined2 *)(iVar14 + 0x20f0);
    *(undefined2 *)(iVar4 + 0x2a6e) = *(undefined2 *)(iVar14 + 0x2110);
    *(undefined2 *)(iVar4 + 0x2a70) = *(undefined2 *)(iVar14 + 0x2100);
    *(undefined2 *)(iVar4 + 0x2a72) = *(undefined2 *)(iVar14 + 0x2130);
    *(undefined2 *)(iVar4 + 0x2a74) = *(undefined2 *)(iVar14 + 0x281c);
    iVar14 = *(int64_t *)(iVar4 + 0x2978);
    iVar17 = (int64_t)*(int32_t *)(iVar4 + 0x2970) * 0x20 + iVar14;
    for (; iVar14 != iVar17; iVar14 = iVar14 + 0x20) {
        if (*(int32_t *)(iVar14 + 4) == 1) {
            (**(code **)(iVar14 + 0x10))(iVar4, iVar14);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fc6e0
// Address: 0x1800fc6e0
// Size: 90 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_109h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e1h because it doesn't fit into ProtoModel

void fcn.1800fc6e0(int64_t arg1, int64_t arg2, int64_t arg_38h, int64_t arg_1c8h, int64_t arg_1d0h)
{
    int64_t arg2_00;
    int32_t iVar1;
    uint32_t uVar2;
    int64_t unaff_RBX;
    uint64_t uVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000198;
    int64_t in_stack_000001a0;
    int64_t var_28h;
    
    iVar1 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar1) {
        iVar4 = *(int32_t *)arg1 + 1;
        if (iVar1 == 0) {
            iVar1 = 8;
        } else {
            iVar1 = iVar1 / 2 + iVar1;
        }
        if (iVar4 < iVar1) {
            iVar4 = iVar1;
        }
        func_0x00018011f4f0(arg1, iVar4);
    }
    *(int64_t *)(*(int64_t *)(arg1 + 8) + (int64_t)*(int32_t *)arg1 * 8) = arg2;
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    if (*(char *)(arg2 + 0x109) != '\0') {
        iVar1 = *(int32_t *)(arg2 + 0x1f0);
        if (1 < (uint64_t)(int64_t)iVar1) {
            func_0x00018046f0d0(*(undefined8 *)(arg2 + 0x1f8), (int64_t)iVar1, 8, 0x1800fc690);
        }
        uVar3 = 0;
        if (0 < iVar1) {
            do {
                arg2_00 = *(int64_t *)(*(int64_t *)(arg2 + 0x1f8) + uVar3 * 8);
                if (*(char *)(arg2_00 + 0x109) != '\0') {
                    fcn.1800fc6e0(arg1, arg2_00, unaff_RBX, in_stack_00000198, in_stack_000001a0);
                }
                uVar2 = (int32_t)uVar3 + 1;
                uVar3 = (uint64_t)uVar2;
            } while ((int32_t)uVar2 < iVar1);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fc73a
// Address: 0x1800fc73a
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_109h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e1h because it doesn't fit into ProtoModel

void fcn.1800fc6e0(int64_t arg1, int64_t arg2, int64_t arg_38h, int64_t arg_1c8h, int64_t arg_1d0h)
{
    int64_t arg2_00;
    int32_t iVar1;
    uint32_t uVar2;
    int64_t unaff_RBX;
    uint64_t uVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000198;
    int64_t in_stack_000001a0;
    int64_t var_28h;
    
    iVar1 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar1) {
        iVar4 = *(int32_t *)arg1 + 1;
        if (iVar1 == 0) {
            iVar1 = 8;
        } else {
            iVar1 = iVar1 / 2 + iVar1;
        }
        if (iVar4 < iVar1) {
            iVar4 = iVar1;
        }
        func_0x00018011f4f0(arg1, iVar4);
    }
    *(int64_t *)(*(int64_t *)(arg1 + 8) + (int64_t)*(int32_t *)arg1 * 8) = arg2;
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    if (*(char *)(arg2 + 0x109) != '\0') {
        iVar1 = *(int32_t *)(arg2 + 0x1f0);
        if (1 < (uint64_t)(int64_t)iVar1) {
            func_0x00018046f0d0(*(undefined8 *)(arg2 + 0x1f8), (int64_t)iVar1, 8, 0x1800fc690);
        }
        uVar3 = 0;
        if (0 < iVar1) {
            do {
                arg2_00 = *(int64_t *)(*(int64_t *)(arg2 + 0x1f8) + uVar3 * 8);
                if (*(char *)(arg2_00 + 0x109) != '\0') {
                    fcn.1800fc6e0(arg1, arg2_00, unaff_RBX, in_stack_00000198, in_stack_000001a0);
                }
                uVar2 = (int32_t)uVar3 + 1;
                uVar3 = (uint64_t)uVar2;
            } while ((int32_t)uVar2 < iVar1);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fc79f
// Address: 0x1800fc79f
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_109h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_e1h because it doesn't fit into ProtoModel

void fcn.1800fc6e0(int64_t arg1, int64_t arg2, int64_t arg_38h, int64_t arg_1c8h, int64_t arg_1d0h)
{
    int64_t arg2_00;
    int32_t iVar1;
    uint32_t uVar2;
    int64_t unaff_RBX;
    uint64_t uVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000198;
    int64_t in_stack_000001a0;
    int64_t var_28h;
    
    iVar1 = *(int32_t *)(arg1 + 4);
    if (*(int32_t *)arg1 == iVar1) {
        iVar4 = *(int32_t *)arg1 + 1;
        if (iVar1 == 0) {
            iVar1 = 8;
        } else {
            iVar1 = iVar1 / 2 + iVar1;
        }
        if (iVar4 < iVar1) {
            iVar4 = iVar1;
        }
        func_0x00018011f4f0(arg1, iVar4);
    }
    *(int64_t *)(*(int64_t *)(arg1 + 8) + (int64_t)*(int32_t *)arg1 * 8) = arg2;
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    if (*(char *)(arg2 + 0x109) != '\0') {
        iVar1 = *(int32_t *)(arg2 + 0x1f0);
        if (1 < (uint64_t)(int64_t)iVar1) {
            func_0x00018046f0d0(*(undefined8 *)(arg2 + 0x1f8), (int64_t)iVar1, 8, 0x1800fc690);
        }
        uVar3 = 0;
        if (0 < iVar1) {
            do {
                arg2_00 = *(int64_t *)(*(int64_t *)(arg2 + 0x1f8) + uVar3 * 8);
                if (*(char *)(arg2_00 + 0x109) != '\0') {
                    fcn.1800fc6e0(arg1, arg2_00, unaff_RBX, in_stack_00000198, in_stack_000001a0);
                }
                uVar2 = (int32_t)uVar3 + 1;
                uVar3 = (uint64_t)uVar2;
            } while ((int32_t)uVar2 < iVar1);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fc7b0
// Address: 0x1800fc7b0
// Size: 166 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800fc7b0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = *(int64_t *)(arg1 + 0x48);
    *(int32_t *)(*(int64_t *)0x180781f28 + 0xfc) = *(int32_t *)(*(int64_t *)0x180781f28 + 0xfc) + 1;
    if (1 < *(int32_t *)(*(int64_t *)(arg1 + 800) + 0x8c)) {
        func_0x000180126c00();
    }
    func_0x0001801270f0(iVar2 + 200, *(undefined8 *)(iVar2 + 0x110 + (int64_t)(int32_t)arg2 * 8), 
                        *(undefined8 *)(arg1 + 800));
    piVar3 = *(int64_t **)(arg1 + 0x1f8);
    piVar1 = piVar3 + *(int32_t *)(arg1 + 0x1f0);
    for (; piVar3 != piVar1; piVar3 = piVar3 + 1) {
        iVar2 = *piVar3;
        if ((*(char *)(iVar2 + 0x109) != '\0') && (*(char *)(iVar2 + 0x111) == '\0')) {
            fcn.1800fc7b0(iVar2, arg2 & 0xffffffff);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fc860
// Address: 0x1800fc860
// Size: 138 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.1800fc860(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined in_R8B;
    
    iVar4 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar4 = *(int64_t *)(iVar4 + 0x15e0);
    fcn.1801244b0(*(undefined8 *)(iVar4 + 800), arg1, arg2, in_R8B);
    iVar6 = (int64_t)*(int32_t *)(*(int64_t *)(iVar4 + 800) + 0xa0);
    iVar5 = *(int64_t *)(*(int64_t *)(iVar4 + 800) + 0xa8);
    uVar1 = *(undefined4 *)(iVar5 + -0xc + iVar6 * 0x10);
    uVar2 = *(undefined4 *)(iVar5 + -8 + iVar6 * 0x10);
    uVar3 = *(undefined4 *)(iVar5 + -4 + iVar6 * 0x10);
    *(undefined4 *)(iVar4 + 0x2b8) = *(undefined4 *)(iVar5 + -0x10 + iVar6 * 0x10);
    *(undefined4 *)(iVar4 + 700) = uVar1;
    *(undefined4 *)(iVar4 + 0x2c0) = uVar2;
    *(undefined4 *)(iVar4 + 0x2c4) = uVar3;
    return;
}

// ============================================================
// Function: FUN_1800fc8f0
// Address: 0x1800fc8f0
// Size: 175 bytes
// ============================================================
void fcn.1800fc8f0(void)
{
    int32_t *piVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    
    iVar5 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar5 = *(int64_t *)(iVar5 + 0x15e0);
    iVar6 = *(int64_t *)(iVar5 + 800);
    piVar1 = (int32_t *)(iVar6 + 0xa0);
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
        puVar7 = (undefined4 *)(*(int64_t *)(iVar6 + 0x38) + 0x38);
    } else {
        puVar7 = (undefined4 *)((int64_t)(*(int32_t *)(iVar6 + 0xa0) + -1) * 0x10 + *(int64_t *)(iVar6 + 0xa8));
    }
    uVar2 = puVar7[1];
    uVar3 = puVar7[2];
    uVar4 = puVar7[3];
    *(undefined4 *)(iVar6 + 0x60) = *puVar7;
    *(undefined4 *)(iVar6 + 100) = uVar2;
    *(undefined4 *)(iVar6 + 0x68) = uVar3;
    *(undefined4 *)(iVar6 + 0x6c) = uVar4;
    func_0x0001801242c0();
    iVar8 = (int64_t)*(int32_t *)(*(int64_t *)(iVar5 + 800) + 0xa0);
    iVar6 = *(int64_t *)(*(int64_t *)(iVar5 + 800) + 0xa8);
    uVar2 = *(undefined4 *)(iVar6 + -0xc + iVar8 * 0x10);
    uVar3 = *(undefined4 *)(iVar6 + -8 + iVar8 * 0x10);
    uVar4 = *(undefined4 *)(iVar6 + -4 + iVar8 * 0x10);
    *(undefined4 *)(iVar5 + 0x2b8) = *(undefined4 *)(iVar6 + -0x10 + iVar8 * 0x10);
    *(undefined4 *)(iVar5 + 700) = uVar2;
    *(undefined4 *)(iVar5 + 0x2c0) = uVar3;
    *(undefined4 *)(iVar5 + 0x2c4) = uVar4;
    return;
}

// ============================================================
// Function: FUN_1800fc9e0
// Address: 0x1800fc9e0
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Removing arg arg_418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.1800fc9e0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    float fVar2;
    float fVar3;
    undefined8 uVar4;
    int32_t *piVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    int32_t *piVar22;
    int64_t iVar23;
    int32_t iVar24;
    int32_t iVar25;
    int32_t iVar26;
    int64_t iVar27;
    int32_t iVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    float var_d0h;
    float var_cch;
    float var_c8h;
    float var_c4h;
    float var_c0h;
    float var_bch;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    if ((arg2 & 0xff000000U) != 0) {
        iVar23 = *(int64_t *)(arg1 + 0x48);
        fVar2 = *(float *)(iVar23 + 8);
        fVar3 = *(float *)(iVar23 + 0xc);
        fVar30 = fVar2 + *(float *)(iVar23 + 0x10);
        fVar31 = fVar3 + *(float *)(iVar23 + 0x14);
        piVar5 = *(int32_t **)(*(int64_t *)(arg1 + 0x428) + 800);
        var_d8h._0_4_ = fVar2;
        var_d8h._4_4_ = fVar3;
        var_d0h = fVar30;
        var_cch = fVar31;
        func_0x000180126c00(piVar5 + 0x22, piVar5);
        if (*piVar5 == 0) {
            func_0x000180124200(piVar5);
        }
        var_18h._0_4_ = fVar30 + 1.0;
        var_20h._0_4_ = fVar2 - 1.0;
        var_18h._4_4_ = fVar31 + 1.0;
        var_20h._4_4_ = fVar3 - 1.0;
        fcn.1801244b0(piVar5, &var_20h, &var_18h, 0);
        func_0x000180126550(piVar5, &var_d8h, &var_d0h, arg2 & 0xffffffff, 0, 0);
        iVar23 = *(int64_t *)(piVar5 + 2);
        iVar26 = 8;
        iVar24 = *piVar5;
        iVar27 = (int64_t)iVar24;
        puVar1 = (undefined4 *)(iVar23 + -0x48 + iVar27 * 0x48);
        uVar6 = *puVar1;
        uVar7 = puVar1[1];
        uVar8 = puVar1[2];
        uVar9 = puVar1[3];
        iVar28 = iVar24 + -1;
        uVar4 = *(undefined8 *)(iVar23 + -8 + iVar27 * 0x48);
        puVar1 = (undefined4 *)(iVar23 + -0x38 + iVar27 * 0x48);
        uVar10 = *puVar1;
        uVar11 = puVar1[1];
        uVar12 = puVar1[2];
        uVar13 = puVar1[3];
        puVar1 = (undefined4 *)(iVar23 + -0x28 + iVar27 * 0x48);
        uVar14 = *puVar1;
        uVar15 = puVar1[1];
        uVar16 = puVar1[2];
        uVar17 = puVar1[3];
        puVar1 = (undefined4 *)(iVar23 + -0x18 + iVar27 * 0x48);
        uVar18 = *puVar1;
        uVar19 = puVar1[1];
        uVar20 = puVar1[2];
        uVar21 = puVar1[3];
        *piVar5 = iVar28;
        iVar25 = piVar5[1];
        if (iVar28 == 0) {
            if (iVar25 == 0) {
                if (iVar24 < 8) {
                    iVar24 = 8;
                }
                func_0x00018011fc10(piVar5, iVar24);
            }
            iVar27 = (int64_t)*piVar5;
            iVar23 = *(int64_t *)(piVar5 + 2);
            puVar1 = (undefined4 *)(iVar23 + iVar27 * 0x48);
            *puVar1 = uVar6;
            puVar1[1] = uVar7;
            puVar1[2] = uVar8;
            puVar1[3] = uVar9;
            puVar1 = (undefined4 *)(iVar23 + 0x10 + iVar27 * 0x48);
            *puVar1 = uVar10;
            puVar1[1] = uVar11;
            puVar1[2] = uVar12;
            puVar1[3] = uVar13;
            puVar1 = (undefined4 *)(iVar23 + 0x20 + iVar27 * 0x48);
            *puVar1 = uVar14;
            puVar1[1] = uVar15;
            puVar1[2] = uVar16;
            puVar1[3] = uVar17;
            puVar1 = (undefined4 *)(iVar23 + 0x30 + iVar27 * 0x48);
            *puVar1 = uVar18;
            puVar1[1] = uVar19;
            puVar1[2] = uVar20;
            puVar1[3] = uVar21;
            *(undefined8 *)(iVar23 + 0x40 + iVar27 * 0x48) = uVar4;
        } else {
            if (iVar28 == iVar25) {
                if (iVar25 == 0) {
                    iVar25 = 8;
                } else {
                    iVar25 = iVar25 / 2 + iVar25;
                }
                if (iVar24 < iVar25) {
                    iVar24 = iVar25;
                }
                func_0x00018011fc10(piVar5, iVar24);
                iVar23 = *(int64_t *)(piVar5 + 2);
            }
            if (0 < (int64_t)*piVar5) {
                func_0x000180498030(iVar23 + 0x48, iVar23, (int64_t)*piVar5 * 0x48);
            }
            puVar1 = *(undefined4 **)(piVar5 + 2);
            *puVar1 = uVar6;
            puVar1[1] = uVar7;
            puVar1[2] = uVar8;
            puVar1[3] = uVar9;
            puVar1[4] = uVar10;
            puVar1[5] = uVar11;
            puVar1[6] = uVar12;
            puVar1[7] = uVar13;
            puVar1[8] = uVar14;
            puVar1[9] = uVar15;
            puVar1[10] = uVar16;
            puVar1[0xb] = uVar17;
            puVar1[0xc] = uVar18;
            puVar1[0xd] = uVar19;
            puVar1[0xe] = uVar20;
            puVar1[0xf] = uVar21;
            *(undefined8 *)(puVar1 + 0x10) = uVar4;
        }
        *piVar5 = *piVar5 + 1;
        func_0x000180124200(piVar5);
        piVar22 = piVar5 + 0x28;
        *piVar22 = *piVar22 + -1;
        if (*piVar22 == 0) {
            piVar22 = (int32_t *)(*(int64_t *)(piVar5 + 0xe) + 0x38);
        } else {
            piVar22 = (int32_t *)((int64_t)(piVar5[0x28] + -1) * 0x10 + *(int64_t *)(piVar5 + 0x2a));
        }
        iVar24 = piVar22[1];
        iVar25 = piVar22[2];
        iVar28 = piVar22[3];
        piVar5[0x18] = *piVar22;
        piVar5[0x19] = iVar24;
        piVar5[0x1a] = iVar25;
        piVar5[0x1b] = iVar28;
        func_0x0001801242c0(piVar5);
        if ((*(uint8_t *)(*(int64_t *)(arg1 + 0x418) + 0x495) & 1) != 0) {
            iVar23 = *(int64_t *)(arg1 + 0x428);
            iVar24 = *(int32_t *)(iVar23 + 0x1f0) + -1;
            if (-1 < iVar24) {
                do {
                    iVar27 = *(int64_t *)(*(int64_t *)(iVar23 + 0x1f8) + (int64_t)iVar24 * 8);
                    if ((*(char *)(iVar27 + 0x109) != '\0') && (*(char *)(iVar27 + 0x111) == '\0')) {
                        iVar23 = func_0x0001800fc9a0(iVar27);
                        break;
                    }
                    iVar24 = iVar24 + -1;
                } while (-1 < iVar24);
            }
            piVar5 = *(int32_t **)(iVar23 + 800);
            func_0x000180126c00(piVar5 + 0x22, piVar5);
            if (*piVar5 == 0) {
                func_0x000180124200(piVar5);
            }
            piVar22 = piVar5 + 0x28;
            iVar24 = piVar5[0x29];
            fVar29 = fVar2;
            if (fVar2 <= fVar30) {
                fVar29 = fVar30;
            }
            fVar30 = fVar3;
            if (fVar3 <= fVar31) {
                fVar30 = fVar31;
            }
            if (*piVar22 == iVar24) {
                iVar25 = *piVar22 + 1;
                if (iVar24 != 0) {
                    iVar26 = iVar24 + iVar24 / 2;
                }
                if (iVar25 < iVar26) {
                    iVar25 = iVar26;
                }
                func_0x00018011faa0(piVar22, iVar25);
            }
            iVar27 = (int64_t)*piVar22;
            iVar23 = *(int64_t *)(piVar5 + 0x2a);
            *(float *)(iVar23 + iVar27 * 0x10) = fVar2;
            *(float *)(iVar23 + 4 + iVar27 * 0x10) = fVar3;
            *(float *)(iVar23 + 8 + iVar27 * 0x10) = fVar29;
            *(float *)(iVar23 + 0xc + iVar27 * 0x10) = fVar30;
            *piVar22 = *piVar22 + 1;
            piVar5[0x18] = (int32_t)fVar2;
            piVar5[0x19] = (int32_t)fVar3;
            piVar5[0x1a] = (int32_t)fVar29;
            piVar5[0x1b] = (int32_t)fVar30;
            func_0x0001801242c0(piVar5);
            iVar23 = *(int64_t *)(arg1 + 0x418);
            var_d8h._0_4_ = *(float *)(iVar23 + 0x60);
            var_d8h._4_4_ = *(float *)(iVar23 + 100);
            var_d0h = (float)var_d8h + *(float *)(iVar23 + 0x68);
            var_cch = var_d8h._4_4_ + *(float *)(iVar23 + 0x6c);
            iVar23 = *(int64_t *)(arg1 + 0x428);
            var_c8h = *(float *)(iVar23 + 0x60);
            var_c4h = *(float *)(iVar23 + 100);
            var_c0h = var_c8h + *(float *)(iVar23 + 0x68);
            var_bch = var_c4h + *(float *)(iVar23 + 0x6c);
            func_0x000180130c50(piVar5, &var_c8h, &var_d8h, arg2 & 0xffffffff, 0);
            *piVar22 = *piVar22 + -1;
            if (*piVar22 == 0) {
                piVar22 = (int32_t *)(*(int64_t *)(piVar5 + 0xe) + 0x38);
            } else {
                piVar22 = (int32_t *)((int64_t)(*piVar22 + -1) * 0x10 + *(int64_t *)(piVar5 + 0x2a));
            }
            iVar24 = piVar22[1];
            iVar25 = piVar22[2];
            iVar26 = piVar22[3];
            piVar5[0x18] = *piVar22;
            piVar5[0x19] = iVar24;
            piVar5[0x1a] = iVar25;
            piVar5[0x1b] = iVar26;
            func_0x0001801242c0(piVar5);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800fc9f9
// Address: 0x1800fc9f9
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Removing arg arg_418h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.1800fc9e0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    float fVar2;
    float fVar3;
    undefined8 uVar4;
    int32_t *piVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    int32_t *piVar22;
    int64_t iVar23;
    int32_t iVar24;
    int32_t iVar25;
    int32_t iVar26;
    int64_t iVar27;
    int32_t iVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    float var_d0h;
    float var_cch;
    float var_c8h;
    float var_c4h;
    float var_c0h;
    float var_bch;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    if ((arg2 & 0xff000000U) != 0) {
        iVar23 = *(int64_t *)(arg1 + 0x48);
        fVar2 = *(float *)(iVar23 + 8);
        fVar3 = *(float *)(iVar23 + 0xc);
        fVar30 = fVar2 + *(float *)(iVar23 + 0x10);
        fVar31 = fVar3 + *(float *)(iVar23 + 0x14);
        piVar5 = *(int32_t **)(*(int64_t *)(arg1 + 0x428) + 800);
        var_d8h._0_4_ = fVar2;
        var_d8h._4_4_ = fVar3;
        var_d0h = fVar30;
        var_cch = fVar31;
        func_0x000180126c00(piVar5 + 0x22, piVar5);
        if (*piVar5 == 0) {
            func_0x000180124200(piVar5);
        }
        var_18h._0_4_ = fVar30 + 1.0;
        var_20h._0_4_ = fVar2 - 1.0;
        var_18h._4_4_ = fVar31 + 1.0;
        var_20h._4_4_ = fVar3 - 1.0;
        fcn.1801244b0(piVar5, &var_20h, &var_18h, 0);
        func_0x000180126550(piVar5, &var_d8h, &var_d0h, arg2 & 0xffffffff, 0, 0);
        iVar23 = *(int64_t *)(piVar5 + 2);
        iVar26 = 8;
        iVar24 = *piVar5;
        iVar27 = (int64_t)iVar24;
        puVar1 = (undefined4 *)(iVar23 + -0x48 + iVar27 * 0x48);
        uVar6 = *puVar1;
        uVar7 = puVar1[1];
        uVar8 = puVar1[2];
        uVar9 = puVar1[3];
        iVar28 = iVar24 + -1;
        uVar4 = *(undefined8 *)(iVar23 + -8 + iVar27 * 0x48);
        puVar1 = (undefined4 *)(iVar23 + -0x38 + iVar27 * 0x48);
        uVar10 = *puVar1;
        uVar11 = puVar1[1];
        uVar12 = puVar1[2];
        uVar13 = puVar1[3];
        puVar1 = (undefined4 *)(iVar23 + -0x28 + iVar27 * 0x48);
        uVar14 = *puVar1;
        uVar15 = puVar1[1];
        uVar16 = puVar1[2];
        uVar17 = puVar1[3];
        puVar1 = (undefined4 *)(iVar23 + -0x18 + iVar27 * 0x48);
        uVar18 = *puVar1;
        uVar19 = puVar1[1];
        uVar20 = puVar1[2];
        uVar21 = puVar1[3];
        *piVar5 = iVar28;
        iVar25 = piVar5[1];
        if (iVar28 == 0) {
            if (iVar25 == 0) {
                if (iVar24 < 8) {
                    iVar24 = 8;
                }
                func_0x00018011fc10(piVar5, iVar24);
            }
            iVar27 = (int64_t)*piVar5;
            iVar23 = *(int64_t *)(piVar5 + 2);
            puVar1 = (undefined4 *)(iVar23 + iVar27 * 0x48);
            *puVar1 = uVar6;
            puVar1[1] = uVar7;
            puVar1[2] = uVar8;
            puVar1[3] = uVar9;
            puVar1 = (undefined4 *)(iVar23 + 0x10 + iVar27 * 0x48);
            *puVar1 = uVar10;
            puVar1[1] = uVar11;
            puVar1[2] = uVar12;
            puVar1[3] = uVar13;
            puVar1 = (undefined4 *)(iVar23 + 0x20 + iVar27 * 0x48);
            *puVar1 = uVar14;
            puVar1[1] = uVar15;
            puVar1[2] = uVar16;
            puVar1[3] = uVar17;
            puVar1 = (undefined4 *)(iVar23 + 0x30 + iVar27 * 0x48);
            *puVar1 = uVar18;
            puVar1[1] = uVar19;
            puVar1[2] = uVar20;
            puVar1[3] = uVar21;
            *(undefined8 *)(iVar23 + 0x40 + iVar27 * 0x48) = uVar4;
        } else {
            if (iVar28 == iVar25) {
                if (iVar25 == 0) {
                    iVar25 = 8;
                } else {
                    iVar25 = iVar25 / 2 + iVar25;
                }
                if (iVar24 < iVar25) {
                    iVar24 = iVar25;
                }
                func_0x00018011fc10(piVar5, iVar24);
                iVar23 = *(int64_t *)(piVar5 + 2);
            }
            if (0 < (int64_t)*piVar5) {
                func_0x000180498030(iVar23 + 0x48, iVar23, (int64_t)*piVar5 * 0x48);
            }
            puVar1 = *(undefined4 **)(piVar5 + 2);
            *puVar1 = uVar6;
            puVar1[1] = uVar7;
            puVar1[2] = uVar8;
            puVar1[3] = uVar9;
            puVar1[4] = uVar10;
            puVar1[5] = uVar11;
            puVar1[6] = uVar12;
            puVar1[7] = uVar13;
            puVar1[8] = uVar14;
            puVar1[9] = uVar15;
            puVar1[10] = uVar16;
            puVar1[0xb] = uVar17;
            puVar1[0xc] = uVar18;
            puVar1[0xd] = uVar19;
            puVar1[0xe] = uVar20;
            puVar1[0xf] = uVar21;
            *(undefined8 *)(puVar1 + 0x10) = uVar4;
        }
        *piVar5 = *piVar5 + 1;
        func_0x000180124200(piVar5);
        piVar22 = piVar5 + 0x28;
        *piVar22 = *piVar22 + -1;
        if (*piVar22 == 0) {
            piVar22 = (int32_t *)(*(int64_t *)(piVar5 + 0xe) + 0x38);
        } else {
            piVar22 = (int32_t *)((int64_t)(piVar5[0x28] + -1) * 0x10 + *(int64_t *)(piVar5 + 0x2a));
        }
        iVar24 = piVar22[1];
        iVar25 = piVar22[2];
        iVar28 = piVar22[3];
        piVar5[0x18] = *piVar22;
        piVar5[0x19] = iVar24;
        piVar5[0x1a] = iVar25;
        piVar5[0x1b] = iVar28;
        func_0x0001801242c0(piVar5);
        if ((*(uint8_t *)(*(int64_t *)(arg1 + 0x418) + 0x495) & 1) != 0) {
            iVar23 = *(int64_t *)(arg1 + 0x428);
            iVar24 = *(int32_t *)(iVar23 + 0x1f0) + -1;
            if (-1 < iVar24) {
                do {
                    iVar27 = *(int64_t *)(*(int64_t *)(iVar23 + 0x1f8) + (int64_t)iVar24 * 8);
                    if ((*(char *)(iVar27 + 0x109) != '\0') && (*(char *)(iVar27 + 0x111) == '\0')) {
                        iVar23 = func_0x0001800fc9a0(iVar27);
                        break;
                    }
                    iVar24 = iVar24 + -1;
                } while (-1 < iVar24);
            }
            piVar5 = *(int32_t **)(iVar23 + 800);
            func_0x000180126c00(piVar5 + 0x22, piVar5);
            if (*piVar5 == 0) {
                func_0x000180124200(piVar5);
            }
            piVar22 = piVar5 + 0x28;
            iVar24 = piVar5[0x29];
            fVar29 = fVar2;
            if (fVar2 <= fVar30) {
                fVar29 = fVar30;
            }
            fVar30 = fVar3;
            if (fVar3 <= fVar31) {
                fVar30 = fVar31;
            }
            if (*piVar22 == iVar24) {
                iVar25 = *piVar22 + 1;
                if (iVar24 != 0) {
                    iVar26 = iVar24 + iVar24 / 2;
                }
                if (iVar25 < iVar26) {
                    iVar25 = iVar26;
                }
                func_0x00018011faa0(piVar22, iVar25);
            }
            iVar27 = (int64_t)*piVar22;
            iVar23 = *(int64_t *)(piVar5 + 0x2a);
            *(float *)(iVar23 + iVar27 * 0x10) = fVar2;
            *(float *)(iVar23 + 4 + iVar27 * 0x10) = fVar3;
            *(float *)(iVar23 + 8 + iVar27 * 0x10) = fVar29;
            *(float *)(iVar23 + 0xc + iVar27 * 0x10) = fVar30;
            *piVar22 = *piVar22 + 1;
            piVar5[0x18] = (int32_t)fVar2;
            piVar5[0x19] = (int32_t)fVar3;
            piVar5[0x1a] = (int32_t)fVar29;
            piVar5[0x1b] = (int32_t)fVar30;
            func_0x0001801242c0(piVar5);
            iVar23 = *(int64_t *)(arg1 + 0x418);
            var_d8h._0_4_ = *(float *)(iVar23 + 0x60);
            var_d8h._4_4_ = *(float *)(iVar23 + 100);
            var_d0h = (float)var_d8h + *(float *)(iVar23 + 0x68);
            var_cch = var_d8h._4_4_ + *(float *)(iVar23 + 0x6c);
            iVar23 = *(int64_t *)(arg1 + 0x428);
            var_c8h = *(float *)(iVar23 + 0x60);
            var_c4h = *(float *)(iVar23 + 100);
            var_c0h = var_c8h + *(float *)(iVar23 + 0x68);
            var_bch = var_c4h + *(float *)(iVar23 + 0x6c);
            func_0x000180130c50(piVar5, &var_c8h, &var_d8h, arg2 & 0xffffffff, 0);
            *piVar22 = *piVar22 + -1;
            if (*piVar22 == 0) {
                piVar22 = (int32_t *)(*(int64_t *)(piVar5 + 0xe) + 0x38);
            } else {
                piVar22 = (int32_t *)((int64_t)(*piVar22 + -1) * 0x10 + *(int64_t *)(piVar5 + 0x2a));
            }
            iVar24 = piVar22[1];
            iVar25 = piVar22[2];
            iVar26 = piVar22[3];
            piVar5[0x18] = *piVar22;
            piVar5[0x19] = iVar24;
            piVar5[0x1a] = iVar25;
            piVar5[0x1b] = iVar26;
            func_0x0001801242c0(piVar5);
        }
    }
    return;
}

