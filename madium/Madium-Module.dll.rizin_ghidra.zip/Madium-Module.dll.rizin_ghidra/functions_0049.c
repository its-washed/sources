// Chunk 49 - 50 functions

// ============================================================
// Function: FUN_18009b4da
// Address: 0x18009b4da
// Size: 20 bytes
// ============================================================
void fcn.18009b4da(void)
{
    code *pcVar1;
    
    fcn.180088470();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_18009b4ee
// Address: 0x18009b4ee
// Size: 16 bytes
// ============================================================
void fcn.18009b4ee(void)
{
    code *pcVar1;
    
    fcn.180088560();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_18009b500
// Address: 0x18009b500
// Size: 165 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18009b500(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    uint32_t uVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar7;
    if (piVar11 <= piVar7) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar3 = func_0x0001800a8360(arg1);
        if (iVar3 == 0) goto code_r0x00018009b6a7;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar7 = *(int64_t **)(arg1 + 0x28);
        piVar11 = *(int64_t **)(arg1 + 0x40);
        piVar8 = piVar7;
        if (piVar11 <= piVar7) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar8 + 0x18;
    if (iVar1 != 0) {
        uVar10 = *(uint32_t *)(*piVar8 + 0x14);
        piVar8 = piVar7 + 2;
        if (piVar11 <= piVar7 + 2) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) < 1)) {
            uVar4 = 1;
        } else {
            uVar4 = func_0x000180088860(arg1, 2);
            piVar7 = *(int64_t **)(arg1 + 0x28);
            piVar11 = *(int64_t **)(arg1 + 0x40);
            if ((int32_t)uVar4 < 0) {
                uVar4 = uVar4 + 1 + uVar10;
            }
        }
        uVar9 = 0;
        if (-1 < (int32_t)uVar4) {
            uVar9 = uVar4;
        }
        piVar8 = piVar7 + 4;
        if (piVar11 <= piVar7 + 4) {
            piVar8 = *(int64_t **)0x180782430;
        }
        uVar4 = uVar9;
        if ((piVar8 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar8 + 0xc))) {
            uVar4 = func_0x000180088860(arg1, 3);
        }
        if ((int32_t)uVar4 < 0) {
            uVar4 = uVar4 + 1 + uVar10;
        }
        uVar6 = 0;
        if (-1 < (int32_t)uVar4) {
            uVar6 = uVar4;
        }
        if ((int32_t)uVar9 < 1) {
            uVar9 = 1;
        }
        if ((uint64_t)uVar10 < (uint64_t)(int64_t)(int32_t)uVar6) {
            uVar6 = uVar10;
        }
        if ((int32_t)uVar6 < (int32_t)uVar9) {
            uVar5 = 0;
        } else {
            uVar10 = (uVar6 - uVar9) + 1;
            if ((int32_t)(uVar10 + uVar9) <= (int32_t)uVar6) {
                fcn.180088560(arg1, 0x18063e570);
                pcVar2 = (code *)swi(3);
                uVar5 = (*pcVar2)();
                return uVar5;
            }
            iVar3 = func_0x000180085510(arg1, uVar10);
            if (iVar3 == 0) {
                fcn.180088560(arg1, 0x18063da38, 0x18063e570);
                pcVar2 = (code *)swi(3);
                uVar5 = (*pcVar2)();
                return uVar5;
            }
            iVar3 = 0;
            if (0 < (int32_t)uVar10) {
                do {
                    func_0x0001800865e0(arg1, *(undefined *)((int64_t)(int32_t)(iVar3 + uVar9) + -1 + iVar1));
                    iVar3 = iVar3 + 1;
                } while (iVar3 < (int32_t)uVar10);
            }
            uVar5 = (uint64_t)uVar10;
        }
        return uVar5;
    }
code_r0x00018009b6a7:
    fcn.180088470(arg1, 1, 6);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_18009b5a5
// Address: 0x18009b5a5
// Size: 258 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18009b500(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    uint32_t uVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar7;
    if (piVar11 <= piVar7) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar3 = func_0x0001800a8360(arg1);
        if (iVar3 == 0) goto code_r0x00018009b6a7;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar7 = *(int64_t **)(arg1 + 0x28);
        piVar11 = *(int64_t **)(arg1 + 0x40);
        piVar8 = piVar7;
        if (piVar11 <= piVar7) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar8 + 0x18;
    if (iVar1 != 0) {
        uVar10 = *(uint32_t *)(*piVar8 + 0x14);
        piVar8 = piVar7 + 2;
        if (piVar11 <= piVar7 + 2) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) < 1)) {
            uVar4 = 1;
        } else {
            uVar4 = func_0x000180088860(arg1, 2);
            piVar7 = *(int64_t **)(arg1 + 0x28);
            piVar11 = *(int64_t **)(arg1 + 0x40);
            if ((int32_t)uVar4 < 0) {
                uVar4 = uVar4 + 1 + uVar10;
            }
        }
        uVar9 = 0;
        if (-1 < (int32_t)uVar4) {
            uVar9 = uVar4;
        }
        piVar8 = piVar7 + 4;
        if (piVar11 <= piVar7 + 4) {
            piVar8 = *(int64_t **)0x180782430;
        }
        uVar4 = uVar9;
        if ((piVar8 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar8 + 0xc))) {
            uVar4 = func_0x000180088860(arg1, 3);
        }
        if ((int32_t)uVar4 < 0) {
            uVar4 = uVar4 + 1 + uVar10;
        }
        uVar6 = 0;
        if (-1 < (int32_t)uVar4) {
            uVar6 = uVar4;
        }
        if ((int32_t)uVar9 < 1) {
            uVar9 = 1;
        }
        if ((uint64_t)uVar10 < (uint64_t)(int64_t)(int32_t)uVar6) {
            uVar6 = uVar10;
        }
        if ((int32_t)uVar6 < (int32_t)uVar9) {
            uVar5 = 0;
        } else {
            uVar10 = (uVar6 - uVar9) + 1;
            if ((int32_t)(uVar10 + uVar9) <= (int32_t)uVar6) {
                fcn.180088560(arg1, 0x18063e570);
                pcVar2 = (code *)swi(3);
                uVar5 = (*pcVar2)();
                return uVar5;
            }
            iVar3 = func_0x000180085510(arg1, uVar10);
            if (iVar3 == 0) {
                fcn.180088560(arg1, 0x18063da38, 0x18063e570);
                pcVar2 = (code *)swi(3);
                uVar5 = (*pcVar2)();
                return uVar5;
            }
            iVar3 = 0;
            if (0 < (int32_t)uVar10) {
                do {
                    func_0x0001800865e0(arg1, *(undefined *)((int64_t)(int32_t)(iVar3 + uVar9) + -1 + iVar1));
                    iVar3 = iVar3 + 1;
                } while (iVar3 < (int32_t)uVar10);
            }
            uVar5 = (uint64_t)uVar10;
        }
        return uVar5;
    }
code_r0x00018009b6a7:
    fcn.180088470(arg1, 1, 6);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_18009b6a7
// Address: 0x18009b6a7
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18009b500(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    uint32_t uVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar7;
    if (piVar11 <= piVar7) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar3 = func_0x0001800a8360(arg1);
        if (iVar3 == 0) goto code_r0x00018009b6a7;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar7 = *(int64_t **)(arg1 + 0x28);
        piVar11 = *(int64_t **)(arg1 + 0x40);
        piVar8 = piVar7;
        if (piVar11 <= piVar7) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar8 + 0x18;
    if (iVar1 != 0) {
        uVar10 = *(uint32_t *)(*piVar8 + 0x14);
        piVar8 = piVar7 + 2;
        if (piVar11 <= piVar7 + 2) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) < 1)) {
            uVar4 = 1;
        } else {
            uVar4 = func_0x000180088860(arg1, 2);
            piVar7 = *(int64_t **)(arg1 + 0x28);
            piVar11 = *(int64_t **)(arg1 + 0x40);
            if ((int32_t)uVar4 < 0) {
                uVar4 = uVar4 + 1 + uVar10;
            }
        }
        uVar9 = 0;
        if (-1 < (int32_t)uVar4) {
            uVar9 = uVar4;
        }
        piVar8 = piVar7 + 4;
        if (piVar11 <= piVar7 + 4) {
            piVar8 = *(int64_t **)0x180782430;
        }
        uVar4 = uVar9;
        if ((piVar8 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar8 + 0xc))) {
            uVar4 = func_0x000180088860(arg1, 3);
        }
        if ((int32_t)uVar4 < 0) {
            uVar4 = uVar4 + 1 + uVar10;
        }
        uVar6 = 0;
        if (-1 < (int32_t)uVar4) {
            uVar6 = uVar4;
        }
        if ((int32_t)uVar9 < 1) {
            uVar9 = 1;
        }
        if ((uint64_t)uVar10 < (uint64_t)(int64_t)(int32_t)uVar6) {
            uVar6 = uVar10;
        }
        if ((int32_t)uVar6 < (int32_t)uVar9) {
            uVar5 = 0;
        } else {
            uVar10 = (uVar6 - uVar9) + 1;
            if ((int32_t)(uVar10 + uVar9) <= (int32_t)uVar6) {
                fcn.180088560(arg1, 0x18063e570);
                pcVar2 = (code *)swi(3);
                uVar5 = (*pcVar2)();
                return uVar5;
            }
            iVar3 = func_0x000180085510(arg1, uVar10);
            if (iVar3 == 0) {
                fcn.180088560(arg1, 0x18063da38, 0x18063e570);
                pcVar2 = (code *)swi(3);
                uVar5 = (*pcVar2)();
                return uVar5;
            }
            iVar3 = 0;
            if (0 < (int32_t)uVar10) {
                do {
                    func_0x0001800865e0(arg1, *(undefined *)((int64_t)(int32_t)(iVar3 + uVar9) + -1 + iVar1));
                    iVar3 = iVar3 + 1;
                } while (iVar3 < (int32_t)uVar10);
            }
            uVar5 = (uint64_t)uVar10;
        }
        return uVar5;
    }
code_r0x00018009b6a7:
    fcn.180088470(arg1, 1, 6);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_18009b6bb
// Address: 0x18009b6bb
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18009b500(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    uint32_t uVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar7;
    if (piVar11 <= piVar7) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar3 = func_0x0001800a8360(arg1);
        if (iVar3 == 0) goto code_r0x00018009b6a7;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar7 = *(int64_t **)(arg1 + 0x28);
        piVar11 = *(int64_t **)(arg1 + 0x40);
        piVar8 = piVar7;
        if (piVar11 <= piVar7) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar8 + 0x18;
    if (iVar1 != 0) {
        uVar10 = *(uint32_t *)(*piVar8 + 0x14);
        piVar8 = piVar7 + 2;
        if (piVar11 <= piVar7 + 2) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) < 1)) {
            uVar4 = 1;
        } else {
            uVar4 = func_0x000180088860(arg1, 2);
            piVar7 = *(int64_t **)(arg1 + 0x28);
            piVar11 = *(int64_t **)(arg1 + 0x40);
            if ((int32_t)uVar4 < 0) {
                uVar4 = uVar4 + 1 + uVar10;
            }
        }
        uVar9 = 0;
        if (-1 < (int32_t)uVar4) {
            uVar9 = uVar4;
        }
        piVar8 = piVar7 + 4;
        if (piVar11 <= piVar7 + 4) {
            piVar8 = *(int64_t **)0x180782430;
        }
        uVar4 = uVar9;
        if ((piVar8 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar8 + 0xc))) {
            uVar4 = func_0x000180088860(arg1, 3);
        }
        if ((int32_t)uVar4 < 0) {
            uVar4 = uVar4 + 1 + uVar10;
        }
        uVar6 = 0;
        if (-1 < (int32_t)uVar4) {
            uVar6 = uVar4;
        }
        if ((int32_t)uVar9 < 1) {
            uVar9 = 1;
        }
        if ((uint64_t)uVar10 < (uint64_t)(int64_t)(int32_t)uVar6) {
            uVar6 = uVar10;
        }
        if ((int32_t)uVar6 < (int32_t)uVar9) {
            uVar5 = 0;
        } else {
            uVar10 = (uVar6 - uVar9) + 1;
            if ((int32_t)(uVar10 + uVar9) <= (int32_t)uVar6) {
                fcn.180088560(arg1, 0x18063e570);
                pcVar2 = (code *)swi(3);
                uVar5 = (*pcVar2)();
                return uVar5;
            }
            iVar3 = func_0x000180085510(arg1, uVar10);
            if (iVar3 == 0) {
                fcn.180088560(arg1, 0x18063da38, 0x18063e570);
                pcVar2 = (code *)swi(3);
                uVar5 = (*pcVar2)();
                return uVar5;
            }
            iVar3 = 0;
            if (0 < (int32_t)uVar10) {
                do {
                    func_0x0001800865e0(arg1, *(undefined *)((int64_t)(int32_t)(iVar3 + uVar9) + -1 + iVar1));
                    iVar3 = iVar3 + 1;
                } while (iVar3 < (int32_t)uVar10);
            }
            uVar5 = (uint64_t)uVar10;
        }
        return uVar5;
    }
code_r0x00018009b6a7:
    fcn.180088470(arg1, 1, 6);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_18009b6e0
// Address: 0x18009b6e0
// Size: 389 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18009b6e0(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    uint64_t uVar10;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_268 [32];
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_268;
    var_248h = (int64_t)&var_228h;
    var_240h = (int64_t)&var_28h;
    iVar9 = (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4);
    uVar10 = (uint64_t)iVar9;
    var_230h = 0;
    var_238h = arg1;
    if (uVar10 < 0x201) {
        piVar6 = &var_228h;
    } else {
        piVar6 = (int64_t *)func_0x0001800890e0(&var_248h, uVar10 - 0x200, 0xffffffff);
    }
    iVar8 = 1;
    if (0 < iVar9) {
        do {
            uVar5 = func_0x000180088860(arg1, iVar8);
            if ((uVar5 & 0xff) != uVar5) {
                func_0x000180088380(arg1, iVar8, 0x18063e560);
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            *(char *)piVar6 = (char)uVar5;
            iVar8 = iVar8 + 1;
            piVar6 = (int64_t *)((int64_t)piVar6 + 1);
        } while (iVar8 <= iVar9);
    }
    iVar4 = var_230h;
    iVar3 = var_238h;
    var_248h = var_248h + uVar10;
    if (var_230h == 0) {
        func_0x0001800867f0(var_238h, &var_228h, (var_248h - (int64_t)&var_248h) + -0x20);
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_238h, 1);
        }
        iVar1 = *(int64_t *)(iVar3 + 0x40);
        if (var_248h == var_240h) {
            uVar7 = func_0x00018009a7e0(iVar3, iVar4);
            *(undefined8 *)(iVar1 + -0x10) = uVar7;
            *(undefined4 *)(iVar1 + -4) = 6;
        } else {
            uVar7 = func_0x00018009a8e0(iVar3, iVar4 + 0x18, (var_248h - iVar4) + -0x18);
            *(undefined8 *)(iVar1 + -0x10) = uVar7;
            *(undefined4 *)(iVar1 + -4) = 6;
        }
    }
    func_0x000180459870(var_28h ^ (uint64_t)auStack_268);
    return;
}

// ============================================================
// Function: FUN_18009b870
// Address: 0x18009b870
// Size: 140 bytes
// ============================================================
char * fcn.18009b870(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    char *pcVar2;
    char *pcVar3;
    
    pcVar3 = (char *)(arg2 + 1);
    if (*(char *)arg2 == '%') {
        if (pcVar3 == *(char **)(arg1 + 0x18)) {
            fcn.180088560(*(undefined8 *)(arg1 + 0x20), 0x18063e5c8);
            pcVar1 = (code *)swi(3);
            pcVar3 = (char *)(*pcVar1)();
            return pcVar3;
        }
        pcVar3 = (char *)(arg2 + 2);
    } else if (*(char *)arg2 == '[') {
        if (*pcVar3 != '^') {
            pcVar3 = (char *)arg2;
        }
        pcVar3 = pcVar3 + 1;
        do {
            if (pcVar3 == *(char **)(arg1 + 0x18)) {
                fcn.180088560(*(undefined8 *)(arg1 + 0x20), 0x18063e5a8);
                pcVar1 = (code *)swi(3);
                pcVar3 = (char *)(*pcVar1)();
                return pcVar3;
            }
            pcVar2 = pcVar3 + 1;
            if (*pcVar3 == '%') {
                if (*(char **)(arg1 + 0x18) <= pcVar2) {
                    pcVar2 = pcVar3;
                }
                pcVar2 = pcVar2 + 1;
            }
            pcVar3 = pcVar2;
        } while (*pcVar2 != ']');
        return pcVar2 + 1;
    }
    return pcVar3;
}

// ============================================================
// Function: FUN_18009b900
// Address: 0x18009b900
// Size: 328 bytes
// ============================================================
uint32_t fcn.18009b900(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint64_t uVar4;
    
    uVar4 = arg1 & 0xffffffff;
    uVar1 = func_0x000180460320(arg2 & 0xffffffff);
    // switch table (26 cases) at 0x18009b9e0
    switch(uVar1) {
    case 0x61:
        uVar2 = func_0x00018046c960(uVar4);
        break;
    default:
        return (uint32_t)((int32_t)arg2 == (int32_t)arg1);
    case 99:
        uVar2 = func_0x00018046cad0(uVar4);
        break;
    case 100:
        uVar2 = func_0x00018046cb80(uVar4);
        break;
    case 0x67:
        uVar2 = func_0x00018046cc30(uVar4);
        break;
    case 0x6c:
        uVar2 = func_0x00018046cce0(uVar4);
        break;
    case 0x70:
        uVar2 = func_0x00018046cd90(uVar4);
        break;
    case 0x73:
        uVar2 = func_0x00018046ce40(uVar4);
        break;
    case 0x75:
        uVar2 = func_0x00018046cef0(uVar4);
        break;
    case 0x77:
        uVar2 = func_0x00018046c8b0(uVar4);
        break;
    case 0x78:
        uVar2 = func_0x00018046cfa0(uVar4);
        break;
    case 0x7a:
        uVar2 = (uint32_t)((int32_t)arg1 == 0);
    }
    iVar3 = func_0x00018046cce0(arg2 & 0xffffffff);
    if (iVar3 == 0) {
        uVar2 = (uint32_t)(uVar2 == 0);
    }
    return uVar2;
}

// ============================================================
// Function: FUN_18009ba50
// Address: 0x18009ba50
// Size: 444 bytes
// ============================================================
bool fcn.18009ba50(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t uVar1;
    uint8_t *puVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    uint8_t *puVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    bool bVar8;
    
    bVar8 = *(uint8_t *)(arg2 + 1U) != 0x5e;
    uVar7 = arg1 & 0xffffffff;
    puVar5 = (uint8_t *)(arg2 + 1U);
    if (bVar8) {
        puVar5 = (uint8_t *)arg2;
    }
    do {
        while( true ) {
            puVar2 = puVar5 + 1;
            if ((uint64_t)arg3 <= puVar2) {
                return !bVar8;
            }
            uVar1 = *puVar2;
            puVar5 = puVar2 + 1;
            uVar4 = (uint32_t)arg1;
            if (uVar1 == 0x25) break;
            if ((*puVar5 == 0x2d) && (puVar5 = puVar2 + 2, puVar5 < (uint64_t)arg3)) {
                if (((int32_t)(uint32_t)uVar1 <= (int32_t)uVar4) && ((int32_t)uVar4 <= (int32_t)(uint32_t)*puVar5)) {
                    return bVar8;
                }
            } else {
                puVar5 = puVar2;
                if (uVar1 == uVar4) {
                    return bVar8;
                }
            }
        }
        uVar1 = *puVar5;
        uVar3 = func_0x000180460320(uVar1);
    // switch table (26 cases) at 0x18009bba4
        switch(uVar3) {
        case 0x61:
            uVar4 = func_0x00018046c960(uVar7);
            break;
        default:
            uVar4 = (uint32_t)(uVar1 == uVar4);
            goto code_r0x00018009bb55;
        case 99:
            uVar4 = func_0x00018046cad0(uVar7);
            break;
        case 100:
            uVar4 = func_0x00018046cb80(uVar7);
            break;
        case 0x67:
            uVar4 = func_0x00018046cc30(uVar7);
            break;
        case 0x6c:
            uVar4 = func_0x00018046cce0(uVar7);
            break;
        case 0x70:
            uVar4 = func_0x00018046cd90(uVar7);
            break;
        case 0x73:
            uVar4 = func_0x00018046ce40(uVar7);
            break;
        case 0x75:
            uVar4 = func_0x00018046cef0(uVar7);
            break;
        case 0x77:
            uVar4 = func_0x00018046c8b0(uVar7);
            break;
        case 0x78:
            uVar4 = func_0x00018046cfa0(uVar7);
            break;
        case 0x7a:
            uVar4 = (uint32_t)(uVar4 == 0);
        }
        uVar6 = func_0x00018046cce0(uVar1);
        if ((int32_t)uVar6 == 0) {
            uVar4 = (uint32_t)CONCAT71((unkint7)((uint64_t)uVar6 >> 8), uVar4 == 0);
        }
code_r0x00018009bb55:
        if (uVar4 != 0) {
            return bVar8;
        }
    } while( true );
}

// ============================================================
// Function: FUN_18009bc10
// Address: 0x18009bc10
// Size: 90 bytes
// ============================================================
void fcn.18009bc10(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    int32_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    
    iVar1 = *(int32_t *)(arg1 + 0x28);
    if (iVar1 < 0x20) {
        *(int64_t *)(arg1 + ((int64_t)iVar1 + 3) * 0x10) = arg2;
        *(int64_t *)(arg1 + 0x38 + (int64_t)iVar1 * 0x10) = (int64_t)(int32_t)arg4;
        *(int32_t *)(arg1 + 0x28) = iVar1 + 1;
        iVar3 = fcn.18009bc70(arg1);
        if (iVar3 == 0) {
            *(int32_t *)(arg1 + 0x28) = *(int32_t *)(arg1 + 0x28) + -1;
        }
        return;
    }
    fcn.180088560(*(undefined8 *)(arg1 + 0x20), 0x18063e668);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_18009bc70
// Address: 0x18009bc70
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

uint8_t * fcn.18009bc70(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t **ppuVar1;
    uint8_t uVar2;
    code *pcVar3;
    uint8_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    uint8_t *arg3_00;
    uint8_t *puVar7;
    uint8_t *puVar8;
    int32_t iVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    int64_t var_28h;
    
    iVar5 = *(int32_t *)arg1;
    iVar11 = *(int64_t *)(arg1 + 0x20);
    *(int32_t *)arg1 = iVar5 + -1;
    if (iVar5 == 0) {
        fcn.180088560(iVar11, 0x18063e650);
        pcVar3 = (code *)swi(3);
        puVar8 = (uint8_t *)(*pcVar3)();
        return puVar8;
    }
    pcVar3 = *(code **)(*(int64_t *)(iVar11 + 0x20) + 0x520);
    if (pcVar3 != (code *)0x0) {
        *(int16_t *)(iVar11 + 0x68) = *(int16_t *)(iVar11 + 0x68) + 1;
        (*pcVar3)(iVar11, 0xffffffff);
        *(int16_t *)(iVar11 + 0x68) = *(int16_t *)(iVar11 + 0x68) + -1;
    }
    puVar8 = *(uint8_t **)(arg1 + 0x18);
    puVar7 = (uint8_t *)arg2;
    if ((uint8_t *)arg3 != puVar8) {
code_r0x00018009bd00:
        uVar4 = *(uint8_t *)arg3;
        if (uVar4 == 0x24) {
            if ((uint8_t *)(arg3 + 1) == puVar8) {
                puVar7 = (uint8_t *)0x0;
                if ((uint8_t *)arg2 == *(uint8_t **)(arg1 + 0x10)) {
                    puVar7 = (uint8_t *)arg2;
                }
                goto code_r0x00018009c15c;
            }
code_r0x00018009bed0:
            puVar8 = (uint8_t *)(arg3 + 1);
            arg3_00 = (uint8_t *)fcn.18009b870(arg1, arg3);
            ppuVar1 = (uint8_t **)(arg1 + 0x10);
            if ((uint64_t)arg2 < *ppuVar1) {
                uVar4 = *(uint8_t *)arg3;
                uVar2 = *(uint8_t *)arg2;
                if (uVar4 == 0x25) {
                    uVar6 = fcn.18009b900((uint64_t)uVar2, (uint64_t)*puVar8);
code_r0x00018009bf58:
                    uVar4 = *arg3_00;
                    if (uVar6 == 0) goto code_r0x00018009bf60;
                } else {
                    if (uVar4 != 0x2e) {
                        if (uVar4 == 0x5b) {
                            uVar6 = fcn.18009ba50((uint64_t)uVar2, arg3, (int64_t)(arg3_00 + -1));
                        } else {
                            uVar6 = (uint32_t)(uVar4 == uVar2);
                        }
                        goto code_r0x00018009bf58;
                    }
                    uVar4 = *arg3_00;
                }
                if (uVar4 != 0x2a) {
                    if (uVar4 != 0x2b) {
                        if (uVar4 == 0x2d) {
                            puVar7 = (uint8_t *)fcn.18009bc70(arg1, arg2, (int64_t)(arg3_00 + 1));
                            goto joined_r0x00018009c05d;
                        }
                        if (uVar4 != 0x3f) {
                            arg2 = (int64_t)(arg2 + 1);
                            goto code_r0x00018009bf98;
                        }
                        arg3_00 = arg3_00 + 1;
                        puVar7 = (uint8_t *)fcn.18009bc70(arg1, (int64_t)(arg2 + 1), (int64_t)arg3_00);
                        if (puVar7 != (uint8_t *)0x0) goto code_r0x00018009c15c;
                        goto code_r0x00018009bf98;
                    }
                    arg2 = arg2 + 1;
                }
                iVar11 = 0;
                goto code_r0x00018009c0d5;
            }
            uVar4 = *arg3_00;
code_r0x00018009bf60:
            if ((0x3f < uVar4) || ((0x8000240000000000U >> ((int64_t)(char)uVar4 & 0x3fU) & 1) == 0))
            goto code_r0x00018009c14b;
            arg3_00 = arg3_00 + 1;
        } else {
            if (uVar4 != 0x25) {
                if (uVar4 != 0x28) {
                    if (uVar4 != 0x29) goto code_r0x00018009bed0;
                    uVar6 = *(int32_t *)(arg1 + 0x28) - 1;
                    if (-1 < (int32_t)uVar6) goto code_r0x00018009bfc0;
                    goto code_r0x00018009c190;
                }
                puVar7 = (uint8_t *)
                         fcn.18009bc10(arg1, arg2, (uint8_t *)(arg3 + (uint64_t)(*(uint8_t *)(arg3 + 1) == 0x29) + 1), 
                                       (uint64_t)((*(uint8_t *)(arg3 + 1) != 0x29) - 2));
                goto code_r0x00018009c15c;
            }
            uVar4 = *(uint8_t *)(arg3 + 1);
    // switch table (4 cases) at 0x18009c1d8
            switch(uVar4) {
            case 0x30:
            case 0x31:
            case 0x32:
            case 0x33:
            case 0x34:
            case 0x35:
            case 0x36:
            case 0x37:
            case 0x38:
            case 0x39:
                iVar5 = uVar4 - 0x31;
                if (((iVar5 < 0) || (*(int32_t *)(arg1 + 0x28) <= iVar5)) ||
                   (uVar10 = *(uint64_t *)(arg1 + 0x38 + ((uint64_t)uVar4 - 0x31) * 0x10), uVar10 == 0xffffffffffffffff)
                   ) {
                    fcn.180088560(*(undefined8 *)(arg1 + 0x20), 0x18063e608, uVar4 - 0x30);
                    pcVar3 = (code *)swi(3);
                    puVar8 = (uint8_t *)(*pcVar3)();
                    return puVar8;
                }
                if (((uint64_t)(*(int64_t *)(arg1 + 0x10) - arg2) < uVar10) ||
                   (iVar5 = func_0x000180497f30(*(undefined8 *)(arg1 + ((uint64_t)uVar4 - 0x2e) * 0x10), arg2, uVar10),
                   iVar5 != 0)) goto code_r0x00018009c14b;
                puVar7 = (uint8_t *)(arg2 + uVar10);
                if (puVar7 != (uint8_t *)0x0) {
                    arg3_00 = (uint8_t *)(arg3 + 2);
                    arg2 = (int64_t)puVar7;
                    break;
                }
                goto code_r0x00018009c15c;
            default:
                goto code_r0x00018009bed0;
            case 0x62:
                if (puVar8 + -1 <= (uint8_t *)(arg3 + 2)) {
                    fcn.180088560(*(undefined8 *)(arg1 + 0x20), 0x18063e680);
                    pcVar3 = (code *)swi(3);
                    puVar8 = (uint8_t *)(*pcVar3)();
                    return puVar8;
                }
                uVar4 = *(uint8_t *)(arg3 + 2);
                if (*(uint8_t *)arg2 == uVar4) {
                    puVar7 = (uint8_t *)(arg2 + 1);
                    iVar5 = 1;
                    if (puVar7 < *(uint8_t **)(arg1 + 0x10)) {
                        do {
                            if (*puVar7 == *(uint8_t *)(arg3 + 3)) {
                                iVar9 = iVar5 + -1;
                                if (iVar5 + -1 == 0) goto code_r0x00018009bdad;
                            } else {
                                iVar9 = iVar5 + 1;
                                if (*puVar7 != uVar4) {
                                    iVar9 = iVar5;
                                }
                            }
                            puVar7 = puVar7 + 1;
                            iVar5 = iVar9;
                            if (*(uint8_t **)(arg1 + 0x10) <= puVar7) {
                                puVar7 = (uint8_t *)0x0;
                                goto code_r0x00018009c15c;
                            }
                        } while( true );
                    }
                }
                goto code_r0x00018009c14b;
            case 0x66:
                puVar8 = (uint8_t *)(arg3 + 2);
                if (*(uint8_t *)(arg3 + 2) != 0x5b) {
                    fcn.180088560(*(undefined8 *)(arg1 + 0x20), 0x18063e628);
                    pcVar3 = (code *)swi(3);
                    puVar8 = (uint8_t *)(*pcVar3)();
                    return puVar8;
                }
                arg3_00 = (uint8_t *)fcn.18009b870(arg1, (int64_t)puVar8);
                if ((uint8_t *)arg2 == *(uint8_t **)(arg1 + 8)) {
                    uVar4 = 0;
                } else {
                    uVar4 = *(uint8_t *)(arg2 + -1);
                }
                iVar5 = fcn.18009ba50((uint64_t)uVar4, (int64_t)puVar8, (int64_t)(arg3_00 + -1));
                if ((iVar5 != 0) ||
                   (iVar5 = fcn.18009ba50((uint64_t)*(uint8_t *)arg2, (int64_t)puVar8, (int64_t)(arg3_00 + -1)),
                   iVar5 == 0)) goto code_r0x00018009c14b;
            }
        }
        goto code_r0x00018009bf98;
    }
code_r0x00018009c15c:
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return puVar7;
code_r0x00018009bfc0:
    uVar10 = (uint64_t)uVar6;
    if (*(int64_t *)(arg1 + 0x38 + uVar10 * 0x10) == -1) {
        *(int64_t *)(arg1 + 0x38 + uVar10 * 0x10) = arg2 - *(int64_t *)((uVar10 + 3) * 0x10 + arg1);
        puVar7 = (uint8_t *)fcn.18009bc70(arg1, arg2, (int64_t)(arg3 + 1));
        if (puVar7 == (uint8_t *)0x0) {
            *(undefined8 *)(arg1 + 0x38 + uVar10 * 0x10) = 0xffffffffffffffff;
        }
        goto code_r0x00018009c15c;
    }
    uVar6 = uVar6 - 1;
    if ((int32_t)uVar6 < 0) {
code_r0x00018009c190:
        fcn.180088560(*(undefined8 *)(arg1 + 0x20), 0x18063e5f0);
        pcVar3 = (code *)swi(3);
        puVar8 = (uint8_t *)(*pcVar3)();
        return puVar8;
    }
    goto code_r0x00018009bfc0;
code_r0x00018009bdad:
    puVar7 = puVar7 + 1;
    if (puVar7 == (uint8_t *)0x0) goto code_r0x00018009c15c;
    arg3_00 = (uint8_t *)(arg3 + 4);
    arg2 = (int64_t)puVar7;
code_r0x00018009bf98:
    puVar7 = (uint8_t *)arg2;
    puVar8 = *(uint8_t **)(arg1 + 0x18);
    arg2 = (int64_t)puVar7;
    arg3 = (int64_t)arg3_00;
    if (arg3_00 == puVar8) goto code_r0x00018009c15c;
    goto code_r0x00018009bd00;
joined_r0x00018009c05d:
    if (puVar7 != (uint8_t *)0x0) goto code_r0x00018009c15c;
    if (*ppuVar1 <= (uint64_t)arg2) goto code_r0x00018009c14b;
    uVar4 = *(uint8_t *)arg3;
    uVar2 = *(uint8_t *)arg2;
    if (uVar4 == 0x25) {
        uVar6 = fcn.18009b900((uint64_t)uVar2, (uint64_t)*puVar8);
code_r0x00018009c0a9:
        if (uVar6 == 0) goto code_r0x00018009c14b;
    } else if (uVar4 != 0x2e) {
        if (uVar4 == 0x5b) {
            uVar6 = fcn.18009ba50((uint64_t)uVar2, arg3, (int64_t)(arg3_00 + -1));
        } else {
            uVar6 = (uint32_t)(uVar4 == uVar2);
        }
        goto code_r0x00018009c0a9;
    }
    arg2 = arg2 + 1;
    puVar7 = (uint8_t *)fcn.18009bc70(arg1, arg2, (int64_t)(arg3_00 + 1));
    goto joined_r0x00018009c05d;
code_r0x00018009c0d5:
    if (*ppuVar1 <= (uint8_t *)(arg2 + iVar11)) goto joined_r0x00018009c127;
    uVar4 = *(uint8_t *)(arg2 + iVar11);
    uVar2 = *(uint8_t *)arg3;
    if (uVar2 == 0x25) {
        uVar6 = fcn.18009b900((uint64_t)uVar4, (uint64_t)*puVar8);
code_r0x00018009c11b:
        if (uVar6 == 0) goto joined_r0x00018009c127;
    } else if (uVar2 != 0x2e) {
        if (uVar2 == 0x5b) {
            uVar6 = fcn.18009ba50((uint64_t)uVar4, arg3, (int64_t)(arg3_00 + -1));
        } else {
            uVar6 = (uint32_t)(uVar2 == uVar4);
        }
        goto code_r0x00018009c11b;
    }
    iVar11 = iVar11 + 1;
    goto code_r0x00018009c0d5;
joined_r0x00018009c127:
    if (iVar11 < 0) goto code_r0x00018009c14b;
    puVar7 = (uint8_t *)fcn.18009bc70(arg1, (int64_t)(arg2 + iVar11), (int64_t)(arg3_00 + 1));
    if (puVar7 != (uint8_t *)0x0) goto code_r0x00018009c15c;
    iVar11 = iVar11 + -1;
    goto joined_r0x00018009c127;
code_r0x00018009c14b:
    puVar7 = (uint8_t *)0x0;
    goto code_r0x00018009c15c;
}

// ============================================================
// Function: FUN_18009bcc5
// Address: 0x18009bcc5
// Size: 1211 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

uint8_t * fcn.18009bc70(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t **ppuVar1;
    uint8_t uVar2;
    code *pcVar3;
    uint8_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    uint8_t *arg3_00;
    uint8_t *puVar7;
    uint8_t *puVar8;
    int32_t iVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    int64_t var_28h;
    
    iVar5 = *(int32_t *)arg1;
    iVar11 = *(int64_t *)(arg1 + 0x20);
    *(int32_t *)arg1 = iVar5 + -1;
    if (iVar5 == 0) {
        fcn.180088560(iVar11, 0x18063e650);
        pcVar3 = (code *)swi(3);
        puVar8 = (uint8_t *)(*pcVar3)();
        return puVar8;
    }
    pcVar3 = *(code **)(*(int64_t *)(iVar11 + 0x20) + 0x520);
    if (pcVar3 != (code *)0x0) {
        *(int16_t *)(iVar11 + 0x68) = *(int16_t *)(iVar11 + 0x68) + 1;
        (*pcVar3)(iVar11, 0xffffffff);
        *(int16_t *)(iVar11 + 0x68) = *(int16_t *)(iVar11 + 0x68) + -1;
    }
    puVar8 = *(uint8_t **)(arg1 + 0x18);
    puVar7 = (uint8_t *)arg2;
    if ((uint8_t *)arg3 != puVar8) {
code_r0x00018009bd00:
        uVar4 = *(uint8_t *)arg3;
        if (uVar4 == 0x24) {
            if ((uint8_t *)(arg3 + 1) == puVar8) {
                puVar7 = (uint8_t *)0x0;
                if ((uint8_t *)arg2 == *(uint8_t **)(arg1 + 0x10)) {
                    puVar7 = (uint8_t *)arg2;
                }
                goto code_r0x00018009c15c;
            }
code_r0x00018009bed0:
            puVar8 = (uint8_t *)(arg3 + 1);
            arg3_00 = (uint8_t *)fcn.18009b870(arg1, arg3);
            ppuVar1 = (uint8_t **)(arg1 + 0x10);
            if ((uint64_t)arg2 < *ppuVar1) {
                uVar4 = *(uint8_t *)arg3;
                uVar2 = *(uint8_t *)arg2;
                if (uVar4 == 0x25) {
                    uVar6 = fcn.18009b900((uint64_t)uVar2, (uint64_t)*puVar8);
code_r0x00018009bf58:
                    uVar4 = *arg3_00;
                    if (uVar6 == 0) goto code_r0x00018009bf60;
                } else {
                    if (uVar4 != 0x2e) {
                        if (uVar4 == 0x5b) {
                            uVar6 = fcn.18009ba50((uint64_t)uVar2, arg3, (int64_t)(arg3_00 + -1));
                        } else {
                            uVar6 = (uint32_t)(uVar4 == uVar2);
                        }
                        goto code_r0x00018009bf58;
                    }
                    uVar4 = *arg3_00;
                }
                if (uVar4 != 0x2a) {
                    if (uVar4 != 0x2b) {
                        if (uVar4 == 0x2d) {
                            puVar7 = (uint8_t *)fcn.18009bc70(arg1, arg2, (int64_t)(arg3_00 + 1));
                            goto joined_r0x00018009c05d;
                        }
                        if (uVar4 != 0x3f) {
                            arg2 = (int64_t)(arg2 + 1);
                            goto code_r0x00018009bf98;
                        }
                        arg3_00 = arg3_00 + 1;
                        puVar7 = (uint8_t *)fcn.18009bc70(arg1, (int64_t)(arg2 + 1), (int64_t)arg3_00);
                        if (puVar7 != (uint8_t *)0x0) goto code_r0x00018009c15c;
                        goto code_r0x00018009bf98;
                    }
                    arg2 = arg2 + 1;
                }
                iVar11 = 0;
                goto code_r0x00018009c0d5;
            }
            uVar4 = *arg3_00;
code_r0x00018009bf60:
            if ((0x3f < uVar4) || ((0x8000240000000000U >> ((int64_t)(char)uVar4 & 0x3fU) & 1) == 0))
            goto code_r0x00018009c14b;
            arg3_00 = arg3_00 + 1;
        } else {
            if (uVar4 != 0x25) {
                if (uVar4 != 0x28) {
                    if (uVar4 != 0x29) goto code_r0x00018009bed0;
                    uVar6 = *(int32_t *)(arg1 + 0x28) - 1;
                    if (-1 < (int32_t)uVar6) goto code_r0x00018009bfc0;
                    goto code_r0x00018009c190;
                }
                puVar7 = (uint8_t *)
                         fcn.18009bc10(arg1, arg2, (uint8_t *)(arg3 + (uint64_t)(*(uint8_t *)(arg3 + 1) == 0x29) + 1), 
                                       (uint64_t)((*(uint8_t *)(arg3 + 1) != 0x29) - 2));
                goto code_r0x00018009c15c;
            }
            uVar4 = *(uint8_t *)(arg3 + 1);
    // switch table (4 cases) at 0x18009c1d8
            switch(uVar4) {
            case 0x30:
            case 0x31:
            case 0x32:
            case 0x33:
            case 0x34:
            case 0x35:
            case 0x36:
            case 0x37:
            case 0x38:
            case 0x39:
                iVar5 = uVar4 - 0x31;
                if (((iVar5 < 0) || (*(int32_t *)(arg1 + 0x28) <= iVar5)) ||
                   (uVar10 = *(uint64_t *)(arg1 + 0x38 + ((uint64_t)uVar4 - 0x31) * 0x10), uVar10 == 0xffffffffffffffff)
                   ) {
                    fcn.180088560(*(undefined8 *)(arg1 + 0x20), 0x18063e608, uVar4 - 0x30);
                    pcVar3 = (code *)swi(3);
                    puVar8 = (uint8_t *)(*pcVar3)();
                    return puVar8;
                }
                if (((uint64_t)(*(int64_t *)(arg1 + 0x10) - arg2) < uVar10) ||
                   (iVar5 = func_0x000180497f30(*(undefined8 *)(arg1 + ((uint64_t)uVar4 - 0x2e) * 0x10), arg2, uVar10),
                   iVar5 != 0)) goto code_r0x00018009c14b;
                puVar7 = (uint8_t *)(arg2 + uVar10);
                if (puVar7 != (uint8_t *)0x0) {
                    arg3_00 = (uint8_t *)(arg3 + 2);
                    arg2 = (int64_t)puVar7;
                    break;
                }
                goto code_r0x00018009c15c;
            default:
                goto code_r0x00018009bed0;
            case 0x62:
                if (puVar8 + -1 <= (uint8_t *)(arg3 + 2)) {
                    fcn.180088560(*(undefined8 *)(arg1 + 0x20), 0x18063e680);
                    pcVar3 = (code *)swi(3);
                    puVar8 = (uint8_t *)(*pcVar3)();
                    return puVar8;
                }
                uVar4 = *(uint8_t *)(arg3 + 2);
                if (*(uint8_t *)arg2 == uVar4) {
                    puVar7 = (uint8_t *)(arg2 + 1);
                    iVar5 = 1;
                    if (puVar7 < *(uint8_t **)(arg1 + 0x10)) {
                        do {
                            if (*puVar7 == *(uint8_t *)(arg3 + 3)) {
                                iVar9 = iVar5 + -1;
                                if (iVar5 + -1 == 0) goto code_r0x00018009bdad;
                            } else {
                                iVar9 = iVar5 + 1;
                                if (*puVar7 != uVar4) {
                                    iVar9 = iVar5;
                                }
                            }
                            puVar7 = puVar7 + 1;
                            iVar5 = iVar9;
                            if (*(uint8_t **)(arg1 + 0x10) <= puVar7) {
                                puVar7 = (uint8_t *)0x0;
                                goto code_r0x00018009c15c;
                            }
                        } while( true );
                    }
                }
                goto code_r0x00018009c14b;
            case 0x66:
                puVar8 = (uint8_t *)(arg3 + 2);
                if (*(uint8_t *)(arg3 + 2) != 0x5b) {
                    fcn.180088560(*(undefined8 *)(arg1 + 0x20), 0x18063e628);
                    pcVar3 = (code *)swi(3);
                    puVar8 = (uint8_t *)(*pcVar3)();
                    return puVar8;
                }
                arg3_00 = (uint8_t *)fcn.18009b870(arg1, (int64_t)puVar8);
                if ((uint8_t *)arg2 == *(uint8_t **)(arg1 + 8)) {
                    uVar4 = 0;
                } else {
                    uVar4 = *(uint8_t *)(arg2 + -1);
                }
                iVar5 = fcn.18009ba50((uint64_t)uVar4, (int64_t)puVar8, (int64_t)(arg3_00 + -1));
                if ((iVar5 != 0) ||
                   (iVar5 = fcn.18009ba50((uint64_t)*(uint8_t *)arg2, (int64_t)puVar8, (int64_t)(arg3_00 + -1)),
                   iVar5 == 0)) goto code_r0x00018009c14b;
            }
        }
        goto code_r0x00018009bf98;
    }
code_r0x00018009c15c:
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return puVar7;
code_r0x00018009bfc0:
    uVar10 = (uint64_t)uVar6;
    if (*(int64_t *)(arg1 + 0x38 + uVar10 * 0x10) == -1) {
        *(int64_t *)(arg1 + 0x38 + uVar10 * 0x10) = arg2 - *(int64_t *)((uVar10 + 3) * 0x10 + arg1);
        puVar7 = (uint8_t *)fcn.18009bc70(arg1, arg2, (int64_t)(arg3 + 1));
        if (puVar7 == (uint8_t *)0x0) {
            *(undefined8 *)(arg1 + 0x38 + uVar10 * 0x10) = 0xffffffffffffffff;
        }
        goto code_r0x00018009c15c;
    }
    uVar6 = uVar6 - 1;
    if ((int32_t)uVar6 < 0) {
code_r0x00018009c190:
        fcn.180088560(*(undefined8 *)(arg1 + 0x20), 0x18063e5f0);
        pcVar3 = (code *)swi(3);
        puVar8 = (uint8_t *)(*pcVar3)();
        return puVar8;
    }
    goto code_r0x00018009bfc0;
code_r0x00018009bdad:
    puVar7 = puVar7 + 1;
    if (puVar7 == (uint8_t *)0x0) goto code_r0x00018009c15c;
    arg3_00 = (uint8_t *)(arg3 + 4);
    arg2 = (int64_t)puVar7;
code_r0x00018009bf98:
    puVar7 = (uint8_t *)arg2;
    puVar8 = *(uint8_t **)(arg1 + 0x18);
    arg2 = (int64_t)puVar7;
    arg3 = (int64_t)arg3_00;
    if (arg3_00 == puVar8) goto code_r0x00018009c15c;
    goto code_r0x00018009bd00;
joined_r0x00018009c05d:
    if (puVar7 != (uint8_t *)0x0) goto code_r0x00018009c15c;
    if (*ppuVar1 <= (uint64_t)arg2) goto code_r0x00018009c14b;
    uVar4 = *(uint8_t *)arg3;
    uVar2 = *(uint8_t *)arg2;
    if (uVar4 == 0x25) {
        uVar6 = fcn.18009b900((uint64_t)uVar2, (uint64_t)*puVar8);
code_r0x00018009c0a9:
        if (uVar6 == 0) goto code_r0x00018009c14b;
    } else if (uVar4 != 0x2e) {
        if (uVar4 == 0x5b) {
            uVar6 = fcn.18009ba50((uint64_t)uVar2, arg3, (int64_t)(arg3_00 + -1));
        } else {
            uVar6 = (uint32_t)(uVar4 == uVar2);
        }
        goto code_r0x00018009c0a9;
    }
    arg2 = arg2 + 1;
    puVar7 = (uint8_t *)fcn.18009bc70(arg1, arg2, (int64_t)(arg3_00 + 1));
    goto joined_r0x00018009c05d;
code_r0x00018009c0d5:
    if (*ppuVar1 <= (uint8_t *)(arg2 + iVar11)) goto joined_r0x00018009c127;
    uVar4 = *(uint8_t *)(arg2 + iVar11);
    uVar2 = *(uint8_t *)arg3;
    if (uVar2 == 0x25) {
        uVar6 = fcn.18009b900((uint64_t)uVar4, (uint64_t)*puVar8);
code_r0x00018009c11b:
        if (uVar6 == 0) goto joined_r0x00018009c127;
    } else if (uVar2 != 0x2e) {
        if (uVar2 == 0x5b) {
            uVar6 = fcn.18009ba50((uint64_t)uVar4, arg3, (int64_t)(arg3_00 + -1));
        } else {
            uVar6 = (uint32_t)(uVar2 == uVar4);
        }
        goto code_r0x00018009c11b;
    }
    iVar11 = iVar11 + 1;
    goto code_r0x00018009c0d5;
joined_r0x00018009c127:
    if (iVar11 < 0) goto code_r0x00018009c14b;
    puVar7 = (uint8_t *)fcn.18009bc70(arg1, (int64_t)(arg2 + iVar11), (int64_t)(arg3_00 + 1));
    if (puVar7 != (uint8_t *)0x0) goto code_r0x00018009c15c;
    iVar11 = iVar11 + -1;
    goto joined_r0x00018009c127;
code_r0x00018009c14b:
    puVar7 = (uint8_t *)0x0;
    goto code_r0x00018009c15c;
}

// ============================================================
// Function: FUN_18009c180
// Address: 0x18009c180
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

uint8_t * fcn.18009bc70(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t **ppuVar1;
    uint8_t uVar2;
    code *pcVar3;
    uint8_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    uint8_t *arg3_00;
    uint8_t *puVar7;
    uint8_t *puVar8;
    int32_t iVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    int64_t var_28h;
    
    iVar5 = *(int32_t *)arg1;
    iVar11 = *(int64_t *)(arg1 + 0x20);
    *(int32_t *)arg1 = iVar5 + -1;
    if (iVar5 == 0) {
        fcn.180088560(iVar11, 0x18063e650);
        pcVar3 = (code *)swi(3);
        puVar8 = (uint8_t *)(*pcVar3)();
        return puVar8;
    }
    pcVar3 = *(code **)(*(int64_t *)(iVar11 + 0x20) + 0x520);
    if (pcVar3 != (code *)0x0) {
        *(int16_t *)(iVar11 + 0x68) = *(int16_t *)(iVar11 + 0x68) + 1;
        (*pcVar3)(iVar11, 0xffffffff);
        *(int16_t *)(iVar11 + 0x68) = *(int16_t *)(iVar11 + 0x68) + -1;
    }
    puVar8 = *(uint8_t **)(arg1 + 0x18);
    puVar7 = (uint8_t *)arg2;
    if ((uint8_t *)arg3 != puVar8) {
code_r0x00018009bd00:
        uVar4 = *(uint8_t *)arg3;
        if (uVar4 == 0x24) {
            if ((uint8_t *)(arg3 + 1) == puVar8) {
                puVar7 = (uint8_t *)0x0;
                if ((uint8_t *)arg2 == *(uint8_t **)(arg1 + 0x10)) {
                    puVar7 = (uint8_t *)arg2;
                }
                goto code_r0x00018009c15c;
            }
code_r0x00018009bed0:
            puVar8 = (uint8_t *)(arg3 + 1);
            arg3_00 = (uint8_t *)fcn.18009b870(arg1, arg3);
            ppuVar1 = (uint8_t **)(arg1 + 0x10);
            if ((uint64_t)arg2 < *ppuVar1) {
                uVar4 = *(uint8_t *)arg3;
                uVar2 = *(uint8_t *)arg2;
                if (uVar4 == 0x25) {
                    uVar6 = fcn.18009b900((uint64_t)uVar2, (uint64_t)*puVar8);
code_r0x00018009bf58:
                    uVar4 = *arg3_00;
                    if (uVar6 == 0) goto code_r0x00018009bf60;
                } else {
                    if (uVar4 != 0x2e) {
                        if (uVar4 == 0x5b) {
                            uVar6 = fcn.18009ba50((uint64_t)uVar2, arg3, (int64_t)(arg3_00 + -1));
                        } else {
                            uVar6 = (uint32_t)(uVar4 == uVar2);
                        }
                        goto code_r0x00018009bf58;
                    }
                    uVar4 = *arg3_00;
                }
                if (uVar4 != 0x2a) {
                    if (uVar4 != 0x2b) {
                        if (uVar4 == 0x2d) {
                            puVar7 = (uint8_t *)fcn.18009bc70(arg1, arg2, (int64_t)(arg3_00 + 1));
                            goto joined_r0x00018009c05d;
                        }
                        if (uVar4 != 0x3f) {
                            arg2 = (int64_t)(arg2 + 1);
                            goto code_r0x00018009bf98;
                        }
                        arg3_00 = arg3_00 + 1;
                        puVar7 = (uint8_t *)fcn.18009bc70(arg1, (int64_t)(arg2 + 1), (int64_t)arg3_00);
                        if (puVar7 != (uint8_t *)0x0) goto code_r0x00018009c15c;
                        goto code_r0x00018009bf98;
                    }
                    arg2 = arg2 + 1;
                }
                iVar11 = 0;
                goto code_r0x00018009c0d5;
            }
            uVar4 = *arg3_00;
code_r0x00018009bf60:
            if ((0x3f < uVar4) || ((0x8000240000000000U >> ((int64_t)(char)uVar4 & 0x3fU) & 1) == 0))
            goto code_r0x00018009c14b;
            arg3_00 = arg3_00 + 1;
        } else {
            if (uVar4 != 0x25) {
                if (uVar4 != 0x28) {
                    if (uVar4 != 0x29) goto code_r0x00018009bed0;
                    uVar6 = *(int32_t *)(arg1 + 0x28) - 1;
                    if (-1 < (int32_t)uVar6) goto code_r0x00018009bfc0;
                    goto code_r0x00018009c190;
                }
                puVar7 = (uint8_t *)
                         fcn.18009bc10(arg1, arg2, (uint8_t *)(arg3 + (uint64_t)(*(uint8_t *)(arg3 + 1) == 0x29) + 1), 
                                       (uint64_t)((*(uint8_t *)(arg3 + 1) != 0x29) - 2));
                goto code_r0x00018009c15c;
            }
            uVar4 = *(uint8_t *)(arg3 + 1);
    // switch table (4 cases) at 0x18009c1d8
            switch(uVar4) {
            case 0x30:
            case 0x31:
            case 0x32:
            case 0x33:
            case 0x34:
            case 0x35:
            case 0x36:
            case 0x37:
            case 0x38:
            case 0x39:
                iVar5 = uVar4 - 0x31;
                if (((iVar5 < 0) || (*(int32_t *)(arg1 + 0x28) <= iVar5)) ||
                   (uVar10 = *(uint64_t *)(arg1 + 0x38 + ((uint64_t)uVar4 - 0x31) * 0x10), uVar10 == 0xffffffffffffffff)
                   ) {
                    fcn.180088560(*(undefined8 *)(arg1 + 0x20), 0x18063e608, uVar4 - 0x30);
                    pcVar3 = (code *)swi(3);
                    puVar8 = (uint8_t *)(*pcVar3)();
                    return puVar8;
                }
                if (((uint64_t)(*(int64_t *)(arg1 + 0x10) - arg2) < uVar10) ||
                   (iVar5 = func_0x000180497f30(*(undefined8 *)(arg1 + ((uint64_t)uVar4 - 0x2e) * 0x10), arg2, uVar10),
                   iVar5 != 0)) goto code_r0x00018009c14b;
                puVar7 = (uint8_t *)(arg2 + uVar10);
                if (puVar7 != (uint8_t *)0x0) {
                    arg3_00 = (uint8_t *)(arg3 + 2);
                    arg2 = (int64_t)puVar7;
                    break;
                }
                goto code_r0x00018009c15c;
            default:
                goto code_r0x00018009bed0;
            case 0x62:
                if (puVar8 + -1 <= (uint8_t *)(arg3 + 2)) {
                    fcn.180088560(*(undefined8 *)(arg1 + 0x20), 0x18063e680);
                    pcVar3 = (code *)swi(3);
                    puVar8 = (uint8_t *)(*pcVar3)();
                    return puVar8;
                }
                uVar4 = *(uint8_t *)(arg3 + 2);
                if (*(uint8_t *)arg2 == uVar4) {
                    puVar7 = (uint8_t *)(arg2 + 1);
                    iVar5 = 1;
                    if (puVar7 < *(uint8_t **)(arg1 + 0x10)) {
                        do {
                            if (*puVar7 == *(uint8_t *)(arg3 + 3)) {
                                iVar9 = iVar5 + -1;
                                if (iVar5 + -1 == 0) goto code_r0x00018009bdad;
                            } else {
                                iVar9 = iVar5 + 1;
                                if (*puVar7 != uVar4) {
                                    iVar9 = iVar5;
                                }
                            }
                            puVar7 = puVar7 + 1;
                            iVar5 = iVar9;
                            if (*(uint8_t **)(arg1 + 0x10) <= puVar7) {
                                puVar7 = (uint8_t *)0x0;
                                goto code_r0x00018009c15c;
                            }
                        } while( true );
                    }
                }
                goto code_r0x00018009c14b;
            case 0x66:
                puVar8 = (uint8_t *)(arg3 + 2);
                if (*(uint8_t *)(arg3 + 2) != 0x5b) {
                    fcn.180088560(*(undefined8 *)(arg1 + 0x20), 0x18063e628);
                    pcVar3 = (code *)swi(3);
                    puVar8 = (uint8_t *)(*pcVar3)();
                    return puVar8;
                }
                arg3_00 = (uint8_t *)fcn.18009b870(arg1, (int64_t)puVar8);
                if ((uint8_t *)arg2 == *(uint8_t **)(arg1 + 8)) {
                    uVar4 = 0;
                } else {
                    uVar4 = *(uint8_t *)(arg2 + -1);
                }
                iVar5 = fcn.18009ba50((uint64_t)uVar4, (int64_t)puVar8, (int64_t)(arg3_00 + -1));
                if ((iVar5 != 0) ||
                   (iVar5 = fcn.18009ba50((uint64_t)*(uint8_t *)arg2, (int64_t)puVar8, (int64_t)(arg3_00 + -1)),
                   iVar5 == 0)) goto code_r0x00018009c14b;
            }
        }
        goto code_r0x00018009bf98;
    }
code_r0x00018009c15c:
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return puVar7;
code_r0x00018009bfc0:
    uVar10 = (uint64_t)uVar6;
    if (*(int64_t *)(arg1 + 0x38 + uVar10 * 0x10) == -1) {
        *(int64_t *)(arg1 + 0x38 + uVar10 * 0x10) = arg2 - *(int64_t *)((uVar10 + 3) * 0x10 + arg1);
        puVar7 = (uint8_t *)fcn.18009bc70(arg1, arg2, (int64_t)(arg3 + 1));
        if (puVar7 == (uint8_t *)0x0) {
            *(undefined8 *)(arg1 + 0x38 + uVar10 * 0x10) = 0xffffffffffffffff;
        }
        goto code_r0x00018009c15c;
    }
    uVar6 = uVar6 - 1;
    if ((int32_t)uVar6 < 0) {
code_r0x00018009c190:
        fcn.180088560(*(undefined8 *)(arg1 + 0x20), 0x18063e5f0);
        pcVar3 = (code *)swi(3);
        puVar8 = (uint8_t *)(*pcVar3)();
        return puVar8;
    }
    goto code_r0x00018009bfc0;
code_r0x00018009bdad:
    puVar7 = puVar7 + 1;
    if (puVar7 == (uint8_t *)0x0) goto code_r0x00018009c15c;
    arg3_00 = (uint8_t *)(arg3 + 4);
    arg2 = (int64_t)puVar7;
code_r0x00018009bf98:
    puVar7 = (uint8_t *)arg2;
    puVar8 = *(uint8_t **)(arg1 + 0x18);
    arg2 = (int64_t)puVar7;
    arg3 = (int64_t)arg3_00;
    if (arg3_00 == puVar8) goto code_r0x00018009c15c;
    goto code_r0x00018009bd00;
joined_r0x00018009c05d:
    if (puVar7 != (uint8_t *)0x0) goto code_r0x00018009c15c;
    if (*ppuVar1 <= (uint64_t)arg2) goto code_r0x00018009c14b;
    uVar4 = *(uint8_t *)arg3;
    uVar2 = *(uint8_t *)arg2;
    if (uVar4 == 0x25) {
        uVar6 = fcn.18009b900((uint64_t)uVar2, (uint64_t)*puVar8);
code_r0x00018009c0a9:
        if (uVar6 == 0) goto code_r0x00018009c14b;
    } else if (uVar4 != 0x2e) {
        if (uVar4 == 0x5b) {
            uVar6 = fcn.18009ba50((uint64_t)uVar2, arg3, (int64_t)(arg3_00 + -1));
        } else {
            uVar6 = (uint32_t)(uVar4 == uVar2);
        }
        goto code_r0x00018009c0a9;
    }
    arg2 = arg2 + 1;
    puVar7 = (uint8_t *)fcn.18009bc70(arg1, arg2, (int64_t)(arg3_00 + 1));
    goto joined_r0x00018009c05d;
code_r0x00018009c0d5:
    if (*ppuVar1 <= (uint8_t *)(arg2 + iVar11)) goto joined_r0x00018009c127;
    uVar4 = *(uint8_t *)(arg2 + iVar11);
    uVar2 = *(uint8_t *)arg3;
    if (uVar2 == 0x25) {
        uVar6 = fcn.18009b900((uint64_t)uVar4, (uint64_t)*puVar8);
code_r0x00018009c11b:
        if (uVar6 == 0) goto joined_r0x00018009c127;
    } else if (uVar2 != 0x2e) {
        if (uVar2 == 0x5b) {
            uVar6 = fcn.18009ba50((uint64_t)uVar4, arg3, (int64_t)(arg3_00 + -1));
        } else {
            uVar6 = (uint32_t)(uVar2 == uVar4);
        }
        goto code_r0x00018009c11b;
    }
    iVar11 = iVar11 + 1;
    goto code_r0x00018009c0d5;
joined_r0x00018009c127:
    if (iVar11 < 0) goto code_r0x00018009c14b;
    puVar7 = (uint8_t *)fcn.18009bc70(arg1, (int64_t)(arg2 + iVar11), (int64_t)(arg3_00 + 1));
    if (puVar7 != (uint8_t *)0x0) goto code_r0x00018009c15c;
    iVar11 = iVar11 + -1;
    goto joined_r0x00018009c127;
code_r0x00018009c14b:
    puVar7 = (uint8_t *)0x0;
    goto code_r0x00018009c15c;
}

// ============================================================
// Function: FUN_18009c190
// Address: 0x18009c190
// Size: 143 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

uint8_t * fcn.18009bc70(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t **ppuVar1;
    uint8_t uVar2;
    code *pcVar3;
    uint8_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    uint8_t *arg3_00;
    uint8_t *puVar7;
    uint8_t *puVar8;
    int32_t iVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    int64_t var_28h;
    
    iVar5 = *(int32_t *)arg1;
    iVar11 = *(int64_t *)(arg1 + 0x20);
    *(int32_t *)arg1 = iVar5 + -1;
    if (iVar5 == 0) {
        fcn.180088560(iVar11, 0x18063e650);
        pcVar3 = (code *)swi(3);
        puVar8 = (uint8_t *)(*pcVar3)();
        return puVar8;
    }
    pcVar3 = *(code **)(*(int64_t *)(iVar11 + 0x20) + 0x520);
    if (pcVar3 != (code *)0x0) {
        *(int16_t *)(iVar11 + 0x68) = *(int16_t *)(iVar11 + 0x68) + 1;
        (*pcVar3)(iVar11, 0xffffffff);
        *(int16_t *)(iVar11 + 0x68) = *(int16_t *)(iVar11 + 0x68) + -1;
    }
    puVar8 = *(uint8_t **)(arg1 + 0x18);
    puVar7 = (uint8_t *)arg2;
    if ((uint8_t *)arg3 != puVar8) {
code_r0x00018009bd00:
        uVar4 = *(uint8_t *)arg3;
        if (uVar4 == 0x24) {
            if ((uint8_t *)(arg3 + 1) == puVar8) {
                puVar7 = (uint8_t *)0x0;
                if ((uint8_t *)arg2 == *(uint8_t **)(arg1 + 0x10)) {
                    puVar7 = (uint8_t *)arg2;
                }
                goto code_r0x00018009c15c;
            }
code_r0x00018009bed0:
            puVar8 = (uint8_t *)(arg3 + 1);
            arg3_00 = (uint8_t *)fcn.18009b870(arg1, arg3);
            ppuVar1 = (uint8_t **)(arg1 + 0x10);
            if ((uint64_t)arg2 < *ppuVar1) {
                uVar4 = *(uint8_t *)arg3;
                uVar2 = *(uint8_t *)arg2;
                if (uVar4 == 0x25) {
                    uVar6 = fcn.18009b900((uint64_t)uVar2, (uint64_t)*puVar8);
code_r0x00018009bf58:
                    uVar4 = *arg3_00;
                    if (uVar6 == 0) goto code_r0x00018009bf60;
                } else {
                    if (uVar4 != 0x2e) {
                        if (uVar4 == 0x5b) {
                            uVar6 = fcn.18009ba50((uint64_t)uVar2, arg3, (int64_t)(arg3_00 + -1));
                        } else {
                            uVar6 = (uint32_t)(uVar4 == uVar2);
                        }
                        goto code_r0x00018009bf58;
                    }
                    uVar4 = *arg3_00;
                }
                if (uVar4 != 0x2a) {
                    if (uVar4 != 0x2b) {
                        if (uVar4 == 0x2d) {
                            puVar7 = (uint8_t *)fcn.18009bc70(arg1, arg2, (int64_t)(arg3_00 + 1));
                            goto joined_r0x00018009c05d;
                        }
                        if (uVar4 != 0x3f) {
                            arg2 = (int64_t)(arg2 + 1);
                            goto code_r0x00018009bf98;
                        }
                        arg3_00 = arg3_00 + 1;
                        puVar7 = (uint8_t *)fcn.18009bc70(arg1, (int64_t)(arg2 + 1), (int64_t)arg3_00);
                        if (puVar7 != (uint8_t *)0x0) goto code_r0x00018009c15c;
                        goto code_r0x00018009bf98;
                    }
                    arg2 = arg2 + 1;
                }
                iVar11 = 0;
                goto code_r0x00018009c0d5;
            }
            uVar4 = *arg3_00;
code_r0x00018009bf60:
            if ((0x3f < uVar4) || ((0x8000240000000000U >> ((int64_t)(char)uVar4 & 0x3fU) & 1) == 0))
            goto code_r0x00018009c14b;
            arg3_00 = arg3_00 + 1;
        } else {
            if (uVar4 != 0x25) {
                if (uVar4 != 0x28) {
                    if (uVar4 != 0x29) goto code_r0x00018009bed0;
                    uVar6 = *(int32_t *)(arg1 + 0x28) - 1;
                    if (-1 < (int32_t)uVar6) goto code_r0x00018009bfc0;
                    goto code_r0x00018009c190;
                }
                puVar7 = (uint8_t *)
                         fcn.18009bc10(arg1, arg2, (uint8_t *)(arg3 + (uint64_t)(*(uint8_t *)(arg3 + 1) == 0x29) + 1), 
                                       (uint64_t)((*(uint8_t *)(arg3 + 1) != 0x29) - 2));
                goto code_r0x00018009c15c;
            }
            uVar4 = *(uint8_t *)(arg3 + 1);
    // switch table (4 cases) at 0x18009c1d8
            switch(uVar4) {
            case 0x30:
            case 0x31:
            case 0x32:
            case 0x33:
            case 0x34:
            case 0x35:
            case 0x36:
            case 0x37:
            case 0x38:
            case 0x39:
                iVar5 = uVar4 - 0x31;
                if (((iVar5 < 0) || (*(int32_t *)(arg1 + 0x28) <= iVar5)) ||
                   (uVar10 = *(uint64_t *)(arg1 + 0x38 + ((uint64_t)uVar4 - 0x31) * 0x10), uVar10 == 0xffffffffffffffff)
                   ) {
                    fcn.180088560(*(undefined8 *)(arg1 + 0x20), 0x18063e608, uVar4 - 0x30);
                    pcVar3 = (code *)swi(3);
                    puVar8 = (uint8_t *)(*pcVar3)();
                    return puVar8;
                }
                if (((uint64_t)(*(int64_t *)(arg1 + 0x10) - arg2) < uVar10) ||
                   (iVar5 = func_0x000180497f30(*(undefined8 *)(arg1 + ((uint64_t)uVar4 - 0x2e) * 0x10), arg2, uVar10),
                   iVar5 != 0)) goto code_r0x00018009c14b;
                puVar7 = (uint8_t *)(arg2 + uVar10);
                if (puVar7 != (uint8_t *)0x0) {
                    arg3_00 = (uint8_t *)(arg3 + 2);
                    arg2 = (int64_t)puVar7;
                    break;
                }
                goto code_r0x00018009c15c;
            default:
                goto code_r0x00018009bed0;
            case 0x62:
                if (puVar8 + -1 <= (uint8_t *)(arg3 + 2)) {
                    fcn.180088560(*(undefined8 *)(arg1 + 0x20), 0x18063e680);
                    pcVar3 = (code *)swi(3);
                    puVar8 = (uint8_t *)(*pcVar3)();
                    return puVar8;
                }
                uVar4 = *(uint8_t *)(arg3 + 2);
                if (*(uint8_t *)arg2 == uVar4) {
                    puVar7 = (uint8_t *)(arg2 + 1);
                    iVar5 = 1;
                    if (puVar7 < *(uint8_t **)(arg1 + 0x10)) {
                        do {
                            if (*puVar7 == *(uint8_t *)(arg3 + 3)) {
                                iVar9 = iVar5 + -1;
                                if (iVar5 + -1 == 0) goto code_r0x00018009bdad;
                            } else {
                                iVar9 = iVar5 + 1;
                                if (*puVar7 != uVar4) {
                                    iVar9 = iVar5;
                                }
                            }
                            puVar7 = puVar7 + 1;
                            iVar5 = iVar9;
                            if (*(uint8_t **)(arg1 + 0x10) <= puVar7) {
                                puVar7 = (uint8_t *)0x0;
                                goto code_r0x00018009c15c;
                            }
                        } while( true );
                    }
                }
                goto code_r0x00018009c14b;
            case 0x66:
                puVar8 = (uint8_t *)(arg3 + 2);
                if (*(uint8_t *)(arg3 + 2) != 0x5b) {
                    fcn.180088560(*(undefined8 *)(arg1 + 0x20), 0x18063e628);
                    pcVar3 = (code *)swi(3);
                    puVar8 = (uint8_t *)(*pcVar3)();
                    return puVar8;
                }
                arg3_00 = (uint8_t *)fcn.18009b870(arg1, (int64_t)puVar8);
                if ((uint8_t *)arg2 == *(uint8_t **)(arg1 + 8)) {
                    uVar4 = 0;
                } else {
                    uVar4 = *(uint8_t *)(arg2 + -1);
                }
                iVar5 = fcn.18009ba50((uint64_t)uVar4, (int64_t)puVar8, (int64_t)(arg3_00 + -1));
                if ((iVar5 != 0) ||
                   (iVar5 = fcn.18009ba50((uint64_t)*(uint8_t *)arg2, (int64_t)puVar8, (int64_t)(arg3_00 + -1)),
                   iVar5 == 0)) goto code_r0x00018009c14b;
            }
        }
        goto code_r0x00018009bf98;
    }
code_r0x00018009c15c:
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return puVar7;
code_r0x00018009bfc0:
    uVar10 = (uint64_t)uVar6;
    if (*(int64_t *)(arg1 + 0x38 + uVar10 * 0x10) == -1) {
        *(int64_t *)(arg1 + 0x38 + uVar10 * 0x10) = arg2 - *(int64_t *)((uVar10 + 3) * 0x10 + arg1);
        puVar7 = (uint8_t *)fcn.18009bc70(arg1, arg2, (int64_t)(arg3 + 1));
        if (puVar7 == (uint8_t *)0x0) {
            *(undefined8 *)(arg1 + 0x38 + uVar10 * 0x10) = 0xffffffffffffffff;
        }
        goto code_r0x00018009c15c;
    }
    uVar6 = uVar6 - 1;
    if ((int32_t)uVar6 < 0) {
code_r0x00018009c190:
        fcn.180088560(*(undefined8 *)(arg1 + 0x20), 0x18063e5f0);
        pcVar3 = (code *)swi(3);
        puVar8 = (uint8_t *)(*pcVar3)();
        return puVar8;
    }
    goto code_r0x00018009bfc0;
code_r0x00018009bdad:
    puVar7 = puVar7 + 1;
    if (puVar7 == (uint8_t *)0x0) goto code_r0x00018009c15c;
    arg3_00 = (uint8_t *)(arg3 + 4);
    arg2 = (int64_t)puVar7;
code_r0x00018009bf98:
    puVar7 = (uint8_t *)arg2;
    puVar8 = *(uint8_t **)(arg1 + 0x18);
    arg2 = (int64_t)puVar7;
    arg3 = (int64_t)arg3_00;
    if (arg3_00 == puVar8) goto code_r0x00018009c15c;
    goto code_r0x00018009bd00;
joined_r0x00018009c05d:
    if (puVar7 != (uint8_t *)0x0) goto code_r0x00018009c15c;
    if (*ppuVar1 <= (uint64_t)arg2) goto code_r0x00018009c14b;
    uVar4 = *(uint8_t *)arg3;
    uVar2 = *(uint8_t *)arg2;
    if (uVar4 == 0x25) {
        uVar6 = fcn.18009b900((uint64_t)uVar2, (uint64_t)*puVar8);
code_r0x00018009c0a9:
        if (uVar6 == 0) goto code_r0x00018009c14b;
    } else if (uVar4 != 0x2e) {
        if (uVar4 == 0x5b) {
            uVar6 = fcn.18009ba50((uint64_t)uVar2, arg3, (int64_t)(arg3_00 + -1));
        } else {
            uVar6 = (uint32_t)(uVar4 == uVar2);
        }
        goto code_r0x00018009c0a9;
    }
    arg2 = arg2 + 1;
    puVar7 = (uint8_t *)fcn.18009bc70(arg1, arg2, (int64_t)(arg3_00 + 1));
    goto joined_r0x00018009c05d;
code_r0x00018009c0d5:
    if (*ppuVar1 <= (uint8_t *)(arg2 + iVar11)) goto joined_r0x00018009c127;
    uVar4 = *(uint8_t *)(arg2 + iVar11);
    uVar2 = *(uint8_t *)arg3;
    if (uVar2 == 0x25) {
        uVar6 = fcn.18009b900((uint64_t)uVar4, (uint64_t)*puVar8);
code_r0x00018009c11b:
        if (uVar6 == 0) goto joined_r0x00018009c127;
    } else if (uVar2 != 0x2e) {
        if (uVar2 == 0x5b) {
            uVar6 = fcn.18009ba50((uint64_t)uVar4, arg3, (int64_t)(arg3_00 + -1));
        } else {
            uVar6 = (uint32_t)(uVar2 == uVar4);
        }
        goto code_r0x00018009c11b;
    }
    iVar11 = iVar11 + 1;
    goto code_r0x00018009c0d5;
joined_r0x00018009c127:
    if (iVar11 < 0) goto code_r0x00018009c14b;
    puVar7 = (uint8_t *)fcn.18009bc70(arg1, (int64_t)(arg2 + iVar11), (int64_t)(arg3_00 + 1));
    if (puVar7 != (uint8_t *)0x0) goto code_r0x00018009c15c;
    iVar11 = iVar11 + -1;
    goto joined_r0x00018009c127;
code_r0x00018009c14b:
    puVar7 = (uint8_t *)0x0;
    goto code_r0x00018009c15c;
}

// ============================================================
// Function: FUN_18009c220
// Address: 0x18009c220
// Size: 209 bytes
// ============================================================
uint64_t fcn.18009c220(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    
    uVar6 = *(uint32_t *)(arg1 + 0x28);
    if ((uVar6 == 0) && (arg2 != 0)) {
        uVar6 = 1;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x20);
    iVar3 = func_0x000180085510(uVar1, uVar6);
    if (iVar3 == 0) {
        fcn.180088560(uVar1, 0x18063da38, 0x18063e668);
        pcVar2 = (code *)swi(3);
        uVar4 = (*pcVar2)();
        return uVar4;
    }
    uVar4 = 0;
    if (0 < (int32_t)uVar6) {
        do {
            uVar1 = *(undefined8 *)(arg1 + 0x20);
            iVar3 = (int32_t)uVar4;
            if (iVar3 < *(int32_t *)(arg1 + 0x28)) {
                iVar7 = *(int64_t *)(arg1 + 0x38 + uVar4 * 0x10);
                if (iVar7 == -1) {
                    fcn.180088560(uVar1, 0x18063e6f0);
                    pcVar2 = (code *)swi(3);
                    uVar4 = (*pcVar2)();
                    return uVar4;
                }
                if (iVar7 != -2) {
                    iVar5 = *(int64_t *)(arg1 + (uVar4 + 3) * 0x10);
                    goto code_r0x00018009c2a8;
                }
                func_0x0001800865e0(uVar1, (*(int32_t *)(arg1 + (uVar4 + 3) * 0x10) - *(int32_t *)(arg1 + 8)) + 1);
            } else {
                if (iVar3 != 0) {
                    fcn.180088560(uVar1, 0x18063e708);
                    pcVar2 = (code *)swi(3);
                    uVar4 = (*pcVar2)();
                    return uVar4;
                }
                iVar7 = arg3 - arg2;
                iVar5 = arg2;
code_r0x00018009c2a8:
                func_0x0001800867f0(uVar1, iVar5, iVar7);
            }
            uVar4 = (uint64_t)(iVar3 + 1U);
        } while ((int32_t)(iVar3 + 1U) < (int32_t)uVar6);
    }
    return (uint64_t)uVar6;
}

// ============================================================
// Function: FUN_18009c300
// Address: 0x18009c300
// Size: 190 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_270h
// WARNING: [rz-ghidra] Detected overlap for variable var_278h

void fcn.18009c300(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    char cVar2;
    uint32_t uVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    int32_t iVar11;
    uint64_t uVar12;
    int64_t iVar13;
    int64_t iVar14;
    uint64_t uVar15;
    int64_t *piVar16;
    int64_t iVar17;
    char *arg3;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_298 [32];
    uint32_t var_278h;
    int64_t var_274h;
    int64_t var_268h;
    int64_t var_260h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_298;
    piVar8 = *(int64_t **)(arg1 + 0x28);
    iVar11 = (int32_t)arg2;
    piVar16 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar8;
    if (piVar16 <= piVar8) {
        piVar7 = *(int64_t **)0x180782430;
    }
    var_274h._0_4_ = iVar11;
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009c703;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = *(int64_t **)(arg1 + 0x28);
        piVar16 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar8;
        if (piVar16 <= piVar8) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar17 = *piVar7 + 0x18;
    unique0x100003b5 = iVar17;
    if (iVar17 == 0) {
code_r0x00018009c703:
        fcn.180088470(arg1, 1, 6);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar3 = *(uint32_t *)(*piVar7 + 0x14);
    piVar7 = piVar8 + 2;
    if (piVar16 <= piVar8 + 2) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009c717;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = *(int64_t **)(arg1 + 0x28);
        piVar16 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar8 + 2;
        if (piVar16 <= piVar8 + 2) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar10 = *piVar7;
    arg3 = (char *)(iVar10 + 0x18);
    if (arg3 == (char *)0x0) {
code_r0x00018009c717:
        fcn.180088470(arg1, 2, 6);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    var_278h = *(uint32_t *)(iVar10 + 0x14);
    uVar15 = (uint64_t)var_278h;
    piVar7 = piVar8 + 4;
    if (piVar16 <= piVar8 + 4) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar5 = 1;
code_r0x00018009c4be:
        if (iVar5 <= (int32_t)(uVar3 + 1)) goto code_r0x00018009c4ca;
    } else {
        iVar6 = func_0x000180088860(arg1, 3);
        if (iVar6 < 0) {
            iVar6 = iVar6 + 1 + uVar3;
        }
        iVar5 = 0;
        if (-1 < iVar6) {
            iVar5 = iVar6;
        }
        if (0 < iVar5) goto code_r0x00018009c4be;
        iVar5 = 1;
code_r0x00018009c4ca:
        if (iVar11 == 0) {
code_r0x00018009c61a:
            cVar2 = *arg3;
            uVar12 = (int64_t)iVar5 + -1 + iVar17;
            if (cVar2 == '^') {
                arg3 = (char *)(iVar10 + 0x19);
                uVar15 = uVar15 - 1;
            }
            var_258h = iVar17 + (uint64_t)uVar3;
            var_250h = (int64_t)(arg3 + uVar15);
            var_268h._0_4_ = 200;
            var_240h._0_4_ = 0;
            var_260h = iVar17;
            var_248h = arg1;
            iVar10 = fcn.18009bc70((int64_t)&var_268h, uVar12, (int64_t)arg3);
            while (iVar10 == 0) {
                if (((uint64_t)var_258h <= uVar12) || (cVar2 == '^')) goto code_r0x00018009c547;
                uVar12 = uVar12 + 1;
                var_240h._0_4_ = 0;
                iVar10 = fcn.18009bc70((int64_t)&var_268h, uVar12, (int64_t)arg3);
            }
            if ((int32_t)var_274h == 0) {
                fcn.18009c220((int64_t)&var_268h, uVar12, iVar10);
            } else {
                func_0x0001800865e0(arg1, ((int32_t)uVar12 - (int32_t)iVar17) + 1);
                func_0x0001800865e0(arg1);
                fcn.18009c220((int64_t)&var_268h, 0, 0);
            }
            goto code_r0x00018009c554;
        }
        piVar8 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x30);
        if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 0) ||
           ((*(int32_t *)((int64_t)piVar8 + 0xc) == 1 && (*(int32_t *)piVar8 == 0)))) {
            uVar12 = 0;
            do {
                iVar9 = func_0x00018046e650(arg3 + uVar12, 0x18063e6e0);
                if (iVar9 != 0) goto code_r0x00018009c61a;
                iVar9 = func_0x000180498cd0(arg3 + uVar12);
                uVar12 = uVar12 + 1 + iVar9;
            } while (uVar12 <= uVar15);
        }
        iVar9 = (int64_t)iVar5 + -1 + iVar17;
        if (uVar15 == 0) {
            if (iVar9 != 0) {
code_r0x00018009c5f4:
                iVar11 = (int32_t)iVar9 - (int32_t)iVar17;
                func_0x0001800865e0(arg1, iVar11 + 1);
                func_0x0001800865e0(arg1, var_278h + iVar11);
                goto code_r0x00018009c554;
            }
        } else {
            uVar12 = ((uint64_t)uVar3 - (int64_t)iVar5) + 1;
            if (uVar15 <= uVar12) {
                iVar14 = uVar12 - (uVar15 - 1);
                if (iVar14 != 0) {
                    cVar2 = *arg3;
                    iVar13 = iVar9;
                    do {
                        iVar9 = func_0x000180498a80(iVar13, (int32_t)cVar2, iVar14);
                        if (iVar9 == 0) break;
                        iVar1 = iVar9 + 1;
                        iVar11 = func_0x000180497f30(iVar1, iVar10 + 0x19, uVar15 - 1);
                        iVar17 = stack0xfffffffffffffd90;
                        if (iVar11 == 0) goto code_r0x00018009c5f4;
                        iVar14 = iVar14 + (iVar13 - iVar1);
                        iVar13 = iVar1;
                    } while (iVar14 != 0);
                }
            }
        }
    }
code_r0x00018009c547:
    func_0x000180086510(arg1);
code_r0x00018009c554:
    func_0x000180459870(var_38h ^ (uint64_t)auStack_298);
    return;
}

// ============================================================
// Function: FUN_18009c3be
// Address: 0x18009c3be
// Size: 474 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_270h
// WARNING: [rz-ghidra] Detected overlap for variable var_278h

void fcn.18009c300(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    char cVar2;
    uint32_t uVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    int32_t iVar11;
    uint64_t uVar12;
    int64_t iVar13;
    int64_t iVar14;
    uint64_t uVar15;
    int64_t *piVar16;
    int64_t iVar17;
    char *arg3;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_298 [32];
    uint32_t var_278h;
    int64_t var_274h;
    int64_t var_268h;
    int64_t var_260h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_298;
    piVar8 = *(int64_t **)(arg1 + 0x28);
    iVar11 = (int32_t)arg2;
    piVar16 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar8;
    if (piVar16 <= piVar8) {
        piVar7 = *(int64_t **)0x180782430;
    }
    var_274h._0_4_ = iVar11;
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009c703;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = *(int64_t **)(arg1 + 0x28);
        piVar16 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar8;
        if (piVar16 <= piVar8) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar17 = *piVar7 + 0x18;
    unique0x100003b5 = iVar17;
    if (iVar17 == 0) {
code_r0x00018009c703:
        fcn.180088470(arg1, 1, 6);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar3 = *(uint32_t *)(*piVar7 + 0x14);
    piVar7 = piVar8 + 2;
    if (piVar16 <= piVar8 + 2) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009c717;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = *(int64_t **)(arg1 + 0x28);
        piVar16 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar8 + 2;
        if (piVar16 <= piVar8 + 2) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar10 = *piVar7;
    arg3 = (char *)(iVar10 + 0x18);
    if (arg3 == (char *)0x0) {
code_r0x00018009c717:
        fcn.180088470(arg1, 2, 6);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    var_278h = *(uint32_t *)(iVar10 + 0x14);
    uVar15 = (uint64_t)var_278h;
    piVar7 = piVar8 + 4;
    if (piVar16 <= piVar8 + 4) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar5 = 1;
code_r0x00018009c4be:
        if (iVar5 <= (int32_t)(uVar3 + 1)) goto code_r0x00018009c4ca;
    } else {
        iVar6 = func_0x000180088860(arg1, 3);
        if (iVar6 < 0) {
            iVar6 = iVar6 + 1 + uVar3;
        }
        iVar5 = 0;
        if (-1 < iVar6) {
            iVar5 = iVar6;
        }
        if (0 < iVar5) goto code_r0x00018009c4be;
        iVar5 = 1;
code_r0x00018009c4ca:
        if (iVar11 == 0) {
code_r0x00018009c61a:
            cVar2 = *arg3;
            uVar12 = (int64_t)iVar5 + -1 + iVar17;
            if (cVar2 == '^') {
                arg3 = (char *)(iVar10 + 0x19);
                uVar15 = uVar15 - 1;
            }
            var_258h = iVar17 + (uint64_t)uVar3;
            var_250h = (int64_t)(arg3 + uVar15);
            var_268h._0_4_ = 200;
            var_240h._0_4_ = 0;
            var_260h = iVar17;
            var_248h = arg1;
            iVar10 = fcn.18009bc70((int64_t)&var_268h, uVar12, (int64_t)arg3);
            while (iVar10 == 0) {
                if (((uint64_t)var_258h <= uVar12) || (cVar2 == '^')) goto code_r0x00018009c547;
                uVar12 = uVar12 + 1;
                var_240h._0_4_ = 0;
                iVar10 = fcn.18009bc70((int64_t)&var_268h, uVar12, (int64_t)arg3);
            }
            if ((int32_t)var_274h == 0) {
                fcn.18009c220((int64_t)&var_268h, uVar12, iVar10);
            } else {
                func_0x0001800865e0(arg1, ((int32_t)uVar12 - (int32_t)iVar17) + 1);
                func_0x0001800865e0(arg1);
                fcn.18009c220((int64_t)&var_268h, 0, 0);
            }
            goto code_r0x00018009c554;
        }
        piVar8 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x30);
        if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 0) ||
           ((*(int32_t *)((int64_t)piVar8 + 0xc) == 1 && (*(int32_t *)piVar8 == 0)))) {
            uVar12 = 0;
            do {
                iVar9 = func_0x00018046e650(arg3 + uVar12, 0x18063e6e0);
                if (iVar9 != 0) goto code_r0x00018009c61a;
                iVar9 = func_0x000180498cd0(arg3 + uVar12);
                uVar12 = uVar12 + 1 + iVar9;
            } while (uVar12 <= uVar15);
        }
        iVar9 = (int64_t)iVar5 + -1 + iVar17;
        if (uVar15 == 0) {
            if (iVar9 != 0) {
code_r0x00018009c5f4:
                iVar11 = (int32_t)iVar9 - (int32_t)iVar17;
                func_0x0001800865e0(arg1, iVar11 + 1);
                func_0x0001800865e0(arg1, var_278h + iVar11);
                goto code_r0x00018009c554;
            }
        } else {
            uVar12 = ((uint64_t)uVar3 - (int64_t)iVar5) + 1;
            if (uVar15 <= uVar12) {
                iVar14 = uVar12 - (uVar15 - 1);
                if (iVar14 != 0) {
                    cVar2 = *arg3;
                    iVar13 = iVar9;
                    do {
                        iVar9 = func_0x000180498a80(iVar13, (int32_t)cVar2, iVar14);
                        if (iVar9 == 0) break;
                        iVar1 = iVar9 + 1;
                        iVar11 = func_0x000180497f30(iVar1, iVar10 + 0x19, uVar15 - 1);
                        iVar17 = stack0xfffffffffffffd90;
                        if (iVar11 == 0) goto code_r0x00018009c5f4;
                        iVar14 = iVar14 + (iVar13 - iVar1);
                        iVar13 = iVar1;
                    } while (iVar14 != 0);
                }
            }
        }
    }
code_r0x00018009c547:
    func_0x000180086510(arg1);
code_r0x00018009c554:
    func_0x000180459870(var_38h ^ (uint64_t)auStack_298);
    return;
}

// ============================================================
// Function: FUN_18009c598
// Address: 0x18009c598
// Size: 363 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_270h
// WARNING: [rz-ghidra] Detected overlap for variable var_278h

void fcn.18009c300(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    char cVar2;
    uint32_t uVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    int32_t iVar11;
    uint64_t uVar12;
    int64_t iVar13;
    int64_t iVar14;
    uint64_t uVar15;
    int64_t *piVar16;
    int64_t iVar17;
    char *arg3;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_298 [32];
    uint32_t var_278h;
    int64_t var_274h;
    int64_t var_268h;
    int64_t var_260h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_298;
    piVar8 = *(int64_t **)(arg1 + 0x28);
    iVar11 = (int32_t)arg2;
    piVar16 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar8;
    if (piVar16 <= piVar8) {
        piVar7 = *(int64_t **)0x180782430;
    }
    var_274h._0_4_ = iVar11;
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009c703;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = *(int64_t **)(arg1 + 0x28);
        piVar16 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar8;
        if (piVar16 <= piVar8) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar17 = *piVar7 + 0x18;
    unique0x100003b5 = iVar17;
    if (iVar17 == 0) {
code_r0x00018009c703:
        fcn.180088470(arg1, 1, 6);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar3 = *(uint32_t *)(*piVar7 + 0x14);
    piVar7 = piVar8 + 2;
    if (piVar16 <= piVar8 + 2) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009c717;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = *(int64_t **)(arg1 + 0x28);
        piVar16 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar8 + 2;
        if (piVar16 <= piVar8 + 2) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar10 = *piVar7;
    arg3 = (char *)(iVar10 + 0x18);
    if (arg3 == (char *)0x0) {
code_r0x00018009c717:
        fcn.180088470(arg1, 2, 6);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    var_278h = *(uint32_t *)(iVar10 + 0x14);
    uVar15 = (uint64_t)var_278h;
    piVar7 = piVar8 + 4;
    if (piVar16 <= piVar8 + 4) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar5 = 1;
code_r0x00018009c4be:
        if (iVar5 <= (int32_t)(uVar3 + 1)) goto code_r0x00018009c4ca;
    } else {
        iVar6 = func_0x000180088860(arg1, 3);
        if (iVar6 < 0) {
            iVar6 = iVar6 + 1 + uVar3;
        }
        iVar5 = 0;
        if (-1 < iVar6) {
            iVar5 = iVar6;
        }
        if (0 < iVar5) goto code_r0x00018009c4be;
        iVar5 = 1;
code_r0x00018009c4ca:
        if (iVar11 == 0) {
code_r0x00018009c61a:
            cVar2 = *arg3;
            uVar12 = (int64_t)iVar5 + -1 + iVar17;
            if (cVar2 == '^') {
                arg3 = (char *)(iVar10 + 0x19);
                uVar15 = uVar15 - 1;
            }
            var_258h = iVar17 + (uint64_t)uVar3;
            var_250h = (int64_t)(arg3 + uVar15);
            var_268h._0_4_ = 200;
            var_240h._0_4_ = 0;
            var_260h = iVar17;
            var_248h = arg1;
            iVar10 = fcn.18009bc70((int64_t)&var_268h, uVar12, (int64_t)arg3);
            while (iVar10 == 0) {
                if (((uint64_t)var_258h <= uVar12) || (cVar2 == '^')) goto code_r0x00018009c547;
                uVar12 = uVar12 + 1;
                var_240h._0_4_ = 0;
                iVar10 = fcn.18009bc70((int64_t)&var_268h, uVar12, (int64_t)arg3);
            }
            if ((int32_t)var_274h == 0) {
                fcn.18009c220((int64_t)&var_268h, uVar12, iVar10);
            } else {
                func_0x0001800865e0(arg1, ((int32_t)uVar12 - (int32_t)iVar17) + 1);
                func_0x0001800865e0(arg1);
                fcn.18009c220((int64_t)&var_268h, 0, 0);
            }
            goto code_r0x00018009c554;
        }
        piVar8 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x30);
        if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 0) ||
           ((*(int32_t *)((int64_t)piVar8 + 0xc) == 1 && (*(int32_t *)piVar8 == 0)))) {
            uVar12 = 0;
            do {
                iVar9 = func_0x00018046e650(arg3 + uVar12, 0x18063e6e0);
                if (iVar9 != 0) goto code_r0x00018009c61a;
                iVar9 = func_0x000180498cd0(arg3 + uVar12);
                uVar12 = uVar12 + 1 + iVar9;
            } while (uVar12 <= uVar15);
        }
        iVar9 = (int64_t)iVar5 + -1 + iVar17;
        if (uVar15 == 0) {
            if (iVar9 != 0) {
code_r0x00018009c5f4:
                iVar11 = (int32_t)iVar9 - (int32_t)iVar17;
                func_0x0001800865e0(arg1, iVar11 + 1);
                func_0x0001800865e0(arg1, var_278h + iVar11);
                goto code_r0x00018009c554;
            }
        } else {
            uVar12 = ((uint64_t)uVar3 - (int64_t)iVar5) + 1;
            if (uVar15 <= uVar12) {
                iVar14 = uVar12 - (uVar15 - 1);
                if (iVar14 != 0) {
                    cVar2 = *arg3;
                    iVar13 = iVar9;
                    do {
                        iVar9 = func_0x000180498a80(iVar13, (int32_t)cVar2, iVar14);
                        if (iVar9 == 0) break;
                        iVar1 = iVar9 + 1;
                        iVar11 = func_0x000180497f30(iVar1, iVar10 + 0x19, uVar15 - 1);
                        iVar17 = stack0xfffffffffffffd90;
                        if (iVar11 == 0) goto code_r0x00018009c5f4;
                        iVar14 = iVar14 + (iVar13 - iVar1);
                        iVar13 = iVar1;
                    } while (iVar14 != 0);
                }
            }
        }
    }
code_r0x00018009c547:
    func_0x000180086510(arg1);
code_r0x00018009c554:
    func_0x000180459870(var_38h ^ (uint64_t)auStack_298);
    return;
}

// ============================================================
// Function: FUN_18009c703
// Address: 0x18009c703
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_270h
// WARNING: [rz-ghidra] Detected overlap for variable var_278h

void fcn.18009c300(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    char cVar2;
    uint32_t uVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    int32_t iVar11;
    uint64_t uVar12;
    int64_t iVar13;
    int64_t iVar14;
    uint64_t uVar15;
    int64_t *piVar16;
    int64_t iVar17;
    char *arg3;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_298 [32];
    uint32_t var_278h;
    int64_t var_274h;
    int64_t var_268h;
    int64_t var_260h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_298;
    piVar8 = *(int64_t **)(arg1 + 0x28);
    iVar11 = (int32_t)arg2;
    piVar16 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar8;
    if (piVar16 <= piVar8) {
        piVar7 = *(int64_t **)0x180782430;
    }
    var_274h._0_4_ = iVar11;
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009c703;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = *(int64_t **)(arg1 + 0x28);
        piVar16 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar8;
        if (piVar16 <= piVar8) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar17 = *piVar7 + 0x18;
    unique0x100003b5 = iVar17;
    if (iVar17 == 0) {
code_r0x00018009c703:
        fcn.180088470(arg1, 1, 6);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar3 = *(uint32_t *)(*piVar7 + 0x14);
    piVar7 = piVar8 + 2;
    if (piVar16 <= piVar8 + 2) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009c717;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = *(int64_t **)(arg1 + 0x28);
        piVar16 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar8 + 2;
        if (piVar16 <= piVar8 + 2) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar10 = *piVar7;
    arg3 = (char *)(iVar10 + 0x18);
    if (arg3 == (char *)0x0) {
code_r0x00018009c717:
        fcn.180088470(arg1, 2, 6);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    var_278h = *(uint32_t *)(iVar10 + 0x14);
    uVar15 = (uint64_t)var_278h;
    piVar7 = piVar8 + 4;
    if (piVar16 <= piVar8 + 4) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar5 = 1;
code_r0x00018009c4be:
        if (iVar5 <= (int32_t)(uVar3 + 1)) goto code_r0x00018009c4ca;
    } else {
        iVar6 = func_0x000180088860(arg1, 3);
        if (iVar6 < 0) {
            iVar6 = iVar6 + 1 + uVar3;
        }
        iVar5 = 0;
        if (-1 < iVar6) {
            iVar5 = iVar6;
        }
        if (0 < iVar5) goto code_r0x00018009c4be;
        iVar5 = 1;
code_r0x00018009c4ca:
        if (iVar11 == 0) {
code_r0x00018009c61a:
            cVar2 = *arg3;
            uVar12 = (int64_t)iVar5 + -1 + iVar17;
            if (cVar2 == '^') {
                arg3 = (char *)(iVar10 + 0x19);
                uVar15 = uVar15 - 1;
            }
            var_258h = iVar17 + (uint64_t)uVar3;
            var_250h = (int64_t)(arg3 + uVar15);
            var_268h._0_4_ = 200;
            var_240h._0_4_ = 0;
            var_260h = iVar17;
            var_248h = arg1;
            iVar10 = fcn.18009bc70((int64_t)&var_268h, uVar12, (int64_t)arg3);
            while (iVar10 == 0) {
                if (((uint64_t)var_258h <= uVar12) || (cVar2 == '^')) goto code_r0x00018009c547;
                uVar12 = uVar12 + 1;
                var_240h._0_4_ = 0;
                iVar10 = fcn.18009bc70((int64_t)&var_268h, uVar12, (int64_t)arg3);
            }
            if ((int32_t)var_274h == 0) {
                fcn.18009c220((int64_t)&var_268h, uVar12, iVar10);
            } else {
                func_0x0001800865e0(arg1, ((int32_t)uVar12 - (int32_t)iVar17) + 1);
                func_0x0001800865e0(arg1);
                fcn.18009c220((int64_t)&var_268h, 0, 0);
            }
            goto code_r0x00018009c554;
        }
        piVar8 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x30);
        if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 0) ||
           ((*(int32_t *)((int64_t)piVar8 + 0xc) == 1 && (*(int32_t *)piVar8 == 0)))) {
            uVar12 = 0;
            do {
                iVar9 = func_0x00018046e650(arg3 + uVar12, 0x18063e6e0);
                if (iVar9 != 0) goto code_r0x00018009c61a;
                iVar9 = func_0x000180498cd0(arg3 + uVar12);
                uVar12 = uVar12 + 1 + iVar9;
            } while (uVar12 <= uVar15);
        }
        iVar9 = (int64_t)iVar5 + -1 + iVar17;
        if (uVar15 == 0) {
            if (iVar9 != 0) {
code_r0x00018009c5f4:
                iVar11 = (int32_t)iVar9 - (int32_t)iVar17;
                func_0x0001800865e0(arg1, iVar11 + 1);
                func_0x0001800865e0(arg1, var_278h + iVar11);
                goto code_r0x00018009c554;
            }
        } else {
            uVar12 = ((uint64_t)uVar3 - (int64_t)iVar5) + 1;
            if (uVar15 <= uVar12) {
                iVar14 = uVar12 - (uVar15 - 1);
                if (iVar14 != 0) {
                    cVar2 = *arg3;
                    iVar13 = iVar9;
                    do {
                        iVar9 = func_0x000180498a80(iVar13, (int32_t)cVar2, iVar14);
                        if (iVar9 == 0) break;
                        iVar1 = iVar9 + 1;
                        iVar11 = func_0x000180497f30(iVar1, iVar10 + 0x19, uVar15 - 1);
                        iVar17 = stack0xfffffffffffffd90;
                        if (iVar11 == 0) goto code_r0x00018009c5f4;
                        iVar14 = iVar14 + (iVar13 - iVar1);
                        iVar13 = iVar1;
                    } while (iVar14 != 0);
                }
            }
        }
    }
code_r0x00018009c547:
    func_0x000180086510(arg1);
code_r0x00018009c554:
    func_0x000180459870(var_38h ^ (uint64_t)auStack_298);
    return;
}

// ============================================================
// Function: FUN_18009c717
// Address: 0x18009c717
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_270h
// WARNING: [rz-ghidra] Detected overlap for variable var_278h

void fcn.18009c300(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    char cVar2;
    uint32_t uVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    int32_t iVar11;
    uint64_t uVar12;
    int64_t iVar13;
    int64_t iVar14;
    uint64_t uVar15;
    int64_t *piVar16;
    int64_t iVar17;
    char *arg3;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_298 [32];
    uint32_t var_278h;
    int64_t var_274h;
    int64_t var_268h;
    int64_t var_260h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_298;
    piVar8 = *(int64_t **)(arg1 + 0x28);
    iVar11 = (int32_t)arg2;
    piVar16 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar8;
    if (piVar16 <= piVar8) {
        piVar7 = *(int64_t **)0x180782430;
    }
    var_274h._0_4_ = iVar11;
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009c703;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = *(int64_t **)(arg1 + 0x28);
        piVar16 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar8;
        if (piVar16 <= piVar8) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar17 = *piVar7 + 0x18;
    unique0x100003b5 = iVar17;
    if (iVar17 == 0) {
code_r0x00018009c703:
        fcn.180088470(arg1, 1, 6);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar3 = *(uint32_t *)(*piVar7 + 0x14);
    piVar7 = piVar8 + 2;
    if (piVar16 <= piVar8 + 2) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009c717;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = *(int64_t **)(arg1 + 0x28);
        piVar16 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar8 + 2;
        if (piVar16 <= piVar8 + 2) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar10 = *piVar7;
    arg3 = (char *)(iVar10 + 0x18);
    if (arg3 == (char *)0x0) {
code_r0x00018009c717:
        fcn.180088470(arg1, 2, 6);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    var_278h = *(uint32_t *)(iVar10 + 0x14);
    uVar15 = (uint64_t)var_278h;
    piVar7 = piVar8 + 4;
    if (piVar16 <= piVar8 + 4) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar5 = 1;
code_r0x00018009c4be:
        if (iVar5 <= (int32_t)(uVar3 + 1)) goto code_r0x00018009c4ca;
    } else {
        iVar6 = func_0x000180088860(arg1, 3);
        if (iVar6 < 0) {
            iVar6 = iVar6 + 1 + uVar3;
        }
        iVar5 = 0;
        if (-1 < iVar6) {
            iVar5 = iVar6;
        }
        if (0 < iVar5) goto code_r0x00018009c4be;
        iVar5 = 1;
code_r0x00018009c4ca:
        if (iVar11 == 0) {
code_r0x00018009c61a:
            cVar2 = *arg3;
            uVar12 = (int64_t)iVar5 + -1 + iVar17;
            if (cVar2 == '^') {
                arg3 = (char *)(iVar10 + 0x19);
                uVar15 = uVar15 - 1;
            }
            var_258h = iVar17 + (uint64_t)uVar3;
            var_250h = (int64_t)(arg3 + uVar15);
            var_268h._0_4_ = 200;
            var_240h._0_4_ = 0;
            var_260h = iVar17;
            var_248h = arg1;
            iVar10 = fcn.18009bc70((int64_t)&var_268h, uVar12, (int64_t)arg3);
            while (iVar10 == 0) {
                if (((uint64_t)var_258h <= uVar12) || (cVar2 == '^')) goto code_r0x00018009c547;
                uVar12 = uVar12 + 1;
                var_240h._0_4_ = 0;
                iVar10 = fcn.18009bc70((int64_t)&var_268h, uVar12, (int64_t)arg3);
            }
            if ((int32_t)var_274h == 0) {
                fcn.18009c220((int64_t)&var_268h, uVar12, iVar10);
            } else {
                func_0x0001800865e0(arg1, ((int32_t)uVar12 - (int32_t)iVar17) + 1);
                func_0x0001800865e0(arg1);
                fcn.18009c220((int64_t)&var_268h, 0, 0);
            }
            goto code_r0x00018009c554;
        }
        piVar8 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x30);
        if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 0) ||
           ((*(int32_t *)((int64_t)piVar8 + 0xc) == 1 && (*(int32_t *)piVar8 == 0)))) {
            uVar12 = 0;
            do {
                iVar9 = func_0x00018046e650(arg3 + uVar12, 0x18063e6e0);
                if (iVar9 != 0) goto code_r0x00018009c61a;
                iVar9 = func_0x000180498cd0(arg3 + uVar12);
                uVar12 = uVar12 + 1 + iVar9;
            } while (uVar12 <= uVar15);
        }
        iVar9 = (int64_t)iVar5 + -1 + iVar17;
        if (uVar15 == 0) {
            if (iVar9 != 0) {
code_r0x00018009c5f4:
                iVar11 = (int32_t)iVar9 - (int32_t)iVar17;
                func_0x0001800865e0(arg1, iVar11 + 1);
                func_0x0001800865e0(arg1, var_278h + iVar11);
                goto code_r0x00018009c554;
            }
        } else {
            uVar12 = ((uint64_t)uVar3 - (int64_t)iVar5) + 1;
            if (uVar15 <= uVar12) {
                iVar14 = uVar12 - (uVar15 - 1);
                if (iVar14 != 0) {
                    cVar2 = *arg3;
                    iVar13 = iVar9;
                    do {
                        iVar9 = func_0x000180498a80(iVar13, (int32_t)cVar2, iVar14);
                        if (iVar9 == 0) break;
                        iVar1 = iVar9 + 1;
                        iVar11 = func_0x000180497f30(iVar1, iVar10 + 0x19, uVar15 - 1);
                        iVar17 = stack0xfffffffffffffd90;
                        if (iVar11 == 0) goto code_r0x00018009c5f4;
                        iVar14 = iVar14 + (iVar13 - iVar1);
                        iVar13 = iVar1;
                    } while (iVar14 != 0);
                }
            }
        }
    }
code_r0x00018009c547:
    func_0x000180086510(arg1);
code_r0x00018009c554:
    func_0x000180459870(var_38h ^ (uint64_t)auStack_298);
    return;
}

// ============================================================
// Function: FUN_18009c750
// Address: 0x18009c750
// Size: 313 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_274h
// WARNING: [rz-ghidra] Detected overlap for variable var_260h
// WARNING: [rz-ghidra] Detected overlap for variable var_258h

void fcn.18009c750(int64_t arg1)
{
    uint8_t uVar1;
    double *pdVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    undefined4 *puVar13;
    uint64_t uVar14;
    uint32_t uVar15;
    uint64_t uVar16;
    int64_t iVar17;
    int64_t iVar18;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_298 [32];
    int64_t var_278h;
    int64_t var_268h;
    int32_t var_260h;
    int64_t var_25ch;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_298;
    piVar11 = (int64_t *)fcn.180085370(arg1, 0xffffd8ed);
    if (*(int32_t *)((int64_t)piVar11 + 0xc) == 6) {
code_r0x00018009c7ed:
        uVar12 = (uint64_t)*(uint32_t *)(*piVar11 + 0x14);
        iVar18 = *piVar11 + 0x18;
    } else {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar8 = func_0x0001800a8360(arg1, piVar11);
        if (iVar8 != 0) {
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar11 = (int64_t *)fcn.180085370(arg1, 0xffffd8ed);
            goto code_r0x00018009c7ed;
        }
        uVar12 = 0;
        iVar18 = 0;
    }
    var_278h = iVar18;
    piVar11 = (int64_t *)fcn.180085370(arg1, 0xffffd8ec);
    if (*(int32_t *)((int64_t)piVar11 + 0xc) == 6) {
code_r0x00018009c86d:
        uVar16 = (uint64_t)*(uint32_t *)(*piVar11 + 0x14);
        iVar17 = *piVar11 + 0x18;
    } else {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar8 = func_0x0001800a8360(arg1, piVar11);
        if (iVar8 != 0) {
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar11 = (int64_t *)fcn.180085370(arg1, 0xffffd8ec);
            goto code_r0x00018009c86d;
        }
        uVar16 = 0;
        iVar17 = 0;
    }
    var_25ch._0_4_ = var_278h._4_4_;
    var_250h = uVar16 + iVar17;
    var_268h._0_4_ = 200;
    var_260h = (int32_t)iVar18;
    unique0x10000393 = uVar12 + iVar18;
    var_248h = arg1;
    iVar8 = func_0x000180085f50(arg1, 0xffffd8eb, 0);
    uVar16 = iVar8 + iVar18;
    if (uVar16 <= uVar12 + iVar18) {
        do {
            var_240h._0_4_ = 0;
            uVar12 = fcn.18009bc70((int64_t)&var_268h, uVar16, iVar17);
            if (uVar12 != 0) {
                iVar9 = (int32_t)uVar12 - (int32_t)iVar18;
                iVar8 = iVar9 + 1;
                if (uVar12 != uVar16) {
                    iVar8 = iVar9;
                }
                if (((*(char *)0x180777010 != '\0') &&
                    (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
                   (iVar9 = func_0x000180085510(arg1, 1), iVar9 == 0)) {
                    func_0x000180099450(arg1, 0x18063d8d0);
                    fcn.180087960(arg1);
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                pdVar2 = *(double **)(arg1 + 0x40);
                *(undefined4 *)((int64_t)pdVar2 + 0xc) = 3;
                *pdVar2 = (double)iVar8;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                puVar13 = (undefined4 *)fcn.180085370(arg1, 0xffffd8eb);
                iVar18 = *(int64_t *)(arg1 + 0x40);
                uVar4 = *(undefined4 *)(iVar18 + -0xc);
                uVar5 = *(undefined4 *)(iVar18 + -8);
                uVar6 = *(undefined4 *)(iVar18 + -4);
                *puVar13 = *(undefined4 *)(iVar18 + -0x10);
                puVar13[1] = uVar4;
                puVar13[2] = uVar5;
                puVar13[3] = uVar6;
                if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                    iVar18 = **(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8);
                    uVar1 = *(uint8_t *)(iVar18 + 1);
                    if (((uVar1 & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar17 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar17 + 0x59) - 1U) < 3) {
                            func_0x000180094420(iVar17);
                        } else {
                            *(uint8_t *)(iVar18 + 1) = *(uint8_t *)(iVar17 + 0x58) & 3 | uVar1 & 0xf8;
                        }
                    }
                }
                iVar8 = (int32_t)var_240h;
                iVar18 = var_248h;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                if (((int32_t)var_240h != 0) || (iVar9 = 1, uVar16 == 0)) {
                    iVar9 = (int32_t)var_240h;
                }
                iVar10 = func_0x000180085510(var_248h, iVar9);
                iVar7 = var_260h;
                if (iVar10 == 0) {
                    fcn.180088560(iVar18, 0x18063da38, 0x18063e668);
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                uVar15 = 0;
                if (0 < iVar9) goto code_r0x00018009ca50;
                break;
            }
            uVar16 = uVar16 + 1;
        } while (uVar16 <= stack0xfffffffffffffda8);
    }
code_r0x00018009c8fc:
    func_0x000180459870(var_38h ^ (uint64_t)auStack_298);
    return;
code_r0x00018009ca50:
    do {
        if ((int32_t)uVar15 < iVar8) {
            uVar14 = (uint64_t)uVar15;
            iVar17 = (&var_230h)[uVar14 * 2];
            if (iVar17 == -1) {
                fcn.180088560(iVar18, 0x18063e6f0);
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            if (iVar17 != -2) {
                uVar14 = (&var_238h)[uVar14 * 2];
                goto code_r0x00018009ca96;
            }
            func_0x0001800865e0(iVar18, (*(int32_t *)(&var_238h + uVar14 * 2) - iVar7) + 1);
        } else {
            if (uVar15 != 0) {
                fcn.180088560(iVar18, 0x18063e708);
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            iVar17 = uVar12 - uVar16;
            uVar14 = uVar16;
code_r0x00018009ca96:
            func_0x0001800867f0(iVar18, uVar14, iVar17);
        }
        uVar15 = uVar15 + 1;
    } while ((int32_t)uVar15 < iVar9);
    goto code_r0x00018009c8fc;
}

// ============================================================
// Function: FUN_18009c889
// Address: 0x18009c889
// Size: 616 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_274h
// WARNING: [rz-ghidra] Detected overlap for variable var_260h
// WARNING: [rz-ghidra] Detected overlap for variable var_258h

void fcn.18009c750(int64_t arg1)
{
    uint8_t uVar1;
    double *pdVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    undefined4 *puVar13;
    uint64_t uVar14;
    uint32_t uVar15;
    uint64_t uVar16;
    int64_t iVar17;
    int64_t iVar18;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_298 [32];
    int64_t var_278h;
    int64_t var_268h;
    int32_t var_260h;
    int64_t var_25ch;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_298;
    piVar11 = (int64_t *)fcn.180085370(arg1, 0xffffd8ed);
    if (*(int32_t *)((int64_t)piVar11 + 0xc) == 6) {
code_r0x00018009c7ed:
        uVar12 = (uint64_t)*(uint32_t *)(*piVar11 + 0x14);
        iVar18 = *piVar11 + 0x18;
    } else {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar8 = func_0x0001800a8360(arg1, piVar11);
        if (iVar8 != 0) {
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar11 = (int64_t *)fcn.180085370(arg1, 0xffffd8ed);
            goto code_r0x00018009c7ed;
        }
        uVar12 = 0;
        iVar18 = 0;
    }
    var_278h = iVar18;
    piVar11 = (int64_t *)fcn.180085370(arg1, 0xffffd8ec);
    if (*(int32_t *)((int64_t)piVar11 + 0xc) == 6) {
code_r0x00018009c86d:
        uVar16 = (uint64_t)*(uint32_t *)(*piVar11 + 0x14);
        iVar17 = *piVar11 + 0x18;
    } else {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar8 = func_0x0001800a8360(arg1, piVar11);
        if (iVar8 != 0) {
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar11 = (int64_t *)fcn.180085370(arg1, 0xffffd8ec);
            goto code_r0x00018009c86d;
        }
        uVar16 = 0;
        iVar17 = 0;
    }
    var_25ch._0_4_ = var_278h._4_4_;
    var_250h = uVar16 + iVar17;
    var_268h._0_4_ = 200;
    var_260h = (int32_t)iVar18;
    unique0x10000393 = uVar12 + iVar18;
    var_248h = arg1;
    iVar8 = func_0x000180085f50(arg1, 0xffffd8eb, 0);
    uVar16 = iVar8 + iVar18;
    if (uVar16 <= uVar12 + iVar18) {
        do {
            var_240h._0_4_ = 0;
            uVar12 = fcn.18009bc70((int64_t)&var_268h, uVar16, iVar17);
            if (uVar12 != 0) {
                iVar9 = (int32_t)uVar12 - (int32_t)iVar18;
                iVar8 = iVar9 + 1;
                if (uVar12 != uVar16) {
                    iVar8 = iVar9;
                }
                if (((*(char *)0x180777010 != '\0') &&
                    (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
                   (iVar9 = func_0x000180085510(arg1, 1), iVar9 == 0)) {
                    func_0x000180099450(arg1, 0x18063d8d0);
                    fcn.180087960(arg1);
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                pdVar2 = *(double **)(arg1 + 0x40);
                *(undefined4 *)((int64_t)pdVar2 + 0xc) = 3;
                *pdVar2 = (double)iVar8;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                puVar13 = (undefined4 *)fcn.180085370(arg1, 0xffffd8eb);
                iVar18 = *(int64_t *)(arg1 + 0x40);
                uVar4 = *(undefined4 *)(iVar18 + -0xc);
                uVar5 = *(undefined4 *)(iVar18 + -8);
                uVar6 = *(undefined4 *)(iVar18 + -4);
                *puVar13 = *(undefined4 *)(iVar18 + -0x10);
                puVar13[1] = uVar4;
                puVar13[2] = uVar5;
                puVar13[3] = uVar6;
                if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                    iVar18 = **(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8);
                    uVar1 = *(uint8_t *)(iVar18 + 1);
                    if (((uVar1 & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar17 = *(int64_t *)(arg1 + 0x20);
                        if ((uint8_t)(*(char *)(iVar17 + 0x59) - 1U) < 3) {
                            func_0x000180094420(iVar17);
                        } else {
                            *(uint8_t *)(iVar18 + 1) = *(uint8_t *)(iVar17 + 0x58) & 3 | uVar1 & 0xf8;
                        }
                    }
                }
                iVar8 = (int32_t)var_240h;
                iVar18 = var_248h;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                if (((int32_t)var_240h != 0) || (iVar9 = 1, uVar16 == 0)) {
                    iVar9 = (int32_t)var_240h;
                }
                iVar10 = func_0x000180085510(var_248h, iVar9);
                iVar7 = var_260h;
                if (iVar10 == 0) {
                    fcn.180088560(iVar18, 0x18063da38, 0x18063e668);
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                uVar15 = 0;
                if (0 < iVar9) goto code_r0x00018009ca50;
                break;
            }
            uVar16 = uVar16 + 1;
        } while (uVar16 <= stack0xfffffffffffffda8);
    }
code_r0x00018009c8fc:
    func_0x000180459870(var_38h ^ (uint64_t)auStack_298);
    return;
code_r0x00018009ca50:
    do {
        if ((int32_t)uVar15 < iVar8) {
            uVar14 = (uint64_t)uVar15;
            iVar17 = (&var_230h)[uVar14 * 2];
            if (iVar17 == -1) {
                fcn.180088560(iVar18, 0x18063e6f0);
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            if (iVar17 != -2) {
                uVar14 = (&var_238h)[uVar14 * 2];
                goto code_r0x00018009ca96;
            }
            func_0x0001800865e0(iVar18, (*(int32_t *)(&var_238h + uVar14 * 2) - iVar7) + 1);
        } else {
            if (uVar15 != 0) {
                fcn.180088560(iVar18, 0x18063e708);
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            iVar17 = uVar12 - uVar16;
            uVar14 = uVar16;
code_r0x00018009ca96:
            func_0x0001800867f0(iVar18, uVar14, iVar17);
        }
        uVar15 = uVar15 + 1;
    } while ((int32_t)uVar15 < iVar9);
    goto code_r0x00018009c8fc;
}

// ============================================================
// Function: FUN_18009cb00
// Address: 0x18009cb00
// Size: 380 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_274h
// WARNING: [rz-ghidra] Detected overlap for variable var_260h
// WARNING: [rz-ghidra] Detected overlap for variable var_258h

undefined8 fcn.18009cb00(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_18h;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar6 = *(int64_t **)(arg1 + 0x40);
    piVar5 = piVar4;
    if (piVar6 <= piVar4) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1);
        if (iVar2 == 0) goto code_r0x00018009cc54;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar4 = *(int64_t **)(arg1 + 0x28);
        piVar6 = *(int64_t **)(arg1 + 0x40);
        piVar5 = piVar4;
        if (piVar6 <= piVar4) {
            piVar5 = *(int64_t **)0x180782430;
        }
    }
    if (*piVar5 == -0x18) {
code_r0x00018009cc54:
        fcn.180088470(arg1, 1, 6);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    piVar5 = piVar4 + 2;
    if (piVar6 <= piVar4 + 2) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1);
        if (iVar2 == 0) goto code_r0x00018009cc68;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar5 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
            piVar5 = *(int64_t **)0x180782430;
        }
    }
    if (*piVar5 != -0x18) {
        func_0x0001800858c0(arg1, 2);
        func_0x0001800865e0(arg1, 0);
        func_0x0001800869f0(arg1, fcn.18009c750, 0, 3, 0);
        return 1;
    }
code_r0x00018009cc68:
    fcn.180088470(arg1, 2, 6);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_18009cc80
// Address: 0x18009cc80
// Size: 335 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_49ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_4a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_258h
// WARNING: [rz-ghidra] Detected overlap for variable var_260h

void fcn.18009cc80(int64_t arg1)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t *piVar6;
    undefined *arg3;
    undefined8 uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t *piVar10;
    undefined *puVar11;
    char cVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    int64_t iVar16;
    int64_t iVar17;
    int32_t iVar18;
    undefined *arg2;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_4c8 [32];
    char var_4a8h;
    int32_t var_4a4h;
    int64_t var_4a0h;
    int64_t var_498h;
    int64_t var_490h;
    int64_t var_488h;
    int64_t var_480h;
    int64_t var_478h;
    int64_t var_470h;
    int64_t var_468h;
    int64_t var_268h;
    int32_t var_260h;
    int64_t var_25ch;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_4c8;
    piVar10 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar6 = piVar10;
    if (piVar15 <= piVar10) {
        piVar6 = *(int64_t **)0x180782430;
    }
    var_490h = arg1;
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018009d453;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar10 = *(int64_t **)(arg1 + 0x28);
        piVar15 = *(int64_t **)(arg1 + 0x40);
        piVar6 = piVar10;
        if (piVar15 <= piVar10) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    arg2 = (undefined *)(*piVar6 + 0x18);
    if (arg2 == (undefined *)0x0) {
code_r0x00018009d453:
        fcn.180088470(arg1, 1, 6);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar1 = *(uint32_t *)(*piVar6 + 0x14);
    piVar6 = piVar10 + 2;
    if (piVar15 <= piVar10 + 2) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018009d467;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar10 = *(int64_t **)(arg1 + 0x28);
        piVar15 = *(int64_t **)(arg1 + 0x40);
        piVar6 = piVar10 + 2;
        if (piVar15 <= piVar10 + 2) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    var_498h = *piVar6 + 0x18;
    if (var_498h == 0) {
code_r0x00018009d467:
        fcn.180088470(arg1, 2, 6);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar9 = (uint64_t)*(uint32_t *)(*piVar6 + 0x14);
    iVar4 = -1;
    piVar6 = piVar10 + 4;
    if (piVar15 <= piVar10 + 4) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (piVar6 != *(int64_t **)0x180782430) {
        iVar4 = *(int32_t *)((int64_t)piVar6 + 0xc);
    }
    piVar6 = piVar10 + 6;
    if (piVar15 <= piVar10 + 6) {
        piVar6 = *(int64_t **)0x180782430;
    }
    var_4a0h._0_4_ = iVar4;
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) < 1)) {
        var_4a0h._4_4_ = uVar1 + 1;
    } else {
        var_4a0h._4_4_ = func_0x000180088860(arg1, 4);
    }
    if ((iVar4 != 3) && (2 < iVar4 - 6U)) {
        fcn.1800883d0(arg1, 3, 0x18063e728);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    var_488h = (int64_t)&var_468h;
    var_480h = (int64_t)&var_268h;
    var_4a4h = 0;
    cVar12 = *(char *)var_498h;
    var_470h = 0;
    if (cVar12 == '^') {
        var_498h = var_498h + 1;
        uVar9 = uVar9 - 1;
    }
    unique0x00003400 = arg2 + uVar1;
    var_250h = uVar9 + var_498h;
    var_268h._0_4_ = 200;
    var_4a8h = cVar12;
    var_478h = arg1;
    var_248h = arg1;
    iVar18 = var_4a0h._4_4_;
    puVar11 = arg2;
    if (0 < var_4a0h._4_4_) {
        do {
            var_25ch._0_4_ = (undefined4)((uint64_t)puVar11 >> 0x20);
            var_260h = (int32_t)puVar11;
            var_240h._0_4_ = 0;
            arg3 = (undefined *)fcn.18009bc70((int64_t)&var_268h, (int64_t)arg2, var_498h);
            iVar3 = var_248h;
            if (arg3 == (undefined *)0x0) {
code_r0x00018009d2ba:
                if (stack0xfffffffffffffda8 <= arg2) goto code_r0x00018009d324;
                if (((uint64_t)var_480h <= (uint64_t)var_488h) && (var_480h == var_488h)) {
                    func_0x0001800890e0(&var_488h, (var_488h - var_480h) + 1, 0xffffffff);
                }
                arg3 = arg2 + 1;
                *(undefined *)var_488h = *arg2;
                var_488h = var_488h + 1;
            } else {
                if (iVar4 == 7) {
                    if ((int32_t)var_240h < 1) {
                        puVar11 = arg2;
                        iVar17 = (int64_t)arg3 - (int64_t)arg2;
code_r0x00018009d1fe:
                        func_0x0001800867f0(var_248h, puVar11, iVar17);
                    } else {
                        if (var_230h == -1) {
                            fcn.180088560(var_248h, 0x18063e6f0);
                            pcVar2 = (code *)swi(3);
                            (*pcVar2)();
                            return;
                        }
                        if (var_230h != -2) {
                            puVar11 = (undefined *)CONCAT44(var_238h._4_4_, (int32_t)var_238h);
                            iVar17 = var_230h;
                            goto code_r0x00018009d1fe;
                        }
                        func_0x0001800865e0(var_248h, ((int32_t)var_238h - var_260h) + 1);
                    }
                    if ((*(uint8_t *)(iVar3 + 1) & 4) != 0) {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar3 + 0x20) + 0x18);
                        *(int64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x18) = iVar3;
                    }
                    piVar10 = (int64_t *)(*(int64_t *)(iVar3 + 0x28) + 0x20);
                    if (*(int64_t **)(iVar3 + 0x40) <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    piVar15 = *(int64_t **)(iVar3 + 0x40) + -2;
                    func_0x0001800a8490(iVar3, piVar10, piVar15, piVar15);
code_r0x00018009d249:
                    iVar17 = *(int64_t *)(iVar3 + 0x40);
                    piVar10 = (int64_t *)(iVar17 - 0x10);
                    if ((*(int32_t *)(iVar17 + -4) == 0) ||
                       ((*(int32_t *)(iVar17 + -4) == 1 && (*(int32_t *)piVar10 == 0)))) {
                        *(int64_t **)(iVar3 + 0x40) = piVar10;
                        func_0x0001800867f0(iVar3, arg2, (int64_t)arg3 - (int64_t)arg2);
                    } else if ((piVar10 == *(int64_t **)0x180782430) ||
                              ((*(int32_t *)(iVar17 + -4) != 6 && (*(int32_t *)(iVar17 + -4) != 3)))) {
                        uVar7 = func_0x000180088fa0(iVar3, 0xffffffff);
                        fcn.180088560(iVar3, 0x18063e740, uVar7);
                        pcVar2 = (code *)swi(3);
                        (*pcVar2)();
                        return;
                    }
                    func_0x0001800891f0(&var_488h);
                } else {
                    if (iVar4 == 8) {
                        func_0x000180085bf0(var_248h, 3);
                        uVar5 = fcn.18009c220((int64_t)&var_268h, (int64_t)arg2, (int64_t)arg3);
                        func_0x000180087810(iVar3, uVar5);
                        goto code_r0x00018009d249;
                    }
                    piVar10 = (int64_t *)(*(int64_t *)(var_248h + 0x28) + 0x20);
                    if (*(int64_t **)(var_248h + 0x40) <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if (*(int32_t *)((int64_t)piVar10 + 0xc) == 6) {
code_r0x00018009cf9b:
                        uVar9 = (uint64_t)*(uint32_t *)(*piVar10 + 0x14);
                        iVar17 = *piVar10 + 0x18;
                    } else {
                        if ((*(uint8_t *)(var_248h + 1) & 4) != 0) {
                            *(uint8_t *)(var_248h + 1) = *(uint8_t *)(var_248h + 1) & 0xfb;
                            *(undefined8 *)(var_248h + 0x48) = *(undefined8 *)(*(int64_t *)(var_248h + 0x20) + 0x18);
                            *(int64_t *)(*(int64_t *)(var_248h + 0x20) + 0x18) = var_248h;
                        }
                        iVar4 = func_0x0001800a8360(var_248h);
                        if (iVar4 != 0) {
                            if (*(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x28) <=
                                *(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x30)) {
                                (**(code **)0x180782658)(iVar3, 1);
                            }
                            piVar10 = (int64_t *)(*(int64_t *)(iVar3 + 0x28) + 0x20);
                            if (*(int64_t **)(iVar3 + 0x40) <= piVar10) {
                                piVar10 = *(int64_t **)0x180782430;
                            }
                            goto code_r0x00018009cf9b;
                        }
                        uVar9 = 0;
                        iVar17 = 0;
                    }
                    if ((uint64_t)(var_480h - var_488h) < uVar9) {
                        func_0x0001800890e0(&var_488h, (uVar9 - var_480h) + var_488h, 0xffffffff);
                    }
                    uVar14 = 0;
                    iVar4 = (int32_t)var_4a0h;
                    iVar18 = var_4a0h._4_4_;
                    if (uVar9 != 0) {
                        do {
                            if (*(char *)(uVar14 + iVar17) == '%') {
                                iVar8 = uVar14 + 1;
                                uVar14 = uVar14 + 1;
                                iVar4 = func_0x00018046cb80(*(undefined *)(iVar8 + iVar17));
                                cVar12 = *(char *)(uVar14 + iVar17);
                                if (iVar4 == 0) {
                                    if (cVar12 != '%') {
                                        fcn.180088560(iVar3, 0x18063e6b0, 0x25);
                                        pcVar2 = (code *)swi(3);
                                        (*pcVar2)();
                                        return;
                                    }
                                    if (((uint64_t)var_480h <= (uint64_t)var_488h) && (var_480h == var_488h)) {
                                        iVar8 = var_488h - var_480h;
                                        goto code_r0x00018009d04b;
                                    }
                                    goto code_r0x00018009d064;
                                }
                                if (cVar12 == '0') {
                                    uVar13 = (int64_t)arg3 - (int64_t)arg2;
                                    if ((uint64_t)(var_480h - var_488h) < uVar13) {
                                        func_0x0001800890e0(&var_488h, (uVar13 - var_480h) + var_488h, 0xffffffff);
                                    }
                                    func_0x000180498030(var_488h, arg2, uVar13);
                                    var_488h = var_488h + uVar13;
                                } else {
                                    if (cVar12 + -0x31 < (int32_t)var_240h) {
                                        iVar8 = (int64_t)cVar12 + -0x31;
                                        iVar16 = (&var_230h)[iVar8 * 2];
                                        if (iVar16 == -1) {
                                            fcn.180088560(iVar3, 0x18063e6f0);
                                            pcVar2 = (code *)swi(3);
                                            (*pcVar2)();
                                            return;
                                        }
                                        if (iVar16 != -2) {
                                            puVar11 = (undefined *)(&var_238h)[iVar8 * 2];
                                            goto code_r0x00018009d135;
                                        }
                                        func_0x0001800865e0(iVar3, (*(int32_t *)(&var_238h + iVar8 * 2) - var_260h) + 1)
                                        ;
                                    } else {
                                        if (cVar12 != 0x31) {
                                            fcn.180088560(iVar3, 0x18063e708);
                                            pcVar2 = (code *)swi(3);
                                            (*pcVar2)();
                                            return;
                                        }
                                        iVar16 = (int64_t)arg3 - (int64_t)arg2;
                                        puVar11 = arg2;
code_r0x00018009d135:
                                        func_0x0001800867f0(iVar3, puVar11, iVar16);
                                    }
                                    func_0x0001800891f0(&var_488h);
                                }
                            } else {
                                if (((uint64_t)var_480h <= (uint64_t)var_488h) && (var_480h == var_488h)) {
                                    iVar8 = var_488h - var_480h;
code_r0x00018009d04b:
                                    func_0x0001800890e0(&var_488h, iVar8 + 1, 0xffffffff);
                                }
code_r0x00018009d064:
                                *(undefined *)var_488h = *(undefined *)(uVar14 + iVar17);
                                var_488h = var_488h + 1;
                            }
                            uVar14 = uVar14 + 1;
                            iVar4 = (int32_t)var_4a0h;
                            cVar12 = var_4a8h;
                            iVar18 = var_4a0h._4_4_;
                        } while (uVar14 < uVar9);
                    }
                }
                var_4a4h = var_4a4h + 1;
                if (arg3 <= arg2) goto code_r0x00018009d2ba;
            }
            puVar11 = (undefined *)CONCAT44((undefined4)var_25ch, var_260h);
            arg2 = arg3;
            if ((cVar12 == '^') || (iVar18 <= var_4a4h)) goto code_r0x00018009d324;
        } while( true );
    }
code_r0x00018009d32e:
    iVar4 = var_4a4h;
    var_25ch._0_4_ = (undefined4)((uint64_t)puVar11 >> 0x20);
    var_260h = (int32_t)puVar11;
    uVar9 = (int64_t)stack0xfffffffffffffda8 - (int64_t)arg2;
    if ((uint64_t)(var_480h - var_488h) < uVar9) {
        func_0x0001800890e0(&var_488h, (uVar9 - var_480h) + var_488h, 0xffffffff);
        puVar11 = (undefined *)CONCAT44((undefined4)var_25ch, var_260h);
    }
    var_25ch._0_4_ = (undefined4)((uint64_t)puVar11 >> 0x20);
    var_260h = (int32_t)puVar11;
    func_0x000180498030(var_488h, arg2, uVar9);
    iVar17 = var_470h;
    iVar3 = var_478h;
    var_488h = var_488h + uVar9;
    if (var_470h == 0) {
        func_0x0001800867f0(var_478h, &var_468h, (var_488h - (int64_t)&var_488h) + -0x20);
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_478h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_478h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_478h, 1);
        }
        iVar8 = *(int64_t *)(iVar3 + 0x40);
        if (var_488h == var_480h) {
            uVar7 = func_0x00018009a7e0(iVar3, iVar17);
        } else {
            uVar7 = func_0x00018009a8e0(iVar3, iVar17 + 0x18, (var_488h - iVar17) + -0x18);
        }
        *(undefined8 *)(iVar8 + -0x10) = uVar7;
        *(undefined4 *)(iVar8 + -4) = 6;
    }
    func_0x0001800865e0(arg1, iVar4);
    func_0x000180459870(var_38h ^ (uint64_t)auStack_4c8);
    return;
code_r0x00018009d324:
    puVar11 = (undefined *)CONCAT44((undefined4)var_25ch, var_260h);
    arg1 = var_490h;
    goto code_r0x00018009d32e;
}

// ============================================================
// Function: FUN_18009cdcf
// Address: 0x18009cdcf
// Size: 1668 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_49ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_4a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_258h
// WARNING: [rz-ghidra] Detected overlap for variable var_260h

void fcn.18009cc80(int64_t arg1)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t *piVar6;
    undefined *arg3;
    undefined8 uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t *piVar10;
    undefined *puVar11;
    char cVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    int64_t iVar16;
    int64_t iVar17;
    int32_t iVar18;
    undefined *arg2;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_4c8 [32];
    char var_4a8h;
    int32_t var_4a4h;
    int64_t var_4a0h;
    int64_t var_498h;
    int64_t var_490h;
    int64_t var_488h;
    int64_t var_480h;
    int64_t var_478h;
    int64_t var_470h;
    int64_t var_468h;
    int64_t var_268h;
    int32_t var_260h;
    int64_t var_25ch;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_4c8;
    piVar10 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar6 = piVar10;
    if (piVar15 <= piVar10) {
        piVar6 = *(int64_t **)0x180782430;
    }
    var_490h = arg1;
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018009d453;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar10 = *(int64_t **)(arg1 + 0x28);
        piVar15 = *(int64_t **)(arg1 + 0x40);
        piVar6 = piVar10;
        if (piVar15 <= piVar10) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    arg2 = (undefined *)(*piVar6 + 0x18);
    if (arg2 == (undefined *)0x0) {
code_r0x00018009d453:
        fcn.180088470(arg1, 1, 6);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar1 = *(uint32_t *)(*piVar6 + 0x14);
    piVar6 = piVar10 + 2;
    if (piVar15 <= piVar10 + 2) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018009d467;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar10 = *(int64_t **)(arg1 + 0x28);
        piVar15 = *(int64_t **)(arg1 + 0x40);
        piVar6 = piVar10 + 2;
        if (piVar15 <= piVar10 + 2) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    var_498h = *piVar6 + 0x18;
    if (var_498h == 0) {
code_r0x00018009d467:
        fcn.180088470(arg1, 2, 6);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar9 = (uint64_t)*(uint32_t *)(*piVar6 + 0x14);
    iVar4 = -1;
    piVar6 = piVar10 + 4;
    if (piVar15 <= piVar10 + 4) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (piVar6 != *(int64_t **)0x180782430) {
        iVar4 = *(int32_t *)((int64_t)piVar6 + 0xc);
    }
    piVar6 = piVar10 + 6;
    if (piVar15 <= piVar10 + 6) {
        piVar6 = *(int64_t **)0x180782430;
    }
    var_4a0h._0_4_ = iVar4;
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) < 1)) {
        var_4a0h._4_4_ = uVar1 + 1;
    } else {
        var_4a0h._4_4_ = func_0x000180088860(arg1, 4);
    }
    if ((iVar4 != 3) && (2 < iVar4 - 6U)) {
        fcn.1800883d0(arg1, 3, 0x18063e728);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    var_488h = (int64_t)&var_468h;
    var_480h = (int64_t)&var_268h;
    var_4a4h = 0;
    cVar12 = *(char *)var_498h;
    var_470h = 0;
    if (cVar12 == '^') {
        var_498h = var_498h + 1;
        uVar9 = uVar9 - 1;
    }
    unique0x00003400 = arg2 + uVar1;
    var_250h = uVar9 + var_498h;
    var_268h._0_4_ = 200;
    var_4a8h = cVar12;
    var_478h = arg1;
    var_248h = arg1;
    iVar18 = var_4a0h._4_4_;
    puVar11 = arg2;
    if (0 < var_4a0h._4_4_) {
        do {
            var_25ch._0_4_ = (undefined4)((uint64_t)puVar11 >> 0x20);
            var_260h = (int32_t)puVar11;
            var_240h._0_4_ = 0;
            arg3 = (undefined *)fcn.18009bc70((int64_t)&var_268h, (int64_t)arg2, var_498h);
            iVar3 = var_248h;
            if (arg3 == (undefined *)0x0) {
code_r0x00018009d2ba:
                if (stack0xfffffffffffffda8 <= arg2) goto code_r0x00018009d324;
                if (((uint64_t)var_480h <= (uint64_t)var_488h) && (var_480h == var_488h)) {
                    func_0x0001800890e0(&var_488h, (var_488h - var_480h) + 1, 0xffffffff);
                }
                arg3 = arg2 + 1;
                *(undefined *)var_488h = *arg2;
                var_488h = var_488h + 1;
            } else {
                if (iVar4 == 7) {
                    if ((int32_t)var_240h < 1) {
                        puVar11 = arg2;
                        iVar17 = (int64_t)arg3 - (int64_t)arg2;
code_r0x00018009d1fe:
                        func_0x0001800867f0(var_248h, puVar11, iVar17);
                    } else {
                        if (var_230h == -1) {
                            fcn.180088560(var_248h, 0x18063e6f0);
                            pcVar2 = (code *)swi(3);
                            (*pcVar2)();
                            return;
                        }
                        if (var_230h != -2) {
                            puVar11 = (undefined *)CONCAT44(var_238h._4_4_, (int32_t)var_238h);
                            iVar17 = var_230h;
                            goto code_r0x00018009d1fe;
                        }
                        func_0x0001800865e0(var_248h, ((int32_t)var_238h - var_260h) + 1);
                    }
                    if ((*(uint8_t *)(iVar3 + 1) & 4) != 0) {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar3 + 0x20) + 0x18);
                        *(int64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x18) = iVar3;
                    }
                    piVar10 = (int64_t *)(*(int64_t *)(iVar3 + 0x28) + 0x20);
                    if (*(int64_t **)(iVar3 + 0x40) <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    piVar15 = *(int64_t **)(iVar3 + 0x40) + -2;
                    func_0x0001800a8490(iVar3, piVar10, piVar15, piVar15);
code_r0x00018009d249:
                    iVar17 = *(int64_t *)(iVar3 + 0x40);
                    piVar10 = (int64_t *)(iVar17 - 0x10);
                    if ((*(int32_t *)(iVar17 + -4) == 0) ||
                       ((*(int32_t *)(iVar17 + -4) == 1 && (*(int32_t *)piVar10 == 0)))) {
                        *(int64_t **)(iVar3 + 0x40) = piVar10;
                        func_0x0001800867f0(iVar3, arg2, (int64_t)arg3 - (int64_t)arg2);
                    } else if ((piVar10 == *(int64_t **)0x180782430) ||
                              ((*(int32_t *)(iVar17 + -4) != 6 && (*(int32_t *)(iVar17 + -4) != 3)))) {
                        uVar7 = func_0x000180088fa0(iVar3, 0xffffffff);
                        fcn.180088560(iVar3, 0x18063e740, uVar7);
                        pcVar2 = (code *)swi(3);
                        (*pcVar2)();
                        return;
                    }
                    func_0x0001800891f0(&var_488h);
                } else {
                    if (iVar4 == 8) {
                        func_0x000180085bf0(var_248h, 3);
                        uVar5 = fcn.18009c220((int64_t)&var_268h, (int64_t)arg2, (int64_t)arg3);
                        func_0x000180087810(iVar3, uVar5);
                        goto code_r0x00018009d249;
                    }
                    piVar10 = (int64_t *)(*(int64_t *)(var_248h + 0x28) + 0x20);
                    if (*(int64_t **)(var_248h + 0x40) <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if (*(int32_t *)((int64_t)piVar10 + 0xc) == 6) {
code_r0x00018009cf9b:
                        uVar9 = (uint64_t)*(uint32_t *)(*piVar10 + 0x14);
                        iVar17 = *piVar10 + 0x18;
                    } else {
                        if ((*(uint8_t *)(var_248h + 1) & 4) != 0) {
                            *(uint8_t *)(var_248h + 1) = *(uint8_t *)(var_248h + 1) & 0xfb;
                            *(undefined8 *)(var_248h + 0x48) = *(undefined8 *)(*(int64_t *)(var_248h + 0x20) + 0x18);
                            *(int64_t *)(*(int64_t *)(var_248h + 0x20) + 0x18) = var_248h;
                        }
                        iVar4 = func_0x0001800a8360(var_248h);
                        if (iVar4 != 0) {
                            if (*(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x28) <=
                                *(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x30)) {
                                (**(code **)0x180782658)(iVar3, 1);
                            }
                            piVar10 = (int64_t *)(*(int64_t *)(iVar3 + 0x28) + 0x20);
                            if (*(int64_t **)(iVar3 + 0x40) <= piVar10) {
                                piVar10 = *(int64_t **)0x180782430;
                            }
                            goto code_r0x00018009cf9b;
                        }
                        uVar9 = 0;
                        iVar17 = 0;
                    }
                    if ((uint64_t)(var_480h - var_488h) < uVar9) {
                        func_0x0001800890e0(&var_488h, (uVar9 - var_480h) + var_488h, 0xffffffff);
                    }
                    uVar14 = 0;
                    iVar4 = (int32_t)var_4a0h;
                    iVar18 = var_4a0h._4_4_;
                    if (uVar9 != 0) {
                        do {
                            if (*(char *)(uVar14 + iVar17) == '%') {
                                iVar8 = uVar14 + 1;
                                uVar14 = uVar14 + 1;
                                iVar4 = func_0x00018046cb80(*(undefined *)(iVar8 + iVar17));
                                cVar12 = *(char *)(uVar14 + iVar17);
                                if (iVar4 == 0) {
                                    if (cVar12 != '%') {
                                        fcn.180088560(iVar3, 0x18063e6b0, 0x25);
                                        pcVar2 = (code *)swi(3);
                                        (*pcVar2)();
                                        return;
                                    }
                                    if (((uint64_t)var_480h <= (uint64_t)var_488h) && (var_480h == var_488h)) {
                                        iVar8 = var_488h - var_480h;
                                        goto code_r0x00018009d04b;
                                    }
                                    goto code_r0x00018009d064;
                                }
                                if (cVar12 == '0') {
                                    uVar13 = (int64_t)arg3 - (int64_t)arg2;
                                    if ((uint64_t)(var_480h - var_488h) < uVar13) {
                                        func_0x0001800890e0(&var_488h, (uVar13 - var_480h) + var_488h, 0xffffffff);
                                    }
                                    func_0x000180498030(var_488h, arg2, uVar13);
                                    var_488h = var_488h + uVar13;
                                } else {
                                    if (cVar12 + -0x31 < (int32_t)var_240h) {
                                        iVar8 = (int64_t)cVar12 + -0x31;
                                        iVar16 = (&var_230h)[iVar8 * 2];
                                        if (iVar16 == -1) {
                                            fcn.180088560(iVar3, 0x18063e6f0);
                                            pcVar2 = (code *)swi(3);
                                            (*pcVar2)();
                                            return;
                                        }
                                        if (iVar16 != -2) {
                                            puVar11 = (undefined *)(&var_238h)[iVar8 * 2];
                                            goto code_r0x00018009d135;
                                        }
                                        func_0x0001800865e0(iVar3, (*(int32_t *)(&var_238h + iVar8 * 2) - var_260h) + 1)
                                        ;
                                    } else {
                                        if (cVar12 != 0x31) {
                                            fcn.180088560(iVar3, 0x18063e708);
                                            pcVar2 = (code *)swi(3);
                                            (*pcVar2)();
                                            return;
                                        }
                                        iVar16 = (int64_t)arg3 - (int64_t)arg2;
                                        puVar11 = arg2;
code_r0x00018009d135:
                                        func_0x0001800867f0(iVar3, puVar11, iVar16);
                                    }
                                    func_0x0001800891f0(&var_488h);
                                }
                            } else {
                                if (((uint64_t)var_480h <= (uint64_t)var_488h) && (var_480h == var_488h)) {
                                    iVar8 = var_488h - var_480h;
code_r0x00018009d04b:
                                    func_0x0001800890e0(&var_488h, iVar8 + 1, 0xffffffff);
                                }
code_r0x00018009d064:
                                *(undefined *)var_488h = *(undefined *)(uVar14 + iVar17);
                                var_488h = var_488h + 1;
                            }
                            uVar14 = uVar14 + 1;
                            iVar4 = (int32_t)var_4a0h;
                            cVar12 = var_4a8h;
                            iVar18 = var_4a0h._4_4_;
                        } while (uVar14 < uVar9);
                    }
                }
                var_4a4h = var_4a4h + 1;
                if (arg3 <= arg2) goto code_r0x00018009d2ba;
            }
            puVar11 = (undefined *)CONCAT44((undefined4)var_25ch, var_260h);
            arg2 = arg3;
            if ((cVar12 == '^') || (iVar18 <= var_4a4h)) goto code_r0x00018009d324;
        } while( true );
    }
code_r0x00018009d32e:
    iVar4 = var_4a4h;
    var_25ch._0_4_ = (undefined4)((uint64_t)puVar11 >> 0x20);
    var_260h = (int32_t)puVar11;
    uVar9 = (int64_t)stack0xfffffffffffffda8 - (int64_t)arg2;
    if ((uint64_t)(var_480h - var_488h) < uVar9) {
        func_0x0001800890e0(&var_488h, (uVar9 - var_480h) + var_488h, 0xffffffff);
        puVar11 = (undefined *)CONCAT44((undefined4)var_25ch, var_260h);
    }
    var_25ch._0_4_ = (undefined4)((uint64_t)puVar11 >> 0x20);
    var_260h = (int32_t)puVar11;
    func_0x000180498030(var_488h, arg2, uVar9);
    iVar17 = var_470h;
    iVar3 = var_478h;
    var_488h = var_488h + uVar9;
    if (var_470h == 0) {
        func_0x0001800867f0(var_478h, &var_468h, (var_488h - (int64_t)&var_488h) + -0x20);
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_478h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_478h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_478h, 1);
        }
        iVar8 = *(int64_t *)(iVar3 + 0x40);
        if (var_488h == var_480h) {
            uVar7 = func_0x00018009a7e0(iVar3, iVar17);
        } else {
            uVar7 = func_0x00018009a8e0(iVar3, iVar17 + 0x18, (var_488h - iVar17) + -0x18);
        }
        *(undefined8 *)(iVar8 + -0x10) = uVar7;
        *(undefined4 *)(iVar8 + -4) = 6;
    }
    func_0x0001800865e0(arg1, iVar4);
    func_0x000180459870(var_38h ^ (uint64_t)auStack_4c8);
    return;
code_r0x00018009d324:
    puVar11 = (undefined *)CONCAT44((undefined4)var_25ch, var_260h);
    arg1 = var_490h;
    goto code_r0x00018009d32e;
}

// ============================================================
// Function: FUN_18009d453
// Address: 0x18009d453
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_49ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_4a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_258h
// WARNING: [rz-ghidra] Detected overlap for variable var_260h

void fcn.18009cc80(int64_t arg1)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t *piVar6;
    undefined *arg3;
    undefined8 uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t *piVar10;
    undefined *puVar11;
    char cVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    int64_t iVar16;
    int64_t iVar17;
    int32_t iVar18;
    undefined *arg2;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_4c8 [32];
    char var_4a8h;
    int32_t var_4a4h;
    int64_t var_4a0h;
    int64_t var_498h;
    int64_t var_490h;
    int64_t var_488h;
    int64_t var_480h;
    int64_t var_478h;
    int64_t var_470h;
    int64_t var_468h;
    int64_t var_268h;
    int32_t var_260h;
    int64_t var_25ch;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_4c8;
    piVar10 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar6 = piVar10;
    if (piVar15 <= piVar10) {
        piVar6 = *(int64_t **)0x180782430;
    }
    var_490h = arg1;
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018009d453;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar10 = *(int64_t **)(arg1 + 0x28);
        piVar15 = *(int64_t **)(arg1 + 0x40);
        piVar6 = piVar10;
        if (piVar15 <= piVar10) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    arg2 = (undefined *)(*piVar6 + 0x18);
    if (arg2 == (undefined *)0x0) {
code_r0x00018009d453:
        fcn.180088470(arg1, 1, 6);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar1 = *(uint32_t *)(*piVar6 + 0x14);
    piVar6 = piVar10 + 2;
    if (piVar15 <= piVar10 + 2) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018009d467;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar10 = *(int64_t **)(arg1 + 0x28);
        piVar15 = *(int64_t **)(arg1 + 0x40);
        piVar6 = piVar10 + 2;
        if (piVar15 <= piVar10 + 2) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    var_498h = *piVar6 + 0x18;
    if (var_498h == 0) {
code_r0x00018009d467:
        fcn.180088470(arg1, 2, 6);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar9 = (uint64_t)*(uint32_t *)(*piVar6 + 0x14);
    iVar4 = -1;
    piVar6 = piVar10 + 4;
    if (piVar15 <= piVar10 + 4) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (piVar6 != *(int64_t **)0x180782430) {
        iVar4 = *(int32_t *)((int64_t)piVar6 + 0xc);
    }
    piVar6 = piVar10 + 6;
    if (piVar15 <= piVar10 + 6) {
        piVar6 = *(int64_t **)0x180782430;
    }
    var_4a0h._0_4_ = iVar4;
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) < 1)) {
        var_4a0h._4_4_ = uVar1 + 1;
    } else {
        var_4a0h._4_4_ = func_0x000180088860(arg1, 4);
    }
    if ((iVar4 != 3) && (2 < iVar4 - 6U)) {
        fcn.1800883d0(arg1, 3, 0x18063e728);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    var_488h = (int64_t)&var_468h;
    var_480h = (int64_t)&var_268h;
    var_4a4h = 0;
    cVar12 = *(char *)var_498h;
    var_470h = 0;
    if (cVar12 == '^') {
        var_498h = var_498h + 1;
        uVar9 = uVar9 - 1;
    }
    unique0x00003400 = arg2 + uVar1;
    var_250h = uVar9 + var_498h;
    var_268h._0_4_ = 200;
    var_4a8h = cVar12;
    var_478h = arg1;
    var_248h = arg1;
    iVar18 = var_4a0h._4_4_;
    puVar11 = arg2;
    if (0 < var_4a0h._4_4_) {
        do {
            var_25ch._0_4_ = (undefined4)((uint64_t)puVar11 >> 0x20);
            var_260h = (int32_t)puVar11;
            var_240h._0_4_ = 0;
            arg3 = (undefined *)fcn.18009bc70((int64_t)&var_268h, (int64_t)arg2, var_498h);
            iVar3 = var_248h;
            if (arg3 == (undefined *)0x0) {
code_r0x00018009d2ba:
                if (stack0xfffffffffffffda8 <= arg2) goto code_r0x00018009d324;
                if (((uint64_t)var_480h <= (uint64_t)var_488h) && (var_480h == var_488h)) {
                    func_0x0001800890e0(&var_488h, (var_488h - var_480h) + 1, 0xffffffff);
                }
                arg3 = arg2 + 1;
                *(undefined *)var_488h = *arg2;
                var_488h = var_488h + 1;
            } else {
                if (iVar4 == 7) {
                    if ((int32_t)var_240h < 1) {
                        puVar11 = arg2;
                        iVar17 = (int64_t)arg3 - (int64_t)arg2;
code_r0x00018009d1fe:
                        func_0x0001800867f0(var_248h, puVar11, iVar17);
                    } else {
                        if (var_230h == -1) {
                            fcn.180088560(var_248h, 0x18063e6f0);
                            pcVar2 = (code *)swi(3);
                            (*pcVar2)();
                            return;
                        }
                        if (var_230h != -2) {
                            puVar11 = (undefined *)CONCAT44(var_238h._4_4_, (int32_t)var_238h);
                            iVar17 = var_230h;
                            goto code_r0x00018009d1fe;
                        }
                        func_0x0001800865e0(var_248h, ((int32_t)var_238h - var_260h) + 1);
                    }
                    if ((*(uint8_t *)(iVar3 + 1) & 4) != 0) {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar3 + 0x20) + 0x18);
                        *(int64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x18) = iVar3;
                    }
                    piVar10 = (int64_t *)(*(int64_t *)(iVar3 + 0x28) + 0x20);
                    if (*(int64_t **)(iVar3 + 0x40) <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    piVar15 = *(int64_t **)(iVar3 + 0x40) + -2;
                    func_0x0001800a8490(iVar3, piVar10, piVar15, piVar15);
code_r0x00018009d249:
                    iVar17 = *(int64_t *)(iVar3 + 0x40);
                    piVar10 = (int64_t *)(iVar17 - 0x10);
                    if ((*(int32_t *)(iVar17 + -4) == 0) ||
                       ((*(int32_t *)(iVar17 + -4) == 1 && (*(int32_t *)piVar10 == 0)))) {
                        *(int64_t **)(iVar3 + 0x40) = piVar10;
                        func_0x0001800867f0(iVar3, arg2, (int64_t)arg3 - (int64_t)arg2);
                    } else if ((piVar10 == *(int64_t **)0x180782430) ||
                              ((*(int32_t *)(iVar17 + -4) != 6 && (*(int32_t *)(iVar17 + -4) != 3)))) {
                        uVar7 = func_0x000180088fa0(iVar3, 0xffffffff);
                        fcn.180088560(iVar3, 0x18063e740, uVar7);
                        pcVar2 = (code *)swi(3);
                        (*pcVar2)();
                        return;
                    }
                    func_0x0001800891f0(&var_488h);
                } else {
                    if (iVar4 == 8) {
                        func_0x000180085bf0(var_248h, 3);
                        uVar5 = fcn.18009c220((int64_t)&var_268h, (int64_t)arg2, (int64_t)arg3);
                        func_0x000180087810(iVar3, uVar5);
                        goto code_r0x00018009d249;
                    }
                    piVar10 = (int64_t *)(*(int64_t *)(var_248h + 0x28) + 0x20);
                    if (*(int64_t **)(var_248h + 0x40) <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if (*(int32_t *)((int64_t)piVar10 + 0xc) == 6) {
code_r0x00018009cf9b:
                        uVar9 = (uint64_t)*(uint32_t *)(*piVar10 + 0x14);
                        iVar17 = *piVar10 + 0x18;
                    } else {
                        if ((*(uint8_t *)(var_248h + 1) & 4) != 0) {
                            *(uint8_t *)(var_248h + 1) = *(uint8_t *)(var_248h + 1) & 0xfb;
                            *(undefined8 *)(var_248h + 0x48) = *(undefined8 *)(*(int64_t *)(var_248h + 0x20) + 0x18);
                            *(int64_t *)(*(int64_t *)(var_248h + 0x20) + 0x18) = var_248h;
                        }
                        iVar4 = func_0x0001800a8360(var_248h);
                        if (iVar4 != 0) {
                            if (*(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x28) <=
                                *(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x30)) {
                                (**(code **)0x180782658)(iVar3, 1);
                            }
                            piVar10 = (int64_t *)(*(int64_t *)(iVar3 + 0x28) + 0x20);
                            if (*(int64_t **)(iVar3 + 0x40) <= piVar10) {
                                piVar10 = *(int64_t **)0x180782430;
                            }
                            goto code_r0x00018009cf9b;
                        }
                        uVar9 = 0;
                        iVar17 = 0;
                    }
                    if ((uint64_t)(var_480h - var_488h) < uVar9) {
                        func_0x0001800890e0(&var_488h, (uVar9 - var_480h) + var_488h, 0xffffffff);
                    }
                    uVar14 = 0;
                    iVar4 = (int32_t)var_4a0h;
                    iVar18 = var_4a0h._4_4_;
                    if (uVar9 != 0) {
                        do {
                            if (*(char *)(uVar14 + iVar17) == '%') {
                                iVar8 = uVar14 + 1;
                                uVar14 = uVar14 + 1;
                                iVar4 = func_0x00018046cb80(*(undefined *)(iVar8 + iVar17));
                                cVar12 = *(char *)(uVar14 + iVar17);
                                if (iVar4 == 0) {
                                    if (cVar12 != '%') {
                                        fcn.180088560(iVar3, 0x18063e6b0, 0x25);
                                        pcVar2 = (code *)swi(3);
                                        (*pcVar2)();
                                        return;
                                    }
                                    if (((uint64_t)var_480h <= (uint64_t)var_488h) && (var_480h == var_488h)) {
                                        iVar8 = var_488h - var_480h;
                                        goto code_r0x00018009d04b;
                                    }
                                    goto code_r0x00018009d064;
                                }
                                if (cVar12 == '0') {
                                    uVar13 = (int64_t)arg3 - (int64_t)arg2;
                                    if ((uint64_t)(var_480h - var_488h) < uVar13) {
                                        func_0x0001800890e0(&var_488h, (uVar13 - var_480h) + var_488h, 0xffffffff);
                                    }
                                    func_0x000180498030(var_488h, arg2, uVar13);
                                    var_488h = var_488h + uVar13;
                                } else {
                                    if (cVar12 + -0x31 < (int32_t)var_240h) {
                                        iVar8 = (int64_t)cVar12 + -0x31;
                                        iVar16 = (&var_230h)[iVar8 * 2];
                                        if (iVar16 == -1) {
                                            fcn.180088560(iVar3, 0x18063e6f0);
                                            pcVar2 = (code *)swi(3);
                                            (*pcVar2)();
                                            return;
                                        }
                                        if (iVar16 != -2) {
                                            puVar11 = (undefined *)(&var_238h)[iVar8 * 2];
                                            goto code_r0x00018009d135;
                                        }
                                        func_0x0001800865e0(iVar3, (*(int32_t *)(&var_238h + iVar8 * 2) - var_260h) + 1)
                                        ;
                                    } else {
                                        if (cVar12 != 0x31) {
                                            fcn.180088560(iVar3, 0x18063e708);
                                            pcVar2 = (code *)swi(3);
                                            (*pcVar2)();
                                            return;
                                        }
                                        iVar16 = (int64_t)arg3 - (int64_t)arg2;
                                        puVar11 = arg2;
code_r0x00018009d135:
                                        func_0x0001800867f0(iVar3, puVar11, iVar16);
                                    }
                                    func_0x0001800891f0(&var_488h);
                                }
                            } else {
                                if (((uint64_t)var_480h <= (uint64_t)var_488h) && (var_480h == var_488h)) {
                                    iVar8 = var_488h - var_480h;
code_r0x00018009d04b:
                                    func_0x0001800890e0(&var_488h, iVar8 + 1, 0xffffffff);
                                }
code_r0x00018009d064:
                                *(undefined *)var_488h = *(undefined *)(uVar14 + iVar17);
                                var_488h = var_488h + 1;
                            }
                            uVar14 = uVar14 + 1;
                            iVar4 = (int32_t)var_4a0h;
                            cVar12 = var_4a8h;
                            iVar18 = var_4a0h._4_4_;
                        } while (uVar14 < uVar9);
                    }
                }
                var_4a4h = var_4a4h + 1;
                if (arg3 <= arg2) goto code_r0x00018009d2ba;
            }
            puVar11 = (undefined *)CONCAT44((undefined4)var_25ch, var_260h);
            arg2 = arg3;
            if ((cVar12 == '^') || (iVar18 <= var_4a4h)) goto code_r0x00018009d324;
        } while( true );
    }
code_r0x00018009d32e:
    iVar4 = var_4a4h;
    var_25ch._0_4_ = (undefined4)((uint64_t)puVar11 >> 0x20);
    var_260h = (int32_t)puVar11;
    uVar9 = (int64_t)stack0xfffffffffffffda8 - (int64_t)arg2;
    if ((uint64_t)(var_480h - var_488h) < uVar9) {
        func_0x0001800890e0(&var_488h, (uVar9 - var_480h) + var_488h, 0xffffffff);
        puVar11 = (undefined *)CONCAT44((undefined4)var_25ch, var_260h);
    }
    var_25ch._0_4_ = (undefined4)((uint64_t)puVar11 >> 0x20);
    var_260h = (int32_t)puVar11;
    func_0x000180498030(var_488h, arg2, uVar9);
    iVar17 = var_470h;
    iVar3 = var_478h;
    var_488h = var_488h + uVar9;
    if (var_470h == 0) {
        func_0x0001800867f0(var_478h, &var_468h, (var_488h - (int64_t)&var_488h) + -0x20);
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_478h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_478h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_478h, 1);
        }
        iVar8 = *(int64_t *)(iVar3 + 0x40);
        if (var_488h == var_480h) {
            uVar7 = func_0x00018009a7e0(iVar3, iVar17);
        } else {
            uVar7 = func_0x00018009a8e0(iVar3, iVar17 + 0x18, (var_488h - iVar17) + -0x18);
        }
        *(undefined8 *)(iVar8 + -0x10) = uVar7;
        *(undefined4 *)(iVar8 + -4) = 6;
    }
    func_0x0001800865e0(arg1, iVar4);
    func_0x000180459870(var_38h ^ (uint64_t)auStack_4c8);
    return;
code_r0x00018009d324:
    puVar11 = (undefined *)CONCAT44((undefined4)var_25ch, var_260h);
    arg1 = var_490h;
    goto code_r0x00018009d32e;
}

// ============================================================
// Function: FUN_18009d47b
// Address: 0x18009d47b
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_49ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_4a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_258h
// WARNING: [rz-ghidra] Detected overlap for variable var_260h

void fcn.18009cc80(int64_t arg1)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t *piVar6;
    undefined *arg3;
    undefined8 uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t *piVar10;
    undefined *puVar11;
    char cVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    int64_t iVar16;
    int64_t iVar17;
    int32_t iVar18;
    undefined *arg2;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_4c8 [32];
    char var_4a8h;
    int32_t var_4a4h;
    int64_t var_4a0h;
    int64_t var_498h;
    int64_t var_490h;
    int64_t var_488h;
    int64_t var_480h;
    int64_t var_478h;
    int64_t var_470h;
    int64_t var_468h;
    int64_t var_268h;
    int32_t var_260h;
    int64_t var_25ch;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_4c8;
    piVar10 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar6 = piVar10;
    if (piVar15 <= piVar10) {
        piVar6 = *(int64_t **)0x180782430;
    }
    var_490h = arg1;
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018009d453;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar10 = *(int64_t **)(arg1 + 0x28);
        piVar15 = *(int64_t **)(arg1 + 0x40);
        piVar6 = piVar10;
        if (piVar15 <= piVar10) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    arg2 = (undefined *)(*piVar6 + 0x18);
    if (arg2 == (undefined *)0x0) {
code_r0x00018009d453:
        fcn.180088470(arg1, 1, 6);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar1 = *(uint32_t *)(*piVar6 + 0x14);
    piVar6 = piVar10 + 2;
    if (piVar15 <= piVar10 + 2) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018009d467;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar10 = *(int64_t **)(arg1 + 0x28);
        piVar15 = *(int64_t **)(arg1 + 0x40);
        piVar6 = piVar10 + 2;
        if (piVar15 <= piVar10 + 2) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    var_498h = *piVar6 + 0x18;
    if (var_498h == 0) {
code_r0x00018009d467:
        fcn.180088470(arg1, 2, 6);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar9 = (uint64_t)*(uint32_t *)(*piVar6 + 0x14);
    iVar4 = -1;
    piVar6 = piVar10 + 4;
    if (piVar15 <= piVar10 + 4) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (piVar6 != *(int64_t **)0x180782430) {
        iVar4 = *(int32_t *)((int64_t)piVar6 + 0xc);
    }
    piVar6 = piVar10 + 6;
    if (piVar15 <= piVar10 + 6) {
        piVar6 = *(int64_t **)0x180782430;
    }
    var_4a0h._0_4_ = iVar4;
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) < 1)) {
        var_4a0h._4_4_ = uVar1 + 1;
    } else {
        var_4a0h._4_4_ = func_0x000180088860(arg1, 4);
    }
    if ((iVar4 != 3) && (2 < iVar4 - 6U)) {
        fcn.1800883d0(arg1, 3, 0x18063e728);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    var_488h = (int64_t)&var_468h;
    var_480h = (int64_t)&var_268h;
    var_4a4h = 0;
    cVar12 = *(char *)var_498h;
    var_470h = 0;
    if (cVar12 == '^') {
        var_498h = var_498h + 1;
        uVar9 = uVar9 - 1;
    }
    unique0x00003400 = arg2 + uVar1;
    var_250h = uVar9 + var_498h;
    var_268h._0_4_ = 200;
    var_4a8h = cVar12;
    var_478h = arg1;
    var_248h = arg1;
    iVar18 = var_4a0h._4_4_;
    puVar11 = arg2;
    if (0 < var_4a0h._4_4_) {
        do {
            var_25ch._0_4_ = (undefined4)((uint64_t)puVar11 >> 0x20);
            var_260h = (int32_t)puVar11;
            var_240h._0_4_ = 0;
            arg3 = (undefined *)fcn.18009bc70((int64_t)&var_268h, (int64_t)arg2, var_498h);
            iVar3 = var_248h;
            if (arg3 == (undefined *)0x0) {
code_r0x00018009d2ba:
                if (stack0xfffffffffffffda8 <= arg2) goto code_r0x00018009d324;
                if (((uint64_t)var_480h <= (uint64_t)var_488h) && (var_480h == var_488h)) {
                    func_0x0001800890e0(&var_488h, (var_488h - var_480h) + 1, 0xffffffff);
                }
                arg3 = arg2 + 1;
                *(undefined *)var_488h = *arg2;
                var_488h = var_488h + 1;
            } else {
                if (iVar4 == 7) {
                    if ((int32_t)var_240h < 1) {
                        puVar11 = arg2;
                        iVar17 = (int64_t)arg3 - (int64_t)arg2;
code_r0x00018009d1fe:
                        func_0x0001800867f0(var_248h, puVar11, iVar17);
                    } else {
                        if (var_230h == -1) {
                            fcn.180088560(var_248h, 0x18063e6f0);
                            pcVar2 = (code *)swi(3);
                            (*pcVar2)();
                            return;
                        }
                        if (var_230h != -2) {
                            puVar11 = (undefined *)CONCAT44(var_238h._4_4_, (int32_t)var_238h);
                            iVar17 = var_230h;
                            goto code_r0x00018009d1fe;
                        }
                        func_0x0001800865e0(var_248h, ((int32_t)var_238h - var_260h) + 1);
                    }
                    if ((*(uint8_t *)(iVar3 + 1) & 4) != 0) {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar3 + 0x20) + 0x18);
                        *(int64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x18) = iVar3;
                    }
                    piVar10 = (int64_t *)(*(int64_t *)(iVar3 + 0x28) + 0x20);
                    if (*(int64_t **)(iVar3 + 0x40) <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    piVar15 = *(int64_t **)(iVar3 + 0x40) + -2;
                    func_0x0001800a8490(iVar3, piVar10, piVar15, piVar15);
code_r0x00018009d249:
                    iVar17 = *(int64_t *)(iVar3 + 0x40);
                    piVar10 = (int64_t *)(iVar17 - 0x10);
                    if ((*(int32_t *)(iVar17 + -4) == 0) ||
                       ((*(int32_t *)(iVar17 + -4) == 1 && (*(int32_t *)piVar10 == 0)))) {
                        *(int64_t **)(iVar3 + 0x40) = piVar10;
                        func_0x0001800867f0(iVar3, arg2, (int64_t)arg3 - (int64_t)arg2);
                    } else if ((piVar10 == *(int64_t **)0x180782430) ||
                              ((*(int32_t *)(iVar17 + -4) != 6 && (*(int32_t *)(iVar17 + -4) != 3)))) {
                        uVar7 = func_0x000180088fa0(iVar3, 0xffffffff);
                        fcn.180088560(iVar3, 0x18063e740, uVar7);
                        pcVar2 = (code *)swi(3);
                        (*pcVar2)();
                        return;
                    }
                    func_0x0001800891f0(&var_488h);
                } else {
                    if (iVar4 == 8) {
                        func_0x000180085bf0(var_248h, 3);
                        uVar5 = fcn.18009c220((int64_t)&var_268h, (int64_t)arg2, (int64_t)arg3);
                        func_0x000180087810(iVar3, uVar5);
                        goto code_r0x00018009d249;
                    }
                    piVar10 = (int64_t *)(*(int64_t *)(var_248h + 0x28) + 0x20);
                    if (*(int64_t **)(var_248h + 0x40) <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if (*(int32_t *)((int64_t)piVar10 + 0xc) == 6) {
code_r0x00018009cf9b:
                        uVar9 = (uint64_t)*(uint32_t *)(*piVar10 + 0x14);
                        iVar17 = *piVar10 + 0x18;
                    } else {
                        if ((*(uint8_t *)(var_248h + 1) & 4) != 0) {
                            *(uint8_t *)(var_248h + 1) = *(uint8_t *)(var_248h + 1) & 0xfb;
                            *(undefined8 *)(var_248h + 0x48) = *(undefined8 *)(*(int64_t *)(var_248h + 0x20) + 0x18);
                            *(int64_t *)(*(int64_t *)(var_248h + 0x20) + 0x18) = var_248h;
                        }
                        iVar4 = func_0x0001800a8360(var_248h);
                        if (iVar4 != 0) {
                            if (*(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x28) <=
                                *(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x30)) {
                                (**(code **)0x180782658)(iVar3, 1);
                            }
                            piVar10 = (int64_t *)(*(int64_t *)(iVar3 + 0x28) + 0x20);
                            if (*(int64_t **)(iVar3 + 0x40) <= piVar10) {
                                piVar10 = *(int64_t **)0x180782430;
                            }
                            goto code_r0x00018009cf9b;
                        }
                        uVar9 = 0;
                        iVar17 = 0;
                    }
                    if ((uint64_t)(var_480h - var_488h) < uVar9) {
                        func_0x0001800890e0(&var_488h, (uVar9 - var_480h) + var_488h, 0xffffffff);
                    }
                    uVar14 = 0;
                    iVar4 = (int32_t)var_4a0h;
                    iVar18 = var_4a0h._4_4_;
                    if (uVar9 != 0) {
                        do {
                            if (*(char *)(uVar14 + iVar17) == '%') {
                                iVar8 = uVar14 + 1;
                                uVar14 = uVar14 + 1;
                                iVar4 = func_0x00018046cb80(*(undefined *)(iVar8 + iVar17));
                                cVar12 = *(char *)(uVar14 + iVar17);
                                if (iVar4 == 0) {
                                    if (cVar12 != '%') {
                                        fcn.180088560(iVar3, 0x18063e6b0, 0x25);
                                        pcVar2 = (code *)swi(3);
                                        (*pcVar2)();
                                        return;
                                    }
                                    if (((uint64_t)var_480h <= (uint64_t)var_488h) && (var_480h == var_488h)) {
                                        iVar8 = var_488h - var_480h;
                                        goto code_r0x00018009d04b;
                                    }
                                    goto code_r0x00018009d064;
                                }
                                if (cVar12 == '0') {
                                    uVar13 = (int64_t)arg3 - (int64_t)arg2;
                                    if ((uint64_t)(var_480h - var_488h) < uVar13) {
                                        func_0x0001800890e0(&var_488h, (uVar13 - var_480h) + var_488h, 0xffffffff);
                                    }
                                    func_0x000180498030(var_488h, arg2, uVar13);
                                    var_488h = var_488h + uVar13;
                                } else {
                                    if (cVar12 + -0x31 < (int32_t)var_240h) {
                                        iVar8 = (int64_t)cVar12 + -0x31;
                                        iVar16 = (&var_230h)[iVar8 * 2];
                                        if (iVar16 == -1) {
                                            fcn.180088560(iVar3, 0x18063e6f0);
                                            pcVar2 = (code *)swi(3);
                                            (*pcVar2)();
                                            return;
                                        }
                                        if (iVar16 != -2) {
                                            puVar11 = (undefined *)(&var_238h)[iVar8 * 2];
                                            goto code_r0x00018009d135;
                                        }
                                        func_0x0001800865e0(iVar3, (*(int32_t *)(&var_238h + iVar8 * 2) - var_260h) + 1)
                                        ;
                                    } else {
                                        if (cVar12 != 0x31) {
                                            fcn.180088560(iVar3, 0x18063e708);
                                            pcVar2 = (code *)swi(3);
                                            (*pcVar2)();
                                            return;
                                        }
                                        iVar16 = (int64_t)arg3 - (int64_t)arg2;
                                        puVar11 = arg2;
code_r0x00018009d135:
                                        func_0x0001800867f0(iVar3, puVar11, iVar16);
                                    }
                                    func_0x0001800891f0(&var_488h);
                                }
                            } else {
                                if (((uint64_t)var_480h <= (uint64_t)var_488h) && (var_480h == var_488h)) {
                                    iVar8 = var_488h - var_480h;
code_r0x00018009d04b:
                                    func_0x0001800890e0(&var_488h, iVar8 + 1, 0xffffffff);
                                }
code_r0x00018009d064:
                                *(undefined *)var_488h = *(undefined *)(uVar14 + iVar17);
                                var_488h = var_488h + 1;
                            }
                            uVar14 = uVar14 + 1;
                            iVar4 = (int32_t)var_4a0h;
                            cVar12 = var_4a8h;
                            iVar18 = var_4a0h._4_4_;
                        } while (uVar14 < uVar9);
                    }
                }
                var_4a4h = var_4a4h + 1;
                if (arg3 <= arg2) goto code_r0x00018009d2ba;
            }
            puVar11 = (undefined *)CONCAT44((undefined4)var_25ch, var_260h);
            arg2 = arg3;
            if ((cVar12 == '^') || (iVar18 <= var_4a4h)) goto code_r0x00018009d324;
        } while( true );
    }
code_r0x00018009d32e:
    iVar4 = var_4a4h;
    var_25ch._0_4_ = (undefined4)((uint64_t)puVar11 >> 0x20);
    var_260h = (int32_t)puVar11;
    uVar9 = (int64_t)stack0xfffffffffffffda8 - (int64_t)arg2;
    if ((uint64_t)(var_480h - var_488h) < uVar9) {
        func_0x0001800890e0(&var_488h, (uVar9 - var_480h) + var_488h, 0xffffffff);
        puVar11 = (undefined *)CONCAT44((undefined4)var_25ch, var_260h);
    }
    var_25ch._0_4_ = (undefined4)((uint64_t)puVar11 >> 0x20);
    var_260h = (int32_t)puVar11;
    func_0x000180498030(var_488h, arg2, uVar9);
    iVar17 = var_470h;
    iVar3 = var_478h;
    var_488h = var_488h + uVar9;
    if (var_470h == 0) {
        func_0x0001800867f0(var_478h, &var_468h, (var_488h - (int64_t)&var_488h) + -0x20);
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_478h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_478h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_478h, 1);
        }
        iVar8 = *(int64_t *)(iVar3 + 0x40);
        if (var_488h == var_480h) {
            uVar7 = func_0x00018009a7e0(iVar3, iVar17);
        } else {
            uVar7 = func_0x00018009a8e0(iVar3, iVar17 + 0x18, (var_488h - iVar17) + -0x18);
        }
        *(undefined8 *)(iVar8 + -0x10) = uVar7;
        *(undefined4 *)(iVar8 + -4) = 6;
    }
    func_0x0001800865e0(arg1, iVar4);
    func_0x000180459870(var_38h ^ (uint64_t)auStack_4c8);
    return;
code_r0x00018009d324:
    puVar11 = (undefined *)CONCAT44((undefined4)var_25ch, var_260h);
    arg1 = var_490h;
    goto code_r0x00018009d32e;
}

// ============================================================
// Function: FUN_18009d490
// Address: 0x18009d490
// Size: 96 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_49ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_4a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_258h
// WARNING: [rz-ghidra] Detected overlap for variable var_260h

void fcn.18009cc80(int64_t arg1)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t *piVar6;
    undefined *arg3;
    undefined8 uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t *piVar10;
    undefined *puVar11;
    char cVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    int64_t iVar16;
    int64_t iVar17;
    int32_t iVar18;
    undefined *arg2;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_4c8 [32];
    char var_4a8h;
    int32_t var_4a4h;
    int64_t var_4a0h;
    int64_t var_498h;
    int64_t var_490h;
    int64_t var_488h;
    int64_t var_480h;
    int64_t var_478h;
    int64_t var_470h;
    int64_t var_468h;
    int64_t var_268h;
    int32_t var_260h;
    int64_t var_25ch;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_4c8;
    piVar10 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar6 = piVar10;
    if (piVar15 <= piVar10) {
        piVar6 = *(int64_t **)0x180782430;
    }
    var_490h = arg1;
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018009d453;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar10 = *(int64_t **)(arg1 + 0x28);
        piVar15 = *(int64_t **)(arg1 + 0x40);
        piVar6 = piVar10;
        if (piVar15 <= piVar10) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    arg2 = (undefined *)(*piVar6 + 0x18);
    if (arg2 == (undefined *)0x0) {
code_r0x00018009d453:
        fcn.180088470(arg1, 1, 6);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar1 = *(uint32_t *)(*piVar6 + 0x14);
    piVar6 = piVar10 + 2;
    if (piVar15 <= piVar10 + 2) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018009d467;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar10 = *(int64_t **)(arg1 + 0x28);
        piVar15 = *(int64_t **)(arg1 + 0x40);
        piVar6 = piVar10 + 2;
        if (piVar15 <= piVar10 + 2) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    var_498h = *piVar6 + 0x18;
    if (var_498h == 0) {
code_r0x00018009d467:
        fcn.180088470(arg1, 2, 6);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar9 = (uint64_t)*(uint32_t *)(*piVar6 + 0x14);
    iVar4 = -1;
    piVar6 = piVar10 + 4;
    if (piVar15 <= piVar10 + 4) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (piVar6 != *(int64_t **)0x180782430) {
        iVar4 = *(int32_t *)((int64_t)piVar6 + 0xc);
    }
    piVar6 = piVar10 + 6;
    if (piVar15 <= piVar10 + 6) {
        piVar6 = *(int64_t **)0x180782430;
    }
    var_4a0h._0_4_ = iVar4;
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) < 1)) {
        var_4a0h._4_4_ = uVar1 + 1;
    } else {
        var_4a0h._4_4_ = func_0x000180088860(arg1, 4);
    }
    if ((iVar4 != 3) && (2 < iVar4 - 6U)) {
        fcn.1800883d0(arg1, 3, 0x18063e728);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    var_488h = (int64_t)&var_468h;
    var_480h = (int64_t)&var_268h;
    var_4a4h = 0;
    cVar12 = *(char *)var_498h;
    var_470h = 0;
    if (cVar12 == '^') {
        var_498h = var_498h + 1;
        uVar9 = uVar9 - 1;
    }
    unique0x00003400 = arg2 + uVar1;
    var_250h = uVar9 + var_498h;
    var_268h._0_4_ = 200;
    var_4a8h = cVar12;
    var_478h = arg1;
    var_248h = arg1;
    iVar18 = var_4a0h._4_4_;
    puVar11 = arg2;
    if (0 < var_4a0h._4_4_) {
        do {
            var_25ch._0_4_ = (undefined4)((uint64_t)puVar11 >> 0x20);
            var_260h = (int32_t)puVar11;
            var_240h._0_4_ = 0;
            arg3 = (undefined *)fcn.18009bc70((int64_t)&var_268h, (int64_t)arg2, var_498h);
            iVar3 = var_248h;
            if (arg3 == (undefined *)0x0) {
code_r0x00018009d2ba:
                if (stack0xfffffffffffffda8 <= arg2) goto code_r0x00018009d324;
                if (((uint64_t)var_480h <= (uint64_t)var_488h) && (var_480h == var_488h)) {
                    func_0x0001800890e0(&var_488h, (var_488h - var_480h) + 1, 0xffffffff);
                }
                arg3 = arg2 + 1;
                *(undefined *)var_488h = *arg2;
                var_488h = var_488h + 1;
            } else {
                if (iVar4 == 7) {
                    if ((int32_t)var_240h < 1) {
                        puVar11 = arg2;
                        iVar17 = (int64_t)arg3 - (int64_t)arg2;
code_r0x00018009d1fe:
                        func_0x0001800867f0(var_248h, puVar11, iVar17);
                    } else {
                        if (var_230h == -1) {
                            fcn.180088560(var_248h, 0x18063e6f0);
                            pcVar2 = (code *)swi(3);
                            (*pcVar2)();
                            return;
                        }
                        if (var_230h != -2) {
                            puVar11 = (undefined *)CONCAT44(var_238h._4_4_, (int32_t)var_238h);
                            iVar17 = var_230h;
                            goto code_r0x00018009d1fe;
                        }
                        func_0x0001800865e0(var_248h, ((int32_t)var_238h - var_260h) + 1);
                    }
                    if ((*(uint8_t *)(iVar3 + 1) & 4) != 0) {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar3 + 0x20) + 0x18);
                        *(int64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x18) = iVar3;
                    }
                    piVar10 = (int64_t *)(*(int64_t *)(iVar3 + 0x28) + 0x20);
                    if (*(int64_t **)(iVar3 + 0x40) <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    piVar15 = *(int64_t **)(iVar3 + 0x40) + -2;
                    func_0x0001800a8490(iVar3, piVar10, piVar15, piVar15);
code_r0x00018009d249:
                    iVar17 = *(int64_t *)(iVar3 + 0x40);
                    piVar10 = (int64_t *)(iVar17 - 0x10);
                    if ((*(int32_t *)(iVar17 + -4) == 0) ||
                       ((*(int32_t *)(iVar17 + -4) == 1 && (*(int32_t *)piVar10 == 0)))) {
                        *(int64_t **)(iVar3 + 0x40) = piVar10;
                        func_0x0001800867f0(iVar3, arg2, (int64_t)arg3 - (int64_t)arg2);
                    } else if ((piVar10 == *(int64_t **)0x180782430) ||
                              ((*(int32_t *)(iVar17 + -4) != 6 && (*(int32_t *)(iVar17 + -4) != 3)))) {
                        uVar7 = func_0x000180088fa0(iVar3, 0xffffffff);
                        fcn.180088560(iVar3, 0x18063e740, uVar7);
                        pcVar2 = (code *)swi(3);
                        (*pcVar2)();
                        return;
                    }
                    func_0x0001800891f0(&var_488h);
                } else {
                    if (iVar4 == 8) {
                        func_0x000180085bf0(var_248h, 3);
                        uVar5 = fcn.18009c220((int64_t)&var_268h, (int64_t)arg2, (int64_t)arg3);
                        func_0x000180087810(iVar3, uVar5);
                        goto code_r0x00018009d249;
                    }
                    piVar10 = (int64_t *)(*(int64_t *)(var_248h + 0x28) + 0x20);
                    if (*(int64_t **)(var_248h + 0x40) <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if (*(int32_t *)((int64_t)piVar10 + 0xc) == 6) {
code_r0x00018009cf9b:
                        uVar9 = (uint64_t)*(uint32_t *)(*piVar10 + 0x14);
                        iVar17 = *piVar10 + 0x18;
                    } else {
                        if ((*(uint8_t *)(var_248h + 1) & 4) != 0) {
                            *(uint8_t *)(var_248h + 1) = *(uint8_t *)(var_248h + 1) & 0xfb;
                            *(undefined8 *)(var_248h + 0x48) = *(undefined8 *)(*(int64_t *)(var_248h + 0x20) + 0x18);
                            *(int64_t *)(*(int64_t *)(var_248h + 0x20) + 0x18) = var_248h;
                        }
                        iVar4 = func_0x0001800a8360(var_248h);
                        if (iVar4 != 0) {
                            if (*(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x28) <=
                                *(uint64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x30)) {
                                (**(code **)0x180782658)(iVar3, 1);
                            }
                            piVar10 = (int64_t *)(*(int64_t *)(iVar3 + 0x28) + 0x20);
                            if (*(int64_t **)(iVar3 + 0x40) <= piVar10) {
                                piVar10 = *(int64_t **)0x180782430;
                            }
                            goto code_r0x00018009cf9b;
                        }
                        uVar9 = 0;
                        iVar17 = 0;
                    }
                    if ((uint64_t)(var_480h - var_488h) < uVar9) {
                        func_0x0001800890e0(&var_488h, (uVar9 - var_480h) + var_488h, 0xffffffff);
                    }
                    uVar14 = 0;
                    iVar4 = (int32_t)var_4a0h;
                    iVar18 = var_4a0h._4_4_;
                    if (uVar9 != 0) {
                        do {
                            if (*(char *)(uVar14 + iVar17) == '%') {
                                iVar8 = uVar14 + 1;
                                uVar14 = uVar14 + 1;
                                iVar4 = func_0x00018046cb80(*(undefined *)(iVar8 + iVar17));
                                cVar12 = *(char *)(uVar14 + iVar17);
                                if (iVar4 == 0) {
                                    if (cVar12 != '%') {
                                        fcn.180088560(iVar3, 0x18063e6b0, 0x25);
                                        pcVar2 = (code *)swi(3);
                                        (*pcVar2)();
                                        return;
                                    }
                                    if (((uint64_t)var_480h <= (uint64_t)var_488h) && (var_480h == var_488h)) {
                                        iVar8 = var_488h - var_480h;
                                        goto code_r0x00018009d04b;
                                    }
                                    goto code_r0x00018009d064;
                                }
                                if (cVar12 == '0') {
                                    uVar13 = (int64_t)arg3 - (int64_t)arg2;
                                    if ((uint64_t)(var_480h - var_488h) < uVar13) {
                                        func_0x0001800890e0(&var_488h, (uVar13 - var_480h) + var_488h, 0xffffffff);
                                    }
                                    func_0x000180498030(var_488h, arg2, uVar13);
                                    var_488h = var_488h + uVar13;
                                } else {
                                    if (cVar12 + -0x31 < (int32_t)var_240h) {
                                        iVar8 = (int64_t)cVar12 + -0x31;
                                        iVar16 = (&var_230h)[iVar8 * 2];
                                        if (iVar16 == -1) {
                                            fcn.180088560(iVar3, 0x18063e6f0);
                                            pcVar2 = (code *)swi(3);
                                            (*pcVar2)();
                                            return;
                                        }
                                        if (iVar16 != -2) {
                                            puVar11 = (undefined *)(&var_238h)[iVar8 * 2];
                                            goto code_r0x00018009d135;
                                        }
                                        func_0x0001800865e0(iVar3, (*(int32_t *)(&var_238h + iVar8 * 2) - var_260h) + 1)
                                        ;
                                    } else {
                                        if (cVar12 != 0x31) {
                                            fcn.180088560(iVar3, 0x18063e708);
                                            pcVar2 = (code *)swi(3);
                                            (*pcVar2)();
                                            return;
                                        }
                                        iVar16 = (int64_t)arg3 - (int64_t)arg2;
                                        puVar11 = arg2;
code_r0x00018009d135:
                                        func_0x0001800867f0(iVar3, puVar11, iVar16);
                                    }
                                    func_0x0001800891f0(&var_488h);
                                }
                            } else {
                                if (((uint64_t)var_480h <= (uint64_t)var_488h) && (var_480h == var_488h)) {
                                    iVar8 = var_488h - var_480h;
code_r0x00018009d04b:
                                    func_0x0001800890e0(&var_488h, iVar8 + 1, 0xffffffff);
                                }
code_r0x00018009d064:
                                *(undefined *)var_488h = *(undefined *)(uVar14 + iVar17);
                                var_488h = var_488h + 1;
                            }
                            uVar14 = uVar14 + 1;
                            iVar4 = (int32_t)var_4a0h;
                            cVar12 = var_4a8h;
                            iVar18 = var_4a0h._4_4_;
                        } while (uVar14 < uVar9);
                    }
                }
                var_4a4h = var_4a4h + 1;
                if (arg3 <= arg2) goto code_r0x00018009d2ba;
            }
            puVar11 = (undefined *)CONCAT44((undefined4)var_25ch, var_260h);
            arg2 = arg3;
            if ((cVar12 == '^') || (iVar18 <= var_4a4h)) goto code_r0x00018009d324;
        } while( true );
    }
code_r0x00018009d32e:
    iVar4 = var_4a4h;
    var_25ch._0_4_ = (undefined4)((uint64_t)puVar11 >> 0x20);
    var_260h = (int32_t)puVar11;
    uVar9 = (int64_t)stack0xfffffffffffffda8 - (int64_t)arg2;
    if ((uint64_t)(var_480h - var_488h) < uVar9) {
        func_0x0001800890e0(&var_488h, (uVar9 - var_480h) + var_488h, 0xffffffff);
        puVar11 = (undefined *)CONCAT44((undefined4)var_25ch, var_260h);
    }
    var_25ch._0_4_ = (undefined4)((uint64_t)puVar11 >> 0x20);
    var_260h = (int32_t)puVar11;
    func_0x000180498030(var_488h, arg2, uVar9);
    iVar17 = var_470h;
    iVar3 = var_478h;
    var_488h = var_488h + uVar9;
    if (var_470h == 0) {
        func_0x0001800867f0(var_478h, &var_468h, (var_488h - (int64_t)&var_488h) + -0x20);
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_478h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_478h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_478h, 1);
        }
        iVar8 = *(int64_t *)(iVar3 + 0x40);
        if (var_488h == var_480h) {
            uVar7 = func_0x00018009a7e0(iVar3, iVar17);
        } else {
            uVar7 = func_0x00018009a8e0(iVar3, iVar17 + 0x18, (var_488h - iVar17) + -0x18);
        }
        *(undefined8 *)(iVar8 + -0x10) = uVar7;
        *(undefined4 *)(iVar8 + -4) = 6;
    }
    func_0x0001800865e0(arg1, iVar4);
    func_0x000180459870(var_38h ^ (uint64_t)auStack_4c8);
    return;
code_r0x00018009d324:
    puVar11 = (undefined *)CONCAT44((undefined4)var_25ch, var_260h);
    arg1 = var_490h;
    goto code_r0x00018009d32e;
}

// ============================================================
// Function: FUN_18009d4f0
// Address: 0x18009d4f0
// Size: 92 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_2b7h
// WARNING: [rz-ghidra] Detected overlap for variable var_2b6h
// WARNING: [rz-ghidra] Removing arg arg_6824h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_518h
// WARNING: [rz-ghidra] Detected overlap for variable var_510h
// WARNING: [rz-ghidra] Detected overlap for variable var_50ch
// WARNING: [rz-ghidra] Detected overlap for variable var_508h

void fcn.18009d4f0(int64_t arg1)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    char *pcVar4;
    uint64_t uVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    char *pcVar8;
    int64_t iVar9;
    int64_t *piVar10;
    uint32_t uVar11;
    int64_t iVar13;
    uint64_t uVar14;
    int64_t iVar15;
    char *pcVar16;
    undefined4 uVar17;
    double dVar18;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_548 [32];
    int64_t var_528h;
    int64_t var_520h;
    int32_t var_518h;
    int64_t var_514h;
    int32_t var_50ch;
    uint64_t var_508h;
    int64_t var_500h;
    int64_t var_4f8h;
    int64_t var_4f0h;
    int64_t var_4e8h;
    int64_t var_4d8h;
    int64_t var_4d0h;
    int64_t var_4c8h;
    int64_t var_4c0h;
    int64_t var_4b8h;
    int64_t var_2b8h;
    int64_t var_298h;
    int64_t var_278h;
    int64_t var_248h;
    int64_t var_48h;
    int64_t var_38h;
    uint64_t uVar12;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_548;
    iVar9 = *(int64_t *)(arg1 + 0x40);
    iVar15 = *(int64_t *)(arg1 + 0x28);
    var_500h = arg1;
    pcVar4 = (char *)func_0x0001800860c0(arg1, 1, &var_520h);
    if (pcVar4 == (char *)0x0) {
        fcn.180088470(arg1, 1, 6);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    piVar10 = &var_4b8h;
    var_4d0h = (int64_t)&var_2b8h;
    iVar9 = iVar9 - iVar15 >> 4;
    var_4f0h = (int64_t)(pcVar4 + var_520h);
    uVar14 = 1;
    var_4c0h = 0;
    var_528h = iVar9;
    var_4d8h = (int64_t)piVar10;
    var_4c8h = arg1;
    if (pcVar4 < (uint64_t)var_4f0h) {
        do {
            if (*pcVar4 != '%') {
                if (((uint64_t)var_4d0h <= piVar10) && ((int64_t *)var_4d0h == piVar10)) {
                    func_0x0001800890e0(&var_4d8h, (int64_t)piVar10 + (1 - var_4d0h));
                    piVar10 = (int64_t *)var_4d8h;
                }
                cVar2 = *pcVar4;
                pcVar4 = pcVar4 + 1;
                *(char *)piVar10 = cVar2;
                piVar10 = (int64_t *)(var_4d8h + 1);
                var_4d8h = (int64_t)piVar10;
                goto code_r0x00018009dffd;
            }
            cVar2 = pcVar4[1];
            pcVar16 = pcVar4 + 1;
            if (cVar2 == '%') {
                if (((uint64_t)var_4d0h <= piVar10) && ((int64_t *)var_4d0h == piVar10)) {
                    func_0x0001800890e0(&var_4d8h, (int64_t)piVar10 + (1 - var_4d0h));
                    piVar10 = (int64_t *)var_4d8h;
                }
                pcVar4 = pcVar4 + 2;
                *(char *)piVar10 = *pcVar16;
                piVar10 = (int64_t *)(var_4d8h + 1);
                var_4d8h = (int64_t)piVar10;
                goto code_r0x00018009dffd;
            }
            iVar15 = (int64_t)(int32_t)uVar14;
            uVar11 = (int32_t)uVar14 + 1;
            uVar12 = (uint64_t)uVar11;
            if (cVar2 == '*') {
                if ((int32_t)iVar9 < (int32_t)uVar11) {
                    fcn.180088560(arg1, 0x18063da20, uVar12);
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                pcVar4 = pcVar4 + 2;
                uVar7 = uVar12;
                iVar13 = var_4c8h;
                if ((int32_t)uVar11 < 1) {
                    if ((int32_t)uVar11 < -9999) {
                        uVar5 = fcn.180085370(var_4c8h, uVar12);
                        piVar10 = (int64_t *)var_4d8h;
                    } else {
                        uVar5 = (int64_t)(int32_t)uVar11 * 0x10 + *(int64_t *)(var_4c8h + 0x40);
                    }
                } else {
                    uVar5 = *(int64_t *)(var_4c8h + 0x28) + iVar15 * 0x10;
                    if (*(uint64_t *)(var_4c8h + 0x40) <= uVar5) {
                        uVar5 = *(uint64_t *)0x180782430;
                    }
                }
                uVar14 = uVar12;
                if (uVar5 == *(uint64_t *)0x180782430) goto code_r0x00018009dffd;
    // switch table (8 cases) at 0x18009e16c
                switch(*(undefined4 *)(uVar5 + 0xc)) {
                case 0:
                    if ((uint64_t)(var_4d0h - (int64_t)piVar10) < 3) {
                        func_0x0001800890e0(&var_4d8h, (int64_t)piVar10 + (3 - var_4d0h));
                        piVar10 = (int64_t *)var_4d8h;
                    }
                    *(undefined2 *)piVar10 = 0x696e;
                    *(undefined *)((int64_t)piVar10 + 2) = 0x6c;
                    piVar10 = (int64_t *)(var_4d8h + 3);
                    var_4d8h = (int64_t)piVar10;
                    break;
                case 1:
                    iVar3 = func_0x000180085ff0(iVar13, uVar7 & 0xffffffff);
                    if (iVar3 == 0) {
                        if ((uint64_t)(var_4d0h - var_4d8h) < 5) {
                            func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 5);
                        }
                        *(undefined4 *)var_4d8h = 0x736c6166;
                        *(undefined *)(var_4d8h + 4) = 0x65;
                        piVar10 = (int64_t *)(var_4d8h + 5);
                        var_4d8h = (int64_t)piVar10;
                    } else {
                        if ((uint64_t)(var_4d0h - var_4d8h) < 4) {
                            func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 4);
                        }
                        *(undefined4 *)var_4d8h = 0x65757274;
                        piVar10 = (int64_t *)(var_4d8h + 4);
                        var_4d8h = (int64_t)piVar10;
                    }
                    break;
                default:
                    func_0x0001800893a0(iVar13, uVar7 & 0xffffffff);
                    func_0x0001800891f0(&var_4d8h);
                    piVar10 = (int64_t *)var_4d8h;
                    break;
                case 3:
                    uVar17 = func_0x000180085ea0(iVar13, uVar7 & 0xffffffff, 0);
                    iVar15 = func_0x000180098ac0(&var_278h, uVar17);
                    uVar7 = iVar15 - (int64_t)&var_278h;
                    if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                        func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                    }
                    func_0x000180498030(var_4d8h, &var_278h);
                    goto code_r0x00018009dff0;
                case 4:
                    uVar6 = func_0x000180086060(iVar13, uVar7 & 0xffffffff);
                    iVar15 = func_0x000180099080(&var_298h, uVar6);
                    uVar7 = iVar15 - (int64_t)&var_298h;
                    if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                        func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                    }
                    func_0x000180498030(var_4d8h, &var_298h, uVar7);
                    goto code_r0x00018009dff0;
                case 6:
                    piVar10 = (int64_t *)func_0x0001800860c0(iVar13, uVar7 & 0xffffffff, &var_508h);
                    uVar7 = var_508h;
                    if ((uint64_t)(var_4d0h - var_4d8h) < var_508h) {
                        func_0x0001800890e0(&var_4d8h, (var_508h - var_4d0h) + var_4d8h, 0xffffffff);
                    }
                    goto code_r0x00018009dfe3;
                case 0xffffffff:
                    break;
                }
                goto code_r0x00018009dffd;
            }
            uVar14 = (uint64_t)(int32_t)uVar11;
            pcVar4 = pcVar16;
            if ((int32_t)iVar9 < (int32_t)uVar11) {
                fcn.180088560(arg1, 0x18063da20, uVar12);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            while (uVar17 = (undefined4)((uint64_t)piVar10 >> 0x20), cVar2 != '\0') {
                iVar9 = func_0x00018045b928(0x18063e720, (int32_t)cVar2);
                uVar17 = (undefined4)((uint64_t)piVar10 >> 0x20);
                if (iVar9 == 0) break;
                cVar2 = pcVar4[1];
                pcVar4 = pcVar4 + 1;
            }
            if (5 < (uint64_t)((int64_t)pcVar4 - (int64_t)pcVar16)) {
                fcn.180088560(arg1, 0x18063e7e0);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            iVar3 = func_0x00018046cb80(*pcVar4);
            pcVar8 = pcVar4 + 1;
            if (iVar3 == 0) {
                pcVar8 = pcVar4;
            }
            iVar3 = func_0x00018046cb80(*pcVar8);
            pcVar4 = pcVar8 + 1;
            if (iVar3 == 0) {
                pcVar4 = pcVar8;
            }
            cVar2 = *pcVar4;
            if (cVar2 == '.') {
                iVar3 = func_0x00018046cb80(pcVar4[1]);
                pcVar8 = pcVar4 + (uint64_t)(iVar3 != 0) + 1;
                iVar3 = func_0x00018046cb80(*pcVar8);
                pcVar4 = pcVar8 + 1;
                if (iVar3 == 0) {
                    pcVar4 = pcVar8;
                }
                cVar2 = *pcVar4;
            }
            iVar3 = func_0x00018046cb80(cVar2);
            if (iVar3 != 0) {
                fcn.180088560(arg1, 0x18063e7b0);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            var_2b8h._0_1_ = 0x25;
            iVar9 = (int64_t)pcVar4 - (int64_t)pcVar16;
            func_0x000180498d90((int64_t)&var_2b8h + 1, pcVar16, (int32_t)iVar9 + 1);
            *(undefined *)((int64_t)&var_2b8h + iVar9 + 2) = 0;
            cVar2 = *pcVar4;
            iVar3 = (int32_t)cVar2;
            pcVar4 = pcVar4 + 1;
    // switch table (79 cases) at 0x18009e18c
            switch(iVar3) {
            case 0x2a:
                fcn.180088560(arg1, 0x18063e790);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            default:
                fcn.180088560(arg1, 0x18063e768);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            case 0x45:
            case 0x47:
            case 0x65:
            case 0x66:
            case 0x67:
                uVar17 = func_0x000180085ea0(arg1, uVar12, &var_50ch);
                if (var_50ch == 0) {
code_r0x00018009e0f4:
                    fcn.180088470(arg1, uVar12, 3);
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                func_0x000180065f60(&var_248h, 0x200, &var_2b8h, uVar17);
                goto code_r0x00018009df5f;
            case 0x58:
            case 0x6f:
            case 0x75:
            case 0x78:
                uVar7 = *(uint64_t *)0x180782430;
                if ((int32_t)uVar11 < 1) {
                    if ((int32_t)uVar11 < -9999) {
                        uVar5 = fcn.180085370(arg1, uVar12, iVar3);
                    } else {
                        uVar5 = uVar14 * 0x10 + *(int64_t *)(arg1 + 0x40);
                    }
                } else {
                    uVar5 = *(int64_t *)(arg1 + 0x28) + iVar15 * 0x10;
                    if (*(uint64_t *)(arg1 + 0x40) <= uVar5) {
                        uVar5 = *(uint64_t *)0x180782430;
                    }
                }
                if ((uVar5 == uVar7) || (*(int32_t *)(uVar5 + 0xc) != 4)) {
                    dVar18 = (double)func_0x000180085ea0(arg1, uVar12, (int64_t)&var_514h + 4);
                    if (var_514h._4_4_ == 0) goto code_r0x00018009e0f4;
                    if (0.0 <= dVar18) {
                        iVar15 = 0;
                        if ((9.223372036854776e+18 <= dVar18) &&
                           (dVar18 = dVar18 - 9.223372036854776e+18, dVar18 < 9.223372036854776e+18)) {
                            iVar15 = -0x8000000000000000;
                        }
                        piVar10 = (int64_t *)((int64_t)dVar18 + iVar15);
                    } else {
                        piVar10 = (int64_t *)(int64_t)dVar18;
                    }
                } else {
                    piVar10 = (int64_t *)func_0x000180088910(arg1, uVar12);
                }
                *(undefined2 *)((int64_t)&var_2b8h + iVar9 + 1) = 0x6c6c;
                *(char *)((int64_t)&var_2b8h + iVar9 + 3) = cVar2;
                *(undefined *)((int64_t)&var_2b8h + iVar9 + 4) = 0;
                goto code_r0x00018009df47;
            case 99:
                dVar18 = (double)func_0x000180085ea0(arg1, uVar12, &var_518h);
                if (var_518h == 0) goto code_r0x00018009e0f4;
                iVar3 = func_0x000180065f60(&var_248h, 0x200, &var_2b8h, CONCAT44(uVar17, (int32_t)dVar18));
                uVar7 = (uint64_t)iVar3;
                if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                    func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                }
                piVar10 = &var_248h;
                uVar12 = uVar14;
                break;
            case 100:
            case 0x69:
                uVar7 = *(uint64_t *)0x180782430;
                if ((int32_t)uVar11 < 1) {
                    if ((int32_t)uVar11 < -9999) {
                        uVar5 = fcn.180085370(arg1, uVar12, iVar3);
                    } else {
                        uVar5 = uVar14 * 0x10 + *(int64_t *)(arg1 + 0x40);
                    }
                } else {
                    uVar5 = *(int64_t *)(arg1 + 0x28) + iVar15 * 0x10;
                    if (*(uint64_t *)(arg1 + 0x40) <= uVar5) {
                        uVar5 = *(uint64_t *)0x180782430;
                    }
                }
                if ((uVar5 == uVar7) || (*(int32_t *)(uVar5 + 0xc) != 4)) {
                    dVar18 = (double)func_0x000180085ea0(arg1, uVar12, &var_514h);
                    if ((int32_t)var_514h == 0) goto code_r0x00018009e0f4;
                    piVar10 = (int64_t *)(int64_t)dVar18;
                } else {
                    piVar10 = (int64_t *)func_0x000180088910(arg1, uVar12);
                }
                *(undefined2 *)((int64_t)&var_2b8h + iVar9 + 1) = 0x6c6c;
                *(char *)((int64_t)&var_2b8h + iVar9 + 3) = cVar2;
                *(undefined *)((int64_t)&var_2b8h + iVar9 + 4) = 0;
code_r0x00018009df47:
                func_0x000180065f60(&var_248h, 0x200, &var_2b8h, piVar10);
code_r0x00018009df5f:
                uVar7 = func_0x000180498cd0(&var_248h);
                if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                    func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                }
                piVar10 = &var_248h;
                uVar12 = uVar14;
                break;
            case 0x71:
                pcVar16 = (char *)func_0x0001800860c0(arg1, uVar12, &var_520h);
                iVar9 = var_520h;
                if (pcVar16 == (char *)0x0) {
code_r0x00018009e106:
                    fcn.180088470(arg1, uVar12, 6);
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                if ((uint64_t)(var_4d0h - var_4d8h) < var_520h + 2U) {
                    func_0x0001800890e0(&var_4d8h, var_4d8h + ((var_520h + 2U) - var_4d0h), 0xffffffff);
                }
                if (((uint64_t)var_4d0h <= (uint64_t)var_4d8h) && (var_4d0h == var_4d8h)) {
                    func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                }
                *(undefined *)var_4d8h = 0x22;
                var_4d8h = var_4d8h + 1;
                if (iVar9 != 0) {
                    do {
                        cVar2 = *pcVar16;
                        iVar9 = iVar9 + -1;
                        if (cVar2 == '\0') {
                            if ((uint64_t)(var_4d0h - var_4d8h) < 4) {
                                func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 4, 0xffffffff);
                            }
                            *(undefined4 *)var_4d8h = 0x3030305c;
                            var_4d8h = var_4d8h + 4;
                        } else if (cVar2 == '\n') {
code_r0x00018009ddce:
                            if (((uint64_t)var_4d0h <= (uint64_t)var_4d8h) && (var_4d0h == var_4d8h)) {
                                func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                            }
                            *(undefined *)var_4d8h = 0x5c;
                            var_4d8h = var_4d8h + 1;
                            if (((uint64_t)var_4d8h < (uint64_t)var_4d0h) || (var_4d0h != var_4d8h)) {
code_r0x00018009dd7c:
                                *(char *)var_4d8h = *pcVar16;
                                var_4d8h = var_4d8h + 1;
                            } else {
                                func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                                *(char *)var_4d8h = *pcVar16;
                                var_4d8h = var_4d8h + 1;
                            }
                        } else {
                            if (cVar2 != '\r') {
                                if ((cVar2 == '\"') || (cVar2 == '\\')) goto code_r0x00018009ddce;
                                if (((uint64_t)var_4d0h <= (uint64_t)var_4d8h) && (var_4d0h == var_4d8h)) {
                                    func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                                }
                                goto code_r0x00018009dd7c;
                            }
                            if ((uint64_t)(var_4d0h - var_4d8h) < 2) {
                                func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 2, 0xffffffff);
                            }
                            *(undefined2 *)var_4d8h = 0x725c;
                            var_4d8h = var_4d8h + 2;
                        }
                        pcVar16 = pcVar16 + 1;
                    } while (iVar9 != 0);
                    iVar9 = 0;
                    arg1 = var_500h;
                }
                var_520h = iVar9 + -1;
                if (((uint64_t)var_4d0h <= (uint64_t)var_4d8h) && (var_4d0h == var_4d8h)) {
                    func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                }
                *(undefined *)var_4d8h = 0x22;
                piVar10 = (int64_t *)(var_4d8h + 1);
                iVar9 = var_528h;
                var_4d8h = (int64_t)piVar10;
                goto code_r0x00018009dffd;
            case 0x73:
                piVar10 = (int64_t *)func_0x0001800860c0(arg1, uVar12, &var_4f8h);
                uVar7 = var_4f8h;
                if (piVar10 == (int64_t *)0x0) goto code_r0x00018009e106;
                if ((var_2b8h._2_1_ != '\0') &&
                   ((iVar9 = func_0x00018045b928(&var_2b8h, 0x2e), iVar9 != 0 || (uVar7 < 100))))
                goto code_r0x00018009df47;
                uVar12 = uVar14;
                if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                    func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                }
            }
code_r0x00018009dfe3:
            func_0x000180498030(var_4d8h, piVar10, uVar7);
            iVar9 = var_528h;
code_r0x00018009dff0:
            piVar10 = (int64_t *)(var_4d8h + uVar7);
            uVar14 = uVar12;
            var_4d8h = (int64_t)piVar10;
code_r0x00018009dffd:
        } while (pcVar4 < (uint64_t)var_4f0h);
    }
    iVar15 = var_4c0h;
    iVar9 = var_4c8h;
    if (var_4c0h == 0) {
        func_0x0001800867f0(var_4c8h, &var_4b8h, (int64_t)piVar10 + (-0x20 - (int64_t)&var_4d8h));
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_4c8h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_4c8h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_4c8h, 1);
            piVar10 = (int64_t *)var_4d8h;
        }
        iVar13 = *(int64_t *)(iVar9 + 0x40);
        if (piVar10 == (int64_t *)var_4d0h) {
            uVar6 = func_0x00018009a7e0(iVar9, iVar15);
            *(undefined8 *)(iVar13 + -0x10) = uVar6;
            *(undefined4 *)(iVar13 + -4) = 6;
        } else {
            uVar6 = func_0x00018009a8e0(iVar9, iVar15 + 0x18, (int64_t)piVar10 + (-0x18 - iVar15));
            *(undefined8 *)(iVar13 + -0x10) = uVar6;
            *(undefined4 *)(iVar13 + -4) = 6;
        }
    }
    func_0x000180459870(var_48h ^ (uint64_t)auStack_548);
    return;
}

// ============================================================
// Function: FUN_18009d54c
// Address: 0x18009d54c
// Size: 2945 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_2b7h
// WARNING: [rz-ghidra] Detected overlap for variable var_2b6h
// WARNING: [rz-ghidra] Removing arg arg_6824h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_518h
// WARNING: [rz-ghidra] Detected overlap for variable var_510h
// WARNING: [rz-ghidra] Detected overlap for variable var_50ch
// WARNING: [rz-ghidra] Detected overlap for variable var_508h

void fcn.18009d4f0(int64_t arg1)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    char *pcVar4;
    uint64_t uVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    char *pcVar8;
    int64_t iVar9;
    int64_t *piVar10;
    uint32_t uVar11;
    int64_t iVar13;
    uint64_t uVar14;
    int64_t iVar15;
    char *pcVar16;
    undefined4 uVar17;
    double dVar18;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_548 [32];
    int64_t var_528h;
    int64_t var_520h;
    int32_t var_518h;
    int64_t var_514h;
    int32_t var_50ch;
    uint64_t var_508h;
    int64_t var_500h;
    int64_t var_4f8h;
    int64_t var_4f0h;
    int64_t var_4e8h;
    int64_t var_4d8h;
    int64_t var_4d0h;
    int64_t var_4c8h;
    int64_t var_4c0h;
    int64_t var_4b8h;
    int64_t var_2b8h;
    int64_t var_298h;
    int64_t var_278h;
    int64_t var_248h;
    int64_t var_48h;
    int64_t var_38h;
    uint64_t uVar12;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_548;
    iVar9 = *(int64_t *)(arg1 + 0x40);
    iVar15 = *(int64_t *)(arg1 + 0x28);
    var_500h = arg1;
    pcVar4 = (char *)func_0x0001800860c0(arg1, 1, &var_520h);
    if (pcVar4 == (char *)0x0) {
        fcn.180088470(arg1, 1, 6);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    piVar10 = &var_4b8h;
    var_4d0h = (int64_t)&var_2b8h;
    iVar9 = iVar9 - iVar15 >> 4;
    var_4f0h = (int64_t)(pcVar4 + var_520h);
    uVar14 = 1;
    var_4c0h = 0;
    var_528h = iVar9;
    var_4d8h = (int64_t)piVar10;
    var_4c8h = arg1;
    if (pcVar4 < (uint64_t)var_4f0h) {
        do {
            if (*pcVar4 != '%') {
                if (((uint64_t)var_4d0h <= piVar10) && ((int64_t *)var_4d0h == piVar10)) {
                    func_0x0001800890e0(&var_4d8h, (int64_t)piVar10 + (1 - var_4d0h));
                    piVar10 = (int64_t *)var_4d8h;
                }
                cVar2 = *pcVar4;
                pcVar4 = pcVar4 + 1;
                *(char *)piVar10 = cVar2;
                piVar10 = (int64_t *)(var_4d8h + 1);
                var_4d8h = (int64_t)piVar10;
                goto code_r0x00018009dffd;
            }
            cVar2 = pcVar4[1];
            pcVar16 = pcVar4 + 1;
            if (cVar2 == '%') {
                if (((uint64_t)var_4d0h <= piVar10) && ((int64_t *)var_4d0h == piVar10)) {
                    func_0x0001800890e0(&var_4d8h, (int64_t)piVar10 + (1 - var_4d0h));
                    piVar10 = (int64_t *)var_4d8h;
                }
                pcVar4 = pcVar4 + 2;
                *(char *)piVar10 = *pcVar16;
                piVar10 = (int64_t *)(var_4d8h + 1);
                var_4d8h = (int64_t)piVar10;
                goto code_r0x00018009dffd;
            }
            iVar15 = (int64_t)(int32_t)uVar14;
            uVar11 = (int32_t)uVar14 + 1;
            uVar12 = (uint64_t)uVar11;
            if (cVar2 == '*') {
                if ((int32_t)iVar9 < (int32_t)uVar11) {
                    fcn.180088560(arg1, 0x18063da20, uVar12);
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                pcVar4 = pcVar4 + 2;
                uVar7 = uVar12;
                iVar13 = var_4c8h;
                if ((int32_t)uVar11 < 1) {
                    if ((int32_t)uVar11 < -9999) {
                        uVar5 = fcn.180085370(var_4c8h, uVar12);
                        piVar10 = (int64_t *)var_4d8h;
                    } else {
                        uVar5 = (int64_t)(int32_t)uVar11 * 0x10 + *(int64_t *)(var_4c8h + 0x40);
                    }
                } else {
                    uVar5 = *(int64_t *)(var_4c8h + 0x28) + iVar15 * 0x10;
                    if (*(uint64_t *)(var_4c8h + 0x40) <= uVar5) {
                        uVar5 = *(uint64_t *)0x180782430;
                    }
                }
                uVar14 = uVar12;
                if (uVar5 == *(uint64_t *)0x180782430) goto code_r0x00018009dffd;
    // switch table (8 cases) at 0x18009e16c
                switch(*(undefined4 *)(uVar5 + 0xc)) {
                case 0:
                    if ((uint64_t)(var_4d0h - (int64_t)piVar10) < 3) {
                        func_0x0001800890e0(&var_4d8h, (int64_t)piVar10 + (3 - var_4d0h));
                        piVar10 = (int64_t *)var_4d8h;
                    }
                    *(undefined2 *)piVar10 = 0x696e;
                    *(undefined *)((int64_t)piVar10 + 2) = 0x6c;
                    piVar10 = (int64_t *)(var_4d8h + 3);
                    var_4d8h = (int64_t)piVar10;
                    break;
                case 1:
                    iVar3 = func_0x000180085ff0(iVar13, uVar7 & 0xffffffff);
                    if (iVar3 == 0) {
                        if ((uint64_t)(var_4d0h - var_4d8h) < 5) {
                            func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 5);
                        }
                        *(undefined4 *)var_4d8h = 0x736c6166;
                        *(undefined *)(var_4d8h + 4) = 0x65;
                        piVar10 = (int64_t *)(var_4d8h + 5);
                        var_4d8h = (int64_t)piVar10;
                    } else {
                        if ((uint64_t)(var_4d0h - var_4d8h) < 4) {
                            func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 4);
                        }
                        *(undefined4 *)var_4d8h = 0x65757274;
                        piVar10 = (int64_t *)(var_4d8h + 4);
                        var_4d8h = (int64_t)piVar10;
                    }
                    break;
                default:
                    func_0x0001800893a0(iVar13, uVar7 & 0xffffffff);
                    func_0x0001800891f0(&var_4d8h);
                    piVar10 = (int64_t *)var_4d8h;
                    break;
                case 3:
                    uVar17 = func_0x000180085ea0(iVar13, uVar7 & 0xffffffff, 0);
                    iVar15 = func_0x000180098ac0(&var_278h, uVar17);
                    uVar7 = iVar15 - (int64_t)&var_278h;
                    if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                        func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                    }
                    func_0x000180498030(var_4d8h, &var_278h);
                    goto code_r0x00018009dff0;
                case 4:
                    uVar6 = func_0x000180086060(iVar13, uVar7 & 0xffffffff);
                    iVar15 = func_0x000180099080(&var_298h, uVar6);
                    uVar7 = iVar15 - (int64_t)&var_298h;
                    if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                        func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                    }
                    func_0x000180498030(var_4d8h, &var_298h, uVar7);
                    goto code_r0x00018009dff0;
                case 6:
                    piVar10 = (int64_t *)func_0x0001800860c0(iVar13, uVar7 & 0xffffffff, &var_508h);
                    uVar7 = var_508h;
                    if ((uint64_t)(var_4d0h - var_4d8h) < var_508h) {
                        func_0x0001800890e0(&var_4d8h, (var_508h - var_4d0h) + var_4d8h, 0xffffffff);
                    }
                    goto code_r0x00018009dfe3;
                case 0xffffffff:
                    break;
                }
                goto code_r0x00018009dffd;
            }
            uVar14 = (uint64_t)(int32_t)uVar11;
            pcVar4 = pcVar16;
            if ((int32_t)iVar9 < (int32_t)uVar11) {
                fcn.180088560(arg1, 0x18063da20, uVar12);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            while (uVar17 = (undefined4)((uint64_t)piVar10 >> 0x20), cVar2 != '\0') {
                iVar9 = func_0x00018045b928(0x18063e720, (int32_t)cVar2);
                uVar17 = (undefined4)((uint64_t)piVar10 >> 0x20);
                if (iVar9 == 0) break;
                cVar2 = pcVar4[1];
                pcVar4 = pcVar4 + 1;
            }
            if (5 < (uint64_t)((int64_t)pcVar4 - (int64_t)pcVar16)) {
                fcn.180088560(arg1, 0x18063e7e0);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            iVar3 = func_0x00018046cb80(*pcVar4);
            pcVar8 = pcVar4 + 1;
            if (iVar3 == 0) {
                pcVar8 = pcVar4;
            }
            iVar3 = func_0x00018046cb80(*pcVar8);
            pcVar4 = pcVar8 + 1;
            if (iVar3 == 0) {
                pcVar4 = pcVar8;
            }
            cVar2 = *pcVar4;
            if (cVar2 == '.') {
                iVar3 = func_0x00018046cb80(pcVar4[1]);
                pcVar8 = pcVar4 + (uint64_t)(iVar3 != 0) + 1;
                iVar3 = func_0x00018046cb80(*pcVar8);
                pcVar4 = pcVar8 + 1;
                if (iVar3 == 0) {
                    pcVar4 = pcVar8;
                }
                cVar2 = *pcVar4;
            }
            iVar3 = func_0x00018046cb80(cVar2);
            if (iVar3 != 0) {
                fcn.180088560(arg1, 0x18063e7b0);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            var_2b8h._0_1_ = 0x25;
            iVar9 = (int64_t)pcVar4 - (int64_t)pcVar16;
            func_0x000180498d90((int64_t)&var_2b8h + 1, pcVar16, (int32_t)iVar9 + 1);
            *(undefined *)((int64_t)&var_2b8h + iVar9 + 2) = 0;
            cVar2 = *pcVar4;
            iVar3 = (int32_t)cVar2;
            pcVar4 = pcVar4 + 1;
    // switch table (79 cases) at 0x18009e18c
            switch(iVar3) {
            case 0x2a:
                fcn.180088560(arg1, 0x18063e790);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            default:
                fcn.180088560(arg1, 0x18063e768);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            case 0x45:
            case 0x47:
            case 0x65:
            case 0x66:
            case 0x67:
                uVar6 = func_0x000180085ea0(arg1, uVar12, &var_50ch);
                if (var_50ch == 0) {
code_r0x00018009e0f4:
                    fcn.180088470(arg1, uVar12, 3);
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                func_0x000180065f60(&var_248h, 0x200, &var_2b8h, uVar6);
                goto code_r0x00018009df5f;
            case 0x58:
            case 0x6f:
            case 0x75:
            case 0x78:
                uVar7 = *(uint64_t *)0x180782430;
                if ((int32_t)uVar11 < 1) {
                    if ((int32_t)uVar11 < -9999) {
                        uVar5 = fcn.180085370(arg1, uVar12, iVar3);
                    } else {
                        uVar5 = uVar14 * 0x10 + *(int64_t *)(arg1 + 0x40);
                    }
                } else {
                    uVar5 = *(int64_t *)(arg1 + 0x28) + iVar15 * 0x10;
                    if (*(uint64_t *)(arg1 + 0x40) <= uVar5) {
                        uVar5 = *(uint64_t *)0x180782430;
                    }
                }
                if ((uVar5 == uVar7) || (*(int32_t *)(uVar5 + 0xc) != 4)) {
                    dVar18 = (double)func_0x000180085ea0(arg1, uVar12, (int64_t)&var_514h + 4);
                    if (var_514h._4_4_ == 0) goto code_r0x00018009e0f4;
                    if (0.0 <= dVar18) {
                        iVar15 = 0;
                        if ((9.223372036854776e+18 <= dVar18) &&
                           (dVar18 = dVar18 - 9.223372036854776e+18, dVar18 < 9.223372036854776e+18)) {
                            iVar15 = -0x8000000000000000;
                        }
                        piVar10 = (int64_t *)((int64_t)dVar18 + iVar15);
                    } else {
                        piVar10 = (int64_t *)(int64_t)dVar18;
                    }
                } else {
                    piVar10 = (int64_t *)func_0x000180088910(arg1, uVar12);
                }
                *(undefined2 *)((int64_t)&var_2b8h + iVar9 + 1) = 0x6c6c;
                *(char *)((int64_t)&var_2b8h + iVar9 + 3) = cVar2;
                *(undefined *)((int64_t)&var_2b8h + iVar9 + 4) = 0;
                goto code_r0x00018009df47;
            case 99:
                dVar18 = (double)func_0x000180085ea0(arg1, uVar12, &var_518h);
                if (var_518h == 0) goto code_r0x00018009e0f4;
                iVar3 = func_0x000180065f60(&var_248h, 0x200, &var_2b8h, CONCAT44(uVar17, (int32_t)dVar18));
                uVar7 = (uint64_t)iVar3;
                if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                    func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                }
                piVar10 = &var_248h;
                uVar12 = uVar14;
                break;
            case 100:
            case 0x69:
                uVar7 = *(uint64_t *)0x180782430;
                if ((int32_t)uVar11 < 1) {
                    if ((int32_t)uVar11 < -9999) {
                        uVar5 = fcn.180085370(arg1, uVar12, iVar3);
                    } else {
                        uVar5 = uVar14 * 0x10 + *(int64_t *)(arg1 + 0x40);
                    }
                } else {
                    uVar5 = *(int64_t *)(arg1 + 0x28) + iVar15 * 0x10;
                    if (*(uint64_t *)(arg1 + 0x40) <= uVar5) {
                        uVar5 = *(uint64_t *)0x180782430;
                    }
                }
                if ((uVar5 == uVar7) || (*(int32_t *)(uVar5 + 0xc) != 4)) {
                    dVar18 = (double)func_0x000180085ea0(arg1, uVar12, &var_514h);
                    if ((int32_t)var_514h == 0) goto code_r0x00018009e0f4;
                    piVar10 = (int64_t *)(int64_t)dVar18;
                } else {
                    piVar10 = (int64_t *)func_0x000180088910(arg1, uVar12);
                }
                *(undefined2 *)((int64_t)&var_2b8h + iVar9 + 1) = 0x6c6c;
                *(char *)((int64_t)&var_2b8h + iVar9 + 3) = cVar2;
                *(undefined *)((int64_t)&var_2b8h + iVar9 + 4) = 0;
code_r0x00018009df47:
                func_0x000180065f60(&var_248h, 0x200, &var_2b8h, piVar10);
code_r0x00018009df5f:
                uVar7 = func_0x000180498cd0(&var_248h);
                if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                    func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                }
                piVar10 = &var_248h;
                uVar12 = uVar14;
                break;
            case 0x71:
                pcVar16 = (char *)func_0x0001800860c0(arg1, uVar12, &var_520h);
                iVar9 = var_520h;
                if (pcVar16 == (char *)0x0) {
code_r0x00018009e106:
                    fcn.180088470(arg1, uVar12, 6);
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                if ((uint64_t)(var_4d0h - var_4d8h) < var_520h + 2U) {
                    func_0x0001800890e0(&var_4d8h, var_4d8h + ((var_520h + 2U) - var_4d0h), 0xffffffff);
                }
                if (((uint64_t)var_4d0h <= (uint64_t)var_4d8h) && (var_4d0h == var_4d8h)) {
                    func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                }
                *(undefined *)var_4d8h = 0x22;
                var_4d8h = var_4d8h + 1;
                if (iVar9 != 0) {
                    do {
                        cVar2 = *pcVar16;
                        iVar9 = iVar9 + -1;
                        if (cVar2 == '\0') {
                            if ((uint64_t)(var_4d0h - var_4d8h) < 4) {
                                func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 4, 0xffffffff);
                            }
                            *(undefined4 *)var_4d8h = 0x3030305c;
                            var_4d8h = var_4d8h + 4;
                        } else if (cVar2 == '\n') {
code_r0x00018009ddce:
                            if (((uint64_t)var_4d0h <= (uint64_t)var_4d8h) && (var_4d0h == var_4d8h)) {
                                func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                            }
                            *(undefined *)var_4d8h = 0x5c;
                            var_4d8h = var_4d8h + 1;
                            if (((uint64_t)var_4d8h < (uint64_t)var_4d0h) || (var_4d0h != var_4d8h)) {
code_r0x00018009dd7c:
                                *(char *)var_4d8h = *pcVar16;
                                var_4d8h = var_4d8h + 1;
                            } else {
                                func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                                *(char *)var_4d8h = *pcVar16;
                                var_4d8h = var_4d8h + 1;
                            }
                        } else {
                            if (cVar2 != '\r') {
                                if ((cVar2 == '\"') || (cVar2 == '\\')) goto code_r0x00018009ddce;
                                if (((uint64_t)var_4d0h <= (uint64_t)var_4d8h) && (var_4d0h == var_4d8h)) {
                                    func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                                }
                                goto code_r0x00018009dd7c;
                            }
                            if ((uint64_t)(var_4d0h - var_4d8h) < 2) {
                                func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 2, 0xffffffff);
                            }
                            *(undefined2 *)var_4d8h = 0x725c;
                            var_4d8h = var_4d8h + 2;
                        }
                        pcVar16 = pcVar16 + 1;
                    } while (iVar9 != 0);
                    iVar9 = 0;
                    arg1 = var_500h;
                }
                var_520h = iVar9 + -1;
                if (((uint64_t)var_4d0h <= (uint64_t)var_4d8h) && (var_4d0h == var_4d8h)) {
                    func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                }
                *(undefined *)var_4d8h = 0x22;
                piVar10 = (int64_t *)(var_4d8h + 1);
                iVar9 = var_528h;
                var_4d8h = (int64_t)piVar10;
                goto code_r0x00018009dffd;
            case 0x73:
                piVar10 = (int64_t *)func_0x0001800860c0(arg1, uVar12, &var_4f8h);
                uVar7 = var_4f8h;
                if (piVar10 == (int64_t *)0x0) goto code_r0x00018009e106;
                if ((var_2b8h._2_1_ != '\0') &&
                   ((iVar9 = func_0x00018045b928(&var_2b8h, 0x2e), iVar9 != 0 || (uVar7 < 100))))
                goto code_r0x00018009df47;
                uVar12 = uVar14;
                if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                    func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                }
            }
code_r0x00018009dfe3:
            func_0x000180498030(var_4d8h, piVar10, uVar7);
            iVar9 = var_528h;
code_r0x00018009dff0:
            piVar10 = (int64_t *)(var_4d8h + uVar7);
            uVar14 = uVar12;
            var_4d8h = (int64_t)piVar10;
code_r0x00018009dffd:
        } while (pcVar4 < (uint64_t)var_4f0h);
    }
    iVar15 = var_4c0h;
    iVar9 = var_4c8h;
    if (var_4c0h == 0) {
        func_0x0001800867f0(var_4c8h, &var_4b8h, (int64_t)piVar10 + (-0x20 - (int64_t)&var_4d8h));
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_4c8h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_4c8h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_4c8h, 1);
            piVar10 = (int64_t *)var_4d8h;
        }
        iVar13 = *(int64_t *)(iVar9 + 0x40);
        if (piVar10 == (int64_t *)var_4d0h) {
            uVar6 = func_0x00018009a7e0(iVar9, iVar15);
            *(undefined8 *)(iVar13 + -0x10) = uVar6;
            *(undefined4 *)(iVar13 + -4) = 6;
        } else {
            uVar6 = func_0x00018009a8e0(iVar9, iVar15 + 0x18, (int64_t)piVar10 + (-0x18 - iVar15));
            *(undefined8 *)(iVar13 + -0x10) = uVar6;
            *(undefined4 *)(iVar13 + -4) = 6;
        }
    }
    func_0x000180459870(var_48h ^ (uint64_t)auStack_548);
    return;
}

// ============================================================
// Function: FUN_18009e0cd
// Address: 0x18009e0cd
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_2b7h
// WARNING: [rz-ghidra] Detected overlap for variable var_2b6h
// WARNING: [rz-ghidra] Removing arg arg_6824h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_518h
// WARNING: [rz-ghidra] Detected overlap for variable var_510h
// WARNING: [rz-ghidra] Detected overlap for variable var_50ch
// WARNING: [rz-ghidra] Detected overlap for variable var_508h

void fcn.18009d4f0(int64_t arg1)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    char *pcVar4;
    uint64_t uVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    char *pcVar8;
    int64_t iVar9;
    int64_t *piVar10;
    uint32_t uVar11;
    int64_t iVar13;
    uint64_t uVar14;
    int64_t iVar15;
    char *pcVar16;
    undefined4 uVar17;
    double dVar18;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_548 [32];
    int64_t var_528h;
    int64_t var_520h;
    int32_t var_518h;
    int64_t var_514h;
    int32_t var_50ch;
    uint64_t var_508h;
    int64_t var_500h;
    int64_t var_4f8h;
    int64_t var_4f0h;
    int64_t var_4e8h;
    int64_t var_4d8h;
    int64_t var_4d0h;
    int64_t var_4c8h;
    int64_t var_4c0h;
    int64_t var_4b8h;
    int64_t var_2b8h;
    int64_t var_298h;
    int64_t var_278h;
    int64_t var_248h;
    int64_t var_48h;
    int64_t var_38h;
    uint64_t uVar12;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_548;
    iVar9 = *(int64_t *)(arg1 + 0x40);
    iVar15 = *(int64_t *)(arg1 + 0x28);
    var_500h = arg1;
    pcVar4 = (char *)func_0x0001800860c0(arg1, 1, &var_520h);
    if (pcVar4 == (char *)0x0) {
        fcn.180088470(arg1, 1, 6);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    piVar10 = &var_4b8h;
    var_4d0h = (int64_t)&var_2b8h;
    iVar9 = iVar9 - iVar15 >> 4;
    var_4f0h = (int64_t)(pcVar4 + var_520h);
    uVar14 = 1;
    var_4c0h = 0;
    var_528h = iVar9;
    var_4d8h = (int64_t)piVar10;
    var_4c8h = arg1;
    if (pcVar4 < (uint64_t)var_4f0h) {
        do {
            if (*pcVar4 != '%') {
                if (((uint64_t)var_4d0h <= piVar10) && ((int64_t *)var_4d0h == piVar10)) {
                    func_0x0001800890e0(&var_4d8h, (int64_t)piVar10 + (1 - var_4d0h));
                    piVar10 = (int64_t *)var_4d8h;
                }
                cVar2 = *pcVar4;
                pcVar4 = pcVar4 + 1;
                *(char *)piVar10 = cVar2;
                piVar10 = (int64_t *)(var_4d8h + 1);
                var_4d8h = (int64_t)piVar10;
                goto code_r0x00018009dffd;
            }
            cVar2 = pcVar4[1];
            pcVar16 = pcVar4 + 1;
            if (cVar2 == '%') {
                if (((uint64_t)var_4d0h <= piVar10) && ((int64_t *)var_4d0h == piVar10)) {
                    func_0x0001800890e0(&var_4d8h, (int64_t)piVar10 + (1 - var_4d0h));
                    piVar10 = (int64_t *)var_4d8h;
                }
                pcVar4 = pcVar4 + 2;
                *(char *)piVar10 = *pcVar16;
                piVar10 = (int64_t *)(var_4d8h + 1);
                var_4d8h = (int64_t)piVar10;
                goto code_r0x00018009dffd;
            }
            iVar15 = (int64_t)(int32_t)uVar14;
            uVar11 = (int32_t)uVar14 + 1;
            uVar12 = (uint64_t)uVar11;
            if (cVar2 == '*') {
                if ((int32_t)iVar9 < (int32_t)uVar11) {
                    fcn.180088560(arg1, 0x18063da20, uVar12);
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                pcVar4 = pcVar4 + 2;
                uVar7 = uVar12;
                iVar13 = var_4c8h;
                if ((int32_t)uVar11 < 1) {
                    if ((int32_t)uVar11 < -9999) {
                        uVar5 = fcn.180085370(var_4c8h, uVar12);
                        piVar10 = (int64_t *)var_4d8h;
                    } else {
                        uVar5 = (int64_t)(int32_t)uVar11 * 0x10 + *(int64_t *)(var_4c8h + 0x40);
                    }
                } else {
                    uVar5 = *(int64_t *)(var_4c8h + 0x28) + iVar15 * 0x10;
                    if (*(uint64_t *)(var_4c8h + 0x40) <= uVar5) {
                        uVar5 = *(uint64_t *)0x180782430;
                    }
                }
                uVar14 = uVar12;
                if (uVar5 == *(uint64_t *)0x180782430) goto code_r0x00018009dffd;
    // switch table (8 cases) at 0x18009e16c
                switch(*(undefined4 *)(uVar5 + 0xc)) {
                case 0:
                    if ((uint64_t)(var_4d0h - (int64_t)piVar10) < 3) {
                        func_0x0001800890e0(&var_4d8h, (int64_t)piVar10 + (3 - var_4d0h));
                        piVar10 = (int64_t *)var_4d8h;
                    }
                    *(undefined2 *)piVar10 = 0x696e;
                    *(undefined *)((int64_t)piVar10 + 2) = 0x6c;
                    piVar10 = (int64_t *)(var_4d8h + 3);
                    var_4d8h = (int64_t)piVar10;
                    break;
                case 1:
                    iVar3 = func_0x000180085ff0(iVar13, uVar7 & 0xffffffff);
                    if (iVar3 == 0) {
                        if ((uint64_t)(var_4d0h - var_4d8h) < 5) {
                            func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 5);
                        }
                        *(undefined4 *)var_4d8h = 0x736c6166;
                        *(undefined *)(var_4d8h + 4) = 0x65;
                        piVar10 = (int64_t *)(var_4d8h + 5);
                        var_4d8h = (int64_t)piVar10;
                    } else {
                        if ((uint64_t)(var_4d0h - var_4d8h) < 4) {
                            func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 4);
                        }
                        *(undefined4 *)var_4d8h = 0x65757274;
                        piVar10 = (int64_t *)(var_4d8h + 4);
                        var_4d8h = (int64_t)piVar10;
                    }
                    break;
                default:
                    func_0x0001800893a0(iVar13, uVar7 & 0xffffffff);
                    func_0x0001800891f0(&var_4d8h);
                    piVar10 = (int64_t *)var_4d8h;
                    break;
                case 3:
                    uVar17 = func_0x000180085ea0(iVar13, uVar7 & 0xffffffff, 0);
                    iVar15 = func_0x000180098ac0(&var_278h, uVar17);
                    uVar7 = iVar15 - (int64_t)&var_278h;
                    if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                        func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                    }
                    func_0x000180498030(var_4d8h, &var_278h);
                    goto code_r0x00018009dff0;
                case 4:
                    uVar6 = func_0x000180086060(iVar13, uVar7 & 0xffffffff);
                    iVar15 = func_0x000180099080(&var_298h, uVar6);
                    uVar7 = iVar15 - (int64_t)&var_298h;
                    if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                        func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                    }
                    func_0x000180498030(var_4d8h, &var_298h, uVar7);
                    goto code_r0x00018009dff0;
                case 6:
                    piVar10 = (int64_t *)func_0x0001800860c0(iVar13, uVar7 & 0xffffffff, &var_508h);
                    uVar7 = var_508h;
                    if ((uint64_t)(var_4d0h - var_4d8h) < var_508h) {
                        func_0x0001800890e0(&var_4d8h, (var_508h - var_4d0h) + var_4d8h, 0xffffffff);
                    }
                    goto code_r0x00018009dfe3;
                case 0xffffffff:
                    break;
                }
                goto code_r0x00018009dffd;
            }
            uVar14 = (uint64_t)(int32_t)uVar11;
            pcVar4 = pcVar16;
            if ((int32_t)iVar9 < (int32_t)uVar11) {
                fcn.180088560(arg1, 0x18063da20, uVar12);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            while (uVar17 = (undefined4)((uint64_t)piVar10 >> 0x20), cVar2 != '\0') {
                iVar9 = func_0x00018045b928(0x18063e720, (int32_t)cVar2);
                uVar17 = (undefined4)((uint64_t)piVar10 >> 0x20);
                if (iVar9 == 0) break;
                cVar2 = pcVar4[1];
                pcVar4 = pcVar4 + 1;
            }
            if (5 < (uint64_t)((int64_t)pcVar4 - (int64_t)pcVar16)) {
                fcn.180088560(arg1, 0x18063e7e0);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            iVar3 = func_0x00018046cb80(*pcVar4);
            pcVar8 = pcVar4 + 1;
            if (iVar3 == 0) {
                pcVar8 = pcVar4;
            }
            iVar3 = func_0x00018046cb80(*pcVar8);
            pcVar4 = pcVar8 + 1;
            if (iVar3 == 0) {
                pcVar4 = pcVar8;
            }
            cVar2 = *pcVar4;
            if (cVar2 == '.') {
                iVar3 = func_0x00018046cb80(pcVar4[1]);
                pcVar8 = pcVar4 + (uint64_t)(iVar3 != 0) + 1;
                iVar3 = func_0x00018046cb80(*pcVar8);
                pcVar4 = pcVar8 + 1;
                if (iVar3 == 0) {
                    pcVar4 = pcVar8;
                }
                cVar2 = *pcVar4;
            }
            iVar3 = func_0x00018046cb80(cVar2);
            if (iVar3 != 0) {
                fcn.180088560(arg1, 0x18063e7b0);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            var_2b8h._0_1_ = 0x25;
            iVar9 = (int64_t)pcVar4 - (int64_t)pcVar16;
            func_0x000180498d90((int64_t)&var_2b8h + 1, pcVar16, (int32_t)iVar9 + 1);
            *(undefined *)((int64_t)&var_2b8h + iVar9 + 2) = 0;
            cVar2 = *pcVar4;
            iVar3 = (int32_t)cVar2;
            pcVar4 = pcVar4 + 1;
    // switch table (79 cases) at 0x18009e18c
            switch(iVar3) {
            case 0x2a:
                fcn.180088560(arg1, 0x18063e790);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            default:
                fcn.180088560(arg1, 0x18063e768);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            case 0x45:
            case 0x47:
            case 0x65:
            case 0x66:
            case 0x67:
                uVar6 = func_0x000180085ea0(arg1, uVar12, &var_50ch);
                if (var_50ch == 0) {
code_r0x00018009e0f4:
                    fcn.180088470(arg1, uVar12, 3);
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                func_0x000180065f60(&var_248h, 0x200, &var_2b8h, uVar6);
                goto code_r0x00018009df5f;
            case 0x58:
            case 0x6f:
            case 0x75:
            case 0x78:
                uVar7 = *(uint64_t *)0x180782430;
                if ((int32_t)uVar11 < 1) {
                    if ((int32_t)uVar11 < -9999) {
                        uVar5 = fcn.180085370(arg1, uVar12, iVar3);
                    } else {
                        uVar5 = uVar14 * 0x10 + *(int64_t *)(arg1 + 0x40);
                    }
                } else {
                    uVar5 = *(int64_t *)(arg1 + 0x28) + iVar15 * 0x10;
                    if (*(uint64_t *)(arg1 + 0x40) <= uVar5) {
                        uVar5 = *(uint64_t *)0x180782430;
                    }
                }
                if ((uVar5 == uVar7) || (*(int32_t *)(uVar5 + 0xc) != 4)) {
                    dVar18 = (double)func_0x000180085ea0(arg1, uVar12, (int64_t)&var_514h + 4);
                    if (var_514h._4_4_ == 0) goto code_r0x00018009e0f4;
                    if (0.0 <= dVar18) {
                        iVar15 = 0;
                        if ((9.223372036854776e+18 <= dVar18) &&
                           (dVar18 = dVar18 - 9.223372036854776e+18, dVar18 < 9.223372036854776e+18)) {
                            iVar15 = -0x8000000000000000;
                        }
                        piVar10 = (int64_t *)((int64_t)dVar18 + iVar15);
                    } else {
                        piVar10 = (int64_t *)(int64_t)dVar18;
                    }
                } else {
                    piVar10 = (int64_t *)func_0x000180088910(arg1, uVar12);
                }
                *(undefined2 *)((int64_t)&var_2b8h + iVar9 + 1) = 0x6c6c;
                *(char *)((int64_t)&var_2b8h + iVar9 + 3) = cVar2;
                *(undefined *)((int64_t)&var_2b8h + iVar9 + 4) = 0;
                goto code_r0x00018009df47;
            case 99:
                dVar18 = (double)func_0x000180085ea0(arg1, uVar12, &var_518h);
                if (var_518h == 0) goto code_r0x00018009e0f4;
                iVar3 = func_0x000180065f60(&var_248h, 0x200, &var_2b8h, CONCAT44(uVar17, (int32_t)dVar18));
                uVar7 = (uint64_t)iVar3;
                if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                    func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                }
                piVar10 = &var_248h;
                uVar12 = uVar14;
                break;
            case 100:
            case 0x69:
                uVar7 = *(uint64_t *)0x180782430;
                if ((int32_t)uVar11 < 1) {
                    if ((int32_t)uVar11 < -9999) {
                        uVar5 = fcn.180085370(arg1, uVar12, iVar3);
                    } else {
                        uVar5 = uVar14 * 0x10 + *(int64_t *)(arg1 + 0x40);
                    }
                } else {
                    uVar5 = *(int64_t *)(arg1 + 0x28) + iVar15 * 0x10;
                    if (*(uint64_t *)(arg1 + 0x40) <= uVar5) {
                        uVar5 = *(uint64_t *)0x180782430;
                    }
                }
                if ((uVar5 == uVar7) || (*(int32_t *)(uVar5 + 0xc) != 4)) {
                    dVar18 = (double)func_0x000180085ea0(arg1, uVar12, &var_514h);
                    if ((int32_t)var_514h == 0) goto code_r0x00018009e0f4;
                    piVar10 = (int64_t *)(int64_t)dVar18;
                } else {
                    piVar10 = (int64_t *)func_0x000180088910(arg1, uVar12);
                }
                *(undefined2 *)((int64_t)&var_2b8h + iVar9 + 1) = 0x6c6c;
                *(char *)((int64_t)&var_2b8h + iVar9 + 3) = cVar2;
                *(undefined *)((int64_t)&var_2b8h + iVar9 + 4) = 0;
code_r0x00018009df47:
                func_0x000180065f60(&var_248h, 0x200, &var_2b8h, piVar10);
code_r0x00018009df5f:
                uVar7 = func_0x000180498cd0(&var_248h);
                if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                    func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                }
                piVar10 = &var_248h;
                uVar12 = uVar14;
                break;
            case 0x71:
                pcVar16 = (char *)func_0x0001800860c0(arg1, uVar12, &var_520h);
                iVar9 = var_520h;
                if (pcVar16 == (char *)0x0) {
code_r0x00018009e106:
                    fcn.180088470(arg1, uVar12, 6);
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                if ((uint64_t)(var_4d0h - var_4d8h) < var_520h + 2U) {
                    func_0x0001800890e0(&var_4d8h, var_4d8h + ((var_520h + 2U) - var_4d0h), 0xffffffff);
                }
                if (((uint64_t)var_4d0h <= (uint64_t)var_4d8h) && (var_4d0h == var_4d8h)) {
                    func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                }
                *(undefined *)var_4d8h = 0x22;
                var_4d8h = var_4d8h + 1;
                if (iVar9 != 0) {
                    do {
                        cVar2 = *pcVar16;
                        iVar9 = iVar9 + -1;
                        if (cVar2 == '\0') {
                            if ((uint64_t)(var_4d0h - var_4d8h) < 4) {
                                func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 4, 0xffffffff);
                            }
                            *(undefined4 *)var_4d8h = 0x3030305c;
                            var_4d8h = var_4d8h + 4;
                        } else if (cVar2 == '\n') {
code_r0x00018009ddce:
                            if (((uint64_t)var_4d0h <= (uint64_t)var_4d8h) && (var_4d0h == var_4d8h)) {
                                func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                            }
                            *(undefined *)var_4d8h = 0x5c;
                            var_4d8h = var_4d8h + 1;
                            if (((uint64_t)var_4d8h < (uint64_t)var_4d0h) || (var_4d0h != var_4d8h)) {
code_r0x00018009dd7c:
                                *(char *)var_4d8h = *pcVar16;
                                var_4d8h = var_4d8h + 1;
                            } else {
                                func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                                *(char *)var_4d8h = *pcVar16;
                                var_4d8h = var_4d8h + 1;
                            }
                        } else {
                            if (cVar2 != '\r') {
                                if ((cVar2 == '\"') || (cVar2 == '\\')) goto code_r0x00018009ddce;
                                if (((uint64_t)var_4d0h <= (uint64_t)var_4d8h) && (var_4d0h == var_4d8h)) {
                                    func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                                }
                                goto code_r0x00018009dd7c;
                            }
                            if ((uint64_t)(var_4d0h - var_4d8h) < 2) {
                                func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 2, 0xffffffff);
                            }
                            *(undefined2 *)var_4d8h = 0x725c;
                            var_4d8h = var_4d8h + 2;
                        }
                        pcVar16 = pcVar16 + 1;
                    } while (iVar9 != 0);
                    iVar9 = 0;
                    arg1 = var_500h;
                }
                var_520h = iVar9 + -1;
                if (((uint64_t)var_4d0h <= (uint64_t)var_4d8h) && (var_4d0h == var_4d8h)) {
                    func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                }
                *(undefined *)var_4d8h = 0x22;
                piVar10 = (int64_t *)(var_4d8h + 1);
                iVar9 = var_528h;
                var_4d8h = (int64_t)piVar10;
                goto code_r0x00018009dffd;
            case 0x73:
                piVar10 = (int64_t *)func_0x0001800860c0(arg1, uVar12, &var_4f8h);
                uVar7 = var_4f8h;
                if (piVar10 == (int64_t *)0x0) goto code_r0x00018009e106;
                if ((var_2b8h._2_1_ != '\0') &&
                   ((iVar9 = func_0x00018045b928(&var_2b8h, 0x2e), iVar9 != 0 || (uVar7 < 100))))
                goto code_r0x00018009df47;
                uVar12 = uVar14;
                if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                    func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                }
            }
code_r0x00018009dfe3:
            func_0x000180498030(var_4d8h, piVar10, uVar7);
            iVar9 = var_528h;
code_r0x00018009dff0:
            piVar10 = (int64_t *)(var_4d8h + uVar7);
            uVar14 = uVar12;
            var_4d8h = (int64_t)piVar10;
code_r0x00018009dffd:
        } while (pcVar4 < (uint64_t)var_4f0h);
    }
    iVar15 = var_4c0h;
    iVar9 = var_4c8h;
    if (var_4c0h == 0) {
        func_0x0001800867f0(var_4c8h, &var_4b8h, (int64_t)piVar10 + (-0x20 - (int64_t)&var_4d8h));
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_4c8h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_4c8h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_4c8h, 1);
            piVar10 = (int64_t *)var_4d8h;
        }
        iVar13 = *(int64_t *)(iVar9 + 0x40);
        if (piVar10 == (int64_t *)var_4d0h) {
            uVar6 = func_0x00018009a7e0(iVar9, iVar15);
            *(undefined8 *)(iVar13 + -0x10) = uVar6;
            *(undefined4 *)(iVar13 + -4) = 6;
        } else {
            uVar6 = func_0x00018009a8e0(iVar9, iVar15 + 0x18, (int64_t)piVar10 + (-0x18 - iVar15));
            *(undefined8 *)(iVar13 + -0x10) = uVar6;
            *(undefined4 *)(iVar13 + -4) = 6;
        }
    }
    func_0x000180459870(var_48h ^ (uint64_t)auStack_548);
    return;
}

// ============================================================
// Function: FUN_18009e0e1
// Address: 0x18009e0e1
// Size: 282 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_2b7h
// WARNING: [rz-ghidra] Detected overlap for variable var_2b6h
// WARNING: [rz-ghidra] Removing arg arg_6824h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_518h
// WARNING: [rz-ghidra] Detected overlap for variable var_510h
// WARNING: [rz-ghidra] Detected overlap for variable var_50ch
// WARNING: [rz-ghidra] Detected overlap for variable var_508h

void fcn.18009d4f0(int64_t arg1)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    char *pcVar4;
    uint64_t uVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    char *pcVar8;
    int64_t iVar9;
    int64_t *piVar10;
    uint32_t uVar11;
    int64_t iVar13;
    uint64_t uVar14;
    int64_t iVar15;
    char *pcVar16;
    undefined4 uVar17;
    double dVar18;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_548 [32];
    int64_t var_528h;
    int64_t var_520h;
    int32_t var_518h;
    int64_t var_514h;
    int32_t var_50ch;
    uint64_t var_508h;
    int64_t var_500h;
    int64_t var_4f8h;
    int64_t var_4f0h;
    int64_t var_4e8h;
    int64_t var_4d8h;
    int64_t var_4d0h;
    int64_t var_4c8h;
    int64_t var_4c0h;
    int64_t var_4b8h;
    int64_t var_2b8h;
    int64_t var_298h;
    int64_t var_278h;
    int64_t var_248h;
    int64_t var_48h;
    int64_t var_38h;
    uint64_t uVar12;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_548;
    iVar9 = *(int64_t *)(arg1 + 0x40);
    iVar15 = *(int64_t *)(arg1 + 0x28);
    var_500h = arg1;
    pcVar4 = (char *)func_0x0001800860c0(arg1, 1, &var_520h);
    if (pcVar4 == (char *)0x0) {
        fcn.180088470(arg1, 1, 6);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    piVar10 = &var_4b8h;
    var_4d0h = (int64_t)&var_2b8h;
    iVar9 = iVar9 - iVar15 >> 4;
    var_4f0h = (int64_t)(pcVar4 + var_520h);
    uVar14 = 1;
    var_4c0h = 0;
    var_528h = iVar9;
    var_4d8h = (int64_t)piVar10;
    var_4c8h = arg1;
    if (pcVar4 < (uint64_t)var_4f0h) {
        do {
            if (*pcVar4 != '%') {
                if (((uint64_t)var_4d0h <= piVar10) && ((int64_t *)var_4d0h == piVar10)) {
                    func_0x0001800890e0(&var_4d8h, (int64_t)piVar10 + (1 - var_4d0h));
                    piVar10 = (int64_t *)var_4d8h;
                }
                cVar2 = *pcVar4;
                pcVar4 = pcVar4 + 1;
                *(char *)piVar10 = cVar2;
                piVar10 = (int64_t *)(var_4d8h + 1);
                var_4d8h = (int64_t)piVar10;
                goto code_r0x00018009dffd;
            }
            cVar2 = pcVar4[1];
            pcVar16 = pcVar4 + 1;
            if (cVar2 == '%') {
                if (((uint64_t)var_4d0h <= piVar10) && ((int64_t *)var_4d0h == piVar10)) {
                    func_0x0001800890e0(&var_4d8h, (int64_t)piVar10 + (1 - var_4d0h));
                    piVar10 = (int64_t *)var_4d8h;
                }
                pcVar4 = pcVar4 + 2;
                *(char *)piVar10 = *pcVar16;
                piVar10 = (int64_t *)(var_4d8h + 1);
                var_4d8h = (int64_t)piVar10;
                goto code_r0x00018009dffd;
            }
            iVar15 = (int64_t)(int32_t)uVar14;
            uVar11 = (int32_t)uVar14 + 1;
            uVar12 = (uint64_t)uVar11;
            if (cVar2 == '*') {
                if ((int32_t)iVar9 < (int32_t)uVar11) {
                    fcn.180088560(arg1, 0x18063da20, uVar12);
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                pcVar4 = pcVar4 + 2;
                uVar7 = uVar12;
                iVar13 = var_4c8h;
                if ((int32_t)uVar11 < 1) {
                    if ((int32_t)uVar11 < -9999) {
                        uVar5 = fcn.180085370(var_4c8h, uVar12);
                        piVar10 = (int64_t *)var_4d8h;
                    } else {
                        uVar5 = (int64_t)(int32_t)uVar11 * 0x10 + *(int64_t *)(var_4c8h + 0x40);
                    }
                } else {
                    uVar5 = *(int64_t *)(var_4c8h + 0x28) + iVar15 * 0x10;
                    if (*(uint64_t *)(var_4c8h + 0x40) <= uVar5) {
                        uVar5 = *(uint64_t *)0x180782430;
                    }
                }
                uVar14 = uVar12;
                if (uVar5 == *(uint64_t *)0x180782430) goto code_r0x00018009dffd;
    // switch table (8 cases) at 0x18009e16c
                switch(*(undefined4 *)(uVar5 + 0xc)) {
                case 0:
                    if ((uint64_t)(var_4d0h - (int64_t)piVar10) < 3) {
                        func_0x0001800890e0(&var_4d8h, (int64_t)piVar10 + (3 - var_4d0h));
                        piVar10 = (int64_t *)var_4d8h;
                    }
                    *(undefined2 *)piVar10 = 0x696e;
                    *(undefined *)((int64_t)piVar10 + 2) = 0x6c;
                    piVar10 = (int64_t *)(var_4d8h + 3);
                    var_4d8h = (int64_t)piVar10;
                    break;
                case 1:
                    iVar3 = func_0x000180085ff0(iVar13, uVar7 & 0xffffffff);
                    if (iVar3 == 0) {
                        if ((uint64_t)(var_4d0h - var_4d8h) < 5) {
                            func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 5);
                        }
                        *(undefined4 *)var_4d8h = 0x736c6166;
                        *(undefined *)(var_4d8h + 4) = 0x65;
                        piVar10 = (int64_t *)(var_4d8h + 5);
                        var_4d8h = (int64_t)piVar10;
                    } else {
                        if ((uint64_t)(var_4d0h - var_4d8h) < 4) {
                            func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 4);
                        }
                        *(undefined4 *)var_4d8h = 0x65757274;
                        piVar10 = (int64_t *)(var_4d8h + 4);
                        var_4d8h = (int64_t)piVar10;
                    }
                    break;
                default:
                    func_0x0001800893a0(iVar13, uVar7 & 0xffffffff);
                    func_0x0001800891f0(&var_4d8h);
                    piVar10 = (int64_t *)var_4d8h;
                    break;
                case 3:
                    uVar17 = func_0x000180085ea0(iVar13, uVar7 & 0xffffffff, 0);
                    iVar15 = func_0x000180098ac0(&var_278h, uVar17);
                    uVar7 = iVar15 - (int64_t)&var_278h;
                    if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                        func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                    }
                    func_0x000180498030(var_4d8h, &var_278h);
                    goto code_r0x00018009dff0;
                case 4:
                    uVar6 = func_0x000180086060(iVar13, uVar7 & 0xffffffff);
                    iVar15 = func_0x000180099080(&var_298h, uVar6);
                    uVar7 = iVar15 - (int64_t)&var_298h;
                    if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                        func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                    }
                    func_0x000180498030(var_4d8h, &var_298h, uVar7);
                    goto code_r0x00018009dff0;
                case 6:
                    piVar10 = (int64_t *)func_0x0001800860c0(iVar13, uVar7 & 0xffffffff, &var_508h);
                    uVar7 = var_508h;
                    if ((uint64_t)(var_4d0h - var_4d8h) < var_508h) {
                        func_0x0001800890e0(&var_4d8h, (var_508h - var_4d0h) + var_4d8h, 0xffffffff);
                    }
                    goto code_r0x00018009dfe3;
                case 0xffffffff:
                    break;
                }
                goto code_r0x00018009dffd;
            }
            uVar14 = (uint64_t)(int32_t)uVar11;
            pcVar4 = pcVar16;
            if ((int32_t)iVar9 < (int32_t)uVar11) {
                fcn.180088560(arg1, 0x18063da20, uVar12);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            while (uVar17 = (undefined4)((uint64_t)piVar10 >> 0x20), cVar2 != '\0') {
                iVar9 = func_0x00018045b928(0x18063e720, (int32_t)cVar2);
                uVar17 = (undefined4)((uint64_t)piVar10 >> 0x20);
                if (iVar9 == 0) break;
                cVar2 = pcVar4[1];
                pcVar4 = pcVar4 + 1;
            }
            if (5 < (uint64_t)((int64_t)pcVar4 - (int64_t)pcVar16)) {
                fcn.180088560(arg1, 0x18063e7e0);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            iVar3 = func_0x00018046cb80(*pcVar4);
            pcVar8 = pcVar4 + 1;
            if (iVar3 == 0) {
                pcVar8 = pcVar4;
            }
            iVar3 = func_0x00018046cb80(*pcVar8);
            pcVar4 = pcVar8 + 1;
            if (iVar3 == 0) {
                pcVar4 = pcVar8;
            }
            cVar2 = *pcVar4;
            if (cVar2 == '.') {
                iVar3 = func_0x00018046cb80(pcVar4[1]);
                pcVar8 = pcVar4 + (uint64_t)(iVar3 != 0) + 1;
                iVar3 = func_0x00018046cb80(*pcVar8);
                pcVar4 = pcVar8 + 1;
                if (iVar3 == 0) {
                    pcVar4 = pcVar8;
                }
                cVar2 = *pcVar4;
            }
            iVar3 = func_0x00018046cb80(cVar2);
            if (iVar3 != 0) {
                fcn.180088560(arg1, 0x18063e7b0);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            var_2b8h._0_1_ = 0x25;
            iVar9 = (int64_t)pcVar4 - (int64_t)pcVar16;
            func_0x000180498d90((int64_t)&var_2b8h + 1, pcVar16, (int32_t)iVar9 + 1);
            *(undefined *)((int64_t)&var_2b8h + iVar9 + 2) = 0;
            cVar2 = *pcVar4;
            iVar3 = (int32_t)cVar2;
            pcVar4 = pcVar4 + 1;
    // switch table (79 cases) at 0x18009e18c
            switch(iVar3) {
            case 0x2a:
                fcn.180088560(arg1, 0x18063e790);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            default:
                fcn.180088560(arg1, 0x18063e768);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            case 0x45:
            case 0x47:
            case 0x65:
            case 0x66:
            case 0x67:
                uVar6 = func_0x000180085ea0(arg1, uVar12, &var_50ch);
                if (var_50ch == 0) {
code_r0x00018009e0f4:
                    fcn.180088470(arg1, uVar12, 3);
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                func_0x000180065f60(&var_248h, 0x200, &var_2b8h, uVar6);
                goto code_r0x00018009df5f;
            case 0x58:
            case 0x6f:
            case 0x75:
            case 0x78:
                uVar7 = *(uint64_t *)0x180782430;
                if ((int32_t)uVar11 < 1) {
                    if ((int32_t)uVar11 < -9999) {
                        uVar5 = fcn.180085370(arg1, uVar12, iVar3);
                    } else {
                        uVar5 = uVar14 * 0x10 + *(int64_t *)(arg1 + 0x40);
                    }
                } else {
                    uVar5 = *(int64_t *)(arg1 + 0x28) + iVar15 * 0x10;
                    if (*(uint64_t *)(arg1 + 0x40) <= uVar5) {
                        uVar5 = *(uint64_t *)0x180782430;
                    }
                }
                if ((uVar5 == uVar7) || (*(int32_t *)(uVar5 + 0xc) != 4)) {
                    dVar18 = (double)func_0x000180085ea0(arg1, uVar12, (int64_t)&var_514h + 4);
                    if (var_514h._4_4_ == 0) goto code_r0x00018009e0f4;
                    if (0.0 <= dVar18) {
                        iVar15 = 0;
                        if ((9.223372036854776e+18 <= dVar18) &&
                           (dVar18 = dVar18 - 9.223372036854776e+18, dVar18 < 9.223372036854776e+18)) {
                            iVar15 = -0x8000000000000000;
                        }
                        piVar10 = (int64_t *)((int64_t)dVar18 + iVar15);
                    } else {
                        piVar10 = (int64_t *)(int64_t)dVar18;
                    }
                } else {
                    piVar10 = (int64_t *)func_0x000180088910(arg1, uVar12);
                }
                *(undefined2 *)((int64_t)&var_2b8h + iVar9 + 1) = 0x6c6c;
                *(char *)((int64_t)&var_2b8h + iVar9 + 3) = cVar2;
                *(undefined *)((int64_t)&var_2b8h + iVar9 + 4) = 0;
                goto code_r0x00018009df47;
            case 99:
                dVar18 = (double)func_0x000180085ea0(arg1, uVar12, &var_518h);
                if (var_518h == 0) goto code_r0x00018009e0f4;
                iVar3 = func_0x000180065f60(&var_248h, 0x200, &var_2b8h, CONCAT44(uVar17, (int32_t)dVar18));
                uVar7 = (uint64_t)iVar3;
                if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                    func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                }
                piVar10 = &var_248h;
                uVar12 = uVar14;
                break;
            case 100:
            case 0x69:
                uVar7 = *(uint64_t *)0x180782430;
                if ((int32_t)uVar11 < 1) {
                    if ((int32_t)uVar11 < -9999) {
                        uVar5 = fcn.180085370(arg1, uVar12, iVar3);
                    } else {
                        uVar5 = uVar14 * 0x10 + *(int64_t *)(arg1 + 0x40);
                    }
                } else {
                    uVar5 = *(int64_t *)(arg1 + 0x28) + iVar15 * 0x10;
                    if (*(uint64_t *)(arg1 + 0x40) <= uVar5) {
                        uVar5 = *(uint64_t *)0x180782430;
                    }
                }
                if ((uVar5 == uVar7) || (*(int32_t *)(uVar5 + 0xc) != 4)) {
                    dVar18 = (double)func_0x000180085ea0(arg1, uVar12, &var_514h);
                    if ((int32_t)var_514h == 0) goto code_r0x00018009e0f4;
                    piVar10 = (int64_t *)(int64_t)dVar18;
                } else {
                    piVar10 = (int64_t *)func_0x000180088910(arg1, uVar12);
                }
                *(undefined2 *)((int64_t)&var_2b8h + iVar9 + 1) = 0x6c6c;
                *(char *)((int64_t)&var_2b8h + iVar9 + 3) = cVar2;
                *(undefined *)((int64_t)&var_2b8h + iVar9 + 4) = 0;
code_r0x00018009df47:
                func_0x000180065f60(&var_248h, 0x200, &var_2b8h, piVar10);
code_r0x00018009df5f:
                uVar7 = func_0x000180498cd0(&var_248h);
                if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                    func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                }
                piVar10 = &var_248h;
                uVar12 = uVar14;
                break;
            case 0x71:
                pcVar16 = (char *)func_0x0001800860c0(arg1, uVar12, &var_520h);
                iVar9 = var_520h;
                if (pcVar16 == (char *)0x0) {
code_r0x00018009e106:
                    fcn.180088470(arg1, uVar12, 6);
                    pcVar1 = (code *)swi(3);
                    (*pcVar1)();
                    return;
                }
                if ((uint64_t)(var_4d0h - var_4d8h) < var_520h + 2U) {
                    func_0x0001800890e0(&var_4d8h, var_4d8h + ((var_520h + 2U) - var_4d0h), 0xffffffff);
                }
                if (((uint64_t)var_4d0h <= (uint64_t)var_4d8h) && (var_4d0h == var_4d8h)) {
                    func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                }
                *(undefined *)var_4d8h = 0x22;
                var_4d8h = var_4d8h + 1;
                if (iVar9 != 0) {
                    do {
                        cVar2 = *pcVar16;
                        iVar9 = iVar9 + -1;
                        if (cVar2 == '\0') {
                            if ((uint64_t)(var_4d0h - var_4d8h) < 4) {
                                func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 4, 0xffffffff);
                            }
                            *(undefined4 *)var_4d8h = 0x3030305c;
                            var_4d8h = var_4d8h + 4;
                        } else if (cVar2 == '\n') {
code_r0x00018009ddce:
                            if (((uint64_t)var_4d0h <= (uint64_t)var_4d8h) && (var_4d0h == var_4d8h)) {
                                func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                            }
                            *(undefined *)var_4d8h = 0x5c;
                            var_4d8h = var_4d8h + 1;
                            if (((uint64_t)var_4d8h < (uint64_t)var_4d0h) || (var_4d0h != var_4d8h)) {
code_r0x00018009dd7c:
                                *(char *)var_4d8h = *pcVar16;
                                var_4d8h = var_4d8h + 1;
                            } else {
                                func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                                *(char *)var_4d8h = *pcVar16;
                                var_4d8h = var_4d8h + 1;
                            }
                        } else {
                            if (cVar2 != '\r') {
                                if ((cVar2 == '\"') || (cVar2 == '\\')) goto code_r0x00018009ddce;
                                if (((uint64_t)var_4d0h <= (uint64_t)var_4d8h) && (var_4d0h == var_4d8h)) {
                                    func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                                }
                                goto code_r0x00018009dd7c;
                            }
                            if ((uint64_t)(var_4d0h - var_4d8h) < 2) {
                                func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 2, 0xffffffff);
                            }
                            *(undefined2 *)var_4d8h = 0x725c;
                            var_4d8h = var_4d8h + 2;
                        }
                        pcVar16 = pcVar16 + 1;
                    } while (iVar9 != 0);
                    iVar9 = 0;
                    arg1 = var_500h;
                }
                var_520h = iVar9 + -1;
                if (((uint64_t)var_4d0h <= (uint64_t)var_4d8h) && (var_4d0h == var_4d8h)) {
                    func_0x0001800890e0(&var_4d8h, (var_4d8h - var_4d0h) + 1, 0xffffffff);
                }
                *(undefined *)var_4d8h = 0x22;
                piVar10 = (int64_t *)(var_4d8h + 1);
                iVar9 = var_528h;
                var_4d8h = (int64_t)piVar10;
                goto code_r0x00018009dffd;
            case 0x73:
                piVar10 = (int64_t *)func_0x0001800860c0(arg1, uVar12, &var_4f8h);
                uVar7 = var_4f8h;
                if (piVar10 == (int64_t *)0x0) goto code_r0x00018009e106;
                if ((var_2b8h._2_1_ != '\0') &&
                   ((iVar9 = func_0x00018045b928(&var_2b8h, 0x2e), iVar9 != 0 || (uVar7 < 100))))
                goto code_r0x00018009df47;
                uVar12 = uVar14;
                if ((uint64_t)(var_4d0h - var_4d8h) < uVar7) {
                    func_0x0001800890e0(&var_4d8h, (uVar7 - var_4d0h) + var_4d8h, 0xffffffff);
                }
            }
code_r0x00018009dfe3:
            func_0x000180498030(var_4d8h, piVar10, uVar7);
            iVar9 = var_528h;
code_r0x00018009dff0:
            piVar10 = (int64_t *)(var_4d8h + uVar7);
            uVar14 = uVar12;
            var_4d8h = (int64_t)piVar10;
code_r0x00018009dffd:
        } while (pcVar4 < (uint64_t)var_4f0h);
    }
    iVar15 = var_4c0h;
    iVar9 = var_4c8h;
    if (var_4c0h == 0) {
        func_0x0001800867f0(var_4c8h, &var_4b8h, (int64_t)piVar10 + (-0x20 - (int64_t)&var_4d8h));
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_4c8h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_4c8h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_4c8h, 1);
            piVar10 = (int64_t *)var_4d8h;
        }
        iVar13 = *(int64_t *)(iVar9 + 0x40);
        if (piVar10 == (int64_t *)var_4d0h) {
            uVar6 = func_0x00018009a7e0(iVar9, iVar15);
            *(undefined8 *)(iVar13 + -0x10) = uVar6;
            *(undefined4 *)(iVar13 + -4) = 6;
        } else {
            uVar6 = func_0x00018009a8e0(iVar9, iVar15 + 0x18, (int64_t)piVar10 + (-0x18 - iVar15));
            *(undefined8 *)(iVar13 + -0x10) = uVar6;
            *(undefined4 *)(iVar13 + -4) = 6;
        }
    }
    func_0x000180459870(var_48h ^ (uint64_t)auStack_548);
    return;
}

// ============================================================
// Function: FUN_18009e200
// Address: 0x18009e200
// Size: 152 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.18009e200(int64_t arg1)
{
    uint32_t uVar1;
    double *pdVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    undefined8 uVar8;
    int64_t *piVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    int64_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    piVar9 = *(int64_t **)(arg1 + 0x28);
    piVar13 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar9;
    if (piVar13 <= piVar9) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009e507;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar9 = *(int64_t **)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar9;
        if (piVar13 <= piVar9) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar10 = *piVar7;
    uVar14 = iVar10 + 0x18;
    if (uVar14 == 0) {
code_r0x00018009e507:
        fcn.180088470(arg1, 1, 6);
        pcVar4 = (code *)swi(3);
        uVar8 = (*pcVar4)();
        return uVar8;
    }
    piVar9 = piVar9 + 2;
    uVar1 = *(uint32_t *)(iVar10 + 0x14);
    piVar7 = piVar9;
    if (piVar13 <= piVar9) {
        piVar7 = *(int64_t **)0x180782430;
    }
    uVar12 = uVar14;
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar15 = 0x180620388;
        uVar11 = 1;
        func_0x000180086fd0(arg1, 0, 0);
    } else {
        if (piVar13 <= piVar9) {
            piVar9 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar5 = func_0x0001800a8360(arg1);
            if (iVar5 == 0) goto code_r0x00018009e51b;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
                piVar9 = *(int64_t **)0x180782430;
            }
        }
        iVar15 = *piVar9 + 0x18;
        if (iVar15 == 0) {
code_r0x00018009e51b:
            fcn.180088470(arg1, 2, 6);
            pcVar4 = (code *)swi(3);
            uVar8 = (*pcVar4)();
            return uVar8;
        }
        uVar11 = (uint64_t)*(uint32_t *)(*piVar9 + 0x14);
        func_0x000180086fd0(arg1, 0, 0);
        if (uVar11 == 0) {
            uVar12 = iVar10 + 0x19;
        }
    }
    iVar5 = 0;
    iVar10 = uVar1 + uVar14;
    for (; uVar12 <= iVar10 - uVar11; uVar12 = uVar12 + 1) {
        iVar6 = func_0x000180497f30(uVar12, iVar15, uVar11);
        if (iVar6 == 0) {
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar6 = func_0x000180085510(arg1, 1), iVar6 == 0)) goto code_r0x00018009e52f;
            pdVar2 = *(double **)(arg1 + 0x40);
            iVar5 = iVar5 + 1;
            *(undefined4 *)((int64_t)pdVar2 + 0xc) = 3;
            *pdVar2 = (double)iVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x0001800867f0(arg1, uVar14, uVar12 - uVar14);
            iVar3 = *(int64_t *)(arg1 + 0x40);
            func_0x0001800a8680(arg1, iVar3 + -0x30, iVar3 + -0x20, iVar3 + -0x10);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
            uVar14 = uVar12 + uVar11;
            if (uVar11 != 0) {
                uVar12 = uVar14 - 1;
            }
        }
    }
    if (uVar11 != 0) {
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = func_0x000180085510(arg1, 1), iVar6 == 0)) {
code_r0x00018009e52f:
            func_0x000180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar4 = (code *)swi(3);
            uVar8 = (*pcVar4)();
            return uVar8;
        }
        pdVar2 = *(double **)(arg1 + 0x40);
        *(undefined4 *)((int64_t)pdVar2 + 0xc) = 3;
        *pdVar2 = (double)(iVar5 + 1);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x0001800867f0(arg1, uVar14, iVar10 - uVar14);
        iVar10 = *(int64_t *)(arg1 + 0x40);
        func_0x0001800a8680(arg1, iVar10 + -0x30, iVar10 + -0x20, iVar10 + -0x10);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
    }
    return 1;
}

// ============================================================
// Function: FUN_18009e298
// Address: 0x18009e298
// Size: 623 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.18009e200(int64_t arg1)
{
    uint32_t uVar1;
    double *pdVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    undefined8 uVar8;
    int64_t *piVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    int64_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    piVar9 = *(int64_t **)(arg1 + 0x28);
    piVar13 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar9;
    if (piVar13 <= piVar9) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009e507;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar9 = *(int64_t **)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar9;
        if (piVar13 <= piVar9) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar10 = *piVar7;
    uVar14 = iVar10 + 0x18;
    if (uVar14 == 0) {
code_r0x00018009e507:
        fcn.180088470(arg1, 1, 6);
        pcVar4 = (code *)swi(3);
        uVar8 = (*pcVar4)();
        return uVar8;
    }
    piVar9 = piVar9 + 2;
    uVar1 = *(uint32_t *)(iVar10 + 0x14);
    piVar7 = piVar9;
    if (piVar13 <= piVar9) {
        piVar7 = *(int64_t **)0x180782430;
    }
    uVar12 = uVar14;
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar15 = 0x180620388;
        uVar11 = 1;
        func_0x000180086fd0(arg1, 0, 0);
    } else {
        if (piVar13 <= piVar9) {
            piVar9 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar5 = func_0x0001800a8360(arg1);
            if (iVar5 == 0) goto code_r0x00018009e51b;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
                piVar9 = *(int64_t **)0x180782430;
            }
        }
        iVar15 = *piVar9 + 0x18;
        if (iVar15 == 0) {
code_r0x00018009e51b:
            fcn.180088470(arg1, 2, 6);
            pcVar4 = (code *)swi(3);
            uVar8 = (*pcVar4)();
            return uVar8;
        }
        uVar11 = (uint64_t)*(uint32_t *)(*piVar9 + 0x14);
        func_0x000180086fd0(arg1, 0, 0);
        if (uVar11 == 0) {
            uVar12 = iVar10 + 0x19;
        }
    }
    iVar5 = 0;
    iVar10 = uVar1 + uVar14;
    for (; uVar12 <= iVar10 - uVar11; uVar12 = uVar12 + 1) {
        iVar6 = func_0x000180497f30(uVar12, iVar15, uVar11);
        if (iVar6 == 0) {
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar6 = func_0x000180085510(arg1, 1), iVar6 == 0)) goto code_r0x00018009e52f;
            pdVar2 = *(double **)(arg1 + 0x40);
            iVar5 = iVar5 + 1;
            *(undefined4 *)((int64_t)pdVar2 + 0xc) = 3;
            *pdVar2 = (double)iVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x0001800867f0(arg1, uVar14, uVar12 - uVar14);
            iVar3 = *(int64_t *)(arg1 + 0x40);
            func_0x0001800a8680(arg1, iVar3 + -0x30, iVar3 + -0x20, iVar3 + -0x10);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
            uVar14 = uVar12 + uVar11;
            if (uVar11 != 0) {
                uVar12 = uVar14 - 1;
            }
        }
    }
    if (uVar11 != 0) {
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = func_0x000180085510(arg1, 1), iVar6 == 0)) {
code_r0x00018009e52f:
            func_0x000180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar4 = (code *)swi(3);
            uVar8 = (*pcVar4)();
            return uVar8;
        }
        pdVar2 = *(double **)(arg1 + 0x40);
        *(undefined4 *)((int64_t)pdVar2 + 0xc) = 3;
        *pdVar2 = (double)(iVar5 + 1);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x0001800867f0(arg1, uVar14, iVar10 - uVar14);
        iVar10 = *(int64_t *)(arg1 + 0x40);
        func_0x0001800a8680(arg1, iVar10 + -0x30, iVar10 + -0x20, iVar10 + -0x10);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
    }
    return 1;
}

// ============================================================
// Function: FUN_18009e507
// Address: 0x18009e507
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.18009e200(int64_t arg1)
{
    uint32_t uVar1;
    double *pdVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    undefined8 uVar8;
    int64_t *piVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    int64_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    piVar9 = *(int64_t **)(arg1 + 0x28);
    piVar13 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar9;
    if (piVar13 <= piVar9) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009e507;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar9 = *(int64_t **)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar9;
        if (piVar13 <= piVar9) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar10 = *piVar7;
    uVar14 = iVar10 + 0x18;
    if (uVar14 == 0) {
code_r0x00018009e507:
        fcn.180088470(arg1, 1, 6);
        pcVar4 = (code *)swi(3);
        uVar8 = (*pcVar4)();
        return uVar8;
    }
    piVar9 = piVar9 + 2;
    uVar1 = *(uint32_t *)(iVar10 + 0x14);
    piVar7 = piVar9;
    if (piVar13 <= piVar9) {
        piVar7 = *(int64_t **)0x180782430;
    }
    uVar12 = uVar14;
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar15 = 0x180620388;
        uVar11 = 1;
        func_0x000180086fd0(arg1, 0, 0);
    } else {
        if (piVar13 <= piVar9) {
            piVar9 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar5 = func_0x0001800a8360(arg1);
            if (iVar5 == 0) goto code_r0x00018009e51b;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
                piVar9 = *(int64_t **)0x180782430;
            }
        }
        iVar15 = *piVar9 + 0x18;
        if (iVar15 == 0) {
code_r0x00018009e51b:
            fcn.180088470(arg1, 2, 6);
            pcVar4 = (code *)swi(3);
            uVar8 = (*pcVar4)();
            return uVar8;
        }
        uVar11 = (uint64_t)*(uint32_t *)(*piVar9 + 0x14);
        func_0x000180086fd0(arg1, 0, 0);
        if (uVar11 == 0) {
            uVar12 = iVar10 + 0x19;
        }
    }
    iVar5 = 0;
    iVar10 = uVar1 + uVar14;
    for (; uVar12 <= iVar10 - uVar11; uVar12 = uVar12 + 1) {
        iVar6 = func_0x000180497f30(uVar12, iVar15, uVar11);
        if (iVar6 == 0) {
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar6 = func_0x000180085510(arg1, 1), iVar6 == 0)) goto code_r0x00018009e52f;
            pdVar2 = *(double **)(arg1 + 0x40);
            iVar5 = iVar5 + 1;
            *(undefined4 *)((int64_t)pdVar2 + 0xc) = 3;
            *pdVar2 = (double)iVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x0001800867f0(arg1, uVar14, uVar12 - uVar14);
            iVar3 = *(int64_t *)(arg1 + 0x40);
            func_0x0001800a8680(arg1, iVar3 + -0x30, iVar3 + -0x20, iVar3 + -0x10);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
            uVar14 = uVar12 + uVar11;
            if (uVar11 != 0) {
                uVar12 = uVar14 - 1;
            }
        }
    }
    if (uVar11 != 0) {
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = func_0x000180085510(arg1, 1), iVar6 == 0)) {
code_r0x00018009e52f:
            func_0x000180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar4 = (code *)swi(3);
            uVar8 = (*pcVar4)();
            return uVar8;
        }
        pdVar2 = *(double **)(arg1 + 0x40);
        *(undefined4 *)((int64_t)pdVar2 + 0xc) = 3;
        *pdVar2 = (double)(iVar5 + 1);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x0001800867f0(arg1, uVar14, iVar10 - uVar14);
        iVar10 = *(int64_t *)(arg1 + 0x40);
        func_0x0001800a8680(arg1, iVar10 + -0x30, iVar10 + -0x20, iVar10 + -0x10);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
    }
    return 1;
}

// ============================================================
// Function: FUN_18009e51b
// Address: 0x18009e51b
// Size: 44 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.18009e200(int64_t arg1)
{
    uint32_t uVar1;
    double *pdVar2;
    int64_t iVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t *piVar7;
    undefined8 uVar8;
    int64_t *piVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    int64_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    piVar9 = *(int64_t **)(arg1 + 0x28);
    piVar13 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar9;
    if (piVar13 <= piVar9) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009e507;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar9 = *(int64_t **)(arg1 + 0x28);
        piVar13 = *(int64_t **)(arg1 + 0x40);
        piVar7 = piVar9;
        if (piVar13 <= piVar9) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar10 = *piVar7;
    uVar14 = iVar10 + 0x18;
    if (uVar14 == 0) {
code_r0x00018009e507:
        fcn.180088470(arg1, 1, 6);
        pcVar4 = (code *)swi(3);
        uVar8 = (*pcVar4)();
        return uVar8;
    }
    piVar9 = piVar9 + 2;
    uVar1 = *(uint32_t *)(iVar10 + 0x14);
    piVar7 = piVar9;
    if (piVar13 <= piVar9) {
        piVar7 = *(int64_t **)0x180782430;
    }
    uVar12 = uVar14;
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar15 = 0x180620388;
        uVar11 = 1;
        func_0x000180086fd0(arg1, 0, 0);
    } else {
        if (piVar13 <= piVar9) {
            piVar9 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar5 = func_0x0001800a8360(arg1);
            if (iVar5 == 0) goto code_r0x00018009e51b;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
                piVar9 = *(int64_t **)0x180782430;
            }
        }
        iVar15 = *piVar9 + 0x18;
        if (iVar15 == 0) {
code_r0x00018009e51b:
            fcn.180088470(arg1, 2, 6);
            pcVar4 = (code *)swi(3);
            uVar8 = (*pcVar4)();
            return uVar8;
        }
        uVar11 = (uint64_t)*(uint32_t *)(*piVar9 + 0x14);
        func_0x000180086fd0(arg1, 0, 0);
        if (uVar11 == 0) {
            uVar12 = iVar10 + 0x19;
        }
    }
    iVar5 = 0;
    iVar10 = uVar1 + uVar14;
    for (; uVar12 <= iVar10 - uVar11; uVar12 = uVar12 + 1) {
        iVar6 = func_0x000180497f30(uVar12, iVar15, uVar11);
        if (iVar6 == 0) {
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar6 = func_0x000180085510(arg1, 1), iVar6 == 0)) goto code_r0x00018009e52f;
            pdVar2 = *(double **)(arg1 + 0x40);
            iVar5 = iVar5 + 1;
            *(undefined4 *)((int64_t)pdVar2 + 0xc) = 3;
            *pdVar2 = (double)iVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x0001800867f0(arg1, uVar14, uVar12 - uVar14);
            iVar3 = *(int64_t *)(arg1 + 0x40);
            func_0x0001800a8680(arg1, iVar3 + -0x30, iVar3 + -0x20, iVar3 + -0x10);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
            uVar14 = uVar12 + uVar11;
            if (uVar11 != 0) {
                uVar12 = uVar14 - 1;
            }
        }
    }
    if (uVar11 != 0) {
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar6 = func_0x000180085510(arg1, 1), iVar6 == 0)) {
code_r0x00018009e52f:
            func_0x000180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar4 = (code *)swi(3);
            uVar8 = (*pcVar4)();
            return uVar8;
        }
        pdVar2 = *(double **)(arg1 + 0x40);
        *(undefined4 *)((int64_t)pdVar2 + 0xc) = 3;
        *pdVar2 = (double)(iVar5 + 1);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x0001800867f0(arg1, uVar14, iVar10 - uVar14);
        iVar10 = *(int64_t *)(arg1 + 0x40);
        func_0x0001800a8680(arg1, iVar10 + -0x30, iVar10 + -0x20, iVar10 + -0x10);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
    }
    return 1;
}

// ============================================================
// Function: FUN_18009e550
// Address: 0x18009e550
// Size: 1319 bytes
// ============================================================
undefined8 fcn.18009e550(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    char cVar5;
    char *pcVar6;
    
    pcVar6 = *(char **)arg2;
    *(undefined4 *)arg3 = 0;
    iVar4 = (int32_t)*pcVar6;
    pcVar6 = pcVar6 + 1;
    *(char **)arg2 = pcVar6;
    // switch table (91 cases) at 0x18009e9c4
    switch(iVar4) {
    case 0x20:
        return 8;
    case 0x21:
        cVar5 = *pcVar6;
        if (9 < (uint8_t)(cVar5 - 0x30U)) {
            *(undefined4 *)(arg1 + 0xc) = 8;
            return 8;
        }
        iVar4 = 0;
        break;
    default:
        fcn.180088560(*(undefined8 *)arg1, 0x18063e800, iVar4);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    case 0x3c:
    case 0x3d:
        *(undefined4 *)(arg1 + 8) = 1;
        return 8;
    case 0x3e:
        *(undefined4 *)(arg1 + 8) = 0;
        return 8;
    case 0x42:
        *(undefined4 *)arg3 = 1;
        return 1;
    case 0x48:
        *(undefined4 *)arg3 = 2;
        return 1;
    case 0x49:
        cVar5 = *pcVar6;
        if (9 < (uint8_t)(cVar5 - 0x30U)) {
            *(undefined4 *)arg3 = 4;
            return 1;
        }
        iVar4 = 0;
        do {
            pcVar6 = pcVar6 + 1;
            iVar2 = (int32_t)cVar5;
            *(char **)arg2 = pcVar6;
            cVar5 = *pcVar6;
            iVar4 = iVar2 + (iVar4 * 5 + -0x18) * 2;
            if (9 < (uint8_t)(cVar5 - 0x30U)) break;
        } while (iVar4 < 0xccccccc);
        if ((0x40000000 < iVar4) || ((uint8_t)(cVar5 - 0x30U) < 10)) {
            fcn.180088560(*(undefined8 *)arg1, 0x18063e870);
            pcVar1 = (code *)swi(3);
            uVar3 = (*pcVar1)();
            return uVar3;
        }
        if ((iVar4 < 0x11) && (0 < iVar4)) {
            *(int32_t *)arg3 = iVar4;
            return 1;
        }
        fcn.180088560(*(undefined8 *)arg1, 0x18063e848, iVar4, 0x10);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    case 0x4a:
    case 0x54:
        *(undefined4 *)arg3 = 4;
        return 1;
    case 0x4c:
        *(undefined4 *)arg3 = 8;
        return 1;
    case 0x58:
        return 7;
    case 0x62:
        *(undefined4 *)arg3 = 1;
        return 0;
    case 99:
        cVar5 = *pcVar6;
        if ((uint8_t)(cVar5 - 0x30U) < 10) {
            iVar4 = 0;
            do {
                iVar2 = (int32_t)cVar5;
                cVar5 = pcVar6[1];
                iVar4 = iVar2 + iVar4 * 10 + -0x30;
                pcVar6 = pcVar6 + 1;
                *(char **)arg2 = pcVar6;
                if (9 < (uint8_t)(cVar5 - 0x30U)) break;
            } while (iVar4 < 0xccccccc);
            if ((0x40000000 < iVar4) || ((uint8_t)(cVar5 - 0x30U) < 10)) {
                fcn.180088560(*(undefined8 *)arg1, 0x18063e870);
                pcVar1 = (code *)swi(3);
                uVar3 = (*pcVar1)();
                return uVar3;
            }
            *(int32_t *)arg3 = iVar4;
            if (iVar4 != -1) {
                return 3;
            }
        } else {
            *(undefined4 *)arg3 = 0xffffffff;
        }
        fcn.180088560(*(undefined8 *)arg1, 0x18063e820);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    case 100:
    case 0x6e:
        *(undefined4 *)arg3 = 8;
        return 2;
    case 0x66:
        *(undefined4 *)arg3 = 4;
        return 2;
    case 0x68:
        *(undefined4 *)arg3 = 2;
        return 0;
    case 0x69:
        cVar5 = *pcVar6;
        if (9 < (uint8_t)(cVar5 - 0x30U)) {
            *(undefined4 *)arg3 = 4;
            return 0;
        }
        iVar4 = 0;
        do {
            pcVar6 = pcVar6 + 1;
            iVar2 = (int32_t)cVar5;
            *(char **)arg2 = pcVar6;
            cVar5 = *pcVar6;
            iVar4 = iVar2 + (iVar4 * 5 + -0x18) * 2;
            if (9 < (uint8_t)(cVar5 - 0x30U)) break;
        } while (iVar4 < 0xccccccc);
        if ((0x40000000 < iVar4) || ((uint8_t)(cVar5 - 0x30U) < 10)) {
            fcn.180088560(*(undefined8 *)arg1, 0x18063e870);
            pcVar1 = (code *)swi(3);
            uVar3 = (*pcVar1)();
            return uVar3;
        }
        if ((iVar4 < 0x11) && (0 < iVar4)) {
            *(int32_t *)arg3 = iVar4;
            return 0;
        }
        fcn.180088560(*(undefined8 *)arg1, 0x18063e848, iVar4, 0x10);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    case 0x6a:
        *(undefined4 *)arg3 = 4;
        return 0;
    case 0x6c:
        *(undefined4 *)arg3 = 8;
        return 0;
    case 0x73:
        cVar5 = *pcVar6;
        if (9 < (uint8_t)(cVar5 - 0x30U)) {
            *(undefined4 *)arg3 = 4;
            return 4;
        }
        iVar4 = 0;
        do {
            iVar2 = (int32_t)cVar5;
            cVar5 = pcVar6[1];
            iVar4 = iVar2 + iVar4 * 10 + -0x30;
            pcVar6 = pcVar6 + 1;
            *(char **)arg2 = pcVar6;
            if (9 < (uint8_t)(cVar5 - 0x30U)) break;
        } while (iVar4 < 0xccccccc);
        if ((0x40000000 < iVar4) || ((uint8_t)(cVar5 - 0x30U) < 10)) {
            fcn.180088560(*(undefined8 *)arg1, 0x18063e870);
            pcVar1 = (code *)swi(3);
            uVar3 = (*pcVar1)();
            return uVar3;
        }
        if ((iVar4 < 0x11) && (0 < iVar4)) {
            *(int32_t *)arg3 = iVar4;
            return 4;
        }
        fcn.180088560(*(undefined8 *)arg1, 0x18063e848, iVar4, 0x10);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    case 0x78:
        *(undefined4 *)arg3 = 1;
        return 6;
    case 0x7a:
        return 5;
    }
    do {
        pcVar6 = pcVar6 + 1;
        iVar2 = (int32_t)cVar5;
        *(char **)arg2 = pcVar6;
        cVar5 = *pcVar6;
        iVar4 = iVar2 + (iVar4 * 5 + -0x18) * 2;
        if (9 < (uint8_t)(cVar5 - 0x30U)) break;
    } while (iVar4 < 0xccccccc);
    if ((0x40000000 < iVar4) || ((uint8_t)(cVar5 - 0x30U) < 10)) {
        fcn.180088560(*(undefined8 *)arg1, 0x18063e870);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    if ((iVar4 < 0x11) && (0 < iVar4)) {
        *(int32_t *)(arg1 + 0xc) = iVar4;
        return 8;
    }
    fcn.180088560(*(undefined8 *)arg1, 0x18063e848, iVar4, 0x10);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_18009ea80
// Address: 0x18009ea80
// Size: 244 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18009ea80(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t var_10h;
    undefined auStack_48 [31];
    undefined uStack_29;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    iVar7 = (int32_t)arg4;
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_48;
    uVar5 = (uint64_t)iVar7;
    iVar6 = (int32_t)arg3;
    iVar2 = 0;
    if (iVar6 == 0) {
        iVar2 = iVar7 + -1;
    }
    *(char *)((int64_t)&var_28h + (int64_t)iVar2) = (char)arg2;
    if (1 < iVar7) {
        uVar1 = 1;
        if (iVar6 == 0) {
            do {
                iVar2 = iVar7 - uVar1;
                uVar1 = uVar1 + 1;
                (&uStack_29)[iVar2] = (char)((uint64_t)arg2 >> 8);
                arg2 = (uint64_t)arg2 >> 8;
            } while ((int32_t)uVar1 < iVar7);
        } else {
            do {
                uVar4 = (uint64_t)uVar1;
                uVar1 = uVar1 + 1;
                *(char *)((int64_t)&var_28h + uVar4) = (char)((uint64_t)arg2 >> 8);
                arg2 = (uint64_t)arg2 >> 8;
            } while ((int32_t)uVar1 < iVar7);
        }
    }
    if (((int32_t)arg_28h != 0) && (8 < iVar7)) {
        if (iVar6 == 0) {
            uVar4 = 8;
            do {
                iVar3 = uVar5 - uVar4;
                uVar1 = (int32_t)uVar4 + 1;
                uVar4 = (uint64_t)uVar1;
                (&uStack_29)[iVar3] = 0xff;
            } while ((int32_t)uVar1 < iVar7);
        } else {
            func_0x0001804986e0(&var_20h, 0xff, uVar5 - 8);
        }
    }
    if ((uint64_t)(*(int64_t *)(arg1 + 8) - *(int64_t *)arg1) < uVar5) {
        func_0x0001800890e0(arg1, (*(int64_t *)arg1 - *(int64_t *)(arg1 + 8)) + uVar5, 0xffffffff);
    }
    func_0x000180498030(*(undefined8 *)arg1, &var_28h, uVar5);
    *(uint64_t *)arg1 = *(int64_t *)arg1 + uVar5;
    func_0x000180459870(var_18h ^ (uint64_t)auStack_48);
    return;
}

// ============================================================
// Function: FUN_18009eb80
// Address: 0x18009eb80
// Size: 161 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_308h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_2e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2cch
// WARNING: [rz-ghidra] Detected overlap for variable var_2d0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2d4h

void fcn.18009eb80(int64_t arg1)
{
    int64_t *piVar1;
    char cVar2;
    undefined uVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint32_t uVar16;
    int64_t *piVar17;
    char *pcVar18;
    uint64_t uVar19;
    undefined *puVar20;
    int64_t iVar21;
    double dVar22;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_328 [32];
    int64_t var_308h;
    int64_t var_2f8h;
    int64_t var_2f0h;
    int64_t var_2e8h;
    char *var_2e0h;
    int64_t var_2d8h;
    int32_t var_2d0h;
    int32_t var_2cch;
    int64_t var_2c8h;
    int64_t var_2c0h;
    int64_t var_2b8h;
    int64_t var_2b0h;
    int64_t var_288h;
    int64_t var_280h;
    int64_t var_278h;
    int64_t var_270h;
    int64_t var_268h;
    undefined uStack_69;
    int64_t var_68h;
    undefined uStack_59;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_328;
    piVar17 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar17 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar17 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009f3ba;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar17 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar17 = *(int64_t **)0x180782430;
        }
    }
    pcVar18 = (char *)(*piVar17 + 0x18);
    if (pcVar18 != (char *)0x0) {
        iVar5 = 1;
        iVar21 = 0;
        var_2e8h._0_4_ = 1;
        var_2e8h._4_4_ = 1;
        var_2f0h = arg1;
        var_2e0h = pcVar18;
        func_0x000180086510(arg1);
        var_288h = (int64_t)&var_268h;
        var_270h = 0;
        var_280h = (int64_t)&var_68h;
        cVar2 = *pcVar18;
        iVar9 = arg1;
        iVar8 = var_270h;
        do {
            var_278h = iVar9;
            var_270h = iVar8;
            if (cVar2 == '\0') {
                if (iVar8 == 0) {
                    func_0x0001800867f0(iVar9, &var_268h, var_288h + (-0x20 - (int64_t)&var_288h));
                } else {
                    if (*(uint64_t *)(*(int64_t *)(iVar9 + 0x20) + 0x28) <=
                        *(uint64_t *)(*(int64_t *)(iVar9 + 0x20) + 0x30)) {
                        (**(code **)0x180782658)(iVar9, 1);
                    }
                    iVar21 = *(int64_t *)(iVar9 + 0x40);
                    if (var_288h == var_280h) {
                        uVar11 = func_0x00018009a7e0(iVar9, iVar8);
                        *(undefined8 *)(iVar21 + -0x10) = uVar11;
                        *(undefined4 *)(iVar21 + -4) = 6;
                    } else {
                        uVar11 = func_0x00018009a8e0(iVar9, iVar8 + 0x18, (var_288h - iVar8) + -0x18);
                        *(undefined8 *)(iVar21 + -0x10) = uVar11;
                        *(undefined4 *)(iVar21 + -4) = 6;
                    }
                }
                func_0x000180459870(var_38h ^ (uint64_t)auStackY_328);
                return;
            }
            iVar6 = fcn.18009e550((int64_t)&var_2f0h, (int64_t)&var_2e0h, (int64_t)&var_2d8h);
            uVar16 = (uint32_t)var_2d8h;
            uVar19 = (uint64_t)(int32_t)(uint32_t)var_2d8h;
            var_2f8h._0_4_ = (uint32_t)var_2d8h;
            if ((iVar6 == 7) &&
               (((*var_2e0h == '\0' ||
                 (iVar7 = fcn.18009e550((int64_t)&var_2f0h, (int64_t)&var_2e0h, (int64_t)&var_2f8h), iVar7 == 3)) ||
                ((uint32_t)var_2f8h == 0)))) {
                func_0x000180088380(var_2f0h, 1, 0x18063e8f8);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            uVar15 = uVar19;
            if ((1 < (int32_t)(uint32_t)var_2f8h) && (iVar6 != 3)) {
                uVar13 = (uint32_t)var_2f8h;
                if ((int32_t)var_2e8h._4_4_ < (int32_t)(uint32_t)var_2f8h) {
                    uVar13 = var_2e8h._4_4_;
                }
                uVar12 = uVar13 - 1;
                if ((uVar12 & uVar13) != 0) {
                    func_0x000180088380(var_2f0h, 1, 0x18063e8c8);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                uVar12 = uVar13 - ((uint32_t)iVar21 & uVar12) & uVar12;
                iVar7 = uVar12 + uVar16;
                while (uVar15 = (int64_t)iVar7, 0 < (int32_t)uVar12) {
                    uVar12 = uVar12 - 1;
                    if (((uint64_t)var_280h <= (uint64_t)var_288h) && (var_280h == var_288h)) {
                        func_0x0001800890e0(&var_288h, (var_288h - var_280h) + 1, 0xffffffff);
                    }
                    *(undefined *)var_288h = 0;
                    var_288h = var_288h + 1;
                }
            }
            iVar21 = iVar21 + uVar15;
            iVar7 = iVar5 + 1;
            cVar2 = (char)uVar16;
    // switch table (9 cases) at 0x18009f494
            switch(iVar6) {
            case 0:
                dVar22 = (double)func_0x000180085ea0(arg1, iVar7, (int64_t)&var_2d8h + 4);
                if (var_2d8h._4_4_ == 0) {
                    fcn.180088470(arg1, iVar7, 3);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                iVar9 = (int64_t)dVar22;
                if (((int32_t)uVar16 < 8) &&
                   ((iVar8 = 1LL << (cVar2 * '\b' - 1U & 0x3f), -iVar9 != iVar8 && iVar9 <= -iVar8 || (iVar8 <= iVar9)))
                   ) {
                    func_0x000180088380(arg1, iVar7, 0x18063e1b0);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                var_308h._0_4_ = (uint32_t)((uint64_t)iVar9 >> 0x3f);
                fcn.18009ea80((int64_t)&var_288h, iVar9, (uint64_t)(uint32_t)var_2e8h, (uint64_t)uVar16, 
                              CONCAT44(var_308h._4_4_, (uint32_t)var_308h));
                iVar5 = iVar7;
                break;
            case 1:
                dVar22 = (double)func_0x000180085ea0(arg1, iVar7, &var_2d0h);
                if (var_2d0h == 0) {
code_r0x00018009f434:
                    fcn.180088470(arg1, iVar7, 3);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                uVar15 = (uint64_t)dVar22;
                if (((int32_t)uVar16 < 8) && ((uint64_t)(1LL << (cVar2 * '\b' & 0x3fU)) <= uVar15)) {
                    func_0x000180088380(arg1, iVar7, 0x18063e8b0);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                iVar5 = 0;
                if ((uint32_t)var_2e8h == 0) {
                    iVar5 = uVar16 - 1;
                }
                *(char *)((int64_t)&var_68h + (int64_t)iVar5) = (char)uVar15;
                if (1 < (int32_t)uVar16) {
                    uVar14 = 1;
                    if ((uint32_t)var_2e8h == 0) {
                        do {
                            iVar5 = (int32_t)uVar14;
                            uVar13 = iVar5 + 1;
                            uVar14 = (uint64_t)uVar13;
                            (&uStack_69)[(int32_t)(uVar16 - iVar5)] = (char)(uVar15 >> 8);
                            uVar15 = uVar15 >> 8;
                        } while ((int32_t)uVar13 < (int32_t)uVar16);
                    } else {
                        do {
                            uVar13 = (int32_t)uVar14 + 1;
                            *(char *)((int64_t)&var_68h + uVar14) = (char)(uVar15 >> 8);
                            uVar14 = (uint64_t)uVar13;
                            uVar15 = uVar15 >> 8;
                        } while ((int32_t)uVar13 < (int32_t)uVar16);
                    }
                }
                if ((uint64_t)(var_280h - var_288h) < uVar19) {
                    func_0x0001800890e0(&var_288h, (uVar19 - var_280h) + var_288h, 0xffffffff);
                }
                piVar17 = &var_68h;
                goto code_r0x00018009eefd;
            case 2:
                dVar22 = (double)func_0x000180085ea0(arg1, iVar7, &var_2cch);
                if (var_2cch == 0) goto code_r0x00018009f434;
                if (uVar16 == 4) {
                    var_2b0h = CONCAT44(var_2b0h._4_4_, (float)dVar22);
                } else {
                    var_2b0h = (int64_t)dVar22;
                }
                piVar17 = &var_2b0h;
                if ((uint32_t)var_2e8h == 1) {
                    piVar1 = &var_48h;
                    for (; uVar16 != 0; uVar16 = uVar16 - 1) {
                        uVar3 = *(undefined *)piVar17;
                        piVar17 = (int64_t *)((int64_t)piVar17 + 1);
                        *(undefined *)piVar1 = uVar3;
                        piVar1 = (int64_t *)((int64_t)piVar1 + 1);
                    }
                } else {
                    puVar20 = (undefined *)((int64_t)&var_48h + (int64_t)(int32_t)(uVar16 - 1));
                    for (; uVar16 != 0; uVar16 = uVar16 - 1) {
                        uVar3 = *(undefined *)piVar17;
                        piVar17 = (int64_t *)((int64_t)piVar17 + 1);
                        *puVar20 = uVar3;
                        puVar20 = puVar20 + -1;
                    }
                }
                if ((uint64_t)(var_280h - var_288h) < uVar19) {
                    func_0x0001800890e0(&var_288h, (uVar19 - var_280h) + var_288h, 0xffffffff);
                }
                piVar17 = &var_48h;
code_r0x00018009eefd:
                func_0x000180498030(var_288h, piVar17, uVar19);
                var_288h = var_288h + uVar19;
                iVar5 = iVar7;
                break;
            case 3:
                iVar9 = func_0x0001800860c0(arg1, iVar7, &var_2c8h);
                uVar15 = var_2c8h;
                if (iVar9 == 0) {
code_r0x00018009f47f:
                    fcn.180088470(arg1, iVar7, 6);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                if (uVar19 < (uint64_t)var_2c8h) {
                    func_0x000180088380(arg1, iVar7, 0x18063e890);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                if ((uint64_t)(var_280h - var_288h) < (uint64_t)var_2c8h) {
                    func_0x0001800890e0(&var_288h, (var_2c8h - var_280h) + var_288h, 0xffffffff);
                }
                func_0x000180498030(var_288h, iVar9, uVar15);
                var_288h = var_288h + uVar15;
                while (uVar15 < uVar19) {
                    uVar15 = uVar15 + 1;
                    if (((uint64_t)var_280h <= (uint64_t)var_288h) && (var_280h == var_288h)) {
                        func_0x0001800890e0(&var_288h, (var_288h - var_280h) + 1, 0xffffffff);
                    }
                    *(undefined *)var_288h = 0;
                    var_288h = var_288h + 1;
                }
                var_2c8h = uVar15 + 1;
                iVar5 = iVar7;
                break;
            case 4:
                iVar8 = func_0x0001800860c0(arg1, iVar7, &var_2c0h);
                iVar9 = var_2c0h;
                if (iVar8 == 0) goto code_r0x00018009f47f;
                if (((int32_t)uVar16 < 8) && ((uint64_t)(1LL << (cVar2 * '\b' & 0x3fU)) <= (uint64_t)var_2c0h)) {
                    func_0x000180088380(arg1, iVar7, 0x18063e968);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                iVar5 = 0;
                if ((uint32_t)var_2e8h == 0) {
                    iVar5 = uVar16 - 1;
                }
                *(char *)((int64_t)&var_58h + (int64_t)iVar5) = (char)var_2c0h;
                if (1 < (int32_t)uVar16) {
                    uVar15 = 1;
                    uVar14 = var_2c0h;
                    if ((uint32_t)var_2e8h == 0) {
                        do {
                            iVar5 = (int32_t)uVar15;
                            uVar13 = iVar5 + 1;
                            uVar15 = (uint64_t)uVar13;
                            (&uStack_59)[(int32_t)(uVar16 - iVar5)] = (char)(uVar14 >> 8);
                            uVar14 = uVar14 >> 8;
                        } while ((int32_t)uVar13 < (int32_t)uVar16);
                    } else {
                        do {
                            uVar13 = (int32_t)uVar15 + 1;
                            *(char *)((int64_t)&var_58h + uVar15) = (char)(uVar14 >> 8);
                            uVar15 = (uint64_t)uVar13;
                            uVar14 = uVar14 >> 8;
                        } while ((int32_t)uVar13 < (int32_t)uVar16);
                    }
                }
                if ((uint64_t)(var_280h - var_288h) < uVar19) {
                    func_0x0001800890e0(&var_288h, (uVar19 - var_280h) + var_288h, 0xffffffff);
                }
                func_0x000180498030(var_288h, &var_58h, uVar19);
                var_288h = var_288h + uVar19;
                if ((uint64_t)(var_280h - var_288h) < (uint64_t)iVar9) {
                    func_0x0001800890e0(&var_288h, iVar9 + (var_288h - var_280h), 0xffffffff);
                }
                func_0x000180498030(var_288h, iVar8, iVar9);
                var_288h = var_288h + iVar9;
                iVar21 = iVar21 + iVar9;
                iVar5 = iVar7;
                break;
            case 5:
                iVar9 = func_0x0001800860c0(arg1, iVar7, &var_2b8h);
                if (iVar9 == 0) goto code_r0x00018009f47f;
                iVar10 = func_0x000180498cd0(iVar9);
                iVar8 = var_2b8h;
                if (iVar10 != var_2b8h) {
                    func_0x000180088380(arg1, iVar7, 0x18063e950);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                if ((uint64_t)(var_280h - var_288h) < (uint64_t)var_2b8h) {
                    func_0x0001800890e0(&var_288h, (var_2b8h - var_280h) + var_288h, 0xffffffff);
                }
                func_0x000180498030(var_288h, iVar9, iVar8);
                var_288h = var_288h + iVar8;
                if (((uint64_t)var_280h <= (uint64_t)var_288h) && (var_280h == var_288h)) {
                    func_0x0001800890e0(&var_288h, (var_288h - var_280h) + 1, 0xffffffff);
                }
                *(undefined *)var_288h = 0;
                var_288h = var_288h + 1;
                iVar21 = iVar21 + 1 + iVar8;
                iVar5 = iVar7;
                break;
            case 6:
                if (((uint64_t)var_280h <= (uint64_t)var_288h) && (var_280h == var_288h)) {
                    func_0x0001800890e0(&var_288h, (var_288h - var_280h) + 1, 0xffffffff);
                }
                *(undefined *)var_288h = 0;
                var_288h = var_288h + 1;
            }
            cVar2 = *var_2e0h;
            iVar9 = var_278h;
            iVar8 = var_270h;
        } while( true );
    }
code_r0x00018009f3ba:
    fcn.180088470(arg1, 1, 6);
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_18009ec21
// Address: 0x18009ec21
// Size: 1945 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_308h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_2e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2cch
// WARNING: [rz-ghidra] Detected overlap for variable var_2d0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2d4h

void fcn.18009eb80(int64_t arg1)
{
    int64_t *piVar1;
    char cVar2;
    undefined uVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint32_t uVar16;
    int64_t *piVar17;
    char *pcVar18;
    uint64_t uVar19;
    undefined *puVar20;
    int64_t iVar21;
    double dVar22;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_328 [32];
    int64_t var_308h;
    int64_t var_2f8h;
    int64_t var_2f0h;
    int64_t var_2e8h;
    char *var_2e0h;
    int64_t var_2d8h;
    int32_t var_2d0h;
    int32_t var_2cch;
    int64_t var_2c8h;
    int64_t var_2c0h;
    int64_t var_2b8h;
    int64_t var_2b0h;
    int64_t var_288h;
    int64_t var_280h;
    int64_t var_278h;
    int64_t var_270h;
    int64_t var_268h;
    undefined uStack_69;
    int64_t var_68h;
    undefined uStack_59;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_328;
    piVar17 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar17 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar17 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009f3ba;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar17 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar17 = *(int64_t **)0x180782430;
        }
    }
    pcVar18 = (char *)(*piVar17 + 0x18);
    if (pcVar18 != (char *)0x0) {
        iVar5 = 1;
        iVar21 = 0;
        var_2e8h._0_4_ = 1;
        var_2e8h._4_4_ = 1;
        var_2f0h = arg1;
        var_2e0h = pcVar18;
        func_0x000180086510(arg1);
        var_288h = (int64_t)&var_268h;
        var_270h = 0;
        var_280h = (int64_t)&var_68h;
        cVar2 = *pcVar18;
        iVar9 = arg1;
        iVar8 = var_270h;
        do {
            var_278h = iVar9;
            var_270h = iVar8;
            if (cVar2 == '\0') {
                if (iVar8 == 0) {
                    func_0x0001800867f0(iVar9, &var_268h, var_288h + (-0x20 - (int64_t)&var_288h));
                } else {
                    if (*(uint64_t *)(*(int64_t *)(iVar9 + 0x20) + 0x28) <=
                        *(uint64_t *)(*(int64_t *)(iVar9 + 0x20) + 0x30)) {
                        (**(code **)0x180782658)(iVar9, 1);
                    }
                    iVar21 = *(int64_t *)(iVar9 + 0x40);
                    if (var_288h == var_280h) {
                        uVar11 = func_0x00018009a7e0(iVar9, iVar8);
                        *(undefined8 *)(iVar21 + -0x10) = uVar11;
                        *(undefined4 *)(iVar21 + -4) = 6;
                    } else {
                        uVar11 = func_0x00018009a8e0(iVar9, iVar8 + 0x18, (var_288h - iVar8) + -0x18);
                        *(undefined8 *)(iVar21 + -0x10) = uVar11;
                        *(undefined4 *)(iVar21 + -4) = 6;
                    }
                }
                func_0x000180459870(var_38h ^ (uint64_t)auStackY_328);
                return;
            }
            iVar6 = fcn.18009e550((int64_t)&var_2f0h, (int64_t)&var_2e0h, (int64_t)&var_2d8h);
            uVar16 = (uint32_t)var_2d8h;
            uVar19 = (uint64_t)(int32_t)(uint32_t)var_2d8h;
            var_2f8h._0_4_ = (uint32_t)var_2d8h;
            if ((iVar6 == 7) &&
               (((*var_2e0h == '\0' ||
                 (iVar7 = fcn.18009e550((int64_t)&var_2f0h, (int64_t)&var_2e0h, (int64_t)&var_2f8h), iVar7 == 3)) ||
                ((uint32_t)var_2f8h == 0)))) {
                func_0x000180088380(var_2f0h, 1, 0x18063e8f8);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            uVar15 = uVar19;
            if ((1 < (int32_t)(uint32_t)var_2f8h) && (iVar6 != 3)) {
                uVar13 = (uint32_t)var_2f8h;
                if ((int32_t)var_2e8h._4_4_ < (int32_t)(uint32_t)var_2f8h) {
                    uVar13 = var_2e8h._4_4_;
                }
                uVar12 = uVar13 - 1;
                if ((uVar12 & uVar13) != 0) {
                    func_0x000180088380(var_2f0h, 1, 0x18063e8c8);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                uVar12 = uVar13 - ((uint32_t)iVar21 & uVar12) & uVar12;
                iVar7 = uVar12 + uVar16;
                while (uVar15 = (int64_t)iVar7, 0 < (int32_t)uVar12) {
                    uVar12 = uVar12 - 1;
                    if (((uint64_t)var_280h <= (uint64_t)var_288h) && (var_280h == var_288h)) {
                        func_0x0001800890e0(&var_288h, (var_288h - var_280h) + 1, 0xffffffff);
                    }
                    *(undefined *)var_288h = 0;
                    var_288h = var_288h + 1;
                }
            }
            iVar21 = iVar21 + uVar15;
            iVar7 = iVar5 + 1;
            cVar2 = (char)uVar16;
    // switch table (9 cases) at 0x18009f494
            switch(iVar6) {
            case 0:
                dVar22 = (double)func_0x000180085ea0(arg1, iVar7, (int64_t)&var_2d8h + 4);
                if (var_2d8h._4_4_ == 0) {
                    fcn.180088470(arg1, iVar7, 3);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                iVar9 = (int64_t)dVar22;
                if (((int32_t)uVar16 < 8) &&
                   ((iVar8 = 1LL << (cVar2 * '\b' - 1U & 0x3f), -iVar9 != iVar8 && iVar9 <= -iVar8 || (iVar8 <= iVar9)))
                   ) {
                    func_0x000180088380(arg1, iVar7, 0x18063e1b0);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                var_308h._0_4_ = (uint32_t)((uint64_t)iVar9 >> 0x3f);
                fcn.18009ea80((int64_t)&var_288h, iVar9, (uint64_t)(uint32_t)var_2e8h, (uint64_t)uVar16, 
                              CONCAT44(var_308h._4_4_, (uint32_t)var_308h));
                iVar5 = iVar7;
                break;
            case 1:
                dVar22 = (double)func_0x000180085ea0(arg1, iVar7, &var_2d0h);
                if (var_2d0h == 0) {
code_r0x00018009f434:
                    fcn.180088470(arg1, iVar7, 3);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                uVar15 = (uint64_t)dVar22;
                if (((int32_t)uVar16 < 8) && ((uint64_t)(1LL << (cVar2 * '\b' & 0x3fU)) <= uVar15)) {
                    func_0x000180088380(arg1, iVar7, 0x18063e8b0);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                iVar5 = 0;
                if ((uint32_t)var_2e8h == 0) {
                    iVar5 = uVar16 - 1;
                }
                *(char *)((int64_t)&var_68h + (int64_t)iVar5) = (char)uVar15;
                if (1 < (int32_t)uVar16) {
                    uVar14 = 1;
                    if ((uint32_t)var_2e8h == 0) {
                        do {
                            iVar5 = (int32_t)uVar14;
                            uVar13 = iVar5 + 1;
                            uVar14 = (uint64_t)uVar13;
                            (&uStack_69)[(int32_t)(uVar16 - iVar5)] = (char)(uVar15 >> 8);
                            uVar15 = uVar15 >> 8;
                        } while ((int32_t)uVar13 < (int32_t)uVar16);
                    } else {
                        do {
                            uVar13 = (int32_t)uVar14 + 1;
                            *(char *)((int64_t)&var_68h + uVar14) = (char)(uVar15 >> 8);
                            uVar14 = (uint64_t)uVar13;
                            uVar15 = uVar15 >> 8;
                        } while ((int32_t)uVar13 < (int32_t)uVar16);
                    }
                }
                if ((uint64_t)(var_280h - var_288h) < uVar19) {
                    func_0x0001800890e0(&var_288h, (uVar19 - var_280h) + var_288h, 0xffffffff);
                }
                piVar17 = &var_68h;
                goto code_r0x00018009eefd;
            case 2:
                dVar22 = (double)func_0x000180085ea0(arg1, iVar7, &var_2cch);
                if (var_2cch == 0) goto code_r0x00018009f434;
                if (uVar16 == 4) {
                    var_2b0h = CONCAT44(var_2b0h._4_4_, (float)dVar22);
                } else {
                    var_2b0h = (int64_t)dVar22;
                }
                piVar17 = &var_2b0h;
                if ((uint32_t)var_2e8h == 1) {
                    piVar1 = &var_48h;
                    for (; uVar16 != 0; uVar16 = uVar16 - 1) {
                        uVar3 = *(undefined *)piVar17;
                        piVar17 = (int64_t *)((int64_t)piVar17 + 1);
                        *(undefined *)piVar1 = uVar3;
                        piVar1 = (int64_t *)((int64_t)piVar1 + 1);
                    }
                } else {
                    puVar20 = (undefined *)((int64_t)&var_48h + (int64_t)(int32_t)(uVar16 - 1));
                    for (; uVar16 != 0; uVar16 = uVar16 - 1) {
                        uVar3 = *(undefined *)piVar17;
                        piVar17 = (int64_t *)((int64_t)piVar17 + 1);
                        *puVar20 = uVar3;
                        puVar20 = puVar20 + -1;
                    }
                }
                if ((uint64_t)(var_280h - var_288h) < uVar19) {
                    func_0x0001800890e0(&var_288h, (uVar19 - var_280h) + var_288h, 0xffffffff);
                }
                piVar17 = &var_48h;
code_r0x00018009eefd:
                func_0x000180498030(var_288h, piVar17, uVar19);
                var_288h = var_288h + uVar19;
                iVar5 = iVar7;
                break;
            case 3:
                iVar9 = func_0x0001800860c0(arg1, iVar7, &var_2c8h);
                uVar15 = var_2c8h;
                if (iVar9 == 0) {
code_r0x00018009f47f:
                    fcn.180088470(arg1, iVar7, 6);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                if (uVar19 < (uint64_t)var_2c8h) {
                    func_0x000180088380(arg1, iVar7, 0x18063e890);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                if ((uint64_t)(var_280h - var_288h) < (uint64_t)var_2c8h) {
                    func_0x0001800890e0(&var_288h, (var_2c8h - var_280h) + var_288h, 0xffffffff);
                }
                func_0x000180498030(var_288h, iVar9, uVar15);
                var_288h = var_288h + uVar15;
                while (uVar15 < uVar19) {
                    uVar15 = uVar15 + 1;
                    if (((uint64_t)var_280h <= (uint64_t)var_288h) && (var_280h == var_288h)) {
                        func_0x0001800890e0(&var_288h, (var_288h - var_280h) + 1, 0xffffffff);
                    }
                    *(undefined *)var_288h = 0;
                    var_288h = var_288h + 1;
                }
                var_2c8h = uVar15 + 1;
                iVar5 = iVar7;
                break;
            case 4:
                iVar8 = func_0x0001800860c0(arg1, iVar7, &var_2c0h);
                iVar9 = var_2c0h;
                if (iVar8 == 0) goto code_r0x00018009f47f;
                if (((int32_t)uVar16 < 8) && ((uint64_t)(1LL << (cVar2 * '\b' & 0x3fU)) <= (uint64_t)var_2c0h)) {
                    func_0x000180088380(arg1, iVar7, 0x18063e968);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                iVar5 = 0;
                if ((uint32_t)var_2e8h == 0) {
                    iVar5 = uVar16 - 1;
                }
                *(char *)((int64_t)&var_58h + (int64_t)iVar5) = (char)var_2c0h;
                if (1 < (int32_t)uVar16) {
                    uVar15 = 1;
                    uVar14 = var_2c0h;
                    if ((uint32_t)var_2e8h == 0) {
                        do {
                            iVar5 = (int32_t)uVar15;
                            uVar13 = iVar5 + 1;
                            uVar15 = (uint64_t)uVar13;
                            (&uStack_59)[(int32_t)(uVar16 - iVar5)] = (char)(uVar14 >> 8);
                            uVar14 = uVar14 >> 8;
                        } while ((int32_t)uVar13 < (int32_t)uVar16);
                    } else {
                        do {
                            uVar13 = (int32_t)uVar15 + 1;
                            *(char *)((int64_t)&var_58h + uVar15) = (char)(uVar14 >> 8);
                            uVar15 = (uint64_t)uVar13;
                            uVar14 = uVar14 >> 8;
                        } while ((int32_t)uVar13 < (int32_t)uVar16);
                    }
                }
                if ((uint64_t)(var_280h - var_288h) < uVar19) {
                    func_0x0001800890e0(&var_288h, (uVar19 - var_280h) + var_288h, 0xffffffff);
                }
                func_0x000180498030(var_288h, &var_58h, uVar19);
                var_288h = var_288h + uVar19;
                if ((uint64_t)(var_280h - var_288h) < (uint64_t)iVar9) {
                    func_0x0001800890e0(&var_288h, iVar9 + (var_288h - var_280h), 0xffffffff);
                }
                func_0x000180498030(var_288h, iVar8, iVar9);
                var_288h = var_288h + iVar9;
                iVar21 = iVar21 + iVar9;
                iVar5 = iVar7;
                break;
            case 5:
                iVar9 = func_0x0001800860c0(arg1, iVar7, &var_2b8h);
                if (iVar9 == 0) goto code_r0x00018009f47f;
                iVar10 = func_0x000180498cd0(iVar9);
                iVar8 = var_2b8h;
                if (iVar10 != var_2b8h) {
                    func_0x000180088380(arg1, iVar7, 0x18063e950);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                if ((uint64_t)(var_280h - var_288h) < (uint64_t)var_2b8h) {
                    func_0x0001800890e0(&var_288h, (var_2b8h - var_280h) + var_288h, 0xffffffff);
                }
                func_0x000180498030(var_288h, iVar9, iVar8);
                var_288h = var_288h + iVar8;
                if (((uint64_t)var_280h <= (uint64_t)var_288h) && (var_280h == var_288h)) {
                    func_0x0001800890e0(&var_288h, (var_288h - var_280h) + 1, 0xffffffff);
                }
                *(undefined *)var_288h = 0;
                var_288h = var_288h + 1;
                iVar21 = iVar21 + 1 + iVar8;
                iVar5 = iVar7;
                break;
            case 6:
                if (((uint64_t)var_280h <= (uint64_t)var_288h) && (var_280h == var_288h)) {
                    func_0x0001800890e0(&var_288h, (var_288h - var_280h) + 1, 0xffffffff);
                }
                *(undefined *)var_288h = 0;
                var_288h = var_288h + 1;
            }
            cVar2 = *var_2e0h;
            iVar9 = var_278h;
            iVar8 = var_270h;
        } while( true );
    }
code_r0x00018009f3ba:
    fcn.180088470(arg1, 1, 6);
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_18009f3ba
// Address: 0x18009f3ba
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_308h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_2e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2cch
// WARNING: [rz-ghidra] Detected overlap for variable var_2d0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2d4h

void fcn.18009eb80(int64_t arg1)
{
    int64_t *piVar1;
    char cVar2;
    undefined uVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint32_t uVar16;
    int64_t *piVar17;
    char *pcVar18;
    uint64_t uVar19;
    undefined *puVar20;
    int64_t iVar21;
    double dVar22;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_328 [32];
    int64_t var_308h;
    int64_t var_2f8h;
    int64_t var_2f0h;
    int64_t var_2e8h;
    char *var_2e0h;
    int64_t var_2d8h;
    int32_t var_2d0h;
    int32_t var_2cch;
    int64_t var_2c8h;
    int64_t var_2c0h;
    int64_t var_2b8h;
    int64_t var_2b0h;
    int64_t var_288h;
    int64_t var_280h;
    int64_t var_278h;
    int64_t var_270h;
    int64_t var_268h;
    undefined uStack_69;
    int64_t var_68h;
    undefined uStack_59;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_328;
    piVar17 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar17 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar17 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009f3ba;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar17 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar17 = *(int64_t **)0x180782430;
        }
    }
    pcVar18 = (char *)(*piVar17 + 0x18);
    if (pcVar18 != (char *)0x0) {
        iVar5 = 1;
        iVar21 = 0;
        var_2e8h._0_4_ = 1;
        var_2e8h._4_4_ = 1;
        var_2f0h = arg1;
        var_2e0h = pcVar18;
        func_0x000180086510(arg1);
        var_288h = (int64_t)&var_268h;
        var_270h = 0;
        var_280h = (int64_t)&var_68h;
        cVar2 = *pcVar18;
        iVar9 = arg1;
        iVar8 = var_270h;
        do {
            var_278h = iVar9;
            var_270h = iVar8;
            if (cVar2 == '\0') {
                if (iVar8 == 0) {
                    func_0x0001800867f0(iVar9, &var_268h, var_288h + (-0x20 - (int64_t)&var_288h));
                } else {
                    if (*(uint64_t *)(*(int64_t *)(iVar9 + 0x20) + 0x28) <=
                        *(uint64_t *)(*(int64_t *)(iVar9 + 0x20) + 0x30)) {
                        (**(code **)0x180782658)(iVar9, 1);
                    }
                    iVar21 = *(int64_t *)(iVar9 + 0x40);
                    if (var_288h == var_280h) {
                        uVar11 = func_0x00018009a7e0(iVar9, iVar8);
                        *(undefined8 *)(iVar21 + -0x10) = uVar11;
                        *(undefined4 *)(iVar21 + -4) = 6;
                    } else {
                        uVar11 = func_0x00018009a8e0(iVar9, iVar8 + 0x18, (var_288h - iVar8) + -0x18);
                        *(undefined8 *)(iVar21 + -0x10) = uVar11;
                        *(undefined4 *)(iVar21 + -4) = 6;
                    }
                }
                func_0x000180459870(var_38h ^ (uint64_t)auStackY_328);
                return;
            }
            iVar6 = fcn.18009e550((int64_t)&var_2f0h, (int64_t)&var_2e0h, (int64_t)&var_2d8h);
            uVar16 = (uint32_t)var_2d8h;
            uVar19 = (uint64_t)(int32_t)(uint32_t)var_2d8h;
            var_2f8h._0_4_ = (uint32_t)var_2d8h;
            if ((iVar6 == 7) &&
               (((*var_2e0h == '\0' ||
                 (iVar7 = fcn.18009e550((int64_t)&var_2f0h, (int64_t)&var_2e0h, (int64_t)&var_2f8h), iVar7 == 3)) ||
                ((uint32_t)var_2f8h == 0)))) {
                func_0x000180088380(var_2f0h, 1, 0x18063e8f8);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            uVar15 = uVar19;
            if ((1 < (int32_t)(uint32_t)var_2f8h) && (iVar6 != 3)) {
                uVar13 = (uint32_t)var_2f8h;
                if ((int32_t)var_2e8h._4_4_ < (int32_t)(uint32_t)var_2f8h) {
                    uVar13 = var_2e8h._4_4_;
                }
                uVar12 = uVar13 - 1;
                if ((uVar12 & uVar13) != 0) {
                    func_0x000180088380(var_2f0h, 1, 0x18063e8c8);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                uVar12 = uVar13 - ((uint32_t)iVar21 & uVar12) & uVar12;
                iVar7 = uVar12 + uVar16;
                while (uVar15 = (int64_t)iVar7, 0 < (int32_t)uVar12) {
                    uVar12 = uVar12 - 1;
                    if (((uint64_t)var_280h <= (uint64_t)var_288h) && (var_280h == var_288h)) {
                        func_0x0001800890e0(&var_288h, (var_288h - var_280h) + 1, 0xffffffff);
                    }
                    *(undefined *)var_288h = 0;
                    var_288h = var_288h + 1;
                }
            }
            iVar21 = iVar21 + uVar15;
            iVar7 = iVar5 + 1;
            cVar2 = (char)uVar16;
    // switch table (9 cases) at 0x18009f494
            switch(iVar6) {
            case 0:
                dVar22 = (double)func_0x000180085ea0(arg1, iVar7, (int64_t)&var_2d8h + 4);
                if (var_2d8h._4_4_ == 0) {
                    fcn.180088470(arg1, iVar7, 3);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                iVar9 = (int64_t)dVar22;
                if (((int32_t)uVar16 < 8) &&
                   ((iVar8 = 1LL << (cVar2 * '\b' - 1U & 0x3f), -iVar9 != iVar8 && iVar9 <= -iVar8 || (iVar8 <= iVar9)))
                   ) {
                    func_0x000180088380(arg1, iVar7, 0x18063e1b0);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                var_308h._0_4_ = (uint32_t)((uint64_t)iVar9 >> 0x3f);
                fcn.18009ea80((int64_t)&var_288h, iVar9, (uint64_t)(uint32_t)var_2e8h, (uint64_t)uVar16, 
                              CONCAT44(var_308h._4_4_, (uint32_t)var_308h));
                iVar5 = iVar7;
                break;
            case 1:
                dVar22 = (double)func_0x000180085ea0(arg1, iVar7, &var_2d0h);
                if (var_2d0h == 0) {
code_r0x00018009f434:
                    fcn.180088470(arg1, iVar7, 3);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                uVar15 = (uint64_t)dVar22;
                if (((int32_t)uVar16 < 8) && ((uint64_t)(1LL << (cVar2 * '\b' & 0x3fU)) <= uVar15)) {
                    func_0x000180088380(arg1, iVar7, 0x18063e8b0);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                iVar5 = 0;
                if ((uint32_t)var_2e8h == 0) {
                    iVar5 = uVar16 - 1;
                }
                *(char *)((int64_t)&var_68h + (int64_t)iVar5) = (char)uVar15;
                if (1 < (int32_t)uVar16) {
                    uVar14 = 1;
                    if ((uint32_t)var_2e8h == 0) {
                        do {
                            iVar5 = (int32_t)uVar14;
                            uVar13 = iVar5 + 1;
                            uVar14 = (uint64_t)uVar13;
                            (&uStack_69)[(int32_t)(uVar16 - iVar5)] = (char)(uVar15 >> 8);
                            uVar15 = uVar15 >> 8;
                        } while ((int32_t)uVar13 < (int32_t)uVar16);
                    } else {
                        do {
                            uVar13 = (int32_t)uVar14 + 1;
                            *(char *)((int64_t)&var_68h + uVar14) = (char)(uVar15 >> 8);
                            uVar14 = (uint64_t)uVar13;
                            uVar15 = uVar15 >> 8;
                        } while ((int32_t)uVar13 < (int32_t)uVar16);
                    }
                }
                if ((uint64_t)(var_280h - var_288h) < uVar19) {
                    func_0x0001800890e0(&var_288h, (uVar19 - var_280h) + var_288h, 0xffffffff);
                }
                piVar17 = &var_68h;
                goto code_r0x00018009eefd;
            case 2:
                dVar22 = (double)func_0x000180085ea0(arg1, iVar7, &var_2cch);
                if (var_2cch == 0) goto code_r0x00018009f434;
                if (uVar16 == 4) {
                    var_2b0h = CONCAT44(var_2b0h._4_4_, (float)dVar22);
                } else {
                    var_2b0h = (int64_t)dVar22;
                }
                piVar17 = &var_2b0h;
                if ((uint32_t)var_2e8h == 1) {
                    piVar1 = &var_48h;
                    for (; uVar16 != 0; uVar16 = uVar16 - 1) {
                        uVar3 = *(undefined *)piVar17;
                        piVar17 = (int64_t *)((int64_t)piVar17 + 1);
                        *(undefined *)piVar1 = uVar3;
                        piVar1 = (int64_t *)((int64_t)piVar1 + 1);
                    }
                } else {
                    puVar20 = (undefined *)((int64_t)&var_48h + (int64_t)(int32_t)(uVar16 - 1));
                    for (; uVar16 != 0; uVar16 = uVar16 - 1) {
                        uVar3 = *(undefined *)piVar17;
                        piVar17 = (int64_t *)((int64_t)piVar17 + 1);
                        *puVar20 = uVar3;
                        puVar20 = puVar20 + -1;
                    }
                }
                if ((uint64_t)(var_280h - var_288h) < uVar19) {
                    func_0x0001800890e0(&var_288h, (uVar19 - var_280h) + var_288h, 0xffffffff);
                }
                piVar17 = &var_48h;
code_r0x00018009eefd:
                func_0x000180498030(var_288h, piVar17, uVar19);
                var_288h = var_288h + uVar19;
                iVar5 = iVar7;
                break;
            case 3:
                iVar9 = func_0x0001800860c0(arg1, iVar7, &var_2c8h);
                uVar15 = var_2c8h;
                if (iVar9 == 0) {
code_r0x00018009f47f:
                    fcn.180088470(arg1, iVar7, 6);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                if (uVar19 < (uint64_t)var_2c8h) {
                    func_0x000180088380(arg1, iVar7, 0x18063e890);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                if ((uint64_t)(var_280h - var_288h) < (uint64_t)var_2c8h) {
                    func_0x0001800890e0(&var_288h, (var_2c8h - var_280h) + var_288h, 0xffffffff);
                }
                func_0x000180498030(var_288h, iVar9, uVar15);
                var_288h = var_288h + uVar15;
                while (uVar15 < uVar19) {
                    uVar15 = uVar15 + 1;
                    if (((uint64_t)var_280h <= (uint64_t)var_288h) && (var_280h == var_288h)) {
                        func_0x0001800890e0(&var_288h, (var_288h - var_280h) + 1, 0xffffffff);
                    }
                    *(undefined *)var_288h = 0;
                    var_288h = var_288h + 1;
                }
                var_2c8h = uVar15 + 1;
                iVar5 = iVar7;
                break;
            case 4:
                iVar8 = func_0x0001800860c0(arg1, iVar7, &var_2c0h);
                iVar9 = var_2c0h;
                if (iVar8 == 0) goto code_r0x00018009f47f;
                if (((int32_t)uVar16 < 8) && ((uint64_t)(1LL << (cVar2 * '\b' & 0x3fU)) <= (uint64_t)var_2c0h)) {
                    func_0x000180088380(arg1, iVar7, 0x18063e968);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                iVar5 = 0;
                if ((uint32_t)var_2e8h == 0) {
                    iVar5 = uVar16 - 1;
                }
                *(char *)((int64_t)&var_58h + (int64_t)iVar5) = (char)var_2c0h;
                if (1 < (int32_t)uVar16) {
                    uVar15 = 1;
                    uVar14 = var_2c0h;
                    if ((uint32_t)var_2e8h == 0) {
                        do {
                            iVar5 = (int32_t)uVar15;
                            uVar13 = iVar5 + 1;
                            uVar15 = (uint64_t)uVar13;
                            (&uStack_59)[(int32_t)(uVar16 - iVar5)] = (char)(uVar14 >> 8);
                            uVar14 = uVar14 >> 8;
                        } while ((int32_t)uVar13 < (int32_t)uVar16);
                    } else {
                        do {
                            uVar13 = (int32_t)uVar15 + 1;
                            *(char *)((int64_t)&var_58h + uVar15) = (char)(uVar14 >> 8);
                            uVar15 = (uint64_t)uVar13;
                            uVar14 = uVar14 >> 8;
                        } while ((int32_t)uVar13 < (int32_t)uVar16);
                    }
                }
                if ((uint64_t)(var_280h - var_288h) < uVar19) {
                    func_0x0001800890e0(&var_288h, (uVar19 - var_280h) + var_288h, 0xffffffff);
                }
                func_0x000180498030(var_288h, &var_58h, uVar19);
                var_288h = var_288h + uVar19;
                if ((uint64_t)(var_280h - var_288h) < (uint64_t)iVar9) {
                    func_0x0001800890e0(&var_288h, iVar9 + (var_288h - var_280h), 0xffffffff);
                }
                func_0x000180498030(var_288h, iVar8, iVar9);
                var_288h = var_288h + iVar9;
                iVar21 = iVar21 + iVar9;
                iVar5 = iVar7;
                break;
            case 5:
                iVar9 = func_0x0001800860c0(arg1, iVar7, &var_2b8h);
                if (iVar9 == 0) goto code_r0x00018009f47f;
                iVar10 = func_0x000180498cd0(iVar9);
                iVar8 = var_2b8h;
                if (iVar10 != var_2b8h) {
                    func_0x000180088380(arg1, iVar7, 0x18063e950);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                if ((uint64_t)(var_280h - var_288h) < (uint64_t)var_2b8h) {
                    func_0x0001800890e0(&var_288h, (var_2b8h - var_280h) + var_288h, 0xffffffff);
                }
                func_0x000180498030(var_288h, iVar9, iVar8);
                var_288h = var_288h + iVar8;
                if (((uint64_t)var_280h <= (uint64_t)var_288h) && (var_280h == var_288h)) {
                    func_0x0001800890e0(&var_288h, (var_288h - var_280h) + 1, 0xffffffff);
                }
                *(undefined *)var_288h = 0;
                var_288h = var_288h + 1;
                iVar21 = iVar21 + 1 + iVar8;
                iVar5 = iVar7;
                break;
            case 6:
                if (((uint64_t)var_280h <= (uint64_t)var_288h) && (var_280h == var_288h)) {
                    func_0x0001800890e0(&var_288h, (var_288h - var_280h) + 1, 0xffffffff);
                }
                *(undefined *)var_288h = 0;
                var_288h = var_288h + 1;
            }
            cVar2 = *var_2e0h;
            iVar9 = var_278h;
            iVar8 = var_270h;
        } while( true );
    }
code_r0x00018009f3ba:
    fcn.180088470(arg1, 1, 6);
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_18009f3ce
// Address: 0x18009f3ce
// Size: 234 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_308h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_2e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2cch
// WARNING: [rz-ghidra] Detected overlap for variable var_2d0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2d4h

void fcn.18009eb80(int64_t arg1)
{
    int64_t *piVar1;
    char cVar2;
    undefined uVar3;
    code *pcVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    uint32_t uVar16;
    int64_t *piVar17;
    char *pcVar18;
    uint64_t uVar19;
    undefined *puVar20;
    int64_t iVar21;
    double dVar22;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_328 [32];
    int64_t var_308h;
    int64_t var_2f8h;
    int64_t var_2f0h;
    int64_t var_2e8h;
    char *var_2e0h;
    int64_t var_2d8h;
    int32_t var_2d0h;
    int32_t var_2cch;
    int64_t var_2c8h;
    int64_t var_2c0h;
    int64_t var_2b8h;
    int64_t var_2b0h;
    int64_t var_288h;
    int64_t var_280h;
    int64_t var_278h;
    int64_t var_270h;
    int64_t var_268h;
    undefined uStack_69;
    int64_t var_68h;
    undefined uStack_59;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_328;
    piVar17 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar17 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar17 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009f3ba;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar17 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar17 = *(int64_t **)0x180782430;
        }
    }
    pcVar18 = (char *)(*piVar17 + 0x18);
    if (pcVar18 != (char *)0x0) {
        iVar5 = 1;
        iVar21 = 0;
        var_2e8h._0_4_ = 1;
        var_2e8h._4_4_ = 1;
        var_2f0h = arg1;
        var_2e0h = pcVar18;
        func_0x000180086510(arg1);
        var_288h = (int64_t)&var_268h;
        var_270h = 0;
        var_280h = (int64_t)&var_68h;
        cVar2 = *pcVar18;
        iVar9 = arg1;
        iVar8 = var_270h;
        do {
            var_278h = iVar9;
            var_270h = iVar8;
            if (cVar2 == '\0') {
                if (iVar8 == 0) {
                    func_0x0001800867f0(iVar9, &var_268h, var_288h + (-0x20 - (int64_t)&var_288h));
                } else {
                    if (*(uint64_t *)(*(int64_t *)(iVar9 + 0x20) + 0x28) <=
                        *(uint64_t *)(*(int64_t *)(iVar9 + 0x20) + 0x30)) {
                        (**(code **)0x180782658)(iVar9, 1);
                    }
                    iVar21 = *(int64_t *)(iVar9 + 0x40);
                    if (var_288h == var_280h) {
                        uVar11 = func_0x00018009a7e0(iVar9, iVar8);
                        *(undefined8 *)(iVar21 + -0x10) = uVar11;
                        *(undefined4 *)(iVar21 + -4) = 6;
                    } else {
                        uVar11 = func_0x00018009a8e0(iVar9, iVar8 + 0x18, (var_288h - iVar8) + -0x18);
                        *(undefined8 *)(iVar21 + -0x10) = uVar11;
                        *(undefined4 *)(iVar21 + -4) = 6;
                    }
                }
                func_0x000180459870(var_38h ^ (uint64_t)auStackY_328);
                return;
            }
            iVar6 = fcn.18009e550((int64_t)&var_2f0h, (int64_t)&var_2e0h, (int64_t)&var_2d8h);
            uVar16 = (uint32_t)var_2d8h;
            uVar19 = (uint64_t)(int32_t)(uint32_t)var_2d8h;
            var_2f8h._0_4_ = (uint32_t)var_2d8h;
            if ((iVar6 == 7) &&
               (((*var_2e0h == '\0' ||
                 (iVar7 = fcn.18009e550((int64_t)&var_2f0h, (int64_t)&var_2e0h, (int64_t)&var_2f8h), iVar7 == 3)) ||
                ((uint32_t)var_2f8h == 0)))) {
                func_0x000180088380(var_2f0h, 1, 0x18063e8f8);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            uVar15 = uVar19;
            if ((1 < (int32_t)(uint32_t)var_2f8h) && (iVar6 != 3)) {
                uVar13 = (uint32_t)var_2f8h;
                if ((int32_t)var_2e8h._4_4_ < (int32_t)(uint32_t)var_2f8h) {
                    uVar13 = var_2e8h._4_4_;
                }
                uVar12 = uVar13 - 1;
                if ((uVar12 & uVar13) != 0) {
                    func_0x000180088380(var_2f0h, 1, 0x18063e8c8);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                uVar12 = uVar13 - ((uint32_t)iVar21 & uVar12) & uVar12;
                iVar7 = uVar12 + uVar16;
                while (uVar15 = (int64_t)iVar7, 0 < (int32_t)uVar12) {
                    uVar12 = uVar12 - 1;
                    if (((uint64_t)var_280h <= (uint64_t)var_288h) && (var_280h == var_288h)) {
                        func_0x0001800890e0(&var_288h, (var_288h - var_280h) + 1, 0xffffffff);
                    }
                    *(undefined *)var_288h = 0;
                    var_288h = var_288h + 1;
                }
            }
            iVar21 = iVar21 + uVar15;
            iVar7 = iVar5 + 1;
            cVar2 = (char)uVar16;
    // switch table (9 cases) at 0x18009f494
            switch(iVar6) {
            case 0:
                dVar22 = (double)func_0x000180085ea0(arg1, iVar7, (int64_t)&var_2d8h + 4);
                if (var_2d8h._4_4_ == 0) {
                    fcn.180088470(arg1, iVar7, 3);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                iVar9 = (int64_t)dVar22;
                if (((int32_t)uVar16 < 8) &&
                   ((iVar8 = 1LL << (cVar2 * '\b' - 1U & 0x3f), -iVar9 != iVar8 && iVar9 <= -iVar8 || (iVar8 <= iVar9)))
                   ) {
                    func_0x000180088380(arg1, iVar7, 0x18063e1b0);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                var_308h._0_4_ = (uint32_t)((uint64_t)iVar9 >> 0x3f);
                fcn.18009ea80((int64_t)&var_288h, iVar9, (uint64_t)(uint32_t)var_2e8h, (uint64_t)uVar16, 
                              CONCAT44(var_308h._4_4_, (uint32_t)var_308h));
                iVar5 = iVar7;
                break;
            case 1:
                dVar22 = (double)func_0x000180085ea0(arg1, iVar7, &var_2d0h);
                if (var_2d0h == 0) {
code_r0x00018009f434:
                    fcn.180088470(arg1, iVar7, 3);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                uVar15 = (uint64_t)dVar22;
                if (((int32_t)uVar16 < 8) && ((uint64_t)(1LL << (cVar2 * '\b' & 0x3fU)) <= uVar15)) {
                    func_0x000180088380(arg1, iVar7, 0x18063e8b0);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                iVar5 = 0;
                if ((uint32_t)var_2e8h == 0) {
                    iVar5 = uVar16 - 1;
                }
                *(char *)((int64_t)&var_68h + (int64_t)iVar5) = (char)uVar15;
                if (1 < (int32_t)uVar16) {
                    uVar14 = 1;
                    if ((uint32_t)var_2e8h == 0) {
                        do {
                            iVar5 = (int32_t)uVar14;
                            uVar13 = iVar5 + 1;
                            uVar14 = (uint64_t)uVar13;
                            (&uStack_69)[(int32_t)(uVar16 - iVar5)] = (char)(uVar15 >> 8);
                            uVar15 = uVar15 >> 8;
                        } while ((int32_t)uVar13 < (int32_t)uVar16);
                    } else {
                        do {
                            uVar13 = (int32_t)uVar14 + 1;
                            *(char *)((int64_t)&var_68h + uVar14) = (char)(uVar15 >> 8);
                            uVar14 = (uint64_t)uVar13;
                            uVar15 = uVar15 >> 8;
                        } while ((int32_t)uVar13 < (int32_t)uVar16);
                    }
                }
                if ((uint64_t)(var_280h - var_288h) < uVar19) {
                    func_0x0001800890e0(&var_288h, (uVar19 - var_280h) + var_288h, 0xffffffff);
                }
                piVar17 = &var_68h;
                goto code_r0x00018009eefd;
            case 2:
                dVar22 = (double)func_0x000180085ea0(arg1, iVar7, &var_2cch);
                if (var_2cch == 0) goto code_r0x00018009f434;
                if (uVar16 == 4) {
                    var_2b0h = CONCAT44(var_2b0h._4_4_, (float)dVar22);
                } else {
                    var_2b0h = (int64_t)dVar22;
                }
                piVar17 = &var_2b0h;
                if ((uint32_t)var_2e8h == 1) {
                    piVar1 = &var_48h;
                    for (; uVar16 != 0; uVar16 = uVar16 - 1) {
                        uVar3 = *(undefined *)piVar17;
                        piVar17 = (int64_t *)((int64_t)piVar17 + 1);
                        *(undefined *)piVar1 = uVar3;
                        piVar1 = (int64_t *)((int64_t)piVar1 + 1);
                    }
                } else {
                    puVar20 = (undefined *)((int64_t)&var_48h + (int64_t)(int32_t)(uVar16 - 1));
                    for (; uVar16 != 0; uVar16 = uVar16 - 1) {
                        uVar3 = *(undefined *)piVar17;
                        piVar17 = (int64_t *)((int64_t)piVar17 + 1);
                        *puVar20 = uVar3;
                        puVar20 = puVar20 + -1;
                    }
                }
                if ((uint64_t)(var_280h - var_288h) < uVar19) {
                    func_0x0001800890e0(&var_288h, (uVar19 - var_280h) + var_288h, 0xffffffff);
                }
                piVar17 = &var_48h;
code_r0x00018009eefd:
                func_0x000180498030(var_288h, piVar17, uVar19);
                var_288h = var_288h + uVar19;
                iVar5 = iVar7;
                break;
            case 3:
                iVar9 = func_0x0001800860c0(arg1, iVar7, &var_2c8h);
                uVar15 = var_2c8h;
                if (iVar9 == 0) {
code_r0x00018009f47f:
                    fcn.180088470(arg1, iVar7, 6);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                if (uVar19 < (uint64_t)var_2c8h) {
                    func_0x000180088380(arg1, iVar7, 0x18063e890);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                if ((uint64_t)(var_280h - var_288h) < (uint64_t)var_2c8h) {
                    func_0x0001800890e0(&var_288h, (var_2c8h - var_280h) + var_288h, 0xffffffff);
                }
                func_0x000180498030(var_288h, iVar9, uVar15);
                var_288h = var_288h + uVar15;
                while (uVar15 < uVar19) {
                    uVar15 = uVar15 + 1;
                    if (((uint64_t)var_280h <= (uint64_t)var_288h) && (var_280h == var_288h)) {
                        func_0x0001800890e0(&var_288h, (var_288h - var_280h) + 1, 0xffffffff);
                    }
                    *(undefined *)var_288h = 0;
                    var_288h = var_288h + 1;
                }
                var_2c8h = uVar15 + 1;
                iVar5 = iVar7;
                break;
            case 4:
                iVar8 = func_0x0001800860c0(arg1, iVar7, &var_2c0h);
                iVar9 = var_2c0h;
                if (iVar8 == 0) goto code_r0x00018009f47f;
                if (((int32_t)uVar16 < 8) && ((uint64_t)(1LL << (cVar2 * '\b' & 0x3fU)) <= (uint64_t)var_2c0h)) {
                    func_0x000180088380(arg1, iVar7, 0x18063e968);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                iVar5 = 0;
                if ((uint32_t)var_2e8h == 0) {
                    iVar5 = uVar16 - 1;
                }
                *(char *)((int64_t)&var_58h + (int64_t)iVar5) = (char)var_2c0h;
                if (1 < (int32_t)uVar16) {
                    uVar15 = 1;
                    uVar14 = var_2c0h;
                    if ((uint32_t)var_2e8h == 0) {
                        do {
                            iVar5 = (int32_t)uVar15;
                            uVar13 = iVar5 + 1;
                            uVar15 = (uint64_t)uVar13;
                            (&uStack_59)[(int32_t)(uVar16 - iVar5)] = (char)(uVar14 >> 8);
                            uVar14 = uVar14 >> 8;
                        } while ((int32_t)uVar13 < (int32_t)uVar16);
                    } else {
                        do {
                            uVar13 = (int32_t)uVar15 + 1;
                            *(char *)((int64_t)&var_58h + uVar15) = (char)(uVar14 >> 8);
                            uVar15 = (uint64_t)uVar13;
                            uVar14 = uVar14 >> 8;
                        } while ((int32_t)uVar13 < (int32_t)uVar16);
                    }
                }
                if ((uint64_t)(var_280h - var_288h) < uVar19) {
                    func_0x0001800890e0(&var_288h, (uVar19 - var_280h) + var_288h, 0xffffffff);
                }
                func_0x000180498030(var_288h, &var_58h, uVar19);
                var_288h = var_288h + uVar19;
                if ((uint64_t)(var_280h - var_288h) < (uint64_t)iVar9) {
                    func_0x0001800890e0(&var_288h, iVar9 + (var_288h - var_280h), 0xffffffff);
                }
                func_0x000180498030(var_288h, iVar8, iVar9);
                var_288h = var_288h + iVar9;
                iVar21 = iVar21 + iVar9;
                iVar5 = iVar7;
                break;
            case 5:
                iVar9 = func_0x0001800860c0(arg1, iVar7, &var_2b8h);
                if (iVar9 == 0) goto code_r0x00018009f47f;
                iVar10 = func_0x000180498cd0(iVar9);
                iVar8 = var_2b8h;
                if (iVar10 != var_2b8h) {
                    func_0x000180088380(arg1, iVar7, 0x18063e950);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                if ((uint64_t)(var_280h - var_288h) < (uint64_t)var_2b8h) {
                    func_0x0001800890e0(&var_288h, (var_2b8h - var_280h) + var_288h, 0xffffffff);
                }
                func_0x000180498030(var_288h, iVar9, iVar8);
                var_288h = var_288h + iVar8;
                if (((uint64_t)var_280h <= (uint64_t)var_288h) && (var_280h == var_288h)) {
                    func_0x0001800890e0(&var_288h, (var_288h - var_280h) + 1, 0xffffffff);
                }
                *(undefined *)var_288h = 0;
                var_288h = var_288h + 1;
                iVar21 = iVar21 + 1 + iVar8;
                iVar5 = iVar7;
                break;
            case 6:
                if (((uint64_t)var_280h <= (uint64_t)var_288h) && (var_280h == var_288h)) {
                    func_0x0001800890e0(&var_288h, (var_288h - var_280h) + 1, 0xffffffff);
                }
                *(undefined *)var_288h = 0;
                var_288h = var_288h + 1;
            }
            cVar2 = *var_2e0h;
            iVar9 = var_278h;
            iVar8 = var_270h;
        } while( true );
    }
code_r0x00018009f3ba:
    fcn.180088470(arg1, 1, 6);
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_18009f4c0
// Address: 0x18009f4c0
// Size: 130 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

undefined8 fcn.18009f4c0(int64_t arg1)
{
    char cVar1;
    code *pcVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    undefined8 uVar7;
    uint32_t uVar8;
    int64_t *piVar9;
    uint32_t uVar10;
    int64_t var_8h;
    char *pcStackX_10;
    int64_t var_18h;
    int64_t var_4ch;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_10h;
    
    piVar9 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009f66c;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar9 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar9 = *(int64_t **)0x180782430;
        }
    }
    pcStackX_10 = (char *)(*piVar9 + 0x18);
    if (pcStackX_10 != (char *)0x0) {
        uVar10 = 0;
        var_20h._0_4_ = 1;
        var_20h._4_4_ = 1;
        cVar1 = *pcStackX_10;
        var_28h = arg1;
        while( true ) {
            if (cVar1 == '\0') {
                func_0x0001800865e0(arg1, uVar10);
                return 1;
            }
            iVar5 = fcn.18009e550((int64_t)&var_28h, (int64_t)&pcStackX_10, (int64_t)&var_8h);
            uVar4 = (uint32_t)var_8h;
            if ((iVar5 == 7) &&
               (((*pcStackX_10 == '\0' ||
                 (iVar6 = fcn.18009e550((int64_t)&var_28h, (int64_t)&pcStackX_10, (int64_t)&var_8h), iVar6 == 3)) ||
                ((uint32_t)var_8h == 0)))) {
                func_0x000180088380(var_28h, 1, 0x18063e8f8);
                pcVar2 = (code *)swi(3);
                uVar7 = (*pcVar2)();
                return uVar7;
            }
            if (((int32_t)(uint32_t)var_8h < 2) || (iVar5 == 3)) {
                uVar8 = 0;
            } else {
                uVar3 = (uint32_t)var_8h;
                if ((int32_t)var_20h._4_4_ < (int32_t)(uint32_t)var_8h) {
                    uVar3 = var_20h._4_4_;
                }
                uVar8 = uVar3 - 1;
                if ((uVar3 & uVar8) != 0) {
                    func_0x000180088380(var_28h, 1, 0x18063e8c8);
                    pcVar2 = (code *)swi(3);
                    uVar7 = (*pcVar2)();
                    return uVar7;
                }
                uVar8 = uVar3 - (uVar8 & uVar10) & uVar8;
            }
            if (iVar5 - 4U < 2) {
                func_0x000180088380(arg1, 1, 0x18063e938);
                pcVar2 = (code *)swi(3);
                uVar7 = (*pcVar2)();
                return uVar7;
            }
            var_8h._0_4_ = uVar4 + uVar8;
            if ((int32_t)(0x40000000 - (uint32_t)var_8h) < (int32_t)uVar10) break;
            uVar10 = uVar10 + (uint32_t)var_8h;
            cVar1 = *pcStackX_10;
        }
        func_0x000180088380(arg1, 1, 0x18063e920);
        pcVar2 = (code *)swi(3);
        uVar7 = (*pcVar2)();
        return uVar7;
    }
code_r0x00018009f66c:
    fcn.180088470(arg1, 1, 6);
    pcVar2 = (code *)swi(3);
    uVar7 = (*pcVar2)();
    return uVar7;
}

// ============================================================
// Function: FUN_18009f542
// Address: 0x18009f542
// Size: 277 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

undefined8 fcn.18009f4c0(int64_t arg1)
{
    char cVar1;
    code *pcVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    undefined8 uVar7;
    uint32_t uVar8;
    int64_t *piVar9;
    uint32_t uVar10;
    int64_t var_8h;
    char *pcStackX_10;
    int64_t var_18h;
    int64_t var_4ch;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_10h;
    
    piVar9 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009f66c;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar9 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar9 = *(int64_t **)0x180782430;
        }
    }
    pcStackX_10 = (char *)(*piVar9 + 0x18);
    if (pcStackX_10 != (char *)0x0) {
        uVar10 = 0;
        var_20h._0_4_ = 1;
        var_20h._4_4_ = 1;
        cVar1 = *pcStackX_10;
        var_28h = arg1;
        while( true ) {
            if (cVar1 == '\0') {
                func_0x0001800865e0(arg1, uVar10);
                return 1;
            }
            iVar5 = fcn.18009e550((int64_t)&var_28h, (int64_t)&pcStackX_10, (int64_t)&var_8h);
            uVar4 = (uint32_t)var_8h;
            if ((iVar5 == 7) &&
               (((*pcStackX_10 == '\0' ||
                 (iVar6 = fcn.18009e550((int64_t)&var_28h, (int64_t)&pcStackX_10, (int64_t)&var_8h), iVar6 == 3)) ||
                ((uint32_t)var_8h == 0)))) {
                func_0x000180088380(var_28h, 1, 0x18063e8f8);
                pcVar2 = (code *)swi(3);
                uVar7 = (*pcVar2)();
                return uVar7;
            }
            if (((int32_t)(uint32_t)var_8h < 2) || (iVar5 == 3)) {
                uVar8 = 0;
            } else {
                uVar3 = (uint32_t)var_8h;
                if ((int32_t)var_20h._4_4_ < (int32_t)(uint32_t)var_8h) {
                    uVar3 = var_20h._4_4_;
                }
                uVar8 = uVar3 - 1;
                if ((uVar3 & uVar8) != 0) {
                    func_0x000180088380(var_28h, 1, 0x18063e8c8);
                    pcVar2 = (code *)swi(3);
                    uVar7 = (*pcVar2)();
                    return uVar7;
                }
                uVar8 = uVar3 - (uVar8 & uVar10) & uVar8;
            }
            if (iVar5 - 4U < 2) {
                func_0x000180088380(arg1, 1, 0x18063e938);
                pcVar2 = (code *)swi(3);
                uVar7 = (*pcVar2)();
                return uVar7;
            }
            var_8h._0_4_ = uVar4 + uVar8;
            if ((int32_t)(0x40000000 - (uint32_t)var_8h) < (int32_t)uVar10) break;
            uVar10 = uVar10 + (uint32_t)var_8h;
            cVar1 = *pcStackX_10;
        }
        func_0x000180088380(arg1, 1, 0x18063e920);
        pcVar2 = (code *)swi(3);
        uVar7 = (*pcVar2)();
        return uVar7;
    }
code_r0x00018009f66c:
    fcn.180088470(arg1, 1, 6);
    pcVar2 = (code *)swi(3);
    uVar7 = (*pcVar2)();
    return uVar7;
}

// ============================================================
// Function: FUN_18009f657
// Address: 0x18009f657
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

undefined8 fcn.18009f4c0(int64_t arg1)
{
    char cVar1;
    code *pcVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    undefined8 uVar7;
    uint32_t uVar8;
    int64_t *piVar9;
    uint32_t uVar10;
    int64_t var_8h;
    char *pcStackX_10;
    int64_t var_18h;
    int64_t var_4ch;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_10h;
    
    piVar9 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009f66c;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar9 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar9 = *(int64_t **)0x180782430;
        }
    }
    pcStackX_10 = (char *)(*piVar9 + 0x18);
    if (pcStackX_10 != (char *)0x0) {
        uVar10 = 0;
        var_20h._0_4_ = 1;
        var_20h._4_4_ = 1;
        cVar1 = *pcStackX_10;
        var_28h = arg1;
        while( true ) {
            if (cVar1 == '\0') {
                func_0x0001800865e0(arg1, uVar10);
                return 1;
            }
            iVar5 = fcn.18009e550((int64_t)&var_28h, (int64_t)&pcStackX_10, (int64_t)&var_8h);
            uVar4 = (uint32_t)var_8h;
            if ((iVar5 == 7) &&
               (((*pcStackX_10 == '\0' ||
                 (iVar6 = fcn.18009e550((int64_t)&var_28h, (int64_t)&pcStackX_10, (int64_t)&var_8h), iVar6 == 3)) ||
                ((uint32_t)var_8h == 0)))) {
                func_0x000180088380(var_28h, 1, 0x18063e8f8);
                pcVar2 = (code *)swi(3);
                uVar7 = (*pcVar2)();
                return uVar7;
            }
            if (((int32_t)(uint32_t)var_8h < 2) || (iVar5 == 3)) {
                uVar8 = 0;
            } else {
                uVar3 = (uint32_t)var_8h;
                if ((int32_t)var_20h._4_4_ < (int32_t)(uint32_t)var_8h) {
                    uVar3 = var_20h._4_4_;
                }
                uVar8 = uVar3 - 1;
                if ((uVar3 & uVar8) != 0) {
                    func_0x000180088380(var_28h, 1, 0x18063e8c8);
                    pcVar2 = (code *)swi(3);
                    uVar7 = (*pcVar2)();
                    return uVar7;
                }
                uVar8 = uVar3 - (uVar8 & uVar10) & uVar8;
            }
            if (iVar5 - 4U < 2) {
                func_0x000180088380(arg1, 1, 0x18063e938);
                pcVar2 = (code *)swi(3);
                uVar7 = (*pcVar2)();
                return uVar7;
            }
            var_8h._0_4_ = uVar4 + uVar8;
            if ((int32_t)(0x40000000 - (uint32_t)var_8h) < (int32_t)uVar10) break;
            uVar10 = uVar10 + (uint32_t)var_8h;
            cVar1 = *pcStackX_10;
        }
        func_0x000180088380(arg1, 1, 0x18063e920);
        pcVar2 = (code *)swi(3);
        uVar7 = (*pcVar2)();
        return uVar7;
    }
code_r0x00018009f66c:
    fcn.180088470(arg1, 1, 6);
    pcVar2 = (code *)swi(3);
    uVar7 = (*pcVar2)();
    return uVar7;
}

// ============================================================
// Function: FUN_18009f66c
// Address: 0x18009f66c
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

undefined8 fcn.18009f4c0(int64_t arg1)
{
    char cVar1;
    code *pcVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    undefined8 uVar7;
    uint32_t uVar8;
    int64_t *piVar9;
    uint32_t uVar10;
    int64_t var_8h;
    char *pcStackX_10;
    int64_t var_18h;
    int64_t var_4ch;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_10h;
    
    piVar9 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009f66c;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar9 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar9 = *(int64_t **)0x180782430;
        }
    }
    pcStackX_10 = (char *)(*piVar9 + 0x18);
    if (pcStackX_10 != (char *)0x0) {
        uVar10 = 0;
        var_20h._0_4_ = 1;
        var_20h._4_4_ = 1;
        cVar1 = *pcStackX_10;
        var_28h = arg1;
        while( true ) {
            if (cVar1 == '\0') {
                func_0x0001800865e0(arg1, uVar10);
                return 1;
            }
            iVar5 = fcn.18009e550((int64_t)&var_28h, (int64_t)&pcStackX_10, (int64_t)&var_8h);
            uVar4 = (uint32_t)var_8h;
            if ((iVar5 == 7) &&
               (((*pcStackX_10 == '\0' ||
                 (iVar6 = fcn.18009e550((int64_t)&var_28h, (int64_t)&pcStackX_10, (int64_t)&var_8h), iVar6 == 3)) ||
                ((uint32_t)var_8h == 0)))) {
                func_0x000180088380(var_28h, 1, 0x18063e8f8);
                pcVar2 = (code *)swi(3);
                uVar7 = (*pcVar2)();
                return uVar7;
            }
            if (((int32_t)(uint32_t)var_8h < 2) || (iVar5 == 3)) {
                uVar8 = 0;
            } else {
                uVar3 = (uint32_t)var_8h;
                if ((int32_t)var_20h._4_4_ < (int32_t)(uint32_t)var_8h) {
                    uVar3 = var_20h._4_4_;
                }
                uVar8 = uVar3 - 1;
                if ((uVar3 & uVar8) != 0) {
                    func_0x000180088380(var_28h, 1, 0x18063e8c8);
                    pcVar2 = (code *)swi(3);
                    uVar7 = (*pcVar2)();
                    return uVar7;
                }
                uVar8 = uVar3 - (uVar8 & uVar10) & uVar8;
            }
            if (iVar5 - 4U < 2) {
                func_0x000180088380(arg1, 1, 0x18063e938);
                pcVar2 = (code *)swi(3);
                uVar7 = (*pcVar2)();
                return uVar7;
            }
            var_8h._0_4_ = uVar4 + uVar8;
            if ((int32_t)(0x40000000 - (uint32_t)var_8h) < (int32_t)uVar10) break;
            uVar10 = uVar10 + (uint32_t)var_8h;
            cVar1 = *pcStackX_10;
        }
        func_0x000180088380(arg1, 1, 0x18063e920);
        pcVar2 = (code *)swi(3);
        uVar7 = (*pcVar2)();
        return uVar7;
    }
code_r0x00018009f66c:
    fcn.180088470(arg1, 1, 6);
    pcVar2 = (code *)swi(3);
    uVar7 = (*pcVar2)();
    return uVar7;
}

// ============================================================
// Function: FUN_18009f680
// Address: 0x18009f680
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

undefined8 fcn.18009f4c0(int64_t arg1)
{
    char cVar1;
    code *pcVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    undefined8 uVar7;
    uint32_t uVar8;
    int64_t *piVar9;
    uint32_t uVar10;
    int64_t var_8h;
    char *pcStackX_10;
    int64_t var_18h;
    int64_t var_4ch;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_10h;
    
    piVar9 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009f66c;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar9 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar9 = *(int64_t **)0x180782430;
        }
    }
    pcStackX_10 = (char *)(*piVar9 + 0x18);
    if (pcStackX_10 != (char *)0x0) {
        uVar10 = 0;
        var_20h._0_4_ = 1;
        var_20h._4_4_ = 1;
        cVar1 = *pcStackX_10;
        var_28h = arg1;
        while( true ) {
            if (cVar1 == '\0') {
                func_0x0001800865e0(arg1, uVar10);
                return 1;
            }
            iVar5 = fcn.18009e550((int64_t)&var_28h, (int64_t)&pcStackX_10, (int64_t)&var_8h);
            uVar4 = (uint32_t)var_8h;
            if ((iVar5 == 7) &&
               (((*pcStackX_10 == '\0' ||
                 (iVar6 = fcn.18009e550((int64_t)&var_28h, (int64_t)&pcStackX_10, (int64_t)&var_8h), iVar6 == 3)) ||
                ((uint32_t)var_8h == 0)))) {
                func_0x000180088380(var_28h, 1, 0x18063e8f8);
                pcVar2 = (code *)swi(3);
                uVar7 = (*pcVar2)();
                return uVar7;
            }
            if (((int32_t)(uint32_t)var_8h < 2) || (iVar5 == 3)) {
                uVar8 = 0;
            } else {
                uVar3 = (uint32_t)var_8h;
                if ((int32_t)var_20h._4_4_ < (int32_t)(uint32_t)var_8h) {
                    uVar3 = var_20h._4_4_;
                }
                uVar8 = uVar3 - 1;
                if ((uVar3 & uVar8) != 0) {
                    func_0x000180088380(var_28h, 1, 0x18063e8c8);
                    pcVar2 = (code *)swi(3);
                    uVar7 = (*pcVar2)();
                    return uVar7;
                }
                uVar8 = uVar3 - (uVar8 & uVar10) & uVar8;
            }
            if (iVar5 - 4U < 2) {
                func_0x000180088380(arg1, 1, 0x18063e938);
                pcVar2 = (code *)swi(3);
                uVar7 = (*pcVar2)();
                return uVar7;
            }
            var_8h._0_4_ = uVar4 + uVar8;
            if ((int32_t)(0x40000000 - (uint32_t)var_8h) < (int32_t)uVar10) break;
            uVar10 = uVar10 + (uint32_t)var_8h;
            cVar1 = *pcStackX_10;
        }
        func_0x000180088380(arg1, 1, 0x18063e920);
        pcVar2 = (code *)swi(3);
        uVar7 = (*pcVar2)();
        return uVar7;
    }
code_r0x00018009f66c:
    fcn.180088470(arg1, 1, 6);
    pcVar2 = (code *)swi(3);
    uVar7 = (*pcVar2)();
    return uVar7;
}

// ============================================================
// Function: FUN_18009f6d0
// Address: 0x18009f6d0
// Size: 279 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.18009f6d0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_58h)
{
    code *pcVar1;
    int32_t iVar2;
    char cVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    int32_t iVar6;
    uint64_t uVar7;
    int32_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar6 = (int32_t)arg4;
    uVar7 = 0;
    iVar8 = 8;
    if (iVar6 < 9) {
        iVar8 = iVar6;
    }
    uVar4 = (uint64_t)(iVar8 - 1U);
    if (-1 < (int32_t)(iVar8 - 1U)) {
        if ((int32_t)arg3 == 0) {
            do {
                uVar7 = uVar7 << 8 | (uint64_t)*(uint8_t *)((int64_t)(iVar6 - (int32_t)uVar4) + -1 + arg2);
                uVar5 = (int32_t)uVar4 - 1;
                uVar4 = (uint64_t)uVar5;
            } while (-1 < (int32_t)uVar5);
        } else {
            do {
                uVar7 = uVar7 << 8 | (uint64_t)*(uint8_t *)(uVar4 + arg2);
                uVar5 = (int32_t)uVar4 - 1;
                uVar4 = (uint64_t)uVar5;
            } while (-1 < (int32_t)uVar5);
        }
    }
    if (iVar6 < 8) {
        if ((int32_t)arg_28h != 0) {
            uVar4 = 1LL << ((char)arg4 * '\b' - 1U & 0x3f);
            uVar7 = (uVar7 ^ uVar4) - uVar4;
        }
    } else if (8 < iVar6) {
        if (((int32_t)arg_28h == 0) || (-1 < (int64_t)uVar7)) {
            cVar3 = '\0';
        } else {
            cVar3 = -1;
        }
        if (iVar8 < iVar6) {
            while( true ) {
                iVar2 = (iVar6 - iVar8) + -1;
                if ((int32_t)arg3 != 0) {
                    iVar2 = iVar8;
                }
                if (*(char *)(iVar2 + arg2) != cVar3) break;
                iVar8 = iVar8 + 1;
                if (iVar6 <= iVar8) {
                    return uVar7;
                }
            }
            fcn.180088560(arg1, 0x18063e9e8, arg4 & 0xffffffff);
            pcVar1 = (code *)swi(3);
            uVar7 = (*pcVar1)();
            return uVar7;
        }
    }
    return uVar7;
}

// ============================================================
// Function: FUN_18009f7f0
// Address: 0x18009f7f0
// Size: 313 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_a8h
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch

void fcn.18009f7f0(int64_t arg1)
{
    char cVar1;
    undefined uVar2;
    code *pcVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    uint32_t uVar10;
    int64_t *piVar11;
    int64_t *piVar12;
    char *pcVar13;
    int32_t iVar14;
    uint32_t uVar15;
    undefined *puVar16;
    int64_t *piVar17;
    undefined *puVar18;
    int64_t iVar19;
    int64_t iVar20;
    double dVar21;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStackY_c8 [32];
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_c8;
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar17 = *(int64_t **)(arg1 + 0x40);
    piVar12 = piVar11;
    if (piVar17 <= piVar11) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar12 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar6 = func_0x0001800a8360(arg1);
        if (iVar6 == 0) goto code_r0x00018009fd16;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar11 = *(int64_t **)(arg1 + 0x28);
        piVar17 = *(int64_t **)(arg1 + 0x40);
        piVar12 = piVar11;
        if (piVar17 <= piVar11) {
            piVar12 = *(int64_t **)0x180782430;
        }
    }
    pcVar13 = (char *)(*piVar12 + 0x18);
    if (pcVar13 == (char *)0x0) {
code_r0x00018009fd16:
        fcn.180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    piVar12 = piVar11 + 2;
    if (piVar17 <= piVar11 + 2) {
        piVar12 = *(int64_t **)0x180782430;
    }
    var_78h = (int64_t)pcVar13;
    if (*(int32_t *)((int64_t)piVar12 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar6 = func_0x0001800a8360(arg1);
        if (iVar6 == 0) goto code_r0x00018009fd2a;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar11 = *(int64_t **)(arg1 + 0x28);
        piVar17 = *(int64_t **)(arg1 + 0x40);
        piVar12 = piVar11 + 2;
        if (piVar17 <= piVar11 + 2) {
            piVar12 = *(int64_t **)0x180782430;
        }
    }
    var_90h = *piVar12 + 0x18;
    if (var_90h != 0) {
        uVar15 = *(uint32_t *)(*piVar12 + 0x14);
        uVar9 = (uint64_t)uVar15;
        piVar12 = piVar11 + 4;
        if (piVar17 <= piVar11 + 4) {
            piVar12 = *(int64_t **)0x180782430;
        }
        var_68h = uVar9;
        if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) < 1)) {
            iVar6 = 1;
        } else {
            iVar6 = func_0x000180088860(arg1, 3);
            if (iVar6 < 0) {
                iVar6 = iVar6 + 1 + uVar15;
            }
        }
        iVar7 = 0;
        if (-1 < iVar6) {
            iVar7 = iVar6;
        }
        uVar15 = 0;
        if (-1 < (int32_t)(iVar7 - 1U)) {
            uVar15 = iVar7 - 1U;
        }
        if (uVar9 < (uint64_t)(int64_t)(int32_t)uVar15) {
            func_0x000180088380(arg1, 3, 0x18063e9c8);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        var_80h._0_4_ = 1;
        var_80h._4_4_ = 1;
        cVar1 = *pcVar13;
        var_88h = arg1;
        iVar6 = 0;
        while( true ) {
            if (cVar1 == '\0') {
                func_0x0001800865e0(arg1, uVar15 + 1);
                func_0x000180459870(var_38h ^ (uint64_t)auStackY_c8);
                return;
            }
            iVar7 = fcn.18009e550((int64_t)&var_88h, (int64_t)&var_78h, (int64_t)&var_70h);
            uVar5 = (uint32_t)var_70h;
            iVar19 = (int64_t)(int32_t)(uint32_t)var_70h;
            var_98h._0_4_ = (uint32_t)var_70h;
            if ((iVar7 == 7) &&
               (((*(char *)var_78h == '\0' ||
                 (iVar8 = fcn.18009e550((int64_t)&var_88h, (int64_t)&var_78h, (int64_t)&var_98h), iVar8 == 3)) ||
                ((uint32_t)var_98h == 0)))) {
                func_0x000180088380(var_88h, 1, 0x18063e8f8);
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            if (((int32_t)(uint32_t)var_98h < 2) || (iVar7 == 3)) {
                uVar10 = 0;
            } else {
                uVar4 = (uint32_t)var_98h;
                if ((int32_t)var_80h._4_4_ < (int32_t)(uint32_t)var_98h) {
                    uVar4 = var_80h._4_4_;
                }
                uVar10 = uVar4 - 1;
                if ((uVar4 & uVar10) != 0) {
                    func_0x000180088380(var_88h, 1, 0x18063e8c8);
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                uVar10 = uVar4 - (uVar10 & uVar15) & uVar10;
            }
            if ((uint64_t)(var_68h - (int32_t)uVar15) < (uint64_t)((int32_t)uVar10 + iVar19)) break;
            if (8000 < (*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4) + 2) {
code_r0x00018009fd7c:
                fcn.180088560(arg1, 0x18063da38, 0x18063e998);
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x21) {
                var_98h._0_4_ = 2;
                iVar8 = func_0x000180093190(arg1, 0x1800855e0, &var_98h);
                if (iVar8 != 0) goto code_r0x00018009fd7c;
            }
            uVar9 = *(int64_t *)(arg1 + 0x40) + 0x20;
            if (**(uint64_t **)(arg1 + 0x18) < uVar9) {
                **(uint64_t **)(arg1 + 0x18) = uVar9;
            }
            iVar14 = uVar15 + uVar10;
            iVar8 = iVar6 + 1;
    // switch table (9 cases) at 0x18009fda8
            switch(iVar7) {
            case 0:
                var_a8h._0_4_ = 1;
                iVar19 = fcn.18009f6d0(arg1, iVar14 + var_90h, (uint64_t)(uint32_t)var_80h, (uint64_t)uVar5, 
                                       CONCAT44(var_a8h._4_4_, 1), var_78h);
                func_0x000180086570(arg1, (double)iVar19);
                break;
            case 1:
                var_a8h._0_4_ = 0;
                uVar9 = fcn.18009f6d0(arg1, iVar14 + var_90h, (uint64_t)(uint32_t)var_80h, (uint64_t)uVar5, 
                                      (uint64_t)var_a8h._4_4_ << 0x20, var_78h);
                if ((int64_t)uVar9 < 0) {
                    dVar21 = (double)(uVar9 >> 1 | (uint64_t)((uint32_t)uVar9 & 1));
                    func_0x000180086570(arg1, dVar21 + dVar21);
                } else {
                    func_0x000180086570(arg1, (double)uVar9);
                }
                break;
            case 2:
                puVar16 = (undefined *)(iVar14 + var_90h);
                if ((uint32_t)var_80h == 1) {
                    piVar11 = &var_60h;
                    for (uVar15 = uVar5; uVar15 != 0; uVar15 = uVar15 - 1) {
                        uVar2 = *puVar16;
                        puVar16 = puVar16 + 1;
                        *(undefined *)piVar11 = uVar2;
                        piVar11 = (int64_t *)((int64_t)piVar11 + 1);
                    }
                } else {
                    puVar18 = (undefined *)((int64_t)&var_60h + (int64_t)(int32_t)(uVar5 - 1));
                    for (uVar15 = uVar5; uVar15 != 0; uVar15 = uVar15 - 1) {
                        uVar2 = *puVar16;
                        puVar16 = puVar16 + 1;
                        *puVar18 = uVar2;
                        puVar18 = puVar18 + -1;
                    }
                }
                if (uVar5 == 4) {
                    func_0x000180086570(arg1, (double)(float)var_60h);
                } else {
                    func_0x000180086570(arg1, CONCAT44(var_60h._4_4_, (float)var_60h));
                }
                break;
            case 3:
                func_0x0001800867f0(arg1, iVar14 + var_90h, iVar19);
                break;
            case 4:
                iVar20 = (int64_t)iVar14;
                var_a8h._0_4_ = 0;
                uVar9 = fcn.18009f6d0(arg1, var_90h + iVar20, (uint64_t)(uint32_t)var_80h, (uint64_t)uVar5, 
                                      (uint64_t)var_a8h._4_4_ << 0x20, var_78h);
                if ((uint64_t)((var_68h - iVar20) - iVar19) < uVar9) goto code_r0x00018009fd93;
                func_0x0001800867f0(arg1, var_90h + iVar20 + iVar19, uVar9);
                iVar14 = iVar14 + (int32_t)uVar9;
                break;
            case 5:
                iVar20 = var_90h + iVar14;
                iVar19 = func_0x000180498cd0(iVar20, iVar6);
                if ((uint64_t)var_68h <= (uint64_t)(iVar14 + iVar19)) {
                    func_0x000180088380(arg1, 2, 0x18063ea28);
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                func_0x0001800867f0(arg1, iVar20, iVar19);
                iVar14 = iVar14 + 1 + (int32_t)iVar19;
                break;
            case 6:
            case 7:
            case 8:
                iVar8 = iVar6;
            }
            uVar15 = iVar14 + uVar5;
            cVar1 = *(char *)var_78h;
            iVar6 = iVar8;
        }
code_r0x00018009fd93:
        func_0x000180088380(arg1, 2, 0x18063e9b0);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
code_r0x00018009fd2a:
    fcn.180088470(arg1, 2, 6);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

