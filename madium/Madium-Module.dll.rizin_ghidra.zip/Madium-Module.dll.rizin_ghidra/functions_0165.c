// Chunk 165 - 50 functions

// ============================================================
// Function: FUN_18021f0d0
// Address: 0x18021f0d0
// Size: 92 bytes
// ============================================================
undefined8 fcn.18021f0d0(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021f0da;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021f0e8;
    iVar1 = fcn.18021f8f0(*(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2));
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021f0f1;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021f109;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021f11b;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_18021f130
// Address: 0x18021f130
// Size: 352 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18021f130(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021f14a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *(undefined8 *)(in_RCX + 0x10);
    iVar6 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021f161;
    iVar3 = func_0x000180222010(uVar1);
    if (0 < iVar3) {
        do {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021f16f;
            iVar5 = func_0x000180222340(uVar1, iVar6);
            if (in_RDX == *(int64_t *)(iVar5 + 8)) {
                return iVar5;
            }
            iVar6 = iVar6 + 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021f183;
            iVar3 = func_0x000180222010(uVar1);
        } while (iVar6 < iVar3);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021f19e;
    iVar5 = func_0x000180224d60(0x20, 0x1804bea28, 0x14);
    if (iVar5 == 0) {
code_r0x00018021f1d1:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021f1d6;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021f1ee;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021f200;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    } else {
        *(int64_t *)(iVar5 + 8) = in_RDX;
        pcVar2 = *(code **)(in_RDX + 8);
        if (pcVar2 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021f1b8;
            iVar3 = (*pcVar2)(iVar5);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021f1d1;
                func_0x000180224990(iVar5, 0x1804bea28, 0x1b);
                goto code_r0x00018021f1d1;
            }
        }
        *(int64_t *)(iVar5 + 0x18) = in_RCX;
        uVar1 = *(undefined8 *)(in_RCX + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021f227;
        iVar3 = func_0x000180222110(uVar1, iVar5);
        if (iVar3 != 0) {
            return iVar5;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021f235;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021f24d;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021f25f;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        if ((*(int64_t *)(iVar5 + 8) != 0) &&
           (pcVar2 = *(code **)(*(int64_t *)(iVar5 + 8) + 0x10), pcVar2 != (code *)0x0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021f276;
            (*pcVar2)(iVar5);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021f28b;
        func_0x000180224990(iVar5, 0x1804bea28, 0x27);
    }
    return 0;
}

// ============================================================
// Function: FUN_18021f290
// Address: 0x18021f290
// Size: 48 bytes
// ============================================================
void fcn.18021f290(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h, int64_t arg_60h)
{
    int32_t *piVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int32_t iVar7;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18021f2a4;
        iVar5 = fcn.18045a350();
        iVar5 = -iVar5;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0x90);
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 < 2) {
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBP;
            uVar2 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RDI;
            iVar7 = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f2d8;
            iVar4 = func_0x000180222010(uVar2);
            if (0 < iVar4) {
                *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f2eb;
                    iVar6 = func_0x000180222340(uVar2, iVar7);
                    if ((*(int64_t *)(iVar6 + 8) != 0) &&
                       (pcVar3 = *(code **)(*(int64_t *)(iVar6 + 8) + 0x20), pcVar3 != (code *)0x0)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f305;
                        (*pcVar3)(iVar6);
                    }
                    if ((*(int64_t *)(iVar6 + 8) != 0) &&
                       (pcVar3 = *(code **)(*(int64_t *)(iVar6 + 8) + 0x10), pcVar3 != (code *)0x0)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f31c;
                        (*pcVar3)(iVar6);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f331;
                    func_0x000180224990(iVar6, 0x1804bea28, 0x27);
                    iVar7 = iVar7 + 1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f33b;
                    iVar4 = func_0x000180222010(uVar2);
                } while (iVar7 < iVar4);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f34c;
            func_0x000180221d50(uVar2);
            uVar2 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f35c;
            func_0x000180222050(uVar2, 0x18021eb10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f370;
            func_0x000180223fb0(4, arg1, arg1 + 0x80);
            uVar2 = *(undefined8 *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f379;
            func_0x000180233bc0(uVar2);
            uVar2 = *(undefined8 *)(arg1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f385;
            func_0x0001802227d0(uVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f39a;
            func_0x000180224990(arg1, 0x1804bea28, 0xfd);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18021f2c0
// Address: 0x18021f2c0
// Size: 28 bytes
// ============================================================
void fcn.18021f290(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h, int64_t arg_60h)
{
    int32_t *piVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int32_t iVar7;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18021f2a4;
        iVar5 = fcn.18045a350();
        iVar5 = -iVar5;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0x90);
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 < 2) {
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBP;
            uVar2 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RDI;
            iVar7 = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f2d8;
            iVar4 = func_0x000180222010(uVar2);
            if (0 < iVar4) {
                *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f2eb;
                    iVar6 = func_0x000180222340(uVar2, iVar7);
                    if ((*(int64_t *)(iVar6 + 8) != 0) &&
                       (pcVar3 = *(code **)(*(int64_t *)(iVar6 + 8) + 0x20), pcVar3 != (code *)0x0)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f305;
                        (*pcVar3)(iVar6);
                    }
                    if ((*(int64_t *)(iVar6 + 8) != 0) &&
                       (pcVar3 = *(code **)(*(int64_t *)(iVar6 + 8) + 0x10), pcVar3 != (code *)0x0)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f31c;
                        (*pcVar3)(iVar6);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f331;
                    func_0x000180224990(iVar6, 0x1804bea28, 0x27);
                    iVar7 = iVar7 + 1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f33b;
                    iVar4 = func_0x000180222010(uVar2);
                } while (iVar7 < iVar4);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f34c;
            func_0x000180221d50(uVar2);
            uVar2 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f35c;
            func_0x000180222050(uVar2, 0x18021eb10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f370;
            func_0x000180223fb0(4, arg1, arg1 + 0x80);
            uVar2 = *(undefined8 *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f379;
            func_0x000180233bc0(uVar2);
            uVar2 = *(undefined8 *)(arg1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f385;
            func_0x0001802227d0(uVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f39a;
            func_0x000180224990(arg1, 0x1804bea28, 0xfd);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18021f2dc
// Address: 0x18021f2dc
// Size: 104 bytes
// ============================================================
void fcn.18021f290(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h, int64_t arg_60h)
{
    int32_t *piVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int32_t iVar7;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18021f2a4;
        iVar5 = fcn.18045a350();
        iVar5 = -iVar5;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0x90);
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 < 2) {
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBP;
            uVar2 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RDI;
            iVar7 = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f2d8;
            iVar4 = func_0x000180222010(uVar2);
            if (0 < iVar4) {
                *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f2eb;
                    iVar6 = func_0x000180222340(uVar2, iVar7);
                    if ((*(int64_t *)(iVar6 + 8) != 0) &&
                       (pcVar3 = *(code **)(*(int64_t *)(iVar6 + 8) + 0x20), pcVar3 != (code *)0x0)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f305;
                        (*pcVar3)(iVar6);
                    }
                    if ((*(int64_t *)(iVar6 + 8) != 0) &&
                       (pcVar3 = *(code **)(*(int64_t *)(iVar6 + 8) + 0x10), pcVar3 != (code *)0x0)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f31c;
                        (*pcVar3)(iVar6);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f331;
                    func_0x000180224990(iVar6, 0x1804bea28, 0x27);
                    iVar7 = iVar7 + 1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f33b;
                    iVar4 = func_0x000180222010(uVar2);
                } while (iVar7 < iVar4);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f34c;
            func_0x000180221d50(uVar2);
            uVar2 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f35c;
            func_0x000180222050(uVar2, 0x18021eb10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f370;
            func_0x000180223fb0(4, arg1, arg1 + 0x80);
            uVar2 = *(undefined8 *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f379;
            func_0x000180233bc0(uVar2);
            uVar2 = *(undefined8 *)(arg1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f385;
            func_0x0001802227d0(uVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f39a;
            func_0x000180224990(arg1, 0x1804bea28, 0xfd);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18021f344
// Address: 0x18021f344
// Size: 96 bytes
// ============================================================
void fcn.18021f290(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h, int64_t arg_60h)
{
    int32_t *piVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int32_t iVar7;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18021f2a4;
        iVar5 = fcn.18045a350();
        iVar5 = -iVar5;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0x90);
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 < 2) {
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBP;
            uVar2 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RDI;
            iVar7 = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f2d8;
            iVar4 = func_0x000180222010(uVar2);
            if (0 < iVar4) {
                *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f2eb;
                    iVar6 = func_0x000180222340(uVar2, iVar7);
                    if ((*(int64_t *)(iVar6 + 8) != 0) &&
                       (pcVar3 = *(code **)(*(int64_t *)(iVar6 + 8) + 0x20), pcVar3 != (code *)0x0)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f305;
                        (*pcVar3)(iVar6);
                    }
                    if ((*(int64_t *)(iVar6 + 8) != 0) &&
                       (pcVar3 = *(code **)(*(int64_t *)(iVar6 + 8) + 0x10), pcVar3 != (code *)0x0)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f31c;
                        (*pcVar3)(iVar6);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f331;
                    func_0x000180224990(iVar6, 0x1804bea28, 0x27);
                    iVar7 = iVar7 + 1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f33b;
                    iVar4 = func_0x000180222010(uVar2);
                } while (iVar7 < iVar4);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f34c;
            func_0x000180221d50(uVar2);
            uVar2 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f35c;
            func_0x000180222050(uVar2, 0x18021eb10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f370;
            func_0x000180223fb0(4, arg1, arg1 + 0x80);
            uVar2 = *(undefined8 *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f379;
            func_0x000180233bc0(uVar2);
            uVar2 = *(undefined8 *)(arg1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f385;
            func_0x0001802227d0(uVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f39a;
            func_0x000180224990(arg1, 0x1804bea28, 0xfd);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18021f3a4
// Address: 0x18021f3a4
// Size: 6 bytes
// ============================================================
void fcn.18021f290(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h, int64_t arg_60h)
{
    int32_t *piVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int32_t iVar7;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18021f2a4;
        iVar5 = fcn.18045a350();
        iVar5 = -iVar5;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0x90);
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 < 2) {
            *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBP;
            uVar2 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RDI;
            iVar7 = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f2d8;
            iVar4 = func_0x000180222010(uVar2);
            if (0 < iVar4) {
                *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
                do {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f2eb;
                    iVar6 = func_0x000180222340(uVar2, iVar7);
                    if ((*(int64_t *)(iVar6 + 8) != 0) &&
                       (pcVar3 = *(code **)(*(int64_t *)(iVar6 + 8) + 0x20), pcVar3 != (code *)0x0)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f305;
                        (*pcVar3)(iVar6);
                    }
                    if ((*(int64_t *)(iVar6 + 8) != 0) &&
                       (pcVar3 = *(code **)(*(int64_t *)(iVar6 + 8) + 0x10), pcVar3 != (code *)0x0)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f31c;
                        (*pcVar3)(iVar6);
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f331;
                    func_0x000180224990(iVar6, 0x1804bea28, 0x27);
                    iVar7 = iVar7 + 1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f33b;
                    iVar4 = func_0x000180222010(uVar2);
                } while (iVar7 < iVar4);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f34c;
            func_0x000180221d50(uVar2);
            uVar2 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f35c;
            func_0x000180222050(uVar2, 0x18021eb10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f370;
            func_0x000180223fb0(4, arg1, arg1 + 0x80);
            uVar2 = *(undefined8 *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f379;
            func_0x000180233bc0(uVar2);
            uVar2 = *(undefined8 *)(arg1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f385;
            func_0x0001802227d0(uVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021f39a;
            func_0x000180224990(arg1, 0x1804bea28, 0xfd);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18021f3b0
// Address: 0x18021f3b0
// Size: 29 bytes
// ============================================================
undefined8 fcn.18021f3b0(int64_t param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    iVar3 = *(int64_t *)(param_1 + 0x98);
    *(undefined8 *)((int64_t)auStackX_18 + iVar1 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1) = 0x18022295c;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)auStackX_18 + (iVar1 - iVar2)) = 0x180222968;
    (*(code *)0x69a094)();
    *(undefined4 *)(iVar3 + 8) = 1;
    return 1;
}

// ============================================================
// Function: FUN_18021f3d0
// Address: 0x18021f3d0
// Size: 414 bytes
// ============================================================
undefined4 * fcn.18021f3d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021f3dc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021f3f6;
    puVar4 = (undefined4 *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar3));
    if (puVar4 == (undefined4 *)0x0) {
        return (undefined4 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_58h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_R13;
    *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021f433;
    iVar5 = fcn.180221ee0(0x18021f7f0);
    *(int64_t *)(puVar4 + 2) = iVar5;
    if (iVar5 != 0) {
        *puVar4 = 1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021f44f;
        iVar5 = fcn.180221f20();
        *(int64_t *)(puVar4 + 4) = iVar5;
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021f465;
            iVar5 = fcn.180234050();
            *(int64_t *)(puVar4 + 6) = iVar5;
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021f490;
                iVar2 = fcn.180224430(*(int64_t *)((int64_t)&arg_58h + iVar3));
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021f4a1;
                    iVar5 = fcn.180222800();
                    *(int64_t *)(puVar4 + 0x26) = iVar5;
                    if (iVar5 != 0) {
                        puVar4[0x24] = 1;
                        return puVar4;
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021f4dd;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021f4eb;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021f4f8;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
    uVar1 = *(undefined8 *)(puVar4 + 6);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021f501;
    fcn.180233bc0(uVar1);
    uVar1 = *(undefined8 *)(puVar4 + 2);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021f50a;
    fcn.180221d50(uVar1);
    uVar1 = *(undefined8 *)(puVar4 + 4);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021f513;
    fcn.180221d50(uVar1);
    uVar1 = *(undefined8 *)(puVar4 + 0x26);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021f51f;
    fcn.1802227d0(uVar1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021f534;
    fcn.180224990(puVar4, 0x1804bea28, 0xde);
    return (undefined4 *)0x0;
}

// ============================================================
// Function: FUN_18021f570
// Address: 0x18021f570
// Size: 26 bytes
// ============================================================
undefined8 fcn.18021f570(int64_t param_1, uint32_t param_2)
{
    int64_t iVar1;
    uint32_t uVar2;
    
    fcn.18045a350();
    iVar1 = *(int64_t *)(param_1 + 0x18);
    uVar2 = param_2 | *(uint32_t *)(iVar1 + 0x14);
    *(uint32_t *)(iVar1 + 0x14) = uVar2;
    if ((param_2 & 0x780) != 0) {
        *(uint32_t *)(iVar1 + 0x14) = uVar2 | 0x80;
    }
    return 1;
}

// ============================================================
// Function: FUN_18021f590
// Address: 0x18021f590
// Size: 29 bytes
// ============================================================
undefined8 fcn.18021f590(int64_t param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    iVar3 = *(int64_t *)(param_1 + 0x98);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1) = 0x18022291a;
    iVar2 = fcn.18045a350();
    if (*(int32_t *)(iVar3 + 8) != 0) {
        *(undefined4 *)(iVar3 + 8) = 0;
        *(undefined8 *)((int64_t)&uStackX_20 + -iVar2 + iVar1) = 0x180222930;
        (*(code *)0x69a062)();
        return 1;
    }
    *(undefined8 *)((int64_t)&uStackX_20 + -iVar2 + iVar1) = 0x180222940;
    (*(code *)0x69a07c)();
    return 1;
}

// ============================================================
// Function: FUN_18021f5d0
// Address: 0x18021f5d0
// Size: 512 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18021f5d0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int64_t *in_RCX;
    uint64_t in_RDX;
    uint32_t uVar10;
    int32_t *piVar11;
    undefined8 in_R8;
    int32_t *in_R9;
    code *pcVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18021f5f2;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar1 = *in_RCX;
    if (iVar1 == 0) {
        return 0;
    }
    piVar11 = (int32_t *)0x0;
    *(undefined4 *)((int64_t)&var_8h + iVar7) = 0;
    *(undefined8 *)((int64_t)&var_10h + iVar7) = 0;
    uVar2 = *(undefined8 *)(iVar1 + 0x98);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18021f623;
    iVar6 = func_0x000180222850(uVar2);
    if (iVar6 == 0) {
        return 0;
    }
    uVar2 = *(undefined8 *)(iVar1 + 8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18021f634;
    iVar6 = func_0x000180221ed0(uVar2);
    if (iVar6 == 0) {
        uVar2 = *(undefined8 *)(iVar1 + 0x98);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18021f644;
        func_0x000180222910(uVar2);
        uVar2 = *(undefined8 *)(iVar1 + 0x98);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18021f650;
        iVar6 = func_0x000180222950(uVar2);
        if (iVar6 == 0) {
            return 0;
        }
        uVar2 = *(undefined8 *)(iVar1 + 8);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18021f661;
        func_0x0001802222d0(uVar2);
    }
    uVar2 = *(undefined8 *)(iVar1 + 8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18021f675;
    iVar6 = func_0x00018021f850(uVar2, in_RDX & 0xffffffff, in_R8, 0);
    if (iVar6 == -1) {
        uVar2 = *(undefined8 *)(iVar1 + 0x98);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18021f689;
        func_0x000180222910(uVar2);
        piVar8 = piVar11;
code_r0x00018021f6b8:
        uVar2 = *(undefined8 *)(iVar1 + 0x10);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18021f6c1;
        iVar6 = func_0x000180222010(uVar2);
        if (0 < iVar6) {
            do {
                uVar2 = *(undefined8 *)(iVar1 + 0x10);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18021f6db;
                iVar9 = func_0x000180222340(uVar2, piVar11);
                if (*(int32_t *)(iVar9 + 4) == 0) {
                    iVar3 = *(int64_t *)(iVar9 + 8);
                    if (iVar3 == 0) {
                        return 0xffffffff;
                    }
                    pcVar4 = *(code **)(iVar3 + 0x30);
                    iVar5 = in_RCX[0x22];
                    if (pcVar4 == (code *)0x0) {
                        if (*(int64_t *)(iVar3 + 0x50) == 0) goto code_r0x00018021f74a;
                        pcVar12 = *(code **)(iVar3 + 0x50);
code_r0x00018021f71a:
                        *(int64_t *)(&stack0x00000000 + iVar7) = in_RCX[0x23];
                        *(int64_t *)(&stack0xfffffffffffffff8 + iVar7) = iVar5;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18021f734;
                        iVar6 = (*pcVar12)(iVar9, in_RDX & 0xffffffff, in_R8, (int64_t)&var_8h + iVar7);
                    } else {
                        pcVar12 = *(code **)(iVar3 + 0x50);
                        if (pcVar12 != (code *)0x0) goto code_r0x00018021f71a;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18021f746;
                        iVar6 = (*pcVar4)(iVar9, in_RDX & 0xffffffff, in_R8, (int64_t)&var_8h + iVar7);
                    }
                    if (iVar6 != 0) {
                        piVar8 = (int32_t *)((int64_t)&var_8h + iVar7);
                        goto code_r0x00018021f762;
                    }
                }
code_r0x00018021f74a:
                uVar2 = *(undefined8 *)(iVar1 + 0x10);
                uVar10 = (int32_t)piVar11 + 1;
                piVar11 = (int32_t *)(uint64_t)uVar10;
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18021f755;
                iVar6 = func_0x000180222010(uVar2);
            } while ((int32_t)uVar10 < iVar6);
        }
        if (piVar8 == (int32_t *)0x0) {
            return 0;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18021f698;
        piVar8 = (int32_t *)func_0x000180222340(uVar2, iVar6);
        uVar2 = *(undefined8 *)(iVar1 + 0x98);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18021f6aa;
        func_0x000180222910(uVar2);
        if ((piVar8 == (int32_t *)0x0) || ((int32_t)in_RDX == 2)) goto code_r0x00018021f6b8;
    }
code_r0x00018021f762:
    if (in_R9 == (int32_t *)0x0) {
        return 1;
    }
    if (*piVar8 == 1) {
        uVar2 = *(undefined8 *)(piVar8 + 2);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18021f78e;
        iVar6 = func_0x0001802375f0(uVar2);
    } else {
        if (*piVar8 != 2) goto code_r0x00018021f799;
        uVar2 = *(undefined8 *)(piVar8 + 2);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18021f77c;
        iVar6 = func_0x00018028ef00(uVar2);
    }
    if (iVar6 == 0) {
        return 0xffffffff;
    }
code_r0x00018021f799:
    *in_R9 = *piVar8;
    *(undefined8 *)(in_R9 + 2) = *(undefined8 *)(piVar8 + 2);
    return 1;
}

// ============================================================
// Function: FUN_18021f7d0
// Address: 0x18021f7d0
// Size: 29 bytes
// ============================================================
undefined8 fcn.18021f7d0(int64_t param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uStackX_20;
    
    iVar2 = fcn.18045a350();
    uVar1 = *(undefined8 *)(param_1 + 0x98);
    *(undefined8 *)((int64_t)&uStackX_20 + -iVar2) = 0x18022285a;
    iVar3 = fcn.18045a350(uVar1);
    *(undefined8 *)((int64_t)&uStackX_20 + (-iVar2 - iVar3)) = 0x180222863;
    (*(code *)0x69a0ae)();
    return 1;
}

// ============================================================
// Function: FUN_18021f7f0
// Address: 0x18021f7f0
// Size: 89 bytes
// ============================================================
uint64_t fcn.18021f7f0(int64_t arg_58h, int64_t arg_78h)
{
    int32_t *piVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    int32_t **in_RCX;
    int64_t iVar10;
    uint32_t uVar11;
    int32_t **in_RDX;
    int64_t iVar12;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 uStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021f7fa;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar1 = *in_RDX;
    piVar2 = *in_RCX;
    iVar6 = *piVar2;
    uVar11 = iVar6 - *piVar1;
    if (uVar11 == 0) {
        if (iVar6 == 0) {
            return 0;
        }
        if (iVar6 == 1) {
            uVar3 = *(undefined8 *)(piVar1 + 2);
            uVar4 = *(undefined8 *)(piVar2 + 2);
            *(undefined8 *)((int64_t)&uStack_8 + iVar7) = 0x18021f839;
            uVar11 = fcn.180238470(uVar4, uVar3);
        } else if (iVar6 == 2) {
            iVar12 = *(int64_t *)(piVar1 + 2);
            iVar10 = *(int64_t *)(piVar2 + 2);
            *(undefined8 *)((int64_t)&uStackX_20 + iVar7) = 0x18023786a;
            iVar8 = fcn.18045a350();
            iVar8 = -iVar8;
            iVar5 = iVar8 + iVar7 + 0x20;
            iVar12 = *(int64_t *)(iVar12 + 0x18);
            iVar10 = *(int64_t *)(iVar10 + 0x18);
            *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_RBX;
            *(undefined8 *)(&stack0x00000048 + iVar8 + iVar7 + 0x20 + -0x20) = unaff_RDI;
            *(undefined8 *)(&stack0x00000040 + iVar8 + iVar7) = 0x1802378f0;
            iVar7 = fcn.18045a350();
            iVar7 = -iVar7;
            if (iVar12 == 0) {
                return (uint64_t)(iVar10 != 0);
            }
            if (iVar10 != 0) {
                if ((*(int64_t *)(iVar10 + 0x18) == 0) || (*(int32_t *)(iVar10 + 8) != 0)) {
                    *(undefined8 *)(&stack0x00000040 + iVar7 + iVar5 + -0x20) = 0x18023793a;
                    iVar6 = fcn.180234b40(*(int64_t *)(&stack0x00000098 + iVar7 + iVar5 + -0x20), 
                                          *(int64_t *)(&stack0x000000c8 + iVar7 + iVar5 + -0x20), 
                                          *(int64_t *)(&stack0x000000d0 + iVar7 + iVar5 + -0x20), 
                                          *(int64_t *)(&stack0x000000d8 + iVar7 + iVar5 + -0x20), 
                                          *(int64_t *)(&stack0x000000e0 + iVar7 + iVar5 + -0x20));
                    if (iVar6 < 0) {
                        return 0xfffffffe;
                    }
                }
                if ((*(int64_t *)(iVar12 + 0x18) == 0) || (*(int32_t *)(iVar12 + 8) != 0)) {
                    *(undefined8 *)(&stack0x00000040 + iVar7 + iVar5 + -0x20) = 0x180237955;
                    iVar6 = fcn.180234b40(*(int64_t *)(&stack0x00000098 + iVar7 + iVar5 + -0x20), 
                                          *(int64_t *)(&stack0x000000c8 + iVar7 + iVar5 + -0x20), 
                                          *(int64_t *)(&stack0x000000d0 + iVar7 + iVar5 + -0x20), 
                                          *(int64_t *)(&stack0x000000d8 + iVar7 + iVar5 + -0x20), 
                                          *(int64_t *)(&stack0x000000e0 + iVar7 + iVar5 + -0x20));
                    if (iVar6 < 0) {
                        return 0xfffffffe;
                    }
                }
                iVar6 = *(int32_t *)(iVar10 + 0x20);
                iVar9 = iVar6 - *(int32_t *)(iVar12 + 0x20);
                if (iVar9 == 0) {
                    if (iVar6 == 0) {
                        return (int64_t)iVar6;
                    }
                    iVar10 = *(int64_t *)(iVar10 + 0x18);
                    if ((iVar10 == 0) || (iVar12 = *(int64_t *)(iVar12 + 0x18), iVar12 == 0)) {
                        return 0xfffffffe;
                    }
                    *(undefined8 *)(&stack0x00000040 + iVar7 + iVar5 + -0x20) = 0x18023798d;
                    iVar9 = fcn.180497f30(iVar10, iVar12, (int64_t)iVar6);
                }
                if (-1 < iVar9) {
                    return (uint64_t)(0 < iVar9);
                }
            }
            return 0xffffffff;
        }
    }
    return (uint64_t)uVar11;
}

// ============================================================
// Function: FUN_18021f850
// Address: 0x18021f850
// Size: 148 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel

void fcn.18021f850(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_120h, int64_t arg_168h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int32_t in_EDX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021f85a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)(&stack0x00000290 + iVar2) = *(uint64_t *)0x1806a3940 ^ (int64_t)&stack0x00000000 + iVar2;
    *(int32_t *)((int64_t)&var_20h + iVar2) = in_EDX;
    if (in_EDX != 0) {
        if (in_EDX == 1) {
            piVar1 = &arg_120h;
            *(undefined8 *)((int64_t)&arg_168h + iVar2) = in_R8;
        } else {
            if (in_EDX != 2) goto code_r0x00018021f8c7;
            piVar1 = &arg_30h;
            *(undefined8 *)((int64_t)&arg_48h + iVar2) = in_R8;
        }
        *(int64_t *)((int64_t)&arg_28h + iVar2) = (int64_t)piVar1 + iVar2;
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021f8af;
        func_0x000180221b80();
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021f8bf;
        func_0x000180459870(*(uint64_t *)(&stack0x00000290 + iVar2) ^ (int64_t)&stack0x00000000 + iVar2);
        return;
    }
code_r0x00018021f8c7:
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021f8dc;
    func_0x000180459870(*(uint64_t *)(&stack0x00000290 + iVar2) ^ (int64_t)&stack0x00000000 + iVar2);
    return;
}

// ============================================================
// Function: FUN_18021f8f0
// Address: 0x18021f8f0
// Size: 72 bytes
// ============================================================
bool fcn.18021f8f0(int64_t arg_30h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int32_t *piVar9;
    int32_t iVar10;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    int32_t in_R8D;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar11;
    undefined8 uStack_28;
    
    uStack_28 = 0x18021f900;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RDX == 0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f92c;
    piVar8 = (int32_t *)fcn.180224d60(*(int64_t *)(&stack0x00000000 + iVar7));
    if (piVar8 == (int32_t *)0x0) {
        return false;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_R14;
    *(int64_t *)(piVar8 + 2) = in_RDX;
    iVar10 = (in_R8D != 0) + 1;
    *piVar8 = iVar10;
    if (iVar10 == 1) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f96c;
        iVar10 = func_0x0001802375f0(in_RDX);
code_r0x00018021f96c:
        if (iVar10 == 0) {
            *piVar8 = 0;
            goto code_r0x00018021f9a5;
        }
    } else if (iVar10 == 2) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f962;
        iVar10 = func_0x00018028ef00(in_RDX);
        goto code_r0x00018021f96c;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x98);
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f981;
    iVar10 = func_0x000180222950(uVar1);
    if (iVar10 == 0) {
        if (*piVar8 == 1) {
            uVar1 = *(undefined8 *)(piVar8 + 2);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f9a5;
            func_0x00018021fe80(uVar1);
        } else if (*piVar8 == 2) {
            uVar1 = *(undefined8 *)(piVar8 + 2);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f99a;
            func_0x00018028eb90(uVar1);
        }
code_r0x00018021f9a5:
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f9ba;
        fcn.180224990(piVar8, 0x1804bea28, 0x212);
        return false;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RBP;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R15;
    uVar1 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f9e4;
    iVar10 = func_0x000180221a50(uVar1, piVar8);
    if (-1 < iVar10) {
        if ((*piVar8 == 1) || (*piVar8 == 2)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa2f;
            iVar4 = func_0x000180222010(uVar1);
            for (; iVar10 < iVar4; iVar10 = iVar10 + 1) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa3f;
                piVar9 = (int32_t *)func_0x000180222340(uVar1, iVar10);
                iVar6 = *piVar9;
                if (iVar6 != *piVar8) break;
                if (iVar6 != 0) {
                    if (iVar6 == 1) {
                        uVar2 = *(undefined8 *)(piVar8 + 2);
                        uVar3 = *(undefined8 *)(piVar9 + 2);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa74;
                        iVar5 = fcn.180238470(uVar3, uVar2);
                    } else {
                        iVar5 = 0;
                        if (iVar6 == 2) {
                            uVar2 = *(undefined8 *)(piVar8 + 2);
                            uVar3 = *(undefined8 *)(piVar9 + 2);
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa65;
                            iVar5 = func_0x000180237860(uVar3, uVar2);
                        }
                    }
                    if (iVar5 != 0) break;
                }
                if (*piVar8 == 1) {
                    uVar2 = *(undefined8 *)(piVar8 + 2);
                    uVar3 = *(undefined8 *)(piVar9 + 2);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa8e;
                    iVar6 = func_0x000180238200(uVar3, uVar2);
                } else {
                    if (*piVar8 != 2) goto code_r0x00018021fa07;
                    uVar2 = *(undefined8 *)(piVar8 + 2);
                    uVar3 = *(undefined8 *)(piVar9 + 2);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021faa6;
                    iVar6 = func_0x000180237880(uVar3, uVar2);
                }
                if (iVar6 == 0) goto code_r0x00018021fa07;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa04;
            piVar9 = (int32_t *)func_0x000180222340(uVar1, iVar10);
code_r0x00018021fa07:
            if (piVar9 != (int32_t *)0x0) {
                uVar1 = *(undefined8 *)(in_RCX + 0x98);
                bVar11 = true;
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa22;
                func_0x000180222910(uVar1);
                goto code_r0x00018021fad8;
            }
        }
    }
    uVar1 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fac0;
    iVar10 = func_0x000180222110(uVar1, piVar8);
    uVar1 = *(undefined8 *)(in_RCX + 0x98);
    bVar11 = iVar10 != 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fad4;
    func_0x000180222910(uVar1);
    if (iVar10 != 0) {
        return bVar11;
    }
code_r0x00018021fad8:
    if (*piVar8 == 1) {
        uVar1 = *(undefined8 *)(piVar8 + 2);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021faf8;
        func_0x00018021fe80(uVar1);
    } else if (*piVar8 == 2) {
        uVar1 = *(undefined8 *)(piVar8 + 2);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021faed;
        func_0x00018028eb90(uVar1);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fb0d;
    fcn.180224990(piVar8, 0x1804bea28, 0x212);
    return bVar11;
}

// ============================================================
// Function: FUN_18021f938
// Address: 0x18021f938
// Size: 147 bytes
// ============================================================
bool fcn.18021f8f0(int64_t arg_30h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int32_t *piVar9;
    int32_t iVar10;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    int32_t in_R8D;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar11;
    undefined8 uStack_28;
    
    uStack_28 = 0x18021f900;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RDX == 0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f92c;
    piVar8 = (int32_t *)fcn.180224d60(*(int64_t *)(&stack0x00000000 + iVar7));
    if (piVar8 == (int32_t *)0x0) {
        return false;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_R14;
    *(int64_t *)(piVar8 + 2) = in_RDX;
    iVar10 = (in_R8D != 0) + 1;
    *piVar8 = iVar10;
    if (iVar10 == 1) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f96c;
        iVar10 = func_0x0001802375f0(in_RDX);
code_r0x00018021f96c:
        if (iVar10 == 0) {
            *piVar8 = 0;
            goto code_r0x00018021f9a5;
        }
    } else if (iVar10 == 2) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f962;
        iVar10 = func_0x00018028ef00(in_RDX);
        goto code_r0x00018021f96c;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x98);
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f981;
    iVar10 = func_0x000180222950(uVar1);
    if (iVar10 == 0) {
        if (*piVar8 == 1) {
            uVar1 = *(undefined8 *)(piVar8 + 2);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f9a5;
            func_0x00018021fe80(uVar1);
        } else if (*piVar8 == 2) {
            uVar1 = *(undefined8 *)(piVar8 + 2);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f99a;
            func_0x00018028eb90(uVar1);
        }
code_r0x00018021f9a5:
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f9ba;
        fcn.180224990(piVar8, 0x1804bea28, 0x212);
        return false;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RBP;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R15;
    uVar1 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f9e4;
    iVar10 = func_0x000180221a50(uVar1, piVar8);
    if (-1 < iVar10) {
        if ((*piVar8 == 1) || (*piVar8 == 2)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa2f;
            iVar4 = func_0x000180222010(uVar1);
            for (; iVar10 < iVar4; iVar10 = iVar10 + 1) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa3f;
                piVar9 = (int32_t *)func_0x000180222340(uVar1, iVar10);
                iVar6 = *piVar9;
                if (iVar6 != *piVar8) break;
                if (iVar6 != 0) {
                    if (iVar6 == 1) {
                        uVar2 = *(undefined8 *)(piVar8 + 2);
                        uVar3 = *(undefined8 *)(piVar9 + 2);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa74;
                        iVar5 = fcn.180238470(uVar3, uVar2);
                    } else {
                        iVar5 = 0;
                        if (iVar6 == 2) {
                            uVar2 = *(undefined8 *)(piVar8 + 2);
                            uVar3 = *(undefined8 *)(piVar9 + 2);
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa65;
                            iVar5 = func_0x000180237860(uVar3, uVar2);
                        }
                    }
                    if (iVar5 != 0) break;
                }
                if (*piVar8 == 1) {
                    uVar2 = *(undefined8 *)(piVar8 + 2);
                    uVar3 = *(undefined8 *)(piVar9 + 2);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa8e;
                    iVar6 = func_0x000180238200(uVar3, uVar2);
                } else {
                    if (*piVar8 != 2) goto code_r0x00018021fa07;
                    uVar2 = *(undefined8 *)(piVar8 + 2);
                    uVar3 = *(undefined8 *)(piVar9 + 2);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021faa6;
                    iVar6 = func_0x000180237880(uVar3, uVar2);
                }
                if (iVar6 == 0) goto code_r0x00018021fa07;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa04;
            piVar9 = (int32_t *)func_0x000180222340(uVar1, iVar10);
code_r0x00018021fa07:
            if (piVar9 != (int32_t *)0x0) {
                uVar1 = *(undefined8 *)(in_RCX + 0x98);
                bVar11 = true;
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa22;
                func_0x000180222910(uVar1);
                goto code_r0x00018021fad8;
            }
        }
    }
    uVar1 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fac0;
    iVar10 = func_0x000180222110(uVar1, piVar8);
    uVar1 = *(undefined8 *)(in_RCX + 0x98);
    bVar11 = iVar10 != 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fad4;
    func_0x000180222910(uVar1);
    if (iVar10 != 0) {
        return bVar11;
    }
code_r0x00018021fad8:
    if (*piVar8 == 1) {
        uVar1 = *(undefined8 *)(piVar8 + 2);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021faf8;
        func_0x00018021fe80(uVar1);
    } else if (*piVar8 == 2) {
        uVar1 = *(undefined8 *)(piVar8 + 2);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021faed;
        func_0x00018028eb90(uVar1);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fb0d;
    fcn.180224990(piVar8, 0x1804bea28, 0x212);
    return bVar11;
}

// ============================================================
// Function: FUN_18021f9cb
// Address: 0x18021f9cb
// Size: 350 bytes
// ============================================================
bool fcn.18021f8f0(int64_t arg_30h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int32_t *piVar9;
    int32_t iVar10;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    int32_t in_R8D;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar11;
    undefined8 uStack_28;
    
    uStack_28 = 0x18021f900;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RDX == 0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f92c;
    piVar8 = (int32_t *)fcn.180224d60(*(int64_t *)(&stack0x00000000 + iVar7));
    if (piVar8 == (int32_t *)0x0) {
        return false;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_R14;
    *(int64_t *)(piVar8 + 2) = in_RDX;
    iVar10 = (in_R8D != 0) + 1;
    *piVar8 = iVar10;
    if (iVar10 == 1) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f96c;
        iVar10 = func_0x0001802375f0(in_RDX);
code_r0x00018021f96c:
        if (iVar10 == 0) {
            *piVar8 = 0;
            goto code_r0x00018021f9a5;
        }
    } else if (iVar10 == 2) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f962;
        iVar10 = func_0x00018028ef00(in_RDX);
        goto code_r0x00018021f96c;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x98);
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f981;
    iVar10 = func_0x000180222950(uVar1);
    if (iVar10 == 0) {
        if (*piVar8 == 1) {
            uVar1 = *(undefined8 *)(piVar8 + 2);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f9a5;
            func_0x00018021fe80(uVar1);
        } else if (*piVar8 == 2) {
            uVar1 = *(undefined8 *)(piVar8 + 2);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f99a;
            func_0x00018028eb90(uVar1);
        }
code_r0x00018021f9a5:
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f9ba;
        fcn.180224990(piVar8, 0x1804bea28, 0x212);
        return false;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RBP;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R15;
    uVar1 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f9e4;
    iVar10 = func_0x000180221a50(uVar1, piVar8);
    if (-1 < iVar10) {
        if ((*piVar8 == 1) || (*piVar8 == 2)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa2f;
            iVar4 = func_0x000180222010(uVar1);
            for (; iVar10 < iVar4; iVar10 = iVar10 + 1) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa3f;
                piVar9 = (int32_t *)func_0x000180222340(uVar1, iVar10);
                iVar6 = *piVar9;
                if (iVar6 != *piVar8) break;
                if (iVar6 != 0) {
                    if (iVar6 == 1) {
                        uVar2 = *(undefined8 *)(piVar8 + 2);
                        uVar3 = *(undefined8 *)(piVar9 + 2);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa74;
                        iVar5 = fcn.180238470(uVar3, uVar2);
                    } else {
                        iVar5 = 0;
                        if (iVar6 == 2) {
                            uVar2 = *(undefined8 *)(piVar8 + 2);
                            uVar3 = *(undefined8 *)(piVar9 + 2);
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa65;
                            iVar5 = func_0x000180237860(uVar3, uVar2);
                        }
                    }
                    if (iVar5 != 0) break;
                }
                if (*piVar8 == 1) {
                    uVar2 = *(undefined8 *)(piVar8 + 2);
                    uVar3 = *(undefined8 *)(piVar9 + 2);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa8e;
                    iVar6 = func_0x000180238200(uVar3, uVar2);
                } else {
                    if (*piVar8 != 2) goto code_r0x00018021fa07;
                    uVar2 = *(undefined8 *)(piVar8 + 2);
                    uVar3 = *(undefined8 *)(piVar9 + 2);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021faa6;
                    iVar6 = func_0x000180237880(uVar3, uVar2);
                }
                if (iVar6 == 0) goto code_r0x00018021fa07;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa04;
            piVar9 = (int32_t *)func_0x000180222340(uVar1, iVar10);
code_r0x00018021fa07:
            if (piVar9 != (int32_t *)0x0) {
                uVar1 = *(undefined8 *)(in_RCX + 0x98);
                bVar11 = true;
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa22;
                func_0x000180222910(uVar1);
                goto code_r0x00018021fad8;
            }
        }
    }
    uVar1 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fac0;
    iVar10 = func_0x000180222110(uVar1, piVar8);
    uVar1 = *(undefined8 *)(in_RCX + 0x98);
    bVar11 = iVar10 != 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fad4;
    func_0x000180222910(uVar1);
    if (iVar10 != 0) {
        return bVar11;
    }
code_r0x00018021fad8:
    if (*piVar8 == 1) {
        uVar1 = *(undefined8 *)(piVar8 + 2);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021faf8;
        func_0x00018021fe80(uVar1);
    } else if (*piVar8 == 2) {
        uVar1 = *(undefined8 *)(piVar8 + 2);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021faed;
        func_0x00018028eb90(uVar1);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fb0d;
    fcn.180224990(piVar8, 0x1804bea28, 0x212);
    return bVar11;
}

// ============================================================
// Function: FUN_18021fb29
// Address: 0x18021fb29
// Size: 12 bytes
// ============================================================
bool fcn.18021f8f0(int64_t arg_30h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int32_t *piVar9;
    int32_t iVar10;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    int32_t in_R8D;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar11;
    undefined8 uStack_28;
    
    uStack_28 = 0x18021f900;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RDX == 0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f92c;
    piVar8 = (int32_t *)fcn.180224d60(*(int64_t *)(&stack0x00000000 + iVar7));
    if (piVar8 == (int32_t *)0x0) {
        return false;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_R14;
    *(int64_t *)(piVar8 + 2) = in_RDX;
    iVar10 = (in_R8D != 0) + 1;
    *piVar8 = iVar10;
    if (iVar10 == 1) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f96c;
        iVar10 = func_0x0001802375f0(in_RDX);
code_r0x00018021f96c:
        if (iVar10 == 0) {
            *piVar8 = 0;
            goto code_r0x00018021f9a5;
        }
    } else if (iVar10 == 2) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f962;
        iVar10 = func_0x00018028ef00(in_RDX);
        goto code_r0x00018021f96c;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x98);
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f981;
    iVar10 = func_0x000180222950(uVar1);
    if (iVar10 == 0) {
        if (*piVar8 == 1) {
            uVar1 = *(undefined8 *)(piVar8 + 2);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f9a5;
            func_0x00018021fe80(uVar1);
        } else if (*piVar8 == 2) {
            uVar1 = *(undefined8 *)(piVar8 + 2);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f99a;
            func_0x00018028eb90(uVar1);
        }
code_r0x00018021f9a5:
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f9ba;
        fcn.180224990(piVar8, 0x1804bea28, 0x212);
        return false;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RBP;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R15;
    uVar1 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021f9e4;
    iVar10 = func_0x000180221a50(uVar1, piVar8);
    if (-1 < iVar10) {
        if ((*piVar8 == 1) || (*piVar8 == 2)) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa2f;
            iVar4 = func_0x000180222010(uVar1);
            for (; iVar10 < iVar4; iVar10 = iVar10 + 1) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa3f;
                piVar9 = (int32_t *)func_0x000180222340(uVar1, iVar10);
                iVar6 = *piVar9;
                if (iVar6 != *piVar8) break;
                if (iVar6 != 0) {
                    if (iVar6 == 1) {
                        uVar2 = *(undefined8 *)(piVar8 + 2);
                        uVar3 = *(undefined8 *)(piVar9 + 2);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa74;
                        iVar5 = fcn.180238470(uVar3, uVar2);
                    } else {
                        iVar5 = 0;
                        if (iVar6 == 2) {
                            uVar2 = *(undefined8 *)(piVar8 + 2);
                            uVar3 = *(undefined8 *)(piVar9 + 2);
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa65;
                            iVar5 = func_0x000180237860(uVar3, uVar2);
                        }
                    }
                    if (iVar5 != 0) break;
                }
                if (*piVar8 == 1) {
                    uVar2 = *(undefined8 *)(piVar8 + 2);
                    uVar3 = *(undefined8 *)(piVar9 + 2);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa8e;
                    iVar6 = func_0x000180238200(uVar3, uVar2);
                } else {
                    if (*piVar8 != 2) goto code_r0x00018021fa07;
                    uVar2 = *(undefined8 *)(piVar8 + 2);
                    uVar3 = *(undefined8 *)(piVar9 + 2);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021faa6;
                    iVar6 = func_0x000180237880(uVar3, uVar2);
                }
                if (iVar6 == 0) goto code_r0x00018021fa07;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa04;
            piVar9 = (int32_t *)func_0x000180222340(uVar1, iVar10);
code_r0x00018021fa07:
            if (piVar9 != (int32_t *)0x0) {
                uVar1 = *(undefined8 *)(in_RCX + 0x98);
                bVar11 = true;
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fa22;
                func_0x000180222910(uVar1);
                goto code_r0x00018021fad8;
            }
        }
    }
    uVar1 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fac0;
    iVar10 = func_0x000180222110(uVar1, piVar8);
    uVar1 = *(undefined8 *)(in_RCX + 0x98);
    bVar11 = iVar10 != 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fad4;
    func_0x000180222910(uVar1);
    if (iVar10 != 0) {
        return bVar11;
    }
code_r0x00018021fad8:
    if (*piVar8 == 1) {
        uVar1 = *(undefined8 *)(piVar8 + 2);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021faf8;
        func_0x00018021fe80(uVar1);
    } else if (*piVar8 == 2) {
        uVar1 = *(undefined8 *)(piVar8 + 2);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021faed;
        func_0x00018028eb90(uVar1);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x18021fb0d;
    fcn.180224990(piVar8, 0x1804bea28, 0x212);
    return bVar11;
}

// ============================================================
// Function: FUN_18021fb50
// Address: 0x18021fb50
// Size: 780 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18021fb50(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined4 in_ECX;
    int64_t *in_RDX;
    undefined8 *in_R9;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    code *pcStack_10;
    
    pcStack_10 = (code *)0x18021fb60;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar1 = *in_RDX;
    // switch table (17 cases) at 0x18021fe18
    switch(in_ECX) {
    default:
        return 1;
    case 3:
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fcc6;
        fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar5), *(int64_t *)(&stack0x00000100 + iVar5));
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fcd2;
        fcn.18028f100(*(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fcde;
        fcn.180228780(*(int64_t *)(&stack0x00000040 + iVar5));
        uVar3 = *(undefined8 *)(iVar1 + 0xf0);
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fcea;
        fcn.18028f3d0(uVar3);
        uVar3 = *(undefined8 *)(iVar1 + 0x100);
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fcf6;
        fcn.180290370(uVar3);
        uVar3 = *(undefined8 *)(iVar1 + 0xf8);
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fd02;
        fcn.180295ed0(uVar3);
        uVar3 = *(undefined8 *)(iVar1 + 0x108);
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fd0e;
        fcn.18028f450(uVar3);
        uVar3 = *(undefined8 *)(iVar1 + 0x110);
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fd1a;
        fcn.180291130(uVar3);
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fd2d;
        fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                      *(int64_t *)(&stack0x00000050 + iVar5));
        uVar3 = *(undefined8 *)(iVar1 + 0x120);
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fd39;
        fcn.180292b40(uVar3);
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fd45;
        fcn.180228780(*(int64_t *)(&stack0x00000040 + iVar5));
        uVar3 = *(undefined8 *)(iVar1 + 0x168);
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fd5e;
        fcn.180224990(uVar3, 0x1804beda0, 0x62);
        return 1;
    case 4:
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fb9b;
        fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar5), *(int64_t *)(&stack0x00000100 + iVar5));
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fba7;
        fcn.18028f100(*(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fbb3;
        fcn.180228780(*(int64_t *)(&stack0x00000040 + iVar5));
        uVar3 = *(undefined8 *)(iVar1 + 0xf0);
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fbbf;
        fcn.18028f3d0(uVar3);
        uVar3 = *(undefined8 *)(iVar1 + 0x100);
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fbcb;
        fcn.180290370(uVar3);
        uVar3 = *(undefined8 *)(iVar1 + 0xf8);
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fbd7;
        fcn.180295ed0(uVar3);
        uVar3 = *(undefined8 *)(iVar1 + 0x108);
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fbe3;
        fcn.18028f450(uVar3);
        uVar3 = *(undefined8 *)(iVar1 + 0x110);
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fbef;
        fcn.180291130(uVar3);
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fc02;
        fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                      *(int64_t *)(&stack0x00000050 + iVar5));
        uVar3 = *(undefined8 *)(iVar1 + 0x120);
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fc0e;
        fcn.180292b40(uVar3);
        *(code **)((int64_t)&pcStack_10 + iVar5) = case.0x18021fb85.1;
        fcn.180228780(*(int64_t *)(&stack0x00000040 + iVar5));
    case 1:
        *(undefined8 *)(iVar1 + 0xd0) = 0xffffffffffffffff;
        *(undefined4 *)(iVar1 + 0x150) = 0;
        *(undefined8 *)(iVar1 + 0xdc) = 0;
        *(undefined4 *)(iVar1 + 0xe4) = 0;
        *(undefined4 *)(iVar1 + 0xd8) = 0;
        *(undefined8 *)(iVar1 + 0xe8) = 0;
        *(undefined8 *)(iVar1 + 0xf0) = 0;
        *(undefined8 *)(iVar1 + 0xf8) = 0;
        *(undefined8 *)(iVar1 + 0x108) = 0;
        *(undefined8 *)(iVar1 + 0x110) = 0;
        *(undefined8 *)(iVar1 + 0x118) = 0;
        *(undefined8 *)(iVar1 + 0x120) = 0;
        *(undefined8 *)(iVar1 + 0x158) = 0;
        *(undefined8 *)(iVar1 + 0x140) = 0;
        *(undefined8 *)(iVar1 + 0x100) = 0;
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fc9a;
        iVar4 = fcn.180224430(*(int64_t *)(&stack0x00000058 + iVar5));
        if (iVar4 != 0) {
            return 1;
        }
        break;
    case 0xf:
        iVar2 = in_R9[0x2d];
        if (iVar1 == 0) {
            return 1;
        }
        uVar3 = *(undefined8 *)(iVar1 + 0x168);
        *(undefined8 *)(iVar1 + 0x160) = in_R9[0x2c];
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fda5;
        fcn.180224990(uVar3, 0x1804beda0, 0x96);
        *(undefined8 *)(iVar1 + 0x168) = 0;
        if (iVar2 == 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar5) = 0x18021fdc8;
        iVar5 = fcn.1802231e0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar5));
        *(int64_t *)(iVar1 + 0x168) = iVar5;
        if (iVar5 != 0) {
            return 1;
        }
        break;
    case 0x10:
        *in_R9 = *(undefined8 *)(iVar1 + 0x160);
        return 1;
    case 0x11:
        *in_R9 = *(undefined8 *)(iVar1 + 0x168);
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_18021fe60
// Address: 0x18021fe60
// Size: 32 bytes
// ============================================================
undefined8
fcn.18021fe60(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
             int64_t arg_60h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_e8h,
             int64_t arg_f0h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    char *pcVar6;
    undefined8 unaff_RBX;
    code *pcVar7;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar6 = "\x01";
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    *(int64_t *)((int64_t)&arg_38h + iVar3) = in_RCX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x18028ef45;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    pcVar7 = (code *)0x0;
    *(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3) = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar4 + iVar3) = 0;
    *(undefined8 *)((int64_t)&arg_98h + iVar4 + iVar3) = 0;
    if (in_RCX != 0) {
        if ((((*pcVar6 == '\x01') || ((*pcVar6 - 2U & 0xfb) == 0)) && (*(int64_t *)(pcVar6 + 0x18) != 0)) &&
           (pcVar7 = *(code **)(*(int64_t *)(pcVar6 + 0x18) + 0x18), pcVar7 != (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028ef9c;
            iVar2 = (*pcVar7)(0xe, (int64_t)&arg_88h + iVar4 + iVar3, pcVar6, 0);
            if (iVar2 == 0) goto code_r0x00018028f06b;
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028efb8;
            iVar2 = (*pcVar7)(0x10, (int64_t)&arg_88h + iVar4 + iVar3, pcVar6, (int64_t)&arg_50h + iVar4 + iVar3);
            if (iVar2 == 0) goto code_r0x00018028f06b;
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028efd4;
            iVar2 = (*pcVar7)(0x11, (int64_t)&arg_88h + iVar4 + iVar3, pcVar6, (int64_t)&arg_98h + iVar4 + iVar3);
            if (iVar2 == 0) goto code_r0x00018028f06b;
            in_RCX = *(int64_t *)((int64_t)&arg_88h + iVar4 + iVar3);
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028eff1;
        iVar2 = func_0x0001802642c0(in_RCX, (int64_t)&arg_90h + iVar4 + iVar3, pcVar6);
        if ((-1 < iVar2) && (iVar1 = *(int64_t *)((int64_t)&arg_90h + iVar4 + iVar3), iVar1 != 0)) {
            *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3) = iVar1;
            *(undefined8 *)((int64_t)&arg_48h + iVar4 + iVar3) = *(undefined8 *)((int64_t)&arg_98h + iVar4 + iVar3);
            *(undefined8 *)((int64_t)&arg_40h + iVar4 + iVar3) = *(undefined8 *)((int64_t)&arg_50h + iVar4 + iVar3);
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028f032;
            uVar5 = func_0x000180261850(0, (int64_t)&arg_60h + iVar4 + iVar3, iVar2, pcVar6);
            *(undefined8 *)((int64_t)&arg_58h + iVar4 + iVar3) = uVar5;
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028f04e;
            fcn.180224990(*(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3), 0x1804ebd30, 0x54);
            if (pcVar7 != (code *)0x0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028f067;
                iVar2 = (*pcVar7)(0xf, (int64_t)&arg_58h + iVar4 + iVar3, pcVar6, 
                                  *(undefined8 *)((int64_t)&arg_88h + iVar4 + iVar3));
                if (iVar2 == 0) {
code_r0x00018028f06b:
                    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028f070;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3));
                    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028f088;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                                  *(int64_t *)(&stack0x00000070 + iVar4 + iVar3));
                    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028f0a2;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
                    return 0;
                }
            }
            return *(undefined8 *)((int64_t)&arg_58h + iVar4 + iVar3);
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028f0c4;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028f0dc;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000070 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028f0ee;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
    }
    return 0;
}

// ============================================================
// Function: FUN_18021fe80
// Address: 0x18021fe80
// Size: 29 bytes
// ============================================================
void fcn.18021fe80(undefined8 param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00000030 + iVar1) = param_1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1) = 0x1802612bf;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x1802612cf;
    fcn.1802612e0(*(int64_t *)(&stack0x00000048 + iVar2 + iVar1), *(int64_t *)(&stack0x00000050 + iVar2 + iVar1), 
                  *(int64_t *)(&stack0x00000058 + iVar2 + iVar1), *(int64_t *)(&stack0x00000060 + iVar2 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18021fec0
// Address: 0x18021fec0
// Size: 29 bytes
// ============================================================
undefined8 fcn.18021fec0(int64_t arg_30h, int64_t arg_50h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    in_RCX = in_RCX + 0xc0;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1802241e0;
    iVar4 = fcn.18045a350();
    if (*(int64_t *)(in_RCX + 8) != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + (iVar3 - iVar4)) = 0x1802241f6;
        iVar2 = fcn.180222010();
        if (in_EDX < iVar2) {
            piVar1 = *(int32_t **)(in_RCX + 8);
            if (((piVar1 != (int32_t *)0x0) && (-1 < in_EDX)) && (in_EDX < *piVar1)) {
                return *(undefined8 *)(*(int64_t *)(piVar1 + 2) + (int64_t)in_EDX * 8);
            }
            return 0;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021fee0
// Address: 0x18021fee0
// Size: 29 bytes
// ============================================================
int32_t fcn.18021fee0(int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                     int64_t arg_98h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint32_t *puVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int32_t iVar7;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar6 = *(int64_t *)(in_RCX + 0x80);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18022cd2a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = iVar4 + iVar3 + 0x20;
    *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3) = iVar6;
    *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3 + 0x20 + -0x20) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = 0x18022ddf0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar7 = 0;
    if (iVar6 != 0) {
        if (*(int32_t *)(iVar6 + 0x10) != 0) {
            return *(int32_t *)(iVar6 + 0x10);
        }
        if (*(int32_t *)(iVar6 + 0x14) != 0) {
            *(undefined4 *)((int64_t)&arg_70h + iVar3 + iVar1 + -0x20) = 0;
            *(undefined8 *)((int64_t)&arg_68h + iVar3 + iVar1 + -0x20) = 0x18022dcf0;
            *(undefined8 *)(&stack0x00000040 + iVar3 + iVar1 + -0x20) = 0x18022de3f;
            puVar5 = (uint32_t *)
                     fcn.1802963b0(*(int64_t *)((int64_t)&arg_68h + iVar3 + iVar1 + -0x20), 
                                   *(int64_t *)((int64_t)&arg_70h + iVar3 + iVar1 + -0x20), 
                                   *(int64_t *)((int64_t)&arg_78h + iVar3 + iVar1 + -0x20), 
                                   *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                                   *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20));
            if (puVar5 != (uint32_t *)0x0) {
                return *(int32_t *)((uint64_t)*puVar5 * 0x28 + 0x1804c3050);
            }
            *(undefined8 *)(&stack0x00000040 + iVar3 + iVar1 + -0x20) = 0x18022de5f;
            iVar2 = fcn.18022dee0();
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&arg_80h + iVar3 + iVar1 + -0x20) =
                     *(undefined8 *)((int64_t)&arg_98h + iVar3 + iVar1 + -0x20);
                *(undefined4 *)((int64_t)&arg_78h + iVar3 + iVar1 + -0x20) = 0;
                *(undefined8 *)(&stack0x00000040 + iVar3 + iVar1 + -0x20) = 0x18022deb9;
                iVar6 = fcn.180229240(*(int64_t *)((int64_t)&arg_70h + iVar3 + iVar1 + -0x20));
                if (iVar6 != 0) {
                    iVar7 = *(int32_t *)(*(int64_t *)(iVar6 + 8) + 0x10);
                }
                *(undefined8 *)(&stack0x00000040 + iVar3 + iVar1 + -0x20) = 0x18022ded1;
                fcn.180222910(*(undefined8 *)0x18077e4a8);
                return iVar7;
            }
            *(undefined8 *)(&stack0x00000040 + iVar3 + iVar1 + -0x20) = 0x18022de68;
            fcn.180229480(*(int64_t *)((int64_t)&arg_68h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_70h + iVar3 + iVar1 + -0x20));
            *(undefined8 *)(&stack0x00000040 + iVar3 + iVar1 + -0x20) = 0x18022de80;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_68h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_70h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_78h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_80h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_98h + iVar3 + iVar1 + -0x20));
            *(undefined8 *)(&stack0x00000040 + iVar3 + iVar1 + -0x20) = 0x18022de92;
            fcn.1802296d0(*(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021ff10
// Address: 0x18021ff10
// Size: 189 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18021ff10(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021ff25;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ff40;
    iVar3 = fcn.180260b80(*(int64_t *)(&stack0x00000040 + iVar2));
    if (iVar3 != 0) {
        uVar1 = *(undefined8 *)(iVar3 + 0x168);
        *(undefined8 *)(iVar3 + 0x160) = in_RCX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ff68;
        fcn.180224990(uVar1, 0x1804beda0, 0x96);
        *(undefined8 *)(iVar3 + 0x168) = 0;
        if (in_RDX != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ff8d;
            iVar4 = fcn.1802231e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2));
            *(int64_t *)(iVar3 + 0x168) = iVar4;
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ffa8;
                fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000048 + iVar2));
                return 0;
            }
        }
    }
    return iVar3;
}

// ============================================================
// Function: FUN_18021ffd0
// Address: 0x18021ffd0
// Size: 29 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling

bool fcn.18021ffd0(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    in_RCX = in_RCX + 0xc0;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x180224465;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar6 = *(int64_t *)(in_RCX + 8);
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18022447e;
        iVar6 = fcn.180221f20();
        *(int64_t *)(in_RCX + 8) = iVar6;
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18022448c;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802244a4;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802244b6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
            return false;
        }
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar5 + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802244d5;
    iVar2 = fcn.180222010(iVar6);
    while( true ) {
        if (in_EDX < iVar2) {
            uVar1 = *(undefined8 *)(in_RCX + 8);
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180224503;
            iVar6 = fcn.1802221b0(uVar1, in_EDX, in_R8);
            if (iVar6 != in_R8) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18022450d;
                fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180224525;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180224537;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
            }
            return iVar6 == in_R8;
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802244eb;
        iVar3 = fcn.180222110(*(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000068 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000070 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000078 + iVar5 + iVar4));
        if (iVar3 == 0) break;
        iVar2 = iVar2 + 1;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180224540;
    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180224558;
    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                  *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                  *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18022456a;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
    return false;
}

// ============================================================
// Function: FUN_18021fff0
// Address: 0x18021fff0
// Size: 29 bytes
// ============================================================
void fcn.18021fff0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_60h, int64_t arg_70h, int64_t arg_78h, int64_t arg_90h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t iVar4;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar5;
    undefined8 uStackX_8;
    undefined8 auStackX_10 [3];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar5 = 0x1804becd0;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 0x10) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar2) = 0x18026177e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_90h + iVar3 + iVar2) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_10 + iVar3 + iVar2;
    *(undefined8 *)((int64_t)&arg_70h + iVar3 + iVar2) = 0;
    *(undefined *)((int64_t)&arg_78h + iVar3 + iVar2) = 0;
    iVar4 = (int64_t)&arg_70h + iVar3 + iVar2;
    if (in_RCX != 0) {
        iVar4 = in_RCX;
    }
    if ((iVar4 == 0) || (iVar5 == 0)) {
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261804;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar3 + iVar2), *(int64_t *)((int64_t)&arg_38h + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026181c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar3 + iVar2), *(int64_t *)((int64_t)&arg_38h + iVar3 + iVar2), 
                      *(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2), 
                      *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026182e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2));
    } else {
        *(undefined8 *)((int64_t)&arg_60h + iVar3 + iVar2) = 0;
        *(undefined8 *)((int64_t)&arg_58h + iVar3 + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_50h + iVar3 + iVar2) = 0;
        *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2) = (int64_t)&arg_78h + iVar3 + iVar2;
        *(undefined *)((int64_t)&arg_40h + iVar3 + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_38h + iVar3 + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = 0xffffffff;
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617e9;
        iVar1 = func_0x0001802629a0(iVar4);
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617f8;
            func_0x000180261290(iVar4, iVar5);
        }
    }
    *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261841;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_90h + iVar3 + iVar2) ^ (int64_t)auStackX_10 + iVar3 + iVar2);
    return;
}

// ============================================================
// Function: FUN_180220010
// Address: 0x180220010
// Size: 192 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180220010(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    bool bVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    undefined8 uVar5;
    undefined8 *in_RDX;
    int32_t in_R8D;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180220028;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    bVar1 = false;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = *in_RDX;
    if ((in_RCX == (int64_t *)0x0) || (*in_RCX == 0)) {
        bVar1 = true;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18022005e;
    iVar3 = func_0x000180261770();
    if (iVar3 == 0) {
code_r0x0001802200ae:
        iVar3 = 0;
    } else {
        uVar5 = *(undefined8 *)((int64_t)&arg_28h + iVar2);
        in_R8D = in_R8D + (*(int32_t *)in_RDX - (int32_t)uVar5);
        if (0 < in_R8D) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18022008a;
            iVar4 = func_0x00018028f3b0(iVar3 + 0x140, (int64_t)&arg_28h + iVar2, in_R8D);
            if (iVar4 == 0) {
                if (bVar1) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1802200a2;
                    fcn.1802612b0(*(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&arg_38h + iVar2));
                    if (in_RCX != (int64_t *)0x0) {
                        *in_RCX = 0;
                    }
                }
                goto code_r0x0001802200ae;
            }
            uVar5 = *(undefined8 *)((int64_t)&arg_28h + iVar2);
        }
        *in_RDX = uVar5;
    }
    return iVar3;
}

// ============================================================
// Function: FUN_1802200d0
// Address: 0x1802200d0
// Size: 29 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.1802200d0(undefined8 param_1, int64_t *param_2)
{
    int64_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar6;
    undefined8 unaff_R14;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x1802642ca;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = iVar4 + iVar3 + 0x20;
    uVar6 = 0;
    *(undefined8 *)(&stack0x00000058 + iVar4 + iVar3) = param_1;
    *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + 0x20 + -0x20) = unaff_RSI;
    *(undefined8 *)(&stack0x00000030 + iVar4 + iVar3) = 0x1802645e2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((param_2 != (int64_t *)0x0) && (*param_2 == 0)) {
        *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
        *(undefined8 *)(&stack0x00000098 + iVar3 + iVar1 + -0x20) = unaff_RDI;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026461d;
        uVar2 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
        if ((int32_t)uVar2 < 1) {
            return (uint64_t)uVar2;
        }
        *(undefined8 *)(&stack0x000000a0 + iVar3 + iVar1 + -0x20) = unaff_R14;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026464d;
        iVar4 = fcn.1802248d0(*(int64_t *)(&stack0x00000058 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000060 + iVar3 + iVar1 + -0x20));
        if (iVar4 == 0) {
            uVar5 = 0xffffffff;
        } else {
            *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20) = iVar4;
            *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
            *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026468d;
            fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
            uVar5 = (uint64_t)uVar2;
            *param_2 = iVar4;
        }
        return uVar5;
    }
    *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
    *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x1802646a8;
    uVar5 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
    return uVar5;
}

// ============================================================
// Function: FUN_1802200f0
// Address: 0x1802200f0
// Size: 36 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.1802200f0(int64_t param_1, int64_t *param_2)
{
    int64_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar6;
    undefined8 unaff_R14;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined4 *)(param_1 + 0x7c) = 1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x1802642ca;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = iVar4 + iVar3 + 0x20;
    uVar6 = 0;
    *(int64_t *)(&stack0x00000058 + iVar4 + iVar3) = param_1;
    *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + 0x20 + -0x20) = unaff_RSI;
    *(undefined8 *)(&stack0x00000030 + iVar4 + iVar3) = 0x1802645e2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((param_2 != (int64_t *)0x0) && (*param_2 == 0)) {
        *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
        *(undefined8 *)(&stack0x00000098 + iVar3 + iVar1 + -0x20) = unaff_RDI;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026461d;
        uVar2 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
        if ((int32_t)uVar2 < 1) {
            return (uint64_t)uVar2;
        }
        *(undefined8 *)(&stack0x000000a0 + iVar3 + iVar1 + -0x20) = unaff_R14;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026464d;
        iVar4 = fcn.1802248d0(*(int64_t *)(&stack0x00000058 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000060 + iVar3 + iVar1 + -0x20));
        if (iVar4 == 0) {
            uVar5 = 0xffffffff;
        } else {
            *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20) = iVar4;
            *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
            *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026468d;
            fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
            uVar5 = (uint64_t)uVar2;
            *param_2 = iVar4;
        }
        return uVar5;
    }
    *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
    *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x1802646a8;
    uVar5 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
    return uVar5;
}

// ============================================================
// Function: FUN_180220120
// Address: 0x180220120
// Size: 155 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.180220120(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180220135;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX != 0) {
        *(undefined8 *)(in_RCX + 0x160) = in_RDX;
        uVar1 = *(undefined8 *)(in_RCX + 0x168);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220163;
        fcn.180224990(uVar1, 0x1804beda0, 0x96);
        *(undefined8 *)(in_RCX + 0x168) = 0;
        if (in_R8 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220186;
            iVar2 = fcn.1802231e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar2));
            *(int64_t *)(in_RCX + 0x168) = iVar2;
            return iVar2 != 0;
        }
    }
    return true;
}

// ============================================================
// Function: FUN_1802201c0
// Address: 0x1802201c0
// Size: 53 bytes
// ============================================================
void fcn.1802201c0(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802201ca;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_R8;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802201f0;
    fcn.180244fe0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000080 + iVar1), 
                  *(int64_t *)(&stack0x00000088 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180220200
// Address: 0x180220200
// Size: 69 bytes
// ============================================================
void fcn.180220200(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022020a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_40h + iVar1) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar1) = 0;
    *(undefined4 *)((int64_t)&arg_30h + iVar1) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180220240;
    fcn.180240830(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1), 
                  *(int64_t *)((int64_t)&arg_40h + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                  *(int64_t *)(&stack0x00000088 + iVar1), *(int64_t *)(&stack0x00000090 + iVar1), 
                  *(int64_t *)(&stack0x00000098 + iVar1), *(int64_t *)(&stack0x000000a0 + iVar1), 
                  *(int64_t *)(&stack0x000000a8 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180220250
// Address: 0x180220250
// Size: 56 bytes
// ============================================================
void fcn.180220250(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_58h, int64_t arg_80h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined *puVar7;
    undefined8 unaff_RBX;
    undefined *puVar8;
    int32_t iVar9;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar10;
    uint64_t uVar11;
    undefined8 uVar12;
    undefined8 unaff_R14;
    undefined *puVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    iVar9 = (int32_t)arg1;
    uStack_18 = 0x180220270;
    var_10h = arg2;
    var_18h = arg3;
    var_20h = arg4;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x18022027f;
    iVar4 = func_0x000180221280();
    if (iVar4 == 0) {
        return;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RDI;
    iVar10 = (int64_t)*(int32_t *)(iVar4 + 0x340);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    iVar6 = iVar4 + iVar10 * 4;
    if (((uint8_t)*(undefined4 *)(iVar6 + 0x1c0) & 3) == 3) {
        iVar2 = iVar4 + iVar10 * 8;
        puVar7 = *(undefined **)(iVar2 + 0xc0);
        if (puVar7 != (undefined *)0x0) {
            uVar11 = *(uint64_t *)(iVar4 + 0x140 + iVar10 * 8);
            *(undefined8 *)(iVar2 + 0xc0) = 0;
            *(undefined4 *)(iVar6 + 0x1c0) = 0;
            goto code_r0x0001802202fc;
        }
    }
    uVar11 = 0x51;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1802202ed;
    puVar7 = (undefined *)
             fcn.1802248d0(*(int64_t *)((int64_t)&var_10h + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3));
    if (puVar7 == (undefined *)0x0) {
        return;
    }
    *puVar7 = 0;
code_r0x0001802202fc:
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x18022030e;
    uVar5 = fcn.180498cd0(puVar7);
    iVar9 = iVar9 + -1;
    if (-1 < iVar9) {
        puVar13 = &stack0x00000050 + iVar3;
        puVar8 = puVar7;
        do {
            piVar1 = (int64_t *)(puVar13 + 8);
            puVar13 = puVar13 + 8;
            iVar4 = 0x1804bf754;
            if (*piVar1 != 0) {
                iVar4 = *piVar1;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x18022033e;
            iVar6 = fcn.180498cd0(iVar4);
            uVar5 = uVar5 + iVar6;
            puVar7 = puVar8;
            if (uVar11 <= uVar5) {
                uVar11 = uVar5 + 0x14;
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180220362;
                puVar7 = (undefined *)func_0x0001802249c0(puVar8, uVar11, 0x1804bf6f0, 0x35e);
                if (puVar7 == (undefined *)0x0) {
                    uVar12 = 0x360;
                    goto code_r0x00018022039b;
                }
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180220378;
            func_0x000180223710(puVar7, iVar4, uVar11);
            iVar9 = iVar9 + -1;
            puVar8 = puVar7;
        } while (-1 < iVar9);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180220391;
    iVar9 = func_0x0001802210c0(puVar7, uVar11, 3, 0);
    if (iVar9 == 0) {
        uVar12 = 0x368;
        puVar8 = puVar7;
code_r0x00018022039b:
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1802203aa;
        fcn.180224990(puVar8, 0x1804bf6f0, uVar12);
    }
    return;
}

// ============================================================
// Function: FUN_180220288
// Address: 0x180220288
// Size: 116 bytes
// ============================================================
void fcn.180220250(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_58h, int64_t arg_80h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined *puVar7;
    undefined8 unaff_RBX;
    undefined *puVar8;
    int32_t iVar9;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar10;
    uint64_t uVar11;
    undefined8 uVar12;
    undefined8 unaff_R14;
    undefined *puVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    iVar9 = (int32_t)arg1;
    uStack_18 = 0x180220270;
    var_10h = arg2;
    var_18h = arg3;
    var_20h = arg4;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x18022027f;
    iVar4 = func_0x000180221280();
    if (iVar4 == 0) {
        return;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RDI;
    iVar10 = (int64_t)*(int32_t *)(iVar4 + 0x340);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    iVar6 = iVar4 + iVar10 * 4;
    if (((uint8_t)*(undefined4 *)(iVar6 + 0x1c0) & 3) == 3) {
        iVar2 = iVar4 + iVar10 * 8;
        puVar7 = *(undefined **)(iVar2 + 0xc0);
        if (puVar7 != (undefined *)0x0) {
            uVar11 = *(uint64_t *)(iVar4 + 0x140 + iVar10 * 8);
            *(undefined8 *)(iVar2 + 0xc0) = 0;
            *(undefined4 *)(iVar6 + 0x1c0) = 0;
            goto code_r0x0001802202fc;
        }
    }
    uVar11 = 0x51;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1802202ed;
    puVar7 = (undefined *)
             fcn.1802248d0(*(int64_t *)((int64_t)&var_10h + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3));
    if (puVar7 == (undefined *)0x0) {
        return;
    }
    *puVar7 = 0;
code_r0x0001802202fc:
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x18022030e;
    uVar5 = fcn.180498cd0(puVar7);
    iVar9 = iVar9 + -1;
    if (-1 < iVar9) {
        puVar13 = &stack0x00000050 + iVar3;
        puVar8 = puVar7;
        do {
            piVar1 = (int64_t *)(puVar13 + 8);
            puVar13 = puVar13 + 8;
            iVar4 = 0x1804bf754;
            if (*piVar1 != 0) {
                iVar4 = *piVar1;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x18022033e;
            iVar6 = fcn.180498cd0(iVar4);
            uVar5 = uVar5 + iVar6;
            puVar7 = puVar8;
            if (uVar11 <= uVar5) {
                uVar11 = uVar5 + 0x14;
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180220362;
                puVar7 = (undefined *)func_0x0001802249c0(puVar8, uVar11, 0x1804bf6f0, 0x35e);
                if (puVar7 == (undefined *)0x0) {
                    uVar12 = 0x360;
                    goto code_r0x00018022039b;
                }
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180220378;
            func_0x000180223710(puVar7, iVar4, uVar11);
            iVar9 = iVar9 + -1;
            puVar8 = puVar7;
        } while (-1 < iVar9);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180220391;
    iVar9 = func_0x0001802210c0(puVar7, uVar11, 3, 0);
    if (iVar9 == 0) {
        uVar12 = 0x368;
        puVar8 = puVar7;
code_r0x00018022039b:
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1802203aa;
        fcn.180224990(puVar8, 0x1804bf6f0, uVar12);
    }
    return;
}

// ============================================================
// Function: FUN_1802202fc
// Address: 0x1802202fc
// Size: 184 bytes
// ============================================================
void fcn.180220250(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_58h, int64_t arg_80h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined *puVar7;
    undefined8 unaff_RBX;
    undefined *puVar8;
    int32_t iVar9;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar10;
    uint64_t uVar11;
    undefined8 uVar12;
    undefined8 unaff_R14;
    undefined *puVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    iVar9 = (int32_t)arg1;
    uStack_18 = 0x180220270;
    var_10h = arg2;
    var_18h = arg3;
    var_20h = arg4;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x18022027f;
    iVar4 = func_0x000180221280();
    if (iVar4 == 0) {
        return;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RDI;
    iVar10 = (int64_t)*(int32_t *)(iVar4 + 0x340);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    iVar6 = iVar4 + iVar10 * 4;
    if (((uint8_t)*(undefined4 *)(iVar6 + 0x1c0) & 3) == 3) {
        iVar2 = iVar4 + iVar10 * 8;
        puVar7 = *(undefined **)(iVar2 + 0xc0);
        if (puVar7 != (undefined *)0x0) {
            uVar11 = *(uint64_t *)(iVar4 + 0x140 + iVar10 * 8);
            *(undefined8 *)(iVar2 + 0xc0) = 0;
            *(undefined4 *)(iVar6 + 0x1c0) = 0;
            goto code_r0x0001802202fc;
        }
    }
    uVar11 = 0x51;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1802202ed;
    puVar7 = (undefined *)
             fcn.1802248d0(*(int64_t *)((int64_t)&var_10h + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3));
    if (puVar7 == (undefined *)0x0) {
        return;
    }
    *puVar7 = 0;
code_r0x0001802202fc:
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x18022030e;
    uVar5 = fcn.180498cd0(puVar7);
    iVar9 = iVar9 + -1;
    if (-1 < iVar9) {
        puVar13 = &stack0x00000050 + iVar3;
        puVar8 = puVar7;
        do {
            piVar1 = (int64_t *)(puVar13 + 8);
            puVar13 = puVar13 + 8;
            iVar4 = 0x1804bf754;
            if (*piVar1 != 0) {
                iVar4 = *piVar1;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x18022033e;
            iVar6 = fcn.180498cd0(iVar4);
            uVar5 = uVar5 + iVar6;
            puVar7 = puVar8;
            if (uVar11 <= uVar5) {
                uVar11 = uVar5 + 0x14;
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180220362;
                puVar7 = (undefined *)func_0x0001802249c0(puVar8, uVar11, 0x1804bf6f0, 0x35e);
                if (puVar7 == (undefined *)0x0) {
                    uVar12 = 0x360;
                    goto code_r0x00018022039b;
                }
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180220378;
            func_0x000180223710(puVar7, iVar4, uVar11);
            iVar9 = iVar9 + -1;
            puVar8 = puVar7;
        } while (-1 < iVar9);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180220391;
    iVar9 = func_0x0001802210c0(puVar7, uVar11, 3, 0);
    if (iVar9 == 0) {
        uVar12 = 0x368;
        puVar8 = puVar7;
code_r0x00018022039b:
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1802203aa;
        fcn.180224990(puVar8, 0x1804bf6f0, uVar12);
    }
    return;
}

// ============================================================
// Function: FUN_1802203b4
// Address: 0x1802203b4
// Size: 10 bytes
// ============================================================
void fcn.180220250(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_58h, int64_t arg_80h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined *puVar7;
    undefined8 unaff_RBX;
    undefined *puVar8;
    int32_t iVar9;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar10;
    uint64_t uVar11;
    undefined8 uVar12;
    undefined8 unaff_R14;
    undefined *puVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    iVar9 = (int32_t)arg1;
    uStack_18 = 0x180220270;
    var_10h = arg2;
    var_18h = arg3;
    var_20h = arg4;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x18022027f;
    iVar4 = func_0x000180221280();
    if (iVar4 == 0) {
        return;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RDI;
    iVar10 = (int64_t)*(int32_t *)(iVar4 + 0x340);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    iVar6 = iVar4 + iVar10 * 4;
    if (((uint8_t)*(undefined4 *)(iVar6 + 0x1c0) & 3) == 3) {
        iVar2 = iVar4 + iVar10 * 8;
        puVar7 = *(undefined **)(iVar2 + 0xc0);
        if (puVar7 != (undefined *)0x0) {
            uVar11 = *(uint64_t *)(iVar4 + 0x140 + iVar10 * 8);
            *(undefined8 *)(iVar2 + 0xc0) = 0;
            *(undefined4 *)(iVar6 + 0x1c0) = 0;
            goto code_r0x0001802202fc;
        }
    }
    uVar11 = 0x51;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1802202ed;
    puVar7 = (undefined *)
             fcn.1802248d0(*(int64_t *)((int64_t)&var_10h + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3));
    if (puVar7 == (undefined *)0x0) {
        return;
    }
    *puVar7 = 0;
code_r0x0001802202fc:
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x18022030e;
    uVar5 = fcn.180498cd0(puVar7);
    iVar9 = iVar9 + -1;
    if (-1 < iVar9) {
        puVar13 = &stack0x00000050 + iVar3;
        puVar8 = puVar7;
        do {
            piVar1 = (int64_t *)(puVar13 + 8);
            puVar13 = puVar13 + 8;
            iVar4 = 0x1804bf754;
            if (*piVar1 != 0) {
                iVar4 = *piVar1;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x18022033e;
            iVar6 = fcn.180498cd0(iVar4);
            uVar5 = uVar5 + iVar6;
            puVar7 = puVar8;
            if (uVar11 <= uVar5) {
                uVar11 = uVar5 + 0x14;
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180220362;
                puVar7 = (undefined *)func_0x0001802249c0(puVar8, uVar11, 0x1804bf6f0, 0x35e);
                if (puVar7 == (undefined *)0x0) {
                    uVar12 = 0x360;
                    goto code_r0x00018022039b;
                }
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180220378;
            func_0x000180223710(puVar7, iVar4, uVar11);
            iVar9 = iVar9 + -1;
            puVar8 = puVar7;
        } while (-1 < iVar9);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180220391;
    iVar9 = func_0x0001802210c0(puVar7, uVar11, 3, 0);
    if (iVar9 == 0) {
        uVar12 = 0x368;
        puVar8 = puVar7;
code_r0x00018022039b:
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1802203aa;
        fcn.180224990(puVar8, 0x1804bf6f0, uVar12);
    }
    return;
}

// ============================================================
// Function: FUN_1802203be
// Address: 0x1802203be
// Size: 8 bytes
// ============================================================
void fcn.180220250(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_58h, int64_t arg_80h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined *puVar7;
    undefined8 unaff_RBX;
    undefined *puVar8;
    int32_t iVar9;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar10;
    uint64_t uVar11;
    undefined8 uVar12;
    undefined8 unaff_R14;
    undefined *puVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    iVar9 = (int32_t)arg1;
    uStack_18 = 0x180220270;
    var_10h = arg2;
    var_18h = arg3;
    var_20h = arg4;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x18022027f;
    iVar4 = func_0x000180221280();
    if (iVar4 == 0) {
        return;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RDI;
    iVar10 = (int64_t)*(int32_t *)(iVar4 + 0x340);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    iVar6 = iVar4 + iVar10 * 4;
    if (((uint8_t)*(undefined4 *)(iVar6 + 0x1c0) & 3) == 3) {
        iVar2 = iVar4 + iVar10 * 8;
        puVar7 = *(undefined **)(iVar2 + 0xc0);
        if (puVar7 != (undefined *)0x0) {
            uVar11 = *(uint64_t *)(iVar4 + 0x140 + iVar10 * 8);
            *(undefined8 *)(iVar2 + 0xc0) = 0;
            *(undefined4 *)(iVar6 + 0x1c0) = 0;
            goto code_r0x0001802202fc;
        }
    }
    uVar11 = 0x51;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1802202ed;
    puVar7 = (undefined *)
             fcn.1802248d0(*(int64_t *)((int64_t)&var_10h + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3));
    if (puVar7 == (undefined *)0x0) {
        return;
    }
    *puVar7 = 0;
code_r0x0001802202fc:
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x18022030e;
    uVar5 = fcn.180498cd0(puVar7);
    iVar9 = iVar9 + -1;
    if (-1 < iVar9) {
        puVar13 = &stack0x00000050 + iVar3;
        puVar8 = puVar7;
        do {
            piVar1 = (int64_t *)(puVar13 + 8);
            puVar13 = puVar13 + 8;
            iVar4 = 0x1804bf754;
            if (*piVar1 != 0) {
                iVar4 = *piVar1;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x18022033e;
            iVar6 = fcn.180498cd0(iVar4);
            uVar5 = uVar5 + iVar6;
            puVar7 = puVar8;
            if (uVar11 <= uVar5) {
                uVar11 = uVar5 + 0x14;
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180220362;
                puVar7 = (undefined *)func_0x0001802249c0(puVar8, uVar11, 0x1804bf6f0, 0x35e);
                if (puVar7 == (undefined *)0x0) {
                    uVar12 = 0x360;
                    goto code_r0x00018022039b;
                }
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180220378;
            func_0x000180223710(puVar7, iVar4, uVar11);
            iVar9 = iVar9 + -1;
            puVar8 = puVar7;
        } while (-1 < iVar9);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180220391;
    iVar9 = func_0x0001802210c0(puVar7, uVar11, 3, 0);
    if (iVar9 == 0) {
        uVar12 = 0x368;
        puVar8 = puVar7;
code_r0x00018022039b:
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1802203aa;
        fcn.180224990(puVar8, 0x1804bf6f0, uVar12);
    }
    return;
}

// ============================================================
// Function: FUN_1802203c6
// Address: 0x1802203c6
// Size: 8 bytes
// ============================================================
void fcn.180220250(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_58h, int64_t arg_80h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined *puVar7;
    undefined8 unaff_RBX;
    undefined *puVar8;
    int32_t iVar9;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar10;
    uint64_t uVar11;
    undefined8 uVar12;
    undefined8 unaff_R14;
    undefined *puVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    iVar9 = (int32_t)arg1;
    uStack_18 = 0x180220270;
    var_10h = arg2;
    var_18h = arg3;
    var_20h = arg4;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x18022027f;
    iVar4 = func_0x000180221280();
    if (iVar4 == 0) {
        return;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RDI;
    iVar10 = (int64_t)*(int32_t *)(iVar4 + 0x340);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    iVar6 = iVar4 + iVar10 * 4;
    if (((uint8_t)*(undefined4 *)(iVar6 + 0x1c0) & 3) == 3) {
        iVar2 = iVar4 + iVar10 * 8;
        puVar7 = *(undefined **)(iVar2 + 0xc0);
        if (puVar7 != (undefined *)0x0) {
            uVar11 = *(uint64_t *)(iVar4 + 0x140 + iVar10 * 8);
            *(undefined8 *)(iVar2 + 0xc0) = 0;
            *(undefined4 *)(iVar6 + 0x1c0) = 0;
            goto code_r0x0001802202fc;
        }
    }
    uVar11 = 0x51;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1802202ed;
    puVar7 = (undefined *)
             fcn.1802248d0(*(int64_t *)((int64_t)&var_10h + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3));
    if (puVar7 == (undefined *)0x0) {
        return;
    }
    *puVar7 = 0;
code_r0x0001802202fc:
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x18022030e;
    uVar5 = fcn.180498cd0(puVar7);
    iVar9 = iVar9 + -1;
    if (-1 < iVar9) {
        puVar13 = &stack0x00000050 + iVar3;
        puVar8 = puVar7;
        do {
            piVar1 = (int64_t *)(puVar13 + 8);
            puVar13 = puVar13 + 8;
            iVar4 = 0x1804bf754;
            if (*piVar1 != 0) {
                iVar4 = *piVar1;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x18022033e;
            iVar6 = fcn.180498cd0(iVar4);
            uVar5 = uVar5 + iVar6;
            puVar7 = puVar8;
            if (uVar11 <= uVar5) {
                uVar11 = uVar5 + 0x14;
                *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180220362;
                puVar7 = (undefined *)func_0x0001802249c0(puVar8, uVar11, 0x1804bf6f0, 0x35e);
                if (puVar7 == (undefined *)0x0) {
                    uVar12 = 0x360;
                    goto code_r0x00018022039b;
                }
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180220378;
            func_0x000180223710(puVar7, iVar4, uVar11);
            iVar9 = iVar9 + -1;
            puVar8 = puVar7;
        } while (-1 < iVar9);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180220391;
    iVar9 = func_0x0001802210c0(puVar7, uVar11, 3, 0);
    if (iVar9 == 0) {
        uVar12 = 0x368;
        puVar8 = puVar7;
code_r0x00018022039b:
        *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1802203aa;
        fcn.180224990(puVar8, 0x1804bf6f0, uVar12);
    }
    return;
}

// ============================================================
// Function: FUN_1802203d0
// Address: 0x1802203d0
// Size: 32 bytes
// ============================================================
void fcn.1802203d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined4 *puVar4;
    undefined8 unaff_RBP;
    int64_t iVar5;
    undefined8 unaff_RDI;
    undefined8 *puVar6;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802203dc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802203e4;
    iVar3 = func_0x000180221280();
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        puVar4 = (undefined4 *)(iVar3 + 0x1c0);
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBP;
        iVar5 = 0x10;
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RDI;
        puVar6 = (undefined8 *)(iVar3 + 0xc0);
        *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_R14;
        do {
            if ((*(uint8_t *)puVar4 & 1) == 0) {
                *puVar6 = 0;
                puVar6[0x10] = 0;
                *puVar4 = 0;
            } else if ((undefined *)*puVar6 != (undefined *)0x0) {
                *(undefined *)*puVar6 = 0;
                *puVar4 = 1;
            }
            puVar4[-0x60] = 0;
            puVar4[-0x70] = 0;
            puVar4[-0x50] = 0;
            puVar4[0x30] = 0xffffffff;
            uVar1 = puVar6[0x28];
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022047d;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x5b);
            uVar1 = puVar6[0x40];
            puVar6[0x28] = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022049d;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x5d);
            puVar6[0x40] = 0;
            puVar4 = puVar4 + 1;
            puVar6 = puVar6 + 1;
            iVar5 = iVar5 + -1;
        } while (iVar5 != 0);
        *(undefined8 *)(iVar3 + 0x340) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1802203f0
// Address: 0x1802203f0
// Size: 225 bytes
// ============================================================
void fcn.1802203d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined4 *puVar4;
    undefined8 unaff_RBP;
    int64_t iVar5;
    undefined8 unaff_RDI;
    undefined8 *puVar6;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802203dc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802203e4;
    iVar3 = func_0x000180221280();
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        puVar4 = (undefined4 *)(iVar3 + 0x1c0);
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBP;
        iVar5 = 0x10;
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RDI;
        puVar6 = (undefined8 *)(iVar3 + 0xc0);
        *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_R14;
        do {
            if ((*(uint8_t *)puVar4 & 1) == 0) {
                *puVar6 = 0;
                puVar6[0x10] = 0;
                *puVar4 = 0;
            } else if ((undefined *)*puVar6 != (undefined *)0x0) {
                *(undefined *)*puVar6 = 0;
                *puVar4 = 1;
            }
            puVar4[-0x60] = 0;
            puVar4[-0x70] = 0;
            puVar4[-0x50] = 0;
            puVar4[0x30] = 0xffffffff;
            uVar1 = puVar6[0x28];
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022047d;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x5b);
            uVar1 = puVar6[0x40];
            puVar6[0x28] = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022049d;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x5d);
            puVar6[0x40] = 0;
            puVar4 = puVar4 + 1;
            puVar6 = puVar6 + 1;
            iVar5 = iVar5 + -1;
        } while (iVar5 != 0);
        *(undefined8 *)(iVar3 + 0x340) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1802204d1
// Address: 0x1802204d1
// Size: 6 bytes
// ============================================================
void fcn.1802203d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined4 *puVar4;
    undefined8 unaff_RBP;
    int64_t iVar5;
    undefined8 unaff_RDI;
    undefined8 *puVar6;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802203dc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802203e4;
    iVar3 = func_0x000180221280();
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        puVar4 = (undefined4 *)(iVar3 + 0x1c0);
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBP;
        iVar5 = 0x10;
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RDI;
        puVar6 = (undefined8 *)(iVar3 + 0xc0);
        *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_R14;
        do {
            if ((*(uint8_t *)puVar4 & 1) == 0) {
                *puVar6 = 0;
                puVar6[0x10] = 0;
                *puVar4 = 0;
            } else if ((undefined *)*puVar6 != (undefined *)0x0) {
                *(undefined *)*puVar6 = 0;
                *puVar4 = 1;
            }
            puVar4[-0x60] = 0;
            puVar4[-0x70] = 0;
            puVar4[-0x50] = 0;
            puVar4[0x30] = 0xffffffff;
            uVar1 = puVar6[0x28];
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022047d;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x5b);
            uVar1 = puVar6[0x40];
            puVar6[0x28] = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022049d;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x5d);
            puVar6[0x40] = 0;
            puVar4 = puVar4 + 1;
            puVar6 = puVar6 + 1;
            iVar5 = iVar5 + -1;
        } while (iVar5 != 0);
        *(undefined8 *)(iVar3 + 0x340) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1802204e0
// Address: 0x1802204e0
// Size: 59 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_220h because it doesn't fit into ProtoModel

int64_t fcn.1802204e0(undefined8 param_1, int64_t param_2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802204ec;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    iVar2 = 0x18077e330;
    if (param_2 != 0) {
        iVar2 = param_2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180220512;
    fcn.180221460(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000080 + iVar1), 
                  *(int64_t *)(&stack0x00000180 + iVar1), *(int64_t *)(&stack0x00000198 + iVar1), 
                  *(int64_t *)(&stack0x000001a0 + iVar1), *(int64_t *)(&stack0x000001a8 + iVar1), 
                  *(int64_t *)(&stack0x000001b0 + iVar1));
    return iVar2;
}

// ============================================================
// Function: FUN_180220520
// Address: 0x180220520
// Size: 35 bytes
// ============================================================
void fcn.180220520(uint32_t param_1, undefined8 param_2, int64_t param_3)
{
    uint64_t uVar1;
    uint8_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined *puVar8;
    undefined8 uVar9;
    uint32_t uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint32_t uVar11;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined *puVar12;
    undefined8 unaff_R13;
    uint32_t uVar13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar9 = 0x1805aadb1;
    if (param_3 == 0) {
        return;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar5 + 0x18) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar5 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar5 + 8) = unaff_R13;
    *(undefined8 *)((int64_t)auStackX_8 + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_8 + iVar5 + -8) = 0x180221479;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)(&stack0x000001b8 + iVar6 + iVar5) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_8 + iVar6 + iVar5;
    *(undefined8 *)(&stack0x000001e8 + iVar6 + iVar5) = unaff_RBX;
    *(undefined8 *)(&stack0x000001e0 + iVar6 + iVar5) = unaff_RSI;
    *(undefined8 *)(&stack0x000001d8 + iVar6 + iVar5) = unaff_R12;
    uVar11 = param_1 >> 0x17;
    *(undefined8 *)(&stack0x000001d0 + iVar6 + iVar5) = unaff_R14;
    *(undefined8 *)(&stack0x00000048 + iVar6 + iVar5) = uVar9;
    uVar13 = 2;
    if (-1 < (int32_t)param_1) {
        uVar13 = uVar11 & 0xff;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5 + -8) = 0x1802214e6;
    iVar3 = fcn.180222870(*(int64_t *)(&stack0x00000028 + iVar6 + iVar5));
    iVar4 = 0;
    if (iVar3 != 0) {
        iVar4 = *(int32_t *)0x18077e314;
    }
    if (iVar4 == 0) {
code_r0x000180221544:
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5 + -8) = 0x18022155d;
        func_0x000180245f70(&stack0x00000078 + iVar6 + iVar5, 0x40, 0x1804bf708, uVar13);
        puVar12 = &stack0x00000078 + iVar6 + iVar5;
    } else {
        uVar2 = (uint8_t)uVar11;
        if ((int32_t)param_1 < 0) {
            uVar2 = 2;
        }
        *(uint32_t *)(&stack0x00000060 + iVar6 + iVar5) = (uint32_t)uVar2 << 0x17;
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5 + -8) = 0x180221512;
        iVar4 = fcn.180222850(*(undefined8 *)0x18077e318);
        if (iVar4 == 0) goto code_r0x000180221544;
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5 + -8) = 0x180221527;
        iVar7 = fcn.180229240(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5 + -8) = 0x180221536;
        fcn.180222910(*(undefined8 *)0x18077e318);
        if ((iVar7 == 0) || (puVar12 = *(undefined **)(iVar7 + 8), puVar12 == (undefined *)0x0))
        goto code_r0x000180221544;
    }
    uVar10 = ((int32_t)param_1 >> 0x1f & 0x7f800000U) + 0x7fffff & param_1;
    if ((int32_t)param_1 < 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5 + -8) = 0x18022158e;
        iVar4 = func_0x000180223be0(uVar10, &stack0x000000b8 + iVar6 + iVar5, 0x100);
        puVar8 = &stack0x000000b8 + iVar6 + iVar5;
        if (iVar4 == 0) {
            puVar8 = (undefined *)0x0;
        }
        goto code_r0x000180221661;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5 + -8) = 0x1802215b9;
    iVar3 = fcn.180222870(*(int64_t *)(&stack0x00000028 + iVar6 + iVar5));
    puVar8 = (undefined *)0x0;
    iVar4 = 0;
    if (iVar3 != 0) {
        iVar4 = *(int32_t *)0x18077e314;
    }
    if (iVar4 == 0) goto code_r0x000180221661;
    *(uint32_t *)(&stack0x00000050 + iVar6 + iVar5) = (uVar11 & 0xff) << 0x17 | param_1 & 0x7fffff;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5 + -8) = 0x1802215f2;
    iVar4 = fcn.180222850(*(undefined8 *)0x18077e318);
    if (iVar4 == 0) {
code_r0x00018022161b:
        *(uint32_t *)(&stack0x00000050 + iVar6 + iVar5) = param_1 & 0x7fffff;
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5 + -8) = 0x18022162b;
        iVar4 = fcn.180222850();
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5 + -8) = 0x180221640;
            iVar7 = fcn.180229240(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5));
            *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5 + -8) = 0x18022164f;
            fcn.180222910();
            if (iVar7 != 0) goto code_r0x000180221654;
        }
        puVar8 = (undefined *)0x0;
    } else {
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5 + -8) = 0x180221607;
        iVar7 = fcn.180229240(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5 + -8) = 0x180221616;
        fcn.180222910(*(undefined8 *)0x18077e318);
        if (iVar7 == 0) goto code_r0x00018022161b;
code_r0x000180221654:
        puVar8 = *(undefined **)(iVar7 + 8);
    }
    uVar9 = *(undefined8 *)(&stack0x00000048 + iVar6 + iVar5);
code_r0x000180221661:
    if (puVar8 == (undefined *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5 + -8) = 0x180221691;
        func_0x000180245f70(&stack0x000000b8 + iVar6 + iVar5, 0x100, 0x1804bf718, uVar10 & 0xff83ffff);
        puVar8 = &stack0x000000b8 + iVar6 + iVar5;
    }
    *(undefined **)(&stack0x00000038 + iVar6 + iVar5) = puVar8;
    *(undefined8 *)(&stack0x00000030 + iVar6 + iVar5) = uVar9;
    *(undefined **)(&stack0x00000028 + iVar6 + iVar5) = puVar12;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5 + -8) = 0x1802216bd;
    func_0x000180245f70(param_2, param_3, 0x1804bf728, param_1);
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5 + -8) = 0x1802216c5;
    iVar7 = fcn.180498cd0(param_2);
    if (iVar7 == param_3 + -1) {
        *(uint32_t *)(&stack0x00000038 + iVar6 + iVar5) = uVar10;
        *(undefined8 *)(&stack0x00000030 + iVar6 + iVar5) = 0;
        *(uint32_t *)(&stack0x00000028 + iVar6 + iVar5) = uVar13;
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5 + -8) = 0x1802216fd;
        func_0x000180245f70(param_2, param_3, 0x1804bf740, param_1);
    }
    uVar1 = *(uint64_t *)(&stack0x000001b8 + iVar6 + iVar5);
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5 + -8) = 0x18022171d;
    func_0x000180459870(uVar1 ^ (int64_t)auStackX_8 + iVar6 + iVar5);
    return;
}

// ============================================================
// Function: FUN_180220550
// Address: 0x180220550
// Size: 250 bytes
// ============================================================
undefined4 fcn.180220550(int64_t arg_28h)
{
    undefined4 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    undefined8 unaff_RBX;
    int32_t iVar6;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022055c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220564;
    iVar3 = fcn.180221280(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    if (iVar3 != 0) {
        iVar4 = *(int32_t *)(iVar3 + 0x344);
        iVar6 = *(int32_t *)(iVar3 + 0x340);
        if (iVar4 != iVar6) {
            do {
                if ((*(uint8_t *)(iVar3 + (int64_t)iVar6 * 4) & 2) == 0) {
                    uVar5 = iVar4 + 1U & 0x8000000f;
                    if ((int32_t)uVar5 < 0) {
                        uVar5 = (uVar5 - 1 | 0xfffffff0) + 1;
                    }
                    if ((*(uint8_t *)(iVar3 + (int64_t)(int32_t)uVar5 * 4) & 2) == 0) break;
                    *(uint32_t *)(iVar3 + 0x344) = uVar5;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802205e6;
                    fcn.180220e60(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022059a;
                    fcn.180220e60(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
                    if (*(int32_t *)(iVar3 + 0x340) < 1) {
                        *(undefined4 *)(iVar3 + 0x340) = 0xf;
                    } else {
                        *(int32_t *)(iVar3 + 0x340) = *(int32_t *)(iVar3 + 0x340) + -1;
                    }
                }
                iVar4 = *(int32_t *)(iVar3 + 0x344);
                iVar6 = *(int32_t *)(iVar3 + 0x340);
            } while (iVar4 != iVar6);
            if (iVar4 != iVar6) {
                *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
                uVar5 = iVar4 + 1U & 0x8000000f;
                if ((int32_t)uVar5 < 0) {
                    uVar5 = (uVar5 - 1 | 0xfffffff0) + 1;
                }
                uVar1 = *(undefined4 *)(iVar3 + 0x80 + (int64_t)(int32_t)uVar5 * 4);
                *(uint32_t *)(iVar3 + 0x344) = uVar5;
                *(undefined4 *)(iVar3 + 0x80 + (int64_t)(int32_t)uVar5 * 4) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022063d;
                fcn.180220f00(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
                return uVar1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180220650
// Address: 0x180220650
// Size: 205 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 fcn.180220650(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t *in_RCX;
    undefined4 *in_RDX;
    int64_t iVar8;
    undefined8 unaff_RDI;
    int32_t iVar9;
    int64_t *in_R8;
    int64_t *in_R9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180220669;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022067d;
    iVar5 = fcn.180221280(*(int64_t *)((int64_t)&iStackX_8 + iVar4));
    if (iVar5 != 0) {
        iVar6 = *(int32_t *)(iVar5 + 0x344);
        iVar9 = *(int32_t *)(iVar5 + 0x340);
        if (iVar6 != iVar9) {
            do {
                if ((*(uint8_t *)(iVar5 + (int64_t)iVar9 * 4) & 2) == 0) {
                    uVar7 = iVar6 + 1U & 0x8000000f;
                    if ((int32_t)uVar7 < 0) {
                        uVar7 = (uVar7 - 1 | 0xfffffff0) + 1;
                    }
                    if ((*(uint8_t *)(iVar5 + (int64_t)(int32_t)uVar7 * 4) & 2) == 0) break;
                    *(uint32_t *)(iVar5 + 0x344) = uVar7;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180220700;
                    fcn.180220e60(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802206b4;
                    fcn.180220e60(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                    if (*(int32_t *)(iVar5 + 0x340) < 1) {
                        *(undefined4 *)(iVar5 + 0x340) = 0xf;
                    } else {
                        *(int32_t *)(iVar5 + 0x340) = *(int32_t *)(iVar5 + 0x340) + -1;
                    }
                }
                iVar6 = *(int32_t *)(iVar5 + 0x344);
                iVar9 = *(int32_t *)(iVar5 + 0x340);
            } while (iVar6 != iVar9);
            if (iVar6 != iVar9) {
                *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
                uVar7 = iVar6 + 1U & 0x8000000f;
                if ((int32_t)uVar7 < 0) {
                    uVar7 = (uVar7 - 1 | 0xfffffff0) + 1;
                }
                iVar8 = (int64_t)(int32_t)uVar7;
                uVar1 = *(undefined4 *)(iVar5 + 0x80 + iVar8 * 4);
                *(uint32_t *)(iVar5 + 0x344) = uVar7;
                *(undefined4 *)(iVar5 + 0x80 + iVar8 * 4) = 0;
                if ((in_RCX != (int64_t *)0x0) &&
                   (iVar2 = *(int64_t *)(iVar5 + 0x200 + iVar8 * 8), *in_RCX = iVar2, iVar2 == 0)) {
                    *in_RCX = 0x1805aadb1;
                }
                if (in_RDX != (undefined4 *)0x0) {
                    *in_RDX = *(undefined4 *)(iVar5 + 0x280 + iVar8 * 4);
                }
                if ((in_R8 != (int64_t *)0x0) &&
                   (iVar2 = *(int64_t *)(iVar5 + 0x2c0 + iVar8 * 8), *in_R8 = iVar2, iVar2 == 0)) {
                    *in_R8 = 0x1805aadb1;
                }
                puVar3 = *(undefined4 **)((int64_t)&arg_48h + iVar4);
                if (puVar3 != (undefined4 *)0x0) {
                    *puVar3 = *(undefined4 *)(iVar5 + 0x1c0 + iVar8 * 4);
                }
                if (in_R9 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802207b6;
                    fcn.180220f00(*(int64_t *)((int64_t)&iStackX_8 + iVar4));
                    return uVar1;
                }
                iVar4 = *(int64_t *)(iVar5 + 0xc0 + iVar8 * 8);
                *in_R9 = iVar4;
                if (iVar4 != 0) {
                    return uVar1;
                }
                *in_R9 = 0x1805aadb1;
                if (puVar3 == (undefined4 *)0x0) {
                    return uVar1;
                }
                *puVar3 = 0;
                return uVar1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022071d
// Address: 0x18022071d
// Size: 189 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 fcn.180220650(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t *in_RCX;
    undefined4 *in_RDX;
    int64_t iVar8;
    undefined8 unaff_RDI;
    int32_t iVar9;
    int64_t *in_R8;
    int64_t *in_R9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180220669;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022067d;
    iVar5 = fcn.180221280(*(int64_t *)((int64_t)&iStackX_8 + iVar4));
    if (iVar5 != 0) {
        iVar6 = *(int32_t *)(iVar5 + 0x344);
        iVar9 = *(int32_t *)(iVar5 + 0x340);
        if (iVar6 != iVar9) {
            do {
                if ((*(uint8_t *)(iVar5 + (int64_t)iVar9 * 4) & 2) == 0) {
                    uVar7 = iVar6 + 1U & 0x8000000f;
                    if ((int32_t)uVar7 < 0) {
                        uVar7 = (uVar7 - 1 | 0xfffffff0) + 1;
                    }
                    if ((*(uint8_t *)(iVar5 + (int64_t)(int32_t)uVar7 * 4) & 2) == 0) break;
                    *(uint32_t *)(iVar5 + 0x344) = uVar7;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180220700;
                    fcn.180220e60(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802206b4;
                    fcn.180220e60(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                    if (*(int32_t *)(iVar5 + 0x340) < 1) {
                        *(undefined4 *)(iVar5 + 0x340) = 0xf;
                    } else {
                        *(int32_t *)(iVar5 + 0x340) = *(int32_t *)(iVar5 + 0x340) + -1;
                    }
                }
                iVar6 = *(int32_t *)(iVar5 + 0x344);
                iVar9 = *(int32_t *)(iVar5 + 0x340);
            } while (iVar6 != iVar9);
            if (iVar6 != iVar9) {
                *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
                uVar7 = iVar6 + 1U & 0x8000000f;
                if ((int32_t)uVar7 < 0) {
                    uVar7 = (uVar7 - 1 | 0xfffffff0) + 1;
                }
                iVar8 = (int64_t)(int32_t)uVar7;
                uVar1 = *(undefined4 *)(iVar5 + 0x80 + iVar8 * 4);
                *(uint32_t *)(iVar5 + 0x344) = uVar7;
                *(undefined4 *)(iVar5 + 0x80 + iVar8 * 4) = 0;
                if ((in_RCX != (int64_t *)0x0) &&
                   (iVar2 = *(int64_t *)(iVar5 + 0x200 + iVar8 * 8), *in_RCX = iVar2, iVar2 == 0)) {
                    *in_RCX = 0x1805aadb1;
                }
                if (in_RDX != (undefined4 *)0x0) {
                    *in_RDX = *(undefined4 *)(iVar5 + 0x280 + iVar8 * 4);
                }
                if ((in_R8 != (int64_t *)0x0) &&
                   (iVar2 = *(int64_t *)(iVar5 + 0x2c0 + iVar8 * 8), *in_R8 = iVar2, iVar2 == 0)) {
                    *in_R8 = 0x1805aadb1;
                }
                puVar3 = *(undefined4 **)((int64_t)&arg_48h + iVar4);
                if (puVar3 != (undefined4 *)0x0) {
                    *puVar3 = *(undefined4 *)(iVar5 + 0x1c0 + iVar8 * 4);
                }
                if (in_R9 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802207b6;
                    fcn.180220f00(*(int64_t *)((int64_t)&iStackX_8 + iVar4));
                    return uVar1;
                }
                iVar4 = *(int64_t *)(iVar5 + 0xc0 + iVar8 * 8);
                *in_R9 = iVar4;
                if (iVar4 != 0) {
                    return uVar1;
                }
                *in_R9 = 0x1805aadb1;
                if (puVar3 == (undefined4 *)0x0) {
                    return uVar1;
                }
                *puVar3 = 0;
                return uVar1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802207da
// Address: 0x1802207da
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 fcn.180220650(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t *in_RCX;
    undefined4 *in_RDX;
    int64_t iVar8;
    undefined8 unaff_RDI;
    int32_t iVar9;
    int64_t *in_R8;
    int64_t *in_R9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180220669;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18022067d;
    iVar5 = fcn.180221280(*(int64_t *)((int64_t)&iStackX_8 + iVar4));
    if (iVar5 != 0) {
        iVar6 = *(int32_t *)(iVar5 + 0x344);
        iVar9 = *(int32_t *)(iVar5 + 0x340);
        if (iVar6 != iVar9) {
            do {
                if ((*(uint8_t *)(iVar5 + (int64_t)iVar9 * 4) & 2) == 0) {
                    uVar7 = iVar6 + 1U & 0x8000000f;
                    if ((int32_t)uVar7 < 0) {
                        uVar7 = (uVar7 - 1 | 0xfffffff0) + 1;
                    }
                    if ((*(uint8_t *)(iVar5 + (int64_t)(int32_t)uVar7 * 4) & 2) == 0) break;
                    *(uint32_t *)(iVar5 + 0x344) = uVar7;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180220700;
                    fcn.180220e60(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802206b4;
                    fcn.180220e60(*(int64_t *)((int64_t)&iStackX_8 + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                    if (*(int32_t *)(iVar5 + 0x340) < 1) {
                        *(undefined4 *)(iVar5 + 0x340) = 0xf;
                    } else {
                        *(int32_t *)(iVar5 + 0x340) = *(int32_t *)(iVar5 + 0x340) + -1;
                    }
                }
                iVar6 = *(int32_t *)(iVar5 + 0x344);
                iVar9 = *(int32_t *)(iVar5 + 0x340);
            } while (iVar6 != iVar9);
            if (iVar6 != iVar9) {
                *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
                uVar7 = iVar6 + 1U & 0x8000000f;
                if ((int32_t)uVar7 < 0) {
                    uVar7 = (uVar7 - 1 | 0xfffffff0) + 1;
                }
                iVar8 = (int64_t)(int32_t)uVar7;
                uVar1 = *(undefined4 *)(iVar5 + 0x80 + iVar8 * 4);
                *(uint32_t *)(iVar5 + 0x344) = uVar7;
                *(undefined4 *)(iVar5 + 0x80 + iVar8 * 4) = 0;
                if ((in_RCX != (int64_t *)0x0) &&
                   (iVar2 = *(int64_t *)(iVar5 + 0x200 + iVar8 * 8), *in_RCX = iVar2, iVar2 == 0)) {
                    *in_RCX = 0x1805aadb1;
                }
                if (in_RDX != (undefined4 *)0x0) {
                    *in_RDX = *(undefined4 *)(iVar5 + 0x280 + iVar8 * 4);
                }
                if ((in_R8 != (int64_t *)0x0) &&
                   (iVar2 = *(int64_t *)(iVar5 + 0x2c0 + iVar8 * 8), *in_R8 = iVar2, iVar2 == 0)) {
                    *in_R8 = 0x1805aadb1;
                }
                puVar3 = *(undefined4 **)((int64_t)&arg_48h + iVar4);
                if (puVar3 != (undefined4 *)0x0) {
                    *puVar3 = *(undefined4 *)(iVar5 + 0x1c0 + iVar8 * 4);
                }
                if (in_R9 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802207b6;
                    fcn.180220f00(*(int64_t *)((int64_t)&iStackX_8 + iVar4));
                    return uVar1;
                }
                iVar4 = *(int64_t *)(iVar5 + 0xc0 + iVar8 * 8);
                *in_R9 = iVar4;
                if (iVar4 != 0) {
                    return uVar1;
                }
                *in_R9 = 0x1805aadb1;
                if (puVar3 == (undefined4 *)0x0) {
                    return uVar1;
                }
                *puVar3 = 0;
                return uVar1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802207f0
// Address: 0x1802207f0
// Size: 63 bytes
// ============================================================
int32_t fcn.1802207f0(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802207fa;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180220810;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)&var_20h + iVar2));
    iVar3 = 0;
    if (iVar1 != 0) {
        iVar3 = *(int32_t *)0x18077e314;
    }
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022082b;
        iVar1 = fcn.180222950(*(undefined8 *)0x18077e318);
        iVar3 = *(int32_t *)0x1806a0010;
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_RBX;
            *(int32_t *)0x1806a0010 = *(int32_t *)0x1806a0010 + 1;
            *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022084f;
            fcn.180222910(*(undefined8 *)0x18077e318);
            return iVar3;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18022082f
// Address: 0x18022082f
// Size: 44 bytes
// ============================================================
int32_t fcn.1802207f0(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802207fa;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180220810;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)&var_20h + iVar2));
    iVar3 = 0;
    if (iVar1 != 0) {
        iVar3 = *(int32_t *)0x18077e314;
    }
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022082b;
        iVar1 = fcn.180222950(*(undefined8 *)0x18077e318);
        iVar3 = *(int32_t *)0x1806a0010;
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_RBX;
            *(int32_t *)0x1806a0010 = *(int32_t *)0x1806a0010 + 1;
            *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18022084f;
            fcn.180222910(*(undefined8 *)0x18077e318);
            return iVar3;
        }
    }
    return 0;
}

