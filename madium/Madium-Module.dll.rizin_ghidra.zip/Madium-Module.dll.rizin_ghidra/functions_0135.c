// Chunk 135 - 50 functions

// ============================================================
// Function: FUN_1801cf438
// Address: 0x1801cf438
// Size: 58 bytes
// ============================================================
void fcn.1801cf438(int64_t arg_70h)
{
    int64_t in_stack_00000020;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t in_stack_00000038;
    int64_t in_stack_00000040;
    int64_t in_stack_00000050;
    
    fcn.180229480(in_stack_00000020, in_stack_00000028);
    fcn.1802295a0(in_stack_00000020, in_stack_00000028, in_stack_00000030, in_stack_00000038, in_stack_00000050);
    fcn.18019b5e0(in_stack_00000040);
    fcn.180459870(arg_70h ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_1801cf480
// Address: 0x1801cf480
// Size: 760 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_368h because it doesn't fit into ProtoModel

void fcn.1801cf480(int64_t arg_108h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t uVar11;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    undefined8 uStack_40;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_40 = 0x1801cf49a;
    iVar7 = func_0x00018045a350();
    iVar7 = -iVar7;
    *(uint64_t *)(&stack0x00000308 + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar7);
    pcVar1 = *(code **)(in_RCX + 0x968);
    uVar8 = 0;
    uVar9 = uVar8;
    uVar10 = uVar8;
    if (pcVar1 == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf4d2;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf4ea;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                      *(int64_t *)((int64_t)&var_18h + iVar7));
        uVar11 = uVar8;
    } else {
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf507;
        func_0x0001804986e0((int64_t)&var_8h + iVar7, 0, 0x101);
        iVar2 = *(int64_t *)(in_RCX + 0x8f8);
        uVar3 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x200;
        *(int64_t *)(&stack0xffffffffffffffe8 + iVar7) = (int64_t)&arg_108h + iVar7;
        uVar4 = *(undefined8 *)(iVar2 + 0x2a0);
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf53c;
        uVar5 = (*pcVar1)(uVar3, uVar4, (int64_t)&var_8h + iVar7, 0x100);
        uVar11 = (uint64_t)uVar5;
        if (0x200 < uVar11) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf54c;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf564;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                          *(int64_t *)((int64_t)&var_18h + iVar7));
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf57a;
            fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar7));
            uVar11 = 0x200;
            goto code_r0x0001801cf6fc;
        }
        if (uVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf58d;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf5a5;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                          *(int64_t *)((int64_t)&var_18h + iVar7));
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf5bf;
            uVar8 = func_0x000180498cd0((int64_t)&var_8h + iVar7);
            if (uVar8 < 0x101) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf60f;
                uVar9 = func_0x000180223170((int64_t)&arg_108h + iVar7, uVar11, 0x1804b3b98, 0xc1e);
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf629;
                uVar10 = func_0x0001802231e0((int64_t)&var_8h + iVar7, 0x1804b3b98, 0xc1f);
                if ((uVar9 == 0) || (uVar10 == 0)) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf6ce;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), 
                                  *(int64_t *)((int64_t)&var_10h + iVar7));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf6e6;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), 
                                  *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                                  *(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7));
                    goto code_r0x0001801cf6f1;
                }
                uVar3 = *(undefined8 *)(in_RCX + 0x3c0);
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf657;
                func_0x000180224990(uVar3, 0x1804b3b98, 0xc25);
                *(uint64_t *)(in_RCX + 0x3c0) = uVar9;
                *(uint64_t *)(in_RCX + 0x3c8) = uVar11;
                uVar9 = 0;
                uVar3 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2a8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf688;
                func_0x000180224990(uVar3, 0x1804b3b98, 0xc29);
                *(uint64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2a8) = uVar10;
                uVar10 = 0;
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf6af;
                iVar6 = func_0x000180244bf0(in_RDX, (int64_t)&var_8h + iVar7, uVar8, 2);
                if (iVar6 != 0) goto code_r0x0001801cf6fc;
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf6b8;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            } else {
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf5cf;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            }
            uVar9 = 0;
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf5e7;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                          *(int64_t *)((int64_t)&var_18h + iVar7));
            uVar10 = uVar9;
        }
    }
code_r0x0001801cf6f1:
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf6fc;
    fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar7));
code_r0x0001801cf6fc:
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf70c;
    func_0x000180244fc0((int64_t)&arg_108h + iVar7, uVar11);
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf71b;
    func_0x000180244fc0((int64_t)&var_8h + iVar7, 0x101);
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf733;
    func_0x000180224b90(uVar9, uVar11, 0x1804b3b98, 0xc37);
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf74b;
    func_0x000180224b90(uVar10, uVar8, 0x1804b3b98, 0xc38);
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801cf75d;
    fcn.180459870(*(uint64_t *)(&stack0x00000308 + iVar7) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar7));
    return;
}

// ============================================================
// Function: FUN_1801cf780
// Address: 0x1801cf780
// Size: 130 bytes
// ============================================================
undefined8 fcn.1801cf780(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_28;
    
    uStack_28 = 0x1801cf791;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar3 = *(int64_t *)(in_RCX + 0x8f8);
    iVar5 = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar2) = 0;
    if ((*(int64_t *)(iVar3 + 0x2b8) == 0) && (*(int64_t *)(iVar3 + 0x2c0) == 0)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf7c7;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf7df;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf7f5;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf80c;
    iVar3 = fcn.1801b1140();
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf819;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf831;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf847;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf868;
    iVar1 = fcn.18022fc40(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2)
                          , *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2)
                          , *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf871;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf889;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf89f;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        return 0;
    }
    *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + -8) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf8cd;
    puVar4 = (undefined *)
             fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2)
                          );
    if (puVar4 == (undefined *)0x0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf8da;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf8f2;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf908;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        return 0;
    }
    *puVar4 = (char)((uint32_t)*(undefined4 *)(in_RCX + 0x9cc) >> 8);
    puVar4[1] = *(undefined *)(in_RCX + 0x9cc);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf937;
    iVar1 = fcn.18021b9c0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2), 
                          *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2));
    if (iVar1 < 1) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf940;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf958;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
    } else if (*(int32_t *)(in_RCX + 0x48) < 0x301) {
code_r0x0001801cf9a5:
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf9b7;
        iVar5 = fcn.180259210(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf9cb;
            iVar1 = fcn.180265330(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2)
                                  , *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000068 + iVar2), 
                                  *(int64_t *)(&stack0x00000070 + iVar2), *(int64_t *)(&stack0x00000078 + iVar2));
            if (0 < iVar1) {
                *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + -0x18) = 0x30;
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf9ee;
                iVar1 = fcn.180265070(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)(&stack0x00000030 + iVar2));
                if (0 < iVar1) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa08;
                    iVar1 = fcn.180243f60(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                          *(int64_t *)(&stack0x00000030 + iVar2));
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + -0x18) = 0x30;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa2e;
                        iVar1 = fcn.180265070(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                              *(int64_t *)(&stack0x00000030 + iVar2));
                        if (0 < iVar1) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa3a;
                            fcn.180258be0(iVar5);
                            iVar5 = 0;
                            if (0x300 < *(int32_t *)(in_RCX + 0x48)) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa4d;
                                iVar1 = fcn.180244000(*(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                                      *(int64_t *)(&stack0x00000028 + iVar2), 
                                                      *(int64_t *)(&stack0x00000030 + iVar2), 
                                                      *(int64_t *)(&stack0x00000038 + iVar2), 
                                                      *(int64_t *)((int64_t)&arg_40h + iVar2));
                                if (iVar1 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa56;
                                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2));
                                    goto code_r0x0001801cf987;
                                }
                            }
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + -0x18) = 0x30;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa7e;
                            iVar1 = fcn.180197af0(*(int64_t *)(&stack0x00000030 + iVar2));
                            if (iVar1 != 0) {
                                *(undefined **)(in_RCX + 0x3b0) = puVar4;
                                *(undefined8 *)(in_RCX + 0x3b8) = 0x30;
                                return 1;
                            }
                            goto code_r0x0001801cfaf3;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfaa0;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfab8;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2));
                    goto code_r0x0001801cfae3;
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfac5;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfadd;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf979;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        if (iVar1 != 0) goto code_r0x0001801cf9a5;
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf982;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
code_r0x0001801cf987:
        iVar5 = 0;
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf99a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
    }
code_r0x0001801cfae3:
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfaf3;
    fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
code_r0x0001801cfaf3:
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfb0d;
    fcn.180224b90(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfb15;
    fcn.180258be0(iVar5);
    return 0;
}

// ============================================================
// Function: FUN_1801cf802
// Address: 0x1801cf802
// Size: 87 bytes
// ============================================================
undefined8 fcn.1801cf780(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_28;
    
    uStack_28 = 0x1801cf791;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar3 = *(int64_t *)(in_RCX + 0x8f8);
    iVar5 = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar2) = 0;
    if ((*(int64_t *)(iVar3 + 0x2b8) == 0) && (*(int64_t *)(iVar3 + 0x2c0) == 0)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf7c7;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf7df;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf7f5;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf80c;
    iVar3 = fcn.1801b1140();
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf819;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf831;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf847;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf868;
    iVar1 = fcn.18022fc40(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2)
                          , *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2)
                          , *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf871;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf889;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf89f;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        return 0;
    }
    *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + -8) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf8cd;
    puVar4 = (undefined *)
             fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2)
                          );
    if (puVar4 == (undefined *)0x0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf8da;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf8f2;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf908;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        return 0;
    }
    *puVar4 = (char)((uint32_t)*(undefined4 *)(in_RCX + 0x9cc) >> 8);
    puVar4[1] = *(undefined *)(in_RCX + 0x9cc);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf937;
    iVar1 = fcn.18021b9c0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2), 
                          *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2));
    if (iVar1 < 1) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf940;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf958;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
    } else if (*(int32_t *)(in_RCX + 0x48) < 0x301) {
code_r0x0001801cf9a5:
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf9b7;
        iVar5 = fcn.180259210(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf9cb;
            iVar1 = fcn.180265330(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2)
                                  , *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000068 + iVar2), 
                                  *(int64_t *)(&stack0x00000070 + iVar2), *(int64_t *)(&stack0x00000078 + iVar2));
            if (0 < iVar1) {
                *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + -0x18) = 0x30;
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf9ee;
                iVar1 = fcn.180265070(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)(&stack0x00000030 + iVar2));
                if (0 < iVar1) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa08;
                    iVar1 = fcn.180243f60(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                          *(int64_t *)(&stack0x00000030 + iVar2));
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + -0x18) = 0x30;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa2e;
                        iVar1 = fcn.180265070(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                              *(int64_t *)(&stack0x00000030 + iVar2));
                        if (0 < iVar1) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa3a;
                            fcn.180258be0(iVar5);
                            iVar5 = 0;
                            if (0x300 < *(int32_t *)(in_RCX + 0x48)) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa4d;
                                iVar1 = fcn.180244000(*(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                                      *(int64_t *)(&stack0x00000028 + iVar2), 
                                                      *(int64_t *)(&stack0x00000030 + iVar2), 
                                                      *(int64_t *)(&stack0x00000038 + iVar2), 
                                                      *(int64_t *)((int64_t)&arg_40h + iVar2));
                                if (iVar1 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa56;
                                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2));
                                    goto code_r0x0001801cf987;
                                }
                            }
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + -0x18) = 0x30;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa7e;
                            iVar1 = fcn.180197af0(*(int64_t *)(&stack0x00000030 + iVar2));
                            if (iVar1 != 0) {
                                *(undefined **)(in_RCX + 0x3b0) = puVar4;
                                *(undefined8 *)(in_RCX + 0x3b8) = 0x30;
                                return 1;
                            }
                            goto code_r0x0001801cfaf3;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfaa0;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfab8;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2));
                    goto code_r0x0001801cfae3;
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfac5;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfadd;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf979;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        if (iVar1 != 0) goto code_r0x0001801cf9a5;
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf982;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
code_r0x0001801cf987:
        iVar5 = 0;
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf99a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
    }
code_r0x0001801cfae3:
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfaf3;
    fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
code_r0x0001801cfaf3:
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfb0d;
    fcn.180224b90(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfb15;
    fcn.180258be0(iVar5);
    return 0;
}

// ============================================================
// Function: FUN_1801cf859
// Address: 0x1801cf859
// Size: 88 bytes
// ============================================================
undefined8 fcn.1801cf780(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_28;
    
    uStack_28 = 0x1801cf791;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar3 = *(int64_t *)(in_RCX + 0x8f8);
    iVar5 = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar2) = 0;
    if ((*(int64_t *)(iVar3 + 0x2b8) == 0) && (*(int64_t *)(iVar3 + 0x2c0) == 0)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf7c7;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf7df;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf7f5;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf80c;
    iVar3 = fcn.1801b1140();
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf819;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf831;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf847;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf868;
    iVar1 = fcn.18022fc40(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2)
                          , *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2)
                          , *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf871;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf889;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf89f;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        return 0;
    }
    *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + -8) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf8cd;
    puVar4 = (undefined *)
             fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2)
                          );
    if (puVar4 == (undefined *)0x0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf8da;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf8f2;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf908;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        return 0;
    }
    *puVar4 = (char)((uint32_t)*(undefined4 *)(in_RCX + 0x9cc) >> 8);
    puVar4[1] = *(undefined *)(in_RCX + 0x9cc);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf937;
    iVar1 = fcn.18021b9c0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2), 
                          *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2));
    if (iVar1 < 1) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf940;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf958;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
    } else if (*(int32_t *)(in_RCX + 0x48) < 0x301) {
code_r0x0001801cf9a5:
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf9b7;
        iVar5 = fcn.180259210(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf9cb;
            iVar1 = fcn.180265330(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2)
                                  , *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000068 + iVar2), 
                                  *(int64_t *)(&stack0x00000070 + iVar2), *(int64_t *)(&stack0x00000078 + iVar2));
            if (0 < iVar1) {
                *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + -0x18) = 0x30;
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf9ee;
                iVar1 = fcn.180265070(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)(&stack0x00000030 + iVar2));
                if (0 < iVar1) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa08;
                    iVar1 = fcn.180243f60(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                          *(int64_t *)(&stack0x00000030 + iVar2));
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + -0x18) = 0x30;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa2e;
                        iVar1 = fcn.180265070(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                              *(int64_t *)(&stack0x00000030 + iVar2));
                        if (0 < iVar1) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa3a;
                            fcn.180258be0(iVar5);
                            iVar5 = 0;
                            if (0x300 < *(int32_t *)(in_RCX + 0x48)) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa4d;
                                iVar1 = fcn.180244000(*(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                                      *(int64_t *)(&stack0x00000028 + iVar2), 
                                                      *(int64_t *)(&stack0x00000030 + iVar2), 
                                                      *(int64_t *)(&stack0x00000038 + iVar2), 
                                                      *(int64_t *)((int64_t)&arg_40h + iVar2));
                                if (iVar1 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa56;
                                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2));
                                    goto code_r0x0001801cf987;
                                }
                            }
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + -0x18) = 0x30;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa7e;
                            iVar1 = fcn.180197af0(*(int64_t *)(&stack0x00000030 + iVar2));
                            if (iVar1 != 0) {
                                *(undefined **)(in_RCX + 0x3b0) = puVar4;
                                *(undefined8 *)(in_RCX + 0x3b8) = 0x30;
                                return 1;
                            }
                            goto code_r0x0001801cfaf3;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfaa0;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfab8;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2));
                    goto code_r0x0001801cfae3;
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfac5;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfadd;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf979;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        if (iVar1 != 0) goto code_r0x0001801cf9a5;
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf982;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
code_r0x0001801cf987:
        iVar5 = 0;
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf99a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
    }
code_r0x0001801cfae3:
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfaf3;
    fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
code_r0x0001801cfaf3:
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfb0d;
    fcn.180224b90(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfb15;
    fcn.180258be0(iVar5);
    return 0;
}

// ============================================================
// Function: FUN_1801cf8b1
// Address: 0x1801cf8b1
// Size: 635 bytes
// ============================================================
undefined8 fcn.1801cf780(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_28;
    
    uStack_28 = 0x1801cf791;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar3 = *(int64_t *)(in_RCX + 0x8f8);
    iVar5 = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar2) = 0;
    if ((*(int64_t *)(iVar3 + 0x2b8) == 0) && (*(int64_t *)(iVar3 + 0x2c0) == 0)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf7c7;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf7df;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf7f5;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf80c;
    iVar3 = fcn.1801b1140();
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf819;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf831;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf847;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf868;
    iVar1 = fcn.18022fc40(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2)
                          , *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2)
                          , *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf871;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf889;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf89f;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        return 0;
    }
    *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + -8) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf8cd;
    puVar4 = (undefined *)
             fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2)
                          );
    if (puVar4 == (undefined *)0x0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf8da;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf8f2;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf908;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        return 0;
    }
    *puVar4 = (char)((uint32_t)*(undefined4 *)(in_RCX + 0x9cc) >> 8);
    puVar4[1] = *(undefined *)(in_RCX + 0x9cc);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf937;
    iVar1 = fcn.18021b9c0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2), 
                          *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2));
    if (iVar1 < 1) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf940;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf958;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
    } else if (*(int32_t *)(in_RCX + 0x48) < 0x301) {
code_r0x0001801cf9a5:
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf9b7;
        iVar5 = fcn.180259210(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf9cb;
            iVar1 = fcn.180265330(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2)
                                  , *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000068 + iVar2), 
                                  *(int64_t *)(&stack0x00000070 + iVar2), *(int64_t *)(&stack0x00000078 + iVar2));
            if (0 < iVar1) {
                *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + -0x18) = 0x30;
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf9ee;
                iVar1 = fcn.180265070(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                      *(int64_t *)(&stack0x00000030 + iVar2));
                if (0 < iVar1) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa08;
                    iVar1 = fcn.180243f60(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                          *(int64_t *)(&stack0x00000030 + iVar2));
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + -0x18) = 0x30;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa2e;
                        iVar1 = fcn.180265070(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                              *(int64_t *)(&stack0x00000030 + iVar2));
                        if (0 < iVar1) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa3a;
                            fcn.180258be0(iVar5);
                            iVar5 = 0;
                            if (0x300 < *(int32_t *)(in_RCX + 0x48)) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa4d;
                                iVar1 = fcn.180244000(*(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                                      *(int64_t *)(&stack0x00000028 + iVar2), 
                                                      *(int64_t *)(&stack0x00000030 + iVar2), 
                                                      *(int64_t *)(&stack0x00000038 + iVar2), 
                                                      *(int64_t *)((int64_t)&arg_40h + iVar2));
                                if (iVar1 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa56;
                                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2));
                                    goto code_r0x0001801cf987;
                                }
                            }
                            *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + -0x18) = 0x30;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfa7e;
                            iVar1 = fcn.180197af0(*(int64_t *)(&stack0x00000030 + iVar2));
                            if (iVar1 != 0) {
                                *(undefined **)(in_RCX + 0x3b0) = puVar4;
                                *(undefined8 *)(in_RCX + 0x3b8) = 0x30;
                                return 1;
                            }
                            goto code_r0x0001801cfaf3;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfaa0;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfab8;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2));
                    goto code_r0x0001801cfae3;
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfac5;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfadd;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf979;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), 
                              *(int64_t *)((int64_t)&iStackX_8 + iVar2));
        if (iVar1 != 0) goto code_r0x0001801cf9a5;
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf982;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
code_r0x0001801cf987:
        iVar5 = 0;
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cf99a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar2 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
    }
code_r0x0001801cfae3:
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfaf3;
    fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
code_r0x0001801cfaf3:
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfb0d;
    fcn.180224b90(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + -0x18), *(int64_t *)((int64_t)&iStackX_8 + iVar2));
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801cfb15;
    fcn.180258be0(iVar5);
    return 0;
}

// ============================================================
// Function: FUN_1801cfb30
// Address: 0x1801cfb30
// Size: 626 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801cfb30(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801cfb45;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar3 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar3)) && (iVar3 != 0x10000)) {
        if (*(int64_t *)(in_RCX + 0xbb0) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cfb97;
            iVar3 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cfba4;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cfbbc;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cfbd2;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                return 0;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cfbf6;
            iVar3 = fcn.180244bf0(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)(&stack0x00000048 + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cfbff;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cfc17;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cfc2d;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                return 0;
            }
        }
    }
    if (*(char *)(in_RCX + 0xb50) == '\0') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cfcc7;
        iVar3 = fcn.1801aecb0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar4));
    } else {
        if (*(char *)(in_RCX + 0xb50) != '\x02') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cfc66;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cfc7e;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cfc94;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cfcb4;
        iVar3 = fcn.1801b1180(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                              *(int64_t *)(&stack0x00000038 + iVar4));
    }
    if (iVar3 == 0) {
        return 0;
    }
    iVar1 = *(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36);
    if ((((((*(uint8_t *)(iVar1 + 0x50) & 8) == 0) && (iVar3 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar3)) &&
         ((iVar3 != 0x10000 && ((*(uint32_t *)(in_RCX + 0x160) & 0x2000) == 0)))) &&
        ((*(int64_t *)(in_RCX + 0x260) == 0 || (*(int64_t *)(in_RCX + 0x2e8) == 0)))) &&
       ((*(int32_t *)(in_RCX + 0xf0) != 0 || ((*(uint32_t *)(in_RCX + 0x9a8) >> 0x14 & 1) != 0)))) {
        pcVar2 = *(code **)(iVar1 + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cfd44;
        iVar3 = (*pcVar2)(in_RCX, 0x92);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cfd4d;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cfd65;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801cfd7b;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801cfdb0
// Address: 0x1801cfdb0
// Size: 110 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.1801cfdb0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined4 uVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t *piVar10;
    uint32_t uVar11;
    int64_t iVar12;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    uint64_t uVar13;
    
    uStack_20 = 0x1801cfdc8;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    puVar2 = *(undefined4 **)(in_RCX + 0x8f8);
    iVar3 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfde1;
    iVar5 = func_0x0001801afc80();
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfdec;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfe04;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfe17;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar7));
        return false;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_R14;
    if (puVar2 == (undefined4 *)0x0) {
code_r0x0001801cfe45:
        if (*(int32_t *)(in_RCX + 0x8c8) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfe58;
            iVar5 = func_0x00018019d4c0(in_RCX, 0);
            if (iVar5 == 0) {
                return false;
            }
        }
    } else {
        uVar1 = *puVar2;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfe35;
        iVar5 = func_0x0001801afde0(in_RCX, uVar1, 0);
        if (iVar5 == 0) goto code_r0x0001801cfe45;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfe41;
        iVar5 = func_0x00018019cb20(puVar2);
        if (iVar5 == 0) goto code_r0x0001801cfe45;
    }
    uVar13 = 0;
    iVar12 = 0x20;
    uVar8 = uVar13;
    if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
        if (*(int32_t *)(in_RCX + 0x8c8) == 0) goto code_r0x0001801cfe9d;
    } else {
        do {
            if (*(char *)(uVar8 + 0x184 + in_RCX) != '\0') goto code_r0x0001801cfec9;
            uVar8 = uVar8 + 1;
        } while (uVar8 < 0x20);
code_r0x0001801cfe9d:
        *(undefined4 *)((int64_t)&var_8h + iVar7) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfeb6;
        iVar5 = func_0x0001801c6280(in_RCX, 0, in_RCX + 0x184, 0x20);
        if (iVar5 < 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfebf;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            goto code_r0x0001801d017b;
        }
    }
code_r0x0001801cfec9:
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfede;
    iVar5 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&arg_48h + iVar7));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfef8;
        iVar5 = func_0x0001802445f0(in_RDX, in_RCX + 0x184, 0x20);
        if (iVar5 != 0) {
            piVar4 = *(int32_t **)(in_RCX + 0x8f8);
            piVar10 = piVar4 + 0x96;
            if ((*(int32_t *)(in_RCX + 0x7c) == 0) && (*piVar4 != 0x304)) {
                iVar12 = *(int64_t *)(piVar4 + 0x94);
                if (*(int32_t *)(in_RCX + 0x48) == 0x304) {
                    *(int64_t *)(in_RCX + 0x940) = iVar12;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cff45;
                    fcn.180498030(in_RCX + 0x920, piVar10, iVar12);
                }
            } else if ((*(int32_t *)(in_RCX + 0x48) == 0x304) && ((*(uint32_t *)(in_RCX + 0x9a8) >> 0x14 & 1) != 0)) {
                piVar10 = (int32_t *)(in_RCX + 0x920);
                *(undefined8 *)(in_RCX + 0x940) = 0x20;
                if (*(int32_t *)(in_RCX + 0x8c8) == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cff85;
                    iVar5 = fcn.18021b9c0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)(&stack0x00000028 + iVar7)
                                          , *(int64_t *)(&stack0x00000030 + iVar7), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7));
                    if (iVar5 < 1) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cff8e;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                        goto code_r0x0001801d017b;
                    }
                }
            } else {
                iVar12 = 0;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cffa8;
            iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            if (iVar5 != 0) {
                if (iVar12 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cffc3;
                    iVar5 = func_0x0001802445f0(in_RDX, piVar10, iVar12);
                    if (iVar5 == 0) goto code_r0x0001801d0165;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cffd3;
                iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)(&stack0x00000028 + iVar7)
                                      , *(int64_t *)(&stack0x00000030 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7)
                                      , *(int64_t *)((int64_t)&arg_40h + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7)
                                     );
                if (iVar5 != 0) {
                    if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
code_r0x0001801d0024:
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0031;
                        iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                              *(int64_t *)((int64_t)&var_10h + iVar7));
                        if (iVar5 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d003a;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                          *(int64_t *)((int64_t)&var_10h + iVar7));
                        } else {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d004c;
                            uVar9 = func_0x000180193a50(in_RCX);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d005a;
                            iVar5 = func_0x0001801ce7b0(in_RCX, uVar9, in_RDX);
                            if (iVar5 == 0) {
                                return false;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d006a;
                            iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                                  *(int64_t *)(&stack0x00000028 + iVar7), 
                                                  *(int64_t *)(&stack0x00000030 + iVar7), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar7), 
                                                  *(int64_t *)((int64_t)&arg_40h + iVar7), 
                                                  *(int64_t *)((int64_t)&arg_48h + iVar7));
                            if (iVar5 == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0073;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                              *(int64_t *)((int64_t)&var_10h + iVar7));
                            } else {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d008a;
                                iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar7));
                                if (iVar5 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0093;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar7));
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d00a5;
                                    iVar5 = func_0x0001801af1c0(in_RCX);
                                    if (((iVar5 != 0) && (*(int64_t *)(iVar3 + 0x118) != 0)) &&
                                       (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) !=
                                         0 || (*(int32_t *)(in_RCX + 0x41c) < 0x304)))) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d00d7;
                                        iVar5 = fcn.180222010();
                                        if (0 < iVar5) {
                                            do {
                                                uVar9 = *(undefined8 *)(iVar3 + 0x118);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d00ee;
                                                func_0x000180222340(uVar9, uVar13);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d00ff;
                                                iVar6 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                                                      *(int64_t *)((int64_t)&var_10h + iVar7), 
                                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                                                if (iVar6 == 0) {
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0152;
                                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar7));
                                                    goto code_r0x0001801d017b;
                                                }
                                                uVar11 = (int32_t)uVar13 + 1;
                                                uVar13 = (uint64_t)uVar11;
                                            } while ((int32_t)uVar11 < iVar5);
                                        }
                                    }
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0119;
                                    iVar5 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                                          *(int64_t *)((int64_t)&var_10h + iVar7), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                                          *(int64_t *)((int64_t)&arg_48h + iVar7));
                                    if (iVar5 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0125;
                                        iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                                              *(int64_t *)(&stack0x00000028 + iVar7), 
                                                              *(int64_t *)(&stack0x00000030 + iVar7), 
                                                              *(int64_t *)((int64_t)&arg_38h + iVar7), 
                                                              *(int64_t *)((int64_t)&arg_40h + iVar7), 
                                                              *(int64_t *)((int64_t)&arg_48h + iVar7));
                                        if (iVar5 != 0) {
                                            *(undefined8 *)((int64_t)&var_8h + iVar7) = 0;
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0142;
                                            iVar5 = func_0x0001801c9910(in_RCX, in_RDX, 0x80, 0);
                                            return iVar5 != 0;
                                        }
                                    }
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d015e;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar7));
                                }
                            }
                        }
                    } else {
                        if (*(uint64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x100) < 0x100) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0011;
                            iVar5 = fcn.180244bf0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
                            if (iVar5 != 0) goto code_r0x0001801d0024;
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d001a;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                    }
                    goto code_r0x0001801d017b;
                }
            }
code_r0x0001801d0165:
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d016a;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            goto code_r0x0001801d017b;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0176;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
code_r0x0001801d017b:
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d018e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                  *(int64_t *)((int64_t)&arg_38h + iVar7));
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d01a4;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar7));
    return false;
}

// ============================================================
// Function: FUN_1801cfe1e
// Address: 0x1801cfe1e
// Size: 909 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.1801cfdb0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined4 uVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t *piVar10;
    uint32_t uVar11;
    int64_t iVar12;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    uint64_t uVar13;
    
    uStack_20 = 0x1801cfdc8;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    puVar2 = *(undefined4 **)(in_RCX + 0x8f8);
    iVar3 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfde1;
    iVar5 = func_0x0001801afc80();
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfdec;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfe04;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfe17;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar7));
        return false;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_R14;
    if (puVar2 == (undefined4 *)0x0) {
code_r0x0001801cfe45:
        if (*(int32_t *)(in_RCX + 0x8c8) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfe58;
            iVar5 = func_0x00018019d4c0(in_RCX, 0);
            if (iVar5 == 0) {
                return false;
            }
        }
    } else {
        uVar1 = *puVar2;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfe35;
        iVar5 = func_0x0001801afde0(in_RCX, uVar1, 0);
        if (iVar5 == 0) goto code_r0x0001801cfe45;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfe41;
        iVar5 = func_0x00018019cb20(puVar2);
        if (iVar5 == 0) goto code_r0x0001801cfe45;
    }
    uVar13 = 0;
    iVar12 = 0x20;
    uVar8 = uVar13;
    if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
        if (*(int32_t *)(in_RCX + 0x8c8) == 0) goto code_r0x0001801cfe9d;
    } else {
        do {
            if (*(char *)(uVar8 + 0x184 + in_RCX) != '\0') goto code_r0x0001801cfec9;
            uVar8 = uVar8 + 1;
        } while (uVar8 < 0x20);
code_r0x0001801cfe9d:
        *(undefined4 *)((int64_t)&var_8h + iVar7) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfeb6;
        iVar5 = func_0x0001801c6280(in_RCX, 0, in_RCX + 0x184, 0x20);
        if (iVar5 < 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfebf;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            goto code_r0x0001801d017b;
        }
    }
code_r0x0001801cfec9:
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfede;
    iVar5 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&arg_48h + iVar7));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfef8;
        iVar5 = func_0x0001802445f0(in_RDX, in_RCX + 0x184, 0x20);
        if (iVar5 != 0) {
            piVar4 = *(int32_t **)(in_RCX + 0x8f8);
            piVar10 = piVar4 + 0x96;
            if ((*(int32_t *)(in_RCX + 0x7c) == 0) && (*piVar4 != 0x304)) {
                iVar12 = *(int64_t *)(piVar4 + 0x94);
                if (*(int32_t *)(in_RCX + 0x48) == 0x304) {
                    *(int64_t *)(in_RCX + 0x940) = iVar12;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cff45;
                    fcn.180498030(in_RCX + 0x920, piVar10, iVar12);
                }
            } else if ((*(int32_t *)(in_RCX + 0x48) == 0x304) && ((*(uint32_t *)(in_RCX + 0x9a8) >> 0x14 & 1) != 0)) {
                piVar10 = (int32_t *)(in_RCX + 0x920);
                *(undefined8 *)(in_RCX + 0x940) = 0x20;
                if (*(int32_t *)(in_RCX + 0x8c8) == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cff85;
                    iVar5 = fcn.18021b9c0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)(&stack0x00000028 + iVar7)
                                          , *(int64_t *)(&stack0x00000030 + iVar7), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7));
                    if (iVar5 < 1) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cff8e;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                        goto code_r0x0001801d017b;
                    }
                }
            } else {
                iVar12 = 0;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cffa8;
            iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            if (iVar5 != 0) {
                if (iVar12 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cffc3;
                    iVar5 = func_0x0001802445f0(in_RDX, piVar10, iVar12);
                    if (iVar5 == 0) goto code_r0x0001801d0165;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cffd3;
                iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)(&stack0x00000028 + iVar7)
                                      , *(int64_t *)(&stack0x00000030 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7)
                                      , *(int64_t *)((int64_t)&arg_40h + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7)
                                     );
                if (iVar5 != 0) {
                    if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
code_r0x0001801d0024:
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0031;
                        iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                              *(int64_t *)((int64_t)&var_10h + iVar7));
                        if (iVar5 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d003a;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                          *(int64_t *)((int64_t)&var_10h + iVar7));
                        } else {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d004c;
                            uVar9 = func_0x000180193a50(in_RCX);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d005a;
                            iVar5 = func_0x0001801ce7b0(in_RCX, uVar9, in_RDX);
                            if (iVar5 == 0) {
                                return false;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d006a;
                            iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                                  *(int64_t *)(&stack0x00000028 + iVar7), 
                                                  *(int64_t *)(&stack0x00000030 + iVar7), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar7), 
                                                  *(int64_t *)((int64_t)&arg_40h + iVar7), 
                                                  *(int64_t *)((int64_t)&arg_48h + iVar7));
                            if (iVar5 == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0073;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                              *(int64_t *)((int64_t)&var_10h + iVar7));
                            } else {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d008a;
                                iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar7));
                                if (iVar5 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0093;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar7));
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d00a5;
                                    iVar5 = func_0x0001801af1c0(in_RCX);
                                    if (((iVar5 != 0) && (*(int64_t *)(iVar3 + 0x118) != 0)) &&
                                       (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) !=
                                         0 || (*(int32_t *)(in_RCX + 0x41c) < 0x304)))) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d00d7;
                                        iVar5 = fcn.180222010();
                                        if (0 < iVar5) {
                                            do {
                                                uVar9 = *(undefined8 *)(iVar3 + 0x118);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d00ee;
                                                func_0x000180222340(uVar9, uVar13);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d00ff;
                                                iVar6 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                                                      *(int64_t *)((int64_t)&var_10h + iVar7), 
                                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                                                if (iVar6 == 0) {
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0152;
                                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar7));
                                                    goto code_r0x0001801d017b;
                                                }
                                                uVar11 = (int32_t)uVar13 + 1;
                                                uVar13 = (uint64_t)uVar11;
                                            } while ((int32_t)uVar11 < iVar5);
                                        }
                                    }
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0119;
                                    iVar5 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                                          *(int64_t *)((int64_t)&var_10h + iVar7), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                                          *(int64_t *)((int64_t)&arg_48h + iVar7));
                                    if (iVar5 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0125;
                                        iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                                              *(int64_t *)(&stack0x00000028 + iVar7), 
                                                              *(int64_t *)(&stack0x00000030 + iVar7), 
                                                              *(int64_t *)((int64_t)&arg_38h + iVar7), 
                                                              *(int64_t *)((int64_t)&arg_40h + iVar7), 
                                                              *(int64_t *)((int64_t)&arg_48h + iVar7));
                                        if (iVar5 != 0) {
                                            *(undefined8 *)((int64_t)&var_8h + iVar7) = 0;
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0142;
                                            iVar5 = func_0x0001801c9910(in_RCX, in_RDX, 0x80, 0);
                                            return iVar5 != 0;
                                        }
                                    }
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d015e;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar7));
                                }
                            }
                        }
                    } else {
                        if (*(uint64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x100) < 0x100) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0011;
                            iVar5 = fcn.180244bf0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
                            if (iVar5 != 0) goto code_r0x0001801d0024;
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d001a;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                    }
                    goto code_r0x0001801d017b;
                }
            }
code_r0x0001801d0165:
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d016a;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            goto code_r0x0001801d017b;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0176;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
code_r0x0001801d017b:
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d018e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                  *(int64_t *)((int64_t)&arg_38h + iVar7));
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d01a4;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar7));
    return false;
}

// ============================================================
// Function: FUN_1801d01ab
// Address: 0x1801d01ab
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.1801cfdb0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined4 uVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t *piVar10;
    uint32_t uVar11;
    int64_t iVar12;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    uint64_t uVar13;
    
    uStack_20 = 0x1801cfdc8;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    puVar2 = *(undefined4 **)(in_RCX + 0x8f8);
    iVar3 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfde1;
    iVar5 = func_0x0001801afc80();
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfdec;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfe04;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfe17;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar7));
        return false;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_R14;
    if (puVar2 == (undefined4 *)0x0) {
code_r0x0001801cfe45:
        if (*(int32_t *)(in_RCX + 0x8c8) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfe58;
            iVar5 = func_0x00018019d4c0(in_RCX, 0);
            if (iVar5 == 0) {
                return false;
            }
        }
    } else {
        uVar1 = *puVar2;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfe35;
        iVar5 = func_0x0001801afde0(in_RCX, uVar1, 0);
        if (iVar5 == 0) goto code_r0x0001801cfe45;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfe41;
        iVar5 = func_0x00018019cb20(puVar2);
        if (iVar5 == 0) goto code_r0x0001801cfe45;
    }
    uVar13 = 0;
    iVar12 = 0x20;
    uVar8 = uVar13;
    if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
        if (*(int32_t *)(in_RCX + 0x8c8) == 0) goto code_r0x0001801cfe9d;
    } else {
        do {
            if (*(char *)(uVar8 + 0x184 + in_RCX) != '\0') goto code_r0x0001801cfec9;
            uVar8 = uVar8 + 1;
        } while (uVar8 < 0x20);
code_r0x0001801cfe9d:
        *(undefined4 *)((int64_t)&var_8h + iVar7) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfeb6;
        iVar5 = func_0x0001801c6280(in_RCX, 0, in_RCX + 0x184, 0x20);
        if (iVar5 < 1) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfebf;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            goto code_r0x0001801d017b;
        }
    }
code_r0x0001801cfec9:
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfede;
    iVar5 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&arg_48h + iVar7));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cfef8;
        iVar5 = func_0x0001802445f0(in_RDX, in_RCX + 0x184, 0x20);
        if (iVar5 != 0) {
            piVar4 = *(int32_t **)(in_RCX + 0x8f8);
            piVar10 = piVar4 + 0x96;
            if ((*(int32_t *)(in_RCX + 0x7c) == 0) && (*piVar4 != 0x304)) {
                iVar12 = *(int64_t *)(piVar4 + 0x94);
                if (*(int32_t *)(in_RCX + 0x48) == 0x304) {
                    *(int64_t *)(in_RCX + 0x940) = iVar12;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cff45;
                    fcn.180498030(in_RCX + 0x920, piVar10, iVar12);
                }
            } else if ((*(int32_t *)(in_RCX + 0x48) == 0x304) && ((*(uint32_t *)(in_RCX + 0x9a8) >> 0x14 & 1) != 0)) {
                piVar10 = (int32_t *)(in_RCX + 0x920);
                *(undefined8 *)(in_RCX + 0x940) = 0x20;
                if (*(int32_t *)(in_RCX + 0x8c8) == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cff85;
                    iVar5 = fcn.18021b9c0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)(&stack0x00000028 + iVar7)
                                          , *(int64_t *)(&stack0x00000030 + iVar7), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7));
                    if (iVar5 < 1) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cff8e;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                        goto code_r0x0001801d017b;
                    }
                }
            } else {
                iVar12 = 0;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cffa8;
            iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            if (iVar5 != 0) {
                if (iVar12 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cffc3;
                    iVar5 = func_0x0001802445f0(in_RDX, piVar10, iVar12);
                    if (iVar5 == 0) goto code_r0x0001801d0165;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801cffd3;
                iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)(&stack0x00000028 + iVar7)
                                      , *(int64_t *)(&stack0x00000030 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7)
                                      , *(int64_t *)((int64_t)&arg_40h + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7)
                                     );
                if (iVar5 != 0) {
                    if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0) {
code_r0x0001801d0024:
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0031;
                        iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                              *(int64_t *)((int64_t)&var_10h + iVar7));
                        if (iVar5 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d003a;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                          *(int64_t *)((int64_t)&var_10h + iVar7));
                        } else {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d004c;
                            uVar9 = func_0x000180193a50(in_RCX);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d005a;
                            iVar5 = func_0x0001801ce7b0(in_RCX, uVar9, in_RDX);
                            if (iVar5 == 0) {
                                return false;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d006a;
                            iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                                  *(int64_t *)(&stack0x00000028 + iVar7), 
                                                  *(int64_t *)(&stack0x00000030 + iVar7), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar7), 
                                                  *(int64_t *)((int64_t)&arg_40h + iVar7), 
                                                  *(int64_t *)((int64_t)&arg_48h + iVar7));
                            if (iVar5 == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0073;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                              *(int64_t *)((int64_t)&var_10h + iVar7));
                            } else {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d008a;
                                iVar5 = fcn.180244a90(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_10h + iVar7));
                                if (iVar5 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0093;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar7));
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d00a5;
                                    iVar5 = func_0x0001801af1c0(in_RCX);
                                    if (((iVar5 != 0) && (*(int64_t *)(iVar3 + 0x118) != 0)) &&
                                       (((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) !=
                                         0 || (*(int32_t *)(in_RCX + 0x41c) < 0x304)))) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d00d7;
                                        iVar5 = fcn.180222010();
                                        if (0 < iVar5) {
                                            do {
                                                uVar9 = *(undefined8 *)(iVar3 + 0x118);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d00ee;
                                                func_0x000180222340(uVar9, uVar13);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d00ff;
                                                iVar6 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                                                      *(int64_t *)((int64_t)&var_10h + iVar7), 
                                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                                                if (iVar6 == 0) {
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0152;
                                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                                                  *(int64_t *)((int64_t)&var_10h + iVar7));
                                                    goto code_r0x0001801d017b;
                                                }
                                                uVar11 = (int32_t)uVar13 + 1;
                                                uVar13 = (uint64_t)uVar11;
                                            } while ((int32_t)uVar11 < iVar5);
                                        }
                                    }
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0119;
                                    iVar5 = fcn.1802446f0(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                                          *(int64_t *)((int64_t)&var_10h + iVar7), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                                          *(int64_t *)((int64_t)&arg_48h + iVar7));
                                    if (iVar5 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0125;
                                        iVar5 = fcn.180244000(*(int64_t *)((int64_t)&var_10h + iVar7), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                                              *(int64_t *)(&stack0x00000028 + iVar7), 
                                                              *(int64_t *)(&stack0x00000030 + iVar7), 
                                                              *(int64_t *)((int64_t)&arg_38h + iVar7), 
                                                              *(int64_t *)((int64_t)&arg_40h + iVar7), 
                                                              *(int64_t *)((int64_t)&arg_48h + iVar7));
                                        if (iVar5 != 0) {
                                            *(undefined8 *)((int64_t)&var_8h + iVar7) = 0;
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0142;
                                            iVar5 = func_0x0001801c9910(in_RCX, in_RDX, 0x80, 0);
                                            return iVar5 != 0;
                                        }
                                    }
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d015e;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar7));
                                }
                            }
                        }
                    } else {
                        if (*(uint64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x100) < 0x100) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0011;
                            iVar5 = fcn.180244bf0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
                            if (iVar5 != 0) goto code_r0x0001801d0024;
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d001a;
                        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                    }
                    goto code_r0x0001801d017b;
                }
            }
code_r0x0001801d0165:
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d016a;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            goto code_r0x0001801d017b;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d0176;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
code_r0x0001801d017b:
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d018e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                  *(int64_t *)((int64_t)&arg_38h + iVar7));
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801d01a4;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000028 + iVar7));
    return false;
}

// ============================================================
// Function: FUN_1801d01c0
// Address: 0x1801d01c0
// Size: 911 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_308h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_368h because it doesn't fit into ProtoModel

undefined8 fcn.1801d01c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801d01d8;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x1c);
    if ((uVar1 & 0x1c8) == 0) {
code_r0x0001801d0203:
        if ((uVar1 & 0x41) == 0) {
            if ((uVar1 & 0x102) != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d0246;
                iVar2 = func_0x0001801ceb10(in_RCX, in_RDX);
                goto code_r0x0001801d0213;
            }
            if ((uVar1 & 0x84) != 0) {
                iVar6 = *(int64_t *)(in_RCX + 0x4e0);
                *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0;
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d0267;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
code_r0x0001801d04ca:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d04d6;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3));
code_r0x0001801d04dc:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d04ec;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar3));
                    goto code_r0x0001801d04ec;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d0283;
                iVar5 = func_0x0001801c6690(in_RCX, iVar6);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d0290;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d02a8;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3));
code_r0x0001801d02ae:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d02be;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar3));
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d02f3;
                    iVar2 = func_0x0001801c5dc0(in_RCX, iVar5, iVar6, 0);
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d0304;
                        iVar6 = func_0x00018022eef0(iVar5, (int64_t)&arg_28h + iVar3);
                        if (iVar6 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d030e;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar3), 
                                          *(int64_t *)((int64_t)&var_10h + iVar3));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d0326;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar3), 
                                          *(int64_t *)((int64_t)&var_10h + iVar3), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar3));
                        } else {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d0344;
                            iVar2 = fcn.180244bf0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar3));
                            if (iVar2 != 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d0387;
                                fcn.180224990(*(undefined8 *)((int64_t)&arg_28h + iVar3), 0x1804b3b98, 0xcfc);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d038f;
                                fcn.18022ecc0(iVar5);
                                goto code_r0x0001801d021b;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d034d;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar3), 
                                          *(int64_t *)((int64_t)&var_10h + iVar3));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d0365;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar3), 
                                          *(int64_t *)((int64_t)&var_10h + iVar3), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar3));
                        }
                        goto code_r0x0001801d02ae;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d02d5;
                fcn.180224990(*(undefined8 *)((int64_t)&arg_28h + iVar3), 0x1804b3b98, 0xcfc);
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d02dd;
                fcn.18022ecc0(iVar5);
                goto code_r0x0001801d04ec;
            }
            if ((uVar1 & 0x10) != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d03a4;
                iVar2 = func_0x0001801ced40(in_RCX, in_RDX);
                goto code_r0x0001801d0213;
            }
            if ((uVar1 >> 9 & 1) != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d03ba;
                iVar2 = func_0x0001801cf0c0(in_RCX, in_RDX);
                goto code_r0x0001801d0213;
            }
            if ((uVar1 & 0x20) != 0) {
                iVar6 = *(int64_t *)(in_RCX + 0xc18);
                *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0;
                if (iVar6 == 0) {
code_r0x0001801d049d:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d04a2;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
                    goto code_r0x0001801d04ca;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d03e2;
                iVar2 = func_0x000180255500();
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d0404;
                iVar2 = func_0x000180244b60(in_RDX, (int64_t)((int32_t)(iVar2 + 7 + (iVar2 + 7 >> 0x1f & 7U)) >> 3), 
                                            (int64_t)&arg_28h + iVar3, 2);
                if (iVar2 == 0) goto code_r0x0001801d049d;
                uVar4 = *(undefined8 *)(in_RCX + 0xc18);
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d041d;
                func_0x000180254c60(uVar4, *(undefined8 *)((int64_t)&arg_28h + iVar3));
                uVar4 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x358);
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d043d;
                fcn.180224990(uVar4, 0x1804b3b98, 0xe03);
                uVar4 = *(undefined8 *)(in_RCX + 0xbf0);
                iVar6 = *(int64_t *)(in_RCX + 0x8f8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d045d;
                uVar4 = func_0x0001802231e0(uVar4, 0x1804b3b98, 0xe04);
                *(undefined8 *)(iVar6 + 0x358) = uVar4;
                if (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x358) != 0) goto code_r0x0001801d021b;
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d047d;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d0495;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3));
                goto code_r0x0001801d04dc;
            }
            if ((uVar1 & 8) == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d04be;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
                goto code_r0x0001801d04ca;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d0213;
            iVar2 = fcn.1801cf780(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar3));
code_r0x0001801d0213:
            if (iVar2 == 0) goto code_r0x0001801d04ec;
        }
code_r0x0001801d021b:
        uVar4 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d01fb;
        iVar2 = fcn.1801cf480(*(int64_t *)(&stack0x000000e8 + iVar3));
        if (iVar2 != 0) goto code_r0x0001801d0203;
code_r0x0001801d04ec:
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d050c;
        fcn.180224b90(*(int64_t *)((int64_t)&iStackX_8 + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
        *(undefined8 *)(in_RCX + 0x3b0) = 0;
        *(undefined8 *)(in_RCX + 0x3b8) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801d053a;
        fcn.180224b90(*(int64_t *)((int64_t)&iStackX_8 + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3));
        uVar4 = 0;
        *(undefined8 *)(in_RCX + 0x3c0) = 0;
        *(undefined8 *)(in_RCX + 0x3c8) = 0;
    }
    return uVar4;
}

// ============================================================
// Function: FUN_1801d0550
// Address: 0x1801d0550
// Size: 114 bytes
// ============================================================
undefined8 fcn.1801d0550(int64_t param_1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d055c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((*(int32_t *)(param_1 + 0xf0) != 3) && (*(int32_t *)(param_1 + 0xf0) != 7)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801d0577;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801d058f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801d05a5;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar1));
        return 0;
    }
    *(undefined4 *)(param_1 + 0xf0) = 7;
    return 1;
}

// ============================================================
// Function: FUN_1801d05d0
// Address: 0x1801d05d0
// Size: 217 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801d05d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d05e5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(undefined8 *)(in_RCX + 0xb08);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0622;
    iVar2 = fcn.180244bf0(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d063c;
        iVar2 = fcn.180244b60(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d064f;
            fcn.1804986e0(*(undefined8 *)((int64_t)&arg_28h + iVar3), 0, 0x20 - (uint64_t)((int32_t)uVar1 + 2U & 0x1f));
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0669;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0681;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0697;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801d06b0
// Address: 0x1801d06b0
// Size: 42 bytes
// ============================================================
uint64_t fcn.1801d06b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d06bc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(char *)(in_RCX + 0xb52) == '\x02') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d06d0;
        uVar4 = fcn.1801d09a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
        return uVar4;
    }
    iVar2 = *(int32_t *)(in_RCX + 0x68);
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    if (iVar2 == 8) {
        *(undefined4 *)(in_RCX + 0x68) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d06ed;
    fcn.180229b10();
    uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0703;
    iVar2 = fcn.1801a2880(in_RCX, uVar5);
    if ((iVar2 < 1) && (*(int32_t *)(in_RCX + 0x948) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0717;
        fcn.180229900();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d071c;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0734;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        uVar1 = *(undefined4 *)(in_RCX + 0x990);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d073f;
        fcn.1801affa0(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0752;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0764;
    fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    if ((0 < iVar2) && (*(int32_t *)(in_RCX + 0x68) == 8)) {
        return 4;
    }
    iVar6 = *(int64_t *)(in_RCX + 0x8f8);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    uVar5 = *(undefined8 *)(iVar6 + 0x2c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0798;
    uVar5 = fcn.180222340(uVar5, 0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07a3;
    iVar6 = fcn.180238400(uVar5);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07b7;
        iVar2 = fcn.18022fd20(iVar6);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07d0;
            iVar6 = fcn.1801a2080(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3));
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07dd;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07f5;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
            } else if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                        (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) ||
                      ((*(uint32_t *)(iVar6 + 4) & *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20)) != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d086a;
                iVar2 = fcn.1802375f0(uVar5);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d08a9;
                    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), *(int64_t *)(&stack0x00000048 + iVar3)
                                 );
                    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0) = uVar5;
                    *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0) = *(undefined4 *)(in_RCX + 0x990);
                    uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d08dd;
                    fcn.18022ecc0(uVar5);
                    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) = 0;
                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                        (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d092c;
                        iVar2 = fcn.180197770(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar3));
                        return (uint64_t)(-(uint32_t)(iVar2 != 0) & 2);
                    }
                    return 2;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0873;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d088b;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d083a;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0852;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
            }
            goto code_r0x0001801d0980;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d095d;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0975;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
code_r0x0001801d0980:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d098b;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801d06da
// Address: 0x1801d06da
// Size: 133 bytes
// ============================================================
uint64_t fcn.1801d06b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d06bc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(char *)(in_RCX + 0xb52) == '\x02') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d06d0;
        uVar4 = fcn.1801d09a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
        return uVar4;
    }
    iVar2 = *(int32_t *)(in_RCX + 0x68);
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    if (iVar2 == 8) {
        *(undefined4 *)(in_RCX + 0x68) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d06ed;
    fcn.180229b10();
    uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0703;
    iVar2 = fcn.1801a2880(in_RCX, uVar5);
    if ((iVar2 < 1) && (*(int32_t *)(in_RCX + 0x948) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0717;
        fcn.180229900();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d071c;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0734;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        uVar1 = *(undefined4 *)(in_RCX + 0x990);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d073f;
        fcn.1801affa0(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0752;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0764;
    fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    if ((0 < iVar2) && (*(int32_t *)(in_RCX + 0x68) == 8)) {
        return 4;
    }
    iVar6 = *(int64_t *)(in_RCX + 0x8f8);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    uVar5 = *(undefined8 *)(iVar6 + 0x2c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0798;
    uVar5 = fcn.180222340(uVar5, 0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07a3;
    iVar6 = fcn.180238400(uVar5);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07b7;
        iVar2 = fcn.18022fd20(iVar6);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07d0;
            iVar6 = fcn.1801a2080(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3));
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07dd;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07f5;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
            } else if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                        (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) ||
                      ((*(uint32_t *)(iVar6 + 4) & *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20)) != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d086a;
                iVar2 = fcn.1802375f0(uVar5);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d08a9;
                    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), *(int64_t *)(&stack0x00000048 + iVar3)
                                 );
                    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0) = uVar5;
                    *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0) = *(undefined4 *)(in_RCX + 0x990);
                    uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d08dd;
                    fcn.18022ecc0(uVar5);
                    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) = 0;
                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                        (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d092c;
                        iVar2 = fcn.180197770(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar3));
                        return (uint64_t)(-(uint32_t)(iVar2 != 0) & 2);
                    }
                    return 2;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0873;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d088b;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d083a;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0852;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
            }
            goto code_r0x0001801d0980;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d095d;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0975;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
code_r0x0001801d0980:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d098b;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801d075f
// Address: 0x1801d075f
// Size: 31 bytes
// ============================================================
uint64_t fcn.1801d06b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d06bc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(char *)(in_RCX + 0xb52) == '\x02') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d06d0;
        uVar4 = fcn.1801d09a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
        return uVar4;
    }
    iVar2 = *(int32_t *)(in_RCX + 0x68);
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    if (iVar2 == 8) {
        *(undefined4 *)(in_RCX + 0x68) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d06ed;
    fcn.180229b10();
    uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0703;
    iVar2 = fcn.1801a2880(in_RCX, uVar5);
    if ((iVar2 < 1) && (*(int32_t *)(in_RCX + 0x948) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0717;
        fcn.180229900();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d071c;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0734;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        uVar1 = *(undefined4 *)(in_RCX + 0x990);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d073f;
        fcn.1801affa0(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0752;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0764;
    fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    if ((0 < iVar2) && (*(int32_t *)(in_RCX + 0x68) == 8)) {
        return 4;
    }
    iVar6 = *(int64_t *)(in_RCX + 0x8f8);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    uVar5 = *(undefined8 *)(iVar6 + 0x2c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0798;
    uVar5 = fcn.180222340(uVar5, 0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07a3;
    iVar6 = fcn.180238400(uVar5);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07b7;
        iVar2 = fcn.18022fd20(iVar6);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07d0;
            iVar6 = fcn.1801a2080(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3));
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07dd;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07f5;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
            } else if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                        (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) ||
                      ((*(uint32_t *)(iVar6 + 4) & *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20)) != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d086a;
                iVar2 = fcn.1802375f0(uVar5);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d08a9;
                    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), *(int64_t *)(&stack0x00000048 + iVar3)
                                 );
                    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0) = uVar5;
                    *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0) = *(undefined4 *)(in_RCX + 0x990);
                    uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d08dd;
                    fcn.18022ecc0(uVar5);
                    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) = 0;
                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                        (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d092c;
                        iVar2 = fcn.180197770(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar3));
                        return (uint64_t)(-(uint32_t)(iVar2 != 0) & 2);
                    }
                    return 2;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0873;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d088b;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d083a;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0852;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
            }
            goto code_r0x0001801d0980;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d095d;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0975;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
code_r0x0001801d0980:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d098b;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801d077e
// Address: 0x1801d077e
// Size: 453 bytes
// ============================================================
uint64_t fcn.1801d06b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d06bc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(char *)(in_RCX + 0xb52) == '\x02') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d06d0;
        uVar4 = fcn.1801d09a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
        return uVar4;
    }
    iVar2 = *(int32_t *)(in_RCX + 0x68);
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    if (iVar2 == 8) {
        *(undefined4 *)(in_RCX + 0x68) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d06ed;
    fcn.180229b10();
    uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0703;
    iVar2 = fcn.1801a2880(in_RCX, uVar5);
    if ((iVar2 < 1) && (*(int32_t *)(in_RCX + 0x948) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0717;
        fcn.180229900();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d071c;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0734;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        uVar1 = *(undefined4 *)(in_RCX + 0x990);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d073f;
        fcn.1801affa0(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0752;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0764;
    fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    if ((0 < iVar2) && (*(int32_t *)(in_RCX + 0x68) == 8)) {
        return 4;
    }
    iVar6 = *(int64_t *)(in_RCX + 0x8f8);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    uVar5 = *(undefined8 *)(iVar6 + 0x2c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0798;
    uVar5 = fcn.180222340(uVar5, 0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07a3;
    iVar6 = fcn.180238400(uVar5);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07b7;
        iVar2 = fcn.18022fd20(iVar6);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07d0;
            iVar6 = fcn.1801a2080(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3));
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07dd;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07f5;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
            } else if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                        (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) ||
                      ((*(uint32_t *)(iVar6 + 4) & *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20)) != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d086a;
                iVar2 = fcn.1802375f0(uVar5);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d08a9;
                    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), *(int64_t *)(&stack0x00000048 + iVar3)
                                 );
                    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0) = uVar5;
                    *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0) = *(undefined4 *)(in_RCX + 0x990);
                    uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d08dd;
                    fcn.18022ecc0(uVar5);
                    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) = 0;
                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                        (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d092c;
                        iVar2 = fcn.180197770(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar3));
                        return (uint64_t)(-(uint32_t)(iVar2 != 0) & 2);
                    }
                    return 2;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0873;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d088b;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d083a;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0852;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
            }
            goto code_r0x0001801d0980;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d095d;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0975;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
code_r0x0001801d0980:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d098b;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801d0943
// Address: 0x1801d0943
// Size: 21 bytes
// ============================================================
uint64_t fcn.1801d06b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d06bc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(char *)(in_RCX + 0xb52) == '\x02') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d06d0;
        uVar4 = fcn.1801d09a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
        return uVar4;
    }
    iVar2 = *(int32_t *)(in_RCX + 0x68);
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    if (iVar2 == 8) {
        *(undefined4 *)(in_RCX + 0x68) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d06ed;
    fcn.180229b10();
    uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0703;
    iVar2 = fcn.1801a2880(in_RCX, uVar5);
    if ((iVar2 < 1) && (*(int32_t *)(in_RCX + 0x948) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0717;
        fcn.180229900();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d071c;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0734;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        uVar1 = *(undefined4 *)(in_RCX + 0x990);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d073f;
        fcn.1801affa0(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0752;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0764;
    fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    if ((0 < iVar2) && (*(int32_t *)(in_RCX + 0x68) == 8)) {
        return 4;
    }
    iVar6 = *(int64_t *)(in_RCX + 0x8f8);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    uVar5 = *(undefined8 *)(iVar6 + 0x2c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0798;
    uVar5 = fcn.180222340(uVar5, 0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07a3;
    iVar6 = fcn.180238400(uVar5);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07b7;
        iVar2 = fcn.18022fd20(iVar6);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07d0;
            iVar6 = fcn.1801a2080(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3));
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07dd;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07f5;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
            } else if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                        (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) ||
                      ((*(uint32_t *)(iVar6 + 4) & *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20)) != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d086a;
                iVar2 = fcn.1802375f0(uVar5);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d08a9;
                    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), *(int64_t *)(&stack0x00000048 + iVar3)
                                 );
                    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0) = uVar5;
                    *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0) = *(undefined4 *)(in_RCX + 0x990);
                    uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d08dd;
                    fcn.18022ecc0(uVar5);
                    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) = 0;
                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                        (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d092c;
                        iVar2 = fcn.180197770(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar3));
                        return (uint64_t)(-(uint32_t)(iVar2 != 0) & 2);
                    }
                    return 2;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0873;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d088b;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d083a;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0852;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
            }
            goto code_r0x0001801d0980;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d095d;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0975;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
code_r0x0001801d0980:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d098b;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801d0958
// Address: 0x1801d0958
// Size: 69 bytes
// ============================================================
uint64_t fcn.1801d06b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d06bc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(char *)(in_RCX + 0xb52) == '\x02') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d06d0;
        uVar4 = fcn.1801d09a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
        return uVar4;
    }
    iVar2 = *(int32_t *)(in_RCX + 0x68);
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    if (iVar2 == 8) {
        *(undefined4 *)(in_RCX + 0x68) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d06ed;
    fcn.180229b10();
    uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0703;
    iVar2 = fcn.1801a2880(in_RCX, uVar5);
    if ((iVar2 < 1) && (*(int32_t *)(in_RCX + 0x948) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0717;
        fcn.180229900();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d071c;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0734;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        uVar1 = *(undefined4 *)(in_RCX + 0x990);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d073f;
        fcn.1801affa0(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0752;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0764;
    fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    if ((0 < iVar2) && (*(int32_t *)(in_RCX + 0x68) == 8)) {
        return 4;
    }
    iVar6 = *(int64_t *)(in_RCX + 0x8f8);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    uVar5 = *(undefined8 *)(iVar6 + 0x2c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0798;
    uVar5 = fcn.180222340(uVar5, 0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07a3;
    iVar6 = fcn.180238400(uVar5);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07b7;
        iVar2 = fcn.18022fd20(iVar6);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07d0;
            iVar6 = fcn.1801a2080(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3));
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07dd;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d07f5;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
            } else if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                        (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) ||
                      ((*(uint32_t *)(iVar6 + 4) & *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20)) != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d086a;
                iVar2 = fcn.1802375f0(uVar5);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d08a9;
                    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), *(int64_t *)(&stack0x00000048 + iVar3)
                                 );
                    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0) = uVar5;
                    *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0) = *(undefined4 *)(in_RCX + 0x990);
                    uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d08dd;
                    fcn.18022ecc0(uVar5);
                    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) = 0;
                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                        (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d092c;
                        iVar2 = fcn.180197770(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar3));
                        return (uint64_t)(-(uint32_t)(iVar2 != 0) & 2);
                    }
                    return 2;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0873;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d088b;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d083a;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0852;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
            }
            goto code_r0x0001801d0980;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d095d;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0975;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
code_r0x0001801d0980:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d098b;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801d09a0
// Address: 0x1801d09a0
// Size: 98 bytes
// ============================================================
uint8_t fcn.1801d09a0(int64_t arg_28h, int64_t arg_30h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d09ac;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09c8;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09e0;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09f6;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    iVar2 = *(int32_t *)(in_RCX + 0x68);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
    if (iVar2 == 8) {
        *(undefined4 *)(in_RCX + 0x68) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a15;
    fcn.180229b10();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a2b;
    iVar2 = fcn.1801a2c20(*(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
    if ((iVar2 < 1) && (*(int32_t *)(in_RCX + 0x948) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a3f;
        fcn.180229900();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a44;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a5c;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        uVar1 = *(undefined4 *)(in_RCX + 0x990);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a67;
        fcn.1801affa0(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a7a;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a8c;
    fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    if ((0 < iVar2) && (*(int32_t *)(in_RCX + 0x68) == 8)) {
        return 4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0ac2;
    iVar4 = fcn.1801a2080(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3));
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0acf;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0ae7;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0afd;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
         (iVar2 = **(int32_t **)(in_RCX + 0x18), iVar2 < 0x304)) || (iVar2 == 0x10000)) &&
       ((*(uint32_t *)(iVar4 + 4) & *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20)) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b3f;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b57;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b6d;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b8d;
    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0bb7;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000050 + iVar3));
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8) = 0;
    *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0) = *(undefined4 *)(in_RCX + 0x990);
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0c15;
        iVar2 = fcn.180197770(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3));
        return -(iVar2 != 0) & 2;
    }
    return 2;
}

// ============================================================
// Function: FUN_1801d0a02
// Address: 0x1801d0a02
// Size: 133 bytes
// ============================================================
uint8_t fcn.1801d09a0(int64_t arg_28h, int64_t arg_30h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d09ac;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09c8;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09e0;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09f6;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    iVar2 = *(int32_t *)(in_RCX + 0x68);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
    if (iVar2 == 8) {
        *(undefined4 *)(in_RCX + 0x68) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a15;
    fcn.180229b10();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a2b;
    iVar2 = fcn.1801a2c20(*(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
    if ((iVar2 < 1) && (*(int32_t *)(in_RCX + 0x948) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a3f;
        fcn.180229900();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a44;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a5c;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        uVar1 = *(undefined4 *)(in_RCX + 0x990);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a67;
        fcn.1801affa0(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a7a;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a8c;
    fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    if ((0 < iVar2) && (*(int32_t *)(in_RCX + 0x68) == 8)) {
        return 4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0ac2;
    iVar4 = fcn.1801a2080(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3));
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0acf;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0ae7;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0afd;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
         (iVar2 = **(int32_t **)(in_RCX + 0x18), iVar2 < 0x304)) || (iVar2 == 0x10000)) &&
       ((*(uint32_t *)(iVar4 + 4) & *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20)) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b3f;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b57;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b6d;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b8d;
    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0bb7;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000050 + iVar3));
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8) = 0;
    *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0) = *(undefined4 *)(in_RCX + 0x990);
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0c15;
        iVar2 = fcn.180197770(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3));
        return -(iVar2 != 0) & 2;
    }
    return 2;
}

// ============================================================
// Function: FUN_1801d0a87
// Address: 0x1801d0a87
// Size: 31 bytes
// ============================================================
uint8_t fcn.1801d09a0(int64_t arg_28h, int64_t arg_30h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d09ac;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09c8;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09e0;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09f6;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    iVar2 = *(int32_t *)(in_RCX + 0x68);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
    if (iVar2 == 8) {
        *(undefined4 *)(in_RCX + 0x68) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a15;
    fcn.180229b10();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a2b;
    iVar2 = fcn.1801a2c20(*(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
    if ((iVar2 < 1) && (*(int32_t *)(in_RCX + 0x948) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a3f;
        fcn.180229900();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a44;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a5c;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        uVar1 = *(undefined4 *)(in_RCX + 0x990);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a67;
        fcn.1801affa0(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a7a;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a8c;
    fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    if ((0 < iVar2) && (*(int32_t *)(in_RCX + 0x68) == 8)) {
        return 4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0ac2;
    iVar4 = fcn.1801a2080(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3));
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0acf;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0ae7;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0afd;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
         (iVar2 = **(int32_t **)(in_RCX + 0x18), iVar2 < 0x304)) || (iVar2 == 0x10000)) &&
       ((*(uint32_t *)(iVar4 + 4) & *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20)) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b3f;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b57;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b6d;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b8d;
    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0bb7;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000050 + iVar3));
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8) = 0;
    *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0) = *(undefined4 *)(in_RCX + 0x990);
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0c15;
        iVar2 = fcn.180197770(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3));
        return -(iVar2 != 0) & 2;
    }
    return 2;
}

// ============================================================
// Function: FUN_1801d0aa6
// Address: 0x1801d0aa6
// Size: 100 bytes
// ============================================================
uint8_t fcn.1801d09a0(int64_t arg_28h, int64_t arg_30h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d09ac;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09c8;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09e0;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09f6;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    iVar2 = *(int32_t *)(in_RCX + 0x68);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
    if (iVar2 == 8) {
        *(undefined4 *)(in_RCX + 0x68) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a15;
    fcn.180229b10();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a2b;
    iVar2 = fcn.1801a2c20(*(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
    if ((iVar2 < 1) && (*(int32_t *)(in_RCX + 0x948) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a3f;
        fcn.180229900();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a44;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a5c;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        uVar1 = *(undefined4 *)(in_RCX + 0x990);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a67;
        fcn.1801affa0(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a7a;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a8c;
    fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    if ((0 < iVar2) && (*(int32_t *)(in_RCX + 0x68) == 8)) {
        return 4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0ac2;
    iVar4 = fcn.1801a2080(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3));
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0acf;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0ae7;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0afd;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
         (iVar2 = **(int32_t **)(in_RCX + 0x18), iVar2 < 0x304)) || (iVar2 == 0x10000)) &&
       ((*(uint32_t *)(iVar4 + 4) & *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20)) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b3f;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b57;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b6d;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b8d;
    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0bb7;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000050 + iVar3));
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8) = 0;
    *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0) = *(undefined4 *)(in_RCX + 0x990);
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0c15;
        iVar2 = fcn.180197770(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3));
        return -(iVar2 != 0) & 2;
    }
    return 2;
}

// ============================================================
// Function: FUN_1801d0b0a
// Address: 0x1801d0b0a
// Size: 112 bytes
// ============================================================
uint8_t fcn.1801d09a0(int64_t arg_28h, int64_t arg_30h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d09ac;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09c8;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09e0;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09f6;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    iVar2 = *(int32_t *)(in_RCX + 0x68);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
    if (iVar2 == 8) {
        *(undefined4 *)(in_RCX + 0x68) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a15;
    fcn.180229b10();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a2b;
    iVar2 = fcn.1801a2c20(*(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
    if ((iVar2 < 1) && (*(int32_t *)(in_RCX + 0x948) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a3f;
        fcn.180229900();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a44;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a5c;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        uVar1 = *(undefined4 *)(in_RCX + 0x990);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a67;
        fcn.1801affa0(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a7a;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a8c;
    fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    if ((0 < iVar2) && (*(int32_t *)(in_RCX + 0x68) == 8)) {
        return 4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0ac2;
    iVar4 = fcn.1801a2080(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3));
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0acf;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0ae7;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0afd;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
         (iVar2 = **(int32_t **)(in_RCX + 0x18), iVar2 < 0x304)) || (iVar2 == 0x10000)) &&
       ((*(uint32_t *)(iVar4 + 4) & *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20)) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b3f;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b57;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b6d;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b8d;
    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0bb7;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000050 + iVar3));
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8) = 0;
    *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0) = *(undefined4 *)(in_RCX + 0x990);
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0c15;
        iVar2 = fcn.180197770(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3));
        return -(iVar2 != 0) & 2;
    }
    return 2;
}

// ============================================================
// Function: FUN_1801d0b7a
// Address: 0x1801d0b7a
// Size: 173 bytes
// ============================================================
uint8_t fcn.1801d09a0(int64_t arg_28h, int64_t arg_30h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d09ac;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09c8;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09e0;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09f6;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    iVar2 = *(int32_t *)(in_RCX + 0x68);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
    if (iVar2 == 8) {
        *(undefined4 *)(in_RCX + 0x68) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a15;
    fcn.180229b10();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a2b;
    iVar2 = fcn.1801a2c20(*(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
    if ((iVar2 < 1) && (*(int32_t *)(in_RCX + 0x948) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a3f;
        fcn.180229900();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a44;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a5c;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        uVar1 = *(undefined4 *)(in_RCX + 0x990);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a67;
        fcn.1801affa0(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a7a;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a8c;
    fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    if ((0 < iVar2) && (*(int32_t *)(in_RCX + 0x68) == 8)) {
        return 4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0ac2;
    iVar4 = fcn.1801a2080(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3));
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0acf;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0ae7;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0afd;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
         (iVar2 = **(int32_t **)(in_RCX + 0x18), iVar2 < 0x304)) || (iVar2 == 0x10000)) &&
       ((*(uint32_t *)(iVar4 + 4) & *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20)) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b3f;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b57;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b6d;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b8d;
    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0bb7;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000050 + iVar3));
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8) = 0;
    *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0) = *(undefined4 *)(in_RCX + 0x990);
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0c15;
        iVar2 = fcn.180197770(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3));
        return -(iVar2 != 0) & 2;
    }
    return 2;
}

// ============================================================
// Function: FUN_1801d0c27
// Address: 0x1801d0c27
// Size: 16 bytes
// ============================================================
uint8_t fcn.1801d09a0(int64_t arg_28h, int64_t arg_30h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d09ac;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09c8;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09e0;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d09f6;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    iVar2 = *(int32_t *)(in_RCX + 0x68);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
    if (iVar2 == 8) {
        *(undefined4 *)(in_RCX + 0x68) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a15;
    fcn.180229b10();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a2b;
    iVar2 = fcn.1801a2c20(*(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
    if ((iVar2 < 1) && (*(int32_t *)(in_RCX + 0x948) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a3f;
        fcn.180229900();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a44;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a5c;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        uVar1 = *(undefined4 *)(in_RCX + 0x990);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a67;
        fcn.1801affa0(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a7a;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0a8c;
    fcn.1802299d0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    if ((0 < iVar2) && (*(int32_t *)(in_RCX + 0x68) == 8)) {
        return 4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0ac2;
    iVar4 = fcn.1801a2080(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3));
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0acf;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0ae7;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0afd;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
         (iVar2 = **(int32_t **)(in_RCX + 0x18), iVar2 < 0x304)) || (iVar2 == 0x10000)) &&
       ((*(uint32_t *)(iVar4 + 4) & *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20)) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b3f;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b57;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b6d;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0b8d;
    fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c0) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0bb7;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000050 + iVar3));
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8) = 0;
    *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2d0) = *(undefined4 *)(in_RCX + 0x990);
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801d0c15;
        iVar2 = fcn.180197770(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3));
        return -(iVar2 != 0) & 2;
    }
    return 2;
}

// ============================================================
// Function: FUN_1801d0c40
// Address: 0x1801d0c40
// Size: 208 bytes
// ============================================================
uint64_t fcn.1801d0c40(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h, int64_t arg_c8h,
                      int64_t arg_208h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x1801d0c4d;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar5 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = 0;
    if (in_EDX == 4) {
        pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x878) + 0x60);
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0c7e;
            iVar4 = (*pcVar1)();
            if (iVar4 < 0) {
                *(undefined4 *)(in_RCX + 0x68) = 4;
                return 4;
            }
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0c9c;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0cb4;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0cca;
                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
                return 0;
            }
            *(undefined4 *)(in_RCX + 0x68) = 1;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ce2;
        iVar4 = fcn.1801ce740(in_RCX);
        if (iVar4 != 0) {
            if (*(int32_t *)(in_RCX + 0xba8) != 4) {
                return 2;
            }
            return 1;
        }
    } else if (in_EDX != 5) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ee0;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ef8;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0f0e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    iVar2 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + -8) = unaff_RSI;
    if (*(int64_t *)(iVar2 + 0x208) == 0) {
code_r0x0001801d0d41:
        pcVar1 = *(code **)(iVar2 + 200);
        if (pcVar1 != (code *)0x0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x40);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0d5d;
            iVar5 = (*pcVar1)(uVar3, (int64_t)&arg_40h + iVar6, (int64_t)&arg_30h + iVar6);
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0d3b;
        iVar5 = fcn.1801bca70(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        if (iVar5 == 0) goto code_r0x0001801d0d41;
    }
    if (iVar5 < 0) {
        *(undefined4 *)(in_RCX + 0x68) = 4;
        return 5;
    }
    *(undefined4 *)(in_RCX + 0x68) = 1;
    if (iVar5 == 1) {
        if ((*(int64_t *)((int64_t)&arg_30h + iVar6) != 0) && (*(int64_t *)((int64_t)&arg_40h + iVar6) != 0)) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0da9;
            iVar4 = fcn.180199810(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6)
                                  , *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6), *(int64_t *)(&stack0x00000050 + iVar6), 
                                  *(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x00000088 + iVar6));
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dba;
                iVar4 = fcn.180199550(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_78h + iVar6));
                if (iVar4 != 0) goto code_r0x0001801d0dc0;
            }
            iVar5 = 0;
            goto code_r0x0001801d0dc0;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e20;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e38;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e4a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e54;
        fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e5e;
        fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_30h + iVar6));
    } else {
code_r0x0001801d0dc0:
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dca;
        fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dd4;
        fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_30h + iVar6));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0de0;
            iVar5 = fcn.1801ce740(in_RCX);
            if (iVar5 != 0) goto code_r0x0001801d0e87;
        }
    }
    if (*(int32_t *)(in_RCX + 0x48) == 0x300) {
        *(undefined4 *)(in_RCX + 0x340) = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e0a;
        fcn.1801c6e50(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        return 2;
    }
    *(undefined4 *)(in_RCX + 0x340) = 2;
    *(undefined4 *)(in_RCX + 0xb3c) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e77;
    uVar7 = fcn.1801da790(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6));
    if ((int32_t)uVar7 == 0) {
        return uVar7;
    }
code_r0x0001801d0e87:
    if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
         (iVar5 = **(int32_t **)(in_RCX + 0x18), iVar5 < 0x304)) || (iVar5 == 0x10000)) ||
       ((*(uint64_t *)(in_RCX + 0x9a8) & 0x100000000) != 0)) {
        *(undefined4 *)(in_RCX + 0xb3c) = 0;
    }
    return (uint64_t)((*(int32_t *)(in_RCX + 0xba8) != 4) + 1);
}

// ============================================================
// Function: FUN_1801d0d10
// Address: 0x1801d0d10
// Size: 88 bytes
// ============================================================
uint64_t fcn.1801d0c40(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h, int64_t arg_c8h,
                      int64_t arg_208h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x1801d0c4d;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar5 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = 0;
    if (in_EDX == 4) {
        pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x878) + 0x60);
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0c7e;
            iVar4 = (*pcVar1)();
            if (iVar4 < 0) {
                *(undefined4 *)(in_RCX + 0x68) = 4;
                return 4;
            }
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0c9c;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0cb4;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0cca;
                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
                return 0;
            }
            *(undefined4 *)(in_RCX + 0x68) = 1;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ce2;
        iVar4 = fcn.1801ce740(in_RCX);
        if (iVar4 != 0) {
            if (*(int32_t *)(in_RCX + 0xba8) != 4) {
                return 2;
            }
            return 1;
        }
    } else if (in_EDX != 5) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ee0;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ef8;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0f0e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    iVar2 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + -8) = unaff_RSI;
    if (*(int64_t *)(iVar2 + 0x208) == 0) {
code_r0x0001801d0d41:
        pcVar1 = *(code **)(iVar2 + 200);
        if (pcVar1 != (code *)0x0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x40);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0d5d;
            iVar5 = (*pcVar1)(uVar3, (int64_t)&arg_40h + iVar6, (int64_t)&arg_30h + iVar6);
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0d3b;
        iVar5 = fcn.1801bca70(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        if (iVar5 == 0) goto code_r0x0001801d0d41;
    }
    if (iVar5 < 0) {
        *(undefined4 *)(in_RCX + 0x68) = 4;
        return 5;
    }
    *(undefined4 *)(in_RCX + 0x68) = 1;
    if (iVar5 == 1) {
        if ((*(int64_t *)((int64_t)&arg_30h + iVar6) != 0) && (*(int64_t *)((int64_t)&arg_40h + iVar6) != 0)) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0da9;
            iVar4 = fcn.180199810(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6)
                                  , *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6), *(int64_t *)(&stack0x00000050 + iVar6), 
                                  *(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x00000088 + iVar6));
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dba;
                iVar4 = fcn.180199550(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_78h + iVar6));
                if (iVar4 != 0) goto code_r0x0001801d0dc0;
            }
            iVar5 = 0;
            goto code_r0x0001801d0dc0;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e20;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e38;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e4a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e54;
        fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e5e;
        fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_30h + iVar6));
    } else {
code_r0x0001801d0dc0:
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dca;
        fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dd4;
        fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_30h + iVar6));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0de0;
            iVar5 = fcn.1801ce740(in_RCX);
            if (iVar5 != 0) goto code_r0x0001801d0e87;
        }
    }
    if (*(int32_t *)(in_RCX + 0x48) == 0x300) {
        *(undefined4 *)(in_RCX + 0x340) = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e0a;
        fcn.1801c6e50(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        return 2;
    }
    *(undefined4 *)(in_RCX + 0x340) = 2;
    *(undefined4 *)(in_RCX + 0xb3c) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e77;
    uVar7 = fcn.1801da790(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6));
    if ((int32_t)uVar7 == 0) {
        return uVar7;
    }
code_r0x0001801d0e87:
    if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
         (iVar5 = **(int32_t **)(in_RCX + 0x18), iVar5 < 0x304)) || (iVar5 == 0x10000)) ||
       ((*(uint64_t *)(in_RCX + 0x9a8) & 0x100000000) != 0)) {
        *(undefined4 *)(in_RCX + 0xb3c) = 0;
    }
    return (uint64_t)((*(int32_t *)(in_RCX + 0xba8) != 4) + 1);
}

// ============================================================
// Function: FUN_1801d0d68
// Address: 0x1801d0d68
// Size: 24 bytes
// ============================================================
uint64_t fcn.1801d0c40(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h, int64_t arg_c8h,
                      int64_t arg_208h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x1801d0c4d;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar5 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = 0;
    if (in_EDX == 4) {
        pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x878) + 0x60);
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0c7e;
            iVar4 = (*pcVar1)();
            if (iVar4 < 0) {
                *(undefined4 *)(in_RCX + 0x68) = 4;
                return 4;
            }
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0c9c;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0cb4;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0cca;
                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
                return 0;
            }
            *(undefined4 *)(in_RCX + 0x68) = 1;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ce2;
        iVar4 = fcn.1801ce740(in_RCX);
        if (iVar4 != 0) {
            if (*(int32_t *)(in_RCX + 0xba8) != 4) {
                return 2;
            }
            return 1;
        }
    } else if (in_EDX != 5) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ee0;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ef8;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0f0e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    iVar2 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + -8) = unaff_RSI;
    if (*(int64_t *)(iVar2 + 0x208) == 0) {
code_r0x0001801d0d41:
        pcVar1 = *(code **)(iVar2 + 200);
        if (pcVar1 != (code *)0x0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x40);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0d5d;
            iVar5 = (*pcVar1)(uVar3, (int64_t)&arg_40h + iVar6, (int64_t)&arg_30h + iVar6);
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0d3b;
        iVar5 = fcn.1801bca70(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        if (iVar5 == 0) goto code_r0x0001801d0d41;
    }
    if (iVar5 < 0) {
        *(undefined4 *)(in_RCX + 0x68) = 4;
        return 5;
    }
    *(undefined4 *)(in_RCX + 0x68) = 1;
    if (iVar5 == 1) {
        if ((*(int64_t *)((int64_t)&arg_30h + iVar6) != 0) && (*(int64_t *)((int64_t)&arg_40h + iVar6) != 0)) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0da9;
            iVar4 = fcn.180199810(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6)
                                  , *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6), *(int64_t *)(&stack0x00000050 + iVar6), 
                                  *(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x00000088 + iVar6));
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dba;
                iVar4 = fcn.180199550(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_78h + iVar6));
                if (iVar4 != 0) goto code_r0x0001801d0dc0;
            }
            iVar5 = 0;
            goto code_r0x0001801d0dc0;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e20;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e38;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e4a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e54;
        fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e5e;
        fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_30h + iVar6));
    } else {
code_r0x0001801d0dc0:
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dca;
        fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dd4;
        fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_30h + iVar6));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0de0;
            iVar5 = fcn.1801ce740(in_RCX);
            if (iVar5 != 0) goto code_r0x0001801d0e87;
        }
    }
    if (*(int32_t *)(in_RCX + 0x48) == 0x300) {
        *(undefined4 *)(in_RCX + 0x340) = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e0a;
        fcn.1801c6e50(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        return 2;
    }
    *(undefined4 *)(in_RCX + 0x340) = 2;
    *(undefined4 *)(in_RCX + 0xb3c) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e77;
    uVar7 = fcn.1801da790(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6));
    if ((int32_t)uVar7 == 0) {
        return uVar7;
    }
code_r0x0001801d0e87:
    if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
         (iVar5 = **(int32_t **)(in_RCX + 0x18), iVar5 < 0x304)) || (iVar5 == 0x10000)) ||
       ((*(uint64_t *)(in_RCX + 0x9a8) & 0x100000000) != 0)) {
        *(undefined4 *)(in_RCX + 0xb3c) = 0;
    }
    return (uint64_t)((*(int32_t *)(in_RCX + 0xba8) != 4) + 1);
}

// ============================================================
// Function: FUN_1801d0d80
// Address: 0x1801d0d80
// Size: 155 bytes
// ============================================================
uint64_t fcn.1801d0c40(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h, int64_t arg_c8h,
                      int64_t arg_208h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x1801d0c4d;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar5 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = 0;
    if (in_EDX == 4) {
        pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x878) + 0x60);
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0c7e;
            iVar4 = (*pcVar1)();
            if (iVar4 < 0) {
                *(undefined4 *)(in_RCX + 0x68) = 4;
                return 4;
            }
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0c9c;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0cb4;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0cca;
                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
                return 0;
            }
            *(undefined4 *)(in_RCX + 0x68) = 1;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ce2;
        iVar4 = fcn.1801ce740(in_RCX);
        if (iVar4 != 0) {
            if (*(int32_t *)(in_RCX + 0xba8) != 4) {
                return 2;
            }
            return 1;
        }
    } else if (in_EDX != 5) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ee0;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ef8;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0f0e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    iVar2 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + -8) = unaff_RSI;
    if (*(int64_t *)(iVar2 + 0x208) == 0) {
code_r0x0001801d0d41:
        pcVar1 = *(code **)(iVar2 + 200);
        if (pcVar1 != (code *)0x0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x40);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0d5d;
            iVar5 = (*pcVar1)(uVar3, (int64_t)&arg_40h + iVar6, (int64_t)&arg_30h + iVar6);
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0d3b;
        iVar5 = fcn.1801bca70(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        if (iVar5 == 0) goto code_r0x0001801d0d41;
    }
    if (iVar5 < 0) {
        *(undefined4 *)(in_RCX + 0x68) = 4;
        return 5;
    }
    *(undefined4 *)(in_RCX + 0x68) = 1;
    if (iVar5 == 1) {
        if ((*(int64_t *)((int64_t)&arg_30h + iVar6) != 0) && (*(int64_t *)((int64_t)&arg_40h + iVar6) != 0)) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0da9;
            iVar4 = fcn.180199810(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6)
                                  , *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6), *(int64_t *)(&stack0x00000050 + iVar6), 
                                  *(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x00000088 + iVar6));
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dba;
                iVar4 = fcn.180199550(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_78h + iVar6));
                if (iVar4 != 0) goto code_r0x0001801d0dc0;
            }
            iVar5 = 0;
            goto code_r0x0001801d0dc0;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e20;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e38;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e4a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e54;
        fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e5e;
        fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_30h + iVar6));
    } else {
code_r0x0001801d0dc0:
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dca;
        fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dd4;
        fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_30h + iVar6));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0de0;
            iVar5 = fcn.1801ce740(in_RCX);
            if (iVar5 != 0) goto code_r0x0001801d0e87;
        }
    }
    if (*(int32_t *)(in_RCX + 0x48) == 0x300) {
        *(undefined4 *)(in_RCX + 0x340) = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e0a;
        fcn.1801c6e50(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        return 2;
    }
    *(undefined4 *)(in_RCX + 0x340) = 2;
    *(undefined4 *)(in_RCX + 0xb3c) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e77;
    uVar7 = fcn.1801da790(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6));
    if ((int32_t)uVar7 == 0) {
        return uVar7;
    }
code_r0x0001801d0e87:
    if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
         (iVar5 = **(int32_t **)(in_RCX + 0x18), iVar5 < 0x304)) || (iVar5 == 0x10000)) ||
       ((*(uint64_t *)(in_RCX + 0x9a8) & 0x100000000) != 0)) {
        *(undefined4 *)(in_RCX + 0xb3c) = 0;
    }
    return (uint64_t)((*(int32_t *)(in_RCX + 0xba8) != 4) + 1);
}

// ============================================================
// Function: FUN_1801d0e1b
// Address: 0x1801d0e1b
// Size: 108 bytes
// ============================================================
uint64_t fcn.1801d0c40(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h, int64_t arg_c8h,
                      int64_t arg_208h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x1801d0c4d;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar5 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = 0;
    if (in_EDX == 4) {
        pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x878) + 0x60);
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0c7e;
            iVar4 = (*pcVar1)();
            if (iVar4 < 0) {
                *(undefined4 *)(in_RCX + 0x68) = 4;
                return 4;
            }
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0c9c;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0cb4;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0cca;
                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
                return 0;
            }
            *(undefined4 *)(in_RCX + 0x68) = 1;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ce2;
        iVar4 = fcn.1801ce740(in_RCX);
        if (iVar4 != 0) {
            if (*(int32_t *)(in_RCX + 0xba8) != 4) {
                return 2;
            }
            return 1;
        }
    } else if (in_EDX != 5) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ee0;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ef8;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0f0e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    iVar2 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + -8) = unaff_RSI;
    if (*(int64_t *)(iVar2 + 0x208) == 0) {
code_r0x0001801d0d41:
        pcVar1 = *(code **)(iVar2 + 200);
        if (pcVar1 != (code *)0x0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x40);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0d5d;
            iVar5 = (*pcVar1)(uVar3, (int64_t)&arg_40h + iVar6, (int64_t)&arg_30h + iVar6);
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0d3b;
        iVar5 = fcn.1801bca70(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        if (iVar5 == 0) goto code_r0x0001801d0d41;
    }
    if (iVar5 < 0) {
        *(undefined4 *)(in_RCX + 0x68) = 4;
        return 5;
    }
    *(undefined4 *)(in_RCX + 0x68) = 1;
    if (iVar5 == 1) {
        if ((*(int64_t *)((int64_t)&arg_30h + iVar6) != 0) && (*(int64_t *)((int64_t)&arg_40h + iVar6) != 0)) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0da9;
            iVar4 = fcn.180199810(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6)
                                  , *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6), *(int64_t *)(&stack0x00000050 + iVar6), 
                                  *(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x00000088 + iVar6));
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dba;
                iVar4 = fcn.180199550(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_78h + iVar6));
                if (iVar4 != 0) goto code_r0x0001801d0dc0;
            }
            iVar5 = 0;
            goto code_r0x0001801d0dc0;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e20;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e38;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e4a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e54;
        fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e5e;
        fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_30h + iVar6));
    } else {
code_r0x0001801d0dc0:
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dca;
        fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dd4;
        fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_30h + iVar6));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0de0;
            iVar5 = fcn.1801ce740(in_RCX);
            if (iVar5 != 0) goto code_r0x0001801d0e87;
        }
    }
    if (*(int32_t *)(in_RCX + 0x48) == 0x300) {
        *(undefined4 *)(in_RCX + 0x340) = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e0a;
        fcn.1801c6e50(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        return 2;
    }
    *(undefined4 *)(in_RCX + 0x340) = 2;
    *(undefined4 *)(in_RCX + 0xb3c) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e77;
    uVar7 = fcn.1801da790(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6));
    if ((int32_t)uVar7 == 0) {
        return uVar7;
    }
code_r0x0001801d0e87:
    if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
         (iVar5 = **(int32_t **)(in_RCX + 0x18), iVar5 < 0x304)) || (iVar5 == 0x10000)) ||
       ((*(uint64_t *)(in_RCX + 0x9a8) & 0x100000000) != 0)) {
        *(undefined4 *)(in_RCX + 0xb3c) = 0;
    }
    return (uint64_t)((*(int32_t *)(in_RCX + 0xba8) != 4) + 1);
}

// ============================================================
// Function: FUN_1801d0e87
// Address: 0x1801d0e87
// Size: 84 bytes
// ============================================================
uint64_t fcn.1801d0c40(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h, int64_t arg_c8h,
                      int64_t arg_208h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x1801d0c4d;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar5 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = 0;
    if (in_EDX == 4) {
        pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x878) + 0x60);
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0c7e;
            iVar4 = (*pcVar1)();
            if (iVar4 < 0) {
                *(undefined4 *)(in_RCX + 0x68) = 4;
                return 4;
            }
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0c9c;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0cb4;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0cca;
                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
                return 0;
            }
            *(undefined4 *)(in_RCX + 0x68) = 1;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ce2;
        iVar4 = fcn.1801ce740(in_RCX);
        if (iVar4 != 0) {
            if (*(int32_t *)(in_RCX + 0xba8) != 4) {
                return 2;
            }
            return 1;
        }
    } else if (in_EDX != 5) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ee0;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ef8;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0f0e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    iVar2 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + -8) = unaff_RSI;
    if (*(int64_t *)(iVar2 + 0x208) == 0) {
code_r0x0001801d0d41:
        pcVar1 = *(code **)(iVar2 + 200);
        if (pcVar1 != (code *)0x0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x40);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0d5d;
            iVar5 = (*pcVar1)(uVar3, (int64_t)&arg_40h + iVar6, (int64_t)&arg_30h + iVar6);
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0d3b;
        iVar5 = fcn.1801bca70(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        if (iVar5 == 0) goto code_r0x0001801d0d41;
    }
    if (iVar5 < 0) {
        *(undefined4 *)(in_RCX + 0x68) = 4;
        return 5;
    }
    *(undefined4 *)(in_RCX + 0x68) = 1;
    if (iVar5 == 1) {
        if ((*(int64_t *)((int64_t)&arg_30h + iVar6) != 0) && (*(int64_t *)((int64_t)&arg_40h + iVar6) != 0)) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0da9;
            iVar4 = fcn.180199810(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6)
                                  , *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6), *(int64_t *)(&stack0x00000050 + iVar6), 
                                  *(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x00000088 + iVar6));
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dba;
                iVar4 = fcn.180199550(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_78h + iVar6));
                if (iVar4 != 0) goto code_r0x0001801d0dc0;
            }
            iVar5 = 0;
            goto code_r0x0001801d0dc0;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e20;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e38;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e4a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e54;
        fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e5e;
        fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_30h + iVar6));
    } else {
code_r0x0001801d0dc0:
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dca;
        fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dd4;
        fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_30h + iVar6));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0de0;
            iVar5 = fcn.1801ce740(in_RCX);
            if (iVar5 != 0) goto code_r0x0001801d0e87;
        }
    }
    if (*(int32_t *)(in_RCX + 0x48) == 0x300) {
        *(undefined4 *)(in_RCX + 0x340) = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e0a;
        fcn.1801c6e50(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        return 2;
    }
    *(undefined4 *)(in_RCX + 0x340) = 2;
    *(undefined4 *)(in_RCX + 0xb3c) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e77;
    uVar7 = fcn.1801da790(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6));
    if ((int32_t)uVar7 == 0) {
        return uVar7;
    }
code_r0x0001801d0e87:
    if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
         (iVar5 = **(int32_t **)(in_RCX + 0x18), iVar5 < 0x304)) || (iVar5 == 0x10000)) ||
       ((*(uint64_t *)(in_RCX + 0x9a8) & 0x100000000) != 0)) {
        *(undefined4 *)(in_RCX + 0xb3c) = 0;
    }
    return (uint64_t)((*(int32_t *)(in_RCX + 0xba8) != 4) + 1);
}

// ============================================================
// Function: FUN_1801d0edb
// Address: 0x1801d0edb
// Size: 60 bytes
// ============================================================
uint64_t fcn.1801d0c40(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h, int64_t arg_c8h,
                      int64_t arg_208h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x1801d0c4d;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar5 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = 0;
    if (in_EDX == 4) {
        pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x878) + 0x60);
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0c7e;
            iVar4 = (*pcVar1)();
            if (iVar4 < 0) {
                *(undefined4 *)(in_RCX + 0x68) = 4;
                return 4;
            }
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0c9c;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0cb4;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0cca;
                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
                return 0;
            }
            *(undefined4 *)(in_RCX + 0x68) = 1;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ce2;
        iVar4 = fcn.1801ce740(in_RCX);
        if (iVar4 != 0) {
            if (*(int32_t *)(in_RCX + 0xba8) != 4) {
                return 2;
            }
            return 1;
        }
    } else if (in_EDX != 5) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ee0;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0ef8;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0f0e;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    iVar2 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + -8) = unaff_RSI;
    if (*(int64_t *)(iVar2 + 0x208) == 0) {
code_r0x0001801d0d41:
        pcVar1 = *(code **)(iVar2 + 200);
        if (pcVar1 != (code *)0x0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x40);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0d5d;
            iVar5 = (*pcVar1)(uVar3, (int64_t)&arg_40h + iVar6, (int64_t)&arg_30h + iVar6);
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0d3b;
        iVar5 = fcn.1801bca70(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        if (iVar5 == 0) goto code_r0x0001801d0d41;
    }
    if (iVar5 < 0) {
        *(undefined4 *)(in_RCX + 0x68) = 4;
        return 5;
    }
    *(undefined4 *)(in_RCX + 0x68) = 1;
    if (iVar5 == 1) {
        if ((*(int64_t *)((int64_t)&arg_30h + iVar6) != 0) && (*(int64_t *)((int64_t)&arg_40h + iVar6) != 0)) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0da9;
            iVar4 = fcn.180199810(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6)
                                  , *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6), *(int64_t *)(&stack0x00000050 + iVar6), 
                                  *(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x00000088 + iVar6));
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dba;
                iVar4 = fcn.180199550(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar6), *(int64_t *)(&stack0x00000048 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_78h + iVar6));
                if (iVar4 != 0) goto code_r0x0001801d0dc0;
            }
            iVar5 = 0;
            goto code_r0x0001801d0dc0;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e20;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e38;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e4a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e54;
        fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e5e;
        fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_30h + iVar6));
    } else {
code_r0x0001801d0dc0:
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dca;
        fcn.18021fe80(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0dd4;
        fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_30h + iVar6));
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0de0;
            iVar5 = fcn.1801ce740(in_RCX);
            if (iVar5 != 0) goto code_r0x0001801d0e87;
        }
    }
    if (*(int32_t *)(in_RCX + 0x48) == 0x300) {
        *(undefined4 *)(in_RCX + 0x340) = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e0a;
        fcn.1801c6e50(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        return 2;
    }
    *(undefined4 *)(in_RCX + 0x340) = 2;
    *(undefined4 *)(in_RCX + 0xb3c) = 0;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801d0e77;
    uVar7 = fcn.1801da790(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6));
    if ((int32_t)uVar7 == 0) {
        return uVar7;
    }
code_r0x0001801d0e87:
    if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
         (iVar5 = **(int32_t **)(in_RCX + 0x18), iVar5 < 0x304)) || (iVar5 == 0x10000)) ||
       ((*(uint64_t *)(in_RCX + 0x9a8) & 0x100000000) != 0)) {
        *(undefined4 *)(in_RCX + 0xb3c) = 0;
    }
    return (uint64_t)((*(int32_t *)(in_RCX + 0xba8) != 4) + 1);
}

// ============================================================
// Function: FUN_1801d0f20
// Address: 0x1801d0f20
// Size: 215 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801d0f20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    char cVar1;
    char cVar2;
    char cVar3;
    char *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    char *pcVar10;
    char **in_R8;
    int64_t aiStackX_8 [4];
    undefined8 uStack_20;
    int64_t var_18h;
    
    uStack_20 = 0x1801d0f2f;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_R8[1] == (char *)0x0) {
code_r0x0001801d11c0:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d11c5;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d11dd;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18)
                      , *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d11f3;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        return 0;
    }
    cVar1 = **in_R8;
    *in_R8 = *in_R8 + 1;
    in_R8[1] = in_R8[1] + -1;
    if (cVar1 != '\x01') goto code_r0x0001801d11c0;
    uVar8 = *(undefined8 *)(in_RCX + 0xa48);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0f80;
    fcn.180224990(uVar8, 0x1804b3b98, 0xb69);
    iVar7 = *(int64_t *)(in_RCX + 0xa58);
    *(undefined8 *)(in_RCX + 0xa48) = 0;
    *(undefined8 *)(in_RCX + 0xa50) = 0;
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0fa1;
        iVar7 = func_0x000180221f20();
        *(int64_t *)(in_RCX + 0xa58) = iVar7;
    }
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
        (iVar5 = **(int32_t **)(in_RCX + 0x18), iVar5 < 0x304)) || (iVar5 == 0x10000)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0fd8;
        func_0x000180222290(iVar7, 0x180196ec0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0fe7;
        fcn.180222050(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18)
                      , *(int64_t *)(&stack0x00000040 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0fec;
        uVar8 = func_0x000180221f20();
        *(undefined8 *)(in_RCX + 0xa58) = uVar8;
    }
    pcVar4 = in_R8[1];
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
    if (pcVar4 == (char *)0x0) {
        return 1;
    }
    if ((char *)0x2 < pcVar4) {
        pcVar10 = *in_R8;
        cVar1 = *pcVar10;
        cVar2 = pcVar10[1];
        cVar3 = pcVar10[2];
        *in_R8 = pcVar10 + 3;
        pcVar10 = (char *)(uint64_t)CONCAT21(CONCAT11(cVar1, cVar2), cVar3);
        in_R8[1] = pcVar4 + -3;
        if (pcVar4 + -3 == pcVar10) {
            if (pcVar10 == (char *)0x0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1067;
            iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1074;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d108c;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), *(int64_t *)((int64_t)&arg_38h + iVar6))
                ;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10c5;
                iVar5 = func_0x0001801b4900(in_R8, iVar7, pcVar10);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10ce;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10e6;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10fc;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1111;
                    fcn.180224990(iVar7, 0x1804b3b98, 0xb89);
                    return 0;
                }
                *(int64_t *)((int64_t)&arg_38h + iVar6) = iVar7;
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1127;
                iVar9 = func_0x00018023f280(0, (int64_t)&arg_38h + iVar6, 
                                            (uint64_t)CONCAT21(CONCAT11(cVar1, cVar2), cVar3));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d113f;
                fcn.180224990(iVar7, 0x1804b3b98, 0xb8e);
                if (iVar9 != 0) {
                    uVar8 = *(undefined8 *)(in_RCX + 0xa58);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1186;
                    func_0x000180221da0(uVar8, iVar9, in_RDX & 0xffffffff);
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1149;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1161;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), *(int64_t *)((int64_t)&arg_38h + iVar6))
                ;
            }
            goto code_r0x0001801d109a;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1195;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d11ad;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                  *(int64_t *)((int64_t)&arg_38h + iVar6));
code_r0x0001801d109a:
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10a2;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801d0ff7
// Address: 0x1801d0ff7
// Size: 192 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801d0f20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    char cVar1;
    char cVar2;
    char cVar3;
    char *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    char *pcVar10;
    char **in_R8;
    int64_t aiStackX_8 [4];
    undefined8 uStack_20;
    int64_t var_18h;
    
    uStack_20 = 0x1801d0f2f;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_R8[1] == (char *)0x0) {
code_r0x0001801d11c0:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d11c5;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d11dd;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18)
                      , *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d11f3;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        return 0;
    }
    cVar1 = **in_R8;
    *in_R8 = *in_R8 + 1;
    in_R8[1] = in_R8[1] + -1;
    if (cVar1 != '\x01') goto code_r0x0001801d11c0;
    uVar8 = *(undefined8 *)(in_RCX + 0xa48);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0f80;
    fcn.180224990(uVar8, 0x1804b3b98, 0xb69);
    iVar7 = *(int64_t *)(in_RCX + 0xa58);
    *(undefined8 *)(in_RCX + 0xa48) = 0;
    *(undefined8 *)(in_RCX + 0xa50) = 0;
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0fa1;
        iVar7 = func_0x000180221f20();
        *(int64_t *)(in_RCX + 0xa58) = iVar7;
    }
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
        (iVar5 = **(int32_t **)(in_RCX + 0x18), iVar5 < 0x304)) || (iVar5 == 0x10000)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0fd8;
        func_0x000180222290(iVar7, 0x180196ec0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0fe7;
        fcn.180222050(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18)
                      , *(int64_t *)(&stack0x00000040 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0fec;
        uVar8 = func_0x000180221f20();
        *(undefined8 *)(in_RCX + 0xa58) = uVar8;
    }
    pcVar4 = in_R8[1];
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
    if (pcVar4 == (char *)0x0) {
        return 1;
    }
    if ((char *)0x2 < pcVar4) {
        pcVar10 = *in_R8;
        cVar1 = *pcVar10;
        cVar2 = pcVar10[1];
        cVar3 = pcVar10[2];
        *in_R8 = pcVar10 + 3;
        pcVar10 = (char *)(uint64_t)CONCAT21(CONCAT11(cVar1, cVar2), cVar3);
        in_R8[1] = pcVar4 + -3;
        if (pcVar4 + -3 == pcVar10) {
            if (pcVar10 == (char *)0x0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1067;
            iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1074;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d108c;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), *(int64_t *)((int64_t)&arg_38h + iVar6))
                ;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10c5;
                iVar5 = func_0x0001801b4900(in_R8, iVar7, pcVar10);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10ce;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10e6;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10fc;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1111;
                    fcn.180224990(iVar7, 0x1804b3b98, 0xb89);
                    return 0;
                }
                *(int64_t *)((int64_t)&arg_38h + iVar6) = iVar7;
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1127;
                iVar9 = func_0x00018023f280(0, (int64_t)&arg_38h + iVar6, 
                                            (uint64_t)CONCAT21(CONCAT11(cVar1, cVar2), cVar3));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d113f;
                fcn.180224990(iVar7, 0x1804b3b98, 0xb8e);
                if (iVar9 != 0) {
                    uVar8 = *(undefined8 *)(in_RCX + 0xa58);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1186;
                    func_0x000180221da0(uVar8, iVar9, in_RDX & 0xffffffff);
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1149;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1161;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), *(int64_t *)((int64_t)&arg_38h + iVar6))
                ;
            }
            goto code_r0x0001801d109a;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1195;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d11ad;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                  *(int64_t *)((int64_t)&arg_38h + iVar6));
code_r0x0001801d109a:
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10a2;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801d10b7
// Address: 0x1801d10b7
// Size: 265 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801d0f20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    char cVar1;
    char cVar2;
    char cVar3;
    char *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    char *pcVar10;
    char **in_R8;
    int64_t aiStackX_8 [4];
    undefined8 uStack_20;
    int64_t var_18h;
    
    uStack_20 = 0x1801d0f2f;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_R8[1] == (char *)0x0) {
code_r0x0001801d11c0:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d11c5;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d11dd;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18)
                      , *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d11f3;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        return 0;
    }
    cVar1 = **in_R8;
    *in_R8 = *in_R8 + 1;
    in_R8[1] = in_R8[1] + -1;
    if (cVar1 != '\x01') goto code_r0x0001801d11c0;
    uVar8 = *(undefined8 *)(in_RCX + 0xa48);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0f80;
    fcn.180224990(uVar8, 0x1804b3b98, 0xb69);
    iVar7 = *(int64_t *)(in_RCX + 0xa58);
    *(undefined8 *)(in_RCX + 0xa48) = 0;
    *(undefined8 *)(in_RCX + 0xa50) = 0;
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0fa1;
        iVar7 = func_0x000180221f20();
        *(int64_t *)(in_RCX + 0xa58) = iVar7;
    }
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
        (iVar5 = **(int32_t **)(in_RCX + 0x18), iVar5 < 0x304)) || (iVar5 == 0x10000)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0fd8;
        func_0x000180222290(iVar7, 0x180196ec0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0fe7;
        fcn.180222050(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18)
                      , *(int64_t *)(&stack0x00000040 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0fec;
        uVar8 = func_0x000180221f20();
        *(undefined8 *)(in_RCX + 0xa58) = uVar8;
    }
    pcVar4 = in_R8[1];
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
    if (pcVar4 == (char *)0x0) {
        return 1;
    }
    if ((char *)0x2 < pcVar4) {
        pcVar10 = *in_R8;
        cVar1 = *pcVar10;
        cVar2 = pcVar10[1];
        cVar3 = pcVar10[2];
        *in_R8 = pcVar10 + 3;
        pcVar10 = (char *)(uint64_t)CONCAT21(CONCAT11(cVar1, cVar2), cVar3);
        in_R8[1] = pcVar4 + -3;
        if (pcVar4 + -3 == pcVar10) {
            if (pcVar10 == (char *)0x0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1067;
            iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1074;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d108c;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), *(int64_t *)((int64_t)&arg_38h + iVar6))
                ;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10c5;
                iVar5 = func_0x0001801b4900(in_R8, iVar7, pcVar10);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10ce;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10e6;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10fc;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1111;
                    fcn.180224990(iVar7, 0x1804b3b98, 0xb89);
                    return 0;
                }
                *(int64_t *)((int64_t)&arg_38h + iVar6) = iVar7;
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1127;
                iVar9 = func_0x00018023f280(0, (int64_t)&arg_38h + iVar6, 
                                            (uint64_t)CONCAT21(CONCAT11(cVar1, cVar2), cVar3));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d113f;
                fcn.180224990(iVar7, 0x1804b3b98, 0xb8e);
                if (iVar9 != 0) {
                    uVar8 = *(undefined8 *)(in_RCX + 0xa58);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1186;
                    func_0x000180221da0(uVar8, iVar9, in_RDX & 0xffffffff);
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1149;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1161;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), *(int64_t *)((int64_t)&arg_38h + iVar6))
                ;
            }
            goto code_r0x0001801d109a;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1195;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d11ad;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                  *(int64_t *)((int64_t)&arg_38h + iVar6));
code_r0x0001801d109a:
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10a2;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801d11c0
// Address: 0x1801d11c0
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801d0f20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    char cVar1;
    char cVar2;
    char cVar3;
    char *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    char *pcVar10;
    char **in_R8;
    int64_t aiStackX_8 [4];
    undefined8 uStack_20;
    int64_t var_18h;
    
    uStack_20 = 0x1801d0f2f;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_R8[1] == (char *)0x0) {
code_r0x0001801d11c0:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d11c5;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d11dd;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18)
                      , *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d11f3;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar6));
        return 0;
    }
    cVar1 = **in_R8;
    *in_R8 = *in_R8 + 1;
    in_R8[1] = in_R8[1] + -1;
    if (cVar1 != '\x01') goto code_r0x0001801d11c0;
    uVar8 = *(undefined8 *)(in_RCX + 0xa48);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0f80;
    fcn.180224990(uVar8, 0x1804b3b98, 0xb69);
    iVar7 = *(int64_t *)(in_RCX + 0xa58);
    *(undefined8 *)(in_RCX + 0xa48) = 0;
    *(undefined8 *)(in_RCX + 0xa50) = 0;
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0fa1;
        iVar7 = func_0x000180221f20();
        *(int64_t *)(in_RCX + 0xa58) = iVar7;
    }
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
        (iVar5 = **(int32_t **)(in_RCX + 0x18), iVar5 < 0x304)) || (iVar5 == 0x10000)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0fd8;
        func_0x000180222290(iVar7, 0x180196ec0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0fe7;
        fcn.180222050(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18)
                      , *(int64_t *)(&stack0x00000040 + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d0fec;
        uVar8 = func_0x000180221f20();
        *(undefined8 *)(in_RCX + 0xa58) = uVar8;
    }
    pcVar4 = in_R8[1];
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
    if (pcVar4 == (char *)0x0) {
        return 1;
    }
    if ((char *)0x2 < pcVar4) {
        pcVar10 = *in_R8;
        cVar1 = *pcVar10;
        cVar2 = pcVar10[1];
        cVar3 = pcVar10[2];
        *in_R8 = pcVar10 + 3;
        pcVar10 = (char *)(uint64_t)CONCAT21(CONCAT11(cVar1, cVar2), cVar3);
        in_R8[1] = pcVar4 + -3;
        if (pcVar4 + -3 == pcVar10) {
            if (pcVar10 == (char *)0x0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1067;
            iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1074;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d108c;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), *(int64_t *)((int64_t)&arg_38h + iVar6))
                ;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10c5;
                iVar5 = func_0x0001801b4900(in_R8, iVar7, pcVar10);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10ce;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10e6;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10fc;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1111;
                    fcn.180224990(iVar7, 0x1804b3b98, 0xb89);
                    return 0;
                }
                *(int64_t *)((int64_t)&arg_38h + iVar6) = iVar7;
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1127;
                iVar9 = func_0x00018023f280(0, (int64_t)&arg_38h + iVar6, 
                                            (uint64_t)CONCAT21(CONCAT11(cVar1, cVar2), cVar3));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d113f;
                fcn.180224990(iVar7, 0x1804b3b98, 0xb8e);
                if (iVar9 != 0) {
                    uVar8 = *(undefined8 *)(in_RCX + 0xa58);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1186;
                    func_0x000180221da0(uVar8, iVar9, in_RDX & 0xffffffff);
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1149;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1161;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), *(int64_t *)((int64_t)&arg_38h + iVar6))
                ;
            }
            goto code_r0x0001801d109a;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d1195;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d11ad;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar6), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 8), 
                  *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x10), *(int64_t *)((int64_t)aiStackX_8 + iVar6 + 0x18), 
                  *(int64_t *)((int64_t)&arg_38h + iVar6));
code_r0x0001801d109a:
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1801d10a2;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801d1200
// Address: 0x1801d1200
// Size: 1205 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

char fcn.1801d1200(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    uint8_t *puVar7;
    int32_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t in_RCX;
    uint8_t *puVar12;
    uint8_t **in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    uint8_t *puVar13;
    undefined8 unaff_R14;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t var_10h;
    
    uStack_18 = 0x1801d120d;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    iVar11 = *(int64_t *)(in_RCX + 0x408);
    iVar2 = *(int64_t *)(in_RCX + 0x118);
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d1254;
        uVar10 = func_0x000180224e40(iVar2, 4, 0x1804b3b98, 0xa2c);
        *(undefined8 *)(in_RCX + 0x408) = uVar10;
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d1238;
        fcn.1804986e0(iVar11, 0, iVar2 * 4);
    }
    iVar11 = *(int64_t *)(in_RCX + 0x408);
    *(undefined8 *)((int64_t)&arg_68h + iVar9) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_70h + iVar9) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_40h + iVar9) = unaff_R14;
    if (iVar11 == 0) {
        return '\0';
    }
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar8 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar8)) && (iVar8 != 0x10000)) {
        uVar1 = *(uint8_t *)(in_RCX + 0x84);
        *(undefined8 *)((int64_t)&arg_60h + iVar9) = 0;
        if ((uVar1 & 1) != 0) {
            return '\x01';
        }
        uVar10 = *(undefined8 *)(in_RCX + 0x348);
        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d12dd;
        fcn.180224990(uVar10, 0x1804b3b98, 0xa40);
        uVar10 = *(undefined8 *)(in_RCX + 0xbb0);
        *(undefined8 *)(in_RCX + 0x348) = 0;
        *(undefined8 *)(in_RCX + 0x350) = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d1304;
        fcn.180224990(uVar10, 0x1804b3b98, 0xa43);
        *(undefined8 *)(in_RCX + 0xbb0) = 0;
        *(undefined8 *)(in_RCX + 3000) = 0;
        puVar7 = *in_RDX;
        puVar12 = in_RDX[1];
        puVar13 = in_RDX[1];
        *(uint8_t **)((int64_t)&var_20h + iVar9) = puVar7;
        *(uint8_t **)((int64_t)&arg_28h + iVar9) = puVar12;
        if (puVar13 != (uint8_t *)0x0) {
            puVar13 = puVar13 + -1;
            puVar12 = (uint8_t *)(uint64_t)*puVar7;
            if (puVar12 <= puVar13) {
                *(uint8_t **)((int64_t)&var_20h + iVar9) = puVar12 + (int64_t)(puVar7 + 1);
                *(int64_t *)((int64_t)&arg_28h + iVar9) = (int64_t)puVar13 - (int64_t)puVar12;
                uVar3 = *(undefined4 *)((int64_t)&var_20h + iVar9);
                uVar4 = *(undefined4 *)((int64_t)&var_20h + iVar9 + 4);
                uVar5 = *(undefined4 *)((int64_t)&arg_28h + iVar9);
                uVar6 = *(undefined4 *)((int64_t)&arg_28h + iVar9 + 4);
                *(uint8_t **)((int64_t)&arg_28h + iVar9) = puVar12;
                *(uint8_t **)((int64_t)&var_20h + iVar9) = puVar7 + 1;
                *(undefined4 *)in_RDX = uVar3;
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar4;
                *(undefined4 *)(in_RDX + 1) = uVar5;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar6;
                *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d1376;
                iVar8 = func_0x0001801cc620((int64_t)&var_20h + iVar9, in_RCX + 0xbb0);
                if (iVar8 != 0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d138b;
                    iVar8 = func_0x0001801b4960(in_RDX, (int64_t)&arg_30h + iVar9);
                    if (iVar8 == 0) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d1394;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar9), 
                                      *(int64_t *)((int64_t)&var_18h + iVar9));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d13ac;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar9), 
                                      *(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9), *(int64_t *)((int64_t)&arg_40h + iVar9));
                        goto code_r0x0001801d168f;
                    }
                    *(undefined4 *)((int64_t)&var_18h + iVar9) = 1;
                    *(undefined8 *)((int64_t)&iStackX_10 + iVar9) = 0;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d13dc;
                    iVar8 = func_0x0001801c9450(in_RCX, (int64_t)&arg_30h + iVar9, 0x4000, (int64_t)&arg_60h + iVar9);
                    if (iVar8 == 0) {
code_r0x0001801d145a:
                        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d1471;
                        fcn.180224990(*(undefined8 *)((int64_t)&arg_60h + iVar9), 0x1804b3b98, 0xa57);
                        return '\0';
                    }
                    *(undefined4 *)((int64_t)&var_18h + iVar9) = 1;
                    *(undefined8 *)((int64_t)&iStackX_10 + iVar9) = 0;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d1402;
                    iVar8 = func_0x0001801c9b70(in_RCX, 0x4000, *(undefined8 *)((int64_t)&arg_60h + iVar9), 0);
                    if (iVar8 == 0) goto code_r0x0001801d145a;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d141d;
                    fcn.180224990(*(undefined8 *)((int64_t)&arg_60h + iVar9), 0x1804b3b98, 0xa5a);
                    *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d1425;
                    iVar8 = func_0x0001801ab7c0(in_RCX);
                    if (iVar8 == 0) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d1432;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar9), 
                                      *(int64_t *)((int64_t)&var_18h + iVar9));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d144a;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar9), 
                                      *(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9), *(int64_t *)((int64_t)&arg_40h + iVar9));
                        goto code_r0x0001801d168f;
                    }
                    goto code_r0x0001801d1612;
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d147b;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9));
    } else {
        puVar7 = *in_RDX;
        puVar12 = in_RDX[1];
        puVar13 = in_RDX[1];
        *(uint8_t **)((int64_t)&var_20h + iVar9) = puVar7;
        *(uint8_t **)((int64_t)&arg_28h + iVar9) = puVar12;
        if (puVar13 != (uint8_t *)0x0) {
            puVar13 = puVar13 + -1;
            puVar12 = (uint8_t *)(uint64_t)*puVar7;
            if (puVar12 <= puVar13) {
                *(int64_t *)((int64_t)&arg_28h + iVar9) = (int64_t)puVar13 - (int64_t)puVar12;
                *(uint8_t **)((int64_t)&var_20h + iVar9) = puVar7 + 1 + (int64_t)puVar12;
                uVar3 = *(undefined4 *)((int64_t)&var_20h + iVar9 + 4);
                uVar4 = *(undefined4 *)((int64_t)&arg_28h + iVar9);
                uVar5 = *(undefined4 *)((int64_t)&arg_28h + iVar9 + 4);
                *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_20h + iVar9);
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar3;
                *(undefined4 *)(in_RDX + 1) = uVar4;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar5;
                uVar10 = *(undefined8 *)(in_RCX + 0x348);
                *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d14e4;
                fcn.180224990(uVar10, 0x1804a9450, 0x1d9);
                *(undefined8 *)(in_RCX + 0x348) = 0;
                *(undefined8 *)(in_RCX + 0x350) = 0;
                if (puVar12 != (uint8_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d1510;
                    iVar11 = func_0x000180223170(puVar7 + 1, puVar12, 0x1804a9450, 0x1e2);
                    *(int64_t *)(in_RCX + 0x348) = iVar11;
                    if (iVar11 == 0) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d155d;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar9), 
                                      *(int64_t *)((int64_t)&var_18h + iVar9));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d1575;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar9), 
                                      *(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9), *(int64_t *)((int64_t)&arg_40h + iVar9));
                        goto code_r0x0001801d168f;
                    }
                    *(uint8_t **)(in_RCX + 0x350) = puVar12;
                }
                if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 2) == 0) {
code_r0x0001801d15ff:
                    *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d160a;
                    iVar8 = func_0x0001801ae830(in_RCX, in_RDX);
                    if (iVar8 == 0) {
                        return '\0';
                    }
code_r0x0001801d1612:
                    if (in_RDX[1] == (uint8_t *)0x0) {
                        *(undefined4 *)(in_RCX + 0x340) = 1;
                        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                            (iVar8 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar8)) && (iVar8 != 0x10000)) {
                            return (*(int32_t *)(in_RCX + 0xba8) != 4) + '\x02';
                        }
                        return '\x02';
                    }
                    *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d161e;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9));
                } else {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d1545;
                    iVar8 = func_0x0001801b4960(in_RDX, (int64_t)&arg_30h + iVar9);
                    if (iVar8 != 0) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d1595;
                        iVar8 = func_0x0001801ab8b0(in_RCX, (int64_t)&arg_30h + iVar9, 0);
                        if (iVar8 == 0) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d159e;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d15b6;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9), 
                                          *(int64_t *)((int64_t)&var_20h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar9));
                            goto code_r0x0001801d168f;
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d15ce;
                        iVar8 = func_0x0001801ab7c0(in_RCX);
                        if (iVar8 == 0) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d15d7;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d15ef;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar9), 
                                          *(int64_t *)((int64_t)&var_18h + iVar9), 
                                          *(int64_t *)((int64_t)&var_20h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar9), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar9));
                            goto code_r0x0001801d168f;
                        }
                        goto code_r0x0001801d15ff;
                    }
                    *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d154e;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9));
                }
                goto code_r0x0001801d1671;
            }
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d166c;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9));
    }
code_r0x0001801d1671:
    *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d1684;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar9), *(int64_t *)((int64_t)&var_18h + iVar9), 
                  *(int64_t *)((int64_t)&var_20h + iVar9), *(int64_t *)((int64_t)&arg_28h + iVar9), 
                  *(int64_t *)((int64_t)&arg_40h + iVar9));
code_r0x0001801d168f:
    *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801d169a;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar9));
    return '\0';
}

// ============================================================
// Function: FUN_1801d16c0
// Address: 0x1801d16c0
// Size: 252 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint32_t fcn.1801d16c0(int64_t arg_28h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d16d0;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar1 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801d16df;
    iVar5 = fcn.1801ce590(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000048 + iVar6));
    if (iVar5 != 0) {
        if ((*(int32_t *)(in_RCX + 0xa20) == -1) || (pcVar2 = *(code **)(iVar1 + 0x268), pcVar2 == (code *)0x0)) {
code_r0x0001801d1780:
            if (*(int64_t *)(in_RCX + 0xb68) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801d1792;
                iVar5 = fcn.180198540(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar6));
                if (iVar5 == 0) {
                    return ~*(uint32_t *)(in_RCX + 0x948) & 1;
                }
            }
            return 1;
        }
        uVar3 = *(undefined8 *)(iVar1 + 0x270);
        uVar4 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801d170d;
        iVar5 = (*pcVar2)(uVar4, uVar3);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801d1716;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801d172e;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                          *(int64_t *)(&stack0x00000048 + iVar6));
        } else {
            if (-1 < iVar5) goto code_r0x0001801d1780;
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801d1758;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801d1770;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                          *(int64_t *)(&stack0x00000048 + iVar6));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801d1744;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar6));
    }
    return 0;
}

// ============================================================
// Function: FUN_1801d17c0
// Address: 0x1801d17c0
// Size: 1609 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_38h

undefined8 fcn.1801d17c0(int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h)
{
    undefined uVar1;
    undefined uVar2;
    uint32_t uVar3;
    undefined8 uVar4;
    undefined *puVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int32_t iVar12;
    int64_t iVar13;
    undefined8 uVar14;
    int64_t iVar15;
    int64_t in_RCX;
    undefined8 *in_RDX;
    uint64_t uVar16;
    uint64_t uVar17;
    undefined8 *puVar18;
    int64_t iVar19;
    int64_t iVar20;
    int64_t var_8h;
    undefined8 uStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_38h;
    int64_t var_10h;
    
    uStack_40 = 0x1801d17da;
    iVar13 = fcn.18045a350();
    iVar13 = -iVar13;
    iVar20 = *(int64_t *)(in_RCX + 0x300);
    puVar18 = *(undefined8 **)(in_RCX + 8);
    uVar8 = *(undefined4 *)in_RDX;
    uVar9 = *(undefined4 *)((int64_t)in_RDX + 4);
    uVar10 = *(undefined4 *)(in_RDX + 1);
    uVar11 = *(undefined4 *)((int64_t)in_RDX + 0xc);
    uVar4 = *(undefined8 *)(in_RCX + 0x4e0);
    *(undefined8 *)((int64_t)&arg_70h + iVar13) = 0;
    iVar19 = 0;
    uVar3 = *(uint32_t *)(iVar20 + 0x1c);
    *(undefined8 *)((int64_t)&arg_68h + iVar13) = 0;
    *(undefined8 **)((int64_t)&arg_78h + iVar13) = puVar18;
    *(undefined4 *)((int64_t)&var_18h + iVar13) = uVar8;
    *(undefined4 *)((int64_t)&var_18h + iVar13 + 4) = uVar9;
    *(undefined4 *)((int64_t)&var_20h + iVar13) = uVar10;
    *(undefined4 *)((int64_t)&var_20h + iVar13 + 4) = uVar11;
    *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1823;
    fcn.18022ecc0(uVar4);
    *(undefined8 *)(in_RCX + 0x4e0) = 0;
    if ((uVar3 & 0x1c8) != 0) {
        puVar5 = (undefined *)*in_RDX;
        uVar4 = in_RDX[1];
        uVar16 = in_RDX[1];
        *(undefined **)((int64_t)&uStackX_10 + iVar13 + -8) = puVar5;
        *(undefined8 *)((int64_t)&uStackX_10 + iVar13) = uVar4;
        if (1 < uVar16) {
            uVar16 = uVar16 - 2;
            uVar17 = (uint64_t)CONCAT11(*puVar5, puVar5[1]);
            if (uVar17 <= uVar16) {
                *(undefined **)((int64_t)&uStackX_10 + iVar13 + -8) = puVar5 + 2 + uVar17;
                *(uint64_t *)((int64_t)&uStackX_10 + iVar13) = uVar16 - uVar17;
                uVar8 = *(undefined4 *)((int64_t)&uStackX_10 + iVar13 + -4);
                uVar9 = *(undefined4 *)((int64_t)&uStackX_10 + iVar13);
                uVar10 = *(undefined4 *)((int64_t)&uStackX_10 + iVar13 + 4);
                *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&uStackX_10 + iVar13 + -8);
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar8;
                *(undefined4 *)(in_RDX + 1) = uVar9;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar10;
                if (uVar17 < 0x101) {
                    iVar20 = *(int64_t *)(in_RCX + 0x8f8);
                    uVar4 = *(undefined8 *)(iVar20 + 0x2a0);
                    if (uVar17 == 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d18e8;
                        fcn.180224990(uVar4, 0x1804b3b98, 0x8b1);
                        *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2a0) = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1910;
                        fcn.180224990(uVar4, 0x1804a9450, 0x1f6);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1928;
                        iVar15 = func_0x000180223270(puVar5 + 2, uVar17, 0x1804a9450, 0x1f9);
                        *(int64_t *)(iVar20 + 0x2a0) = iVar15;
                        if (iVar15 == 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1939;
                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), 
                                          *(int64_t *)((int64_t)&var_10h + iVar13));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1951;
                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), 
                                          *(int64_t *)((int64_t)&var_10h + iVar13), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar13), 
                                          *(int64_t *)(&stack0x00000000 + iVar13), 
                                          *(int64_t *)((int64_t)&var_18h + iVar13));
                            goto code_r0x0001801d1def;
                        }
                    }
                    puVar18 = *(undefined8 **)((int64_t)&arg_78h + iVar13);
                    goto code_r0x0001801d1994;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d189b;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13))
                ;
                *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d18b3;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13)
                              , *(int64_t *)(&stack0xfffffffffffffff8 + iVar13), *(int64_t *)(&stack0x00000000 + iVar13)
                              , *(int64_t *)((int64_t)&var_18h + iVar13));
                iVar19 = 0;
                goto code_r0x0001801d1def;
            }
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1966;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13));
code_r0x0001801d1972:
        *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d197e;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar13), *(int64_t *)(&stack0x00000000 + iVar13), 
                      *(int64_t *)((int64_t)&var_18h + iVar13));
        goto code_r0x0001801d1def;
    }
code_r0x0001801d1994:
    if ((uVar3 & 0x48) == 0) {
        if ((uVar3 & 0x20) == 0) {
            if ((uVar3 & 0x102) == 0) {
                if ((uVar3 & 0x84) == 0) {
                    if (uVar3 != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1d55;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), 
                                      *(int64_t *)((int64_t)&var_10h + iVar13));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1d6d;
                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), 
                                      *(int64_t *)((int64_t)&var_10h + iVar13), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar13), 
                                      *(int64_t *)(&stack0x00000000 + iVar13), *(int64_t *)((int64_t)&var_18h + iVar13))
                        ;
                        goto code_r0x0001801d1def;
                    }
                    goto code_r0x0001801d1d7a;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d19f3;
                iVar12 = func_0x0001801d3990(in_RCX, in_RDX, (int64_t)&arg_68h + iVar13);
            } else {
                *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d19d4;
                iVar12 = func_0x0001801d3500(in_RCX, in_RDX, (int64_t)&arg_68h + iVar13);
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d19b7;
            iVar12 = func_0x0001801d3bf0(in_RCX, in_RDX, (int64_t)&arg_68h + iVar13);
        }
        iVar20 = 0;
        if (iVar12 == 0) goto code_r0x0001801d1dfa;
        iVar15 = *(int64_t *)((int64_t)&arg_68h + iVar13);
        if (iVar15 == 0) goto code_r0x0001801d1d7a;
        uVar4 = *(undefined8 *)((int64_t)&var_18h + iVar13);
        uVar16 = in_RDX[1];
        *(undefined8 *)((int64_t)&arg_68h + iVar13) = 0;
        uVar17 = *(uint64_t *)((int64_t)&var_20h + iVar13) - uVar16;
        if ((*(uint64_t *)((int64_t)&var_20h + iVar13) < uVar17) || (0x7fffffffffffffff < uVar17)) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1d29;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13));
            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1d41;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar13), *(int64_t *)(&stack0x00000000 + iVar13), 
                          *(int64_t *)((int64_t)&var_18h + iVar13));
        } else if ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1b28;
            iVar12 = func_0x0001801ac160(in_RCX, iVar15);
            if (iVar12 != 0) goto code_r0x0001801d1aa9;
            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1b35;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13));
            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1b4d;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar13), *(int64_t *)(&stack0x00000000 + iVar13), 
                          *(int64_t *)((int64_t)&var_18h + iVar13));
        } else if (uVar16 < 2) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1afa;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13));
            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1b12;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar13), *(int64_t *)(&stack0x00000000 + iVar13), 
                          *(int64_t *)((int64_t)&var_18h + iVar13));
        } else {
            puVar5 = (undefined *)*in_RDX;
            uVar1 = puVar5[1];
            uVar2 = *puVar5;
            *in_RDX = puVar5 + 2;
            in_RDX[1] = uVar16 - 2;
            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1aa1;
            iVar12 = func_0x0001801a98b0(in_RCX, CONCAT11(uVar2, uVar1), iVar15);
            iVar20 = iVar19;
            if (iVar12 < 1) goto code_r0x0001801d1dfa;
code_r0x0001801d1aa9:
            uVar14 = *(undefined8 *)(in_RCX + 0x400);
            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1ac0;
            iVar12 = func_0x0001801ab730(puVar18, uVar14, (int64_t)&arg_68h + iVar13);
            if (iVar12 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1acd;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13))
                ;
                *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1ae5;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13)
                              , *(int64_t *)(&stack0xfffffffffffffff8 + iVar13), *(int64_t *)(&stack0x00000000 + iVar13)
                              , *(int64_t *)((int64_t)&var_18h + iVar13));
            } else {
                *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1b6a;
                iVar12 = func_0x0001801b4960(in_RDX, (int64_t)&uStackX_10 + iVar13 + -8);
                if ((iVar12 == 0) || (in_RDX[1] != 0)) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1d13;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), 
                                  *(int64_t *)((int64_t)&var_10h + iVar13));
                    goto code_r0x0001801d1972;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1b81;
                iVar19 = func_0x000180215470();
                if (iVar19 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1b8e;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), 
                                  *(int64_t *)((int64_t)&var_10h + iVar13));
                } else {
                    if (*(int64_t *)((int64_t)&arg_68h + iVar13) == 0) {
                        uVar14 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1bcc;
                        uVar14 = func_0x00018020f750();
                    }
                    uVar6 = puVar18[0x8c];
                    uVar7 = *puVar18;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar13) = 0;
                    *(int64_t *)((int64_t)&var_10h + iVar13) = iVar15;
                    *(undefined8 *)(&stack0xffffffffffffffe8 + iVar13) = uVar6;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1bfe;
                    iVar12 = func_0x00018025cbd0(iVar19, (int64_t)&arg_70h + iVar13, uVar14, uVar7);
                    if (iVar12 < 1) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1c07;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), 
                                      *(int64_t *)((int64_t)&var_10h + iVar13));
                    } else {
                        if ((*(int64_t *)(in_RCX + 0x400) == 0) ||
                           (*(int32_t *)(*(int64_t *)(in_RCX + 0x400) + 0x1c) != 0x390)) {
code_r0x0001801d1c5e:
                            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1c74;
                            iVar15 = func_0x0001801ae2b0(in_RCX, (int64_t)&arg_78h + iVar13, uVar4, uVar17);
                            iVar20 = iVar19;
                            if (iVar15 == 0) goto code_r0x0001801d1dfa;
                            uVar4 = *(undefined8 *)((int64_t)&uStackX_10 + iVar13 + -8);
                            *(int64_t *)(&stack0xffffffffffffffe8 + iVar13) = iVar15;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1c9c;
                            iVar12 = func_0x00018025c530(iVar19, uVar4, *(undefined8 *)((int64_t)&uStackX_10 + iVar13), 
                                                         *(undefined8 *)((int64_t)&arg_78h + iVar13));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1cb8;
                            fcn.180224990(*(undefined8 *)((int64_t)&arg_78h + iVar13), 0x1804b3b98, 0xa06);
                            if (0 < iVar12) {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1cf1;
                                func_0x000180215310(iVar19);
                                return 3;
                            }
                            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1cc1;
                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), 
                                          *(int64_t *)((int64_t)&var_10h + iVar13));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1cd9;
                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), 
                                          *(int64_t *)((int64_t)&var_10h + iVar13), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar13), 
                                          *(int64_t *)(&stack0x00000000 + iVar13), 
                                          *(int64_t *)((int64_t)&var_18h + iVar13));
                            goto code_r0x0001801d1def;
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1c35;
                        iVar12 = func_0x00018025dd20(*(undefined8 *)((int64_t)&arg_70h + iVar13), 6);
                        if (0 < iVar12) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1c4b;
                            iVar12 = func_0x00018025de80(*(undefined8 *)((int64_t)&arg_70h + iVar13), 0xffffffff);
                            if (0 < iVar12) goto code_r0x0001801d1c5e;
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1c54;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), 
                                      *(int64_t *)((int64_t)&var_10h + iVar13));
                    }
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1ba6;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13)
                              , *(int64_t *)(&stack0xfffffffffffffff8 + iVar13), *(int64_t *)(&stack0x00000000 + iVar13)
                              , *(int64_t *)((int64_t)&var_18h + iVar13));
            }
        }
    } else {
code_r0x0001801d1d7a:
        if (((*(uint8_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20) & 0x44) == 0) && ((uVar3 & 0x1c8) == 0)) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1d94;
            iVar12 = fcn.1801ce590(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), 
                                   *(int64_t *)((int64_t)&var_10h + iVar13), 
                                   *(int64_t *)(&stack0xfffffffffffffff8 + iVar13), 
                                   *(int64_t *)((int64_t)&var_18h + iVar13));
            iVar20 = iVar19;
            if (iVar12 == 0) goto code_r0x0001801d1dfa;
            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1d9d;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13));
            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1db5;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar13), *(int64_t *)(&stack0x00000000 + iVar13), 
                          *(int64_t *)((int64_t)&var_18h + iVar13));
        } else {
            if (in_RDX[1] == 0) {
                return 3;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1dcc;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13));
            *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1de4;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar13), *(int64_t *)(&stack0x00000000 + iVar13), 
                          *(int64_t *)((int64_t)&var_18h + iVar13));
        }
    }
code_r0x0001801d1def:
    *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1dfa;
    fcn.18019b5e0(*(int64_t *)((int64_t)&uStackX_10 + iVar13 + -8));
    iVar20 = iVar19;
code_r0x0001801d1dfa:
    *(undefined8 *)((int64_t)&uStack_40 + iVar13) = 0x1801d1e02;
    func_0x000180215310(iVar20);
    return 0;
}

// ============================================================
// Function: FUN_1801d1e10
// Address: 0x1801d1e10
// Size: 1724 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801d1e10(int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    uint8_t uVar3;
    uint8_t uVar4;
    uint8_t *puVar5;
    int32_t *piVar6;
    undefined8 uVar7;
    uint16_t uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int32_t iVar12;
    int32_t iVar13;
    int64_t iVar14;
    int64_t iVar15;
    undefined8 uVar16;
    int64_t in_RCX;
    uint8_t *puVar17;
    uint8_t **in_RDX;
    uint8_t *puVar18;
    int64_t iVar19;
    undefined4 uVar20;
    undefined8 *puVar21;
    int64_t *piVar22;
    uint32_t uVar23;
    int64_t iVar24;
    uint32_t uVar25;
    int64_t var_8h;
    undefined8 uStackX_10;
    undefined8 uStackX_18;
    int64_t var_20h;
    undefined8 uStack_48;
    int64_t var_18h;
    int64_t var_10h;
    
    uStack_48 = 0x1801d1e27;
    iVar14 = fcn.18045a350();
    iVar14 = -iVar14;
    puVar18 = in_RDX[1];
    *(undefined8 *)((int64_t)&arg_88h + iVar14) = 0;
    uVar20 = 0;
    *(undefined8 *)((int64_t)&arg_98h + iVar14) = 0;
    iVar24 = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar14) = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_90h + iVar14) = 0;
    if (puVar18 < (uint8_t *)0x4) {
code_r0x0001801d1fc1:
        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d1fc6;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar14), *(int64_t *)((int64_t)&var_18h + iVar14));
code_r0x0001801d1fcb:
        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d1fde;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar14), *(int64_t *)((int64_t)&var_18h + iVar14), 
                      *(int64_t *)((int64_t)&var_10h + iVar14), *(int64_t *)(&stack0xfffffffffffffff8 + iVar14), 
                      *(int64_t *)((int64_t)&uStackX_10 + iVar14));
        iVar19 = 0;
    } else {
        puVar5 = *in_RDX;
        uVar1 = *puVar5;
        uVar2 = puVar5[1];
        uVar3 = puVar5[2];
        uVar4 = puVar5[3];
        in_RDX[1] = puVar18 + -4;
        *in_RDX = puVar5 + 4;
        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
            (iVar12 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar12)) && (iVar12 != 0x10000)) {
            if ((uint8_t *)0x3 < puVar18 + -4) {
                uVar20 = CONCAT31(CONCAT21(CONCAT11(puVar5[4], puVar5[5]), puVar5[6]), puVar5[7]);
                *in_RDX = puVar5 + 8;
                in_RDX[1] = puVar18 + -8;
                puVar5 = *in_RDX;
                puVar17 = in_RDX[1];
                *(uint8_t **)((int64_t)&uStackX_10 + iVar14) = puVar5;
                *(uint8_t **)((int64_t)&uStackX_18 + iVar14) = puVar17;
                if (puVar18 + -8 != (uint8_t *)0x0) {
                    puVar17 = (uint8_t *)(uint64_t)*puVar5;
                    *(uint8_t **)((int64_t)&arg_98h + iVar14) = puVar5 + 1;
                    *(uint8_t **)((int64_t)&arg_90h + iVar14) = puVar17;
                    if (puVar17 <= puVar18 + -9) {
                        *(uint8_t **)((int64_t)&uStackX_10 + iVar14) = puVar17 + (int64_t)(puVar5 + 1);
                        *(int64_t *)((int64_t)&uStackX_18 + iVar14) = (int64_t)(puVar18 + -9) - (int64_t)puVar17;
                        uVar9 = *(undefined4 *)((int64_t)&uStackX_10 + iVar14 + 4);
                        uVar10 = *(undefined4 *)((int64_t)&uStackX_18 + iVar14);
                        uVar11 = *(undefined4 *)((int64_t)&uStackX_18 + iVar14 + 4);
                        *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&uStackX_10 + iVar14);
                        *(undefined4 *)((int64_t)in_RDX + 4) = uVar9;
                        *(undefined4 *)(in_RDX + 1) = uVar10;
                        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar11;
                        goto code_r0x0001801d1f59;
                    }
                }
            }
            goto code_r0x0001801d1fc1;
        }
code_r0x0001801d1f59:
        if (in_RDX[1] < (uint8_t *)0x2) goto code_r0x0001801d1fc1;
        puVar18 = *in_RDX;
        uVar8 = CONCAT11(*puVar18, puVar18[1]);
        uVar25 = (uint32_t)uVar8;
        *in_RDX = puVar18 + 2;
        puVar18 = in_RDX[1] + -2;
        in_RDX[1] = puVar18;
        piVar6 = *(int32_t **)(in_RCX + 0x18);
        uVar23 = *(uint32_t *)(*(int64_t *)(piVar6 + 0x36) + 0x50) & 8;
        iVar19 = iVar24;
        if (((uVar23 == 0) && (0x303 < *piVar6)) && (*piVar6 != 0x10000)) {
            if ((uVar8 != 0) && ((uint8_t *)(uint64_t)uVar25 <= puVar18)) {
code_r0x0001801d206f:
                puVar21 = (undefined8 *)(in_RCX + 0x8f8);
                uVar16 = *puVar21;
                *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d207c;
                iVar15 = func_0x00018019dc20(uVar16, 0);
                *(int64_t *)((int64_t)&uStackX_10 + iVar14) = iVar15;
                if (iVar15 != 0) {
                    iVar15 = *(int64_t *)(in_RCX + 0xb88);
                    if (((*(uint8_t *)(iVar15 + 0x50) & 1) != 0) &&
                       ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0 ||
                         (iVar12 = **(int32_t **)(in_RCX + 0x18), iVar12 < 0x304)) || (iVar12 == 0x10000)))) {
                        uVar16 = *puVar21;
                        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d20e9;
                        func_0x00018019c8a0(iVar15, uVar16);
                    }
                    uVar16 = *puVar21;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d20f8;
                    func_0x00018019c980(uVar16);
                    *puVar21 = *(undefined8 *)((int64_t)&uStackX_10 + iVar14);
                    goto code_r0x0001801d2100;
                }
                *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d208b;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar14), *(int64_t *)((int64_t)&var_18h + iVar14))
                ;
                *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d20a3;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar14), *(int64_t *)((int64_t)&var_18h + iVar14)
                              , *(int64_t *)((int64_t)&var_10h + iVar14), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar14), 
                              *(int64_t *)((int64_t)&uStackX_10 + iVar14));
                goto code_r0x0001801d1fe9;
            }
            goto code_r0x0001801d1fc1;
        }
        if (puVar18 != (uint8_t *)(uint64_t)uVar25) goto code_r0x0001801d1fc1;
        if (uVar8 == 0) {
            return 3;
        }
        if ((((uVar23 == 0) && (0x303 < *piVar6)) && (*piVar6 != 0x10000)) ||
           (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x250) != 0)) goto code_r0x0001801d206f;
code_r0x0001801d2100:
        piVar22 = (int64_t *)(in_RCX + 0x8f8);
        iVar15 = *piVar22;
        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d2108;
        uVar16 = func_0x0001802450c0();
        *(undefined8 *)(iVar15 + 0x2e0) = uVar16;
        iVar15 = *piVar22;
        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d2117;
        func_0x00018019dbf0(iVar15);
        uVar16 = *(undefined8 *)(*piVar22 + 800);
        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d2133;
        fcn.180224990(uVar16, 0x1804b3b98, 0xae8);
        *(undefined8 *)(*piVar22 + 800) = 0;
        *(undefined8 *)(*piVar22 + 0x328) = 0;
        iVar15 = *piVar22;
        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d2161;
        uVar16 = fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar14), *(int64_t *)((int64_t)&var_18h + iVar14)
                              );
        *(undefined8 *)(iVar15 + 800) = uVar16;
        iVar15 = *(int64_t *)(*piVar22 + 800);
        if (iVar15 != 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d21b2;
            iVar12 = func_0x0001801b4900(in_RDX, iVar15, uVar25);
            if (iVar12 == 0) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d21bb;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar14), *(int64_t *)((int64_t)&var_18h + iVar14))
                ;
            } else {
                *(uint32_t *)(*piVar22 + 0x330) = CONCAT31(CONCAT21(CONCAT11(uVar1, uVar2), uVar3), uVar4);
                *(undefined4 *)(*piVar22 + 0x334) = uVar20;
                *(uint64_t *)(*piVar22 + 0x328) = (uint64_t)uVar25;
                if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                    (iVar12 = **(int32_t **)(in_RCX + 0x18), iVar12 < 0x304)) || (iVar12 == 0x10000)) {
code_r0x0001801d22db:
                    uVar16 = (*(undefined8 **)((int64_t)&var_20h + iVar14))[0x8c];
                    uVar7 = **(undefined8 **)((int64_t)&var_20h + iVar14);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d22f6;
                    iVar19 = func_0x000180215540(uVar7, 0x1804b30b0, uVar16);
                    if (iVar19 == 0) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d230b;
                        func_0x00018019b6a0(in_RCX, 0x50);
                        goto code_r0x0001801d1ff4;
                    }
                    iVar24 = *(int64_t *)(in_RCX + 0x8f8);
                    *(undefined8 *)((int64_t)&var_18h + iVar14) = 0;
                    *(int64_t *)(&stack0xffffffffffffffe0 + iVar14) = iVar19;
                    uVar16 = *(undefined8 *)(iVar24 + 800);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d2352;
                    iVar12 = func_0x000180214220(uVar16, uVar25, iVar24 + 600, (int64_t)&arg_80h + iVar14);
                    if (iVar12 == 0) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d235b;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar14), 
                                      *(int64_t *)((int64_t)&var_18h + iVar14));
                        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d2373;
                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar14), 
                                      *(int64_t *)((int64_t)&var_18h + iVar14), *(int64_t *)((int64_t)&var_10h + iVar14)
                                      , *(int64_t *)(&stack0xfffffffffffffff8 + iVar14), 
                                      *(int64_t *)((int64_t)&uStackX_10 + iVar14));
                    } else {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d238b;
                        func_0x000180215590(iVar19);
                        iVar19 = 0;
                        *(uint64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x250) =
                             (uint64_t)*(uint32_t *)((int64_t)&arg_80h + iVar14);
                        *(undefined4 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b0) = 0;
                        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                            (iVar12 = **(int32_t **)(in_RCX + 0x18), iVar12 < 0x304)) || (iVar12 == 0x10000)) {
                            return 3;
                        }
                        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d23e6;
                        uVar16 = func_0x0001801a0380(in_RCX);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d23f1;
                        iVar12 = func_0x00018020f800(uVar16);
                        if (0 < iVar12) {
                            iVar24 = *(int64_t *)(in_RCX + 0x8f8);
                            *(undefined4 *)((int64_t)&uStackX_10 + iVar14 + -8) = 1;
                            *(int64_t *)(&stack0x00000000 + iVar14) = (int64_t)iVar12;
                            *(int64_t *)(&stack0xfffffffffffffff8 + iVar14) = iVar24 + 0x50;
                            *(undefined8 *)((int64_t)&var_10h + iVar14) = *(undefined8 *)((int64_t)&arg_90h + iVar14);
                            *(undefined8 *)((int64_t)&var_18h + iVar14) = *(undefined8 *)((int64_t)&arg_98h + iVar14);
                            *(undefined8 *)(&stack0xffffffffffffffe0 + iVar14) = 10;
                            *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d247e;
                            iVar13 = func_0x0001801b40a0(in_RCX, uVar16, in_RCX + 0x634, 0x1804b3ac0);
                            if (iVar13 != 0) {
                                *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 8) = (int64_t)iVar12;
                                *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d24ab;
                                fcn.180224990(*(undefined8 *)((int64_t)&arg_88h + iVar14), 0x1804b3b98, 0xb48);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d24b8;
                                func_0x000180198390(in_RCX, 1);
                                return 1;
                            }
                            goto code_r0x0001801d1ff4;
                        }
                        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d23fa;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar14), 
                                      *(int64_t *)((int64_t)&var_18h + iVar14));
                        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d2412;
                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar14), 
                                      *(int64_t *)((int64_t)&var_18h + iVar14), *(int64_t *)((int64_t)&var_10h + iVar14)
                                      , *(int64_t *)(&stack0xfffffffffffffff8 + iVar14), 
                                      *(int64_t *)((int64_t)&uStackX_10 + iVar14));
                    }
                    goto code_r0x0001801d1fe9;
                }
                puVar5 = *in_RDX;
                puVar17 = in_RDX[1];
                puVar18 = in_RDX[1];
                *(uint8_t **)((int64_t)&uStackX_10 + iVar14) = puVar5;
                *(uint8_t **)((int64_t)&uStackX_18 + iVar14) = puVar17;
                if ((uint8_t *)0x1 < puVar18) {
                    puVar18 = puVar18 + -2;
                    puVar17 = (uint8_t *)(uint64_t)CONCAT11(*puVar5, puVar5[1]);
                    if (puVar17 <= puVar18) {
                        iVar19 = (int64_t)puVar18 - (int64_t)puVar17;
                        *(uint8_t **)((int64_t)&uStackX_10 + iVar14) = puVar5 + 2 + (int64_t)puVar17;
                        *(int64_t *)((int64_t)&uStackX_18 + iVar14) = iVar19;
                        if (iVar19 == 0) {
                            uVar20 = *(undefined4 *)((int64_t)&uStackX_10 + iVar14);
                            uVar9 = *(undefined4 *)((int64_t)&uStackX_10 + iVar14 + 4);
                            uVar10 = *(undefined4 *)((int64_t)&uStackX_18 + iVar14);
                            uVar11 = *(undefined4 *)((int64_t)&uStackX_18 + iVar14 + 4);
                            *(uint8_t **)((int64_t)&uStackX_10 + iVar14) = puVar5 + 2;
                            *(uint8_t **)((int64_t)&uStackX_18 + iVar14) = puVar17;
                            *(undefined4 *)in_RDX = uVar20;
                            *(undefined4 *)((int64_t)in_RDX + 4) = uVar9;
                            *(undefined4 *)(in_RDX + 1) = uVar10;
                            *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar11;
                            if (in_RDX[1] == (uint8_t *)0x0) {
                                *(undefined4 *)((int64_t)&var_18h + iVar14) = 1;
                                *(undefined8 *)(&stack0xffffffffffffffe0 + iVar14) = 0;
                                *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d22a6;
                                iVar12 = func_0x0001801c9450(in_RCX, (int64_t)&uStackX_10 + iVar14, 0x2000, 
                                                             (int64_t)&arg_88h + iVar14);
                                iVar19 = 0;
                                if (iVar12 == 0) goto code_r0x0001801d1ff4;
                                *(undefined4 *)((int64_t)&var_18h + iVar14) = 1;
                                *(undefined8 *)(&stack0xffffffffffffffe0 + iVar14) = 0;
                                *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d22d3;
                                iVar12 = func_0x0001801c9b70(in_RCX, 0x2000, *(undefined8 *)((int64_t)&arg_88h + iVar14)
                                                             , 0);
                                iVar19 = iVar24;
                                if (iVar12 == 0) goto code_r0x0001801d1ff4;
                                goto code_r0x0001801d22db;
                            }
                        }
                    }
                }
                *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d2315;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar14), *(int64_t *)((int64_t)&var_18h + iVar14))
                ;
            }
            goto code_r0x0001801d1fcb;
        }
        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d217c;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar14), *(int64_t *)((int64_t)&var_18h + iVar14));
        *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d2194;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar14), *(int64_t *)((int64_t)&var_18h + iVar14), 
                      *(int64_t *)((int64_t)&var_10h + iVar14), *(int64_t *)(&stack0xfffffffffffffff8 + iVar14), 
                      *(int64_t *)((int64_t)&uStackX_10 + iVar14));
    }
code_r0x0001801d1fe9:
    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d1ff4;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000000 + iVar14));
code_r0x0001801d1ff4:
    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d1ffc;
    func_0x000180215590(iVar19);
    *(undefined8 *)((int64_t)&uStack_48 + iVar14) = 0x1801d2016;
    fcn.180224990(*(undefined8 *)((int64_t)&arg_88h + iVar14), 0x1804b3b98, 0xb50);
    return 0;
}

// ============================================================
// Function: FUN_1801d24d0
// Address: 0x1801d24d0
// Size: 1287 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_a08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a10h because it doesn't fit into ProtoModel

int64_t fcn.1801d24d0(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_88h)
{
    char cVar1;
    char cVar2;
    char cVar3;
    undefined8 uVar4;
    char *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint32_t uVar9;
    int64_t in_RCX;
    char *pcVar10;
    char **in_RDX;
    undefined8 unaff_RSI;
    char *pcVar11;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    int64_t iVar12;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801d24e3;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar12 = 0;
    cVar1 = *(char *)(in_RCX + 0xb52);
    var_8h = 0;
    if (cVar1 == '\x02') {
        var_18h = 0;
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d2517;
        iVar6 = fcn.1801b2020(*(int64_t *)((int64_t)&arg_40h + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7), 
                              *(int64_t *)(&stack0x00000058 + iVar7));
        if (iVar6 != 0) {
            if (var_18h == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d2526;
                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d253e;
                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar7));
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d2554;
                fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
                return 0;
            }
            uVar4 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d2574;
            fcn.18022ecc0(uVar4);
            iVar12 = 2;
            *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2b8) = var_18h;
        }
        return iVar12;
    }
    *(undefined8 *)((int64_t)&arg_88h + iVar7) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_R13;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_R15;
    if (cVar1 != '\0') {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d25b9;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d25d1;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)(&stack0x00000030 + iVar7));
        goto code_r0x0001801d297f;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d25e6;
    iVar8 = fcn.180221f20();
    *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8) = iVar8;
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d25fe;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
code_r0x0001801d2603:
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d2616;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)(&stack0x00000030 + iVar7));
        goto code_r0x0001801d297f;
    }
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar6 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar6)) && (iVar6 != 0x10000)) {
        if (in_RDX[1] != (char *)0x0) {
            cVar1 = **in_RDX;
            *in_RDX = *in_RDX + 1;
            in_RDX[1] = in_RDX[1] + -1;
            if (cVar1 == '\0') goto code_r0x0001801d2670;
        }
    } else {
code_r0x0001801d2670:
        if ((char *)0x2 < in_RDX[1]) {
            pcVar5 = *in_RDX;
            pcVar11 = in_RDX[1] + -3;
            cVar1 = *pcVar5;
            cVar2 = pcVar5[1];
            cVar3 = pcVar5[2];
            *in_RDX = pcVar5 + 3;
            in_RDX[1] = pcVar11;
            if ((pcVar11 == (char *)(uint64_t)CONCAT21(CONCAT11(cVar1, cVar2), cVar3)) && (pcVar11 != (char *)0x0)) {
                while ((char *)0x2 < pcVar11) {
                    pcVar10 = *in_RDX;
                    pcVar11 = pcVar11 + -3;
                    pcVar5 = pcVar10 + 3;
                    uVar9 = (uint32_t)CONCAT21(CONCAT11(*pcVar10, pcVar10[1]), pcVar10[2]);
                    *in_RDX = pcVar5;
                    pcVar10 = (char *)(uint64_t)uVar9;
                    in_RDX[1] = pcVar11;
                    if (pcVar11 < pcVar10) break;
                    var_20h = (int64_t)pcVar5;
                    *in_RDX = pcVar5 + uVar9;
                    in_RDX[1] = pcVar11 + -(int64_t)pcVar10;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d2722;
                    var_8h = fcn.18021ff10(*(int64_t *)(&stack0x00000000 + iVar7), 
                                           *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                    if (var_8h == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d292b;
                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d2943;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)(&stack0x00000030 + iVar7));
                        goto code_r0x0001801d297f;
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d273f;
                    iVar8 = fcn.18021fff0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                          *(int64_t *)((int64_t)&var_18h + iVar7), 
                                          *(int64_t *)((int64_t)&var_20h + iVar7), 
                                          *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7)
                                          , *(int64_t *)(&stack0x00000038 + iVar7), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar7), 
                                          *(int64_t *)(&stack0x00000068 + iVar7));
                    if (iVar8 == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d2901;
                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d2919;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)(&stack0x00000030 + iVar7));
                        goto code_r0x0001801d297f;
                    }
                    if ((char *)var_20h != pcVar5 + (int64_t)pcVar10) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d28dc;
                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                        goto code_r0x0001801d28e1;
                    }
                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                        (iVar6 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar6)) && (iVar6 != 0x10000)) {
                        pcVar5 = *in_RDX;
                        var_18h = 0;
                        if ((char *)0x1 < in_RDX[1]) {
                            pcVar11 = in_RDX[1] + -2;
                            pcVar10 = (char *)(uint64_t)CONCAT11(*pcVar5, pcVar5[1]);
                            if (pcVar10 <= pcVar11) {
                                *(uint32_t *)((int64_t)&iStackX_10 + iVar7 + -8) = (uint32_t)(iVar12 == 0);
                                *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
                                *in_RDX = pcVar5 + 2 + (int64_t)pcVar10;
                                in_RDX[1] = pcVar11 + -(int64_t)pcVar10;
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d2806;
                                iVar6 = fcn.1801c9450(*(int64_t *)(&stack0x00000000 + iVar7), 
                                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                                      *(int64_t *)((int64_t)&var_18h + iVar7), 
                                                      *(int64_t *)((int64_t)&var_20h + iVar7), 
                                                      *(int64_t *)(&stack0x00000030 + iVar7), 
                                                      *(int64_t *)(&stack0x00000038 + iVar7), 
                                                      *(int64_t *)((int64_t)&arg_50h + iVar7), 
                                                      *(int64_t *)(&stack0x00000070 + iVar7), 
                                                      *(int64_t *)(&stack0x00000078 + iVar7), 
                                                      *(int64_t *)(&stack0x00000080 + iVar7), 
                                                      *(int64_t *)((int64_t)&arg_88h + iVar7), 
                                                      *(int64_t *)(&stack0x00000090 + iVar7), 
                                                      *(int64_t *)(&stack0x00000098 + iVar7), 
                                                      *(int64_t *)(&stack0x000000a0 + iVar7));
                                if (iVar6 != 0) {
                                    *(uint32_t *)((int64_t)&iStackX_10 + iVar7 + -8) =
                                         (uint32_t)(in_RDX[1] == (char *)0x0);
                                    *(int64_t *)(&stack0x00000000 + iVar7) = iVar12;
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d2832;
                                    iVar6 = fcn.1801c9b70(*(int64_t *)((int64_t)&var_20h + iVar7), 
                                                          *(int64_t *)(&stack0x00000030 + iVar7), 
                                                          *(int64_t *)(&stack0x00000038 + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_40h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_48h + iVar7));
                                    if (iVar6 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d284c;
                                        fcn.180224990(var_18h, 0x1804b3b98, 0x814);
                                        goto code_r0x0001801d284c;
                                    }
                                }
                                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d289b;
                                fcn.180224990(var_18h, 0x1804b3b98, 0x810);
                                goto code_r0x0001801d298a;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d28a5;
                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d28bd;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)(&stack0x00000030 + iVar7));
                        goto code_r0x0001801d297f;
                    }
code_r0x0001801d284c:
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d2863;
                    iVar6 = fcn.180222110(*(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                                          *(int64_t *)((int64_t)&var_18h + iVar7), 
                                          *(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x00000030 + iVar7)
                                          , *(int64_t *)(&stack0x00000038 + iVar7));
                    if (iVar6 == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d28cd;
                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
                        goto code_r0x0001801d2603;
                    }
                    pcVar11 = in_RDX[1];
                    iVar12 = iVar12 + 1;
                    var_8h = 0;
                    if (pcVar11 == (char *)0x0) {
                        return 2;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d2950;
                fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
code_r0x0001801d28e1:
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d28f4;
                fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar7));
                goto code_r0x0001801d297f;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d295c;
    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d2974;
    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                  *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                  *(int64_t *)(&stack0x00000030 + iVar7));
code_r0x0001801d297f:
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d298a;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_20h + iVar7));
code_r0x0001801d298a:
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d2993;
    fcn.18021fe80(var_8h);
    uVar4 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8);
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801d29a6;
    fcn.180238640(uVar4);
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2c8) = 0;
    return 0;
}

// ============================================================
// Function: FUN_1801d29e0
// Address: 0x1801d29e0
// Size: 2834 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_a08h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_a10h because it doesn't fit into ProtoModel

undefined8 fcn.1801d29e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined4 *puVar1;
    uint8_t *puVar2;
    uint8_t uVar3;
    uint8_t uVar4;
    uint8_t uVar5;
    int32_t *piVar6;
    code *pcVar7;
    int64_t iVar8;
    code **ppcVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    bool bVar13;
    int32_t iVar14;
    int32_t iVar15;
    int64_t iVar16;
    int64_t iVar17;
    int64_t in_RCX;
    uint8_t *puVar18;
    uint8_t *puVar19;
    uint8_t **in_RDX;
    uint32_t uVar20;
    undefined8 uVar21;
    uint8_t *puVar22;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined8 uStack_48;
    
    uStack_48 = 0x1801d29fc;
    iVar16 = fcn.18045a350();
    iVar16 = -iVar16;
    bVar13 = false;
    var_10h = 0;
    var_68h = *(int64_t *)(in_RCX + 0x40);
    if (in_RDX[1] < (uint8_t *)0x2) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d3498;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
        goto code_r0x0001801d349d;
    }
    puVar22 = *in_RDX;
    uVar3 = *puVar22;
    puVar1 = (undefined4 *)(puVar22 + 2);
    uVar4 = puVar22[1];
    *in_RDX = (uint8_t *)puVar1;
    puVar18 = in_RDX[1] + -2;
    in_RDX[1] = puVar18;
    if ((*(int32_t *)(in_RCX + 0x48) == 0x304) && (CONCAT11(uVar3, uVar4) == 0x303)) {
        if ((uint8_t *)0x1f < puVar18) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2a81;
            iVar14 = fcn.180497f30(0x1804af260, puVar1, 0x20);
            if (iVar14 != 0) goto code_r0x0001801d2b38;
            if (*(int32_t *)(in_RCX + 0x8c8) != 0) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2a97;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                              *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
                *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2aaf;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                              *(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), *(int64_t *)((int64_t)&var_10h + iVar16))
                ;
                goto code_r0x0001801d34bb;
            }
            *(undefined4 *)(in_RCX + 0x8c8) = 1;
            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2ad3;
            iVar14 = func_0x0001801a5230(in_RCX, 0x304);
            if (iVar14 != 0) {
                bVar13 = true;
                if (in_RDX[1] < (uint8_t *)0x20) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2b24;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
                    goto code_r0x0001801d349d;
                }
                *in_RDX = *in_RDX + 0x20;
                in_RDX[1] = in_RDX[1] + -0x20;
                goto code_r0x0001801d2b56;
            }
            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2adc;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
code_r0x0001801d2ae1:
            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2af4;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), *(int64_t *)((int64_t)&var_10h + iVar16));
            goto code_r0x0001801d34bb;
        }
code_r0x0001801d3487:
        *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d348c;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
code_r0x0001801d349d:
        *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d34b0;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), *(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), 
                      *(int64_t *)((int64_t)&var_10h + iVar16));
    } else {
        if (puVar18 < (uint8_t *)0x20) goto code_r0x0001801d3487;
code_r0x0001801d2b38:
        uVar10 = *(undefined4 *)(puVar22 + 6);
        uVar11 = *(undefined4 *)(puVar22 + 10);
        uVar12 = *(undefined4 *)(puVar22 + 0xe);
        *(undefined4 *)(in_RCX + 0x164) = *puVar1;
        *(undefined4 *)(in_RCX + 0x168) = uVar10;
        *(undefined4 *)(in_RCX + 0x16c) = uVar11;
        *(undefined4 *)(in_RCX + 0x170) = uVar12;
        uVar10 = *(undefined4 *)(puVar22 + 0x16);
        uVar11 = *(undefined4 *)(puVar22 + 0x1a);
        uVar12 = *(undefined4 *)(puVar22 + 0x1e);
        *(undefined4 *)(in_RCX + 0x174) = *(undefined4 *)(puVar22 + 0x12);
        *(undefined4 *)(in_RCX + 0x178) = uVar10;
        *(undefined4 *)(in_RCX + 0x17c) = uVar11;
        *(undefined4 *)(in_RCX + 0x180) = uVar12;
        *in_RDX = *in_RDX + 0x20;
        in_RDX[1] = in_RDX[1] + -0x20;
code_r0x0001801d2b56:
        var_78h = (int64_t)*in_RDX;
        var_70h = (int64_t)in_RDX[1];
        if (in_RDX[1] == (uint8_t *)0x0) {
code_r0x0001801d347b:
            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d3480;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
            goto code_r0x0001801d349d;
        }
        puVar18 = in_RDX[1] + -1;
        puVar22 = (uint8_t *)(uint64_t)*(uint8_t *)var_78h;
        var_18h = var_78h + 1;
        if (puVar18 < puVar22) goto code_r0x0001801d347b;
        var_78h = (int64_t)(puVar22 + var_18h);
        var_70h = (int64_t)(puVar18 + -(int64_t)puVar22);
        *in_RDX = puVar22 + var_18h;
        in_RDX[1] = puVar18 + -(int64_t)puVar22;
        if ((uint8_t *)0x20 < puVar22) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d3456;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d346e;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), *(int64_t *)((int64_t)&var_10h + iVar16));
            goto code_r0x0001801d34bb;
        }
        puVar18 = in_RDX[1];
        if (puVar18 < (uint8_t *)0x2) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d344a;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
            goto code_r0x0001801d349d;
        }
        var_20h = (int64_t)*in_RDX;
        *in_RDX = (uint8_t *)(var_20h + 2);
        in_RDX[1] = puVar18 + -2;
        if (puVar18 + -2 == (uint8_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d343e;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
            goto code_r0x0001801d349d;
        }
        uVar5 = *(uint8_t *)(var_20h + 2);
        *in_RDX = (uint8_t *)(var_20h + 3);
        puVar2 = puVar18 + -3;
        var_8h = CONCAT44(var_8h._4_4_, (uint32_t)uVar5);
        in_RDX[1] = puVar2;
        if ((puVar2 != (uint8_t *)0x0) || (bVar13)) {
            var_78h = (int64_t)*in_RDX;
            var_70h = (int64_t)in_RDX[1];
            if ((uint8_t *)0x1 < puVar2) {
                puVar2 = (uint8_t *)(var_78h + 2);
                puVar19 = (uint8_t *)(uint64_t)CONCAT11(*(uint8_t *)var_78h, *(uint8_t *)(var_78h + 1));
                if (puVar19 <= puVar18 + -5) {
                    var_70h = (int64_t)(puVar18 + -5) - (int64_t)puVar19;
                    var_78h = (int64_t)(puVar2 + (int64_t)puVar19);
                    if (var_70h == 0) {
                        var_60h = (int64_t)puVar2;
                        var_58h = (int64_t)puVar19;
                        *in_RDX = puVar2 + (int64_t)puVar19;
                        in_RDX[1] = (uint8_t *)0x0;
                        if (in_RDX[1] == (uint8_t *)0x0) {
                            if (!bVar13) goto code_r0x0001801d2c67;
                            goto code_r0x0001801d2caa;
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d3419;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d3431;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), *(int64_t *)((int64_t)&var_10h + iVar16));
        } else {
            var_60h = (int64_t)puVar2;
            var_58h = (int64_t)puVar2;
code_r0x0001801d2c67:
            *(undefined4 *)(&stack0xffffffffffffffe8 + iVar16) = 1;
            *(undefined8 *)(&stack0xffffffffffffffe0 + iVar16) = 0;
            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2c87;
            iVar14 = fcn.1801c9450(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                   *(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                                   *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), 
                                   *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), 
                                   *(int64_t *)(&stack0x00000000 + iVar16), *(int64_t *)((int64_t)&var_10h + iVar16), 
                                   *(int64_t *)((int64_t)&var_18h + iVar16), *(int64_t *)((int64_t)&arg_30h + iVar16), 
                                   *(int64_t *)(&stack0x00000050 + iVar16), *(int64_t *)(&stack0x00000058 + iVar16), 
                                   *(int64_t *)(&stack0x00000060 + iVar16), *(int64_t *)(&stack0x00000068 + iVar16), 
                                   *(int64_t *)(&stack0x00000070 + iVar16), *(int64_t *)(&stack0x00000078 + iVar16), 
                                   *(int64_t *)(&stack0x00000080 + iVar16));
            if (iVar14 == 0) goto code_r0x0001801d34c6;
            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2c9e;
            iVar14 = func_0x0001801af2b0(in_RCX, CONCAT11(uVar3, uVar4), var_10h);
            if (iVar14 == 0) goto code_r0x0001801d34c6;
code_r0x0001801d2caa:
            iVar8 = var_8h;
            piVar6 = *(int32_t **)(in_RCX + 0x18);
            uVar20 = *(uint32_t *)(*(int64_t *)(piVar6 + 0x36) + 0x50) & 8;
            iVar14 = (int32_t)var_8h;
            if ((((uVar20 == 0) && (0x303 < *piVar6)) && (*piVar6 != 0x10000)) || (bVar13)) {
                if ((int32_t)var_8h == 0) {
                    if (puVar22 == *(uint8_t **)(in_RCX + 0x940)) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2d2b;
                        iVar15 = fcn.180497f30(var_18h, in_RCX + 0x920, puVar22);
                        if (iVar15 == 0) {
                            if (bVar13) {
                                *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2d48;
                                iVar14 = func_0x0001801ce270(in_RCX, var_20h);
                                if (iVar14 != 0) {
                                    var_8h = 0;
                                    if (*(int32_t *)(in_RCX + 0xf0) == 7) {
                                        *(undefined8 *)((int64_t)&arg_48h + iVar16) = 0;
                                        *(undefined8 *)((int64_t)&arg_40h + iVar16) = 0;
                                        *(undefined8 *)((int64_t)&arg_38h + iVar16) = 0;
                                        *(undefined4 *)((int64_t)&arg_30h + iVar16) = 0;
                                        *(undefined8 *)((int64_t)&arg_28h + iVar16) = 0;
                                        *(undefined8 *)((int64_t)&var_20h + iVar16) = 0;
                                        *(undefined8 *)((int64_t)&var_18h + iVar16) = 0;
                                        *(undefined8 *)((int64_t)&var_10h + iVar16) = 0;
                                        *(undefined8 *)((int64_t)&var_8h + iVar16) = 0;
                                        *(undefined8 *)(&stack0x00000000 + iVar16) = 0;
                                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar16) = 0;
                                        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar16) = 0;
                                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar16) = 0;
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + iVar16) = 0;
                                        *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2dbd;
                                        iVar14 = func_0x0001801a4960(in_RCX, 0x10000, 1, 0);
                                        if (iVar14 == 0) goto code_r0x0001801d2ec9;
                                    }
                                    uVar21 = *(undefined8 *)(in_RCX + 0xc80);
                                    pcVar7 = *(code **)(*(int64_t *)(in_RCX + 0xc70) + 0x60);
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2ddf;
                                    (*pcVar7)(uVar21, 0x304);
                                    *(undefined4 *)(&stack0xffffffffffffffe8 + iVar16) = 1;
                                    *(undefined8 *)(&stack0xffffffffffffffe0 + iVar16) = 0;
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2dff;
                                    iVar14 = fcn.1801c9450(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                                           *(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                                                           *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), 
                                                           *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), 
                                                           *(int64_t *)(&stack0x00000000 + iVar16), 
                                                           *(int64_t *)((int64_t)&var_10h + iVar16), 
                                                           *(int64_t *)((int64_t)&var_18h + iVar16), 
                                                           *(int64_t *)((int64_t)&arg_30h + iVar16), 
                                                           *(int64_t *)(&stack0x00000050 + iVar16), 
                                                           *(int64_t *)(&stack0x00000058 + iVar16), 
                                                           *(int64_t *)(&stack0x00000060 + iVar16), 
                                                           *(int64_t *)(&stack0x00000068 + iVar16), 
                                                           *(int64_t *)(&stack0x00000070 + iVar16), 
                                                           *(int64_t *)(&stack0x00000078 + iVar16), 
                                                           *(int64_t *)(&stack0x00000080 + iVar16));
                                    if (iVar14 != 0) {
                                        *(undefined4 *)(&stack0xffffffffffffffe8 + iVar16) = 1;
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + iVar16) = 0;
                                        *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2e25;
                                        iVar14 = fcn.1801c9b70(*(int64_t *)(&stack0x00000000 + iVar16), 
                                                               *(int64_t *)((int64_t)&var_10h + iVar16), 
                                                               *(int64_t *)((int64_t)&var_18h + iVar16), 
                                                               *(int64_t *)((int64_t)&var_20h + iVar16), 
                                                               *(int64_t *)((int64_t)&arg_28h + iVar16));
                                        if (iVar14 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2e43;
                                            fcn.180224990(var_8h, 0x1804b3b98, 0x74d);
                                            var_8h = 0;
                                            if ((*(int64_t *)(in_RCX + 0xb28) == 0) &&
                                               (*(int64_t *)(in_RCX + 0x308) != 0)) {
                                                *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2e5e;
                                                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                                              *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
                                                *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2e76;
                                                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                                              *(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                                                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), 
                                                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), 
                                                              *(int64_t *)((int64_t)&var_10h + iVar16));
                                                *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2e8c;
                                                fcn.18019b5e0(*(int64_t *)(&stack0x00000000 + iVar16));
                                            } else {
                                                *(undefined8 *)(&stack0xffffffffffffffe0 + iVar16) = 0;
                                                *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2ea3;
                                                iVar14 = func_0x0001801ae390(in_RCX, 0, 0, 0);
                                                if (iVar14 != 0) {
                                                    iVar8 = *(int64_t *)(in_RCX + 0x108);
                                                    uVar21 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xf8) + 8);
                                                    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2ec5;
                                                    iVar14 = func_0x0001801dac70(in_RCX, uVar21, iVar8 + 4);
                                                    if (iVar14 != 0) {
                                                        return 1;
                                                    }
                                                }
                                            }
                                        }
                                    }
code_r0x0001801d2ec9:
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2edf;
                                    fcn.180224990(var_8h, 0x1804b3b98, 0x770);
                                    return 0;
                                }
                                goto code_r0x0001801d34c6;
                            }
                            goto code_r0x0001801d2f1b;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2eef;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
                    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2f07;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), 
                                  *(int64_t *)((int64_t)&var_10h + iVar16));
                } else {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2ce4;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
                    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2cfc;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), 
                                  *(int64_t *)((int64_t)&var_10h + iVar16));
                }
            } else {
code_r0x0001801d2f1b:
                if (((uVar20 != 0) || (*piVar6 < 0x304)) || (uVar21 = 0x200, *piVar6 == 0x10000)) {
                    uVar21 = 0x100;
                }
                *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2f4a;
                iVar15 = func_0x0001801ca4d0(in_RCX, uVar21, var_10h);
                if (iVar15 == 0) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2f53;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
                    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2f6b;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), 
                                  *(int64_t *)((int64_t)&var_10h + iVar16));
                } else {
                    *(undefined4 *)(in_RCX + 0x508) = 0;
                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
                        (iVar15 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar15)) && (iVar15 != 0x10000)) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2fb0;
                        iVar15 = func_0x0001801a2f70(in_RCX + 0xc50);
                        if (iVar15 != 0) {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2fb9;
                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
                            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d2fd1;
                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), 
                                          *(int64_t *)((int64_t)&var_10h + iVar16));
                            goto code_r0x0001801d34bb;
                        }
                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar16) = 0;
                        *(undefined8 *)(&stack0xffffffffffffffe0 + iVar16) = 0;
                        *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d3002;
                        iVar15 = func_0x0001801c9d00(in_RCX, 0x1c, 0x200, var_10h);
                        if (iVar15 == 0) goto code_r0x0001801d34c6;
                    } else {
                        if (((0x300 < *(int32_t *)(in_RCX + 0x48)) &&
                            (pcVar7 = *(code **)(in_RCX + 0xae0), pcVar7 != (code *)0x0)) &&
                           (iVar17 = *(int64_t *)(in_RCX + 0x8f8), *(int64_t *)(iVar17 + 800) != 0)) {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + iVar16) = *(undefined8 *)(in_RCX + 0xae8);
                            var_78h = 0;
                            *(int64_t **)(&stack0xffffffffffffffe0 + iVar16) = &var_78h;
                            var_8h = CONCAT44(var_8h._4_4_, 0x200);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d306e;
                            iVar15 = (*pcVar7)(var_68h, iVar17 + 0x50, &var_8h, 0);
                            if (iVar15 != 0) {
                                if (0 < (int32_t)var_8h) {
                                    *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 8) = (int64_t)(int32_t)var_8h;
                                    iVar17 = var_78h;
                                    if (var_78h == 0) {
                                        *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d30a8;
                                        iVar17 = func_0x0001801a0300(in_RCX, var_20h, 0);
                                    }
                                    *(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x2f8) = iVar17;
                                    goto code_r0x0001801d30b6;
                                }
                            }
                            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d3158;
                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
                            goto code_r0x0001801d2ae1;
                        }
code_r0x0001801d30b6:
                        if ((puVar22 != (uint8_t *)0x0) &&
                           (iVar17 = *(int64_t *)(in_RCX + 0x8f8), puVar22 == *(uint8_t **)(iVar17 + 0x250))) {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d30de;
                            iVar15 = fcn.180497f30(var_18h, iVar17 + 600, puVar22);
                            if (iVar15 == 0) {
                                *(undefined4 *)(in_RCX + 0x508) = 1;
                            }
                        }
                    }
                    iVar17 = *(int64_t *)(in_RCX + 0x8f8);
                    if (*(int32_t *)(in_RCX + 0x508) == 0) {
                        if (*(int64_t *)(iVar17 + 0x250) != 0) {
                            LOCK();
                            piVar6 = (int32_t *)(*(int64_t *)(in_RCX + 0xb88) + 0x90);
                            *piVar6 = *piVar6 + 1;
                            UNLOCK();
                            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d3186;
                            iVar15 = func_0x00018019d4c0(in_RCX, 0);
                            if (iVar15 == 0) goto code_r0x0001801d34c6;
                        }
                        **(undefined4 **)(int64_t *)(in_RCX + 0x8f8) = *(undefined4 *)(in_RCX + 0x48);
                        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                            (iVar15 = **(int32_t **)(in_RCX + 0x18), iVar15 < 0x304)) || (iVar15 == 0x10000)) {
                            *(uint8_t **)(*(int64_t *)(in_RCX + 0x8f8) + 0x250) = puVar22;
                            if (puVar22 != (uint8_t *)0x0) {
                                iVar17 = *(int64_t *)(in_RCX + 0x8f8);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d31ef;
                                fcn.180498030(iVar17 + 600, var_18h, puVar22);
                            }
                        }
code_r0x0001801d31f1:
                        iVar17 = 0;
                        iVar15 = *(int32_t *)(in_RCX + 0x48);
                        if (iVar15 == **(int32_t **)(in_RCX + 0x8f8)) {
                            *(int32_t *)(in_RCX + 0x418) = iVar15;
                            *(int32_t *)(in_RCX + 0x41c) = iVar15;
                            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d3240;
                            iVar15 = func_0x0001801ce270(in_RCX, var_20h);
                            if (iVar15 == 0) goto code_r0x0001801d34c6;
                            if ((*(int32_t *)(in_RCX + 0x508) == 0) || (iVar14 == (*(int32_t **)(in_RCX + 0x8f8))[0xbc])
                               ) {
                                if (iVar14 == 0) {
code_r0x0001801d3296:
                                    *(undefined4 *)(&stack0xffffffffffffffe8 + iVar16) = 1;
                                    *(undefined8 *)(&stack0xffffffffffffffe0 + iVar16) = 0;
                                    *(int64_t *)(in_RCX + 0x390) = iVar17;
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d32b9;
                                    iVar14 = fcn.1801c9b70(*(int64_t *)(&stack0x00000000 + iVar16), 
                                                           *(int64_t *)((int64_t)&var_10h + iVar16), 
                                                           *(int64_t *)((int64_t)&var_18h + iVar16), 
                                                           *(int64_t *)((int64_t)&var_20h + iVar16), 
                                                           *(int64_t *)((int64_t)&arg_28h + iVar16));
                                    if (iVar14 != 0) {
                                        ppcVar9 = *(code ***)(*(int32_t **)(in_RCX + 0x18) + 0x36);
                                        if ((((*(uint8_t *)(ppcVar9 + 10) & 8) != 0) ||
                                            (iVar14 = **(int32_t **)(in_RCX + 0x18), iVar14 < 0x304)) ||
                                           (iVar14 == 0x10000)) {
code_r0x0001801d3372:
                                            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d3388;
                                            fcn.180224990(var_10h, 0x1804b3b98, 0x728);
                                            return 3;
                                        }
                                        pcVar7 = *ppcVar9;
                                        *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d32f6;
                                        iVar14 = (*pcVar7)(in_RCX);
                                        if (iVar14 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d3306;
                                            iVar14 = func_0x0001801b4590(in_RCX);
                                            if (iVar14 != 0) {
                                                if (((*(uint32_t *)(in_RCX + 0x160) & 0x2000) != 0) ||
                                                   ((*(int32_t *)(in_RCX + 0xf0) == 0 &&
                                                    ((*(uint32_t *)(in_RCX + 0x9a8) >> 0x14 & 1) == 0)))) {
                                                    pcVar7 = *(code **)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8)
                                                                       + 0x10);
                                                    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d3349;
                                                    iVar14 = (*pcVar7)(in_RCX, 0x92);
                                                    if (iVar14 == 0) goto code_r0x0001801d34c6;
                                                }
                                                pcVar7 = *(code **)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) +
                                                                   0x10);
                                                *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d336a;
                                                iVar14 = (*pcVar7)(in_RCX, 0x91);
                                                if (iVar14 != 0) goto code_r0x0001801d3372;
                                            }
                                        }
                                    }
                                    goto code_r0x0001801d34c6;
                                }
                                *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d339a;
                                iVar14 = func_0x0001801af1c0(in_RCX);
                                if (iVar14 == 0) {
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d33a3;
                                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d33bb;
                                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), 
                                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar16));
                                } else {
                                    uVar21 = *(undefined8 *)(*(int64_t *)(in_RCX + 8) + 0x118);
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d33de;
                                    iVar17 = func_0x00018019e430(uVar21, iVar8 & 0xffffffff);
                                    if (iVar17 != 0) goto code_r0x0001801d3296;
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d33ec;
                                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d3404;
                                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), 
                                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar16));
                                }
                            } else {
                                *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d3262;
                                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                              *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
                                *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d327a;
                                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                              *(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), 
                                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), 
                                              *(int64_t *)((int64_t)&var_10h + iVar16));
                            }
                        } else {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d3200;
                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
                            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d3218;
                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), 
                                          *(int64_t *)((int64_t)&var_10h + iVar16));
                        }
                    } else {
                        if (*(int64_t *)(in_RCX + 0x8d0) == *(int64_t *)(iVar17 + 0x278)) {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d311e;
                            iVar15 = fcn.180497f30(iVar17 + 0x280, in_RCX + 0x8d8);
                            if (iVar15 == 0) goto code_r0x0001801d31f1;
                        }
                        *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d312b;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                      *(int64_t *)(&stack0xffffffffffffffe8 + iVar16));
                        *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d3143;
                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar16), 
                                      *(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), 
                                      *(int64_t *)((int64_t)&var_10h + iVar16));
                    }
                }
            }
        }
    }
code_r0x0001801d34bb:
    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d34c6;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000000 + iVar16));
code_r0x0001801d34c6:
    *(undefined8 *)((int64_t)&uStack_48 + iVar16) = 0x1801d34dc;
    fcn.180224990(var_10h, 0x1804b3b98, 0x72b);
    return 0;
}

// ============================================================
// Function: FUN_1801d3500
// Address: 0x1801d3500
// Size: 1153 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1801d3500(int64_t placeholder_0, undefined4 *placeholder_1, int64_t arg3, int64_t arg_60h, int64_t arg_68h,
                     int64_t arg_70h, int64_t arg_78h, int64_t arg_90h)
{
    undefined *puVar1;
    undefined4 *puVar2;
    undefined uVar3;
    undefined uVar4;
    undefined uVar5;
    undefined uVar6;
    undefined8 *puVar7;
    undefined *puVar8;
    undefined8 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    int32_t iVar13;
    undefined4 uVar14;
    int64_t iVar15;
    uint64_t uVar16;
    undefined8 uVar17;
    int64_t iVar18;
    int64_t iVar19;
    int64_t iVar20;
    int64_t iVar21;
    uint64_t uVar22;
    int64_t iVar23;
    int64_t iVar24;
    int64_t iVar25;
    uint64_t uVar26;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    undefined8 uStack_48;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_48 = 0x1801d351b;
    var_18h = arg3;
    iVar15 = fcn.18045a350();
    iVar15 = -iVar15;
    uVar14 = *placeholder_1;
    uVar10 = placeholder_1[1];
    uVar11 = placeholder_1[2];
    uVar12 = placeholder_1[3];
    uVar16 = *(uint64_t *)(placeholder_1 + 2);
    iVar23 = 0;
    puVar7 = *(undefined8 **)(placeholder_0 + 8);
    *(undefined8 *)((int64_t)&arg_60h + iVar15) = 0;
    iVar25 = 0;
    iVar24 = 0;
    *(undefined4 *)((int64_t)&var_10h + iVar15) = uVar14;
    *(undefined4 *)((int64_t)&var_10h + iVar15 + 4) = uVar10;
    *(undefined4 *)((int64_t)&var_8h + iVar15) = uVar11;
    *(undefined4 *)((int64_t)&var_8h + iVar15 + 4) = uVar12;
    if (uVar16 < 2) {
code_r0x0001801d393b:
        *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d3940;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar15), *(int64_t *)(&stack0xffffffffffffffe8 + iVar15));
        *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d3958;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar15), *(int64_t *)(&stack0xffffffffffffffe8 + iVar15), 
                      *(int64_t *)((int64_t)&var_10h + iVar15), *(int64_t *)((int64_t)&var_8h + iVar15), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar15 + 8));
        *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d396e;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000000 + iVar15));
        return 0;
    }
    puVar8 = *(undefined **)((int64_t)&var_10h + iVar15);
    puVar1 = puVar8 + 2;
    uVar16 = uVar16 - 2;
    uVar22 = (uint64_t)CONCAT11(*puVar8, puVar8[1]);
    *(undefined **)((int64_t)&var_10h + iVar15) = puVar1;
    if (uVar16 < uVar22) goto code_r0x0001801d393b;
    uVar16 = uVar16 - uVar22;
    puVar8 = puVar1 + uVar22;
    *(undefined **)((int64_t)&var_10h + iVar15) = puVar8;
    *(uint64_t *)((int64_t)&var_8h + iVar15) = uVar16;
    uVar14 = *(undefined4 *)((int64_t)&var_10h + iVar15 + 4);
    uVar10 = *(undefined4 *)((int64_t)&var_8h + iVar15);
    uVar11 = *(undefined4 *)((int64_t)&var_8h + iVar15 + 4);
    *placeholder_1 = *(undefined4 *)((int64_t)&var_10h + iVar15);
    placeholder_1[1] = uVar14;
    placeholder_1[2] = uVar10;
    placeholder_1[3] = uVar11;
    if (uVar16 < 2) goto code_r0x0001801d393b;
    uVar3 = *puVar8;
    uVar4 = puVar8[1];
    puVar8 = puVar8 + 2;
    uVar26 = (uint64_t)CONCAT11(uVar3, uVar4);
    *(undefined **)((int64_t)&arg_78h + iVar15) = puVar8;
    *(undefined **)((int64_t)&var_10h + iVar15) = puVar8;
    if (uVar16 - 2 < uVar26) goto code_r0x0001801d393b;
    uVar16 = (uVar16 - 2) - uVar26;
    puVar8 = puVar8 + uVar26;
    *(undefined **)((int64_t)&var_10h + iVar15) = puVar8;
    *(uint64_t *)((int64_t)&var_8h + iVar15) = uVar16;
    uVar14 = *(undefined4 *)((int64_t)&var_10h + iVar15 + 4);
    uVar10 = *(undefined4 *)((int64_t)&var_8h + iVar15);
    uVar11 = *(undefined4 *)((int64_t)&var_8h + iVar15 + 4);
    *placeholder_1 = *(undefined4 *)((int64_t)&var_10h + iVar15);
    placeholder_1[1] = uVar14;
    placeholder_1[2] = uVar10;
    placeholder_1[3] = uVar11;
    if (uVar16 < 2) goto code_r0x0001801d393b;
    uVar5 = puVar8[1];
    uVar6 = *puVar8;
    uVar26 = (uint64_t)CONCAT11(uVar6, uVar5);
    *(undefined **)((int64_t)&var_10h + iVar15) = puVar8 + 2;
    if (uVar16 - 2 < uVar26) goto code_r0x0001801d393b;
    *(uint64_t *)((int64_t)aiStackX_8 + iVar15) = (uVar16 - 2) - uVar26;
    *(undefined **)(&stack0x00000000 + iVar15) = puVar8 + 2 + uVar26;
    puVar2 = (undefined4 *)(&stack0x00000000 + iVar15);
    uVar14 = puVar2[1];
    uVar10 = puVar2[2];
    uVar11 = puVar2[3];
    *placeholder_1 = *puVar2;
    placeholder_1[1] = uVar14;
    placeholder_1[2] = uVar10;
    placeholder_1[3] = uVar11;
    *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d3638;
    uVar17 = func_0x000180254c30(puVar1, uVar22, 0);
    *(undefined8 *)((int64_t)&arg_68h + iVar15) = uVar17;
    *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d3653;
    iVar18 = func_0x000180254c30(*(undefined8 *)((int64_t)&arg_78h + iVar15), CONCAT11(uVar3, uVar4), 0);
    *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d3666;
    iVar19 = func_0x000180254c30(*(undefined8 *)((int64_t)&var_10h + iVar15), CONCAT11(uVar6, uVar5), 0);
    iVar21 = iVar23;
    iVar20 = iVar23;
    if (((*(int64_t *)((int64_t)&arg_68h + iVar15) == 0) || (iVar18 == 0)) || (iVar19 == 0)) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d38c7;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar15), *(int64_t *)(&stack0xffffffffffffffe8 + iVar15));
        *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d38df;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar15), *(int64_t *)(&stack0xffffffffffffffe8 + iVar15), 
                      *(int64_t *)((int64_t)&var_10h + iVar15), *(int64_t *)((int64_t)&var_8h + iVar15), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar15 + 8));
    } else {
        *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d368e;
        iVar24 = func_0x00018025b2a0();
        if (iVar24 == 0) {
code_r0x0001801d38b3:
            *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d38b8;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar15), *(int64_t *)(&stack0xffffffffffffffe8 + iVar15));
        } else {
            *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d36b1;
            iVar13 = func_0x00018025b310(iVar24, 0x1804af230, *(undefined8 *)((int64_t)&arg_68h + iVar15));
            iVar20 = iVar25;
            if (iVar13 == 0) goto code_r0x0001801d38b3;
            *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d36cb;
            iVar13 = func_0x00018025b310(iVar24, 0x1804af234, iVar18);
            if (iVar13 == 0) goto code_r0x0001801d38b3;
            *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d36e5;
            iVar13 = func_0x00018025b310(iVar24, 0x1804afebc, iVar19);
            if (iVar13 == 0) goto code_r0x0001801d38b3;
            *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d36f5;
            iVar20 = func_0x00018025b5a0(iVar24);
            if (iVar20 == 0) goto code_r0x0001801d38b3;
            uVar17 = puVar7[0x8c];
            uVar9 = *puVar7;
            *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d3717;
            iVar21 = func_0x0001802591e0(uVar9, 0x1804ad19c, uVar17);
            if (iVar21 != 0) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d374f;
                iVar13 = func_0x00018025a8a0(iVar21);
                if (0 < iVar13) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d3770;
                    iVar13 = func_0x00018025a780(iVar21, (int64_t)&arg_60h + iVar15, 0x87, iVar20);
                    if (0 < iVar13) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d3780;
                        fcn.180258be0(iVar21);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d3797;
                        iVar21 = fcn.180259210(*(int64_t *)((int64_t)&var_20h + iVar15));
                        if (iVar21 != 0) {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d37ab;
                            iVar13 = func_0x00018026ebd0(iVar21);
                            if (iVar13 == 1) {
                                *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d37bc;
                                iVar13 = func_0x00018026ebf0(iVar21);
                                if (iVar13 == 1) {
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d37d2;
                                    uVar14 = func_0x00018022fb60(*(undefined8 *)((int64_t)&arg_60h + iVar15));
                                    *(undefined8 *)((int64_t)&var_20h + iVar15) =
                                         *(undefined8 *)((int64_t)&arg_60h + iVar15);
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d37f2;
                                    iVar13 = func_0x0001801a2690(placeholder_0, 0x40007, uVar14, 0);
                                    if (iVar13 != 0) {
                                        *(undefined8 *)(placeholder_0 + 0x4e0) =
                                             *(undefined8 *)((int64_t)&arg_60h + iVar15);
                                        iVar23 = *(int64_t *)(placeholder_0 + 0x300);
                                        *(undefined8 *)((int64_t)&arg_60h + iVar15) = 0;
                                        if ((*(uint8_t *)(iVar23 + 0x20) & 3) != 0) {
                                            *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d384f;
                                            uVar17 = fcn.1801b1140(placeholder_0);
                                            **(undefined8 **)((int64_t)&arg_70h + iVar15) = uVar17;
                                        }
                                        iVar23 = 1;
                                        goto code_r0x0001801d38f5;
                                    }
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d37fb;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar15), 
                                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar15));
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d3813;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar15), 
                                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar15), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar15), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar15), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar15 + 8));
                                    goto code_r0x0001801d38ea;
                                }
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d3869;
                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar15), 
                                      *(int64_t *)(&stack0xffffffffffffffe8 + iVar15));
                        *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d3881;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar15), 
                                      *(int64_t *)(&stack0xffffffffffffffe8 + iVar15), 
                                      *(int64_t *)((int64_t)&var_10h + iVar15), *(int64_t *)((int64_t)&var_8h + iVar15)
                                      , *(int64_t *)((int64_t)aiStackX_8 + iVar15 + 8));
                        goto code_r0x0001801d38ea;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d3893;
                fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar15), *(int64_t *)(&stack0xffffffffffffffe8 + iVar15))
                ;
                *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d38ab;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar15), *(int64_t *)(&stack0xffffffffffffffe8 + iVar15)
                              , *(int64_t *)((int64_t)&var_10h + iVar15), *(int64_t *)((int64_t)&var_8h + iVar15), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar15 + 8));
                goto code_r0x0001801d38ea;
            }
            *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d3724;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar15), *(int64_t *)(&stack0xffffffffffffffe8 + iVar15));
        }
        *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d373c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar15), *(int64_t *)(&stack0xffffffffffffffe8 + iVar15), 
                      *(int64_t *)((int64_t)&var_10h + iVar15), *(int64_t *)((int64_t)&var_8h + iVar15), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar15 + 8));
    }
code_r0x0001801d38ea:
    *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d38f5;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000000 + iVar15));
code_r0x0001801d38f5:
    *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d38fd;
    func_0x00018025b220(iVar24);
    *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d3905;
    func_0x000180256a40(iVar20);
    *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d3912;
    fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_60h + iVar15));
    *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d391a;
    fcn.180258be0(iVar21);
    *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d3927;
    fcn.180255290(*(undefined8 *)((int64_t)&arg_68h + iVar15));
    *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d392f;
    fcn.180255290(iVar18);
    *(undefined8 *)((int64_t)&uStack_48 + iVar15) = 0x1801d3937;
    fcn.180255290(iVar19);
    return iVar23;
}

// ============================================================
// Function: FUN_1801d3990
// Address: 0x1801d3990
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801d3990(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    uint8_t uVar3;
    uint32_t uVar4;
    uint8_t *puVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    undefined8 uVar12;
    int64_t in_RCX;
    uint8_t *puVar13;
    uint8_t **in_RDX;
    undefined8 unaff_RSI;
    undefined8 *in_R8;
    uint8_t *puVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d39a6;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    puVar13 = in_RDX[1];
    if (puVar13 == (uint8_t *)0x0) {
code_r0x0001801d3ba0:
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3ba5;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3bbd;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                      *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10), 
                      *(int64_t *)((int64_t)&arg_48h + iVar10));
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3bd3;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar10));
        return 0;
    }
    puVar5 = *in_RDX;
    uVar1 = *puVar5;
    *in_RDX = puVar5 + 1;
    in_RDX[1] = puVar13 + -1;
    if (puVar13 + -1 < (uint8_t *)0x2) goto code_r0x0001801d3ba0;
    uVar2 = puVar5[2];
    *(undefined8 *)((int64_t)&arg_38h + iVar10) = unaff_RSI;
    uVar3 = puVar5[1];
    *in_RDX = puVar5 + 3;
    in_RDX[1] = puVar13 + -3;
    if (uVar1 == 3) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a19;
        iVar9 = fcn.1801aac50(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a2c;
            iVar11 = fcn.1801c6590(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                                   *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10));
            *(int64_t *)(in_RCX + 0x4e0) = iVar11;
            if (iVar11 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a3d;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a55;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                              *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10), 
                              *(int64_t *)((int64_t)&arg_48h + iVar10));
            } else {
                puVar5 = *in_RDX;
                puVar14 = in_RDX[1];
                puVar13 = in_RDX[1];
                *(uint8_t **)((int64_t)&var_18h + iVar10) = puVar5;
                *(uint8_t **)((int64_t)&var_20h + iVar10) = puVar14;
                if (puVar13 != (uint8_t *)0x0) {
                    puVar13 = puVar13 + -1;
                    puVar14 = (uint8_t *)(uint64_t)*puVar5;
                    if (puVar14 <= puVar13) {
                        *(int64_t *)((int64_t)&var_20h + iVar10) = (int64_t)puVar13 - (int64_t)puVar14;
                        *(uint8_t **)((int64_t)&var_18h + iVar10) = puVar5 + 1 + (int64_t)puVar14;
                        uVar6 = *(undefined4 *)((int64_t)&var_18h + iVar10 + 4);
                        uVar7 = *(undefined4 *)((int64_t)&var_20h + iVar10);
                        uVar8 = *(undefined4 *)((int64_t)&var_20h + iVar10 + 4);
                        *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_18h + iVar10);
                        *(undefined4 *)((int64_t)in_RDX + 4) = uVar6;
                        *(undefined4 *)(in_RDX + 1) = uVar7;
                        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar8;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3ad6;
                        iVar9 = fcn.180230390(*(int64_t *)((int64_t)&arg_38h + iVar10), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar10), 
                                              *(int64_t *)(&stack0x00000058 + iVar10), 
                                              *(int64_t *)(&stack0x00000060 + iVar10), 
                                              *(int64_t *)(&stack0x00000070 + iVar10), 
                                              *(int64_t *)(&stack0x00000080 + iVar10));
                        if (0 < iVar9) {
                            uVar4 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20);
                            if (((uVar4 & 8) != 0) || ((uVar4 & 1) != 0)) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b26;
                                uVar12 = fcn.1801b1140(in_RCX);
                                *in_R8 = uVar12;
                            }
                            *(uint32_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x304) = (uint32_t)CONCAT11(uVar3, uVar2);
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3adf;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10)
                                     );
                        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3af7;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10)
                                      , *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10)
                                      , *(int64_t *)((int64_t)&arg_48h + iVar10));
                        goto code_r0x0001801d3a63;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b45;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b5d;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                              *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10), 
                              *(int64_t *)((int64_t)&arg_48h + iVar10));
            }
            goto code_r0x0001801d3a63;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b75;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b8d;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                  *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10), 
                  *(int64_t *)((int64_t)&arg_48h + iVar10));
code_r0x0001801d3a63:
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a6b;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar10));
    return 0;
}

// ============================================================
// Function: FUN_1801d39e2
// Address: 0x1801d39e2
// Size: 161 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801d3990(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    uint8_t uVar3;
    uint32_t uVar4;
    uint8_t *puVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    undefined8 uVar12;
    int64_t in_RCX;
    uint8_t *puVar13;
    uint8_t **in_RDX;
    undefined8 unaff_RSI;
    undefined8 *in_R8;
    uint8_t *puVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d39a6;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    puVar13 = in_RDX[1];
    if (puVar13 == (uint8_t *)0x0) {
code_r0x0001801d3ba0:
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3ba5;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3bbd;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                      *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10), 
                      *(int64_t *)((int64_t)&arg_48h + iVar10));
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3bd3;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar10));
        return 0;
    }
    puVar5 = *in_RDX;
    uVar1 = *puVar5;
    *in_RDX = puVar5 + 1;
    in_RDX[1] = puVar13 + -1;
    if (puVar13 + -1 < (uint8_t *)0x2) goto code_r0x0001801d3ba0;
    uVar2 = puVar5[2];
    *(undefined8 *)((int64_t)&arg_38h + iVar10) = unaff_RSI;
    uVar3 = puVar5[1];
    *in_RDX = puVar5 + 3;
    in_RDX[1] = puVar13 + -3;
    if (uVar1 == 3) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a19;
        iVar9 = fcn.1801aac50(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a2c;
            iVar11 = fcn.1801c6590(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                                   *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10));
            *(int64_t *)(in_RCX + 0x4e0) = iVar11;
            if (iVar11 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a3d;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a55;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                              *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10), 
                              *(int64_t *)((int64_t)&arg_48h + iVar10));
            } else {
                puVar5 = *in_RDX;
                puVar14 = in_RDX[1];
                puVar13 = in_RDX[1];
                *(uint8_t **)((int64_t)&var_18h + iVar10) = puVar5;
                *(uint8_t **)((int64_t)&var_20h + iVar10) = puVar14;
                if (puVar13 != (uint8_t *)0x0) {
                    puVar13 = puVar13 + -1;
                    puVar14 = (uint8_t *)(uint64_t)*puVar5;
                    if (puVar14 <= puVar13) {
                        *(int64_t *)((int64_t)&var_20h + iVar10) = (int64_t)puVar13 - (int64_t)puVar14;
                        *(uint8_t **)((int64_t)&var_18h + iVar10) = puVar5 + 1 + (int64_t)puVar14;
                        uVar6 = *(undefined4 *)((int64_t)&var_18h + iVar10 + 4);
                        uVar7 = *(undefined4 *)((int64_t)&var_20h + iVar10);
                        uVar8 = *(undefined4 *)((int64_t)&var_20h + iVar10 + 4);
                        *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_18h + iVar10);
                        *(undefined4 *)((int64_t)in_RDX + 4) = uVar6;
                        *(undefined4 *)(in_RDX + 1) = uVar7;
                        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar8;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3ad6;
                        iVar9 = fcn.180230390(*(int64_t *)((int64_t)&arg_38h + iVar10), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar10), 
                                              *(int64_t *)(&stack0x00000058 + iVar10), 
                                              *(int64_t *)(&stack0x00000060 + iVar10), 
                                              *(int64_t *)(&stack0x00000070 + iVar10), 
                                              *(int64_t *)(&stack0x00000080 + iVar10));
                        if (0 < iVar9) {
                            uVar4 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20);
                            if (((uVar4 & 8) != 0) || ((uVar4 & 1) != 0)) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b26;
                                uVar12 = fcn.1801b1140(in_RCX);
                                *in_R8 = uVar12;
                            }
                            *(uint32_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x304) = (uint32_t)CONCAT11(uVar3, uVar2);
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3adf;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10)
                                     );
                        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3af7;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10)
                                      , *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10)
                                      , *(int64_t *)((int64_t)&arg_48h + iVar10));
                        goto code_r0x0001801d3a63;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b45;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b5d;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                              *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10), 
                              *(int64_t *)((int64_t)&arg_48h + iVar10));
            }
            goto code_r0x0001801d3a63;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b75;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b8d;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                  *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10), 
                  *(int64_t *)((int64_t)&arg_48h + iVar10));
code_r0x0001801d3a63:
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a6b;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar10));
    return 0;
}

// ============================================================
// Function: FUN_1801d3a83
// Address: 0x1801d3a83
// Size: 285 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801d3990(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    uint8_t uVar3;
    uint32_t uVar4;
    uint8_t *puVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    undefined8 uVar12;
    int64_t in_RCX;
    uint8_t *puVar13;
    uint8_t **in_RDX;
    undefined8 unaff_RSI;
    undefined8 *in_R8;
    uint8_t *puVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d39a6;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    puVar13 = in_RDX[1];
    if (puVar13 == (uint8_t *)0x0) {
code_r0x0001801d3ba0:
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3ba5;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3bbd;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                      *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10), 
                      *(int64_t *)((int64_t)&arg_48h + iVar10));
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3bd3;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar10));
        return 0;
    }
    puVar5 = *in_RDX;
    uVar1 = *puVar5;
    *in_RDX = puVar5 + 1;
    in_RDX[1] = puVar13 + -1;
    if (puVar13 + -1 < (uint8_t *)0x2) goto code_r0x0001801d3ba0;
    uVar2 = puVar5[2];
    *(undefined8 *)((int64_t)&arg_38h + iVar10) = unaff_RSI;
    uVar3 = puVar5[1];
    *in_RDX = puVar5 + 3;
    in_RDX[1] = puVar13 + -3;
    if (uVar1 == 3) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a19;
        iVar9 = fcn.1801aac50(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a2c;
            iVar11 = fcn.1801c6590(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                                   *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10));
            *(int64_t *)(in_RCX + 0x4e0) = iVar11;
            if (iVar11 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a3d;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a55;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                              *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10), 
                              *(int64_t *)((int64_t)&arg_48h + iVar10));
            } else {
                puVar5 = *in_RDX;
                puVar14 = in_RDX[1];
                puVar13 = in_RDX[1];
                *(uint8_t **)((int64_t)&var_18h + iVar10) = puVar5;
                *(uint8_t **)((int64_t)&var_20h + iVar10) = puVar14;
                if (puVar13 != (uint8_t *)0x0) {
                    puVar13 = puVar13 + -1;
                    puVar14 = (uint8_t *)(uint64_t)*puVar5;
                    if (puVar14 <= puVar13) {
                        *(int64_t *)((int64_t)&var_20h + iVar10) = (int64_t)puVar13 - (int64_t)puVar14;
                        *(uint8_t **)((int64_t)&var_18h + iVar10) = puVar5 + 1 + (int64_t)puVar14;
                        uVar6 = *(undefined4 *)((int64_t)&var_18h + iVar10 + 4);
                        uVar7 = *(undefined4 *)((int64_t)&var_20h + iVar10);
                        uVar8 = *(undefined4 *)((int64_t)&var_20h + iVar10 + 4);
                        *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_18h + iVar10);
                        *(undefined4 *)((int64_t)in_RDX + 4) = uVar6;
                        *(undefined4 *)(in_RDX + 1) = uVar7;
                        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar8;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3ad6;
                        iVar9 = fcn.180230390(*(int64_t *)((int64_t)&arg_38h + iVar10), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar10), 
                                              *(int64_t *)(&stack0x00000058 + iVar10), 
                                              *(int64_t *)(&stack0x00000060 + iVar10), 
                                              *(int64_t *)(&stack0x00000070 + iVar10), 
                                              *(int64_t *)(&stack0x00000080 + iVar10));
                        if (0 < iVar9) {
                            uVar4 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20);
                            if (((uVar4 & 8) != 0) || ((uVar4 & 1) != 0)) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b26;
                                uVar12 = fcn.1801b1140(in_RCX);
                                *in_R8 = uVar12;
                            }
                            *(uint32_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x304) = (uint32_t)CONCAT11(uVar3, uVar2);
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3adf;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10)
                                     );
                        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3af7;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10)
                                      , *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10)
                                      , *(int64_t *)((int64_t)&arg_48h + iVar10));
                        goto code_r0x0001801d3a63;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b45;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b5d;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                              *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10), 
                              *(int64_t *)((int64_t)&arg_48h + iVar10));
            }
            goto code_r0x0001801d3a63;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b75;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b8d;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                  *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10), 
                  *(int64_t *)((int64_t)&arg_48h + iVar10));
code_r0x0001801d3a63:
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a6b;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar10));
    return 0;
}

// ============================================================
// Function: FUN_1801d3ba0
// Address: 0x1801d3ba0
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801d3990(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    uint8_t uVar3;
    uint32_t uVar4;
    uint8_t *puVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    undefined8 uVar12;
    int64_t in_RCX;
    uint8_t *puVar13;
    uint8_t **in_RDX;
    undefined8 unaff_RSI;
    undefined8 *in_R8;
    uint8_t *puVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801d39a6;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    puVar13 = in_RDX[1];
    if (puVar13 == (uint8_t *)0x0) {
code_r0x0001801d3ba0:
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3ba5;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3bbd;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                      *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10), 
                      *(int64_t *)((int64_t)&arg_48h + iVar10));
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3bd3;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar10));
        return 0;
    }
    puVar5 = *in_RDX;
    uVar1 = *puVar5;
    *in_RDX = puVar5 + 1;
    in_RDX[1] = puVar13 + -1;
    if (puVar13 + -1 < (uint8_t *)0x2) goto code_r0x0001801d3ba0;
    uVar2 = puVar5[2];
    *(undefined8 *)((int64_t)&arg_38h + iVar10) = unaff_RSI;
    uVar3 = puVar5[1];
    *in_RDX = puVar5 + 3;
    in_RDX[1] = puVar13 + -3;
    if (uVar1 == 3) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a19;
        iVar9 = fcn.1801aac50(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a2c;
            iVar11 = fcn.1801c6590(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                                   *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10));
            *(int64_t *)(in_RCX + 0x4e0) = iVar11;
            if (iVar11 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a3d;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a55;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                              *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10), 
                              *(int64_t *)((int64_t)&arg_48h + iVar10));
            } else {
                puVar5 = *in_RDX;
                puVar14 = in_RDX[1];
                puVar13 = in_RDX[1];
                *(uint8_t **)((int64_t)&var_18h + iVar10) = puVar5;
                *(uint8_t **)((int64_t)&var_20h + iVar10) = puVar14;
                if (puVar13 != (uint8_t *)0x0) {
                    puVar13 = puVar13 + -1;
                    puVar14 = (uint8_t *)(uint64_t)*puVar5;
                    if (puVar14 <= puVar13) {
                        *(int64_t *)((int64_t)&var_20h + iVar10) = (int64_t)puVar13 - (int64_t)puVar14;
                        *(uint8_t **)((int64_t)&var_18h + iVar10) = puVar5 + 1 + (int64_t)puVar14;
                        uVar6 = *(undefined4 *)((int64_t)&var_18h + iVar10 + 4);
                        uVar7 = *(undefined4 *)((int64_t)&var_20h + iVar10);
                        uVar8 = *(undefined4 *)((int64_t)&var_20h + iVar10 + 4);
                        *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_18h + iVar10);
                        *(undefined4 *)((int64_t)in_RDX + 4) = uVar6;
                        *(undefined4 *)(in_RDX + 1) = uVar7;
                        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar8;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3ad6;
                        iVar9 = fcn.180230390(*(int64_t *)((int64_t)&arg_38h + iVar10), 
                                              *(int64_t *)((int64_t)&arg_48h + iVar10), 
                                              *(int64_t *)(&stack0x00000058 + iVar10), 
                                              *(int64_t *)(&stack0x00000060 + iVar10), 
                                              *(int64_t *)(&stack0x00000070 + iVar10), 
                                              *(int64_t *)(&stack0x00000080 + iVar10));
                        if (0 < iVar9) {
                            uVar4 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20);
                            if (((uVar4 & 8) != 0) || ((uVar4 & 1) != 0)) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b26;
                                uVar12 = fcn.1801b1140(in_RCX);
                                *in_R8 = uVar12;
                            }
                            *(uint32_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x304) = (uint32_t)CONCAT11(uVar3, uVar2);
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3adf;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10)
                                     );
                        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3af7;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10)
                                      , *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10)
                                      , *(int64_t *)((int64_t)&arg_48h + iVar10));
                        goto code_r0x0001801d3a63;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b45;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
                *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b5d;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                              *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10), 
                              *(int64_t *)((int64_t)&arg_48h + iVar10));
            }
            goto code_r0x0001801d3a63;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b75;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10));
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3b8d;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar10), *(int64_t *)((int64_t)&var_20h + iVar10), 
                  *(int64_t *)(&stack0x00000028 + iVar10), *(int64_t *)(&stack0x00000030 + iVar10), 
                  *(int64_t *)((int64_t)&arg_48h + iVar10));
code_r0x0001801d3a63:
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801d3a6b;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar10));
    return 0;
}

// ============================================================
// Function: FUN_1801d3bf0
// Address: 0x1801d3bf0
// Size: 601 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.1801d3bf0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    undefined *puVar1;
    uint8_t *puVar2;
    uint8_t *puVar3;
    undefined uVar4;
    undefined uVar5;
    uint8_t uVar6;
    uint8_t uVar7;
    undefined *puVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int32_t iVar12;
    int64_t iVar13;
    uint64_t uVar14;
    undefined8 uVar15;
    int64_t in_RCX;
    int64_t iVar16;
    undefined4 *in_RDX;
    uint64_t uVar17;
    uint64_t uVar18;
    uint64_t uVar19;
    undefined8 *in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801d3c12;
    iVar13 = fcn.18045a350();
    iVar13 = -iVar13;
    uVar9 = in_RDX[1];
    uVar10 = in_RDX[2];
    uVar11 = in_RDX[3];
    uVar14 = *(uint64_t *)(in_RDX + 2);
    *(undefined4 *)(&stack0xfffffffffffffff8 + iVar13) = *in_RDX;
    *(undefined4 *)(&stack0xfffffffffffffffc + iVar13) = uVar9;
    *(undefined4 *)(&stack0x00000000 + iVar13) = uVar10;
    *(undefined4 *)(&stack0x00000004 + iVar13) = uVar11;
    if (1 < uVar14) {
        puVar8 = *(undefined **)(&stack0xfffffffffffffff8 + iVar13);
        puVar1 = puVar8 + 2;
        uVar14 = uVar14 - 2;
        uVar17 = (uint64_t)CONCAT11(*puVar8, puVar8[1]);
        *(undefined **)(&stack0xfffffffffffffff8 + iVar13) = puVar1;
        if (uVar17 <= uVar14) {
            uVar14 = uVar14 - uVar17;
            puVar8 = puVar1 + uVar17;
            *(undefined **)(&stack0xfffffffffffffff8 + iVar13) = puVar8;
            *(uint64_t *)(&stack0x00000000 + iVar13) = uVar14;
            uVar9 = *(undefined4 *)(&stack0xfffffffffffffffc + iVar13);
            uVar10 = *(undefined4 *)(&stack0x00000000 + iVar13);
            uVar11 = *(undefined4 *)(&stack0x00000004 + iVar13);
            *in_RDX = *(undefined4 *)(&stack0xfffffffffffffff8 + iVar13);
            in_RDX[1] = uVar9;
            in_RDX[2] = uVar10;
            in_RDX[3] = uVar11;
            if (1 < uVar14) {
                uVar4 = puVar8[1];
                uVar5 = *puVar8;
                puVar8 = puVar8 + 2;
                uVar19 = (uint64_t)CONCAT11(uVar5, uVar4);
                *(undefined **)(&stack0xfffffffffffffff8 + iVar13) = puVar8;
                if (uVar19 <= uVar14 - 2) {
                    puVar2 = puVar8 + uVar19;
                    iVar16 = (uVar14 - 2) - uVar19;
                    *(uint8_t **)(&stack0xfffffffffffffff8 + iVar13) = puVar2;
                    *(int64_t *)(&stack0x00000000 + iVar13) = iVar16;
                    uVar9 = *(undefined4 *)(&stack0xfffffffffffffffc + iVar13);
                    uVar10 = *(undefined4 *)(&stack0x00000000 + iVar13);
                    uVar11 = *(undefined4 *)(&stack0x00000004 + iVar13);
                    *in_RDX = *(undefined4 *)(&stack0xfffffffffffffff8 + iVar13);
                    in_RDX[1] = uVar9;
                    in_RDX[2] = uVar10;
                    in_RDX[3] = uVar11;
                    if (iVar16 != 0) {
                        uVar14 = (uint64_t)*puVar2;
                        puVar2 = puVar2 + 1;
                        *(uint8_t **)(&stack0xfffffffffffffff8 + iVar13) = puVar2;
                        if (uVar14 <= iVar16 - 1U) {
                            uVar19 = (iVar16 - 1U) - uVar14;
                            puVar3 = puVar2 + uVar14;
                            *(uint8_t **)(&stack0xfffffffffffffff8 + iVar13) = puVar3;
                            *(uint64_t *)(&stack0x00000000 + iVar13) = uVar19;
                            uVar9 = *(undefined4 *)(&stack0xfffffffffffffffc + iVar13);
                            uVar10 = *(undefined4 *)(&stack0x00000000 + iVar13);
                            uVar11 = *(undefined4 *)(&stack0x00000004 + iVar13);
                            *in_RDX = *(undefined4 *)(&stack0xfffffffffffffff8 + iVar13);
                            in_RDX[1] = uVar9;
                            in_RDX[2] = uVar10;
                            in_RDX[3] = uVar11;
                            if (1 < uVar19) {
                                uVar6 = puVar3[1];
                                uVar7 = *puVar3;
                                uVar18 = (uint64_t)CONCAT11(uVar7, uVar6);
                                if (uVar18 <= uVar19 - 2) {
                                    *(uint64_t *)(&stack0x00000000 + iVar13) = (uVar19 - 2) - uVar18;
                                    *(uint8_t **)(&stack0xfffffffffffffff8 + iVar13) = puVar3 + 2 + uVar18;
                                    uVar9 = *(undefined4 *)(&stack0xfffffffffffffffc + iVar13);
                                    uVar10 = *(undefined4 *)(&stack0x00000000 + iVar13);
                                    uVar11 = *(undefined4 *)(&stack0x00000004 + iVar13);
                                    *in_RDX = *(undefined4 *)(&stack0xfffffffffffffff8 + iVar13);
                                    in_RDX[1] = uVar9;
                                    in_RDX[2] = uVar10;
                                    in_RDX[3] = uVar11;
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d3d49;
                                    iVar16 = func_0x000180254c30(puVar1, uVar17, 0);
                                    *(int64_t *)(in_RCX + 0xbf8) = iVar16;
                                    if (iVar16 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d3d62;
                                        iVar16 = func_0x000180254c30(puVar8, CONCAT11(uVar5, uVar4), 0);
                                        *(int64_t *)(in_RCX + 0xc00) = iVar16;
                                        if (iVar16 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d3d7c;
                                            iVar16 = func_0x000180254c30(puVar2, uVar14, 0);
                                            *(int64_t *)(in_RCX + 0xc08) = iVar16;
                                            if (iVar16 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d3d95;
                                                iVar16 = func_0x000180254c30(puVar3 + 2, CONCAT11(uVar7, uVar6), 0);
                                                *(int64_t *)(in_RCX + 0xc10) = iVar16;
                                                if (iVar16 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d3da9;
                                                    iVar12 = func_0x0001801bd000(in_RCX);
                                                    if (iVar12 == 0) {
                                                        return 0;
                                                    }
                                                    if ((*(uint8_t *)(*(int64_t *)(in_RCX + 0x300) + 0x20) & 3) != 0) {
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d3dc2;
                                                        uVar15 = fcn.1801b1140(in_RCX);
                                                        *in_R8 = uVar15;
                                                    }
                                                    return 1;
                                                }
                                            }
                                        }
                                    }
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d3dd2;
                                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar13), 
                                                  *(int64_t *)(&stack0x00000000 + iVar13));
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d3dea;
                                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar13), 
                                                  *(int64_t *)(&stack0x00000000 + iVar13), 
                                                  *(int64_t *)((int64_t)&var_8h + iVar13), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar13), 
                                                  *(int64_t *)(&stack0x00000028 + iVar13));
                                    goto code_r0x0001801d3e1f;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d3dfc;
    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar13), *(int64_t *)(&stack0x00000000 + iVar13));
    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d3e14;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar13), *(int64_t *)(&stack0x00000000 + iVar13), 
                  *(int64_t *)((int64_t)&var_8h + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13), 
                  *(int64_t *)(&stack0x00000028 + iVar13));
code_r0x0001801d3e1f:
    *(undefined8 *)((int64_t)&uStack_30 + iVar13) = 0x1801d3e2a;
    fcn.18019b5e0(*(int64_t *)((int64_t)&var_18h + iVar13));
    return 0;
}

// ============================================================
// Function: FUN_1801d3e50
// Address: 0x1801d3e50
// Size: 1303 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int32_t * fcn.1801d3e50(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_68h)
{
    undefined4 uVar1;
    uint8_t *puVar2;
    uint32_t *puVar3;
    undefined8 uVar4;
    undefined4 *puVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int32_t *piVar9;
    int64_t iVar10;
    int32_t *piVar11;
    int32_t *piVar12;
    uint32_t uVar13;
    int32_t **in_RCX;
    undefined8 *in_RDX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801d3e6c;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = *in_RDX;
    piVar12 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d3e99;
    piVar8 = (int32_t *)func_0x000180261770(0, (int64_t)&arg_50h + iVar7);
    piVar9 = piVar12;
    if (piVar8 == (int32_t *)0x0) goto code_r0x0001801d3eef;
    if ((in_RCX == (int32_t **)0x0) || (piVar9 = *in_RCX, piVar9 == (int32_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d3eb3;
        piVar9 = (int32_t *)func_0x00018019cd20();
        if (piVar9 == (int32_t *)0x0) goto code_r0x0001801d3eef;
    }
    if (*piVar8 == 1) {
        iVar6 = piVar8[1];
        if (((iVar6 >> 8 == 3) || (iVar6 >> 8 == 0xfe)) || (iVar6 == 0x100)) {
            *piVar9 = iVar6;
            piVar9[0xc1] = piVar8[0x2e];
            if (**(int32_t **)(piVar8 + 2) == 2) {
                puVar2 = *(uint8_t **)(*(int32_t **)(piVar8 + 2) + 2);
                piVar9[0xc0] = (*puVar2 | 0x30000) << 8 | (uint32_t)puVar2[1];
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d3fd4;
                iVar10 = func_0x0001801c51e0();
                *(int64_t *)(piVar9 + 0xbe) = iVar10;
                if (iVar10 == 0) goto code_r0x0001801d3eef;
                puVar3 = *(uint32_t **)(piVar8 + 8);
                piVar11 = piVar12;
                if (puVar3 != (uint32_t *)0x0) {
                    uVar13 = *puVar3;
                    if (uVar13 != 0) {
                        if (0x20 < uVar13) goto code_r0x0001801d3eef;
                        uVar4 = *(undefined8 *)(puVar3 + 2);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d4010;
                        fcn.180498030(piVar9 + 0x96, uVar4, (int64_t)(int32_t)uVar13);
                        piVar11 = (int32_t *)(int64_t)(int32_t)*puVar3;
                    }
                }
                *(int32_t **)(piVar9 + 0x94) = piVar11;
                puVar3 = *(uint32_t **)(piVar8 + 6);
                piVar11 = piVar12;
                if (puVar3 != (uint32_t *)0x0) {
                    uVar13 = *puVar3;
                    if (uVar13 != 0) {
                        if (0x200 < uVar13) goto code_r0x0001801d3eef;
                        uVar4 = *(undefined8 *)(puVar3 + 2);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d404a;
                        fcn.180498030(piVar9 + 0x14, uVar4, (int64_t)(int32_t)uVar13);
                        piVar11 = (int32_t *)(int64_t)(int32_t)*puVar3;
                    }
                }
                *(int32_t **)(piVar9 + 2) = piVar11;
                if (*(int64_t *)(piVar8 + 0xc) == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d406d;
                    iVar10 = func_0x0001802450c0();
                } else {
                    iVar10 = *(int64_t *)(piVar8 + 0xc) * 1000000000;
                }
                *(int64_t *)(piVar9 + 0xb8) = iVar10;
                if (*(int64_t *)(piVar8 + 0xe) == 0) {
                    iVar10 = 3000000000;
                } else {
                    iVar10 = *(int64_t *)(piVar8 + 0xe) * 1000000000;
                }
                *(int64_t *)(piVar9 + 0xb6) = iVar10;
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d409a;
                func_0x00018019dbf0(piVar9);
                uVar4 = *(undefined8 *)(piVar9 + 0xb0);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d40a6;
                fcn.18021fe80(uVar4);
                *(undefined8 *)(piVar9 + 0xb0) = *(undefined8 *)(piVar8 + 0x10);
                *(undefined8 *)(piVar8 + 0x10) = 0;
                uVar4 = *(undefined8 *)(piVar9 + 0xae);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d40c1;
                fcn.18022ecc0(uVar4);
                *(undefined8 *)(piVar9 + 0xae) = 0;
                puVar5 = *(undefined4 **)(piVar8 + 0x30);
                if (puVar5 != (undefined4 *)0x0) {
                    *(undefined8 *)((int64_t)&iStackX_10 + iVar7 + -8) = *(undefined8 *)(puVar5 + 2);
                    uVar1 = *puVar5;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = *(undefined8 *)((int64_t)&arg_68h + iVar7);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d40fc;
                    iVar10 = func_0x000180235e90(0, (int64_t)&iStackX_10 + iVar7 + -8, uVar1, in_R9);
                    *(int64_t *)(piVar9 + 0xae) = iVar10;
                    if (iVar10 == 0) goto code_r0x0001801d3eef;
                }
                puVar3 = *(uint32_t **)(piVar8 + 0x12);
                if (puVar3 != (uint32_t *)0x0) {
                    uVar13 = *puVar3;
                    if (uVar13 != 0) {
                        if (0x20 < uVar13) goto code_r0x0001801d3eef;
                        uVar4 = *(undefined8 *)(puVar3 + 2);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d4138;
                        fcn.180498030(piVar9 + 0xa0, uVar4, (int64_t)(int32_t)uVar13);
                        piVar12 = (int32_t *)(int64_t)(int32_t)*puVar3;
                    }
                }
                *(int32_t **)(piVar9 + 0x9e) = piVar12;
                piVar9[0xb4] = piVar8[0x14];
                uVar4 = *(undefined8 *)(piVar8 + 0x16);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d4160;
                iVar6 = func_0x0001801d4770(piVar9 + 0xc6, uVar4);
                if (iVar6 == 0) goto code_r0x0001801d3eef;
                uVar4 = *(undefined8 *)(piVar8 + 0x1e);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d4178;
                iVar6 = func_0x0001801d4770(piVar9 + 0xa8, uVar4);
                if (iVar6 == 0) goto code_r0x0001801d3eef;
                uVar4 = *(undefined8 *)(piVar8 + 0x20);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d4193;
                iVar6 = func_0x0001801d4770(piVar9 + 0xaa, uVar4);
                if (iVar6 == 0) goto code_r0x0001801d3eef;
                uVar4 = *(undefined8 *)(piVar9 + 200);
                piVar9[0xcc] = piVar8[0x18];
                piVar9[0xcd] = piVar8[0x1a];
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d41c6;
                fcn.180224990(uVar4, 0x1804b45e8, 0x173);
                if (*(int64_t *)(piVar8 + 0x1c) == 0) {
                    *(undefined8 *)(piVar9 + 200) = 0;
                } else {
                    *(undefined8 *)(piVar9 + 200) = *(undefined8 *)(*(int64_t *)(piVar8 + 0x1c) + 8);
                    *(int64_t *)(piVar9 + 0xca) = (int64_t)**(int32_t **)(piVar8 + 0x1c);
                    *(undefined8 *)(*(int64_t *)(piVar8 + 0x1c) + 8) = 0;
                }
                piVar12 = *(int32_t **)(piVar8 + 4);
                if (piVar12 == (int32_t *)0x0) {
                    uVar13 = 0;
                } else {
                    if (*piVar12 != 1) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d420c;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                      *(int64_t *)(&stack0x00000000 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d4224;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), 
                                      *(int64_t *)(&stack0x00000000 + iVar7), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)(&stack0x00000028 + iVar7)
                                     );
                        goto code_r0x0001801d3ee5;
                    }
                    uVar13 = (uint32_t)**(uint8_t **)(piVar12 + 2);
                }
                piVar9[0xbc] = uVar13;
                uVar4 = *(undefined8 *)(piVar8 + 0x22);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d4256;
                iVar6 = func_0x0001801d4770(piVar9 + 0xd6, uVar4);
                if (iVar6 != 0) {
                    uVar4 = *(undefined8 *)(piVar9 + 0xd0);
                    piVar9[0xdc] = piVar8[0x24];
                    piVar9[0xce] = piVar8[0x26];
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d428f;
                    fcn.180224990(uVar4, 0x1804b45e8, 399);
                    if (*(int64_t *)(piVar8 + 0x28) == 0) {
                        *(undefined8 *)(piVar9 + 0xd0) = 0;
                        *(undefined8 *)(piVar9 + 0xd2) = 0;
                    } else {
                        *(undefined8 *)(piVar9 + 0xd0) = *(undefined8 *)(*(int64_t *)(piVar8 + 0x28) + 8);
                        *(int64_t *)(piVar9 + 0xd2) = (int64_t)**(int32_t **)(piVar8 + 0x28);
                        *(undefined8 *)(*(int64_t *)(piVar8 + 0x28) + 8) = 0;
                    }
                    uVar4 = *(undefined8 *)(piVar9 + 0xd8);
                    *(undefined *)(piVar9 + 0xd4) = *(undefined *)(piVar8 + 0x2a);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d42f8;
                    fcn.180224990(uVar4, 0x1804b45e8, 0x19b);
                    if (*(int64_t *)(piVar8 + 0x2c) == 0) {
                        *(undefined8 *)(piVar9 + 0xd8) = 0;
                        *(undefined8 *)(piVar9 + 0xda) = 0;
                    } else {
                        *(undefined8 *)(piVar9 + 0xd8) = *(undefined8 *)(*(int64_t *)(piVar8 + 0x2c) + 8);
                        *(int64_t *)(piVar9 + 0xda) = (int64_t)**(int32_t **)(piVar8 + 0x2c);
                        *(undefined8 *)(*(int64_t *)(piVar8 + 0x2c) + 8) = 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d434a;
                    fcn.1802612b0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)(&stack0x00000028 + iVar7));
                    if ((in_RCX != (int32_t **)0x0) && (*in_RCX == (int32_t *)0x0)) {
                        *in_RCX = piVar9;
                    }
                    *in_RDX = *(undefined8 *)((int64_t)&arg_50h + iVar7);
                    return piVar9;
                }
                goto code_r0x0001801d3eef;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d3f8e;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d3fa6;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                          *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                          *(int64_t *)(&stack0x00000028 + iVar7));
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d3f4d;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d3f65;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                          *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                          *(int64_t *)(&stack0x00000028 + iVar7));
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d3ec5;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d3edd;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7));
    }
code_r0x0001801d3ee5:
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d3eef;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar7));
code_r0x0001801d3eef:
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d3efe;
    fcn.1802612b0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)(&stack0x00000028 + iVar7));
    if ((in_RCX == (int32_t **)0x0) || (*in_RCX != piVar9)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801d3f10;
        func_0x00018019c980(piVar9);
    }
    return (int32_t *)0x0;
}

