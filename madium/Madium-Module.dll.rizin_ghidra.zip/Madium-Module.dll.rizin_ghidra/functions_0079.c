// Chunk 79 - 50 functions

// ============================================================
// Function: FUN_18010ba8b
// Address: 0x18010ba8b
// Size: 174 bytes
// ============================================================
uint64_t fcn.18010ba8b(int64_t arg_a8h)
{
    bool bVar1;
    char cVar2;
    uint64_t in_RAX;
    int64_t unaff_RBX;
    int32_t unaff_ESI;
    int64_t unaff_RDI;
    uint64_t uVar3;
    float *unaff_R13;
    int64_t unaff_R14;
    float fVar4;
    
    if (((*(uint8_t *)(unaff_RBX + 0x1f80) & 4) != 0) && ((*(uint8_t *)(unaff_RDI + 0x1fbc) & 0x40) == 0)) {
        if ((*(uint32_t *)(unaff_RDI + 0x1fa0) >> 0x12 & 1) != 0) {
            *(uint32_t *)(unaff_RDI + 0x1fc0) = *(uint32_t *)(unaff_RDI + 0x1fc0) | 0x400;
            *(undefined4 *)(unaff_RDI + 0x2004) = *(undefined4 *)(unaff_RDI + 0x1f9c);
        }
        in_RAX = func_0x000180109d80(*(undefined4 *)(unaff_RDI + 0x1f9c), *(uint32_t *)(unaff_RDI + 0x1fa0) & 0x3fcff, 
                                     unaff_ESI);
        uVar3 = *(uint64_t *)0x180781f28;
        if (((char)in_RAX != '\0') && (*(int32_t *)(unaff_RDI + 0x21ec) == 0)) {
            *(int32_t *)(unaff_RDI + 0x21ec) = unaff_ESI;
            *(undefined4 *)(unaff_RDI + 0x21f8) = 0x11;
            *(int32_t *)(unaff_RDI + 0x21f4) = unaff_ESI;
            *(int32_t *)(unaff_RDI + 0x21f0) = unaff_ESI;
            *(int32_t *)(uVar3 + 0x2210) = unaff_ESI;
            *(undefined4 *)(uVar3 + 0x2214) = 0x3dcccccd;
            in_RAX = uVar3;
        }
    }
    *(undefined8 *)(unaff_RBX + 0x1f80) = 0;
    fVar4 = unaff_R13[3];
    if ((((fVar4 < *(float *)(unaff_R14 + 700) || fVar4 == *(float *)(unaff_R14 + 700)) ||
         (fVar4 = *(float *)(unaff_R14 + 0x2c4), fVar4 < unaff_R13[1] || fVar4 == unaff_R13[1])) ||
        (fVar4 = unaff_R13[2], fVar4 < *(float *)(unaff_R14 + 0x2b8) || fVar4 == *(float *)(unaff_R14 + 0x2b8))) ||
       (fVar4 = *(float *)(unaff_R14 + 0x2c0), fVar4 < *unaff_R13 || fVar4 == *unaff_R13)) {
        bVar1 = false;
        if ((unaff_ESI == 0) ||
           (((unaff_ESI != *(int32_t *)(unaff_RBX + 0x1654) && (unaff_ESI != *(int32_t *)(unaff_RBX + 0x1680))) &&
            ((unaff_ESI != *(int32_t *)(unaff_RBX + 0x21d0) && (unaff_ESI != *(int32_t *)(unaff_RBX + 0x21ec))))))) {
            if (*(char *)(unaff_RBX + 0x1652) == '\0') {
                return in_RAX & 0xffffffffffffff00;
            }
            goto code_r0x00018010bb69;
        }
    } else {
        bVar1 = true;
code_r0x00018010bb69:
        if (unaff_ESI == 0) goto code_r0x00018010bb7e;
    }
    if (*(int32_t *)(unaff_RBX + 0x1684) == unaff_ESI) {
        *(undefined4 *)(unaff_RBX + 0x1688) = *(undefined4 *)(unaff_RBX + 4);
    }
code_r0x00018010bb7e:
    if (bVar1) {
        *(uint32_t *)(unaff_RBX + 0x1fc0) = *(uint32_t *)(unaff_RBX + 0x1fc0) | 0x100;
    }
    uVar3 = 1;
    cVar2 = func_0x000180108120(fVar4, unaff_R13 + 2, 1);
    if (cVar2 != '\0') {
        *(uint32_t *)(unaff_RBX + 0x1fc0) = *(uint32_t *)(unaff_RBX + 0x1fc0) | 1;
    }
    return uVar3 & 0xff;
}

// ============================================================
// Function: FUN_18010bb39
// Address: 0x18010bb39
// Size: 179 bytes
// ============================================================
uint64_t fcn.18010ba8b(int64_t arg_a8h)
{
    bool bVar1;
    char cVar2;
    uint64_t in_RAX;
    int64_t unaff_RBX;
    int32_t unaff_ESI;
    int64_t unaff_RDI;
    uint64_t uVar3;
    float *unaff_R13;
    int64_t unaff_R14;
    float fVar4;
    
    if (((*(uint8_t *)(unaff_RBX + 0x1f80) & 4) != 0) && ((*(uint8_t *)(unaff_RDI + 0x1fbc) & 0x40) == 0)) {
        if ((*(uint32_t *)(unaff_RDI + 0x1fa0) >> 0x12 & 1) != 0) {
            *(uint32_t *)(unaff_RDI + 0x1fc0) = *(uint32_t *)(unaff_RDI + 0x1fc0) | 0x400;
            *(undefined4 *)(unaff_RDI + 0x2004) = *(undefined4 *)(unaff_RDI + 0x1f9c);
        }
        in_RAX = func_0x000180109d80(*(undefined4 *)(unaff_RDI + 0x1f9c), *(uint32_t *)(unaff_RDI + 0x1fa0) & 0x3fcff, 
                                     unaff_ESI);
        uVar3 = *(uint64_t *)0x180781f28;
        if (((char)in_RAX != '\0') && (*(int32_t *)(unaff_RDI + 0x21ec) == 0)) {
            *(int32_t *)(unaff_RDI + 0x21ec) = unaff_ESI;
            *(undefined4 *)(unaff_RDI + 0x21f8) = 0x11;
            *(int32_t *)(unaff_RDI + 0x21f4) = unaff_ESI;
            *(int32_t *)(unaff_RDI + 0x21f0) = unaff_ESI;
            *(int32_t *)(uVar3 + 0x2210) = unaff_ESI;
            *(undefined4 *)(uVar3 + 0x2214) = 0x3dcccccd;
            in_RAX = uVar3;
        }
    }
    *(undefined8 *)(unaff_RBX + 0x1f80) = 0;
    fVar4 = unaff_R13[3];
    if ((((fVar4 < *(float *)(unaff_R14 + 700) || fVar4 == *(float *)(unaff_R14 + 700)) ||
         (fVar4 = *(float *)(unaff_R14 + 0x2c4), fVar4 < unaff_R13[1] || fVar4 == unaff_R13[1])) ||
        (fVar4 = unaff_R13[2], fVar4 < *(float *)(unaff_R14 + 0x2b8) || fVar4 == *(float *)(unaff_R14 + 0x2b8))) ||
       (fVar4 = *(float *)(unaff_R14 + 0x2c0), fVar4 < *unaff_R13 || fVar4 == *unaff_R13)) {
        bVar1 = false;
        if ((unaff_ESI == 0) ||
           (((unaff_ESI != *(int32_t *)(unaff_RBX + 0x1654) && (unaff_ESI != *(int32_t *)(unaff_RBX + 0x1680))) &&
            ((unaff_ESI != *(int32_t *)(unaff_RBX + 0x21d0) && (unaff_ESI != *(int32_t *)(unaff_RBX + 0x21ec))))))) {
            if (*(char *)(unaff_RBX + 0x1652) == '\0') {
                return in_RAX & 0xffffffffffffff00;
            }
            goto code_r0x00018010bb69;
        }
    } else {
        bVar1 = true;
code_r0x00018010bb69:
        if (unaff_ESI == 0) goto code_r0x00018010bb7e;
    }
    if (*(int32_t *)(unaff_RBX + 0x1684) == unaff_ESI) {
        *(undefined4 *)(unaff_RBX + 0x1688) = *(undefined4 *)(unaff_RBX + 4);
    }
code_r0x00018010bb7e:
    if (bVar1) {
        *(uint32_t *)(unaff_RBX + 0x1fc0) = *(uint32_t *)(unaff_RBX + 0x1fc0) | 0x100;
    }
    uVar3 = 1;
    cVar2 = func_0x000180108120(fVar4, unaff_R13 + 2, 1);
    if (cVar2 != '\0') {
        *(uint32_t *)(unaff_RBX + 0x1fc0) = *(uint32_t *)(unaff_RBX + 0x1fc0) | 1;
    }
    return uVar3 & 0xff;
}

// ============================================================
// Function: FUN_18010bbf0
// Address: 0x18010bbf0
// Size: 42 bytes
// ============================================================
void fcn.18010bbf0(int64_t arg1)
{
    float fVar1;
    int64_t iVar2;
    float fVar3;
    int64_t iVar4;
    int64_t iVar5;
    float fVar6;
    float in_XMM1_Da;
    float fVar7;
    float fVar8;
    float fVar9;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar4 = *(int64_t *)0x180781f28;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar2 + 0x10e) == '\0') {
        fVar9 = *(float *)(iVar2 + 400);
        fVar6 = 0.0;
        if ((0.0 <= in_XMM1_Da) && (0.0 <= fVar9 - in_XMM1_Da)) {
            fVar6 = fVar9 - in_XMM1_Da;
        }
        if (fVar9 <= in_XMM1_Da) {
            fVar9 = in_XMM1_Da;
        }
        iVar5 = 0x164;
        if (*(char *)(iVar2 + 0x198) == '\0') {
            iVar5 = 0x15c;
        }
        fVar7 = *(float *)(iVar2 + 0x158) + *(float *)arg1;
        fVar1 = *(float *)(iVar5 + iVar2);
        fVar8 = *(float *)(arg1 + 4);
        *(float *)(iVar2 + 0x164) = fVar1;
        *(float *)(iVar2 + 0x160) = fVar7;
        fVar6 = (*(float *)(iVar2 + 0x15c) - fVar1) + fVar8 + fVar6;
        fVar8 = *(float *)(iVar2 + 0x184);
        if (*(float *)(iVar2 + 0x184) <= fVar6) {
            fVar8 = fVar6;
        }
        *(float *)(iVar2 + 0x158) =
             (float)(int32_t)(*(float *)(iVar2 + 0x19c) + *(float *)(iVar2 + 0x60) + *(float *)(iVar2 + 0x1a0));
        fVar6 = *(float *)(iVar4 + 0xdf0);
        fVar3 = *(float *)(iVar2 + 0x170);
        if (*(float *)(iVar2 + 0x170) <= fVar7) {
            fVar3 = fVar7;
        }
        *(float *)(iVar2 + 0x170) = fVar3;
        fVar6 = (float)(int32_t)(fVar8 + fVar1 + fVar6);
        *(float *)(iVar2 + 0x15c) = fVar6;
        fVar6 = fVar6 - *(float *)(iVar4 + 0xdf0);
        *(float *)(iVar2 + 0x194) = fVar9;
        *(float *)(iVar2 + 0x18c) = fVar8;
        *(undefined4 *)(iVar2 + 0x184) = 0;
        fVar9 = *(float *)(iVar2 + 0x174);
        if (*(float *)(iVar2 + 0x174) <= fVar6) {
            fVar9 = fVar6;
        }
        *(undefined4 *)(iVar2 + 400) = 0;
        *(undefined2 *)(iVar2 + 0x198) = 0;
        *(float *)(iVar2 + 0x174) = fVar9;
        if (*(int32_t *)(iVar2 + 0x214) == 0) {
            func_0x00018010bd60(arg1, 0xbf800000);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18010bc1a
// Address: 0x18010bc1a
// Size: 298 bytes
// ============================================================
void fcn.18010bbf0(int64_t arg1)
{
    float fVar1;
    int64_t iVar2;
    float fVar3;
    int64_t iVar4;
    int64_t iVar5;
    float fVar6;
    float in_XMM1_Da;
    float fVar7;
    float fVar8;
    float fVar9;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar4 = *(int64_t *)0x180781f28;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar2 + 0x10e) == '\0') {
        fVar9 = *(float *)(iVar2 + 400);
        fVar6 = 0.0;
        if ((0.0 <= in_XMM1_Da) && (0.0 <= fVar9 - in_XMM1_Da)) {
            fVar6 = fVar9 - in_XMM1_Da;
        }
        if (fVar9 <= in_XMM1_Da) {
            fVar9 = in_XMM1_Da;
        }
        iVar5 = 0x164;
        if (*(char *)(iVar2 + 0x198) == '\0') {
            iVar5 = 0x15c;
        }
        fVar7 = *(float *)(iVar2 + 0x158) + *(float *)arg1;
        fVar1 = *(float *)(iVar5 + iVar2);
        fVar8 = *(float *)(arg1 + 4);
        *(float *)(iVar2 + 0x164) = fVar1;
        *(float *)(iVar2 + 0x160) = fVar7;
        fVar6 = (*(float *)(iVar2 + 0x15c) - fVar1) + fVar8 + fVar6;
        fVar8 = *(float *)(iVar2 + 0x184);
        if (*(float *)(iVar2 + 0x184) <= fVar6) {
            fVar8 = fVar6;
        }
        *(float *)(iVar2 + 0x158) =
             (float)(int32_t)(*(float *)(iVar2 + 0x19c) + *(float *)(iVar2 + 0x60) + *(float *)(iVar2 + 0x1a0));
        fVar6 = *(float *)(iVar4 + 0xdf0);
        fVar3 = *(float *)(iVar2 + 0x170);
        if (*(float *)(iVar2 + 0x170) <= fVar7) {
            fVar3 = fVar7;
        }
        *(float *)(iVar2 + 0x170) = fVar3;
        fVar6 = (float)(int32_t)(fVar8 + fVar1 + fVar6);
        *(float *)(iVar2 + 0x15c) = fVar6;
        fVar6 = fVar6 - *(float *)(iVar4 + 0xdf0);
        *(float *)(iVar2 + 0x194) = fVar9;
        *(float *)(iVar2 + 0x18c) = fVar8;
        *(undefined4 *)(iVar2 + 0x184) = 0;
        fVar9 = *(float *)(iVar2 + 0x174);
        if (*(float *)(iVar2 + 0x174) <= fVar6) {
            fVar9 = fVar6;
        }
        *(undefined4 *)(iVar2 + 400) = 0;
        *(undefined2 *)(iVar2 + 0x198) = 0;
        *(float *)(iVar2 + 0x174) = fVar9;
        if (*(int32_t *)(iVar2 + 0x214) == 0) {
            func_0x00018010bd60(arg1, 0xbf800000);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18010bd44
// Address: 0x18010bd44
// Size: 26 bytes
// ============================================================
void fcn.18010bbf0(int64_t arg1)
{
    float fVar1;
    int64_t iVar2;
    float fVar3;
    int64_t iVar4;
    int64_t iVar5;
    float fVar6;
    float in_XMM1_Da;
    float fVar7;
    float fVar8;
    float fVar9;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar4 = *(int64_t *)0x180781f28;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar2 + 0x10e) == '\0') {
        fVar9 = *(float *)(iVar2 + 400);
        fVar6 = 0.0;
        if ((0.0 <= in_XMM1_Da) && (0.0 <= fVar9 - in_XMM1_Da)) {
            fVar6 = fVar9 - in_XMM1_Da;
        }
        if (fVar9 <= in_XMM1_Da) {
            fVar9 = in_XMM1_Da;
        }
        iVar5 = 0x164;
        if (*(char *)(iVar2 + 0x198) == '\0') {
            iVar5 = 0x15c;
        }
        fVar7 = *(float *)(iVar2 + 0x158) + *(float *)arg1;
        fVar1 = *(float *)(iVar5 + iVar2);
        fVar8 = *(float *)(arg1 + 4);
        *(float *)(iVar2 + 0x164) = fVar1;
        *(float *)(iVar2 + 0x160) = fVar7;
        fVar6 = (*(float *)(iVar2 + 0x15c) - fVar1) + fVar8 + fVar6;
        fVar8 = *(float *)(iVar2 + 0x184);
        if (*(float *)(iVar2 + 0x184) <= fVar6) {
            fVar8 = fVar6;
        }
        *(float *)(iVar2 + 0x158) =
             (float)(int32_t)(*(float *)(iVar2 + 0x19c) + *(float *)(iVar2 + 0x60) + *(float *)(iVar2 + 0x1a0));
        fVar6 = *(float *)(iVar4 + 0xdf0);
        fVar3 = *(float *)(iVar2 + 0x170);
        if (*(float *)(iVar2 + 0x170) <= fVar7) {
            fVar3 = fVar7;
        }
        *(float *)(iVar2 + 0x170) = fVar3;
        fVar6 = (float)(int32_t)(fVar8 + fVar1 + fVar6);
        *(float *)(iVar2 + 0x15c) = fVar6;
        fVar6 = fVar6 - *(float *)(iVar4 + 0xdf0);
        *(float *)(iVar2 + 0x194) = fVar9;
        *(float *)(iVar2 + 0x18c) = fVar8;
        *(undefined4 *)(iVar2 + 0x184) = 0;
        fVar9 = *(float *)(iVar2 + 0x174);
        if (*(float *)(iVar2 + 0x174) <= fVar6) {
            fVar9 = fVar6;
        }
        *(undefined4 *)(iVar2 + 400) = 0;
        *(undefined2 *)(iVar2 + 0x198) = 0;
        *(float *)(iVar2 + 0x174) = fVar9;
        if (*(int32_t *)(iVar2 + 0x214) == 0) {
            func_0x00018010bd60(arg1, 0xbf800000);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18010be90
// Address: 0x18010be90
// Size: 247 bytes
// ============================================================
int64_t fcn.18010be90(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t iVar1;
    undefined auVar2 [12];
    undefined auVar3 [12];
    int64_t iVar4;
    float fVar5;
    float fVar7;
    undefined8 uVar6;
    float in_XMM2_Da;
    float fVar8;
    undefined4 in_XMM3_Da;
    float fVar9;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    
    fVar5 = (float)arg2;
    fVar7 = (float)((uint64_t)arg2 >> 0x20);
    if (fVar5 < 0.0) {
code_r0x00018010bec8:
        iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        if ((*(int64_t *)(iVar1 + 0x208) != 0) || (iVar4 = 0x2d0, *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0) != 0))
        {
            iVar4 = 0x2a0;
        }
        fVar9 = *(float *)(iVar1 + iVar4) - *(float *)(iVar1 + 0x158);
        fVar8 = *(float *)(iVar1 + 4 + iVar4) - *(float *)(iVar1 + 0x15c);
    } else {
        fVar9 = 0.0;
        fVar8 = 0.0;
        if (fVar7 < 0.0) goto code_r0x00018010bec8;
    }
    if (fVar5 == 0.0) {
code_r0x00018010bf33:
        var_8h = CONCAT44(fVar7, in_XMM2_Da);
    } else {
        var_8h = arg2;
        if (fVar5 < 0.0) {
            in_XMM2_Da = 4.0;
            if (4.0 <= fVar9 + fVar5) {
                in_XMM2_Da = fVar9 + fVar5;
            }
            goto code_r0x00018010bf33;
        }
    }
    if (fVar7 == 0.0) {
        auVar2._4_8_ = var_8h & 0xffffffff;
        auVar2._0_4_ = in_XMM3_Da;
        uVar6 = auVar2._0_8_;
    } else {
        if (0.0 <= fVar7) goto code_r0x00018010bf72;
        fVar5 = 4.0;
        if (4.0 <= fVar8 + fVar7) {
            fVar5 = fVar8 + fVar7;
        }
        auVar3._4_8_ = var_8h & 0xffffffff;
        auVar3._0_4_ = fVar5;
        uVar6 = auVar3._0_8_;
    }
    var_8h = CONCAT44((int32_t)uVar6, (int32_t)((uint64_t)uVar6 >> 0x20));
code_r0x00018010bf72:
    *(int64_t *)arg1 = var_8h;
    return arg1;
}

// ============================================================
// Function: FUN_18010bfc0
// Address: 0x18010bfc0
// Size: 326 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18010bfc0(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t unaff_RSI;
    float fVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    fcn.18011f140(unaff_RSI);
    iVar2 = *(int64_t *)(iVar3 + 0x2118);
    iVar4 = (int64_t)*(int32_t *)(iVar3 + 0x2110) * 0x3c;
    *(undefined4 *)(iVar4 + -0x3c + iVar2) = *(undefined4 *)(iVar1 + 0x10);
    *(undefined8 *)(iVar4 + -0x38 + iVar2) = *(undefined8 *)(iVar1 + 0x158);
    *(undefined8 *)(iVar4 + -0x28 + iVar2) = *(undefined8 *)(iVar1 + 0x160);
    *(undefined8 *)(iVar4 + -0x30 + iVar2) = *(undefined8 *)(iVar1 + 0x170);
    *(undefined4 *)(iVar4 + -0x20 + iVar2) = *(undefined4 *)(iVar1 + 0x19c);
    *(undefined4 *)(iVar4 + -0x1c + iVar2) = *(undefined4 *)(iVar1 + 0x1a4);
    *(undefined8 *)(iVar4 + -0x18 + iVar2) = *(undefined8 *)(iVar1 + 0x180);
    *(undefined4 *)(iVar4 + -0x10 + iVar2) = *(undefined4 *)(iVar1 + 400);
    *(undefined4 *)(iVar4 + -0xc + iVar2) = *(undefined4 *)(iVar3 + 0x1658);
    *(bool *)(iVar4 + -6 + iVar2) = *(int32_t *)(iVar3 + 0x163c) != 0;
    *(undefined *)(iVar4 + -5 + iVar2) = *(undefined *)(iVar1 + 0x198);
    *(undefined *)(iVar4 + -8 + iVar2) = *(undefined *)(iVar3 + 0x1665);
    *(undefined *)(iVar4 + -7 + iVar2) = *(undefined *)(iVar3 + 0x168d);
    *(undefined *)(iVar4 + -4 + iVar2) = 1;
    *(undefined8 *)(iVar1 + 0x180) = 0;
    fVar5 = (*(float *)(iVar1 + 0x158) - *(float *)(iVar1 + 0x60)) - *(float *)(iVar1 + 0x1a0);
    *(float *)(iVar1 + 0x1a4) = fVar5;
    *(float *)(iVar1 + 0x19c) = fVar5;
    *(undefined8 *)(iVar1 + 0x170) = *(undefined8 *)(iVar1 + 0x158);
    if (*(char *)(iVar3 + 0x29f8) != '\0') {
        *(undefined4 *)(iVar3 + 0x2a30) = 0xff7fffff;
    }
    return;
}

// ============================================================
// Function: FUN_18010c110
// Address: 0x18010c110
// Size: 356 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_80h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_199h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_174h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Removing arg arg_19ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.18010c110(int64_t arg_158h, int64_t arg_180h, int64_t arg_190h, int64_t arg_198h)
{
    uint32_t *puVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    float fVar10;
    float fVar11;
    char cVar12;
    int32_t iVar13;
    uint32_t *puVar14;
    int64_t iVar15;
    int64_t iVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    int64_t var_8h;
    float var_10h;
    float var_14h;
    int64_t var_18h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    float var_70h;
    int64_t var_6ch;
    int64_t var_38h;
    
    iVar9 = *(int64_t *)0x180781f28;
    iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2118);
    iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2110) * 0x3c;
    if (*(char *)(iVar4 + 0x199) != '\0') {
        func_0x000180109fd0();
    }
    fVar2 = *(float *)(iVar15 + -0x34 + iVar5);
    fVar3 = *(float *)(iVar15 + -0x38 + iVar5);
    fVar20 = *(float *)(iVar4 + 0x174);
    if (*(float *)(iVar4 + 0x174) <= *(float *)(iVar9 + 0x1fd0)) {
        fVar20 = *(float *)(iVar9 + 0x1fd0);
    }
    fVar19 = *(float *)(iVar4 + 0x170);
    if (*(float *)(iVar4 + 0x170) <= *(float *)(iVar9 + 0x1fcc)) {
        fVar19 = *(float *)(iVar9 + 0x1fcc);
    }
    *(float *)(iVar4 + 0x158) = fVar3;
    *(float *)(iVar4 + 0x15c) = fVar2;
    *(undefined8 *)(iVar4 + 0x160) = *(undefined8 *)(iVar15 + -0x28 + iVar5);
    if (fVar20 <= fVar2) {
        fVar20 = fVar2;
    }
    fVar18 = *(float *)(iVar15 + -0x2c + iVar5);
    if (fVar19 <= fVar3) {
        fVar19 = fVar3;
    }
    fVar17 = *(float *)(iVar15 + -0x30 + iVar5);
    if (fVar18 <= fVar20) {
        fVar18 = fVar20;
    }
    if (fVar17 <= fVar19) {
        fVar17 = fVar19;
    }
    *(float *)(iVar4 + 0x174) = fVar18;
    *(float *)(iVar4 + 0x170) = fVar17;
    *(undefined4 *)(iVar4 + 0x19c) = *(undefined4 *)(iVar15 + -0x20 + iVar5);
    *(undefined4 *)(iVar4 + 0x1a4) = *(undefined4 *)(iVar15 + -0x1c + iVar5);
    *(undefined8 *)(iVar4 + 0x180) = *(undefined8 *)(iVar15 + -0x18 + iVar5);
    *(undefined4 *)(iVar4 + 400) = *(undefined4 *)(iVar15 + -0x10 + iVar5);
    *(undefined *)(iVar4 + 0x198) = *(undefined *)(iVar15 + -5 + iVar5);
    if (*(char *)(iVar9 + 0x29f8) != '\0') {
        *(undefined4 *)(iVar9 + 0x2a30) = 0xff7fffff;
    }
    if (*(char *)(iVar15 + -4 + iVar5) == '\0') {
        *(int32_t *)(iVar9 + 0x2110) = *(int32_t *)(iVar9 + 0x2110) + -1;
        return;
    }
    fVar18 = *(float *)(iVar15 + -0x10 + iVar5);
    fVar17 = *(float *)(iVar4 + 0x194);
    if (*(float *)(iVar4 + 0x194) <= fVar18) {
        fVar17 = fVar18;
    }
    var_8h._0_4_ = fVar19 - fVar3;
    *(float *)(iVar4 + 400) = fVar17;
    var_8h._4_4_ = fVar20 - fVar2;
    var_78h._0_4_ = fVar3;
    var_78h._4_4_ = fVar2;
    var_70h = fVar19;
    var_6ch._0_4_ = fVar20;
    fcn.18010bbf0((int64_t)&var_8h);
    fVar11 = (float)var_6ch;
    fVar10 = var_70h;
    fVar17 = var_78h._4_4_;
    fVar18 = (float)var_78h;
    iVar16 = *(int64_t *)0x180781f28;
    puVar14 = (uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78);
    puVar1 = (uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = 0;
    *(uint32_t *)(iVar16 + 0x1fbc) = *puVar14 | *puVar1 | 1;
    iVar6 = *(int64_t *)(iVar16 + 0x15e0);
    *(float *)(iVar16 + 0x1fc4) = (float)var_78h;
    *(float *)(iVar16 + 0x1fc8) = var_78h._4_4_;
    *(float *)(iVar16 + 0x1fcc) = var_70h;
    *(float *)(iVar16 + 0x1fd0) = (float)var_6ch;
    *(undefined4 *)(iVar16 + 0x1fc0) = 0;
    *(float *)(iVar16 + 0x1fd4) = (float)var_78h;
    *(float *)(iVar16 + 0x1fd8) = var_78h._4_4_;
    *(float *)(iVar16 + 0x1fdc) = var_70h;
    *(float *)(iVar16 + 0x1fe0) = (float)var_6ch;
    *(undefined8 *)(iVar16 + 0x1f80) = 0;
    if ((((fVar20 < *(float *)(iVar6 + 700) || fVar20 == *(float *)(iVar6 + 700)) ||
         (*(float *)(iVar6 + 0x2c4) <= fVar2)) ||
        (fVar19 < *(float *)(iVar6 + 0x2b8) || fVar19 == *(float *)(iVar6 + 0x2b8))) ||
       (*(float *)(iVar6 + 0x2c0) <= fVar3)) {
        if (*(char *)(iVar16 + 0x1652) != '\0') goto code_r0x00018010c34e;
    } else {
        *(undefined4 *)(iVar16 + 0x1fc0) = 0x100;
code_r0x00018010c34e:
        cVar12 = func_0x000180108120(&var_78h, &var_70h, 1);
        if (cVar12 != '\0') {
            *(uint32_t *)(iVar16 + 0x1fc0) = *(uint32_t *)(iVar16 + 0x1fc0) | 1;
        }
    }
    iVar13 = *(int32_t *)(iVar9 + 0x1654);
    if (((*(int32_t *)(iVar15 + -0xc + iVar5) == iVar13) || (*(int32_t *)(iVar9 + 0x1658) != iVar13)) || (iVar13 == 0))
    {
        bVar7 = false;
    } else {
        bVar7 = true;
    }
    if ((*(char *)(iVar15 + -7 + iVar5) == '\0') && (*(char *)(iVar9 + 0x168d) == '\x01')) {
        bVar8 = true;
    } else {
        bVar8 = false;
    }
    if (!bVar7) {
        if (!bVar8) goto code_r0x00018010c3b4;
        iVar13 = *(int32_t *)(iVar9 + 0x1684);
    }
    *(int32_t *)(iVar9 + 0x1fb8) = iVar13;
code_r0x00018010c3b4:
    *(float *)(iVar9 + 0x1fc4) = fVar18;
    *(float *)(iVar9 + 0x1fc8) = fVar17;
    *(float *)(iVar9 + 0x1fcc) = fVar10;
    *(float *)(iVar9 + 0x1fd0) = fVar11;
    if ((*(char *)(iVar15 + -6 + iVar5) == '\0') && (*(int32_t *)(iVar9 + 0x163c) != 0)) {
        *(uint32_t *)(iVar9 + 0x1fc0) = *(uint32_t *)(iVar9 + 0x1fc0) | 0x80;
    }
    puVar14 = (uint32_t *)(iVar9 + 0x1fc0);
    if ((*(char *)(iVar9 + 0x1665) != '\0') && (*(char *)(iVar15 + -8 + iVar5) == '\0')) {
        *puVar14 = *puVar14 | 4;
    }
    *puVar14 = *puVar14 | 0x20;
    if (bVar8) {
        *puVar14 = *puVar14 | 0x40;
    }
    *(int32_t *)(iVar9 + 0x2110) = *(int32_t *)(iVar9 + 0x2110) + -1;
    if (*(char *)(iVar9 + 0x20b8) != '\0') {
        iVar4 = *(int64_t *)(iVar4 + 800);
        if ((*(uint8_t *)(iVar4 + 0x30) & 1) == 0) {
            var_8h._0_4_ = fVar19 - 0.49;
            var_8h._4_4_ = fVar20 - 0.49;
        } else {
            var_8h._0_4_ = fVar19 - 0.5;
            var_8h._4_4_ = fVar20 - 0.5;
        }
        var_10h = fVar3 + 0.5;
        var_14h = fVar2 + 0.5;
        func_0x000180125f20(iVar4, &var_10h, &var_8h, 0, 0);
        func_0x0001801248e0(iVar4, *(undefined8 *)(iVar4 + 0x58), *(undefined4 *)(iVar4 + 0x50), 0xffff00ff, 1, 
                            0x3f800000);
        *(undefined4 *)(iVar4 + 0x50) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18010c274
// Address: 0x18010c274
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_80h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_199h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_174h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Removing arg arg_19ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.18010c110(int64_t arg_158h, int64_t arg_180h, int64_t arg_190h, int64_t arg_198h)
{
    uint32_t *puVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    float fVar10;
    float fVar11;
    char cVar12;
    int32_t iVar13;
    uint32_t *puVar14;
    int64_t iVar15;
    int64_t iVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    int64_t var_8h;
    float var_10h;
    float var_14h;
    int64_t var_18h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    float var_70h;
    int64_t var_6ch;
    int64_t var_38h;
    
    iVar9 = *(int64_t *)0x180781f28;
    iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2118);
    iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2110) * 0x3c;
    if (*(char *)(iVar4 + 0x199) != '\0') {
        func_0x000180109fd0();
    }
    fVar2 = *(float *)(iVar15 + -0x34 + iVar5);
    fVar3 = *(float *)(iVar15 + -0x38 + iVar5);
    fVar20 = *(float *)(iVar4 + 0x174);
    if (*(float *)(iVar4 + 0x174) <= *(float *)(iVar9 + 0x1fd0)) {
        fVar20 = *(float *)(iVar9 + 0x1fd0);
    }
    fVar19 = *(float *)(iVar4 + 0x170);
    if (*(float *)(iVar4 + 0x170) <= *(float *)(iVar9 + 0x1fcc)) {
        fVar19 = *(float *)(iVar9 + 0x1fcc);
    }
    *(float *)(iVar4 + 0x158) = fVar3;
    *(float *)(iVar4 + 0x15c) = fVar2;
    *(undefined8 *)(iVar4 + 0x160) = *(undefined8 *)(iVar15 + -0x28 + iVar5);
    if (fVar20 <= fVar2) {
        fVar20 = fVar2;
    }
    fVar18 = *(float *)(iVar15 + -0x2c + iVar5);
    if (fVar19 <= fVar3) {
        fVar19 = fVar3;
    }
    fVar17 = *(float *)(iVar15 + -0x30 + iVar5);
    if (fVar18 <= fVar20) {
        fVar18 = fVar20;
    }
    if (fVar17 <= fVar19) {
        fVar17 = fVar19;
    }
    *(float *)(iVar4 + 0x174) = fVar18;
    *(float *)(iVar4 + 0x170) = fVar17;
    *(undefined4 *)(iVar4 + 0x19c) = *(undefined4 *)(iVar15 + -0x20 + iVar5);
    *(undefined4 *)(iVar4 + 0x1a4) = *(undefined4 *)(iVar15 + -0x1c + iVar5);
    *(undefined8 *)(iVar4 + 0x180) = *(undefined8 *)(iVar15 + -0x18 + iVar5);
    *(undefined4 *)(iVar4 + 400) = *(undefined4 *)(iVar15 + -0x10 + iVar5);
    *(undefined *)(iVar4 + 0x198) = *(undefined *)(iVar15 + -5 + iVar5);
    if (*(char *)(iVar9 + 0x29f8) != '\0') {
        *(undefined4 *)(iVar9 + 0x2a30) = 0xff7fffff;
    }
    if (*(char *)(iVar15 + -4 + iVar5) == '\0') {
        *(int32_t *)(iVar9 + 0x2110) = *(int32_t *)(iVar9 + 0x2110) + -1;
        return;
    }
    fVar18 = *(float *)(iVar15 + -0x10 + iVar5);
    fVar17 = *(float *)(iVar4 + 0x194);
    if (*(float *)(iVar4 + 0x194) <= fVar18) {
        fVar17 = fVar18;
    }
    var_8h._0_4_ = fVar19 - fVar3;
    *(float *)(iVar4 + 400) = fVar17;
    var_8h._4_4_ = fVar20 - fVar2;
    var_78h._0_4_ = fVar3;
    var_78h._4_4_ = fVar2;
    var_70h = fVar19;
    var_6ch._0_4_ = fVar20;
    fcn.18010bbf0((int64_t)&var_8h);
    fVar11 = (float)var_6ch;
    fVar10 = var_70h;
    fVar17 = var_78h._4_4_;
    fVar18 = (float)var_78h;
    iVar16 = *(int64_t *)0x180781f28;
    puVar14 = (uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78);
    puVar1 = (uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = 0;
    *(uint32_t *)(iVar16 + 0x1fbc) = *puVar14 | *puVar1 | 1;
    iVar6 = *(int64_t *)(iVar16 + 0x15e0);
    *(float *)(iVar16 + 0x1fc4) = (float)var_78h;
    *(float *)(iVar16 + 0x1fc8) = var_78h._4_4_;
    *(float *)(iVar16 + 0x1fcc) = var_70h;
    *(float *)(iVar16 + 0x1fd0) = (float)var_6ch;
    *(undefined4 *)(iVar16 + 0x1fc0) = 0;
    *(float *)(iVar16 + 0x1fd4) = (float)var_78h;
    *(float *)(iVar16 + 0x1fd8) = var_78h._4_4_;
    *(float *)(iVar16 + 0x1fdc) = var_70h;
    *(float *)(iVar16 + 0x1fe0) = (float)var_6ch;
    *(undefined8 *)(iVar16 + 0x1f80) = 0;
    if ((((fVar20 < *(float *)(iVar6 + 700) || fVar20 == *(float *)(iVar6 + 700)) ||
         (*(float *)(iVar6 + 0x2c4) <= fVar2)) ||
        (fVar19 < *(float *)(iVar6 + 0x2b8) || fVar19 == *(float *)(iVar6 + 0x2b8))) ||
       (*(float *)(iVar6 + 0x2c0) <= fVar3)) {
        if (*(char *)(iVar16 + 0x1652) != '\0') goto code_r0x00018010c34e;
    } else {
        *(undefined4 *)(iVar16 + 0x1fc0) = 0x100;
code_r0x00018010c34e:
        cVar12 = func_0x000180108120(&var_78h, &var_70h, 1);
        if (cVar12 != '\0') {
            *(uint32_t *)(iVar16 + 0x1fc0) = *(uint32_t *)(iVar16 + 0x1fc0) | 1;
        }
    }
    iVar13 = *(int32_t *)(iVar9 + 0x1654);
    if (((*(int32_t *)(iVar15 + -0xc + iVar5) == iVar13) || (*(int32_t *)(iVar9 + 0x1658) != iVar13)) || (iVar13 == 0))
    {
        bVar7 = false;
    } else {
        bVar7 = true;
    }
    if ((*(char *)(iVar15 + -7 + iVar5) == '\0') && (*(char *)(iVar9 + 0x168d) == '\x01')) {
        bVar8 = true;
    } else {
        bVar8 = false;
    }
    if (!bVar7) {
        if (!bVar8) goto code_r0x00018010c3b4;
        iVar13 = *(int32_t *)(iVar9 + 0x1684);
    }
    *(int32_t *)(iVar9 + 0x1fb8) = iVar13;
code_r0x00018010c3b4:
    *(float *)(iVar9 + 0x1fc4) = fVar18;
    *(float *)(iVar9 + 0x1fc8) = fVar17;
    *(float *)(iVar9 + 0x1fcc) = fVar10;
    *(float *)(iVar9 + 0x1fd0) = fVar11;
    if ((*(char *)(iVar15 + -6 + iVar5) == '\0') && (*(int32_t *)(iVar9 + 0x163c) != 0)) {
        *(uint32_t *)(iVar9 + 0x1fc0) = *(uint32_t *)(iVar9 + 0x1fc0) | 0x80;
    }
    puVar14 = (uint32_t *)(iVar9 + 0x1fc0);
    if ((*(char *)(iVar9 + 0x1665) != '\0') && (*(char *)(iVar15 + -8 + iVar5) == '\0')) {
        *puVar14 = *puVar14 | 4;
    }
    *puVar14 = *puVar14 | 0x20;
    if (bVar8) {
        *puVar14 = *puVar14 | 0x40;
    }
    *(int32_t *)(iVar9 + 0x2110) = *(int32_t *)(iVar9 + 0x2110) + -1;
    if (*(char *)(iVar9 + 0x20b8) != '\0') {
        iVar4 = *(int64_t *)(iVar4 + 800);
        if ((*(uint8_t *)(iVar4 + 0x30) & 1) == 0) {
            var_8h._0_4_ = fVar19 - 0.49;
            var_8h._4_4_ = fVar20 - 0.49;
        } else {
            var_8h._0_4_ = fVar19 - 0.5;
            var_8h._4_4_ = fVar20 - 0.5;
        }
        var_10h = fVar3 + 0.5;
        var_14h = fVar2 + 0.5;
        func_0x000180125f20(iVar4, &var_10h, &var_8h, 0, 0);
        func_0x0001801248e0(iVar4, *(undefined8 *)(iVar4 + 0x58), *(undefined4 *)(iVar4 + 0x50), 0xffff00ff, 1, 
                            0x3f800000);
        *(undefined4 *)(iVar4 + 0x50) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18010c280
// Address: 0x18010c280
// Size: 329 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_80h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_199h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_174h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Removing arg arg_19ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.18010c110(int64_t arg_158h, int64_t arg_180h, int64_t arg_190h, int64_t arg_198h)
{
    uint32_t *puVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    float fVar10;
    float fVar11;
    char cVar12;
    int32_t iVar13;
    uint32_t *puVar14;
    int64_t iVar15;
    int64_t iVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    int64_t var_8h;
    float var_10h;
    float var_14h;
    int64_t var_18h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    float var_70h;
    int64_t var_6ch;
    int64_t var_38h;
    
    iVar9 = *(int64_t *)0x180781f28;
    iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2118);
    iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2110) * 0x3c;
    if (*(char *)(iVar4 + 0x199) != '\0') {
        func_0x000180109fd0();
    }
    fVar2 = *(float *)(iVar15 + -0x34 + iVar5);
    fVar3 = *(float *)(iVar15 + -0x38 + iVar5);
    fVar20 = *(float *)(iVar4 + 0x174);
    if (*(float *)(iVar4 + 0x174) <= *(float *)(iVar9 + 0x1fd0)) {
        fVar20 = *(float *)(iVar9 + 0x1fd0);
    }
    fVar19 = *(float *)(iVar4 + 0x170);
    if (*(float *)(iVar4 + 0x170) <= *(float *)(iVar9 + 0x1fcc)) {
        fVar19 = *(float *)(iVar9 + 0x1fcc);
    }
    *(float *)(iVar4 + 0x158) = fVar3;
    *(float *)(iVar4 + 0x15c) = fVar2;
    *(undefined8 *)(iVar4 + 0x160) = *(undefined8 *)(iVar15 + -0x28 + iVar5);
    if (fVar20 <= fVar2) {
        fVar20 = fVar2;
    }
    fVar18 = *(float *)(iVar15 + -0x2c + iVar5);
    if (fVar19 <= fVar3) {
        fVar19 = fVar3;
    }
    fVar17 = *(float *)(iVar15 + -0x30 + iVar5);
    if (fVar18 <= fVar20) {
        fVar18 = fVar20;
    }
    if (fVar17 <= fVar19) {
        fVar17 = fVar19;
    }
    *(float *)(iVar4 + 0x174) = fVar18;
    *(float *)(iVar4 + 0x170) = fVar17;
    *(undefined4 *)(iVar4 + 0x19c) = *(undefined4 *)(iVar15 + -0x20 + iVar5);
    *(undefined4 *)(iVar4 + 0x1a4) = *(undefined4 *)(iVar15 + -0x1c + iVar5);
    *(undefined8 *)(iVar4 + 0x180) = *(undefined8 *)(iVar15 + -0x18 + iVar5);
    *(undefined4 *)(iVar4 + 400) = *(undefined4 *)(iVar15 + -0x10 + iVar5);
    *(undefined *)(iVar4 + 0x198) = *(undefined *)(iVar15 + -5 + iVar5);
    if (*(char *)(iVar9 + 0x29f8) != '\0') {
        *(undefined4 *)(iVar9 + 0x2a30) = 0xff7fffff;
    }
    if (*(char *)(iVar15 + -4 + iVar5) == '\0') {
        *(int32_t *)(iVar9 + 0x2110) = *(int32_t *)(iVar9 + 0x2110) + -1;
        return;
    }
    fVar18 = *(float *)(iVar15 + -0x10 + iVar5);
    fVar17 = *(float *)(iVar4 + 0x194);
    if (*(float *)(iVar4 + 0x194) <= fVar18) {
        fVar17 = fVar18;
    }
    var_8h._0_4_ = fVar19 - fVar3;
    *(float *)(iVar4 + 400) = fVar17;
    var_8h._4_4_ = fVar20 - fVar2;
    var_78h._0_4_ = fVar3;
    var_78h._4_4_ = fVar2;
    var_70h = fVar19;
    var_6ch._0_4_ = fVar20;
    fcn.18010bbf0((int64_t)&var_8h);
    fVar11 = (float)var_6ch;
    fVar10 = var_70h;
    fVar17 = var_78h._4_4_;
    fVar18 = (float)var_78h;
    iVar16 = *(int64_t *)0x180781f28;
    puVar14 = (uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78);
    puVar1 = (uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = 0;
    *(uint32_t *)(iVar16 + 0x1fbc) = *puVar14 | *puVar1 | 1;
    iVar6 = *(int64_t *)(iVar16 + 0x15e0);
    *(float *)(iVar16 + 0x1fc4) = (float)var_78h;
    *(float *)(iVar16 + 0x1fc8) = var_78h._4_4_;
    *(float *)(iVar16 + 0x1fcc) = var_70h;
    *(float *)(iVar16 + 0x1fd0) = (float)var_6ch;
    *(undefined4 *)(iVar16 + 0x1fc0) = 0;
    *(float *)(iVar16 + 0x1fd4) = (float)var_78h;
    *(float *)(iVar16 + 0x1fd8) = var_78h._4_4_;
    *(float *)(iVar16 + 0x1fdc) = var_70h;
    *(float *)(iVar16 + 0x1fe0) = (float)var_6ch;
    *(undefined8 *)(iVar16 + 0x1f80) = 0;
    if ((((fVar20 < *(float *)(iVar6 + 700) || fVar20 == *(float *)(iVar6 + 700)) ||
         (*(float *)(iVar6 + 0x2c4) <= fVar2)) ||
        (fVar19 < *(float *)(iVar6 + 0x2b8) || fVar19 == *(float *)(iVar6 + 0x2b8))) ||
       (*(float *)(iVar6 + 0x2c0) <= fVar3)) {
        if (*(char *)(iVar16 + 0x1652) != '\0') goto code_r0x00018010c34e;
    } else {
        *(undefined4 *)(iVar16 + 0x1fc0) = 0x100;
code_r0x00018010c34e:
        cVar12 = func_0x000180108120(&var_78h, &var_70h, 1);
        if (cVar12 != '\0') {
            *(uint32_t *)(iVar16 + 0x1fc0) = *(uint32_t *)(iVar16 + 0x1fc0) | 1;
        }
    }
    iVar13 = *(int32_t *)(iVar9 + 0x1654);
    if (((*(int32_t *)(iVar15 + -0xc + iVar5) == iVar13) || (*(int32_t *)(iVar9 + 0x1658) != iVar13)) || (iVar13 == 0))
    {
        bVar7 = false;
    } else {
        bVar7 = true;
    }
    if ((*(char *)(iVar15 + -7 + iVar5) == '\0') && (*(char *)(iVar9 + 0x168d) == '\x01')) {
        bVar8 = true;
    } else {
        bVar8 = false;
    }
    if (!bVar7) {
        if (!bVar8) goto code_r0x00018010c3b4;
        iVar13 = *(int32_t *)(iVar9 + 0x1684);
    }
    *(int32_t *)(iVar9 + 0x1fb8) = iVar13;
code_r0x00018010c3b4:
    *(float *)(iVar9 + 0x1fc4) = fVar18;
    *(float *)(iVar9 + 0x1fc8) = fVar17;
    *(float *)(iVar9 + 0x1fcc) = fVar10;
    *(float *)(iVar9 + 0x1fd0) = fVar11;
    if ((*(char *)(iVar15 + -6 + iVar5) == '\0') && (*(int32_t *)(iVar9 + 0x163c) != 0)) {
        *(uint32_t *)(iVar9 + 0x1fc0) = *(uint32_t *)(iVar9 + 0x1fc0) | 0x80;
    }
    puVar14 = (uint32_t *)(iVar9 + 0x1fc0);
    if ((*(char *)(iVar9 + 0x1665) != '\0') && (*(char *)(iVar15 + -8 + iVar5) == '\0')) {
        *puVar14 = *puVar14 | 4;
    }
    *puVar14 = *puVar14 | 0x20;
    if (bVar8) {
        *puVar14 = *puVar14 | 0x40;
    }
    *(int32_t *)(iVar9 + 0x2110) = *(int32_t *)(iVar9 + 0x2110) + -1;
    if (*(char *)(iVar9 + 0x20b8) != '\0') {
        iVar4 = *(int64_t *)(iVar4 + 800);
        if ((*(uint8_t *)(iVar4 + 0x30) & 1) == 0) {
            var_8h._0_4_ = fVar19 - 0.49;
            var_8h._4_4_ = fVar20 - 0.49;
        } else {
            var_8h._0_4_ = fVar19 - 0.5;
            var_8h._4_4_ = fVar20 - 0.5;
        }
        var_10h = fVar3 + 0.5;
        var_14h = fVar2 + 0.5;
        func_0x000180125f20(iVar4, &var_10h, &var_8h, 0, 0);
        func_0x0001801248e0(iVar4, *(undefined8 *)(iVar4 + 0x58), *(undefined4 *)(iVar4 + 0x50), 0xffff00ff, 1, 
                            0x3f800000);
        *(undefined4 *)(iVar4 + 0x50) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18010c3c9
// Address: 0x18010c3c9
// Size: 280 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_80h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_199h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_174h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Removing arg arg_19ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.18010c110(int64_t arg_158h, int64_t arg_180h, int64_t arg_190h, int64_t arg_198h)
{
    uint32_t *puVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    float fVar10;
    float fVar11;
    char cVar12;
    int32_t iVar13;
    uint32_t *puVar14;
    int64_t iVar15;
    int64_t iVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    int64_t var_8h;
    float var_10h;
    float var_14h;
    int64_t var_18h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    float var_70h;
    int64_t var_6ch;
    int64_t var_38h;
    
    iVar9 = *(int64_t *)0x180781f28;
    iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2118);
    iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2110) * 0x3c;
    if (*(char *)(iVar4 + 0x199) != '\0') {
        func_0x000180109fd0();
    }
    fVar2 = *(float *)(iVar15 + -0x34 + iVar5);
    fVar3 = *(float *)(iVar15 + -0x38 + iVar5);
    fVar20 = *(float *)(iVar4 + 0x174);
    if (*(float *)(iVar4 + 0x174) <= *(float *)(iVar9 + 0x1fd0)) {
        fVar20 = *(float *)(iVar9 + 0x1fd0);
    }
    fVar19 = *(float *)(iVar4 + 0x170);
    if (*(float *)(iVar4 + 0x170) <= *(float *)(iVar9 + 0x1fcc)) {
        fVar19 = *(float *)(iVar9 + 0x1fcc);
    }
    *(float *)(iVar4 + 0x158) = fVar3;
    *(float *)(iVar4 + 0x15c) = fVar2;
    *(undefined8 *)(iVar4 + 0x160) = *(undefined8 *)(iVar15 + -0x28 + iVar5);
    if (fVar20 <= fVar2) {
        fVar20 = fVar2;
    }
    fVar18 = *(float *)(iVar15 + -0x2c + iVar5);
    if (fVar19 <= fVar3) {
        fVar19 = fVar3;
    }
    fVar17 = *(float *)(iVar15 + -0x30 + iVar5);
    if (fVar18 <= fVar20) {
        fVar18 = fVar20;
    }
    if (fVar17 <= fVar19) {
        fVar17 = fVar19;
    }
    *(float *)(iVar4 + 0x174) = fVar18;
    *(float *)(iVar4 + 0x170) = fVar17;
    *(undefined4 *)(iVar4 + 0x19c) = *(undefined4 *)(iVar15 + -0x20 + iVar5);
    *(undefined4 *)(iVar4 + 0x1a4) = *(undefined4 *)(iVar15 + -0x1c + iVar5);
    *(undefined8 *)(iVar4 + 0x180) = *(undefined8 *)(iVar15 + -0x18 + iVar5);
    *(undefined4 *)(iVar4 + 400) = *(undefined4 *)(iVar15 + -0x10 + iVar5);
    *(undefined *)(iVar4 + 0x198) = *(undefined *)(iVar15 + -5 + iVar5);
    if (*(char *)(iVar9 + 0x29f8) != '\0') {
        *(undefined4 *)(iVar9 + 0x2a30) = 0xff7fffff;
    }
    if (*(char *)(iVar15 + -4 + iVar5) == '\0') {
        *(int32_t *)(iVar9 + 0x2110) = *(int32_t *)(iVar9 + 0x2110) + -1;
        return;
    }
    fVar18 = *(float *)(iVar15 + -0x10 + iVar5);
    fVar17 = *(float *)(iVar4 + 0x194);
    if (*(float *)(iVar4 + 0x194) <= fVar18) {
        fVar17 = fVar18;
    }
    var_8h._0_4_ = fVar19 - fVar3;
    *(float *)(iVar4 + 400) = fVar17;
    var_8h._4_4_ = fVar20 - fVar2;
    var_78h._0_4_ = fVar3;
    var_78h._4_4_ = fVar2;
    var_70h = fVar19;
    var_6ch._0_4_ = fVar20;
    fcn.18010bbf0((int64_t)&var_8h);
    fVar11 = (float)var_6ch;
    fVar10 = var_70h;
    fVar17 = var_78h._4_4_;
    fVar18 = (float)var_78h;
    iVar16 = *(int64_t *)0x180781f28;
    puVar14 = (uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78);
    puVar1 = (uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = 0;
    *(uint32_t *)(iVar16 + 0x1fbc) = *puVar14 | *puVar1 | 1;
    iVar6 = *(int64_t *)(iVar16 + 0x15e0);
    *(float *)(iVar16 + 0x1fc4) = (float)var_78h;
    *(float *)(iVar16 + 0x1fc8) = var_78h._4_4_;
    *(float *)(iVar16 + 0x1fcc) = var_70h;
    *(float *)(iVar16 + 0x1fd0) = (float)var_6ch;
    *(undefined4 *)(iVar16 + 0x1fc0) = 0;
    *(float *)(iVar16 + 0x1fd4) = (float)var_78h;
    *(float *)(iVar16 + 0x1fd8) = var_78h._4_4_;
    *(float *)(iVar16 + 0x1fdc) = var_70h;
    *(float *)(iVar16 + 0x1fe0) = (float)var_6ch;
    *(undefined8 *)(iVar16 + 0x1f80) = 0;
    if ((((fVar20 < *(float *)(iVar6 + 700) || fVar20 == *(float *)(iVar6 + 700)) ||
         (*(float *)(iVar6 + 0x2c4) <= fVar2)) ||
        (fVar19 < *(float *)(iVar6 + 0x2b8) || fVar19 == *(float *)(iVar6 + 0x2b8))) ||
       (*(float *)(iVar6 + 0x2c0) <= fVar3)) {
        if (*(char *)(iVar16 + 0x1652) != '\0') goto code_r0x00018010c34e;
    } else {
        *(undefined4 *)(iVar16 + 0x1fc0) = 0x100;
code_r0x00018010c34e:
        cVar12 = func_0x000180108120(&var_78h, &var_70h, 1);
        if (cVar12 != '\0') {
            *(uint32_t *)(iVar16 + 0x1fc0) = *(uint32_t *)(iVar16 + 0x1fc0) | 1;
        }
    }
    iVar13 = *(int32_t *)(iVar9 + 0x1654);
    if (((*(int32_t *)(iVar15 + -0xc + iVar5) == iVar13) || (*(int32_t *)(iVar9 + 0x1658) != iVar13)) || (iVar13 == 0))
    {
        bVar7 = false;
    } else {
        bVar7 = true;
    }
    if ((*(char *)(iVar15 + -7 + iVar5) == '\0') && (*(char *)(iVar9 + 0x168d) == '\x01')) {
        bVar8 = true;
    } else {
        bVar8 = false;
    }
    if (!bVar7) {
        if (!bVar8) goto code_r0x00018010c3b4;
        iVar13 = *(int32_t *)(iVar9 + 0x1684);
    }
    *(int32_t *)(iVar9 + 0x1fb8) = iVar13;
code_r0x00018010c3b4:
    *(float *)(iVar9 + 0x1fc4) = fVar18;
    *(float *)(iVar9 + 0x1fc8) = fVar17;
    *(float *)(iVar9 + 0x1fcc) = fVar10;
    *(float *)(iVar9 + 0x1fd0) = fVar11;
    if ((*(char *)(iVar15 + -6 + iVar5) == '\0') && (*(int32_t *)(iVar9 + 0x163c) != 0)) {
        *(uint32_t *)(iVar9 + 0x1fc0) = *(uint32_t *)(iVar9 + 0x1fc0) | 0x80;
    }
    puVar14 = (uint32_t *)(iVar9 + 0x1fc0);
    if ((*(char *)(iVar9 + 0x1665) != '\0') && (*(char *)(iVar15 + -8 + iVar5) == '\0')) {
        *puVar14 = *puVar14 | 4;
    }
    *puVar14 = *puVar14 | 0x20;
    if (bVar8) {
        *puVar14 = *puVar14 | 0x40;
    }
    *(int32_t *)(iVar9 + 0x2110) = *(int32_t *)(iVar9 + 0x2110) + -1;
    if (*(char *)(iVar9 + 0x20b8) != '\0') {
        iVar4 = *(int64_t *)(iVar4 + 800);
        if ((*(uint8_t *)(iVar4 + 0x30) & 1) == 0) {
            var_8h._0_4_ = fVar19 - 0.49;
            var_8h._4_4_ = fVar20 - 0.49;
        } else {
            var_8h._0_4_ = fVar19 - 0.5;
            var_8h._4_4_ = fVar20 - 0.5;
        }
        var_10h = fVar3 + 0.5;
        var_14h = fVar2 + 0.5;
        func_0x000180125f20(iVar4, &var_10h, &var_8h, 0, 0);
        func_0x0001801248e0(iVar4, *(undefined8 *)(iVar4 + 0x58), *(undefined4 *)(iVar4 + 0x50), 0xffff00ff, 1, 
                            0x3f800000);
        *(undefined4 *)(iVar4 + 0x50) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18010c4e1
// Address: 0x18010c4e1
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_80h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_199h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_174h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Removing arg arg_19ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Removing arg arg_320h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.18010c110(int64_t arg_158h, int64_t arg_180h, int64_t arg_190h, int64_t arg_198h)
{
    uint32_t *puVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    float fVar10;
    float fVar11;
    char cVar12;
    int32_t iVar13;
    uint32_t *puVar14;
    int64_t iVar15;
    int64_t iVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    float fVar20;
    int64_t var_8h;
    float var_10h;
    float var_14h;
    int64_t var_18h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    float var_70h;
    int64_t var_6ch;
    int64_t var_38h;
    
    iVar9 = *(int64_t *)0x180781f28;
    iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2118);
    iVar15 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2110) * 0x3c;
    if (*(char *)(iVar4 + 0x199) != '\0') {
        func_0x000180109fd0();
    }
    fVar2 = *(float *)(iVar15 + -0x34 + iVar5);
    fVar3 = *(float *)(iVar15 + -0x38 + iVar5);
    fVar20 = *(float *)(iVar4 + 0x174);
    if (*(float *)(iVar4 + 0x174) <= *(float *)(iVar9 + 0x1fd0)) {
        fVar20 = *(float *)(iVar9 + 0x1fd0);
    }
    fVar19 = *(float *)(iVar4 + 0x170);
    if (*(float *)(iVar4 + 0x170) <= *(float *)(iVar9 + 0x1fcc)) {
        fVar19 = *(float *)(iVar9 + 0x1fcc);
    }
    *(float *)(iVar4 + 0x158) = fVar3;
    *(float *)(iVar4 + 0x15c) = fVar2;
    *(undefined8 *)(iVar4 + 0x160) = *(undefined8 *)(iVar15 + -0x28 + iVar5);
    if (fVar20 <= fVar2) {
        fVar20 = fVar2;
    }
    fVar18 = *(float *)(iVar15 + -0x2c + iVar5);
    if (fVar19 <= fVar3) {
        fVar19 = fVar3;
    }
    fVar17 = *(float *)(iVar15 + -0x30 + iVar5);
    if (fVar18 <= fVar20) {
        fVar18 = fVar20;
    }
    if (fVar17 <= fVar19) {
        fVar17 = fVar19;
    }
    *(float *)(iVar4 + 0x174) = fVar18;
    *(float *)(iVar4 + 0x170) = fVar17;
    *(undefined4 *)(iVar4 + 0x19c) = *(undefined4 *)(iVar15 + -0x20 + iVar5);
    *(undefined4 *)(iVar4 + 0x1a4) = *(undefined4 *)(iVar15 + -0x1c + iVar5);
    *(undefined8 *)(iVar4 + 0x180) = *(undefined8 *)(iVar15 + -0x18 + iVar5);
    *(undefined4 *)(iVar4 + 400) = *(undefined4 *)(iVar15 + -0x10 + iVar5);
    *(undefined *)(iVar4 + 0x198) = *(undefined *)(iVar15 + -5 + iVar5);
    if (*(char *)(iVar9 + 0x29f8) != '\0') {
        *(undefined4 *)(iVar9 + 0x2a30) = 0xff7fffff;
    }
    if (*(char *)(iVar15 + -4 + iVar5) == '\0') {
        *(int32_t *)(iVar9 + 0x2110) = *(int32_t *)(iVar9 + 0x2110) + -1;
        return;
    }
    fVar18 = *(float *)(iVar15 + -0x10 + iVar5);
    fVar17 = *(float *)(iVar4 + 0x194);
    if (*(float *)(iVar4 + 0x194) <= fVar18) {
        fVar17 = fVar18;
    }
    var_8h._0_4_ = fVar19 - fVar3;
    *(float *)(iVar4 + 400) = fVar17;
    var_8h._4_4_ = fVar20 - fVar2;
    var_78h._0_4_ = fVar3;
    var_78h._4_4_ = fVar2;
    var_70h = fVar19;
    var_6ch._0_4_ = fVar20;
    fcn.18010bbf0((int64_t)&var_8h);
    fVar11 = (float)var_6ch;
    fVar10 = var_70h;
    fVar17 = var_78h._4_4_;
    fVar18 = (float)var_78h;
    iVar16 = *(int64_t *)0x180781f28;
    puVar14 = (uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78);
    puVar1 = (uint32_t *)(*(int64_t *)0x180781f28 + 0x1f84);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1fb8) = 0;
    *(uint32_t *)(iVar16 + 0x1fbc) = *puVar14 | *puVar1 | 1;
    iVar6 = *(int64_t *)(iVar16 + 0x15e0);
    *(float *)(iVar16 + 0x1fc4) = (float)var_78h;
    *(float *)(iVar16 + 0x1fc8) = var_78h._4_4_;
    *(float *)(iVar16 + 0x1fcc) = var_70h;
    *(float *)(iVar16 + 0x1fd0) = (float)var_6ch;
    *(undefined4 *)(iVar16 + 0x1fc0) = 0;
    *(float *)(iVar16 + 0x1fd4) = (float)var_78h;
    *(float *)(iVar16 + 0x1fd8) = var_78h._4_4_;
    *(float *)(iVar16 + 0x1fdc) = var_70h;
    *(float *)(iVar16 + 0x1fe0) = (float)var_6ch;
    *(undefined8 *)(iVar16 + 0x1f80) = 0;
    if ((((fVar20 < *(float *)(iVar6 + 700) || fVar20 == *(float *)(iVar6 + 700)) ||
         (*(float *)(iVar6 + 0x2c4) <= fVar2)) ||
        (fVar19 < *(float *)(iVar6 + 0x2b8) || fVar19 == *(float *)(iVar6 + 0x2b8))) ||
       (*(float *)(iVar6 + 0x2c0) <= fVar3)) {
        if (*(char *)(iVar16 + 0x1652) != '\0') goto code_r0x00018010c34e;
    } else {
        *(undefined4 *)(iVar16 + 0x1fc0) = 0x100;
code_r0x00018010c34e:
        cVar12 = func_0x000180108120(&var_78h, &var_70h, 1);
        if (cVar12 != '\0') {
            *(uint32_t *)(iVar16 + 0x1fc0) = *(uint32_t *)(iVar16 + 0x1fc0) | 1;
        }
    }
    iVar13 = *(int32_t *)(iVar9 + 0x1654);
    if (((*(int32_t *)(iVar15 + -0xc + iVar5) == iVar13) || (*(int32_t *)(iVar9 + 0x1658) != iVar13)) || (iVar13 == 0))
    {
        bVar7 = false;
    } else {
        bVar7 = true;
    }
    if ((*(char *)(iVar15 + -7 + iVar5) == '\0') && (*(char *)(iVar9 + 0x168d) == '\x01')) {
        bVar8 = true;
    } else {
        bVar8 = false;
    }
    if (!bVar7) {
        if (!bVar8) goto code_r0x00018010c3b4;
        iVar13 = *(int32_t *)(iVar9 + 0x1684);
    }
    *(int32_t *)(iVar9 + 0x1fb8) = iVar13;
code_r0x00018010c3b4:
    *(float *)(iVar9 + 0x1fc4) = fVar18;
    *(float *)(iVar9 + 0x1fc8) = fVar17;
    *(float *)(iVar9 + 0x1fcc) = fVar10;
    *(float *)(iVar9 + 0x1fd0) = fVar11;
    if ((*(char *)(iVar15 + -6 + iVar5) == '\0') && (*(int32_t *)(iVar9 + 0x163c) != 0)) {
        *(uint32_t *)(iVar9 + 0x1fc0) = *(uint32_t *)(iVar9 + 0x1fc0) | 0x80;
    }
    puVar14 = (uint32_t *)(iVar9 + 0x1fc0);
    if ((*(char *)(iVar9 + 0x1665) != '\0') && (*(char *)(iVar15 + -8 + iVar5) == '\0')) {
        *puVar14 = *puVar14 | 4;
    }
    *puVar14 = *puVar14 | 0x20;
    if (bVar8) {
        *puVar14 = *puVar14 | 0x40;
    }
    *(int32_t *)(iVar9 + 0x2110) = *(int32_t *)(iVar9 + 0x2110) + -1;
    if (*(char *)(iVar9 + 0x20b8) != '\0') {
        iVar4 = *(int64_t *)(iVar4 + 800);
        if ((*(uint8_t *)(iVar4 + 0x30) & 1) == 0) {
            var_8h._0_4_ = fVar19 - 0.49;
            var_8h._4_4_ = fVar20 - 0.49;
        } else {
            var_8h._0_4_ = fVar19 - 0.5;
            var_8h._4_4_ = fVar20 - 0.5;
        }
        var_10h = fVar3 + 0.5;
        var_14h = fVar2 + 0.5;
        func_0x000180125f20(iVar4, &var_10h, &var_8h, 0, 0);
        func_0x0001801248e0(iVar4, *(undefined8 *)(iVar4 + 0x58), *(undefined4 *)(iVar4 + 0x50), 0xffff00ff, 1, 
                            0x3f800000);
        *(undefined4 *)(iVar4 + 0x50) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18010c510
// Address: 0x18010c510
// Size: 538 bytes
// ============================================================
int64_t fcn.18010c510(int64_t arg1, int64_t arg2)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    *(undefined8 *)arg1 = *(undefined8 *)(arg2 + 0xd4);
    fVar4 = *(float *)(arg2 + 0xe4);
    fVar6 = *(float *)(arg2 + 0xac);
    fVar1 = *(float *)(arg2 + 0xbc);
    fVar8 = *(float *)(arg2 + 0xb4);
    if (fVar4 < 3.402823e+38) {
        fVar2 = *(float *)(arg2 + 0xf4);
        fVar7 = *(float *)(arg2 + 0xb8) + *(float *)(arg2 + 0xa8) + *(float *)(arg2 + 0xb0);
        fVar3 = *(float *)(arg2 + 0xec);
        if (0.0 < fVar2) {
            if (fVar2 + 0.0 < fVar4) {
                fVar5 = (*(float *)(arg2 + 0xdc) + *(float *)(arg2 + 0x70)) - fVar7;
                if (fVar5 - fVar2 <= fVar4) {
                    fVar4 = (fVar5 - fVar4) * fVar3 + fVar4;
                }
            } else {
                fVar4 = (fVar4 - 0.0) * fVar3 + 0.0;
            }
        }
        *(float *)arg1 = fVar4 - (*(float *)(arg2 + 0x70) - fVar7) * fVar3;
    }
    fVar4 = *(float *)arg1;
    if (fVar4 <= 0.0) {
        fVar4 = 0.0;
    }
    fVar4 = (float)(int64_t)(fVar4 + 0.5);
    *(float *)arg1 = fVar4;
    if ((*(char *)(arg2 + 0x10c) == '\0') && (*(char *)(arg2 + 0x10e) == '\0')) {
        if (*(float *)(arg2 + 0xdc) <= fVar4) {
            fVar4 = *(float *)(arg2 + 0xdc);
        }
        *(float *)arg1 = fVar4;
    }
    fVar4 = *(float *)(arg2 + 0xe8);
    if (fVar4 < 3.402823e+38) {
        fVar2 = *(float *)(arg2 + 0xf8);
        fVar3 = *(float *)(arg2 + 0xf0);
        fVar8 = fVar6 + fVar1 + fVar8;
        if (0.0 < fVar2) {
            if (fVar2 + 0.0 < fVar4) {
                fVar6 = (*(float *)(arg2 + 0xe0) + *(float *)(arg2 + 0x74)) - fVar8;
                if (fVar6 - fVar2 <= fVar4) {
                    fVar4 = (fVar6 - fVar4) * fVar3 + fVar4;
                }
            } else {
                fVar4 = (fVar4 - 0.0) * fVar3 + 0.0;
            }
        }
        *(float *)(arg1 + 4) = fVar4 - (*(float *)(arg2 + 0x74) - fVar8) * fVar3;
    }
    fVar4 = *(float *)(arg1 + 4);
    if (fVar4 <= 0.0) {
        fVar4 = 0.0;
    }
    fVar4 = (float)(int64_t)(fVar4 + 0.5);
    *(float *)(arg1 + 4) = fVar4;
    if ((*(char *)(arg2 + 0x10c) == '\0') && (*(char *)(arg2 + 0x10e) == '\0')) {
        if (*(float *)(arg2 + 0xe0) <= fVar4) {
            fVar4 = *(float *)(arg2 + 0xe0);
        }
        *(float *)(arg1 + 4) = fVar4;
    }
    return arg1;
}

// ============================================================
// Function: FUN_18010c730
// Address: 0x18010c730
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch

int64_t fcn.18010c730(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    bool bVar5;
    bool bVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    uint32_t uVar10;
    int32_t iVar11;
    float *pfVar12;
    float *pfVar13;
    uint64_t uVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    float var_80h;
    float var_7ch;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar9 = *(int64_t *)0x180781f28;
    uVar14 = arg4 & 0xffffffff;
    fVar17 = *(float *)(arg2 + 0x280) + 1.0;
    fVar19 = *(float *)(arg2 + 0x284) + 1.0;
    fVar1 = *(float *)(arg2 + 0xbc);
    fVar18 = (*(float *)(arg2 + 0x27c) - 1.0) + fVar1;
    fVar15 = *(float *)(arg2 + 0xb8);
    fVar16 = (*(float *)(arg2 + 0x278) - 1.0) + fVar15;
    if (fVar19 <= fVar18) {
        fVar18 = fVar19;
    }
    if (fVar17 <= fVar16) {
        fVar16 = fVar17;
    }
    if (((arg4 & 0x15U) == 0) && (uVar14 = (uint64_t)((uint32_t)arg4 | 1), *(char *)(arg2 + 0x104) == '\0')) {
        uVar14 = arg4 & 0xffffffff;
    }
    if ((uVar14 & 0x2a) == 0) {
        uVar10 = 2;
        if (*(char *)(arg2 + 0x110) != '\0') {
            uVar10 = 0x20;
        }
        uVar14 = (uint64_t)((uint32_t)uVar14 | uVar10);
    }
    fVar2 = *(float *)arg3;
    pfVar12 = (float *)(arg3 + 8);
    if ((fVar2 < fVar16) || (fVar17 < *pfVar12)) {
        bVar5 = false;
    } else {
        bVar5 = true;
    }
    if ((*(float *)(arg3 + 4) < fVar18) || (fVar19 < *(float *)(arg3 + 0xc))) {
        bVar7 = false;
    } else {
        bVar7 = true;
    }
    pfVar13 = (float *)(arg3 + 0xc);
    fVar3 = *(float *)(*(int64_t *)0x180781f28 + 0xdec);
    fVar4 = *pfVar12;
    if ((((fVar4 - fVar2) + fVar3 + fVar3 <= fVar17 - fVar16) || ('\0' < *(char *)(arg2 + 0x128))) ||
       ((*(uint8_t *)(arg2 + 0x14) & 0x40) != 0)) {
        bVar6 = true;
    } else {
        bVar6 = false;
    }
    if ((((*pfVar13 - *(float *)(arg3 + 4)) +
          *(float *)(*(int64_t *)0x180781f28 + 0xdf0) + *(float *)(*(int64_t *)0x180781f28 + 0xdf0) <= fVar19 - fVar18)
        || ('\0' < *(char *)(arg2 + 0x129))) || ((*(uint8_t *)(arg2 + 0x14) & 0x40) != 0)) {
        bVar8 = true;
    } else {
        bVar8 = false;
    }
    if (((uVar14 & 1) == 0) || (bVar5)) {
        if ((((uVar14 & 4) != 0) && (!bVar5)) || ((uVar14 & 0x10) != 0)) {
            *(undefined4 *)(arg2 + 0xf4) = 0;
            if (bVar6) {
                *(undefined4 *)(arg2 + 0xec) = 0x3f000000;
                iVar11 = (int32_t)(((((float)(int32_t)((fVar4 + fVar2) * 0.5) - *(float *)(arg2 + 0x60)) -
                                    *(float *)(arg2 + 0xa8)) - fVar15) + *(float *)(arg2 + 0xd4));
                goto code_r0x00018010c9e3;
            }
            fVar15 = (((fVar2 - *(float *)(arg2 + 0x60)) - *(float *)(arg2 + 0xa8)) - fVar15) + *(float *)(arg2 + 0xd4);
            goto code_r0x00018010c9d8;
        }
    } else {
        if ((fVar2 < fVar16) || (!bVar6)) {
            *(undefined4 *)(arg2 + 0xf4) = 0;
            fVar15 = ((((fVar2 - fVar3) - *(float *)(arg2 + 0x60)) - *(float *)(arg2 + 0xa8)) - fVar15) +
                     *(float *)(arg2 + 0xd4);
code_r0x00018010c9d8:
            *(undefined4 *)(arg2 + 0xec) = 0;
            iVar11 = (int32_t)fVar15;
        } else {
            if (fVar4 < fVar17) goto code_r0x00018010c9f2;
            *(undefined4 *)(arg2 + 0xec) = 0x3f800000;
            *(undefined4 *)(arg2 + 0xf4) = 0;
            iVar11 = (int32_t)(((((fVar3 + fVar4) - *(float *)(arg2 + 0x60)) - *(float *)(arg2 + 0xa8)) - fVar15) +
                              *(float *)(arg2 + 0xd4));
        }
code_r0x00018010c9e3:
        *(float *)(arg2 + 0xe4) = (float)iVar11;
    }
code_r0x00018010c9f2:
    if (((uVar14 & 2) == 0) || (bVar7)) {
        if ((((uVar14 & 8) == 0) || (bVar7)) && ((uVar14 & 0x20) == 0)) goto code_r0x00018010cb0e;
        if (!bVar8) {
            fVar15 = *(float *)(arg3 + 4);
            goto code_r0x00018010cad3;
        }
        fVar15 = *pfVar13;
        fVar16 = *(float *)(arg3 + 4);
        *(undefined4 *)(arg2 + 0xf0) = 0x3f000000;
        iVar11 = (int32_t)(((((float)(int32_t)((fVar15 + fVar16) * 0.5) - *(float *)(arg2 + 100)) -
                            *(float *)(arg2 + 0xac)) - fVar1) + *(float *)(arg2 + 0xd8));
    } else if ((*(float *)(arg3 + 4) < fVar18) || (!bVar8)) {
        fVar15 = *(float *)(arg3 + 4) - *(float *)(iVar9 + 0xdf0);
code_r0x00018010cad3:
        *(undefined4 *)(arg2 + 0xf0) = 0;
        iVar11 = (int32_t)((((fVar15 - *(float *)(arg2 + 100)) - *(float *)(arg2 + 0xac)) - fVar1) +
                          *(float *)(arg2 + 0xd8));
    } else {
        fVar15 = *pfVar13;
        if (fVar15 < fVar19) goto code_r0x00018010cb0e;
        fVar16 = *(float *)(iVar9 + 0xdf0);
        *(undefined4 *)(arg2 + 0xf0) = 0x3f800000;
        iVar11 = (int32_t)(((((fVar15 + fVar16) - *(float *)(arg2 + 100)) - *(float *)(arg2 + 0xac)) - fVar1) +
                          *(float *)(arg2 + 0xd8));
    }
    *(undefined4 *)(arg2 + 0xf8) = 0;
    *(float *)(arg2 + 0xe8) = (float)iVar11;
code_r0x00018010cb0e:
    fcn.18010c510((int64_t)&var_8h, arg2);
    var_8h._0_4_ = (float)var_8h - *(float *)(arg2 + 0xd4);
    var_8h._4_4_ = var_8h._4_4_ - *(float *)(arg2 + 0xd8);
    *(float *)arg1 = (float)var_8h;
    *(float *)(arg1 + 4) = var_8h._4_4_;
    if (((uVar14 & 0x40) == 0) && ((*(uint32_t *)(arg2 + 0x14) & 0x1000000) != 0)) {
        if ((arg4 & 0x14U) != 0) {
            arg4 = (int64_t)((uint32_t)arg4 & 0xffffffeb | 1);
        }
        if ((arg4 & 0x28U) != 0) {
            arg4 = (int64_t)((uint32_t)arg4 & 0xffffffd7 | 2);
        }
        var_88h._0_4_ = *(float *)arg3 - (float)var_8h;
        var_88h._4_4_ = *(float *)(arg3 + 4) - var_8h._4_4_;
        var_80h = *pfVar12 - (float)var_8h;
        var_7ch = pfVar12[1] - var_8h._4_4_;
        pfVar12 = (float *)fcn.18010c730((int64_t)&var_8h, *(int64_t *)(arg2 + 0x408), (int64_t)&var_88h, arg4);
        fVar1 = pfVar12[1];
        *(float *)arg1 = *pfVar12 + *(float *)arg1;
        *(float *)(arg1 + 4) = fVar1 + *(float *)(arg1 + 4);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18010c75d
// Address: 0x18010c75d
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch

int64_t fcn.18010c730(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    bool bVar5;
    bool bVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    uint32_t uVar10;
    int32_t iVar11;
    float *pfVar12;
    float *pfVar13;
    uint64_t uVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    float var_80h;
    float var_7ch;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar9 = *(int64_t *)0x180781f28;
    uVar14 = arg4 & 0xffffffff;
    fVar17 = *(float *)(arg2 + 0x280) + 1.0;
    fVar19 = *(float *)(arg2 + 0x284) + 1.0;
    fVar1 = *(float *)(arg2 + 0xbc);
    fVar18 = (*(float *)(arg2 + 0x27c) - 1.0) + fVar1;
    fVar15 = *(float *)(arg2 + 0xb8);
    fVar16 = (*(float *)(arg2 + 0x278) - 1.0) + fVar15;
    if (fVar19 <= fVar18) {
        fVar18 = fVar19;
    }
    if (fVar17 <= fVar16) {
        fVar16 = fVar17;
    }
    if (((arg4 & 0x15U) == 0) && (uVar14 = (uint64_t)((uint32_t)arg4 | 1), *(char *)(arg2 + 0x104) == '\0')) {
        uVar14 = arg4 & 0xffffffff;
    }
    if ((uVar14 & 0x2a) == 0) {
        uVar10 = 2;
        if (*(char *)(arg2 + 0x110) != '\0') {
            uVar10 = 0x20;
        }
        uVar14 = (uint64_t)((uint32_t)uVar14 | uVar10);
    }
    fVar2 = *(float *)arg3;
    pfVar12 = (float *)(arg3 + 8);
    if ((fVar2 < fVar16) || (fVar17 < *pfVar12)) {
        bVar5 = false;
    } else {
        bVar5 = true;
    }
    if ((*(float *)(arg3 + 4) < fVar18) || (fVar19 < *(float *)(arg3 + 0xc))) {
        bVar7 = false;
    } else {
        bVar7 = true;
    }
    pfVar13 = (float *)(arg3 + 0xc);
    fVar3 = *(float *)(*(int64_t *)0x180781f28 + 0xdec);
    fVar4 = *pfVar12;
    if ((((fVar4 - fVar2) + fVar3 + fVar3 <= fVar17 - fVar16) || ('\0' < *(char *)(arg2 + 0x128))) ||
       ((*(uint8_t *)(arg2 + 0x14) & 0x40) != 0)) {
        bVar6 = true;
    } else {
        bVar6 = false;
    }
    if ((((*pfVar13 - *(float *)(arg3 + 4)) +
          *(float *)(*(int64_t *)0x180781f28 + 0xdf0) + *(float *)(*(int64_t *)0x180781f28 + 0xdf0) <= fVar19 - fVar18)
        || ('\0' < *(char *)(arg2 + 0x129))) || ((*(uint8_t *)(arg2 + 0x14) & 0x40) != 0)) {
        bVar8 = true;
    } else {
        bVar8 = false;
    }
    if (((uVar14 & 1) == 0) || (bVar5)) {
        if ((((uVar14 & 4) != 0) && (!bVar5)) || ((uVar14 & 0x10) != 0)) {
            *(undefined4 *)(arg2 + 0xf4) = 0;
            if (bVar6) {
                *(undefined4 *)(arg2 + 0xec) = 0x3f000000;
                iVar11 = (int32_t)(((((float)(int32_t)((fVar4 + fVar2) * 0.5) - *(float *)(arg2 + 0x60)) -
                                    *(float *)(arg2 + 0xa8)) - fVar15) + *(float *)(arg2 + 0xd4));
                goto code_r0x00018010c9e3;
            }
            fVar15 = (((fVar2 - *(float *)(arg2 + 0x60)) - *(float *)(arg2 + 0xa8)) - fVar15) + *(float *)(arg2 + 0xd4);
            goto code_r0x00018010c9d8;
        }
    } else {
        if ((fVar2 < fVar16) || (!bVar6)) {
            *(undefined4 *)(arg2 + 0xf4) = 0;
            fVar15 = ((((fVar2 - fVar3) - *(float *)(arg2 + 0x60)) - *(float *)(arg2 + 0xa8)) - fVar15) +
                     *(float *)(arg2 + 0xd4);
code_r0x00018010c9d8:
            *(undefined4 *)(arg2 + 0xec) = 0;
            iVar11 = (int32_t)fVar15;
        } else {
            if (fVar4 < fVar17) goto code_r0x00018010c9f2;
            *(undefined4 *)(arg2 + 0xec) = 0x3f800000;
            *(undefined4 *)(arg2 + 0xf4) = 0;
            iVar11 = (int32_t)(((((fVar3 + fVar4) - *(float *)(arg2 + 0x60)) - *(float *)(arg2 + 0xa8)) - fVar15) +
                              *(float *)(arg2 + 0xd4));
        }
code_r0x00018010c9e3:
        *(float *)(arg2 + 0xe4) = (float)iVar11;
    }
code_r0x00018010c9f2:
    if (((uVar14 & 2) == 0) || (bVar7)) {
        if ((((uVar14 & 8) == 0) || (bVar7)) && ((uVar14 & 0x20) == 0)) goto code_r0x00018010cb0e;
        if (!bVar8) {
            fVar15 = *(float *)(arg3 + 4);
            goto code_r0x00018010cad3;
        }
        fVar15 = *pfVar13;
        fVar16 = *(float *)(arg3 + 4);
        *(undefined4 *)(arg2 + 0xf0) = 0x3f000000;
        iVar11 = (int32_t)(((((float)(int32_t)((fVar15 + fVar16) * 0.5) - *(float *)(arg2 + 100)) -
                            *(float *)(arg2 + 0xac)) - fVar1) + *(float *)(arg2 + 0xd8));
    } else if ((*(float *)(arg3 + 4) < fVar18) || (!bVar8)) {
        fVar15 = *(float *)(arg3 + 4) - *(float *)(iVar9 + 0xdf0);
code_r0x00018010cad3:
        *(undefined4 *)(arg2 + 0xf0) = 0;
        iVar11 = (int32_t)((((fVar15 - *(float *)(arg2 + 100)) - *(float *)(arg2 + 0xac)) - fVar1) +
                          *(float *)(arg2 + 0xd8));
    } else {
        fVar15 = *pfVar13;
        if (fVar15 < fVar19) goto code_r0x00018010cb0e;
        fVar16 = *(float *)(iVar9 + 0xdf0);
        *(undefined4 *)(arg2 + 0xf0) = 0x3f800000;
        iVar11 = (int32_t)(((((fVar15 + fVar16) - *(float *)(arg2 + 100)) - *(float *)(arg2 + 0xac)) - fVar1) +
                          *(float *)(arg2 + 0xd8));
    }
    *(undefined4 *)(arg2 + 0xf8) = 0;
    *(float *)(arg2 + 0xe8) = (float)iVar11;
code_r0x00018010cb0e:
    fcn.18010c510((int64_t)&var_8h, arg2);
    var_8h._0_4_ = (float)var_8h - *(float *)(arg2 + 0xd4);
    var_8h._4_4_ = var_8h._4_4_ - *(float *)(arg2 + 0xd8);
    *(float *)arg1 = (float)var_8h;
    *(float *)(arg1 + 4) = var_8h._4_4_;
    if (((uVar14 & 0x40) == 0) && ((*(uint32_t *)(arg2 + 0x14) & 0x1000000) != 0)) {
        if ((arg4 & 0x14U) != 0) {
            arg4 = (int64_t)((uint32_t)arg4 & 0xffffffeb | 1);
        }
        if ((arg4 & 0x28U) != 0) {
            arg4 = (int64_t)((uint32_t)arg4 & 0xffffffd7 | 2);
        }
        var_88h._0_4_ = *(float *)arg3 - (float)var_8h;
        var_88h._4_4_ = *(float *)(arg3 + 4) - var_8h._4_4_;
        var_80h = *pfVar12 - (float)var_8h;
        var_7ch = pfVar12[1] - var_8h._4_4_;
        pfVar12 = (float *)fcn.18010c730((int64_t)&var_8h, *(int64_t *)(arg2 + 0x408), (int64_t)&var_88h, arg4);
        fVar1 = pfVar12[1];
        *(float *)arg1 = *pfVar12 + *(float *)arg1;
        *(float *)(arg1 + 4) = fVar1 + *(float *)(arg1 + 4);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18010c780
// Address: 0x18010c780
// Size: 290 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch

int64_t fcn.18010c730(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    bool bVar5;
    bool bVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    uint32_t uVar10;
    int32_t iVar11;
    float *pfVar12;
    float *pfVar13;
    uint64_t uVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    float var_80h;
    float var_7ch;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar9 = *(int64_t *)0x180781f28;
    uVar14 = arg4 & 0xffffffff;
    fVar17 = *(float *)(arg2 + 0x280) + 1.0;
    fVar19 = *(float *)(arg2 + 0x284) + 1.0;
    fVar1 = *(float *)(arg2 + 0xbc);
    fVar18 = (*(float *)(arg2 + 0x27c) - 1.0) + fVar1;
    fVar15 = *(float *)(arg2 + 0xb8);
    fVar16 = (*(float *)(arg2 + 0x278) - 1.0) + fVar15;
    if (fVar19 <= fVar18) {
        fVar18 = fVar19;
    }
    if (fVar17 <= fVar16) {
        fVar16 = fVar17;
    }
    if (((arg4 & 0x15U) == 0) && (uVar14 = (uint64_t)((uint32_t)arg4 | 1), *(char *)(arg2 + 0x104) == '\0')) {
        uVar14 = arg4 & 0xffffffff;
    }
    if ((uVar14 & 0x2a) == 0) {
        uVar10 = 2;
        if (*(char *)(arg2 + 0x110) != '\0') {
            uVar10 = 0x20;
        }
        uVar14 = (uint64_t)((uint32_t)uVar14 | uVar10);
    }
    fVar2 = *(float *)arg3;
    pfVar12 = (float *)(arg3 + 8);
    if ((fVar2 < fVar16) || (fVar17 < *pfVar12)) {
        bVar5 = false;
    } else {
        bVar5 = true;
    }
    if ((*(float *)(arg3 + 4) < fVar18) || (fVar19 < *(float *)(arg3 + 0xc))) {
        bVar7 = false;
    } else {
        bVar7 = true;
    }
    pfVar13 = (float *)(arg3 + 0xc);
    fVar3 = *(float *)(*(int64_t *)0x180781f28 + 0xdec);
    fVar4 = *pfVar12;
    if ((((fVar4 - fVar2) + fVar3 + fVar3 <= fVar17 - fVar16) || ('\0' < *(char *)(arg2 + 0x128))) ||
       ((*(uint8_t *)(arg2 + 0x14) & 0x40) != 0)) {
        bVar6 = true;
    } else {
        bVar6 = false;
    }
    if ((((*pfVar13 - *(float *)(arg3 + 4)) +
          *(float *)(*(int64_t *)0x180781f28 + 0xdf0) + *(float *)(*(int64_t *)0x180781f28 + 0xdf0) <= fVar19 - fVar18)
        || ('\0' < *(char *)(arg2 + 0x129))) || ((*(uint8_t *)(arg2 + 0x14) & 0x40) != 0)) {
        bVar8 = true;
    } else {
        bVar8 = false;
    }
    if (((uVar14 & 1) == 0) || (bVar5)) {
        if ((((uVar14 & 4) != 0) && (!bVar5)) || ((uVar14 & 0x10) != 0)) {
            *(undefined4 *)(arg2 + 0xf4) = 0;
            if (bVar6) {
                *(undefined4 *)(arg2 + 0xec) = 0x3f000000;
                iVar11 = (int32_t)(((((float)(int32_t)((fVar4 + fVar2) * 0.5) - *(float *)(arg2 + 0x60)) -
                                    *(float *)(arg2 + 0xa8)) - fVar15) + *(float *)(arg2 + 0xd4));
                goto code_r0x00018010c9e3;
            }
            fVar15 = (((fVar2 - *(float *)(arg2 + 0x60)) - *(float *)(arg2 + 0xa8)) - fVar15) + *(float *)(arg2 + 0xd4);
            goto code_r0x00018010c9d8;
        }
    } else {
        if ((fVar2 < fVar16) || (!bVar6)) {
            *(undefined4 *)(arg2 + 0xf4) = 0;
            fVar15 = ((((fVar2 - fVar3) - *(float *)(arg2 + 0x60)) - *(float *)(arg2 + 0xa8)) - fVar15) +
                     *(float *)(arg2 + 0xd4);
code_r0x00018010c9d8:
            *(undefined4 *)(arg2 + 0xec) = 0;
            iVar11 = (int32_t)fVar15;
        } else {
            if (fVar4 < fVar17) goto code_r0x00018010c9f2;
            *(undefined4 *)(arg2 + 0xec) = 0x3f800000;
            *(undefined4 *)(arg2 + 0xf4) = 0;
            iVar11 = (int32_t)(((((fVar3 + fVar4) - *(float *)(arg2 + 0x60)) - *(float *)(arg2 + 0xa8)) - fVar15) +
                              *(float *)(arg2 + 0xd4));
        }
code_r0x00018010c9e3:
        *(float *)(arg2 + 0xe4) = (float)iVar11;
    }
code_r0x00018010c9f2:
    if (((uVar14 & 2) == 0) || (bVar7)) {
        if ((((uVar14 & 8) == 0) || (bVar7)) && ((uVar14 & 0x20) == 0)) goto code_r0x00018010cb0e;
        if (!bVar8) {
            fVar15 = *(float *)(arg3 + 4);
            goto code_r0x00018010cad3;
        }
        fVar15 = *pfVar13;
        fVar16 = *(float *)(arg3 + 4);
        *(undefined4 *)(arg2 + 0xf0) = 0x3f000000;
        iVar11 = (int32_t)(((((float)(int32_t)((fVar15 + fVar16) * 0.5) - *(float *)(arg2 + 100)) -
                            *(float *)(arg2 + 0xac)) - fVar1) + *(float *)(arg2 + 0xd8));
    } else if ((*(float *)(arg3 + 4) < fVar18) || (!bVar8)) {
        fVar15 = *(float *)(arg3 + 4) - *(float *)(iVar9 + 0xdf0);
code_r0x00018010cad3:
        *(undefined4 *)(arg2 + 0xf0) = 0;
        iVar11 = (int32_t)((((fVar15 - *(float *)(arg2 + 100)) - *(float *)(arg2 + 0xac)) - fVar1) +
                          *(float *)(arg2 + 0xd8));
    } else {
        fVar15 = *pfVar13;
        if (fVar15 < fVar19) goto code_r0x00018010cb0e;
        fVar16 = *(float *)(iVar9 + 0xdf0);
        *(undefined4 *)(arg2 + 0xf0) = 0x3f800000;
        iVar11 = (int32_t)(((((fVar15 + fVar16) - *(float *)(arg2 + 100)) - *(float *)(arg2 + 0xac)) - fVar1) +
                          *(float *)(arg2 + 0xd8));
    }
    *(undefined4 *)(arg2 + 0xf8) = 0;
    *(float *)(arg2 + 0xe8) = (float)iVar11;
code_r0x00018010cb0e:
    fcn.18010c510((int64_t)&var_8h, arg2);
    var_8h._0_4_ = (float)var_8h - *(float *)(arg2 + 0xd4);
    var_8h._4_4_ = var_8h._4_4_ - *(float *)(arg2 + 0xd8);
    *(float *)arg1 = (float)var_8h;
    *(float *)(arg1 + 4) = var_8h._4_4_;
    if (((uVar14 & 0x40) == 0) && ((*(uint32_t *)(arg2 + 0x14) & 0x1000000) != 0)) {
        if ((arg4 & 0x14U) != 0) {
            arg4 = (int64_t)((uint32_t)arg4 & 0xffffffeb | 1);
        }
        if ((arg4 & 0x28U) != 0) {
            arg4 = (int64_t)((uint32_t)arg4 & 0xffffffd7 | 2);
        }
        var_88h._0_4_ = *(float *)arg3 - (float)var_8h;
        var_88h._4_4_ = *(float *)(arg3 + 4) - var_8h._4_4_;
        var_80h = *pfVar12 - (float)var_8h;
        var_7ch = pfVar12[1] - var_8h._4_4_;
        pfVar12 = (float *)fcn.18010c730((int64_t)&var_8h, *(int64_t *)(arg2 + 0x408), (int64_t)&var_88h, arg4);
        fVar1 = pfVar12[1];
        *(float *)arg1 = *pfVar12 + *(float *)arg1;
        *(float *)(arg1 + 4) = fVar1 + *(float *)(arg1 + 4);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18010c8a2
// Address: 0x18010c8a2
// Size: 362 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch

int64_t fcn.18010c730(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    bool bVar5;
    bool bVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    uint32_t uVar10;
    int32_t iVar11;
    float *pfVar12;
    float *pfVar13;
    uint64_t uVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    float var_80h;
    float var_7ch;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar9 = *(int64_t *)0x180781f28;
    uVar14 = arg4 & 0xffffffff;
    fVar17 = *(float *)(arg2 + 0x280) + 1.0;
    fVar19 = *(float *)(arg2 + 0x284) + 1.0;
    fVar1 = *(float *)(arg2 + 0xbc);
    fVar18 = (*(float *)(arg2 + 0x27c) - 1.0) + fVar1;
    fVar15 = *(float *)(arg2 + 0xb8);
    fVar16 = (*(float *)(arg2 + 0x278) - 1.0) + fVar15;
    if (fVar19 <= fVar18) {
        fVar18 = fVar19;
    }
    if (fVar17 <= fVar16) {
        fVar16 = fVar17;
    }
    if (((arg4 & 0x15U) == 0) && (uVar14 = (uint64_t)((uint32_t)arg4 | 1), *(char *)(arg2 + 0x104) == '\0')) {
        uVar14 = arg4 & 0xffffffff;
    }
    if ((uVar14 & 0x2a) == 0) {
        uVar10 = 2;
        if (*(char *)(arg2 + 0x110) != '\0') {
            uVar10 = 0x20;
        }
        uVar14 = (uint64_t)((uint32_t)uVar14 | uVar10);
    }
    fVar2 = *(float *)arg3;
    pfVar12 = (float *)(arg3 + 8);
    if ((fVar2 < fVar16) || (fVar17 < *pfVar12)) {
        bVar5 = false;
    } else {
        bVar5 = true;
    }
    if ((*(float *)(arg3 + 4) < fVar18) || (fVar19 < *(float *)(arg3 + 0xc))) {
        bVar7 = false;
    } else {
        bVar7 = true;
    }
    pfVar13 = (float *)(arg3 + 0xc);
    fVar3 = *(float *)(*(int64_t *)0x180781f28 + 0xdec);
    fVar4 = *pfVar12;
    if ((((fVar4 - fVar2) + fVar3 + fVar3 <= fVar17 - fVar16) || ('\0' < *(char *)(arg2 + 0x128))) ||
       ((*(uint8_t *)(arg2 + 0x14) & 0x40) != 0)) {
        bVar6 = true;
    } else {
        bVar6 = false;
    }
    if ((((*pfVar13 - *(float *)(arg3 + 4)) +
          *(float *)(*(int64_t *)0x180781f28 + 0xdf0) + *(float *)(*(int64_t *)0x180781f28 + 0xdf0) <= fVar19 - fVar18)
        || ('\0' < *(char *)(arg2 + 0x129))) || ((*(uint8_t *)(arg2 + 0x14) & 0x40) != 0)) {
        bVar8 = true;
    } else {
        bVar8 = false;
    }
    if (((uVar14 & 1) == 0) || (bVar5)) {
        if ((((uVar14 & 4) != 0) && (!bVar5)) || ((uVar14 & 0x10) != 0)) {
            *(undefined4 *)(arg2 + 0xf4) = 0;
            if (bVar6) {
                *(undefined4 *)(arg2 + 0xec) = 0x3f000000;
                iVar11 = (int32_t)(((((float)(int32_t)((fVar4 + fVar2) * 0.5) - *(float *)(arg2 + 0x60)) -
                                    *(float *)(arg2 + 0xa8)) - fVar15) + *(float *)(arg2 + 0xd4));
                goto code_r0x00018010c9e3;
            }
            fVar15 = (((fVar2 - *(float *)(arg2 + 0x60)) - *(float *)(arg2 + 0xa8)) - fVar15) + *(float *)(arg2 + 0xd4);
            goto code_r0x00018010c9d8;
        }
    } else {
        if ((fVar2 < fVar16) || (!bVar6)) {
            *(undefined4 *)(arg2 + 0xf4) = 0;
            fVar15 = ((((fVar2 - fVar3) - *(float *)(arg2 + 0x60)) - *(float *)(arg2 + 0xa8)) - fVar15) +
                     *(float *)(arg2 + 0xd4);
code_r0x00018010c9d8:
            *(undefined4 *)(arg2 + 0xec) = 0;
            iVar11 = (int32_t)fVar15;
        } else {
            if (fVar4 < fVar17) goto code_r0x00018010c9f2;
            *(undefined4 *)(arg2 + 0xec) = 0x3f800000;
            *(undefined4 *)(arg2 + 0xf4) = 0;
            iVar11 = (int32_t)(((((fVar3 + fVar4) - *(float *)(arg2 + 0x60)) - *(float *)(arg2 + 0xa8)) - fVar15) +
                              *(float *)(arg2 + 0xd4));
        }
code_r0x00018010c9e3:
        *(float *)(arg2 + 0xe4) = (float)iVar11;
    }
code_r0x00018010c9f2:
    if (((uVar14 & 2) == 0) || (bVar7)) {
        if ((((uVar14 & 8) == 0) || (bVar7)) && ((uVar14 & 0x20) == 0)) goto code_r0x00018010cb0e;
        if (!bVar8) {
            fVar15 = *(float *)(arg3 + 4);
            goto code_r0x00018010cad3;
        }
        fVar15 = *pfVar13;
        fVar16 = *(float *)(arg3 + 4);
        *(undefined4 *)(arg2 + 0xf0) = 0x3f000000;
        iVar11 = (int32_t)(((((float)(int32_t)((fVar15 + fVar16) * 0.5) - *(float *)(arg2 + 100)) -
                            *(float *)(arg2 + 0xac)) - fVar1) + *(float *)(arg2 + 0xd8));
    } else if ((*(float *)(arg3 + 4) < fVar18) || (!bVar8)) {
        fVar15 = *(float *)(arg3 + 4) - *(float *)(iVar9 + 0xdf0);
code_r0x00018010cad3:
        *(undefined4 *)(arg2 + 0xf0) = 0;
        iVar11 = (int32_t)((((fVar15 - *(float *)(arg2 + 100)) - *(float *)(arg2 + 0xac)) - fVar1) +
                          *(float *)(arg2 + 0xd8));
    } else {
        fVar15 = *pfVar13;
        if (fVar15 < fVar19) goto code_r0x00018010cb0e;
        fVar16 = *(float *)(iVar9 + 0xdf0);
        *(undefined4 *)(arg2 + 0xf0) = 0x3f800000;
        iVar11 = (int32_t)(((((fVar15 + fVar16) - *(float *)(arg2 + 100)) - *(float *)(arg2 + 0xac)) - fVar1) +
                          *(float *)(arg2 + 0xd8));
    }
    *(undefined4 *)(arg2 + 0xf8) = 0;
    *(float *)(arg2 + 0xe8) = (float)iVar11;
code_r0x00018010cb0e:
    fcn.18010c510((int64_t)&var_8h, arg2);
    var_8h._0_4_ = (float)var_8h - *(float *)(arg2 + 0xd4);
    var_8h._4_4_ = var_8h._4_4_ - *(float *)(arg2 + 0xd8);
    *(float *)arg1 = (float)var_8h;
    *(float *)(arg1 + 4) = var_8h._4_4_;
    if (((uVar14 & 0x40) == 0) && ((*(uint32_t *)(arg2 + 0x14) & 0x1000000) != 0)) {
        if ((arg4 & 0x14U) != 0) {
            arg4 = (int64_t)((uint32_t)arg4 & 0xffffffeb | 1);
        }
        if ((arg4 & 0x28U) != 0) {
            arg4 = (int64_t)((uint32_t)arg4 & 0xffffffd7 | 2);
        }
        var_88h._0_4_ = *(float *)arg3 - (float)var_8h;
        var_88h._4_4_ = *(float *)(arg3 + 4) - var_8h._4_4_;
        var_80h = *pfVar12 - (float)var_8h;
        var_7ch = pfVar12[1] - var_8h._4_4_;
        pfVar12 = (float *)fcn.18010c730((int64_t)&var_8h, *(int64_t *)(arg2 + 0x408), (int64_t)&var_88h, arg4);
        fVar1 = pfVar12[1];
        *(float *)arg1 = *pfVar12 + *(float *)arg1;
        *(float *)(arg1 + 4) = fVar1 + *(float *)(arg1 + 4);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18010ca0c
// Address: 0x18010ca0c
// Size: 381 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch

int64_t fcn.18010c730(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    bool bVar5;
    bool bVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    uint32_t uVar10;
    int32_t iVar11;
    float *pfVar12;
    float *pfVar13;
    uint64_t uVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    float var_80h;
    float var_7ch;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar9 = *(int64_t *)0x180781f28;
    uVar14 = arg4 & 0xffffffff;
    fVar17 = *(float *)(arg2 + 0x280) + 1.0;
    fVar19 = *(float *)(arg2 + 0x284) + 1.0;
    fVar1 = *(float *)(arg2 + 0xbc);
    fVar18 = (*(float *)(arg2 + 0x27c) - 1.0) + fVar1;
    fVar15 = *(float *)(arg2 + 0xb8);
    fVar16 = (*(float *)(arg2 + 0x278) - 1.0) + fVar15;
    if (fVar19 <= fVar18) {
        fVar18 = fVar19;
    }
    if (fVar17 <= fVar16) {
        fVar16 = fVar17;
    }
    if (((arg4 & 0x15U) == 0) && (uVar14 = (uint64_t)((uint32_t)arg4 | 1), *(char *)(arg2 + 0x104) == '\0')) {
        uVar14 = arg4 & 0xffffffff;
    }
    if ((uVar14 & 0x2a) == 0) {
        uVar10 = 2;
        if (*(char *)(arg2 + 0x110) != '\0') {
            uVar10 = 0x20;
        }
        uVar14 = (uint64_t)((uint32_t)uVar14 | uVar10);
    }
    fVar2 = *(float *)arg3;
    pfVar12 = (float *)(arg3 + 8);
    if ((fVar2 < fVar16) || (fVar17 < *pfVar12)) {
        bVar5 = false;
    } else {
        bVar5 = true;
    }
    if ((*(float *)(arg3 + 4) < fVar18) || (fVar19 < *(float *)(arg3 + 0xc))) {
        bVar7 = false;
    } else {
        bVar7 = true;
    }
    pfVar13 = (float *)(arg3 + 0xc);
    fVar3 = *(float *)(*(int64_t *)0x180781f28 + 0xdec);
    fVar4 = *pfVar12;
    if ((((fVar4 - fVar2) + fVar3 + fVar3 <= fVar17 - fVar16) || ('\0' < *(char *)(arg2 + 0x128))) ||
       ((*(uint8_t *)(arg2 + 0x14) & 0x40) != 0)) {
        bVar6 = true;
    } else {
        bVar6 = false;
    }
    if ((((*pfVar13 - *(float *)(arg3 + 4)) +
          *(float *)(*(int64_t *)0x180781f28 + 0xdf0) + *(float *)(*(int64_t *)0x180781f28 + 0xdf0) <= fVar19 - fVar18)
        || ('\0' < *(char *)(arg2 + 0x129))) || ((*(uint8_t *)(arg2 + 0x14) & 0x40) != 0)) {
        bVar8 = true;
    } else {
        bVar8 = false;
    }
    if (((uVar14 & 1) == 0) || (bVar5)) {
        if ((((uVar14 & 4) != 0) && (!bVar5)) || ((uVar14 & 0x10) != 0)) {
            *(undefined4 *)(arg2 + 0xf4) = 0;
            if (bVar6) {
                *(undefined4 *)(arg2 + 0xec) = 0x3f000000;
                iVar11 = (int32_t)(((((float)(int32_t)((fVar4 + fVar2) * 0.5) - *(float *)(arg2 + 0x60)) -
                                    *(float *)(arg2 + 0xa8)) - fVar15) + *(float *)(arg2 + 0xd4));
                goto code_r0x00018010c9e3;
            }
            fVar15 = (((fVar2 - *(float *)(arg2 + 0x60)) - *(float *)(arg2 + 0xa8)) - fVar15) + *(float *)(arg2 + 0xd4);
            goto code_r0x00018010c9d8;
        }
    } else {
        if ((fVar2 < fVar16) || (!bVar6)) {
            *(undefined4 *)(arg2 + 0xf4) = 0;
            fVar15 = ((((fVar2 - fVar3) - *(float *)(arg2 + 0x60)) - *(float *)(arg2 + 0xa8)) - fVar15) +
                     *(float *)(arg2 + 0xd4);
code_r0x00018010c9d8:
            *(undefined4 *)(arg2 + 0xec) = 0;
            iVar11 = (int32_t)fVar15;
        } else {
            if (fVar4 < fVar17) goto code_r0x00018010c9f2;
            *(undefined4 *)(arg2 + 0xec) = 0x3f800000;
            *(undefined4 *)(arg2 + 0xf4) = 0;
            iVar11 = (int32_t)(((((fVar3 + fVar4) - *(float *)(arg2 + 0x60)) - *(float *)(arg2 + 0xa8)) - fVar15) +
                              *(float *)(arg2 + 0xd4));
        }
code_r0x00018010c9e3:
        *(float *)(arg2 + 0xe4) = (float)iVar11;
    }
code_r0x00018010c9f2:
    if (((uVar14 & 2) == 0) || (bVar7)) {
        if ((((uVar14 & 8) == 0) || (bVar7)) && ((uVar14 & 0x20) == 0)) goto code_r0x00018010cb0e;
        if (!bVar8) {
            fVar15 = *(float *)(arg3 + 4);
            goto code_r0x00018010cad3;
        }
        fVar15 = *pfVar13;
        fVar16 = *(float *)(arg3 + 4);
        *(undefined4 *)(arg2 + 0xf0) = 0x3f000000;
        iVar11 = (int32_t)(((((float)(int32_t)((fVar15 + fVar16) * 0.5) - *(float *)(arg2 + 100)) -
                            *(float *)(arg2 + 0xac)) - fVar1) + *(float *)(arg2 + 0xd8));
    } else if ((*(float *)(arg3 + 4) < fVar18) || (!bVar8)) {
        fVar15 = *(float *)(arg3 + 4) - *(float *)(iVar9 + 0xdf0);
code_r0x00018010cad3:
        *(undefined4 *)(arg2 + 0xf0) = 0;
        iVar11 = (int32_t)((((fVar15 - *(float *)(arg2 + 100)) - *(float *)(arg2 + 0xac)) - fVar1) +
                          *(float *)(arg2 + 0xd8));
    } else {
        fVar15 = *pfVar13;
        if (fVar15 < fVar19) goto code_r0x00018010cb0e;
        fVar16 = *(float *)(iVar9 + 0xdf0);
        *(undefined4 *)(arg2 + 0xf0) = 0x3f800000;
        iVar11 = (int32_t)(((((fVar15 + fVar16) - *(float *)(arg2 + 100)) - *(float *)(arg2 + 0xac)) - fVar1) +
                          *(float *)(arg2 + 0xd8));
    }
    *(undefined4 *)(arg2 + 0xf8) = 0;
    *(float *)(arg2 + 0xe8) = (float)iVar11;
code_r0x00018010cb0e:
    fcn.18010c510((int64_t)&var_8h, arg2);
    var_8h._0_4_ = (float)var_8h - *(float *)(arg2 + 0xd4);
    var_8h._4_4_ = var_8h._4_4_ - *(float *)(arg2 + 0xd8);
    *(float *)arg1 = (float)var_8h;
    *(float *)(arg1 + 4) = var_8h._4_4_;
    if (((uVar14 & 0x40) == 0) && ((*(uint32_t *)(arg2 + 0x14) & 0x1000000) != 0)) {
        if ((arg4 & 0x14U) != 0) {
            arg4 = (int64_t)((uint32_t)arg4 & 0xffffffeb | 1);
        }
        if ((arg4 & 0x28U) != 0) {
            arg4 = (int64_t)((uint32_t)arg4 & 0xffffffd7 | 2);
        }
        var_88h._0_4_ = *(float *)arg3 - (float)var_8h;
        var_88h._4_4_ = *(float *)(arg3 + 4) - var_8h._4_4_;
        var_80h = *pfVar12 - (float)var_8h;
        var_7ch = pfVar12[1] - var_8h._4_4_;
        pfVar12 = (float *)fcn.18010c730((int64_t)&var_8h, *(int64_t *)(arg2 + 0x408), (int64_t)&var_88h, arg4);
        fVar1 = pfVar12[1];
        *(float *)arg1 = *pfVar12 + *(float *)arg1;
        *(float *)(arg1 + 4) = fVar1 + *(float *)(arg1 + 4);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18010cb89
// Address: 0x18010cb89
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch

int64_t fcn.18010c730(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    bool bVar5;
    bool bVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    uint32_t uVar10;
    int32_t iVar11;
    float *pfVar12;
    float *pfVar13;
    uint64_t uVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    float var_80h;
    float var_7ch;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar9 = *(int64_t *)0x180781f28;
    uVar14 = arg4 & 0xffffffff;
    fVar17 = *(float *)(arg2 + 0x280) + 1.0;
    fVar19 = *(float *)(arg2 + 0x284) + 1.0;
    fVar1 = *(float *)(arg2 + 0xbc);
    fVar18 = (*(float *)(arg2 + 0x27c) - 1.0) + fVar1;
    fVar15 = *(float *)(arg2 + 0xb8);
    fVar16 = (*(float *)(arg2 + 0x278) - 1.0) + fVar15;
    if (fVar19 <= fVar18) {
        fVar18 = fVar19;
    }
    if (fVar17 <= fVar16) {
        fVar16 = fVar17;
    }
    if (((arg4 & 0x15U) == 0) && (uVar14 = (uint64_t)((uint32_t)arg4 | 1), *(char *)(arg2 + 0x104) == '\0')) {
        uVar14 = arg4 & 0xffffffff;
    }
    if ((uVar14 & 0x2a) == 0) {
        uVar10 = 2;
        if (*(char *)(arg2 + 0x110) != '\0') {
            uVar10 = 0x20;
        }
        uVar14 = (uint64_t)((uint32_t)uVar14 | uVar10);
    }
    fVar2 = *(float *)arg3;
    pfVar12 = (float *)(arg3 + 8);
    if ((fVar2 < fVar16) || (fVar17 < *pfVar12)) {
        bVar5 = false;
    } else {
        bVar5 = true;
    }
    if ((*(float *)(arg3 + 4) < fVar18) || (fVar19 < *(float *)(arg3 + 0xc))) {
        bVar7 = false;
    } else {
        bVar7 = true;
    }
    pfVar13 = (float *)(arg3 + 0xc);
    fVar3 = *(float *)(*(int64_t *)0x180781f28 + 0xdec);
    fVar4 = *pfVar12;
    if ((((fVar4 - fVar2) + fVar3 + fVar3 <= fVar17 - fVar16) || ('\0' < *(char *)(arg2 + 0x128))) ||
       ((*(uint8_t *)(arg2 + 0x14) & 0x40) != 0)) {
        bVar6 = true;
    } else {
        bVar6 = false;
    }
    if ((((*pfVar13 - *(float *)(arg3 + 4)) +
          *(float *)(*(int64_t *)0x180781f28 + 0xdf0) + *(float *)(*(int64_t *)0x180781f28 + 0xdf0) <= fVar19 - fVar18)
        || ('\0' < *(char *)(arg2 + 0x129))) || ((*(uint8_t *)(arg2 + 0x14) & 0x40) != 0)) {
        bVar8 = true;
    } else {
        bVar8 = false;
    }
    if (((uVar14 & 1) == 0) || (bVar5)) {
        if ((((uVar14 & 4) != 0) && (!bVar5)) || ((uVar14 & 0x10) != 0)) {
            *(undefined4 *)(arg2 + 0xf4) = 0;
            if (bVar6) {
                *(undefined4 *)(arg2 + 0xec) = 0x3f000000;
                iVar11 = (int32_t)(((((float)(int32_t)((fVar4 + fVar2) * 0.5) - *(float *)(arg2 + 0x60)) -
                                    *(float *)(arg2 + 0xa8)) - fVar15) + *(float *)(arg2 + 0xd4));
                goto code_r0x00018010c9e3;
            }
            fVar15 = (((fVar2 - *(float *)(arg2 + 0x60)) - *(float *)(arg2 + 0xa8)) - fVar15) + *(float *)(arg2 + 0xd4);
            goto code_r0x00018010c9d8;
        }
    } else {
        if ((fVar2 < fVar16) || (!bVar6)) {
            *(undefined4 *)(arg2 + 0xf4) = 0;
            fVar15 = ((((fVar2 - fVar3) - *(float *)(arg2 + 0x60)) - *(float *)(arg2 + 0xa8)) - fVar15) +
                     *(float *)(arg2 + 0xd4);
code_r0x00018010c9d8:
            *(undefined4 *)(arg2 + 0xec) = 0;
            iVar11 = (int32_t)fVar15;
        } else {
            if (fVar4 < fVar17) goto code_r0x00018010c9f2;
            *(undefined4 *)(arg2 + 0xec) = 0x3f800000;
            *(undefined4 *)(arg2 + 0xf4) = 0;
            iVar11 = (int32_t)(((((fVar3 + fVar4) - *(float *)(arg2 + 0x60)) - *(float *)(arg2 + 0xa8)) - fVar15) +
                              *(float *)(arg2 + 0xd4));
        }
code_r0x00018010c9e3:
        *(float *)(arg2 + 0xe4) = (float)iVar11;
    }
code_r0x00018010c9f2:
    if (((uVar14 & 2) == 0) || (bVar7)) {
        if ((((uVar14 & 8) == 0) || (bVar7)) && ((uVar14 & 0x20) == 0)) goto code_r0x00018010cb0e;
        if (!bVar8) {
            fVar15 = *(float *)(arg3 + 4);
            goto code_r0x00018010cad3;
        }
        fVar15 = *pfVar13;
        fVar16 = *(float *)(arg3 + 4);
        *(undefined4 *)(arg2 + 0xf0) = 0x3f000000;
        iVar11 = (int32_t)(((((float)(int32_t)((fVar15 + fVar16) * 0.5) - *(float *)(arg2 + 100)) -
                            *(float *)(arg2 + 0xac)) - fVar1) + *(float *)(arg2 + 0xd8));
    } else if ((*(float *)(arg3 + 4) < fVar18) || (!bVar8)) {
        fVar15 = *(float *)(arg3 + 4) - *(float *)(iVar9 + 0xdf0);
code_r0x00018010cad3:
        *(undefined4 *)(arg2 + 0xf0) = 0;
        iVar11 = (int32_t)((((fVar15 - *(float *)(arg2 + 100)) - *(float *)(arg2 + 0xac)) - fVar1) +
                          *(float *)(arg2 + 0xd8));
    } else {
        fVar15 = *pfVar13;
        if (fVar15 < fVar19) goto code_r0x00018010cb0e;
        fVar16 = *(float *)(iVar9 + 0xdf0);
        *(undefined4 *)(arg2 + 0xf0) = 0x3f800000;
        iVar11 = (int32_t)(((((fVar15 + fVar16) - *(float *)(arg2 + 100)) - *(float *)(arg2 + 0xac)) - fVar1) +
                          *(float *)(arg2 + 0xd8));
    }
    *(undefined4 *)(arg2 + 0xf8) = 0;
    *(float *)(arg2 + 0xe8) = (float)iVar11;
code_r0x00018010cb0e:
    fcn.18010c510((int64_t)&var_8h, arg2);
    var_8h._0_4_ = (float)var_8h - *(float *)(arg2 + 0xd4);
    var_8h._4_4_ = var_8h._4_4_ - *(float *)(arg2 + 0xd8);
    *(float *)arg1 = (float)var_8h;
    *(float *)(arg1 + 4) = var_8h._4_4_;
    if (((uVar14 & 0x40) == 0) && ((*(uint32_t *)(arg2 + 0x14) & 0x1000000) != 0)) {
        if ((arg4 & 0x14U) != 0) {
            arg4 = (int64_t)((uint32_t)arg4 & 0xffffffeb | 1);
        }
        if ((arg4 & 0x28U) != 0) {
            arg4 = (int64_t)((uint32_t)arg4 & 0xffffffd7 | 2);
        }
        var_88h._0_4_ = *(float *)arg3 - (float)var_8h;
        var_88h._4_4_ = *(float *)(arg3 + 4) - var_8h._4_4_;
        var_80h = *pfVar12 - (float)var_8h;
        var_7ch = pfVar12[1] - var_8h._4_4_;
        pfVar12 = (float *)fcn.18010c730((int64_t)&var_8h, *(int64_t *)(arg2 + 0x408), (int64_t)&var_88h, arg4);
        fVar1 = pfVar12[1];
        *(float *)arg1 = *pfVar12 + *(float *)arg1;
        *(float *)(arg1 + 4) = fVar1 + *(float *)(arg1 + 4);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18010ccd0
// Address: 0x18010ccd0
// Size: 392 bytes
// ============================================================
void fcn.18010ccd0(int64_t arg1)
{
    float fVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    float fVar7;
    float fVar8;
    undefined auStack_58 [32];
    int64_t var_38h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    if ((*(char *)(*(int64_t *)0x180781f28 + 0x2401) == '\0') && (*(char *)(*(int64_t *)0x180781f28 + 0x2402) == '\0'))
    {
        if ((arg1 & 2U) == 0) goto code_r0x00018010ce32;
    } else {
        uVar4 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008);
        if ((uVar4 & 1) == 0) {
            uVar5 = 0;
            fVar8 = *(float *)(*(int64_t *)0x180781f28 + 0xec0);
            fVar1 = *(float *)(*(int64_t *)0x180781f28 + 0x118);
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x130) == 1) {
                fVar7 = fVar8 * 0.0;
                uVar5 = 0x3f000000;
                fVar8 = *(float *)(*(int64_t *)0x180781f28 + 0x11c) - fVar8 * 20.0;
                uVar6 = 0x3f800000;
            } else {
                fVar7 = fVar8 * 16.0;
                fVar8 = fVar8 * 10.0 + *(float *)(*(int64_t *)0x180781f28 + 0x11c);
                uVar6 = 0;
            }
            *(float *)(*(int64_t *)0x180781f28 + 0x2020) = fVar8;
            *(undefined4 *)(iVar3 + 0x2024) = uVar5;
            uVar4 = uVar4 | 1;
            *(undefined4 *)(iVar3 + 0x2028) = uVar6;
            *(undefined4 *)(iVar3 + 0x200c) = 1;
            *(undefined *)(iVar3 + 0x204c) = 1;
            *(float *)(iVar3 + 0x201c) = fVar7 + fVar1;
        }
        *(uint32_t *)(iVar3 + 0x2008) = uVar4 | 0x40;
        *(float *)(iVar3 + 0x2070) = *(float *)(iVar3 + 0xf1c) * 0.6;
    }
    iVar2 = *(int64_t *)(iVar3 + 0x2820);
    if ((iVar2 != 0) && (*(char *)(iVar2 + 0x109) != '\0')) {
        uVar4 = *(int32_t *)(iVar3 + 0x15b0) - 1;
        if (-1 < (int32_t)uVar4) {
            do {
                if (*(int64_t *)((uint64_t)uVar4 * 0x78 + *(int64_t *)(iVar3 + 0x15b8)) == iVar2)
                goto code_r0x00018010ce32;
                uVar4 = uVar4 - 1;
            } while (-1 < (int32_t)uVar4);
        }
        *(undefined *)(iVar2 + 0x10e) = 1;
        *(undefined *)(iVar2 + 0x111) = 1;
        *(undefined *)(iVar2 + 299) = 1;
        *(int16_t *)(iVar3 + 0x281e) = *(int16_t *)(iVar3 + 0x281e) + 1;
    }
code_r0x00018010ce32:
    func_0x0001801019f0(&var_38h, 0, 0x20b0347);
    func_0x000180459870(var_18h ^ (uint64_t)auStack_58);
    return;
}

// ============================================================
// Function: FUN_18010ce60
// Address: 0x18010ce60
// Size: 71 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.18010ce60(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    char cVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    cVar1 = fcn.18010ccd0(2);
    if (cVar1 != '\0') {
        fcn.180139b10(arg3);
        fcn.180105c20();
    }
    return;
}

// ============================================================
// Function: FUN_18010ceb0
// Address: 0x18010ceb0
// Size: 44 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Removing arg arg_10bh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.18010ceb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4, int64_t arg_30h)
{
    char cVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000088;
    int64_t in_stack_00000110;
    
    cVar1 = fcn.1800fa150(in_stack_00000088, in_stack_00000110);
    if ((cVar1 != '\0') && (cVar1 = fcn.18010ccd0(2), cVar1 != '\0')) {
        fcn.180139b10(arg3);
        fcn.180105c20();
    }
    return;
}

// ============================================================
// Function: FUN_18010cedc
// Address: 0x18010cedc
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Removing arg arg_10bh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.18010ceb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4, int64_t arg_30h)
{
    char cVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000088;
    int64_t in_stack_00000110;
    
    cVar1 = fcn.1800fa150(in_stack_00000088, in_stack_00000110);
    if ((cVar1 != '\0') && (cVar1 = fcn.18010ccd0(2), cVar1 != '\0')) {
        fcn.180139b10(arg3);
        fcn.180105c20();
    }
    return;
}

// ============================================================
// Function: FUN_18010cf09
// Address: 0x18010cf09
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Removing arg arg_10bh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.18010ceb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4, int64_t arg_30h)
{
    char cVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000088;
    int64_t in_stack_00000110;
    
    cVar1 = fcn.1800fa150(in_stack_00000088, in_stack_00000110);
    if ((cVar1 != '\0') && (cVar1 = fcn.18010ccd0(2), cVar1 != '\0')) {
        fcn.180139b10(arg3);
        fcn.180105c20();
    }
    return;
}

// ============================================================
// Function: FUN_18010cff0
// Address: 0x18010cff0
// Size: 57 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x00018010d04e)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_28h

void fcn.18010cff0(undefined8 param_1)
{
    int32_t *piVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    int64_t *piVar10;
    int64_t iVar11;
    int64_t iVar12;
    int32_t iVar13;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_54h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_34h;
    int64_t var_2ch;
    int64_t var_24h;
    
    var_34h._4_4_ = 0x8010d01c;
    var_2ch._0_4_ = 1;
    iVar7 = func_0x0001800f5a90(param_1, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x150) + -4 +
                                 (int64_t)*(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) * 4));
    iVar8 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2130);
    var_24h._0_4_ = 0;
    uVar6 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x21d8);
    uVar4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
    var_34h._0_4_ = 0;
    var_34h._4_4_ = 0;
    var_2ch._0_4_ = 0;
    var_2ch._4_4_ = 0;
    uVar5 = *(undefined4 *)
             (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x150) + -4 +
             (int64_t)*(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) * 4);
    iVar14 = *(int64_t *)0x180781f28;
    puVar9 = (undefined8 *)func_0x00018010ef90(&var_18h, 0x4000000);
    piVar10 = (int64_t *)(iVar14 + 0x118);
    var_34h._0_4_ = (undefined4)*puVar9;
    var_34h._4_4_ = (undefined4)((uint64_t)*puVar9 >> 0x20);
    if ((*(float *)(iVar14 + 0x118) < -256000.0) || (*(float *)(iVar14 + 0x11c) < -256000.0)) {
        piVar10 = &var_34h;
    }
    piVar1 = (int32_t *)(iVar14 + 0x2120);
    iVar13 = *piVar1;
    var_2ch._0_4_ = *(undefined4 *)piVar10;
    var_2ch._4_4_ = *(undefined4 *)((int64_t)piVar10 + 4);
    if (iVar13 < iVar8 + 1) {
        iVar8 = *(int32_t *)(iVar14 + 0x2124);
        if (iVar13 != iVar8) goto code_r0x00018010d1ba;
        iVar13 = iVar13 + 1;
        if (iVar8 == 0) {
code_r0x00018010d1a3:
            iVar8 = 8;
        } else {
            iVar8 = iVar8 / 2 + iVar8;
        }
    } else {
        iVar12 = *(int64_t *)(iVar14 + 0x2128);
        iVar11 = (int64_t)iVar8 * 0x38;
        if ((*(int32_t *)(iVar11 + iVar12) == iVar7) &&
           (*(int32_t *)(iVar11 + 0x1c + iVar12) == *(int32_t *)(iVar14 + 4) + -1)) {
            *(undefined4 *)(iVar11 + 0x1c + iVar12) = uVar4;
            return;
        }
        func_0x00018010d2d0(iVar8, CONCAT71((unkint7)((uint64_t)iVar12 >> 8), 1));
        iVar8 = *(int32_t *)(iVar14 + 0x2124);
        if (*piVar1 != iVar8) goto code_r0x00018010d1ba;
        iVar13 = *piVar1 + 1;
        if (iVar8 == 0) goto code_r0x00018010d1a3;
        iVar8 = iVar8 / 2 + iVar8;
    }
    if (iVar13 < iVar8) {
        iVar13 = iVar8;
    }
    func_0x00018011f970(piVar1, iVar13);
code_r0x00018010d1ba:
    var_48h._0_4_ = (undefined4)uVar6;
    var_48h._4_4_ = (undefined4)((uint64_t)uVar6 >> 0x20);
    iVar12 = (int64_t)*piVar1 * 0x38;
    iVar14 = *(int64_t *)(iVar14 + 0x2128);
    piVar2 = (int32_t *)(iVar12 + iVar14);
    *piVar2 = iVar7;
    piVar2[1] = 0;
    piVar2[2] = 0;
    piVar2[3] = 0;
    puVar3 = (undefined4 *)(iVar12 + 0x10 + iVar14);
    *puVar3 = (undefined4)var_48h;
    puVar3[1] = var_48h._4_4_;
    puVar3[2] = 0xffffffff;
    puVar3[3] = uVar4;
    puVar3 = (undefined4 *)(iVar12 + 0x20 + iVar14);
    *puVar3 = uVar5;
    puVar3[1] = (undefined4)var_34h;
    puVar3[2] = var_34h._4_4_;
    puVar3[3] = (undefined4)var_2ch;
    *(uint64_t *)(iVar12 + 0x30 + iVar14) = CONCAT44((undefined4)var_24h, var_2ch._4_4_);
    *piVar1 = *piVar1 + 1;
    return;
}

// ============================================================
// Function: FUN_18010d030
// Address: 0x18010d030
// Size: 45 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x00018010d04e)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_28h

void fcn.18010cff0(undefined8 param_1)
{
    int32_t *piVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    int64_t *piVar10;
    int64_t iVar11;
    int64_t iVar12;
    int32_t iVar13;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_54h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_34h;
    int64_t var_2ch;
    int64_t var_24h;
    
    var_34h._4_4_ = 0x8010d01c;
    var_2ch._0_4_ = 1;
    iVar7 = func_0x0001800f5a90(param_1, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x150) + -4 +
                                 (int64_t)*(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) * 4));
    iVar8 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2130);
    var_24h._0_4_ = 0;
    uVar6 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x21d8);
    uVar4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
    var_34h._0_4_ = 0;
    var_34h._4_4_ = 0;
    var_2ch._0_4_ = 0;
    var_2ch._4_4_ = 0;
    uVar5 = *(undefined4 *)
             (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x150) + -4 +
             (int64_t)*(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) * 4);
    iVar14 = *(int64_t *)0x180781f28;
    puVar9 = (undefined8 *)func_0x00018010ef90(&var_18h, 0x4000000);
    piVar10 = (int64_t *)(iVar14 + 0x118);
    var_34h._0_4_ = (undefined4)*puVar9;
    var_34h._4_4_ = (undefined4)((uint64_t)*puVar9 >> 0x20);
    if ((*(float *)(iVar14 + 0x118) < -256000.0) || (*(float *)(iVar14 + 0x11c) < -256000.0)) {
        piVar10 = &var_34h;
    }
    piVar1 = (int32_t *)(iVar14 + 0x2120);
    iVar13 = *piVar1;
    var_2ch._0_4_ = *(undefined4 *)piVar10;
    var_2ch._4_4_ = *(undefined4 *)((int64_t)piVar10 + 4);
    if (iVar13 < iVar8 + 1) {
        iVar8 = *(int32_t *)(iVar14 + 0x2124);
        if (iVar13 != iVar8) goto code_r0x00018010d1ba;
        iVar13 = iVar13 + 1;
        if (iVar8 == 0) {
code_r0x00018010d1a3:
            iVar8 = 8;
        } else {
            iVar8 = iVar8 / 2 + iVar8;
        }
    } else {
        iVar12 = *(int64_t *)(iVar14 + 0x2128);
        iVar11 = (int64_t)iVar8 * 0x38;
        if ((*(int32_t *)(iVar11 + iVar12) == iVar7) &&
           (*(int32_t *)(iVar11 + 0x1c + iVar12) == *(int32_t *)(iVar14 + 4) + -1)) {
            *(undefined4 *)(iVar11 + 0x1c + iVar12) = uVar4;
            return;
        }
        func_0x00018010d2d0(iVar8, CONCAT71((unkint7)((uint64_t)iVar12 >> 8), 1));
        iVar8 = *(int32_t *)(iVar14 + 0x2124);
        if (*piVar1 != iVar8) goto code_r0x00018010d1ba;
        iVar13 = *piVar1 + 1;
        if (iVar8 == 0) goto code_r0x00018010d1a3;
        iVar8 = iVar8 / 2 + iVar8;
    }
    if (iVar13 < iVar8) {
        iVar13 = iVar8;
    }
    func_0x00018011f970(piVar1, iVar13);
code_r0x00018010d1ba:
    var_48h._0_4_ = (undefined4)uVar6;
    var_48h._4_4_ = (undefined4)((uint64_t)uVar6 >> 0x20);
    iVar12 = (int64_t)*piVar1 * 0x38;
    iVar14 = *(int64_t *)(iVar14 + 0x2128);
    piVar2 = (int32_t *)(iVar12 + iVar14);
    *piVar2 = iVar7;
    piVar2[1] = 0;
    piVar2[2] = 0;
    piVar2[3] = 0;
    puVar3 = (undefined4 *)(iVar12 + 0x10 + iVar14);
    *puVar3 = (undefined4)var_48h;
    puVar3[1] = var_48h._4_4_;
    puVar3[2] = 0xffffffff;
    puVar3[3] = uVar4;
    puVar3 = (undefined4 *)(iVar12 + 0x20 + iVar14);
    *puVar3 = uVar5;
    puVar3[1] = (undefined4)var_34h;
    puVar3[2] = var_34h._4_4_;
    puVar3[3] = (undefined4)var_2ch;
    *(uint64_t *)(iVar12 + 0x30 + iVar14) = CONCAT44((undefined4)var_24h, var_2ch._4_4_);
    *piVar1 = *piVar1 + 1;
    return;
}

// ============================================================
// Function: FUN_18010d05d
// Address: 0x18010d05d
// Size: 419 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x00018010d04e)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_28h

void fcn.18010cff0(undefined8 param_1)
{
    int32_t *piVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    int64_t *piVar10;
    int64_t iVar11;
    int64_t iVar12;
    int32_t iVar13;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_54h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_34h;
    int64_t var_2ch;
    int64_t var_24h;
    
    var_34h._4_4_ = 0x8010d01c;
    var_2ch._0_4_ = 1;
    iVar7 = func_0x0001800f5a90(param_1, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x150) + -4 +
                                 (int64_t)*(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) * 4));
    iVar8 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2130);
    var_24h._0_4_ = 0;
    uVar6 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x21d8);
    uVar4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
    var_34h._0_4_ = 0;
    var_34h._4_4_ = 0;
    var_2ch._0_4_ = 0;
    var_2ch._4_4_ = 0;
    uVar5 = *(undefined4 *)
             (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x150) + -4 +
             (int64_t)*(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) * 4);
    iVar14 = *(int64_t *)0x180781f28;
    puVar9 = (undefined8 *)func_0x00018010ef90(&var_18h, 0x4000000);
    piVar10 = (int64_t *)(iVar14 + 0x118);
    var_34h._0_4_ = (undefined4)*puVar9;
    var_34h._4_4_ = (undefined4)((uint64_t)*puVar9 >> 0x20);
    if ((*(float *)(iVar14 + 0x118) < -256000.0) || (*(float *)(iVar14 + 0x11c) < -256000.0)) {
        piVar10 = &var_34h;
    }
    piVar1 = (int32_t *)(iVar14 + 0x2120);
    iVar13 = *piVar1;
    var_2ch._0_4_ = *(undefined4 *)piVar10;
    var_2ch._4_4_ = *(undefined4 *)((int64_t)piVar10 + 4);
    if (iVar13 < iVar8 + 1) {
        iVar8 = *(int32_t *)(iVar14 + 0x2124);
        if (iVar13 != iVar8) goto code_r0x00018010d1ba;
        iVar13 = iVar13 + 1;
        if (iVar8 == 0) {
code_r0x00018010d1a3:
            iVar8 = 8;
        } else {
            iVar8 = iVar8 / 2 + iVar8;
        }
    } else {
        iVar12 = *(int64_t *)(iVar14 + 0x2128);
        iVar11 = (int64_t)iVar8 * 0x38;
        if ((*(int32_t *)(iVar11 + iVar12) == iVar7) &&
           (*(int32_t *)(iVar11 + 0x1c + iVar12) == *(int32_t *)(iVar14 + 4) + -1)) {
            *(undefined4 *)(iVar11 + 0x1c + iVar12) = uVar4;
            return;
        }
        func_0x00018010d2d0(iVar8, CONCAT71((unkint7)((uint64_t)iVar12 >> 8), 1));
        iVar8 = *(int32_t *)(iVar14 + 0x2124);
        if (*piVar1 != iVar8) goto code_r0x00018010d1ba;
        iVar13 = *piVar1 + 1;
        if (iVar8 == 0) goto code_r0x00018010d1a3;
        iVar8 = iVar8 / 2 + iVar8;
    }
    if (iVar13 < iVar8) {
        iVar13 = iVar8;
    }
    func_0x00018011f970(piVar1, iVar13);
code_r0x00018010d1ba:
    var_48h._0_4_ = (undefined4)uVar6;
    var_48h._4_4_ = (undefined4)((uint64_t)uVar6 >> 0x20);
    iVar12 = (int64_t)*piVar1 * 0x38;
    iVar14 = *(int64_t *)(iVar14 + 0x2128);
    piVar2 = (int32_t *)(iVar12 + iVar14);
    *piVar2 = iVar7;
    piVar2[1] = 0;
    piVar2[2] = 0;
    piVar2[3] = 0;
    puVar3 = (undefined4 *)(iVar12 + 0x10 + iVar14);
    *puVar3 = (undefined4)var_48h;
    puVar3[1] = var_48h._4_4_;
    puVar3[2] = 0xffffffff;
    puVar3[3] = uVar4;
    puVar3 = (undefined4 *)(iVar12 + 0x20 + iVar14);
    *puVar3 = uVar5;
    puVar3[1] = (undefined4)var_34h;
    puVar3[2] = var_34h._4_4_;
    puVar3[3] = (undefined4)var_2ch;
    *(uint64_t *)(iVar12 + 0x30 + iVar14) = CONCAT44((undefined4)var_24h, var_2ch._4_4_);
    *piVar1 = *piVar1 + 1;
    return;
}

// ============================================================
// Function: FUN_18010d200
// Address: 0x18010d200
// Size: 8 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x00018010d04e)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_28h

void fcn.18010cff0(undefined8 param_1)
{
    int32_t *piVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    int64_t *piVar10;
    int64_t iVar11;
    int64_t iVar12;
    int32_t iVar13;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_54h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_34h;
    int64_t var_2ch;
    int64_t var_24h;
    
    var_34h._4_4_ = 0x8010d01c;
    var_2ch._0_4_ = 1;
    iVar7 = func_0x0001800f5a90(param_1, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x150) + -4 +
                                 (int64_t)*(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) * 4));
    iVar8 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2130);
    var_24h._0_4_ = 0;
    uVar6 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x21d8);
    uVar4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
    var_34h._0_4_ = 0;
    var_34h._4_4_ = 0;
    var_2ch._0_4_ = 0;
    var_2ch._4_4_ = 0;
    uVar5 = *(undefined4 *)
             (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x150) + -4 +
             (int64_t)*(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) * 4);
    iVar14 = *(int64_t *)0x180781f28;
    puVar9 = (undefined8 *)func_0x00018010ef90(&var_18h, 0x4000000);
    piVar10 = (int64_t *)(iVar14 + 0x118);
    var_34h._0_4_ = (undefined4)*puVar9;
    var_34h._4_4_ = (undefined4)((uint64_t)*puVar9 >> 0x20);
    if ((*(float *)(iVar14 + 0x118) < -256000.0) || (*(float *)(iVar14 + 0x11c) < -256000.0)) {
        piVar10 = &var_34h;
    }
    piVar1 = (int32_t *)(iVar14 + 0x2120);
    iVar13 = *piVar1;
    var_2ch._0_4_ = *(undefined4 *)piVar10;
    var_2ch._4_4_ = *(undefined4 *)((int64_t)piVar10 + 4);
    if (iVar13 < iVar8 + 1) {
        iVar8 = *(int32_t *)(iVar14 + 0x2124);
        if (iVar13 != iVar8) goto code_r0x00018010d1ba;
        iVar13 = iVar13 + 1;
        if (iVar8 == 0) {
code_r0x00018010d1a3:
            iVar8 = 8;
        } else {
            iVar8 = iVar8 / 2 + iVar8;
        }
    } else {
        iVar12 = *(int64_t *)(iVar14 + 0x2128);
        iVar11 = (int64_t)iVar8 * 0x38;
        if ((*(int32_t *)(iVar11 + iVar12) == iVar7) &&
           (*(int32_t *)(iVar11 + 0x1c + iVar12) == *(int32_t *)(iVar14 + 4) + -1)) {
            *(undefined4 *)(iVar11 + 0x1c + iVar12) = uVar4;
            return;
        }
        func_0x00018010d2d0(iVar8, CONCAT71((unkint7)((uint64_t)iVar12 >> 8), 1));
        iVar8 = *(int32_t *)(iVar14 + 0x2124);
        if (*piVar1 != iVar8) goto code_r0x00018010d1ba;
        iVar13 = *piVar1 + 1;
        if (iVar8 == 0) goto code_r0x00018010d1a3;
        iVar8 = iVar8 / 2 + iVar8;
    }
    if (iVar13 < iVar8) {
        iVar13 = iVar8;
    }
    func_0x00018011f970(piVar1, iVar13);
code_r0x00018010d1ba:
    var_48h._0_4_ = (undefined4)uVar6;
    var_48h._4_4_ = (undefined4)((uint64_t)uVar6 >> 0x20);
    iVar12 = (int64_t)*piVar1 * 0x38;
    iVar14 = *(int64_t *)(iVar14 + 0x2128);
    piVar2 = (int32_t *)(iVar12 + iVar14);
    *piVar2 = iVar7;
    piVar2[1] = 0;
    piVar2[2] = 0;
    piVar2[3] = 0;
    puVar3 = (undefined4 *)(iVar12 + 0x10 + iVar14);
    *puVar3 = (undefined4)var_48h;
    puVar3[1] = var_48h._4_4_;
    puVar3[2] = 0xffffffff;
    puVar3[3] = uVar4;
    puVar3 = (undefined4 *)(iVar12 + 0x20 + iVar14);
    *puVar3 = uVar5;
    puVar3[1] = (undefined4)var_34h;
    puVar3[2] = var_34h._4_4_;
    puVar3[3] = (undefined4)var_2ch;
    *(uint64_t *)(iVar12 + 0x30 + iVar14) = CONCAT44((undefined4)var_24h, var_2ch._4_4_);
    *piVar1 = *piVar1 + 1;
    return;
}

// ============================================================
// Function: FUN_18010d210
// Address: 0x18010d210
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18010d210(int64_t arg1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined in_DL;
    uint32_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t var_8h;
    
    iVar1 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120);
    if (iVar1 != 0) {
        uVar6 = 0;
        if ((arg1 != 0) && (0 < iVar1)) {
            do {
                uVar5 = uVar6;
                if (*(int64_t *)(uVar6 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128)) != 0) {
                    do {
                        iVar2 = *(int64_t *)
                                 ((int64_t)(int32_t)uVar5 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
                        if (iVar2 != 0) {
                            iVar3 = arg1;
                            if (*(int64_t *)(arg1 + 0x418) == iVar2) break;
                            do {
                                if (iVar3 == iVar2) goto code_r0x00018010d2ab;
                                iVar3 = *(int64_t *)(iVar3 + 0x410);
                            } while (iVar3 != 0);
                        }
                        uVar4 = (int32_t)uVar5 + 1;
                        uVar5 = (uint64_t)uVar4;
                        if (iVar1 <= (int32_t)uVar4) goto code_r0x00018010d2b8;
                    } while( true );
                }
code_r0x00018010d2ab:
                uVar4 = (int32_t)uVar6 + 1;
                uVar6 = (uint64_t)uVar4;
            } while ((int32_t)uVar4 < iVar1);
        }
        if ((int32_t)uVar6 < iVar1) {
code_r0x00018010d2b8:
            func_0x00018010d2d0(uVar6, in_DL);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18010d236
// Address: 0x18010d236
// Size: 147 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18010d210(int64_t arg1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined in_DL;
    uint32_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t var_8h;
    
    iVar1 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120);
    if (iVar1 != 0) {
        uVar6 = 0;
        if ((arg1 != 0) && (0 < iVar1)) {
            do {
                uVar5 = uVar6;
                if (*(int64_t *)(uVar6 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128)) != 0) {
                    do {
                        iVar2 = *(int64_t *)
                                 ((int64_t)(int32_t)uVar5 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
                        if (iVar2 != 0) {
                            iVar3 = arg1;
                            if (*(int64_t *)(arg1 + 0x418) == iVar2) break;
                            do {
                                if (iVar3 == iVar2) goto code_r0x00018010d2ab;
                                iVar3 = *(int64_t *)(iVar3 + 0x410);
                            } while (iVar3 != 0);
                        }
                        uVar4 = (int32_t)uVar5 + 1;
                        uVar5 = (uint64_t)uVar4;
                        if (iVar1 <= (int32_t)uVar4) goto code_r0x00018010d2b8;
                    } while( true );
                }
code_r0x00018010d2ab:
                uVar4 = (int32_t)uVar6 + 1;
                uVar6 = (uint64_t)uVar4;
            } while ((int32_t)uVar4 < iVar1);
        }
        if ((int32_t)uVar6 < iVar1) {
code_r0x00018010d2b8:
            func_0x00018010d2d0(uVar6, in_DL);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18010d2c9
// Address: 0x18010d2c9
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18010d210(int64_t arg1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined in_DL;
    uint32_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t var_8h;
    
    iVar1 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120);
    if (iVar1 != 0) {
        uVar6 = 0;
        if ((arg1 != 0) && (0 < iVar1)) {
            do {
                uVar5 = uVar6;
                if (*(int64_t *)(uVar6 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128)) != 0) {
                    do {
                        iVar2 = *(int64_t *)
                                 ((int64_t)(int32_t)uVar5 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
                        if (iVar2 != 0) {
                            iVar3 = arg1;
                            if (*(int64_t *)(arg1 + 0x418) == iVar2) break;
                            do {
                                if (iVar3 == iVar2) goto code_r0x00018010d2ab;
                                iVar3 = *(int64_t *)(iVar3 + 0x410);
                            } while (iVar3 != 0);
                        }
                        uVar4 = (int32_t)uVar5 + 1;
                        uVar5 = (uint64_t)uVar4;
                        if (iVar1 <= (int32_t)uVar4) goto code_r0x00018010d2b8;
                    } while( true );
                }
code_r0x00018010d2ab:
                uVar4 = (int32_t)uVar6 + 1;
                uVar6 = (uint64_t)uVar4;
            } while ((int32_t)uVar4 < iVar1);
        }
        if ((int32_t)uVar6 < iVar1) {
code_r0x00018010d2b8:
            func_0x00018010d2d0(uVar6, in_DL);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18010d2d0
// Address: 0x18010d2d0
// Size: 299 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21e4h because it doesn't fit into ProtoModel

void fcn.18010d2d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    bool bVar9;
    
    iVar2 = *(int64_t *)0x180781f28;
    iVar5 = (int32_t)arg1;
    iVar6 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2124);
    iVar1 = *(int64_t *)((int64_t)iVar5 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
    iVar7 = *(int64_t *)((int64_t)iVar5 * 0x38 + 0x10 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
    if (iVar6 < iVar5) {
        if (iVar6 == 0) {
            uVar4 = 8;
        } else {
            uVar4 = iVar6 / 2 + iVar6;
        }
        uVar8 = arg1 & 0xffffffff;
        if (iVar5 < (int32_t)uVar4) {
            uVar8 = (uint64_t)uVar4;
        }
        func_0x00018011f970(*(int64_t *)0x180781f28 + 0x2120, uVar8);
    }
    iVar3 = *(int64_t *)0x180781f28;
    *(int32_t *)(iVar2 + 0x2120) = iVar5;
    if (((char)arg2 != '\0') && (iVar1 != 0)) {
        if ((*(uint32_t *)(iVar1 + 0x14) >> 0x1c & 1) != 0) {
            iVar7 = *(int64_t *)(iVar1 + 0x408);
        }
        if ((iVar7 == 0) || (*(char *)(iVar7 + 0x10a) != '\0')) {
            bVar9 = *(int32_t *)(iVar2 + 0x21e4) == 0;
        } else {
            iVar6 = -1;
            uVar4 = *(uint32_t *)(iVar1 + 0x14) >> 0x18 & 1;
            while (uVar4 != 0) {
                iVar1 = *(int64_t *)(iVar1 + 0x408);
                iVar6 = 0;
                uVar4 = *(uint32_t *)(iVar1 + 0x14) & 0x1000000;
            }
            uVar4 = *(int16_t *)(iVar1 + 0x120) + iVar6;
            iVar7 = 0;
            if (-1 < (int32_t)uVar4) {
                do {
                    iVar7 = *(int64_t *)(*(int64_t *)(iVar3 + 0x1598) + (uint64_t)uVar4 * 8);
                    if (((iVar7 != 0) && (*(char *)(iVar7 + 0x10a) != '\0')) &&
                       ((*(uint32_t *)(iVar7 + 0x14) & 0x10200) != 0x10200)) break;
                    uVar4 = uVar4 - 1;
                    iVar7 = 0;
                } while (-1 < (int32_t)uVar4);
            }
            bVar9 = true;
        }
        func_0x00018010e050(iVar7, bVar9);
    }
    return;
}

// ============================================================
// Function: FUN_18010d400
// Address: 0x18010d400
// Size: 167 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21e4h because it doesn't fit into ProtoModel

void fcn.18010d400(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    uint64_t arg1;
    int64_t iVar4;
    uint64_t arg3_00;
    
    iVar2 = *(int64_t *)0x180781f28;
    uVar3 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) - 1;
    if ((-1 < (int32_t)uVar3) && ((int32_t)uVar3 < *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120))) {
        iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128);
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2138);
        arg3_00 = (int64_t)(int32_t)uVar3 * 0x38;
        if (*(int32_t *)(arg3_00 + iVar4) == *(int32_t *)(arg3_00 + iVar1)) {
            arg1 = (uint64_t)uVar3;
            if (0 < (int32_t)uVar3) {
                while( true ) {
                    arg3_00 = arg1;
                    iVar4 = *(int64_t *)(arg3_00 * 0x38 + 8 + iVar1);
                    arg1 = arg3_00;
                    if (((iVar4 == 0) || ((*(uint32_t *)(iVar4 + 0x14) & 0x10000000) == 0)) ||
                       (iVar4 = *(int64_t *)(arg3_00 * 0x38 + -0x30 + iVar1), iVar4 == 0)) break;
                    if (((*(uint32_t *)(iVar4 + 0x14) & 0x400) != 0) ||
                       (uVar3 = (int32_t)arg3_00 - 1, arg1 = (uint64_t)uVar3, (int32_t)uVar3 < 1)) break;
                }
            }
            fcn.18010d2d0(arg1, CONCAT71((unkint7)((uint64_t)iVar4 >> 8), 1), arg3_00);
            if (*(int64_t *)(iVar2 + 0x21d8) != 0) {
                *(undefined *)(*(int64_t *)(iVar2 + 0x21d8) + 0x1b9) = 1;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18010d4b0
// Address: 0x18010d4b0
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_27ch
// WARNING: [rz-ghidra] Detected overlap for variable var_286h
// WARNING: [rz-ghidra] Detected overlap for variable var_284h
// WARNING: [rz-ghidra] Detected overlap for variable var_278h
// WARNING: [rz-ghidra] Detected overlap for variable var_288h
// WARNING: [rz-ghidra] Detected overlap for variable var_287h
// WARNING: [rz-ghidra] Detected overlap for variable arg_74h
// WARNING: [rz-ghidra] Detected overlap for variable arg_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_285h
// WARNING: [rz-ghidra] Detected overlap for variable var_274h
// WARNING: [rz-ghidra] Detected overlap for variable var_24ch
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34h

void fcn.18010d4b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char cVar1;
    uint64_t uVar2;
    int64_t unaff_RBX;
    int64_t in_stack_00000008;
    int64_t in_stack_00000018;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t in_stack_00000048;
    int64_t in_stack_00000058;
    int64_t in_stack_00000060;
    int64_t in_stack_00000068;
    int64_t in_stack_00000070;
    int64_t in_stack_00000078;
    int64_t in_stack_00000080;
    int64_t in_stack_00000090;
    undefined auStack_48 [32];
    int64_t var_28h;
    int64_t in_stack_ffffffffffffffe0;
    int64_t in_stack_ffffffffffffffe8;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar2 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_48;
    if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) < *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120)) &&
       (arg3 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) * 0x38,
       *(int32_t *)(arg3 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128)) == (int32_t)arg1)) {
        cVar1 = fcn.1801019f0(var_28h, in_stack_ffffffffffffffe0, in_stack_ffffffffffffffe8, unaff_RBX, 
                              in_stack_00000008, in_stack_00000018, in_stack_00000028, in_stack_00000030, 
                              in_stack_00000048, in_stack_00000058, in_stack_00000060, in_stack_00000068, 
                              in_stack_00000070, in_stack_00000078, in_stack_00000080, in_stack_00000090);
        if (cVar1 == '\0') {
            fcn.18010d5c0();
        }
        fcn.180459870(uVar2 ^ (uint64_t)auStack_48);
        return;
    }
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2008) = 0;
    fcn.180459870(uVar2 ^ (uint64_t)auStack_48, arg2, arg3);
    return;
}

// ============================================================
// Function: FUN_18010d4f1
// Address: 0x18010d4f1
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_27ch
// WARNING: [rz-ghidra] Detected overlap for variable var_286h
// WARNING: [rz-ghidra] Detected overlap for variable var_284h
// WARNING: [rz-ghidra] Detected overlap for variable var_278h
// WARNING: [rz-ghidra] Detected overlap for variable var_288h
// WARNING: [rz-ghidra] Detected overlap for variable var_287h
// WARNING: [rz-ghidra] Detected overlap for variable arg_74h
// WARNING: [rz-ghidra] Detected overlap for variable arg_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_285h
// WARNING: [rz-ghidra] Detected overlap for variable var_274h
// WARNING: [rz-ghidra] Detected overlap for variable var_24ch
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34h

void fcn.18010d4b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char cVar1;
    uint64_t uVar2;
    int64_t unaff_RBX;
    int64_t in_stack_00000008;
    int64_t in_stack_00000018;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t in_stack_00000048;
    int64_t in_stack_00000058;
    int64_t in_stack_00000060;
    int64_t in_stack_00000068;
    int64_t in_stack_00000070;
    int64_t in_stack_00000078;
    int64_t in_stack_00000080;
    int64_t in_stack_00000090;
    undefined auStack_48 [32];
    int64_t var_28h;
    int64_t in_stack_ffffffffffffffe0;
    int64_t in_stack_ffffffffffffffe8;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar2 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_48;
    if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) < *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120)) &&
       (arg3 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) * 0x38,
       *(int32_t *)(arg3 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128)) == (int32_t)arg1)) {
        cVar1 = fcn.1801019f0(var_28h, in_stack_ffffffffffffffe0, in_stack_ffffffffffffffe8, unaff_RBX, 
                              in_stack_00000008, in_stack_00000018, in_stack_00000028, in_stack_00000030, 
                              in_stack_00000048, in_stack_00000058, in_stack_00000060, in_stack_00000068, 
                              in_stack_00000070, in_stack_00000078, in_stack_00000080, in_stack_00000090);
        if (cVar1 == '\0') {
            fcn.18010d5c0();
        }
        fcn.180459870(uVar2 ^ (uint64_t)auStack_48);
        return;
    }
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2008) = 0;
    fcn.180459870(uVar2 ^ (uint64_t)auStack_48, arg2, arg3);
    return;
}

// ============================================================
// Function: FUN_18010d52b
// Address: 0x18010d52b
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_27ch
// WARNING: [rz-ghidra] Detected overlap for variable var_286h
// WARNING: [rz-ghidra] Detected overlap for variable var_284h
// WARNING: [rz-ghidra] Detected overlap for variable var_278h
// WARNING: [rz-ghidra] Detected overlap for variable var_288h
// WARNING: [rz-ghidra] Detected overlap for variable var_287h
// WARNING: [rz-ghidra] Detected overlap for variable arg_74h
// WARNING: [rz-ghidra] Detected overlap for variable arg_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_285h
// WARNING: [rz-ghidra] Detected overlap for variable var_274h
// WARNING: [rz-ghidra] Detected overlap for variable var_24ch
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34h

void fcn.18010d4b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char cVar1;
    uint64_t uVar2;
    int64_t unaff_RBX;
    int64_t in_stack_00000008;
    int64_t in_stack_00000018;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t in_stack_00000048;
    int64_t in_stack_00000058;
    int64_t in_stack_00000060;
    int64_t in_stack_00000068;
    int64_t in_stack_00000070;
    int64_t in_stack_00000078;
    int64_t in_stack_00000080;
    int64_t in_stack_00000090;
    undefined auStack_48 [32];
    int64_t var_28h;
    int64_t in_stack_ffffffffffffffe0;
    int64_t in_stack_ffffffffffffffe8;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar2 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_48;
    if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) < *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120)) &&
       (arg3 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) * 0x38,
       *(int32_t *)(arg3 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128)) == (int32_t)arg1)) {
        cVar1 = fcn.1801019f0(var_28h, in_stack_ffffffffffffffe0, in_stack_ffffffffffffffe8, unaff_RBX, 
                              in_stack_00000008, in_stack_00000018, in_stack_00000028, in_stack_00000030, 
                              in_stack_00000048, in_stack_00000058, in_stack_00000060, in_stack_00000068, 
                              in_stack_00000070, in_stack_00000078, in_stack_00000080, in_stack_00000090);
        if (cVar1 == '\0') {
            fcn.18010d5c0();
        }
        fcn.180459870(uVar2 ^ (uint64_t)auStack_48);
        return;
    }
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2008) = 0;
    fcn.180459870(uVar2 ^ (uint64_t)auStack_48, arg2, arg3);
    return;
}

// ============================================================
// Function: FUN_18010d550
// Address: 0x18010d550
// Size: 103 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_27ch
// WARNING: [rz-ghidra] Detected overlap for variable var_286h
// WARNING: [rz-ghidra] Detected overlap for variable var_284h
// WARNING: [rz-ghidra] Detected overlap for variable var_278h
// WARNING: [rz-ghidra] Detected overlap for variable var_288h
// WARNING: [rz-ghidra] Detected overlap for variable var_287h
// WARNING: [rz-ghidra] Detected overlap for variable arg_74h
// WARNING: [rz-ghidra] Detected overlap for variable arg_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_285h
// WARNING: [rz-ghidra] Detected overlap for variable var_274h
// WARNING: [rz-ghidra] Detected overlap for variable var_24ch
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34h

int64_t fcn.18010d550(undefined8 placeholder_0, int64_t arg2)
{
    int32_t *piVar1;
    char cVar2;
    int32_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t unaff_RBX;
    int64_t in_stack_00000008;
    int64_t in_stack_00000018;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t in_stack_00000048;
    int64_t in_stack_00000058;
    int64_t in_stack_00000060;
    int64_t in_stack_00000068;
    int64_t in_stack_00000070;
    int64_t in_stack_00000078;
    int64_t in_stack_00000080;
    int64_t in_stack_00000090;
    undefined auStack_48 [24];
    undefined8 uStack_30;
    int64_t in_stack_ffffffffffffffd8;
    int64_t in_stack_ffffffffffffffe0;
    int64_t in_stack_ffffffffffffffe8;
    
    piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0x2130);
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) <= *piVar1) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2008) = 0;
        return (uint64_t)(unkuint3)((uint32_t)*piVar1 >> 8) << 8;
    }
    uStack_30 = 0x18010d5a3;
    iVar3 = fcn.1800f5a90(placeholder_0, 0, 
                          *(undefined4 *)
                           (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x150) + -4 +
                           (int64_t)*(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) * 4));
    uVar4 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_48;
    if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) < *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120)) &&
       (*(int32_t *)
         ((int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) * 0x38 +
         *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128)) == iVar3)) {
        cVar2 = fcn.1801019f0(in_stack_ffffffffffffffd8, in_stack_ffffffffffffffe0, in_stack_ffffffffffffffe8, unaff_RBX
                              , in_stack_00000008, in_stack_00000018, in_stack_00000028, in_stack_00000030, 
                              in_stack_00000048, in_stack_00000058, in_stack_00000060, in_stack_00000068, 
                              in_stack_00000070, in_stack_00000078, in_stack_00000080, in_stack_00000090);
        if (cVar2 == '\0') {
            fcn.18010d5c0();
        }
        iVar5 = fcn.180459870(uVar4 ^ (uint64_t)auStack_48);
        return iVar5;
    }
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2008) = 0;
    iVar5 = fcn.180459870(uVar4 ^ (uint64_t)auStack_48, (uint32_t)arg2 | 0x141);
    return iVar5;
}

// ============================================================
// Function: FUN_18010d5c0
// Address: 0x18010d5c0
// Size: 46 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18010d5c0(void)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar4 = *(int64_t *)0x180781f28;
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (((*(uint32_t *)(iVar3 + 0x14) & 0x4000000) != 0) && (0 < *(int32_t *)(*(int64_t *)0x180781f28 + 0x2130))) {
        if (((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) == iVar3) &&
            (*(char *)(*(int64_t *)0x180781f28 + 0x2279) != '\0')) &&
           (*(int32_t *)(*(int64_t *)0x180781f28 + 0x21e4) == *(int32_t *)(iVar3 + 0x1b0))) {
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x227c) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x227c) & 0xfffffff2;
            *(uint32_t *)(iVar4 + 0x227c) = *(uint32_t *)(iVar4 + 0x227c) | 2;
        }
        uVar1 = *(undefined4 *)(iVar4 + 0x154c);
        uVar2 = *(undefined4 *)(iVar4 + 0x1548);
        *(undefined4 *)(iVar4 + 0x154c) = *(undefined4 *)(iVar3 + 0x10);
        if ((*(uint32_t *)(iVar3 + 0x14) & 0x1000000) != 0) {
            *(undefined4 *)(iVar4 + 0x1548) = *(undefined4 *)(iVar3 + 0x10);
        }
        fcn.180105c20();
        *(undefined4 *)(iVar4 + 0x154c) = uVar1;
        *(undefined4 *)(iVar4 + 0x1548) = uVar2;
        return;
    }
    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018010d690. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644f20);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_18010d5ee
// Address: 0x18010d5ee
// Size: 128 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18010d5c0(void)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar4 = *(int64_t *)0x180781f28;
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (((*(uint32_t *)(iVar3 + 0x14) & 0x4000000) != 0) && (0 < *(int32_t *)(*(int64_t *)0x180781f28 + 0x2130))) {
        if (((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) == iVar3) &&
            (*(char *)(*(int64_t *)0x180781f28 + 0x2279) != '\0')) &&
           (*(int32_t *)(*(int64_t *)0x180781f28 + 0x21e4) == *(int32_t *)(iVar3 + 0x1b0))) {
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x227c) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x227c) & 0xfffffff2;
            *(uint32_t *)(iVar4 + 0x227c) = *(uint32_t *)(iVar4 + 0x227c) | 2;
        }
        uVar1 = *(undefined4 *)(iVar4 + 0x154c);
        uVar2 = *(undefined4 *)(iVar4 + 0x1548);
        *(undefined4 *)(iVar4 + 0x154c) = *(undefined4 *)(iVar3 + 0x10);
        if ((*(uint32_t *)(iVar3 + 0x14) & 0x1000000) != 0) {
            *(undefined4 *)(iVar4 + 0x1548) = *(undefined4 *)(iVar3 + 0x10);
        }
        fcn.180105c20();
        *(undefined4 *)(iVar4 + 0x154c) = uVar1;
        *(undefined4 *)(iVar4 + 0x1548) = uVar2;
        return;
    }
    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018010d690. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644f20);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_18010d66e
// Address: 0x18010d66e
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18010d5c0(void)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar4 = *(int64_t *)0x180781f28;
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (((*(uint32_t *)(iVar3 + 0x14) & 0x4000000) != 0) && (0 < *(int32_t *)(*(int64_t *)0x180781f28 + 0x2130))) {
        if (((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) == iVar3) &&
            (*(char *)(*(int64_t *)0x180781f28 + 0x2279) != '\0')) &&
           (*(int32_t *)(*(int64_t *)0x180781f28 + 0x21e4) == *(int32_t *)(iVar3 + 0x1b0))) {
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x227c) =
                 *(uint32_t *)(*(int64_t *)0x180781f28 + 0x227c) & 0xfffffff2;
            *(uint32_t *)(iVar4 + 0x227c) = *(uint32_t *)(iVar4 + 0x227c) | 2;
        }
        uVar1 = *(undefined4 *)(iVar4 + 0x154c);
        uVar2 = *(undefined4 *)(iVar4 + 0x1548);
        *(undefined4 *)(iVar4 + 0x154c) = *(undefined4 *)(iVar3 + 0x10);
        if ((*(uint32_t *)(iVar3 + 0x14) & 0x1000000) != 0) {
            *(undefined4 *)(iVar4 + 0x1548) = *(undefined4 *)(iVar3 + 0x10);
        }
        fcn.180105c20();
        *(undefined4 *)(iVar4 + 0x154c) = uVar1;
        *(undefined4 *)(iVar4 + 0x1548) = uVar2;
        return;
    }
    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018010d690. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644f20);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_18010d6a0
// Address: 0x18010d6a0
// Size: 161 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Removing arg arg_10bh because it doesn't fit into ProtoModel

bool fcn.18010d6a0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    char cVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t in_stack_00000098;
    int64_t in_stack_00000120;
    
    iVar1 = *(int64_t *)0x180781f28;
    iVar3 = *(int64_t *)0x180781f28;
    cVar2 = func_0x000180108070(1);
    if ((cVar2 == '\0') ||
       (cVar2 = fcn.1800fa150(in_stack_00000098, in_stack_00000120), iVar3 = *(int64_t *)0x180781f28, cVar2 == '\0')) {
        if (*(int32_t *)(iVar1 + 0x2218) != (int32_t)arg2) {
            return false;
        }
        if (((*(int32_t *)(iVar3 + 0x21d0) != *(int32_t *)(iVar3 + 0x1fb8)) || (*(int32_t *)(iVar3 + 0x21d0) == 0)) ||
           ((*(int32_t *)(iVar3 + 0x1fb8) == *(int32_t *)(*(int64_t *)(iVar3 + 0x15e0) + 0x10) &&
            (*(char *)(*(int64_t *)(iVar3 + 0x15e0) + 0x10b) != '\0')))) {
            return (int32_t)arg2 == *(int32_t *)(*(int64_t *)(iVar1 + 0x15e0) + 0xc4);
        }
    }
    return true;
}

// ============================================================
// Function: FUN_18010d750
// Address: 0x18010d750
// Size: 130 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_27ch
// WARNING: [rz-ghidra] Detected overlap for variable var_286h
// WARNING: [rz-ghidra] Detected overlap for variable var_284h
// WARNING: [rz-ghidra] Detected overlap for variable var_278h
// WARNING: [rz-ghidra] Detected overlap for variable var_288h
// WARNING: [rz-ghidra] Detected overlap for variable var_287h
// WARNING: [rz-ghidra] Detected overlap for variable arg_74h
// WARNING: [rz-ghidra] Detected overlap for variable arg_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_285h
// WARNING: [rz-ghidra] Detected overlap for variable var_274h
// WARNING: [rz-ghidra] Detected overlap for variable var_24ch
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Removing arg arg_94h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34h

uint64_t fcn.18010d750(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    char cVar3;
    int32_t iVar4;
    uint64_t uVar5;
    uint64_t in_RAX;
    int64_t unaff_RBX;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t in_stack_00000018;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t in_stack_00000048;
    int64_t in_stack_00000058;
    int64_t in_stack_00000060;
    int64_t in_stack_00000068;
    int64_t in_stack_00000070;
    int64_t in_stack_00000078;
    int64_t in_stack_00000080;
    int64_t in_stack_00000090;
    undefined auStack_48 [24];
    undefined8 uStack_30;
    int64_t in_stack_ffffffffffffffd8;
    int64_t in_stack_ffffffffffffffe0;
    int64_t in_stack_ffffffffffffffe8;
    
    iVar2 = *(int64_t *)0x180781f28;
    iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    if (*(char *)(iVar1 + 0x10e) != '\0') {
        return in_RAX & 0xffffffffffffff00;
    }
    if (arg1 == 0) {
        iVar4 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8);
    } else {
        uStack_30 = 0x18010d79a;
        iVar4 = fcn.1800f5a90(arg1, 0, *(undefined4 *)
                                        (*(int64_t *)(iVar1 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar1 + 0x148) * 4));
    }
    uStack_30 = 0x18010d7af;
    cVar3 = fcn.18010d6a0(arg1, (uint64_t)*(uint32_t *)(iVar2 + 0x1fb8));
    if (cVar3 != '\0') {
        uStack_30 = 0x18010d7bc;
        fcn.18010d030(iVar4, 0);
    }
    uVar5 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_48;
    if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) < *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120)) &&
       (*(int32_t *)
         ((int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) * 0x38 +
         *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128)) == iVar4)) {
        cVar3 = fcn.1801019f0(in_stack_ffffffffffffffd8, in_stack_ffffffffffffffe0, in_stack_ffffffffffffffe8, unaff_RBX
                              , unaff_RDI, in_stack_00000018, in_stack_00000028, in_stack_00000030, in_stack_00000048, 
                              in_stack_00000058, in_stack_00000060, in_stack_00000068, in_stack_00000070, 
                              in_stack_00000078, in_stack_00000080, in_stack_00000090);
        if (cVar3 == '\0') {
            fcn.18010d5c0();
        }
        uVar5 = fcn.180459870(uVar5 ^ (uint64_t)auStack_48);
        return uVar5;
    }
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2008) = 0;
    uVar5 = fcn.180459870(uVar5 ^ (uint64_t)auStack_48, 0x141);
    return uVar5;
}

// ============================================================
// Function: FUN_18010d7e0
// Address: 0x18010d7e0
// Size: 796 bytes
// ============================================================
int64_t fcn.18010d7e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                     int64_t arg_38h)
{
    float fVar1;
    float fVar2;
    float fVar3;
    uint32_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int32_t iVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    int64_t var_4h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    
    fVar11 = *(float *)(arg2 + 4);
    fVar9 = *(float *)(arg_28h + 8);
    fVar1 = *(float *)(arg3 + 4);
    fVar2 = *(float *)arg3;
    fVar3 = *(float *)(arg_28h + 4);
    fVar12 = fVar3;
    if ((fVar3 <= fVar11) && (fVar12 = *(float *)(arg_28h + 0xc) - fVar1, fVar11 <= fVar12)) {
        fVar12 = fVar11;
    }
    fVar11 = *(float *)arg_28h;
    fVar14 = *(float *)arg2;
    fVar16 = fVar11;
    if ((fVar11 <= fVar14) && (fVar16 = fVar9 - fVar2, fVar14 <= fVar9 - fVar2)) {
        fVar16 = fVar14;
    }
    if ((int32_t)arg_38h == 1) {
        iVar8 = *(int32_t *)arg4;
        _var_88h = *(undefined (*) [16])0x1806469d0;
        iVar7 = -(uint32_t)(iVar8 != -1);
        do {
            iVar5 = iVar8;
            if ((iVar7 == -1) || (iVar5 = *(int32_t *)((int64_t)&var_88h + (int64_t)iVar7 * 4), iVar5 != iVar8)) {
                if (iVar5 == 3) {
                    fVar12 = *(float *)arg_30h;
                    fVar14 = *(float *)(arg_30h + 0xc);
                } else if (iVar5 == 1) {
                    fVar12 = *(float *)arg_30h;
                    fVar14 = *(float *)(arg_30h + 4) - fVar1;
                } else if (iVar5 == 0) {
                    fVar14 = *(float *)(arg_30h + 0xc);
                    fVar12 = *(float *)(arg_30h + 8) - fVar2;
                } else if (iVar5 == 2) {
                    fVar12 = *(float *)(arg_30h + 8) - fVar2;
                    fVar14 = *(float *)(arg_30h + 4) - fVar1;
                } else {
                    fVar12 = 0.0;
                    fVar14 = 0.0;
                }
                if ((((fVar11 <= fVar12) && (fVar3 <= fVar14)) && (fVar2 + fVar12 <= fVar9)) &&
                   (fVar1 + fVar14 <= *(float *)(arg_28h + 0xc))) {
                    *(float *)arg1 = fVar12;
                    *(float *)(arg1 + 4) = fVar14;
                    *(int32_t *)arg4 = iVar5;
                    return arg1;
                }
            }
            iVar7 = iVar7 + 1;
        } while (iVar7 < 4);
        *(undefined4 *)arg4 = 0xffffffff;
        fVar11 = *(float *)arg2;
    } else {
        if ((arg_38h & 0xfffffffdU) == 0) {
            uVar4 = *(uint32_t *)arg4;
            _var_88h = *(undefined (*) [16])0x180646970;
            iVar8 = -(uint32_t)(uVar4 != 0xffffffff);
            do {
                uVar6 = uVar4;
                if ((iVar8 == -1) || (uVar6 = *(uint32_t *)((int64_t)&var_88h + (int64_t)iVar8 * 4), uVar6 != uVar4)) {
                    fVar14 = fVar3;
                    if (uVar6 == 0) {
                        fVar13 = *(float *)arg_30h;
code_r0x00018010da16:
                        fVar15 = fVar11;
                        if (uVar6 == 2) {
                            fVar10 = *(float *)(arg_30h + 4);
                        } else {
                            fVar10 = *(float *)(arg_28h + 0xc);
                            if (uVar6 == 3) {
                                fVar14 = *(float *)(arg_30h + 0xc);
                            }
                        }
                    } else {
                        fVar13 = fVar9;
                        if (uVar6 != 1) goto code_r0x00018010da16;
                        fVar15 = *(float *)(arg_30h + 8);
                        fVar10 = *(float *)(arg_28h + 0xc);
                    }
                    if (((fVar2 <= fVar13 - fVar15) || (1 < uVar6)) && ((fVar1 <= fVar10 - fVar14 || (1 < uVar6 - 2))))
                    {
                        if (uVar6 == 0) {
                            fVar16 = *(float *)arg_30h - fVar2;
                        } else if (uVar6 == 1) {
                            fVar16 = *(float *)(arg_30h + 8);
                        } else if (uVar6 == 2) {
                            fVar12 = *(float *)(arg_30h + 4) - fVar1;
                        } else if (uVar6 == 3) {
                            fVar12 = *(float *)(arg_30h + 0xc);
                        }
                        if (fVar16 <= fVar11) {
                            fVar16 = fVar11;
                        }
                        *(uint32_t *)arg4 = uVar6;
                        if (fVar12 <= fVar3) {
                            fVar12 = fVar3;
                        }
                        *(float *)arg1 = fVar16;
                        *(float *)(arg1 + 4) = fVar12;
                        return arg1;
                    }
                }
                iVar8 = iVar8 + 1;
            } while (iVar8 < 4);
        }
        *(undefined4 *)arg4 = 0xffffffff;
        fVar11 = *(float *)arg2;
        if ((int32_t)arg_38h == 2) {
            fVar9 = *(float *)(arg2 + 4) + 2.0;
            *(float *)arg1 = fVar11 + 2.0;
            goto code_r0x00018010d990;
        }
    }
    fVar1 = *(float *)(arg3 + 4);
    fVar11 = *(float *)arg3 + fVar11;
    if (*(float *)(arg_28h + 8) <= fVar11) {
        fVar11 = *(float *)(arg_28h + 8);
    }
    fVar11 = fVar11 - *(float *)arg3;
    fVar9 = fVar1 + *(float *)(arg2 + 4);
    if (fVar11 <= *(float *)arg_28h) {
        fVar11 = *(float *)arg_28h;
    }
    if (*(float *)(arg_28h + 0xc) <= fVar9) {
        fVar9 = *(float *)(arg_28h + 0xc);
    }
    *(float *)arg1 = fVar11;
    fVar9 = fVar9 - fVar1;
    if (fVar9 <= *(float *)(arg_28h + 4)) {
        fVar9 = *(float *)(arg_28h + 4);
    }
code_r0x00018010d990:
    *(float *)(arg1 + 4) = fVar9;
    // WARNING: Read-only address (ram,0x000180646970) is written
    // WARNING: Read-only address (ram,0x0001806469d0) is written
    return arg1;
}

// ============================================================
// Function: FUN_18010db00
// Address: 0x18010db00
// Size: 305 bytes
// ============================================================
int64_t fcn.18010db00(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    iVar3 = (int64_t)*(int32_t *)(arg2 + 0x5c);
    if (*(int32_t *)(arg2 + 0x5c) < 0) {
        iVar3 = *(int64_t *)(arg2 + 0x48);
        fVar7 = *(float *)(iVar3 + 8);
        fVar6 = *(float *)(iVar3 + 0xc);
        fVar4 = fVar7 + *(float *)(iVar3 + 0x10);
        fVar5 = *(float *)(iVar3 + 0x14);
        *(float *)arg1 = fVar7;
        *(float *)(arg1 + 4) = fVar6;
        *(float *)(arg1 + 8) = fVar4;
        *(float *)(arg1 + 0xc) = fVar6 + fVar5;
    } else {
        iVar1 = *(int64_t *)(iVar2 + 0xd68);
        *(undefined8 *)arg1 = *(undefined8 *)(iVar1 + 0x10 + iVar3 * 0x30);
        fVar6 = *(float *)(iVar1 + 0x1c + iVar3 * 0x30);
        fVar4 = *(float *)(iVar1 + 0x10 + iVar3 * 0x30) + *(float *)(iVar1 + 0x18 + iVar3 * 0x30);
        fVar5 = *(float *)(iVar1 + 0x14 + iVar3 * 0x30);
        fVar7 = *(float *)arg1;
        *(float *)(arg1 + 8) = fVar4;
        *(float *)(arg1 + 0xc) = fVar6 + fVar5;
    }
    fVar6 = *(float *)(iVar2 + 0xeb4);
    fVar5 = *(float *)(iVar2 + 0xeb0);
    if (*(float *)(arg1 + 0xc) - *(float *)(arg1 + 4) <= fVar6 + fVar6) {
        fVar6 = 0.0;
    } else {
        fVar6 = (float)((uint32_t)fVar6 ^ 0x80000000);
    }
    if (fVar4 - fVar7 <= fVar5 + fVar5) {
        fVar5 = 0.0;
    } else {
        fVar5 = (float)((uint32_t)fVar5 ^ 0x80000000);
    }
    *(float *)(arg1 + 4) = *(float *)(arg1 + 4) - fVar6;
    *(float *)(arg1 + 0xc) = *(float *)(arg1 + 0xc) + fVar6;
    *(float *)arg1 = fVar7 - fVar5;
    *(float *)(arg1 + 8) = fVar4 + fVar5;
    return arg1;
}

// ============================================================
// Function: FUN_18010dc40
// Address: 0x18010dc40
// Size: 279 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18010dc40(int64_t arg1, int64_t arg2)
{
    float fVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    float fVar6;
    float fVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    float var_20h;
    float var_1ch;
    
    iVar4 = *(int64_t *)0x180781f28;
    iVar5 = arg2;
    fcn.18010db00((int64_t)&var_28h, arg2);
    uVar2 = *(uint32_t *)(arg2 + 0x14);
    if ((uVar2 >> 0x1c & 1) == 0) {
        if ((uVar2 >> 0x1a & 1) == 0) {
            if ((uVar2 >> 0x19 & 1) == 0) {
                *(undefined8 *)arg1 = *(undefined8 *)(iVar5 + 0x60);
                return arg1;
            }
            fVar1 = *(float *)(iVar4 + 0xec0);
            func_0x00018010ef90(&var_10h, 0x2000000);
            if (((*(int32_t *)(iVar4 + 0x130) == 1) &&
                ((((*(char *)(iVar4 + 0x21cc) == '\0' || (*(char *)(iVar4 + 0x21cd) == '\0')) ||
                  (*(int64_t *)(iVar4 + 0x21d8) == 0)) &&
                 ((fVar7 = (fVar1 * 0.0 + (float)var_10h) - *(float *)(iVar5 + 0x68) * 0.5, (float)var_28h <= fVar7 &&
                  (fVar6 = (var_10h._4_4_ - fVar1 * 20.0) - *(float *)(iVar5 + 0x6c), var_28h._4_4_ <= fVar6)))))) &&
               ((fVar7 + *(float *)(iVar5 + 0x68) <= var_20h && (fVar6 + *(float *)(iVar5 + 0x6c) <= var_1ch)))) {
                *(float *)arg1 = fVar7;
                *(float *)(arg1 + 4) = fVar6;
                return arg1;
            }
            if (((*(char *)(iVar4 + 0x21cc) == '\0') || (*(char *)(iVar4 + 0x21cd) == '\0')) ||
               (*(char *)(iVar4 + 0x7a) != '\0')) {
                var_30h._0_4_ = fVar1 * 24.0 + (float)var_10h;
                var_30h._4_4_ = fVar1 * 24.0 + var_10h._4_4_;
            } else {
                var_30h._4_4_ = var_10h._4_4_ + 8.0;
                var_30h._0_4_ = (float)var_10h + 16.0;
            }
            var_38h._0_4_ = (float)var_10h - 16.0;
            var_38h._4_4_ = var_10h._4_4_ - 8.0;
            var_10h._0_4_ = fVar1 * 16.0 + (float)var_10h;
            var_10h._4_4_ = fVar1 * 10.0 + var_10h._4_4_;
            fcn.18010d7e0(arg1, (int64_t)&var_10h, iVar5 + 0x68, iVar5 + 0x124, (int64_t)&var_28h, (int64_t)&var_38h, 
                          CONCAT44(var_48h._4_4_, 2));
            return arg1;
        }
        var_38h._0_4_ = *(float *)(iVar5 + 0x60);
        var_38h._4_4_ = *(float *)(iVar5 + 100);
        var_30h._0_4_ = (float)var_38h;
        var_30h._4_4_ = var_38h._4_4_;
    } else {
        iVar3 = *(int64_t *)(iVar5 + 0x408);
        if (*(char *)(iVar3 + 0x1bb) == '\0') {
            var_38h._0_4_ = *(float *)(iVar3 + 0x60) + *(float *)(iVar4 + 0xdf4);
            var_38h._4_4_ = -3.402823e+38;
            var_30h._4_4_ = 3.402823e+38;
            var_30h._0_4_ =
                 ((*(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68)) - *(float *)(iVar4 + 0xdf4)) -
                 *(float *)(iVar3 + 0xfc);
        } else {
            var_38h._4_4_ = *(float *)(iVar3 + 700);
            var_30h._4_4_ = *(float *)(iVar3 + 0x2c4);
            var_38h._0_4_ = -3.402823e+38;
            var_30h._0_4_ = 3.402823e+38;
        }
    }
    fcn.18010d7e0(arg1, iVar5 + 0x60, iVar5 + 0x68, iVar5 + 0x124, (int64_t)&var_28h, (int64_t)&var_38h, 
                  (uint64_t)var_48h._4_4_ << 0x20);
    return arg1;
}

// ============================================================
// Function: FUN_18010dd57
// Address: 0x18010dd57
// Size: 202 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18010dc40(int64_t arg1, int64_t arg2)
{
    float fVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    float fVar6;
    float fVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    float var_20h;
    float var_1ch;
    
    iVar4 = *(int64_t *)0x180781f28;
    iVar5 = arg2;
    fcn.18010db00((int64_t)&var_28h, arg2);
    uVar2 = *(uint32_t *)(arg2 + 0x14);
    if ((uVar2 >> 0x1c & 1) == 0) {
        if ((uVar2 >> 0x1a & 1) == 0) {
            if ((uVar2 >> 0x19 & 1) == 0) {
                *(undefined8 *)arg1 = *(undefined8 *)(iVar5 + 0x60);
                return arg1;
            }
            fVar1 = *(float *)(iVar4 + 0xec0);
            func_0x00018010ef90(&var_10h, 0x2000000);
            if (((*(int32_t *)(iVar4 + 0x130) == 1) &&
                ((((*(char *)(iVar4 + 0x21cc) == '\0' || (*(char *)(iVar4 + 0x21cd) == '\0')) ||
                  (*(int64_t *)(iVar4 + 0x21d8) == 0)) &&
                 ((fVar7 = (fVar1 * 0.0 + (float)var_10h) - *(float *)(iVar5 + 0x68) * 0.5, (float)var_28h <= fVar7 &&
                  (fVar6 = (var_10h._4_4_ - fVar1 * 20.0) - *(float *)(iVar5 + 0x6c), var_28h._4_4_ <= fVar6)))))) &&
               ((fVar7 + *(float *)(iVar5 + 0x68) <= var_20h && (fVar6 + *(float *)(iVar5 + 0x6c) <= var_1ch)))) {
                *(float *)arg1 = fVar7;
                *(float *)(arg1 + 4) = fVar6;
                return arg1;
            }
            if (((*(char *)(iVar4 + 0x21cc) == '\0') || (*(char *)(iVar4 + 0x21cd) == '\0')) ||
               (*(char *)(iVar4 + 0x7a) != '\0')) {
                var_30h._0_4_ = fVar1 * 24.0 + (float)var_10h;
                var_30h._4_4_ = fVar1 * 24.0 + var_10h._4_4_;
            } else {
                var_30h._4_4_ = var_10h._4_4_ + 8.0;
                var_30h._0_4_ = (float)var_10h + 16.0;
            }
            var_38h._0_4_ = (float)var_10h - 16.0;
            var_38h._4_4_ = var_10h._4_4_ - 8.0;
            var_10h._0_4_ = fVar1 * 16.0 + (float)var_10h;
            var_10h._4_4_ = fVar1 * 10.0 + var_10h._4_4_;
            fcn.18010d7e0(arg1, (int64_t)&var_10h, iVar5 + 0x68, iVar5 + 0x124, (int64_t)&var_28h, (int64_t)&var_38h, 
                          CONCAT44(var_48h._4_4_, 2));
            return arg1;
        }
        var_38h._0_4_ = *(float *)(iVar5 + 0x60);
        var_38h._4_4_ = *(float *)(iVar5 + 100);
        var_30h._0_4_ = (float)var_38h;
        var_30h._4_4_ = var_38h._4_4_;
    } else {
        iVar3 = *(int64_t *)(iVar5 + 0x408);
        if (*(char *)(iVar3 + 0x1bb) == '\0') {
            var_38h._0_4_ = *(float *)(iVar3 + 0x60) + *(float *)(iVar4 + 0xdf4);
            var_38h._4_4_ = -3.402823e+38;
            var_30h._4_4_ = 3.402823e+38;
            var_30h._0_4_ =
                 ((*(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68)) - *(float *)(iVar4 + 0xdf4)) -
                 *(float *)(iVar3 + 0xfc);
        } else {
            var_38h._4_4_ = *(float *)(iVar3 + 700);
            var_30h._4_4_ = *(float *)(iVar3 + 0x2c4);
            var_38h._0_4_ = -3.402823e+38;
            var_30h._0_4_ = 3.402823e+38;
        }
    }
    fcn.18010d7e0(arg1, iVar5 + 0x60, iVar5 + 0x68, iVar5 + 0x124, (int64_t)&var_28h, (int64_t)&var_38h, 
                  (uint64_t)var_48h._4_4_ << 0x20);
    return arg1;
}

// ============================================================
// Function: FUN_18010de21
// Address: 0x18010de21
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18010dc40(int64_t arg1, int64_t arg2)
{
    float fVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    float fVar6;
    float fVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    float var_20h;
    float var_1ch;
    
    iVar4 = *(int64_t *)0x180781f28;
    iVar5 = arg2;
    fcn.18010db00((int64_t)&var_28h, arg2);
    uVar2 = *(uint32_t *)(arg2 + 0x14);
    if ((uVar2 >> 0x1c & 1) == 0) {
        if ((uVar2 >> 0x1a & 1) == 0) {
            if ((uVar2 >> 0x19 & 1) == 0) {
                *(undefined8 *)arg1 = *(undefined8 *)(iVar5 + 0x60);
                return arg1;
            }
            fVar1 = *(float *)(iVar4 + 0xec0);
            func_0x00018010ef90(&var_10h, 0x2000000);
            if (((*(int32_t *)(iVar4 + 0x130) == 1) &&
                ((((*(char *)(iVar4 + 0x21cc) == '\0' || (*(char *)(iVar4 + 0x21cd) == '\0')) ||
                  (*(int64_t *)(iVar4 + 0x21d8) == 0)) &&
                 ((fVar7 = (fVar1 * 0.0 + (float)var_10h) - *(float *)(iVar5 + 0x68) * 0.5, (float)var_28h <= fVar7 &&
                  (fVar6 = (var_10h._4_4_ - fVar1 * 20.0) - *(float *)(iVar5 + 0x6c), var_28h._4_4_ <= fVar6)))))) &&
               ((fVar7 + *(float *)(iVar5 + 0x68) <= var_20h && (fVar6 + *(float *)(iVar5 + 0x6c) <= var_1ch)))) {
                *(float *)arg1 = fVar7;
                *(float *)(arg1 + 4) = fVar6;
                return arg1;
            }
            if (((*(char *)(iVar4 + 0x21cc) == '\0') || (*(char *)(iVar4 + 0x21cd) == '\0')) ||
               (*(char *)(iVar4 + 0x7a) != '\0')) {
                var_30h._0_4_ = fVar1 * 24.0 + (float)var_10h;
                var_30h._4_4_ = fVar1 * 24.0 + var_10h._4_4_;
            } else {
                var_30h._4_4_ = var_10h._4_4_ + 8.0;
                var_30h._0_4_ = (float)var_10h + 16.0;
            }
            var_38h._0_4_ = (float)var_10h - 16.0;
            var_38h._4_4_ = var_10h._4_4_ - 8.0;
            var_10h._0_4_ = fVar1 * 16.0 + (float)var_10h;
            var_10h._4_4_ = fVar1 * 10.0 + var_10h._4_4_;
            fcn.18010d7e0(arg1, (int64_t)&var_10h, iVar5 + 0x68, iVar5 + 0x124, (int64_t)&var_28h, (int64_t)&var_38h, 
                          CONCAT44(var_48h._4_4_, 2));
            return arg1;
        }
        var_38h._0_4_ = *(float *)(iVar5 + 0x60);
        var_38h._4_4_ = *(float *)(iVar5 + 100);
        var_30h._0_4_ = (float)var_38h;
        var_30h._4_4_ = var_38h._4_4_;
    } else {
        iVar3 = *(int64_t *)(iVar5 + 0x408);
        if (*(char *)(iVar3 + 0x1bb) == '\0') {
            var_38h._0_4_ = *(float *)(iVar3 + 0x60) + *(float *)(iVar4 + 0xdf4);
            var_38h._4_4_ = -3.402823e+38;
            var_30h._4_4_ = 3.402823e+38;
            var_30h._0_4_ =
                 ((*(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68)) - *(float *)(iVar4 + 0xdf4)) -
                 *(float *)(iVar3 + 0xfc);
        } else {
            var_38h._4_4_ = *(float *)(iVar3 + 700);
            var_30h._4_4_ = *(float *)(iVar3 + 0x2c4);
            var_38h._0_4_ = -3.402823e+38;
            var_30h._0_4_ = 3.402823e+38;
        }
    }
    fcn.18010d7e0(arg1, iVar5 + 0x60, iVar5 + 0x68, iVar5 + 0x124, (int64_t)&var_28h, (int64_t)&var_38h, 
                  (uint64_t)var_48h._4_4_ << 0x20);
    return arg1;
}

// ============================================================
// Function: FUN_18010de36
// Address: 0x18010de36
// Size: 218 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18010dc40(int64_t arg1, int64_t arg2)
{
    float fVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    float fVar6;
    float fVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    float var_20h;
    float var_1ch;
    
    iVar4 = *(int64_t *)0x180781f28;
    iVar5 = arg2;
    fcn.18010db00((int64_t)&var_28h, arg2);
    uVar2 = *(uint32_t *)(arg2 + 0x14);
    if ((uVar2 >> 0x1c & 1) == 0) {
        if ((uVar2 >> 0x1a & 1) == 0) {
            if ((uVar2 >> 0x19 & 1) == 0) {
                *(undefined8 *)arg1 = *(undefined8 *)(iVar5 + 0x60);
                return arg1;
            }
            fVar1 = *(float *)(iVar4 + 0xec0);
            func_0x00018010ef90(&var_10h, 0x2000000);
            if (((*(int32_t *)(iVar4 + 0x130) == 1) &&
                ((((*(char *)(iVar4 + 0x21cc) == '\0' || (*(char *)(iVar4 + 0x21cd) == '\0')) ||
                  (*(int64_t *)(iVar4 + 0x21d8) == 0)) &&
                 ((fVar7 = (fVar1 * 0.0 + (float)var_10h) - *(float *)(iVar5 + 0x68) * 0.5, (float)var_28h <= fVar7 &&
                  (fVar6 = (var_10h._4_4_ - fVar1 * 20.0) - *(float *)(iVar5 + 0x6c), var_28h._4_4_ <= fVar6)))))) &&
               ((fVar7 + *(float *)(iVar5 + 0x68) <= var_20h && (fVar6 + *(float *)(iVar5 + 0x6c) <= var_1ch)))) {
                *(float *)arg1 = fVar7;
                *(float *)(arg1 + 4) = fVar6;
                return arg1;
            }
            if (((*(char *)(iVar4 + 0x21cc) == '\0') || (*(char *)(iVar4 + 0x21cd) == '\0')) ||
               (*(char *)(iVar4 + 0x7a) != '\0')) {
                var_30h._0_4_ = fVar1 * 24.0 + (float)var_10h;
                var_30h._4_4_ = fVar1 * 24.0 + var_10h._4_4_;
            } else {
                var_30h._4_4_ = var_10h._4_4_ + 8.0;
                var_30h._0_4_ = (float)var_10h + 16.0;
            }
            var_38h._0_4_ = (float)var_10h - 16.0;
            var_38h._4_4_ = var_10h._4_4_ - 8.0;
            var_10h._0_4_ = fVar1 * 16.0 + (float)var_10h;
            var_10h._4_4_ = fVar1 * 10.0 + var_10h._4_4_;
            fcn.18010d7e0(arg1, (int64_t)&var_10h, iVar5 + 0x68, iVar5 + 0x124, (int64_t)&var_28h, (int64_t)&var_38h, 
                          CONCAT44(var_48h._4_4_, 2));
            return arg1;
        }
        var_38h._0_4_ = *(float *)(iVar5 + 0x60);
        var_38h._4_4_ = *(float *)(iVar5 + 100);
        var_30h._0_4_ = (float)var_38h;
        var_30h._4_4_ = var_38h._4_4_;
    } else {
        iVar3 = *(int64_t *)(iVar5 + 0x408);
        if (*(char *)(iVar3 + 0x1bb) == '\0') {
            var_38h._0_4_ = *(float *)(iVar3 + 0x60) + *(float *)(iVar4 + 0xdf4);
            var_38h._4_4_ = -3.402823e+38;
            var_30h._4_4_ = 3.402823e+38;
            var_30h._0_4_ =
                 ((*(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68)) - *(float *)(iVar4 + 0xdf4)) -
                 *(float *)(iVar3 + 0xfc);
        } else {
            var_38h._4_4_ = *(float *)(iVar3 + 700);
            var_30h._4_4_ = *(float *)(iVar3 + 0x2c4);
            var_38h._0_4_ = -3.402823e+38;
            var_30h._0_4_ = 3.402823e+38;
        }
    }
    fcn.18010d7e0(arg1, iVar5 + 0x60, iVar5 + 0x68, iVar5 + 0x124, (int64_t)&var_28h, (int64_t)&var_38h, 
                  (uint64_t)var_48h._4_4_ << 0x20);
    return arg1;
}

// ============================================================
// Function: FUN_18010df10
// Address: 0x18010df10
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t fcn.18010dc40(int64_t arg1, int64_t arg2)
{
    float fVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    float fVar6;
    float fVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    float var_20h;
    float var_1ch;
    
    iVar4 = *(int64_t *)0x180781f28;
    iVar5 = arg2;
    fcn.18010db00((int64_t)&var_28h, arg2);
    uVar2 = *(uint32_t *)(arg2 + 0x14);
    if ((uVar2 >> 0x1c & 1) == 0) {
        if ((uVar2 >> 0x1a & 1) == 0) {
            if ((uVar2 >> 0x19 & 1) == 0) {
                *(undefined8 *)arg1 = *(undefined8 *)(iVar5 + 0x60);
                return arg1;
            }
            fVar1 = *(float *)(iVar4 + 0xec0);
            func_0x00018010ef90(&var_10h, 0x2000000);
            if (((*(int32_t *)(iVar4 + 0x130) == 1) &&
                ((((*(char *)(iVar4 + 0x21cc) == '\0' || (*(char *)(iVar4 + 0x21cd) == '\0')) ||
                  (*(int64_t *)(iVar4 + 0x21d8) == 0)) &&
                 ((fVar7 = (fVar1 * 0.0 + (float)var_10h) - *(float *)(iVar5 + 0x68) * 0.5, (float)var_28h <= fVar7 &&
                  (fVar6 = (var_10h._4_4_ - fVar1 * 20.0) - *(float *)(iVar5 + 0x6c), var_28h._4_4_ <= fVar6)))))) &&
               ((fVar7 + *(float *)(iVar5 + 0x68) <= var_20h && (fVar6 + *(float *)(iVar5 + 0x6c) <= var_1ch)))) {
                *(float *)arg1 = fVar7;
                *(float *)(arg1 + 4) = fVar6;
                return arg1;
            }
            if (((*(char *)(iVar4 + 0x21cc) == '\0') || (*(char *)(iVar4 + 0x21cd) == '\0')) ||
               (*(char *)(iVar4 + 0x7a) != '\0')) {
                var_30h._0_4_ = fVar1 * 24.0 + (float)var_10h;
                var_30h._4_4_ = fVar1 * 24.0 + var_10h._4_4_;
            } else {
                var_30h._4_4_ = var_10h._4_4_ + 8.0;
                var_30h._0_4_ = (float)var_10h + 16.0;
            }
            var_38h._0_4_ = (float)var_10h - 16.0;
            var_38h._4_4_ = var_10h._4_4_ - 8.0;
            var_10h._0_4_ = fVar1 * 16.0 + (float)var_10h;
            var_10h._4_4_ = fVar1 * 10.0 + var_10h._4_4_;
            fcn.18010d7e0(arg1, (int64_t)&var_10h, iVar5 + 0x68, iVar5 + 0x124, (int64_t)&var_28h, (int64_t)&var_38h, 
                          CONCAT44(var_48h._4_4_, 2));
            return arg1;
        }
        var_38h._0_4_ = *(float *)(iVar5 + 0x60);
        var_38h._4_4_ = *(float *)(iVar5 + 100);
        var_30h._0_4_ = (float)var_38h;
        var_30h._4_4_ = var_38h._4_4_;
    } else {
        iVar3 = *(int64_t *)(iVar5 + 0x408);
        if (*(char *)(iVar3 + 0x1bb) == '\0') {
            var_38h._0_4_ = *(float *)(iVar3 + 0x60) + *(float *)(iVar4 + 0xdf4);
            var_38h._4_4_ = -3.402823e+38;
            var_30h._4_4_ = 3.402823e+38;
            var_30h._0_4_ =
                 ((*(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68)) - *(float *)(iVar4 + 0xdf4)) -
                 *(float *)(iVar3 + 0xfc);
        } else {
            var_38h._4_4_ = *(float *)(iVar3 + 700);
            var_30h._4_4_ = *(float *)(iVar3 + 0x2c4);
            var_38h._0_4_ = -3.402823e+38;
            var_30h._0_4_ = 3.402823e+38;
        }
    }
    fcn.18010d7e0(arg1, iVar5 + 0x60, iVar5 + 0x68, iVar5 + 0x124, (int64_t)&var_28h, (int64_t)&var_38h, 
                  (uint64_t)var_48h._4_4_ << 0x20);
    return arg1;
}

// ============================================================
// Function: FUN_18010df20
// Address: 0x18010df20
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18010df20(int64_t arg1)
{
    int16_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    uint64_t uVar6;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar2 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1590);
    if (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x1598) + -8 + (int64_t)iVar2 * 8) != arg1) {
        uVar5 = (uint64_t)*(int16_t *)(arg1 + 0x120);
        uVar4 = (uint32_t)*(int16_t *)(arg1 + 0x120);
        uVar6 = uVar5;
        while ((int32_t)uVar4 < iVar2 + -1) {
            uVar5 = uVar5 + 1;
            uVar4 = (int32_t)uVar6 + 1;
            uVar6 = (uint64_t)uVar4;
            *(undefined8 *)(*(int64_t *)(iVar3 + 0x1598) + -8 + uVar5 * 8) =
                 *(undefined8 *)(*(int64_t *)(iVar3 + 0x1598) + uVar5 * 8);
            piVar1 = (int16_t *)(*(int64_t *)(*(int64_t *)(iVar3 + 0x1598) + -8 + uVar5 * 8) + 0x120);
            *piVar1 = *piVar1 + -1;
        }
        *(int64_t *)(*(int64_t *)(iVar3 + 0x1598) + -8 + (int64_t)iVar2 * 8) = arg1;
        *(int16_t *)(arg1 + 0x120) = (int16_t)(iVar2 + -1);
    }
    return;
}

