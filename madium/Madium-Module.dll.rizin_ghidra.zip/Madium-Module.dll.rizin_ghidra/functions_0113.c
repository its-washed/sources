// Chunk 113 - 50 functions

// ============================================================
// Function: FUN_180185710
// Address: 0x180185710
// Size: 432 bytes
// ============================================================
int64_t fcn.180185710(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    char cVar9;
    int32_t iVar10;
    int64_t *piVar11;
    undefined8 uVar12;
    int64_t iVar13;
    undefined8 *puVar14;
    undefined4 uVar15;
    uint64_t uVar16;
    undefined8 *puVar17;
    undefined8 *puVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    
    puVar1 = *(undefined8 **)arg1;
    puVar18 = (undefined8 *)puVar1[1];
    uVar15 = 0;
    puVar17 = puVar1;
    if (*(char *)((int64_t)puVar18 + 0x19) == '\0') {
        uVar2 = *(uint64_t *)(arg3 + 0x18);
        uVar3 = *(uint64_t *)(arg3 + 0x10);
        puVar14 = puVar18;
        do {
            puVar18 = puVar14;
            iVar13 = arg3;
            if (0xf < uVar2) {
                iVar13 = *(int64_t *)arg3;
            }
            if ((uint64_t)puVar18[7] < 0x10) {
                puVar14 = puVar18 + 4;
            } else {
                puVar14 = (undefined8 *)puVar18[4];
            }
            uVar4 = puVar18[6];
            uVar16 = uVar4;
            if (uVar3 < uVar4) {
                uVar16 = uVar3;
            }
            iVar10 = func_0x000180497f30(puVar14, iVar13, uVar16);
            if (iVar10 == 0) {
                if (uVar3 <= uVar4) goto code_r0x00018018579b;
code_r0x0001801857ed:
                uVar15 = 0;
                puVar14 = (undefined8 *)puVar18[2];
            } else {
                if (iVar10 < 0) goto code_r0x0001801857ed;
code_r0x00018018579b:
                uVar15 = 1;
                puVar14 = (undefined8 *)*puVar18;
                puVar17 = puVar18;
            }
        } while (*(char *)((int64_t)puVar14 + 0x19) == '\0');
    }
    if ((*(char *)((int64_t)puVar17 + 0x19) == '\0') &&
       (cVar9 = func_0x000180170420(arg1, arg3, puVar17 + 4), cVar9 == '\0')) {
        *(undefined8 **)arg2 = puVar17;
        *(undefined *)(arg2 + 8) = 0;
    } else {
        if (*(int64_t *)(arg1 + 8) == 0x2aaaaaaaaaaaaaa) {
            func_0x000180013c00();
            pcVar5 = (code *)swi(3);
            iVar13 = (*pcVar5)();
            return iVar13;
        }
        var_50h = 0;
        var_58h = arg1;
        piVar11 = (int64_t *)func_0x000180459890(0x60);
        *(undefined (*) [16])(piVar11 + 4) = ZEXT816(0);
        piVar11[6] = 0;
        piVar11[7] = 0;
        uVar6 = *(undefined4 *)(arg3 + 4);
        uVar7 = *(undefined4 *)(arg3 + 8);
        uVar8 = *(undefined4 *)(arg3 + 0xc);
        *(undefined4 *)(piVar11 + 4) = *(undefined4 *)arg3;
        *(undefined4 *)((int64_t)piVar11 + 0x24) = uVar6;
        *(undefined4 *)(piVar11 + 5) = uVar7;
        *(undefined4 *)((int64_t)piVar11 + 0x2c) = uVar8;
        uVar6 = *(undefined4 *)(arg3 + 0x14);
        uVar7 = *(undefined4 *)(arg3 + 0x18);
        uVar8 = *(undefined4 *)(arg3 + 0x1c);
        *(undefined4 *)(piVar11 + 6) = *(undefined4 *)(arg3 + 0x10);
        *(undefined4 *)((int64_t)piVar11 + 0x34) = uVar6;
        *(undefined4 *)(piVar11 + 7) = uVar7;
        *(undefined4 *)((int64_t)piVar11 + 0x3c) = uVar8;
        *(undefined8 *)(arg3 + 0x10) = 0;
        *(undefined8 *)(arg3 + 0x18) = 0xf;
        *(undefined *)arg3 = 0;
        *(undefined (*) [16])(piVar11 + 8) = ZEXT816(0);
        piVar11[10] = 0;
        piVar11[0xb] = 0xf;
        *(undefined *)(piVar11 + 8) = 0;
        *piVar11 = (int64_t)puVar1;
        piVar11[1] = (int64_t)puVar1;
        piVar11[2] = (int64_t)puVar1;
        *(undefined2 *)(piVar11 + 3) = 0;
        var_50h = CONCAT44(var_50h._4_4_, uVar15);
        var_58h = (int64_t)puVar18;
        uVar12 = func_0x0001800156d0(arg1, &var_58h, piVar11);
        *(undefined8 *)arg2 = uVar12;
        *(undefined *)(arg2 + 8) = 1;
    }
    return arg2;
}

// ============================================================
// Function: FUN_1801858c0
// Address: 0x1801858c0
// Size: 224 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h

int64_t fcn.1801858c0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    uint64_t *puVar2;
    int64_t iVar3;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    var_18h = arg3;
    iStackX_20 = arg4;
    puVar2 = (uint64_t *)func_0x0001800102c0();
    iVar1 = func_0x000180467554(*puVar2 | 2, 0, 0, arg2, 0, &var_18h, 0);
    if (iVar1 < 0) {
        iVar1 = -1;
    }
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    func_0x00018000b240(arg1, (int64_t)(iVar1 + 1));
    func_0x00018000b3b0(arg1, (int64_t)iVar1, 0);
    iVar3 = arg1;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar3 = *(int64_t *)arg1;
    }
    func_0x000180467554(*puVar2 | 2, iVar3, (int64_t)(iVar1 + 1), arg2, 0, &var_18h, 1);
    return arg1;
}

// ============================================================
// Function: FUN_1801859a0
// Address: 0x1801859a0
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801859a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                      undefined8 placeholder_5, int64_t arg_38h)
{
    code *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    if (*(uint64_t *)(arg1 + 0x10) < (uint64_t)arg2) {
        func_0x00018000f930();
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    iVar4 = arg4;
    if (0xf < *(uint64_t *)(arg4 + 0x18)) {
        iVar4 = *(int64_t *)arg4;
    }
    uVar2 = *(uint64_t *)(arg1 + 0x10) - arg2;
    if (uVar2 < (uint64_t)arg3) {
        arg3 = uVar2;
    }
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    uVar2 = *(uint64_t *)(arg4 + 0x10);
    uVar3 = arg3;
    if (uVar2 < (uint64_t)arg3) {
        uVar3 = uVar2;
    }
    uVar3 = func_0x000180497f30(arg1 + arg2, iVar4, uVar3);
    if ((int32_t)uVar3 == 0) {
        if ((uint64_t)arg3 < uVar2) {
            return 0xffffffff;
        }
        uVar3 = (uint64_t)(uVar2 < (uint64_t)arg3);
    }
    return uVar3;
}

// ============================================================
// Function: FUN_1801859b7
// Address: 0x1801859b7
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801859a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                      undefined8 placeholder_5, int64_t arg_38h)
{
    code *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    if (*(uint64_t *)(arg1 + 0x10) < (uint64_t)arg2) {
        func_0x00018000f930();
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    iVar4 = arg4;
    if (0xf < *(uint64_t *)(arg4 + 0x18)) {
        iVar4 = *(int64_t *)arg4;
    }
    uVar2 = *(uint64_t *)(arg1 + 0x10) - arg2;
    if (uVar2 < (uint64_t)arg3) {
        arg3 = uVar2;
    }
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    uVar2 = *(uint64_t *)(arg4 + 0x10);
    uVar3 = arg3;
    if (uVar2 < (uint64_t)arg3) {
        uVar3 = uVar2;
    }
    uVar3 = func_0x000180497f30(arg1 + arg2, iVar4, uVar3);
    if ((int32_t)uVar3 == 0) {
        if ((uint64_t)arg3 < uVar2) {
            return 0xffffffff;
        }
        uVar3 = (uint64_t)(uVar2 < (uint64_t)arg3);
    }
    return uVar3;
}

// ============================================================
// Function: FUN_180185a0c
// Address: 0x180185a0c
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801859a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                      undefined8 placeholder_5, int64_t arg_38h)
{
    code *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    if (*(uint64_t *)(arg1 + 0x10) < (uint64_t)arg2) {
        func_0x00018000f930();
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    iVar4 = arg4;
    if (0xf < *(uint64_t *)(arg4 + 0x18)) {
        iVar4 = *(int64_t *)arg4;
    }
    uVar2 = *(uint64_t *)(arg1 + 0x10) - arg2;
    if (uVar2 < (uint64_t)arg3) {
        arg3 = uVar2;
    }
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    uVar2 = *(uint64_t *)(arg4 + 0x10);
    uVar3 = arg3;
    if (uVar2 < (uint64_t)arg3) {
        uVar3 = uVar2;
    }
    uVar3 = func_0x000180497f30(arg1 + arg2, iVar4, uVar3);
    if ((int32_t)uVar3 == 0) {
        if ((uint64_t)arg3 < uVar2) {
            return 0xffffffff;
        }
        uVar3 = (uint64_t)(uVar2 < (uint64_t)arg3);
    }
    return uVar3;
}

// ============================================================
// Function: FUN_180185a1f
// Address: 0x180185a1f
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801859a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                      undefined8 placeholder_5, int64_t arg_38h)
{
    code *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    if (*(uint64_t *)(arg1 + 0x10) < (uint64_t)arg2) {
        func_0x00018000f930();
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    iVar4 = arg4;
    if (0xf < *(uint64_t *)(arg4 + 0x18)) {
        iVar4 = *(int64_t *)arg4;
    }
    uVar2 = *(uint64_t *)(arg1 + 0x10) - arg2;
    if (uVar2 < (uint64_t)arg3) {
        arg3 = uVar2;
    }
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    uVar2 = *(uint64_t *)(arg4 + 0x10);
    uVar3 = arg3;
    if (uVar2 < (uint64_t)arg3) {
        uVar3 = uVar2;
    }
    uVar3 = func_0x000180497f30(arg1 + arg2, iVar4, uVar3);
    if ((int32_t)uVar3 == 0) {
        if ((uint64_t)arg3 < uVar2) {
            return 0xffffffff;
        }
        uVar3 = (uint64_t)(uVar2 < (uint64_t)arg3);
    }
    return uVar3;
}

// ============================================================
// Function: FUN_180185a30
// Address: 0x180185a30
// Size: 129 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180185a30(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    func_0x00018000b4d0();
    iVar1 = func_0x000180014120(arg1, arg3, 0);
    if (iVar1 != -1) {
        iVar2 = arg4;
        if (0xf < *(uint64_t *)(arg4 + 0x18)) {
            iVar2 = *(int64_t *)arg4;
        }
        func_0x000180185560(arg1, iVar1, *(undefined8 *)(arg3 + 0x10), iVar2, *(undefined8 *)(arg4 + 0x10));
    }
    return arg1;
}

// ============================================================
// Function: FUN_180185ac0
// Address: 0x180185ac0
// Size: 41 bytes
// ============================================================
bool fcn.180185ac0(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    undefined8 unaff_retaddr;
    int64_t in_stack_00000008;
    undefined8 in_stack_fffffffffffffff8;
    
    if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg2 + 0x10)) {
        return false;
    }
    iVar1 = fcn.1801859a0(arg1, 0, *(uint64_t *)(arg2 + 0x10), arg2, in_stack_fffffffffffffff8, unaff_retaddr, 
                          in_stack_00000008);
    return iVar1 == 0;
}

// ============================================================
// Function: FUN_180185af0
// Address: 0x180185af0
// Size: 91 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180185af0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t arg2_00;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = fcn.18045b928(arg2, 0x3a);
    arg2_00 = 0x18063e190;
    if (iVar1 != 0) {
        arg2_00 = 0x1804a7b38;
    }
    fcn.1801858c0(arg1, arg2_00, arg2, arg3 & 0xffffffff);
    return arg1;
}

// ============================================================
// Function: FUN_180185b50
// Address: 0x180185b50
// Size: 181 bytes
// ============================================================
int64_t fcn.180185b50(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    
    uVar2 = fcn.18016ec60(arg2, arg3, 0);
    if (uVar2 == 0xffffffffffffffff) {
        *(undefined (*) [16])arg1 = ZEXT816(0);
        *(undefined8 *)(arg1 + 0x10) = 0;
        *(undefined8 *)(arg1 + 0x18) = 0xf;
        *(undefined *)arg1 = 0;
        return arg1;
    }
    iVar3 = fcn.18016ed60(arg2, arg3, 0xffffffffffffffff);
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    if (uVar2 <= *(uint64_t *)(arg2 + 0x10)) {
        uVar4 = *(uint64_t *)(arg2 + 0x10) - uVar2;
        uVar5 = (iVar3 - uVar2) + 1;
        if (uVar4 < uVar5) {
            uVar5 = uVar4;
        }
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            arg2 = *(int64_t *)arg2;
        }
        fcn.180004830(arg1, arg2 + uVar2, uVar5);
        return arg1;
    }
    fcn.18000f930();
    pcVar1 = (code *)swi(3);
    iVar3 = (*pcVar1)();
    return iVar3;
}

// ============================================================
// Function: FUN_180187e30
// Address: 0x180187e30
// Size: 43 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.180187e30(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 0x108) != 0) {
        fcn.18045ff84();
        *(undefined8 *)(arg1 + 0x108) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180187e60
// Address: 0x180187e60
// Size: 43 bytes
// ============================================================
int64_t fcn.180187e60(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1804a8560;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x20);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180187e90
// Address: 0x180187e90
// Size: 777 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_27fh
// WARNING: [rz-ghidra] Detected overlap for variable var_27eh
// WARNING: [rz-ghidra] Detected overlap for variable var_78h

void fcn.180187e90(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h, int64_t arg_30h)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    code *pcVar5;
    undefined auVar6 [16];
    undefined (*pauVar7) [16];
    int64_t iVar8;
    undefined *puVar9;
    undefined (*pauVar10) [16];
    bool bVar11;
    int64_t var_18h;
    undefined auStack_348 [8];
    undefined auStack_340 [24];
    int64_t var_328h;
    int64_t var_320h;
    int64_t var_318h;
    int64_t var_310h;
    int64_t var_308h;
    int64_t var_300h;
    int64_t var_2f8h;
    int64_t var_2f0h;
    int64_t var_2e8h;
    int64_t var_2d8h;
    int64_t var_2d0h;
    int64_t var_2c8h;
    int64_t var_2b8h;
    int64_t var_2a8h;
    int64_t var_298h;
    int64_t var_288h;
    int64_t var_280h;
    int64_t var_7eh;
    undefined8 uStack_70;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    
    puVar9 = auStack_348;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_348;
    pauVar10 = (undefined (*) [16])0x0;
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    var_318h._0_4_ = 1;
    var_2f8h = arg2;
    pauVar7 = (undefined (*) [16])fcn.180459890(0x20);
    if (pauVar7 != (undefined (*) [16])0x0) {
        *pauVar7 = ZEXT816(0);
        *(undefined4 *)(*pauVar7 + 8) = 1;
        *(undefined4 *)(*pauVar7 + 0xc) = 1;
        *(undefined8 *)*pauVar7 = 0x1804a8560;
        *(undefined8 *)pauVar7[1] = 0x1804a8540;
        *(int64_t *)(pauVar7[1] + 8) = arg2;
        pauVar10 = pauVar7;
    }
    var_318h._0_4_ = 3;
    var_2f0h = (int64_t)(pauVar10 + 1);
    if (pauVar10 != (undefined (*) [16])0x0) {
        LOCK();
        *(int32_t *)(*pauVar10 + 8) = *(int32_t *)(*pauVar10 + 8) + 1;
        UNLOCK();
    }
    var_310h = (int64_t)&var_308h;
    _var_308h = ZEXT816(0);
    _var_2c8h = ZEXT816(0);
    _var_2b8h = ZEXT816(0);
    _var_2a8h = ZEXT816(0);
    _var_298h = ZEXT816(0);
    var_2e8h = (int64_t)pauVar10;
    var_2d8h = var_2f0h;
    var_2d0h = (int64_t)pauVar10;
    var_288h = func_0x000180467ba0();
    if (*(undefined **)(var_288h + 8) == (undefined *)0x0) {
        var_280h._0_1_ = 0;
    } else {
        var_280h._0_1_ = **(undefined **)(var_288h + 8);
    }
    if (*(undefined **)var_288h == (undefined *)0x0) {
        var_280h._1_1_ = 0;
    } else {
        var_280h._1_1_ = **(undefined **)var_288h;
    }
    func_0x0001804986e0((int64_t)&var_280h + 2, 0, 0x200);
    unique0x100001a7 = ZEXT816(0);
    var_68h = 0;
    var_60h = 0;
    var_7eh._0_1_ = (char)placeholder_3;
    iVar8 = fcn.180459890(0x210);
    stack0xffffffffffffff88 = iVar8;
    var_68h = 0x200;
    var_60h = 0x20f;
    func_0x0001804986e0(iVar8, (int32_t)(char)placeholder_3, 0x200);
    *(undefined *)(iVar8 + 0x200) = 0;
    var_58h._0_4_ = (undefined4)arg_30h;
    iVar8 = var_300h;
    if (var_300h != 0) {
        LOCK();
        piVar1 = (int32_t *)(var_300h + 8);
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (***(code ***)var_300h)(var_300h);
            LOCK();
            piVar1 = (int32_t *)(iVar8 + 0xc);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*(int64_t *)iVar8 + 8))(iVar8);
            }
        }
    }
    if (pauVar10 != (undefined (*) [16])0x0) {
        LOCK();
        piVar1 = (int32_t *)(*pauVar10 + 8);
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (***(code ***)*pauVar10)(pauVar10);
            LOCK();
            piVar1 = (int32_t *)(*pauVar10 + 0xc);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*(int64_t *)*pauVar10 + 8))(pauVar10);
            }
        }
    }
    var_320h._0_4_ = 0;
    var_328h._0_4_ = (int32_t)arg3;
    bVar11 = (int32_t)var_328h < 0;
    if (bVar11) {
        var_328h._0_4_ = 0;
    }
    func_0x0001801793f0(&var_2d8h, arg1, !bVar11, arg_28h & 0xff);
    if (0xf < (uint64_t)var_60h) {
        iVar8 = stack0xffffffffffffff88;
        puVar9 = auStack_348;
        if ((0xfff < var_60h + 1U) &&
           (iVar8 = *(int64_t *)(stack0xffffffffffffff88 + -8), puVar9 = auStack_348,
           0x1f < (stack0xffffffffffffff88 - iVar8) - 8U)) {
            pcVar5 = (code *)swi(0x29);
            iVar8 = (*pcVar5)(5);
            puVar9 = auStack_340;
        }
        *(undefined8 *)(puVar9 + -8) = 0x180188121;
        fcn.180459c3c(iVar8);
    }
    var_68h = 0;
    var_60h = 0xf;
    auVar6[15] = 0;
    auVar6._0_15_ = stack0xffffffffffffff89;
    stack0xffffffffffffff88 = auVar6 << 8;
    piVar4 = *(int64_t **)(puVar9 + 0x78);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar2 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar2;
        *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            pcVar5 = *(code **)*piVar4;
            *(undefined8 *)(puVar9 + -8) = 0x180188158;
            (*pcVar5)(piVar4);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                pcVar5 = *(code **)(*piVar4 + 8);
                *(undefined8 *)(puVar9 + -8) = 0x18018816b;
                (*pcVar5)(piVar4);
            }
        }
    }
    *(undefined8 *)(puVar9 + -8) = 0x18018817d;
    func_0x000180459870(var_48h ^ (uint64_t)puVar9);
    return;
}

// ============================================================
// Function: FUN_1801881a0
// Address: 0x1801881a0
// Size: 172 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_27fh
// WARNING: [rz-ghidra] Detected overlap for variable var_27eh
// WARNING: [rz-ghidra] Detected overlap for variable var_78h

int64_t fcn.1801881a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    bool bVar1;
    int64_t var_28h;
    int64_t var_20h;
    
    // switch table (10 cases) at 0x180188224
    switch(*(uint8_t *)arg2) {
    case 0:
        goto code_r0x0001801881e8;
    case 1:
        bVar1 = *(int64_t *)(*(int64_t *)(arg2 + 8) + 8) == 0;
        break;
    case 2:
        bVar1 = **(int64_t **)(arg2 + 8) == (*(int64_t **)(arg2 + 8))[1];
        break;
    default:
        goto code_r0x000180188205;
    }
    if (!bVar1) {
code_r0x000180188205:
        fcn.180187e90(arg2, arg1, arg3, 
                      CONCAT71((unkint7)((uint64_t)*(uint32_t *)((uint64_t)*(uint8_t *)arg2 * 4 + 0x180188224) +
                                         0x180000000 >> 8), 0x20), (uint64_t)var_28h._1_7_ << 8, 
                      (uint64_t)var_20h._4_4_ << 0x20);
        return arg1;
    }
code_r0x0001801881e8:
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    return arg1;
}

// ============================================================
// Function: FUN_180188250
// Address: 0x180188250
// Size: 1823 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_274h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.180188250(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char cVar1;
    int64_t **ppiVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int32_t *piVar5;
    char *pcVar6;
    int64_t iVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t iVar10;
    int64_t var_10h;
    undefined auStack_2c8 [32];
    int64_t var_2a8h;
    int64_t var_298h;
    int64_t var_290h;
    int64_t var_288h;
    int64_t var_278h;
    int64_t var_268h;
    int64_t var_258h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_48h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_2c8;
    var_298h._0_4_ = 1;
    var_290h = arg1;
    func_0x0001804986e0(&var_148h, 0, 0x100);
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    var_298h._0_4_ = 1;
    if (*(int64_t *)(arg2 + 8) != 0) {
        ppiVar9 = (int64_t **)**(int64_t ***)arg2;
        cVar1 = *(char *)((int64_t)ppiVar9 + 0x19);
        while (cVar1 == '\0') {
            iVar10 = *(int64_t *)(arg1 + 0x10);
            if (*(uint64_t *)(arg1 + 0x18) - iVar10 < 2) {
                var_2a8h = 2;
                func_0x00018000ee80(arg1, 2, 0, 0x180645d50);
            } else {
                *(int64_t *)(arg1 + 0x10) = iVar10 + 2;
                iVar7 = arg1;
                if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                    iVar7 = *(int64_t *)arg1;
                }
                *(undefined2 *)(iVar10 + iVar7) = 0x2d2d;
                *(undefined *)(iVar10 + 2 + iVar7) = 0;
            }
            uVar3 = func_0x000180498cd0(arg3);
            func_0x00018000d970(arg1, arg3, uVar3);
            iVar10 = *(int64_t *)(arg1 + 0x10);
            if (*(uint64_t *)(arg1 + 0x18) - iVar10 < 2) {
                var_2a8h = 2;
                func_0x00018000ee80(arg1, 2, 0, 0x180644f68);
            } else {
                *(int64_t *)(arg1 + 0x10) = iVar10 + 2;
                iVar7 = arg1;
                if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                    iVar7 = *(int64_t *)arg1;
                }
                *(undefined2 *)(iVar10 + iVar7) = 0xa0d;
                *(undefined *)(iVar10 + 2 + iVar7) = 0;
            }
            iVar10 = *(int64_t *)(arg1 + 0x10);
            if (*(uint64_t *)(arg1 + 0x18) - iVar10 < 0x1e) {
                var_2a8h = 0x1e;
                func_0x00018000ee80(arg1, 0x1e, 0, 0x1804a84b0);
            } else {
                *(int64_t *)(arg1 + 0x10) = iVar10 + 0x1e;
                iVar7 = arg1;
                if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                    iVar7 = *(int64_t *)arg1;
                }
                fcn.180498030(iVar10 + iVar7, 0x1804a84b0, 0x1e);
                *(undefined *)(iVar10 + iVar7 + 0x1e) = 0;
            }
            if (ppiVar9[7] < (int64_t *)0x10) {
                ppiVar8 = ppiVar9 + 4;
            } else {
                ppiVar8 = (int64_t **)ppiVar9[4];
            }
            func_0x000180065f60(&var_148h, 0x100, 0x1804a84d0, ppiVar8);
            uVar4 = func_0x000180498cd0(&var_148h);
            iVar10 = *(int64_t *)(arg1 + 0x10);
            if (*(uint64_t *)(arg1 + 0x18) - iVar10 < uVar4) {
                var_2a8h = uVar4;
                func_0x00018000ee80(arg1, uVar4, 0, &var_148h);
            } else {
                *(uint64_t *)(arg1 + 0x10) = uVar4 + iVar10;
                iVar7 = arg1;
                if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                    iVar7 = *(int64_t *)arg1;
                }
                fcn.180498030(iVar10 + iVar7, &var_148h, uVar4);
                *(undefined *)(uVar4 + iVar10 + iVar7) = 0;
            }
            if (ppiVar9[10] != (int64_t *)0x0) {
                if (ppiVar9[0xe] == (int64_t *)0x0) {
                    var_258h._0_1_ = 0;
                    var_150h = 0;
                    ppiVar8 = ppiVar9 + 8;
                    if ((int64_t *)0xf < ppiVar9[0xb]) {
                        ppiVar8 = (int64_t **)ppiVar9[8];
                    }
                    func_0x000180498d90(&var_258h, ppiVar8, 0x103);
                    var_150h = func_0x00018046d990(ppiVar8, 0x180625030);
                    if ((var_150h != 0) || (piVar5 = (int32_t *)fcn.18046b77c(), *piVar5 == 0)) {
                        _var_288h = ZEXT816(0);
                        _var_278h = ZEXT816(0);
                        _var_268h = ZEXT816(0);
                        func_0x000180472e30(&var_258h, &var_288h);
                        iVar10 = (int64_t)var_278h._4_4_;
                        if (iVar10 != 0) {
                            ppiVar8 = ppiVar9 + 0xc;
                            func_0x00018000b3b0(ppiVar8, iVar10, 0);
                            if ((int64_t *)0xf < ppiVar9[0xf]) {
                                ppiVar8 = (int64_t **)*ppiVar8;
                            }
                            func_0x0001804611b4(ppiVar8, 1, iVar10, var_150h);
                        }
                    }
                    if (var_150h != 0) {
                        fcn.18045ff84();
                    }
                }
                ppiVar8 = ppiVar9 + 8;
                if ((int64_t *)0xf < ppiVar9[0xb]) {
                    ppiVar8 = (int64_t **)ppiVar9[8];
                }
                uVar3 = func_0x000180180fa0(ppiVar8);
                func_0x000180065f60(&var_148h, 0x100, 0x1804a84e0, uVar3);
                uVar4 = func_0x000180498cd0(&var_148h);
                iVar10 = *(int64_t *)(arg1 + 0x10);
                if (*(uint64_t *)(arg1 + 0x18) - iVar10 < uVar4) {
                    var_2a8h = uVar4;
                    func_0x00018000ee80(arg1, uVar4, 0, &var_148h);
                } else {
                    *(uint64_t *)(arg1 + 0x10) = uVar4 + iVar10;
                    iVar7 = arg1;
                    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                        iVar7 = *(int64_t *)arg1;
                    }
                    fcn.180498030(iVar10 + iVar7, &var_148h, uVar4);
                    *(undefined *)(uVar4 + iVar10 + iVar7) = 0;
                }
                if (ppiVar9[0xb] < (int64_t *)0x10) {
                    ppiVar8 = ppiVar9 + 8;
                } else {
                    ppiVar8 = (int64_t **)ppiVar9[8];
                }
                iVar10 = func_0x00018045b9a8(ppiVar8, 0x2e);
                if (((iVar10 != 0) && (pcVar6 = (char *)func_0x000180186cf0(iVar10 + 1), pcVar6 != (char *)0x0)) &&
                   (*pcVar6 != '\0')) {
                    iVar10 = *(int64_t *)(arg1 + 0x10);
                    if (*(uint64_t *)(arg1 + 0x18) - iVar10 < 2) {
                        var_2a8h = 2;
                        func_0x00018000ee80(arg1, 2, 0, 0x180644f68);
                    } else {
                        *(int64_t *)(arg1 + 0x10) = iVar10 + 2;
                        iVar7 = arg1;
                        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                            iVar7 = *(int64_t *)arg1;
                        }
                        *(undefined2 *)(iVar7 + iVar10) = 0xa0d;
                        *(undefined *)(iVar7 + 2 + iVar10) = 0;
                    }
                    iVar10 = *(int64_t *)(arg1 + 0x10);
                    if (*(uint64_t *)(arg1 + 0x18) - iVar10 < 0xe) {
                        var_2a8h = 0xe;
                        func_0x00018000ee80(arg1, 0xe, 0, 0x1804a84f0);
                    } else {
                        *(int64_t *)(arg1 + 0x10) = iVar10 + 0xe;
                        iVar7 = arg1;
                        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                            iVar7 = *(int64_t *)arg1;
                        }
                        fcn.180498030(iVar7 + iVar10, 0x1804a84f0, 0xe);
                        *(undefined *)(iVar7 + iVar10 + 0xe) = 0;
                    }
                    uVar3 = func_0x000180498cd0(pcVar6);
                    func_0x00018000d970(arg1, pcVar6, uVar3);
                }
            }
            iVar10 = *(int64_t *)(arg1 + 0x10);
            if (*(uint64_t *)(arg1 + 0x18) - iVar10 < 4) {
                var_2a8h = 4;
                func_0x00018000ee80(arg1, 4, 0, 0x1804a8500);
            } else {
                *(int64_t *)(arg1 + 0x10) = iVar10 + 4;
                iVar7 = arg1;
                if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                    iVar7 = *(int64_t *)arg1;
                }
                *(undefined4 *)(iVar10 + iVar7) = 0xa0d0a0d;
                *(undefined *)(iVar10 + 4 + iVar7) = 0;
            }
            if (ppiVar9[0xf] < (int64_t *)0x10) {
                ppiVar8 = ppiVar9 + 0xc;
            } else {
                ppiVar8 = (int64_t **)ppiVar9[0xc];
            }
            func_0x00018000d970(arg1, ppiVar8, ppiVar9[0xe]);
            iVar10 = *(int64_t *)(arg1 + 0x10);
            if (*(uint64_t *)(arg1 + 0x18) - iVar10 < 2) {
                var_2a8h = 2;
                func_0x00018000ee80(arg1, 2, 0, 0x180644f68);
            } else {
                *(int64_t *)(arg1 + 0x10) = iVar10 + 2;
                iVar7 = arg1;
                if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                    iVar7 = *(int64_t *)arg1;
                }
                *(undefined2 *)(iVar10 + iVar7) = 0xa0d;
                *(undefined *)(iVar10 + 2 + iVar7) = 0;
            }
            ppiVar8 = (int64_t **)ppiVar9[2];
            if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                ppiVar9 = ppiVar8;
                ppiVar8 = (int64_t **)*ppiVar8;
                while (cVar1 == '\0') {
                    cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                    ppiVar9 = ppiVar8;
                    ppiVar8 = (int64_t **)*ppiVar8;
                }
            } else {
                cVar1 = *(char *)((int64_t)ppiVar9[1] + 0x19);
                ppiVar2 = (int64_t **)ppiVar9[1];
                ppiVar8 = ppiVar9;
                while ((ppiVar9 = ppiVar2, cVar1 == '\0' && (ppiVar8 == (int64_t **)ppiVar9[2]))) {
                    cVar1 = *(char *)((int64_t)ppiVar9[1] + 0x19);
                    ppiVar2 = (int64_t **)ppiVar9[1];
                    ppiVar8 = ppiVar9;
                }
            }
            cVar1 = *(char *)((int64_t)ppiVar9 + 0x19);
        }
        iVar10 = *(int64_t *)(arg1 + 0x10);
        if (*(uint64_t *)(arg1 + 0x18) - iVar10 < 2) {
            var_2a8h = 2;
            func_0x00018000ee80(arg1, 2, 0, 0x180645d50);
        } else {
            *(int64_t *)(arg1 + 0x10) = iVar10 + 2;
            iVar7 = arg1;
            if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                iVar7 = *(int64_t *)arg1;
            }
            *(undefined2 *)(iVar10 + iVar7) = 0x2d2d;
            *(undefined *)(iVar10 + 2 + iVar7) = 0;
        }
        uVar3 = func_0x000180498cd0(arg3);
        func_0x00018000d970(arg1, arg3, uVar3);
        iVar10 = *(int64_t *)(arg1 + 0x10);
        if (*(uint64_t *)(arg1 + 0x18) - iVar10 < 4) {
            var_2a8h = 4;
            func_0x00018000ee80(arg1, 4, 0, 0x1804a8508);
        } else {
            *(int64_t *)(arg1 + 0x10) = iVar10 + 4;
            if (*(uint64_t *)(arg1 + 0x18) < 0x10) {
                *(undefined4 *)(iVar10 + arg1) = 0xa0d2d2d;
                *(undefined *)(iVar10 + 4 + arg1) = 0;
            } else {
                arg1 = *(int64_t *)arg1;
                *(undefined4 *)(iVar10 + arg1) = 0xa0d2d2d;
                *(undefined *)(iVar10 + 4 + arg1) = 0;
            }
        }
    }
    func_0x000180459870(var_48h ^ (uint64_t)auStack_2c8);
    return;
}

// ============================================================
// Function: FUN_180188970
// Address: 0x180188970
// Size: 579 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180188970(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t **ppiVar2;
    code *pcVar3;
    int64_t **ppiVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    undefined8 *puVar7;
    uint64_t uVar8;
    int64_t **ppiVar9;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_68 [32];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_20h;
    uint64_t uStack_18;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    var_48h._0_4_ = 1;
    ppiVar9 = (int64_t **)**(int64_t ***)arg2;
    cVar1 = *(char *)((int64_t)ppiVar9 + 0x19);
    var_40h = arg1;
    do {
        if (cVar1 != '\0') {
            func_0x000180459870(uStack_18 ^ (uint64_t)auStack_68);
            return;
        }
        uVar8 = *(uint64_t *)(arg1 + 0x10);
        if (uVar8 != 0) {
            if (uVar8 < *(uint64_t *)(arg1 + 0x18)) {
                *(uint64_t *)(arg1 + 0x10) = uVar8 + 1;
                iVar5 = arg1;
                if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                    iVar5 = *(int64_t *)arg1;
                }
                *(undefined2 *)(uVar8 + iVar5) = 0x26;
            } else {
                func_0x00018000f010(arg1, 1, 0, 0x26);
            }
        }
        puVar6 = (undefined8 *)func_0x000180189390(&var_38h, ppiVar9 + 4, 0x1805aadb1);
        puVar7 = puVar6;
        if (0xf < (uint64_t)puVar6[3]) {
            puVar7 = (undefined8 *)*puVar6;
        }
        func_0x00018000d970(arg1, puVar7, puVar6[2]);
        if (0xf < (uint64_t)var_20h) {
            uVar8 = var_20h + 1;
            iVar5 = var_38h;
            if (0xfff < uVar8) {
                iVar5 = *(int64_t *)(var_38h + -8);
                if (0x1f < (var_38h - iVar5) - 8U) goto code_r0x000180188bac;
                uVar8 = var_20h + 0x28;
            }
            fcn.180459c3c(iVar5, uVar8);
        }
        uVar8 = *(uint64_t *)(arg1 + 0x10);
        if (uVar8 < *(uint64_t *)(arg1 + 0x18)) {
            *(uint64_t *)(arg1 + 0x10) = uVar8 + 1;
            if (*(uint64_t *)(arg1 + 0x18) < 0x10) {
                *(undefined2 *)(uVar8 + arg1) = 0x3d;
            } else {
                *(undefined2 *)(uVar8 + *(int64_t *)arg1) = 0x3d;
            }
        } else {
            func_0x00018000f010(arg1, 1, 0, 0x3d);
        }
        puVar7 = (undefined8 *)func_0x000180189390(&var_38h, ppiVar9 + 8, 0x1805aadb1);
        if (0xf < (uint64_t)puVar7[3]) {
            puVar7 = (undefined8 *)*puVar7;
        }
        func_0x00018000d970(arg1, puVar7);
        if (0xf < (uint64_t)var_20h) {
            uVar8 = var_20h + 1;
            iVar5 = var_38h;
            if (0xfff < uVar8) {
                iVar5 = *(int64_t *)(var_38h + -8);
                if (0x1f < (var_38h - iVar5) - 8U) {
code_r0x000180188bac:
                    pcVar3 = (code *)swi(0x29);
                    (*pcVar3)(5);
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                uVar8 = var_20h + 0x28;
            }
            fcn.180459c3c(iVar5, uVar8);
        }
        ppiVar2 = (int64_t **)ppiVar9[2];
        if (*(char *)((int64_t)ppiVar2 + 0x19) == '\0') {
            cVar1 = *(char *)((int64_t)*ppiVar2 + 0x19);
            ppiVar9 = ppiVar2;
            ppiVar2 = (int64_t **)*ppiVar2;
            while (cVar1 == '\0') {
                cVar1 = *(char *)((int64_t)*ppiVar2 + 0x19);
                ppiVar9 = ppiVar2;
                ppiVar2 = (int64_t **)*ppiVar2;
            }
        } else {
            cVar1 = *(char *)((int64_t)ppiVar9[1] + 0x19);
            ppiVar4 = (int64_t **)ppiVar9[1];
            ppiVar2 = ppiVar9;
            while ((ppiVar9 = ppiVar4, cVar1 == '\0' && (ppiVar2 == (int64_t **)ppiVar9[2]))) {
                cVar1 = *(char *)((int64_t)ppiVar9[1] + 0x19);
                ppiVar4 = (int64_t **)ppiVar9[1];
                ppiVar2 = ppiVar9;
            }
        }
        cVar1 = *(char *)((int64_t)ppiVar9 + 0x19);
    } while( true );
}

// ============================================================
// Function: FUN_180188bc0
// Address: 0x180188bc0
// Size: 1169 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch

void fcn.180188bc0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined auVar5 [16];
    undefined auVar6 [16];
    char cVar7;
    int64_t iVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    undefined8 uVar11;
    int64_t iVar12;
    char *pcVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    int32_t iVar16;
    char *pcVar17;
    undefined *puVar18;
    undefined *puVar19;
    undefined *puVar20;
    undefined *puVar21;
    undefined *puVar22;
    undefined *puVar23;
    char *pcVar24;
    char *pcVar25;
    char *pcVar26;
    char *pcVar27;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_f0;
    undefined auStack_e8 [8];
    undefined auStack_e0 [24];
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    
    puVar18 = auStack_e8;
    puVar19 = auStack_e8;
    puVar20 = auStack_e8;
    puVar22 = auStack_e8;
    puVar21 = auStack_e8;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_e8;
    iVar8 = fcn.18045b928(arg1, 0x3f);
    if (iVar8 != 0) {
        arg1 = iVar8 + 1;
    }
    pcVar26 = (char *)0x0;
    cVar7 = *(char *)arg1;
    pcVar13 = pcVar26;
    pcVar17 = pcVar26;
    puVar23 = auStack_e8;
    pcVar24 = pcVar26;
    pcVar25 = (char *)arg1;
    pcVar27 = pcVar26;
    if (cVar7 != '\0') {
        do {
            iVar16 = (int32_t)pcVar17;
            if (cVar7 == '&') {
                if (iVar16 != 0) {
                    _var_98h = ZEXT816(0);
                    var_88h = 0;
                    var_80h = 0;
                    fcn.180004830(&var_98h, arg1, (int64_t)iVar16);
                    _var_b8h = ZEXT816(0);
                    var_a8h = 0;
                    var_a0h = 0;
                    fcn.180004830(&var_b8h, pcVar27, (int64_t)(int32_t)pcVar24);
                    piVar9 = (int64_t *)func_0x000180189550(&var_58h, &var_b8h);
                    iVar8 = func_0x000180189550(&var_78h, &var_98h);
                    piVar10 = (int64_t *)fcn.180185710(arg2, (int64_t)&var_c8h, iVar8);
                    iVar8 = *piVar10;
                    piVar10 = (int64_t *)(iVar8 + 0x40);
                    if (piVar10 != piVar9) {
                        uVar15 = *(uint64_t *)(iVar8 + 0x58);
                        if (uVar15 < 0x10) {
code_r0x000180188cf0:
                            *(undefined8 *)(iVar8 + 0x50) = 0;
                            *(undefined8 *)(iVar8 + 0x58) = 0xf;
                            *(undefined *)piVar10 = 0;
                            uVar2 = *(undefined4 *)((int64_t)piVar9 + 4);
                            uVar3 = *(undefined4 *)(piVar9 + 1);
                            uVar4 = *(undefined4 *)((int64_t)piVar9 + 0xc);
                            *(undefined4 *)piVar10 = *(undefined4 *)piVar9;
                            *(undefined4 *)(iVar8 + 0x44) = uVar2;
                            *(undefined4 *)(iVar8 + 0x48) = uVar3;
                            *(undefined4 *)(iVar8 + 0x4c) = uVar4;
                            uVar2 = *(undefined4 *)((int64_t)piVar9 + 0x14);
                            uVar3 = *(undefined4 *)(piVar9 + 3);
                            uVar4 = *(undefined4 *)((int64_t)piVar9 + 0x1c);
                            *(undefined4 *)(iVar8 + 0x50) = *(undefined4 *)(piVar9 + 2);
                            *(undefined4 *)(iVar8 + 0x54) = uVar2;
                            *(undefined4 *)(iVar8 + 0x58) = uVar3;
                            *(undefined4 *)(iVar8 + 0x5c) = uVar4;
                            piVar9[2] = 0;
                            piVar9[3] = 0xf;
                            *(undefined *)piVar9 = 0;
                            goto code_r0x000180188d1c;
                        }
                        iVar12 = *piVar10;
                        uVar14 = uVar15 + 1;
                        if (uVar14 < 0x1000) {
code_r0x000180188ceb:
                            fcn.180459c3c(iVar12, uVar14);
                            goto code_r0x000180188cf0;
                        }
                        if ((iVar12 - *(int64_t *)(iVar12 + -8)) - 8U < 0x20) {
                            uVar14 = uVar15 + 0x28;
                            iVar12 = *(int64_t *)(iVar12 + -8);
                            goto code_r0x000180188ceb;
                        }
                        pcVar1 = (code *)swi(0x29);
                        (*pcVar1)(5);
                        puVar18 = auStack_e0;
code_r0x000180188f17:
                        pcVar1 = (code *)swi(0x29);
                        (*pcVar1)(5);
                        puVar19 = puVar18 + 8;
code_r0x000180188f1e:
                        pcVar1 = (code *)swi(0x29);
                        (*pcVar1)(5);
                        puVar20 = puVar19 + 8;
code_r0x000180188f25:
                        pcVar1 = (code *)swi(0x29);
                        (*pcVar1)(5);
                        puVar21 = puVar20 + 8;
                        goto code_r0x000180188f2c;
                    }
code_r0x000180188d1c:
                    if (0xf < (uint64_t)var_60h) {
                        uVar15 = var_60h + 1;
                        iVar12 = CONCAT71(var_78h._1_7_, (undefined)var_78h);
                        iVar8 = iVar12;
                        if (0xfff < uVar15) {
                            iVar8 = *(int64_t *)(iVar12 + -8);
                            if (0x1f < (iVar12 - iVar8) - 8U) goto code_r0x000180188f17;
                            uVar15 = var_60h + 0x28;
                        }
                        fcn.180459c3c(iVar8, uVar15);
                    }
                    var_68h = 0;
                    var_60h = 0xf;
                    var_78h._0_1_ = 0;
                    if (0xf < (uint64_t)var_40h) {
                        uVar15 = var_40h + 1;
                        iVar8 = var_58h;
                        if (0xfff < uVar15) {
                            iVar8 = *(int64_t *)(var_58h + -8);
                            if (0x1f < (var_58h - iVar8) - 8U) goto code_r0x000180188f1e;
                            uVar15 = var_40h + 0x28;
                        }
                        fcn.180459c3c(iVar8, uVar15);
                    }
                    if (0xf < (uint64_t)var_a0h) {
                        uVar15 = var_a0h + 1;
                        iVar8 = var_b8h;
                        if (0xfff < uVar15) {
                            iVar8 = *(int64_t *)(var_b8h + -8);
                            if (0x1f < (var_b8h - iVar8) - 8U) goto code_r0x000180188f25;
                            uVar15 = var_a0h + 0x28;
                        }
                        fcn.180459c3c(iVar8, uVar15);
                    }
                    var_a8h = 0;
                    var_a0h = 0xf;
                    auVar5[15] = 0;
                    auVar5._0_15_ = stack0xffffffffffffff49;
                    _var_b8h = auVar5 << 8;
                    pcVar17 = pcVar26;
                    pcVar24 = pcVar26;
                    if (0xf < (uint64_t)var_80h) {
                        uVar15 = var_80h + 1;
                        iVar8 = var_98h;
                        if (0xfff < uVar15) {
                            iVar8 = *(int64_t *)(var_98h + -8);
                            if (0x1f < (var_98h - iVar8) - 8U) goto code_r0x00018018900d;
                            uVar15 = var_80h + 0x28;
                        }
                        fcn.180459c3c(iVar8, uVar15);
                        pcVar17 = (char *)0x0;
                        pcVar24 = (char *)0x0;
                    }
                }
                arg1 = (int64_t)(pcVar25 + 1);
                pcVar13 = pcVar26;
            } else if ((int32_t)pcVar13 == 0) {
                if (*pcVar25 == '=') {
                    pcVar13 = (char *)0x1;
                    pcVar27 = pcVar25 + 1;
                } else {
                    pcVar17 = (char *)(uint64_t)(iVar16 + 1);
                }
            } else {
                pcVar24 = (char *)(uint64_t)((int32_t)pcVar24 + 1);
            }
            pcVar25 = pcVar25 + 1;
            cVar7 = *pcVar25;
        } while (cVar7 != '\0');
        puVar23 = auStack_e8;
        if ((int32_t)pcVar17 != 0) {
            _var_98h = ZEXT816(0);
            var_88h = 0;
            var_80h = 0;
            fcn.180004830(&var_98h, arg1, (int64_t)(int32_t)pcVar17);
            _var_b8h = ZEXT816(0);
            var_a8h = 0;
            var_a0h = 0;
            fcn.180004830(&var_b8h, pcVar27, (int64_t)(int32_t)pcVar24);
            uVar11 = func_0x000180189550(&var_58h, &var_b8h);
            iVar8 = func_0x000180189550(&var_78h, &var_98h);
            piVar9 = (int64_t *)fcn.180185710(arg2, (int64_t)&var_c8h, iVar8);
            func_0x000180012c10(*piVar9 + 0x40, uVar11);
            puVar22 = auStack_e8;
            if (0xf < (uint64_t)var_60h) {
                iVar12 = CONCAT71(var_78h._1_7_, (undefined)var_78h);
                iVar8 = iVar12;
                puVar22 = auStack_e8;
                if ((0xfff < var_60h + 1U) &&
                   (iVar8 = *(int64_t *)(iVar12 + -8), puVar22 = auStack_e8, 0x1f < (iVar12 - iVar8) - 8U)) {
code_r0x000180188f2c:
                    pcVar1 = (code *)swi(0x29);
                    iVar8 = (*pcVar1)(5);
                    puVar22 = puVar21 + 8;
                }
                *(undefined8 *)(puVar22 + -8) = 0x180188f3b;
                fcn.180459c3c(iVar8);
            }
            var_68h = 0;
            var_60h = 0xf;
            var_78h._0_1_ = 0;
            if (0xf < (uint64_t)var_40h) {
                iVar8 = var_58h;
                if ((0xfff < var_40h + 1U) && (iVar8 = *(int64_t *)(var_58h + -8), 0x1f < (var_58h - iVar8) - 8U)) {
                    pcVar1 = (code *)swi(0x29);
                    iVar8 = (*pcVar1)(5);
                    puVar22 = puVar22 + 8;
                }
                *(undefined8 *)(puVar22 + -8) = 0x180188f8b;
                fcn.180459c3c(iVar8);
            }
            if (0xf < (uint64_t)var_a0h) {
                iVar8 = var_b8h;
                if ((0xfff < var_a0h + 1U) && (iVar8 = *(int64_t *)(var_b8h + -8), 0x1f < (var_b8h - iVar8) - 8U)) {
                    pcVar1 = (code *)swi(0x29);
                    iVar8 = (*pcVar1)(5);
                    puVar22 = puVar22 + 8;
                }
                *(undefined8 *)(puVar22 + -8) = 0x180188fcc;
                fcn.180459c3c(iVar8);
            }
            var_a8h = 0;
            var_a0h = 0xf;
            auVar6[15] = 0;
            auVar6._0_15_ = stack0xffffffffffffff49;
            _var_b8h = auVar6 << 8;
            puVar23 = puVar22;
            if (0xf < (uint64_t)var_80h) {
                iVar8 = var_98h;
                if ((0xfff < var_80h + 1U) && (iVar8 = *(int64_t *)(var_98h + -8), 0x1f < (var_98h - iVar8) - 8U)) {
code_r0x00018018900d:
                    var_a0h = 0xf;
                    var_a8h = 0;
                    pcVar1 = (code *)swi(0x29);
                    iVar8 = (*pcVar1)(5);
                    puVar23 = puVar22 + 8;
                }
                *(undefined8 *)(puVar23 + -8) = 0x18018901c;
                fcn.180459c3c(iVar8);
            }
        }
    }
    *(undefined8 *)(puVar23 + -8) = 0x180189035;
    func_0x000180459870(var_38h ^ (uint64_t)puVar23);
    return;
}

// ============================================================
// Function: FUN_1801890b0
// Address: 0x1801890b0
// Size: 348 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h

void fcn.1801890b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t iVar1;
    code *UNRECOVERED_JUMPTABLE;
    uint32_t uVar2;
    int32_t iVar3;
    undefined auStack_88 [32];
    int64_t var_68h;
    int64_t var_60h;
    int32_t var_58h;
    int32_t var_54h;
    int64_t var_50h;
    int32_t var_48h;
    undefined4 uStack_44;
    int64_t var_40h;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    uVar2 = (uint32_t)arg1;
    func_0x000180467bd4(&var_68h);
    iVar1 = func_0x000180461948(&var_68h);
    var_58h = *(int32_t *)(iVar1 + 8);
    var_54h = *(int32_t *)(iVar1 + 0xc);
    var_50h._0_4_ = *(int32_t *)(iVar1 + 0x10);
    var_50h._4_4_ = *(undefined4 *)(iVar1 + 0x14);
    var_48h = *(int32_t *)(iVar1 + 0x18);
    uStack_44 = *(undefined4 *)(iVar1 + 0x1c);
    var_40h._0_4_ = *(undefined4 *)(iVar1 + 0x20);
    var_60h._4_4_ = *(uint32_t *)(iVar1 + 4);
    if (-1 < (int32_t)uVar2) {
        var_60h._4_4_ = uVar2;
    }
    var_60h._0_4_ = 0;
    if ((int32_t)arg2 < 0) {
        uVar2 = ~uVar2 >> 0x1f;
    } else {
        uVar2 = 2;
        var_58h = (int32_t)arg2;
    }
    if ((int32_t)arg4 < 0) {
        iVar3 = (int32_t)arg3;
        if (0 < iVar3) {
            uVar2 = 4;
            var_54h = iVar3;
            if (0 < (int32_t)arg_28h) {
                var_50h._0_4_ = (int32_t)arg_28h + -1;
                uVar2 = 5;
            }
        }
        iVar1 = func_0x000180473b84(&var_60h);
    } else {
        iVar1 = func_0x000180473b84(&var_60h);
        uVar2 = 3;
        iVar1 = ((int32_t)arg4 - var_48h) * 0x15180 + iVar1;
    }
    if (var_68h < iVar1) {
        func_0x000180459870(var_38h ^ (uint64_t)auStack_88);
        return;
    }
    UNRECOVERED_JUMPTABLE = (code *)((uint64_t)*(uint32_t *)((int64_t)(int32_t)uVar2 * 4 + 0x1801891f4) + 0x180000000);
    // WARNING: Could not recover jumptable at 0x000180189191. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (6 cases) at 0x1801891f4
    (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
    return;
}

// ============================================================
// Function: FUN_180189210
// Address: 0x180189210
// Size: 144 bytes
// ============================================================
int64_t fcn.180189210(int64_t arg_38h)
{
    int64_t iVar1;
    double dVar2;
    int64_t var_8h;
    
    if (*(int64_t *)0x18077e200 == 0) {
        (*(code *)0x699e5a)(&var_8h);
        *(int64_t *)0x18077e200 = var_8h;
        if (var_8h == 0) {
            return var_8h;
        }
    }
    (*(code *)0x699e76)(&var_8h);
    iVar1 = 0;
    dVar2 = ((double)var_8h / (double)*(int64_t *)0x18077e200) * 1000000.0;
    if ((9.223372036854776e+18 <= dVar2) && (dVar2 = dVar2 - 9.223372036854776e+18, dVar2 < 9.223372036854776e+18)) {
        iVar1 = -0x8000000000000000;
    }
    return (int64_t)dVar2 + iVar1;
}

// ============================================================
// Function: FUN_1801892a0
// Address: 0x1801892a0
// Size: 129 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1801892a0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    int64_t var_8h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_8h = arg1;
    puVar1 = (undefined4 *)fcn.18046e560(&var_8h);
    fcn.180189330(arg2, 0x1804a8658, *(undefined8 *)((int64_t)(int32_t)puVar1[6] * 8 + 0x18069c1f0), puVar1[3], 
                  *(undefined8 *)((int64_t)(int32_t)puVar1[4] * 8 + 0x18069c230), puVar1[5] + 0x76c, puVar1[2], 
                  puVar1[1], *puVar1);
    return arg2;
}

// ============================================================
// Function: FUN_180189330
// Address: 0x180189330
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ffh
// WARNING: [rz-ghidra] Detected overlap for variable var_4fbh
// WARNING: [rz-ghidra] Detected overlap for variable var_4f9h
// WARNING: [rz-ghidra] Detected overlap for variable var_500h
// WARNING: [rz-ghidra] Detected overlap for variable var_494h
// WARNING: [rz-ghidra] Detected overlap for variable var_490h
// WARNING: [rz-ghidra] Detected overlap for variable var_46ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4c4h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_4cch

int32_t fcn.180189330(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    var_18h = arg3;
    var_20h = arg4;
    fcn.1800102c0();
    iVar1 = fcn.180467554(0, (int64_t)&var_18h);
    if (iVar1 < 0) {
        iVar1 = -1;
    }
    return iVar1;
}

// ============================================================
// Function: FUN_180189390
// Address: 0x180189390
// Size: 444 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_11h
// WARNING: [rz-ghidra] Detected overlap for variable var_12h

int64_t fcn.180189390(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined4 uVar3;
    uint8_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint8_t *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        arg2 = *(int64_t *)arg2;
    }
    var_10h._0_4_ = 0x303025;
    uVar1 = *(uint8_t *)arg2;
    uVar3 = (undefined4)var_10h;
    do {
        if (uVar1 == 0) {
            return arg1;
        }
        if (((uint8_t)(uVar1 + 0x9f) < 0x1a) ||
           ((((uint8_t)(uVar1 - 0x2d) < 0x33 && ((0x43ffffff01ffbU >> ((uint64_t)(uVar1 - 0x2d) & 0x3f) & 1) != 0)) ||
            (uVar1 == 0x7e)))) {
code_r0x0001801894d7:
            uVar5 = *(uint64_t *)(arg1 + 0x10);
            var_10h._0_4_ = uVar3;
            if (uVar5 < *(uint64_t *)(arg1 + 0x18)) {
                *(uint64_t *)(arg1 + 0x10) = uVar5 + 1;
                if (*(uint64_t *)(arg1 + 0x18) < 0x10) {
                    *(uint8_t *)(uVar5 + arg1) = uVar1;
                    *(undefined *)(uVar5 + 1 + arg1) = 0;
                } else {
                    iVar2 = *(int64_t *)arg1;
                    *(uint8_t *)(uVar5 + iVar2) = uVar1;
                    *(undefined *)(uVar5 + 1 + iVar2) = 0;
                }
            } else {
                func_0x00018000f010(arg1, 1, 0, uVar1);
            }
        } else {
            uVar4 = *(uint8_t *)arg3;
            puVar7 = (uint8_t *)arg3;
            if (uVar4 == 0) {
code_r0x000180189445:
                if (*puVar7 != 0) goto code_r0x0001801894d7;
            } else {
                do {
                    if (uVar4 == uVar1) goto code_r0x000180189445;
                    puVar7 = puVar7 + 1;
                    uVar4 = *puVar7;
                } while (uVar4 != 0);
            }
            uVar5 = func_0x000180498cd0(&var_10h);
            iVar2 = *(int64_t *)(arg1 + 0x10);
            if (*(uint64_t *)(arg1 + 0x18) - iVar2 < uVar5) {
                func_0x00018000ee80(arg1, uVar5, 0, &var_10h, uVar5);
            } else {
                *(uint64_t *)(arg1 + 0x10) = iVar2 + uVar5;
                iVar6 = arg1;
                if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                    iVar6 = *(int64_t *)arg1;
                }
                fcn.180498030(iVar2 + iVar6, &var_10h);
                *(undefined *)(iVar2 + iVar6 + uVar5) = 0;
            }
        }
        arg2 = arg2 + 1;
        uVar1 = *(uint8_t *)arg2;
        uVar3 = (undefined4)var_10h;
    } while( true );
}

// ============================================================
// Function: FUN_180189550
// Address: 0x180189550
// Size: 449 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180189550(int64_t arg1, int64_t arg2)
{
    char cVar1;
    char cVar2;
    uint64_t uVar3;
    char cVar4;
    int64_t iVar5;
    uint8_t uVar6;
    int32_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 uVar8;
    
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    uVar8 = 1;
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        arg2 = *(int64_t *)arg2;
    }
    cVar4 = *(char *)arg2;
    do {
        if (cVar4 == '\0') {
            return arg1;
        }
        if (cVar4 == '%') {
            cVar1 = *(char *)(arg2 + 1);
            if ((((9 < (uint8_t)(cVar1 - 0x30U)) && (5 < (uint8_t)(cVar1 + 0x9fU))) && (5 < (uint8_t)(cVar1 + 0xbfU)))
               || (((cVar2 = *(char *)(arg2 + 2), 9 < (uint8_t)(cVar2 - 0x30U) && (5 < (uint8_t)(cVar2 + 0x9fU))) &&
                   (5 < (uint8_t)(cVar2 + 0xbfU))))) {
code_r0x0001801896ad:
                uVar3 = *(uint64_t *)(arg1 + 0x10);
                if (uVar3 < *(uint64_t *)(arg1 + 0x18)) {
                    *(uint64_t *)(arg1 + 0x10) = uVar3 + 1;
                    iVar5 = arg1;
                    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                        iVar5 = *(int64_t *)arg1;
                    }
                    *(char *)(uVar3 + iVar5) = cVar4;
                    *(undefined *)(uVar3 + 1 + iVar5) = 0;
                } else {
code_r0x0001801896dd:
                    func_0x00018000f010(arg1, 1, 0, cVar4, uVar8);
                }
                goto code_r0x0001801896ed;
            }
            if (cVar1 < ':') {
                iVar7 = cVar1 + -0x30;
            } else {
                iVar7 = 0x37;
                if ('F' < cVar1) {
                    iVar7 = 0x57;
                }
                iVar7 = cVar1 - iVar7;
            }
            if (cVar2 < ':') {
                cVar4 = -0x30;
            } else {
                cVar4 = '7';
                if ('F' < cVar2) {
                    cVar4 = 'W';
                }
                cVar4 = -cVar4;
            }
            uVar6 = (char)iVar7 << 4 | cVar2 + cVar4;
            uVar3 = *(uint64_t *)(arg1 + 0x10);
            if (uVar3 < *(uint64_t *)(arg1 + 0x18)) {
                *(uint64_t *)(arg1 + 0x10) = uVar3 + 1;
                iVar5 = arg1;
                if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                    iVar5 = *(int64_t *)arg1;
                }
                *(uint8_t *)(uVar3 + iVar5) = uVar6;
                *(undefined *)(uVar3 + 1 + iVar5) = 0;
                arg2 = arg2 + 3;
            } else {
                func_0x00018000f010(arg1, 1, 0, CONCAT31((unkint3)((uint32_t)iVar7 >> 8), uVar6), uVar8);
                arg2 = arg2 + 3;
            }
        } else {
            if (cVar4 != '+') goto code_r0x0001801896ad;
            uVar3 = *(uint64_t *)(arg1 + 0x10);
            if (*(uint64_t *)(arg1 + 0x18) <= uVar3) {
                cVar4 = ' ';
                goto code_r0x0001801896dd;
            }
            *(uint64_t *)(arg1 + 0x10) = uVar3 + 1;
            iVar5 = arg1;
            if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                iVar5 = *(int64_t *)arg1;
            }
            *(undefined2 *)(uVar3 + iVar5) = 0x20;
code_r0x0001801896ed:
            arg2 = arg2 + 1;
        }
        cVar4 = *(char *)arg2;
    } while( true );
}

// ============================================================
// Function: FUN_180189720
// Address: 0x180189720
// Size: 277 bytes
// ============================================================
uint64_t fcn.180189720(int64_t arg1, int64_t arg2)
{
    undefined uVar1;
    uint64_t uVar2;
    int32_t iVar3;
    int64_t in_R8;
    int32_t iVar4;
    uint64_t uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    
    uVar2 = 0;
    uVar7 = 0;
    uVar5 = 0;
    if ((uint32_t)arg2 != 0) {
        do {
            iVar6 = (int32_t)uVar2;
            iVar4 = (int32_t)(uVar2 / 3);
            iVar3 = iVar6 + iVar4 * -3;
            if (iVar6 == iVar4 * 3) {
                uVar2 = (uint64_t)(*(uint8_t *)(uVar2 + arg1) >> 2);
code_r0x0001801897b0:
                uVar1 = *(undefined *)(uVar2 + 0x1804a8690);
code_r0x0001801897b4:
                *(undefined *)(uVar5 + in_R8) = uVar1;
                uVar5 = (uint64_t)((int32_t)uVar5 + 1);
            } else {
                if (iVar3 == 1) {
                    uVar1 = *(undefined *)
                             ((uint64_t)
                              ((*(uint8_t *)((uint64_t)(iVar6 - 1) + arg1) & 3) * 0x10 +
                              (uint32_t)(*(uint8_t *)(uVar2 + arg1) >> 4)) + 0x1804a8690);
                    goto code_r0x0001801897b4;
                }
                if (iVar3 == 2) {
                    *(undefined *)(uVar5 + in_R8) =
                         *(undefined *)
                          ((uint64_t)
                           ((uint32_t)(*(uint8_t *)(uVar2 + arg1) >> 6) +
                           (*(uint8_t *)((uint64_t)(iVar6 - 1) + arg1) & 0xf) * 4) + 0x1804a8690);
                    uVar5 = (uint64_t)((int32_t)uVar5 + 1);
                    uVar2 = (uint64_t)(*(uint8_t *)(uVar2 + arg1) & 0x3f);
                    goto code_r0x0001801897b0;
                }
            }
            uVar7 = iVar6 + 1;
            uVar2 = (uint64_t)uVar7;
        } while (uVar7 < (uint32_t)arg2);
    }
    uVar7 = uVar7 - 1;
    iVar4 = (int32_t)uVar5;
    if (uVar7 == (uVar7 / 3) * 3) {
        *(undefined *)(uVar5 + in_R8) =
             *(undefined *)((uint64_t)(*(uint8_t *)((uint64_t)uVar7 + arg1) & 3) * 0x10 + 0x1804a8690);
        *(undefined *)((uint64_t)(iVar4 + 1) + in_R8) = 0x3d;
        *(undefined *)((uint64_t)(iVar4 + 2) + in_R8) = 0x3d;
        return (uint64_t)(iVar4 + 3);
    }
    if (uVar7 % 3 == 1) {
        *(undefined *)(uVar5 + in_R8) =
             *(undefined *)((uint64_t)(*(uint8_t *)((uint64_t)uVar7 + arg1) & 0xf) * 4 + 0x1804a8690);
        *(undefined *)((uint64_t)(iVar4 + 1) + in_R8) = 0x3d;
        return (uint64_t)(iVar4 + 2);
    }
    return uVar5;
}

// ============================================================
// Function: FUN_180189840
// Address: 0x180189840
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180189840(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    int64_t var_18h;
    
    fcn.18018ba00((int64_t)(int32_t)arg3);
    return;
}

// ============================================================
// Function: FUN_1801898c0
// Address: 0x1801898c0
// Size: 231 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_3fh
// WARNING: [rz-ghidra] Detected overlap for variable var_3eh
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3bh
// WARNING: [rz-ghidra] Detected overlap for variable var_3ah
// WARNING: [rz-ghidra] Detected overlap for variable var_3dh
// WARNING: [rz-ghidra] Detected overlap for variable var_39h

void fcn.1801898c0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined auStack_d8 [32];
    int64_t var_b8h;
    int64_t var_58h;
    undefined4 uStack_48;
    int64_t var_40h;
    undefined4 uStack_38;
    undefined4 uStack_34;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    undefined4 uStack_28;
    undefined4 uStack_24;
    unkbyte5 Stack_20;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_d8;
    var_40h._0_4_ = 0x45383532;
    var_40h._4_4_ = 0x35414641;
    uStack_38 = 0x3139452d;
    uStack_34 = 0x37342d34;
    uStack_48 = 0;
    uStack_30 = 0x392d4144;
    uStack_2c = 0x2d414335;
    uStack_28 = 0x42413543;
    uStack_24 = 0x38434430;
    Stack_20 = 0x31314235;
    _var_58h = ZEXT816(0);
    fcn.18018a710(&var_b8h);
    uVar1 = fcn.180498cd0(arg1);
    fcn.18018b950(&var_b8h, arg1, uVar1);
    uVar1 = fcn.180498cd0(&var_40h);
    fcn.18018b950(&var_b8h, &var_40h, uVar1);
    fcn.18018a3e0(&var_58h, &var_b8h);
    fcn.180189720((int64_t)&var_58h, 0x14);
    fcn.180459870(var_18h ^ (uint64_t)auStack_d8);
    return;
}

// ============================================================
// Function: FUN_1801899b0
// Address: 0x1801899b0
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_4h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

uint64_t fcn.1801899b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int64_t var_4h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar1 = arg1 + 0x1a0;
    iVar5 = (int32_t)arg3;
    if (iVar5 < 0x10000) {
        iVar5 = func_0x000180456008(iVar1);
        if (iVar5 != 0) goto code_r0x000180189b02;
        if (*(int32_t *)(arg1 + 0x1ec) == 0x7fffffff) goto code_r0x000180189aef;
        uVar4 = func_0x000180189b10(arg1, arg2, arg3 & 0xffffffffU, arg4 & 0xffffffffU, (undefined)arg_28h);
        uVar6 = (uint64_t)uVar4;
        func_0x000180456010(iVar1);
    } else {
        iVar3 = func_0x000180456008(iVar1);
        if (iVar3 != 0) {
code_r0x000180189b02:
            func_0x0001804542e8(5);
            pcVar2 = (code *)swi(3);
            uVar6 = (*pcVar2)();
            return uVar6;
        }
        if (*(int32_t *)(arg1 + 0x1ec) == 0x7fffffff) {
code_r0x000180189aef:
            *(undefined4 *)(arg1 + 0x1ec) = 0x7ffffffe;
            func_0x0001804542e8(6);
            pcVar2 = (code *)swi(3);
            uVar6 = (*pcVar2)();
            return uVar6;
        }
        uVar4 = func_0x000180189b10(arg1, arg2, 0xffff, arg4 & 0xffffffffU, 0);
        uVar6 = (uint64_t)uVar4;
        if (-1 < (int32_t)uVar4) {
            arg2 = arg2 + 0xffff;
            while (iVar5 = iVar5 + -0xffff, 0xffff < iVar5) {
                uVar4 = func_0x000180189b10(arg1, arg2, 0xffff, 0, 0);
                uVar6 = (uint64_t)uVar4;
                if ((int32_t)uVar4 < 0) goto code_r0x000180189a92;
                arg2 = arg2 + 0xffff;
            }
            uVar4 = func_0x000180189b10(arg1, arg2, iVar5, 0, 1);
            uVar6 = arg3 & 0xffffffffU;
            if ((int32_t)uVar4 < 0) {
                uVar6 = (uint64_t)uVar4;
            }
        }
code_r0x000180189a92:
        func_0x000180456010(iVar1);
    }
    return uVar6;
}

// ============================================================
// Function: FUN_180189a03
// Address: 0x180189a03
// Size: 160 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_4h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

uint64_t fcn.1801899b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int64_t var_4h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar1 = arg1 + 0x1a0;
    iVar5 = (int32_t)arg3;
    if (iVar5 < 0x10000) {
        iVar5 = func_0x000180456008(iVar1);
        if (iVar5 != 0) goto code_r0x000180189b02;
        if (*(int32_t *)(arg1 + 0x1ec) == 0x7fffffff) goto code_r0x000180189aef;
        uVar4 = func_0x000180189b10(arg1, arg2, arg3 & 0xffffffffU, arg4 & 0xffffffffU, (undefined)arg_28h);
        uVar6 = (uint64_t)uVar4;
        func_0x000180456010(iVar1);
    } else {
        iVar3 = func_0x000180456008(iVar1);
        if (iVar3 != 0) {
code_r0x000180189b02:
            func_0x0001804542e8(5);
            pcVar2 = (code *)swi(3);
            uVar6 = (*pcVar2)();
            return uVar6;
        }
        if (*(int32_t *)(arg1 + 0x1ec) == 0x7fffffff) {
code_r0x000180189aef:
            *(undefined4 *)(arg1 + 0x1ec) = 0x7ffffffe;
            func_0x0001804542e8(6);
            pcVar2 = (code *)swi(3);
            uVar6 = (*pcVar2)();
            return uVar6;
        }
        uVar4 = func_0x000180189b10(arg1, arg2, 0xffff, arg4 & 0xffffffffU, 0);
        uVar6 = (uint64_t)uVar4;
        if (-1 < (int32_t)uVar4) {
            arg2 = arg2 + 0xffff;
            while (iVar5 = iVar5 + -0xffff, 0xffff < iVar5) {
                uVar4 = func_0x000180189b10(arg1, arg2, 0xffff, 0, 0);
                uVar6 = (uint64_t)uVar4;
                if ((int32_t)uVar4 < 0) goto code_r0x000180189a92;
                arg2 = arg2 + 0xffff;
            }
            uVar4 = func_0x000180189b10(arg1, arg2, iVar5, 0, 1);
            uVar6 = arg3 & 0xffffffffU;
            if ((int32_t)uVar4 < 0) {
                uVar6 = (uint64_t)uVar4;
            }
        }
code_r0x000180189a92:
        func_0x000180456010(iVar1);
    }
    return uVar6;
}

// ============================================================
// Function: FUN_180189aa3
// Address: 0x180189aa3
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_4h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

uint64_t fcn.1801899b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int64_t var_4h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar1 = arg1 + 0x1a0;
    iVar5 = (int32_t)arg3;
    if (iVar5 < 0x10000) {
        iVar5 = func_0x000180456008(iVar1);
        if (iVar5 != 0) goto code_r0x000180189b02;
        if (*(int32_t *)(arg1 + 0x1ec) == 0x7fffffff) goto code_r0x000180189aef;
        uVar4 = func_0x000180189b10(arg1, arg2, arg3 & 0xffffffffU, arg4 & 0xffffffffU, (undefined)arg_28h);
        uVar6 = (uint64_t)uVar4;
        func_0x000180456010(iVar1);
    } else {
        iVar3 = func_0x000180456008(iVar1);
        if (iVar3 != 0) {
code_r0x000180189b02:
            func_0x0001804542e8(5);
            pcVar2 = (code *)swi(3);
            uVar6 = (*pcVar2)();
            return uVar6;
        }
        if (*(int32_t *)(arg1 + 0x1ec) == 0x7fffffff) {
code_r0x000180189aef:
            *(undefined4 *)(arg1 + 0x1ec) = 0x7ffffffe;
            func_0x0001804542e8(6);
            pcVar2 = (code *)swi(3);
            uVar6 = (*pcVar2)();
            return uVar6;
        }
        uVar4 = func_0x000180189b10(arg1, arg2, 0xffff, arg4 & 0xffffffffU, 0);
        uVar6 = (uint64_t)uVar4;
        if (-1 < (int32_t)uVar4) {
            arg2 = arg2 + 0xffff;
            while (iVar5 = iVar5 + -0xffff, 0xffff < iVar5) {
                uVar4 = func_0x000180189b10(arg1, arg2, 0xffff, 0, 0);
                uVar6 = (uint64_t)uVar4;
                if ((int32_t)uVar4 < 0) goto code_r0x000180189a92;
                arg2 = arg2 + 0xffff;
            }
            uVar4 = func_0x000180189b10(arg1, arg2, iVar5, 0, 1);
            uVar6 = arg3 & 0xffffffffU;
            if ((int32_t)uVar4 < 0) {
                uVar6 = (uint64_t)uVar4;
            }
        }
code_r0x000180189a92:
        func_0x000180456010(iVar1);
    }
    return uVar6;
}

// ============================================================
// Function: FUN_180189b10
// Address: 0x180189b10
// Size: 88 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180189b10(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_80h)
{
    uint64_t uVar1;
    uint32_t uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    uint32_t uVar6;
    bool bVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    var_8h._0_4_ = 0;
    bVar7 = *(int32_t *)(arg1 + 0x178) == 0;
    if (bVar7) {
        var_8h._0_4_ = func_0x000180472118();
    }
    uVar2 = func_0x000180189890(arg3 & 0xffffffff, bVar7);
    uVar1 = *(uint64_t *)(arg1 + 400);
    if (uVar1 < (uint64_t)(int64_t)(int32_t)uVar2) {
        uVar5 = 1;
        if (1 < uVar2) {
            uVar6 = uVar2 - 1;
            iVar4 = 1;
            while (uVar6 = uVar6 >> 1, uVar6 != 0) {
                iVar4 = iVar4 + 1;
            }
            for (; iVar4 != 0; iVar4 = iVar4 + -1) {
                uVar5 = (uint64_t)(uint32_t)((int32_t)uVar5 * 2);
            }
        }
        if (uVar5 != uVar1) {
            if (*(int64_t *)(arg1 + 0x188) == 0) {
                uVar3 = func_0x0001801813b0(uVar5);
            } else {
                uVar3 = func_0x000180181320(*(int64_t *)(arg1 + 0x188), uVar5, uVar1);
            }
            *(undefined8 *)(arg1 + 0x188) = uVar3;
            *(uint64_t *)(arg1 + 400) = uVar5;
            *(undefined *)(arg1 + 0x198) = 1;
        }
    }
    fcn.180189840(*(undefined8 *)(arg1 + 0x188), arg2, arg3 & 0xffffffff, (int64_t)&var_8h, 
                  CONCAT71(var_48h._1_7_, bVar7), CONCAT44(var_40h._4_4_, (int32_t)arg4), 
                  CONCAT71(var_38h._1_7_, (undefined)arg_28h));
    func_0x000180180f10(arg1, *(undefined8 *)(arg1 + 0x188), uVar2);
    return;
}

// ============================================================
// Function: FUN_180189b68
// Address: 0x180189b68
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180189b10(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_80h)
{
    uint64_t uVar1;
    uint32_t uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    uint32_t uVar6;
    bool bVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    var_8h._0_4_ = 0;
    bVar7 = *(int32_t *)(arg1 + 0x178) == 0;
    if (bVar7) {
        var_8h._0_4_ = func_0x000180472118();
    }
    uVar2 = func_0x000180189890(arg3 & 0xffffffff, bVar7);
    uVar1 = *(uint64_t *)(arg1 + 400);
    if (uVar1 < (uint64_t)(int64_t)(int32_t)uVar2) {
        uVar5 = 1;
        if (1 < uVar2) {
            uVar6 = uVar2 - 1;
            iVar4 = 1;
            while (uVar6 = uVar6 >> 1, uVar6 != 0) {
                iVar4 = iVar4 + 1;
            }
            for (; iVar4 != 0; iVar4 = iVar4 + -1) {
                uVar5 = (uint64_t)(uint32_t)((int32_t)uVar5 * 2);
            }
        }
        if (uVar5 != uVar1) {
            if (*(int64_t *)(arg1 + 0x188) == 0) {
                uVar3 = func_0x0001801813b0(uVar5);
            } else {
                uVar3 = func_0x000180181320(*(int64_t *)(arg1 + 0x188), uVar5, uVar1);
            }
            *(undefined8 *)(arg1 + 0x188) = uVar3;
            *(uint64_t *)(arg1 + 400) = uVar5;
            *(undefined *)(arg1 + 0x198) = 1;
        }
    }
    fcn.180189840(*(undefined8 *)(arg1 + 0x188), arg2, arg3 & 0xffffffff, (int64_t)&var_8h, 
                  CONCAT71(var_48h._1_7_, bVar7), CONCAT44(var_40h._4_4_, (int32_t)arg4), 
                  CONCAT71(var_38h._1_7_, (undefined)arg_28h));
    func_0x000180180f10(arg1, *(undefined8 *)(arg1 + 0x188), uVar2);
    return;
}

// ============================================================
// Function: FUN_180189bd8
// Address: 0x180189bd8
// Size: 84 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180189b10(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_80h)
{
    uint64_t uVar1;
    uint32_t uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    uint32_t uVar6;
    bool bVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    var_8h._0_4_ = 0;
    bVar7 = *(int32_t *)(arg1 + 0x178) == 0;
    if (bVar7) {
        var_8h._0_4_ = func_0x000180472118();
    }
    uVar2 = func_0x000180189890(arg3 & 0xffffffff, bVar7);
    uVar1 = *(uint64_t *)(arg1 + 400);
    if (uVar1 < (uint64_t)(int64_t)(int32_t)uVar2) {
        uVar5 = 1;
        if (1 < uVar2) {
            uVar6 = uVar2 - 1;
            iVar4 = 1;
            while (uVar6 = uVar6 >> 1, uVar6 != 0) {
                iVar4 = iVar4 + 1;
            }
            for (; iVar4 != 0; iVar4 = iVar4 + -1) {
                uVar5 = (uint64_t)(uint32_t)((int32_t)uVar5 * 2);
            }
        }
        if (uVar5 != uVar1) {
            if (*(int64_t *)(arg1 + 0x188) == 0) {
                uVar3 = func_0x0001801813b0(uVar5);
            } else {
                uVar3 = func_0x000180181320(*(int64_t *)(arg1 + 0x188), uVar5, uVar1);
            }
            *(undefined8 *)(arg1 + 0x188) = uVar3;
            *(uint64_t *)(arg1 + 400) = uVar5;
            *(undefined *)(arg1 + 0x198) = 1;
        }
    }
    fcn.180189840(*(undefined8 *)(arg1 + 0x188), arg2, arg3 & 0xffffffff, (int64_t)&var_8h, 
                  CONCAT71(var_48h._1_7_, bVar7), CONCAT44(var_40h._4_4_, (int32_t)arg4), 
                  CONCAT71(var_38h._1_7_, (undefined)arg_28h));
    func_0x000180180f10(arg1, *(undefined8 *)(arg1 + 0x188), uVar2);
    return;
}

// ============================================================
// Function: FUN_180189c30
// Address: 0x180189c30
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.180189c30(int64_t arg1)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar3 = func_0x000180456008(arg1 + 0x1a0);
    if (iVar3 != 0) {
        func_0x0001804542e8(5);
        pcVar1 = (code *)swi(3);
        uVar6 = (*pcVar1)();
        return uVar6;
    }
    if (*(int32_t *)(arg1 + 0x1ec) == 0x7fffffff) {
        *(undefined4 *)(arg1 + 0x1ec) = 0x7ffffffe;
        func_0x0001804542e8(6);
        pcVar1 = (code *)swi(3);
        uVar6 = (*pcVar1)();
        return uVar6;
    }
    if (*(int32_t *)(arg1 + 0x178) == 0) {
        if ((*(int64_t *)(arg1 + 8) != 0) && (*(int32_t *)(arg1 + 0x20) < 3)) {
            iVar3 = *(int32_t *)(arg1 + 0x14);
            iVar4 = func_0x000180173bc0(*(undefined8 *)(arg1 + 8));
            if (iVar3 == iVar4) {
                cVar2 = func_0x000180173be0(*(undefined8 *)(arg1 + 8));
                if (cVar2 != '\0') {
                    uVar5 = func_0x000180183bc0(*(undefined8 *)(arg1 + 8), 0x1804a8748, 6);
                    uVar6 = (uint64_t)uVar5;
                    goto code_r0x000180189d06;
                }
            }
        }
    } else if ((*(int64_t *)(arg1 + 8) != 0) && (*(int32_t *)(arg1 + 0x20) < 3)) {
        iVar3 = *(int32_t *)(arg1 + 0x14);
        iVar4 = func_0x000180173bc0(*(undefined8 *)(arg1 + 8));
        if (iVar3 == iVar4) {
            cVar2 = func_0x000180173be0(*(undefined8 *)(arg1 + 8));
            if (cVar2 != '\0') {
                uVar5 = func_0x000180183bc0(*(undefined8 *)(arg1 + 8), 0x1804a8750, 2);
                uVar6 = (uint64_t)uVar5;
                goto code_r0x000180189d06;
            }
        }
    }
    uVar6 = 0xffffffff;
code_r0x000180189d06:
    func_0x000180456010(arg1 + 0x1a0);
    return uVar6;
}

// ============================================================
// Function: FUN_180189c6c
// Address: 0x180189c6c
// Size: 184 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.180189c30(int64_t arg1)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar3 = func_0x000180456008(arg1 + 0x1a0);
    if (iVar3 != 0) {
        func_0x0001804542e8(5);
        pcVar1 = (code *)swi(3);
        uVar6 = (*pcVar1)();
        return uVar6;
    }
    if (*(int32_t *)(arg1 + 0x1ec) == 0x7fffffff) {
        *(undefined4 *)(arg1 + 0x1ec) = 0x7ffffffe;
        func_0x0001804542e8(6);
        pcVar1 = (code *)swi(3);
        uVar6 = (*pcVar1)();
        return uVar6;
    }
    if (*(int32_t *)(arg1 + 0x178) == 0) {
        if ((*(int64_t *)(arg1 + 8) != 0) && (*(int32_t *)(arg1 + 0x20) < 3)) {
            iVar3 = *(int32_t *)(arg1 + 0x14);
            iVar4 = func_0x000180173bc0(*(undefined8 *)(arg1 + 8));
            if (iVar3 == iVar4) {
                cVar2 = func_0x000180173be0(*(undefined8 *)(arg1 + 8));
                if (cVar2 != '\0') {
                    uVar5 = func_0x000180183bc0(*(undefined8 *)(arg1 + 8), 0x1804a8748, 6);
                    uVar6 = (uint64_t)uVar5;
                    goto code_r0x000180189d06;
                }
            }
        }
    } else if ((*(int64_t *)(arg1 + 8) != 0) && (*(int32_t *)(arg1 + 0x20) < 3)) {
        iVar3 = *(int32_t *)(arg1 + 0x14);
        iVar4 = func_0x000180173bc0(*(undefined8 *)(arg1 + 8));
        if (iVar3 == iVar4) {
            cVar2 = func_0x000180173be0(*(undefined8 *)(arg1 + 8));
            if (cVar2 != '\0') {
                uVar5 = func_0x000180183bc0(*(undefined8 *)(arg1 + 8), 0x1804a8750, 2);
                uVar6 = (uint64_t)uVar5;
                goto code_r0x000180189d06;
            }
        }
    }
    uVar6 = 0xffffffff;
code_r0x000180189d06:
    func_0x000180456010(arg1 + 0x1a0);
    return uVar6;
}

// ============================================================
// Function: FUN_180189d24
// Address: 0x180189d24
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.180189c30(int64_t arg1)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar3 = func_0x000180456008(arg1 + 0x1a0);
    if (iVar3 != 0) {
        func_0x0001804542e8(5);
        pcVar1 = (code *)swi(3);
        uVar6 = (*pcVar1)();
        return uVar6;
    }
    if (*(int32_t *)(arg1 + 0x1ec) == 0x7fffffff) {
        *(undefined4 *)(arg1 + 0x1ec) = 0x7ffffffe;
        func_0x0001804542e8(6);
        pcVar1 = (code *)swi(3);
        uVar6 = (*pcVar1)();
        return uVar6;
    }
    if (*(int32_t *)(arg1 + 0x178) == 0) {
        if ((*(int64_t *)(arg1 + 8) != 0) && (*(int32_t *)(arg1 + 0x20) < 3)) {
            iVar3 = *(int32_t *)(arg1 + 0x14);
            iVar4 = func_0x000180173bc0(*(undefined8 *)(arg1 + 8));
            if (iVar3 == iVar4) {
                cVar2 = func_0x000180173be0(*(undefined8 *)(arg1 + 8));
                if (cVar2 != '\0') {
                    uVar5 = func_0x000180183bc0(*(undefined8 *)(arg1 + 8), 0x1804a8748, 6);
                    uVar6 = (uint64_t)uVar5;
                    goto code_r0x000180189d06;
                }
            }
        }
    } else if ((*(int64_t *)(arg1 + 8) != 0) && (*(int32_t *)(arg1 + 0x20) < 3)) {
        iVar3 = *(int32_t *)(arg1 + 0x14);
        iVar4 = func_0x000180173bc0(*(undefined8 *)(arg1 + 8));
        if (iVar3 == iVar4) {
            cVar2 = func_0x000180173be0(*(undefined8 *)(arg1 + 8));
            if (cVar2 != '\0') {
                uVar5 = func_0x000180183bc0(*(undefined8 *)(arg1 + 8), 0x1804a8750, 2);
                uVar6 = (uint64_t)uVar5;
                goto code_r0x000180189d06;
            }
        }
    }
    uVar6 = 0xffffffff;
code_r0x000180189d06:
    func_0x000180456010(arg1 + 0x1a0);
    return uVar6;
}

// ============================================================
// Function: FUN_180189d50
// Address: 0x180189d50
// Size: 173 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180189d50(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_10h;
    
    if ((int32_t)arg2 == 1) {
        iVar1 = fcn.180459890(200);
        if (iVar1 == 0) {
            iVar1 = 0;
        } else {
            iVar1 = func_0x00018018c820(iVar1, arg1 & 0xffffffff);
        }
        if (iVar1 != 0) {
            *(undefined4 *)(iVar1 + 8) = 1;
            *(int32_t *)(iVar1 + 0xc) = (int32_t)arg1;
            return iVar1;
        }
    } else {
        iVar1 = 0;
        if ((int32_t)arg2 == 2) {
            iVar2 = func_0x00018045b9a8(0x1804a8790, 0x5c);
            uVar3 = func_0x0001801723e0();
            func_0x000180172b00(uVar3, 2, 0x1804a87f8, iVar2 + 1, 0x10, 0x1804a8780);
        }
    }
    return iVar1;
}

// ============================================================
// Function: FUN_180189e00
// Address: 0x180189e00
// Size: 111 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180189e00(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg1 + 0x28);
    uVar2 = *(uint32_t *)(arg1 + 4) & 0xf;
    if (uVar2 != 0) {
        *(uint32_t *)(iVar1 + 0xc) = uVar2;
    }
    puVar5 = (undefined8 *)(iVar1 + 0x10);
    iVar3 = *(int32_t *)(arg1 + 0x10) + 1;
    iVar4 = 0x1000000;
    if (iVar3 < 0x1000000) {
        iVar4 = iVar3;
    }
    if (*(uint64_t *)(iVar1 + 0x28) < (uint64_t)(int64_t)iVar4) {
        func_0x00018000b240(puVar5);
    }
    if ((*(uint32_t *)(iVar1 + 8) & 0xfffffffb) == 0) {
        *(undefined8 *)(iVar1 + 0x20) = 0;
        if (0xf < *(uint64_t *)(iVar1 + 0x28)) {
            puVar5 = (undefined8 *)*puVar5;
        }
        *(undefined *)puVar5 = 0;
    }
    *(undefined4 *)(iVar1 + 8) = 1;
    return 0;
}

// ============================================================
// Function: FUN_180189e70
// Address: 0x180189e70
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180189e70(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t **ppiVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    *(undefined4 *)(piVar1 + 1) = 2;
    if ((*(uint8_t *)(*piVar1 + 4) & 0x20) != 0) {
        func_0x00018018bb40(arg2);
    }
    ppiVar3 = (int64_t **)(piVar1 + 2);
    iVar2 = piVar1[4];
    if ((uint64_t)arg3 <= (uint64_t)(piVar1[5] - iVar2)) {
        piVar1[4] = iVar2 + arg3;
        if (0xf < (uint64_t)piVar1[5]) {
            ppiVar3 = (int64_t **)*ppiVar3;
        }
        fcn.180498030(iVar2 + (int64_t)ppiVar3, arg2, arg3);
        *(undefined *)(iVar2 + (int64_t)ppiVar3 + arg3) = 0;
        return 0;
    }
    func_0x00018000ee80(ppiVar3, arg3, 0, arg2, arg3);
    return 0;
}

// ============================================================
// Function: FUN_180189f20
// Address: 0x180189f20
// Size: 72 bytes
// ============================================================
undefined8 fcn.180189f20(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    *(undefined4 *)(piVar1 + 1) = 3;
    if ((*(uint8_t *)(*piVar1 + 4) & 0x10) != 0) {
        piVar2 = (int64_t *)piVar1[0xd];
        *(undefined4 *)(piVar1 + 1) = 4;
        if (piVar2 != (int64_t *)0x0) {
            var_8h._0_4_ = *(undefined4 *)((int64_t)piVar1 + 0xc);
            (**(code **)(*piVar2 + 0x10))(piVar2, &var_8h, piVar1 + 2);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180189f70
// Address: 0x180189f70
// Size: 95 bytes
// ============================================================
int64_t fcn.180189f70(int64_t arg1)
{
    undefined8 uVar1;
    
    *(undefined (*) [16])(arg1 + 0x10) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x20) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0xf;
    *(undefined *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x68) = 0;
    uVar1 = fcn.18046d050(0x30);
    *(undefined8 *)arg1 = uVar1;
    fcn.18018bea0(uVar1);
    *(int64_t *)(*(int64_t *)arg1 + 0x28) = arg1;
    *(undefined4 *)(arg1 + 8) = 0;
    *(undefined4 *)(arg1 + 0xc) = 8;
    return arg1;
}

// ============================================================
// Function: FUN_180189fd0
// Address: 0x180189fd0
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180189fd0(int64_t arg1)
{
    int64_t iVar1;
    int64_t *piVar2;
    code *pcVar3;
    int64_t iVar4;
    undefined *puVar5;
    int64_t var_8h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    if (*(int64_t *)arg1 != 0) {
        func_0x000180460d90();
        *(undefined8 *)arg1 = 0;
    }
    piVar2 = *(int64_t **)(arg1 + 0x68);
    if (piVar2 != (int64_t *)0x0) {
        (**(code **)(*piVar2 + 0x20))(piVar2, piVar2 != (int64_t *)(arg1 + 0x30));
        *(undefined8 *)(arg1 + 0x68) = 0;
    }
    if (0xf < *(uint64_t *)(arg1 + 0x28)) {
        iVar1 = *(int64_t *)(arg1 + 0x10);
        iVar4 = iVar1;
        puVar5 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg1 + 0x28) + 1) &&
           (iVar4 = *(int64_t *)(iVar1 + -8), puVar5 = auStack_28, 0x1f < (iVar1 - iVar4) - 8U)) {
            pcVar3 = (code *)swi(0x29);
            iVar4 = (*pcVar3)(5);
            puVar5 = auStack_20;
        }
        *(undefined8 *)(puVar5 + -8) = 0x180004e88;
        fcn.180459c3c(iVar4);
    }
    *(undefined8 *)(arg1 + 0x20) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0xf;
    *(undefined *)(int64_t *)(arg1 + 0x10) = 0;
    return;
}

// ============================================================
// Function: FUN_18018a050
// Address: 0x18018a050
// Size: 287 bytes
// ============================================================
undefined8 fcn.18018a050(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    uint32_t uVar2;
    undefined auVar3 [12];
    uint32_t uVar4;
    int32_t iVar5;
    undefined8 *puVar6;
    undefined8 uVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    int64_t var_38h;
    int64_t var_30h;
    
    puVar6 = *(undefined8 **)(arg1 + 0x148);
    uVar9 = (uint32_t)arg2;
    if (puVar6 == (undefined8 *)0x0) {
        puVar6 = (undefined8 *)func_0x0001801813b0(0x20);
        uVar7 = func_0x00018018d1f0(0x40);
        *puVar6 = uVar7;
        puVar6[2] = 0;
        puVar6[3] = 0x40;
        uVar7 = func_0x0001801813b0(0x400);
        puVar6[1] = uVar7;
        *(undefined8 **)(arg1 + 0x148) = puVar6;
    }
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x118) + (int64_t)(int32_t)uVar9 * 8);
    auVar3._4_8_ = 0;
    auVar3._0_4_ = uVar9;
    _var_38h = auVar3 << 0x40;
    uVar8 = *(uint32_t *)(iVar1 + 0x50) & 1;
    uVar4 = (uint32_t)(uVar8 != 0);
    if ((*(uint8_t *)(iVar1 + 0x50) & 4) != 0) {
        uVar8 = uVar8 | 4;
        uVar4 = uVar8;
    }
    if ((arg3 & 1U) != 0) {
        uVar4 = uVar8 | 1;
    }
    uVar2 = uVar8 | 1;
    if ((arg3 & 1U) == 0) {
        uVar2 = uVar8;
    }
    if ((arg3 & 4U) != 0) {
        uVar4 = uVar2 | 4;
    }
    stack0xffffffffffffffcc = SUB128(_var_38h, 4);
    var_38h._0_4_ = uVar4;
    var_30h._4_4_ = 0;
    iVar5 = *(int32_t *)(iVar1 + 0x50);
    func_0x00018018d220(*puVar6, (iVar5 != 0) + '\x01', (int64_t)(int32_t)uVar9, &var_38h);
    if (iVar5 == 0) {
        if (puVar6[2] == puVar6[3]) {
            iVar5 = (int32_t)puVar6[3] * 2;
            if (iVar5 == 0) {
                iVar5 = 0x10;
            }
            uVar7 = func_0x000180181320(puVar6[1], (int64_t)iVar5 << 4, puVar6[3] << 4);
            puVar6[1] = uVar7;
            puVar6[3] = (int64_t)iVar5;
        }
        puVar6[2] = puVar6[2] + 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_18018a170
// Address: 0x18018a170
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18018a170(int64_t arg1)
{
    undefined8 *puVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar1 = *(undefined8 **)(arg1 + 0x148);
    if (puVar1 != (undefined8 *)0x0) {
        func_0x00018018d070(*puVar1);
        if (puVar1[1] != 0) {
            func_0x000180180fe0();
            puVar1[1] = 0;
        }
        puVar1[3] = 0;
        puVar1[2] = 0;
        if (*(int64_t *)(arg1 + 0x148) != 0) {
            func_0x000180180fe0();
            *(undefined8 *)(arg1 + 0x148) = 0;
        }
        return 0;
    }
    return 0;
}

// ============================================================
// Function: FUN_18018a18c
// Address: 0x18018a18c
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18018a170(int64_t arg1)
{
    undefined8 *puVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar1 = *(undefined8 **)(arg1 + 0x148);
    if (puVar1 != (undefined8 *)0x0) {
        func_0x00018018d070(*puVar1);
        if (puVar1[1] != 0) {
            func_0x000180180fe0();
            puVar1[1] = 0;
        }
        puVar1[3] = 0;
        puVar1[2] = 0;
        if (*(int64_t *)(arg1 + 0x148) != 0) {
            func_0x000180180fe0();
            *(undefined8 *)(arg1 + 0x148) = 0;
        }
        return 0;
    }
    return 0;
}

// ============================================================
// Function: FUN_18018a1dc
// Address: 0x18018a1dc
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18018a170(int64_t arg1)
{
    undefined8 *puVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar1 = *(undefined8 **)(arg1 + 0x148);
    if (puVar1 != (undefined8 *)0x0) {
        func_0x00018018d070(*puVar1);
        if (puVar1[1] != 0) {
            func_0x000180180fe0();
            puVar1[1] = 0;
        }
        puVar1[3] = 0;
        puVar1[2] = 0;
        if (*(int64_t *)(arg1 + 0x148) != 0) {
            func_0x000180180fe0();
            *(undefined8 *)(arg1 + 0x148) = 0;
        }
        return 0;
    }
    return 0;
}

// ============================================================
// Function: FUN_18018a1f0
// Address: 0x18018a1f0
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18018a1f0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    undefined8 *puVar1;
    int64_t iVar2;
    uint32_t uVar3;
    undefined auVar4 [12];
    uint32_t uVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_10h;
    
    puVar1 = *(undefined8 **)(arg1 + 0x148);
    if (puVar1 != (undefined8 *)0x0) {
        uVar6 = (uint32_t)arg2;
        iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 0x118) + (int64_t)(int32_t)uVar6 * 8);
        auVar4._4_8_ = 0;
        auVar4._0_4_ = uVar6;
        _var_18h = auVar4 << 0x40;
        uVar7 = *(uint32_t *)(iVar2 + 0x50) & 1;
        uVar3 = (uint32_t)(uVar7 != 0);
        if ((*(uint8_t *)(iVar2 + 0x50) & 4) != 0) {
            uVar7 = uVar7 | 4;
            uVar3 = uVar7;
        }
        if ((arg3 & 1U) != 0) {
            uVar3 = uVar7 & 0xfffffffe;
        }
        uVar5 = uVar7 & 0xfffffffe;
        if ((arg3 & 1U) == 0) {
            uVar5 = uVar7;
        }
        if ((arg3 & 4U) != 0) {
            uVar3 = uVar5 & 0xfffffffb;
        }
        stack0xffffffffffffffec = SUB128(_var_18h, 4);
        var_18h._0_4_ = uVar3;
        var_10h._4_4_ = 0;
        uVar3 = uVar5 & 0xfffffffb;
        if ((arg3 & 4U) == 0) {
            uVar3 = uVar5;
        }
        func_0x00018018d220(*puVar1, 3 - (uint32_t)(uVar3 != 0), (int64_t)(int32_t)uVar6, &var_18h);
        if (uVar3 == 0) {
            puVar1[2] = puVar1[2] + -1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18018a219
// Address: 0x18018a219
// Size: 126 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18018a1f0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    undefined8 *puVar1;
    int64_t iVar2;
    uint32_t uVar3;
    undefined auVar4 [12];
    uint32_t uVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_10h;
    
    puVar1 = *(undefined8 **)(arg1 + 0x148);
    if (puVar1 != (undefined8 *)0x0) {
        uVar6 = (uint32_t)arg2;
        iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 0x118) + (int64_t)(int32_t)uVar6 * 8);
        auVar4._4_8_ = 0;
        auVar4._0_4_ = uVar6;
        _var_18h = auVar4 << 0x40;
        uVar7 = *(uint32_t *)(iVar2 + 0x50) & 1;
        uVar3 = (uint32_t)(uVar7 != 0);
        if ((*(uint8_t *)(iVar2 + 0x50) & 4) != 0) {
            uVar7 = uVar7 | 4;
            uVar3 = uVar7;
        }
        if ((arg3 & 1U) != 0) {
            uVar3 = uVar7 & 0xfffffffe;
        }
        uVar5 = uVar7 & 0xfffffffe;
        if ((arg3 & 1U) == 0) {
            uVar5 = uVar7;
        }
        if ((arg3 & 4U) != 0) {
            uVar3 = uVar5 & 0xfffffffb;
        }
        stack0xffffffffffffffec = SUB128(_var_18h, 4);
        var_18h._0_4_ = uVar3;
        var_10h._4_4_ = 0;
        uVar3 = uVar5 & 0xfffffffb;
        if ((arg3 & 4U) == 0) {
            uVar3 = uVar5;
        }
        func_0x00018018d220(*puVar1, 3 - (uint32_t)(uVar3 != 0), (int64_t)(int32_t)uVar6, &var_18h);
        if (uVar3 == 0) {
            puVar1[2] = puVar1[2] + -1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18018a297
// Address: 0x18018a297
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18018a1f0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    undefined8 *puVar1;
    int64_t iVar2;
    uint32_t uVar3;
    undefined auVar4 [12];
    uint32_t uVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_10h;
    
    puVar1 = *(undefined8 **)(arg1 + 0x148);
    if (puVar1 != (undefined8 *)0x0) {
        uVar6 = (uint32_t)arg2;
        iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 0x118) + (int64_t)(int32_t)uVar6 * 8);
        auVar4._4_8_ = 0;
        auVar4._0_4_ = uVar6;
        _var_18h = auVar4 << 0x40;
        uVar7 = *(uint32_t *)(iVar2 + 0x50) & 1;
        uVar3 = (uint32_t)(uVar7 != 0);
        if ((*(uint8_t *)(iVar2 + 0x50) & 4) != 0) {
            uVar7 = uVar7 | 4;
            uVar3 = uVar7;
        }
        if ((arg3 & 1U) != 0) {
            uVar3 = uVar7 & 0xfffffffe;
        }
        uVar5 = uVar7 & 0xfffffffe;
        if ((arg3 & 1U) == 0) {
            uVar5 = uVar7;
        }
        if ((arg3 & 4U) != 0) {
            uVar3 = uVar5 & 0xfffffffb;
        }
        stack0xffffffffffffffec = SUB128(_var_18h, 4);
        var_18h._0_4_ = uVar3;
        var_10h._4_4_ = 0;
        uVar3 = uVar5 & 0xfffffffb;
        if ((arg3 & 4U) == 0) {
            uVar3 = uVar5;
        }
        func_0x00018018d220(*puVar1, 3 - (uint32_t)(uVar3 != 0), (int64_t)(int32_t)uVar6, &var_18h);
        if (uVar3 == 0) {
            puVar1[2] = puVar1[2] + -1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18018a2b0
// Address: 0x18018a2b0
// Size: 304 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int32_t fcn.18018a2b0(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    int64_t *piVar3;
    int32_t iVar4;
    int32_t *piVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar2 = *(undefined8 **)(arg1 + 0x148);
    if ((puVar2 != (undefined8 *)0x0) && (puVar2[2] != 0)) {
        iVar4 = fcn.18018d3a0(*puVar2, puVar2[1]);
        if (iVar4 < 0) {
            piVar5 = (int32_t *)fcn.18046b77c();
            if (*piVar5 != 4) {
                fcn.18047208c(0x1804a7608);
                return iVar4;
            }
        } else if (iVar4 != 0) {
            iVar7 = 0;
            iVar6 = 0;
            if (puVar2[2] != 0) {
                do {
                    uVar1 = *(uint32_t *)(puVar2[1] + (int64_t)iVar6 * 0x10);
                    if (uVar1 != 0) {
                        iVar7 = iVar7 + 1;
                        piVar3 = *(int64_t **)
                                  (*(int64_t *)(arg1 + 0x118) +
                                  (int64_t)*(int32_t *)(puVar2[1] + 8 + (int64_t)iVar6 * 0x10) * 8);
                        if (piVar3 != (int64_t *)0x0) {
                            if ((uVar1 & 0x19) != 0) {
                                *(uint32_t *)((int64_t)piVar3 + 0x54) = *(uint32_t *)((int64_t)piVar3 + 0x54) | 1;
                            }
                            if ((uVar1 & 0x1c) != 0) {
                                *(uint32_t *)((int64_t)piVar3 + 0x54) = *(uint32_t *)((int64_t)piVar3 + 0x54) | 4;
                            }
                            if ((*(uint32_t *)((int64_t)piVar3 + 0x3c) & 4) == 0) {
                                *(uint32_t *)((int64_t)piVar3 + 0x3c) = *(uint32_t *)((int64_t)piVar3 + 0x3c) | 4;
                                *(int32_t *)(*piVar3 + 0x48) = *(int32_t *)(*piVar3 + 0x48) + 1;
                                piVar3[6] = *(int64_t *)(*piVar3 + 0x78 + (int64_t)*(int32_t *)(piVar3 + 7) * 8);
                                *(int64_t **)(*piVar3 + (int64_t)*(int32_t *)(piVar3 + 7) * 8 + 0x78) = piVar3;
                            }
                        }
                    }
                } while ((iVar7 != iVar4) && (iVar6 = iVar6 + 1, (uint64_t)(int64_t)iVar6 < (uint64_t)puVar2[2]));
            }
            return iVar7;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18018a3e0
// Address: 0x18018a3e0
// Size: 807 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_3fh
// WARNING: [rz-ghidra] Detected overlap for variable var_3eh
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3bh
// WARNING: [rz-ghidra] Detected overlap for variable var_3ah
// WARNING: [rz-ghidra] Detected overlap for variable var_3dh
// WARNING: [rz-ghidra] Detected overlap for variable var_39h

void fcn.18018a3e0(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int64_t iVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    uint64_t uVar5;
    
    var_48h._0_1_ = 0x80;
    piVar1 = (int32_t *)(arg2 + 0x18);
    iVar6 = *piVar1;
    uVar4 = *(uint32_t *)(arg2 + 0x14);
    var_40h._0_1_ = (undefined)((uint32_t)iVar6 >> 0x18);
    var_40h._1_1_ = (undefined)((uint32_t)iVar6 >> 0x10);
    var_40h._2_1_ = (undefined)((uint32_t)iVar6 >> 8);
    var_40h._4_1_ = (undefined)(uVar4 >> 0x18);
    var_40h._5_1_ = (undefined)(uVar4 >> 0x10);
    var_40h._6_1_ = (undefined)(uVar4 >> 8);
    var_40h._3_1_ = (undefined)iVar6;
    var_40h._7_1_ = (undefined)uVar4;
    *(uint32_t *)(arg2 + 0x14) = uVar4 + 8;
    if (uVar4 + 8 < uVar4) {
        iVar6 = iVar6 + 1;
    }
    iVar2 = arg2 + 0x1c;
    uVar4 = uVar4 >> 3 & 0x3f;
    uVar5 = (uint64_t)uVar4;
    *piVar1 = iVar6;
    if (uVar4 + 1 < 0x40) {
        uVar4 = 0;
    } else {
        uVar7 = -uVar4 + 0x40;
        fcn.180498030(uVar5 + 0x1c + arg2, &var_48h, uVar7);
        func_0x00018018a740(arg2, iVar2);
        uVar3 = -uVar4;
        while (uVar4 = uVar7, uVar3 == 0xffffff81) {
            func_0x00018018a740(arg2, (int64_t)&var_48h + (uint64_t)uVar4);
            uVar7 = uVar4 + 0x40;
            uVar3 = uVar4;
        }
        uVar5 = 0;
    }
    fcn.180498030(uVar5 + 0x1c + arg2, (int64_t)&var_48h + (uint64_t)uVar4, 1 - uVar4);
    uVar4 = *(uint32_t *)(arg2 + 0x14);
    while ((uVar4 & 0x1f8) != 0x1c0) {
        var_48h._0_1_ = 0;
        *(uint32_t *)(arg2 + 0x14) = uVar4 + 8;
        if (uVar4 + 8 < uVar4) {
            *piVar1 = *piVar1 + 1;
        }
        uVar4 = uVar4 >> 3 & 0x3f;
        uVar5 = (uint64_t)uVar4;
        if (uVar4 + 1 < 0x40) {
            uVar4 = 0;
        } else {
            uVar7 = -uVar4 + 0x40;
            fcn.180498030(uVar5 + 0x1c + arg2, &var_48h, uVar7);
            func_0x00018018a740(arg2, iVar2);
            uVar3 = -uVar4;
            while (uVar4 = uVar7, uVar3 == 0xffffff81) {
                func_0x00018018a740(arg2, (int64_t)&var_48h + (uint64_t)uVar4);
                uVar7 = uVar4 + 0x40;
                uVar3 = uVar4;
            }
            uVar5 = 0;
        }
        fcn.180498030(uVar5 + iVar2, (int64_t)&var_48h + (uint64_t)uVar4, 1 - uVar4);
        uVar4 = *(uint32_t *)(arg2 + 0x14);
    }
    *(uint32_t *)(arg2 + 0x14) = uVar4 + 0x40;
    if (uVar4 + 0x40 < uVar4) {
        *piVar1 = *piVar1 + 1;
    }
    uVar4 = uVar4 >> 3 & 0x3f;
    uVar5 = (uint64_t)uVar4;
    if (uVar4 + 8 < 0x40) {
        uVar4 = 0;
    } else {
        uVar7 = -uVar4 + 0x40;
        fcn.180498030(uVar5 + 0x1c + arg2, &var_40h, uVar7);
        func_0x00018018a740(arg2, iVar2);
        uVar3 = -uVar4;
        while (uVar4 = uVar7, uVar3 + 0x7f < 8) {
            func_0x00018018a740(arg2, (int64_t)&var_40h + (uint64_t)uVar4);
            uVar7 = uVar4 + 0x40;
            uVar3 = uVar4;
        }
        uVar5 = 0;
    }
    fcn.180498030(uVar5 + 0x1c + arg2, (int64_t)&var_40h + (uint64_t)uVar4, 8 - uVar4);
    *(undefined *)arg1 = *(undefined *)(arg2 + 3);
    *(undefined *)(arg1 + 1) = *(undefined *)(arg2 + 2);
    *(char *)(arg1 + 2) = (char)((uint32_t)*(undefined4 *)arg2 >> 8);
    *(undefined *)(arg1 + 3) = *(undefined *)arg2;
    *(undefined *)(arg1 + 4) = *(undefined *)(arg2 + 7);
    *(undefined *)(arg1 + 5) = *(undefined *)(arg2 + 6);
    *(char *)(arg1 + 6) = (char)((uint32_t)*(undefined4 *)(arg2 + 4) >> 8);
    *(undefined *)(arg1 + 7) = *(undefined *)(arg2 + 4);
    *(undefined *)(arg1 + 8) = *(undefined *)(arg2 + 0xb);
    *(undefined *)(arg1 + 9) = *(undefined *)(arg2 + 10);
    *(char *)(arg1 + 10) = (char)((uint32_t)*(undefined4 *)(arg2 + 8) >> 8);
    *(undefined *)(arg1 + 0xb) = *(undefined *)(arg2 + 8);
    *(undefined *)(arg1 + 0xc) = *(undefined *)(arg2 + 0xf);
    *(undefined *)(arg1 + 0xd) = *(undefined *)(arg2 + 0xe);
    *(char *)(arg1 + 0xe) = (char)((uint32_t)*(undefined4 *)(arg2 + 0xc) >> 8);
    *(undefined *)(arg1 + 0xf) = *(undefined *)(arg2 + 0xc);
    *(undefined *)(arg1 + 0x10) = *(undefined *)(arg2 + 0x13);
    *(undefined *)(arg1 + 0x11) = *(undefined *)(arg2 + 0x12);
    *(char *)(arg1 + 0x12) = (char)((uint32_t)*(undefined4 *)(arg2 + 0x10) >> 8);
    *(undefined *)(arg1 + 0x13) = *(undefined *)(arg2 + 0x10);
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined (*) [16])(arg2 + 0x10) = ZEXT816(0);
    *(undefined (*) [16])(arg2 + 0x20) = ZEXT816(0);
    *(undefined (*) [16])(arg2 + 0x30) = ZEXT816(0);
    *(undefined (*) [16])(arg2 + 0x40) = ZEXT816(0);
    *(undefined (*) [16])(arg2 + 0x4c) = ZEXT816(0);
    return;
}

