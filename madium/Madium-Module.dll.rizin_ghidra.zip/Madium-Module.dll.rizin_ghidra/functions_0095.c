// Chunk 95 - 50 functions

// ============================================================
// Function: FUN_1801422c0
// Address: 0x1801422c0
// Size: 42 bytes
// ============================================================
void fcn.1801422c0(int64_t arg1, int64_t arg2, int64_t arg_30h)
{
    int16_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar6 = (int64_t)*(int16_t *)(arg2 + 0xa38);
    if (*(int16_t *)(arg2 + 0xa38) != 0) {
        iVar2 = *(int32_t *)(arg2 + 0x18 + iVar6 * 0x10);
        iVar3 = *(int32_t *)(arg2 + 0x1c + iVar6 * 0x10);
        iVar4 = *(int32_t *)(arg2 + 0x10 + iVar6 * 0x10);
        iVar9 = (int64_t)*(int16_t *)(arg2 + 0xa3a) * 0x10 + arg2;
        iVar5 = *(int32_t *)(arg2 + 0x14 + iVar6 * 0x10);
        *(undefined4 *)(iVar9 + 0x1c) = 0xffffffff;
        *(int32_t *)(iVar9 + 0x14) = iVar2;
        *(int32_t *)(iVar9 + 0x18) = iVar5;
        *(int32_t *)(iVar9 + 0x10) = iVar4;
        if (iVar2 != 0) {
            iVar10 = *(int32_t *)(arg2 + 0xa3c) + iVar2;
            if (iVar10 < 999) {
                iVar7 = *(int32_t *)(arg2 + 0xa40);
                if (iVar7 < iVar10) {
                    do {
                        if (*(int16_t *)(arg2 + 0xa3a) == 99) {
                            return;
                        }
                        if (*(int16_t *)(arg2 + 0xa3a) < 99) {
                            if (-1 < *(int32_t *)(arg2 + 0x64c)) {
                                iVar10 = *(int32_t *)(arg2 + 0x644);
                                iVar7 = iVar7 + iVar10;
                                *(int32_t *)(arg2 + 0xa40) = iVar7;
                                func_0x000180498030(arg2 + 0x650 + (int64_t)iVar7, 
                                                    ((int64_t)iVar7 - (int64_t)iVar10) + 0x650 + arg2, 
                                                    (int64_t)(999 - iVar7));
                                for (iVar7 = (int32_t)*(int16_t *)(arg2 + 0xa3a); iVar7 < 0x62; iVar7 = iVar7 + 1) {
                                    iVar8 = *(int32_t *)(arg2 + 0x2c + (int64_t)iVar7 * 0x10);
                                    if (-1 < iVar8) {
                                        *(int32_t *)(arg2 + 0x2c + (int64_t)iVar7 * 0x10) = iVar8 + iVar10;
                                    }
                                }
                            }
                            iVar6 = (int64_t)*(int16_t *)(arg2 + 0xa3a) * 0x10 + 0x20 + arg2;
                            func_0x000180498030(iVar6 + 0x10, iVar6, (int64_t)(0x62 - *(int16_t *)(arg2 + 0xa3a)) << 4);
                            *(int16_t *)(arg2 + 0xa3a) = *(int16_t *)(arg2 + 0xa3a) + 1;
                        }
                        iVar7 = *(int32_t *)(arg2 + 0xa40);
                    } while (iVar7 < *(int32_t *)(arg2 + 0xa3c) + iVar2);
                }
                iVar1 = *(int16_t *)(arg2 + 0xa3a);
                iVar10 = 0;
                *(int32_t *)(arg2 + 0x1c + (int64_t)iVar1 * 0x10) = iVar7 - iVar2;
                *(int32_t *)(arg2 + 0xa40) = *(int32_t *)(arg2 + 0xa40) - iVar2;
                if (0 < iVar2) {
                    do {
                        iVar7 = iVar4 + iVar10;
                        iVar8 = *(int32_t *)(arg2 + 0x1c + (int64_t)iVar1 * 0x10) + iVar10;
                        iVar10 = iVar10 + 1;
                        *(undefined *)((int64_t)iVar8 + 0x650 + arg2) =
                             *(undefined *)((int64_t)iVar7 + *(int64_t *)(arg1 + 0x20));
                    } while (iVar10 < iVar2);
                }
            } else {
                *(undefined4 *)(iVar9 + 0x14) = 0;
            }
            iVar6 = (int64_t)iVar4 + *(int64_t *)(arg1 + 0x30);
            func_0x000180498030(iVar6, iVar6 + iVar2, (int64_t)(((*(int32_t *)(arg1 + 0x18) - iVar2) - iVar4) + 1));
            *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) - iVar2;
            *(undefined2 *)(arg1 + 0x73) = 0x101;
        }
        if (iVar5 != 0) {
            iVar5 = func_0x000180140a70(arg1, iVar4, arg2 + 0x650 + (int64_t)iVar3, iVar5);
            *(int32_t *)(arg2 + 0xa3c) = *(int32_t *)(arg2 + 0xa3c) - iVar5;
        }
        *(int32_t *)arg2 = iVar5 + iVar4;
        *(int16_t *)(arg2 + 0xa38) = *(int16_t *)(arg2 + 0xa38) + -1;
        *(int16_t *)(arg2 + 0xa3a) = *(int16_t *)(arg2 + 0xa3a) + -1;
    }
    return;
}

// ============================================================
// Function: FUN_1801422ea
// Address: 0x1801422ea
// Size: 600 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Removing arg arg_73h because it doesn't fit into ProtoModel

void fcn.1801422c0(int64_t arg1, int64_t arg2, int64_t arg_30h)
{
    int16_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar6 = (int64_t)*(int16_t *)(arg2 + 0xa38);
    if (*(int16_t *)(arg2 + 0xa38) != 0) {
        iVar2 = *(int32_t *)(arg2 + 0x18 + iVar6 * 0x10);
        iVar3 = *(int32_t *)(arg2 + 0x1c + iVar6 * 0x10);
        iVar4 = *(int32_t *)(arg2 + 0x10 + iVar6 * 0x10);
        iVar9 = (int64_t)*(int16_t *)(arg2 + 0xa3a) * 0x10 + arg2;
        iVar5 = *(int32_t *)(arg2 + 0x14 + iVar6 * 0x10);
        *(undefined4 *)(iVar9 + 0x1c) = 0xffffffff;
        *(int32_t *)(iVar9 + 0x14) = iVar2;
        *(int32_t *)(iVar9 + 0x18) = iVar5;
        *(int32_t *)(iVar9 + 0x10) = iVar4;
        if (iVar2 != 0) {
            iVar10 = *(int32_t *)(arg2 + 0xa3c) + iVar2;
            if (iVar10 < 999) {
                iVar7 = *(int32_t *)(arg2 + 0xa40);
                if (iVar7 < iVar10) {
                    do {
                        if (*(int16_t *)(arg2 + 0xa3a) == 99) {
                            return;
                        }
                        if (*(int16_t *)(arg2 + 0xa3a) < 99) {
                            if (-1 < *(int32_t *)(arg2 + 0x64c)) {
                                iVar10 = *(int32_t *)(arg2 + 0x644);
                                iVar7 = iVar7 + iVar10;
                                *(int32_t *)(arg2 + 0xa40) = iVar7;
                                func_0x000180498030(arg2 + 0x650 + (int64_t)iVar7, 
                                                    ((int64_t)iVar7 - (int64_t)iVar10) + 0x650 + arg2, 
                                                    (int64_t)(999 - iVar7));
                                for (iVar7 = (int32_t)*(int16_t *)(arg2 + 0xa3a); iVar7 < 0x62; iVar7 = iVar7 + 1) {
                                    iVar8 = *(int32_t *)(arg2 + 0x2c + (int64_t)iVar7 * 0x10);
                                    if (-1 < iVar8) {
                                        *(int32_t *)(arg2 + 0x2c + (int64_t)iVar7 * 0x10) = iVar8 + iVar10;
                                    }
                                }
                            }
                            iVar6 = (int64_t)*(int16_t *)(arg2 + 0xa3a) * 0x10 + 0x20 + arg2;
                            func_0x000180498030(iVar6 + 0x10, iVar6, (int64_t)(0x62 - *(int16_t *)(arg2 + 0xa3a)) << 4);
                            *(int16_t *)(arg2 + 0xa3a) = *(int16_t *)(arg2 + 0xa3a) + 1;
                        }
                        iVar7 = *(int32_t *)(arg2 + 0xa40);
                    } while (iVar7 < *(int32_t *)(arg2 + 0xa3c) + iVar2);
                }
                iVar1 = *(int16_t *)(arg2 + 0xa3a);
                iVar10 = 0;
                *(int32_t *)(arg2 + 0x1c + (int64_t)iVar1 * 0x10) = iVar7 - iVar2;
                *(int32_t *)(arg2 + 0xa40) = *(int32_t *)(arg2 + 0xa40) - iVar2;
                if (0 < iVar2) {
                    do {
                        iVar7 = iVar4 + iVar10;
                        iVar8 = *(int32_t *)(arg2 + 0x1c + (int64_t)iVar1 * 0x10) + iVar10;
                        iVar10 = iVar10 + 1;
                        *(undefined *)((int64_t)iVar8 + 0x650 + arg2) =
                             *(undefined *)((int64_t)iVar7 + *(int64_t *)(arg1 + 0x20));
                    } while (iVar10 < iVar2);
                }
            } else {
                *(undefined4 *)(iVar9 + 0x14) = 0;
            }
            iVar6 = (int64_t)iVar4 + *(int64_t *)(arg1 + 0x30);
            func_0x000180498030(iVar6, iVar6 + iVar2, (int64_t)(((*(int32_t *)(arg1 + 0x18) - iVar2) - iVar4) + 1));
            *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) - iVar2;
            *(undefined2 *)(arg1 + 0x73) = 0x101;
        }
        if (iVar5 != 0) {
            iVar5 = func_0x000180140a70(arg1, iVar4, arg2 + 0x650 + (int64_t)iVar3, iVar5);
            *(int32_t *)(arg2 + 0xa3c) = *(int32_t *)(arg2 + 0xa3c) - iVar5;
        }
        *(int32_t *)arg2 = iVar5 + iVar4;
        *(int16_t *)(arg2 + 0xa38) = *(int16_t *)(arg2 + 0xa38) + -1;
        *(int16_t *)(arg2 + 0xa3a) = *(int16_t *)(arg2 + 0xa3a) + -1;
    }
    return;
}

// ============================================================
// Function: FUN_180142542
// Address: 0x180142542
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Removing arg arg_73h because it doesn't fit into ProtoModel

void fcn.1801422c0(int64_t arg1, int64_t arg2, int64_t arg_30h)
{
    int16_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar6 = (int64_t)*(int16_t *)(arg2 + 0xa38);
    if (*(int16_t *)(arg2 + 0xa38) != 0) {
        iVar2 = *(int32_t *)(arg2 + 0x18 + iVar6 * 0x10);
        iVar3 = *(int32_t *)(arg2 + 0x1c + iVar6 * 0x10);
        iVar4 = *(int32_t *)(arg2 + 0x10 + iVar6 * 0x10);
        iVar9 = (int64_t)*(int16_t *)(arg2 + 0xa3a) * 0x10 + arg2;
        iVar5 = *(int32_t *)(arg2 + 0x14 + iVar6 * 0x10);
        *(undefined4 *)(iVar9 + 0x1c) = 0xffffffff;
        *(int32_t *)(iVar9 + 0x14) = iVar2;
        *(int32_t *)(iVar9 + 0x18) = iVar5;
        *(int32_t *)(iVar9 + 0x10) = iVar4;
        if (iVar2 != 0) {
            iVar10 = *(int32_t *)(arg2 + 0xa3c) + iVar2;
            if (iVar10 < 999) {
                iVar7 = *(int32_t *)(arg2 + 0xa40);
                if (iVar7 < iVar10) {
                    do {
                        if (*(int16_t *)(arg2 + 0xa3a) == 99) {
                            return;
                        }
                        if (*(int16_t *)(arg2 + 0xa3a) < 99) {
                            if (-1 < *(int32_t *)(arg2 + 0x64c)) {
                                iVar10 = *(int32_t *)(arg2 + 0x644);
                                iVar7 = iVar7 + iVar10;
                                *(int32_t *)(arg2 + 0xa40) = iVar7;
                                func_0x000180498030(arg2 + 0x650 + (int64_t)iVar7, 
                                                    ((int64_t)iVar7 - (int64_t)iVar10) + 0x650 + arg2, 
                                                    (int64_t)(999 - iVar7));
                                for (iVar7 = (int32_t)*(int16_t *)(arg2 + 0xa3a); iVar7 < 0x62; iVar7 = iVar7 + 1) {
                                    iVar8 = *(int32_t *)(arg2 + 0x2c + (int64_t)iVar7 * 0x10);
                                    if (-1 < iVar8) {
                                        *(int32_t *)(arg2 + 0x2c + (int64_t)iVar7 * 0x10) = iVar8 + iVar10;
                                    }
                                }
                            }
                            iVar6 = (int64_t)*(int16_t *)(arg2 + 0xa3a) * 0x10 + 0x20 + arg2;
                            func_0x000180498030(iVar6 + 0x10, iVar6, (int64_t)(0x62 - *(int16_t *)(arg2 + 0xa3a)) << 4);
                            *(int16_t *)(arg2 + 0xa3a) = *(int16_t *)(arg2 + 0xa3a) + 1;
                        }
                        iVar7 = *(int32_t *)(arg2 + 0xa40);
                    } while (iVar7 < *(int32_t *)(arg2 + 0xa3c) + iVar2);
                }
                iVar1 = *(int16_t *)(arg2 + 0xa3a);
                iVar10 = 0;
                *(int32_t *)(arg2 + 0x1c + (int64_t)iVar1 * 0x10) = iVar7 - iVar2;
                *(int32_t *)(arg2 + 0xa40) = *(int32_t *)(arg2 + 0xa40) - iVar2;
                if (0 < iVar2) {
                    do {
                        iVar7 = iVar4 + iVar10;
                        iVar8 = *(int32_t *)(arg2 + 0x1c + (int64_t)iVar1 * 0x10) + iVar10;
                        iVar10 = iVar10 + 1;
                        *(undefined *)((int64_t)iVar8 + 0x650 + arg2) =
                             *(undefined *)((int64_t)iVar7 + *(int64_t *)(arg1 + 0x20));
                    } while (iVar10 < iVar2);
                }
            } else {
                *(undefined4 *)(iVar9 + 0x14) = 0;
            }
            iVar6 = (int64_t)iVar4 + *(int64_t *)(arg1 + 0x30);
            func_0x000180498030(iVar6, iVar6 + iVar2, (int64_t)(((*(int32_t *)(arg1 + 0x18) - iVar2) - iVar4) + 1));
            *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) - iVar2;
            *(undefined2 *)(arg1 + 0x73) = 0x101;
        }
        if (iVar5 != 0) {
            iVar5 = func_0x000180140a70(arg1, iVar4, arg2 + 0x650 + (int64_t)iVar3, iVar5);
            *(int32_t *)(arg2 + 0xa3c) = *(int32_t *)(arg2 + 0xa3c) - iVar5;
        }
        *(int32_t *)arg2 = iVar5 + iVar4;
        *(int16_t *)(arg2 + 0xa38) = *(int16_t *)(arg2 + 0xa38) + -1;
        *(int16_t *)(arg2 + 0xa3a) = *(int16_t *)(arg2 + 0xa3a) + -1;
    }
    return;
}

// ============================================================
// Function: FUN_180142550
// Address: 0x180142550
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180142550(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar7 = (int64_t)*(int16_t *)(arg2 + 0xa3a);
    if (*(int16_t *)(arg2 + 0xa3a) != 99) {
        iVar1 = *(int32_t *)(arg2 + 0x20 + iVar7 * 0x10);
        iVar9 = (int64_t)*(int16_t *)(arg2 + 0xa38) * 0x10 + arg2;
        iVar6 = *(int32_t *)(arg2 + 0x24 + iVar7 * 0x10);
        iVar2 = *(int32_t *)(arg2 + 0x2c + iVar7 * 0x10);
        iVar3 = *(int32_t *)(arg2 + 0x28 + iVar7 * 0x10);
        *(int32_t *)(iVar9 + 0x28) = iVar6;
        *(int32_t *)(iVar9 + 0x24) = iVar3;
        *(int32_t *)(iVar9 + 0x20) = iVar1;
        *(undefined4 *)(iVar9 + 0x2c) = 0xffffffff;
        if (iVar3 != 0) {
            iVar8 = 0;
            if (*(int32_t *)(arg2 + 0xa40) < iVar3 + *(int32_t *)(arg2 + 0xa3c)) {
                *(undefined8 *)(iVar9 + 0x24) = 0;
            } else {
                *(int32_t *)(iVar9 + 0x2c) = *(int32_t *)(arg2 + 0xa3c);
                *(int32_t *)(arg2 + 0xa3c) = *(int32_t *)(arg2 + 0xa3c) + iVar3;
                if (0 < *(int32_t *)(iVar9 + 0x24)) {
                    do {
                        iVar4 = *(int32_t *)(iVar9 + 0x20) + iVar8;
                        iVar5 = *(int32_t *)(iVar9 + 0x2c) + iVar8;
                        iVar8 = iVar8 + 1;
                        *(undefined *)((int64_t)iVar5 + 0x650 + arg2) =
                             *(undefined *)((int64_t)iVar4 + *(int64_t *)(arg1 + 0x20));
                    } while (iVar8 < *(int32_t *)(iVar9 + 0x24));
                }
            }
            iVar7 = (int64_t)iVar1 + *(int64_t *)(arg1 + 0x30);
            func_0x000180498030(iVar7, iVar7 + iVar3, (int64_t)(((*(int32_t *)(arg1 + 0x18) - iVar3) - iVar1) + 1));
            *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) - iVar3;
            *(undefined2 *)(arg1 + 0x73) = 0x101;
        }
        if (iVar6 != 0) {
            iVar6 = func_0x000180140a70(arg1, iVar1, arg2 + 0x650 + (int64_t)iVar2, iVar6);
            *(int32_t *)(arg2 + 0xa40) = *(int32_t *)(arg2 + 0xa40) + iVar6;
        }
        *(int32_t *)arg2 = iVar6 + iVar1;
        *(int16_t *)(arg2 + 0xa38) = *(int16_t *)(arg2 + 0xa38) + 1;
        *(int16_t *)(arg2 + 0xa3a) = *(int16_t *)(arg2 + 0xa3a) + 1;
    }
    return;
}

// ============================================================
// Function: FUN_18014257d
// Address: 0x18014257d
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180142550(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar7 = (int64_t)*(int16_t *)(arg2 + 0xa3a);
    if (*(int16_t *)(arg2 + 0xa3a) != 99) {
        iVar1 = *(int32_t *)(arg2 + 0x20 + iVar7 * 0x10);
        iVar9 = (int64_t)*(int16_t *)(arg2 + 0xa38) * 0x10 + arg2;
        iVar6 = *(int32_t *)(arg2 + 0x24 + iVar7 * 0x10);
        iVar2 = *(int32_t *)(arg2 + 0x2c + iVar7 * 0x10);
        iVar3 = *(int32_t *)(arg2 + 0x28 + iVar7 * 0x10);
        *(int32_t *)(iVar9 + 0x28) = iVar6;
        *(int32_t *)(iVar9 + 0x24) = iVar3;
        *(int32_t *)(iVar9 + 0x20) = iVar1;
        *(undefined4 *)(iVar9 + 0x2c) = 0xffffffff;
        if (iVar3 != 0) {
            iVar8 = 0;
            if (*(int32_t *)(arg2 + 0xa40) < iVar3 + *(int32_t *)(arg2 + 0xa3c)) {
                *(undefined8 *)(iVar9 + 0x24) = 0;
            } else {
                *(int32_t *)(iVar9 + 0x2c) = *(int32_t *)(arg2 + 0xa3c);
                *(int32_t *)(arg2 + 0xa3c) = *(int32_t *)(arg2 + 0xa3c) + iVar3;
                if (0 < *(int32_t *)(iVar9 + 0x24)) {
                    do {
                        iVar4 = *(int32_t *)(iVar9 + 0x20) + iVar8;
                        iVar5 = *(int32_t *)(iVar9 + 0x2c) + iVar8;
                        iVar8 = iVar8 + 1;
                        *(undefined *)((int64_t)iVar5 + 0x650 + arg2) =
                             *(undefined *)((int64_t)iVar4 + *(int64_t *)(arg1 + 0x20));
                    } while (iVar8 < *(int32_t *)(iVar9 + 0x24));
                }
            }
            iVar7 = (int64_t)iVar1 + *(int64_t *)(arg1 + 0x30);
            func_0x000180498030(iVar7, iVar7 + iVar3, (int64_t)(((*(int32_t *)(arg1 + 0x18) - iVar3) - iVar1) + 1));
            *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) - iVar3;
            *(undefined2 *)(arg1 + 0x73) = 0x101;
        }
        if (iVar6 != 0) {
            iVar6 = func_0x000180140a70(arg1, iVar1, arg2 + 0x650 + (int64_t)iVar2, iVar6);
            *(int32_t *)(arg2 + 0xa40) = *(int32_t *)(arg2 + 0xa40) + iVar6;
        }
        *(int32_t *)arg2 = iVar6 + iVar1;
        *(int16_t *)(arg2 + 0xa38) = *(int16_t *)(arg2 + 0xa38) + 1;
        *(int16_t *)(arg2 + 0xa3a) = *(int16_t *)(arg2 + 0xa3a) + 1;
    }
    return;
}

// ============================================================
// Function: FUN_1801425a6
// Address: 0x1801425a6
// Size: 184 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180142550(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar7 = (int64_t)*(int16_t *)(arg2 + 0xa3a);
    if (*(int16_t *)(arg2 + 0xa3a) != 99) {
        iVar1 = *(int32_t *)(arg2 + 0x20 + iVar7 * 0x10);
        iVar9 = (int64_t)*(int16_t *)(arg2 + 0xa38) * 0x10 + arg2;
        iVar6 = *(int32_t *)(arg2 + 0x24 + iVar7 * 0x10);
        iVar2 = *(int32_t *)(arg2 + 0x2c + iVar7 * 0x10);
        iVar3 = *(int32_t *)(arg2 + 0x28 + iVar7 * 0x10);
        *(int32_t *)(iVar9 + 0x28) = iVar6;
        *(int32_t *)(iVar9 + 0x24) = iVar3;
        *(int32_t *)(iVar9 + 0x20) = iVar1;
        *(undefined4 *)(iVar9 + 0x2c) = 0xffffffff;
        if (iVar3 != 0) {
            iVar8 = 0;
            if (*(int32_t *)(arg2 + 0xa40) < iVar3 + *(int32_t *)(arg2 + 0xa3c)) {
                *(undefined8 *)(iVar9 + 0x24) = 0;
            } else {
                *(int32_t *)(iVar9 + 0x2c) = *(int32_t *)(arg2 + 0xa3c);
                *(int32_t *)(arg2 + 0xa3c) = *(int32_t *)(arg2 + 0xa3c) + iVar3;
                if (0 < *(int32_t *)(iVar9 + 0x24)) {
                    do {
                        iVar4 = *(int32_t *)(iVar9 + 0x20) + iVar8;
                        iVar5 = *(int32_t *)(iVar9 + 0x2c) + iVar8;
                        iVar8 = iVar8 + 1;
                        *(undefined *)((int64_t)iVar5 + 0x650 + arg2) =
                             *(undefined *)((int64_t)iVar4 + *(int64_t *)(arg1 + 0x20));
                    } while (iVar8 < *(int32_t *)(iVar9 + 0x24));
                }
            }
            iVar7 = (int64_t)iVar1 + *(int64_t *)(arg1 + 0x30);
            func_0x000180498030(iVar7, iVar7 + iVar3, (int64_t)(((*(int32_t *)(arg1 + 0x18) - iVar3) - iVar1) + 1));
            *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) - iVar3;
            *(undefined2 *)(arg1 + 0x73) = 0x101;
        }
        if (iVar6 != 0) {
            iVar6 = func_0x000180140a70(arg1, iVar1, arg2 + 0x650 + (int64_t)iVar2, iVar6);
            *(int32_t *)(arg2 + 0xa40) = *(int32_t *)(arg2 + 0xa40) + iVar6;
        }
        *(int32_t *)arg2 = iVar6 + iVar1;
        *(int16_t *)(arg2 + 0xa38) = *(int16_t *)(arg2 + 0xa38) + 1;
        *(int16_t *)(arg2 + 0xa3a) = *(int16_t *)(arg2 + 0xa3a) + 1;
    }
    return;
}

// ============================================================
// Function: FUN_18014265e
// Address: 0x18014265e
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180142550(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar7 = (int64_t)*(int16_t *)(arg2 + 0xa3a);
    if (*(int16_t *)(arg2 + 0xa3a) != 99) {
        iVar1 = *(int32_t *)(arg2 + 0x20 + iVar7 * 0x10);
        iVar9 = (int64_t)*(int16_t *)(arg2 + 0xa38) * 0x10 + arg2;
        iVar6 = *(int32_t *)(arg2 + 0x24 + iVar7 * 0x10);
        iVar2 = *(int32_t *)(arg2 + 0x2c + iVar7 * 0x10);
        iVar3 = *(int32_t *)(arg2 + 0x28 + iVar7 * 0x10);
        *(int32_t *)(iVar9 + 0x28) = iVar6;
        *(int32_t *)(iVar9 + 0x24) = iVar3;
        *(int32_t *)(iVar9 + 0x20) = iVar1;
        *(undefined4 *)(iVar9 + 0x2c) = 0xffffffff;
        if (iVar3 != 0) {
            iVar8 = 0;
            if (*(int32_t *)(arg2 + 0xa40) < iVar3 + *(int32_t *)(arg2 + 0xa3c)) {
                *(undefined8 *)(iVar9 + 0x24) = 0;
            } else {
                *(int32_t *)(iVar9 + 0x2c) = *(int32_t *)(arg2 + 0xa3c);
                *(int32_t *)(arg2 + 0xa3c) = *(int32_t *)(arg2 + 0xa3c) + iVar3;
                if (0 < *(int32_t *)(iVar9 + 0x24)) {
                    do {
                        iVar4 = *(int32_t *)(iVar9 + 0x20) + iVar8;
                        iVar5 = *(int32_t *)(iVar9 + 0x2c) + iVar8;
                        iVar8 = iVar8 + 1;
                        *(undefined *)((int64_t)iVar5 + 0x650 + arg2) =
                             *(undefined *)((int64_t)iVar4 + *(int64_t *)(arg1 + 0x20));
                    } while (iVar8 < *(int32_t *)(iVar9 + 0x24));
                }
            }
            iVar7 = (int64_t)iVar1 + *(int64_t *)(arg1 + 0x30);
            func_0x000180498030(iVar7, iVar7 + iVar3, (int64_t)(((*(int32_t *)(arg1 + 0x18) - iVar3) - iVar1) + 1));
            *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) - iVar3;
            *(undefined2 *)(arg1 + 0x73) = 0x101;
        }
        if (iVar6 != 0) {
            iVar6 = func_0x000180140a70(arg1, iVar1, arg2 + 0x650 + (int64_t)iVar2, iVar6);
            *(int32_t *)(arg2 + 0xa40) = *(int32_t *)(arg2 + 0xa40) + iVar6;
        }
        *(int32_t *)arg2 = iVar6 + iVar1;
        *(int16_t *)(arg2 + 0xa38) = *(int16_t *)(arg2 + 0xa38) + 1;
        *(int16_t *)(arg2 + 0xa3a) = *(int16_t *)(arg2 + 0xa3a) + 1;
    }
    return;
}

// ============================================================
// Function: FUN_1801426a8
// Address: 0x1801426a8
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180142550(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar7 = (int64_t)*(int16_t *)(arg2 + 0xa3a);
    if (*(int16_t *)(arg2 + 0xa3a) != 99) {
        iVar1 = *(int32_t *)(arg2 + 0x20 + iVar7 * 0x10);
        iVar9 = (int64_t)*(int16_t *)(arg2 + 0xa38) * 0x10 + arg2;
        iVar6 = *(int32_t *)(arg2 + 0x24 + iVar7 * 0x10);
        iVar2 = *(int32_t *)(arg2 + 0x2c + iVar7 * 0x10);
        iVar3 = *(int32_t *)(arg2 + 0x28 + iVar7 * 0x10);
        *(int32_t *)(iVar9 + 0x28) = iVar6;
        *(int32_t *)(iVar9 + 0x24) = iVar3;
        *(int32_t *)(iVar9 + 0x20) = iVar1;
        *(undefined4 *)(iVar9 + 0x2c) = 0xffffffff;
        if (iVar3 != 0) {
            iVar8 = 0;
            if (*(int32_t *)(arg2 + 0xa40) < iVar3 + *(int32_t *)(arg2 + 0xa3c)) {
                *(undefined8 *)(iVar9 + 0x24) = 0;
            } else {
                *(int32_t *)(iVar9 + 0x2c) = *(int32_t *)(arg2 + 0xa3c);
                *(int32_t *)(arg2 + 0xa3c) = *(int32_t *)(arg2 + 0xa3c) + iVar3;
                if (0 < *(int32_t *)(iVar9 + 0x24)) {
                    do {
                        iVar4 = *(int32_t *)(iVar9 + 0x20) + iVar8;
                        iVar5 = *(int32_t *)(iVar9 + 0x2c) + iVar8;
                        iVar8 = iVar8 + 1;
                        *(undefined *)((int64_t)iVar5 + 0x650 + arg2) =
                             *(undefined *)((int64_t)iVar4 + *(int64_t *)(arg1 + 0x20));
                    } while (iVar8 < *(int32_t *)(iVar9 + 0x24));
                }
            }
            iVar7 = (int64_t)iVar1 + *(int64_t *)(arg1 + 0x30);
            func_0x000180498030(iVar7, iVar7 + iVar3, (int64_t)(((*(int32_t *)(arg1 + 0x18) - iVar3) - iVar1) + 1));
            *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) - iVar3;
            *(undefined2 *)(arg1 + 0x73) = 0x101;
        }
        if (iVar6 != 0) {
            iVar6 = func_0x000180140a70(arg1, iVar1, arg2 + 0x650 + (int64_t)iVar2, iVar6);
            *(int32_t *)(arg2 + 0xa40) = *(int32_t *)(arg2 + 0xa40) + iVar6;
        }
        *(int32_t *)arg2 = iVar6 + iVar1;
        *(int16_t *)(arg2 + 0xa38) = *(int16_t *)(arg2 + 0xa38) + 1;
        *(int16_t *)(arg2 + 0xa3a) = *(int16_t *)(arg2 + 0xa3a) + 1;
    }
    return;
}

// ============================================================
// Function: FUN_1801426b0
// Address: 0x1801426b0
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801426b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar8 = (uint32_t)arg4;
    iVar7 = (int32_t)arg3;
    piVar3 = (int64_t *)func_0x000180142130(arg2 + 0x20, arg3 & 0xffffffff, arg4 & 0xffffffff, arg_28h & 0xffffffff);
    if ((piVar3 != (int64_t *)0x0) && (0 < (int32_t)uVar8)) {
        iVar4 = 0;
        if (0xf < uVar8) {
            piVar1 = (int64_t *)(arg1 + 0x20);
            piVar6 = (int64_t *)((int64_t)(int32_t)uVar8 + -1 + (int64_t)piVar3);
            if ((((int64_t *)((int64_t)(int32_t)((uVar8 - 1) + iVar7) + *piVar1) < piVar3) ||
                (piVar6 < (int64_t *)((int64_t)iVar7 + *piVar1))) && ((piVar1 < piVar3 || (iVar4 = 0, piVar6 < piVar1)))
               ) {
                func_0x000180498030(piVar3, (int64_t *)((int64_t)iVar7 + *piVar1), (int64_t)(int32_t)uVar8);
                return;
            }
        }
        do {
            iVar2 = iVar4 + iVar7;
            iVar5 = (int64_t)iVar4;
            iVar4 = iVar4 + 1;
            *(undefined *)(iVar5 + (int64_t)piVar3) = *(undefined *)((int64_t)iVar2 + *(int64_t *)(arg1 + 0x20));
        } while (iVar4 < (int32_t)uVar8);
    }
    return;
}

// ============================================================
// Function: FUN_1801426e9
// Address: 0x1801426e9
// Size: 120 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801426b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar8 = (uint32_t)arg4;
    iVar7 = (int32_t)arg3;
    piVar3 = (int64_t *)func_0x000180142130(arg2 + 0x20, arg3 & 0xffffffff, arg4 & 0xffffffff, arg_28h & 0xffffffff);
    if ((piVar3 != (int64_t *)0x0) && (0 < (int32_t)uVar8)) {
        iVar4 = 0;
        if (0xf < uVar8) {
            piVar1 = (int64_t *)(arg1 + 0x20);
            piVar6 = (int64_t *)((int64_t)(int32_t)uVar8 + -1 + (int64_t)piVar3);
            if ((((int64_t *)((int64_t)(int32_t)((uVar8 - 1) + iVar7) + *piVar1) < piVar3) ||
                (piVar6 < (int64_t *)((int64_t)iVar7 + *piVar1))) && ((piVar1 < piVar3 || (iVar4 = 0, piVar6 < piVar1)))
               ) {
                func_0x000180498030(piVar3, (int64_t *)((int64_t)iVar7 + *piVar1), (int64_t)(int32_t)uVar8);
                return;
            }
        }
        do {
            iVar2 = iVar4 + iVar7;
            iVar5 = (int64_t)iVar4;
            iVar4 = iVar4 + 1;
            *(undefined *)(iVar5 + (int64_t)piVar3) = *(undefined *)((int64_t)iVar2 + *(int64_t *)(arg1 + 0x20));
        } while (iVar4 < (int32_t)uVar8);
    }
    return;
}

// ============================================================
// Function: FUN_180142761
// Address: 0x180142761
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801426b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar8 = (uint32_t)arg4;
    iVar7 = (int32_t)arg3;
    piVar3 = (int64_t *)func_0x000180142130(arg2 + 0x20, arg3 & 0xffffffff, arg4 & 0xffffffff, arg_28h & 0xffffffff);
    if ((piVar3 != (int64_t *)0x0) && (0 < (int32_t)uVar8)) {
        iVar4 = 0;
        if (0xf < uVar8) {
            piVar1 = (int64_t *)(arg1 + 0x20);
            piVar6 = (int64_t *)((int64_t)(int32_t)uVar8 + -1 + (int64_t)piVar3);
            if ((((int64_t *)((int64_t)(int32_t)((uVar8 - 1) + iVar7) + *piVar1) < piVar3) ||
                (piVar6 < (int64_t *)((int64_t)iVar7 + *piVar1))) && ((piVar1 < piVar3 || (iVar4 = 0, piVar6 < piVar1)))
               ) {
                func_0x000180498030(piVar3, (int64_t *)((int64_t)iVar7 + *piVar1), (int64_t)(int32_t)uVar8);
                return;
            }
        }
        do {
            iVar2 = iVar4 + iVar7;
            iVar5 = (int64_t)iVar4;
            iVar4 = iVar4 + 1;
            *(undefined *)(iVar5 + (int64_t)piVar3) = *(undefined *)((int64_t)iVar2 + *(int64_t *)(arg1 + 0x20));
        } while (iVar4 < (int32_t)uVar8);
    }
    return;
}

// ============================================================
// Function: FUN_180142780
// Address: 0x180142780
// Size: 117 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.180142780(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t var_38h;
    
    iVar2 = (int32_t)arg4;
    fcn.1801426b0(arg1, arg2, 0, (uint64_t)*(uint32_t *)(arg1 + 0x18), CONCAT44(var_38h._4_4_, iVar2));
    iVar1 = *(int32_t *)(arg1 + 0x18);
    **(undefined **)(arg1 + 0x30) = (*(undefined **)(arg1 + 0x30))[iVar1];
    *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) - iVar1;
    *(undefined2 *)(arg1 + 0x73) = 0x101;
    *(undefined8 *)(arg2 + 4) = 0;
    *(undefined4 *)arg2 = 0;
    if (0 < iVar2) {
        iVar1 = fcn.180140a70(arg1, 0, arg3, arg4 & 0xffffffff);
        if (0 < iVar1) {
            *(int32_t *)(arg2 + 8) = iVar2;
            *(int32_t *)(arg2 + 4) = iVar2;
            *(int32_t *)arg2 = iVar2;
            *(undefined *)(arg2 + 0x16) = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180142800
// Address: 0x180142800
// Size: 75 bytes
// ============================================================
void fcn.180142800(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 8) != 0) {
        func_0x000180460d90();
    }
    if (*(int64_t *)(arg1 + 0x50) != 0) {
        func_0x000180460d90();
    }
    if (*(int64_t *)(arg1 + 0x40) != 0) {
        func_0x000180460d90();
    }
    if (*(int64_t *)(arg1 + 0x30) != 0) {
        func_0x000180460d90();
    }
    return;
}

// ============================================================
// Function: FUN_180142850
// Address: 0x180142850
// Size: 114 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_94h

void fcn.180142850(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    uint32_t uVar2;
    int64_t var_8h;
    
    fcn.1801411f0(arg1, *(undefined8 *)(arg1 + 8), arg2 & 0xffffffff);
    uVar2 = (uint32_t)arg2 & 0xffbfffff;
    *(undefined *)(arg1 + 0x70) = 1;
    *(undefined4 *)(arg1 + 0x6c) = 0xbe99999a;
    uVar1 = uVar2 - 0x200000;
    if ((uVar1 < 0xd) && ((0x1251U >> (uVar1 & 0x1f) & 1) != 0)) {
        *(undefined *)(arg1 + 0x76) = 0;
        return;
    }
    uVar2 = uVar2 - 0x200001;
    if ((uVar2 < 0xd) && ((0x10d1U >> (uVar2 & 0x1f) & 1) != 0)) {
        *(undefined *)(arg1 + 0x76) = 1;
    }
    return;
}

// ============================================================
// Function: FUN_1801428d0
// Address: 0x1801428d0
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801428d0(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined *puVar4;
    int64_t iVar5;
    int64_t var_18h;
    undefined auStack_48 [32];
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_48;
    iVar2 = func_0x0001800f5e10(&var_28h, arg2, arg2 & 0xffffffff);
    *(undefined *)((int64_t)&var_28h + (int64_t)iVar2) = 0;
    uVar3 = func_0x000180498cd0(&var_28h);
    piVar1 = *(int32_t **)(arg1 + 8);
    if (((char)var_28h == '\n') && (*(char *)((int64_t)piVar1 + 0x17) != '\0')) goto code_r0x0001801429dc;
    if ((*(char *)(piVar1 + 3) == '\0') || (piVar1[1] != piVar1[2])) {
code_r0x00018014299d:
        func_0x000180141170(arg1, piVar1);
        iVar2 = fcn.180140a70(arg1, *piVar1, &var_28h, uVar3);
        if (iVar2 == 0) goto code_r0x0001801429dc;
        func_0x000180142130(piVar1 + 8, *piVar1, 0, iVar2);
        *piVar1 = *piVar1 + iVar2;
    } else {
        iVar2 = *piVar1;
        if (*(int32_t *)(arg1 + 0x18) <= iVar2) goto code_r0x00018014299d;
        puVar4 = (undefined *)func_0x000180142130(piVar1 + 8, iVar2, 1);
        if (puVar4 != (undefined *)0x0) {
            *puVar4 = *(undefined *)((int64_t)iVar2 + *(int64_t *)(arg1 + 0x20));
        }
        iVar5 = (int64_t)*piVar1 + *(int64_t *)(arg1 + 0x30);
        func_0x000180498030(iVar5, iVar5 + 1, (int64_t)(*(int32_t *)(arg1 + 0x18) - *piVar1));
        *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) + -1;
        *(undefined2 *)(arg1 + 0x73) = 0x101;
        iVar2 = fcn.180140a70(arg1, *piVar1, &var_28h, uVar3);
        if (iVar2 == 0) goto code_r0x0001801429dc;
        *piVar1 = *piVar1 + iVar2;
    }
    *(undefined *)((int64_t)piVar1 + 0x16) = 0;
code_r0x0001801429dc:
    *(undefined *)(arg1 + 0x70) = 1;
    *(undefined4 *)(arg1 + 0x6c) = 0xbe99999a;
    func_0x000180459870(var_20h ^ (uint64_t)auStack_48);
    return;
}

// ============================================================
// Function: FUN_180142925
// Address: 0x180142925
// Size: 183 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801428d0(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined *puVar4;
    int64_t iVar5;
    int64_t var_18h;
    undefined auStack_48 [32];
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_48;
    iVar2 = func_0x0001800f5e10(&var_28h, arg2, arg2 & 0xffffffff);
    *(undefined *)((int64_t)&var_28h + (int64_t)iVar2) = 0;
    uVar3 = func_0x000180498cd0(&var_28h);
    piVar1 = *(int32_t **)(arg1 + 8);
    if (((char)var_28h == '\n') && (*(char *)((int64_t)piVar1 + 0x17) != '\0')) goto code_r0x0001801429dc;
    if ((*(char *)(piVar1 + 3) == '\0') || (piVar1[1] != piVar1[2])) {
code_r0x00018014299d:
        func_0x000180141170(arg1, piVar1);
        iVar2 = fcn.180140a70(arg1, *piVar1, &var_28h, uVar3);
        if (iVar2 == 0) goto code_r0x0001801429dc;
        func_0x000180142130(piVar1 + 8, *piVar1, 0, iVar2);
        *piVar1 = *piVar1 + iVar2;
    } else {
        iVar2 = *piVar1;
        if (*(int32_t *)(arg1 + 0x18) <= iVar2) goto code_r0x00018014299d;
        puVar4 = (undefined *)func_0x000180142130(piVar1 + 8, iVar2, 1);
        if (puVar4 != (undefined *)0x0) {
            *puVar4 = *(undefined *)((int64_t)iVar2 + *(int64_t *)(arg1 + 0x20));
        }
        iVar5 = (int64_t)*piVar1 + *(int64_t *)(arg1 + 0x30);
        func_0x000180498030(iVar5, iVar5 + 1, (int64_t)(*(int32_t *)(arg1 + 0x18) - *piVar1));
        *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) + -1;
        *(undefined2 *)(arg1 + 0x73) = 0x101;
        iVar2 = fcn.180140a70(arg1, *piVar1, &var_28h, uVar3);
        if (iVar2 == 0) goto code_r0x0001801429dc;
        *piVar1 = *piVar1 + iVar2;
    }
    *(undefined *)((int64_t)piVar1 + 0x16) = 0;
code_r0x0001801429dc:
    *(undefined *)(arg1 + 0x70) = 1;
    *(undefined4 *)(arg1 + 0x6c) = 0xbe99999a;
    func_0x000180459870(var_20h ^ (uint64_t)auStack_48);
    return;
}

// ============================================================
// Function: FUN_1801429dc
// Address: 0x1801429dc
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801428d0(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined *puVar4;
    int64_t iVar5;
    int64_t var_18h;
    undefined auStack_48 [32];
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_48;
    iVar2 = func_0x0001800f5e10(&var_28h, arg2, arg2 & 0xffffffff);
    *(undefined *)((int64_t)&var_28h + (int64_t)iVar2) = 0;
    uVar3 = func_0x000180498cd0(&var_28h);
    piVar1 = *(int32_t **)(arg1 + 8);
    if (((char)var_28h == '\n') && (*(char *)((int64_t)piVar1 + 0x17) != '\0')) goto code_r0x0001801429dc;
    if ((*(char *)(piVar1 + 3) == '\0') || (piVar1[1] != piVar1[2])) {
code_r0x00018014299d:
        func_0x000180141170(arg1, piVar1);
        iVar2 = fcn.180140a70(arg1, *piVar1, &var_28h, uVar3);
        if (iVar2 == 0) goto code_r0x0001801429dc;
        func_0x000180142130(piVar1 + 8, *piVar1, 0, iVar2);
        *piVar1 = *piVar1 + iVar2;
    } else {
        iVar2 = *piVar1;
        if (*(int32_t *)(arg1 + 0x18) <= iVar2) goto code_r0x00018014299d;
        puVar4 = (undefined *)func_0x000180142130(piVar1 + 8, iVar2, 1);
        if (puVar4 != (undefined *)0x0) {
            *puVar4 = *(undefined *)((int64_t)iVar2 + *(int64_t *)(arg1 + 0x20));
        }
        iVar5 = (int64_t)*piVar1 + *(int64_t *)(arg1 + 0x30);
        func_0x000180498030(iVar5, iVar5 + 1, (int64_t)(*(int32_t *)(arg1 + 0x18) - *piVar1));
        *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) + -1;
        *(undefined2 *)(arg1 + 0x73) = 0x101;
        iVar2 = fcn.180140a70(arg1, *piVar1, &var_28h, uVar3);
        if (iVar2 == 0) goto code_r0x0001801429dc;
        *piVar1 = *piVar1 + iVar2;
    }
    *(undefined *)((int64_t)piVar1 + 0x16) = 0;
code_r0x0001801429dc:
    *(undefined *)(arg1 + 0x70) = 1;
    *(undefined4 *)(arg1 + 0x6c) = 0xbe99999a;
    func_0x000180459870(var_20h ^ (uint64_t)auStack_48);
    return;
}

// ============================================================
// Function: FUN_180142a00
// Address: 0x180142a00
// Size: 285 bytes
// ============================================================
void fcn.180142a00(void)
{
    uint32_t *puVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    int64_t iVar7;
    
    iVar6 = *(int64_t *)0x180781f28;
    iVar7 = fcn.18012eb00(*(undefined8 *)(*(int64_t *)0x180781f28 + 0x12f0), 0x2a);
    *(undefined4 *)(iVar6 + 0x2778) = *(undefined4 *)(*(int64_t *)(iVar6 + 0x12e8) + 0x10);
    *(undefined4 *)(iVar6 + 0x2750) = *(undefined4 *)(*(int64_t *)(iVar6 + 0x12f0) + 0x40);
    *(undefined4 *)(iVar6 + 0x2720) = *(undefined4 *)(*(int64_t *)(iVar6 + 0x12f0) + 0x10);
    iVar3 = *(int64_t *)(iVar6 + 0x12f0);
    uVar2 = *(undefined4 *)(iVar3 + 0x20);
    *(undefined4 *)(iVar3 + 0x20) = *(undefined4 *)(iVar6 + 0x2730);
    *(undefined4 *)(iVar6 + 0x2730) = uVar2;
    uVar2 = *(undefined4 *)(iVar3 + 0x24);
    *(undefined4 *)(iVar3 + 0x24) = *(undefined4 *)(iVar6 + 0x2734);
    *(undefined4 *)(iVar6 + 0x2734) = uVar2;
    uVar4 = *(undefined8 *)(iVar3 + 0x28);
    *(undefined8 *)(iVar3 + 0x28) = *(undefined8 *)(iVar6 + 0x2738);
    *(undefined8 *)(iVar6 + 0x2738) = uVar4;
    puVar5 = *(undefined4 **)(iVar6 + 0x12f0);
    uVar2 = *puVar5;
    *puVar5 = *(undefined4 *)(iVar6 + 10000);
    *(undefined4 *)(iVar6 + 10000) = uVar2;
    uVar2 = puVar5[1];
    puVar5[1] = *(undefined4 *)(iVar6 + 0x2714);
    *(undefined4 *)(iVar6 + 0x2714) = uVar2;
    uVar4 = *(undefined8 *)(puVar5 + 2);
    *(undefined8 *)(puVar5 + 2) = *(undefined8 *)(iVar6 + 0x2718);
    *(undefined8 *)(iVar6 + 0x2718) = uVar4;
    puVar1 = (uint32_t *)(*(int64_t *)(iVar6 + 0x12e8) + 0x10);
    *puVar1 = *puVar1 | 4;
    *(int32_t *)(*(int64_t *)(iVar6 + 0x12f0) + 0x40) =
         (int32_t)((iVar7 - *(int64_t *)(*(int64_t *)(iVar6 + 0x12f0) + 0x38)) / 0x2c);
    *(undefined4 *)(*(int64_t *)(iVar6 + 0x12f0) + 0x10) = *(undefined4 *)(iVar7 + 4);
    return;
}

// ============================================================
// Function: FUN_180142bf0
// Address: 0x180142bf0
// Size: 718 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_11h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_36h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_26h

bool fcn.180142bf0(int64_t arg1, int64_t arg2, int64_t arg3, code *placeholder_3, int64_t arg_28h, int64_t arg_30h)
{
    uint16_t uVar1;
    undefined4 *puVar2;
    bool bVar3;
    uint8_t uVar4;
    uint8_t uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_58h;
    undefined4 var_50h;
    uint32_t var_4ch;
    int64_t var_48h;
    int32_t var_40h;
    int64_t var_3ch;
    int64_t var_2dh;
    int64_t var_25h;
    int64_t var_1dh;
    int64_t var_15h;
    
    var_4ch = *(uint32_t *)(arg2 + 0x10);
    bVar3 = true;
    uVar8 = *(uint32_t *)arg3;
    uVar9 = (uint64_t)uVar8;
    uVar5 = 0;
    if (0x1f < uVar8) goto code_r0x000180142c65;
    uVar4 = 1;
    uVar7 = var_4ch & 0x4000000;
    if ((uVar8 == 10) && (uVar7 != 0)) {
        uVar5 = 1;
code_r0x000180142c3e:
        if ((char)arg_30h == '\0') {
            if (uVar7 == 0) goto code_r0x000180142e79;
        } else if (uVar7 == 0) {
            uVar9 = 0x20;
            *(undefined4 *)arg3 = 0x20;
        }
code_r0x000180142c59:
        uVar5 = uVar4;
        uVar4 = 0;
    } else {
        if (uVar8 == 10) goto code_r0x000180142c3e;
code_r0x000180142e79:
        uVar4 = uVar5;
        if ((uVar8 != 9) || ((var_4ch & 0x20) == 0)) goto code_r0x000180142c59;
        uVar4 = 1;
    }
    if (!(bool)(uVar5 | uVar4)) {
        return false;
    }
    bVar3 = false;
code_r0x000180142c65:
    uVar8 = (uint32_t)uVar9;
    if ((char)arg_30h == '\0') {
        if (uVar8 == 0x7f) {
            return false;
        }
        if (uVar8 - 0xe000 < 0x1900) {
            return false;
        }
    }
    if (0xffff < uVar8) {
        return false;
    }
    if ((bVar3) && ((var_4ch & 0x1000001f) != 0)) {
        uVar1 = *(uint16_t *)(arg1 + 0xc80);
        if (((var_4ch & 0x10000005) != 0) && ((uVar8 - 0x2c & 0xfffffffd) == 0)) {
            uVar9 = (uint64_t)uVar1;
        }
        if (((var_4ch & 7) != 0) && ((int32_t)uVar9 - 0xff01U < 0x5e)) {
            uVar9 = (uint64_t)((int32_t)uVar9 - 0xfee0);
        }
        uVar8 = (uint32_t)uVar9;
        if ((((var_4ch & 1) != 0) && (9 < uVar8 - 0x30)) && (uVar8 != uVar1)) {
            if (0x2f < uVar8) {
                return false;
            }
            if ((0xac0000000000U >> (uVar9 & 0x3f) & 1) == 0) {
                return false;
            }
        }
        if ((((var_4ch & 4) != 0) && (9 < uVar8 - 0x30)) && (uVar8 != uVar1)) {
            if (0x3b < uVar8 - 0x2a) {
                return false;
            }
            if ((0x80000000800002bU >> ((uint64_t)(uVar8 - 0x2a) & 0x3f) & 1) == 0) {
                return false;
            }
        }
        if ((var_4ch & 2) != 0) {
            if (0x36 < uVar8 - 0x30) {
                return false;
            }
            if ((0x7e0000007e03ffU >> ((uint64_t)(uVar8 - 0x30) & 0x3f) & 1) == 0) {
                return false;
            }
        }
        if (((var_4ch & 8) != 0) && (uVar8 - 0x61 < 0x1a)) {
            uVar9 = (uint64_t)(uVar8 - 0x20);
        }
        iVar6 = (int32_t)uVar9;
        if ((var_4ch & 0x10) != 0) {
            if (iVar6 == 0x20) {
                return false;
            }
            if (iVar6 == 9) {
                return false;
            }
            if (iVar6 == 0x3000) {
                return false;
            }
        }
        *(int32_t *)arg3 = iVar6;
    }
    if ((var_4ch >> 0x15 & 1) == 0) {
        return true;
    }
    var_40h = *(int32_t *)(arg2 + 0x14);
    var_3ch._0_4_ = 0;
    stack0xffffffffffffffcb = 0;
    var_2dh = 0;
    var_25h._0_5_ = 0;
    var_15h._1_4_ = 0;
    var_58h = *(int64_t *)0x180781f28;
    var_50h = 0x200000;
    var_3ch._4_2_ = (uint16_t)uVar9;
    if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != var_40h) ||
       (var_3ch._6_1_ = 1, *(char *)(*(int64_t *)0x180781f28 + 0x1660) == '\0')) {
        var_3ch._6_1_ = 0;
    }
    puVar2 = *(undefined4 **)(arg2 + 8);
    unique0x0000c180 = *puVar2;
    var_1dh._1_4_ = puVar2[1];
    unique0x0000c180 = puVar2[2];
    var_48h = arg_28h;
    iVar6 = (*placeholder_3)(&var_58h);
    if (iVar6 != 0) {
        return false;
    }
    *(uint32_t *)arg3 = (uint32_t)var_3ch._4_2_;
    return var_3ch._4_2_ != 0;
}

// ============================================================
// Function: FUN_180142ec0
// Address: 0x180142ec0
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180142ec0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int16_t iVar6;
    int32_t *piVar7;
    int64_t iVar8;
    uint32_t uVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int32_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = (int32_t)arg3;
    iVar10 = (int32_t)arg_28h;
    if (iVar3 < (int32_t)arg_28h) {
        iVar10 = iVar3;
    }
    uVar11 = 0;
    if (0 < iVar10) {
        do {
            if (*(char *)(arg2 + uVar11) != *(char *)(arg4 + uVar11)) break;
            uVar9 = (int32_t)uVar11 + 1;
            uVar11 = (uint64_t)uVar9;
        } while ((int32_t)uVar9 < iVar10);
    }
    iVar10 = (int32_t)uVar11;
    if ((iVar10 != iVar3) || (iVar10 != (int32_t)arg_28h)) {
        while( true ) {
            iVar3 = iVar3 + -1;
            arg_28h._0_4_ = (int32_t)arg_28h + -1;
            if (iVar3 < iVar10) break;
            if (((int32_t)arg_28h < iVar10) || (*(char *)(iVar3 + arg2) != *(char *)((int32_t)arg_28h + arg4))) break;
        }
        iVar12 = ((int32_t)arg_28h - iVar10) + 1;
        uVar9 = (iVar3 - iVar10) + 1;
        if ((0 < iVar12) || (0 < (int32_t)uVar9)) {
            iVar5 = *(int64_t *)(arg1 + 8);
            iVar8 = iVar5 + 0x20;
            *(undefined2 *)(iVar5 + 0xa3a) = 99;
            *(undefined4 *)(iVar5 + 0xa40) = 999;
            if (*(int16_t *)(iVar5 + 0xa38) == 99) {
                func_0x000180142080(iVar8);
            }
            if ((int32_t)uVar9 < 1000) {
                iVar4 = *(int32_t *)(iVar5 + 0xa3c);
                while (999 < (int32_t)(iVar4 + uVar9)) {
                    iVar6 = *(int16_t *)(iVar5 + 0xa38);
                    if (0 < iVar6) {
                        if (-1 < *(int32_t *)(iVar5 + 0x2c)) {
                            iVar1 = *(int32_t *)(iVar5 + 0x24);
                            *(int32_t *)(iVar5 + 0xa3c) = iVar4 - iVar1;
                            func_0x000180498030(iVar5 + 0x650, iVar5 + 0x650 + (int64_t)iVar1, (int64_t)(iVar4 - iVar1))
                            ;
                            iVar6 = *(int16_t *)(iVar5 + 0xa38);
                            iVar4 = 0;
                            if (0 < iVar6) {
                                do {
                                    iVar2 = *(int32_t *)(iVar5 + 0x2c + (int64_t)iVar4 * 0x10);
                                    if (-1 < iVar2) {
                                        *(int32_t *)(iVar5 + 0x2c + (int64_t)iVar4 * 0x10) = iVar2 - iVar1;
                                    }
                                    iVar6 = *(int16_t *)(iVar5 + 0xa38);
                                    iVar4 = iVar4 + 1;
                                } while (iVar4 < iVar6);
                            }
                        }
                        *(int16_t *)(iVar5 + 0xa38) = iVar6 + -1;
                        func_0x000180498030(iVar8, iVar5 + 0x30, (int64_t)(int16_t)(iVar6 + -1) << 4);
                    }
                    iVar4 = *(int32_t *)(iVar5 + 0xa3c);
                }
                iVar6 = *(int16_t *)(iVar5 + 0xa38);
                *(int16_t *)(iVar5 + 0xa38) = iVar6 + 1;
                piVar7 = (int32_t *)((int64_t)iVar6 * 0x10 + iVar8);
                if (piVar7 != (int32_t *)0x0) {
                    *piVar7 = iVar10;
                    piVar7[1] = uVar9;
                    piVar7[2] = iVar12;
                    if (uVar9 == 0) {
                        piVar7[3] = -1;
                    } else {
                        piVar7[3] = *(int32_t *)(iVar5 + 0xa3c);
                        *(int32_t *)(iVar5 + 0xa3c) = *(int32_t *)(iVar5 + 0xa3c) + uVar9;
                        uVar11 = (int64_t)piVar7[3] + 0x630 + iVar8;
                        if ((uVar11 != 0) && (0 < (int32_t)uVar9)) {
                            iVar12 = 0;
                            if ((uVar9 < 0x10) ||
                               ((uVar11 <= (uint64_t)(iVar3 + arg2) &&
                                ((uint64_t)(iVar10 + arg2) <= (int64_t)(iVar3 - iVar10) + uVar11)))) {
                                if (0 < (int32_t)uVar9) {
                                    do {
                                        iVar3 = iVar12 + iVar10;
                                        iVar5 = (int64_t)iVar12;
                                        iVar12 = iVar12 + 1;
                                        *(undefined *)(iVar5 + uVar11) = *(undefined *)(iVar3 + arg2);
                                    } while (iVar12 < (int32_t)uVar9);
                                }
                            } else {
                                func_0x000180498030(uVar11, iVar10 + arg2, (int64_t)(int32_t)uVar9);
                            }
                        }
                    }
                }
            } else {
                *(undefined2 *)(iVar5 + 0xa38) = 0;
                *(undefined4 *)(iVar5 + 0xa3c) = 0;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180142f04
// Address: 0x180142f04
// Size: 186 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180142ec0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int16_t iVar6;
    int32_t *piVar7;
    int64_t iVar8;
    uint32_t uVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int32_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = (int32_t)arg3;
    iVar10 = (int32_t)arg_28h;
    if (iVar3 < (int32_t)arg_28h) {
        iVar10 = iVar3;
    }
    uVar11 = 0;
    if (0 < iVar10) {
        do {
            if (*(char *)(arg2 + uVar11) != *(char *)(arg4 + uVar11)) break;
            uVar9 = (int32_t)uVar11 + 1;
            uVar11 = (uint64_t)uVar9;
        } while ((int32_t)uVar9 < iVar10);
    }
    iVar10 = (int32_t)uVar11;
    if ((iVar10 != iVar3) || (iVar10 != (int32_t)arg_28h)) {
        while( true ) {
            iVar3 = iVar3 + -1;
            arg_28h._0_4_ = (int32_t)arg_28h + -1;
            if (iVar3 < iVar10) break;
            if (((int32_t)arg_28h < iVar10) || (*(char *)(iVar3 + arg2) != *(char *)((int32_t)arg_28h + arg4))) break;
        }
        iVar12 = ((int32_t)arg_28h - iVar10) + 1;
        uVar9 = (iVar3 - iVar10) + 1;
        if ((0 < iVar12) || (0 < (int32_t)uVar9)) {
            iVar5 = *(int64_t *)(arg1 + 8);
            iVar8 = iVar5 + 0x20;
            *(undefined2 *)(iVar5 + 0xa3a) = 99;
            *(undefined4 *)(iVar5 + 0xa40) = 999;
            if (*(int16_t *)(iVar5 + 0xa38) == 99) {
                func_0x000180142080(iVar8);
            }
            if ((int32_t)uVar9 < 1000) {
                iVar4 = *(int32_t *)(iVar5 + 0xa3c);
                while (999 < (int32_t)(iVar4 + uVar9)) {
                    iVar6 = *(int16_t *)(iVar5 + 0xa38);
                    if (0 < iVar6) {
                        if (-1 < *(int32_t *)(iVar5 + 0x2c)) {
                            iVar1 = *(int32_t *)(iVar5 + 0x24);
                            *(int32_t *)(iVar5 + 0xa3c) = iVar4 - iVar1;
                            func_0x000180498030(iVar5 + 0x650, iVar5 + 0x650 + (int64_t)iVar1, (int64_t)(iVar4 - iVar1))
                            ;
                            iVar6 = *(int16_t *)(iVar5 + 0xa38);
                            iVar4 = 0;
                            if (0 < iVar6) {
                                do {
                                    iVar2 = *(int32_t *)(iVar5 + 0x2c + (int64_t)iVar4 * 0x10);
                                    if (-1 < iVar2) {
                                        *(int32_t *)(iVar5 + 0x2c + (int64_t)iVar4 * 0x10) = iVar2 - iVar1;
                                    }
                                    iVar6 = *(int16_t *)(iVar5 + 0xa38);
                                    iVar4 = iVar4 + 1;
                                } while (iVar4 < iVar6);
                            }
                        }
                        *(int16_t *)(iVar5 + 0xa38) = iVar6 + -1;
                        func_0x000180498030(iVar8, iVar5 + 0x30, (int64_t)(int16_t)(iVar6 + -1) << 4);
                    }
                    iVar4 = *(int32_t *)(iVar5 + 0xa3c);
                }
                iVar6 = *(int16_t *)(iVar5 + 0xa38);
                *(int16_t *)(iVar5 + 0xa38) = iVar6 + 1;
                piVar7 = (int32_t *)((int64_t)iVar6 * 0x10 + iVar8);
                if (piVar7 != (int32_t *)0x0) {
                    *piVar7 = iVar10;
                    piVar7[1] = uVar9;
                    piVar7[2] = iVar12;
                    if (uVar9 == 0) {
                        piVar7[3] = -1;
                    } else {
                        piVar7[3] = *(int32_t *)(iVar5 + 0xa3c);
                        *(int32_t *)(iVar5 + 0xa3c) = *(int32_t *)(iVar5 + 0xa3c) + uVar9;
                        uVar11 = (int64_t)piVar7[3] + 0x630 + iVar8;
                        if ((uVar11 != 0) && (0 < (int32_t)uVar9)) {
                            iVar12 = 0;
                            if ((uVar9 < 0x10) ||
                               ((uVar11 <= (uint64_t)(iVar3 + arg2) &&
                                ((uint64_t)(iVar10 + arg2) <= (int64_t)(iVar3 - iVar10) + uVar11)))) {
                                if (0 < (int32_t)uVar9) {
                                    do {
                                        iVar3 = iVar12 + iVar10;
                                        iVar5 = (int64_t)iVar12;
                                        iVar12 = iVar12 + 1;
                                        *(undefined *)(iVar5 + uVar11) = *(undefined *)(iVar3 + arg2);
                                    } while (iVar12 < (int32_t)uVar9);
                                }
                            } else {
                                func_0x000180498030(uVar11, iVar10 + arg2, (int64_t)(int32_t)uVar9);
                            }
                        }
                    }
                }
            } else {
                *(undefined2 *)(iVar5 + 0xa38) = 0;
                *(undefined4 *)(iVar5 + 0xa3c) = 0;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180142fbe
// Address: 0x180142fbe
// Size: 187 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180142ec0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int16_t iVar6;
    int32_t *piVar7;
    int64_t iVar8;
    uint32_t uVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int32_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = (int32_t)arg3;
    iVar10 = (int32_t)arg_28h;
    if (iVar3 < (int32_t)arg_28h) {
        iVar10 = iVar3;
    }
    uVar11 = 0;
    if (0 < iVar10) {
        do {
            if (*(char *)(arg2 + uVar11) != *(char *)(arg4 + uVar11)) break;
            uVar9 = (int32_t)uVar11 + 1;
            uVar11 = (uint64_t)uVar9;
        } while ((int32_t)uVar9 < iVar10);
    }
    iVar10 = (int32_t)uVar11;
    if ((iVar10 != iVar3) || (iVar10 != (int32_t)arg_28h)) {
        while( true ) {
            iVar3 = iVar3 + -1;
            arg_28h._0_4_ = (int32_t)arg_28h + -1;
            if (iVar3 < iVar10) break;
            if (((int32_t)arg_28h < iVar10) || (*(char *)(iVar3 + arg2) != *(char *)((int32_t)arg_28h + arg4))) break;
        }
        iVar12 = ((int32_t)arg_28h - iVar10) + 1;
        uVar9 = (iVar3 - iVar10) + 1;
        if ((0 < iVar12) || (0 < (int32_t)uVar9)) {
            iVar5 = *(int64_t *)(arg1 + 8);
            iVar8 = iVar5 + 0x20;
            *(undefined2 *)(iVar5 + 0xa3a) = 99;
            *(undefined4 *)(iVar5 + 0xa40) = 999;
            if (*(int16_t *)(iVar5 + 0xa38) == 99) {
                func_0x000180142080(iVar8);
            }
            if ((int32_t)uVar9 < 1000) {
                iVar4 = *(int32_t *)(iVar5 + 0xa3c);
                while (999 < (int32_t)(iVar4 + uVar9)) {
                    iVar6 = *(int16_t *)(iVar5 + 0xa38);
                    if (0 < iVar6) {
                        if (-1 < *(int32_t *)(iVar5 + 0x2c)) {
                            iVar1 = *(int32_t *)(iVar5 + 0x24);
                            *(int32_t *)(iVar5 + 0xa3c) = iVar4 - iVar1;
                            func_0x000180498030(iVar5 + 0x650, iVar5 + 0x650 + (int64_t)iVar1, (int64_t)(iVar4 - iVar1))
                            ;
                            iVar6 = *(int16_t *)(iVar5 + 0xa38);
                            iVar4 = 0;
                            if (0 < iVar6) {
                                do {
                                    iVar2 = *(int32_t *)(iVar5 + 0x2c + (int64_t)iVar4 * 0x10);
                                    if (-1 < iVar2) {
                                        *(int32_t *)(iVar5 + 0x2c + (int64_t)iVar4 * 0x10) = iVar2 - iVar1;
                                    }
                                    iVar6 = *(int16_t *)(iVar5 + 0xa38);
                                    iVar4 = iVar4 + 1;
                                } while (iVar4 < iVar6);
                            }
                        }
                        *(int16_t *)(iVar5 + 0xa38) = iVar6 + -1;
                        func_0x000180498030(iVar8, iVar5 + 0x30, (int64_t)(int16_t)(iVar6 + -1) << 4);
                    }
                    iVar4 = *(int32_t *)(iVar5 + 0xa3c);
                }
                iVar6 = *(int16_t *)(iVar5 + 0xa38);
                *(int16_t *)(iVar5 + 0xa38) = iVar6 + 1;
                piVar7 = (int32_t *)((int64_t)iVar6 * 0x10 + iVar8);
                if (piVar7 != (int32_t *)0x0) {
                    *piVar7 = iVar10;
                    piVar7[1] = uVar9;
                    piVar7[2] = iVar12;
                    if (uVar9 == 0) {
                        piVar7[3] = -1;
                    } else {
                        piVar7[3] = *(int32_t *)(iVar5 + 0xa3c);
                        *(int32_t *)(iVar5 + 0xa3c) = *(int32_t *)(iVar5 + 0xa3c) + uVar9;
                        uVar11 = (int64_t)piVar7[3] + 0x630 + iVar8;
                        if ((uVar11 != 0) && (0 < (int32_t)uVar9)) {
                            iVar12 = 0;
                            if ((uVar9 < 0x10) ||
                               ((uVar11 <= (uint64_t)(iVar3 + arg2) &&
                                ((uint64_t)(iVar10 + arg2) <= (int64_t)(iVar3 - iVar10) + uVar11)))) {
                                if (0 < (int32_t)uVar9) {
                                    do {
                                        iVar3 = iVar12 + iVar10;
                                        iVar5 = (int64_t)iVar12;
                                        iVar12 = iVar12 + 1;
                                        *(undefined *)(iVar5 + uVar11) = *(undefined *)(iVar3 + arg2);
                                    } while (iVar12 < (int32_t)uVar9);
                                }
                            } else {
                                func_0x000180498030(uVar11, iVar10 + arg2, (int64_t)(int32_t)uVar9);
                            }
                        }
                    }
                }
            } else {
                *(undefined2 *)(iVar5 + 0xa38) = 0;
                *(undefined4 *)(iVar5 + 0xa3c) = 0;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180143079
// Address: 0x180143079
// Size: 194 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180142ec0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int16_t iVar6;
    int32_t *piVar7;
    int64_t iVar8;
    uint32_t uVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int32_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = (int32_t)arg3;
    iVar10 = (int32_t)arg_28h;
    if (iVar3 < (int32_t)arg_28h) {
        iVar10 = iVar3;
    }
    uVar11 = 0;
    if (0 < iVar10) {
        do {
            if (*(char *)(arg2 + uVar11) != *(char *)(arg4 + uVar11)) break;
            uVar9 = (int32_t)uVar11 + 1;
            uVar11 = (uint64_t)uVar9;
        } while ((int32_t)uVar9 < iVar10);
    }
    iVar10 = (int32_t)uVar11;
    if ((iVar10 != iVar3) || (iVar10 != (int32_t)arg_28h)) {
        while( true ) {
            iVar3 = iVar3 + -1;
            arg_28h._0_4_ = (int32_t)arg_28h + -1;
            if (iVar3 < iVar10) break;
            if (((int32_t)arg_28h < iVar10) || (*(char *)(iVar3 + arg2) != *(char *)((int32_t)arg_28h + arg4))) break;
        }
        iVar12 = ((int32_t)arg_28h - iVar10) + 1;
        uVar9 = (iVar3 - iVar10) + 1;
        if ((0 < iVar12) || (0 < (int32_t)uVar9)) {
            iVar5 = *(int64_t *)(arg1 + 8);
            iVar8 = iVar5 + 0x20;
            *(undefined2 *)(iVar5 + 0xa3a) = 99;
            *(undefined4 *)(iVar5 + 0xa40) = 999;
            if (*(int16_t *)(iVar5 + 0xa38) == 99) {
                func_0x000180142080(iVar8);
            }
            if ((int32_t)uVar9 < 1000) {
                iVar4 = *(int32_t *)(iVar5 + 0xa3c);
                while (999 < (int32_t)(iVar4 + uVar9)) {
                    iVar6 = *(int16_t *)(iVar5 + 0xa38);
                    if (0 < iVar6) {
                        if (-1 < *(int32_t *)(iVar5 + 0x2c)) {
                            iVar1 = *(int32_t *)(iVar5 + 0x24);
                            *(int32_t *)(iVar5 + 0xa3c) = iVar4 - iVar1;
                            func_0x000180498030(iVar5 + 0x650, iVar5 + 0x650 + (int64_t)iVar1, (int64_t)(iVar4 - iVar1))
                            ;
                            iVar6 = *(int16_t *)(iVar5 + 0xa38);
                            iVar4 = 0;
                            if (0 < iVar6) {
                                do {
                                    iVar2 = *(int32_t *)(iVar5 + 0x2c + (int64_t)iVar4 * 0x10);
                                    if (-1 < iVar2) {
                                        *(int32_t *)(iVar5 + 0x2c + (int64_t)iVar4 * 0x10) = iVar2 - iVar1;
                                    }
                                    iVar6 = *(int16_t *)(iVar5 + 0xa38);
                                    iVar4 = iVar4 + 1;
                                } while (iVar4 < iVar6);
                            }
                        }
                        *(int16_t *)(iVar5 + 0xa38) = iVar6 + -1;
                        func_0x000180498030(iVar8, iVar5 + 0x30, (int64_t)(int16_t)(iVar6 + -1) << 4);
                    }
                    iVar4 = *(int32_t *)(iVar5 + 0xa3c);
                }
                iVar6 = *(int16_t *)(iVar5 + 0xa38);
                *(int16_t *)(iVar5 + 0xa38) = iVar6 + 1;
                piVar7 = (int32_t *)((int64_t)iVar6 * 0x10 + iVar8);
                if (piVar7 != (int32_t *)0x0) {
                    *piVar7 = iVar10;
                    piVar7[1] = uVar9;
                    piVar7[2] = iVar12;
                    if (uVar9 == 0) {
                        piVar7[3] = -1;
                    } else {
                        piVar7[3] = *(int32_t *)(iVar5 + 0xa3c);
                        *(int32_t *)(iVar5 + 0xa3c) = *(int32_t *)(iVar5 + 0xa3c) + uVar9;
                        uVar11 = (int64_t)piVar7[3] + 0x630 + iVar8;
                        if ((uVar11 != 0) && (0 < (int32_t)uVar9)) {
                            iVar12 = 0;
                            if ((uVar9 < 0x10) ||
                               ((uVar11 <= (uint64_t)(iVar3 + arg2) &&
                                ((uint64_t)(iVar10 + arg2) <= (int64_t)(iVar3 - iVar10) + uVar11)))) {
                                if (0 < (int32_t)uVar9) {
                                    do {
                                        iVar3 = iVar12 + iVar10;
                                        iVar5 = (int64_t)iVar12;
                                        iVar12 = iVar12 + 1;
                                        *(undefined *)(iVar5 + uVar11) = *(undefined *)(iVar3 + arg2);
                                    } while (iVar12 < (int32_t)uVar9);
                                }
                            } else {
                                func_0x000180498030(uVar11, iVar10 + arg2, (int64_t)(int32_t)uVar9);
                            }
                        }
                    }
                }
            } else {
                *(undefined2 *)(iVar5 + 0xa38) = 0;
                *(undefined4 *)(iVar5 + 0xa3c) = 0;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18014313b
// Address: 0x18014313b
// Size: 9 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180142ec0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int16_t iVar6;
    int32_t *piVar7;
    int64_t iVar8;
    uint32_t uVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int32_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = (int32_t)arg3;
    iVar10 = (int32_t)arg_28h;
    if (iVar3 < (int32_t)arg_28h) {
        iVar10 = iVar3;
    }
    uVar11 = 0;
    if (0 < iVar10) {
        do {
            if (*(char *)(arg2 + uVar11) != *(char *)(arg4 + uVar11)) break;
            uVar9 = (int32_t)uVar11 + 1;
            uVar11 = (uint64_t)uVar9;
        } while ((int32_t)uVar9 < iVar10);
    }
    iVar10 = (int32_t)uVar11;
    if ((iVar10 != iVar3) || (iVar10 != (int32_t)arg_28h)) {
        while( true ) {
            iVar3 = iVar3 + -1;
            arg_28h._0_4_ = (int32_t)arg_28h + -1;
            if (iVar3 < iVar10) break;
            if (((int32_t)arg_28h < iVar10) || (*(char *)(iVar3 + arg2) != *(char *)((int32_t)arg_28h + arg4))) break;
        }
        iVar12 = ((int32_t)arg_28h - iVar10) + 1;
        uVar9 = (iVar3 - iVar10) + 1;
        if ((0 < iVar12) || (0 < (int32_t)uVar9)) {
            iVar5 = *(int64_t *)(arg1 + 8);
            iVar8 = iVar5 + 0x20;
            *(undefined2 *)(iVar5 + 0xa3a) = 99;
            *(undefined4 *)(iVar5 + 0xa40) = 999;
            if (*(int16_t *)(iVar5 + 0xa38) == 99) {
                func_0x000180142080(iVar8);
            }
            if ((int32_t)uVar9 < 1000) {
                iVar4 = *(int32_t *)(iVar5 + 0xa3c);
                while (999 < (int32_t)(iVar4 + uVar9)) {
                    iVar6 = *(int16_t *)(iVar5 + 0xa38);
                    if (0 < iVar6) {
                        if (-1 < *(int32_t *)(iVar5 + 0x2c)) {
                            iVar1 = *(int32_t *)(iVar5 + 0x24);
                            *(int32_t *)(iVar5 + 0xa3c) = iVar4 - iVar1;
                            func_0x000180498030(iVar5 + 0x650, iVar5 + 0x650 + (int64_t)iVar1, (int64_t)(iVar4 - iVar1))
                            ;
                            iVar6 = *(int16_t *)(iVar5 + 0xa38);
                            iVar4 = 0;
                            if (0 < iVar6) {
                                do {
                                    iVar2 = *(int32_t *)(iVar5 + 0x2c + (int64_t)iVar4 * 0x10);
                                    if (-1 < iVar2) {
                                        *(int32_t *)(iVar5 + 0x2c + (int64_t)iVar4 * 0x10) = iVar2 - iVar1;
                                    }
                                    iVar6 = *(int16_t *)(iVar5 + 0xa38);
                                    iVar4 = iVar4 + 1;
                                } while (iVar4 < iVar6);
                            }
                        }
                        *(int16_t *)(iVar5 + 0xa38) = iVar6 + -1;
                        func_0x000180498030(iVar8, iVar5 + 0x30, (int64_t)(int16_t)(iVar6 + -1) << 4);
                    }
                    iVar4 = *(int32_t *)(iVar5 + 0xa3c);
                }
                iVar6 = *(int16_t *)(iVar5 + 0xa38);
                *(int16_t *)(iVar5 + 0xa38) = iVar6 + 1;
                piVar7 = (int32_t *)((int64_t)iVar6 * 0x10 + iVar8);
                if (piVar7 != (int32_t *)0x0) {
                    *piVar7 = iVar10;
                    piVar7[1] = uVar9;
                    piVar7[2] = iVar12;
                    if (uVar9 == 0) {
                        piVar7[3] = -1;
                    } else {
                        piVar7[3] = *(int32_t *)(iVar5 + 0xa3c);
                        *(int32_t *)(iVar5 + 0xa3c) = *(int32_t *)(iVar5 + 0xa3c) + uVar9;
                        uVar11 = (int64_t)piVar7[3] + 0x630 + iVar8;
                        if ((uVar11 != 0) && (0 < (int32_t)uVar9)) {
                            iVar12 = 0;
                            if ((uVar9 < 0x10) ||
                               ((uVar11 <= (uint64_t)(iVar3 + arg2) &&
                                ((uint64_t)(iVar10 + arg2) <= (int64_t)(iVar3 - iVar10) + uVar11)))) {
                                if (0 < (int32_t)uVar9) {
                                    do {
                                        iVar3 = iVar12 + iVar10;
                                        iVar5 = (int64_t)iVar12;
                                        iVar12 = iVar12 + 1;
                                        *(undefined *)(iVar5 + uVar11) = *(undefined *)(iVar3 + arg2);
                                    } while (iVar12 < (int32_t)uVar9);
                                }
                            } else {
                                func_0x000180498030(uVar11, iVar10 + arg2, (int64_t)(int32_t)uVar9);
                            }
                        }
                    }
                }
            } else {
                *(undefined2 *)(iVar5 + 0xa38) = 0;
                *(undefined4 *)(iVar5 + 0xa3c) = 0;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180143150
// Address: 0x180143150
// Size: 8 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018011f69d: Changing call to branch
// WARNING: Possible PIC construction at 0x00018014319f: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018011f6a2)
// WARNING: Removing unreachable block (ram,0x0001801431a4)
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180143150(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    uint32_t *puVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    undefined uVar4;
    undefined2 uVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    uint32_t uVar22;
    undefined (*pauVar23) [32];
    undefined (*pauVar24) [32];
    undefined (*pauVar25) [32];
    undefined4 *puVar26;
    undefined (*pauVar27) [16];
    undefined (*pauVar28) [16];
    uint32_t uVar29;
    undefined (*pauVar30) [32];
    undefined (*pauVar31) [32];
    undefined4 *puVar32;
    int64_t unaff_RBX;
    undefined8 unaff_RBP;
    int32_t iVar33;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar34;
    int64_t iVar35;
    uint64_t uVar36;
    undefined auVar37 [16];
    undefined auVar38 [32];
    undefined auVar39 [32];
    undefined auVar40 [32];
    undefined auVar41 [32];
    undefined auVar42 [32];
    undefined auVar43 [32];
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_28h;
    int64_t var_8h;
    
    iVar35 = *(int64_t *)0x180781f28;
    if (((int32_t)arg1 == 0) || (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2674) != (int32_t)arg1)) {
        return;
    }
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x26f8) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2674);
    puVar1 = (uint32_t *)(iVar35 + 0x2700);
    if ((*(uint32_t *)(iVar35 + 0x2670) & 0x200) == 0) {
        uVar29 = *(int32_t *)(iVar35 + 0x2678) + 1;
        *(undefined8 **)0x20 = (BADSPACEBASE *)&uStack_30;
        uStack_30 = 0x1801431a4;
        unaff_RBX = iVar35;
    } else {
        uVar29 = 0;
    }
    *(int64_t *)((int64_t)*(undefined **)0x20 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RDI;
    iVar6 = *(int32_t *)(iVar35 + 0x2704);
    if ((int32_t)uVar29 <= iVar6) {
        *puVar1 = uVar29;
        return;
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + 0x10) = unaff_RSI;
    if (iVar6 == 0) {
        uVar22 = 8;
    } else {
        uVar22 = iVar6 / 2 + iVar6;
    }
    uVar36 = (uint64_t)uVar29;
    if ((int32_t)uVar29 < (int32_t)uVar22) {
        uVar36 = (uint64_t)uVar22;
    }
    iVar33 = (int32_t)uVar36;
    if (iVar33 <= iVar6) {
        *puVar1 = uVar29;
        return;
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + 8) = unaff_RBP;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18011f68b;
    pauVar23 = (undefined (*) [32])func_0x00018046d050((int64_t)iVar33);
    pauVar30 = *(undefined (**) [32])(iVar35 + 0x2708);
    if (pauVar30 == (undefined (*) [32])0x0) {
        *(undefined (**) [32])(iVar35 + 0x2708) = pauVar23;
        *(int32_t *)(iVar35 + 0x2704) = iVar33;
        *puVar1 = uVar29;
        return;
    }
    uVar34 = (uint64_t)(int32_t)*puVar1;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18011f6a2;
    // switch table (16 cases) at 0x180650960
    switch(uVar34) {
    case 0:
        return;
    case 1:
        (*pauVar23)[0] = (*pauVar30)[0];
        return;
    case 2:
        *(undefined2 *)*pauVar23 = *(undefined2 *)*pauVar30;
        return;
    case 3:
        uVar4 = (*pauVar30)[2];
        *(undefined2 *)*pauVar23 = *(undefined2 *)*pauVar30;
        (*pauVar23)[2] = uVar4;
        return;
    case 4:
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        return;
    case 5:
        uVar4 = (*pauVar30)[4];
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        (*pauVar23)[4] = uVar4;
        return;
    case 6:
        uVar5 = *(undefined2 *)(*pauVar30 + 4);
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 4) = uVar5;
        return;
    case 7:
        uVar5 = *(undefined2 *)(*pauVar30 + 4);
        uVar4 = (*pauVar30)[6];
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 4) = uVar5;
        (*pauVar23)[6] = uVar4;
        return;
    case 8:
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        return;
    case 9:
        uVar4 = (*pauVar30)[8];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        (*pauVar23)[8] = uVar4;
        return;
    case 10:
        uVar5 = *(undefined2 *)(*pauVar30 + 8);
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 8) = uVar5;
        return;
    case 0xb:
        uVar5 = *(undefined2 *)(*pauVar30 + 8);
        uVar4 = (*pauVar30)[10];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 8) = uVar5;
        (*pauVar23)[10] = uVar4;
        return;
    case 0xc:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        return;
    case 0xd:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        uVar4 = (*pauVar30)[0xc];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        (*pauVar23)[0xc] = uVar4;
        return;
    case 0xe:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        uVar5 = *(undefined2 *)(*pauVar30 + 0xc);
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        *(undefined2 *)(*pauVar23 + 0xc) = uVar5;
        return;
    case 0xf:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        uVar5 = *(undefined2 *)(*pauVar30 + 0xc);
        uVar4 = (*pauVar30)[0xe];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        *(undefined2 *)(*pauVar23 + 0xc) = uVar5;
        (*pauVar23)[0xe] = uVar4;
        return;
    }
    if (uVar34 < 0x21) {
        uVar7 = *(undefined4 *)(*pauVar30 + 4);
        uVar8 = *(undefined4 *)(*pauVar30 + 8);
        uVar9 = *(undefined4 *)(*pauVar30 + 0xc);
        puVar26 = (undefined4 *)(pauVar30[-1] + uVar34 + 0x10);
        uVar10 = *puVar26;
        uVar11 = puVar26[1];
        uVar12 = puVar26[2];
        uVar13 = puVar26[3];
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 4) = uVar7;
        *(undefined4 *)(*pauVar23 + 8) = uVar8;
        *(undefined4 *)(*pauVar23 + 0xc) = uVar9;
        puVar26 = (undefined4 *)(pauVar23[-1] + uVar34 + 0x10);
        *puVar26 = uVar10;
        puVar26[1] = uVar11;
        puVar26[2] = uVar12;
        puVar26[3] = uVar13;
        return;
    }
    pauVar24 = (undefined (*) [32])(*pauVar30 + uVar34);
    if (pauVar23 <= pauVar30) {
        pauVar24 = pauVar23;
    }
    if (pauVar23 < pauVar24) {
        uVar7 = *(undefined4 *)*pauVar30;
        uVar8 = *(undefined4 *)(*pauVar30 + 4);
        uVar9 = *(undefined4 *)(*pauVar30 + 8);
        uVar10 = *(undefined4 *)(*pauVar30 + 0xc);
        iVar35 = (int64_t)pauVar30 - (int64_t)pauVar23;
        auVar2 = *(undefined (*) [16])((int64_t)pauVar23 + iVar35 + (uVar34 - 0x10));
        pauVar28 = (undefined (*) [16])(pauVar23[-1] + uVar34 + 0x10);
        uVar34 = uVar34 - 0x10;
        pauVar27 = pauVar28;
        auVar37 = auVar2;
        if (((uint64_t)pauVar28 & 0xf) != 0) {
            pauVar27 = (undefined (*) [16])((uint64_t)pauVar28 & 0xfffffffffffffff0);
            auVar37 = *(undefined (*) [16])((int64_t)pauVar27 + iVar35);
            *pauVar28 = auVar2;
            uVar34 = (int64_t)pauVar27 - (int64_t)pauVar23;
        }
        uVar36 = uVar34 >> 7;
        if (uVar36 != 0) {
            *pauVar27 = auVar37;
            pauVar28 = pauVar27;
            while( true ) {
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x10);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                puVar32 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x20);
                uVar14 = *puVar32;
                uVar15 = puVar32[1];
                uVar16 = puVar32[2];
                uVar17 = puVar32[3];
                pauVar27 = pauVar28 + -8;
                *(undefined4 *)pauVar28[-1] = *puVar26;
                *(undefined4 *)(pauVar28[-1] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-1] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-1] + 0xc) = uVar13;
                *(undefined4 *)pauVar28[-2] = uVar14;
                *(undefined4 *)(pauVar28[-2] + 4) = uVar15;
                *(undefined4 *)(pauVar28[-2] + 8) = uVar16;
                *(undefined4 *)(pauVar28[-2] + 0xc) = uVar17;
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x30);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                puVar32 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x40);
                uVar14 = *puVar32;
                uVar15 = puVar32[1];
                uVar16 = puVar32[2];
                uVar17 = puVar32[3];
                uVar36 = uVar36 - 1;
                *(undefined4 *)pauVar28[-3] = *puVar26;
                *(undefined4 *)(pauVar28[-3] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-3] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-3] + 0xc) = uVar13;
                *(undefined4 *)pauVar28[-4] = uVar14;
                *(undefined4 *)(pauVar28[-4] + 4) = uVar15;
                *(undefined4 *)(pauVar28[-4] + 8) = uVar16;
                *(undefined4 *)(pauVar28[-4] + 0xc) = uVar17;
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x50);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                puVar32 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x60);
                uVar14 = *puVar32;
                uVar15 = puVar32[1];
                uVar16 = puVar32[2];
                uVar17 = puVar32[3];
                *(undefined4 *)pauVar28[-5] = *puVar26;
                *(undefined4 *)(pauVar28[-5] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-5] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-5] + 0xc) = uVar13;
                *(undefined4 *)pauVar28[-6] = uVar14;
                *(undefined4 *)(pauVar28[-6] + 4) = uVar15;
                *(undefined4 *)(pauVar28[-6] + 8) = uVar16;
                *(undefined4 *)(pauVar28[-6] + 0xc) = uVar17;
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x70);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                auVar37 = *(undefined (*) [16])((int64_t)pauVar27 + iVar35);
                if (uVar36 == 0) break;
                *(undefined4 *)pauVar28[-7] = *puVar26;
                *(undefined4 *)(pauVar28[-7] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-7] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-7] + 0xc) = uVar13;
                *pauVar27 = auVar37;
                pauVar28 = pauVar27;
            }
            *(undefined4 *)pauVar28[-7] = *puVar26;
            *(undefined4 *)(pauVar28[-7] + 4) = uVar11;
            *(undefined4 *)(pauVar28[-7] + 8) = uVar12;
            *(undefined4 *)(pauVar28[-7] + 0xc) = uVar13;
            uVar34 = uVar34 & 0x7f;
        }
        for (uVar36 = uVar34 >> 4; uVar36 != 0; uVar36 = uVar36 - 1) {
            *pauVar27 = auVar37;
            pauVar27 = pauVar27 + -1;
            auVar37 = *(undefined (*) [16])((int64_t)pauVar27 + iVar35);
        }
        if ((uVar34 & 0xf) != 0) {
            *(undefined4 *)*pauVar23 = uVar7;
            *(undefined4 *)(*pauVar23 + 4) = uVar8;
            *(undefined4 *)(*pauVar23 + 8) = uVar9;
            *(undefined4 *)(*pauVar23 + 0xc) = uVar10;
        }
        *pauVar27 = auVar37;
        return;
    }
    if (*(uint32_t *)0x1806a3990 < 3) {
        if ((uVar34 < 0x801) || ((*(uint8_t *)0x18078131c & 2) == 0)) {
            if (0x80 < uVar34) {
                iVar35 = ((uint64_t)pauVar23 & 0xf) - 0x10;
                puVar26 = (undefined4 *)((int64_t)pauVar23 - iVar35);
                puVar32 = (undefined4 *)((int64_t)pauVar30 - iVar35);
                uVar34 = uVar34 + iVar35;
                if (0x80 < uVar34) {
                    do {
                        uVar7 = puVar32[1];
                        uVar8 = puVar32[2];
                        uVar9 = puVar32[3];
                        uVar10 = puVar32[4];
                        uVar11 = puVar32[5];
                        uVar12 = puVar32[6];
                        uVar13 = puVar32[7];
                        uVar14 = puVar32[8];
                        uVar15 = puVar32[9];
                        uVar16 = puVar32[10];
                        uVar17 = puVar32[0xb];
                        uVar18 = puVar32[0xc];
                        uVar19 = puVar32[0xd];
                        uVar20 = puVar32[0xe];
                        uVar21 = puVar32[0xf];
                        *puVar26 = *puVar32;
                        puVar26[1] = uVar7;
                        puVar26[2] = uVar8;
                        puVar26[3] = uVar9;
                        puVar26[4] = uVar10;
                        puVar26[5] = uVar11;
                        puVar26[6] = uVar12;
                        puVar26[7] = uVar13;
                        puVar26[8] = uVar14;
                        puVar26[9] = uVar15;
                        puVar26[10] = uVar16;
                        puVar26[0xb] = uVar17;
                        puVar26[0xc] = uVar18;
                        puVar26[0xd] = uVar19;
                        puVar26[0xe] = uVar20;
                        puVar26[0xf] = uVar21;
                        auVar2 = *(undefined (*) [16])(puVar32 + 0x14);
                        auVar37 = *(undefined (*) [16])(puVar32 + 0x18);
                        auVar3 = *(undefined (*) [16])(puVar32 + 0x1c);
                        *(undefined (*) [16])(puVar26 + 0x10) = *(undefined (*) [16])(puVar32 + 0x10);
                        *(undefined (*) [16])(puVar26 + 0x14) = auVar2;
                        *(undefined (*) [16])(puVar26 + 0x18) = auVar37;
                        *(undefined (*) [16])(puVar26 + 0x1c) = auVar3;
                        puVar26 = puVar26 + 0x20;
                        puVar32 = puVar32 + 0x20;
                        uVar34 = uVar34 - 0x80;
                    } while (0x7f < uVar34);
                }
            }
    // WARNING: Could not recover jumptable at 0x000180498556. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (9 cases) at 0x1806509e8
            (*(code *)((uint64_t)*(uint32_t *)((uVar34 + 0xf >> 4) * 4 + 0x1806509e8) + 0x180000000))();
            return;
        }
code_r0x000180498020:
        *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x38) = (uint64_t)uVar29;
        *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x40) = uVar36;
        for (; uVar34 != 0; uVar34 = uVar34 - 1) {
            (*pauVar23)[0] = (*pauVar30)[0];
            pauVar30 = (undefined (*) [32])(*pauVar30 + 1);
            pauVar23 = (undefined (*) [32])(*pauVar23 + 1);
        }
        return;
    }
    if ((0x2000 < uVar34) && (uVar34 < 0x180001)) {
        pauVar24 = pauVar23 + 2;
        if (pauVar30 < pauVar23) {
            pauVar24 = pauVar30;
        }
        if ((pauVar24 <= pauVar30) && ((*(uint8_t *)0x18078131c & 2) != 0)) goto code_r0x000180498020;
    }
    auVar38 = vmovdqu_avx(*pauVar30);
    auVar43 = vmovdqu_avx(*(undefined (*) [32])(pauVar30[-1] + uVar34));
    if (0x100 < uVar34) {
        iVar35 = ((uint64_t)pauVar23 & 0x1f) - 0x20;
        pauVar24 = (undefined (*) [32])((int64_t)pauVar23 - iVar35);
        pauVar30 = (undefined (*) [32])((int64_t)pauVar30 - iVar35);
        uVar34 = uVar34 + iVar35;
        if (0x100 < uVar34) {
            if (0x180000 < uVar34) {
                do {
                    uVar36 = uVar34;
                    pauVar31 = pauVar30;
                    pauVar25 = pauVar24;
                    auVar39 = vmovdqu_avx(*pauVar31);
                    auVar41 = vmovdqu_avx(pauVar31[1]);
                    auVar40 = vmovdqu_avx(pauVar31[2]);
                    auVar42 = vmovdqu_avx(pauVar31[3]);
                    auVar39 = vmovntdq_avx(auVar39);
                    *pauVar25 = auVar39;
                    auVar39 = vmovntdq_avx(auVar41);
                    pauVar25[1] = auVar39;
                    auVar39 = vmovntdq_avx(auVar40);
                    pauVar25[2] = auVar39;
                    auVar39 = vmovntdq_avx(auVar42);
                    pauVar25[3] = auVar39;
                    auVar39 = vmovdqu_avx(pauVar31[4]);
                    auVar41 = vmovdqu_avx(pauVar31[5]);
                    auVar40 = vmovdqu_avx(pauVar31[6]);
                    auVar42 = vmovdqu_avx(pauVar31[7]);
                    auVar39 = vmovntdq_avx(auVar39);
                    pauVar25[4] = auVar39;
                    auVar39 = vmovntdq_avx(auVar41);
                    pauVar25[5] = auVar39;
                    auVar39 = vmovntdq_avx(auVar40);
                    pauVar25[6] = auVar39;
                    auVar39 = vmovntdq_avx(auVar42);
                    pauVar25[7] = auVar39;
                    pauVar24 = pauVar25 + 8;
                    pauVar30 = pauVar31 + 8;
                    uVar34 = uVar36 - 0x100;
                } while (0xff < uVar36 - 0x100);
                uVar34 = uVar36 - 0xe1 & 0xffffffffffffffe0;
    // switch table (18 cases) at 0x1806509c4
                switch(uVar36) {
                case 0x1e1:
                case 0x1e2:
                case 0x1e3:
                case 0x1e4:
                case 0x1e5:
                case 0x1e6:
                case 0x1e7:
                case 0x1e8:
                case 0x1e9:
                case 0x1ea:
                case 0x1eb:
                case 0x1ec:
                case 0x1ed:
                case 0x1ee:
                case 0x1ef:
                case 0x1f0:
                case 0x1f1:
                case 0x1f2:
                case 499:
                case 500:
                case 0x1f5:
                case 0x1f6:
                case 0x1f7:
                case 0x1f8:
                case 0x1f9:
                case 0x1fa:
                case 0x1fb:
                case 0x1fc:
                case 0x1fd:
                case 0x1fe:
                case 0x1ff:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(*pauVar31 + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(*pauVar25 + uVar34) = auVar39;
                case 0x1c1:
                case 0x1c2:
                case 0x1c3:
                case 0x1c4:
                case 0x1c5:
                case 0x1c6:
                case 0x1c7:
                case 0x1c8:
                case 0x1c9:
                case 0x1ca:
                case 0x1cb:
                case 0x1cc:
                case 0x1cd:
                case 0x1ce:
                case 0x1cf:
                case 0x1d0:
                case 0x1d1:
                case 0x1d2:
                case 0x1d3:
                case 0x1d4:
                case 0x1d5:
                case 0x1d6:
                case 0x1d7:
                case 0x1d8:
                case 0x1d9:
                case 0x1da:
                case 0x1db:
                case 0x1dc:
                case 0x1dd:
                case 0x1de:
                case 0x1df:
                case 0x1e0:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[1] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[1] + uVar34) = auVar39;
                case 0x1a1:
                case 0x1a2:
                case 0x1a3:
                case 0x1a4:
                case 0x1a5:
                case 0x1a6:
                case 0x1a7:
                case 0x1a8:
                case 0x1a9:
                case 0x1aa:
                case 0x1ab:
                case 0x1ac:
                case 0x1ad:
                case 0x1ae:
                case 0x1af:
                case 0x1b0:
                case 0x1b1:
                case 0x1b2:
                case 0x1b3:
                case 0x1b4:
                case 0x1b5:
                case 0x1b6:
                case 0x1b7:
                case 0x1b8:
                case 0x1b9:
                case 0x1ba:
                case 0x1bb:
                case 0x1bc:
                case 0x1bd:
                case 0x1be:
                case 0x1bf:
                case 0x1c0:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[2] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[2] + uVar34) = auVar39;
                case 0x181:
                case 0x182:
                case 0x183:
                case 0x184:
                case 0x185:
                case 0x186:
                case 0x187:
                case 0x188:
                case 0x189:
                case 0x18a:
                case 0x18b:
                case 0x18c:
                case 0x18d:
                case 0x18e:
                case 399:
                case 400:
                case 0x191:
                case 0x192:
                case 0x193:
                case 0x194:
                case 0x195:
                case 0x196:
                case 0x197:
                case 0x198:
                case 0x199:
                case 0x19a:
                case 0x19b:
                case 0x19c:
                case 0x19d:
                case 0x19e:
                case 0x19f:
                case 0x1a0:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[3] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[3] + uVar34) = auVar39;
                case 0x161:
                case 0x162:
                case 0x163:
                case 0x164:
                case 0x165:
                case 0x166:
                case 0x167:
                case 0x168:
                case 0x169:
                case 0x16a:
                case 0x16b:
                case 0x16c:
                case 0x16d:
                case 0x16e:
                case 0x16f:
                case 0x170:
                case 0x171:
                case 0x172:
                case 0x173:
                case 0x174:
                case 0x175:
                case 0x176:
                case 0x177:
                case 0x178:
                case 0x179:
                case 0x17a:
                case 0x17b:
                case 0x17c:
                case 0x17d:
                case 0x17e:
                case 0x17f:
                case 0x180:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[4] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[4] + uVar34) = auVar39;
                case 0x141:
                case 0x142:
                case 0x143:
                case 0x144:
                case 0x145:
                case 0x146:
                case 0x147:
                case 0x148:
                case 0x149:
                case 0x14a:
                case 0x14b:
                case 0x14c:
                case 0x14d:
                case 0x14e:
                case 0x14f:
                case 0x150:
                case 0x151:
                case 0x152:
                case 0x153:
                case 0x154:
                case 0x155:
                case 0x156:
                case 0x157:
                case 0x158:
                case 0x159:
                case 0x15a:
                case 0x15b:
                case 0x15c:
                case 0x15d:
                case 0x15e:
                case 0x15f:
                case 0x160:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[5] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[5] + uVar34) = auVar39;
                case 0x121:
                case 0x122:
                case 0x123:
                case 0x124:
                case 0x125:
                case 0x126:
                case 0x127:
                case 0x128:
                case 0x129:
                case 0x12a:
                case 299:
                case 300:
                case 0x12d:
                case 0x12e:
                case 0x12f:
                case 0x130:
                case 0x131:
                case 0x132:
                case 0x133:
                case 0x134:
                case 0x135:
                case 0x136:
                case 0x137:
                case 0x138:
                case 0x139:
                case 0x13a:
                case 0x13b:
                case 0x13c:
                case 0x13d:
                case 0x13e:
                case 0x13f:
                case 0x140:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[6] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[6] + uVar34) = auVar39;
                default:
                    auVar43 = vmovdqu_avx(auVar43);
                    *(undefined (*) [32])(pauVar25[-1] + uVar36) = auVar43;
                case 0x100:
                    auVar38 = vmovdqu_avx(auVar38);
                    *pauVar23 = auVar38;
                    return;
                }
            }
            do {
                auVar38 = vmovdqu_avx(*pauVar30);
                auVar43 = vmovdqu_avx(pauVar30[1]);
                auVar39 = vmovdqu_avx(pauVar30[2]);
                auVar41 = vmovdqu_avx(pauVar30[3]);
                *pauVar24 = auVar38;
                pauVar24[1] = auVar43;
                pauVar24[2] = auVar39;
                pauVar24[3] = auVar41;
                auVar38 = vmovdqu_avx(pauVar30[4]);
                auVar43 = vmovdqu_avx(pauVar30[5]);
                auVar39 = vmovdqu_avx(pauVar30[6]);
                auVar41 = vmovdqu_avx(pauVar30[7]);
                pauVar24[4] = auVar38;
                pauVar24[5] = auVar43;
                pauVar24[6] = auVar39;
                pauVar24[7] = auVar41;
                pauVar24 = pauVar24 + 8;
                pauVar30 = pauVar30 + 8;
                uVar34 = uVar34 - 0x100;
            } while (0xff < uVar34);
        }
    }
    // WARNING: Could not recover jumptable at 0x0001804982b2. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (27 cases) at 0x1806509a0
    (*(code *)((uint64_t)*(uint32_t *)((uVar34 + 0x1f >> 5) * 4 + 0x1806509a0) + 0x180000000))();
    return;
}

// ============================================================
// Function: FUN_180143158
// Address: 0x180143158
// Size: 63 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018011f69d: Changing call to branch
// WARNING: Possible PIC construction at 0x00018014319f: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018011f6a2)
// WARNING: Removing unreachable block (ram,0x0001801431a4)
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180143150(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    uint32_t *puVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    undefined uVar4;
    undefined2 uVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    uint32_t uVar22;
    undefined (*pauVar23) [32];
    undefined (*pauVar24) [32];
    undefined (*pauVar25) [32];
    undefined4 *puVar26;
    undefined (*pauVar27) [16];
    undefined (*pauVar28) [16];
    uint32_t uVar29;
    undefined (*pauVar30) [32];
    undefined (*pauVar31) [32];
    undefined4 *puVar32;
    int64_t unaff_RBX;
    undefined8 unaff_RBP;
    int32_t iVar33;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar34;
    int64_t iVar35;
    uint64_t uVar36;
    undefined auVar37 [16];
    undefined auVar38 [32];
    undefined auVar39 [32];
    undefined auVar40 [32];
    undefined auVar41 [32];
    undefined auVar42 [32];
    undefined auVar43 [32];
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_28h;
    int64_t var_8h;
    
    iVar35 = *(int64_t *)0x180781f28;
    if (((int32_t)arg1 == 0) || (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2674) != (int32_t)arg1)) {
        return;
    }
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x26f8) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2674);
    puVar1 = (uint32_t *)(iVar35 + 0x2700);
    if ((*(uint32_t *)(iVar35 + 0x2670) & 0x200) == 0) {
        uVar29 = *(int32_t *)(iVar35 + 0x2678) + 1;
        *(undefined8 **)0x20 = (BADSPACEBASE *)&uStack_30;
        uStack_30 = 0x1801431a4;
        unaff_RBX = iVar35;
    } else {
        uVar29 = 0;
    }
    *(int64_t *)((int64_t)*(undefined **)0x20 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RDI;
    iVar6 = *(int32_t *)(iVar35 + 0x2704);
    if ((int32_t)uVar29 <= iVar6) {
        *puVar1 = uVar29;
        return;
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + 0x10) = unaff_RSI;
    if (iVar6 == 0) {
        uVar22 = 8;
    } else {
        uVar22 = iVar6 / 2 + iVar6;
    }
    uVar36 = (uint64_t)uVar29;
    if ((int32_t)uVar29 < (int32_t)uVar22) {
        uVar36 = (uint64_t)uVar22;
    }
    iVar33 = (int32_t)uVar36;
    if (iVar33 <= iVar6) {
        *puVar1 = uVar29;
        return;
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + 8) = unaff_RBP;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18011f68b;
    pauVar23 = (undefined (*) [32])func_0x00018046d050((int64_t)iVar33);
    pauVar30 = *(undefined (**) [32])(iVar35 + 0x2708);
    if (pauVar30 == (undefined (*) [32])0x0) {
        *(undefined (**) [32])(iVar35 + 0x2708) = pauVar23;
        *(int32_t *)(iVar35 + 0x2704) = iVar33;
        *puVar1 = uVar29;
        return;
    }
    uVar34 = (uint64_t)(int32_t)*puVar1;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18011f6a2;
    // switch table (16 cases) at 0x180650960
    switch(uVar34) {
    case 0:
        return;
    case 1:
        (*pauVar23)[0] = (*pauVar30)[0];
        return;
    case 2:
        *(undefined2 *)*pauVar23 = *(undefined2 *)*pauVar30;
        return;
    case 3:
        uVar4 = (*pauVar30)[2];
        *(undefined2 *)*pauVar23 = *(undefined2 *)*pauVar30;
        (*pauVar23)[2] = uVar4;
        return;
    case 4:
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        return;
    case 5:
        uVar4 = (*pauVar30)[4];
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        (*pauVar23)[4] = uVar4;
        return;
    case 6:
        uVar5 = *(undefined2 *)(*pauVar30 + 4);
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 4) = uVar5;
        return;
    case 7:
        uVar5 = *(undefined2 *)(*pauVar30 + 4);
        uVar4 = (*pauVar30)[6];
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 4) = uVar5;
        (*pauVar23)[6] = uVar4;
        return;
    case 8:
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        return;
    case 9:
        uVar4 = (*pauVar30)[8];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        (*pauVar23)[8] = uVar4;
        return;
    case 10:
        uVar5 = *(undefined2 *)(*pauVar30 + 8);
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 8) = uVar5;
        return;
    case 0xb:
        uVar5 = *(undefined2 *)(*pauVar30 + 8);
        uVar4 = (*pauVar30)[10];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 8) = uVar5;
        (*pauVar23)[10] = uVar4;
        return;
    case 0xc:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        return;
    case 0xd:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        uVar4 = (*pauVar30)[0xc];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        (*pauVar23)[0xc] = uVar4;
        return;
    case 0xe:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        uVar5 = *(undefined2 *)(*pauVar30 + 0xc);
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        *(undefined2 *)(*pauVar23 + 0xc) = uVar5;
        return;
    case 0xf:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        uVar5 = *(undefined2 *)(*pauVar30 + 0xc);
        uVar4 = (*pauVar30)[0xe];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        *(undefined2 *)(*pauVar23 + 0xc) = uVar5;
        (*pauVar23)[0xe] = uVar4;
        return;
    }
    if (uVar34 < 0x21) {
        uVar7 = *(undefined4 *)(*pauVar30 + 4);
        uVar8 = *(undefined4 *)(*pauVar30 + 8);
        uVar9 = *(undefined4 *)(*pauVar30 + 0xc);
        puVar26 = (undefined4 *)(pauVar30[-1] + uVar34 + 0x10);
        uVar10 = *puVar26;
        uVar11 = puVar26[1];
        uVar12 = puVar26[2];
        uVar13 = puVar26[3];
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 4) = uVar7;
        *(undefined4 *)(*pauVar23 + 8) = uVar8;
        *(undefined4 *)(*pauVar23 + 0xc) = uVar9;
        puVar26 = (undefined4 *)(pauVar23[-1] + uVar34 + 0x10);
        *puVar26 = uVar10;
        puVar26[1] = uVar11;
        puVar26[2] = uVar12;
        puVar26[3] = uVar13;
        return;
    }
    pauVar24 = (undefined (*) [32])(*pauVar30 + uVar34);
    if (pauVar23 <= pauVar30) {
        pauVar24 = pauVar23;
    }
    if (pauVar23 < pauVar24) {
        uVar7 = *(undefined4 *)*pauVar30;
        uVar8 = *(undefined4 *)(*pauVar30 + 4);
        uVar9 = *(undefined4 *)(*pauVar30 + 8);
        uVar10 = *(undefined4 *)(*pauVar30 + 0xc);
        iVar35 = (int64_t)pauVar30 - (int64_t)pauVar23;
        auVar2 = *(undefined (*) [16])((int64_t)pauVar23 + iVar35 + (uVar34 - 0x10));
        pauVar28 = (undefined (*) [16])(pauVar23[-1] + uVar34 + 0x10);
        uVar34 = uVar34 - 0x10;
        pauVar27 = pauVar28;
        auVar37 = auVar2;
        if (((uint64_t)pauVar28 & 0xf) != 0) {
            pauVar27 = (undefined (*) [16])((uint64_t)pauVar28 & 0xfffffffffffffff0);
            auVar37 = *(undefined (*) [16])((int64_t)pauVar27 + iVar35);
            *pauVar28 = auVar2;
            uVar34 = (int64_t)pauVar27 - (int64_t)pauVar23;
        }
        uVar36 = uVar34 >> 7;
        if (uVar36 != 0) {
            *pauVar27 = auVar37;
            pauVar28 = pauVar27;
            while( true ) {
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x10);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                puVar32 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x20);
                uVar14 = *puVar32;
                uVar15 = puVar32[1];
                uVar16 = puVar32[2];
                uVar17 = puVar32[3];
                pauVar27 = pauVar28 + -8;
                *(undefined4 *)pauVar28[-1] = *puVar26;
                *(undefined4 *)(pauVar28[-1] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-1] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-1] + 0xc) = uVar13;
                *(undefined4 *)pauVar28[-2] = uVar14;
                *(undefined4 *)(pauVar28[-2] + 4) = uVar15;
                *(undefined4 *)(pauVar28[-2] + 8) = uVar16;
                *(undefined4 *)(pauVar28[-2] + 0xc) = uVar17;
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x30);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                puVar32 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x40);
                uVar14 = *puVar32;
                uVar15 = puVar32[1];
                uVar16 = puVar32[2];
                uVar17 = puVar32[3];
                uVar36 = uVar36 - 1;
                *(undefined4 *)pauVar28[-3] = *puVar26;
                *(undefined4 *)(pauVar28[-3] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-3] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-3] + 0xc) = uVar13;
                *(undefined4 *)pauVar28[-4] = uVar14;
                *(undefined4 *)(pauVar28[-4] + 4) = uVar15;
                *(undefined4 *)(pauVar28[-4] + 8) = uVar16;
                *(undefined4 *)(pauVar28[-4] + 0xc) = uVar17;
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x50);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                puVar32 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x60);
                uVar14 = *puVar32;
                uVar15 = puVar32[1];
                uVar16 = puVar32[2];
                uVar17 = puVar32[3];
                *(undefined4 *)pauVar28[-5] = *puVar26;
                *(undefined4 *)(pauVar28[-5] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-5] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-5] + 0xc) = uVar13;
                *(undefined4 *)pauVar28[-6] = uVar14;
                *(undefined4 *)(pauVar28[-6] + 4) = uVar15;
                *(undefined4 *)(pauVar28[-6] + 8) = uVar16;
                *(undefined4 *)(pauVar28[-6] + 0xc) = uVar17;
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x70);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                auVar37 = *(undefined (*) [16])((int64_t)pauVar27 + iVar35);
                if (uVar36 == 0) break;
                *(undefined4 *)pauVar28[-7] = *puVar26;
                *(undefined4 *)(pauVar28[-7] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-7] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-7] + 0xc) = uVar13;
                *pauVar27 = auVar37;
                pauVar28 = pauVar27;
            }
            *(undefined4 *)pauVar28[-7] = *puVar26;
            *(undefined4 *)(pauVar28[-7] + 4) = uVar11;
            *(undefined4 *)(pauVar28[-7] + 8) = uVar12;
            *(undefined4 *)(pauVar28[-7] + 0xc) = uVar13;
            uVar34 = uVar34 & 0x7f;
        }
        for (uVar36 = uVar34 >> 4; uVar36 != 0; uVar36 = uVar36 - 1) {
            *pauVar27 = auVar37;
            pauVar27 = pauVar27 + -1;
            auVar37 = *(undefined (*) [16])((int64_t)pauVar27 + iVar35);
        }
        if ((uVar34 & 0xf) != 0) {
            *(undefined4 *)*pauVar23 = uVar7;
            *(undefined4 *)(*pauVar23 + 4) = uVar8;
            *(undefined4 *)(*pauVar23 + 8) = uVar9;
            *(undefined4 *)(*pauVar23 + 0xc) = uVar10;
        }
        *pauVar27 = auVar37;
        return;
    }
    if (*(uint32_t *)0x1806a3990 < 3) {
        if ((uVar34 < 0x801) || ((*(uint8_t *)0x18078131c & 2) == 0)) {
            if (0x80 < uVar34) {
                iVar35 = ((uint64_t)pauVar23 & 0xf) - 0x10;
                puVar26 = (undefined4 *)((int64_t)pauVar23 - iVar35);
                puVar32 = (undefined4 *)((int64_t)pauVar30 - iVar35);
                uVar34 = uVar34 + iVar35;
                if (0x80 < uVar34) {
                    do {
                        uVar7 = puVar32[1];
                        uVar8 = puVar32[2];
                        uVar9 = puVar32[3];
                        uVar10 = puVar32[4];
                        uVar11 = puVar32[5];
                        uVar12 = puVar32[6];
                        uVar13 = puVar32[7];
                        uVar14 = puVar32[8];
                        uVar15 = puVar32[9];
                        uVar16 = puVar32[10];
                        uVar17 = puVar32[0xb];
                        uVar18 = puVar32[0xc];
                        uVar19 = puVar32[0xd];
                        uVar20 = puVar32[0xe];
                        uVar21 = puVar32[0xf];
                        *puVar26 = *puVar32;
                        puVar26[1] = uVar7;
                        puVar26[2] = uVar8;
                        puVar26[3] = uVar9;
                        puVar26[4] = uVar10;
                        puVar26[5] = uVar11;
                        puVar26[6] = uVar12;
                        puVar26[7] = uVar13;
                        puVar26[8] = uVar14;
                        puVar26[9] = uVar15;
                        puVar26[10] = uVar16;
                        puVar26[0xb] = uVar17;
                        puVar26[0xc] = uVar18;
                        puVar26[0xd] = uVar19;
                        puVar26[0xe] = uVar20;
                        puVar26[0xf] = uVar21;
                        auVar2 = *(undefined (*) [16])(puVar32 + 0x14);
                        auVar37 = *(undefined (*) [16])(puVar32 + 0x18);
                        auVar3 = *(undefined (*) [16])(puVar32 + 0x1c);
                        *(undefined (*) [16])(puVar26 + 0x10) = *(undefined (*) [16])(puVar32 + 0x10);
                        *(undefined (*) [16])(puVar26 + 0x14) = auVar2;
                        *(undefined (*) [16])(puVar26 + 0x18) = auVar37;
                        *(undefined (*) [16])(puVar26 + 0x1c) = auVar3;
                        puVar26 = puVar26 + 0x20;
                        puVar32 = puVar32 + 0x20;
                        uVar34 = uVar34 - 0x80;
                    } while (0x7f < uVar34);
                }
            }
    // WARNING: Could not recover jumptable at 0x000180498556. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (9 cases) at 0x1806509e8
            (*(code *)((uint64_t)*(uint32_t *)((uVar34 + 0xf >> 4) * 4 + 0x1806509e8) + 0x180000000))();
            return;
        }
code_r0x000180498020:
        *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x38) = (uint64_t)uVar29;
        *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x40) = uVar36;
        for (; uVar34 != 0; uVar34 = uVar34 - 1) {
            (*pauVar23)[0] = (*pauVar30)[0];
            pauVar30 = (undefined (*) [32])(*pauVar30 + 1);
            pauVar23 = (undefined (*) [32])(*pauVar23 + 1);
        }
        return;
    }
    if ((0x2000 < uVar34) && (uVar34 < 0x180001)) {
        pauVar24 = pauVar23 + 2;
        if (pauVar30 < pauVar23) {
            pauVar24 = pauVar30;
        }
        if ((pauVar24 <= pauVar30) && ((*(uint8_t *)0x18078131c & 2) != 0)) goto code_r0x000180498020;
    }
    auVar38 = vmovdqu_avx(*pauVar30);
    auVar43 = vmovdqu_avx(*(undefined (*) [32])(pauVar30[-1] + uVar34));
    if (0x100 < uVar34) {
        iVar35 = ((uint64_t)pauVar23 & 0x1f) - 0x20;
        pauVar24 = (undefined (*) [32])((int64_t)pauVar23 - iVar35);
        pauVar30 = (undefined (*) [32])((int64_t)pauVar30 - iVar35);
        uVar34 = uVar34 + iVar35;
        if (0x100 < uVar34) {
            if (0x180000 < uVar34) {
                do {
                    uVar36 = uVar34;
                    pauVar31 = pauVar30;
                    pauVar25 = pauVar24;
                    auVar39 = vmovdqu_avx(*pauVar31);
                    auVar41 = vmovdqu_avx(pauVar31[1]);
                    auVar40 = vmovdqu_avx(pauVar31[2]);
                    auVar42 = vmovdqu_avx(pauVar31[3]);
                    auVar39 = vmovntdq_avx(auVar39);
                    *pauVar25 = auVar39;
                    auVar39 = vmovntdq_avx(auVar41);
                    pauVar25[1] = auVar39;
                    auVar39 = vmovntdq_avx(auVar40);
                    pauVar25[2] = auVar39;
                    auVar39 = vmovntdq_avx(auVar42);
                    pauVar25[3] = auVar39;
                    auVar39 = vmovdqu_avx(pauVar31[4]);
                    auVar41 = vmovdqu_avx(pauVar31[5]);
                    auVar40 = vmovdqu_avx(pauVar31[6]);
                    auVar42 = vmovdqu_avx(pauVar31[7]);
                    auVar39 = vmovntdq_avx(auVar39);
                    pauVar25[4] = auVar39;
                    auVar39 = vmovntdq_avx(auVar41);
                    pauVar25[5] = auVar39;
                    auVar39 = vmovntdq_avx(auVar40);
                    pauVar25[6] = auVar39;
                    auVar39 = vmovntdq_avx(auVar42);
                    pauVar25[7] = auVar39;
                    pauVar24 = pauVar25 + 8;
                    pauVar30 = pauVar31 + 8;
                    uVar34 = uVar36 - 0x100;
                } while (0xff < uVar36 - 0x100);
                uVar34 = uVar36 - 0xe1 & 0xffffffffffffffe0;
    // switch table (18 cases) at 0x1806509c4
                switch(uVar36) {
                case 0x1e1:
                case 0x1e2:
                case 0x1e3:
                case 0x1e4:
                case 0x1e5:
                case 0x1e6:
                case 0x1e7:
                case 0x1e8:
                case 0x1e9:
                case 0x1ea:
                case 0x1eb:
                case 0x1ec:
                case 0x1ed:
                case 0x1ee:
                case 0x1ef:
                case 0x1f0:
                case 0x1f1:
                case 0x1f2:
                case 499:
                case 500:
                case 0x1f5:
                case 0x1f6:
                case 0x1f7:
                case 0x1f8:
                case 0x1f9:
                case 0x1fa:
                case 0x1fb:
                case 0x1fc:
                case 0x1fd:
                case 0x1fe:
                case 0x1ff:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(*pauVar31 + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(*pauVar25 + uVar34) = auVar39;
                case 0x1c1:
                case 0x1c2:
                case 0x1c3:
                case 0x1c4:
                case 0x1c5:
                case 0x1c6:
                case 0x1c7:
                case 0x1c8:
                case 0x1c9:
                case 0x1ca:
                case 0x1cb:
                case 0x1cc:
                case 0x1cd:
                case 0x1ce:
                case 0x1cf:
                case 0x1d0:
                case 0x1d1:
                case 0x1d2:
                case 0x1d3:
                case 0x1d4:
                case 0x1d5:
                case 0x1d6:
                case 0x1d7:
                case 0x1d8:
                case 0x1d9:
                case 0x1da:
                case 0x1db:
                case 0x1dc:
                case 0x1dd:
                case 0x1de:
                case 0x1df:
                case 0x1e0:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[1] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[1] + uVar34) = auVar39;
                case 0x1a1:
                case 0x1a2:
                case 0x1a3:
                case 0x1a4:
                case 0x1a5:
                case 0x1a6:
                case 0x1a7:
                case 0x1a8:
                case 0x1a9:
                case 0x1aa:
                case 0x1ab:
                case 0x1ac:
                case 0x1ad:
                case 0x1ae:
                case 0x1af:
                case 0x1b0:
                case 0x1b1:
                case 0x1b2:
                case 0x1b3:
                case 0x1b4:
                case 0x1b5:
                case 0x1b6:
                case 0x1b7:
                case 0x1b8:
                case 0x1b9:
                case 0x1ba:
                case 0x1bb:
                case 0x1bc:
                case 0x1bd:
                case 0x1be:
                case 0x1bf:
                case 0x1c0:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[2] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[2] + uVar34) = auVar39;
                case 0x181:
                case 0x182:
                case 0x183:
                case 0x184:
                case 0x185:
                case 0x186:
                case 0x187:
                case 0x188:
                case 0x189:
                case 0x18a:
                case 0x18b:
                case 0x18c:
                case 0x18d:
                case 0x18e:
                case 399:
                case 400:
                case 0x191:
                case 0x192:
                case 0x193:
                case 0x194:
                case 0x195:
                case 0x196:
                case 0x197:
                case 0x198:
                case 0x199:
                case 0x19a:
                case 0x19b:
                case 0x19c:
                case 0x19d:
                case 0x19e:
                case 0x19f:
                case 0x1a0:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[3] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[3] + uVar34) = auVar39;
                case 0x161:
                case 0x162:
                case 0x163:
                case 0x164:
                case 0x165:
                case 0x166:
                case 0x167:
                case 0x168:
                case 0x169:
                case 0x16a:
                case 0x16b:
                case 0x16c:
                case 0x16d:
                case 0x16e:
                case 0x16f:
                case 0x170:
                case 0x171:
                case 0x172:
                case 0x173:
                case 0x174:
                case 0x175:
                case 0x176:
                case 0x177:
                case 0x178:
                case 0x179:
                case 0x17a:
                case 0x17b:
                case 0x17c:
                case 0x17d:
                case 0x17e:
                case 0x17f:
                case 0x180:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[4] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[4] + uVar34) = auVar39;
                case 0x141:
                case 0x142:
                case 0x143:
                case 0x144:
                case 0x145:
                case 0x146:
                case 0x147:
                case 0x148:
                case 0x149:
                case 0x14a:
                case 0x14b:
                case 0x14c:
                case 0x14d:
                case 0x14e:
                case 0x14f:
                case 0x150:
                case 0x151:
                case 0x152:
                case 0x153:
                case 0x154:
                case 0x155:
                case 0x156:
                case 0x157:
                case 0x158:
                case 0x159:
                case 0x15a:
                case 0x15b:
                case 0x15c:
                case 0x15d:
                case 0x15e:
                case 0x15f:
                case 0x160:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[5] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[5] + uVar34) = auVar39;
                case 0x121:
                case 0x122:
                case 0x123:
                case 0x124:
                case 0x125:
                case 0x126:
                case 0x127:
                case 0x128:
                case 0x129:
                case 0x12a:
                case 299:
                case 300:
                case 0x12d:
                case 0x12e:
                case 0x12f:
                case 0x130:
                case 0x131:
                case 0x132:
                case 0x133:
                case 0x134:
                case 0x135:
                case 0x136:
                case 0x137:
                case 0x138:
                case 0x139:
                case 0x13a:
                case 0x13b:
                case 0x13c:
                case 0x13d:
                case 0x13e:
                case 0x13f:
                case 0x140:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[6] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[6] + uVar34) = auVar39;
                default:
                    auVar43 = vmovdqu_avx(auVar43);
                    *(undefined (*) [32])(pauVar25[-1] + uVar36) = auVar43;
                case 0x100:
                    auVar38 = vmovdqu_avx(auVar38);
                    *pauVar23 = auVar38;
                    return;
                }
            }
            do {
                auVar38 = vmovdqu_avx(*pauVar30);
                auVar43 = vmovdqu_avx(pauVar30[1]);
                auVar39 = vmovdqu_avx(pauVar30[2]);
                auVar41 = vmovdqu_avx(pauVar30[3]);
                *pauVar24 = auVar38;
                pauVar24[1] = auVar43;
                pauVar24[2] = auVar39;
                pauVar24[3] = auVar41;
                auVar38 = vmovdqu_avx(pauVar30[4]);
                auVar43 = vmovdqu_avx(pauVar30[5]);
                auVar39 = vmovdqu_avx(pauVar30[6]);
                auVar41 = vmovdqu_avx(pauVar30[7]);
                pauVar24[4] = auVar38;
                pauVar24[5] = auVar43;
                pauVar24[6] = auVar39;
                pauVar24[7] = auVar41;
                pauVar24 = pauVar24 + 8;
                pauVar30 = pauVar30 + 8;
                uVar34 = uVar34 - 0x100;
            } while (0xff < uVar34);
        }
    }
    // WARNING: Could not recover jumptable at 0x0001804982b2. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (27 cases) at 0x1806509a0
    (*(code *)((uint64_t)*(uint32_t *)((uVar34 + 0x1f >> 5) * 4 + 0x1806509a0) + 0x180000000))();
    return;
}

// ============================================================
// Function: FUN_180143197
// Address: 0x180143197
// Size: 52 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018011f69d: Changing call to branch
// WARNING: Possible PIC construction at 0x00018014319f: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018011f6a2)
// WARNING: Removing unreachable block (ram,0x0001801431a4)
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180143150(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    uint32_t *puVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    undefined uVar4;
    undefined2 uVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    uint32_t uVar22;
    undefined (*pauVar23) [32];
    undefined (*pauVar24) [32];
    undefined (*pauVar25) [32];
    undefined4 *puVar26;
    undefined (*pauVar27) [16];
    undefined (*pauVar28) [16];
    uint32_t uVar29;
    undefined (*pauVar30) [32];
    undefined (*pauVar31) [32];
    undefined4 *puVar32;
    int64_t unaff_RBX;
    undefined8 unaff_RBP;
    int32_t iVar33;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar34;
    int64_t iVar35;
    uint64_t uVar36;
    undefined auVar37 [16];
    undefined auVar38 [32];
    undefined auVar39 [32];
    undefined auVar40 [32];
    undefined auVar41 [32];
    undefined auVar42 [32];
    undefined auVar43 [32];
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_28h;
    int64_t var_8h;
    
    iVar35 = *(int64_t *)0x180781f28;
    if (((int32_t)arg1 == 0) || (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2674) != (int32_t)arg1)) {
        return;
    }
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x26f8) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2674);
    puVar1 = (uint32_t *)(iVar35 + 0x2700);
    if ((*(uint32_t *)(iVar35 + 0x2670) & 0x200) == 0) {
        uVar29 = *(int32_t *)(iVar35 + 0x2678) + 1;
        *(undefined8 **)0x20 = (BADSPACEBASE *)&uStack_30;
        uStack_30 = 0x1801431a4;
        unaff_RBX = iVar35;
    } else {
        uVar29 = 0;
    }
    *(int64_t *)((int64_t)*(undefined **)0x20 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RDI;
    iVar6 = *(int32_t *)(iVar35 + 0x2704);
    if ((int32_t)uVar29 <= iVar6) {
        *puVar1 = uVar29;
        return;
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + 0x10) = unaff_RSI;
    if (iVar6 == 0) {
        uVar22 = 8;
    } else {
        uVar22 = iVar6 / 2 + iVar6;
    }
    uVar36 = (uint64_t)uVar29;
    if ((int32_t)uVar29 < (int32_t)uVar22) {
        uVar36 = (uint64_t)uVar22;
    }
    iVar33 = (int32_t)uVar36;
    if (iVar33 <= iVar6) {
        *puVar1 = uVar29;
        return;
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + 8) = unaff_RBP;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18011f68b;
    pauVar23 = (undefined (*) [32])func_0x00018046d050((int64_t)iVar33);
    pauVar30 = *(undefined (**) [32])(iVar35 + 0x2708);
    if (pauVar30 == (undefined (*) [32])0x0) {
        *(undefined (**) [32])(iVar35 + 0x2708) = pauVar23;
        *(int32_t *)(iVar35 + 0x2704) = iVar33;
        *puVar1 = uVar29;
        return;
    }
    uVar34 = (uint64_t)(int32_t)*puVar1;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18011f6a2;
    // switch table (16 cases) at 0x180650960
    switch(uVar34) {
    case 0:
        return;
    case 1:
        (*pauVar23)[0] = (*pauVar30)[0];
        return;
    case 2:
        *(undefined2 *)*pauVar23 = *(undefined2 *)*pauVar30;
        return;
    case 3:
        uVar4 = (*pauVar30)[2];
        *(undefined2 *)*pauVar23 = *(undefined2 *)*pauVar30;
        (*pauVar23)[2] = uVar4;
        return;
    case 4:
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        return;
    case 5:
        uVar4 = (*pauVar30)[4];
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        (*pauVar23)[4] = uVar4;
        return;
    case 6:
        uVar5 = *(undefined2 *)(*pauVar30 + 4);
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 4) = uVar5;
        return;
    case 7:
        uVar5 = *(undefined2 *)(*pauVar30 + 4);
        uVar4 = (*pauVar30)[6];
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 4) = uVar5;
        (*pauVar23)[6] = uVar4;
        return;
    case 8:
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        return;
    case 9:
        uVar4 = (*pauVar30)[8];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        (*pauVar23)[8] = uVar4;
        return;
    case 10:
        uVar5 = *(undefined2 *)(*pauVar30 + 8);
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 8) = uVar5;
        return;
    case 0xb:
        uVar5 = *(undefined2 *)(*pauVar30 + 8);
        uVar4 = (*pauVar30)[10];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 8) = uVar5;
        (*pauVar23)[10] = uVar4;
        return;
    case 0xc:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        return;
    case 0xd:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        uVar4 = (*pauVar30)[0xc];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        (*pauVar23)[0xc] = uVar4;
        return;
    case 0xe:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        uVar5 = *(undefined2 *)(*pauVar30 + 0xc);
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        *(undefined2 *)(*pauVar23 + 0xc) = uVar5;
        return;
    case 0xf:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        uVar5 = *(undefined2 *)(*pauVar30 + 0xc);
        uVar4 = (*pauVar30)[0xe];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        *(undefined2 *)(*pauVar23 + 0xc) = uVar5;
        (*pauVar23)[0xe] = uVar4;
        return;
    }
    if (uVar34 < 0x21) {
        uVar7 = *(undefined4 *)(*pauVar30 + 4);
        uVar8 = *(undefined4 *)(*pauVar30 + 8);
        uVar9 = *(undefined4 *)(*pauVar30 + 0xc);
        puVar26 = (undefined4 *)(pauVar30[-1] + uVar34 + 0x10);
        uVar10 = *puVar26;
        uVar11 = puVar26[1];
        uVar12 = puVar26[2];
        uVar13 = puVar26[3];
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 4) = uVar7;
        *(undefined4 *)(*pauVar23 + 8) = uVar8;
        *(undefined4 *)(*pauVar23 + 0xc) = uVar9;
        puVar26 = (undefined4 *)(pauVar23[-1] + uVar34 + 0x10);
        *puVar26 = uVar10;
        puVar26[1] = uVar11;
        puVar26[2] = uVar12;
        puVar26[3] = uVar13;
        return;
    }
    pauVar24 = (undefined (*) [32])(*pauVar30 + uVar34);
    if (pauVar23 <= pauVar30) {
        pauVar24 = pauVar23;
    }
    if (pauVar23 < pauVar24) {
        uVar7 = *(undefined4 *)*pauVar30;
        uVar8 = *(undefined4 *)(*pauVar30 + 4);
        uVar9 = *(undefined4 *)(*pauVar30 + 8);
        uVar10 = *(undefined4 *)(*pauVar30 + 0xc);
        iVar35 = (int64_t)pauVar30 - (int64_t)pauVar23;
        auVar2 = *(undefined (*) [16])((int64_t)pauVar23 + iVar35 + (uVar34 - 0x10));
        pauVar28 = (undefined (*) [16])(pauVar23[-1] + uVar34 + 0x10);
        uVar34 = uVar34 - 0x10;
        pauVar27 = pauVar28;
        auVar37 = auVar2;
        if (((uint64_t)pauVar28 & 0xf) != 0) {
            pauVar27 = (undefined (*) [16])((uint64_t)pauVar28 & 0xfffffffffffffff0);
            auVar37 = *(undefined (*) [16])((int64_t)pauVar27 + iVar35);
            *pauVar28 = auVar2;
            uVar34 = (int64_t)pauVar27 - (int64_t)pauVar23;
        }
        uVar36 = uVar34 >> 7;
        if (uVar36 != 0) {
            *pauVar27 = auVar37;
            pauVar28 = pauVar27;
            while( true ) {
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x10);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                puVar32 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x20);
                uVar14 = *puVar32;
                uVar15 = puVar32[1];
                uVar16 = puVar32[2];
                uVar17 = puVar32[3];
                pauVar27 = pauVar28 + -8;
                *(undefined4 *)pauVar28[-1] = *puVar26;
                *(undefined4 *)(pauVar28[-1] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-1] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-1] + 0xc) = uVar13;
                *(undefined4 *)pauVar28[-2] = uVar14;
                *(undefined4 *)(pauVar28[-2] + 4) = uVar15;
                *(undefined4 *)(pauVar28[-2] + 8) = uVar16;
                *(undefined4 *)(pauVar28[-2] + 0xc) = uVar17;
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x30);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                puVar32 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x40);
                uVar14 = *puVar32;
                uVar15 = puVar32[1];
                uVar16 = puVar32[2];
                uVar17 = puVar32[3];
                uVar36 = uVar36 - 1;
                *(undefined4 *)pauVar28[-3] = *puVar26;
                *(undefined4 *)(pauVar28[-3] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-3] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-3] + 0xc) = uVar13;
                *(undefined4 *)pauVar28[-4] = uVar14;
                *(undefined4 *)(pauVar28[-4] + 4) = uVar15;
                *(undefined4 *)(pauVar28[-4] + 8) = uVar16;
                *(undefined4 *)(pauVar28[-4] + 0xc) = uVar17;
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x50);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                puVar32 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x60);
                uVar14 = *puVar32;
                uVar15 = puVar32[1];
                uVar16 = puVar32[2];
                uVar17 = puVar32[3];
                *(undefined4 *)pauVar28[-5] = *puVar26;
                *(undefined4 *)(pauVar28[-5] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-5] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-5] + 0xc) = uVar13;
                *(undefined4 *)pauVar28[-6] = uVar14;
                *(undefined4 *)(pauVar28[-6] + 4) = uVar15;
                *(undefined4 *)(pauVar28[-6] + 8) = uVar16;
                *(undefined4 *)(pauVar28[-6] + 0xc) = uVar17;
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x70);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                auVar37 = *(undefined (*) [16])((int64_t)pauVar27 + iVar35);
                if (uVar36 == 0) break;
                *(undefined4 *)pauVar28[-7] = *puVar26;
                *(undefined4 *)(pauVar28[-7] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-7] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-7] + 0xc) = uVar13;
                *pauVar27 = auVar37;
                pauVar28 = pauVar27;
            }
            *(undefined4 *)pauVar28[-7] = *puVar26;
            *(undefined4 *)(pauVar28[-7] + 4) = uVar11;
            *(undefined4 *)(pauVar28[-7] + 8) = uVar12;
            *(undefined4 *)(pauVar28[-7] + 0xc) = uVar13;
            uVar34 = uVar34 & 0x7f;
        }
        for (uVar36 = uVar34 >> 4; uVar36 != 0; uVar36 = uVar36 - 1) {
            *pauVar27 = auVar37;
            pauVar27 = pauVar27 + -1;
            auVar37 = *(undefined (*) [16])((int64_t)pauVar27 + iVar35);
        }
        if ((uVar34 & 0xf) != 0) {
            *(undefined4 *)*pauVar23 = uVar7;
            *(undefined4 *)(*pauVar23 + 4) = uVar8;
            *(undefined4 *)(*pauVar23 + 8) = uVar9;
            *(undefined4 *)(*pauVar23 + 0xc) = uVar10;
        }
        *pauVar27 = auVar37;
        return;
    }
    if (*(uint32_t *)0x1806a3990 < 3) {
        if ((uVar34 < 0x801) || ((*(uint8_t *)0x18078131c & 2) == 0)) {
            if (0x80 < uVar34) {
                iVar35 = ((uint64_t)pauVar23 & 0xf) - 0x10;
                puVar26 = (undefined4 *)((int64_t)pauVar23 - iVar35);
                puVar32 = (undefined4 *)((int64_t)pauVar30 - iVar35);
                uVar34 = uVar34 + iVar35;
                if (0x80 < uVar34) {
                    do {
                        uVar7 = puVar32[1];
                        uVar8 = puVar32[2];
                        uVar9 = puVar32[3];
                        uVar10 = puVar32[4];
                        uVar11 = puVar32[5];
                        uVar12 = puVar32[6];
                        uVar13 = puVar32[7];
                        uVar14 = puVar32[8];
                        uVar15 = puVar32[9];
                        uVar16 = puVar32[10];
                        uVar17 = puVar32[0xb];
                        uVar18 = puVar32[0xc];
                        uVar19 = puVar32[0xd];
                        uVar20 = puVar32[0xe];
                        uVar21 = puVar32[0xf];
                        *puVar26 = *puVar32;
                        puVar26[1] = uVar7;
                        puVar26[2] = uVar8;
                        puVar26[3] = uVar9;
                        puVar26[4] = uVar10;
                        puVar26[5] = uVar11;
                        puVar26[6] = uVar12;
                        puVar26[7] = uVar13;
                        puVar26[8] = uVar14;
                        puVar26[9] = uVar15;
                        puVar26[10] = uVar16;
                        puVar26[0xb] = uVar17;
                        puVar26[0xc] = uVar18;
                        puVar26[0xd] = uVar19;
                        puVar26[0xe] = uVar20;
                        puVar26[0xf] = uVar21;
                        auVar2 = *(undefined (*) [16])(puVar32 + 0x14);
                        auVar37 = *(undefined (*) [16])(puVar32 + 0x18);
                        auVar3 = *(undefined (*) [16])(puVar32 + 0x1c);
                        *(undefined (*) [16])(puVar26 + 0x10) = *(undefined (*) [16])(puVar32 + 0x10);
                        *(undefined (*) [16])(puVar26 + 0x14) = auVar2;
                        *(undefined (*) [16])(puVar26 + 0x18) = auVar37;
                        *(undefined (*) [16])(puVar26 + 0x1c) = auVar3;
                        puVar26 = puVar26 + 0x20;
                        puVar32 = puVar32 + 0x20;
                        uVar34 = uVar34 - 0x80;
                    } while (0x7f < uVar34);
                }
            }
    // WARNING: Could not recover jumptable at 0x000180498556. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (9 cases) at 0x1806509e8
            (*(code *)((uint64_t)*(uint32_t *)((uVar34 + 0xf >> 4) * 4 + 0x1806509e8) + 0x180000000))();
            return;
        }
code_r0x000180498020:
        *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x38) = (uint64_t)uVar29;
        *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x40) = uVar36;
        for (; uVar34 != 0; uVar34 = uVar34 - 1) {
            (*pauVar23)[0] = (*pauVar30)[0];
            pauVar30 = (undefined (*) [32])(*pauVar30 + 1);
            pauVar23 = (undefined (*) [32])(*pauVar23 + 1);
        }
        return;
    }
    if ((0x2000 < uVar34) && (uVar34 < 0x180001)) {
        pauVar24 = pauVar23 + 2;
        if (pauVar30 < pauVar23) {
            pauVar24 = pauVar30;
        }
        if ((pauVar24 <= pauVar30) && ((*(uint8_t *)0x18078131c & 2) != 0)) goto code_r0x000180498020;
    }
    auVar38 = vmovdqu_avx(*pauVar30);
    auVar43 = vmovdqu_avx(*(undefined (*) [32])(pauVar30[-1] + uVar34));
    if (0x100 < uVar34) {
        iVar35 = ((uint64_t)pauVar23 & 0x1f) - 0x20;
        pauVar24 = (undefined (*) [32])((int64_t)pauVar23 - iVar35);
        pauVar30 = (undefined (*) [32])((int64_t)pauVar30 - iVar35);
        uVar34 = uVar34 + iVar35;
        if (0x100 < uVar34) {
            if (0x180000 < uVar34) {
                do {
                    uVar36 = uVar34;
                    pauVar31 = pauVar30;
                    pauVar25 = pauVar24;
                    auVar39 = vmovdqu_avx(*pauVar31);
                    auVar41 = vmovdqu_avx(pauVar31[1]);
                    auVar40 = vmovdqu_avx(pauVar31[2]);
                    auVar42 = vmovdqu_avx(pauVar31[3]);
                    auVar39 = vmovntdq_avx(auVar39);
                    *pauVar25 = auVar39;
                    auVar39 = vmovntdq_avx(auVar41);
                    pauVar25[1] = auVar39;
                    auVar39 = vmovntdq_avx(auVar40);
                    pauVar25[2] = auVar39;
                    auVar39 = vmovntdq_avx(auVar42);
                    pauVar25[3] = auVar39;
                    auVar39 = vmovdqu_avx(pauVar31[4]);
                    auVar41 = vmovdqu_avx(pauVar31[5]);
                    auVar40 = vmovdqu_avx(pauVar31[6]);
                    auVar42 = vmovdqu_avx(pauVar31[7]);
                    auVar39 = vmovntdq_avx(auVar39);
                    pauVar25[4] = auVar39;
                    auVar39 = vmovntdq_avx(auVar41);
                    pauVar25[5] = auVar39;
                    auVar39 = vmovntdq_avx(auVar40);
                    pauVar25[6] = auVar39;
                    auVar39 = vmovntdq_avx(auVar42);
                    pauVar25[7] = auVar39;
                    pauVar24 = pauVar25 + 8;
                    pauVar30 = pauVar31 + 8;
                    uVar34 = uVar36 - 0x100;
                } while (0xff < uVar36 - 0x100);
                uVar34 = uVar36 - 0xe1 & 0xffffffffffffffe0;
    // switch table (18 cases) at 0x1806509c4
                switch(uVar36) {
                case 0x1e1:
                case 0x1e2:
                case 0x1e3:
                case 0x1e4:
                case 0x1e5:
                case 0x1e6:
                case 0x1e7:
                case 0x1e8:
                case 0x1e9:
                case 0x1ea:
                case 0x1eb:
                case 0x1ec:
                case 0x1ed:
                case 0x1ee:
                case 0x1ef:
                case 0x1f0:
                case 0x1f1:
                case 0x1f2:
                case 499:
                case 500:
                case 0x1f5:
                case 0x1f6:
                case 0x1f7:
                case 0x1f8:
                case 0x1f9:
                case 0x1fa:
                case 0x1fb:
                case 0x1fc:
                case 0x1fd:
                case 0x1fe:
                case 0x1ff:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(*pauVar31 + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(*pauVar25 + uVar34) = auVar39;
                case 0x1c1:
                case 0x1c2:
                case 0x1c3:
                case 0x1c4:
                case 0x1c5:
                case 0x1c6:
                case 0x1c7:
                case 0x1c8:
                case 0x1c9:
                case 0x1ca:
                case 0x1cb:
                case 0x1cc:
                case 0x1cd:
                case 0x1ce:
                case 0x1cf:
                case 0x1d0:
                case 0x1d1:
                case 0x1d2:
                case 0x1d3:
                case 0x1d4:
                case 0x1d5:
                case 0x1d6:
                case 0x1d7:
                case 0x1d8:
                case 0x1d9:
                case 0x1da:
                case 0x1db:
                case 0x1dc:
                case 0x1dd:
                case 0x1de:
                case 0x1df:
                case 0x1e0:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[1] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[1] + uVar34) = auVar39;
                case 0x1a1:
                case 0x1a2:
                case 0x1a3:
                case 0x1a4:
                case 0x1a5:
                case 0x1a6:
                case 0x1a7:
                case 0x1a8:
                case 0x1a9:
                case 0x1aa:
                case 0x1ab:
                case 0x1ac:
                case 0x1ad:
                case 0x1ae:
                case 0x1af:
                case 0x1b0:
                case 0x1b1:
                case 0x1b2:
                case 0x1b3:
                case 0x1b4:
                case 0x1b5:
                case 0x1b6:
                case 0x1b7:
                case 0x1b8:
                case 0x1b9:
                case 0x1ba:
                case 0x1bb:
                case 0x1bc:
                case 0x1bd:
                case 0x1be:
                case 0x1bf:
                case 0x1c0:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[2] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[2] + uVar34) = auVar39;
                case 0x181:
                case 0x182:
                case 0x183:
                case 0x184:
                case 0x185:
                case 0x186:
                case 0x187:
                case 0x188:
                case 0x189:
                case 0x18a:
                case 0x18b:
                case 0x18c:
                case 0x18d:
                case 0x18e:
                case 399:
                case 400:
                case 0x191:
                case 0x192:
                case 0x193:
                case 0x194:
                case 0x195:
                case 0x196:
                case 0x197:
                case 0x198:
                case 0x199:
                case 0x19a:
                case 0x19b:
                case 0x19c:
                case 0x19d:
                case 0x19e:
                case 0x19f:
                case 0x1a0:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[3] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[3] + uVar34) = auVar39;
                case 0x161:
                case 0x162:
                case 0x163:
                case 0x164:
                case 0x165:
                case 0x166:
                case 0x167:
                case 0x168:
                case 0x169:
                case 0x16a:
                case 0x16b:
                case 0x16c:
                case 0x16d:
                case 0x16e:
                case 0x16f:
                case 0x170:
                case 0x171:
                case 0x172:
                case 0x173:
                case 0x174:
                case 0x175:
                case 0x176:
                case 0x177:
                case 0x178:
                case 0x179:
                case 0x17a:
                case 0x17b:
                case 0x17c:
                case 0x17d:
                case 0x17e:
                case 0x17f:
                case 0x180:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[4] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[4] + uVar34) = auVar39;
                case 0x141:
                case 0x142:
                case 0x143:
                case 0x144:
                case 0x145:
                case 0x146:
                case 0x147:
                case 0x148:
                case 0x149:
                case 0x14a:
                case 0x14b:
                case 0x14c:
                case 0x14d:
                case 0x14e:
                case 0x14f:
                case 0x150:
                case 0x151:
                case 0x152:
                case 0x153:
                case 0x154:
                case 0x155:
                case 0x156:
                case 0x157:
                case 0x158:
                case 0x159:
                case 0x15a:
                case 0x15b:
                case 0x15c:
                case 0x15d:
                case 0x15e:
                case 0x15f:
                case 0x160:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[5] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[5] + uVar34) = auVar39;
                case 0x121:
                case 0x122:
                case 0x123:
                case 0x124:
                case 0x125:
                case 0x126:
                case 0x127:
                case 0x128:
                case 0x129:
                case 0x12a:
                case 299:
                case 300:
                case 0x12d:
                case 0x12e:
                case 0x12f:
                case 0x130:
                case 0x131:
                case 0x132:
                case 0x133:
                case 0x134:
                case 0x135:
                case 0x136:
                case 0x137:
                case 0x138:
                case 0x139:
                case 0x13a:
                case 0x13b:
                case 0x13c:
                case 0x13d:
                case 0x13e:
                case 0x13f:
                case 0x140:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[6] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[6] + uVar34) = auVar39;
                default:
                    auVar43 = vmovdqu_avx(auVar43);
                    *(undefined (*) [32])(pauVar25[-1] + uVar36) = auVar43;
                case 0x100:
                    auVar38 = vmovdqu_avx(auVar38);
                    *pauVar23 = auVar38;
                    return;
                }
            }
            do {
                auVar38 = vmovdqu_avx(*pauVar30);
                auVar43 = vmovdqu_avx(pauVar30[1]);
                auVar39 = vmovdqu_avx(pauVar30[2]);
                auVar41 = vmovdqu_avx(pauVar30[3]);
                *pauVar24 = auVar38;
                pauVar24[1] = auVar43;
                pauVar24[2] = auVar39;
                pauVar24[3] = auVar41;
                auVar38 = vmovdqu_avx(pauVar30[4]);
                auVar43 = vmovdqu_avx(pauVar30[5]);
                auVar39 = vmovdqu_avx(pauVar30[6]);
                auVar41 = vmovdqu_avx(pauVar30[7]);
                pauVar24[4] = auVar38;
                pauVar24[5] = auVar43;
                pauVar24[6] = auVar39;
                pauVar24[7] = auVar41;
                pauVar24 = pauVar24 + 8;
                pauVar30 = pauVar30 + 8;
                uVar34 = uVar34 - 0x100;
            } while (0xff < uVar34);
        }
    }
    // WARNING: Could not recover jumptable at 0x0001804982b2. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (27 cases) at 0x1806509a0
    (*(code *)((uint64_t)*(uint32_t *)((uVar34 + 0x1f >> 5) * 4 + 0x1806509a0) + 0x180000000))();
    return;
}

// ============================================================
// Function: FUN_1801431cb
// Address: 0x1801431cb
// Size: 5 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018011f69d: Changing call to branch
// WARNING: Possible PIC construction at 0x00018014319f: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018011f6a2)
// WARNING: Removing unreachable block (ram,0x0001801431a4)
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180143150(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    uint32_t *puVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    undefined uVar4;
    undefined2 uVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    uint32_t uVar22;
    undefined (*pauVar23) [32];
    undefined (*pauVar24) [32];
    undefined (*pauVar25) [32];
    undefined4 *puVar26;
    undefined (*pauVar27) [16];
    undefined (*pauVar28) [16];
    uint32_t uVar29;
    undefined (*pauVar30) [32];
    undefined (*pauVar31) [32];
    undefined4 *puVar32;
    int64_t unaff_RBX;
    undefined8 unaff_RBP;
    int32_t iVar33;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar34;
    int64_t iVar35;
    uint64_t uVar36;
    undefined auVar37 [16];
    undefined auVar38 [32];
    undefined auVar39 [32];
    undefined auVar40 [32];
    undefined auVar41 [32];
    undefined auVar42 [32];
    undefined auVar43 [32];
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_28h;
    int64_t var_8h;
    
    iVar35 = *(int64_t *)0x180781f28;
    if (((int32_t)arg1 == 0) || (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2674) != (int32_t)arg1)) {
        return;
    }
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x26f8) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2674);
    puVar1 = (uint32_t *)(iVar35 + 0x2700);
    if ((*(uint32_t *)(iVar35 + 0x2670) & 0x200) == 0) {
        uVar29 = *(int32_t *)(iVar35 + 0x2678) + 1;
        *(undefined8 **)0x20 = (BADSPACEBASE *)&uStack_30;
        uStack_30 = 0x1801431a4;
        unaff_RBX = iVar35;
    } else {
        uVar29 = 0;
    }
    *(int64_t *)((int64_t)*(undefined **)0x20 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RDI;
    iVar6 = *(int32_t *)(iVar35 + 0x2704);
    if ((int32_t)uVar29 <= iVar6) {
        *puVar1 = uVar29;
        return;
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + 0x10) = unaff_RSI;
    if (iVar6 == 0) {
        uVar22 = 8;
    } else {
        uVar22 = iVar6 / 2 + iVar6;
    }
    uVar36 = (uint64_t)uVar29;
    if ((int32_t)uVar29 < (int32_t)uVar22) {
        uVar36 = (uint64_t)uVar22;
    }
    iVar33 = (int32_t)uVar36;
    if (iVar33 <= iVar6) {
        *puVar1 = uVar29;
        return;
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + 8) = unaff_RBP;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18011f68b;
    pauVar23 = (undefined (*) [32])func_0x00018046d050((int64_t)iVar33);
    pauVar30 = *(undefined (**) [32])(iVar35 + 0x2708);
    if (pauVar30 == (undefined (*) [32])0x0) {
        *(undefined (**) [32])(iVar35 + 0x2708) = pauVar23;
        *(int32_t *)(iVar35 + 0x2704) = iVar33;
        *puVar1 = uVar29;
        return;
    }
    uVar34 = (uint64_t)(int32_t)*puVar1;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18011f6a2;
    // switch table (16 cases) at 0x180650960
    switch(uVar34) {
    case 0:
        return;
    case 1:
        (*pauVar23)[0] = (*pauVar30)[0];
        return;
    case 2:
        *(undefined2 *)*pauVar23 = *(undefined2 *)*pauVar30;
        return;
    case 3:
        uVar4 = (*pauVar30)[2];
        *(undefined2 *)*pauVar23 = *(undefined2 *)*pauVar30;
        (*pauVar23)[2] = uVar4;
        return;
    case 4:
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        return;
    case 5:
        uVar4 = (*pauVar30)[4];
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        (*pauVar23)[4] = uVar4;
        return;
    case 6:
        uVar5 = *(undefined2 *)(*pauVar30 + 4);
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 4) = uVar5;
        return;
    case 7:
        uVar5 = *(undefined2 *)(*pauVar30 + 4);
        uVar4 = (*pauVar30)[6];
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 4) = uVar5;
        (*pauVar23)[6] = uVar4;
        return;
    case 8:
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        return;
    case 9:
        uVar4 = (*pauVar30)[8];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        (*pauVar23)[8] = uVar4;
        return;
    case 10:
        uVar5 = *(undefined2 *)(*pauVar30 + 8);
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 8) = uVar5;
        return;
    case 0xb:
        uVar5 = *(undefined2 *)(*pauVar30 + 8);
        uVar4 = (*pauVar30)[10];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 8) = uVar5;
        (*pauVar23)[10] = uVar4;
        return;
    case 0xc:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        return;
    case 0xd:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        uVar4 = (*pauVar30)[0xc];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        (*pauVar23)[0xc] = uVar4;
        return;
    case 0xe:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        uVar5 = *(undefined2 *)(*pauVar30 + 0xc);
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        *(undefined2 *)(*pauVar23 + 0xc) = uVar5;
        return;
    case 0xf:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        uVar5 = *(undefined2 *)(*pauVar30 + 0xc);
        uVar4 = (*pauVar30)[0xe];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        *(undefined2 *)(*pauVar23 + 0xc) = uVar5;
        (*pauVar23)[0xe] = uVar4;
        return;
    }
    if (uVar34 < 0x21) {
        uVar7 = *(undefined4 *)(*pauVar30 + 4);
        uVar8 = *(undefined4 *)(*pauVar30 + 8);
        uVar9 = *(undefined4 *)(*pauVar30 + 0xc);
        puVar26 = (undefined4 *)(pauVar30[-1] + uVar34 + 0x10);
        uVar10 = *puVar26;
        uVar11 = puVar26[1];
        uVar12 = puVar26[2];
        uVar13 = puVar26[3];
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 4) = uVar7;
        *(undefined4 *)(*pauVar23 + 8) = uVar8;
        *(undefined4 *)(*pauVar23 + 0xc) = uVar9;
        puVar26 = (undefined4 *)(pauVar23[-1] + uVar34 + 0x10);
        *puVar26 = uVar10;
        puVar26[1] = uVar11;
        puVar26[2] = uVar12;
        puVar26[3] = uVar13;
        return;
    }
    pauVar24 = (undefined (*) [32])(*pauVar30 + uVar34);
    if (pauVar23 <= pauVar30) {
        pauVar24 = pauVar23;
    }
    if (pauVar23 < pauVar24) {
        uVar7 = *(undefined4 *)*pauVar30;
        uVar8 = *(undefined4 *)(*pauVar30 + 4);
        uVar9 = *(undefined4 *)(*pauVar30 + 8);
        uVar10 = *(undefined4 *)(*pauVar30 + 0xc);
        iVar35 = (int64_t)pauVar30 - (int64_t)pauVar23;
        auVar2 = *(undefined (*) [16])((int64_t)pauVar23 + iVar35 + (uVar34 - 0x10));
        pauVar28 = (undefined (*) [16])(pauVar23[-1] + uVar34 + 0x10);
        uVar34 = uVar34 - 0x10;
        pauVar27 = pauVar28;
        auVar37 = auVar2;
        if (((uint64_t)pauVar28 & 0xf) != 0) {
            pauVar27 = (undefined (*) [16])((uint64_t)pauVar28 & 0xfffffffffffffff0);
            auVar37 = *(undefined (*) [16])((int64_t)pauVar27 + iVar35);
            *pauVar28 = auVar2;
            uVar34 = (int64_t)pauVar27 - (int64_t)pauVar23;
        }
        uVar36 = uVar34 >> 7;
        if (uVar36 != 0) {
            *pauVar27 = auVar37;
            pauVar28 = pauVar27;
            while( true ) {
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x10);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                puVar32 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x20);
                uVar14 = *puVar32;
                uVar15 = puVar32[1];
                uVar16 = puVar32[2];
                uVar17 = puVar32[3];
                pauVar27 = pauVar28 + -8;
                *(undefined4 *)pauVar28[-1] = *puVar26;
                *(undefined4 *)(pauVar28[-1] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-1] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-1] + 0xc) = uVar13;
                *(undefined4 *)pauVar28[-2] = uVar14;
                *(undefined4 *)(pauVar28[-2] + 4) = uVar15;
                *(undefined4 *)(pauVar28[-2] + 8) = uVar16;
                *(undefined4 *)(pauVar28[-2] + 0xc) = uVar17;
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x30);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                puVar32 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x40);
                uVar14 = *puVar32;
                uVar15 = puVar32[1];
                uVar16 = puVar32[2];
                uVar17 = puVar32[3];
                uVar36 = uVar36 - 1;
                *(undefined4 *)pauVar28[-3] = *puVar26;
                *(undefined4 *)(pauVar28[-3] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-3] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-3] + 0xc) = uVar13;
                *(undefined4 *)pauVar28[-4] = uVar14;
                *(undefined4 *)(pauVar28[-4] + 4) = uVar15;
                *(undefined4 *)(pauVar28[-4] + 8) = uVar16;
                *(undefined4 *)(pauVar28[-4] + 0xc) = uVar17;
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x50);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                puVar32 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x60);
                uVar14 = *puVar32;
                uVar15 = puVar32[1];
                uVar16 = puVar32[2];
                uVar17 = puVar32[3];
                *(undefined4 *)pauVar28[-5] = *puVar26;
                *(undefined4 *)(pauVar28[-5] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-5] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-5] + 0xc) = uVar13;
                *(undefined4 *)pauVar28[-6] = uVar14;
                *(undefined4 *)(pauVar28[-6] + 4) = uVar15;
                *(undefined4 *)(pauVar28[-6] + 8) = uVar16;
                *(undefined4 *)(pauVar28[-6] + 0xc) = uVar17;
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x70);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                auVar37 = *(undefined (*) [16])((int64_t)pauVar27 + iVar35);
                if (uVar36 == 0) break;
                *(undefined4 *)pauVar28[-7] = *puVar26;
                *(undefined4 *)(pauVar28[-7] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-7] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-7] + 0xc) = uVar13;
                *pauVar27 = auVar37;
                pauVar28 = pauVar27;
            }
            *(undefined4 *)pauVar28[-7] = *puVar26;
            *(undefined4 *)(pauVar28[-7] + 4) = uVar11;
            *(undefined4 *)(pauVar28[-7] + 8) = uVar12;
            *(undefined4 *)(pauVar28[-7] + 0xc) = uVar13;
            uVar34 = uVar34 & 0x7f;
        }
        for (uVar36 = uVar34 >> 4; uVar36 != 0; uVar36 = uVar36 - 1) {
            *pauVar27 = auVar37;
            pauVar27 = pauVar27 + -1;
            auVar37 = *(undefined (*) [16])((int64_t)pauVar27 + iVar35);
        }
        if ((uVar34 & 0xf) != 0) {
            *(undefined4 *)*pauVar23 = uVar7;
            *(undefined4 *)(*pauVar23 + 4) = uVar8;
            *(undefined4 *)(*pauVar23 + 8) = uVar9;
            *(undefined4 *)(*pauVar23 + 0xc) = uVar10;
        }
        *pauVar27 = auVar37;
        return;
    }
    if (*(uint32_t *)0x1806a3990 < 3) {
        if ((uVar34 < 0x801) || ((*(uint8_t *)0x18078131c & 2) == 0)) {
            if (0x80 < uVar34) {
                iVar35 = ((uint64_t)pauVar23 & 0xf) - 0x10;
                puVar26 = (undefined4 *)((int64_t)pauVar23 - iVar35);
                puVar32 = (undefined4 *)((int64_t)pauVar30 - iVar35);
                uVar34 = uVar34 + iVar35;
                if (0x80 < uVar34) {
                    do {
                        uVar7 = puVar32[1];
                        uVar8 = puVar32[2];
                        uVar9 = puVar32[3];
                        uVar10 = puVar32[4];
                        uVar11 = puVar32[5];
                        uVar12 = puVar32[6];
                        uVar13 = puVar32[7];
                        uVar14 = puVar32[8];
                        uVar15 = puVar32[9];
                        uVar16 = puVar32[10];
                        uVar17 = puVar32[0xb];
                        uVar18 = puVar32[0xc];
                        uVar19 = puVar32[0xd];
                        uVar20 = puVar32[0xe];
                        uVar21 = puVar32[0xf];
                        *puVar26 = *puVar32;
                        puVar26[1] = uVar7;
                        puVar26[2] = uVar8;
                        puVar26[3] = uVar9;
                        puVar26[4] = uVar10;
                        puVar26[5] = uVar11;
                        puVar26[6] = uVar12;
                        puVar26[7] = uVar13;
                        puVar26[8] = uVar14;
                        puVar26[9] = uVar15;
                        puVar26[10] = uVar16;
                        puVar26[0xb] = uVar17;
                        puVar26[0xc] = uVar18;
                        puVar26[0xd] = uVar19;
                        puVar26[0xe] = uVar20;
                        puVar26[0xf] = uVar21;
                        auVar2 = *(undefined (*) [16])(puVar32 + 0x14);
                        auVar37 = *(undefined (*) [16])(puVar32 + 0x18);
                        auVar3 = *(undefined (*) [16])(puVar32 + 0x1c);
                        *(undefined (*) [16])(puVar26 + 0x10) = *(undefined (*) [16])(puVar32 + 0x10);
                        *(undefined (*) [16])(puVar26 + 0x14) = auVar2;
                        *(undefined (*) [16])(puVar26 + 0x18) = auVar37;
                        *(undefined (*) [16])(puVar26 + 0x1c) = auVar3;
                        puVar26 = puVar26 + 0x20;
                        puVar32 = puVar32 + 0x20;
                        uVar34 = uVar34 - 0x80;
                    } while (0x7f < uVar34);
                }
            }
    // WARNING: Could not recover jumptable at 0x000180498556. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (9 cases) at 0x1806509e8
            (*(code *)((uint64_t)*(uint32_t *)((uVar34 + 0xf >> 4) * 4 + 0x1806509e8) + 0x180000000))();
            return;
        }
code_r0x000180498020:
        *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x38) = (uint64_t)uVar29;
        *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x40) = uVar36;
        for (; uVar34 != 0; uVar34 = uVar34 - 1) {
            (*pauVar23)[0] = (*pauVar30)[0];
            pauVar30 = (undefined (*) [32])(*pauVar30 + 1);
            pauVar23 = (undefined (*) [32])(*pauVar23 + 1);
        }
        return;
    }
    if ((0x2000 < uVar34) && (uVar34 < 0x180001)) {
        pauVar24 = pauVar23 + 2;
        if (pauVar30 < pauVar23) {
            pauVar24 = pauVar30;
        }
        if ((pauVar24 <= pauVar30) && ((*(uint8_t *)0x18078131c & 2) != 0)) goto code_r0x000180498020;
    }
    auVar38 = vmovdqu_avx(*pauVar30);
    auVar43 = vmovdqu_avx(*(undefined (*) [32])(pauVar30[-1] + uVar34));
    if (0x100 < uVar34) {
        iVar35 = ((uint64_t)pauVar23 & 0x1f) - 0x20;
        pauVar24 = (undefined (*) [32])((int64_t)pauVar23 - iVar35);
        pauVar30 = (undefined (*) [32])((int64_t)pauVar30 - iVar35);
        uVar34 = uVar34 + iVar35;
        if (0x100 < uVar34) {
            if (0x180000 < uVar34) {
                do {
                    uVar36 = uVar34;
                    pauVar31 = pauVar30;
                    pauVar25 = pauVar24;
                    auVar39 = vmovdqu_avx(*pauVar31);
                    auVar41 = vmovdqu_avx(pauVar31[1]);
                    auVar40 = vmovdqu_avx(pauVar31[2]);
                    auVar42 = vmovdqu_avx(pauVar31[3]);
                    auVar39 = vmovntdq_avx(auVar39);
                    *pauVar25 = auVar39;
                    auVar39 = vmovntdq_avx(auVar41);
                    pauVar25[1] = auVar39;
                    auVar39 = vmovntdq_avx(auVar40);
                    pauVar25[2] = auVar39;
                    auVar39 = vmovntdq_avx(auVar42);
                    pauVar25[3] = auVar39;
                    auVar39 = vmovdqu_avx(pauVar31[4]);
                    auVar41 = vmovdqu_avx(pauVar31[5]);
                    auVar40 = vmovdqu_avx(pauVar31[6]);
                    auVar42 = vmovdqu_avx(pauVar31[7]);
                    auVar39 = vmovntdq_avx(auVar39);
                    pauVar25[4] = auVar39;
                    auVar39 = vmovntdq_avx(auVar41);
                    pauVar25[5] = auVar39;
                    auVar39 = vmovntdq_avx(auVar40);
                    pauVar25[6] = auVar39;
                    auVar39 = vmovntdq_avx(auVar42);
                    pauVar25[7] = auVar39;
                    pauVar24 = pauVar25 + 8;
                    pauVar30 = pauVar31 + 8;
                    uVar34 = uVar36 - 0x100;
                } while (0xff < uVar36 - 0x100);
                uVar34 = uVar36 - 0xe1 & 0xffffffffffffffe0;
    // switch table (18 cases) at 0x1806509c4
                switch(uVar36) {
                case 0x1e1:
                case 0x1e2:
                case 0x1e3:
                case 0x1e4:
                case 0x1e5:
                case 0x1e6:
                case 0x1e7:
                case 0x1e8:
                case 0x1e9:
                case 0x1ea:
                case 0x1eb:
                case 0x1ec:
                case 0x1ed:
                case 0x1ee:
                case 0x1ef:
                case 0x1f0:
                case 0x1f1:
                case 0x1f2:
                case 499:
                case 500:
                case 0x1f5:
                case 0x1f6:
                case 0x1f7:
                case 0x1f8:
                case 0x1f9:
                case 0x1fa:
                case 0x1fb:
                case 0x1fc:
                case 0x1fd:
                case 0x1fe:
                case 0x1ff:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(*pauVar31 + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(*pauVar25 + uVar34) = auVar39;
                case 0x1c1:
                case 0x1c2:
                case 0x1c3:
                case 0x1c4:
                case 0x1c5:
                case 0x1c6:
                case 0x1c7:
                case 0x1c8:
                case 0x1c9:
                case 0x1ca:
                case 0x1cb:
                case 0x1cc:
                case 0x1cd:
                case 0x1ce:
                case 0x1cf:
                case 0x1d0:
                case 0x1d1:
                case 0x1d2:
                case 0x1d3:
                case 0x1d4:
                case 0x1d5:
                case 0x1d6:
                case 0x1d7:
                case 0x1d8:
                case 0x1d9:
                case 0x1da:
                case 0x1db:
                case 0x1dc:
                case 0x1dd:
                case 0x1de:
                case 0x1df:
                case 0x1e0:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[1] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[1] + uVar34) = auVar39;
                case 0x1a1:
                case 0x1a2:
                case 0x1a3:
                case 0x1a4:
                case 0x1a5:
                case 0x1a6:
                case 0x1a7:
                case 0x1a8:
                case 0x1a9:
                case 0x1aa:
                case 0x1ab:
                case 0x1ac:
                case 0x1ad:
                case 0x1ae:
                case 0x1af:
                case 0x1b0:
                case 0x1b1:
                case 0x1b2:
                case 0x1b3:
                case 0x1b4:
                case 0x1b5:
                case 0x1b6:
                case 0x1b7:
                case 0x1b8:
                case 0x1b9:
                case 0x1ba:
                case 0x1bb:
                case 0x1bc:
                case 0x1bd:
                case 0x1be:
                case 0x1bf:
                case 0x1c0:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[2] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[2] + uVar34) = auVar39;
                case 0x181:
                case 0x182:
                case 0x183:
                case 0x184:
                case 0x185:
                case 0x186:
                case 0x187:
                case 0x188:
                case 0x189:
                case 0x18a:
                case 0x18b:
                case 0x18c:
                case 0x18d:
                case 0x18e:
                case 399:
                case 400:
                case 0x191:
                case 0x192:
                case 0x193:
                case 0x194:
                case 0x195:
                case 0x196:
                case 0x197:
                case 0x198:
                case 0x199:
                case 0x19a:
                case 0x19b:
                case 0x19c:
                case 0x19d:
                case 0x19e:
                case 0x19f:
                case 0x1a0:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[3] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[3] + uVar34) = auVar39;
                case 0x161:
                case 0x162:
                case 0x163:
                case 0x164:
                case 0x165:
                case 0x166:
                case 0x167:
                case 0x168:
                case 0x169:
                case 0x16a:
                case 0x16b:
                case 0x16c:
                case 0x16d:
                case 0x16e:
                case 0x16f:
                case 0x170:
                case 0x171:
                case 0x172:
                case 0x173:
                case 0x174:
                case 0x175:
                case 0x176:
                case 0x177:
                case 0x178:
                case 0x179:
                case 0x17a:
                case 0x17b:
                case 0x17c:
                case 0x17d:
                case 0x17e:
                case 0x17f:
                case 0x180:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[4] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[4] + uVar34) = auVar39;
                case 0x141:
                case 0x142:
                case 0x143:
                case 0x144:
                case 0x145:
                case 0x146:
                case 0x147:
                case 0x148:
                case 0x149:
                case 0x14a:
                case 0x14b:
                case 0x14c:
                case 0x14d:
                case 0x14e:
                case 0x14f:
                case 0x150:
                case 0x151:
                case 0x152:
                case 0x153:
                case 0x154:
                case 0x155:
                case 0x156:
                case 0x157:
                case 0x158:
                case 0x159:
                case 0x15a:
                case 0x15b:
                case 0x15c:
                case 0x15d:
                case 0x15e:
                case 0x15f:
                case 0x160:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[5] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[5] + uVar34) = auVar39;
                case 0x121:
                case 0x122:
                case 0x123:
                case 0x124:
                case 0x125:
                case 0x126:
                case 0x127:
                case 0x128:
                case 0x129:
                case 0x12a:
                case 299:
                case 300:
                case 0x12d:
                case 0x12e:
                case 0x12f:
                case 0x130:
                case 0x131:
                case 0x132:
                case 0x133:
                case 0x134:
                case 0x135:
                case 0x136:
                case 0x137:
                case 0x138:
                case 0x139:
                case 0x13a:
                case 0x13b:
                case 0x13c:
                case 0x13d:
                case 0x13e:
                case 0x13f:
                case 0x140:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[6] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[6] + uVar34) = auVar39;
                default:
                    auVar43 = vmovdqu_avx(auVar43);
                    *(undefined (*) [32])(pauVar25[-1] + uVar36) = auVar43;
                case 0x100:
                    auVar38 = vmovdqu_avx(auVar38);
                    *pauVar23 = auVar38;
                    return;
                }
            }
            do {
                auVar38 = vmovdqu_avx(*pauVar30);
                auVar43 = vmovdqu_avx(pauVar30[1]);
                auVar39 = vmovdqu_avx(pauVar30[2]);
                auVar41 = vmovdqu_avx(pauVar30[3]);
                *pauVar24 = auVar38;
                pauVar24[1] = auVar43;
                pauVar24[2] = auVar39;
                pauVar24[3] = auVar41;
                auVar38 = vmovdqu_avx(pauVar30[4]);
                auVar43 = vmovdqu_avx(pauVar30[5]);
                auVar39 = vmovdqu_avx(pauVar30[6]);
                auVar41 = vmovdqu_avx(pauVar30[7]);
                pauVar24[4] = auVar38;
                pauVar24[5] = auVar43;
                pauVar24[6] = auVar39;
                pauVar24[7] = auVar41;
                pauVar24 = pauVar24 + 8;
                pauVar30 = pauVar30 + 8;
                uVar34 = uVar34 - 0x100;
            } while (0xff < uVar34);
        }
    }
    // WARNING: Could not recover jumptable at 0x0001804982b2. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (27 cases) at 0x1806509a0
    (*(code *)((uint64_t)*(uint32_t *)((uVar34 + 0x1f >> 5) * 4 + 0x1806509a0) + 0x180000000))();
    return;
}

// ============================================================
// Function: FUN_1801431d0
// Address: 0x1801431d0
// Size: 5 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018011f69d: Changing call to branch
// WARNING: Possible PIC construction at 0x00018014319f: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018011f6a2)
// WARNING: Removing unreachable block (ram,0x0001801431a4)
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180143150(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    uint32_t *puVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    undefined uVar4;
    undefined2 uVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    undefined4 uVar19;
    undefined4 uVar20;
    undefined4 uVar21;
    uint32_t uVar22;
    undefined (*pauVar23) [32];
    undefined (*pauVar24) [32];
    undefined (*pauVar25) [32];
    undefined4 *puVar26;
    undefined (*pauVar27) [16];
    undefined (*pauVar28) [16];
    uint32_t uVar29;
    undefined (*pauVar30) [32];
    undefined (*pauVar31) [32];
    undefined4 *puVar32;
    int64_t unaff_RBX;
    undefined8 unaff_RBP;
    int32_t iVar33;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar34;
    int64_t iVar35;
    uint64_t uVar36;
    undefined auVar37 [16];
    undefined auVar38 [32];
    undefined auVar39 [32];
    undefined auVar40 [32];
    undefined auVar41 [32];
    undefined auVar42 [32];
    undefined auVar43 [32];
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_28h;
    int64_t var_8h;
    
    iVar35 = *(int64_t *)0x180781f28;
    if (((int32_t)arg1 == 0) || (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2674) != (int32_t)arg1)) {
        return;
    }
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x26f8) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2674);
    puVar1 = (uint32_t *)(iVar35 + 0x2700);
    if ((*(uint32_t *)(iVar35 + 0x2670) & 0x200) == 0) {
        uVar29 = *(int32_t *)(iVar35 + 0x2678) + 1;
        *(undefined8 **)0x20 = (BADSPACEBASE *)&uStack_30;
        uStack_30 = 0x1801431a4;
        unaff_RBX = iVar35;
    } else {
        uVar29 = 0;
    }
    *(int64_t *)((int64_t)*(undefined **)0x20 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RDI;
    iVar6 = *(int32_t *)(iVar35 + 0x2704);
    if ((int32_t)uVar29 <= iVar6) {
        *puVar1 = uVar29;
        return;
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + 0x10) = unaff_RSI;
    if (iVar6 == 0) {
        uVar22 = 8;
    } else {
        uVar22 = iVar6 / 2 + iVar6;
    }
    uVar36 = (uint64_t)uVar29;
    if ((int32_t)uVar29 < (int32_t)uVar22) {
        uVar36 = (uint64_t)uVar22;
    }
    iVar33 = (int32_t)uVar36;
    if (iVar33 <= iVar6) {
        *puVar1 = uVar29;
        return;
    }
    *(undefined8 *)((int64_t)*(undefined **)0x20 + 8) = unaff_RBP;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18011f68b;
    pauVar23 = (undefined (*) [32])func_0x00018046d050((int64_t)iVar33);
    pauVar30 = *(undefined (**) [32])(iVar35 + 0x2708);
    if (pauVar30 == (undefined (*) [32])0x0) {
        *(undefined (**) [32])(iVar35 + 0x2708) = pauVar23;
        *(int32_t *)(iVar35 + 0x2704) = iVar33;
        *puVar1 = uVar29;
        return;
    }
    uVar34 = (uint64_t)(int32_t)*puVar1;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18011f6a2;
    // switch table (16 cases) at 0x180650960
    switch(uVar34) {
    case 0:
        return;
    case 1:
        (*pauVar23)[0] = (*pauVar30)[0];
        return;
    case 2:
        *(undefined2 *)*pauVar23 = *(undefined2 *)*pauVar30;
        return;
    case 3:
        uVar4 = (*pauVar30)[2];
        *(undefined2 *)*pauVar23 = *(undefined2 *)*pauVar30;
        (*pauVar23)[2] = uVar4;
        return;
    case 4:
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        return;
    case 5:
        uVar4 = (*pauVar30)[4];
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        (*pauVar23)[4] = uVar4;
        return;
    case 6:
        uVar5 = *(undefined2 *)(*pauVar30 + 4);
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 4) = uVar5;
        return;
    case 7:
        uVar5 = *(undefined2 *)(*pauVar30 + 4);
        uVar4 = (*pauVar30)[6];
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 4) = uVar5;
        (*pauVar23)[6] = uVar4;
        return;
    case 8:
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        return;
    case 9:
        uVar4 = (*pauVar30)[8];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        (*pauVar23)[8] = uVar4;
        return;
    case 10:
        uVar5 = *(undefined2 *)(*pauVar30 + 8);
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 8) = uVar5;
        return;
    case 0xb:
        uVar5 = *(undefined2 *)(*pauVar30 + 8);
        uVar4 = (*pauVar30)[10];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined2 *)(*pauVar23 + 8) = uVar5;
        (*pauVar23)[10] = uVar4;
        return;
    case 0xc:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        return;
    case 0xd:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        uVar4 = (*pauVar30)[0xc];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        (*pauVar23)[0xc] = uVar4;
        return;
    case 0xe:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        uVar5 = *(undefined2 *)(*pauVar30 + 0xc);
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        *(undefined2 *)(*pauVar23 + 0xc) = uVar5;
        return;
    case 0xf:
        uVar7 = *(undefined4 *)(*pauVar30 + 8);
        uVar5 = *(undefined2 *)(*pauVar30 + 0xc);
        uVar4 = (*pauVar30)[0xe];
        *(undefined8 *)*pauVar23 = *(undefined8 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 8) = uVar7;
        *(undefined2 *)(*pauVar23 + 0xc) = uVar5;
        (*pauVar23)[0xe] = uVar4;
        return;
    }
    if (uVar34 < 0x21) {
        uVar7 = *(undefined4 *)(*pauVar30 + 4);
        uVar8 = *(undefined4 *)(*pauVar30 + 8);
        uVar9 = *(undefined4 *)(*pauVar30 + 0xc);
        puVar26 = (undefined4 *)(pauVar30[-1] + uVar34 + 0x10);
        uVar10 = *puVar26;
        uVar11 = puVar26[1];
        uVar12 = puVar26[2];
        uVar13 = puVar26[3];
        *(undefined4 *)*pauVar23 = *(undefined4 *)*pauVar30;
        *(undefined4 *)(*pauVar23 + 4) = uVar7;
        *(undefined4 *)(*pauVar23 + 8) = uVar8;
        *(undefined4 *)(*pauVar23 + 0xc) = uVar9;
        puVar26 = (undefined4 *)(pauVar23[-1] + uVar34 + 0x10);
        *puVar26 = uVar10;
        puVar26[1] = uVar11;
        puVar26[2] = uVar12;
        puVar26[3] = uVar13;
        return;
    }
    pauVar24 = (undefined (*) [32])(*pauVar30 + uVar34);
    if (pauVar23 <= pauVar30) {
        pauVar24 = pauVar23;
    }
    if (pauVar23 < pauVar24) {
        uVar7 = *(undefined4 *)*pauVar30;
        uVar8 = *(undefined4 *)(*pauVar30 + 4);
        uVar9 = *(undefined4 *)(*pauVar30 + 8);
        uVar10 = *(undefined4 *)(*pauVar30 + 0xc);
        iVar35 = (int64_t)pauVar30 - (int64_t)pauVar23;
        auVar2 = *(undefined (*) [16])((int64_t)pauVar23 + iVar35 + (uVar34 - 0x10));
        pauVar28 = (undefined (*) [16])(pauVar23[-1] + uVar34 + 0x10);
        uVar34 = uVar34 - 0x10;
        pauVar27 = pauVar28;
        auVar37 = auVar2;
        if (((uint64_t)pauVar28 & 0xf) != 0) {
            pauVar27 = (undefined (*) [16])((uint64_t)pauVar28 & 0xfffffffffffffff0);
            auVar37 = *(undefined (*) [16])((int64_t)pauVar27 + iVar35);
            *pauVar28 = auVar2;
            uVar34 = (int64_t)pauVar27 - (int64_t)pauVar23;
        }
        uVar36 = uVar34 >> 7;
        if (uVar36 != 0) {
            *pauVar27 = auVar37;
            pauVar28 = pauVar27;
            while( true ) {
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x10);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                puVar32 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x20);
                uVar14 = *puVar32;
                uVar15 = puVar32[1];
                uVar16 = puVar32[2];
                uVar17 = puVar32[3];
                pauVar27 = pauVar28 + -8;
                *(undefined4 *)pauVar28[-1] = *puVar26;
                *(undefined4 *)(pauVar28[-1] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-1] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-1] + 0xc) = uVar13;
                *(undefined4 *)pauVar28[-2] = uVar14;
                *(undefined4 *)(pauVar28[-2] + 4) = uVar15;
                *(undefined4 *)(pauVar28[-2] + 8) = uVar16;
                *(undefined4 *)(pauVar28[-2] + 0xc) = uVar17;
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x30);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                puVar32 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x40);
                uVar14 = *puVar32;
                uVar15 = puVar32[1];
                uVar16 = puVar32[2];
                uVar17 = puVar32[3];
                uVar36 = uVar36 - 1;
                *(undefined4 *)pauVar28[-3] = *puVar26;
                *(undefined4 *)(pauVar28[-3] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-3] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-3] + 0xc) = uVar13;
                *(undefined4 *)pauVar28[-4] = uVar14;
                *(undefined4 *)(pauVar28[-4] + 4) = uVar15;
                *(undefined4 *)(pauVar28[-4] + 8) = uVar16;
                *(undefined4 *)(pauVar28[-4] + 0xc) = uVar17;
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x50);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                puVar32 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x60);
                uVar14 = *puVar32;
                uVar15 = puVar32[1];
                uVar16 = puVar32[2];
                uVar17 = puVar32[3];
                *(undefined4 *)pauVar28[-5] = *puVar26;
                *(undefined4 *)(pauVar28[-5] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-5] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-5] + 0xc) = uVar13;
                *(undefined4 *)pauVar28[-6] = uVar14;
                *(undefined4 *)(pauVar28[-6] + 4) = uVar15;
                *(undefined4 *)(pauVar28[-6] + 8) = uVar16;
                *(undefined4 *)(pauVar28[-6] + 0xc) = uVar17;
                puVar26 = (undefined4 *)((int64_t)pauVar28 + iVar35 + -0x70);
                uVar11 = puVar26[1];
                uVar12 = puVar26[2];
                uVar13 = puVar26[3];
                auVar37 = *(undefined (*) [16])((int64_t)pauVar27 + iVar35);
                if (uVar36 == 0) break;
                *(undefined4 *)pauVar28[-7] = *puVar26;
                *(undefined4 *)(pauVar28[-7] + 4) = uVar11;
                *(undefined4 *)(pauVar28[-7] + 8) = uVar12;
                *(undefined4 *)(pauVar28[-7] + 0xc) = uVar13;
                *pauVar27 = auVar37;
                pauVar28 = pauVar27;
            }
            *(undefined4 *)pauVar28[-7] = *puVar26;
            *(undefined4 *)(pauVar28[-7] + 4) = uVar11;
            *(undefined4 *)(pauVar28[-7] + 8) = uVar12;
            *(undefined4 *)(pauVar28[-7] + 0xc) = uVar13;
            uVar34 = uVar34 & 0x7f;
        }
        for (uVar36 = uVar34 >> 4; uVar36 != 0; uVar36 = uVar36 - 1) {
            *pauVar27 = auVar37;
            pauVar27 = pauVar27 + -1;
            auVar37 = *(undefined (*) [16])((int64_t)pauVar27 + iVar35);
        }
        if ((uVar34 & 0xf) != 0) {
            *(undefined4 *)*pauVar23 = uVar7;
            *(undefined4 *)(*pauVar23 + 4) = uVar8;
            *(undefined4 *)(*pauVar23 + 8) = uVar9;
            *(undefined4 *)(*pauVar23 + 0xc) = uVar10;
        }
        *pauVar27 = auVar37;
        return;
    }
    if (*(uint32_t *)0x1806a3990 < 3) {
        if ((uVar34 < 0x801) || ((*(uint8_t *)0x18078131c & 2) == 0)) {
            if (0x80 < uVar34) {
                iVar35 = ((uint64_t)pauVar23 & 0xf) - 0x10;
                puVar26 = (undefined4 *)((int64_t)pauVar23 - iVar35);
                puVar32 = (undefined4 *)((int64_t)pauVar30 - iVar35);
                uVar34 = uVar34 + iVar35;
                if (0x80 < uVar34) {
                    do {
                        uVar7 = puVar32[1];
                        uVar8 = puVar32[2];
                        uVar9 = puVar32[3];
                        uVar10 = puVar32[4];
                        uVar11 = puVar32[5];
                        uVar12 = puVar32[6];
                        uVar13 = puVar32[7];
                        uVar14 = puVar32[8];
                        uVar15 = puVar32[9];
                        uVar16 = puVar32[10];
                        uVar17 = puVar32[0xb];
                        uVar18 = puVar32[0xc];
                        uVar19 = puVar32[0xd];
                        uVar20 = puVar32[0xe];
                        uVar21 = puVar32[0xf];
                        *puVar26 = *puVar32;
                        puVar26[1] = uVar7;
                        puVar26[2] = uVar8;
                        puVar26[3] = uVar9;
                        puVar26[4] = uVar10;
                        puVar26[5] = uVar11;
                        puVar26[6] = uVar12;
                        puVar26[7] = uVar13;
                        puVar26[8] = uVar14;
                        puVar26[9] = uVar15;
                        puVar26[10] = uVar16;
                        puVar26[0xb] = uVar17;
                        puVar26[0xc] = uVar18;
                        puVar26[0xd] = uVar19;
                        puVar26[0xe] = uVar20;
                        puVar26[0xf] = uVar21;
                        auVar2 = *(undefined (*) [16])(puVar32 + 0x14);
                        auVar37 = *(undefined (*) [16])(puVar32 + 0x18);
                        auVar3 = *(undefined (*) [16])(puVar32 + 0x1c);
                        *(undefined (*) [16])(puVar26 + 0x10) = *(undefined (*) [16])(puVar32 + 0x10);
                        *(undefined (*) [16])(puVar26 + 0x14) = auVar2;
                        *(undefined (*) [16])(puVar26 + 0x18) = auVar37;
                        *(undefined (*) [16])(puVar26 + 0x1c) = auVar3;
                        puVar26 = puVar26 + 0x20;
                        puVar32 = puVar32 + 0x20;
                        uVar34 = uVar34 - 0x80;
                    } while (0x7f < uVar34);
                }
            }
    // WARNING: Could not recover jumptable at 0x000180498556. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (9 cases) at 0x1806509e8
            (*(code *)((uint64_t)*(uint32_t *)((uVar34 + 0xf >> 4) * 4 + 0x1806509e8) + 0x180000000))();
            return;
        }
code_r0x000180498020:
        *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x38) = (uint64_t)uVar29;
        *(uint64_t *)((int64_t)*(undefined **)0x20 + -0x40) = uVar36;
        for (; uVar34 != 0; uVar34 = uVar34 - 1) {
            (*pauVar23)[0] = (*pauVar30)[0];
            pauVar30 = (undefined (*) [32])(*pauVar30 + 1);
            pauVar23 = (undefined (*) [32])(*pauVar23 + 1);
        }
        return;
    }
    if ((0x2000 < uVar34) && (uVar34 < 0x180001)) {
        pauVar24 = pauVar23 + 2;
        if (pauVar30 < pauVar23) {
            pauVar24 = pauVar30;
        }
        if ((pauVar24 <= pauVar30) && ((*(uint8_t *)0x18078131c & 2) != 0)) goto code_r0x000180498020;
    }
    auVar38 = vmovdqu_avx(*pauVar30);
    auVar43 = vmovdqu_avx(*(undefined (*) [32])(pauVar30[-1] + uVar34));
    if (0x100 < uVar34) {
        iVar35 = ((uint64_t)pauVar23 & 0x1f) - 0x20;
        pauVar24 = (undefined (*) [32])((int64_t)pauVar23 - iVar35);
        pauVar30 = (undefined (*) [32])((int64_t)pauVar30 - iVar35);
        uVar34 = uVar34 + iVar35;
        if (0x100 < uVar34) {
            if (0x180000 < uVar34) {
                do {
                    uVar36 = uVar34;
                    pauVar31 = pauVar30;
                    pauVar25 = pauVar24;
                    auVar39 = vmovdqu_avx(*pauVar31);
                    auVar41 = vmovdqu_avx(pauVar31[1]);
                    auVar40 = vmovdqu_avx(pauVar31[2]);
                    auVar42 = vmovdqu_avx(pauVar31[3]);
                    auVar39 = vmovntdq_avx(auVar39);
                    *pauVar25 = auVar39;
                    auVar39 = vmovntdq_avx(auVar41);
                    pauVar25[1] = auVar39;
                    auVar39 = vmovntdq_avx(auVar40);
                    pauVar25[2] = auVar39;
                    auVar39 = vmovntdq_avx(auVar42);
                    pauVar25[3] = auVar39;
                    auVar39 = vmovdqu_avx(pauVar31[4]);
                    auVar41 = vmovdqu_avx(pauVar31[5]);
                    auVar40 = vmovdqu_avx(pauVar31[6]);
                    auVar42 = vmovdqu_avx(pauVar31[7]);
                    auVar39 = vmovntdq_avx(auVar39);
                    pauVar25[4] = auVar39;
                    auVar39 = vmovntdq_avx(auVar41);
                    pauVar25[5] = auVar39;
                    auVar39 = vmovntdq_avx(auVar40);
                    pauVar25[6] = auVar39;
                    auVar39 = vmovntdq_avx(auVar42);
                    pauVar25[7] = auVar39;
                    pauVar24 = pauVar25 + 8;
                    pauVar30 = pauVar31 + 8;
                    uVar34 = uVar36 - 0x100;
                } while (0xff < uVar36 - 0x100);
                uVar34 = uVar36 - 0xe1 & 0xffffffffffffffe0;
    // switch table (18 cases) at 0x1806509c4
                switch(uVar36) {
                case 0x1e1:
                case 0x1e2:
                case 0x1e3:
                case 0x1e4:
                case 0x1e5:
                case 0x1e6:
                case 0x1e7:
                case 0x1e8:
                case 0x1e9:
                case 0x1ea:
                case 0x1eb:
                case 0x1ec:
                case 0x1ed:
                case 0x1ee:
                case 0x1ef:
                case 0x1f0:
                case 0x1f1:
                case 0x1f2:
                case 499:
                case 500:
                case 0x1f5:
                case 0x1f6:
                case 0x1f7:
                case 0x1f8:
                case 0x1f9:
                case 0x1fa:
                case 0x1fb:
                case 0x1fc:
                case 0x1fd:
                case 0x1fe:
                case 0x1ff:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(*pauVar31 + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(*pauVar25 + uVar34) = auVar39;
                case 0x1c1:
                case 0x1c2:
                case 0x1c3:
                case 0x1c4:
                case 0x1c5:
                case 0x1c6:
                case 0x1c7:
                case 0x1c8:
                case 0x1c9:
                case 0x1ca:
                case 0x1cb:
                case 0x1cc:
                case 0x1cd:
                case 0x1ce:
                case 0x1cf:
                case 0x1d0:
                case 0x1d1:
                case 0x1d2:
                case 0x1d3:
                case 0x1d4:
                case 0x1d5:
                case 0x1d6:
                case 0x1d7:
                case 0x1d8:
                case 0x1d9:
                case 0x1da:
                case 0x1db:
                case 0x1dc:
                case 0x1dd:
                case 0x1de:
                case 0x1df:
                case 0x1e0:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[1] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[1] + uVar34) = auVar39;
                case 0x1a1:
                case 0x1a2:
                case 0x1a3:
                case 0x1a4:
                case 0x1a5:
                case 0x1a6:
                case 0x1a7:
                case 0x1a8:
                case 0x1a9:
                case 0x1aa:
                case 0x1ab:
                case 0x1ac:
                case 0x1ad:
                case 0x1ae:
                case 0x1af:
                case 0x1b0:
                case 0x1b1:
                case 0x1b2:
                case 0x1b3:
                case 0x1b4:
                case 0x1b5:
                case 0x1b6:
                case 0x1b7:
                case 0x1b8:
                case 0x1b9:
                case 0x1ba:
                case 0x1bb:
                case 0x1bc:
                case 0x1bd:
                case 0x1be:
                case 0x1bf:
                case 0x1c0:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[2] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[2] + uVar34) = auVar39;
                case 0x181:
                case 0x182:
                case 0x183:
                case 0x184:
                case 0x185:
                case 0x186:
                case 0x187:
                case 0x188:
                case 0x189:
                case 0x18a:
                case 0x18b:
                case 0x18c:
                case 0x18d:
                case 0x18e:
                case 399:
                case 400:
                case 0x191:
                case 0x192:
                case 0x193:
                case 0x194:
                case 0x195:
                case 0x196:
                case 0x197:
                case 0x198:
                case 0x199:
                case 0x19a:
                case 0x19b:
                case 0x19c:
                case 0x19d:
                case 0x19e:
                case 0x19f:
                case 0x1a0:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[3] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[3] + uVar34) = auVar39;
                case 0x161:
                case 0x162:
                case 0x163:
                case 0x164:
                case 0x165:
                case 0x166:
                case 0x167:
                case 0x168:
                case 0x169:
                case 0x16a:
                case 0x16b:
                case 0x16c:
                case 0x16d:
                case 0x16e:
                case 0x16f:
                case 0x170:
                case 0x171:
                case 0x172:
                case 0x173:
                case 0x174:
                case 0x175:
                case 0x176:
                case 0x177:
                case 0x178:
                case 0x179:
                case 0x17a:
                case 0x17b:
                case 0x17c:
                case 0x17d:
                case 0x17e:
                case 0x17f:
                case 0x180:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[4] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[4] + uVar34) = auVar39;
                case 0x141:
                case 0x142:
                case 0x143:
                case 0x144:
                case 0x145:
                case 0x146:
                case 0x147:
                case 0x148:
                case 0x149:
                case 0x14a:
                case 0x14b:
                case 0x14c:
                case 0x14d:
                case 0x14e:
                case 0x14f:
                case 0x150:
                case 0x151:
                case 0x152:
                case 0x153:
                case 0x154:
                case 0x155:
                case 0x156:
                case 0x157:
                case 0x158:
                case 0x159:
                case 0x15a:
                case 0x15b:
                case 0x15c:
                case 0x15d:
                case 0x15e:
                case 0x15f:
                case 0x160:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[5] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[5] + uVar34) = auVar39;
                case 0x121:
                case 0x122:
                case 0x123:
                case 0x124:
                case 0x125:
                case 0x126:
                case 0x127:
                case 0x128:
                case 0x129:
                case 0x12a:
                case 299:
                case 300:
                case 0x12d:
                case 0x12e:
                case 0x12f:
                case 0x130:
                case 0x131:
                case 0x132:
                case 0x133:
                case 0x134:
                case 0x135:
                case 0x136:
                case 0x137:
                case 0x138:
                case 0x139:
                case 0x13a:
                case 0x13b:
                case 0x13c:
                case 0x13d:
                case 0x13e:
                case 0x13f:
                case 0x140:
                    auVar39 = vmovdqu_avx(*(undefined (*) [32])(pauVar31[6] + uVar34));
                    auVar39 = vmovntdq_avx(auVar39);
                    *(undefined (*) [32])(pauVar25[6] + uVar34) = auVar39;
                default:
                    auVar43 = vmovdqu_avx(auVar43);
                    *(undefined (*) [32])(pauVar25[-1] + uVar36) = auVar43;
                case 0x100:
                    auVar38 = vmovdqu_avx(auVar38);
                    *pauVar23 = auVar38;
                    return;
                }
            }
            do {
                auVar38 = vmovdqu_avx(*pauVar30);
                auVar43 = vmovdqu_avx(pauVar30[1]);
                auVar39 = vmovdqu_avx(pauVar30[2]);
                auVar41 = vmovdqu_avx(pauVar30[3]);
                *pauVar24 = auVar38;
                pauVar24[1] = auVar43;
                pauVar24[2] = auVar39;
                pauVar24[3] = auVar41;
                auVar38 = vmovdqu_avx(pauVar30[4]);
                auVar43 = vmovdqu_avx(pauVar30[5]);
                auVar39 = vmovdqu_avx(pauVar30[6]);
                auVar41 = vmovdqu_avx(pauVar30[7]);
                pauVar24[4] = auVar38;
                pauVar24[5] = auVar43;
                pauVar24[6] = auVar39;
                pauVar24[7] = auVar41;
                pauVar24 = pauVar24 + 8;
                pauVar30 = pauVar30 + 8;
                uVar34 = uVar34 - 0x100;
            } while (0xff < uVar34);
        }
    }
    // WARNING: Could not recover jumptable at 0x0001804982b2. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (27 cases) at 0x1806509a0
    (*(code *)((uint64_t)*(uint32_t *)((uVar34 + 0x1f >> 5) * 4 + 0x1806509a0) + 0x180000000))();
    return;
}

// ============================================================
// Function: FUN_1801431e0
// Address: 0x1801431e0
// Size: 14980 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_2e8h
// WARNING: Variable defined which should be unmapped: var_2d0h
// WARNING: Variable defined which should be unmapped: var_2e0h
// WARNING: Variable defined which should be unmapped: var_2d8h
// WARNING: Variable defined which should be unmapped: var_2c8h
// WARNING: Variable defined which should be unmapped: var_14h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_240h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_238h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Removing arg arg_230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_294h
// WARNING: [rz-ghidra] Detected overlap for variable var_2a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_2b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_2b6h
// WARNING: [rz-ghidra] Detected overlap for variable var_2a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_2aeh
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_290h
// WARNING: [rz-ghidra] Detected overlap for variable var_2b7h
// WARNING: [rz-ghidra] Detected overlap for variable var_2afh
// WARNING: [rz-ghidra] Detected overlap for variable var_2b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_5bh
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28eh
// WARNING: [rz-ghidra] Detected overlap for variable arg_bch
// WARNING: [rz-ghidra] Detected overlap for variable arg_c3h
// WARNING: [rz-ghidra] Detected overlap for variable arg_c7h
// WARNING: [rz-ghidra] Detected overlap for variable arg_ach
// WARNING: [rz-ghidra] Detected overlap for variable arg_c2h
// WARNING: [rz-ghidra] Detected overlap for variable arg_d4h
// WARNING: [rz-ghidra] Removing arg arg_6ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_73h
// WARNING: [rz-ghidra] Removing arg arg_7bh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_83h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_8bh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_93h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_97h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_72h
// WARNING: [rz-ghidra] Detected overlap for variable arg_84h
// WARNING: [rz-ghidra] Detected overlap for variable arg_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_2adh
// WARNING: [rz-ghidra] Detected overlap for variable var_28fh
// WARNING: [rz-ghidra] Detected overlap for variable var_5dh
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_5fh
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable arg_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_11h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_36h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_26h
// WARNING: [rz-ghidra] Detected overlap for variable arg_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_6h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h

void fcn.1801431e0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int32_t **placeholder_6, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_90h,
                  int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c8h, int64_t arg_d8h, int64_t arg_e0h,
                  int64_t arg_f0h, int64_t arg_f8h, int64_t arg_100h, int64_t arg_108h, int64_t arg_118h,
                  int64_t arg_120h, int64_t arg_128h)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined4 *puVar3;
    int32_t *piVar4;
    bool bVar5;
    bool bVar6;
    bool bVar7;
    bool bVar8;
    bool bVar9;
    bool bVar10;
    undefined auVar11 [16];
    uint64_t uVar12;
    undefined auVar13 [16];
    uint32_t uVar14;
    float fVar15;
    float fVar16;
    char cVar17;
    uint8_t uVar18;
    char cVar19;
    char cVar20;
    uint32_t uVar21;
    uint32_t uVar22;
    int32_t iVar23;
    char *pcVar24;
    int64_t *piVar25;
    int64_t iVar26;
    undefined8 *puVar27;
    int64_t iVar28;
    int32_t **ppiVar29;
    undefined8 *puVar30;
    float *pfVar31;
    undefined8 uVar32;
    int32_t iVar33;
    uint32_t uVar34;
    uint64_t uVar35;
    undefined8 *puVar36;
    undefined8 *puVar37;
    undefined8 *puVar38;
    int32_t iVar39;
    int32_t iVar40;
    undefined8 *puVar41;
    int64_t *piVar42;
    uint32_t uVar43;
    undefined8 *puVar44;
    int64_t arg1_00;
    char *pcVar45;
    undefined4 uVar46;
    int32_t *piVar47;
    undefined4 uVar48;
    float fVar49;
    float fVar50;
    float fVar51;
    float fVar52;
    float fVar53;
    undefined auVar54 [16];
    undefined8 extraout_XMM0_Qb;
    float fVar55;
    float fVar56;
    undefined auVar57 [16];
    float fVar58;
    undefined auVar59 [16];
    undefined auVar60 [16];
    undefined auVar61 [16];
    float fVar62;
    float fVar63;
    int64_t var_4h;
    int64_t var_20h;
    undefined auStackY_308 [32];
    int64_t var_2e8h;
    uint8_t var_2b8h;
    char var_2b7h;
    char var_2b6h;
    int64_t var_2b4h;
    int64_t var_2e0h;
    int64_t var_2d8h;
    int64_t var_2d0h;
    int64_t var_2c8h;
    int64_t var_2c0h;
    int64_t var_2ach;
    uint32_t var_2a4h;
    int64_t var_2a0h;
    int64_t var_298h;
    char var_290h;
    char var_28fh;
    char var_28eh;
    undefined8 *puStack_288;
    undefined8 *puStack_280;
    float fStack_278;
    undefined8 uStack_270;
    char cStack_268;
    uint8_t uStack_267;
    char cStack_266;
    char cStack_265;
    char cStack_264;
    char cStack_263;
    undefined8 uStack_260;
    float fStack_258;
    float fStack_254;
    uint32_t uStack_250;
    int64_t iStack_248;
    undefined8 uStack_240;
    int64_t iStack_238;
    uint32_t uStack_230;
    float fStack_22c;
    float fStack_228;
    uint32_t uStack_224;
    float fStack_220;
    float fStack_21c;
    undefined8 uStack_218;
    float fStack_210;
    float fStack_20c;
    undefined8 uStack_208;
    float fStack_200;
    float fStack_1fc;
    float fStack_1f8;
    float fStack_1f4;
    float fStack_1f0;
    undefined4 uStack_1ec;
    float afStack_1e8 [2];
    int64_t iStack_1e0;
    undefined auStack_1d8 [16];
    float fStack_1c8;
    int64_t iStack_1c0;
    int64_t iStack_1b8;
    undefined4 uStack_1b0;
    uint32_t uStack_1ac;
    int32_t *piStack_1a8;
    uint32_t uStack_1a0;
    undefined4 uStack_19c;
    undefined2 uStack_198;
    undefined uStack_196;
    char cStack_195;
    undefined4 uStack_194;
    unkbyte3 Stack_190;
    unkbyte5 Stack_18d;
    int32_t iStack_188;
    undefined4 uStack_184;
    int32_t iStack_180;
    int32_t iStack_17c;
    int32_t iStack_178;
    undefined4 uStack_174;
    undefined auStack_168 [8];
    uint32_t uStack_160;
    undefined4 uStack_15c;
    undefined auStack_158 [12];
    undefined4 uStack_14c;
    undefined auStack_148 [8];
    undefined8 *puStack_140;
    undefined auStack_138 [8];
    undefined8 uStack_130;
    undefined auStack_128 [16];
    char *pcStack_118;
    int64_t iStack_110;
    undefined auStack_108 [8];
    undefined auStack_100 [16];
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    undefined8 uStack_e8;
    uint64_t uStack_e0;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_14h;
    
    iVar28 = *(int64_t *)0x180781f28;
    uStack_e0 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_308;
    fStack_278 = (float)arg4;
    uStack_270 = (undefined8 *)arg_40h;
    var_2a0h = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar26 = *(int64_t *)(iVar28 + 0x15e0);
    puStack_288 = (undefined8 *)arg3;
    uStack_260 = placeholder_6;
    iStack_1e0 = iVar26;
    iStack_110 = arg1;
    if (*(char *)(iVar26 + 0x10e) != '\0') goto code_r0x000180143643;
    var_298h._0_4_ = (uint32_t)arg_30h & 0x4000000;
    if ((arg_30h & 0x4000000U) != 0) {
        func_0x00018010bfc0();
    }
    uVar21 = func_0x0001800f5a90(arg1, 0, *(undefined4 *)
                                           (*(int64_t *)(iVar26 + 0x150) + -4 +
                                           (int64_t)*(int32_t *)(iVar26 + 0x148) * 4));
    pcStack_118 = (char *)arg1;
    if (arg1 != -1) {
        while (*pcStack_118 != '\0') {
            pcVar24 = pcStack_118 + 1;
            if (((*pcStack_118 == '#') && (*pcVar24 == '#')) ||
               (pcStack_118 = pcVar24, pcVar24 == (char *)0xffffffffffffffff)) break;
        }
    }
    var_2e8h = CONCAT44(var_2e8h._4_4_, 0xbf800000);
    var_2b4h._0_4_ = uVar21;
    func_0x0001800fe0a0(&puStack_280, arg1, pcStack_118, 0);
    uVar48 = func_0x00018010be10();
    func_0x00018010be90(&uStack_208, *(undefined8 *)arg_28h, uVar48);
    fVar50 = uStack_208._4_4_;
    afStack_1e8[0] = uStack_208._4_4_;
    fVar63 = 0.0;
    fStack_1c8 = puStack_280._0_4_;
    if (puStack_280._0_4_ <= 0.0) {
        puStack_280._0_4_ = 0.0;
    } else {
        puStack_280._0_4_ = puStack_280._0_4_ + *(float *)(iVar28 + 0xdf4);
    }
    ppiVar29 = (int32_t **)(iVar26 + 0x158);
    fVar62 = *(float *)ppiVar29;
    fVar52 = *(float *)(iVar26 + 0x15c);
    uStack_240 = *ppiVar29;
    uStack_218 = (undefined8 *)*ppiVar29;
    fVar58 = (float)uStack_208;
    fStack_210 = fVar62 + (float)uStack_208;
    auStack_1d8 = ZEXT416((uint32_t)fStack_210);
    fStack_20c = fVar52 + uStack_208._4_4_;
    fVar55 = puStack_280._0_4_ + (float)uStack_208 + fVar62;
    iStack_238 = CONCAT44(fVar52 + uStack_208._4_4_, fVar55);
    fStack_220 = (float)uStack_208;
    _auStack_168 = ZEXT416(0);
    puStack_280 = (undefined8 *)CONCAT44((fVar52 + uStack_208._4_4_) - fVar52, fVar55 - fVar62);
    fStack_228 = fVar62;
    fStack_21c = fVar52;
    _auStack_158 = _auStack_168;
    _auStack_148 = _auStack_168;
    _auStack_138 = _auStack_168;
    auStack_128 = _auStack_168;
    if ((arg_30h & 0x4000000U) != 0) {
        func_0x00018010bbf0(&puStack_280);
        if (((*(uint32_t *)(iVar28 + 0x26f8) == uVar21) || (*(uint32_t *)(iVar28 + 0x1654) == uVar21)) ||
           (uVar21 == *(uint32_t *)(iVar28 + 0x21ec))) {
            bVar5 = true;
        } else {
            bVar5 = false;
        }
        cVar17 = func_0x00018010b530(&uStack_240, uVar21, &uStack_218, 0x100000);
        if ((cVar17 != '\0') || (bVar5)) {
            uVar48 = *(undefined4 *)(iVar28 + 0x1fbc);
            uVar22 = *(uint32_t *)(iVar28 + 0x1fc0);
            _auStack_158 = *(undefined (*) [16])(iVar28 + 0x1fc8);
            _auStack_148 = *(undefined (*) [16])(iVar28 + 0x1fd8);
            _auStack_138 = *(undefined (*) [16])(iVar28 + 0x1fe8);
            auStack_128 = *(undefined (*) [16])(iVar28 + 0x1ff8);
            *(float *)(iVar26 + 0x158) = fVar62;
            *(float *)(iVar26 + 0x15c) = fVar52;
            uVar34 = *(uint32_t *)(iVar28 + 0x21ec);
            if ((uVar34 == uVar21) &&
               ((((uint8_t)*(undefined4 *)(iVar28 + 0x21f8) & 0x28) == 8 && ((arg_30h & 0x20U) != 0)))) {
                *(undefined4 *)(iVar28 + 0x21ec) = 0;
                uVar34 = 0;
            }
            if (*(uint32_t *)(iVar28 + 0x1654) == uVar21) {
                *(undefined4 *)(iVar28 + 0x21ec) = 0;
            }
            func_0x0001800f6710(3, iVar28 + 0xf40);
            func_0x0001800f6810(7);
            func_0x0001800f6810(8);
            puStack_280 = (undefined8 *)0x0;
            func_0x0001800f6960(2, &puStack_280);
            auStack_1d8 = ZEXT416((uint32_t)fStack_210);
            fVar62 = (float)uStack_218;
            fStack_228 = (float)uStack_218;
            fStack_21c = uStack_218._4_4_;
            puStack_280 = (undefined8 *)CONCAT44(fStack_20c - uStack_218._4_4_, fStack_210 - (float)uStack_218);
            var_2e8h = CONCAT44(var_2e8h._4_4_, 4);
            cVar17 = func_0x0001800fe6d0(arg1, uVar21, &puStack_280, 1);
            *(uint32_t *)(iVar28 + 0x21ec) = uVar34;
            func_0x0001800f6a20(3);
            func_0x0001800f6770(1);
            if ((cVar17 != '\0') || (bVar5)) {
                iVar26 = *(int64_t *)(iVar28 + 0x15e0);
                *(uint16_t *)(iVar26 + 0x1b6) =
                     *(uint16_t *)(iVar26 + 0x1b6) | (uint16_t)(1 << (*(uint32_t *)(iVar26 + 0x1b0) & 0x1f));
                *(float *)(iVar26 + 0x158) = *(float *)(iVar26 + 0x158) + *(float *)(iVar28 + 0xddc);
                *(float *)(iVar26 + 0x15c) = *(float *)(iVar28 + 0xde0) + *(float *)(iVar26 + 0x15c);
                fStack_220 = fVar58 - *(float *)(iVar26 + 0xfc);
                *(uint32_t *)(iVar28 + 0x1fb8) = (uint32_t)var_2b4h;
                *(undefined4 *)(iVar28 + 0x1fbc) = uVar48;
                *(uint32_t *)(iVar28 + 0x1fc0) = uVar22;
                fVar52 = fStack_220;
                iStack_248 = iVar26;
                uStack_224 = uVar22;
                uStack_1ec = uVar48;
                uVar21 = (uint32_t)var_2b4h;
                goto code_r0x0001801437b4;
            }
            func_0x0001800fea60();
        }
        func_0x00018010c110();
        goto code_r0x000180143643;
    }
    iStack_248 = iVar26;
    func_0x00018010bbf0(&puStack_280);
    fVar52 = fVar58;
    if (((uint32_t)arg_30h >> 0x1b & 1) == 0) {
        cVar17 = func_0x00018010b530(&uStack_240, uVar21, &uStack_218, 0x100000);
        if (cVar17 == '\0') goto code_r0x000180143643;
        auStack_1d8 = ZEXT416((uint32_t)fStack_210);
        fStack_21c = uStack_218._4_4_;
        fStack_228 = (float)uStack_218;
        uStack_224 = uStack_160;
        uStack_1ec = auStack_168._4_4_;
        fVar62 = (float)uStack_218;
    } else {
        uStack_224 = uStack_160;
        uStack_1ec = auStack_168._4_4_;
    }
code_r0x0001801437b4:
    uVar18 = func_0x0001800fa440(&uStack_218, uVar21, *(uint32_t *)(iVar28 + 0x1fbc) | 0x8000);
    var_2ach._0_4_ = (uint32_t)uVar18;
    if (uVar18 != 0) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2650) = 1;
        var_2ach._0_4_ = (uint32_t)uVar18;
        if (*(char *)(iVar28 + 0x21cd) != '\0') {
            var_2ach._0_4_ = 0;
        }
    }
    if ((uVar21 == 0) ||
       (uStack_208 = *(int64_t *)0x180781f28 + 0x2660, *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2674) != uVar21)) {
        uStack_208 = 0;
    }
    arg1_00 = uStack_208;
    var_298h._4_4_ = (uint32_t)arg_30h | 0x200;
    if ((*(uint32_t *)(iVar28 + 0x1fbc) & 0x800) == 0) {
        var_298h._4_4_ = (uint32_t)arg_30h;
    }
    var_2ach._4_4_ = var_298h._4_4_ & 0x200;
    uStack_230 = var_298h._4_4_ & 0x400;
    uStack_250 = var_298h._4_4_ & 0x1000000;
    if (uStack_250 == 0) {
        fVar55 = 0.0;
    } else {
        if (*(char *)(iVar26 + 0x105) == '\0') {
            fVar49 = (float)(*(uint32_t *)(iVar28 + 0xe14) ^ 0x80000000);
        } else {
            fVar49 = 0.0;
        }
        iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        if ((*(int64_t *)(iVar2 + 0x208) != 0) ||
           (pfVar31 = (float *)(iVar2 + 0x2d0), *(int64_t *)(*(int64_t *)0x180781f28 + 0x24d0) != 0)) {
            pfVar31 = (float *)(iVar2 + 0x2a0);
        }
        fVar49 = (*pfVar31 - *(float *)(iVar2 + 0x158)) + fVar49;
        fVar55 = 1.0;
        if (1.0 <= fVar49) {
            fVar55 = fVar49;
        }
    }
    if (((char)(uint32_t)var_2ach == '\0') || (*(char *)(iVar28 + 0xb50) == '\0')) {
        bVar5 = false;
    } else {
        bVar5 = true;
    }
    uVar34 = *(uint32_t *)(iVar28 + 0x1654);
    if ((uVar34 == uVar21) || (var_2b4h._4_1_ = '\x01', *(uint32_t *)(iVar28 + 0x21ec) != uVar21)) {
        var_2b4h._4_1_ = '\0';
    }
    if ((bVar5) || ((uVar34 == 0 && ((var_298h._4_4_ >> 0x1b & 1) != 0)))) {
        bVar6 = true;
    } else {
        bVar6 = false;
    }
    fStack_1f0 = fVar55;
    if (((uint32_t)var_298h == 0) || (uStack_208 == 0)) {
        uVar21 = 0;
        if (((uint32_t)var_298h != 0) && (uVar22 = 0, uStack_208 != 0)) goto code_r0x000180143976;
code_r0x000180143991:
        bVar7 = false;
        if (((uint32_t)var_298h != 0) && (arg1_00 != 0)) goto code_r0x00018014399d;
code_r0x0001801439c1:
        var_2a4h = var_2a4h & 0xffffff00;
        var_2b4h._6_1_ = 0;
        if ((uint32_t)var_298h == 0) {
            fStack_22c = 3.402823e+38;
            var_2b4h._6_1_ = 0;
        } else {
            fStack_22c = *(float *)(iVar26 + 0xd8);
        }
    } else {
        uVar22 = func_0x0001800f5a90(0x180645a58, 0, 
                                     *(undefined4 *)
                                      (*(int64_t *)(iVar26 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar26 + 0x148) * 4));
code_r0x000180143976:
        uVar21 = uVar22;
        if ((uVar34 != 0) || (*(uint32_t *)(var_2a0h + 0x1680) != uVar21)) goto code_r0x000180143991;
        bVar7 = true;
code_r0x00018014399d:
        if (uVar34 != uVar21) goto code_r0x0001801439c1;
        var_2b4h._6_1_ = 1;
        var_2a4h = var_2a4h & 0xffffff00;
        fStack_22c = *(float *)(iVar26 + 0xd8);
    }
    fVar49 = fStack_22c;
    puVar41 = puStack_288;
    iVar26 = var_2a0h;
    var_2b6h = '\0';
    if ((arg1_00 == 0) || (*(char *)(arg1_00 + 0x75) == '\0')) {
        bVar8 = false;
        if (arg1_00 != 0) goto code_r0x000180143a0a;
code_r0x000180143a23:
        bVar9 = false;
        if (arg1_00 != 0) goto code_r0x000180143a2b;
code_r0x000180143a3c:
        bVar10 = false;
    } else {
        bVar8 = true;
code_r0x000180143a0a:
        if ((bool)*(char *)(*(int64_t *)(arg1_00 + 8) + 0x17) == ((uint32_t)var_298h == 0)) goto code_r0x000180143a23;
        bVar9 = true;
code_r0x000180143a2b:
        if (((var_298h._4_4_ ^ *(uint32_t *)(arg1_00 + 0x10)) & 0x200) == 0) goto code_r0x000180143a3c;
        bVar10 = true;
    }
    if ((((bVar6) || (var_2b4h._4_1_ != '\0')) || (*(uint32_t *)(var_2a0h + 0x277c) == (uint32_t)var_2b4h)) || (bVar7))
    {
        bVar6 = true;
    }
    if (bVar8) {
        uVar48 = func_0x000180498cd0(puStack_288);
        *(undefined *)(arg1_00 + 0x75) = 0;
        var_2e8h = CONCAT44(var_2e8h._4_4_, uVar48);
        fcn.180142ec0(arg1_00, *(int64_t *)(arg1_00 + 0x30), (uint64_t)*(uint32_t *)(arg1_00 + 0x18), (int64_t)puVar41, 
                      var_2e8h);
        func_0x00018011f640(arg1_00 + 0x28, (int32_t)fStack_278 + 1);
        *(undefined4 *)(arg1_00 + 0x18) = uVar48;
        func_0x000180498030(*(undefined8 *)(arg1_00 + 0x30), puVar41);
        *(undefined4 *)(*(int64_t *)(arg1_00 + 8) + 4) = *(undefined4 *)(arg1_00 + 0x78);
        *(undefined4 *)(*(int64_t *)(arg1_00 + 8) + 8) = *(undefined4 *)(arg1_00 + 0x7c);
        **(undefined4 **)(arg1_00 + 8) = (*(undefined4 **)(arg1_00 + 8))[2];
    } else if (((bVar6) && (uVar34 != (uint32_t)var_2b4h)) || ((bVar9 || (bVar10)))) {
        arg1_00 = var_2a0h + 0x2660;
        *(undefined4 *)(var_2a0h + 0x26cc) = 0xbe99999a;
        uStack_208 = arg1_00;
        fcn.180143150((uint64_t)*(uint32_t *)(var_2a0h + 0x2674), var_2e8h, var_2d0h);
        iVar33 = func_0x000180498cd0(puStack_288);
        if (!bVar7) {
            func_0x00018011f640(iVar26 + 0x2698, iVar33 + 1);
            func_0x000180498030(*(undefined8 *)(iVar26 + 0x26a0), puStack_288, (int64_t)(iVar33 + 1));
        }
        if (((*(uint32_t *)(iVar26 + 0x2674) != (uint32_t)var_2b4h) || (bVar9)) ||
           ((bVar7 = true, !bVar10 &&
            (((*(int32_t *)(iVar26 + 0x2678) != iVar33 || (*(int64_t *)(iVar26 + 0x2690) == 0)) ||
             (iVar23 = func_0x000180498f90(*(int64_t *)(iVar26 + 0x2690), puStack_288, iVar33), iVar23 != 0)))))) {
            bVar7 = false;
        }
        *(uint32_t *)(iVar26 + 0x2674) = (uint32_t)var_2b4h;
        *(int32_t *)(iVar26 + 0x2678) = iVar33;
        *(undefined *)(iVar26 + 0x26d3) = 0;
        puVar41 = puStack_288;
        if (var_2ach._4_4_ == 0) {
            func_0x00018011f640(iVar26 + 0x2688, (int32_t)fStack_278 + 1);
            puVar41 = puStack_288;
            func_0x000180498030(*(undefined8 *)(iVar26 + 0x2690), puStack_288, 
                                (int64_t)(*(int32_t *)(iVar26 + 0x2678) + 1));
        }
        iVar28 = var_2a0h;
        *(undefined8 *)(iVar26 + 0x26bc) = 0;
        if ((var_298h._4_4_ >> 0x11 & 1) != 0) {
            fVar51 = *(float *)(var_2a0h + 0xddc);
            var_2e8h = CONCAT44(var_2e8h._4_4_, 0xbf800000);
            pfVar31 = (float *)func_0x0001800fe0a0(auStack_108, puVar41, 0);
            fVar51 = (*pfVar31 - fVar58) + fVar51 + fVar51;
            fVar58 = 0.0;
            if (0.0 <= fVar51) {
                fVar58 = fVar51;
            }
            *(float *)(iVar26 + 0x26bc) = fVar58 + *(float *)(iVar26 + 0x26bc);
        }
        if (!bVar7) {
            puVar3 = *(undefined4 **)(iVar26 + 0x2668);
            *(undefined8 *)(puVar3 + 0x28e) = 0x630000;
            puVar3[0x290] = 999;
            *(undefined8 *)(puVar3 + 1) = 0;
            *puVar3 = 0;
            *(undefined2 *)((int64_t)puVar3 + 0x15) = 1;
            puVar3[7] = 0;
            *(undefined *)(puVar3 + 5) = 0;
            *(bool *)((int64_t)puVar3 + 0x17) = (uint32_t)var_298h == 0;
            *(undefined *)(puVar3 + 3) = 0;
            puVar3[4] = 0;
        }
        if ((uint32_t)var_298h == 0) {
            var_2a4h = var_2a4h & 0xff;
            if ((var_298h._4_4_ >> 0xc & 1) != 0) {
                var_2a4h = 1;
            }
            if ((var_2b4h._4_1_ != '\0') && ((!bVar7 || ((*(uint8_t *)(iVar28 + 0x21f8) & 4) == 0)))) {
                var_2a4h = 1;
            }
            uVar18 = (uint8_t)var_2a4h;
            if (bVar5) {
                if (*(char *)(iVar28 + 0x138) != '\0') {
                    uVar18 = 1;
                }
                var_2a4h = (uint32_t)uVar18;
            }
        }
        if ((var_298h._4_4_ >> 0xb & 1) != 0) {
            *(undefined *)(*(int64_t *)(iVar26 + 0x2668) + 0xc) = 1;
        }
    }
    iVar28 = iStack_1e0;
    iVar26 = var_2a0h;
    cVar17 = *(char *)(var_2a0h + 0x8d);
    cVar20 = var_2b4h._4_1_;
    var_290h = cVar17;
    if ((*(uint32_t *)(var_2a0h + 0x1654) != (uint32_t)var_2b4h) && (bVar6)) {
        func_0x0001800f9f30((uint32_t)var_2b4h, iStack_1e0);
        func_0x00018010e4a0((uint32_t)var_2b4h, iVar28);
        func_0x00018010e050(iVar28, 0);
        cVar20 = var_2b4h._4_1_;
        if (var_2b4h._4_1_ != '\0') {
            func_0x00018010e380();
        }
    }
    uVar35 = (uint64_t)(uint32_t)var_2b4h;
    if (*(uint32_t *)(iVar26 + 0x1654) == (uint32_t)var_2b4h) {
        auStack_100 = *(undefined (*) [16])0x180646aa0;
        uStack_f0 = 0x207;
        uStack_ec = 0x208;
        puVar41 = (undefined8 *)auStack_100;
        do {
            func_0x000180109bc0(*(undefined4 *)puVar41, uVar35 & 0xffffffff);
            iVar28 = iStack_248;
            iVar2 = *(int64_t *)0x180781f28;
            puVar41 = (undefined8 *)((int64_t)puVar41 + 4);
        } while (puVar41 != &uStack_e8);
        uVar48 = (undefined4)uVar35;
        if (bVar5) {
            *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1d90) = uVar48;
            *(undefined4 *)(iVar2 + 0x1d8c) = uVar48;
            *(undefined2 *)(iVar2 + 0x1d94) = 0;
        }
        *(uint32_t *)(iVar26 + 0x1f68) = *(uint32_t *)(iVar26 + 0x1f68) | 3;
        if (((uint32_t)var_298h != 0) || ((var_298h._4_4_ & 0x80000) != 0)) {
            *(uint32_t *)(iVar26 + 0x1f68) = *(uint32_t *)(iVar26 + 0x1f68) | 0xc;
            iVar2 = *(int64_t *)0x180781f28;
            *(undefined4 *)(*(int64_t *)0x180781f28 + 0x16f4) = uVar48;
            *(undefined4 *)(iVar2 + 0x16f0) = uVar48;
            *(undefined2 *)(iVar2 + 0x16f8) = 0;
            *(undefined4 *)(iVar2 + 0x1700) = uVar48;
            *(undefined4 *)(iVar2 + 0x16fc) = uVar48;
            *(undefined2 *)(iVar2 + 0x1704) = 0;
            if ((uint32_t)var_298h != 0) {
                *(undefined4 *)(iVar2 + 0x170c) = uVar48;
                *(undefined4 *)(iVar2 + 0x1708) = uVar48;
                *(undefined2 *)(iVar2 + 0x1710) = 0;
                *(undefined4 *)(iVar2 + 0x1718) = uVar48;
                *(undefined4 *)(iVar2 + 0x1714) = uVar48;
                *(undefined2 *)(iVar2 + 0x171c) = 0;
            }
        }
        iVar2 = *(int64_t *)0x180781f28;
        if (cVar17 != '\0') {
            *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1dfc) = uVar48;
            *(undefined4 *)(iVar2 + 0x1df8) = uVar48;
            *(undefined2 *)(iVar2 + 0x1e00) = 0;
        }
        if (((uint32_t)var_298h != 0) && (arg1_00 != 0)) {
            *(undefined4 *)(arg1_00 + 0x60) = *(undefined4 *)(iStack_248 + 0xd8);
        }
        if (var_2ach._4_4_ == 0) {
            if (arg1_00 != 0) goto code_r0x000180143e92;
        } else if (arg1_00 != 0) {
            uVar48 = func_0x000180498cd0(puStack_288);
            *(undefined4 *)(arg1_00 + 0x18) = uVar48;
            uVar35 = (uint64_t)(uint32_t)var_2b4h;
code_r0x000180143e92:
            iVar33 = *(int32_t *)(arg1_00 + 0x18);
            piVar47 = *(int32_t **)(arg1_00 + 8);
            if (*piVar47 < iVar33) {
                iVar33 = *piVar47;
            }
            *piVar47 = iVar33;
            iVar33 = *(int32_t *)(arg1_00 + 0x18);
            iVar2 = *(int64_t *)(arg1_00 + 8);
            if (*(int32_t *)(iVar2 + 4) < iVar33) {
                iVar33 = *(int32_t *)(iVar2 + 4);
            }
            *(int32_t *)(iVar2 + 4) = iVar33;
            iVar33 = *(int32_t *)(arg1_00 + 0x18);
            iVar2 = *(int64_t *)(arg1_00 + 8);
            if (*(int32_t *)(iVar2 + 8) < iVar33) {
                iVar33 = *(int32_t *)(iVar2 + 8);
            }
            *(int32_t *)(iVar2 + 8) = iVar33;
            goto code_r0x000180143ed0;
        }
    } else {
        iVar28 = iStack_248;
        if (arg1_00 == 0) goto code_r0x000180143ee3;
code_r0x000180143ed0:
        puVar41 = puStack_288;
        if (var_2ach._4_4_ == 0) {
            puVar41 = *(undefined8 **)(arg1_00 + 0x30);
        }
        *(undefined8 **)(arg1_00 + 0x20) = puVar41;
    }
code_r0x000180143ee3:
    if ((*(int32_t *)(iVar26 + 0x1654) == (int32_t)uVar35) && (arg1_00 == 0)) {
        func_0x0001800f9f30(0, 0);
        uVar35 = (uint64_t)(uint32_t)var_2b4h;
    }
    if (*(int32_t *)(iVar26 + 0x1654) == (int32_t)uVar35) {
        if ((*(char *)(iVar26 + 0xb50) == '\0') || (bVar6)) {
code_r0x000180143f30:
            var_2b7h = '\x01';
        } else {
            var_2b6h = '\x01';
            var_2b7h = '\x01';
        }
    } else {
        if ((arg1_00 != 0) && (var_2b4h._6_1_ != 0)) goto code_r0x000180143f30;
        var_2b7h = '\0';
    }
    cVar19 = (char)var_2a4h;
    if ((arg1_00 == 0) ||
       (((*(int32_t *)(*(int64_t *)(arg1_00 + 8) + 4) == *(int32_t *)(*(int64_t *)(arg1_00 + 8) + 8) && (cVar19 == '\0')
         ) || (var_2b7h == '\0')))) {
        var_2b8h = 0;
        if ((var_2b7h != '\0') || (var_2b8h = 0, *(int32_t *)(iVar26 + 0x1654) == (int32_t)uVar35))
        goto code_r0x000180143f8a;
code_r0x000180143f9a:
        cStack_263 = '\0';
    } else {
        var_2b8h = 1;
code_r0x000180143f8a:
        if ((var_2ach._4_4_ != 0) || (cStack_263 = '\x01', arg1_00 == 0)) goto code_r0x000180143f9a;
    }
    var_2b4h._5_1_ = '\0';
    var_2b4h._4_1_ = 0;
    if (uStack_230 != 0) {
        fcn.180142a00();
        uVar35 = (uint64_t)(uint32_t)var_2b4h;
    }
    uVar21 = (uint32_t)var_298h;
    if ((((arg1_00 != 0) && (*(int32_t *)(arg1_00 + 0x14) == (int32_t)uVar35)) &&
        (*(uint32_t *)(arg1_00 + 0x10) = var_298h._4_4_, uStack_250 != 0)) && (*(float *)(arg1_00 + 0x68) != fVar55)) {
        *(undefined *)(arg1_00 + 0x71) = 1;
        *(float *)(arg1_00 + 0x68) = fVar55;
        var_2b7h = '\x01';
    }
    if (*(int32_t *)(iVar26 + 0x1654) == (int32_t)uVar35) {
        *(undefined *)(arg1_00 + 0x74) = 0;
        *(float *)(arg1_00 + 0x58) = fStack_278;
        *(float *)(arg1_00 + 0x68) = fVar55;
        *(bool *)(iVar26 + 0x1661) = *(char *)(iVar26 + 0x120) == '\0';
        if ((uint32_t)var_298h == 0) {
            fVar58 = *(float *)(iVar26 + 0x12f8) * 0.5;
        } else {
            fVar58 = *(float *)(iVar26 + 0x11c) - *(float *)(iVar28 + 0x15c);
        }
        if (cVar19 != '\0') {
            *(undefined4 *)(*(int64_t *)(arg1_00 + 8) + 4) = 0;
            *(undefined4 *)(*(int64_t *)(arg1_00 + 8) + 8) = *(undefined4 *)(arg1_00 + 0x18);
            **(undefined4 **)(arg1_00 + 8) = (*(undefined4 **)(arg1_00 + 8))[2];
            *(undefined *)(*(int64_t *)(arg1_00 + 8) + 0x16) = 0;
            *(undefined *)(arg1_00 + 0x72) = 1;
            goto code_r0x000180144278;
        }
        fVar51 = ((*(float *)(iVar26 + 0x118) - fVar62) - *(float *)(iVar26 + 0xddc)) + *(float *)(arg1_00 + 0x5c);
        if ((((char)(uint32_t)var_2ach == '\0') || (*(uint16_t *)(iVar26 + 0xb5a) < 2)) ||
           (*(char *)(iVar26 + 0x139) != '\0')) {
            if ((*(char *)(iVar26 + 0xb50) == '\0') || (*(char *)(arg1_00 + 0x72) != '\0')) {
                if (((*(char *)(iVar26 + 0x120) != '\0') && (*(char *)(arg1_00 + 0x72) == '\0')) &&
                   ((*(float *)(iVar26 + 0x104) != 0.0 || (*(float *)(iVar26 + 0x108) != 0.0)))) {
                    func_0x000180140da0(arg1_00, *(undefined8 *)(arg1_00 + 8), fVar51, fVar58);
                    *(undefined *)(arg1_00 + 0x70) = 1;
                    goto code_r0x000180144270;
                }
            } else if ((char)(uint32_t)var_2ach != '\0') {
                if (*(char *)(iVar26 + 0x139) == '\0') {
                    func_0x000180140d30(arg1_00);
                } else {
                    func_0x000180140da0(arg1_00, *(undefined8 *)(arg1_00 + 8), fVar51, fVar58);
                }
                goto code_r0x000180144270;
            }
        } else {
            func_0x000180140d30(arg1_00, *(undefined8 *)(arg1_00 + 8));
            piVar47 = *(int32_t **)(arg1_00 + 8);
            iVar33 = *piVar47;
            if ((*(uint8_t *)(iVar26 + 0xb5a) & 1) == 0) {
                if ((iVar33 == 0) || (*(char *)(*(int64_t *)(arg1_00 + 0x20) + -1 + (int64_t)iVar33) == '\n')) {
                    bVar5 = true;
                } else {
                    bVar5 = false;
                }
                if ((piVar47[1] != piVar47[2]) || (!bVar5)) {
                    fcn.180142850(arg1_00, 0x20000c);
                }
                puVar3 = *(undefined4 **)(arg1_00 + 8);
                if (puVar3[1] == puVar3[2]) {
                    puVar3[2] = *puVar3;
                    puVar3[1] = *puVar3;
                }
                uVar48 = func_0x000180140550(arg1_00, **(undefined4 **)(arg1_00 + 8));
                **(undefined4 **)(arg1_00 + 8) = uVar48;
                (*(undefined4 **)(arg1_00 + 8))[2] = **(undefined4 **)(arg1_00 + 8);
                piVar47 = *(int32_t **)(arg1_00 + 8);
                iVar33 = *(int32_t *)(arg1_00 + 0x18);
                iVar23 = piVar47[2];
                iVar40 = piVar47[1];
                if (iVar40 != iVar23) {
                    if (iVar33 < iVar40) {
                        piVar47[1] = iVar33;
                        iVar40 = iVar33;
                    }
                    if (iVar33 < iVar23) {
                        piVar47[2] = iVar33;
                        iVar23 = iVar33;
                    }
                    if (iVar40 == iVar23) {
                        *piVar47 = iVar40;
                    }
                }
                if (iVar33 < *piVar47) {
                    *piVar47 = iVar33;
                }
            } else {
                cVar19 = *(char *)((int64_t)iVar33 + *(int64_t *)(arg1_00 + 0x20));
                *(undefined4 *)(arg1_00 + 0x68) = 0;
                fcn.180142850(arg1_00, 0x200004);
                fcn.180142850(arg1_00, 0x600005);
                fcn.180142850(arg1_00, 0x600001);
                *(float *)(arg1_00 + 0x68) = fVar55;
                if ((cVar19 != '\n') && (uVar21 != 0)) {
                    iVar28 = *(int64_t *)(arg1_00 + 8);
                    uVar48 = *(undefined4 *)(iVar28 + 4);
                    *(undefined4 *)(iVar28 + 4) = *(undefined4 *)(iVar28 + 8);
                    *(undefined4 *)(iVar28 + 8) = uVar48;
                    **(undefined4 **)(arg1_00 + 8) = (*(undefined4 **)(arg1_00 + 8))[2];
                }
                *(undefined *)(arg1_00 + 0x70) = 0;
            }
code_r0x000180144270:
            *(undefined4 *)(arg1_00 + 0x6c) = 0xbe99999a;
        }
code_r0x000180144278:
        if ((*(char *)(arg1_00 + 0x72) != '\0') && (*(char *)(iVar26 + 0x120) == '\0')) {
            *(char *)(arg1_00 + 0x72) = '\0';
        }
        ppiVar29 = uStack_260;
        piVar47 = (int32_t *)uStack_270;
        if ((((var_298h._4_4_ & 0x20) != 0) && (var_2ach._4_4_ == 0)) &&
           (cVar19 = func_0x000180109d80(0x200), ppiVar29 = uStack_260, piVar47 = (int32_t *)uStack_270, cVar19 != '\0')
           ) {
            var_2ach._0_4_ = 9;
            var_2e0h = var_2e0h & 0xffffffffffffff00;
            var_2e8h = (int64_t)uStack_270;
            cVar19 = fcn.180142bf0(iVar26, arg1_00, (int64_t)&var_2ach, uStack_260, (int64_t)uStack_270, var_2e0h);
            if (cVar19 != '\0') {
                fcn.1801428d0(arg1_00, (uint64_t)(uint32_t)var_2ach);
            }
        }
        if (((*(char *)(iVar26 + 0x138) == '\0') || (*(char *)(iVar26 + 0x13a) != '\0')) &&
           ((cVar17 == '\0' || (*(char *)(iVar26 + 0x138) == '\0')))) {
            bVar5 = false;
        } else {
            bVar5 = true;
        }
        if (0 < *(int32_t *)(iVar26 + 0xc18)) {
            if (((!bVar5) && (var_2ach._4_4_ == 0)) && (cVar20 == '\0')) {
                iVar33 = 0;
                do {
                    var_2ach._0_4_ = (uint32_t)*(uint16_t *)(*(int64_t *)(iVar26 + 0xc20) + (int64_t)iVar33 * 2);
                    if ((uint32_t)var_2ach != 9) {
                        var_2e0h = var_2e0h & 0xffffffffffffff00;
                        var_2e8h = (int64_t)piVar47;
                        cVar20 = fcn.180142bf0(iVar26, arg1_00, (int64_t)&var_2ach, ppiVar29, (int64_t)piVar47, var_2e0h
                                              );
                        if (cVar20 != '\0') {
                            fcn.1801428d0(arg1_00, (uint64_t)(uint32_t)var_2ach);
                        }
                    }
                    iVar33 = iVar33 + 1;
                } while (iVar33 < *(int32_t *)(iVar26 + 0xc18));
            }
            if (*(int32_t *)(iVar26 + 0xc1c) < 0) {
                func_0x00018011f8d0(iVar26 + 0xc18);
            }
            *(undefined4 *)(iVar26 + 0xc18) = 0;
        }
        uVar35 = (uint64_t)(uint32_t)var_2b4h;
    }
    bVar5 = false;
    cVar20 = var_2b6h;
    if (((*(int32_t *)(iVar26 + 0x1654) == (int32_t)uVar35) && (*(char *)(iVar26 + 0x1660) == '\0')) &&
       (var_2b6h == '\0')) {
        uVar34 = var_298h._4_4_ & 0x10000;
        uVar21 = (uint32_t)((fVar50 - *(float *)(iVar26 + 0xde0)) / *(float *)(iVar26 + 0x12f8));
        var_2ach._0_4_ = 1;
        if (0 < (int32_t)uVar21) {
            var_2ach._0_4_ = uVar21;
        }
        *(uint32_t *)(*(int64_t *)(arg1_00 + 8) + 0x10) = (uint32_t)var_2ach;
        uVar21 = -(uint32_t)(*(char *)(iVar26 + 0x139) != '\0') & 0x400000;
        if (cVar17 == '\0') {
            var_2b4h._7_1_ = *(char *)(iVar26 + 0x138);
code_r0x00018014449d:
            var_2b4h._6_1_ = 0;
        } else {
            var_2b4h._4_1_ = 0;
            var_2b4h._5_1_ = '\0';
            var_2b4h._7_1_ = *(char *)(iVar26 + 0x13a);
            if (((*(char *)(iVar26 + 0x138) == '\0') || (*(char *)(iVar26 + 0x13b) != '\0')) || (var_2b4h._7_1_ != '\0')
               ) {
                var_2b4h._5_1_ = '\0';
                var_2b4h._4_1_ = 0;
                goto code_r0x00018014449d;
            }
            var_2b4h._6_1_ = 1;
        }
        cVar17 = func_0x000180109d80(0x1239, 1, uVar35 & 0xffffffff);
        uVar22 = (uint32_t)var_2b4h;
        if (((cVar17 == '\0') && (cVar17 = func_0x000180109d80(0x220a, 1, (uint32_t)var_2b4h), cVar17 == '\0')) ||
           (((var_2ach._4_4_ != 0 || (uStack_230 != 0)) ||
            (((uint32_t)var_298h != 0 &&
             (*(int32_t *)(*(int64_t *)(arg1_00 + 8) + 4) == *(int32_t *)(*(int64_t *)(arg1_00 + 8) + 8))))))) {
            var_28fh = '\0';
        } else {
            var_28fh = '\x01';
        }
        uVar14 = (uint32_t)var_298h;
        uVar43 = var_2ach._4_4_;
        cVar17 = func_0x000180109d80(0x1224, 0, uVar22);
        if ((((cVar17 == '\0') && (cVar17 = func_0x000180109d80(0x1209, 0, uVar22), cVar17 == '\0')) ||
            (uStack_230 != 0)) ||
           ((uVar14 != 0 && (*(int32_t *)(*(int64_t *)(arg1_00 + 8) + 4) == *(int32_t *)(*(int64_t *)(arg1_00 + 8) + 8))
            ))) {
            cStack_265 = '\0';
        } else {
            cStack_265 = '\x01';
        }
        bVar5 = true;
        cVar17 = func_0x000180109d80(0x1237, 1, uVar22);
        if (((cVar17 == '\0') && (cVar17 = func_0x000180109d80(0x2209, 1, uVar22), cVar17 == '\0')) ||
           (cStack_264 = '\x01', uVar43 != 0)) {
            cStack_264 = '\0';
        }
        cVar17 = func_0x000180109d80(0x123b, 1, uVar22);
        if (((cVar17 == '\0') || (uVar43 != 0)) || (uStack_267 = 1, uVar34 != 0)) {
            uStack_267 = 0;
        }
        cVar17 = func_0x000180109d80(0x123a, 1, uVar22);
        if (((cVar17 == '\0') && (cVar17 = func_0x000180109d80(0x323b, 1, uVar22), cVar17 == '\0')) ||
           ((uVar43 != 0 || (cStack_266 = '\x01', uVar34 != 0)))) {
            cStack_266 = '\0';
        }
        var_28eh = func_0x000180109d80(0x1222, 0, uVar22);
        if (((*(uint8_t *)(iVar26 + 0x30) & 2) == 0) || ((*(uint8_t *)(iVar26 + 0x34) & 1) == 0)) {
            bVar5 = false;
        }
        cVar17 = func_0x000180109d80(0x20d, 1, uVar22);
        if (cVar17 == '\0') {
            cVar17 = func_0x000180109d80(0x273, 1, uVar22);
            cStack_268 = '\0';
            if (cVar17 != '\0') goto code_r0x000180144637;
        } else {
code_r0x000180144637:
            cStack_268 = '\x01';
        }
        cVar17 = func_0x000180109d80(0x120d, 1, uVar22);
        if ((cVar17 == '\0') && (cVar17 = func_0x000180109d80(0x1273, 1, uVar22), cVar17 == '\0')) {
            bVar6 = false;
        } else {
            bVar6 = true;
        }
        cVar17 = func_0x000180109d80(0x220d, 1, uVar22);
        if ((cVar17 == '\0') && (cVar17 = func_0x000180109d80(0x2273, 1, uVar22), cVar17 == '\0')) {
            bVar7 = false;
        } else {
            bVar7 = true;
        }
        if (bVar5) {
            uVar32 = 0x27d;
            if (*(char *)(iVar26 + 0x79) != '\0') {
                uVar32 = 0x27b;
            }
            cVar17 = func_0x000180107dc0(uVar32, 0, 0);
            if (cVar17 == '\0') goto code_r0x0001801446c2;
            bVar8 = true;
        } else {
code_r0x0001801446c2:
            bVar8 = false;
        }
        cVar17 = func_0x000180109d80(0x20e, 1);
        if (cVar17 == '\0') {
            if (bVar5) {
                uVar32 = 0x27b;
                if (*(char *)(var_2a0h + 0x79) != '\0') {
                    uVar32 = 0x27d;
                }
                cVar17 = func_0x000180109d80(uVar32, 1);
                if (cVar17 != '\0') goto code_r0x000180144713;
            }
            bVar5 = false;
        } else {
code_r0x000180144713:
            bVar5 = true;
        }
        cVar17 = func_0x000180107dc0(0x201, 1);
        if (cVar17 == '\0') {
            cVar17 = func_0x000180107dc0(0x202, 1);
            if (cVar17 != '\0') {
                if (var_2b4h._6_1_ == 0) {
                    uVar34 = 0x200001;
                    if (var_2b4h._7_1_ != '\0') {
                        uVar34 = 0x20000d;
                    }
                    fcn.180142850(arg1_00, (uint64_t)(uVar34 | uVar21));
                    iVar26 = var_2a0h;
                    cVar20 = var_2b6h;
                } else {
                    fcn.180142850(arg1_00, (uint64_t)(uVar21 | 0x200005));
                    iVar26 = var_2a0h;
                    cVar20 = var_2b6h;
                }
                goto code_r0x000180144841;
            }
            cVar17 = func_0x000180107dc0(0x203);
            uVar34 = (uint32_t)var_298h;
            if ((cVar17 != '\0') && ((uint32_t)var_298h != 0)) {
                if (*(char *)(var_2a0h + 0x138) != '\0') {
                    fVar58 = *(float *)(iStack_248 + 0xd8) - *(float *)(var_2a0h + 0x12f8);
                    if (fVar58 <= 0.0) {
                        fVar58 = 0.0;
                    }
                    *(float *)(iStack_248 + 0xe8) = fVar58;
                    *(undefined4 *)(iStack_248 + 0xf0) = 0;
                    *(undefined4 *)(iStack_248 + 0xf8) = 0;
                    iVar26 = var_2a0h;
                    cVar20 = var_2b6h;
                    goto code_r0x000180144841;
                }
                uVar34 = (uint32_t)var_2b4h._6_1_ * 4 + 0x200002;
code_r0x00018014482c:
                uVar35 = (uint64_t)(uVar34 | uVar21);
                iVar26 = var_2a0h;
code_r0x00018014482e:
                fcn.180142850(arg1_00, uVar35);
                cVar20 = var_2b6h;
                goto code_r0x000180144841;
            }
            cVar17 = func_0x000180107dc0(0x204, 1);
            if ((cVar17 != '\0') && (uVar34 != 0)) {
                if (*(char *)(var_2a0h + 0x138) == '\0') {
                    uVar34 = (uint32_t)var_2b4h._6_1_ * 4 + 0x200003;
                    goto code_r0x00018014482c;
                }
                fVar55 = *(float *)(var_2a0h + 0x12f8) + *(float *)(iStack_248 + 0xd8);
                fVar58 = *(float *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0xe0);
                if (fVar58 <= fVar55) {
                    fVar55 = fVar58;
                }
                *(float *)(iStack_248 + 0xe8) = fVar55;
                *(undefined4 *)(iStack_248 + 0xf0) = 0;
                *(undefined4 *)(iStack_248 + 0xf8) = 0;
                iVar26 = var_2a0h;
                cVar20 = var_2b6h;
                goto code_r0x000180144841;
            }
            cVar17 = func_0x000180107dc0(0x205, 1);
            if ((cVar17 != '\0') && (uVar34 != 0)) {
                fcn.180142850(arg1_00, (uint64_t)(uVar21 | 0x20000e));
                fStack_22c = fVar49 - (float)(uint32_t)var_2ach * *(float *)(var_2a0h + 0x12f8);
                iVar26 = var_2a0h;
                cVar20 = var_2b6h;
                goto code_r0x000180144841;
            }
            cVar17 = func_0x000180107dc0(0x206, 1);
            if ((cVar17 != '\0') && (uVar34 != 0)) {
                fcn.180142850(arg1_00, (uint64_t)(uVar21 | 0x20000f));
                fStack_22c = fVar49 + (float)(uint32_t)var_2ach * *(float *)(var_2a0h + 0x12f8);
                iVar26 = var_2a0h;
                cVar20 = var_2b6h;
                goto code_r0x000180144841;
            }
            cVar17 = func_0x000180107dc0(0x207, 1);
            if (cVar17 != '\0') {
                uVar34 = uVar21 | 0x200006;
                uVar21 = uVar21 | 0x200004;
code_r0x0001801449b4:
                if (*(char *)(var_2a0h + 0x138) != '\0') {
                    uVar21 = uVar34;
                }
                uVar35 = (uint64_t)uVar21;
                iVar26 = var_2a0h;
                goto code_r0x00018014482e;
            }
            cVar17 = func_0x000180107dc0(0x208, 1);
            if (cVar17 != '\0') {
                uVar34 = uVar21 | 0x200007;
                uVar21 = uVar21 | 0x200005;
                goto code_r0x0001801449b4;
            }
            cVar17 = func_0x000180107dc0(0x20a, 1);
            if (((cVar17 != '\0') && (var_2ach._4_4_ == 0)) && (var_28fh == '\0')) {
                if ((*(int32_t *)(*(int64_t *)(arg1_00 + 8) + 4) == *(int32_t *)(*(int64_t *)(arg1_00 + 8) + 8)) &&
                   (var_2b4h._7_1_ != '\0')) {
                    fcn.180142850(arg1_00, 0x60000d);
                }
                fcn.180142850(arg1_00, (uint64_t)(uVar21 | 0x200008));
                iVar26 = var_2a0h;
                cVar20 = var_2b6h;
                goto code_r0x000180144841;
            }
            cVar20 = func_0x000180107dc0(0x20b, 1);
            cVar17 = var_28fh;
            iVar26 = var_2a0h;
            if ((cVar20 != '\0') && (var_2ach._4_4_ == 0)) {
                if (*(int32_t *)(*(int64_t *)(arg1_00 + 8) + 4) == *(int32_t *)(*(int64_t *)(arg1_00 + 8) + 8)) {
                    if (var_2b4h._7_1_ == (char)var_2ach._4_4_) {
                        if ((((var_290h != '\0') && (*(char *)(var_2a0h + 0x138) != '\0')) &&
                            (*(char *)(var_2a0h + 0x13a) == '\0')) && (*(char *)(var_2a0h + 0x13b) == '\0')) {
                            fcn.180142850(arg1_00, 0x600004);
                            uVar35 = (uint64_t)(uVar21 | 0x200009);
                            goto code_r0x00018014482e;
                        }
                    } else {
                        fcn.180142850(arg1_00, 0x60000c);
                    }
                }
                uVar35 = (uint64_t)(uVar21 | 0x200009);
                iVar26 = var_2a0h;
                goto code_r0x00018014482e;
            }
            cVar20 = var_2b6h;
            if (((cStack_268 != '\0') || (bVar6)) || ((bVar7 || (bVar8)))) {
                if (((uVar34 == 0) || (bVar8)) ||
                   ((!bVar7 &&
                    (((cStack_268 == '\0' || ((var_298h._4_4_ & 0x100) != 0)) &&
                     ((!bVar6 || ((var_298h._4_4_ & 0x100) == 0)))))))) {
                    var_2b4h._4_1_ = 1;
                    cVar20 = '\x01';
                    if ((*(char *)(var_2a0h + 0x90) != '\0') && (uVar34 == 0)) {
                        *(undefined4 *)(*(int64_t *)(arg1_00 + 8) + 4) = 0;
                        *(undefined4 *)(*(int64_t *)(arg1_00 + 8) + 8) = *(undefined4 *)(arg1_00 + 0x18);
                        **(undefined4 **)(arg1_00 + 8) = (*(undefined4 **)(arg1_00 + 8))[2];
                        *(undefined *)(*(int64_t *)(arg1_00 + 8) + 0x16) = 0;
                        *(uint32_t *)(var_2a0h + 0x277c) = (uint32_t)var_2b4h;
                        cVar20 = '\x01';
                    }
                } else if (var_2ach._4_4_ == 0) {
                    var_2ach._0_4_ = 10;
                    var_2e0h = CONCAT71(var_2e0h._1_7_, (char)var_2ach._4_4_);
                    var_2e8h = (int64_t)uStack_270;
                    cVar17 = fcn.180142bf0(var_2a0h, arg1_00, (int64_t)&var_2ach, uStack_260, (int64_t)uStack_270, 
                                           var_2e0h);
                    cVar20 = var_2b6h;
                    if (cVar17 != '\0') {
                        fcn.1801428d0(arg1_00, (uint64_t)(uint32_t)var_2ach);
                        cVar20 = var_2b6h;
                    }
                }
                goto code_r0x000180144841;
            }
            if (!bVar5) {
                if ((uStack_267 == 0) && (cStack_266 == '\0')) {
                    if (var_28eh == '\0') {
                        if ((var_28fh == '\0') && (cStack_265 == '\0')) {
                            if ((cStack_264 != '\0') && (*(code **)(*(int64_t *)0x180781f28 + 0xc48) != (code *)0x0)) {
                                pcVar24 = (char *)(**(code **)(*(int64_t *)0x180781f28 + 0xc48))();
                                iVar26 = var_2a0h;
                                cVar20 = var_2b6h;
                                if (pcVar24 != (char *)0x0) {
                                    iVar33 = func_0x000180498cd0(pcVar24);
                                    pcVar45 = pcVar24 + iVar33;
                                    uStack_240 = (int32_t *)0x0;
                                    uVar35 = 0;
                                    iStack_238 = 0;
                                    iVar33 = iVar33 + 1;
                                    if (0 < iVar33) {
                                        iStack_238 = func_0x00018046d050((int64_t)iVar33);
                                        uStack_240 = (int32_t *)CONCAT44(iVar33, (int32_t)uStack_240);
                                    }
                                    piVar47 = (int32_t *)uStack_270;
                                    iVar28 = iStack_238;
                                    iVar26 = iStack_238;
                                    if (*pcVar24 != '\0') {
                                        do {
                                            iVar33 = func_0x0001800f5c80(&var_2ach, pcVar24, pcVar45);
                                            pcVar24 = pcVar24 + iVar33;
                                            var_2e0h = CONCAT71(var_2e0h._1_7_, 1);
                                            var_2e8h = (int64_t)piVar47;
                                            cVar17 = fcn.180142bf0(var_2a0h, arg1_00, (int64_t)&var_2ach, uStack_260, 
                                                                   (int64_t)piVar47, var_2e0h);
                                            if (cVar17 != '\0') {
                                                iVar33 = func_0x0001800f5e10(&uStack_e8);
                                                *(undefined *)((int64_t)&uStack_e8 + (int64_t)iVar33) = 0;
                                                iVar33 = func_0x000180498cd0(&uStack_e8);
                                                func_0x00018011f640(&uStack_240, (int32_t)uVar35 + iVar33);
                                                iVar26 = iStack_238;
                                                uVar35 = (uint64_t)(int32_t)uStack_240;
                                                func_0x000180498030((uVar35 - (int64_t)iVar33) + iStack_238);
                                            }
                                        } while (*pcVar24 != '\0');
                                        iVar33 = (int32_t)uVar35;
                                        iVar28 = iVar26;
                                        if (0 < iVar33) {
                                            if (iVar33 == uStack_240._4_4_) {
                                                if (uStack_240._4_4_ == 0) {
                                                    uVar21 = 8;
                                                } else {
                                                    uVar21 = uStack_240._4_4_ / 2 + uStack_240._4_4_;
                                                }
                                                uVar34 = iVar33 + 1U;
                                                if ((int32_t)(iVar33 + 1U) < (int32_t)uVar21) {
                                                    uVar34 = uVar21;
                                                }
                                                if (uStack_240._4_4_ < (int32_t)uVar34) {
                                                    iVar28 = func_0x00018046d050((int64_t)(int32_t)uVar34);
                                                    if (iVar26 != 0) {
                                                        func_0x000180498030(iVar28, iVar26, (int64_t)iVar33);
                                                        func_0x000180460d90(iVar26);
                                                    }
                                                    uStack_240 = (int32_t *)((uint64_t)uVar34 << 0x20);
                                                    iStack_238 = iVar28;
                                                }
                                            }
                                            *(undefined *)(iVar33 + iVar28) = 0;
                                            uStack_240 = (int32_t *)CONCAT44(uStack_240._4_4_, iVar33 + 1);
                                            piVar47 = *(int32_t **)(arg1_00 + 8);
                                            iVar33 = *(int32_t *)(arg1_00 + 0x18);
                                            iVar23 = piVar47[2];
                                            iVar40 = piVar47[1];
                                            if (iVar40 != iVar23) {
                                                if (iVar33 < iVar40) {
                                                    piVar47[1] = iVar33;
                                                    iVar40 = iVar33;
                                                }
                                                if (iVar33 < iVar23) {
                                                    piVar47[2] = iVar33;
                                                    iVar23 = iVar33;
                                                }
                                                if (iVar40 == iVar23) {
                                                    *piVar47 = iVar40;
                                                }
                                            }
                                            iVar39 = *piVar47;
                                            if (iVar33 < iVar39) {
                                                *piVar47 = iVar33;
                                                iVar39 = iVar33;
                                            }
                                            iVar33 = *(int32_t *)(arg1_00 + 0x18);
                                            if (iVar40 != iVar23) {
                                                if (iVar33 < iVar40) {
                                                    piVar47[1] = iVar33;
                                                    iVar40 = iVar33;
                                                }
                                                if (iVar33 < iVar23) {
                                                    piVar47[2] = iVar33;
                                                    iVar23 = iVar33;
                                                }
                                                if (iVar40 == iVar23) {
                                                    *piVar47 = iVar40;
                                                    iVar39 = iVar40;
                                                }
                                            }
                                            if (iVar33 < iVar39) {
                                                *piVar47 = iVar33;
                                            }
                                            if (iVar40 != iVar23) {
                                                if (iVar40 < iVar23) {
                                                    uVar21 = iVar23 - iVar40;
                                                    piVar25 = (int64_t *)
                                                              func_0x000180142130(piVar47 + 8, iVar40, uVar21, 0);
                                                    if ((piVar25 != (int64_t *)0x0) && (0 < (int32_t)uVar21)) {
                                                        iVar23 = 0;
                                                        iVar33 = iVar23;
                                                        if (0xf < uVar21) {
                                                            piVar1 = (int64_t *)(arg1_00 + 0x20);
                                                            piVar42 = (int64_t *)
                                                                      ((int64_t)(int32_t)(uVar21 - 1) + (int64_t)piVar25
                                                                      );
                                                            if ((((int64_t *)
                                                                  ((int64_t)(int32_t)(iVar40 + (uVar21 - 1)) + *piVar1)
                                                                  < piVar25) ||
                                                                (piVar42 < (int64_t *)((int64_t)iVar40 + *piVar1))) &&
                                                               ((piVar1 < piVar25 || (iVar33 = 0, piVar42 < piVar1)))) {
                                                                func_0x000180498030(piVar25, (int64_t *)
                                                                                             ((int64_t)iVar40 + *piVar1)
                                                                                    , (int64_t)(int32_t)uVar21);
                                                                do {
                                                                    iVar23 = iVar23 + 1;
                                                                } while (iVar23 < (int32_t)uVar21);
                                                                goto code_r0x000180144e5b;
                                                            }
                                                        }
                                                        do {
                                                            *(undefined *)((int64_t)iVar33 + (int64_t)piVar25) =
                                                                 *(undefined *)
                                                                  ((int64_t)(iVar40 + iVar33) +
                                                                  *(int64_t *)(arg1_00 + 0x20));
                                                            iVar33 = iVar33 + 1;
                                                        } while (iVar33 < (int32_t)uVar21);
                                                    }
code_r0x000180144e5b:
                                                    iVar26 = (int64_t)iVar40 + *(int64_t *)(arg1_00 + 0x30);
                                                    func_0x000180498030(iVar26, (int32_t)uVar21 + iVar26, 
                                                                        (int64_t)(int32_t)(((*(int32_t *)
                                                                                              (arg1_00 + 0x18) - iVar40)
                                                                                           - uVar21) + 1));
                                                    *(undefined2 *)(arg1_00 + 0x73) = 0x101;
                                                    *(int32_t *)(arg1_00 + 0x18) = *(int32_t *)(arg1_00 + 0x18) - uVar21
                                                    ;
                                                    iVar33 = piVar47[1];
                                                    piVar47[2] = iVar33;
                                                } else {
                                                    uVar21 = iVar40 - iVar23;
                                                    piVar25 = (int64_t *)
                                                              func_0x000180142130(piVar47 + 8, iVar23, uVar21, 0);
                                                    if ((piVar25 != (int64_t *)0x0) && (0 < (int32_t)uVar21)) {
                                                        iVar40 = 0;
                                                        iVar33 = iVar40;
                                                        if (0xf < uVar21) {
                                                            piVar1 = (int64_t *)(arg1_00 + 0x20);
                                                            piVar42 = (int64_t *)
                                                                      ((int64_t)(int32_t)(uVar21 - 1) + (int64_t)piVar25
                                                                      );
                                                            if ((((int64_t *)
                                                                  ((int64_t)(int32_t)(iVar23 + (uVar21 - 1)) + *piVar1)
                                                                  < piVar25) ||
                                                                (piVar42 < (int64_t *)((int64_t)iVar23 + *piVar1))) &&
                                                               ((piVar1 < piVar25 || (iVar33 = 0, piVar42 < piVar1)))) {
                                                                func_0x000180498030(piVar25, (int64_t *)
                                                                                             ((int64_t)iVar23 + *piVar1)
                                                                                    , (int64_t)(int32_t)uVar21);
                                                                do {
                                                                    iVar40 = iVar40 + 1;
                                                                } while (iVar40 < (int32_t)uVar21);
                                                                goto code_r0x000180144f1b;
                                                            }
                                                        }
                                                        do {
                                                            *(undefined *)((int64_t)iVar33 + (int64_t)piVar25) =
                                                                 *(undefined *)
                                                                  ((int64_t)(iVar23 + iVar33) +
                                                                  *(int64_t *)(arg1_00 + 0x20));
                                                            iVar33 = iVar33 + 1;
                                                        } while (iVar33 < (int32_t)uVar21);
                                                    }
code_r0x000180144f1b:
                                                    iVar26 = (int64_t)iVar23 + *(int64_t *)(arg1_00 + 0x30);
                                                    func_0x000180498030(iVar26, (int32_t)uVar21 + iVar26, 
                                                                        (int64_t)(int32_t)(((*(int32_t *)
                                                                                              (arg1_00 + 0x18) - iVar23)
                                                                                           - uVar21) + 1));
                                                    *(undefined2 *)(arg1_00 + 0x73) = 0x101;
                                                    *(int32_t *)(arg1_00 + 0x18) = *(int32_t *)(arg1_00 + 0x18) - uVar21
                                                    ;
                                                    iVar33 = piVar47[2];
                                                    piVar47[1] = iVar33;
                                                }
                                                *piVar47 = iVar33;
                                                *(undefined *)((int64_t)piVar47 + 0x16) = 0;
                                            }
                                            iVar33 = fcn.180140a70(arg1_00, *piVar47, iVar28, uVar35 & 0xffffffff);
                                            if (iVar33 != 0) {
                                                func_0x000180142130(piVar47 + 8, *piVar47, 0, iVar33);
                                                *piVar47 = *piVar47 + iVar33;
                                                *(undefined *)((int64_t)piVar47 + 0x16) = 0;
                                            }
                                            *(undefined *)(arg1_00 + 0x70) = 1;
                                        }
                                    }
                                    iVar26 = var_2a0h;
                                    cVar20 = var_2b6h;
                                    if (iVar28 != 0) {
                                        func_0x000180460d90(iVar28);
                                        iVar26 = var_2a0h;
                                        cVar20 = var_2b6h;
                                    }
                                }
                            }
                        } else {
                            if (*(int64_t *)(var_2a0h + 0xc50) != 0) {
                                iVar33 = *(int32_t *)(*(int64_t *)(arg1_00 + 8) + 8);
                                iVar23 = *(int32_t *)(*(int64_t *)(arg1_00 + 8) + 4);
                                if (iVar23 == iVar33) {
                                    iVar40 = *(int32_t *)(arg1_00 + 0x18);
                                    iVar33 = 0;
                                } else {
                                    iVar40 = iVar23;
                                    if (iVar23 < iVar33) {
                                        iVar40 = iVar33;
                                        iVar33 = iVar23;
                                    }
                                }
                                iVar40 = iVar40 - iVar33;
                                func_0x00018011f800(var_2a0h + 0x2c90, iVar40 + 1);
                                func_0x000180498030(*(undefined8 *)(iVar26 + 0x2c98), 
                                                    (int64_t)iVar33 + *(int64_t *)(arg1_00 + 0x20), (int64_t)iVar40);
                                *(undefined *)((int64_t)iVar40 + *(int64_t *)(iVar26 + 0x2c98)) = 0;
                                if (*(code **)(*(int64_t *)0x180781f28 + 0xc50) != (code *)0x0) {
                                    (**(code **)(*(int64_t *)0x180781f28 + 0xc50))();
                                }
                            }
                            cVar20 = var_2b6h;
                            if (cVar17 != '\0') {
                                iVar26 = *(int64_t *)(arg1_00 + 8);
                                if (*(int32_t *)(iVar26 + 4) == *(int32_t *)(iVar26 + 8)) {
                                    *(undefined4 *)(iVar26 + 4) = 0;
                                    *(undefined4 *)(*(int64_t *)(arg1_00 + 8) + 8) = *(undefined4 *)(arg1_00 + 0x18);
                                    **(undefined4 **)(arg1_00 + 8) = (*(undefined4 **)(arg1_00 + 8))[2];
                                    *(undefined *)(*(int64_t *)(arg1_00 + 8) + 0x16) = 0;
                                }
                                *(undefined *)(arg1_00 + 0x70) = 1;
                                piVar47 = *(int32_t **)(arg1_00 + 8);
                                iVar23 = piVar47[2];
                                iVar33 = piVar47[1];
                                iVar26 = var_2a0h;
                                if (iVar33 != iVar23) {
                                    iVar40 = *(int32_t *)(arg1_00 + 0x18);
                                    if (iVar40 < iVar33) {
                                        piVar47[1] = iVar40;
                                        iVar33 = iVar40;
                                    }
                                    if (iVar40 < iVar23) {
                                        piVar47[2] = iVar40;
                                        iVar23 = iVar40;
                                    }
                                    if (iVar33 == iVar23) {
                                        *piVar47 = iVar33;
                                    }
                                    if (iVar40 < *piVar47) {
                                        *piVar47 = iVar40;
                                    }
                                    if (iVar33 != iVar23) {
                                        if (iVar33 < iVar23) {
                                            uVar21 = iVar23 - iVar33;
                                            piVar25 = (int64_t *)func_0x000180142130(piVar47 + 8, iVar33, uVar21, 0);
                                            if ((piVar25 != (int64_t *)0x0) && (0 < (int32_t)uVar21)) {
                                                iVar40 = 0;
                                                iVar23 = iVar40;
                                                if (0xf < uVar21) {
                                                    piVar1 = (int64_t *)(arg1_00 + 0x20);
                                                    piVar42 = (int64_t *)
                                                              ((int64_t)(int32_t)(uVar21 - 1) + (int64_t)piVar25);
                                                    if ((((int64_t *)
                                                          ((int64_t)(int32_t)(iVar33 + (uVar21 - 1)) + *piVar1) <
                                                          piVar25) || (piVar42 < (int64_t *)((int64_t)iVar33 + *piVar1))
                                                        ) && ((piVar1 < piVar25 || (iVar23 = 0, piVar42 < piVar1)))) {
                                                        func_0x000180498030(piVar25, (int64_t *)
                                                                                     ((int64_t)iVar33 + *piVar1), 
                                                                            (int64_t)(int32_t)uVar21);
                                                        do {
                                                            iVar40 = iVar40 + 1;
                                                        } while (iVar40 < (int32_t)uVar21);
                                                        goto code_r0x00018014513b;
                                                    }
                                                }
                                                do {
                                                    *(undefined *)((int64_t)iVar23 + (int64_t)piVar25) =
                                                         *(undefined *)
                                                          ((int64_t)(iVar33 + iVar23) + *(int64_t *)(arg1_00 + 0x20));
                                                    iVar23 = iVar23 + 1;
                                                } while (iVar23 < (int32_t)uVar21);
                                            }
code_r0x00018014513b:
                                            iVar26 = (int64_t)iVar33 + *(int64_t *)(arg1_00 + 0x30);
                                            func_0x000180498030(iVar26, (int32_t)uVar21 + iVar26, 
                                                                (int64_t)(int32_t)(((*(int32_t *)(arg1_00 + 0x18) -
                                                                                    iVar33) - uVar21) + 1));
                                            *(undefined2 *)(arg1_00 + 0x73) = 0x101;
                                            *(int32_t *)(arg1_00 + 0x18) = *(int32_t *)(arg1_00 + 0x18) - uVar21;
                                            iVar33 = piVar47[1];
                                            piVar47[2] = iVar33;
                                        } else {
                                            uVar21 = iVar33 - iVar23;
                                            piVar25 = (int64_t *)func_0x000180142130(piVar47 + 8, iVar23, uVar21, 0);
                                            if ((piVar25 != (int64_t *)0x0) && (0 < (int32_t)uVar21)) {
                                                iVar40 = 0;
                                                iVar33 = iVar40;
                                                if (0xf < uVar21) {
                                                    piVar1 = (int64_t *)(arg1_00 + 0x20);
                                                    piVar42 = (int64_t *)
                                                              ((int64_t)(int32_t)(uVar21 - 1) + (int64_t)piVar25);
                                                    if ((((int64_t *)
                                                          ((int64_t)(int32_t)(iVar23 + (uVar21 - 1)) + *piVar1) <
                                                          piVar25) || (piVar42 < (int64_t *)((int64_t)iVar23 + *piVar1))
                                                        ) && ((piVar1 < piVar25 || (iVar33 = 0, piVar42 < piVar1)))) {
                                                        func_0x000180498030(piVar25, (int64_t *)
                                                                                     ((int64_t)iVar23 + *piVar1), 
                                                                            (int64_t)(int32_t)uVar21);
                                                        do {
                                                            iVar40 = iVar40 + 1;
                                                        } while (iVar40 < (int32_t)uVar21);
                                                        goto code_r0x0001801451fb;
                                                    }
                                                }
                                                do {
                                                    *(undefined *)((int64_t)iVar33 + (int64_t)piVar25) =
                                                         *(undefined *)
                                                          ((int64_t)(iVar23 + iVar33) + *(int64_t *)(arg1_00 + 0x20));
                                                    iVar33 = iVar33 + 1;
                                                } while (iVar33 < (int32_t)uVar21);
                                            }
code_r0x0001801451fb:
                                            iVar26 = (int64_t)iVar23 + *(int64_t *)(arg1_00 + 0x30);
                                            func_0x000180498030(iVar26, (int32_t)uVar21 + iVar26, 
                                                                (int64_t)(int32_t)(((*(int32_t *)(arg1_00 + 0x18) -
                                                                                    iVar23) - uVar21) + 1));
                                            *(undefined2 *)(arg1_00 + 0x73) = 0x101;
                                            *(int32_t *)(arg1_00 + 0x18) = *(int32_t *)(arg1_00 + 0x18) - uVar21;
                                            iVar33 = piVar47[2];
                                            piVar47[1] = iVar33;
                                        }
                                        *(undefined *)((int64_t)piVar47 + 0x16) = 0;
                                        *piVar47 = iVar33;
                                    }
                                    *(undefined *)((int64_t)piVar47 + 0x16) = 0;
                                    iVar26 = var_2a0h;
                                    cVar20 = var_2b6h;
                                }
                            }
                        }
                    } else {
                        *(undefined4 *)(*(int64_t *)(arg1_00 + 8) + 4) = 0;
                        *(undefined4 *)(*(int64_t *)(arg1_00 + 8) + 8) = *(undefined4 *)(arg1_00 + 0x18);
                        **(undefined4 **)(arg1_00 + 8) = (*(undefined4 **)(arg1_00 + 8))[2];
                        *(undefined *)(*(int64_t *)(arg1_00 + 8) + 0x16) = 0;
                        *(undefined *)(arg1_00 + 0x70) = 1;
                    }
                } else {
                    fcn.180142850(arg1_00, (uint64_t)((uStack_267 ^ 1) + 0x20000a));
                    (*(undefined4 **)(arg1_00 + 8))[2] = **(undefined4 **)(arg1_00 + 8);
                    *(undefined4 *)(*(int64_t *)(arg1_00 + 8) + 4) = *(undefined4 *)(*(int64_t *)(arg1_00 + 8) + 8);
                    iVar26 = var_2a0h;
                    cVar20 = var_2b6h;
                }
                goto code_r0x000180144841;
            }
            uVar35 = (uint64_t)(uint32_t)var_2b4h;
            if ((var_298h._4_4_ & 0x80) == 0) {
                bVar5 = true;
                var_2b8h = 0;
                var_2b7h = '\0';
                cVar20 = '\x01';
            } else if (**(char **)(arg1_00 + 0x30) == '\0') {
                var_2b8h = 0;
                var_2b7h = '\0';
                bVar5 = false;
                cVar20 = '\x01';
            } else {
                bVar5 = true;
            }
        } else {
            if (var_2b4h._6_1_ == 0) {
                uVar34 = 0x200000;
                if (var_2b4h._7_1_ != '\0') {
                    uVar34 = 0x20000c;
                }
            } else {
                uVar34 = 0x200004;
            }
            fcn.180142850(arg1_00, (uint64_t)(uVar34 | uVar21));
            iVar26 = var_2a0h;
            cVar20 = var_2b6h;
code_r0x000180144841:
            uVar35 = (uint64_t)(uint32_t)var_2b4h;
            bVar5 = false;
        }
        if ((*(int32_t *)(*(int64_t *)(arg1_00 + 8) + 4) == *(int32_t *)(*(int64_t *)(arg1_00 + 8) + 8)) ||
           (var_2b7h == '\0')) {
            uVar18 = 0;
        } else {
            uVar18 = 1;
        }
        var_2b8h = var_2b8h | uVar18;
    }
    iVar28 = 0;
    uVar21 = 0;
    puVar41 = puStack_288;
    uVar34 = (uint32_t)uVar35;
    if (*(uint32_t *)(iVar26 + 0x1654) == (uint32_t)uVar35) {
        if ((bVar5) && (var_2ach._4_4_ == 0)) {
            if ((var_298h._4_4_ & 0x80) == 0) {
                iVar2 = *(int64_t *)(arg1_00 + 0x40);
                iVar33 = func_0x000180498f10(*(undefined8 *)(arg1_00 + 0x30), iVar2);
                if (iVar33 != 0) {
                    uVar21 = *(int32_t *)(arg1_00 + 0x38) - 1;
                    var_2b4h._5_1_ = '\x01';
                    fcn.180142780(arg1_00, *(int64_t *)(arg1_00 + 8), iVar2, (uint64_t)uVar21);
                    iVar28 = iVar2;
                }
            } else {
                var_2b4h._5_1_ = '\x01';
                puVar3 = *(undefined4 **)(arg1_00 + 8);
                var_2e8h = var_2e8h & 0xffffffff00000000;
                fcn.1801426b0(arg1_00, (int64_t)puVar3, 0, (uint64_t)*(uint32_t *)(arg1_00 + 0x18), var_2e8h);
                iVar33 = *(int32_t *)(arg1_00 + 0x18);
                **(undefined **)(arg1_00 + 0x30) = (*(undefined **)(arg1_00 + 0x30))[iVar33];
                *(undefined2 *)(arg1_00 + 0x73) = 0x101;
                *(int32_t *)(arg1_00 + 0x18) = *(int32_t *)(arg1_00 + 0x18) - iVar33;
                *(undefined8 *)(puVar3 + 1) = 0;
                *puVar3 = 0;
                iVar28 = 0x1805aadb1;
            }
            uVar35 = (uint64_t)(uint32_t)var_2b4h;
        }
        if ((var_298h._4_4_ & 0x9c0000) != 0) {
            uVar48 = 0x40000;
            if ((var_298h._4_4_ & 0x40000) == 0) {
code_r0x00018014542e:
                if ((var_298h._4_4_ >> 0x13 & 1) == 0) {
code_r0x00018014547e:
                    uVar48 = 0x800000;
                    if (((var_298h._4_4_ & 0x800000) == 0) || (uVar46 = 0, *(char *)(arg1_00 + 0x74) == '\0')) {
                        if ((var_298h._4_4_ >> 0x14 & 1) == 0) goto code_r0x000180145633;
                        uVar48 = 0x100000;
                        uVar46 = 0;
                    }
                } else {
                    cVar17 = func_0x000180107dc0(0x203, 1, 0);
                    if (cVar17 == '\0') {
                        cVar17 = func_0x000180107dc0(0x204, 1, 0);
                        if (cVar17 == '\0') goto code_r0x00018014547e;
                        uVar48 = 0x80000;
                        uVar46 = 0x204;
                    } else {
                        uVar48 = 0x80000;
                        uVar46 = 0x203;
                    }
                }
            } else {
                cVar17 = func_0x000180109d80(0x200, 0, uVar35 & 0xffffffff);
                uVar46 = 0x200;
                if (cVar17 == '\0') goto code_r0x00018014542e;
            }
            uStack_19c = 0;
            uStack_198 = 0;
            cStack_195 = 0;
            uStack_194 = 0;
            Stack_190 = 0;
            Stack_18d = 0;
            iStack_188 = 0;
            uStack_184 = 0;
            iStack_180 = 0;
            iStack_17c = 0;
            iStack_178 = 0;
            uStack_174 = 0;
            uStack_1a0 = (uint32_t)var_2b4h;
            uStack_1ac = var_298h._4_4_;
            if ((*(int32_t *)(iVar26 + 0x1654) != *(int32_t *)(arg1_00 + 0x14)) ||
               (uStack_196 = 1, *(char *)(iVar26 + 0x1660) == '\0')) {
                uStack_196 = 0;
            }
            piStack_1a8 = (int32_t *)uStack_270;
            puVar41 = puStack_288;
            if (var_2ach._4_4_ == 0) {
                puVar41 = *(undefined8 **)(arg1_00 + 0x30);
            }
            iStack_1b8 = iVar26;
            uStack_1b0 = uVar48;
            func_0x00018011f640(arg1_00 + 0x48, *(int32_t *)(arg1_00 + 0x18) + 1);
            func_0x000180498030(*(undefined8 *)(arg1_00 + 0x50), puVar41, (int64_t)(*(int32_t *)(arg1_00 + 0x18) + 1));
            Stack_190 = SUB83(puVar41, 0);
            Stack_18d = (unkbyte5)((uint64_t)puVar41 >> 0x18);
            iStack_188 = *(int32_t *)(arg1_00 + 0x18);
            uStack_184 = *(undefined4 *)(arg1_00 + 0x58);
            cStack_195 = '\0';
            piVar47 = *(int32_t **)(arg1_00 + 8);
            iStack_180 = *piVar47;
            iStack_17c = piVar47[1];
            iStack_178 = piVar47[2];
            uStack_19c = uVar46;
            (*(code *)uStack_260)(&iStack_1b8);
            if ((cStack_195 != '\0') || (iStack_180 != **(int32_t **)(arg1_00 + 8))) {
                *(undefined *)(arg1_00 + 0x70) = 1;
            }
            if (iStack_180 < 0) {
                iVar33 = 0;
            } else {
                iVar33 = iStack_180;
                if (iStack_188 < iStack_180) {
                    iVar33 = iStack_188;
                }
            }
            **(int32_t **)(arg1_00 + 8) = iVar33;
            if (iStack_17c < 0) {
                iVar33 = 0;
            } else {
                iVar33 = iStack_17c;
                if (iStack_188 < iStack_17c) {
                    iVar33 = iStack_188;
                }
            }
            *(int32_t *)(*(int64_t *)(arg1_00 + 8) + 4) = iVar33;
            if (iStack_178 < 0) {
                iVar33 = 0;
            } else {
                iVar33 = iStack_178;
                if (iStack_188 < iStack_178) {
                    iVar33 = iStack_188;
                }
            }
            *(int32_t *)(*(int64_t *)(arg1_00 + 8) + 8) = iVar33;
            if (cStack_195 != '\0') {
                var_2e8h = CONCAT44(var_2e8h._4_4_, iStack_188);
                fcn.180142ec0(arg1_00, *(int64_t *)(arg1_00 + 0x50), (uint64_t)(*(int32_t *)(arg1_00 + 0x48) - 1), 
                              CONCAT53(Stack_18d, Stack_190), var_2e8h);
                *(int32_t *)(arg1_00 + 0x18) = iStack_188;
                *(undefined4 *)(arg1_00 + 0x6c) = 0xbe99999a;
            }
        }
code_r0x000180145633:
        puVar41 = puStack_288;
        uVar34 = (uint32_t)var_2b4h;
        if (var_2ach._4_4_ == 0) {
            iVar2 = *(int64_t *)(arg1_00 + 0x20);
            iVar33 = func_0x000180498f10(iVar2, puStack_288);
            uVar34 = (uint32_t)var_2b4h;
            if (iVar33 != 0) {
                uVar21 = *(uint32_t *)(arg1_00 + 0x18);
                var_2b4h._5_1_ = '\x01';
                iVar28 = iVar2;
            }
        }
    }
    if (*(uint32_t *)(iVar26 + 0x26f8) == uVar34) {
        if (*(uint32_t *)(iVar26 + 0x1654) != uVar34) {
            if ((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fc0) & 0x20) == 0) {
                if (((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1684) == *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8))
                    && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8) != 0)) &&
                   (*(int32_t *)(*(int64_t *)0x180781f28 + 4) <= *(int32_t *)(*(int64_t *)0x180781f28 + 0x1688)))
                goto code_r0x0001801456c5;
            } else if ((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fc0) >> 6 & 1) != 0) {
code_r0x0001801456c5:
                if ((*(char *)(*(int64_t *)0x180781f28 + 0x168c) != '\0') && (var_2ach._4_4_ == 0)) {
                    iVar2 = *(int64_t *)(iVar26 + 0x2708);
                    iVar33 = func_0x000180498f10(iVar2, puVar41);
                    uVar34 = (uint32_t)var_2b4h;
                    if (iVar33 != 0) {
                        uVar21 = *(int32_t *)(iVar26 + 0x2700) - 1;
                        var_2b4h._5_1_ = '\x01';
                        iVar28 = iVar2;
                    }
                }
            }
        }
        *(undefined4 *)(iVar26 + 0x26f8) = 0;
    }
    if (iVar28 != 0) {
        fVar58 = fStack_278;
        if ((var_298h._4_4_ >> 0x16 & 1) != 0) {
            auVar13._8_8_ = 0;
            auVar13._0_8_ = puStack_140;
            _auStack_148 = auVar13 << 0x40;
            auVar11._8_8_ = 0;
            auVar11._0_8_ = auStack_128._8_8_;
            auStack_128 = auVar11 << 0x40;
            uStack_160 = 0x400000;
            auStack_168 = (undefined  [8])iVar26;
            uStack_15c = var_298h._4_4_;
            if ((arg1_00 == 0) || (*(int32_t *)(iVar26 + 0x1654) != *(int32_t *)(arg1_00 + 0x14))) {
code_r0x00018014578e:
                auStack_148 = (undefined  [8])0x0;
            } else {
                auStack_148._0_3_ = 0x10000;
                if (*(char *)(iVar26 + 0x1660) == '\0') goto code_r0x00018014578e;
            }
            puStack_140 = puVar41;
            auStack_138._4_4_ = uVar21 + 1;
            if ((int32_t)(uVar21 + 1) <= (int32_t)fStack_278) {
                auStack_138._4_4_ = fStack_278;
            }
            auStack_138._0_4_ = uVar21;
            uStack_130 = 0;
            auStack_158._8_4_ = uVar34;
            auStack_158._0_8_ = uStack_270;
            uStack_14c = 0;
            (*(code *)uStack_260)(auStack_168);
            puStack_288 = puStack_140;
            puVar41 = puStack_140;
            fVar58 = (float)auStack_138._4_4_;
            uVar21 = auStack_138._4_4_ - 1;
            if ((int32_t)auStack_138._0_4_ < (int32_t)(auStack_138._4_4_ - 1)) {
                uVar21 = auStack_138._0_4_;
            }
        }
        if ((int32_t)(uVar21 + 1) < (int32_t)fVar58) {
            fVar58 = (float)(uVar21 + 1);
        }
        uVar35 = (uint64_t)(int32_t)fVar58;
        if (uVar35 != 0) {
            if (1 < uVar35) {
                func_0x000180498d90(puVar41, iVar28, (int32_t)fVar58 + -1);
            }
            *(undefined *)((uVar35 - 1) + (int64_t)puVar41) = 0;
        }
    }
    uVar21 = (uint32_t)var_2b4h;
    if ((*(uint32_t *)(iVar26 + 0x1654) == (uint32_t)var_2b4h) && (cVar20 != '\0')) {
        func_0x0001800f9f30(0, 0);
    }
    uVar34 = (uint32_t)var_298h;
    if ((uint32_t)var_298h == 0) {
        func_0x0001800f7d00(&uStack_218, uVar21, 0);
        fStack_200 = *(float *)(*(int64_t *)0x180781f28 + 0xf40);
        fStack_1fc = *(float *)(*(int64_t *)0x180781f28 + 0xf44);
        fStack_1f8 = *(float *)(*(int64_t *)0x180781f28 + 0xf48);
        fStack_1f4 = *(float *)(*(int64_t *)0x180781f28 + 0xf4c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar48 = func_0x0001800f5fa0(&fStack_200);
        fVar58 = fStack_21c;
        var_2e8h = CONCAT44(var_2e8h._4_4_, *(undefined4 *)(iVar26 + 0xde4));
        func_0x0001800f7a00(CONCAT44(fStack_21c, fVar62), CONCAT44(fStack_20c, fStack_210), uVar48, 1);
        fStack_254 = fVar58 + *(float *)(iVar26 + 0xde0);
        fStack_258 = fVar62 + *(float *)(iVar26 + 0xddc);
        fVar55 = fVar52 + fVar62;
        fVar49 = fVar58 + fVar50;
    } else {
        fStack_254 = *(float *)(iStack_248 + 0x15c);
        fStack_258 = *(float *)(iStack_248 + 0x158);
        if (fStack_228 <= *(float *)(iStack_248 + 0x2b8)) {
            fStack_228 = *(float *)(iStack_248 + 0x2b8);
        }
        fVar58 = fStack_21c;
        if (fStack_21c <= *(float *)(iStack_248 + 700)) {
            fVar58 = *(float *)(iStack_248 + 700);
        }
        fVar55 = fVar52 + fVar62;
        if (*(float *)(iStack_248 + 0x2c0) <= fVar52 + fVar62) {
            fVar55 = *(float *)(iStack_248 + 0x2c0);
        }
        fVar49 = fStack_21c + fVar50;
        fVar62 = fStack_228;
        if (*(float *)(iStack_248 + 0x2c4) <= fStack_21c + fVar50) {
            fVar49 = *(float *)(iStack_248 + 0x2c4);
        }
    }
    fVar50 = fStack_254;
    iStack_238 = CONCAT44(fVar49, fVar55);
    uStack_240 = (int32_t *)CONCAT44(fVar58, fVar62);
    if (cStack_263 != '\0') {
        puVar41 = *(undefined8 **)(arg1_00 + 0x30);
        puStack_288 = puVar41;
    }
    fStack_278 = fVar58;
    if (((var_2b7h == '\0') && (var_2b8h == 0)) && (*(uint32_t *)(iVar26 + 0x1654) != uVar21)) {
        if ((uVar34 == 0) || (uStack_250 != 0)) {
            iVar26 = func_0x000180498cd0(puVar41);
            goto code_r0x0001801459bd;
        }
        uStack_270 = (undefined8 *)0x0;
code_r0x0001801459e1:
        puVar41 = uStack_270;
        uVar34 = (uint32_t)((fVar58 - fVar50) / *(float *)(var_2a0h + 0x12f8));
        uVar21 = 0;
        if (-1 < (int32_t)uVar34) {
            uVar21 = uVar34;
        }
        puStack_280 = uStack_270;
        uStack_250 = uVar21;
        fVar50 = (float)func_0x000180471c90((fVar49 - fVar50) / *(float *)(var_2a0h + 0x12f8));
        var_2ach._0_4_ = uVar21;
        if ((int32_t)uVar21 <= (int32_t)fVar50) {
            var_2ach._0_4_ = (int32_t)fVar50;
        }
    } else {
        iVar26 = (int64_t)*(int32_t *)(arg1_00 + 0x18);
code_r0x0001801459bd:
        puVar41 = (undefined8 *)((int64_t)puVar41 + iVar26);
        uStack_250 = 0;
        var_2ach._0_4_ = 1;
        puStack_280 = puVar41;
        uStack_270 = puVar41;
        if (uVar34 != 0) goto code_r0x0001801459e1;
    }
    iVar26 = var_2a0h;
    uVar21 = (uint32_t)var_2ach;
    puVar38 = (undefined8 *)(var_2a0h + 0x26e0);
    iVar33 = *(int32_t *)(var_2a0h + 0x26e4);
    uStack_218 = puVar38;
    if (iVar33 < 0) {
        iVar33 = iVar33 + iVar33 / 2;
        iVar23 = 0;
        if (0 < iVar33) {
            iVar23 = iVar33;
        }
        func_0x00018011fb10(puVar38, iVar23);
    }
    fVar50 = fStack_1f0;
    puVar36 = puStack_288;
    *(int32_t *)puVar38 = 0;
    iVar28 = *(int64_t *)0x180781f28;
    uVar34 = 1;
    var_2a4h = 1;
    if ((uint32_t)var_298h != 0) {
        if ((arg1_00 == 0) ||
           (((*(char *)(arg1_00 + 0x70) == '\0' || (var_2b7h == '\0')) &&
            ((*(char *)(arg1_00 + 0x71) == '\0' || ((var_2b7h == '\0' && (var_2b8h == 0)))))))) {
            iVar33 = uVar21 + 1;
        } else {
            iVar33 = 0x7fffffff;
        }
        uStack_260 = (int32_t **)&uStack_270;
        if (puVar41 != (undefined8 *)0x0) {
            uStack_260 = (int32_t **)0x0;
        }
        uVar21 = 0;
        var_2a4h = 0;
        bVar5 = false;
        puVar27 = puStack_288;
        uStack_e8 = puVar41;
        if ((var_298h._4_4_ & 0x1000000) == 0) {
            if (puVar41 == (undefined8 *)0x0) {
                while( true ) {
                    uVar22 = uVar21 + 1;
                    if ((int32_t)uVar21 <= iVar33) {
                        iVar23 = *(int32_t *)(iVar26 + 0x26e4);
                        if (*(int32_t *)puVar38 == iVar23) {
                            iVar40 = *(int32_t *)puVar38 + 1;
                            if (iVar23 == 0) {
                                iVar23 = 8;
                            } else {
                                iVar23 = iVar23 / 2 + iVar23;
                            }
                            if (iVar40 < iVar23) {
                                iVar40 = iVar23;
                            }
                            func_0x00018011fb10(puVar38, iVar40);
                        }
                        *(int32_t *)(*(int64_t *)(iVar26 + 0x26e8) + (int64_t)*(int32_t *)puVar38 * 4) =
                             (int32_t)puVar27 - (int32_t)puVar36;
                        *(int32_t *)puVar38 = *(int32_t *)puVar38 + 1;
                    }
                    iVar28 = func_0x00018045b928(puVar27, 10);
                    if (iVar28 == 0) break;
                    puVar27 = (undefined8 *)(iVar28 + 1);
                    uVar21 = uVar22;
                }
                var_2a4h = uVar22;
                iVar28 = func_0x000180498cd0(puVar27);
                puVar27 = (undefined8 *)((int64_t)puVar27 + iVar28);
                bVar5 = true;
                puVar41 = puStack_280;
                arg1_00 = uStack_208;
            } else {
                uVar22 = uVar21;
                if (puStack_288 < puVar41) {
                    do {
                        uVar22 = uVar21 + 1;
                        var_2a4h = uVar22;
                        if ((int32_t)uVar21 <= iVar33) {
                            iVar40 = (int32_t)puStack_288;
                            iVar23 = *(int32_t *)(iVar26 + 0x26e4);
                            if (*(int32_t *)puVar38 == iVar23) {
                                iVar39 = *(int32_t *)puVar38 + 1;
                                if (iVar23 == 0) {
                                    iVar23 = 8;
                                } else {
                                    iVar23 = iVar23 / 2 + iVar23;
                                }
                                if (iVar39 < iVar23) {
                                    iVar39 = iVar23;
                                }
                                func_0x00018011fb10(puVar38, iVar39);
                            }
                            *(int32_t *)(*(int64_t *)(iVar26 + 0x26e8) + (int64_t)*(int32_t *)puVar38 * 4) =
                                 (int32_t)puVar27 - iVar40;
                            *(int32_t *)puVar38 = *(int32_t *)puVar38 + 1;
                        }
                        iVar28 = func_0x000180498a80(puVar27, 10, (int64_t)puVar41 - (int64_t)puVar27);
                        if (iVar28 == 0) {
                            bVar5 = false;
                            puVar27 = puVar41;
                            goto code_r0x000180145baf;
                        }
                        puVar27 = (undefined8 *)(iVar28 + 1);
                        uVar21 = uVar22;
                    } while (puVar27 < puVar41);
                    bVar5 = false;
                }
            }
        } else {
            uVar21 = var_2a4h;
            if (puStack_288 < puVar41) {
                uVar34 = 0;
                do {
                    uVar21 = uVar34 + 1;
                    if ((int32_t)uVar34 <= iVar33) {
                        iVar40 = (int32_t)puStack_288;
                        iVar23 = *(int32_t *)(iVar26 + 0x26e4);
                        if (*(int32_t *)puVar38 == iVar23) {
                            iVar39 = *(int32_t *)puVar38 + 1;
                            if (iVar23 == 0) {
                                iVar23 = 8;
                            } else {
                                iVar23 = iVar23 / 2 + iVar23;
                            }
                            if (iVar39 < iVar23) {
                                iVar39 = iVar23;
                            }
                            func_0x00018011fb10(puVar38, iVar39);
                        }
                        *(int32_t *)(*(int64_t *)(iVar26 + 0x26e8) + (int64_t)*(int32_t *)puVar38 * 4) =
                             (int32_t)puVar27 - iVar40;
                        *(int32_t *)puVar38 = *(int32_t *)puVar38 + 1;
                    }
                    var_2e0h = CONCAT44(var_2e0h._4_4_, 2);
                    var_2e8h = CONCAT44(var_2e8h._4_4_, fVar50);
                    puVar27 = (undefined8 *)func_0x00018012f4a0(*(undefined8 *)(iVar28 + 0x12e8));
                    if (*(char *)puVar27 == '\n') {
                        puVar27 = (undefined8 *)((int64_t)puVar27 + 1);
                    }
                    arg1_00 = uStack_208;
                    uVar34 = uVar21;
                } while (puVar27 < puVar41);
            }
            var_2a4h = uVar21;
            bVar5 = false;
            uVar22 = var_2a4h;
        }
code_r0x000180145baf:
        puVar37 = uStack_e8;
        if (uStack_260 != (int32_t **)0x0) {
            uStack_e8 = puVar27;
            *uStack_260 = (int32_t *)puVar27;
            puStack_280 = uStack_270;
            puVar37 = puVar27;
            puVar41 = uStack_270;
        }
        if (uVar22 == 0) {
            iVar23 = *(int32_t *)(iVar26 + 0x26e4);
            if (*(int32_t *)puVar38 == iVar23) {
                iVar40 = *(int32_t *)puVar38 + 1;
                if (iVar23 == 0) {
                    iVar23 = 8;
                } else {
                    iVar23 = iVar23 / 2 + iVar23;
                }
                if (iVar40 < iVar23) {
                    iVar40 = iVar23;
                }
                func_0x00018011fb10(puVar38, iVar40);
                puVar37 = uStack_e8;
            }
            *(undefined4 *)(*(int64_t *)(iVar26 + 0x26e8) + (int64_t)*(int32_t *)puVar38 * 4) = 0;
            *(int32_t *)puVar38 = *(int32_t *)puVar38 + 1;
            uVar22 = 1;
            var_2a4h = 1;
        }
        puVar36 = puStack_288;
        uVar34 = uVar22;
        if ((((puStack_288 < puVar37) && (*(char *)((int64_t)puVar37 + -1) == '\n')) && (!bVar5)) &&
           (uVar34 = uVar22 + 1, var_2a4h = uVar34, (int32_t)uVar22 <= iVar33)) {
            uVar21 = (int32_t)puVar37 - (int32_t)puStack_288;
            uStack_e8 = (undefined8 *)(uint64_t)uVar21;
            iVar33 = *(int32_t *)(iVar26 + 0x26e4);
            if (*(int32_t *)puVar38 == iVar33) {
                iVar23 = *(int32_t *)puVar38 + 1;
                if (iVar33 == 0) {
                    iVar33 = 8;
                } else {
                    iVar33 = iVar33 / 2 + iVar33;
                }
                if (iVar23 < iVar33) {
                    iVar23 = iVar33;
                }
                func_0x00018011fb10(puVar38, iVar23);
                uVar21 = (uint32_t)uStack_e8;
            }
            *(uint32_t *)(*(int64_t *)(iVar26 + 0x26e8) + (int64_t)*(int32_t *)puVar38 * 4) = uVar21;
            *(int32_t *)puVar38 = *(int32_t *)puVar38 + 1;
        }
    }
    *(int32_t *)(iVar26 + 0x26f0) = (int32_t)puVar41 - (int32_t)puVar36;
    uVar21 = uVar34;
    if ((int32_t)(uint32_t)var_2ach < (int32_t)uVar34) {
        uVar21 = (uint32_t)var_2ach;
    }
    fVar50 = (float)uVar34 * *(float *)(var_2a0h + 0x12f8);
    uStack_e8 = (undefined8 *)CONCAT44(uStack_e8._4_4_, fVar50);
    var_2ach._0_4_ = uVar21;
    if ((var_2b7h == '\0') || (arg1_00 == 0)) {
        fVar58 = 0.0;
        fVar62 = 0.0;
    } else {
        iVar33 = **(int32_t **)(arg1_00 + 8);
        uStack_270 = (undefined8 *)((int64_t)puVar36 + (int64_t)iVar33);
        piVar4 = *(int32_t **)(iVar26 + 0x26e8);
        piVar47 = piVar4;
        uVar35 = (int64_t)*(int32_t *)puVar38;
        while (uVar12 = uVar35, uVar12 != 0) {
            uVar35 = uVar12 >> 1;
            if (piVar47[uVar35] < iVar33) {
                piVar47 = piVar47 + uVar35 + 1;
                uVar35 = uVar12 + (-1 - uVar35);
            }
        }
        if (piVar4 < piVar47) {
            if (((piVar47 == piVar4 + *(int32_t *)puVar38) || (*piVar47 != iVar33)) ||
               ((0.0 < *(float *)(arg1_00 + 0x68) &&
                (((*(char *)(arg1_00 + 0x76) == '\x01' && (*(char *)((int64_t)uStack_270 + -1) != '\n')) &&
                 (*(char *)((int64_t)uStack_270 + -1) != '\0')))))) {
                piVar47 = piVar47 + -1;
                goto code_r0x000180145ee4;
            }
code_r0x000180145eeb:
            iVar33 = (int32_t)((int64_t)piVar47 - (int64_t)piVar4 >> 2);
        } else {
code_r0x000180145ee4:
            if (piVar47 != piVar4) goto code_r0x000180145eeb;
            iVar33 = 0;
        }
        if (*(int32_t *)puVar38 == 0) {
            iVar23 = 0;
        } else {
            iVar23 = piVar4[iVar33];
        }
        puVar36 = (undefined8 *)((int64_t)puVar36 + (int64_t)iVar23);
        fVar62 = *(float *)(var_2a0h + 0x26c8);
        fVar52 = *(float *)(var_2a0h + 0x12f8);
        iVar26 = *(int64_t *)(var_2a0h + 0x12e8);
        puVar27 = puVar41;
        iStack_1c0 = iVar26;
        if (puVar41 == (undefined8 *)0x0) {
            iVar28 = func_0x000180498cd0(puVar36);
            puVar27 = (undefined8 *)(iVar28 + (int64_t)puVar36);
        }
        if (uStack_270 == (undefined8 *)0x0) {
            uStack_270 = puVar27;
        }
        ppiVar29 = (int32_t **)func_0x00018012ec80(iVar26);
        iVar26 = iStack_1c0;
        fVar58 = *(float *)((int64_t)ppiVar29 + 0x14);
        auVar59 = ZEXT816(0);
        auVar61 = ZEXT816(0);
        bVar5 = 0.0 < fVar62;
        puVar30 = (undefined8 *)0x0;
        puVar37 = uStack_270;
        var_28eh = bVar5;
        uStack_260 = ppiVar29;
        if (puVar36 < uStack_270) {
            do {
                auVar60._4_12_ = auVar61._4_12_;
                fVar51 = auVar61._0_4_;
                fVar56 = auVar59._0_4_;
                if (bVar5) {
                    if (puVar30 == (undefined8 *)0x0) {
                        var_2e0h = CONCAT44(var_2e0h._4_4_, 2);
                        var_2e8h = CONCAT44(var_2e8h._4_4_, fVar62 - fVar51);
                        puVar30 = (undefined8 *)func_0x00018012f4a0(iVar26);
                        puVar37 = uStack_270;
                    }
                    if (puVar36 < puVar30) goto code_r0x000180145ffb;
                    auVar59 = auVar61;
                    if (fVar51 <= fVar56) {
                        auVar60._0_4_ = fVar56;
                        auVar59 = auVar60;
                    }
                    auVar61 = ZEXT816(0);
                    if ((puVar36 < puVar27) && (*(char *)puVar36 == '\n')) {
                        puVar36 = (undefined8 *)((int64_t)puVar36 + 1);
                    }
                    puVar30 = (undefined8 *)0x0;
                } else {
code_r0x000180145ffb:
                    uVar21 = (uint32_t)*(char *)puVar36;
                    uStack_260 = (int32_t **)CONCAT44(uStack_260._4_4_, uVar21);
                    if (uVar21 < 0x80) {
                        puVar36 = (undefined8 *)((int64_t)puVar36 + 1);
                    } else {
                        iVar23 = func_0x0001800f5c80(&uStack_260, puVar36, puVar27);
                        puVar36 = (undefined8 *)((int64_t)puVar36 + (int64_t)iVar23);
                        uVar21 = (uint32_t)(float)uStack_260;
                    }
                    puVar37 = uStack_270;
                    if (uVar21 == 10) {
                        if (fVar56 <= fVar51) {
                            auVar59._0_4_ = fVar51;
                        }
                        auVar61 = ZEXT816(0);
                    } else if (uVar21 != 0xd) {
                        if ((*(uint32_t *)ppiVar29 <= uVar21) ||
                           (auVar54 = ZEXT416((uint32_t)ppiVar29[1][uVar21]), (float)ppiVar29[1][uVar21] < 0.0)) {
                            auVar54._0_8_ = func_0x00018012bbd0(ppiVar29);
                            auVar54._8_8_ = extraout_XMM0_Qb;
                        }
                        fVar51 = auVar54._0_4_ * (fVar52 / fVar58) + fVar51;
                        puVar41 = puStack_280;
                        puVar38 = uStack_218;
                        arg1_00 = uStack_208;
                        if (3.402823e+38 <= fVar51) break;
                        auVar61._4_4_ = auVar54._4_4_;
                        auVar61._0_4_ = fVar51;
                        auVar61._8_4_ = auVar54._8_4_;
                        auVar61._12_4_ = auVar54._12_4_;
                        puVar37 = uStack_270;
                    }
                }
                puVar41 = puStack_280;
                puVar38 = uStack_218;
                arg1_00 = uStack_208;
            } while (puVar36 < puVar37);
        }
        if (auVar61._0_4_ <= auVar59._0_4_) {
            auVar61._0_4_ = auVar59._0_4_;
        }
        fVar58 = auVar61._0_4_;
        fVar62 = (float)(iVar33 + 1) * *(float *)(var_2a0h + 0x12f8);
        fVar52 = fStack_220;
        uVar34 = var_2a4h;
    }
    iVar26 = var_2a0h;
    uVar21 = (uint32_t)var_2ach;
    uStack_270 = (undefined8 *)CONCAT44(uStack_270._4_4_, fVar62);
    uStack_260 = (int32_t **)CONCAT44(uStack_260._4_4_, fVar58);
    fStack_200 = *(float *)(*(int64_t *)0x180781f28 + 0xed0);
    fStack_1fc = *(float *)(*(int64_t *)0x180781f28 + 0xed4);
    fStack_1f8 = *(float *)(*(int64_t *)0x180781f28 + 0xed8);
    fStack_1f4 = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar22 = func_0x0001800f5fa0(&fStack_200);
    fVar51 = fStack_278;
    var_2a4h = uVar22;
    if ((var_2b7h != '\0') || (var_2b8h != 0)) {
        *(uint32_t *)(arg1_00 + 100) = uVar34;
        fVar63 = fStack_22c;
        if ((var_2b7h != '\0') && (*(char *)(arg1_00 + 0x70) != '\0')) {
            if ((var_298h._4_4_ & 0x8000) == 0) {
                if (*(float *)(arg1_00 + 0x5c) <= fVar58) {
                    fVar56 = fVar58 - (fVar52 - *(float *)(iVar26 + 0xddc));
                    if (*(float *)(arg1_00 + 0x5c) <= fVar56) {
                        *(float *)(arg1_00 + 0x5c) = (float)(int32_t)(fVar56 + fVar52 * 0.25);
                    }
                } else {
                    fVar56 = fVar58 - fVar52 * 0.25;
                    fVar52 = 0.0;
                    if (0.0 <= fVar56) {
                        fVar52 = fVar56;
                    }
                    *(float *)(arg1_00 + 0x5c) = (float)(int32_t)fVar52;
                }
            } else {
                *(undefined4 *)(arg1_00 + 0x5c) = 0;
            }
            if ((uint32_t)var_298h != 0) {
                fVar52 = fVar62 - *(float *)(iVar26 + 0x12f8);
                if (fVar52 < fStack_22c) {
                    fVar63 = 0.0;
                    if (0.0 <= fVar52) {
                        fVar63 = fVar52;
                    }
                    *(undefined *)(arg1_00 + 0x70) = 0;
                    goto code_r0x000180146229;
                }
                fVar52 = *(float *)(iVar26 + 0xde0) + *(float *)(iVar26 + 0xde0);
                if (fStack_22c <= fVar62 - (afStack_1e8[0] - fVar52)) {
                    fVar63 = (fVar62 - afStack_1e8[0]) + fVar52;
                }
            }
            *(undefined *)(arg1_00 + 0x70) = 0;
        }
code_r0x000180146229:
        if (*(char *)(arg1_00 + 0x71) != '\0') {
            if ((uint32_t)var_298h != 0) {
                fVar63 = (fVar62 - *(float *)(iVar26 + 0x12f8)) - (afStack_1e8[0] * 0.5 - *(float *)(iVar26 + 0xde0));
            }
            *(undefined *)(arg1_00 + 0x71) = 0;
            var_2b7h = '\0';
        }
        if (fVar63 != fStack_22c) {
            if (0.0 <= fVar63) {
                fVar52 = (*(float *)(iVar26 + 0xde0) + *(float *)(iVar26 + 0xde0) + fVar50) - afStack_1e8[0];
                if (fVar52 <= 0.0) {
                    fVar52 = 0.0;
                }
                if (fVar63 <= fVar52) {
                    fVar52 = fVar63;
                }
            } else {
                fVar52 = 0.0;
            }
            fStack_254 = fStack_254 + (*(float *)(iStack_248 + 0xd8) - fVar52);
            *(float *)(iStack_248 + 0xd8) = fVar52;
            uVar21 = (uint32_t)((fStack_278 - fStack_254) / *(float *)(iVar26 + 0x12f8));
            uVar43 = 0;
            if (-1 < (int32_t)uVar21) {
                uVar43 = uVar21;
            }
            uStack_250 = uVar43;
            fVar63 = (float)func_0x000180471c90((fVar49 - fStack_254) / *(float *)(iVar26 + 0x12f8));
            if ((int32_t)uVar43 <= (int32_t)fVar63) {
                uVar43 = (int32_t)fVar63;
            }
            uVar21 = uVar34;
            var_2ach._0_4_ = uVar34;
            if ((int32_t)uVar43 < (int32_t)uVar34) {
                uVar21 = uVar43;
                var_2ach._0_4_ = uVar43;
            }
        }
        fVar63 = *(float *)(arg1_00 + 0x5c);
        if (var_2b8h != 0) {
            if (var_2b7h == '\0') {
                fVar52 = 0.6;
            } else {
                fVar52 = 1.0;
            }
            fStack_200 = *(float *)(*(int64_t *)0x180781f28 + 0x1220);
            fStack_1fc = *(float *)(*(int64_t *)0x180781f28 + 0x1224);
            fStack_1f8 = *(float *)(*(int64_t *)0x180781f28 + 0x1228);
            fStack_1f4 = *(float *)(*(int64_t *)0x180781f28 + 0x122c) *
                         fVar52 * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fStack_22c = (float)func_0x0001800f5fa0(&fStack_200);
            if ((uint32_t)var_298h == 0) {
                fVar52 = -1.0;
                fVar56 = 2.0;
            } else {
                fVar52 = 0.0;
                fVar56 = 0.0;
            }
            piVar47 = *(int32_t **)(iVar26 + 0x12f0);
            if ((*piVar47 < 0x21) ||
               (fVar53 = *(float *)(*(int64_t *)(piVar47 + 2) + 0x80),
               *(float *)(*(int64_t *)(piVar47 + 2) + 0x80) < 0.0)) {
                if ((128.0 <= (float)piVar47[5]) || ((piVar47[0x13] & 0x10000000U) != 0)) {
                    fStack_220 = 0.0;
                    iVar28 = fcn.18012b6e0(var_2e8h, var_2e0h, var_2d8h, var_2d0h, 
                                           CONCAT44(var_2c8h._4_4_, (float)var_2c8h));
                    fVar53 = fStack_220;
                    if (iVar28 != 0) {
                        fVar53 = *(float *)(iVar28 + 4);
                    }
                } else {
                    iVar28 = fcn.18012b6e0(var_2e8h, var_2e0h, var_2d8h, var_2d0h, 
                                           CONCAT44(var_2c8h._4_4_, (float)var_2c8h));
                    if (iVar28 == 0) {
                        fVar53 = (float)piVar47[4];
                    } else {
                        fVar53 = *(float *)(iVar28 + 4);
                    }
                }
            }
            fVar16 = fStack_228;
            fVar15 = fStack_278;
            iVar33 = *(int32_t *)(*(int64_t *)(arg1_00 + 8) + 8);
            iVar23 = *(int32_t *)(*(int64_t *)(arg1_00 + 8) + 4);
            iVar40 = iVar33;
            if (iVar23 < iVar33) {
                iVar40 = iVar23;
            }
            iStack_1c0 = (int64_t)iVar40;
            puVar36 = (undefined8 *)((int64_t)puStack_288 + iStack_1c0);
            if (iVar33 <= iVar23) {
                iVar33 = iVar23;
            }
            puVar27 = (undefined8 *)((int64_t)iVar33 + (int64_t)puStack_288);
            uVar34 = uStack_250;
            puStack_280 = puVar36;
            uVar22 = var_2a4h;
            if ((int32_t)uStack_250 < (int32_t)uVar21) {
                do {
                    auVar57 = ZEXT816(0);
                    if (*(int32_t *)puVar38 == 0) {
                        iVar33 = 0;
                    } else {
                        iVar33 = *(int32_t *)(puVar38[1] + (int64_t)(int32_t)uVar34 * 4);
                    }
                    uStack_218 = (undefined8 *)((int64_t)puStack_288 + (int64_t)iVar33);
                    if ((int32_t)(uVar34 + 1) < *(int32_t *)puVar38) {
                        iVar23 = *(int32_t *)(puVar38[1] + 4 + (int64_t)(int32_t)uVar34 * 4) + -1;
                    } else {
                        iVar23 = *(int32_t *)(puVar38 + 2);
                    }
                    puVar37 = (undefined8 *)((int64_t)puStack_288 + (int64_t)iVar23);
                    if ((puVar37 < puVar41) && (*(char *)puVar37 != '\n')) {
                        bVar5 = true;
                        puVar37 = (undefined8 *)((int64_t)puVar37 + 1);
                    } else {
                        bVar5 = false;
                    }
                    iVar26 = (int64_t)iVar33;
                    if (uStack_218 < puVar36) {
                        iVar26 = iStack_1c0;
                    }
                    puVar44 = (undefined8 *)((int64_t)puStack_288 + iVar26);
                    puVar30 = puVar37;
                    if (puVar27 < puVar37) {
                        puVar30 = puVar27;
                    }
                    if (puVar44 < puVar30) {
                        var_2e8h = CONCAT44(var_2e8h._4_4_, 0xbf800000);
                        pfVar31 = (float *)func_0x0001800fe0a0(auStack_108, puVar44, puVar30, 0);
                        auVar57 = ZEXT416((uint32_t)(*pfVar31 + 0.0));
                        puVar36 = puStack_280;
                    }
                    if (((puVar36 <= puVar37) && (puVar37 < puVar27)) && (!bVar5)) {
                        auVar57._0_4_ = auVar57._0_4_ + (float)(int32_t)(fVar53 * 0.5);
                    }
                    iVar26 = var_2a0h;
                    if (auVar57._0_4_ != 0.0) {
                        var_2e8h = CONCAT44(var_2e8h._4_4_, 0xbf800000);
                        pfVar31 = (float *)func_0x0001800fe0a0(afStack_1e8, uStack_218, puVar44, 0);
                        iVar26 = var_2a0h;
                        fStack_1f8 = (fStack_258 - fVar63) + *pfVar31;
                        fVar50 = (float)uVar34 * *(float *)(var_2a0h + 0x12f8) + (fStack_254 - 0.0);
                        fStack_200 = fStack_1f8;
                        if (fStack_1f8 <= fVar16) {
                            fStack_200 = fVar16;
                        }
                        fStack_1fc = fVar50 + fVar52;
                        if (fStack_1fc <= fVar15) {
                            fStack_1fc = fVar15;
                        }
                        fStack_1f8 = fStack_1f8 + auVar57._0_4_;
                        if (fVar55 <= fStack_1f8) {
                            fStack_1f8 = fVar55;
                        }
                        fStack_1f4 = fVar50 + fVar56 + *(float *)(var_2a0h + 0x12f8);
                        if (fVar49 <= fStack_1f4) {
                            fStack_1f4 = fVar49;
                        }
                        var_2e0h = var_2e0h & 0xffffffff00000000;
                        var_2e8h = var_2e8h & 0xffffffff00000000;
                        func_0x000180126550(*(undefined8 *)(iStack_248 + 800), &fStack_200, &fStack_1f8, fStack_22c);
                        puVar36 = puStack_280;
                    }
                    uVar34 = uVar34 + 1;
                } while ((int32_t)uVar34 < (int32_t)(uint32_t)var_2ach);
                arg1_00 = uStack_208;
                uVar21 = (uint32_t)var_2ach;
                fVar51 = fStack_278;
                fVar50 = (float)uStack_e8;
                fVar62 = (float)uStack_270;
                fVar58 = (float)uStack_260;
                uVar22 = var_2a4h;
            }
        }
    }
    puVar36 = puStack_288;
    if (((*(uint32_t *)(iVar26 + 0x1654) == (uint32_t)var_2b4h) || ((var_298h._4_4_ & 0x20000) == 0)) ||
       ((var_2b7h != '\0' || (var_2b8h != 0)))) {
        fVar52 = (float)auStack_1d8._0_4_;
    } else {
        var_2e8h = CONCAT44(var_2e8h._4_4_, 0xbf800000);
        pfVar31 = (float *)func_0x0001800fe0a0(&uStack_218, puStack_288, 0, 0);
        fVar56 = ((float)auStack_1d8._0_4_ - *pfVar31) - *(float *)(iVar26 + 0xddc);
        fVar52 = (float)auStack_1d8._0_4_;
        if (fVar56 <= fStack_258) {
            fStack_258 = fVar56;
        }
    }
    iVar28 = iStack_248;
    if ((((uint32_t)var_298h != 0) || ((int64_t)puVar41 - (int64_t)puVar36 < 0x200000)) &&
       (((uVar22 & 0xff000000) != 0 && ((int32_t)uStack_250 < (int32_t)uVar21)))) {
        iVar33 = *(int32_t *)puVar38;
        if ((int32_t)uVar21 < iVar33) {
            iVar23 = *(int32_t *)(puVar38[1] + (int64_t)(int32_t)uVar21 * 4) + -1;
        } else {
            iVar23 = *(int32_t *)(puVar38 + 2);
        }
        var_2d0h = (int64_t)iVar23 + (int64_t)puVar36;
        if (iVar33 == 0) {
            iVar23 = 0;
        } else {
            iVar23 = *(int32_t *)(puVar38[1] + (int64_t)(int32_t)uStack_250 * 4);
        }
        puStack_280 = (undefined8 *)
                      CONCAT44((float)uStack_250 * *(float *)(iVar26 + 0x12f8) + (fStack_254 - 0.0), 
                               (fStack_258 - fVar63) + 0.0);
        var_2d8h = (int64_t)iVar23 + (int64_t)puVar36;
        var_2c0h._0_4_ = 3;
        var_2c8h._0_4_ = fStack_1f0;
        var_2e0h = (int64_t)&uStack_240;
        var_2e8h = CONCAT44(var_2e8h._4_4_, uVar22);
        func_0x00018012f9d0(*(undefined8 *)(iVar26 + 0x12e8), *(undefined8 *)(iStack_248 + 800), iVar33, &puStack_280);
    }
    if (var_2b7h != '\0') {
        fVar56 = *(float *)(iVar26 + 0x48) + *(float *)(arg1_00 + 0x6c);
        *(float *)(arg1_00 + 0x6c) = fVar56;
        if (((*(char *)(iVar26 + 0x8f) == '\0') || (fVar56 <= 0.0)) ||
           (fVar56 = (float)func_0x000180490df0(), fVar56 <= 0.8)) {
            bVar5 = true;
        } else {
            bVar5 = false;
        }
        fVar63 = (float)(int32_t)((fVar58 + fStack_258) - fVar63);
        fVar62 = (float)(int32_t)((fVar62 + fStack_254) - 0.0);
        fStack_1fc = (fVar62 - *(float *)(iVar26 + 0x12f8)) + 0.5;
        fStack_1f8 = fVar63 + 1.0;
        fStack_1f4 = fVar62 - 1.5;
        fStack_200 = fVar63;
        if (((bVar5) && (fVar51 < fStack_1f4)) &&
           ((fStack_1fc < fVar49 && ((fStack_228 < fStack_1f8 && (fVar63 < fVar55)))))) {
            auStack_1d8._12_4_ =
                 *(float *)(*(int64_t *)0x180781f28 + 0x10ec) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            auStack_1d8._0_12_ = *(undefined (*) [12])(*(int64_t *)0x180781f28 + 0x10e0);
            puStack_280 = (undefined8 *)CONCAT44(fStack_1f4, fVar63);
            fVar58 = *(float *)(iVar26 + 0x12c4);
            uVar48 = func_0x0001800f5fa0(auStack_1d8);
            var_2e8h = CONCAT44(var_2e8h._4_4_, (float)(int32_t)fVar58);
            func_0x000180126300(*(undefined8 *)(iVar28 + 800), &fStack_200, &puStack_280, uVar48);
        }
        if ((var_2ach._4_4_ == 0) && (*(uint32_t *)(iVar26 + 0x1654) == (uint32_t)var_2b4h)) {
            *(undefined2 *)(iVar26 + 0x28b0) = 0x101;
            *(float *)(iVar26 + 0x28b4) = fVar63 - 1.0;
            *(float *)(iVar26 + 0x28b8) = fVar62 - *(float *)(iVar26 + 0x12f8);
            *(undefined4 *)(iVar26 + 0x28bc) = *(undefined4 *)(iVar26 + 0x12f8);
            *(undefined4 *)(iVar26 + 0x28c0) = **(undefined4 **)(iStack_1e0 + 0x48);
        }
    }
    uVar21 = (uint32_t)var_2b4h;
    uVar34 = uStack_230;
    if (uStack_230 != 0) {
        func_0x000180142b20();
    }
    if ((uint32_t)var_298h != 0) {
        iStack_1e0 = (uint64_t)(uint32_t)(fVar50 + *(float *)(iVar26 + 0xde0)) << 0x20;
        func_0x00018013c3d0(&iStack_1e0);
        *(uint32_t *)(iVar26 + 0x1f84) = *(uint32_t *)(iVar26 + 0x1f84) | 0x100001;
        func_0x0001800fea60();
        uStack_224 = uStack_224 | *(uint32_t *)(iVar26 + 0x1fc0) & 0x80;
        func_0x00018010c110();
        iVar33 = *(int32_t *)(iVar26 + 0x1fb8);
        if ((iVar33 == 0) ||
           (iVar23 = func_0x0001800f5a90(0x180645a58, 0, 
                                         *(undefined4 *)
                                          (*(int64_t *)(iVar28 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar28 + 0x148) * 4
                                          )), uVar34 = uStack_230, iVar33 != iVar23)) {
            *(uint32_t *)(iVar26 + 0x1fb8) = uVar21;
            *(undefined4 *)(iVar26 + 0x1fbc) = uStack_1ec;
            *(uint32_t *)(iVar26 + 0x1fc0) = uStack_224;
            uVar34 = uStack_230;
        }
    }
    if ((arg1_00 != 0) && (var_2ach._4_4_ != 0)) {
        *(undefined8 *)(arg1_00 + 0x20) = 0;
    }
    iVar28 = *(int64_t *)0x180781f28;
    if ((*(char *)(iVar26 + 0x29f8) != '\0') && (uVar34 == 0)) {
        iVar26 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar28 + 0x2a20) = 0;
        if ((puVar41 == (undefined8 *)0x0) && (puVar41 = puVar36, puVar36 != (undefined8 *)0xffffffffffffffff)) {
            while (*(char *)puVar41 != '\0') {
                puVar38 = (undefined8 *)((int64_t)puVar41 + 1);
                if (((*(char *)puVar41 == '#') && (*(char *)puVar38 == '#')) ||
                   (puVar41 = puVar38, puVar38 == (undefined8 *)0xffffffffffffffff)) break;
            }
        }
        fVar63 = *(float *)(iVar28 + 0xde0);
        if (*(float *)(iVar28 + 0xde0) <= *(float *)(iVar28 + 0xdf0)) {
            fVar63 = *(float *)(iVar28 + 0xdf0);
        }
        fVar50 = *(float *)(iVar28 + 0x2a30);
        *(float *)(iVar28 + 0x2a30) = fStack_254;
        if (fVar63 + fVar50 + 1.0 < fStack_254) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar28 + 0x29f9) = 1;
        }
        func_0x000180112520(&fStack_258, 0x180620384, 0x180620385);
        iVar33 = *(int32_t *)(iVar26 + 0x1e0);
        iVar23 = *(int32_t *)(iVar28 + 0x2a34);
        if (iVar33 < iVar23) {
            *(int32_t *)(iVar28 + 0x2a34) = iVar33;
            iVar23 = iVar33;
        }
        iVar33 = *(int32_t *)(iVar26 + 0x1e0);
        while( true ) {
            puVar27 = (undefined8 *)func_0x000180498a80(puVar36, 10, (int64_t)puVar41 - (int64_t)puVar36);
            puVar38 = puVar41;
            if (puVar27 != (undefined8 *)0x0) {
                puVar38 = puVar27;
            }
            if ((puVar36 == puVar38) && (puVar38 == puVar41)) break;
            iVar40 = (iVar33 - iVar23) * 4;
            if (*(char *)(iVar28 + 0x29f9) == '\0') {
                iVar40 = 1;
            }
            var_2e8h = (int64_t)puVar36;
            func_0x0001801124e0(0x180644f70, iVar40, 0x1805aadb1, (int32_t)puVar38 - (int32_t)puVar36);
            *(undefined *)(iVar28 + 0x29f9) = 0;
            if (*(char *)puVar38 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar28 + 0x29f9) = 1;
            }
            if (puVar38 == puVar41) break;
            puVar36 = (undefined8 *)((int64_t)puVar38 + 1);
        }
        func_0x000180112520(&fStack_258, 0x18061fecc, 0x18061fecd);
        iVar26 = var_2a0h;
    }
    if (0.0 < fStack_1c8) {
        func_0x0001800f6cb0(CONCAT44(fStack_21c + *(float *)(iVar26 + 0xde0), fVar52 + *(float *)(iVar26 + 0xdf4)), 
                            iStack_110, pcStack_118, 0);
    }
    iVar26 = *(int64_t *)0x180781f28;
    if ((var_2b4h._5_1_ != '\0') && ((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) & 0x10000) == 0)) {
        if (((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x1654) == uVar21) ||
            (*(uint32_t *)(*(int64_t *)0x180781f28 + 0x1654) == 0)) &&
           (*(undefined2 *)(*(int64_t *)0x180781f28 + 0x1664) = 0x101, *(uint32_t *)(iVar26 + 0x1684) == uVar21)) {
            *(undefined *)(iVar26 + 0x168c) = 1;
        }
        *(uint32_t *)(iVar26 + 0x1fc0) = *(uint32_t *)(iVar26 + 0x1fc0) | 4;
    }
code_r0x000180143643:
    func_0x000180459870(uStack_e0 ^ (uint64_t)auStackY_308);
    return;
}

// ============================================================
// Function: FUN_180146c70
// Address: 0x180146c70
// Size: 131 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_138h
// WARNING: Variable defined which should be unmapped: var_130h
// WARNING: Variable defined which should be unmapped: var_128h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

uint64_t fcn.180146c70(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_60h,
                      int64_t arg_68h)
{
    char *pcVar1;
    undefined4 *puVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 uVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    char cVar9;
    uint8_t uVar10;
    int32_t iVar11;
    undefined4 uVar12;
    float *pfVar13;
    uint64_t uVar14;
    int64_t iVar15;
    char *pcVar16;
    char cVar17;
    undefined8 uVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_10h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_118h;
    int64_t var_110h;
    float var_108h;
    int64_t var_104h;
    float var_fch;
    int64_t var_f8h;
    uint32_t var_f0h;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    float fStack_d8;
    float fStack_d4;
    uint32_t uStack_d0;
    uint32_t uStack_cc;
    float fStack_c8;
    float fStack_c4;
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    undefined4 uStack_b8;
    float fStack_b4;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar7 = *(int64_t *)0x180781f28;
    uVar14 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar14 + 0x10b) = 1;
    iVar4 = *(int64_t *)(iVar7 + 0x15e0);
    if (*(char *)(iVar4 + 0x10e) != '\0') {
code_r0x000180147424:
        return uVar14 & 0xffffffffffffff00;
    }
    var_10h._0_1_ = (char)placeholder_1;
    var_118h._0_1_ = (char)placeholder_1;
    iVar11 = func_0x0001800f5a90(arg1, 0, *(undefined4 *)
                                           (*(int64_t *)(iVar4 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar4 + 0x148) * 4)
                                );
    pcVar16 = (char *)arg1;
    if (arg1 != -1) {
        while (*pcVar16 != '\0') {
            pcVar1 = pcVar16 + 1;
            if (((*pcVar16 == '#') && (*pcVar1 == '#')) || (pcVar16 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
            break;
        }
    }
    var_138h = CONCAT44(var_138h._4_4_, 0xbf800000);
    func_0x0001800fe0a0(&fStack_c8, arg1, pcVar16, 0, var_138h);
    fVar24 = *(float *)(arg4 + 4);
    if (*(float *)(arg4 + 4) == 0.0) {
        fVar24 = fStack_c4;
    }
    fVar23 = *(float *)arg4;
    if (*(float *)arg4 == 0.0) {
        fVar23 = fStack_c8;
    }
    var_f8h._0_4_ = (float)*(undefined8 *)(iVar4 + 0x158);
    var_f8h = CONCAT44((float)((uint64_t)*(undefined8 *)(iVar4 + 0x158) >> 0x20) + *(float *)(iVar4 + 400), 
                       (float)var_f8h);
    fStack_d8 = fVar23;
    fStack_d4 = fVar24;
    func_0x00018010bbf0(&fStack_d8, 0);
    uVar19 = (uint32_t)arg3;
    var_f0h = uVar19 & 2;
    if ((arg3 & 2U) == 0) {
        pfVar13 = (float *)(iVar4 + 0x2a0);
        var_110h._0_4_ = (float)var_f8h;
    } else {
        pfVar13 = (float *)(iVar4 + 0x2b0);
        var_110h._0_4_ = *(float *)(iVar4 + 0x2a8);
    }
    if (((*(float *)arg4 == 0.0) || ((uVar19 >> 0x18 & 1) != 0)) &&
       (fVar23 = fStack_c8, fStack_c8 <= *pfVar13 - (float)var_110h)) {
        fVar23 = *pfVar13 - (float)var_110h;
    }
    var_110h._4_4_ = var_f8h._4_4_;
    var_104h._0_4_ = var_f8h._4_4_ + fVar24;
    var_108h = fVar23 + (float)var_110h;
    if ((uVar19 >> 0x1a & 1) == 0) {
        if ((arg3 & 2U) == 0) {
            fVar22 = *(float *)(iVar7 + 0xdec);
        } else {
            fVar22 = 0.0;
        }
        var_110h._0_4_ = (float)var_110h - (float)(int32_t)(fVar22 * 0.5);
        fVar21 = (float)(int32_t)(*(float *)(iVar7 + 0xdf0) * 0.5);
        var_108h = (fVar22 - (float)(int32_t)(fVar22 * 0.5)) + var_108h;
        var_110h._4_4_ = var_f8h._4_4_ - fVar21;
        var_104h._0_4_ = (*(float *)(iVar7 + 0xdf0) - fVar21) + (float)var_104h;
    }
    uStack_cc = uVar19 & 8;
    uVar10 = -((arg3 & 8U) != 0) & 0x40;
    if ((arg3 & 2U) == 0) {
        uVar14 = func_0x00018010b530(&var_110h, iVar11, 0, uVar10);
    } else {
        uVar12 = *(undefined4 *)(iVar4 + 0x2b8);
        uVar3 = *(undefined4 *)(iVar4 + 0x2c0);
        *(undefined4 *)(iVar4 + 0x2b8) = *(undefined4 *)(iVar4 + 0x2a8);
        *(undefined4 *)(iVar4 + 0x2c0) = *(undefined4 *)(iVar4 + 0x2b0);
        uVar14 = func_0x00018010b530(&var_110h, iVar11, 0, uVar10);
        *(undefined4 *)(iVar4 + 0x2b8) = uVar12;
        *(undefined4 *)(iVar4 + 0x2c0) = uVar3;
    }
    uVar20 = *(uint32_t *)(iVar7 + 0x1fbc) & 0x400000;
    var_118h._4_1_ = (char)uVar14;
    if ((var_118h._4_1_ == '\0') &&
       (((uVar20 == 0 || (*(char *)(iVar7 + 0x25b8) == '\0')) ||
        ((*(float *)(iVar7 + 0x25c8) <= var_110h._4_4_ ||
         ((((float)var_104h < *(float *)(iVar7 + 0x25c0) || (float)var_104h == *(float *)(iVar7 + 0x25c0) ||
           (*(float *)(iVar7 + 0x25c4) <= (float)var_110h)) ||
          (var_108h < *(float *)(iVar7 + 0x25bc) || var_108h == *(float *)(iVar7 + 0x25bc)))))))))
    goto code_r0x000180147424;
    fStack_d8 = (float)(*(uint32_t *)(iVar7 + 0x1f78) & 0x40);
    uStack_d0 = uVar20;
    if (((arg3 & 8U) != 0) && (fStack_d8 == 0.0)) {
        func_0x000180106080();
    }
    if (var_f0h != 0) {
        if (*(int64_t *)(iVar7 + 0x24d0) == 0) {
            if (*(int64_t *)(iVar4 + 0x208) != 0) {
                func_0x000180138b90();
            }
        } else {
            func_0x0001801374d0();
        }
        *(uint32_t *)(iVar7 + 0x1fc0) = *(uint32_t *)(iVar7 + 0x1fc0) | 0x200;
        uVar12 = *(undefined4 *)(iVar4 + 700);
        uVar3 = *(undefined4 *)(iVar4 + 0x2c0);
        uVar5 = *(undefined4 *)(iVar4 + 0x2c4);
        *(undefined4 *)(iVar7 + 0x1ff4) = *(undefined4 *)(iVar4 + 0x2b8);
        *(undefined4 *)(iVar7 + 0x1ff8) = uVar12;
        *(undefined4 *)(iVar7 + 0x1ffc) = uVar3;
        *(undefined4 *)(iVar7 + 0x2000) = uVar5;
    }
    cVar8 = (char)var_118h;
    fVar21 = 0.0;
    fVar22 = 0.0;
    var_104h._4_4_ = 0.0;
    if ((uVar19 >> 0x14 & 1) != 0) {
        fVar21 = 1.83671e-40;
        var_104h._4_4_ = 1.83671e-40;
        fVar22 = 1.83671e-40;
    }
    if ((uVar19 >> 0x1b & 1) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x100000);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if ((uVar19 >> 0x16 & 1) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x10);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if ((uVar19 >> 0x17 & 1) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x80);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if ((arg3 & 4U) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x120);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if (((arg3 & 0x10U) != 0) || ((*(uint32_t *)(iVar7 + 0x1fbc) & 0x4000) != 0)) {
        fVar21 = (float)((uint32_t)fVar22 | 0x1000);
        var_104h._4_4_ = fVar21;
    }
    if (uVar20 == 0) {
        var_138h = CONCAT44(var_138h._4_4_, fVar21);
        uVar10 = func_0x000180139d40(&var_110h, iVar11, (int64_t)&var_118h + 1, (int64_t)&var_118h + 5, var_138h);
        if (((((arg3 & 0x40U) == 0) || (*(int32_t *)(iVar7 + 0x23a4) == 0)) ||
            (*(int32_t *)(iVar7 + 0x23a8) != *(int32_t *)(iVar7 + 0x1f74))) ||
           ((*(int32_t *)(iVar7 + 0x23a4) != iVar11 || ((*(uint32_t *)(iVar7 + 0x23ac) & 0x1000) != 0))))
        goto code_r0x000180147188;
        uVar10 = 1;
        var_118h._2_1_ = '\x01';
        var_118h._0_1_ = '\x01';
code_r0x0001801471a3:
        if ((*(char *)(iVar7 + 0x21cd) == '\0') &&
           ((*(int64_t *)(iVar7 + 0x21d8) == iVar4 && (*(int32_t *)(iVar7 + 0x21e4) == *(int32_t *)(iVar4 + 0x1b0))))) {
            var_e8h._0_4_ = (float)var_110h - *(float *)(iVar4 + 0x168);
            var_e8h._4_4_ = var_110h._4_4_ - *(float *)(iVar4 + 0x16c);
            var_e0h = var_108h - *(float *)(iVar4 + 0x168);
            var_dch = (float)var_104h - *(float *)(iVar4 + 0x16c);
            func_0x00018010e3f0(iVar11, *(int32_t *)(iVar4 + 0x1b0), *(undefined4 *)(iVar7 + 0x1f74), &var_e8h);
            if (*(char *)(iVar7 + 0x7e) != '\0') {
                *(undefined *)(iVar7 + 0x21cc) = 0;
            }
        }
        cVar17 = (char)var_118h;
        if (uVar10 != 0) {
            func_0x0001800fa060();
        }
    } else {
        func_0x0001801475c0(iVar11, &var_10h, (int64_t)&var_104h + 4);
        var_138h = CONCAT44(var_138h._4_4_, var_104h._4_4_);
        var_118h._3_1_ =
             func_0x000180139d40(&var_110h, iVar11, (int64_t)&var_118h + 1, (int64_t)&var_118h + 5, var_138h);
        func_0x0001801476e0(iVar11, &var_10h, (int64_t)&var_118h + 3);
        var_118h._0_1_ = (char)var_10h;
        uVar10 = var_118h._3_1_;
code_r0x000180147188:
        var_118h._2_1_ = '\0';
        if ((uVar10 != 0) || ((cVar17 = (char)var_118h, var_118h._1_1_ != '\0' && ((uVar19 >> 0x19 & 1) != 0))))
        goto code_r0x0001801471a3;
    }
    cVar9 = var_118h._4_1_;
    if (cVar17 != cVar8) {
        *(uint32_t *)(iVar7 + 0x1fc0) = *(uint32_t *)(iVar7 + 0x1fc0) | 8;
    }
    if (var_118h._4_1_ == '\0') goto code_r0x00018014735e;
    if ((var_118h._1_1_ == '\0') && ((arg3 & 0x20U) == 0)) {
        if (cVar17 != '\0') {
            bVar6 = false;
            iVar15 = 0;
            goto code_r0x00018014728d;
        }
    } else {
        bVar6 = true;
        iVar15 = 1;
code_r0x00018014728d:
        if ((var_118h._5_1_ == '\0') || (!bVar6)) {
            iVar15 = (iVar15 + 0x2c) * 0x10;
        } else {
            iVar15 = 0x2e0;
        }
        var_fch = (float)var_104h;
        var_e8h._4_4_ = var_110h._4_4_;
        puVar2 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + iVar15);
        uStack_c0 = *puVar2;
        uStack_bc = puVar2[1];
        uStack_b8 = puVar2[2];
        fStack_b4 = (float)puVar2[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        var_104h._4_4_ = var_108h;
        var_e8h._0_4_ = (float)var_110h;
        iVar15 = *(int64_t *)0x180781f28;
        uVar12 = func_0x0001800f5fa0(&uStack_c0);
        var_130h = var_130h & 0xffffffff00000000;
        var_138h = var_138h & 0xffffffff00000000;
        func_0x000180126550(*(undefined8 *)(*(int64_t *)(iVar15 + 0x15e0) + 800), &var_e8h, (int64_t)&var_104h + 4, 
                            uVar12, var_138h, var_130h);
    }
    if (*(int32_t *)(iVar7 + 0x21d0) == iVar11) {
        uVar18 = 0xe;
        if (uStack_d0 == 0) {
            uVar18 = 10;
        }
        func_0x0001800f7d00(&var_110h, iVar11, uVar18);
    }
code_r0x00018014735e:
    if (var_f0h != 0) {
        if (*(int64_t *)(iVar7 + 0x24d0) == 0) {
            if (*(int64_t *)(iVar4 + 0x208) != 0) {
                func_0x000180138c50();
            }
        } else {
            func_0x000180137590();
        }
    }
    if (cVar9 != '\0') {
        var_e8h._4_4_ = fVar24 + var_f8h._4_4_;
        var_e8h._0_4_ = fVar23 + (float)var_f8h;
        if (*(float *)(iVar4 + 0x2a0) <= fVar23 + (float)var_f8h) {
            var_e8h._0_4_ = *(float *)(iVar4 + 0x2a0);
        }
        func_0x0001800f7200(&var_f8h, &var_e8h, arg1, pcVar16, &fStack_c8, iVar7 + 0xe88, &var_110h);
    }
    if ((((uVar10 != 0) && (var_118h._2_1_ == '\0')) && ((*(uint32_t *)(iVar4 + 0x14) & 0x4000000) != 0)) &&
       (((arg3 & 1U) == 0 && ((*(uint8_t *)(iVar7 + 0x1fbc) & 0x10) != 0)))) {
        func_0x00018010d400();
    }
    if ((uStack_cc != 0) && (fStack_d8 == 0.0)) {
        func_0x000180106130();
    }
    return (uint64_t)uVar10;
}

// ============================================================
// Function: FUN_180146cf3
// Address: 0x180146cf3
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_138h
// WARNING: Variable defined which should be unmapped: var_130h
// WARNING: Variable defined which should be unmapped: var_128h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

uint64_t fcn.180146c70(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_60h,
                      int64_t arg_68h)
{
    char *pcVar1;
    undefined4 *puVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 uVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    char cVar9;
    uint8_t uVar10;
    int32_t iVar11;
    undefined4 uVar12;
    float *pfVar13;
    uint64_t uVar14;
    int64_t iVar15;
    char *pcVar16;
    char cVar17;
    undefined8 uVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_10h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_118h;
    int64_t var_110h;
    float var_108h;
    int64_t var_104h;
    float var_fch;
    int64_t var_f8h;
    uint32_t var_f0h;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    float fStack_d8;
    float fStack_d4;
    uint32_t uStack_d0;
    uint32_t uStack_cc;
    float fStack_c8;
    float fStack_c4;
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    undefined4 uStack_b8;
    float fStack_b4;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar7 = *(int64_t *)0x180781f28;
    uVar14 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar14 + 0x10b) = 1;
    iVar4 = *(int64_t *)(iVar7 + 0x15e0);
    if (*(char *)(iVar4 + 0x10e) != '\0') {
code_r0x000180147424:
        return uVar14 & 0xffffffffffffff00;
    }
    var_10h._0_1_ = (char)placeholder_1;
    var_118h._0_1_ = (char)placeholder_1;
    iVar11 = func_0x0001800f5a90(arg1, 0, *(undefined4 *)
                                           (*(int64_t *)(iVar4 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar4 + 0x148) * 4)
                                );
    pcVar16 = (char *)arg1;
    if (arg1 != -1) {
        while (*pcVar16 != '\0') {
            pcVar1 = pcVar16 + 1;
            if (((*pcVar16 == '#') && (*pcVar1 == '#')) || (pcVar16 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
            break;
        }
    }
    var_138h = CONCAT44(var_138h._4_4_, 0xbf800000);
    func_0x0001800fe0a0(&fStack_c8, arg1, pcVar16, 0, var_138h);
    fVar24 = *(float *)(arg4 + 4);
    if (*(float *)(arg4 + 4) == 0.0) {
        fVar24 = fStack_c4;
    }
    fVar23 = *(float *)arg4;
    if (*(float *)arg4 == 0.0) {
        fVar23 = fStack_c8;
    }
    var_f8h._0_4_ = (float)*(undefined8 *)(iVar4 + 0x158);
    var_f8h = CONCAT44((float)((uint64_t)*(undefined8 *)(iVar4 + 0x158) >> 0x20) + *(float *)(iVar4 + 400), 
                       (float)var_f8h);
    fStack_d8 = fVar23;
    fStack_d4 = fVar24;
    func_0x00018010bbf0(&fStack_d8, 0);
    uVar19 = (uint32_t)arg3;
    var_f0h = uVar19 & 2;
    if ((arg3 & 2U) == 0) {
        pfVar13 = (float *)(iVar4 + 0x2a0);
        var_110h._0_4_ = (float)var_f8h;
    } else {
        pfVar13 = (float *)(iVar4 + 0x2b0);
        var_110h._0_4_ = *(float *)(iVar4 + 0x2a8);
    }
    if (((*(float *)arg4 == 0.0) || ((uVar19 >> 0x18 & 1) != 0)) &&
       (fVar23 = fStack_c8, fStack_c8 <= *pfVar13 - (float)var_110h)) {
        fVar23 = *pfVar13 - (float)var_110h;
    }
    var_110h._4_4_ = var_f8h._4_4_;
    var_104h._0_4_ = var_f8h._4_4_ + fVar24;
    var_108h = fVar23 + (float)var_110h;
    if ((uVar19 >> 0x1a & 1) == 0) {
        if ((arg3 & 2U) == 0) {
            fVar22 = *(float *)(iVar7 + 0xdec);
        } else {
            fVar22 = 0.0;
        }
        var_110h._0_4_ = (float)var_110h - (float)(int32_t)(fVar22 * 0.5);
        fVar21 = (float)(int32_t)(*(float *)(iVar7 + 0xdf0) * 0.5);
        var_108h = (fVar22 - (float)(int32_t)(fVar22 * 0.5)) + var_108h;
        var_110h._4_4_ = var_f8h._4_4_ - fVar21;
        var_104h._0_4_ = (*(float *)(iVar7 + 0xdf0) - fVar21) + (float)var_104h;
    }
    uStack_cc = uVar19 & 8;
    uVar10 = -((arg3 & 8U) != 0) & 0x40;
    if ((arg3 & 2U) == 0) {
        uVar14 = func_0x00018010b530(&var_110h, iVar11, 0, uVar10);
    } else {
        uVar12 = *(undefined4 *)(iVar4 + 0x2b8);
        uVar3 = *(undefined4 *)(iVar4 + 0x2c0);
        *(undefined4 *)(iVar4 + 0x2b8) = *(undefined4 *)(iVar4 + 0x2a8);
        *(undefined4 *)(iVar4 + 0x2c0) = *(undefined4 *)(iVar4 + 0x2b0);
        uVar14 = func_0x00018010b530(&var_110h, iVar11, 0, uVar10);
        *(undefined4 *)(iVar4 + 0x2b8) = uVar12;
        *(undefined4 *)(iVar4 + 0x2c0) = uVar3;
    }
    uVar20 = *(uint32_t *)(iVar7 + 0x1fbc) & 0x400000;
    var_118h._4_1_ = (char)uVar14;
    if ((var_118h._4_1_ == '\0') &&
       (((uVar20 == 0 || (*(char *)(iVar7 + 0x25b8) == '\0')) ||
        ((*(float *)(iVar7 + 0x25c8) <= var_110h._4_4_ ||
         ((((float)var_104h < *(float *)(iVar7 + 0x25c0) || (float)var_104h == *(float *)(iVar7 + 0x25c0) ||
           (*(float *)(iVar7 + 0x25c4) <= (float)var_110h)) ||
          (var_108h < *(float *)(iVar7 + 0x25bc) || var_108h == *(float *)(iVar7 + 0x25bc)))))))))
    goto code_r0x000180147424;
    fStack_d8 = (float)(*(uint32_t *)(iVar7 + 0x1f78) & 0x40);
    uStack_d0 = uVar20;
    if (((arg3 & 8U) != 0) && (fStack_d8 == 0.0)) {
        func_0x000180106080();
    }
    if (var_f0h != 0) {
        if (*(int64_t *)(iVar7 + 0x24d0) == 0) {
            if (*(int64_t *)(iVar4 + 0x208) != 0) {
                func_0x000180138b90();
            }
        } else {
            func_0x0001801374d0();
        }
        *(uint32_t *)(iVar7 + 0x1fc0) = *(uint32_t *)(iVar7 + 0x1fc0) | 0x200;
        uVar12 = *(undefined4 *)(iVar4 + 700);
        uVar3 = *(undefined4 *)(iVar4 + 0x2c0);
        uVar5 = *(undefined4 *)(iVar4 + 0x2c4);
        *(undefined4 *)(iVar7 + 0x1ff4) = *(undefined4 *)(iVar4 + 0x2b8);
        *(undefined4 *)(iVar7 + 0x1ff8) = uVar12;
        *(undefined4 *)(iVar7 + 0x1ffc) = uVar3;
        *(undefined4 *)(iVar7 + 0x2000) = uVar5;
    }
    cVar8 = (char)var_118h;
    fVar21 = 0.0;
    fVar22 = 0.0;
    var_104h._4_4_ = 0.0;
    if ((uVar19 >> 0x14 & 1) != 0) {
        fVar21 = 1.83671e-40;
        var_104h._4_4_ = 1.83671e-40;
        fVar22 = 1.83671e-40;
    }
    if ((uVar19 >> 0x1b & 1) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x100000);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if ((uVar19 >> 0x16 & 1) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x10);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if ((uVar19 >> 0x17 & 1) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x80);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if ((arg3 & 4U) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x120);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if (((arg3 & 0x10U) != 0) || ((*(uint32_t *)(iVar7 + 0x1fbc) & 0x4000) != 0)) {
        fVar21 = (float)((uint32_t)fVar22 | 0x1000);
        var_104h._4_4_ = fVar21;
    }
    if (uVar20 == 0) {
        var_138h = CONCAT44(var_138h._4_4_, fVar21);
        uVar10 = func_0x000180139d40(&var_110h, iVar11, (int64_t)&var_118h + 1, (int64_t)&var_118h + 5, var_138h);
        if (((((arg3 & 0x40U) == 0) || (*(int32_t *)(iVar7 + 0x23a4) == 0)) ||
            (*(int32_t *)(iVar7 + 0x23a8) != *(int32_t *)(iVar7 + 0x1f74))) ||
           ((*(int32_t *)(iVar7 + 0x23a4) != iVar11 || ((*(uint32_t *)(iVar7 + 0x23ac) & 0x1000) != 0))))
        goto code_r0x000180147188;
        uVar10 = 1;
        var_118h._2_1_ = '\x01';
        var_118h._0_1_ = '\x01';
code_r0x0001801471a3:
        if ((*(char *)(iVar7 + 0x21cd) == '\0') &&
           ((*(int64_t *)(iVar7 + 0x21d8) == iVar4 && (*(int32_t *)(iVar7 + 0x21e4) == *(int32_t *)(iVar4 + 0x1b0))))) {
            var_e8h._0_4_ = (float)var_110h - *(float *)(iVar4 + 0x168);
            var_e8h._4_4_ = var_110h._4_4_ - *(float *)(iVar4 + 0x16c);
            var_e0h = var_108h - *(float *)(iVar4 + 0x168);
            var_dch = (float)var_104h - *(float *)(iVar4 + 0x16c);
            func_0x00018010e3f0(iVar11, *(int32_t *)(iVar4 + 0x1b0), *(undefined4 *)(iVar7 + 0x1f74), &var_e8h);
            if (*(char *)(iVar7 + 0x7e) != '\0') {
                *(undefined *)(iVar7 + 0x21cc) = 0;
            }
        }
        cVar17 = (char)var_118h;
        if (uVar10 != 0) {
            func_0x0001800fa060();
        }
    } else {
        func_0x0001801475c0(iVar11, &var_10h, (int64_t)&var_104h + 4);
        var_138h = CONCAT44(var_138h._4_4_, var_104h._4_4_);
        var_118h._3_1_ =
             func_0x000180139d40(&var_110h, iVar11, (int64_t)&var_118h + 1, (int64_t)&var_118h + 5, var_138h);
        func_0x0001801476e0(iVar11, &var_10h, (int64_t)&var_118h + 3);
        var_118h._0_1_ = (char)var_10h;
        uVar10 = var_118h._3_1_;
code_r0x000180147188:
        var_118h._2_1_ = '\0';
        if ((uVar10 != 0) || ((cVar17 = (char)var_118h, var_118h._1_1_ != '\0' && ((uVar19 >> 0x19 & 1) != 0))))
        goto code_r0x0001801471a3;
    }
    cVar9 = var_118h._4_1_;
    if (cVar17 != cVar8) {
        *(uint32_t *)(iVar7 + 0x1fc0) = *(uint32_t *)(iVar7 + 0x1fc0) | 8;
    }
    if (var_118h._4_1_ == '\0') goto code_r0x00018014735e;
    if ((var_118h._1_1_ == '\0') && ((arg3 & 0x20U) == 0)) {
        if (cVar17 != '\0') {
            bVar6 = false;
            iVar15 = 0;
            goto code_r0x00018014728d;
        }
    } else {
        bVar6 = true;
        iVar15 = 1;
code_r0x00018014728d:
        if ((var_118h._5_1_ == '\0') || (!bVar6)) {
            iVar15 = (iVar15 + 0x2c) * 0x10;
        } else {
            iVar15 = 0x2e0;
        }
        var_fch = (float)var_104h;
        var_e8h._4_4_ = var_110h._4_4_;
        puVar2 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + iVar15);
        uStack_c0 = *puVar2;
        uStack_bc = puVar2[1];
        uStack_b8 = puVar2[2];
        fStack_b4 = (float)puVar2[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        var_104h._4_4_ = var_108h;
        var_e8h._0_4_ = (float)var_110h;
        iVar15 = *(int64_t *)0x180781f28;
        uVar12 = func_0x0001800f5fa0(&uStack_c0);
        var_130h = var_130h & 0xffffffff00000000;
        var_138h = var_138h & 0xffffffff00000000;
        func_0x000180126550(*(undefined8 *)(*(int64_t *)(iVar15 + 0x15e0) + 800), &var_e8h, (int64_t)&var_104h + 4, 
                            uVar12, var_138h, var_130h);
    }
    if (*(int32_t *)(iVar7 + 0x21d0) == iVar11) {
        uVar18 = 0xe;
        if (uStack_d0 == 0) {
            uVar18 = 10;
        }
        func_0x0001800f7d00(&var_110h, iVar11, uVar18);
    }
code_r0x00018014735e:
    if (var_f0h != 0) {
        if (*(int64_t *)(iVar7 + 0x24d0) == 0) {
            if (*(int64_t *)(iVar4 + 0x208) != 0) {
                func_0x000180138c50();
            }
        } else {
            func_0x000180137590();
        }
    }
    if (cVar9 != '\0') {
        var_e8h._4_4_ = fVar24 + var_f8h._4_4_;
        var_e8h._0_4_ = fVar23 + (float)var_f8h;
        if (*(float *)(iVar4 + 0x2a0) <= fVar23 + (float)var_f8h) {
            var_e8h._0_4_ = *(float *)(iVar4 + 0x2a0);
        }
        func_0x0001800f7200(&var_f8h, &var_e8h, arg1, pcVar16, &fStack_c8, iVar7 + 0xe88, &var_110h);
    }
    if ((((uVar10 != 0) && (var_118h._2_1_ == '\0')) && ((*(uint32_t *)(iVar4 + 0x14) & 0x4000000) != 0)) &&
       (((arg3 & 1U) == 0 && ((*(uint8_t *)(iVar7 + 0x1fbc) & 0x10) != 0)))) {
        func_0x00018010d400();
    }
    if ((uStack_cc != 0) && (fStack_d8 == 0.0)) {
        func_0x000180106130();
    }
    return (uint64_t)uVar10;
}

// ============================================================
// Function: FUN_180146cfd
// Address: 0x180146cfd
// Size: 517 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_138h
// WARNING: Variable defined which should be unmapped: var_130h
// WARNING: Variable defined which should be unmapped: var_128h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

uint64_t fcn.180146c70(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_60h,
                      int64_t arg_68h)
{
    char *pcVar1;
    undefined4 *puVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 uVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    char cVar9;
    uint8_t uVar10;
    int32_t iVar11;
    undefined4 uVar12;
    float *pfVar13;
    uint64_t uVar14;
    int64_t iVar15;
    char *pcVar16;
    char cVar17;
    undefined8 uVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_10h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_118h;
    int64_t var_110h;
    float var_108h;
    int64_t var_104h;
    float var_fch;
    int64_t var_f8h;
    uint32_t var_f0h;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    float fStack_d8;
    float fStack_d4;
    uint32_t uStack_d0;
    uint32_t uStack_cc;
    float fStack_c8;
    float fStack_c4;
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    undefined4 uStack_b8;
    float fStack_b4;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar7 = *(int64_t *)0x180781f28;
    uVar14 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar14 + 0x10b) = 1;
    iVar4 = *(int64_t *)(iVar7 + 0x15e0);
    if (*(char *)(iVar4 + 0x10e) != '\0') {
code_r0x000180147424:
        return uVar14 & 0xffffffffffffff00;
    }
    var_10h._0_1_ = (char)placeholder_1;
    var_118h._0_1_ = (char)placeholder_1;
    iVar11 = func_0x0001800f5a90(arg1, 0, *(undefined4 *)
                                           (*(int64_t *)(iVar4 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar4 + 0x148) * 4)
                                );
    pcVar16 = (char *)arg1;
    if (arg1 != -1) {
        while (*pcVar16 != '\0') {
            pcVar1 = pcVar16 + 1;
            if (((*pcVar16 == '#') && (*pcVar1 == '#')) || (pcVar16 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
            break;
        }
    }
    var_138h = CONCAT44(var_138h._4_4_, 0xbf800000);
    func_0x0001800fe0a0(&fStack_c8, arg1, pcVar16, 0, var_138h);
    fVar24 = *(float *)(arg4 + 4);
    if (*(float *)(arg4 + 4) == 0.0) {
        fVar24 = fStack_c4;
    }
    fVar23 = *(float *)arg4;
    if (*(float *)arg4 == 0.0) {
        fVar23 = fStack_c8;
    }
    var_f8h._0_4_ = (float)*(undefined8 *)(iVar4 + 0x158);
    var_f8h = CONCAT44((float)((uint64_t)*(undefined8 *)(iVar4 + 0x158) >> 0x20) + *(float *)(iVar4 + 400), 
                       (float)var_f8h);
    fStack_d8 = fVar23;
    fStack_d4 = fVar24;
    func_0x00018010bbf0(&fStack_d8, 0);
    uVar19 = (uint32_t)arg3;
    var_f0h = uVar19 & 2;
    if ((arg3 & 2U) == 0) {
        pfVar13 = (float *)(iVar4 + 0x2a0);
        var_110h._0_4_ = (float)var_f8h;
    } else {
        pfVar13 = (float *)(iVar4 + 0x2b0);
        var_110h._0_4_ = *(float *)(iVar4 + 0x2a8);
    }
    if (((*(float *)arg4 == 0.0) || ((uVar19 >> 0x18 & 1) != 0)) &&
       (fVar23 = fStack_c8, fStack_c8 <= *pfVar13 - (float)var_110h)) {
        fVar23 = *pfVar13 - (float)var_110h;
    }
    var_110h._4_4_ = var_f8h._4_4_;
    var_104h._0_4_ = var_f8h._4_4_ + fVar24;
    var_108h = fVar23 + (float)var_110h;
    if ((uVar19 >> 0x1a & 1) == 0) {
        if ((arg3 & 2U) == 0) {
            fVar22 = *(float *)(iVar7 + 0xdec);
        } else {
            fVar22 = 0.0;
        }
        var_110h._0_4_ = (float)var_110h - (float)(int32_t)(fVar22 * 0.5);
        fVar21 = (float)(int32_t)(*(float *)(iVar7 + 0xdf0) * 0.5);
        var_108h = (fVar22 - (float)(int32_t)(fVar22 * 0.5)) + var_108h;
        var_110h._4_4_ = var_f8h._4_4_ - fVar21;
        var_104h._0_4_ = (*(float *)(iVar7 + 0xdf0) - fVar21) + (float)var_104h;
    }
    uStack_cc = uVar19 & 8;
    uVar10 = -((arg3 & 8U) != 0) & 0x40;
    if ((arg3 & 2U) == 0) {
        uVar14 = func_0x00018010b530(&var_110h, iVar11, 0, uVar10);
    } else {
        uVar12 = *(undefined4 *)(iVar4 + 0x2b8);
        uVar3 = *(undefined4 *)(iVar4 + 0x2c0);
        *(undefined4 *)(iVar4 + 0x2b8) = *(undefined4 *)(iVar4 + 0x2a8);
        *(undefined4 *)(iVar4 + 0x2c0) = *(undefined4 *)(iVar4 + 0x2b0);
        uVar14 = func_0x00018010b530(&var_110h, iVar11, 0, uVar10);
        *(undefined4 *)(iVar4 + 0x2b8) = uVar12;
        *(undefined4 *)(iVar4 + 0x2c0) = uVar3;
    }
    uVar20 = *(uint32_t *)(iVar7 + 0x1fbc) & 0x400000;
    var_118h._4_1_ = (char)uVar14;
    if ((var_118h._4_1_ == '\0') &&
       (((uVar20 == 0 || (*(char *)(iVar7 + 0x25b8) == '\0')) ||
        ((*(float *)(iVar7 + 0x25c8) <= var_110h._4_4_ ||
         ((((float)var_104h < *(float *)(iVar7 + 0x25c0) || (float)var_104h == *(float *)(iVar7 + 0x25c0) ||
           (*(float *)(iVar7 + 0x25c4) <= (float)var_110h)) ||
          (var_108h < *(float *)(iVar7 + 0x25bc) || var_108h == *(float *)(iVar7 + 0x25bc)))))))))
    goto code_r0x000180147424;
    fStack_d8 = (float)(*(uint32_t *)(iVar7 + 0x1f78) & 0x40);
    uStack_d0 = uVar20;
    if (((arg3 & 8U) != 0) && (fStack_d8 == 0.0)) {
        func_0x000180106080();
    }
    if (var_f0h != 0) {
        if (*(int64_t *)(iVar7 + 0x24d0) == 0) {
            if (*(int64_t *)(iVar4 + 0x208) != 0) {
                func_0x000180138b90();
            }
        } else {
            func_0x0001801374d0();
        }
        *(uint32_t *)(iVar7 + 0x1fc0) = *(uint32_t *)(iVar7 + 0x1fc0) | 0x200;
        uVar12 = *(undefined4 *)(iVar4 + 700);
        uVar3 = *(undefined4 *)(iVar4 + 0x2c0);
        uVar5 = *(undefined4 *)(iVar4 + 0x2c4);
        *(undefined4 *)(iVar7 + 0x1ff4) = *(undefined4 *)(iVar4 + 0x2b8);
        *(undefined4 *)(iVar7 + 0x1ff8) = uVar12;
        *(undefined4 *)(iVar7 + 0x1ffc) = uVar3;
        *(undefined4 *)(iVar7 + 0x2000) = uVar5;
    }
    cVar8 = (char)var_118h;
    fVar21 = 0.0;
    fVar22 = 0.0;
    var_104h._4_4_ = 0.0;
    if ((uVar19 >> 0x14 & 1) != 0) {
        fVar21 = 1.83671e-40;
        var_104h._4_4_ = 1.83671e-40;
        fVar22 = 1.83671e-40;
    }
    if ((uVar19 >> 0x1b & 1) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x100000);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if ((uVar19 >> 0x16 & 1) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x10);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if ((uVar19 >> 0x17 & 1) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x80);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if ((arg3 & 4U) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x120);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if (((arg3 & 0x10U) != 0) || ((*(uint32_t *)(iVar7 + 0x1fbc) & 0x4000) != 0)) {
        fVar21 = (float)((uint32_t)fVar22 | 0x1000);
        var_104h._4_4_ = fVar21;
    }
    if (uVar20 == 0) {
        var_138h = CONCAT44(var_138h._4_4_, fVar21);
        uVar10 = func_0x000180139d40(&var_110h, iVar11, (int64_t)&var_118h + 1, (int64_t)&var_118h + 5, var_138h);
        if (((((arg3 & 0x40U) == 0) || (*(int32_t *)(iVar7 + 0x23a4) == 0)) ||
            (*(int32_t *)(iVar7 + 0x23a8) != *(int32_t *)(iVar7 + 0x1f74))) ||
           ((*(int32_t *)(iVar7 + 0x23a4) != iVar11 || ((*(uint32_t *)(iVar7 + 0x23ac) & 0x1000) != 0))))
        goto code_r0x000180147188;
        uVar10 = 1;
        var_118h._2_1_ = '\x01';
        var_118h._0_1_ = '\x01';
code_r0x0001801471a3:
        if ((*(char *)(iVar7 + 0x21cd) == '\0') &&
           ((*(int64_t *)(iVar7 + 0x21d8) == iVar4 && (*(int32_t *)(iVar7 + 0x21e4) == *(int32_t *)(iVar4 + 0x1b0))))) {
            var_e8h._0_4_ = (float)var_110h - *(float *)(iVar4 + 0x168);
            var_e8h._4_4_ = var_110h._4_4_ - *(float *)(iVar4 + 0x16c);
            var_e0h = var_108h - *(float *)(iVar4 + 0x168);
            var_dch = (float)var_104h - *(float *)(iVar4 + 0x16c);
            func_0x00018010e3f0(iVar11, *(int32_t *)(iVar4 + 0x1b0), *(undefined4 *)(iVar7 + 0x1f74), &var_e8h);
            if (*(char *)(iVar7 + 0x7e) != '\0') {
                *(undefined *)(iVar7 + 0x21cc) = 0;
            }
        }
        cVar17 = (char)var_118h;
        if (uVar10 != 0) {
            func_0x0001800fa060();
        }
    } else {
        func_0x0001801475c0(iVar11, &var_10h, (int64_t)&var_104h + 4);
        var_138h = CONCAT44(var_138h._4_4_, var_104h._4_4_);
        var_118h._3_1_ =
             func_0x000180139d40(&var_110h, iVar11, (int64_t)&var_118h + 1, (int64_t)&var_118h + 5, var_138h);
        func_0x0001801476e0(iVar11, &var_10h, (int64_t)&var_118h + 3);
        var_118h._0_1_ = (char)var_10h;
        uVar10 = var_118h._3_1_;
code_r0x000180147188:
        var_118h._2_1_ = '\0';
        if ((uVar10 != 0) || ((cVar17 = (char)var_118h, var_118h._1_1_ != '\0' && ((uVar19 >> 0x19 & 1) != 0))))
        goto code_r0x0001801471a3;
    }
    cVar9 = var_118h._4_1_;
    if (cVar17 != cVar8) {
        *(uint32_t *)(iVar7 + 0x1fc0) = *(uint32_t *)(iVar7 + 0x1fc0) | 8;
    }
    if (var_118h._4_1_ == '\0') goto code_r0x00018014735e;
    if ((var_118h._1_1_ == '\0') && ((arg3 & 0x20U) == 0)) {
        if (cVar17 != '\0') {
            bVar6 = false;
            iVar15 = 0;
            goto code_r0x00018014728d;
        }
    } else {
        bVar6 = true;
        iVar15 = 1;
code_r0x00018014728d:
        if ((var_118h._5_1_ == '\0') || (!bVar6)) {
            iVar15 = (iVar15 + 0x2c) * 0x10;
        } else {
            iVar15 = 0x2e0;
        }
        var_fch = (float)var_104h;
        var_e8h._4_4_ = var_110h._4_4_;
        puVar2 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + iVar15);
        uStack_c0 = *puVar2;
        uStack_bc = puVar2[1];
        uStack_b8 = puVar2[2];
        fStack_b4 = (float)puVar2[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        var_104h._4_4_ = var_108h;
        var_e8h._0_4_ = (float)var_110h;
        iVar15 = *(int64_t *)0x180781f28;
        uVar12 = func_0x0001800f5fa0(&uStack_c0);
        var_130h = var_130h & 0xffffffff00000000;
        var_138h = var_138h & 0xffffffff00000000;
        func_0x000180126550(*(undefined8 *)(*(int64_t *)(iVar15 + 0x15e0) + 800), &var_e8h, (int64_t)&var_104h + 4, 
                            uVar12, var_138h, var_130h);
    }
    if (*(int32_t *)(iVar7 + 0x21d0) == iVar11) {
        uVar18 = 0xe;
        if (uStack_d0 == 0) {
            uVar18 = 10;
        }
        func_0x0001800f7d00(&var_110h, iVar11, uVar18);
    }
code_r0x00018014735e:
    if (var_f0h != 0) {
        if (*(int64_t *)(iVar7 + 0x24d0) == 0) {
            if (*(int64_t *)(iVar4 + 0x208) != 0) {
                func_0x000180138c50();
            }
        } else {
            func_0x000180137590();
        }
    }
    if (cVar9 != '\0') {
        var_e8h._4_4_ = fVar24 + var_f8h._4_4_;
        var_e8h._0_4_ = fVar23 + (float)var_f8h;
        if (*(float *)(iVar4 + 0x2a0) <= fVar23 + (float)var_f8h) {
            var_e8h._0_4_ = *(float *)(iVar4 + 0x2a0);
        }
        func_0x0001800f7200(&var_f8h, &var_e8h, arg1, pcVar16, &fStack_c8, iVar7 + 0xe88, &var_110h);
    }
    if ((((uVar10 != 0) && (var_118h._2_1_ == '\0')) && ((*(uint32_t *)(iVar4 + 0x14) & 0x4000000) != 0)) &&
       (((arg3 & 1U) == 0 && ((*(uint8_t *)(iVar7 + 0x1fbc) & 0x10) != 0)))) {
        func_0x00018010d400();
    }
    if ((uStack_cc != 0) && (fStack_d8 == 0.0)) {
        func_0x000180106130();
    }
    return (uint64_t)uVar10;
}

// ============================================================
// Function: FUN_180146f02
// Address: 0x180146f02
// Size: 116 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_138h
// WARNING: Variable defined which should be unmapped: var_130h
// WARNING: Variable defined which should be unmapped: var_128h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

uint64_t fcn.180146c70(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_60h,
                      int64_t arg_68h)
{
    char *pcVar1;
    undefined4 *puVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 uVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    char cVar9;
    uint8_t uVar10;
    int32_t iVar11;
    undefined4 uVar12;
    float *pfVar13;
    uint64_t uVar14;
    int64_t iVar15;
    char *pcVar16;
    char cVar17;
    undefined8 uVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_10h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_118h;
    int64_t var_110h;
    float var_108h;
    int64_t var_104h;
    float var_fch;
    int64_t var_f8h;
    uint32_t var_f0h;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    float fStack_d8;
    float fStack_d4;
    uint32_t uStack_d0;
    uint32_t uStack_cc;
    float fStack_c8;
    float fStack_c4;
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    undefined4 uStack_b8;
    float fStack_b4;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar7 = *(int64_t *)0x180781f28;
    uVar14 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar14 + 0x10b) = 1;
    iVar4 = *(int64_t *)(iVar7 + 0x15e0);
    if (*(char *)(iVar4 + 0x10e) != '\0') {
code_r0x000180147424:
        return uVar14 & 0xffffffffffffff00;
    }
    var_10h._0_1_ = (char)placeholder_1;
    var_118h._0_1_ = (char)placeholder_1;
    iVar11 = func_0x0001800f5a90(arg1, 0, *(undefined4 *)
                                           (*(int64_t *)(iVar4 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar4 + 0x148) * 4)
                                );
    pcVar16 = (char *)arg1;
    if (arg1 != -1) {
        while (*pcVar16 != '\0') {
            pcVar1 = pcVar16 + 1;
            if (((*pcVar16 == '#') && (*pcVar1 == '#')) || (pcVar16 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
            break;
        }
    }
    var_138h = CONCAT44(var_138h._4_4_, 0xbf800000);
    func_0x0001800fe0a0(&fStack_c8, arg1, pcVar16, 0, var_138h);
    fVar24 = *(float *)(arg4 + 4);
    if (*(float *)(arg4 + 4) == 0.0) {
        fVar24 = fStack_c4;
    }
    fVar23 = *(float *)arg4;
    if (*(float *)arg4 == 0.0) {
        fVar23 = fStack_c8;
    }
    var_f8h._0_4_ = (float)*(undefined8 *)(iVar4 + 0x158);
    var_f8h = CONCAT44((float)((uint64_t)*(undefined8 *)(iVar4 + 0x158) >> 0x20) + *(float *)(iVar4 + 400), 
                       (float)var_f8h);
    fStack_d8 = fVar23;
    fStack_d4 = fVar24;
    func_0x00018010bbf0(&fStack_d8, 0);
    uVar19 = (uint32_t)arg3;
    var_f0h = uVar19 & 2;
    if ((arg3 & 2U) == 0) {
        pfVar13 = (float *)(iVar4 + 0x2a0);
        var_110h._0_4_ = (float)var_f8h;
    } else {
        pfVar13 = (float *)(iVar4 + 0x2b0);
        var_110h._0_4_ = *(float *)(iVar4 + 0x2a8);
    }
    if (((*(float *)arg4 == 0.0) || ((uVar19 >> 0x18 & 1) != 0)) &&
       (fVar23 = fStack_c8, fStack_c8 <= *pfVar13 - (float)var_110h)) {
        fVar23 = *pfVar13 - (float)var_110h;
    }
    var_110h._4_4_ = var_f8h._4_4_;
    var_104h._0_4_ = var_f8h._4_4_ + fVar24;
    var_108h = fVar23 + (float)var_110h;
    if ((uVar19 >> 0x1a & 1) == 0) {
        if ((arg3 & 2U) == 0) {
            fVar22 = *(float *)(iVar7 + 0xdec);
        } else {
            fVar22 = 0.0;
        }
        var_110h._0_4_ = (float)var_110h - (float)(int32_t)(fVar22 * 0.5);
        fVar21 = (float)(int32_t)(*(float *)(iVar7 + 0xdf0) * 0.5);
        var_108h = (fVar22 - (float)(int32_t)(fVar22 * 0.5)) + var_108h;
        var_110h._4_4_ = var_f8h._4_4_ - fVar21;
        var_104h._0_4_ = (*(float *)(iVar7 + 0xdf0) - fVar21) + (float)var_104h;
    }
    uStack_cc = uVar19 & 8;
    uVar10 = -((arg3 & 8U) != 0) & 0x40;
    if ((arg3 & 2U) == 0) {
        uVar14 = func_0x00018010b530(&var_110h, iVar11, 0, uVar10);
    } else {
        uVar12 = *(undefined4 *)(iVar4 + 0x2b8);
        uVar3 = *(undefined4 *)(iVar4 + 0x2c0);
        *(undefined4 *)(iVar4 + 0x2b8) = *(undefined4 *)(iVar4 + 0x2a8);
        *(undefined4 *)(iVar4 + 0x2c0) = *(undefined4 *)(iVar4 + 0x2b0);
        uVar14 = func_0x00018010b530(&var_110h, iVar11, 0, uVar10);
        *(undefined4 *)(iVar4 + 0x2b8) = uVar12;
        *(undefined4 *)(iVar4 + 0x2c0) = uVar3;
    }
    uVar20 = *(uint32_t *)(iVar7 + 0x1fbc) & 0x400000;
    var_118h._4_1_ = (char)uVar14;
    if ((var_118h._4_1_ == '\0') &&
       (((uVar20 == 0 || (*(char *)(iVar7 + 0x25b8) == '\0')) ||
        ((*(float *)(iVar7 + 0x25c8) <= var_110h._4_4_ ||
         ((((float)var_104h < *(float *)(iVar7 + 0x25c0) || (float)var_104h == *(float *)(iVar7 + 0x25c0) ||
           (*(float *)(iVar7 + 0x25c4) <= (float)var_110h)) ||
          (var_108h < *(float *)(iVar7 + 0x25bc) || var_108h == *(float *)(iVar7 + 0x25bc)))))))))
    goto code_r0x000180147424;
    fStack_d8 = (float)(*(uint32_t *)(iVar7 + 0x1f78) & 0x40);
    uStack_d0 = uVar20;
    if (((arg3 & 8U) != 0) && (fStack_d8 == 0.0)) {
        func_0x000180106080();
    }
    if (var_f0h != 0) {
        if (*(int64_t *)(iVar7 + 0x24d0) == 0) {
            if (*(int64_t *)(iVar4 + 0x208) != 0) {
                func_0x000180138b90();
            }
        } else {
            func_0x0001801374d0();
        }
        *(uint32_t *)(iVar7 + 0x1fc0) = *(uint32_t *)(iVar7 + 0x1fc0) | 0x200;
        uVar12 = *(undefined4 *)(iVar4 + 700);
        uVar3 = *(undefined4 *)(iVar4 + 0x2c0);
        uVar5 = *(undefined4 *)(iVar4 + 0x2c4);
        *(undefined4 *)(iVar7 + 0x1ff4) = *(undefined4 *)(iVar4 + 0x2b8);
        *(undefined4 *)(iVar7 + 0x1ff8) = uVar12;
        *(undefined4 *)(iVar7 + 0x1ffc) = uVar3;
        *(undefined4 *)(iVar7 + 0x2000) = uVar5;
    }
    cVar8 = (char)var_118h;
    fVar21 = 0.0;
    fVar22 = 0.0;
    var_104h._4_4_ = 0.0;
    if ((uVar19 >> 0x14 & 1) != 0) {
        fVar21 = 1.83671e-40;
        var_104h._4_4_ = 1.83671e-40;
        fVar22 = 1.83671e-40;
    }
    if ((uVar19 >> 0x1b & 1) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x100000);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if ((uVar19 >> 0x16 & 1) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x10);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if ((uVar19 >> 0x17 & 1) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x80);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if ((arg3 & 4U) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x120);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if (((arg3 & 0x10U) != 0) || ((*(uint32_t *)(iVar7 + 0x1fbc) & 0x4000) != 0)) {
        fVar21 = (float)((uint32_t)fVar22 | 0x1000);
        var_104h._4_4_ = fVar21;
    }
    if (uVar20 == 0) {
        var_138h = CONCAT44(var_138h._4_4_, fVar21);
        uVar10 = func_0x000180139d40(&var_110h, iVar11, (int64_t)&var_118h + 1, (int64_t)&var_118h + 5, var_138h);
        if (((((arg3 & 0x40U) == 0) || (*(int32_t *)(iVar7 + 0x23a4) == 0)) ||
            (*(int32_t *)(iVar7 + 0x23a8) != *(int32_t *)(iVar7 + 0x1f74))) ||
           ((*(int32_t *)(iVar7 + 0x23a4) != iVar11 || ((*(uint32_t *)(iVar7 + 0x23ac) & 0x1000) != 0))))
        goto code_r0x000180147188;
        uVar10 = 1;
        var_118h._2_1_ = '\x01';
        var_118h._0_1_ = '\x01';
code_r0x0001801471a3:
        if ((*(char *)(iVar7 + 0x21cd) == '\0') &&
           ((*(int64_t *)(iVar7 + 0x21d8) == iVar4 && (*(int32_t *)(iVar7 + 0x21e4) == *(int32_t *)(iVar4 + 0x1b0))))) {
            var_e8h._0_4_ = (float)var_110h - *(float *)(iVar4 + 0x168);
            var_e8h._4_4_ = var_110h._4_4_ - *(float *)(iVar4 + 0x16c);
            var_e0h = var_108h - *(float *)(iVar4 + 0x168);
            var_dch = (float)var_104h - *(float *)(iVar4 + 0x16c);
            func_0x00018010e3f0(iVar11, *(int32_t *)(iVar4 + 0x1b0), *(undefined4 *)(iVar7 + 0x1f74), &var_e8h);
            if (*(char *)(iVar7 + 0x7e) != '\0') {
                *(undefined *)(iVar7 + 0x21cc) = 0;
            }
        }
        cVar17 = (char)var_118h;
        if (uVar10 != 0) {
            func_0x0001800fa060();
        }
    } else {
        func_0x0001801475c0(iVar11, &var_10h, (int64_t)&var_104h + 4);
        var_138h = CONCAT44(var_138h._4_4_, var_104h._4_4_);
        var_118h._3_1_ =
             func_0x000180139d40(&var_110h, iVar11, (int64_t)&var_118h + 1, (int64_t)&var_118h + 5, var_138h);
        func_0x0001801476e0(iVar11, &var_10h, (int64_t)&var_118h + 3);
        var_118h._0_1_ = (char)var_10h;
        uVar10 = var_118h._3_1_;
code_r0x000180147188:
        var_118h._2_1_ = '\0';
        if ((uVar10 != 0) || ((cVar17 = (char)var_118h, var_118h._1_1_ != '\0' && ((uVar19 >> 0x19 & 1) != 0))))
        goto code_r0x0001801471a3;
    }
    cVar9 = var_118h._4_1_;
    if (cVar17 != cVar8) {
        *(uint32_t *)(iVar7 + 0x1fc0) = *(uint32_t *)(iVar7 + 0x1fc0) | 8;
    }
    if (var_118h._4_1_ == '\0') goto code_r0x00018014735e;
    if ((var_118h._1_1_ == '\0') && ((arg3 & 0x20U) == 0)) {
        if (cVar17 != '\0') {
            bVar6 = false;
            iVar15 = 0;
            goto code_r0x00018014728d;
        }
    } else {
        bVar6 = true;
        iVar15 = 1;
code_r0x00018014728d:
        if ((var_118h._5_1_ == '\0') || (!bVar6)) {
            iVar15 = (iVar15 + 0x2c) * 0x10;
        } else {
            iVar15 = 0x2e0;
        }
        var_fch = (float)var_104h;
        var_e8h._4_4_ = var_110h._4_4_;
        puVar2 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + iVar15);
        uStack_c0 = *puVar2;
        uStack_bc = puVar2[1];
        uStack_b8 = puVar2[2];
        fStack_b4 = (float)puVar2[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        var_104h._4_4_ = var_108h;
        var_e8h._0_4_ = (float)var_110h;
        iVar15 = *(int64_t *)0x180781f28;
        uVar12 = func_0x0001800f5fa0(&uStack_c0);
        var_130h = var_130h & 0xffffffff00000000;
        var_138h = var_138h & 0xffffffff00000000;
        func_0x000180126550(*(undefined8 *)(*(int64_t *)(iVar15 + 0x15e0) + 800), &var_e8h, (int64_t)&var_104h + 4, 
                            uVar12, var_138h, var_130h);
    }
    if (*(int32_t *)(iVar7 + 0x21d0) == iVar11) {
        uVar18 = 0xe;
        if (uStack_d0 == 0) {
            uVar18 = 10;
        }
        func_0x0001800f7d00(&var_110h, iVar11, uVar18);
    }
code_r0x00018014735e:
    if (var_f0h != 0) {
        if (*(int64_t *)(iVar7 + 0x24d0) == 0) {
            if (*(int64_t *)(iVar4 + 0x208) != 0) {
                func_0x000180138c50();
            }
        } else {
            func_0x000180137590();
        }
    }
    if (cVar9 != '\0') {
        var_e8h._4_4_ = fVar24 + var_f8h._4_4_;
        var_e8h._0_4_ = fVar23 + (float)var_f8h;
        if (*(float *)(iVar4 + 0x2a0) <= fVar23 + (float)var_f8h) {
            var_e8h._0_4_ = *(float *)(iVar4 + 0x2a0);
        }
        func_0x0001800f7200(&var_f8h, &var_e8h, arg1, pcVar16, &fStack_c8, iVar7 + 0xe88, &var_110h);
    }
    if ((((uVar10 != 0) && (var_118h._2_1_ == '\0')) && ((*(uint32_t *)(iVar4 + 0x14) & 0x4000000) != 0)) &&
       (((arg3 & 1U) == 0 && ((*(uint8_t *)(iVar7 + 0x1fbc) & 0x10) != 0)))) {
        func_0x00018010d400();
    }
    if ((uStack_cc != 0) && (fStack_d8 == 0.0)) {
        func_0x000180106130();
    }
    return (uint64_t)uVar10;
}

// ============================================================
// Function: FUN_180146f76
// Address: 0x180146f76
// Size: 1242 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_138h
// WARNING: Variable defined which should be unmapped: var_130h
// WARNING: Variable defined which should be unmapped: var_128h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

uint64_t fcn.180146c70(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_60h,
                      int64_t arg_68h)
{
    char *pcVar1;
    undefined4 *puVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 uVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    char cVar9;
    uint8_t uVar10;
    int32_t iVar11;
    undefined4 uVar12;
    float *pfVar13;
    uint64_t uVar14;
    int64_t iVar15;
    char *pcVar16;
    char cVar17;
    undefined8 uVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_10h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_118h;
    int64_t var_110h;
    float var_108h;
    int64_t var_104h;
    float var_fch;
    int64_t var_f8h;
    uint32_t var_f0h;
    int64_t var_e8h;
    float var_e0h;
    float var_dch;
    float fStack_d8;
    float fStack_d4;
    uint32_t uStack_d0;
    uint32_t uStack_cc;
    float fStack_c8;
    float fStack_c4;
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    undefined4 uStack_b8;
    float fStack_b4;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar7 = *(int64_t *)0x180781f28;
    uVar14 = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined *)(uVar14 + 0x10b) = 1;
    iVar4 = *(int64_t *)(iVar7 + 0x15e0);
    if (*(char *)(iVar4 + 0x10e) != '\0') {
code_r0x000180147424:
        return uVar14 & 0xffffffffffffff00;
    }
    var_10h._0_1_ = (char)placeholder_1;
    var_118h._0_1_ = (char)placeholder_1;
    iVar11 = func_0x0001800f5a90(arg1, 0, *(undefined4 *)
                                           (*(int64_t *)(iVar4 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar4 + 0x148) * 4)
                                );
    pcVar16 = (char *)arg1;
    if (arg1 != -1) {
        while (*pcVar16 != '\0') {
            pcVar1 = pcVar16 + 1;
            if (((*pcVar16 == '#') && (*pcVar1 == '#')) || (pcVar16 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
            break;
        }
    }
    var_138h = CONCAT44(var_138h._4_4_, 0xbf800000);
    func_0x0001800fe0a0(&fStack_c8, arg1, pcVar16, 0, var_138h);
    fVar24 = *(float *)(arg4 + 4);
    if (*(float *)(arg4 + 4) == 0.0) {
        fVar24 = fStack_c4;
    }
    fVar23 = *(float *)arg4;
    if (*(float *)arg4 == 0.0) {
        fVar23 = fStack_c8;
    }
    var_f8h._0_4_ = (float)*(undefined8 *)(iVar4 + 0x158);
    var_f8h = CONCAT44((float)((uint64_t)*(undefined8 *)(iVar4 + 0x158) >> 0x20) + *(float *)(iVar4 + 400), 
                       (float)var_f8h);
    fStack_d8 = fVar23;
    fStack_d4 = fVar24;
    func_0x00018010bbf0(&fStack_d8, 0);
    uVar19 = (uint32_t)arg3;
    var_f0h = uVar19 & 2;
    if ((arg3 & 2U) == 0) {
        pfVar13 = (float *)(iVar4 + 0x2a0);
        var_110h._0_4_ = (float)var_f8h;
    } else {
        pfVar13 = (float *)(iVar4 + 0x2b0);
        var_110h._0_4_ = *(float *)(iVar4 + 0x2a8);
    }
    if (((*(float *)arg4 == 0.0) || ((uVar19 >> 0x18 & 1) != 0)) &&
       (fVar23 = fStack_c8, fStack_c8 <= *pfVar13 - (float)var_110h)) {
        fVar23 = *pfVar13 - (float)var_110h;
    }
    var_110h._4_4_ = var_f8h._4_4_;
    var_104h._0_4_ = var_f8h._4_4_ + fVar24;
    var_108h = fVar23 + (float)var_110h;
    if ((uVar19 >> 0x1a & 1) == 0) {
        if ((arg3 & 2U) == 0) {
            fVar22 = *(float *)(iVar7 + 0xdec);
        } else {
            fVar22 = 0.0;
        }
        var_110h._0_4_ = (float)var_110h - (float)(int32_t)(fVar22 * 0.5);
        fVar21 = (float)(int32_t)(*(float *)(iVar7 + 0xdf0) * 0.5);
        var_108h = (fVar22 - (float)(int32_t)(fVar22 * 0.5)) + var_108h;
        var_110h._4_4_ = var_f8h._4_4_ - fVar21;
        var_104h._0_4_ = (*(float *)(iVar7 + 0xdf0) - fVar21) + (float)var_104h;
    }
    uStack_cc = uVar19 & 8;
    uVar10 = -((arg3 & 8U) != 0) & 0x40;
    if ((arg3 & 2U) == 0) {
        uVar14 = func_0x00018010b530(&var_110h, iVar11, 0, uVar10);
    } else {
        uVar12 = *(undefined4 *)(iVar4 + 0x2b8);
        uVar3 = *(undefined4 *)(iVar4 + 0x2c0);
        *(undefined4 *)(iVar4 + 0x2b8) = *(undefined4 *)(iVar4 + 0x2a8);
        *(undefined4 *)(iVar4 + 0x2c0) = *(undefined4 *)(iVar4 + 0x2b0);
        uVar14 = func_0x00018010b530(&var_110h, iVar11, 0, uVar10);
        *(undefined4 *)(iVar4 + 0x2b8) = uVar12;
        *(undefined4 *)(iVar4 + 0x2c0) = uVar3;
    }
    uVar20 = *(uint32_t *)(iVar7 + 0x1fbc) & 0x400000;
    var_118h._4_1_ = (char)uVar14;
    if ((var_118h._4_1_ == '\0') &&
       (((uVar20 == 0 || (*(char *)(iVar7 + 0x25b8) == '\0')) ||
        ((*(float *)(iVar7 + 0x25c8) <= var_110h._4_4_ ||
         ((((float)var_104h < *(float *)(iVar7 + 0x25c0) || (float)var_104h == *(float *)(iVar7 + 0x25c0) ||
           (*(float *)(iVar7 + 0x25c4) <= (float)var_110h)) ||
          (var_108h < *(float *)(iVar7 + 0x25bc) || var_108h == *(float *)(iVar7 + 0x25bc)))))))))
    goto code_r0x000180147424;
    fStack_d8 = (float)(*(uint32_t *)(iVar7 + 0x1f78) & 0x40);
    uStack_d0 = uVar20;
    if (((arg3 & 8U) != 0) && (fStack_d8 == 0.0)) {
        func_0x000180106080();
    }
    if (var_f0h != 0) {
        if (*(int64_t *)(iVar7 + 0x24d0) == 0) {
            if (*(int64_t *)(iVar4 + 0x208) != 0) {
                func_0x000180138b90();
            }
        } else {
            func_0x0001801374d0();
        }
        *(uint32_t *)(iVar7 + 0x1fc0) = *(uint32_t *)(iVar7 + 0x1fc0) | 0x200;
        uVar12 = *(undefined4 *)(iVar4 + 700);
        uVar3 = *(undefined4 *)(iVar4 + 0x2c0);
        uVar5 = *(undefined4 *)(iVar4 + 0x2c4);
        *(undefined4 *)(iVar7 + 0x1ff4) = *(undefined4 *)(iVar4 + 0x2b8);
        *(undefined4 *)(iVar7 + 0x1ff8) = uVar12;
        *(undefined4 *)(iVar7 + 0x1ffc) = uVar3;
        *(undefined4 *)(iVar7 + 0x2000) = uVar5;
    }
    cVar8 = (char)var_118h;
    fVar21 = 0.0;
    fVar22 = 0.0;
    var_104h._4_4_ = 0.0;
    if ((uVar19 >> 0x14 & 1) != 0) {
        fVar21 = 1.83671e-40;
        var_104h._4_4_ = 1.83671e-40;
        fVar22 = 1.83671e-40;
    }
    if ((uVar19 >> 0x1b & 1) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x100000);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if ((uVar19 >> 0x16 & 1) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x10);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if ((uVar19 >> 0x17 & 1) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x80);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if ((arg3 & 4U) != 0) {
        fVar21 = (float)((uint32_t)fVar22 | 0x120);
        fVar22 = fVar21;
        var_104h._4_4_ = fVar21;
    }
    if (((arg3 & 0x10U) != 0) || ((*(uint32_t *)(iVar7 + 0x1fbc) & 0x4000) != 0)) {
        fVar21 = (float)((uint32_t)fVar22 | 0x1000);
        var_104h._4_4_ = fVar21;
    }
    if (uVar20 == 0) {
        var_138h = CONCAT44(var_138h._4_4_, fVar21);
        uVar10 = func_0x000180139d40(&var_110h, iVar11, (int64_t)&var_118h + 1, (int64_t)&var_118h + 5, var_138h);
        if (((((arg3 & 0x40U) == 0) || (*(int32_t *)(iVar7 + 0x23a4) == 0)) ||
            (*(int32_t *)(iVar7 + 0x23a8) != *(int32_t *)(iVar7 + 0x1f74))) ||
           ((*(int32_t *)(iVar7 + 0x23a4) != iVar11 || ((*(uint32_t *)(iVar7 + 0x23ac) & 0x1000) != 0))))
        goto code_r0x000180147188;
        uVar10 = 1;
        var_118h._2_1_ = '\x01';
        var_118h._0_1_ = '\x01';
code_r0x0001801471a3:
        if ((*(char *)(iVar7 + 0x21cd) == '\0') &&
           ((*(int64_t *)(iVar7 + 0x21d8) == iVar4 && (*(int32_t *)(iVar7 + 0x21e4) == *(int32_t *)(iVar4 + 0x1b0))))) {
            var_e8h._0_4_ = (float)var_110h - *(float *)(iVar4 + 0x168);
            var_e8h._4_4_ = var_110h._4_4_ - *(float *)(iVar4 + 0x16c);
            var_e0h = var_108h - *(float *)(iVar4 + 0x168);
            var_dch = (float)var_104h - *(float *)(iVar4 + 0x16c);
            func_0x00018010e3f0(iVar11, *(int32_t *)(iVar4 + 0x1b0), *(undefined4 *)(iVar7 + 0x1f74), &var_e8h);
            if (*(char *)(iVar7 + 0x7e) != '\0') {
                *(undefined *)(iVar7 + 0x21cc) = 0;
            }
        }
        cVar17 = (char)var_118h;
        if (uVar10 != 0) {
            func_0x0001800fa060();
        }
    } else {
        func_0x0001801475c0(iVar11, &var_10h, (int64_t)&var_104h + 4);
        var_138h = CONCAT44(var_138h._4_4_, var_104h._4_4_);
        var_118h._3_1_ =
             func_0x000180139d40(&var_110h, iVar11, (int64_t)&var_118h + 1, (int64_t)&var_118h + 5, var_138h);
        func_0x0001801476e0(iVar11, &var_10h, (int64_t)&var_118h + 3);
        var_118h._0_1_ = (char)var_10h;
        uVar10 = var_118h._3_1_;
code_r0x000180147188:
        var_118h._2_1_ = '\0';
        if ((uVar10 != 0) || ((cVar17 = (char)var_118h, var_118h._1_1_ != '\0' && ((uVar19 >> 0x19 & 1) != 0))))
        goto code_r0x0001801471a3;
    }
    cVar9 = var_118h._4_1_;
    if (cVar17 != cVar8) {
        *(uint32_t *)(iVar7 + 0x1fc0) = *(uint32_t *)(iVar7 + 0x1fc0) | 8;
    }
    if (var_118h._4_1_ == '\0') goto code_r0x00018014735e;
    if ((var_118h._1_1_ == '\0') && ((arg3 & 0x20U) == 0)) {
        if (cVar17 != '\0') {
            bVar6 = false;
            iVar15 = 0;
            goto code_r0x00018014728d;
        }
    } else {
        bVar6 = true;
        iVar15 = 1;
code_r0x00018014728d:
        if ((var_118h._5_1_ == '\0') || (!bVar6)) {
            iVar15 = (iVar15 + 0x2c) * 0x10;
        } else {
            iVar15 = 0x2e0;
        }
        var_fch = (float)var_104h;
        var_e8h._4_4_ = var_110h._4_4_;
        puVar2 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + iVar15);
        uStack_c0 = *puVar2;
        uStack_bc = puVar2[1];
        uStack_b8 = puVar2[2];
        fStack_b4 = (float)puVar2[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        var_104h._4_4_ = var_108h;
        var_e8h._0_4_ = (float)var_110h;
        iVar15 = *(int64_t *)0x180781f28;
        uVar12 = func_0x0001800f5fa0(&uStack_c0);
        var_130h = var_130h & 0xffffffff00000000;
        var_138h = var_138h & 0xffffffff00000000;
        func_0x000180126550(*(undefined8 *)(*(int64_t *)(iVar15 + 0x15e0) + 800), &var_e8h, (int64_t)&var_104h + 4, 
                            uVar12, var_138h, var_130h);
    }
    if (*(int32_t *)(iVar7 + 0x21d0) == iVar11) {
        uVar18 = 0xe;
        if (uStack_d0 == 0) {
            uVar18 = 10;
        }
        func_0x0001800f7d00(&var_110h, iVar11, uVar18);
    }
code_r0x00018014735e:
    if (var_f0h != 0) {
        if (*(int64_t *)(iVar7 + 0x24d0) == 0) {
            if (*(int64_t *)(iVar4 + 0x208) != 0) {
                func_0x000180138c50();
            }
        } else {
            func_0x000180137590();
        }
    }
    if (cVar9 != '\0') {
        var_e8h._4_4_ = fVar24 + var_f8h._4_4_;
        var_e8h._0_4_ = fVar23 + (float)var_f8h;
        if (*(float *)(iVar4 + 0x2a0) <= fVar23 + (float)var_f8h) {
            var_e8h._0_4_ = *(float *)(iVar4 + 0x2a0);
        }
        func_0x0001800f7200(&var_f8h, &var_e8h, arg1, pcVar16, &fStack_c8, iVar7 + 0xe88, &var_110h);
    }
    if ((((uVar10 != 0) && (var_118h._2_1_ == '\0')) && ((*(uint32_t *)(iVar4 + 0x14) & 0x4000000) != 0)) &&
       (((arg3 & 1U) == 0 && ((*(uint8_t *)(iVar7 + 0x1fbc) & 0x10) != 0)))) {
        func_0x00018010d400();
    }
    if ((uStack_cc != 0) && (fStack_d8 == 0.0)) {
        func_0x000180106130();
    }
    return (uint64_t)uVar10;
}

// ============================================================
// Function: FUN_1801475c0
// Address: 0x1801475c0
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801475c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    char cVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar5 = *(int64_t *)0x180781f28;
    cVar6 = *(char *)arg2;
    iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x25f0);
    if (*(char *)(iVar1 + 0x52) != '\0') {
        if (*(char *)(iVar1 + 0x50) != -1) {
            cVar6 = *(char *)(iVar1 + 0x50) == '\x01';
        }
        if (*(char *)(iVar1 + 0x53) != '\0') {
            iVar2 = *(int64_t *)(iVar1 + 0x28);
            iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1f90);
            if ((*(char *)(iVar1 + 0x56) == '\0') && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x23a4) == (int32_t)arg1))
            {
                bVar4 = true;
                *(undefined *)(iVar1 + 0x56) = 1;
                if (*(int64_t *)(iVar2 + 0x18) == -1) {
                    *(int64_t *)(iVar2 + 0x18) = iVar3;
                    *(bool *)(iVar2 + 0x14) = cVar6 != '\0';
                }
            } else {
                bVar4 = false;
            }
            if (((*(int64_t *)(iVar2 + 0x18) == iVar3) || (bVar4)) ||
               (*(char *)(iVar1 + 0x55) != *(char *)(iVar1 + 0x56))) {
                cVar6 = *(char *)(iVar2 + 0x14) != '\0';
            } else if (((*(uint32_t *)(iVar1 + 0x4c) & 0x1000) == 0) && ((*(uint8_t *)(iVar1 + 0x34) & 0x10) == 0)) {
                cVar6 = '\0';
            }
        }
        *(char *)arg2 = cVar6;
    }
    if (arg3 != 0) {
        if (((*(uint32_t *)(iVar1 + 0x34) >> 0xe & 1) == 0) &&
           (((*(uint32_t *)(iVar1 + 0x34) >> 0xf & 1) != 0 ||
            ((cVar6 != '\0' && ((*(int32_t *)(iVar5 + 0x1654) != (int32_t)arg1 || (*(char *)(iVar5 + 0x1663) == '\0'))))
            )))) {
            *(uint32_t *)arg3 = *(uint32_t *)arg3 & 0xffffffcf | 0x80020;
            return;
        }
        *(uint32_t *)arg3 = *(uint32_t *)arg3 & 0xffffffcf | 0x80010;
    }
    return;
}

// ============================================================
// Function: FUN_1801475cf
// Address: 0x1801475cf
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801475c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    char cVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar5 = *(int64_t *)0x180781f28;
    cVar6 = *(char *)arg2;
    iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x25f0);
    if (*(char *)(iVar1 + 0x52) != '\0') {
        if (*(char *)(iVar1 + 0x50) != -1) {
            cVar6 = *(char *)(iVar1 + 0x50) == '\x01';
        }
        if (*(char *)(iVar1 + 0x53) != '\0') {
            iVar2 = *(int64_t *)(iVar1 + 0x28);
            iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1f90);
            if ((*(char *)(iVar1 + 0x56) == '\0') && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x23a4) == (int32_t)arg1))
            {
                bVar4 = true;
                *(undefined *)(iVar1 + 0x56) = 1;
                if (*(int64_t *)(iVar2 + 0x18) == -1) {
                    *(int64_t *)(iVar2 + 0x18) = iVar3;
                    *(bool *)(iVar2 + 0x14) = cVar6 != '\0';
                }
            } else {
                bVar4 = false;
            }
            if (((*(int64_t *)(iVar2 + 0x18) == iVar3) || (bVar4)) ||
               (*(char *)(iVar1 + 0x55) != *(char *)(iVar1 + 0x56))) {
                cVar6 = *(char *)(iVar2 + 0x14) != '\0';
            } else if (((*(uint32_t *)(iVar1 + 0x4c) & 0x1000) == 0) && ((*(uint8_t *)(iVar1 + 0x34) & 0x10) == 0)) {
                cVar6 = '\0';
            }
        }
        *(char *)arg2 = cVar6;
    }
    if (arg3 != 0) {
        if (((*(uint32_t *)(iVar1 + 0x34) >> 0xe & 1) == 0) &&
           (((*(uint32_t *)(iVar1 + 0x34) >> 0xf & 1) != 0 ||
            ((cVar6 != '\0' && ((*(int32_t *)(iVar5 + 0x1654) != (int32_t)arg1 || (*(char *)(iVar5 + 0x1663) == '\0'))))
            )))) {
            *(uint32_t *)arg3 = *(uint32_t *)arg3 & 0xffffffcf | 0x80020;
            return;
        }
        *(uint32_t *)arg3 = *(uint32_t *)arg3 & 0xffffffcf | 0x80010;
    }
    return;
}

// ============================================================
// Function: FUN_18014760c
// Address: 0x18014760c
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801475c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    char cVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar5 = *(int64_t *)0x180781f28;
    cVar6 = *(char *)arg2;
    iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x25f0);
    if (*(char *)(iVar1 + 0x52) != '\0') {
        if (*(char *)(iVar1 + 0x50) != -1) {
            cVar6 = *(char *)(iVar1 + 0x50) == '\x01';
        }
        if (*(char *)(iVar1 + 0x53) != '\0') {
            iVar2 = *(int64_t *)(iVar1 + 0x28);
            iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1f90);
            if ((*(char *)(iVar1 + 0x56) == '\0') && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x23a4) == (int32_t)arg1))
            {
                bVar4 = true;
                *(undefined *)(iVar1 + 0x56) = 1;
                if (*(int64_t *)(iVar2 + 0x18) == -1) {
                    *(int64_t *)(iVar2 + 0x18) = iVar3;
                    *(bool *)(iVar2 + 0x14) = cVar6 != '\0';
                }
            } else {
                bVar4 = false;
            }
            if (((*(int64_t *)(iVar2 + 0x18) == iVar3) || (bVar4)) ||
               (*(char *)(iVar1 + 0x55) != *(char *)(iVar1 + 0x56))) {
                cVar6 = *(char *)(iVar2 + 0x14) != '\0';
            } else if (((*(uint32_t *)(iVar1 + 0x4c) & 0x1000) == 0) && ((*(uint8_t *)(iVar1 + 0x34) & 0x10) == 0)) {
                cVar6 = '\0';
            }
        }
        *(char *)arg2 = cVar6;
    }
    if (arg3 != 0) {
        if (((*(uint32_t *)(iVar1 + 0x34) >> 0xe & 1) == 0) &&
           (((*(uint32_t *)(iVar1 + 0x34) >> 0xf & 1) != 0 ||
            ((cVar6 != '\0' && ((*(int32_t *)(iVar5 + 0x1654) != (int32_t)arg1 || (*(char *)(iVar5 + 0x1663) == '\0'))))
            )))) {
            *(uint32_t *)arg3 = *(uint32_t *)arg3 & 0xffffffcf | 0x80020;
            return;
        }
        *(uint32_t *)arg3 = *(uint32_t *)arg3 & 0xffffffcf | 0x80010;
    }
    return;
}

// ============================================================
// Function: FUN_180147656
// Address: 0x180147656
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801475c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    char cVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar5 = *(int64_t *)0x180781f28;
    cVar6 = *(char *)arg2;
    iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x25f0);
    if (*(char *)(iVar1 + 0x52) != '\0') {
        if (*(char *)(iVar1 + 0x50) != -1) {
            cVar6 = *(char *)(iVar1 + 0x50) == '\x01';
        }
        if (*(char *)(iVar1 + 0x53) != '\0') {
            iVar2 = *(int64_t *)(iVar1 + 0x28);
            iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1f90);
            if ((*(char *)(iVar1 + 0x56) == '\0') && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x23a4) == (int32_t)arg1))
            {
                bVar4 = true;
                *(undefined *)(iVar1 + 0x56) = 1;
                if (*(int64_t *)(iVar2 + 0x18) == -1) {
                    *(int64_t *)(iVar2 + 0x18) = iVar3;
                    *(bool *)(iVar2 + 0x14) = cVar6 != '\0';
                }
            } else {
                bVar4 = false;
            }
            if (((*(int64_t *)(iVar2 + 0x18) == iVar3) || (bVar4)) ||
               (*(char *)(iVar1 + 0x55) != *(char *)(iVar1 + 0x56))) {
                cVar6 = *(char *)(iVar2 + 0x14) != '\0';
            } else if (((*(uint32_t *)(iVar1 + 0x4c) & 0x1000) == 0) && ((*(uint8_t *)(iVar1 + 0x34) & 0x10) == 0)) {
                cVar6 = '\0';
            }
        }
        *(char *)arg2 = cVar6;
    }
    if (arg3 != 0) {
        if (((*(uint32_t *)(iVar1 + 0x34) >> 0xe & 1) == 0) &&
           (((*(uint32_t *)(iVar1 + 0x34) >> 0xf & 1) != 0 ||
            ((cVar6 != '\0' && ((*(int32_t *)(iVar5 + 0x1654) != (int32_t)arg1 || (*(char *)(iVar5 + 0x1663) == '\0'))))
            )))) {
            *(uint32_t *)arg3 = *(uint32_t *)arg3 & 0xffffffcf | 0x80020;
            return;
        }
        *(uint32_t *)arg3 = *(uint32_t *)arg3 & 0xffffffcf | 0x80010;
    }
    return;
}

// ============================================================
// Function: FUN_180147688
// Address: 0x180147688
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801475c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    char cVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar5 = *(int64_t *)0x180781f28;
    cVar6 = *(char *)arg2;
    iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x25f0);
    if (*(char *)(iVar1 + 0x52) != '\0') {
        if (*(char *)(iVar1 + 0x50) != -1) {
            cVar6 = *(char *)(iVar1 + 0x50) == '\x01';
        }
        if (*(char *)(iVar1 + 0x53) != '\0') {
            iVar2 = *(int64_t *)(iVar1 + 0x28);
            iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1f90);
            if ((*(char *)(iVar1 + 0x56) == '\0') && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x23a4) == (int32_t)arg1))
            {
                bVar4 = true;
                *(undefined *)(iVar1 + 0x56) = 1;
                if (*(int64_t *)(iVar2 + 0x18) == -1) {
                    *(int64_t *)(iVar2 + 0x18) = iVar3;
                    *(bool *)(iVar2 + 0x14) = cVar6 != '\0';
                }
            } else {
                bVar4 = false;
            }
            if (((*(int64_t *)(iVar2 + 0x18) == iVar3) || (bVar4)) ||
               (*(char *)(iVar1 + 0x55) != *(char *)(iVar1 + 0x56))) {
                cVar6 = *(char *)(iVar2 + 0x14) != '\0';
            } else if (((*(uint32_t *)(iVar1 + 0x4c) & 0x1000) == 0) && ((*(uint8_t *)(iVar1 + 0x34) & 0x10) == 0)) {
                cVar6 = '\0';
            }
        }
        *(char *)arg2 = cVar6;
    }
    if (arg3 != 0) {
        if (((*(uint32_t *)(iVar1 + 0x34) >> 0xe & 1) == 0) &&
           (((*(uint32_t *)(iVar1 + 0x34) >> 0xf & 1) != 0 ||
            ((cVar6 != '\0' && ((*(int32_t *)(iVar5 + 0x1654) != (int32_t)arg1 || (*(char *)(iVar5 + 0x1663) == '\0'))))
            )))) {
            *(uint32_t *)arg3 = *(uint32_t *)arg3 & 0xffffffcf | 0x80020;
            return;
        }
        *(uint32_t *)arg3 = *(uint32_t *)arg3 & 0xffffffcf | 0x80010;
    }
    return;
}

// ============================================================
// Function: FUN_180147695
// Address: 0x180147695
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801475c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    char cVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar5 = *(int64_t *)0x180781f28;
    cVar6 = *(char *)arg2;
    iVar1 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x25f0);
    if (*(char *)(iVar1 + 0x52) != '\0') {
        if (*(char *)(iVar1 + 0x50) != -1) {
            cVar6 = *(char *)(iVar1 + 0x50) == '\x01';
        }
        if (*(char *)(iVar1 + 0x53) != '\0') {
            iVar2 = *(int64_t *)(iVar1 + 0x28);
            iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1f90);
            if ((*(char *)(iVar1 + 0x56) == '\0') && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x23a4) == (int32_t)arg1))
            {
                bVar4 = true;
                *(undefined *)(iVar1 + 0x56) = 1;
                if (*(int64_t *)(iVar2 + 0x18) == -1) {
                    *(int64_t *)(iVar2 + 0x18) = iVar3;
                    *(bool *)(iVar2 + 0x14) = cVar6 != '\0';
                }
            } else {
                bVar4 = false;
            }
            if (((*(int64_t *)(iVar2 + 0x18) == iVar3) || (bVar4)) ||
               (*(char *)(iVar1 + 0x55) != *(char *)(iVar1 + 0x56))) {
                cVar6 = *(char *)(iVar2 + 0x14) != '\0';
            } else if (((*(uint32_t *)(iVar1 + 0x4c) & 0x1000) == 0) && ((*(uint8_t *)(iVar1 + 0x34) & 0x10) == 0)) {
                cVar6 = '\0';
            }
        }
        *(char *)arg2 = cVar6;
    }
    if (arg3 != 0) {
        if (((*(uint32_t *)(iVar1 + 0x34) >> 0xe & 1) == 0) &&
           (((*(uint32_t *)(iVar1 + 0x34) >> 0xf & 1) != 0 ||
            ((cVar6 != '\0' && ((*(int32_t *)(iVar5 + 0x1654) != (int32_t)arg1 || (*(char *)(iVar5 + 0x1663) == '\0'))))
            )))) {
            *(uint32_t *)arg3 = *(uint32_t *)arg3 & 0xffffffcf | 0x80020;
            return;
        }
        *(uint32_t *)arg3 = *(uint32_t *)arg3 & 0xffffffcf | 0x80010;
    }
    return;
}

// ============================================================
// Function: FUN_1801476e0
// Address: 0x1801476e0
// Size: 142 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_76h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_77h
// WARNING: [rz-ghidra] Detected overlap for variable var_15h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.1801476e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint32_t uVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    bool bVar5;
    int64_t iVar6;
    char cVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    undefined8 uVar12;
    int64_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    bool bVar16;
    bool bVar17;
    bool bVar18;
    char cVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    char var_76h;
    int64_t var_70h;
    int64_t var_62h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar6 = *(int64_t *)0x180781f28;
    iVar10 = (int32_t)arg1;
    var_20h._0_1_ = *(char *)arg3;
    cVar19 = *(char *)arg2;
    piVar2 = *(int32_t **)(*(int64_t *)0x180781f28 + 0x25f0);
    uVar12 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x15e0);
    iVar3 = *(int64_t *)(piVar2 + 10);
    if ((char)var_20h != '\0') {
        *(undefined *)((int64_t)piVar2 + 0x52) = 1;
    }
    var_76h = '\0';
    if ((*(uint8_t *)(iVar6 + 0x1fc0) & 1) != 0) {
        var_76h = func_0x0001800fa150(0x20);
    }
    if ((*(char *)((int64_t)piVar2 + 0x52) == '\0') && (var_76h == '\0')) {
        return;
    }
    uVar1 = piVar2[0xd];
    iVar4 = *(int64_t *)(iVar6 + 0x1f90);
    uVar15 = piVar2[0x13] & 0x1000;
    bVar16 = uVar15 != 0;
    uVar14 = piVar2[0x13] & 0x2000;
    bVar17 = uVar14 != 0;
    bVar18 = false;
    if (*(int32_t *)(iVar6 + 0x21d0) == iVar10) {
        bVar18 = *(int64_t *)(iVar3 + 0x18) == -1;
    }
    if (*(char *)((int64_t)piVar2 + 0x51) == '\0') {
        if (piVar2[1] < 0) {
            func_0x00018014fa90(piVar2);
        }
        *piVar2 = 0;
        *(undefined *)((int64_t)piVar2 + 0x51) = 1;
    }
    if (*(int32_t *)(iVar6 + 0x23a4) == iVar10) {
        if ((uVar1 & 8) == 0) {
            if (uVar15 == 0) {
                var_20h._0_1_ = '\x01';
                cVar19 = '\x01';
            } else if (uVar14 != 0) {
                var_20h._0_1_ = '\x01';
            }
            goto code_r0x000180147835;
        }
        if (uVar14 != 0) {
            var_20h._0_1_ = '\x01';
            goto code_r0x000180147835;
        }
        if (uVar15 != 0) goto code_r0x000180147835;
code_r0x00018014783a:
        *(int64_t *)(iVar3 + 0x18) = iVar4;
        *(char *)(iVar3 + 0x14) = cVar19;
    } else {
code_r0x000180147835:
        if (bVar18) goto code_r0x00018014783a;
    }
    if (((piVar2[0x12] != 0) && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2588) == piVar2[0x12])) &&
       (*(char *)(*(int64_t *)0x180781f28 + 0x258c) != '\0')) {
        if (((*(float *)(*(int64_t *)0x180781f28 + 0x25e8) <= *(float *)(iVar6 + 0x1fc8)) ||
            (*(float *)(iVar6 + 0x1fd0) < *(float *)(*(int64_t *)0x180781f28 + 0x25e0) ||
             *(float *)(iVar6 + 0x1fd0) == *(float *)(*(int64_t *)0x180781f28 + 0x25e0))) ||
           ((*(float *)(*(int64_t *)0x180781f28 + 0x25e4) < *(float *)(iVar6 + 0x1fc4) ||
             *(float *)(*(int64_t *)0x180781f28 + 0x25e4) == *(float *)(iVar6 + 0x1fc4) ||
            (*(float *)(iVar6 + 0x1fcc) < *(float *)(*(int64_t *)0x180781f28 + 0x25dc) ||
             *(float *)(iVar6 + 0x1fcc) == *(float *)(*(int64_t *)0x180781f28 + 0x25dc))))) {
            bVar18 = false;
        } else {
            bVar18 = true;
        }
        if (((*(float *)(*(int64_t *)0x180781f28 + 0x25d8) <= *(float *)(iVar6 + 0x1fc8)) ||
            (*(float *)(iVar6 + 0x1fd0) < *(float *)(*(int64_t *)0x180781f28 + 0x25d0) ||
             *(float *)(iVar6 + 0x1fd0) == *(float *)(*(int64_t *)0x180781f28 + 0x25d0))) ||
           ((*(float *)(*(int64_t *)0x180781f28 + 0x25d4) < *(float *)(iVar6 + 0x1fc4) ||
             *(float *)(*(int64_t *)0x180781f28 + 0x25d4) == *(float *)(iVar6 + 0x1fc4) ||
            (*(float *)(iVar6 + 0x1fcc) < *(float *)(*(int64_t *)0x180781f28 + 0x25cc) ||
             *(float *)(iVar6 + 0x1fcc) == *(float *)(*(int64_t *)0x180781f28 + 0x25cc))))) {
            bVar5 = false;
        } else {
            bVar5 = true;
        }
        if (bVar18) {
            if ((!bVar5) && (cVar19 == '\0')) {
code_r0x00018014792f:
                if ((*(int32_t *)(iVar3 + 0x10) < 1) && (*(char *)(*(int64_t *)0x180781f28 + 0x258f) != '\0')) {
                    var_20h._0_1_ = '\x01';
                    *(undefined *)(*(int64_t *)0x180781f28 + 0x258f) = 0;
                } else {
                    iVar8 = piVar2[1];
                    cVar19 = cVar19 == '\0';
                    if (*piVar2 == iVar8) {
                        iVar11 = *piVar2 + 1;
                        if (iVar8 == 0) {
                            iVar8 = 8;
                        } else {
                            iVar8 = iVar8 / 2 + iVar8;
                        }
                        if (iVar11 < iVar8) {
                            iVar11 = iVar8;
                        }
                        func_0x00018014fa90(piVar2, iVar11);
                    }
                    iVar9 = (int64_t)*piVar2;
                    iVar13 = *(int64_t *)(piVar2 + 2);
                    *(undefined4 *)(iVar13 + iVar9 * 0x18) = 2;
                    *(char *)(iVar13 + 4 + iVar9 * 0x18) = cVar19;
                    *(undefined *)(iVar13 + 5 + iVar9 * 0x18) = 1;
                    *(undefined2 *)(iVar13 + 6 + iVar9 * 0x18) = (undefined2)var_62h;
                    *(int64_t *)(iVar13 + 8 + iVar9 * 0x18) = iVar4;
                    *(int64_t *)(iVar13 + 0x10 + iVar9 * 0x18) = iVar4;
                    *piVar2 = *piVar2 + 1;
                }
                iVar11 = *(int32_t *)(iVar3 + 0x10) + 1;
                iVar8 = 1;
                if (0 < iVar11) {
                    iVar8 = iVar11;
                }
                *(int32_t *)(iVar3 + 0x10) = iVar8;
            }
        } else if (bVar5) goto code_r0x00018014792f;
    }
    if (((var_76h == '\0') || (iVar8 = iVar10, cVar7 = func_0x000180107ff0(1, 0, 0), cVar7 == '\0')) ||
       ((uVar1 & 0x20008) != 0)) {
        if ((char)var_20h != '\0') goto code_r0x000180147a6d;
code_r0x000180147a83:
        bVar18 = false;
    } else {
        if ((*(int32_t *)(iVar6 + 0x1654) != 0) && (*(int32_t *)(iVar6 + 0x1654) != iVar8)) {
            func_0x0001800f9f30(0, 0);
        }
        func_0x00018010e4a0(iVar10, uVar12);
        if ((char)var_20h == '\0') {
            if (cVar19 != '\0') goto code_r0x000180147a83;
            var_20h._0_1_ = '\x01';
            bVar16 = false;
            bVar17 = false;
        }
code_r0x000180147a6d:
        if ((*(int32_t *)(iVar6 + 0x21ec) != iVar10) || ((*(uint8_t *)(iVar6 + 0x21f8) & 1) == 0))
        goto code_r0x000180147a83;
        bVar18 = true;
    }
    if (((char)var_20h == '\0') || ((bVar18 && (cVar19 != '\0')))) goto code_r0x000180147be4;
    if ((*(int32_t *)(iVar6 + 0x23a4) == iVar10) || (iVar8 = 1, *(int32_t *)(iVar6 + 0x21ec) == iVar10)) {
        iVar8 = *(int32_t *)(iVar6 + 0x2228);
    }
    if (((((uVar1 & 0xc0) != 0) && (*(char *)(iVar6 + 0x258c) == '\0')) && (*(char *)(iVar6 + 0x258d) == '\0')) &&
       ((iVar8 == 1 && (*(int16_t *)(iVar6 + 0xb5a) == 1)))) {
        func_0x000180147450(piVar2[0x12], iVar4);
    }
    if ((uVar1 & 0x10) != 0) goto code_r0x000180147b45;
    if ((uVar1 & 1) == 0) {
        if (((iVar8 == 1) || (*(int32_t *)(iVar6 + 0x21ec) == iVar10)) && (!bVar16)) {
            if (((uVar1 & 0x20) == 0) || (cVar19 == '\0')) goto code_r0x000180147b3d;
            goto code_r0x000180147b45;
        }
        if (1 < iVar8 - 2U) goto code_r0x000180147b45;
        if (!bVar17) goto code_r0x000180147ba5;
        if (!bVar16) goto code_r0x000180147b3d;
code_r0x000180147b56:
        iVar13 = *(int64_t *)(iVar3 + 0x18);
        if (*(int64_t *)(iVar3 + 0x18) == -1) {
            *(int64_t *)(iVar3 + 0x18) = iVar4;
            iVar13 = iVar4;
        }
        if ((uVar1 & 8) == 0) {
            if (bVar16) {
code_r0x000180147b71:
                if (*(char *)(iVar3 + 0x14) != -1) {
                    bVar18 = *(char *)(iVar3 + 0x14) != '\0';
                    goto code_r0x000180147b8c;
                }
            }
            bVar18 = true;
        } else {
            if (*(char *)((int64_t)piVar2 + 0x53) != '\0') goto code_r0x000180147b71;
            bVar18 = cVar19 == '\0';
        }
code_r0x000180147b8c:
        uVar12 = 0xffffffff;
        if (*(char *)((int64_t)piVar2 + 0x55) != '\0') {
            uVar12 = 1;
        }
    } else {
code_r0x000180147b3d:
        func_0x000180147c50(piVar2);
code_r0x000180147b45:
        if ((bVar17) && ((uVar1 & 1) == 0)) goto code_r0x000180147b56;
code_r0x000180147ba5:
        if (((uVar1 & 8) != 0) || (bVar16)) {
            cVar19 = cVar19 == '\0';
        } else {
            cVar19 = true;
        }
        *(int64_t *)(iVar3 + 0x18) = iVar4;
        uVar12 = 1;
        iVar13 = iVar4;
        bVar18 = (bool)cVar19;
    }
    func_0x000180147ce0(piVar2, bVar18, uVar12, iVar13, iVar4);
code_r0x000180147be4:
    if (*(int64_t *)(iVar3 + 0x18) == iVar4) {
        *(bool *)(iVar3 + 0x14) = cVar19 != '\0';
    }
    if (*(int32_t *)(iVar6 + 0x21d0) == iVar10) {
        *(int64_t *)(iVar3 + 0x20) = iVar4;
        *(bool *)(iVar3 + 0x15) = cVar19 != '\0';
    }
    if (*(int64_t *)(iVar3 + 0x20) == iVar4) {
        *(undefined *)(piVar2 + 0x15) = 1;
    }
    *(char *)arg2 = cVar19;
    *(char *)arg3 = (char)var_20h;
    return;
}

// ============================================================
// Function: FUN_18014776e
// Address: 0x18014776e
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_76h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_77h
// WARNING: [rz-ghidra] Detected overlap for variable var_15h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.1801476e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint32_t uVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    bool bVar5;
    int64_t iVar6;
    char cVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    undefined8 uVar12;
    int64_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    bool bVar16;
    bool bVar17;
    bool bVar18;
    char cVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    char var_76h;
    int64_t var_70h;
    int64_t var_62h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar6 = *(int64_t *)0x180781f28;
    iVar10 = (int32_t)arg1;
    var_20h._0_1_ = *(char *)arg3;
    cVar19 = *(char *)arg2;
    piVar2 = *(int32_t **)(*(int64_t *)0x180781f28 + 0x25f0);
    uVar12 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x15e0);
    iVar3 = *(int64_t *)(piVar2 + 10);
    if ((char)var_20h != '\0') {
        *(undefined *)((int64_t)piVar2 + 0x52) = 1;
    }
    var_76h = '\0';
    if ((*(uint8_t *)(iVar6 + 0x1fc0) & 1) != 0) {
        var_76h = func_0x0001800fa150(0x20);
    }
    if ((*(char *)((int64_t)piVar2 + 0x52) == '\0') && (var_76h == '\0')) {
        return;
    }
    uVar1 = piVar2[0xd];
    iVar4 = *(int64_t *)(iVar6 + 0x1f90);
    uVar15 = piVar2[0x13] & 0x1000;
    bVar16 = uVar15 != 0;
    uVar14 = piVar2[0x13] & 0x2000;
    bVar17 = uVar14 != 0;
    bVar18 = false;
    if (*(int32_t *)(iVar6 + 0x21d0) == iVar10) {
        bVar18 = *(int64_t *)(iVar3 + 0x18) == -1;
    }
    if (*(char *)((int64_t)piVar2 + 0x51) == '\0') {
        if (piVar2[1] < 0) {
            func_0x00018014fa90(piVar2);
        }
        *piVar2 = 0;
        *(undefined *)((int64_t)piVar2 + 0x51) = 1;
    }
    if (*(int32_t *)(iVar6 + 0x23a4) == iVar10) {
        if ((uVar1 & 8) == 0) {
            if (uVar15 == 0) {
                var_20h._0_1_ = '\x01';
                cVar19 = '\x01';
            } else if (uVar14 != 0) {
                var_20h._0_1_ = '\x01';
            }
            goto code_r0x000180147835;
        }
        if (uVar14 != 0) {
            var_20h._0_1_ = '\x01';
            goto code_r0x000180147835;
        }
        if (uVar15 != 0) goto code_r0x000180147835;
code_r0x00018014783a:
        *(int64_t *)(iVar3 + 0x18) = iVar4;
        *(char *)(iVar3 + 0x14) = cVar19;
    } else {
code_r0x000180147835:
        if (bVar18) goto code_r0x00018014783a;
    }
    if (((piVar2[0x12] != 0) && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2588) == piVar2[0x12])) &&
       (*(char *)(*(int64_t *)0x180781f28 + 0x258c) != '\0')) {
        if (((*(float *)(*(int64_t *)0x180781f28 + 0x25e8) <= *(float *)(iVar6 + 0x1fc8)) ||
            (*(float *)(iVar6 + 0x1fd0) < *(float *)(*(int64_t *)0x180781f28 + 0x25e0) ||
             *(float *)(iVar6 + 0x1fd0) == *(float *)(*(int64_t *)0x180781f28 + 0x25e0))) ||
           ((*(float *)(*(int64_t *)0x180781f28 + 0x25e4) < *(float *)(iVar6 + 0x1fc4) ||
             *(float *)(*(int64_t *)0x180781f28 + 0x25e4) == *(float *)(iVar6 + 0x1fc4) ||
            (*(float *)(iVar6 + 0x1fcc) < *(float *)(*(int64_t *)0x180781f28 + 0x25dc) ||
             *(float *)(iVar6 + 0x1fcc) == *(float *)(*(int64_t *)0x180781f28 + 0x25dc))))) {
            bVar18 = false;
        } else {
            bVar18 = true;
        }
        if (((*(float *)(*(int64_t *)0x180781f28 + 0x25d8) <= *(float *)(iVar6 + 0x1fc8)) ||
            (*(float *)(iVar6 + 0x1fd0) < *(float *)(*(int64_t *)0x180781f28 + 0x25d0) ||
             *(float *)(iVar6 + 0x1fd0) == *(float *)(*(int64_t *)0x180781f28 + 0x25d0))) ||
           ((*(float *)(*(int64_t *)0x180781f28 + 0x25d4) < *(float *)(iVar6 + 0x1fc4) ||
             *(float *)(*(int64_t *)0x180781f28 + 0x25d4) == *(float *)(iVar6 + 0x1fc4) ||
            (*(float *)(iVar6 + 0x1fcc) < *(float *)(*(int64_t *)0x180781f28 + 0x25cc) ||
             *(float *)(iVar6 + 0x1fcc) == *(float *)(*(int64_t *)0x180781f28 + 0x25cc))))) {
            bVar5 = false;
        } else {
            bVar5 = true;
        }
        if (bVar18) {
            if ((!bVar5) && (cVar19 == '\0')) {
code_r0x00018014792f:
                if ((*(int32_t *)(iVar3 + 0x10) < 1) && (*(char *)(*(int64_t *)0x180781f28 + 0x258f) != '\0')) {
                    var_20h._0_1_ = '\x01';
                    *(undefined *)(*(int64_t *)0x180781f28 + 0x258f) = 0;
                } else {
                    iVar8 = piVar2[1];
                    cVar19 = cVar19 == '\0';
                    if (*piVar2 == iVar8) {
                        iVar11 = *piVar2 + 1;
                        if (iVar8 == 0) {
                            iVar8 = 8;
                        } else {
                            iVar8 = iVar8 / 2 + iVar8;
                        }
                        if (iVar11 < iVar8) {
                            iVar11 = iVar8;
                        }
                        func_0x00018014fa90(piVar2, iVar11);
                    }
                    iVar9 = (int64_t)*piVar2;
                    iVar13 = *(int64_t *)(piVar2 + 2);
                    *(undefined4 *)(iVar13 + iVar9 * 0x18) = 2;
                    *(char *)(iVar13 + 4 + iVar9 * 0x18) = cVar19;
                    *(undefined *)(iVar13 + 5 + iVar9 * 0x18) = 1;
                    *(undefined2 *)(iVar13 + 6 + iVar9 * 0x18) = (undefined2)var_62h;
                    *(int64_t *)(iVar13 + 8 + iVar9 * 0x18) = iVar4;
                    *(int64_t *)(iVar13 + 0x10 + iVar9 * 0x18) = iVar4;
                    *piVar2 = *piVar2 + 1;
                }
                iVar11 = *(int32_t *)(iVar3 + 0x10) + 1;
                iVar8 = 1;
                if (0 < iVar11) {
                    iVar8 = iVar11;
                }
                *(int32_t *)(iVar3 + 0x10) = iVar8;
            }
        } else if (bVar5) goto code_r0x00018014792f;
    }
    if (((var_76h == '\0') || (iVar8 = iVar10, cVar7 = func_0x000180107ff0(1, 0, 0), cVar7 == '\0')) ||
       ((uVar1 & 0x20008) != 0)) {
        if ((char)var_20h != '\0') goto code_r0x000180147a6d;
code_r0x000180147a83:
        bVar18 = false;
    } else {
        if ((*(int32_t *)(iVar6 + 0x1654) != 0) && (*(int32_t *)(iVar6 + 0x1654) != iVar8)) {
            func_0x0001800f9f30(0, 0);
        }
        func_0x00018010e4a0(iVar10, uVar12);
        if ((char)var_20h == '\0') {
            if (cVar19 != '\0') goto code_r0x000180147a83;
            var_20h._0_1_ = '\x01';
            bVar16 = false;
            bVar17 = false;
        }
code_r0x000180147a6d:
        if ((*(int32_t *)(iVar6 + 0x21ec) != iVar10) || ((*(uint8_t *)(iVar6 + 0x21f8) & 1) == 0))
        goto code_r0x000180147a83;
        bVar18 = true;
    }
    if (((char)var_20h == '\0') || ((bVar18 && (cVar19 != '\0')))) goto code_r0x000180147be4;
    if ((*(int32_t *)(iVar6 + 0x23a4) == iVar10) || (iVar8 = 1, *(int32_t *)(iVar6 + 0x21ec) == iVar10)) {
        iVar8 = *(int32_t *)(iVar6 + 0x2228);
    }
    if (((((uVar1 & 0xc0) != 0) && (*(char *)(iVar6 + 0x258c) == '\0')) && (*(char *)(iVar6 + 0x258d) == '\0')) &&
       ((iVar8 == 1 && (*(int16_t *)(iVar6 + 0xb5a) == 1)))) {
        func_0x000180147450(piVar2[0x12], iVar4);
    }
    if ((uVar1 & 0x10) != 0) goto code_r0x000180147b45;
    if ((uVar1 & 1) == 0) {
        if (((iVar8 == 1) || (*(int32_t *)(iVar6 + 0x21ec) == iVar10)) && (!bVar16)) {
            if (((uVar1 & 0x20) == 0) || (cVar19 == '\0')) goto code_r0x000180147b3d;
            goto code_r0x000180147b45;
        }
        if (1 < iVar8 - 2U) goto code_r0x000180147b45;
        if (!bVar17) goto code_r0x000180147ba5;
        if (!bVar16) goto code_r0x000180147b3d;
code_r0x000180147b56:
        iVar13 = *(int64_t *)(iVar3 + 0x18);
        if (*(int64_t *)(iVar3 + 0x18) == -1) {
            *(int64_t *)(iVar3 + 0x18) = iVar4;
            iVar13 = iVar4;
        }
        if ((uVar1 & 8) == 0) {
            if (bVar16) {
code_r0x000180147b71:
                if (*(char *)(iVar3 + 0x14) != -1) {
                    bVar18 = *(char *)(iVar3 + 0x14) != '\0';
                    goto code_r0x000180147b8c;
                }
            }
            bVar18 = true;
        } else {
            if (*(char *)((int64_t)piVar2 + 0x53) != '\0') goto code_r0x000180147b71;
            bVar18 = cVar19 == '\0';
        }
code_r0x000180147b8c:
        uVar12 = 0xffffffff;
        if (*(char *)((int64_t)piVar2 + 0x55) != '\0') {
            uVar12 = 1;
        }
    } else {
code_r0x000180147b3d:
        func_0x000180147c50(piVar2);
code_r0x000180147b45:
        if ((bVar17) && ((uVar1 & 1) == 0)) goto code_r0x000180147b56;
code_r0x000180147ba5:
        if (((uVar1 & 8) != 0) || (bVar16)) {
            cVar19 = cVar19 == '\0';
        } else {
            cVar19 = true;
        }
        *(int64_t *)(iVar3 + 0x18) = iVar4;
        uVar12 = 1;
        iVar13 = iVar4;
        bVar18 = (bool)cVar19;
    }
    func_0x000180147ce0(piVar2, bVar18, uVar12, iVar13, iVar4);
code_r0x000180147be4:
    if (*(int64_t *)(iVar3 + 0x18) == iVar4) {
        *(bool *)(iVar3 + 0x14) = cVar19 != '\0';
    }
    if (*(int32_t *)(iVar6 + 0x21d0) == iVar10) {
        *(int64_t *)(iVar3 + 0x20) = iVar4;
        *(bool *)(iVar3 + 0x15) = cVar19 != '\0';
    }
    if (*(int64_t *)(iVar3 + 0x20) == iVar4) {
        *(undefined *)(piVar2 + 0x15) = 1;
    }
    *(char *)arg2 = cVar19;
    *(char *)arg3 = (char)var_20h;
    return;
}

// ============================================================
// Function: FUN_18014777f
// Address: 0x18014777f
// Size: 1136 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_76h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_77h
// WARNING: [rz-ghidra] Detected overlap for variable var_15h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.1801476e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint32_t uVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    bool bVar5;
    int64_t iVar6;
    char cVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    undefined8 uVar12;
    int64_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    bool bVar16;
    bool bVar17;
    bool bVar18;
    char cVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    char var_76h;
    int64_t var_70h;
    int64_t var_62h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar6 = *(int64_t *)0x180781f28;
    iVar10 = (int32_t)arg1;
    var_20h._0_1_ = *(char *)arg3;
    cVar19 = *(char *)arg2;
    piVar2 = *(int32_t **)(*(int64_t *)0x180781f28 + 0x25f0);
    uVar12 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x15e0);
    iVar3 = *(int64_t *)(piVar2 + 10);
    if ((char)var_20h != '\0') {
        *(undefined *)((int64_t)piVar2 + 0x52) = 1;
    }
    var_76h = '\0';
    if ((*(uint8_t *)(iVar6 + 0x1fc0) & 1) != 0) {
        var_76h = func_0x0001800fa150(0x20);
    }
    if ((*(char *)((int64_t)piVar2 + 0x52) == '\0') && (var_76h == '\0')) {
        return;
    }
    uVar1 = piVar2[0xd];
    iVar4 = *(int64_t *)(iVar6 + 0x1f90);
    uVar15 = piVar2[0x13] & 0x1000;
    bVar16 = uVar15 != 0;
    uVar14 = piVar2[0x13] & 0x2000;
    bVar17 = uVar14 != 0;
    bVar18 = false;
    if (*(int32_t *)(iVar6 + 0x21d0) == iVar10) {
        bVar18 = *(int64_t *)(iVar3 + 0x18) == -1;
    }
    if (*(char *)((int64_t)piVar2 + 0x51) == '\0') {
        if (piVar2[1] < 0) {
            func_0x00018014fa90(piVar2);
        }
        *piVar2 = 0;
        *(undefined *)((int64_t)piVar2 + 0x51) = 1;
    }
    if (*(int32_t *)(iVar6 + 0x23a4) == iVar10) {
        if ((uVar1 & 8) == 0) {
            if (uVar15 == 0) {
                var_20h._0_1_ = '\x01';
                cVar19 = '\x01';
            } else if (uVar14 != 0) {
                var_20h._0_1_ = '\x01';
            }
            goto code_r0x000180147835;
        }
        if (uVar14 != 0) {
            var_20h._0_1_ = '\x01';
            goto code_r0x000180147835;
        }
        if (uVar15 != 0) goto code_r0x000180147835;
code_r0x00018014783a:
        *(int64_t *)(iVar3 + 0x18) = iVar4;
        *(char *)(iVar3 + 0x14) = cVar19;
    } else {
code_r0x000180147835:
        if (bVar18) goto code_r0x00018014783a;
    }
    if (((piVar2[0x12] != 0) && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2588) == piVar2[0x12])) &&
       (*(char *)(*(int64_t *)0x180781f28 + 0x258c) != '\0')) {
        if (((*(float *)(*(int64_t *)0x180781f28 + 0x25e8) <= *(float *)(iVar6 + 0x1fc8)) ||
            (*(float *)(iVar6 + 0x1fd0) < *(float *)(*(int64_t *)0x180781f28 + 0x25e0) ||
             *(float *)(iVar6 + 0x1fd0) == *(float *)(*(int64_t *)0x180781f28 + 0x25e0))) ||
           ((*(float *)(*(int64_t *)0x180781f28 + 0x25e4) < *(float *)(iVar6 + 0x1fc4) ||
             *(float *)(*(int64_t *)0x180781f28 + 0x25e4) == *(float *)(iVar6 + 0x1fc4) ||
            (*(float *)(iVar6 + 0x1fcc) < *(float *)(*(int64_t *)0x180781f28 + 0x25dc) ||
             *(float *)(iVar6 + 0x1fcc) == *(float *)(*(int64_t *)0x180781f28 + 0x25dc))))) {
            bVar18 = false;
        } else {
            bVar18 = true;
        }
        if (((*(float *)(*(int64_t *)0x180781f28 + 0x25d8) <= *(float *)(iVar6 + 0x1fc8)) ||
            (*(float *)(iVar6 + 0x1fd0) < *(float *)(*(int64_t *)0x180781f28 + 0x25d0) ||
             *(float *)(iVar6 + 0x1fd0) == *(float *)(*(int64_t *)0x180781f28 + 0x25d0))) ||
           ((*(float *)(*(int64_t *)0x180781f28 + 0x25d4) < *(float *)(iVar6 + 0x1fc4) ||
             *(float *)(*(int64_t *)0x180781f28 + 0x25d4) == *(float *)(iVar6 + 0x1fc4) ||
            (*(float *)(iVar6 + 0x1fcc) < *(float *)(*(int64_t *)0x180781f28 + 0x25cc) ||
             *(float *)(iVar6 + 0x1fcc) == *(float *)(*(int64_t *)0x180781f28 + 0x25cc))))) {
            bVar5 = false;
        } else {
            bVar5 = true;
        }
        if (bVar18) {
            if ((!bVar5) && (cVar19 == '\0')) {
code_r0x00018014792f:
                if ((*(int32_t *)(iVar3 + 0x10) < 1) && (*(char *)(*(int64_t *)0x180781f28 + 0x258f) != '\0')) {
                    var_20h._0_1_ = '\x01';
                    *(undefined *)(*(int64_t *)0x180781f28 + 0x258f) = 0;
                } else {
                    iVar8 = piVar2[1];
                    cVar19 = cVar19 == '\0';
                    if (*piVar2 == iVar8) {
                        iVar11 = *piVar2 + 1;
                        if (iVar8 == 0) {
                            iVar8 = 8;
                        } else {
                            iVar8 = iVar8 / 2 + iVar8;
                        }
                        if (iVar11 < iVar8) {
                            iVar11 = iVar8;
                        }
                        func_0x00018014fa90(piVar2, iVar11);
                    }
                    iVar9 = (int64_t)*piVar2;
                    iVar13 = *(int64_t *)(piVar2 + 2);
                    *(undefined4 *)(iVar13 + iVar9 * 0x18) = 2;
                    *(char *)(iVar13 + 4 + iVar9 * 0x18) = cVar19;
                    *(undefined *)(iVar13 + 5 + iVar9 * 0x18) = 1;
                    *(undefined2 *)(iVar13 + 6 + iVar9 * 0x18) = (undefined2)var_62h;
                    *(int64_t *)(iVar13 + 8 + iVar9 * 0x18) = iVar4;
                    *(int64_t *)(iVar13 + 0x10 + iVar9 * 0x18) = iVar4;
                    *piVar2 = *piVar2 + 1;
                }
                iVar11 = *(int32_t *)(iVar3 + 0x10) + 1;
                iVar8 = 1;
                if (0 < iVar11) {
                    iVar8 = iVar11;
                }
                *(int32_t *)(iVar3 + 0x10) = iVar8;
            }
        } else if (bVar5) goto code_r0x00018014792f;
    }
    if (((var_76h == '\0') || (iVar8 = iVar10, cVar7 = func_0x000180107ff0(1, 0, 0), cVar7 == '\0')) ||
       ((uVar1 & 0x20008) != 0)) {
        if ((char)var_20h != '\0') goto code_r0x000180147a6d;
code_r0x000180147a83:
        bVar18 = false;
    } else {
        if ((*(int32_t *)(iVar6 + 0x1654) != 0) && (*(int32_t *)(iVar6 + 0x1654) != iVar8)) {
            func_0x0001800f9f30(0, 0);
        }
        func_0x00018010e4a0(iVar10, uVar12);
        if ((char)var_20h == '\0') {
            if (cVar19 != '\0') goto code_r0x000180147a83;
            var_20h._0_1_ = '\x01';
            bVar16 = false;
            bVar17 = false;
        }
code_r0x000180147a6d:
        if ((*(int32_t *)(iVar6 + 0x21ec) != iVar10) || ((*(uint8_t *)(iVar6 + 0x21f8) & 1) == 0))
        goto code_r0x000180147a83;
        bVar18 = true;
    }
    if (((char)var_20h == '\0') || ((bVar18 && (cVar19 != '\0')))) goto code_r0x000180147be4;
    if ((*(int32_t *)(iVar6 + 0x23a4) == iVar10) || (iVar8 = 1, *(int32_t *)(iVar6 + 0x21ec) == iVar10)) {
        iVar8 = *(int32_t *)(iVar6 + 0x2228);
    }
    if (((((uVar1 & 0xc0) != 0) && (*(char *)(iVar6 + 0x258c) == '\0')) && (*(char *)(iVar6 + 0x258d) == '\0')) &&
       ((iVar8 == 1 && (*(int16_t *)(iVar6 + 0xb5a) == 1)))) {
        func_0x000180147450(piVar2[0x12], iVar4);
    }
    if ((uVar1 & 0x10) != 0) goto code_r0x000180147b45;
    if ((uVar1 & 1) == 0) {
        if (((iVar8 == 1) || (*(int32_t *)(iVar6 + 0x21ec) == iVar10)) && (!bVar16)) {
            if (((uVar1 & 0x20) == 0) || (cVar19 == '\0')) goto code_r0x000180147b3d;
            goto code_r0x000180147b45;
        }
        if (1 < iVar8 - 2U) goto code_r0x000180147b45;
        if (!bVar17) goto code_r0x000180147ba5;
        if (!bVar16) goto code_r0x000180147b3d;
code_r0x000180147b56:
        iVar13 = *(int64_t *)(iVar3 + 0x18);
        if (*(int64_t *)(iVar3 + 0x18) == -1) {
            *(int64_t *)(iVar3 + 0x18) = iVar4;
            iVar13 = iVar4;
        }
        if ((uVar1 & 8) == 0) {
            if (bVar16) {
code_r0x000180147b71:
                if (*(char *)(iVar3 + 0x14) != -1) {
                    bVar18 = *(char *)(iVar3 + 0x14) != '\0';
                    goto code_r0x000180147b8c;
                }
            }
            bVar18 = true;
        } else {
            if (*(char *)((int64_t)piVar2 + 0x53) != '\0') goto code_r0x000180147b71;
            bVar18 = cVar19 == '\0';
        }
code_r0x000180147b8c:
        uVar12 = 0xffffffff;
        if (*(char *)((int64_t)piVar2 + 0x55) != '\0') {
            uVar12 = 1;
        }
    } else {
code_r0x000180147b3d:
        func_0x000180147c50(piVar2);
code_r0x000180147b45:
        if ((bVar17) && ((uVar1 & 1) == 0)) goto code_r0x000180147b56;
code_r0x000180147ba5:
        if (((uVar1 & 8) != 0) || (bVar16)) {
            cVar19 = cVar19 == '\0';
        } else {
            cVar19 = true;
        }
        *(int64_t *)(iVar3 + 0x18) = iVar4;
        uVar12 = 1;
        iVar13 = iVar4;
        bVar18 = (bool)cVar19;
    }
    func_0x000180147ce0(piVar2, bVar18, uVar12, iVar13, iVar4);
code_r0x000180147be4:
    if (*(int64_t *)(iVar3 + 0x18) == iVar4) {
        *(bool *)(iVar3 + 0x14) = cVar19 != '\0';
    }
    if (*(int32_t *)(iVar6 + 0x21d0) == iVar10) {
        *(int64_t *)(iVar3 + 0x20) = iVar4;
        *(bool *)(iVar3 + 0x15) = cVar19 != '\0';
    }
    if (*(int64_t *)(iVar3 + 0x20) == iVar4) {
        *(undefined *)(piVar2 + 0x15) = 1;
    }
    *(char *)arg2 = cVar19;
    *(char *)arg3 = (char)var_20h;
    return;
}

// ============================================================
// Function: FUN_180147bef
// Address: 0x180147bef
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_76h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_77h
// WARNING: [rz-ghidra] Detected overlap for variable var_15h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.1801476e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint32_t uVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    bool bVar5;
    int64_t iVar6;
    char cVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    undefined8 uVar12;
    int64_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    bool bVar16;
    bool bVar17;
    bool bVar18;
    char cVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    char var_76h;
    int64_t var_70h;
    int64_t var_62h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar6 = *(int64_t *)0x180781f28;
    iVar10 = (int32_t)arg1;
    var_20h._0_1_ = *(char *)arg3;
    cVar19 = *(char *)arg2;
    piVar2 = *(int32_t **)(*(int64_t *)0x180781f28 + 0x25f0);
    uVar12 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x15e0);
    iVar3 = *(int64_t *)(piVar2 + 10);
    if ((char)var_20h != '\0') {
        *(undefined *)((int64_t)piVar2 + 0x52) = 1;
    }
    var_76h = '\0';
    if ((*(uint8_t *)(iVar6 + 0x1fc0) & 1) != 0) {
        var_76h = func_0x0001800fa150(0x20);
    }
    if ((*(char *)((int64_t)piVar2 + 0x52) == '\0') && (var_76h == '\0')) {
        return;
    }
    uVar1 = piVar2[0xd];
    iVar4 = *(int64_t *)(iVar6 + 0x1f90);
    uVar15 = piVar2[0x13] & 0x1000;
    bVar16 = uVar15 != 0;
    uVar14 = piVar2[0x13] & 0x2000;
    bVar17 = uVar14 != 0;
    bVar18 = false;
    if (*(int32_t *)(iVar6 + 0x21d0) == iVar10) {
        bVar18 = *(int64_t *)(iVar3 + 0x18) == -1;
    }
    if (*(char *)((int64_t)piVar2 + 0x51) == '\0') {
        if (piVar2[1] < 0) {
            func_0x00018014fa90(piVar2);
        }
        *piVar2 = 0;
        *(undefined *)((int64_t)piVar2 + 0x51) = 1;
    }
    if (*(int32_t *)(iVar6 + 0x23a4) == iVar10) {
        if ((uVar1 & 8) == 0) {
            if (uVar15 == 0) {
                var_20h._0_1_ = '\x01';
                cVar19 = '\x01';
            } else if (uVar14 != 0) {
                var_20h._0_1_ = '\x01';
            }
            goto code_r0x000180147835;
        }
        if (uVar14 != 0) {
            var_20h._0_1_ = '\x01';
            goto code_r0x000180147835;
        }
        if (uVar15 != 0) goto code_r0x000180147835;
code_r0x00018014783a:
        *(int64_t *)(iVar3 + 0x18) = iVar4;
        *(char *)(iVar3 + 0x14) = cVar19;
    } else {
code_r0x000180147835:
        if (bVar18) goto code_r0x00018014783a;
    }
    if (((piVar2[0x12] != 0) && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2588) == piVar2[0x12])) &&
       (*(char *)(*(int64_t *)0x180781f28 + 0x258c) != '\0')) {
        if (((*(float *)(*(int64_t *)0x180781f28 + 0x25e8) <= *(float *)(iVar6 + 0x1fc8)) ||
            (*(float *)(iVar6 + 0x1fd0) < *(float *)(*(int64_t *)0x180781f28 + 0x25e0) ||
             *(float *)(iVar6 + 0x1fd0) == *(float *)(*(int64_t *)0x180781f28 + 0x25e0))) ||
           ((*(float *)(*(int64_t *)0x180781f28 + 0x25e4) < *(float *)(iVar6 + 0x1fc4) ||
             *(float *)(*(int64_t *)0x180781f28 + 0x25e4) == *(float *)(iVar6 + 0x1fc4) ||
            (*(float *)(iVar6 + 0x1fcc) < *(float *)(*(int64_t *)0x180781f28 + 0x25dc) ||
             *(float *)(iVar6 + 0x1fcc) == *(float *)(*(int64_t *)0x180781f28 + 0x25dc))))) {
            bVar18 = false;
        } else {
            bVar18 = true;
        }
        if (((*(float *)(*(int64_t *)0x180781f28 + 0x25d8) <= *(float *)(iVar6 + 0x1fc8)) ||
            (*(float *)(iVar6 + 0x1fd0) < *(float *)(*(int64_t *)0x180781f28 + 0x25d0) ||
             *(float *)(iVar6 + 0x1fd0) == *(float *)(*(int64_t *)0x180781f28 + 0x25d0))) ||
           ((*(float *)(*(int64_t *)0x180781f28 + 0x25d4) < *(float *)(iVar6 + 0x1fc4) ||
             *(float *)(*(int64_t *)0x180781f28 + 0x25d4) == *(float *)(iVar6 + 0x1fc4) ||
            (*(float *)(iVar6 + 0x1fcc) < *(float *)(*(int64_t *)0x180781f28 + 0x25cc) ||
             *(float *)(iVar6 + 0x1fcc) == *(float *)(*(int64_t *)0x180781f28 + 0x25cc))))) {
            bVar5 = false;
        } else {
            bVar5 = true;
        }
        if (bVar18) {
            if ((!bVar5) && (cVar19 == '\0')) {
code_r0x00018014792f:
                if ((*(int32_t *)(iVar3 + 0x10) < 1) && (*(char *)(*(int64_t *)0x180781f28 + 0x258f) != '\0')) {
                    var_20h._0_1_ = '\x01';
                    *(undefined *)(*(int64_t *)0x180781f28 + 0x258f) = 0;
                } else {
                    iVar8 = piVar2[1];
                    cVar19 = cVar19 == '\0';
                    if (*piVar2 == iVar8) {
                        iVar11 = *piVar2 + 1;
                        if (iVar8 == 0) {
                            iVar8 = 8;
                        } else {
                            iVar8 = iVar8 / 2 + iVar8;
                        }
                        if (iVar11 < iVar8) {
                            iVar11 = iVar8;
                        }
                        func_0x00018014fa90(piVar2, iVar11);
                    }
                    iVar9 = (int64_t)*piVar2;
                    iVar13 = *(int64_t *)(piVar2 + 2);
                    *(undefined4 *)(iVar13 + iVar9 * 0x18) = 2;
                    *(char *)(iVar13 + 4 + iVar9 * 0x18) = cVar19;
                    *(undefined *)(iVar13 + 5 + iVar9 * 0x18) = 1;
                    *(undefined2 *)(iVar13 + 6 + iVar9 * 0x18) = (undefined2)var_62h;
                    *(int64_t *)(iVar13 + 8 + iVar9 * 0x18) = iVar4;
                    *(int64_t *)(iVar13 + 0x10 + iVar9 * 0x18) = iVar4;
                    *piVar2 = *piVar2 + 1;
                }
                iVar11 = *(int32_t *)(iVar3 + 0x10) + 1;
                iVar8 = 1;
                if (0 < iVar11) {
                    iVar8 = iVar11;
                }
                *(int32_t *)(iVar3 + 0x10) = iVar8;
            }
        } else if (bVar5) goto code_r0x00018014792f;
    }
    if (((var_76h == '\0') || (iVar8 = iVar10, cVar7 = func_0x000180107ff0(1, 0, 0), cVar7 == '\0')) ||
       ((uVar1 & 0x20008) != 0)) {
        if ((char)var_20h != '\0') goto code_r0x000180147a6d;
code_r0x000180147a83:
        bVar18 = false;
    } else {
        if ((*(int32_t *)(iVar6 + 0x1654) != 0) && (*(int32_t *)(iVar6 + 0x1654) != iVar8)) {
            func_0x0001800f9f30(0, 0);
        }
        func_0x00018010e4a0(iVar10, uVar12);
        if ((char)var_20h == '\0') {
            if (cVar19 != '\0') goto code_r0x000180147a83;
            var_20h._0_1_ = '\x01';
            bVar16 = false;
            bVar17 = false;
        }
code_r0x000180147a6d:
        if ((*(int32_t *)(iVar6 + 0x21ec) != iVar10) || ((*(uint8_t *)(iVar6 + 0x21f8) & 1) == 0))
        goto code_r0x000180147a83;
        bVar18 = true;
    }
    if (((char)var_20h == '\0') || ((bVar18 && (cVar19 != '\0')))) goto code_r0x000180147be4;
    if ((*(int32_t *)(iVar6 + 0x23a4) == iVar10) || (iVar8 = 1, *(int32_t *)(iVar6 + 0x21ec) == iVar10)) {
        iVar8 = *(int32_t *)(iVar6 + 0x2228);
    }
    if (((((uVar1 & 0xc0) != 0) && (*(char *)(iVar6 + 0x258c) == '\0')) && (*(char *)(iVar6 + 0x258d) == '\0')) &&
       ((iVar8 == 1 && (*(int16_t *)(iVar6 + 0xb5a) == 1)))) {
        func_0x000180147450(piVar2[0x12], iVar4);
    }
    if ((uVar1 & 0x10) != 0) goto code_r0x000180147b45;
    if ((uVar1 & 1) == 0) {
        if (((iVar8 == 1) || (*(int32_t *)(iVar6 + 0x21ec) == iVar10)) && (!bVar16)) {
            if (((uVar1 & 0x20) == 0) || (cVar19 == '\0')) goto code_r0x000180147b3d;
            goto code_r0x000180147b45;
        }
        if (1 < iVar8 - 2U) goto code_r0x000180147b45;
        if (!bVar17) goto code_r0x000180147ba5;
        if (!bVar16) goto code_r0x000180147b3d;
code_r0x000180147b56:
        iVar13 = *(int64_t *)(iVar3 + 0x18);
        if (*(int64_t *)(iVar3 + 0x18) == -1) {
            *(int64_t *)(iVar3 + 0x18) = iVar4;
            iVar13 = iVar4;
        }
        if ((uVar1 & 8) == 0) {
            if (bVar16) {
code_r0x000180147b71:
                if (*(char *)(iVar3 + 0x14) != -1) {
                    bVar18 = *(char *)(iVar3 + 0x14) != '\0';
                    goto code_r0x000180147b8c;
                }
            }
            bVar18 = true;
        } else {
            if (*(char *)((int64_t)piVar2 + 0x53) != '\0') goto code_r0x000180147b71;
            bVar18 = cVar19 == '\0';
        }
code_r0x000180147b8c:
        uVar12 = 0xffffffff;
        if (*(char *)((int64_t)piVar2 + 0x55) != '\0') {
            uVar12 = 1;
        }
    } else {
code_r0x000180147b3d:
        func_0x000180147c50(piVar2);
code_r0x000180147b45:
        if ((bVar17) && ((uVar1 & 1) == 0)) goto code_r0x000180147b56;
code_r0x000180147ba5:
        if (((uVar1 & 8) != 0) || (bVar16)) {
            cVar19 = cVar19 == '\0';
        } else {
            cVar19 = true;
        }
        *(int64_t *)(iVar3 + 0x18) = iVar4;
        uVar12 = 1;
        iVar13 = iVar4;
        bVar18 = (bool)cVar19;
    }
    func_0x000180147ce0(piVar2, bVar18, uVar12, iVar13, iVar4);
code_r0x000180147be4:
    if (*(int64_t *)(iVar3 + 0x18) == iVar4) {
        *(bool *)(iVar3 + 0x14) = cVar19 != '\0';
    }
    if (*(int32_t *)(iVar6 + 0x21d0) == iVar10) {
        *(int64_t *)(iVar3 + 0x20) = iVar4;
        *(bool *)(iVar3 + 0x15) = cVar19 != '\0';
    }
    if (*(int64_t *)(iVar3 + 0x20) == iVar4) {
        *(undefined *)(piVar2 + 0x15) = 1;
    }
    *(char *)arg2 = cVar19;
    *(char *)arg3 = (char)var_20h;
    return;
}

// ============================================================
// Function: FUN_180147c06
// Address: 0x180147c06
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_76h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_77h
// WARNING: [rz-ghidra] Detected overlap for variable var_15h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.1801476e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint32_t uVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    bool bVar5;
    int64_t iVar6;
    char cVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    undefined8 uVar12;
    int64_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    bool bVar16;
    bool bVar17;
    bool bVar18;
    char cVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    char var_76h;
    int64_t var_70h;
    int64_t var_62h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar6 = *(int64_t *)0x180781f28;
    iVar10 = (int32_t)arg1;
    var_20h._0_1_ = *(char *)arg3;
    cVar19 = *(char *)arg2;
    piVar2 = *(int32_t **)(*(int64_t *)0x180781f28 + 0x25f0);
    uVar12 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x15e0);
    iVar3 = *(int64_t *)(piVar2 + 10);
    if ((char)var_20h != '\0') {
        *(undefined *)((int64_t)piVar2 + 0x52) = 1;
    }
    var_76h = '\0';
    if ((*(uint8_t *)(iVar6 + 0x1fc0) & 1) != 0) {
        var_76h = func_0x0001800fa150(0x20);
    }
    if ((*(char *)((int64_t)piVar2 + 0x52) == '\0') && (var_76h == '\0')) {
        return;
    }
    uVar1 = piVar2[0xd];
    iVar4 = *(int64_t *)(iVar6 + 0x1f90);
    uVar15 = piVar2[0x13] & 0x1000;
    bVar16 = uVar15 != 0;
    uVar14 = piVar2[0x13] & 0x2000;
    bVar17 = uVar14 != 0;
    bVar18 = false;
    if (*(int32_t *)(iVar6 + 0x21d0) == iVar10) {
        bVar18 = *(int64_t *)(iVar3 + 0x18) == -1;
    }
    if (*(char *)((int64_t)piVar2 + 0x51) == '\0') {
        if (piVar2[1] < 0) {
            func_0x00018014fa90(piVar2);
        }
        *piVar2 = 0;
        *(undefined *)((int64_t)piVar2 + 0x51) = 1;
    }
    if (*(int32_t *)(iVar6 + 0x23a4) == iVar10) {
        if ((uVar1 & 8) == 0) {
            if (uVar15 == 0) {
                var_20h._0_1_ = '\x01';
                cVar19 = '\x01';
            } else if (uVar14 != 0) {
                var_20h._0_1_ = '\x01';
            }
            goto code_r0x000180147835;
        }
        if (uVar14 != 0) {
            var_20h._0_1_ = '\x01';
            goto code_r0x000180147835;
        }
        if (uVar15 != 0) goto code_r0x000180147835;
code_r0x00018014783a:
        *(int64_t *)(iVar3 + 0x18) = iVar4;
        *(char *)(iVar3 + 0x14) = cVar19;
    } else {
code_r0x000180147835:
        if (bVar18) goto code_r0x00018014783a;
    }
    if (((piVar2[0x12] != 0) && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2588) == piVar2[0x12])) &&
       (*(char *)(*(int64_t *)0x180781f28 + 0x258c) != '\0')) {
        if (((*(float *)(*(int64_t *)0x180781f28 + 0x25e8) <= *(float *)(iVar6 + 0x1fc8)) ||
            (*(float *)(iVar6 + 0x1fd0) < *(float *)(*(int64_t *)0x180781f28 + 0x25e0) ||
             *(float *)(iVar6 + 0x1fd0) == *(float *)(*(int64_t *)0x180781f28 + 0x25e0))) ||
           ((*(float *)(*(int64_t *)0x180781f28 + 0x25e4) < *(float *)(iVar6 + 0x1fc4) ||
             *(float *)(*(int64_t *)0x180781f28 + 0x25e4) == *(float *)(iVar6 + 0x1fc4) ||
            (*(float *)(iVar6 + 0x1fcc) < *(float *)(*(int64_t *)0x180781f28 + 0x25dc) ||
             *(float *)(iVar6 + 0x1fcc) == *(float *)(*(int64_t *)0x180781f28 + 0x25dc))))) {
            bVar18 = false;
        } else {
            bVar18 = true;
        }
        if (((*(float *)(*(int64_t *)0x180781f28 + 0x25d8) <= *(float *)(iVar6 + 0x1fc8)) ||
            (*(float *)(iVar6 + 0x1fd0) < *(float *)(*(int64_t *)0x180781f28 + 0x25d0) ||
             *(float *)(iVar6 + 0x1fd0) == *(float *)(*(int64_t *)0x180781f28 + 0x25d0))) ||
           ((*(float *)(*(int64_t *)0x180781f28 + 0x25d4) < *(float *)(iVar6 + 0x1fc4) ||
             *(float *)(*(int64_t *)0x180781f28 + 0x25d4) == *(float *)(iVar6 + 0x1fc4) ||
            (*(float *)(iVar6 + 0x1fcc) < *(float *)(*(int64_t *)0x180781f28 + 0x25cc) ||
             *(float *)(iVar6 + 0x1fcc) == *(float *)(*(int64_t *)0x180781f28 + 0x25cc))))) {
            bVar5 = false;
        } else {
            bVar5 = true;
        }
        if (bVar18) {
            if ((!bVar5) && (cVar19 == '\0')) {
code_r0x00018014792f:
                if ((*(int32_t *)(iVar3 + 0x10) < 1) && (*(char *)(*(int64_t *)0x180781f28 + 0x258f) != '\0')) {
                    var_20h._0_1_ = '\x01';
                    *(undefined *)(*(int64_t *)0x180781f28 + 0x258f) = 0;
                } else {
                    iVar8 = piVar2[1];
                    cVar19 = cVar19 == '\0';
                    if (*piVar2 == iVar8) {
                        iVar11 = *piVar2 + 1;
                        if (iVar8 == 0) {
                            iVar8 = 8;
                        } else {
                            iVar8 = iVar8 / 2 + iVar8;
                        }
                        if (iVar11 < iVar8) {
                            iVar11 = iVar8;
                        }
                        func_0x00018014fa90(piVar2, iVar11);
                    }
                    iVar9 = (int64_t)*piVar2;
                    iVar13 = *(int64_t *)(piVar2 + 2);
                    *(undefined4 *)(iVar13 + iVar9 * 0x18) = 2;
                    *(char *)(iVar13 + 4 + iVar9 * 0x18) = cVar19;
                    *(undefined *)(iVar13 + 5 + iVar9 * 0x18) = 1;
                    *(undefined2 *)(iVar13 + 6 + iVar9 * 0x18) = (undefined2)var_62h;
                    *(int64_t *)(iVar13 + 8 + iVar9 * 0x18) = iVar4;
                    *(int64_t *)(iVar13 + 0x10 + iVar9 * 0x18) = iVar4;
                    *piVar2 = *piVar2 + 1;
                }
                iVar11 = *(int32_t *)(iVar3 + 0x10) + 1;
                iVar8 = 1;
                if (0 < iVar11) {
                    iVar8 = iVar11;
                }
                *(int32_t *)(iVar3 + 0x10) = iVar8;
            }
        } else if (bVar5) goto code_r0x00018014792f;
    }
    if (((var_76h == '\0') || (iVar8 = iVar10, cVar7 = func_0x000180107ff0(1, 0, 0), cVar7 == '\0')) ||
       ((uVar1 & 0x20008) != 0)) {
        if ((char)var_20h != '\0') goto code_r0x000180147a6d;
code_r0x000180147a83:
        bVar18 = false;
    } else {
        if ((*(int32_t *)(iVar6 + 0x1654) != 0) && (*(int32_t *)(iVar6 + 0x1654) != iVar8)) {
            func_0x0001800f9f30(0, 0);
        }
        func_0x00018010e4a0(iVar10, uVar12);
        if ((char)var_20h == '\0') {
            if (cVar19 != '\0') goto code_r0x000180147a83;
            var_20h._0_1_ = '\x01';
            bVar16 = false;
            bVar17 = false;
        }
code_r0x000180147a6d:
        if ((*(int32_t *)(iVar6 + 0x21ec) != iVar10) || ((*(uint8_t *)(iVar6 + 0x21f8) & 1) == 0))
        goto code_r0x000180147a83;
        bVar18 = true;
    }
    if (((char)var_20h == '\0') || ((bVar18 && (cVar19 != '\0')))) goto code_r0x000180147be4;
    if ((*(int32_t *)(iVar6 + 0x23a4) == iVar10) || (iVar8 = 1, *(int32_t *)(iVar6 + 0x21ec) == iVar10)) {
        iVar8 = *(int32_t *)(iVar6 + 0x2228);
    }
    if (((((uVar1 & 0xc0) != 0) && (*(char *)(iVar6 + 0x258c) == '\0')) && (*(char *)(iVar6 + 0x258d) == '\0')) &&
       ((iVar8 == 1 && (*(int16_t *)(iVar6 + 0xb5a) == 1)))) {
        func_0x000180147450(piVar2[0x12], iVar4);
    }
    if ((uVar1 & 0x10) != 0) goto code_r0x000180147b45;
    if ((uVar1 & 1) == 0) {
        if (((iVar8 == 1) || (*(int32_t *)(iVar6 + 0x21ec) == iVar10)) && (!bVar16)) {
            if (((uVar1 & 0x20) == 0) || (cVar19 == '\0')) goto code_r0x000180147b3d;
            goto code_r0x000180147b45;
        }
        if (1 < iVar8 - 2U) goto code_r0x000180147b45;
        if (!bVar17) goto code_r0x000180147ba5;
        if (!bVar16) goto code_r0x000180147b3d;
code_r0x000180147b56:
        iVar13 = *(int64_t *)(iVar3 + 0x18);
        if (*(int64_t *)(iVar3 + 0x18) == -1) {
            *(int64_t *)(iVar3 + 0x18) = iVar4;
            iVar13 = iVar4;
        }
        if ((uVar1 & 8) == 0) {
            if (bVar16) {
code_r0x000180147b71:
                if (*(char *)(iVar3 + 0x14) != -1) {
                    bVar18 = *(char *)(iVar3 + 0x14) != '\0';
                    goto code_r0x000180147b8c;
                }
            }
            bVar18 = true;
        } else {
            if (*(char *)((int64_t)piVar2 + 0x53) != '\0') goto code_r0x000180147b71;
            bVar18 = cVar19 == '\0';
        }
code_r0x000180147b8c:
        uVar12 = 0xffffffff;
        if (*(char *)((int64_t)piVar2 + 0x55) != '\0') {
            uVar12 = 1;
        }
    } else {
code_r0x000180147b3d:
        func_0x000180147c50(piVar2);
code_r0x000180147b45:
        if ((bVar17) && ((uVar1 & 1) == 0)) goto code_r0x000180147b56;
code_r0x000180147ba5:
        if (((uVar1 & 8) != 0) || (bVar16)) {
            cVar19 = cVar19 == '\0';
        } else {
            cVar19 = true;
        }
        *(int64_t *)(iVar3 + 0x18) = iVar4;
        uVar12 = 1;
        iVar13 = iVar4;
        bVar18 = (bool)cVar19;
    }
    func_0x000180147ce0(piVar2, bVar18, uVar12, iVar13, iVar4);
code_r0x000180147be4:
    if (*(int64_t *)(iVar3 + 0x18) == iVar4) {
        *(bool *)(iVar3 + 0x14) = cVar19 != '\0';
    }
    if (*(int32_t *)(iVar6 + 0x21d0) == iVar10) {
        *(int64_t *)(iVar3 + 0x20) = iVar4;
        *(bool *)(iVar3 + 0x15) = cVar19 != '\0';
    }
    if (*(int64_t *)(iVar3 + 0x20) == iVar4) {
        *(undefined *)(piVar2 + 0x15) = 1;
    }
    *(char *)arg2 = cVar19;
    *(char *)arg3 = (char)var_20h;
    return;
}

// ============================================================
// Function: FUN_180147c1e
// Address: 0x180147c1e
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_76h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_77h
// WARNING: [rz-ghidra] Detected overlap for variable var_15h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.1801476e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint32_t uVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    bool bVar5;
    int64_t iVar6;
    char cVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    undefined8 uVar12;
    int64_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    bool bVar16;
    bool bVar17;
    bool bVar18;
    char cVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    char var_76h;
    int64_t var_70h;
    int64_t var_62h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar6 = *(int64_t *)0x180781f28;
    iVar10 = (int32_t)arg1;
    var_20h._0_1_ = *(char *)arg3;
    cVar19 = *(char *)arg2;
    piVar2 = *(int32_t **)(*(int64_t *)0x180781f28 + 0x25f0);
    uVar12 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x15e0);
    iVar3 = *(int64_t *)(piVar2 + 10);
    if ((char)var_20h != '\0') {
        *(undefined *)((int64_t)piVar2 + 0x52) = 1;
    }
    var_76h = '\0';
    if ((*(uint8_t *)(iVar6 + 0x1fc0) & 1) != 0) {
        var_76h = func_0x0001800fa150(0x20);
    }
    if ((*(char *)((int64_t)piVar2 + 0x52) == '\0') && (var_76h == '\0')) {
        return;
    }
    uVar1 = piVar2[0xd];
    iVar4 = *(int64_t *)(iVar6 + 0x1f90);
    uVar15 = piVar2[0x13] & 0x1000;
    bVar16 = uVar15 != 0;
    uVar14 = piVar2[0x13] & 0x2000;
    bVar17 = uVar14 != 0;
    bVar18 = false;
    if (*(int32_t *)(iVar6 + 0x21d0) == iVar10) {
        bVar18 = *(int64_t *)(iVar3 + 0x18) == -1;
    }
    if (*(char *)((int64_t)piVar2 + 0x51) == '\0') {
        if (piVar2[1] < 0) {
            func_0x00018014fa90(piVar2);
        }
        *piVar2 = 0;
        *(undefined *)((int64_t)piVar2 + 0x51) = 1;
    }
    if (*(int32_t *)(iVar6 + 0x23a4) == iVar10) {
        if ((uVar1 & 8) == 0) {
            if (uVar15 == 0) {
                var_20h._0_1_ = '\x01';
                cVar19 = '\x01';
            } else if (uVar14 != 0) {
                var_20h._0_1_ = '\x01';
            }
            goto code_r0x000180147835;
        }
        if (uVar14 != 0) {
            var_20h._0_1_ = '\x01';
            goto code_r0x000180147835;
        }
        if (uVar15 != 0) goto code_r0x000180147835;
code_r0x00018014783a:
        *(int64_t *)(iVar3 + 0x18) = iVar4;
        *(char *)(iVar3 + 0x14) = cVar19;
    } else {
code_r0x000180147835:
        if (bVar18) goto code_r0x00018014783a;
    }
    if (((piVar2[0x12] != 0) && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2588) == piVar2[0x12])) &&
       (*(char *)(*(int64_t *)0x180781f28 + 0x258c) != '\0')) {
        if (((*(float *)(*(int64_t *)0x180781f28 + 0x25e8) <= *(float *)(iVar6 + 0x1fc8)) ||
            (*(float *)(iVar6 + 0x1fd0) < *(float *)(*(int64_t *)0x180781f28 + 0x25e0) ||
             *(float *)(iVar6 + 0x1fd0) == *(float *)(*(int64_t *)0x180781f28 + 0x25e0))) ||
           ((*(float *)(*(int64_t *)0x180781f28 + 0x25e4) < *(float *)(iVar6 + 0x1fc4) ||
             *(float *)(*(int64_t *)0x180781f28 + 0x25e4) == *(float *)(iVar6 + 0x1fc4) ||
            (*(float *)(iVar6 + 0x1fcc) < *(float *)(*(int64_t *)0x180781f28 + 0x25dc) ||
             *(float *)(iVar6 + 0x1fcc) == *(float *)(*(int64_t *)0x180781f28 + 0x25dc))))) {
            bVar18 = false;
        } else {
            bVar18 = true;
        }
        if (((*(float *)(*(int64_t *)0x180781f28 + 0x25d8) <= *(float *)(iVar6 + 0x1fc8)) ||
            (*(float *)(iVar6 + 0x1fd0) < *(float *)(*(int64_t *)0x180781f28 + 0x25d0) ||
             *(float *)(iVar6 + 0x1fd0) == *(float *)(*(int64_t *)0x180781f28 + 0x25d0))) ||
           ((*(float *)(*(int64_t *)0x180781f28 + 0x25d4) < *(float *)(iVar6 + 0x1fc4) ||
             *(float *)(*(int64_t *)0x180781f28 + 0x25d4) == *(float *)(iVar6 + 0x1fc4) ||
            (*(float *)(iVar6 + 0x1fcc) < *(float *)(*(int64_t *)0x180781f28 + 0x25cc) ||
             *(float *)(iVar6 + 0x1fcc) == *(float *)(*(int64_t *)0x180781f28 + 0x25cc))))) {
            bVar5 = false;
        } else {
            bVar5 = true;
        }
        if (bVar18) {
            if ((!bVar5) && (cVar19 == '\0')) {
code_r0x00018014792f:
                if ((*(int32_t *)(iVar3 + 0x10) < 1) && (*(char *)(*(int64_t *)0x180781f28 + 0x258f) != '\0')) {
                    var_20h._0_1_ = '\x01';
                    *(undefined *)(*(int64_t *)0x180781f28 + 0x258f) = 0;
                } else {
                    iVar8 = piVar2[1];
                    cVar19 = cVar19 == '\0';
                    if (*piVar2 == iVar8) {
                        iVar11 = *piVar2 + 1;
                        if (iVar8 == 0) {
                            iVar8 = 8;
                        } else {
                            iVar8 = iVar8 / 2 + iVar8;
                        }
                        if (iVar11 < iVar8) {
                            iVar11 = iVar8;
                        }
                        func_0x00018014fa90(piVar2, iVar11);
                    }
                    iVar9 = (int64_t)*piVar2;
                    iVar13 = *(int64_t *)(piVar2 + 2);
                    *(undefined4 *)(iVar13 + iVar9 * 0x18) = 2;
                    *(char *)(iVar13 + 4 + iVar9 * 0x18) = cVar19;
                    *(undefined *)(iVar13 + 5 + iVar9 * 0x18) = 1;
                    *(undefined2 *)(iVar13 + 6 + iVar9 * 0x18) = (undefined2)var_62h;
                    *(int64_t *)(iVar13 + 8 + iVar9 * 0x18) = iVar4;
                    *(int64_t *)(iVar13 + 0x10 + iVar9 * 0x18) = iVar4;
                    *piVar2 = *piVar2 + 1;
                }
                iVar11 = *(int32_t *)(iVar3 + 0x10) + 1;
                iVar8 = 1;
                if (0 < iVar11) {
                    iVar8 = iVar11;
                }
                *(int32_t *)(iVar3 + 0x10) = iVar8;
            }
        } else if (bVar5) goto code_r0x00018014792f;
    }
    if (((var_76h == '\0') || (iVar8 = iVar10, cVar7 = func_0x000180107ff0(1, 0, 0), cVar7 == '\0')) ||
       ((uVar1 & 0x20008) != 0)) {
        if ((char)var_20h != '\0') goto code_r0x000180147a6d;
code_r0x000180147a83:
        bVar18 = false;
    } else {
        if ((*(int32_t *)(iVar6 + 0x1654) != 0) && (*(int32_t *)(iVar6 + 0x1654) != iVar8)) {
            func_0x0001800f9f30(0, 0);
        }
        func_0x00018010e4a0(iVar10, uVar12);
        if ((char)var_20h == '\0') {
            if (cVar19 != '\0') goto code_r0x000180147a83;
            var_20h._0_1_ = '\x01';
            bVar16 = false;
            bVar17 = false;
        }
code_r0x000180147a6d:
        if ((*(int32_t *)(iVar6 + 0x21ec) != iVar10) || ((*(uint8_t *)(iVar6 + 0x21f8) & 1) == 0))
        goto code_r0x000180147a83;
        bVar18 = true;
    }
    if (((char)var_20h == '\0') || ((bVar18 && (cVar19 != '\0')))) goto code_r0x000180147be4;
    if ((*(int32_t *)(iVar6 + 0x23a4) == iVar10) || (iVar8 = 1, *(int32_t *)(iVar6 + 0x21ec) == iVar10)) {
        iVar8 = *(int32_t *)(iVar6 + 0x2228);
    }
    if (((((uVar1 & 0xc0) != 0) && (*(char *)(iVar6 + 0x258c) == '\0')) && (*(char *)(iVar6 + 0x258d) == '\0')) &&
       ((iVar8 == 1 && (*(int16_t *)(iVar6 + 0xb5a) == 1)))) {
        func_0x000180147450(piVar2[0x12], iVar4);
    }
    if ((uVar1 & 0x10) != 0) goto code_r0x000180147b45;
    if ((uVar1 & 1) == 0) {
        if (((iVar8 == 1) || (*(int32_t *)(iVar6 + 0x21ec) == iVar10)) && (!bVar16)) {
            if (((uVar1 & 0x20) == 0) || (cVar19 == '\0')) goto code_r0x000180147b3d;
            goto code_r0x000180147b45;
        }
        if (1 < iVar8 - 2U) goto code_r0x000180147b45;
        if (!bVar17) goto code_r0x000180147ba5;
        if (!bVar16) goto code_r0x000180147b3d;
code_r0x000180147b56:
        iVar13 = *(int64_t *)(iVar3 + 0x18);
        if (*(int64_t *)(iVar3 + 0x18) == -1) {
            *(int64_t *)(iVar3 + 0x18) = iVar4;
            iVar13 = iVar4;
        }
        if ((uVar1 & 8) == 0) {
            if (bVar16) {
code_r0x000180147b71:
                if (*(char *)(iVar3 + 0x14) != -1) {
                    bVar18 = *(char *)(iVar3 + 0x14) != '\0';
                    goto code_r0x000180147b8c;
                }
            }
            bVar18 = true;
        } else {
            if (*(char *)((int64_t)piVar2 + 0x53) != '\0') goto code_r0x000180147b71;
            bVar18 = cVar19 == '\0';
        }
code_r0x000180147b8c:
        uVar12 = 0xffffffff;
        if (*(char *)((int64_t)piVar2 + 0x55) != '\0') {
            uVar12 = 1;
        }
    } else {
code_r0x000180147b3d:
        func_0x000180147c50(piVar2);
code_r0x000180147b45:
        if ((bVar17) && ((uVar1 & 1) == 0)) goto code_r0x000180147b56;
code_r0x000180147ba5:
        if (((uVar1 & 8) != 0) || (bVar16)) {
            cVar19 = cVar19 == '\0';
        } else {
            cVar19 = true;
        }
        *(int64_t *)(iVar3 + 0x18) = iVar4;
        uVar12 = 1;
        iVar13 = iVar4;
        bVar18 = (bool)cVar19;
    }
    func_0x000180147ce0(piVar2, bVar18, uVar12, iVar13, iVar4);
code_r0x000180147be4:
    if (*(int64_t *)(iVar3 + 0x18) == iVar4) {
        *(bool *)(iVar3 + 0x14) = cVar19 != '\0';
    }
    if (*(int32_t *)(iVar6 + 0x21d0) == iVar10) {
        *(int64_t *)(iVar3 + 0x20) = iVar4;
        *(bool *)(iVar3 + 0x15) = cVar19 != '\0';
    }
    if (*(int64_t *)(iVar3 + 0x20) == iVar4) {
        *(undefined *)(piVar2 + 0x15) = 1;
    }
    *(char *)arg2 = cVar19;
    *(char *)arg3 = (char)var_20h;
    return;
}

// ============================================================
// Function: FUN_180147c50
// Address: 0x180147c50
// Size: 131 bytes
// ============================================================
void fcn.180147c50(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t var_22h;
    
    iVar1 = *(int32_t *)(arg1 + 4);
    if (iVar1 < 0) {
        iVar1 = iVar1 / 2 + iVar1;
        iVar4 = 0;
        if (0 < iVar1) {
            iVar4 = iVar1;
        }
        func_0x00018014fa90(arg1, iVar4);
    }
    *(undefined4 *)arg1 = 0;
    if (*(int32_t *)(arg1 + 4) == 0) {
        func_0x00018014fa90(arg1, 8);
    }
    iVar3 = (int64_t)*(int32_t *)arg1;
    iVar2 = *(int64_t *)(arg1 + 8);
    *(undefined4 *)(iVar2 + iVar3 * 0x18) = 1;
    *(undefined2 *)(iVar2 + 4 + iVar3 * 0x18) = 0;
    iVar2 = iVar2 + iVar3 * 0x18;
    *(undefined2 *)(iVar2 + 6) = (undefined2)var_22h;
    *(undefined8 *)(iVar2 + 8) = 0xffffffffffffffff;
    *(undefined8 *)(iVar2 + 0x10) = 0xffffffffffffffff;
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_180147ce0
// Address: 0x180147ce0
// Size: 161 bytes
// ============================================================
void fcn.180147ce0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t var_68h;
    int64_t var_42h;
    
    iVar2 = *(int32_t *)(arg1 + 4);
    iVar5 = arg_28h;
    if (0 < (int32_t)arg3) {
        iVar5 = arg4;
        arg4 = arg_28h;
    }
    if (*(int32_t *)arg1 == iVar2) {
        iVar4 = *(int32_t *)arg1 + 1;
        if (iVar2 == 0) {
            iVar2 = 8;
        } else {
            iVar2 = iVar2 / 2 + iVar2;
        }
        if (iVar4 < iVar2) {
            iVar4 = iVar2;
        }
        func_0x00018014fa90(arg1, iVar4);
    }
    iVar3 = (int64_t)*(int32_t *)arg1;
    iVar1 = *(int64_t *)(arg1 + 8);
    *(undefined4 *)(iVar1 + iVar3 * 0x18) = 2;
    *(char *)(iVar1 + 4 + iVar3 * 0x18) = (char)arg2;
    *(char *)(iVar1 + 5 + iVar3 * 0x18) = (char)arg3;
    iVar1 = iVar1 + iVar3 * 0x18;
    *(undefined2 *)(iVar1 + 6) = (undefined2)var_42h;
    *(int64_t *)(iVar1 + 8) = iVar5;
    *(int64_t *)(iVar1 + 0x10) = arg4;
    *(int32_t *)arg1 = *(int32_t *)arg1 + 1;
    return;
}

// ============================================================
// Function: FUN_180147f30
// Address: 0x180147f30
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180147f30(void)
{
    uint32_t uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    float fVar11;
    float fVar12;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar6 = *(int64_t *)(iVar8 + 0x15e0);
    if (*(char *)(iVar6 + 0x10e) == '\0') {
        if ((((*(char *)(iVar8 + 0x2279) == '\0') || (*(int32_t *)(iVar8 + 0x22c8) != 0)) ||
            (*(int32_t *)(iVar8 + 0x2338) != 0)) ||
           ((1 < *(uint32_t *)(iVar8 + 0x2288) ||
            (iVar10 = *(int64_t *)(iVar8 + 0x21d8), (*(uint32_t *)(iVar10 + 0x14) & 0x10000000) == 0)))) {
            if ((*(int64_t *)(iVar8 + 0x21d8) == iVar6) &&
               ((*(char *)(iVar8 + 0x2279) != '\0' && (*(int32_t *)(iVar8 + 0x21e4) == *(int32_t *)(iVar6 + 0x1b0))))) {
                *(uint32_t *)(iVar8 + 0x227c) = *(uint32_t *)(iVar8 + 0x227c) & 0xfffffff4;
                *(uint32_t *)(iVar8 + 0x227c) = *(uint32_t *)(iVar8 + 0x227c) | 4;
            }
        } else {
            iVar9 = *(int64_t *)(iVar10 + 0x408);
            while ((iVar9 != 0 &&
                   (iVar7 = *(int64_t *)(iVar10 + 0x408), (*(uint32_t *)(iVar7 + 0x14) & 0x10000000) != 0))) {
                iVar9 = *(int64_t *)(iVar7 + 0x408);
                iVar10 = iVar7;
            }
            if (((*(int64_t *)(iVar10 + 0x408) == iVar6) && (*(int32_t *)(iVar10 + 0x218) == 0)) &&
               ((*(uint8_t *)(iVar8 + 0x227c) & 0x80) == 0)) {
                func_0x00018010e050(iVar6, 0);
                func_0x00018010e3f0(*(undefined4 *)(iVar6 + 0x454), 1, 0, iVar6 + 0x468);
                if (*(char *)(iVar8 + 0x21cc) != '\0') {
                    *(undefined *)(iVar8 + 0x21cc) = 0;
                    *(undefined *)(iVar8 + 0x2238) = 2;
                }
                iVar10 = *(int64_t *)0x180781f28;
                uVar1 = *(uint32_t *)(iVar8 + 0x227c);
                uVar2 = *(undefined4 *)(iVar8 + 0x2280);
                uVar3 = *(undefined4 *)(iVar8 + 0x2290);
                uVar4 = *(undefined4 *)(iVar8 + 0x2288);
                *(undefined2 *)(iVar8 + 0x21cd) = 0x101;
                *(undefined2 *)(iVar10 + 0x2278) = 0;
                *(undefined *)(iVar10 + 0x227a) = 1;
                *(bool *)(iVar10 + 0x2239) = *(char *)(iVar10 + 0x223a) != '\0';
                *(uint32_t *)(iVar10 + 0x227c) = uVar1 | 0x80;
                *(undefined4 *)(iVar10 + 0x2288) = uVar4;
                *(undefined4 *)(iVar10 + 0x2290) = uVar3;
                *(undefined4 *)(iVar10 + 0x2280) = uVar2;
            }
        }
        func_0x0001800fc8f0();
        iVar5 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
        if (iVar5 < 2) {
            if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                          (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
            }
        } else {
            *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar5 + -1;
        }
        *(float *)(iVar6 + 0x1bc) = *(float *)(iVar6 + 0x158) - *(float *)(iVar6 + 0x60);
        iVar10 = (int64_t)*(int32_t *)(iVar8 + 0x2110) * 0x3c;
        iVar8 = *(int64_t *)(iVar8 + 0x2118);
        uVar2 = *(undefined4 *)(iVar10 + -0x30 + iVar8);
        uVar3 = *(undefined4 *)(iVar10 + -0x2c + iVar8);
        *(undefined *)(iVar10 + -4 + iVar8) = 0;
        fVar12 = *(float *)(iVar6 + 0x170) - *(float *)(iVar6 + 0xd4);
        fVar11 = *(float *)(iVar6 + 0x178);
        if (*(float *)(iVar6 + 0x178) <= fVar12) {
            fVar11 = fVar12;
        }
        *(float *)(iVar6 + 0x178) = fVar11;
        func_0x00018010c110();
        *(undefined4 *)(iVar6 + 0x170) = uVar2;
        *(undefined4 *)(iVar6 + 0x174) = uVar3;
        *(undefined4 *)(iVar6 + 0x214) = 1;
        *(undefined *)(iVar6 + 0x198) = 0;
        *(undefined4 *)(iVar6 + 0x1b0) = 0;
        *(undefined *)(iVar6 + 0x1bb) = 0;
    }
    return;
}

