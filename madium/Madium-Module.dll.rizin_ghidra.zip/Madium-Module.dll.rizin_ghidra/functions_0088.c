// Chunk 88 - 50 functions

// ============================================================
// Function: FUN_180126760
// Address: 0x180126760
// Size: 215 bytes
// ============================================================
void fcn.180126760(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4,
                  undefined8 placeholder_4, int64_t arg_30h, int64_t arg_68h)
{
    float fVar1;
    float in_XMM2_Da;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (((arg4 & 0xff000000U) != 0) && (0.5 <= in_XMM2_Da)) {
        if ((int32_t)placeholder_4 < 1) {
            func_0x0001801257a0(arg1, placeholder_1, in_XMM2_Da - 0.5, 0, 0x30);
            *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + -1;
        } else {
            if ((int32_t)placeholder_4 < 3) {
                placeholder_4._0_4_ = 3;
            } else if (0x200 < (int32_t)placeholder_4) {
                placeholder_4._0_4_ = 0x200;
            }
            fVar1 = (((float)(int32_t)placeholder_4 - 1.0) * 6.283185) / (float)(int32_t)placeholder_4;
            func_0x000180125bc0(arg1, fVar1, in_XMM2_Da - 0.5, 0, fVar1, (int32_t)placeholder_4 + -1);
        }
        func_0x0001801248e0(arg1, *(undefined8 *)(arg1 + 0x58), *(undefined4 *)(arg1 + 0x50), arg4 & 0xffffffff, 1, 
                            (undefined4)arg_30h);
        *(undefined4 *)(arg1 + 0x50) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180126840
// Address: 0x180126840
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180126840(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4, int64_t arg_68h)
{
    float fVar1;
    float in_XMM2_Da;
    int64_t var_8h;
    int64_t var_10h;
    int32_t in_stack_00000028;
    int64_t var_18h;
    
    if (((arg4 & 0xff000000U) != 0) && (0.5 <= in_XMM2_Da)) {
        if (in_stack_00000028 < 1) {
            func_0x0001801257a0(arg1, placeholder_1, placeholder_2, 0, 0x30);
            *(int32_t *)(arg1 + 0x50) = *(int32_t *)(arg1 + 0x50) + -1;
        } else {
            if (in_stack_00000028 < 3) {
                in_stack_00000028 = 3;
            } else if (0x200 < in_stack_00000028) {
                in_stack_00000028 = 0x200;
            }
            fVar1 = (((float)in_stack_00000028 - 1.0) * 6.283185) / (float)in_stack_00000028;
            func_0x000180125bc0(arg1, fVar1, placeholder_2, 0, fVar1, in_stack_00000028 + -1);
        }
        func_0x0001800f3bc0(arg1, arg4 & 0xffffffff);
    }
    return;
}

// ============================================================
// Function: FUN_1801268f0
// Address: 0x1801268f0
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801268f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    bool bVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    if ((arg_38h & 0xff000000U) != 0) {
        if ((*(int64_t *)(arg2 + 8) == *(int64_t *)(arg1 + 0x78)) && (*(int64_t *)arg2 == *(int64_t *)(arg1 + 0x70))) {
            bVar7 = false;
        } else {
            bVar7 = true;
            piVar1 = (int32_t *)(arg1 + 0xb0);
            iVar8 = *(int32_t *)(arg1 + 0xb4);
            if (*piVar1 == iVar8) {
                iVar9 = *piVar1 + 1;
                if (iVar8 == 0) {
                    iVar8 = 8;
                } else {
                    iVar8 = iVar8 / 2 + iVar8;
                }
                if (iVar9 < iVar8) {
                    iVar9 = iVar8;
                }
                func_0x00018011faa0(piVar1, iVar9);
            }
            uVar3 = *(undefined4 *)arg2;
            uVar4 = *(undefined4 *)(arg2 + 4);
            uVar5 = *(undefined4 *)(arg2 + 8);
            uVar6 = *(undefined4 *)(arg2 + 0xc);
            puVar2 = (undefined4 *)(*(int64_t *)(arg1 + 0xb8) + (int64_t)*piVar1 * 0x10);
            *puVar2 = uVar3;
            puVar2[1] = uVar4;
            puVar2[2] = uVar5;
            puVar2[3] = uVar6;
            *piVar1 = *piVar1 + 1;
            *(undefined4 *)(arg1 + 0x70) = uVar3;
            *(undefined4 *)(arg1 + 0x74) = uVar4;
            *(undefined4 *)(arg1 + 0x78) = uVar5;
            *(undefined4 *)(arg1 + 0x7c) = uVar6;
            func_0x000180124360(arg1);
        }
        func_0x000180124680(arg1, 6, 4);
        func_0x000180124790(arg1, arg3, arg4, arg_28h, arg_30h, (undefined4)arg_38h);
        if (bVar7) {
            func_0x000180124620(arg1);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180126929
// Address: 0x180126929
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801268f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    bool bVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    if ((arg_38h & 0xff000000U) != 0) {
        if ((*(int64_t *)(arg2 + 8) == *(int64_t *)(arg1 + 0x78)) && (*(int64_t *)arg2 == *(int64_t *)(arg1 + 0x70))) {
            bVar7 = false;
        } else {
            bVar7 = true;
            piVar1 = (int32_t *)(arg1 + 0xb0);
            iVar8 = *(int32_t *)(arg1 + 0xb4);
            if (*piVar1 == iVar8) {
                iVar9 = *piVar1 + 1;
                if (iVar8 == 0) {
                    iVar8 = 8;
                } else {
                    iVar8 = iVar8 / 2 + iVar8;
                }
                if (iVar9 < iVar8) {
                    iVar9 = iVar8;
                }
                func_0x00018011faa0(piVar1, iVar9);
            }
            uVar3 = *(undefined4 *)arg2;
            uVar4 = *(undefined4 *)(arg2 + 4);
            uVar5 = *(undefined4 *)(arg2 + 8);
            uVar6 = *(undefined4 *)(arg2 + 0xc);
            puVar2 = (undefined4 *)(*(int64_t *)(arg1 + 0xb8) + (int64_t)*piVar1 * 0x10);
            *puVar2 = uVar3;
            puVar2[1] = uVar4;
            puVar2[2] = uVar5;
            puVar2[3] = uVar6;
            *piVar1 = *piVar1 + 1;
            *(undefined4 *)(arg1 + 0x70) = uVar3;
            *(undefined4 *)(arg1 + 0x74) = uVar4;
            *(undefined4 *)(arg1 + 0x78) = uVar5;
            *(undefined4 *)(arg1 + 0x7c) = uVar6;
            func_0x000180124360(arg1);
        }
        func_0x000180124680(arg1, 6, 4);
        func_0x000180124790(arg1, arg3, arg4, arg_28h, arg_30h, (undefined4)arg_38h);
        if (bVar7) {
            func_0x000180124620(arg1);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180126942
// Address: 0x180126942
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801268f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    bool bVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    if ((arg_38h & 0xff000000U) != 0) {
        if ((*(int64_t *)(arg2 + 8) == *(int64_t *)(arg1 + 0x78)) && (*(int64_t *)arg2 == *(int64_t *)(arg1 + 0x70))) {
            bVar7 = false;
        } else {
            bVar7 = true;
            piVar1 = (int32_t *)(arg1 + 0xb0);
            iVar8 = *(int32_t *)(arg1 + 0xb4);
            if (*piVar1 == iVar8) {
                iVar9 = *piVar1 + 1;
                if (iVar8 == 0) {
                    iVar8 = 8;
                } else {
                    iVar8 = iVar8 / 2 + iVar8;
                }
                if (iVar9 < iVar8) {
                    iVar9 = iVar8;
                }
                func_0x00018011faa0(piVar1, iVar9);
            }
            uVar3 = *(undefined4 *)arg2;
            uVar4 = *(undefined4 *)(arg2 + 4);
            uVar5 = *(undefined4 *)(arg2 + 8);
            uVar6 = *(undefined4 *)(arg2 + 0xc);
            puVar2 = (undefined4 *)(*(int64_t *)(arg1 + 0xb8) + (int64_t)*piVar1 * 0x10);
            *puVar2 = uVar3;
            puVar2[1] = uVar4;
            puVar2[2] = uVar5;
            puVar2[3] = uVar6;
            *piVar1 = *piVar1 + 1;
            *(undefined4 *)(arg1 + 0x70) = uVar3;
            *(undefined4 *)(arg1 + 0x74) = uVar4;
            *(undefined4 *)(arg1 + 0x78) = uVar5;
            *(undefined4 *)(arg1 + 0x7c) = uVar6;
            func_0x000180124360(arg1);
        }
        func_0x000180124680(arg1, 6, 4);
        func_0x000180124790(arg1, arg3, arg4, arg_28h, arg_30h, (undefined4)arg_38h);
        if (bVar7) {
            func_0x000180124620(arg1);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801269a9
// Address: 0x1801269a9
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801268f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    bool bVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    if ((arg_38h & 0xff000000U) != 0) {
        if ((*(int64_t *)(arg2 + 8) == *(int64_t *)(arg1 + 0x78)) && (*(int64_t *)arg2 == *(int64_t *)(arg1 + 0x70))) {
            bVar7 = false;
        } else {
            bVar7 = true;
            piVar1 = (int32_t *)(arg1 + 0xb0);
            iVar8 = *(int32_t *)(arg1 + 0xb4);
            if (*piVar1 == iVar8) {
                iVar9 = *piVar1 + 1;
                if (iVar8 == 0) {
                    iVar8 = 8;
                } else {
                    iVar8 = iVar8 / 2 + iVar8;
                }
                if (iVar9 < iVar8) {
                    iVar9 = iVar8;
                }
                func_0x00018011faa0(piVar1, iVar9);
            }
            uVar3 = *(undefined4 *)arg2;
            uVar4 = *(undefined4 *)(arg2 + 4);
            uVar5 = *(undefined4 *)(arg2 + 8);
            uVar6 = *(undefined4 *)(arg2 + 0xc);
            puVar2 = (undefined4 *)(*(int64_t *)(arg1 + 0xb8) + (int64_t)*piVar1 * 0x10);
            *puVar2 = uVar3;
            puVar2[1] = uVar4;
            puVar2[2] = uVar5;
            puVar2[3] = uVar6;
            *piVar1 = *piVar1 + 1;
            *(undefined4 *)(arg1 + 0x70) = uVar3;
            *(undefined4 *)(arg1 + 0x74) = uVar4;
            *(undefined4 *)(arg1 + 0x78) = uVar5;
            *(undefined4 *)(arg1 + 0x7c) = uVar6;
            func_0x000180124360(arg1);
        }
        func_0x000180124680(arg1, 6, 4);
        func_0x000180124790(arg1, arg3, arg4, arg_28h, arg_30h, (undefined4)arg_38h);
        if (bVar7) {
            func_0x000180124620(arg1);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801269e8
// Address: 0x1801269e8
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801268f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    bool bVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    if ((arg_38h & 0xff000000U) != 0) {
        if ((*(int64_t *)(arg2 + 8) == *(int64_t *)(arg1 + 0x78)) && (*(int64_t *)arg2 == *(int64_t *)(arg1 + 0x70))) {
            bVar7 = false;
        } else {
            bVar7 = true;
            piVar1 = (int32_t *)(arg1 + 0xb0);
            iVar8 = *(int32_t *)(arg1 + 0xb4);
            if (*piVar1 == iVar8) {
                iVar9 = *piVar1 + 1;
                if (iVar8 == 0) {
                    iVar8 = 8;
                } else {
                    iVar8 = iVar8 / 2 + iVar8;
                }
                if (iVar9 < iVar8) {
                    iVar9 = iVar8;
                }
                func_0x00018011faa0(piVar1, iVar9);
            }
            uVar3 = *(undefined4 *)arg2;
            uVar4 = *(undefined4 *)(arg2 + 4);
            uVar5 = *(undefined4 *)(arg2 + 8);
            uVar6 = *(undefined4 *)(arg2 + 0xc);
            puVar2 = (undefined4 *)(*(int64_t *)(arg1 + 0xb8) + (int64_t)*piVar1 * 0x10);
            *puVar2 = uVar3;
            puVar2[1] = uVar4;
            puVar2[2] = uVar5;
            puVar2[3] = uVar6;
            *piVar1 = *piVar1 + 1;
            *(undefined4 *)(arg1 + 0x70) = uVar3;
            *(undefined4 *)(arg1 + 0x74) = uVar4;
            *(undefined4 *)(arg1 + 0x78) = uVar5;
            *(undefined4 *)(arg1 + 0x7c) = uVar6;
            func_0x000180124360(arg1);
        }
        func_0x000180124680(arg1, 6, 4);
        func_0x000180124790(arg1, arg3, arg4, arg_28h, arg_30h, (undefined4)arg_38h);
        if (bVar7) {
            func_0x000180124620(arg1);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180126a10
// Address: 0x180126a10
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180126a10(int64_t arg1, int64_t arg_40h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar2 = 0;
    if (0 < *(int32_t *)(arg1 + 8)) {
        do {
            iVar3 = (int64_t)iVar2 * 0x20;
            if (iVar2 == *(int32_t *)arg1) {
                iVar1 = *(int64_t *)(arg1 + 0x10);
                *(undefined (*) [16])(iVar3 + iVar1) = ZEXT816(0);
                *(undefined (*) [16])(iVar3 + 0x10 + iVar1) = ZEXT816(0);
            }
            iVar1 = *(int64_t *)(arg1 + 0x10);
            if (*(int64_t *)(iVar1 + 8 + iVar3) != 0) {
                *(undefined8 *)(iVar1 + iVar3) = 0;
                func_0x000180460d90();
                *(undefined8 *)(iVar1 + 8 + iVar3) = 0;
            }
            iVar3 = iVar3 + *(int64_t *)(arg1 + 0x10);
            if (*(int64_t *)(iVar3 + 0x18) != 0) {
                *(undefined8 *)(iVar3 + 0x10) = 0;
                func_0x000180460d90();
                *(undefined8 *)(iVar3 + 0x18) = 0;
            }
            iVar2 = iVar2 + 1;
        } while (iVar2 < *(int32_t *)(arg1 + 8));
    }
    *(undefined4 *)arg1 = 0;
    *(undefined4 *)(arg1 + 4) = 1;
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        *(undefined8 *)(arg1 + 8) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180126a1c
// Address: 0x180126a1c
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180126a10(int64_t arg1, int64_t arg_40h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar2 = 0;
    if (0 < *(int32_t *)(arg1 + 8)) {
        do {
            iVar3 = (int64_t)iVar2 * 0x20;
            if (iVar2 == *(int32_t *)arg1) {
                iVar1 = *(int64_t *)(arg1 + 0x10);
                *(undefined (*) [16])(iVar3 + iVar1) = ZEXT816(0);
                *(undefined (*) [16])(iVar3 + 0x10 + iVar1) = ZEXT816(0);
            }
            iVar1 = *(int64_t *)(arg1 + 0x10);
            if (*(int64_t *)(iVar1 + 8 + iVar3) != 0) {
                *(undefined8 *)(iVar1 + iVar3) = 0;
                func_0x000180460d90();
                *(undefined8 *)(iVar1 + 8 + iVar3) = 0;
            }
            iVar3 = iVar3 + *(int64_t *)(arg1 + 0x10);
            if (*(int64_t *)(iVar3 + 0x18) != 0) {
                *(undefined8 *)(iVar3 + 0x10) = 0;
                func_0x000180460d90();
                *(undefined8 *)(iVar3 + 0x18) = 0;
            }
            iVar2 = iVar2 + 1;
        } while (iVar2 < *(int32_t *)(arg1 + 8));
    }
    *(undefined4 *)arg1 = 0;
    *(undefined4 *)(arg1 + 4) = 1;
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        *(undefined8 *)(arg1 + 8) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180126a2b
// Address: 0x180126a2b
// Size: 108 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180126a10(int64_t arg1, int64_t arg_40h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar2 = 0;
    if (0 < *(int32_t *)(arg1 + 8)) {
        do {
            iVar3 = (int64_t)iVar2 * 0x20;
            if (iVar2 == *(int32_t *)arg1) {
                iVar1 = *(int64_t *)(arg1 + 0x10);
                *(undefined (*) [16])(iVar3 + iVar1) = ZEXT816(0);
                *(undefined (*) [16])(iVar3 + 0x10 + iVar1) = ZEXT816(0);
            }
            iVar1 = *(int64_t *)(arg1 + 0x10);
            if (*(int64_t *)(iVar1 + 8 + iVar3) != 0) {
                *(undefined8 *)(iVar1 + iVar3) = 0;
                func_0x000180460d90();
                *(undefined8 *)(iVar1 + 8 + iVar3) = 0;
            }
            iVar3 = iVar3 + *(int64_t *)(arg1 + 0x10);
            if (*(int64_t *)(iVar3 + 0x18) != 0) {
                *(undefined8 *)(iVar3 + 0x10) = 0;
                func_0x000180460d90();
                *(undefined8 *)(iVar3 + 0x18) = 0;
            }
            iVar2 = iVar2 + 1;
        } while (iVar2 < *(int32_t *)(arg1 + 8));
    }
    *(undefined4 *)arg1 = 0;
    *(undefined4 *)(arg1 + 4) = 1;
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        *(undefined8 *)(arg1 + 8) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180126a97
// Address: 0x180126a97
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180126a10(int64_t arg1, int64_t arg_40h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar2 = 0;
    if (0 < *(int32_t *)(arg1 + 8)) {
        do {
            iVar3 = (int64_t)iVar2 * 0x20;
            if (iVar2 == *(int32_t *)arg1) {
                iVar1 = *(int64_t *)(arg1 + 0x10);
                *(undefined (*) [16])(iVar3 + iVar1) = ZEXT816(0);
                *(undefined (*) [16])(iVar3 + 0x10 + iVar1) = ZEXT816(0);
            }
            iVar1 = *(int64_t *)(arg1 + 0x10);
            if (*(int64_t *)(iVar1 + 8 + iVar3) != 0) {
                *(undefined8 *)(iVar1 + iVar3) = 0;
                func_0x000180460d90();
                *(undefined8 *)(iVar1 + 8 + iVar3) = 0;
            }
            iVar3 = iVar3 + *(int64_t *)(arg1 + 0x10);
            if (*(int64_t *)(iVar3 + 0x18) != 0) {
                *(undefined8 *)(iVar3 + 0x10) = 0;
                func_0x000180460d90();
                *(undefined8 *)(iVar3 + 0x18) = 0;
            }
            iVar2 = iVar2 + 1;
        } while (iVar2 < *(int32_t *)(arg1 + 8));
    }
    *(undefined4 *)arg1 = 0;
    *(undefined4 *)(arg1 + 4) = 1;
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        *(undefined8 *)(arg1 + 8) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180126aae
// Address: 0x180126aae
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180126a10(int64_t arg1, int64_t arg_40h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar2 = 0;
    if (0 < *(int32_t *)(arg1 + 8)) {
        do {
            iVar3 = (int64_t)iVar2 * 0x20;
            if (iVar2 == *(int32_t *)arg1) {
                iVar1 = *(int64_t *)(arg1 + 0x10);
                *(undefined (*) [16])(iVar3 + iVar1) = ZEXT816(0);
                *(undefined (*) [16])(iVar3 + 0x10 + iVar1) = ZEXT816(0);
            }
            iVar1 = *(int64_t *)(arg1 + 0x10);
            if (*(int64_t *)(iVar1 + 8 + iVar3) != 0) {
                *(undefined8 *)(iVar1 + iVar3) = 0;
                func_0x000180460d90();
                *(undefined8 *)(iVar1 + 8 + iVar3) = 0;
            }
            iVar3 = iVar3 + *(int64_t *)(arg1 + 0x10);
            if (*(int64_t *)(iVar3 + 0x18) != 0) {
                *(undefined8 *)(iVar3 + 0x10) = 0;
                func_0x000180460d90();
                *(undefined8 *)(iVar3 + 0x18) = 0;
            }
            iVar2 = iVar2 + 1;
        } while (iVar2 < *(int32_t *)(arg1 + 8));
    }
    *(undefined4 *)arg1 = 0;
    *(undefined4 *)(arg1 + 4) = 1;
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        *(undefined8 *)(arg1 + 8) = 0;
        func_0x000180460d90();
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180126ad0
// Address: 0x180126ad0
// Size: 122 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180126ad0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg_58h)
{
    int32_t iVar1;
    undefined (*pauVar2) [16];
    int64_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    undefined8 *puVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_20h;
    
    iVar1 = *(int32_t *)(arg1 + 8);
    iVar10 = (int32_t)arg3;
    uVar9 = arg3 & 0xffffffff;
    if (iVar1 < iVar10) {
        func_0x000180131330(arg1 + 8, arg3 & 0xffffffff);
        iVar5 = *(int32_t *)(arg1 + 0xc);
        if (iVar5 < iVar10) {
            if (iVar5 == 0) {
                uVar4 = 8;
            } else {
                uVar4 = iVar5 / 2 + iVar5;
            }
            if (iVar10 < (int32_t)uVar4) {
                uVar9 = (uint64_t)uVar4;
            }
            func_0x000180131330(arg1 + 8, uVar9);
        }
        *(int32_t *)(arg1 + 8) = iVar10;
    }
    *(int32_t *)(arg1 + 4) = iVar10;
    pauVar2 = *(undefined (**) [16])(arg1 + 0x10);
    uVar9 = 1;
    *pauVar2 = ZEXT816(0);
    pauVar2[1] = ZEXT816(0);
    if (1 < iVar10) {
        do {
            iVar8 = uVar9 * 0x20;
            puVar7 = (undefined8 *)(*(int64_t *)(arg1 + 0x10) + iVar8);
            if ((int32_t)uVar9 < iVar1) {
                iVar5 = *(int32_t *)((int64_t)puVar7 + 4);
                if (iVar5 < 0) {
                    iVar5 = iVar5 + (iVar5 + 1 >> 1);
                    iVar6 = 0;
                    if (0 < iVar5) {
                        iVar6 = iVar5;
                    }
                    func_0x00018011fc10(puVar7, iVar6);
                }
                *(undefined4 *)puVar7 = 0;
                iVar3 = *(int64_t *)(arg1 + 0x10);
                iVar5 = *(int32_t *)(iVar3 + 0x14 + iVar8);
                if (iVar5 < 0) {
                    iVar5 = (iVar5 + 1 >> 1) + iVar5;
                    iVar6 = 0;
                    if (0 < iVar5) {
                        iVar6 = iVar5;
                    }
                    func_0x00018011f8d0(iVar3 + 0x10 + iVar8, iVar6);
                }
                *(undefined4 *)(iVar3 + 0x10 + iVar8) = 0;
            } else if (puVar7 != (undefined8 *)0x0) {
                *puVar7 = 0;
                puVar7[1] = 0;
                puVar7[2] = 0;
                puVar7[3] = 0;
            }
            uVar4 = (int32_t)uVar9 + 1;
            uVar9 = (uint64_t)uVar4;
        } while ((int32_t)uVar4 < iVar10);
    }
    return;
}

// ============================================================
// Function: FUN_180126b4a
// Address: 0x180126b4a
// Size: 159 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180126ad0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg_58h)
{
    int32_t iVar1;
    undefined (*pauVar2) [16];
    int64_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    undefined8 *puVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_20h;
    
    iVar1 = *(int32_t *)(arg1 + 8);
    iVar10 = (int32_t)arg3;
    uVar9 = arg3 & 0xffffffff;
    if (iVar1 < iVar10) {
        func_0x000180131330(arg1 + 8, arg3 & 0xffffffff);
        iVar5 = *(int32_t *)(arg1 + 0xc);
        if (iVar5 < iVar10) {
            if (iVar5 == 0) {
                uVar4 = 8;
            } else {
                uVar4 = iVar5 / 2 + iVar5;
            }
            if (iVar10 < (int32_t)uVar4) {
                uVar9 = (uint64_t)uVar4;
            }
            func_0x000180131330(arg1 + 8, uVar9);
        }
        *(int32_t *)(arg1 + 8) = iVar10;
    }
    *(int32_t *)(arg1 + 4) = iVar10;
    pauVar2 = *(undefined (**) [16])(arg1 + 0x10);
    uVar9 = 1;
    *pauVar2 = ZEXT816(0);
    pauVar2[1] = ZEXT816(0);
    if (1 < iVar10) {
        do {
            iVar8 = uVar9 * 0x20;
            puVar7 = (undefined8 *)(*(int64_t *)(arg1 + 0x10) + iVar8);
            if ((int32_t)uVar9 < iVar1) {
                iVar5 = *(int32_t *)((int64_t)puVar7 + 4);
                if (iVar5 < 0) {
                    iVar5 = iVar5 + (iVar5 + 1 >> 1);
                    iVar6 = 0;
                    if (0 < iVar5) {
                        iVar6 = iVar5;
                    }
                    func_0x00018011fc10(puVar7, iVar6);
                }
                *(undefined4 *)puVar7 = 0;
                iVar3 = *(int64_t *)(arg1 + 0x10);
                iVar5 = *(int32_t *)(iVar3 + 0x14 + iVar8);
                if (iVar5 < 0) {
                    iVar5 = (iVar5 + 1 >> 1) + iVar5;
                    iVar6 = 0;
                    if (0 < iVar5) {
                        iVar6 = iVar5;
                    }
                    func_0x00018011f8d0(iVar3 + 0x10 + iVar8, iVar6);
                }
                *(undefined4 *)(iVar3 + 0x10 + iVar8) = 0;
            } else if (puVar7 != (undefined8 *)0x0) {
                *puVar7 = 0;
                puVar7[1] = 0;
                puVar7[2] = 0;
                puVar7[3] = 0;
            }
            uVar4 = (int32_t)uVar9 + 1;
            uVar9 = (uint64_t)uVar4;
        } while ((int32_t)uVar4 < iVar10);
    }
    return;
}

// ============================================================
// Function: FUN_180126be9
// Address: 0x180126be9
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180126ad0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg_58h)
{
    int32_t iVar1;
    undefined (*pauVar2) [16];
    int64_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    undefined8 *puVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int32_t iVar10;
    int64_t var_8h;
    int64_t var_20h;
    
    iVar1 = *(int32_t *)(arg1 + 8);
    iVar10 = (int32_t)arg3;
    uVar9 = arg3 & 0xffffffff;
    if (iVar1 < iVar10) {
        func_0x000180131330(arg1 + 8, arg3 & 0xffffffff);
        iVar5 = *(int32_t *)(arg1 + 0xc);
        if (iVar5 < iVar10) {
            if (iVar5 == 0) {
                uVar4 = 8;
            } else {
                uVar4 = iVar5 / 2 + iVar5;
            }
            if (iVar10 < (int32_t)uVar4) {
                uVar9 = (uint64_t)uVar4;
            }
            func_0x000180131330(arg1 + 8, uVar9);
        }
        *(int32_t *)(arg1 + 8) = iVar10;
    }
    *(int32_t *)(arg1 + 4) = iVar10;
    pauVar2 = *(undefined (**) [16])(arg1 + 0x10);
    uVar9 = 1;
    *pauVar2 = ZEXT816(0);
    pauVar2[1] = ZEXT816(0);
    if (1 < iVar10) {
        do {
            iVar8 = uVar9 * 0x20;
            puVar7 = (undefined8 *)(*(int64_t *)(arg1 + 0x10) + iVar8);
            if ((int32_t)uVar9 < iVar1) {
                iVar5 = *(int32_t *)((int64_t)puVar7 + 4);
                if (iVar5 < 0) {
                    iVar5 = iVar5 + (iVar5 + 1 >> 1);
                    iVar6 = 0;
                    if (0 < iVar5) {
                        iVar6 = iVar5;
                    }
                    func_0x00018011fc10(puVar7, iVar6);
                }
                *(undefined4 *)puVar7 = 0;
                iVar3 = *(int64_t *)(arg1 + 0x10);
                iVar5 = *(int32_t *)(iVar3 + 0x14 + iVar8);
                if (iVar5 < 0) {
                    iVar5 = (iVar5 + 1 >> 1) + iVar5;
                    iVar6 = 0;
                    if (0 < iVar5) {
                        iVar6 = iVar5;
                    }
                    func_0x00018011f8d0(iVar3 + 0x10 + iVar8, iVar6);
                }
                *(undefined4 *)(iVar3 + 0x10 + iVar8) = 0;
            } else if (puVar7 != (undefined8 *)0x0) {
                *puVar7 = 0;
                puVar7[1] = 0;
                puVar7[2] = 0;
                puVar7[3] = 0;
            }
            uVar4 = (int32_t)uVar9 + 1;
            uVar9 = (uint64_t)uVar4;
        } while ((int32_t)uVar4 < iVar10);
    }
    return;
}

// ============================================================
// Function: FUN_180126c00
// Address: 0x180126c00
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.180126c00(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined4 *puVar2;
    int64_t *piVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    uint32_t uVar12;
    int32_t iVar13;
    int32_t *piVar14;
    int64_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_81h;
    int64_t var_78h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(int32_t *)(arg1 + 4) < 2) {
        return;
    }
    func_0x000180127010(arg1, arg2, 0);
    uVar12 = *(uint32_t *)arg2;
    piVar3 = (int64_t *)(arg2 + 8);
    while (((0 < (int32_t)uVar12 && (*(int32_t *)(*piVar3 + -0x20 + (uint64_t)uVar12 * 0x48) == 0)) &&
           (*(int64_t *)(*piVar3 + (uint64_t)uVar12 * 0x48 + -0x18) == 0))) {
        uVar12 = uVar12 - 1;
        *(uint32_t *)arg2 = uVar12;
    }
    var_18h._0_4_ = 0;
    var_20h._0_4_ = 0;
    if ((*(int32_t *)(arg1 + 4) < 1) || ((int32_t)uVar12 < 1)) {
        iVar15 = 0;
    } else {
        iVar15 = *piVar3 + ((int64_t)(int32_t)uVar12 * 9 + -9) * 8;
        if (iVar15 != 0) {
            iVar10 = *(int32_t *)(iVar15 + 0x28) + *(int32_t *)(iVar15 + 0x24);
            goto code_r0x000180126cdd;
        }
    }
    iVar10 = 0;
code_r0x000180126cdd:
    if (1 < *(int32_t *)(arg1 + 4)) {
        iVar13 = 1;
        do {
            piVar14 = (int32_t *)((int64_t)iVar13 * 0x20 + *(int64_t *)(arg1 + 0x10));
            iVar11 = *piVar14;
            if (0 < iVar11) {
                iVar8 = iVar11 + -1;
                if (((*(int32_t *)(*(int64_t *)(piVar14 + 2) + 0x28 + (int64_t)iVar8 * 0x48) != 0) ||
                    (*(int64_t *)(*(int64_t *)(piVar14 + 2) + 0x30 + (int64_t)iVar8 * 0x48) != 0)) ||
                   (*piVar14 = iVar8, iVar11 = iVar8, 0 < iVar8)) {
                    piVar1 = (int64_t *)(piVar14 + 2);
                    if (iVar15 != 0) {
                        iVar7 = *piVar1;
                        iVar8 = func_0x000180497f30(iVar15, iVar7, 0x24);
                        if (((iVar8 == 0) && (*(int64_t *)(iVar15 + 0x30) == 0)) && (*(int64_t *)(iVar7 + 0x30) == 0)) {
                            *(int32_t *)(iVar15 + 0x28) = *(int32_t *)(iVar15 + 0x28) + *(int32_t *)(iVar7 + 0x28);
                            iVar10 = iVar10 + *(int32_t *)(iVar7 + 0x28);
                            func_0x000180498030(*piVar1, *piVar1 + 0x48, (int64_t)*piVar14 * 0x48 + -0x48);
                            *piVar14 = *piVar14 + -1;
                            iVar11 = *piVar14;
                            if (iVar11 < 1) goto code_r0x000180126dcd;
                        }
                    }
                    iVar15 = *piVar1 + (int64_t)(iVar11 + -1) * 0x48;
                }
            }
code_r0x000180126dcd:
            var_20h._0_4_ = (int32_t)var_20h + piVar14[4];
            var_18h._0_4_ = (int32_t)var_18h + iVar11;
            iVar8 = 0;
            if (0 < iVar11) {
                do {
                    iVar7 = (int64_t)iVar8;
                    iVar8 = iVar8 + 1;
                    *(int32_t *)(*(int64_t *)(piVar14 + 2) + 0x24 + iVar7 * 0x48) = iVar10;
                    iVar10 = iVar10 + *(int32_t *)(*(int64_t *)(piVar14 + 2) + 0x28 + iVar7 * 0x48);
                } while (iVar8 < *piVar14);
            }
            iVar13 = iVar13 + 1;
        } while (iVar13 < *(int32_t *)(arg1 + 4));
    }
    iVar10 = 8;
    iVar13 = *(int32_t *)(arg2 + 4);
    iVar11 = *(int32_t *)arg2 + (int32_t)var_18h;
    if (iVar13 < iVar11) {
        if (iVar13 == 0) {
            iVar13 = 8;
        } else {
            iVar13 = iVar13 / 2 + iVar13;
        }
        iVar8 = iVar11;
        if (iVar11 < iVar13) {
            iVar8 = iVar13;
        }
        func_0x00018011fc10(arg2, iVar8);
    }
    *(int32_t *)arg2 = iVar11;
    iVar13 = *(int32_t *)(arg2 + 0x14);
    iVar11 = *(int32_t *)(arg2 + 0x10) + (int32_t)var_20h;
    if (iVar13 < iVar11) {
        if (iVar13 != 0) {
            iVar10 = iVar13 + iVar13 / 2;
        }
        iVar13 = iVar11;
        if (iVar11 < iVar10) {
            iVar13 = iVar10;
        }
        func_0x00018011f8d0(arg2 + 0x10, iVar13);
    }
    iVar10 = 1;
    *(int32_t *)(arg2 + 0x10) = iVar11;
    iVar9 = *piVar3;
    iVar15 = iVar9 + ((int64_t)*(int32_t *)arg2 - (int64_t)(int32_t)var_18h) * 0x48;
    iVar7 = *(int64_t *)(arg2 + 0x18) + ((int64_t)iVar11 - (int64_t)(int32_t)var_20h) * 2;
    if (1 < *(int32_t *)(arg1 + 4)) {
        do {
            piVar14 = (int32_t *)((int64_t)iVar10 * 0x20 + *(int64_t *)(arg1 + 0x10));
            if (*piVar14 != 0) {
                iVar9 = (int64_t)*piVar14 * 0x48;
                func_0x000180498030(iVar15, *(undefined8 *)(piVar14 + 2), iVar9);
                iVar15 = iVar15 + iVar9;
            }
            if (piVar14[4] != 0) {
                iVar9 = (int64_t)piVar14[4] * 2;
                func_0x000180498030(iVar7, *(undefined8 *)(piVar14 + 6), iVar9);
                iVar7 = iVar7 + iVar9;
            }
            iVar10 = iVar10 + 1;
        } while (iVar10 < *(int32_t *)(arg1 + 4));
        iVar9 = *piVar3;
    }
    *(int64_t *)(arg2 + 0x48) = iVar7;
    if ((*(int32_t *)arg2 == 0) || (*(int64_t *)(iVar9 + -0x18 + (int64_t)*(int32_t *)arg2 * 0x48) != 0)) {
        func_0x000180124200(arg2);
    }
    iVar15 = (int64_t)*(int32_t *)arg2 * 9 + -9;
    puVar2 = (undefined4 *)(*piVar3 + iVar15 * 8);
    if (*(int32_t *)(*piVar3 + 0x28 + iVar15 * 8) != 0) {
        iVar10 = func_0x000180497f30(puVar2, (undefined4 *)(arg2 + 0x60), 0x24);
        if (iVar10 != 0) {
            func_0x000180124200(arg2);
        }
        *(undefined4 *)(arg1 + 4) = 1;
        return;
    }
    uVar4 = *(undefined4 *)(arg2 + 100);
    uVar5 = *(undefined4 *)(arg2 + 0x68);
    uVar6 = *(undefined4 *)(arg2 + 0x6c);
    *puVar2 = *(undefined4 *)(arg2 + 0x60);
    puVar2[1] = uVar4;
    puVar2[2] = uVar5;
    puVar2[3] = uVar6;
    uVar4 = *(undefined4 *)(arg2 + 0x74);
    uVar5 = *(undefined4 *)(arg2 + 0x78);
    uVar6 = *(undefined4 *)(arg2 + 0x7c);
    puVar2[4] = *(undefined4 *)(arg2 + 0x70);
    puVar2[5] = uVar4;
    puVar2[6] = uVar5;
    puVar2[7] = uVar6;
    puVar2[8] = *(undefined4 *)(arg2 + 0x80);
    *(undefined4 *)(arg1 + 4) = 1;
    return;
}

// ============================================================
// Function: FUN_180126c23
// Address: 0x180126c23
// Size: 859 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.180126c00(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined4 *puVar2;
    int64_t *piVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    uint32_t uVar12;
    int32_t iVar13;
    int32_t *piVar14;
    int64_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_81h;
    int64_t var_78h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(int32_t *)(arg1 + 4) < 2) {
        return;
    }
    func_0x000180127010(arg1, arg2, 0);
    uVar12 = *(uint32_t *)arg2;
    piVar3 = (int64_t *)(arg2 + 8);
    while (((0 < (int32_t)uVar12 && (*(int32_t *)(*piVar3 + -0x20 + (uint64_t)uVar12 * 0x48) == 0)) &&
           (*(int64_t *)(*piVar3 + (uint64_t)uVar12 * 0x48 + -0x18) == 0))) {
        uVar12 = uVar12 - 1;
        *(uint32_t *)arg2 = uVar12;
    }
    var_18h._0_4_ = 0;
    var_20h._0_4_ = 0;
    if ((*(int32_t *)(arg1 + 4) < 1) || ((int32_t)uVar12 < 1)) {
        iVar15 = 0;
    } else {
        iVar15 = *piVar3 + ((int64_t)(int32_t)uVar12 * 9 + -9) * 8;
        if (iVar15 != 0) {
            iVar10 = *(int32_t *)(iVar15 + 0x28) + *(int32_t *)(iVar15 + 0x24);
            goto code_r0x000180126cdd;
        }
    }
    iVar10 = 0;
code_r0x000180126cdd:
    if (1 < *(int32_t *)(arg1 + 4)) {
        iVar13 = 1;
        do {
            piVar14 = (int32_t *)((int64_t)iVar13 * 0x20 + *(int64_t *)(arg1 + 0x10));
            iVar11 = *piVar14;
            if (0 < iVar11) {
                iVar8 = iVar11 + -1;
                if (((*(int32_t *)(*(int64_t *)(piVar14 + 2) + 0x28 + (int64_t)iVar8 * 0x48) != 0) ||
                    (*(int64_t *)(*(int64_t *)(piVar14 + 2) + 0x30 + (int64_t)iVar8 * 0x48) != 0)) ||
                   (*piVar14 = iVar8, iVar11 = iVar8, 0 < iVar8)) {
                    piVar1 = (int64_t *)(piVar14 + 2);
                    if (iVar15 != 0) {
                        iVar7 = *piVar1;
                        iVar8 = func_0x000180497f30(iVar15, iVar7, 0x24);
                        if (((iVar8 == 0) && (*(int64_t *)(iVar15 + 0x30) == 0)) && (*(int64_t *)(iVar7 + 0x30) == 0)) {
                            *(int32_t *)(iVar15 + 0x28) = *(int32_t *)(iVar15 + 0x28) + *(int32_t *)(iVar7 + 0x28);
                            iVar10 = iVar10 + *(int32_t *)(iVar7 + 0x28);
                            func_0x000180498030(*piVar1, *piVar1 + 0x48, (int64_t)*piVar14 * 0x48 + -0x48);
                            *piVar14 = *piVar14 + -1;
                            iVar11 = *piVar14;
                            if (iVar11 < 1) goto code_r0x000180126dcd;
                        }
                    }
                    iVar15 = *piVar1 + (int64_t)(iVar11 + -1) * 0x48;
                }
            }
code_r0x000180126dcd:
            var_20h._0_4_ = (int32_t)var_20h + piVar14[4];
            var_18h._0_4_ = (int32_t)var_18h + iVar11;
            iVar8 = 0;
            if (0 < iVar11) {
                do {
                    iVar7 = (int64_t)iVar8;
                    iVar8 = iVar8 + 1;
                    *(int32_t *)(*(int64_t *)(piVar14 + 2) + 0x24 + iVar7 * 0x48) = iVar10;
                    iVar10 = iVar10 + *(int32_t *)(*(int64_t *)(piVar14 + 2) + 0x28 + iVar7 * 0x48);
                } while (iVar8 < *piVar14);
            }
            iVar13 = iVar13 + 1;
        } while (iVar13 < *(int32_t *)(arg1 + 4));
    }
    iVar10 = 8;
    iVar13 = *(int32_t *)(arg2 + 4);
    iVar11 = *(int32_t *)arg2 + (int32_t)var_18h;
    if (iVar13 < iVar11) {
        if (iVar13 == 0) {
            iVar13 = 8;
        } else {
            iVar13 = iVar13 / 2 + iVar13;
        }
        iVar8 = iVar11;
        if (iVar11 < iVar13) {
            iVar8 = iVar13;
        }
        func_0x00018011fc10(arg2, iVar8);
    }
    *(int32_t *)arg2 = iVar11;
    iVar13 = *(int32_t *)(arg2 + 0x14);
    iVar11 = *(int32_t *)(arg2 + 0x10) + (int32_t)var_20h;
    if (iVar13 < iVar11) {
        if (iVar13 != 0) {
            iVar10 = iVar13 + iVar13 / 2;
        }
        iVar13 = iVar11;
        if (iVar11 < iVar10) {
            iVar13 = iVar10;
        }
        func_0x00018011f8d0(arg2 + 0x10, iVar13);
    }
    iVar10 = 1;
    *(int32_t *)(arg2 + 0x10) = iVar11;
    iVar9 = *piVar3;
    iVar15 = iVar9 + ((int64_t)*(int32_t *)arg2 - (int64_t)(int32_t)var_18h) * 0x48;
    iVar7 = *(int64_t *)(arg2 + 0x18) + ((int64_t)iVar11 - (int64_t)(int32_t)var_20h) * 2;
    if (1 < *(int32_t *)(arg1 + 4)) {
        do {
            piVar14 = (int32_t *)((int64_t)iVar10 * 0x20 + *(int64_t *)(arg1 + 0x10));
            if (*piVar14 != 0) {
                iVar9 = (int64_t)*piVar14 * 0x48;
                func_0x000180498030(iVar15, *(undefined8 *)(piVar14 + 2), iVar9);
                iVar15 = iVar15 + iVar9;
            }
            if (piVar14[4] != 0) {
                iVar9 = (int64_t)piVar14[4] * 2;
                func_0x000180498030(iVar7, *(undefined8 *)(piVar14 + 6), iVar9);
                iVar7 = iVar7 + iVar9;
            }
            iVar10 = iVar10 + 1;
        } while (iVar10 < *(int32_t *)(arg1 + 4));
        iVar9 = *piVar3;
    }
    *(int64_t *)(arg2 + 0x48) = iVar7;
    if ((*(int32_t *)arg2 == 0) || (*(int64_t *)(iVar9 + -0x18 + (int64_t)*(int32_t *)arg2 * 0x48) != 0)) {
        func_0x000180124200(arg2);
    }
    iVar15 = (int64_t)*(int32_t *)arg2 * 9 + -9;
    puVar2 = (undefined4 *)(*piVar3 + iVar15 * 8);
    if (*(int32_t *)(*piVar3 + 0x28 + iVar15 * 8) != 0) {
        iVar10 = func_0x000180497f30(puVar2, (undefined4 *)(arg2 + 0x60), 0x24);
        if (iVar10 != 0) {
            func_0x000180124200(arg2);
        }
        *(undefined4 *)(arg1 + 4) = 1;
        return;
    }
    uVar4 = *(undefined4 *)(arg2 + 100);
    uVar5 = *(undefined4 *)(arg2 + 0x68);
    uVar6 = *(undefined4 *)(arg2 + 0x6c);
    *puVar2 = *(undefined4 *)(arg2 + 0x60);
    puVar2[1] = uVar4;
    puVar2[2] = uVar5;
    puVar2[3] = uVar6;
    uVar4 = *(undefined4 *)(arg2 + 0x74);
    uVar5 = *(undefined4 *)(arg2 + 0x78);
    uVar6 = *(undefined4 *)(arg2 + 0x7c);
    puVar2[4] = *(undefined4 *)(arg2 + 0x70);
    puVar2[5] = uVar4;
    puVar2[6] = uVar5;
    puVar2[7] = uVar6;
    puVar2[8] = *(undefined4 *)(arg2 + 0x80);
    *(undefined4 *)(arg1 + 4) = 1;
    return;
}

// ============================================================
// Function: FUN_180126f7e
// Address: 0x180126f7e
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.180126c00(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined4 *puVar2;
    int64_t *piVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    uint32_t uVar12;
    int32_t iVar13;
    int32_t *piVar14;
    int64_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_81h;
    int64_t var_78h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(int32_t *)(arg1 + 4) < 2) {
        return;
    }
    func_0x000180127010(arg1, arg2, 0);
    uVar12 = *(uint32_t *)arg2;
    piVar3 = (int64_t *)(arg2 + 8);
    while (((0 < (int32_t)uVar12 && (*(int32_t *)(*piVar3 + -0x20 + (uint64_t)uVar12 * 0x48) == 0)) &&
           (*(int64_t *)(*piVar3 + (uint64_t)uVar12 * 0x48 + -0x18) == 0))) {
        uVar12 = uVar12 - 1;
        *(uint32_t *)arg2 = uVar12;
    }
    var_18h._0_4_ = 0;
    var_20h._0_4_ = 0;
    if ((*(int32_t *)(arg1 + 4) < 1) || ((int32_t)uVar12 < 1)) {
        iVar15 = 0;
    } else {
        iVar15 = *piVar3 + ((int64_t)(int32_t)uVar12 * 9 + -9) * 8;
        if (iVar15 != 0) {
            iVar10 = *(int32_t *)(iVar15 + 0x28) + *(int32_t *)(iVar15 + 0x24);
            goto code_r0x000180126cdd;
        }
    }
    iVar10 = 0;
code_r0x000180126cdd:
    if (1 < *(int32_t *)(arg1 + 4)) {
        iVar13 = 1;
        do {
            piVar14 = (int32_t *)((int64_t)iVar13 * 0x20 + *(int64_t *)(arg1 + 0x10));
            iVar11 = *piVar14;
            if (0 < iVar11) {
                iVar8 = iVar11 + -1;
                if (((*(int32_t *)(*(int64_t *)(piVar14 + 2) + 0x28 + (int64_t)iVar8 * 0x48) != 0) ||
                    (*(int64_t *)(*(int64_t *)(piVar14 + 2) + 0x30 + (int64_t)iVar8 * 0x48) != 0)) ||
                   (*piVar14 = iVar8, iVar11 = iVar8, 0 < iVar8)) {
                    piVar1 = (int64_t *)(piVar14 + 2);
                    if (iVar15 != 0) {
                        iVar7 = *piVar1;
                        iVar8 = func_0x000180497f30(iVar15, iVar7, 0x24);
                        if (((iVar8 == 0) && (*(int64_t *)(iVar15 + 0x30) == 0)) && (*(int64_t *)(iVar7 + 0x30) == 0)) {
                            *(int32_t *)(iVar15 + 0x28) = *(int32_t *)(iVar15 + 0x28) + *(int32_t *)(iVar7 + 0x28);
                            iVar10 = iVar10 + *(int32_t *)(iVar7 + 0x28);
                            func_0x000180498030(*piVar1, *piVar1 + 0x48, (int64_t)*piVar14 * 0x48 + -0x48);
                            *piVar14 = *piVar14 + -1;
                            iVar11 = *piVar14;
                            if (iVar11 < 1) goto code_r0x000180126dcd;
                        }
                    }
                    iVar15 = *piVar1 + (int64_t)(iVar11 + -1) * 0x48;
                }
            }
code_r0x000180126dcd:
            var_20h._0_4_ = (int32_t)var_20h + piVar14[4];
            var_18h._0_4_ = (int32_t)var_18h + iVar11;
            iVar8 = 0;
            if (0 < iVar11) {
                do {
                    iVar7 = (int64_t)iVar8;
                    iVar8 = iVar8 + 1;
                    *(int32_t *)(*(int64_t *)(piVar14 + 2) + 0x24 + iVar7 * 0x48) = iVar10;
                    iVar10 = iVar10 + *(int32_t *)(*(int64_t *)(piVar14 + 2) + 0x28 + iVar7 * 0x48);
                } while (iVar8 < *piVar14);
            }
            iVar13 = iVar13 + 1;
        } while (iVar13 < *(int32_t *)(arg1 + 4));
    }
    iVar10 = 8;
    iVar13 = *(int32_t *)(arg2 + 4);
    iVar11 = *(int32_t *)arg2 + (int32_t)var_18h;
    if (iVar13 < iVar11) {
        if (iVar13 == 0) {
            iVar13 = 8;
        } else {
            iVar13 = iVar13 / 2 + iVar13;
        }
        iVar8 = iVar11;
        if (iVar11 < iVar13) {
            iVar8 = iVar13;
        }
        func_0x00018011fc10(arg2, iVar8);
    }
    *(int32_t *)arg2 = iVar11;
    iVar13 = *(int32_t *)(arg2 + 0x14);
    iVar11 = *(int32_t *)(arg2 + 0x10) + (int32_t)var_20h;
    if (iVar13 < iVar11) {
        if (iVar13 != 0) {
            iVar10 = iVar13 + iVar13 / 2;
        }
        iVar13 = iVar11;
        if (iVar11 < iVar10) {
            iVar13 = iVar10;
        }
        func_0x00018011f8d0(arg2 + 0x10, iVar13);
    }
    iVar10 = 1;
    *(int32_t *)(arg2 + 0x10) = iVar11;
    iVar9 = *piVar3;
    iVar15 = iVar9 + ((int64_t)*(int32_t *)arg2 - (int64_t)(int32_t)var_18h) * 0x48;
    iVar7 = *(int64_t *)(arg2 + 0x18) + ((int64_t)iVar11 - (int64_t)(int32_t)var_20h) * 2;
    if (1 < *(int32_t *)(arg1 + 4)) {
        do {
            piVar14 = (int32_t *)((int64_t)iVar10 * 0x20 + *(int64_t *)(arg1 + 0x10));
            if (*piVar14 != 0) {
                iVar9 = (int64_t)*piVar14 * 0x48;
                func_0x000180498030(iVar15, *(undefined8 *)(piVar14 + 2), iVar9);
                iVar15 = iVar15 + iVar9;
            }
            if (piVar14[4] != 0) {
                iVar9 = (int64_t)piVar14[4] * 2;
                func_0x000180498030(iVar7, *(undefined8 *)(piVar14 + 6), iVar9);
                iVar7 = iVar7 + iVar9;
            }
            iVar10 = iVar10 + 1;
        } while (iVar10 < *(int32_t *)(arg1 + 4));
        iVar9 = *piVar3;
    }
    *(int64_t *)(arg2 + 0x48) = iVar7;
    if ((*(int32_t *)arg2 == 0) || (*(int64_t *)(iVar9 + -0x18 + (int64_t)*(int32_t *)arg2 * 0x48) != 0)) {
        func_0x000180124200(arg2);
    }
    iVar15 = (int64_t)*(int32_t *)arg2 * 9 + -9;
    puVar2 = (undefined4 *)(*piVar3 + iVar15 * 8);
    if (*(int32_t *)(*piVar3 + 0x28 + iVar15 * 8) != 0) {
        iVar10 = func_0x000180497f30(puVar2, (undefined4 *)(arg2 + 0x60), 0x24);
        if (iVar10 != 0) {
            func_0x000180124200(arg2);
        }
        *(undefined4 *)(arg1 + 4) = 1;
        return;
    }
    uVar4 = *(undefined4 *)(arg2 + 100);
    uVar5 = *(undefined4 *)(arg2 + 0x68);
    uVar6 = *(undefined4 *)(arg2 + 0x6c);
    *puVar2 = *(undefined4 *)(arg2 + 0x60);
    puVar2[1] = uVar4;
    puVar2[2] = uVar5;
    puVar2[3] = uVar6;
    uVar4 = *(undefined4 *)(arg2 + 0x74);
    uVar5 = *(undefined4 *)(arg2 + 0x78);
    uVar6 = *(undefined4 *)(arg2 + 0x7c);
    puVar2[4] = *(undefined4 *)(arg2 + 0x70);
    puVar2[5] = uVar4;
    puVar2[6] = uVar5;
    puVar2[7] = uVar6;
    puVar2[8] = *(undefined4 *)(arg2 + 0x80);
    *(undefined4 *)(arg1 + 4) = 1;
    return;
}

// ============================================================
// Function: FUN_180126fb7
// Address: 0x180126fb7
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.180126c00(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined4 *puVar2;
    int64_t *piVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    uint32_t uVar12;
    int32_t iVar13;
    int32_t *piVar14;
    int64_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_81h;
    int64_t var_78h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if (*(int32_t *)(arg1 + 4) < 2) {
        return;
    }
    func_0x000180127010(arg1, arg2, 0);
    uVar12 = *(uint32_t *)arg2;
    piVar3 = (int64_t *)(arg2 + 8);
    while (((0 < (int32_t)uVar12 && (*(int32_t *)(*piVar3 + -0x20 + (uint64_t)uVar12 * 0x48) == 0)) &&
           (*(int64_t *)(*piVar3 + (uint64_t)uVar12 * 0x48 + -0x18) == 0))) {
        uVar12 = uVar12 - 1;
        *(uint32_t *)arg2 = uVar12;
    }
    var_18h._0_4_ = 0;
    var_20h._0_4_ = 0;
    if ((*(int32_t *)(arg1 + 4) < 1) || ((int32_t)uVar12 < 1)) {
        iVar15 = 0;
    } else {
        iVar15 = *piVar3 + ((int64_t)(int32_t)uVar12 * 9 + -9) * 8;
        if (iVar15 != 0) {
            iVar10 = *(int32_t *)(iVar15 + 0x28) + *(int32_t *)(iVar15 + 0x24);
            goto code_r0x000180126cdd;
        }
    }
    iVar10 = 0;
code_r0x000180126cdd:
    if (1 < *(int32_t *)(arg1 + 4)) {
        iVar13 = 1;
        do {
            piVar14 = (int32_t *)((int64_t)iVar13 * 0x20 + *(int64_t *)(arg1 + 0x10));
            iVar11 = *piVar14;
            if (0 < iVar11) {
                iVar8 = iVar11 + -1;
                if (((*(int32_t *)(*(int64_t *)(piVar14 + 2) + 0x28 + (int64_t)iVar8 * 0x48) != 0) ||
                    (*(int64_t *)(*(int64_t *)(piVar14 + 2) + 0x30 + (int64_t)iVar8 * 0x48) != 0)) ||
                   (*piVar14 = iVar8, iVar11 = iVar8, 0 < iVar8)) {
                    piVar1 = (int64_t *)(piVar14 + 2);
                    if (iVar15 != 0) {
                        iVar7 = *piVar1;
                        iVar8 = func_0x000180497f30(iVar15, iVar7, 0x24);
                        if (((iVar8 == 0) && (*(int64_t *)(iVar15 + 0x30) == 0)) && (*(int64_t *)(iVar7 + 0x30) == 0)) {
                            *(int32_t *)(iVar15 + 0x28) = *(int32_t *)(iVar15 + 0x28) + *(int32_t *)(iVar7 + 0x28);
                            iVar10 = iVar10 + *(int32_t *)(iVar7 + 0x28);
                            func_0x000180498030(*piVar1, *piVar1 + 0x48, (int64_t)*piVar14 * 0x48 + -0x48);
                            *piVar14 = *piVar14 + -1;
                            iVar11 = *piVar14;
                            if (iVar11 < 1) goto code_r0x000180126dcd;
                        }
                    }
                    iVar15 = *piVar1 + (int64_t)(iVar11 + -1) * 0x48;
                }
            }
code_r0x000180126dcd:
            var_20h._0_4_ = (int32_t)var_20h + piVar14[4];
            var_18h._0_4_ = (int32_t)var_18h + iVar11;
            iVar8 = 0;
            if (0 < iVar11) {
                do {
                    iVar7 = (int64_t)iVar8;
                    iVar8 = iVar8 + 1;
                    *(int32_t *)(*(int64_t *)(piVar14 + 2) + 0x24 + iVar7 * 0x48) = iVar10;
                    iVar10 = iVar10 + *(int32_t *)(*(int64_t *)(piVar14 + 2) + 0x28 + iVar7 * 0x48);
                } while (iVar8 < *piVar14);
            }
            iVar13 = iVar13 + 1;
        } while (iVar13 < *(int32_t *)(arg1 + 4));
    }
    iVar10 = 8;
    iVar13 = *(int32_t *)(arg2 + 4);
    iVar11 = *(int32_t *)arg2 + (int32_t)var_18h;
    if (iVar13 < iVar11) {
        if (iVar13 == 0) {
            iVar13 = 8;
        } else {
            iVar13 = iVar13 / 2 + iVar13;
        }
        iVar8 = iVar11;
        if (iVar11 < iVar13) {
            iVar8 = iVar13;
        }
        func_0x00018011fc10(arg2, iVar8);
    }
    *(int32_t *)arg2 = iVar11;
    iVar13 = *(int32_t *)(arg2 + 0x14);
    iVar11 = *(int32_t *)(arg2 + 0x10) + (int32_t)var_20h;
    if (iVar13 < iVar11) {
        if (iVar13 != 0) {
            iVar10 = iVar13 + iVar13 / 2;
        }
        iVar13 = iVar11;
        if (iVar11 < iVar10) {
            iVar13 = iVar10;
        }
        func_0x00018011f8d0(arg2 + 0x10, iVar13);
    }
    iVar10 = 1;
    *(int32_t *)(arg2 + 0x10) = iVar11;
    iVar9 = *piVar3;
    iVar15 = iVar9 + ((int64_t)*(int32_t *)arg2 - (int64_t)(int32_t)var_18h) * 0x48;
    iVar7 = *(int64_t *)(arg2 + 0x18) + ((int64_t)iVar11 - (int64_t)(int32_t)var_20h) * 2;
    if (1 < *(int32_t *)(arg1 + 4)) {
        do {
            piVar14 = (int32_t *)((int64_t)iVar10 * 0x20 + *(int64_t *)(arg1 + 0x10));
            if (*piVar14 != 0) {
                iVar9 = (int64_t)*piVar14 * 0x48;
                func_0x000180498030(iVar15, *(undefined8 *)(piVar14 + 2), iVar9);
                iVar15 = iVar15 + iVar9;
            }
            if (piVar14[4] != 0) {
                iVar9 = (int64_t)piVar14[4] * 2;
                func_0x000180498030(iVar7, *(undefined8 *)(piVar14 + 6), iVar9);
                iVar7 = iVar7 + iVar9;
            }
            iVar10 = iVar10 + 1;
        } while (iVar10 < *(int32_t *)(arg1 + 4));
        iVar9 = *piVar3;
    }
    *(int64_t *)(arg2 + 0x48) = iVar7;
    if ((*(int32_t *)arg2 == 0) || (*(int64_t *)(iVar9 + -0x18 + (int64_t)*(int32_t *)arg2 * 0x48) != 0)) {
        func_0x000180124200(arg2);
    }
    iVar15 = (int64_t)*(int32_t *)arg2 * 9 + -9;
    puVar2 = (undefined4 *)(*piVar3 + iVar15 * 8);
    if (*(int32_t *)(*piVar3 + 0x28 + iVar15 * 8) != 0) {
        iVar10 = func_0x000180497f30(puVar2, (undefined4 *)(arg2 + 0x60), 0x24);
        if (iVar10 != 0) {
            func_0x000180124200(arg2);
        }
        *(undefined4 *)(arg1 + 4) = 1;
        return;
    }
    uVar4 = *(undefined4 *)(arg2 + 100);
    uVar5 = *(undefined4 *)(arg2 + 0x68);
    uVar6 = *(undefined4 *)(arg2 + 0x6c);
    *puVar2 = *(undefined4 *)(arg2 + 0x60);
    puVar2[1] = uVar4;
    puVar2[2] = uVar5;
    puVar2[3] = uVar6;
    uVar4 = *(undefined4 *)(arg2 + 0x74);
    uVar5 = *(undefined4 *)(arg2 + 0x78);
    uVar6 = *(undefined4 *)(arg2 + 0x7c);
    puVar2[4] = *(undefined4 *)(arg2 + 0x70);
    puVar2[5] = uVar4;
    puVar2[6] = uVar5;
    puVar2[7] = uVar6;
    puVar2[8] = *(undefined4 *)(arg2 + 0x80);
    *(undefined4 *)(arg1 + 4) = 1;
    return;
}

// ============================================================
// Function: FUN_180127010
// Address: 0x180127010
// Size: 211 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180127010(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    int32_t iVar13;
    int64_t iVar14;
    int32_t iVar15;
    int64_t var_68h;
    int64_t var_8h;
    
    iVar13 = (int32_t)arg3;
    if (*(int32_t *)arg1 == iVar13) {
        return;
    }
    uVar2 = *(undefined4 *)(arg2 + 4);
    uVar3 = *(undefined4 *)(arg2 + 8);
    uVar5 = *(undefined4 *)(arg2 + 0xc);
    puVar1 = (undefined4 *)((int64_t)*(int32_t *)arg1 * 0x20 + *(int64_t *)(arg1 + 0x10));
    *puVar1 = *(undefined4 *)arg2;
    puVar1[1] = uVar2;
    puVar1[2] = uVar3;
    puVar1[3] = uVar5;
    uVar2 = *(undefined4 *)(arg2 + 0x14);
    uVar3 = *(undefined4 *)(arg2 + 0x18);
    uVar5 = *(undefined4 *)(arg2 + 0x1c);
    puVar1 = (undefined4 *)((int64_t)*(int32_t *)arg1 * 0x20 + 0x10 + *(int64_t *)(arg1 + 0x10));
    *puVar1 = *(undefined4 *)(arg2 + 0x10);
    puVar1[1] = uVar2;
    puVar1[2] = uVar3;
    puVar1[3] = uVar5;
    *(int32_t *)arg1 = iVar13;
    puVar1 = (undefined4 *)((int64_t)iVar13 * 0x20 + *(int64_t *)(arg1 + 0x10));
    uVar2 = puVar1[1];
    uVar3 = puVar1[2];
    uVar5 = puVar1[3];
    *(undefined4 *)arg2 = *puVar1;
    *(undefined4 *)(arg2 + 4) = uVar2;
    *(undefined4 *)(arg2 + 8) = uVar3;
    *(undefined4 *)(arg2 + 0xc) = uVar5;
    puVar1 = (undefined4 *)((int64_t)iVar13 * 0x20 + 0x10 + *(int64_t *)(arg1 + 0x10));
    uVar2 = puVar1[1];
    uVar3 = puVar1[2];
    uVar5 = puVar1[3];
    *(undefined4 *)(arg2 + 0x10) = *puVar1;
    *(undefined4 *)(arg2 + 0x14) = uVar2;
    *(undefined4 *)(arg2 + 0x18) = uVar3;
    *(undefined4 *)(arg2 + 0x1c) = uVar5;
    *(int64_t *)(arg2 + 0x48) = *(int64_t *)(arg2 + 0x18) + (int64_t)*(int32_t *)(arg2 + 0x10) * 2;
    if ((*(int32_t *)arg2 != 0) &&
       (puVar1 = (undefined4 *)(*(int64_t *)(arg2 + 8) + ((int64_t)*(int32_t *)arg2 * 9 + -9) * 8),
       puVar1 != (undefined4 *)0x0)) {
        if (puVar1[10] == 0) {
            uVar2 = *(undefined4 *)(arg2 + 100);
            uVar3 = *(undefined4 *)(arg2 + 0x68);
            uVar5 = *(undefined4 *)(arg2 + 0x6c);
            *puVar1 = *(undefined4 *)(arg2 + 0x60);
            puVar1[1] = uVar2;
            puVar1[2] = uVar3;
            puVar1[3] = uVar5;
            uVar2 = *(undefined4 *)(arg2 + 0x74);
            uVar3 = *(undefined4 *)(arg2 + 0x78);
            uVar5 = *(undefined4 *)(arg2 + 0x7c);
            puVar1[4] = *(undefined4 *)(arg2 + 0x70);
            puVar1[5] = uVar2;
            puVar1[6] = uVar3;
            puVar1[7] = uVar5;
            puVar1[8] = *(undefined4 *)(arg2 + 0x80);
            return;
        }
        iVar13 = fcn.180497f30(puVar1, (undefined4 *)(arg2 + 0x60), 0x24);
        if (iVar13 == 0) {
            return;
        }
    }
    iVar13 = *(int32_t *)(arg2 + 4);
    uVar5 = *(undefined4 *)(arg2 + 0x60);
    uVar6 = *(undefined4 *)(arg2 + 100);
    uVar7 = *(undefined4 *)(arg2 + 0x68);
    uVar8 = *(undefined4 *)(arg2 + 0x6c);
    uVar2 = *(undefined4 *)(arg2 + 0x80);
    uVar9 = *(undefined4 *)(arg2 + 0x70);
    uVar10 = *(undefined4 *)(arg2 + 0x74);
    uVar11 = *(undefined4 *)(arg2 + 0x78);
    uVar12 = *(undefined4 *)(arg2 + 0x7c);
    uVar3 = *(undefined4 *)(arg2 + 0x10);
    if (*(int32_t *)arg2 == iVar13) {
        iVar15 = *(int32_t *)arg2 + 1;
        if (iVar13 == 0) {
            iVar13 = 8;
        } else {
            iVar13 = iVar13 / 2 + iVar13;
        }
        if (iVar15 < iVar13) {
            iVar15 = iVar13;
        }
        fcn.18011fc10(arg2, iVar15);
    }
    iVar14 = (int64_t)*(int32_t *)arg2;
    iVar4 = *(int64_t *)(arg2 + 8);
    puVar1 = (undefined4 *)(iVar4 + iVar14 * 0x48);
    *puVar1 = uVar5;
    puVar1[1] = uVar6;
    puVar1[2] = uVar7;
    puVar1[3] = uVar8;
    puVar1 = (undefined4 *)(iVar4 + 0x10 + iVar14 * 0x48);
    *puVar1 = uVar9;
    puVar1[1] = uVar10;
    puVar1[2] = uVar11;
    puVar1[3] = uVar12;
    puVar1 = (undefined4 *)(iVar4 + 0x20 + iVar14 * 0x48);
    *puVar1 = uVar2;
    puVar1[1] = uVar3;
    puVar1[2] = 0;
    puVar1[3] = 0;
    *(undefined (*) [16])(iVar4 + 0x30 + iVar14 * 0x48) = ZEXT816(0);
    *(undefined8 *)(iVar4 + 0x40 + iVar14 * 0x48) = 0;
    *(int32_t *)arg2 = *(int32_t *)arg2 + 1;
    return;
}

// ============================================================
// Function: FUN_1801270f0
// Address: 0x1801270f0
// Size: 234 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801270f0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = *(int32_t *)arg3;
    if ((iVar2 != 0) &&
       (((iVar2 != 1 || (*(int32_t *)(*(int64_t *)(arg3 + 8) + 0x28) != 0)) ||
        (*(int64_t *)(*(int64_t *)(arg3 + 8) + 0x30) != 0)))) {
        if (0 < *(int32_t *)(arg3 + 0xc0)) {
            iVar3 = *(int64_t *)(arg3 + 8);
            iVar1 = iVar3 + (int64_t)iVar2 * 0x48;
            for (; iVar3 != iVar1; iVar3 = iVar3 + 0x48) {
                if (((*(int64_t *)(iVar3 + 0x30) != 0) && (*(int32_t *)(iVar3 + 0x44) != -1)) &&
                   (0 < *(int32_t *)(iVar3 + 0x40))) {
                    *(int64_t *)(iVar3 + 0x38) = (int64_t)*(int32_t *)(iVar3 + 0x44) + *(int64_t *)(arg3 + 200);
                }
            }
        }
        iVar2 = *(int32_t *)(arg2 + 4);
        if (*(int32_t *)arg2 == iVar2) {
            iVar4 = *(int32_t *)arg2 + 1;
            if (iVar2 == 0) {
                iVar2 = 8;
            } else {
                iVar2 = iVar2 / 2 + iVar2;
            }
            if (iVar4 < iVar2) {
                iVar4 = iVar2;
            }
            func_0x00018011f4f0(arg2, iVar4);
        }
        *(int64_t *)(*(int64_t *)(arg2 + 8) + (int64_t)*(int32_t *)arg2 * 8) = arg3;
        *(int32_t *)arg2 = *(int32_t *)arg2 + 1;
        *(int32_t *)(arg1 + 4) = *(int32_t *)(arg1 + 4) + 1;
        *(int32_t *)(arg1 + 0xc) = *(int32_t *)(arg1 + 0xc) + *(int32_t *)(arg3 + 0x20);
        *(int32_t *)(arg1 + 8) = *(int32_t *)(arg1 + 8) + *(int32_t *)(arg3 + 0x10);
    }
    return;
}

// ============================================================
// Function: FUN_1801271e0
// Address: 0x1801271e0
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801271e0(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    piVar3 = *(int64_t **)(arg1 + 0x48);
    piVar1 = piVar3 + *(int32_t *)(arg1 + 0x40);
    for (; piVar3 != piVar1; piVar3 = piVar3 + 1) {
        iVar2 = *piVar3;
        if (*(int64_t *)(iVar2 + 0x28) != 0) {
            fcn.180460d90();
        }
        *(undefined8 *)(iVar2 + 0x28) = 0;
        *(undefined *)(iVar2 + 0x56) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1801271fb
// Address: 0x1801271fb
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801271e0(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    piVar3 = *(int64_t **)(arg1 + 0x48);
    piVar1 = piVar3 + *(int32_t *)(arg1 + 0x40);
    for (; piVar3 != piVar1; piVar3 = piVar3 + 1) {
        iVar2 = *piVar3;
        if (*(int64_t *)(iVar2 + 0x28) != 0) {
            fcn.180460d90();
        }
        *(undefined8 *)(iVar2 + 0x28) = 0;
        *(undefined *)(iVar2 + 0x56) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18012723c
// Address: 0x18012723c
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801271e0(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    piVar3 = *(int64_t **)(arg1 + 0x48);
    piVar1 = piVar3 + *(int32_t *)(arg1 + 0x40);
    for (; piVar3 != piVar1; piVar3 = piVar3 + 1) {
        iVar2 = *piVar3;
        if (*(int64_t *)(iVar2 + 0x28) != 0) {
            fcn.180460d90();
        }
        *(undefined8 *)(iVar2 + 0x28) = 0;
        *(undefined *)(iVar2 + 0x56) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180127250
// Address: 0x180127250
// Size: 542 bytes
// ============================================================
void fcn.180127250(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    undefined8 *puVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    
    puVar4 = *(undefined8 **)(arg1 + 0x70);
    puVar3 = puVar4 + *(int32_t *)(arg1 + 0x68);
    for (; puVar4 != puVar3; puVar4 = puVar4 + 1) {
        func_0x000180128320(arg1, *puVar4, 0);
    }
    func_0x00018012a970(arg1);
    puVar4 = *(undefined8 **)(arg1 + 0x70);
    puVar3 = puVar4 + *(int32_t *)(arg1 + 0x68);
    iVar8 = 0;
    for (; puVar4 != puVar3; puVar4 = puVar4 + 1) {
        puVar2 = (undefined8 *)*puVar4;
        if (puVar2[1] != 0) {
            func_0x000180129580(puVar2[1], puVar2);
        }
        *(undefined *)((int64_t)puVar2 + 0x34) = 0;
        *puVar2 = 0;
        piVar5 = (int64_t *)puVar2[5];
        piVar1 = piVar5 + *(int32_t *)(puVar2 + 4);
        for (; piVar5 != piVar1; piVar5 = piVar5 + 1) {
            iVar6 = *(int64_t *)(*piVar5 + 0x88);
            if (((iVar6 != 0) || (iVar6 = *(int64_t *)(arg1 + 0x2b8), iVar6 != 0)) &&
               (*(code **)(iVar6 + 0x20) != (code *)0x0)) {
                (**(code **)(iVar6 + 0x20))(arg1);
            }
        }
    }
    iVar6 = *(int64_t *)(arg1 + 0x80);
    iVar7 = (int64_t)*(int32_t *)(arg1 + 0x78) * 0xa0 + iVar6;
    for (; iVar6 != iVar7; iVar6 = iVar6 + 0xa0) {
        if (*(char *)(iVar6 + 0x34) != '\0') {
            fcn.180460d90(*(undefined8 *)(iVar6 + 0x28));
        }
        *(undefined8 *)(iVar6 + 0x28) = 0;
        if (*(int64_t *)(iVar6 + 0x48) != 0) {
            fcn.180460d90();
        }
        *(undefined8 *)(iVar6 + 0x48) = 0;
    }
    piVar5 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar5 + *(int32_t *)(arg1 + 0x68);
    for (; piVar5 != piVar1; piVar5 = piVar5 + 1) {
        iVar6 = *piVar5;
        if (*(int64_t *)(iVar6 + 0x28) != 0) {
            *(undefined8 *)(iVar6 + 0x20) = 0;
            fcn.180460d90();
            *(undefined8 *)(iVar6 + 0x28) = 0;
        }
        *(uint32_t *)(iVar6 + 0x10) = *(uint32_t *)(iVar6 + 0x10) | 4;
    }
    if (*(int64_t *)(arg1 + 0x80) != 0) {
        *(undefined8 *)(arg1 + 0x78) = 0;
        fcn.180460d90();
        *(undefined8 *)(arg1 + 0x80) = 0;
    }
    if (0 < *(int32_t *)(arg1 + 0x68)) {
        do {
            puVar3 = *(undefined8 **)(*(int64_t *)(arg1 + 0x70) + (int64_t)iVar8 * 8);
            if (puVar3 != (undefined8 *)0x0) {
                if (puVar3[1] != 0) {
                    func_0x000180129580(puVar3[1], puVar3);
                }
                *(undefined *)((int64_t)puVar3 + 0x34) = 0;
                *puVar3 = 0;
                if (puVar3[8] != 0) {
                    fcn.180460d90();
                }
                if (puVar3[5] != 0) {
                    fcn.180460d90();
                }
                fcn.180460d90(puVar3);
            }
            iVar8 = iVar8 + 1;
        } while (iVar8 < *(int32_t *)(arg1 + 0x68));
    }
    if (*(int64_t *)(arg1 + 0x70) != 0) {
        *(undefined8 *)(arg1 + 0x68) = 0;
        fcn.180460d90();
        *(undefined8 *)(arg1 + 0x70) = 0;
    }
    *(undefined *)(arg1 + 0x52) = 0;
    piVar5 = *(int64_t **)(arg1 + 0x2a8);
    piVar1 = piVar5 + *(int32_t *)(arg1 + 0x2a0);
    for (; piVar5 != piVar1; piVar5 = piVar5 + 1) {
        iVar6 = *piVar5;
        if (*(int64_t *)(iVar6 + 0x10) == arg1) {
            *(undefined8 *)(iVar6 + 0x18) = 0;
            *(undefined8 *)(iVar6 + 0x20) = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180127470
// Address: 0x180127470
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180127470(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, undefined8 placeholder_8, undefined8 placeholder_9, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = 0;
    if (0 < (int32_t)arg_40h) {
        do {
            fcn.180498030((int64_t)(((iVar1 + (int32_t)arg_30h) * *(int32_t *)(arg4 + 0x1c) + (int32_t)arg_28h) *
                                   *(int32_t *)(arg4 + 0x24)) + *(int64_t *)(arg4 + 0x28), 
                          (int64_t)(((iVar1 + (int32_t)arg3) * *(int32_t *)(arg1 + 0x1c) + (int32_t)arg2) *
                                   *(int32_t *)(arg1 + 0x24)) + *(int64_t *)(arg1 + 0x28), 
                          (int64_t)(*(int32_t *)(arg4 + 0x24) * (int32_t)arg_38h));
            iVar1 = iVar1 + 1;
        } while (iVar1 < (int32_t)arg_40h);
    }
    return;
}

// ============================================================
// Function: FUN_180127499
// Address: 0x180127499
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180127470(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, undefined8 placeholder_8, undefined8 placeholder_9, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = 0;
    if (0 < (int32_t)arg_40h) {
        do {
            fcn.180498030((int64_t)(((iVar1 + (int32_t)arg_30h) * *(int32_t *)(arg4 + 0x1c) + (int32_t)arg_28h) *
                                   *(int32_t *)(arg4 + 0x24)) + *(int64_t *)(arg4 + 0x28), 
                          (int64_t)(((iVar1 + (int32_t)arg3) * *(int32_t *)(arg1 + 0x1c) + (int32_t)arg2) *
                                   *(int32_t *)(arg1 + 0x24)) + *(int64_t *)(arg1 + 0x28), 
                          (int64_t)(*(int32_t *)(arg4 + 0x24) * (int32_t)arg_38h));
            iVar1 = iVar1 + 1;
        } while (iVar1 < (int32_t)arg_40h);
    }
    return;
}

// ============================================================
// Function: FUN_1801274fc
// Address: 0x1801274fc
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180127470(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h, undefined8 placeholder_8, undefined8 placeholder_9, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = 0;
    if (0 < (int32_t)arg_40h) {
        do {
            fcn.180498030((int64_t)(((iVar1 + (int32_t)arg_30h) * *(int32_t *)(arg4 + 0x1c) + (int32_t)arg_28h) *
                                   *(int32_t *)(arg4 + 0x24)) + *(int64_t *)(arg4 + 0x28), 
                          (int64_t)(((iVar1 + (int32_t)arg3) * *(int32_t *)(arg1 + 0x1c) + (int32_t)arg2) *
                                   *(int32_t *)(arg1 + 0x24)) + *(int64_t *)(arg1 + 0x28), 
                          (int64_t)(*(int32_t *)(arg4 + 0x24) * (int32_t)arg_38h));
            iVar1 = iVar1 + 1;
        } while (iVar1 < (int32_t)arg_40h);
    }
    return;
}

// ============================================================
// Function: FUN_180127510
// Address: 0x180127510
// Size: 383 bytes
// ============================================================
void fcn.180127510(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint16_t *puVar1;
    int64_t iVar2;
    uint16_t uVar3;
    int32_t iVar4;
    uint16_t uVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint16_t uVar8;
    int16_t iVar9;
    uint32_t uVar10;
    int32_t iVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    
    uVar3 = (uint16_t)arg4;
    uVar8 = *(uint16_t *)(arg2 + 0x38);
    uVar12 = (uint32_t)(uint16_t)arg_28h + (uint32_t)(uint16_t)placeholder_2;
    if (*(uint16_t *)(arg2 + 0x3c) == 0) {
        uVar13 = 0;
    } else {
        uVar13 = (uint32_t)uVar8 + (uint32_t)*(uint16_t *)(arg2 + 0x3c);
    }
    puVar1 = (uint16_t *)(arg2 + 0x3a);
    uVar6 = uVar12;
    if (uVar12 <= uVar13) {
        uVar6 = uVar13;
    }
    uVar13 = ((uint32_t)arg4 & 0xffff) + (uint32_t)(uint16_t)arg_30h;
    if (*(uint16_t *)(arg2 + 0x3e) == 0) {
        uVar10 = 0;
    } else {
        uVar10 = (uint32_t)*(uint16_t *)(arg2 + 0x3e) + (uint32_t)*puVar1;
    }
    iVar9 = (int16_t)uVar13;
    uVar5 = (uint16_t)placeholder_2;
    if (uVar8 < (uint16_t)placeholder_2) {
        uVar5 = uVar8;
    }
    *(uint16_t *)(arg2 + 0x38) = uVar5;
    uVar8 = uVar3;
    if (*puVar1 < uVar3) {
        uVar8 = *puVar1;
    }
    *puVar1 = uVar8;
    if (uVar13 <= uVar10) {
        iVar9 = (int16_t)uVar10;
    }
    *(uint16_t *)(arg2 + 0x3c) = (int16_t)uVar6 - uVar5;
    *(uint16_t *)(arg2 + 0x3e) = iVar9 - uVar8;
    uVar8 = (uint16_t)placeholder_2;
    if (*(uint16_t *)(arg2 + 0x30) < (uint16_t)placeholder_2) {
        uVar8 = *(uint16_t *)(arg2 + 0x30);
    }
    uVar5 = uVar3;
    if (*(uint16_t *)(arg2 + 0x32) < uVar3) {
        uVar5 = *(uint16_t *)(arg2 + 0x32);
    }
    uVar6 = (uint32_t)*(uint16_t *)(arg2 + 0x34) + (uint32_t)uVar8;
    *(uint16_t *)(arg2 + 0x30) = uVar8;
    if (uVar12 <= uVar6) {
        uVar12 = uVar6 & 0xffff;
    }
    *(uint16_t *)(arg2 + 0x32) = uVar5;
    uVar6 = (uint32_t)*(uint16_t *)(arg2 + 0x36) + (uint32_t)uVar5;
    *(uint16_t *)(arg2 + 0x34) = (int16_t)uVar12 - uVar8;
    if (uVar13 <= uVar6) {
        uVar13 = uVar6 & 0xffff;
    }
    *(uint16_t *)(arg2 + 0x36) = (int16_t)uVar13 - uVar5;
    *(undefined *)(arg1 + 0x52) = 0;
    if ((*(int32_t *)(arg2 + 4) == 0) || (*(int32_t *)(arg2 + 4) == 3)) {
        *(undefined4 *)(arg2 + 4) = 3;
        iVar4 = *(int32_t *)(arg2 + 0x44);
        if (*(int32_t *)(arg2 + 0x40) == iVar4) {
            iVar11 = *(int32_t *)(arg2 + 0x40) + 1;
            if (iVar4 == 0) {
                iVar4 = 8;
            } else {
                iVar4 = iVar4 / 2 + iVar4;
            }
            if (iVar11 < iVar4) {
                iVar11 = iVar4;
            }
            func_0x00018011f4f0(arg2 + 0x40, iVar11);
        }
        iVar7 = (int64_t)*(int32_t *)(arg2 + 0x40);
        iVar2 = *(int64_t *)(arg2 + 0x48);
        *(uint16_t *)(iVar2 + iVar7 * 8) = (uint16_t)placeholder_2;
        *(uint16_t *)(iVar2 + 2 + iVar7 * 8) = uVar3;
        *(uint16_t *)(iVar2 + 4 + iVar7 * 8) = (uint16_t)arg_28h;
        *(uint16_t *)(iVar2 + 6 + iVar7 * 8) = (uint16_t)arg_30h;
        *(int32_t *)(arg2 + 0x40) = *(int32_t *)(arg2 + 0x40) + 1;
    }
    return;
}

// ============================================================
// Function: FUN_180127690
// Address: 0x180127690
// Size: 787 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_118h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ceh
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d1h
// WARNING: [rz-ghidra] Detected overlap for variable var_d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_d2h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_58h

void fcn.180127690(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    undefined4 uVar4;
    undefined8 uVar5;
    float fVar6;
    undefined4 uVar7;
    int64_t var_118h;
    int64_t var_108h;
    undefined4 uStack_100;
    undefined4 uStack_fc;
    int64_t var_f8h;
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    int64_t var_e8h;
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    undefined4 var_d8h;
    undefined var_d4h;
    undefined uStack_d3;
    undefined var_d2h;
    undefined var_d1h;
    undefined uStack_d0;
    undefined uStack_cf;
    undefined2 var_ceh;
    float var_cch;
    int64_t var_c8h;
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    undefined auStack_b8 [8];
    undefined8 uStack_b0;
    undefined auStack_a8 [8];
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    undefined auStack_98 [8];
    undefined8 uStack_90;
    undefined auStack_88 [8];
    int64_t var_80h;
    undefined auStack_78 [4];
    int64_t var_74h;
    undefined4 uStack_6c;
    int64_t var_64h;
    int64_t var_5ch;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_8h;
    
    uStack_90 = auStack_98;
    iVar1 = *(int64_t *)(arg1 + 0x2d8);
    if (iVar1 != 0) {
        fVar6 = *(float *)(iVar1 + 0xd90);
        if (fVar6 <= 0.0) {
            fVar6 = 13.0;
        }
        if (fVar6 * *(float *)(iVar1 + 0xd94) * *(float *)(iVar1 + 0xd98) < 15.0) {
            if (arg2 == 0) {
                func_0x0001804986e0(&var_108h, 0, 0xa0);
                var_d1h = 0;
                uStack_d0 = 0;
                var_d4h = 1;
                uStack_b0._4_4_ = 0x7f7fffff;
                uStack_9c = 0x3f800000;
                auStack_98._0_4_ = 0x3f800000;
                auStack_98._4_4_ = 0x3f800000;
                var_d2h = 1;
            } else {
                var_d8h = *(undefined4 *)(arg2 + 0x30);
                uVar7 = *(undefined4 *)(arg2 + 0x34);
                var_cch = *(float *)(arg2 + 0x3c);
                var_108h._0_4_ = *(undefined4 *)arg2;
                var_108h._4_4_ = *(undefined4 *)(arg2 + 4);
                uStack_100 = *(undefined4 *)(arg2 + 8);
                uStack_fc = *(undefined4 *)(arg2 + 0xc);
                var_f8h._0_4_ = *(undefined4 *)(arg2 + 0x10);
                var_f8h._4_4_ = *(undefined4 *)(arg2 + 0x14);
                uStack_f0 = *(undefined4 *)(arg2 + 0x18);
                uStack_ec = *(undefined4 *)(arg2 + 0x1c);
                var_e8h._0_4_ = *(undefined4 *)(arg2 + 0x20);
                var_e8h._4_4_ = *(undefined4 *)(arg2 + 0x24);
                uStack_e0 = *(undefined4 *)(arg2 + 0x28);
                uStack_dc = *(undefined4 *)(arg2 + 0x2c);
                var_c8h._0_4_ = *(undefined4 *)(arg2 + 0x40);
                var_c8h._4_4_ = *(undefined4 *)(arg2 + 0x44);
                uStack_c0 = *(undefined4 *)(arg2 + 0x48);
                uStack_bc = *(undefined4 *)(arg2 + 0x4c);
                auStack_b8._0_4_ = *(undefined4 *)(arg2 + 0x50);
                auStack_b8._4_4_ = *(float *)(arg2 + 0x54);
                uStack_b0._0_4_ = *(undefined4 *)(arg2 + 0x58);
                uStack_b0._4_4_ = *(undefined4 *)(arg2 + 0x5c);
                auStack_a8._0_4_ = *(undefined4 *)(arg2 + 0x60);
                auStack_a8._4_4_ = *(undefined4 *)(arg2 + 100);
                uStack_a0 = *(undefined4 *)(arg2 + 0x68);
                uStack_9c = *(undefined4 *)(arg2 + 0x6c);
                auStack_98._0_4_ = *(undefined4 *)(arg2 + 0x70);
                auStack_98._4_4_ = *(undefined4 *)(arg2 + 0x74);
                uStack_90._0_4_ = *(uint32_t *)(arg2 + 0x78);
                uStack_90._4_4_ = *(undefined4 *)(arg2 + 0x7c);
                auStack_88._0_4_ = *(undefined4 *)(arg2 + 0x80);
                auStack_88._4_4_ = *(undefined4 *)(arg2 + 0x84);
                var_80h._0_4_ = *(undefined4 *)(arg2 + 0x88);
                var_80h._4_4_ = *(undefined4 *)(arg2 + 0x8c);
                auStack_78 = *(undefined (*) [4])(arg2 + 0x90);
                var_74h._0_4_ = *(undefined4 *)(arg2 + 0x94);
                var_74h._4_4_ = *(undefined4 *)(arg2 + 0x98);
                uStack_6c = *(undefined4 *)(arg2 + 0x9c);
                var_d4h = (undefined)uVar7;
                uStack_d3 = (undefined)((uint32_t)uVar7 >> 8);
                var_d2h = (undefined)((uint32_t)uVar7 >> 0x10);
                var_d1h = (undefined)((uint32_t)uVar7 >> 0x18);
                uStack_d0 = (undefined)*(undefined4 *)(arg2 + 0x38);
                uStack_cf = (undefined)((uint32_t)*(undefined4 *)(arg2 + 0x38) >> 8);
            }
            auVar2._4_4_ = auStack_b8._4_4_;
            auVar2._0_4_ = auStack_b8._0_4_;
            auVar2._8_4_ = (undefined4)uStack_b0;
            auVar2._12_4_ = uStack_b0._4_4_;
            if (var_cch <= 0.0) {
                uStack_90._0_4_ = (uint32_t)uStack_90 | 0x10;
                var_cch = 13.0;
            }
            uVar5 = 0x18061c8e0;
            var_ceh = 0x85;
            uStack_b0 = auVar2._8_8_;
            auStack_b8._4_4_ = (float)auStack_b8._4_4_ + var_cch / 13.0;
            uVar7 = (undefined4)var_e8h;
            goto code_r0x000180127962;
        }
    }
    if (arg2 == 0) {
        func_0x0001804986e0(&var_108h, 0, 0xa0);
        var_d1h = 0;
        uStack_d0 = 0;
        var_d4h = 1;
        var_ceh = 0;
        uStack_b0._4_4_ = 0x7f7fffff;
        uStack_9c = 0x3f800000;
        auStack_98._0_4_ = 0x3f800000;
        auStack_98._4_4_ = 1.0;
        var_d2h = 1;
        uVar7 = (undefined4)var_e8h;
    } else {
        var_d8h = *(undefined4 *)(arg2 + 0x30);
        uVar7 = *(undefined4 *)(arg2 + 0x34);
        uVar4 = *(undefined4 *)(arg2 + 0x38);
        var_cch = *(float *)(arg2 + 0x3c);
        var_108h._0_4_ = *(undefined4 *)arg2;
        var_108h._4_4_ = *(undefined4 *)(arg2 + 4);
        uStack_100 = *(undefined4 *)(arg2 + 8);
        uStack_fc = *(undefined4 *)(arg2 + 0xc);
        var_f8h._0_4_ = *(undefined4 *)(arg2 + 0x10);
        var_f8h._4_4_ = *(undefined4 *)(arg2 + 0x14);
        uStack_f0 = *(undefined4 *)(arg2 + 0x18);
        uStack_ec = *(undefined4 *)(arg2 + 0x1c);
        var_e8h._4_4_ = *(undefined4 *)(arg2 + 0x24);
        uStack_e0 = *(undefined4 *)(arg2 + 0x28);
        uStack_dc = *(undefined4 *)(arg2 + 0x2c);
        var_c8h._0_4_ = *(undefined4 *)(arg2 + 0x40);
        var_c8h._4_4_ = *(undefined4 *)(arg2 + 0x44);
        uStack_c0 = *(undefined4 *)(arg2 + 0x48);
        uStack_bc = *(undefined4 *)(arg2 + 0x4c);
        auStack_b8._0_4_ = *(undefined4 *)(arg2 + 0x50);
        auStack_b8._4_4_ = *(float *)(arg2 + 0x54);
        uStack_b0._0_4_ = *(undefined4 *)(arg2 + 0x58);
        uStack_b0._4_4_ = *(undefined4 *)(arg2 + 0x5c);
        auStack_a8._0_4_ = *(undefined4 *)(arg2 + 0x60);
        auStack_a8._4_4_ = *(undefined4 *)(arg2 + 100);
        uStack_a0 = *(undefined4 *)(arg2 + 0x68);
        uStack_9c = *(undefined4 *)(arg2 + 0x6c);
        auStack_98._0_4_ = *(undefined4 *)(arg2 + 0x70);
        auStack_98._4_4_ = *(float *)(arg2 + 0x74);
        uStack_90._0_4_ = *(uint32_t *)(arg2 + 0x78);
        uStack_90._4_4_ = *(undefined4 *)(arg2 + 0x7c);
        auStack_88._0_4_ = *(undefined4 *)(arg2 + 0x80);
        auStack_88._4_4_ = *(undefined4 *)(arg2 + 0x84);
        var_80h._0_4_ = *(undefined4 *)(arg2 + 0x88);
        var_80h._4_4_ = *(undefined4 *)(arg2 + 0x8c);
        auStack_78 = *(undefined (*) [4])(arg2 + 0x90);
        var_74h._0_4_ = *(undefined4 *)(arg2 + 0x94);
        var_74h._4_4_ = *(undefined4 *)(arg2 + 0x98);
        uStack_6c = *(undefined4 *)(arg2 + 0x9c);
        var_d4h = (undefined)uVar7;
        uStack_d3 = (undefined)((uint32_t)uVar7 >> 8);
        var_d2h = (undefined)((uint32_t)uVar7 >> 0x10);
        var_d1h = (undefined)((uint32_t)uVar7 >> 0x18);
        uStack_d0 = (undefined)uVar4;
        uStack_cf = (undefined)((uint32_t)uVar4 >> 8);
        var_ceh = (undefined2)((uint32_t)uVar4 >> 0x10);
        uVar7 = *(undefined4 *)(arg2 + 0x20);
    }
    auVar3._4_4_ = auStack_b8._4_4_;
    auVar3._0_4_ = auStack_b8._0_4_;
    auVar3._8_4_ = (undefined4)uStack_b0;
    auVar3._12_4_ = uStack_b0._4_4_;
    var_e8h._0_4_ = uVar7;
    if (var_cch <= 0.0) {
        uStack_90._0_4_ = (uint32_t)uStack_90 | 0x10;
        var_cch = 13.0;
    }
    uVar5 = 0x180618ff0;
    auStack_98._4_4_ = (float)auStack_98._4_4_ * 1.015;
    uStack_b0 = auVar3._8_8_;
    auStack_b8._4_4_ = (float)auStack_b8._4_4_ + var_cch * 0.0625 * 0.5;
code_r0x000180127962:
    func_0x000180127ea0(arg1, uVar5, uVar7, var_cch, &var_108h);
    return;
}

// ============================================================
// Function: FUN_1801279b0
// Address: 0x1801279b0
// Size: 1264 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_131h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_12eh
// WARNING: [rz-ghidra] Detected overlap for variable var_138h
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Detected overlap for variable var_133h

undefined (*) [16] fcn.1801279b0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    undefined4 *puVar1;
    int16_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int16_t *piVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined auVar8 [16];
    undefined auVar9 [16];
    undefined auVar10 [16];
    undefined auVar11 [16];
    undefined auVar12 [16];
    int16_t *piVar13;
    undefined auVar14 [11];
    char cVar15;
    undefined (*pauVar16) [16];
    undefined8 uVar17;
    int32_t iVar18;
    int64_t iVar19;
    int32_t iVar20;
    int32_t iVar21;
    int64_t iVar22;
    undefined auVar23 [16];
    float in_XMM3_Da;
    float fVar24;
    undefined4 uVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    undefined4 uVar28;
    undefined4 uVar29;
    undefined4 uVar30;
    undefined4 uVar31;
    undefined4 uVar32;
    undefined4 uVar33;
    undefined4 uVar34;
    undefined4 uVar35;
    undefined4 uVar36;
    undefined4 uVar37;
    undefined4 uVar38;
    undefined4 uVar39;
    undefined4 uVar40;
    undefined4 uVar41;
    undefined4 uVar42;
    undefined4 uVar43;
    undefined4 uVar44;
    undefined4 uVar45;
    undefined4 uVar46;
    undefined4 uVar47;
    undefined4 uVar48;
    undefined4 uVar49;
    undefined4 uVar50;
    undefined4 uVar51;
    undefined4 uVar52;
    undefined4 uVar53;
    undefined4 uVar54;
    undefined4 uVar55;
    undefined4 uVar56;
    int64_t var_168h;
    undefined4 uStack_160;
    undefined4 uStack_15c;
    int64_t var_158h;
    undefined4 uStack_150;
    undefined4 uStack_14c;
    int64_t var_148h;
    undefined var_138h [4];
    int64_t var_134h;
    int64_t var_140h;
    float var_12ch;
    undefined4 var_128h;
    undefined4 uStack_124;
    undefined4 uStack_120;
    undefined4 uStack_11c;
    int64_t var_118h;
    undefined4 uStack_110;
    int64_t var_10ch;
    undefined4 uStack_104;
    undefined4 uStack_100;
    int64_t var_fch;
    int64_t var_f4h;
    undefined4 uStack_ec;
    int64_t var_e8h;
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    int64_t var_d8h;
    undefined4 uStack_d0;
    undefined4 uStack_cc;
    int64_t var_38h;
    
    if (arg_28h == 0) {
        func_0x0001804986e0(&var_168h, 0, 0xa0);
        auVar14 = stack0xfffffffffffffecd;
        _var_138h = 0x100000000;
        auVar23 = _var_138h;
        _var_138h = (unkuint9)0;
        auVar6 = _var_138h;
        var_f4h._0_4_ = 0x3f800000;
        var_10ch._0_4_ = 0x7f7fffff;
        var_fch._0_4_ = 0x3f800000;
        var_fch._4_4_ = 0x3f800000;
        var_12ch = auVar14._7_4_;
        var_134h._0_4_ = (uint32_t)auVar23._4_3_;
        var_134h._4_4_ = (uint32_t)auVar6._8_2_;
        uVar48 = 0x7f7fffff;
        uVar52 = 0x3f800000;
        uVar25 = 0x3f800000;
        uVar26 = 0x3f800000;
        uVar27 = var_f4h._4_4_;
        uVar28 = uStack_ec;
        uVar29 = (undefined4)var_e8h;
        uVar30 = var_e8h._4_4_;
        uVar31 = uStack_e0;
        uVar32 = uStack_dc;
        uVar33 = (undefined4)var_168h;
        uVar34 = var_168h._4_4_;
        uVar35 = uStack_160;
        uVar36 = uStack_15c;
        uVar37 = (undefined4)var_158h;
        uVar38 = var_158h._4_4_;
        uVar39 = uStack_150;
        uVar40 = uStack_14c;
        uVar41 = var_128h;
        uVar42 = uStack_124;
        uVar43 = uStack_120;
        uVar44 = uStack_11c;
        uVar45 = (undefined4)var_118h;
        uVar46 = var_118h._4_4_;
        uVar47 = uStack_110;
        uVar49 = var_10ch._4_4_;
        uVar50 = uStack_104;
        uVar51 = uStack_100;
        uVar53 = (undefined4)var_d8h;
        uVar54 = var_d8h._4_4_;
        uVar55 = uStack_d0;
        uVar56 = uStack_cc;
    } else {
        var_148h._0_4_ = *(undefined4 *)(arg_28h + 0x20);
        var_148h._4_4_ = *(undefined4 *)(arg_28h + 0x24);
        var_134h._0_4_ = *(uint32_t *)(arg_28h + 0x34);
        var_134h._4_4_ = *(uint32_t *)(arg_28h + 0x38);
        var_12ch = *(float *)(arg_28h + 0x3c);
        uVar48 = *(undefined4 *)(arg_28h + 0x5c);
        uVar52 = *(undefined4 *)(arg_28h + 0x6c);
        uVar25 = *(undefined4 *)(arg_28h + 0x70);
        uVar26 = *(undefined4 *)(arg_28h + 0x74);
        uVar27 = *(undefined4 *)(arg_28h + 0x78);
        uVar28 = *(undefined4 *)(arg_28h + 0x7c);
        uVar29 = *(undefined4 *)(arg_28h + 0x80);
        uVar30 = *(undefined4 *)(arg_28h + 0x84);
        uVar31 = *(undefined4 *)(arg_28h + 0x88);
        uVar32 = *(undefined4 *)(arg_28h + 0x8c);
        uVar33 = *(undefined4 *)arg_28h;
        uVar34 = *(undefined4 *)(arg_28h + 4);
        uVar35 = *(undefined4 *)(arg_28h + 8);
        uVar36 = *(undefined4 *)(arg_28h + 0xc);
        uVar37 = *(undefined4 *)(arg_28h + 0x10);
        uVar38 = *(undefined4 *)(arg_28h + 0x14);
        uVar39 = *(undefined4 *)(arg_28h + 0x18);
        uVar40 = *(undefined4 *)(arg_28h + 0x1c);
        uVar41 = *(undefined4 *)(arg_28h + 0x40);
        uVar42 = *(undefined4 *)(arg_28h + 0x44);
        uVar43 = *(undefined4 *)(arg_28h + 0x48);
        uVar44 = *(undefined4 *)(arg_28h + 0x4c);
        uVar45 = *(undefined4 *)(arg_28h + 0x50);
        uVar46 = *(undefined4 *)(arg_28h + 0x54);
        uVar47 = *(undefined4 *)(arg_28h + 0x58);
        uVar49 = *(undefined4 *)(arg_28h + 0x60);
        uVar50 = *(undefined4 *)(arg_28h + 100);
        uVar51 = *(undefined4 *)(arg_28h + 0x68);
        uVar53 = *(undefined4 *)(arg_28h + 0x90);
        uVar54 = *(undefined4 *)(arg_28h + 0x94);
        uVar55 = *(undefined4 *)(arg_28h + 0x98);
        uVar56 = *(undefined4 *)(arg_28h + 0x9c);
    }
    var_138h = (undefined  [4])(int32_t)arg3;
    fVar24 = var_12ch;
    if (0.0 < in_XMM3_Da) {
        var_12ch = in_XMM3_Da;
        fVar24 = in_XMM3_Da;
    }
    var_140h = arg2;
    if (*(int64_t *)(arg1 + 0x2b0) == 0) {
        func_0x00018012a190(arg1);
    }
    iVar3 = *(int32_t *)(arg1 + 0x68);
    iVar18 = 8;
    if (var_134h._1_1_ == '\0') {
        pauVar16 = (undefined (*) [16])fcn.18046d050(0x50);
        if (pauVar16 == (undefined (*) [16])0x0) {
            pauVar16 = (undefined (*) [16])0x0;
        } else {
            auVar23 = ZEXT816(0);
            *pauVar16 = auVar23;
            pauVar16[1] = auVar23;
            pauVar16[2] = auVar23;
            pauVar16[3] = auVar23;
            pauVar16[4] = auVar23;
            *(undefined4 *)(pauVar16[4] + 8) = 0x3f800000;
        }
        iVar4 = *(int32_t *)(arg1 + 0x29c);
        *(int32_t *)(arg1 + 0x29c) = iVar4 + 1;
        *(int32_t *)(pauVar16[1] + 8) = iVar4;
        *(undefined4 *)pauVar16[1] = uVar27;
        *(float *)(pauVar16[1] + 0xc) = fVar24;
        *(undefined4 *)(pauVar16[1] + 4) = uVar25;
        iVar4 = *(int32_t *)(arg1 + 0x6c);
        if (*(int32_t *)(arg1 + 0x68) == iVar4) {
            iVar20 = *(int32_t *)(arg1 + 0x68) + 1;
            iVar21 = iVar18;
            if (iVar4 != 0) {
                iVar21 = iVar4 / 2 + iVar4;
            }
            if (iVar20 < iVar21) {
                iVar20 = iVar21;
            }
            if (iVar4 < iVar20) {
                uVar17 = fcn.18046d050((int64_t)iVar20 << 3);
                if (*(int64_t *)(arg1 + 0x70) != 0) {
                    fcn.180498030(uVar17, *(int64_t *)(arg1 + 0x70), (int64_t)*(int32_t *)(arg1 + 0x68) << 3);
                    fcn.180460d90(*(undefined8 *)(arg1 + 0x70));
                }
                *(undefined8 *)(arg1 + 0x70) = uVar17;
                *(int32_t *)(arg1 + 0x6c) = iVar20;
            }
        }
        *(undefined (**) [16])(*(int64_t *)(arg1 + 0x70) + (int64_t)*(int32_t *)(arg1 + 0x68) * 8) = pauVar16;
        *(int32_t *)(arg1 + 0x68) = *(int32_t *)(arg1 + 0x68) + 1;
    } else {
        pauVar16 = (undefined (*) [16])CONCAT44(uVar30, uVar29);
        if (pauVar16 == (undefined (*) [16])0x0) {
            pauVar16 = *(undefined (**) [16])(*(int64_t *)(arg1 + 0x70) + -8 + (int64_t)iVar3 * 8);
        }
        func_0x000180129580(arg1, pauVar16);
    }
    iVar4 = *(int32_t *)(arg1 + 0x7c);
    if (*(int32_t *)(arg1 + 0x78) == iVar4) {
        iVar20 = *(int32_t *)(arg1 + 0x78) + 1;
        iVar21 = iVar18;
        if (iVar4 != 0) {
            iVar21 = iVar4 / 2 + iVar4;
        }
        if (iVar20 < iVar21) {
            iVar20 = iVar21;
        }
        if (iVar4 < iVar20) {
            uVar17 = fcn.18046d050((int64_t)iVar20 * 0xa0);
            if (*(int64_t *)(arg1 + 0x80) != 0) {
                fcn.180498030(uVar17, *(int64_t *)(arg1 + 0x80), (int64_t)*(int32_t *)(arg1 + 0x78) * 0xa0);
                fcn.180460d90(*(undefined8 *)(arg1 + 0x80));
            }
            *(undefined8 *)(arg1 + 0x80) = uVar17;
            *(int32_t *)(arg1 + 0x7c) = iVar20;
        }
    }
    iVar19 = (int64_t)*(int32_t *)(arg1 + 0x78) * 0xa0;
    iVar22 = *(int64_t *)(arg1 + 0x80);
    auVar7._4_4_ = uVar34;
    auVar7._0_4_ = uVar33;
    auVar7._8_4_ = uVar35;
    auVar7._12_4_ = uVar36;
    *(undefined (*) [16])(iVar19 + iVar22) = auVar7;
    auVar8._4_4_ = uVar38;
    auVar8._0_4_ = uVar37;
    auVar8._8_4_ = uVar39;
    auVar8._12_4_ = uVar40;
    *(undefined (*) [16])(iVar19 + 0x10 + iVar22) = auVar8;
    puVar1 = (undefined4 *)(iVar19 + 0x20 + iVar22);
    *puVar1 = (undefined4)var_148h;
    puVar1[1] = var_148h._4_4_;
    puVar1[2] = (undefined4)var_140h;
    puVar1[3] = var_140h._4_4_;
    puVar1 = (undefined4 *)(iVar19 + 0x30 + iVar22);
    *puVar1 = var_138h;
    puVar1[1] = (uint32_t)var_134h;
    puVar1[2] = var_134h._4_4_;
    puVar1[3] = var_12ch;
    auVar9._4_4_ = uVar42;
    auVar9._0_4_ = uVar41;
    auVar9._8_4_ = uVar43;
    auVar9._12_4_ = uVar44;
    *(undefined (*) [16])(iVar19 + 0x40 + iVar22) = auVar9;
    auVar10._4_4_ = uVar46;
    auVar10._0_4_ = uVar45;
    auVar10._8_4_ = uVar47;
    auVar10._12_4_ = uVar48;
    *(undefined (*) [16])(iVar19 + 0x50 + iVar22) = auVar10;
    auVar11._4_4_ = uVar50;
    auVar11._0_4_ = uVar49;
    auVar11._8_4_ = uVar51;
    auVar11._12_4_ = uVar52;
    *(undefined (*) [16])(iVar19 + 0x60 + iVar22) = auVar11;
    auVar23._4_4_ = uVar26;
    auVar23._0_4_ = uVar25;
    auVar23._8_4_ = uVar27;
    auVar23._12_4_ = uVar28;
    *(undefined (*) [16])(iVar19 + 0x70 + iVar22) = auVar23;
    auVar6._4_4_ = uVar30;
    auVar6._0_4_ = uVar29;
    auVar6._8_4_ = uVar31;
    auVar6._12_4_ = uVar32;
    *(undefined (*) [16])(iVar19 + 0x80 + iVar22) = auVar6;
    auVar12._4_4_ = uVar54;
    auVar12._0_4_ = uVar53;
    auVar12._8_4_ = uVar55;
    auVar12._12_4_ = uVar56;
    *(undefined (*) [16])(iVar19 + 0x90 + iVar22) = auVar12;
    iVar4 = *(int32_t *)(arg1 + 0x78);
    *(int32_t *)(arg1 + 0x78) = iVar4 + 1;
    iVar22 = (int64_t)iVar4 * 0xa0 + *(int64_t *)(arg1 + 0x80);
    if (*(int64_t *)(iVar22 + 0x80) == 0) {
        *(undefined (**) [16])(iVar22 + 0x80) = pauVar16;
    }
    iVar4 = *(int32_t *)(pauVar16[2] + 4);
    if (*(int32_t *)pauVar16[2] == iVar4) {
        iVar21 = *(int32_t *)pauVar16[2] + 1;
        if (iVar4 != 0) {
            iVar18 = iVar4 + iVar4 / 2;
        }
        if (iVar21 < iVar18) {
            iVar21 = iVar18;
        }
        func_0x00018011f4f0(pauVar16 + 2, iVar21);
    }
    *(int64_t *)(*(int64_t *)(pauVar16[2] + 8) + (int64_t)*(int32_t *)pauVar16[2] * 8) = iVar22;
    *(int32_t *)pauVar16[2] = *(int32_t *)pauVar16[2] + 1;
    func_0x000180128810();
    piVar5 = *(int16_t **)(iVar22 + 0x48);
    if (piVar5 != (int16_t *)0x0) {
        iVar18 = 0;
        iVar2 = *piVar5;
        piVar13 = piVar5;
        while (iVar2 != 0) {
            piVar13 = piVar13 + 1;
            iVar18 = iVar18 + 1;
            iVar2 = *piVar13;
        }
        iVar19 = (int64_t)(iVar18 + 1) * 2;
        uVar17 = fcn.18046d050(iVar19);
        uVar17 = fcn.180498030(uVar17, piVar5, iVar19);
        *(undefined8 *)(iVar22 + 0x48) = uVar17;
    }
    iVar19 = *(int64_t *)(iVar22 + 0x88);
    if (iVar19 == 0) {
        iVar19 = *(int64_t *)(arg1 + 0x2b8);
    }
    if ((*(code **)(iVar19 + 0x18) == (code *)0x0) ||
       (cVar15 = (**(code **)(iVar19 + 0x18))(arg1, iVar22), cVar15 != '\0')) {
        func_0x000180129250(arg1, pauVar16, iVar22);
        if (iVar3 == 0) {
            func_0x000180128320(arg1, 0, pauVar16);
        }
    } else {
        if (*(char *)(iVar22 + 0x34) != '\0') {
            fcn.180460d90(*(undefined8 *)(iVar22 + 0x28));
        }
        *(undefined8 *)(iVar22 + 0x28) = 0;
        if (*(int64_t *)(iVar22 + 0x48) != 0) {
            fcn.180460d90();
        }
        *(undefined8 *)(iVar22 + 0x48) = 0;
        *(int32_t *)(arg1 + 0x78) = *(int32_t *)(arg1 + 0x78) + -1;
        *(int32_t *)pauVar16[2] = *(int32_t *)pauVar16[2] + -1;
        if (*(char *)(iVar22 + 0x35) == '\0') {
            if (pauVar16 != (undefined (*) [16])0x0) {
                if (*(int64_t *)(*pauVar16 + 8) != 0) {
                    func_0x000180129580(*(int64_t *)(*pauVar16 + 8), pauVar16);
                }
                pauVar16[3][4] = 0;
                *(undefined8 *)*pauVar16 = 0;
                if (*(int64_t *)pauVar16[4] != 0) {
                    fcn.180460d90();
                }
                if (*(int64_t *)(pauVar16[2] + 8) != 0) {
                    fcn.180460d90();
                }
                fcn.180460d90(pauVar16);
            }
            *(int32_t *)(arg1 + 0x68) = *(int32_t *)(arg1 + 0x68) + -1;
        }
        pauVar16 = (undefined (*) [16])0x0;
    }
    return pauVar16;
}

// ============================================================
// Function: FUN_180127ea0
// Address: 0x180127ea0
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_138h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_eeh
// WARNING: [rz-ghidra] Detected overlap for variable var_f1h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_131h
// WARNING: [rz-ghidra] Detected overlap for variable var_12eh
// WARNING: [rz-ghidra] Detected overlap for variable var_138h
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Detected overlap for variable var_133h

void fcn.180127ea0(int64_t arg1, int64_t arg2, int64_t arg_80h)
{
    uint8_t uVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    uint64_t arg2_00;
    uint8_t *puVar4;
    uint64_t uVar5;
    undefined8 in_R9;
    uint8_t *puVar6;
    uint32_t uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 *in_stack_00000028;
    int64_t var_138h;
    int64_t var_128h;
    undefined4 uStack_120;
    undefined4 uStack_11c;
    int64_t var_118h;
    undefined4 uStack_110;
    undefined4 uStack_10c;
    int64_t var_108h;
    undefined4 uStack_100;
    undefined4 uStack_fc;
    undefined var_f8h [4];
    int64_t var_f4h;
    undefined4 uStack_ec;
    undefined var_e8h [8];
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    undefined auStack_d8 [8];
    undefined4 uStack_d0;
    undefined4 uStack_cc;
    undefined auStack_c8 [8];
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    undefined auStack_b8 [8];
    undefined8 uStack_b0;
    undefined auStack_a8 [8];
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    undefined auStack_98 [8];
    undefined4 uStack_90;
    undefined4 uStack_8c;
    int64_t var_80h;
    int64_t var_74h;
    int64_t var_64h;
    int64_t var_5ch;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    uVar7 = (uint32_t)*(uint8_t *)(arg2 + 10) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 9) * 0x10000 +
            (uint32_t)*(uint8_t *)(arg2 + 8) * 0x1000000 + (uint32_t)*(uint8_t *)(arg2 + 0xb);
    arg2_00 = fcn.18046d050(uVar7);
    if (((((uint32_t)*(uint8_t *)arg2 * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 1)) * 0x100 +
         (uint32_t)*(uint8_t *)(arg2 + 2)) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 3) == 0x57bc0000) &&
       ((((uint32_t)*(uint8_t *)(arg2 + 4) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 5)) * 0x100 +
        (uint32_t)*(uint8_t *)(arg2 + 6)) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 7) == 0)) {
        uVar5 = ((uint32_t)*(uint8_t *)(arg2 + 10) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 9) * 0x10000 +
                 (uint32_t)*(uint8_t *)(arg2 + 8) * 0x1000000 + (uint32_t)*(uint8_t *)(arg2 + 0xb)) + arg2_00;
        puVar4 = (uint8_t *)(arg2 + 0x10);
        *(int64_t *)0x180782380 = arg2;
        *(uint64_t *)0x180782390 = uVar5;
        *(uint64_t *)0x180782398 = arg2_00;
        *(uint64_t *)0x1807823c0 = arg2_00;
        do {
            uVar1 = *puVar4;
            if (uVar1 < 0x20) {
                if (uVar1 < 0x18) {
                    if (uVar1 < 0x10) {
                        if (uVar1 < 8) {
                            if (uVar1 == 7) {
                                func_0x0001801310b0(puVar4 + 3, (uint32_t)puVar4[2] + (uint32_t)puVar4[1] * 0x100 + 1);
                                puVar6 = puVar4 + (uint64_t)puVar4[2] + (uint64_t)puVar4[1] * 0x100 + 4;
                            } else if (uVar1 == 6) {
                                func_0x000180131050(((*(uint64_t *)0x1807823c0 +
                                                     (uint64_t)CONCAT11(puVar4[1], puVar4[2]) * -0x100) -
                                                    (uint64_t)puVar4[3]) + -1, puVar4[4] + 1);
                                puVar6 = puVar4 + 5;
                            } else {
                                puVar6 = puVar4;
                                if (uVar1 == 4) {
                                    func_0x000180131050(((*(uint64_t *)0x1807823c0 +
                                                         (uint64_t)CONCAT11(puVar4[1], puVar4[2]) * -0x100) -
                                                        (uint64_t)puVar4[3]) + -1, 
                                                        (uint32_t)puVar4[5] + (uint32_t)puVar4[4] * 0x100 + 1);
                                    puVar6 = puVar4 + 6;
                                }
                            }
                        } else {
                            func_0x0001801310b0(puVar4 + 2, (uint32_t)puVar4[1] + (uint32_t)uVar1 * 0x100 + -0x7ff);
                            puVar6 = puVar4 + (uint64_t)puVar4[1] + (uint64_t)*puVar4 * 0x100 + -0x7fd;
                        }
                    } else {
                        func_0x000180131050(((*(uint64_t *)0x1807823c0 + (uint64_t)CONCAT11(uVar1, puVar4[1]) * -0x100)
                                            - (uint64_t)puVar4[2]) + 0xfffff, 
                                            (uint32_t)puVar4[4] + (uint32_t)puVar4[3] * 0x100 + 1);
                        puVar6 = puVar4 + 5;
                    }
                } else {
                    func_0x000180131050(((*(uint64_t *)0x1807823c0 + (uint64_t)CONCAT11(uVar1, puVar4[1]) * -0x100) -
                                        (uint64_t)puVar4[2]) + 0x17ffff, puVar4[3] + 1);
                    puVar6 = puVar4 + 4;
                }
            } else if (uVar1 < 0x80) {
                if (uVar1 < 0x40) {
                    func_0x0001801310b0(puVar4 + 1, uVar1 - 0x1f);
                    puVar6 = puVar4 + ((uint64_t)*puVar4 - 0x1e);
                } else {
                    func_0x000180131050(((*(uint64_t *)0x1807823c0 + (uint64_t)uVar1 * -0x100) - (uint64_t)puVar4[1]) +
                                        0x3fff, puVar4[2] + 1);
                    puVar6 = puVar4 + 3;
                }
            } else {
                func_0x000180131050((*(uint64_t *)0x1807823c0 - puVar4[1]) + -1, uVar1 - 0x7f);
                puVar6 = puVar4 + 2;
            }
        } while ((puVar6 != puVar4) && (puVar4 = puVar6, *(uint64_t *)0x1807823c0 <= uVar5));
    }
    if (in_stack_00000028 == (undefined4 *)0x0) {
        func_0x0001804986e0(&var_128h, 0, 0xa0);
        auVar2 = _var_f8h;
        uVar8 = var_f8h;
        auVar3._11_5_ = 0;
        auVar3._0_11_ = stack0xffffffffffffff0d;
        _var_f8h = auVar3 << 0x28;
        auVar3 = _var_f8h;
        uStack_ec = auVar2._12_4_;
        uVar9 = uStack_ec;
        _var_f8h = auVar3._0_10_;
        var_f4h._6_2_ = 0;
        _var_f8h = (unkuint9)0;
        auVar2 = _var_f8h;
        var_f4h._0_4_ = (uint32_t)auVar3._4_3_;
        var_f4h._4_4_ = auVar2._8_4_;
        uStack_cc = 0x7f7fffff;
        uStack_bc = 0x3f800000;
        auStack_b8._0_4_ = 0x3f800000;
        auStack_b8._4_4_ = 0x3f800000;
    } else {
        var_128h._0_4_ = *in_stack_00000028;
        var_128h._4_4_ = in_stack_00000028[1];
        uStack_120 = in_stack_00000028[2];
        uStack_11c = in_stack_00000028[3];
        var_118h._0_4_ = in_stack_00000028[4];
        var_118h._4_4_ = in_stack_00000028[5];
        uStack_110 = in_stack_00000028[6];
        uStack_10c = in_stack_00000028[7];
        var_108h._0_4_ = in_stack_00000028[8];
        var_108h._4_4_ = in_stack_00000028[9];
        uStack_100 = in_stack_00000028[10];
        uStack_fc = in_stack_00000028[0xb];
        uVar8 = in_stack_00000028[0xc];
        var_f4h._0_4_ = in_stack_00000028[0xd];
        var_f4h._4_4_ = in_stack_00000028[0xe];
        uVar9 = in_stack_00000028[0xf];
        var_e8h._0_4_ = in_stack_00000028[0x10];
        var_e8h._4_4_ = in_stack_00000028[0x11];
        uStack_e0 = in_stack_00000028[0x12];
        uStack_dc = in_stack_00000028[0x13];
        auStack_d8._0_4_ = in_stack_00000028[0x14];
        auStack_d8._4_4_ = in_stack_00000028[0x15];
        uStack_d0 = in_stack_00000028[0x16];
        uStack_cc = in_stack_00000028[0x17];
        auStack_c8._0_4_ = in_stack_00000028[0x18];
        auStack_c8._4_4_ = in_stack_00000028[0x19];
        uStack_c0 = in_stack_00000028[0x1a];
        uStack_bc = in_stack_00000028[0x1b];
        auStack_b8._0_4_ = in_stack_00000028[0x1c];
        auStack_b8._4_4_ = in_stack_00000028[0x1d];
        uStack_b0._0_4_ = in_stack_00000028[0x1e];
        uStack_b0._4_4_ = in_stack_00000028[0x1f];
        auStack_a8._0_4_ = in_stack_00000028[0x20];
        auStack_a8._4_4_ = in_stack_00000028[0x21];
        uStack_a0 = in_stack_00000028[0x22];
        uStack_9c = in_stack_00000028[0x23];
        auStack_98._0_4_ = in_stack_00000028[0x24];
        auStack_98._4_4_ = in_stack_00000028[0x25];
        uStack_90 = in_stack_00000028[0x26];
        uStack_8c = in_stack_00000028[0x27];
    }
    auVar2._4_4_ = (uint32_t)var_f4h;
    auVar2._0_4_ = uVar8;
    auVar2._8_4_ = var_f4h._4_4_;
    auVar2._12_4_ = uVar9;
    stack0xffffffffffffff0d = auVar2._5_11_;
    var_f4h._0_1_ = 1;
    var_f8h = (undefined  [4])uVar8;
    fcn.1801279b0(arg1, arg2_00, (uint64_t)uVar7, in_R9, (int64_t)&var_128h);
    return;
}

// ============================================================
// Function: FUN_180127ee3
// Address: 0x180127ee3
// Size: 132 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_138h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_eeh
// WARNING: [rz-ghidra] Detected overlap for variable var_f1h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_131h
// WARNING: [rz-ghidra] Detected overlap for variable var_12eh
// WARNING: [rz-ghidra] Detected overlap for variable var_138h
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Detected overlap for variable var_133h

void fcn.180127ea0(int64_t arg1, int64_t arg2, int64_t arg_80h)
{
    uint8_t uVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    uint64_t arg2_00;
    uint8_t *puVar4;
    uint64_t uVar5;
    undefined8 in_R9;
    uint8_t *puVar6;
    uint32_t uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 *in_stack_00000028;
    int64_t var_138h;
    int64_t var_128h;
    undefined4 uStack_120;
    undefined4 uStack_11c;
    int64_t var_118h;
    undefined4 uStack_110;
    undefined4 uStack_10c;
    int64_t var_108h;
    undefined4 uStack_100;
    undefined4 uStack_fc;
    undefined var_f8h [4];
    int64_t var_f4h;
    undefined4 uStack_ec;
    undefined var_e8h [8];
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    undefined auStack_d8 [8];
    undefined4 uStack_d0;
    undefined4 uStack_cc;
    undefined auStack_c8 [8];
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    undefined auStack_b8 [8];
    undefined8 uStack_b0;
    undefined auStack_a8 [8];
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    undefined auStack_98 [8];
    undefined4 uStack_90;
    undefined4 uStack_8c;
    int64_t var_80h;
    int64_t var_74h;
    int64_t var_64h;
    int64_t var_5ch;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    uVar7 = (uint32_t)*(uint8_t *)(arg2 + 10) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 9) * 0x10000 +
            (uint32_t)*(uint8_t *)(arg2 + 8) * 0x1000000 + (uint32_t)*(uint8_t *)(arg2 + 0xb);
    arg2_00 = fcn.18046d050(uVar7);
    if (((((uint32_t)*(uint8_t *)arg2 * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 1)) * 0x100 +
         (uint32_t)*(uint8_t *)(arg2 + 2)) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 3) == 0x57bc0000) &&
       ((((uint32_t)*(uint8_t *)(arg2 + 4) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 5)) * 0x100 +
        (uint32_t)*(uint8_t *)(arg2 + 6)) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 7) == 0)) {
        uVar5 = ((uint32_t)*(uint8_t *)(arg2 + 10) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 9) * 0x10000 +
                 (uint32_t)*(uint8_t *)(arg2 + 8) * 0x1000000 + (uint32_t)*(uint8_t *)(arg2 + 0xb)) + arg2_00;
        puVar4 = (uint8_t *)(arg2 + 0x10);
        *(int64_t *)0x180782380 = arg2;
        *(uint64_t *)0x180782390 = uVar5;
        *(uint64_t *)0x180782398 = arg2_00;
        *(uint64_t *)0x1807823c0 = arg2_00;
        do {
            uVar1 = *puVar4;
            if (uVar1 < 0x20) {
                if (uVar1 < 0x18) {
                    if (uVar1 < 0x10) {
                        if (uVar1 < 8) {
                            if (uVar1 == 7) {
                                func_0x0001801310b0(puVar4 + 3, (uint32_t)puVar4[2] + (uint32_t)puVar4[1] * 0x100 + 1);
                                puVar6 = puVar4 + (uint64_t)puVar4[2] + (uint64_t)puVar4[1] * 0x100 + 4;
                            } else if (uVar1 == 6) {
                                func_0x000180131050(((*(uint64_t *)0x1807823c0 +
                                                     (uint64_t)CONCAT11(puVar4[1], puVar4[2]) * -0x100) -
                                                    (uint64_t)puVar4[3]) + -1, puVar4[4] + 1);
                                puVar6 = puVar4 + 5;
                            } else {
                                puVar6 = puVar4;
                                if (uVar1 == 4) {
                                    func_0x000180131050(((*(uint64_t *)0x1807823c0 +
                                                         (uint64_t)CONCAT11(puVar4[1], puVar4[2]) * -0x100) -
                                                        (uint64_t)puVar4[3]) + -1, 
                                                        (uint32_t)puVar4[5] + (uint32_t)puVar4[4] * 0x100 + 1);
                                    puVar6 = puVar4 + 6;
                                }
                            }
                        } else {
                            func_0x0001801310b0(puVar4 + 2, (uint32_t)puVar4[1] + (uint32_t)uVar1 * 0x100 + -0x7ff);
                            puVar6 = puVar4 + (uint64_t)puVar4[1] + (uint64_t)*puVar4 * 0x100 + -0x7fd;
                        }
                    } else {
                        func_0x000180131050(((*(uint64_t *)0x1807823c0 + (uint64_t)CONCAT11(uVar1, puVar4[1]) * -0x100)
                                            - (uint64_t)puVar4[2]) + 0xfffff, 
                                            (uint32_t)puVar4[4] + (uint32_t)puVar4[3] * 0x100 + 1);
                        puVar6 = puVar4 + 5;
                    }
                } else {
                    func_0x000180131050(((*(uint64_t *)0x1807823c0 + (uint64_t)CONCAT11(uVar1, puVar4[1]) * -0x100) -
                                        (uint64_t)puVar4[2]) + 0x17ffff, puVar4[3] + 1);
                    puVar6 = puVar4 + 4;
                }
            } else if (uVar1 < 0x80) {
                if (uVar1 < 0x40) {
                    func_0x0001801310b0(puVar4 + 1, uVar1 - 0x1f);
                    puVar6 = puVar4 + ((uint64_t)*puVar4 - 0x1e);
                } else {
                    func_0x000180131050(((*(uint64_t *)0x1807823c0 + (uint64_t)uVar1 * -0x100) - (uint64_t)puVar4[1]) +
                                        0x3fff, puVar4[2] + 1);
                    puVar6 = puVar4 + 3;
                }
            } else {
                func_0x000180131050((*(uint64_t *)0x1807823c0 - puVar4[1]) + -1, uVar1 - 0x7f);
                puVar6 = puVar4 + 2;
            }
        } while ((puVar6 != puVar4) && (puVar4 = puVar6, *(uint64_t *)0x1807823c0 <= uVar5));
    }
    if (in_stack_00000028 == (undefined4 *)0x0) {
        func_0x0001804986e0(&var_128h, 0, 0xa0);
        auVar2 = _var_f8h;
        uVar8 = var_f8h;
        auVar3._11_5_ = 0;
        auVar3._0_11_ = stack0xffffffffffffff0d;
        _var_f8h = auVar3 << 0x28;
        auVar3 = _var_f8h;
        uStack_ec = auVar2._12_4_;
        uVar9 = uStack_ec;
        _var_f8h = auVar3._0_10_;
        var_f4h._6_2_ = 0;
        _var_f8h = (unkuint9)0;
        auVar2 = _var_f8h;
        var_f4h._0_4_ = (uint32_t)auVar3._4_3_;
        var_f4h._4_4_ = auVar2._8_4_;
        uStack_cc = 0x7f7fffff;
        uStack_bc = 0x3f800000;
        auStack_b8._0_4_ = 0x3f800000;
        auStack_b8._4_4_ = 0x3f800000;
    } else {
        var_128h._0_4_ = *in_stack_00000028;
        var_128h._4_4_ = in_stack_00000028[1];
        uStack_120 = in_stack_00000028[2];
        uStack_11c = in_stack_00000028[3];
        var_118h._0_4_ = in_stack_00000028[4];
        var_118h._4_4_ = in_stack_00000028[5];
        uStack_110 = in_stack_00000028[6];
        uStack_10c = in_stack_00000028[7];
        var_108h._0_4_ = in_stack_00000028[8];
        var_108h._4_4_ = in_stack_00000028[9];
        uStack_100 = in_stack_00000028[10];
        uStack_fc = in_stack_00000028[0xb];
        uVar8 = in_stack_00000028[0xc];
        var_f4h._0_4_ = in_stack_00000028[0xd];
        var_f4h._4_4_ = in_stack_00000028[0xe];
        uVar9 = in_stack_00000028[0xf];
        var_e8h._0_4_ = in_stack_00000028[0x10];
        var_e8h._4_4_ = in_stack_00000028[0x11];
        uStack_e0 = in_stack_00000028[0x12];
        uStack_dc = in_stack_00000028[0x13];
        auStack_d8._0_4_ = in_stack_00000028[0x14];
        auStack_d8._4_4_ = in_stack_00000028[0x15];
        uStack_d0 = in_stack_00000028[0x16];
        uStack_cc = in_stack_00000028[0x17];
        auStack_c8._0_4_ = in_stack_00000028[0x18];
        auStack_c8._4_4_ = in_stack_00000028[0x19];
        uStack_c0 = in_stack_00000028[0x1a];
        uStack_bc = in_stack_00000028[0x1b];
        auStack_b8._0_4_ = in_stack_00000028[0x1c];
        auStack_b8._4_4_ = in_stack_00000028[0x1d];
        uStack_b0._0_4_ = in_stack_00000028[0x1e];
        uStack_b0._4_4_ = in_stack_00000028[0x1f];
        auStack_a8._0_4_ = in_stack_00000028[0x20];
        auStack_a8._4_4_ = in_stack_00000028[0x21];
        uStack_a0 = in_stack_00000028[0x22];
        uStack_9c = in_stack_00000028[0x23];
        auStack_98._0_4_ = in_stack_00000028[0x24];
        auStack_98._4_4_ = in_stack_00000028[0x25];
        uStack_90 = in_stack_00000028[0x26];
        uStack_8c = in_stack_00000028[0x27];
    }
    auVar2._4_4_ = (uint32_t)var_f4h;
    auVar2._0_4_ = uVar8;
    auVar2._8_4_ = var_f4h._4_4_;
    auVar2._12_4_ = uVar9;
    stack0xffffffffffffff0d = auVar2._5_11_;
    var_f4h._0_1_ = 1;
    var_f8h = (undefined  [4])uVar8;
    fcn.1801279b0(arg1, arg2_00, (uint64_t)uVar7, in_R9, (int64_t)&var_128h);
    return;
}

// ============================================================
// Function: FUN_180127f67
// Address: 0x180127f67
// Size: 639 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_138h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_eeh
// WARNING: [rz-ghidra] Detected overlap for variable var_f1h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_131h
// WARNING: [rz-ghidra] Detected overlap for variable var_12eh
// WARNING: [rz-ghidra] Detected overlap for variable var_138h
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Detected overlap for variable var_133h

void fcn.180127ea0(int64_t arg1, int64_t arg2, int64_t arg_80h)
{
    uint8_t uVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    uint64_t arg2_00;
    uint8_t *puVar4;
    uint64_t uVar5;
    undefined8 in_R9;
    uint8_t *puVar6;
    uint32_t uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 *in_stack_00000028;
    int64_t var_138h;
    int64_t var_128h;
    undefined4 uStack_120;
    undefined4 uStack_11c;
    int64_t var_118h;
    undefined4 uStack_110;
    undefined4 uStack_10c;
    int64_t var_108h;
    undefined4 uStack_100;
    undefined4 uStack_fc;
    undefined var_f8h [4];
    int64_t var_f4h;
    undefined4 uStack_ec;
    undefined var_e8h [8];
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    undefined auStack_d8 [8];
    undefined4 uStack_d0;
    undefined4 uStack_cc;
    undefined auStack_c8 [8];
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    undefined auStack_b8 [8];
    undefined8 uStack_b0;
    undefined auStack_a8 [8];
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    undefined auStack_98 [8];
    undefined4 uStack_90;
    undefined4 uStack_8c;
    int64_t var_80h;
    int64_t var_74h;
    int64_t var_64h;
    int64_t var_5ch;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    uVar7 = (uint32_t)*(uint8_t *)(arg2 + 10) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 9) * 0x10000 +
            (uint32_t)*(uint8_t *)(arg2 + 8) * 0x1000000 + (uint32_t)*(uint8_t *)(arg2 + 0xb);
    arg2_00 = fcn.18046d050(uVar7);
    if (((((uint32_t)*(uint8_t *)arg2 * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 1)) * 0x100 +
         (uint32_t)*(uint8_t *)(arg2 + 2)) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 3) == 0x57bc0000) &&
       ((((uint32_t)*(uint8_t *)(arg2 + 4) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 5)) * 0x100 +
        (uint32_t)*(uint8_t *)(arg2 + 6)) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 7) == 0)) {
        uVar5 = ((uint32_t)*(uint8_t *)(arg2 + 10) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 9) * 0x10000 +
                 (uint32_t)*(uint8_t *)(arg2 + 8) * 0x1000000 + (uint32_t)*(uint8_t *)(arg2 + 0xb)) + arg2_00;
        puVar4 = (uint8_t *)(arg2 + 0x10);
        *(int64_t *)0x180782380 = arg2;
        *(uint64_t *)0x180782390 = uVar5;
        *(uint64_t *)0x180782398 = arg2_00;
        *(uint64_t *)0x1807823c0 = arg2_00;
        do {
            uVar1 = *puVar4;
            if (uVar1 < 0x20) {
                if (uVar1 < 0x18) {
                    if (uVar1 < 0x10) {
                        if (uVar1 < 8) {
                            if (uVar1 == 7) {
                                func_0x0001801310b0(puVar4 + 3, (uint32_t)puVar4[2] + (uint32_t)puVar4[1] * 0x100 + 1);
                                puVar6 = puVar4 + (uint64_t)puVar4[2] + (uint64_t)puVar4[1] * 0x100 + 4;
                            } else if (uVar1 == 6) {
                                func_0x000180131050(((*(uint64_t *)0x1807823c0 +
                                                     (uint64_t)CONCAT11(puVar4[1], puVar4[2]) * -0x100) -
                                                    (uint64_t)puVar4[3]) + -1, puVar4[4] + 1);
                                puVar6 = puVar4 + 5;
                            } else {
                                puVar6 = puVar4;
                                if (uVar1 == 4) {
                                    func_0x000180131050(((*(uint64_t *)0x1807823c0 +
                                                         (uint64_t)CONCAT11(puVar4[1], puVar4[2]) * -0x100) -
                                                        (uint64_t)puVar4[3]) + -1, 
                                                        (uint32_t)puVar4[5] + (uint32_t)puVar4[4] * 0x100 + 1);
                                    puVar6 = puVar4 + 6;
                                }
                            }
                        } else {
                            func_0x0001801310b0(puVar4 + 2, (uint32_t)puVar4[1] + (uint32_t)uVar1 * 0x100 + -0x7ff);
                            puVar6 = puVar4 + (uint64_t)puVar4[1] + (uint64_t)*puVar4 * 0x100 + -0x7fd;
                        }
                    } else {
                        func_0x000180131050(((*(uint64_t *)0x1807823c0 + (uint64_t)CONCAT11(uVar1, puVar4[1]) * -0x100)
                                            - (uint64_t)puVar4[2]) + 0xfffff, 
                                            (uint32_t)puVar4[4] + (uint32_t)puVar4[3] * 0x100 + 1);
                        puVar6 = puVar4 + 5;
                    }
                } else {
                    func_0x000180131050(((*(uint64_t *)0x1807823c0 + (uint64_t)CONCAT11(uVar1, puVar4[1]) * -0x100) -
                                        (uint64_t)puVar4[2]) + 0x17ffff, puVar4[3] + 1);
                    puVar6 = puVar4 + 4;
                }
            } else if (uVar1 < 0x80) {
                if (uVar1 < 0x40) {
                    func_0x0001801310b0(puVar4 + 1, uVar1 - 0x1f);
                    puVar6 = puVar4 + ((uint64_t)*puVar4 - 0x1e);
                } else {
                    func_0x000180131050(((*(uint64_t *)0x1807823c0 + (uint64_t)uVar1 * -0x100) - (uint64_t)puVar4[1]) +
                                        0x3fff, puVar4[2] + 1);
                    puVar6 = puVar4 + 3;
                }
            } else {
                func_0x000180131050((*(uint64_t *)0x1807823c0 - puVar4[1]) + -1, uVar1 - 0x7f);
                puVar6 = puVar4 + 2;
            }
        } while ((puVar6 != puVar4) && (puVar4 = puVar6, *(uint64_t *)0x1807823c0 <= uVar5));
    }
    if (in_stack_00000028 == (undefined4 *)0x0) {
        func_0x0001804986e0(&var_128h, 0, 0xa0);
        auVar2 = _var_f8h;
        uVar8 = var_f8h;
        auVar3._11_5_ = 0;
        auVar3._0_11_ = stack0xffffffffffffff0d;
        _var_f8h = auVar3 << 0x28;
        auVar3 = _var_f8h;
        uStack_ec = auVar2._12_4_;
        uVar9 = uStack_ec;
        _var_f8h = auVar3._0_10_;
        var_f4h._6_2_ = 0;
        _var_f8h = (unkuint9)0;
        auVar2 = _var_f8h;
        var_f4h._0_4_ = (uint32_t)auVar3._4_3_;
        var_f4h._4_4_ = auVar2._8_4_;
        uStack_cc = 0x7f7fffff;
        uStack_bc = 0x3f800000;
        auStack_b8._0_4_ = 0x3f800000;
        auStack_b8._4_4_ = 0x3f800000;
    } else {
        var_128h._0_4_ = *in_stack_00000028;
        var_128h._4_4_ = in_stack_00000028[1];
        uStack_120 = in_stack_00000028[2];
        uStack_11c = in_stack_00000028[3];
        var_118h._0_4_ = in_stack_00000028[4];
        var_118h._4_4_ = in_stack_00000028[5];
        uStack_110 = in_stack_00000028[6];
        uStack_10c = in_stack_00000028[7];
        var_108h._0_4_ = in_stack_00000028[8];
        var_108h._4_4_ = in_stack_00000028[9];
        uStack_100 = in_stack_00000028[10];
        uStack_fc = in_stack_00000028[0xb];
        uVar8 = in_stack_00000028[0xc];
        var_f4h._0_4_ = in_stack_00000028[0xd];
        var_f4h._4_4_ = in_stack_00000028[0xe];
        uVar9 = in_stack_00000028[0xf];
        var_e8h._0_4_ = in_stack_00000028[0x10];
        var_e8h._4_4_ = in_stack_00000028[0x11];
        uStack_e0 = in_stack_00000028[0x12];
        uStack_dc = in_stack_00000028[0x13];
        auStack_d8._0_4_ = in_stack_00000028[0x14];
        auStack_d8._4_4_ = in_stack_00000028[0x15];
        uStack_d0 = in_stack_00000028[0x16];
        uStack_cc = in_stack_00000028[0x17];
        auStack_c8._0_4_ = in_stack_00000028[0x18];
        auStack_c8._4_4_ = in_stack_00000028[0x19];
        uStack_c0 = in_stack_00000028[0x1a];
        uStack_bc = in_stack_00000028[0x1b];
        auStack_b8._0_4_ = in_stack_00000028[0x1c];
        auStack_b8._4_4_ = in_stack_00000028[0x1d];
        uStack_b0._0_4_ = in_stack_00000028[0x1e];
        uStack_b0._4_4_ = in_stack_00000028[0x1f];
        auStack_a8._0_4_ = in_stack_00000028[0x20];
        auStack_a8._4_4_ = in_stack_00000028[0x21];
        uStack_a0 = in_stack_00000028[0x22];
        uStack_9c = in_stack_00000028[0x23];
        auStack_98._0_4_ = in_stack_00000028[0x24];
        auStack_98._4_4_ = in_stack_00000028[0x25];
        uStack_90 = in_stack_00000028[0x26];
        uStack_8c = in_stack_00000028[0x27];
    }
    auVar2._4_4_ = (uint32_t)var_f4h;
    auVar2._0_4_ = uVar8;
    auVar2._8_4_ = var_f4h._4_4_;
    auVar2._12_4_ = uVar9;
    stack0xffffffffffffff0d = auVar2._5_11_;
    var_f4h._0_1_ = 1;
    var_f8h = (undefined  [4])uVar8;
    fcn.1801279b0(arg1, arg2_00, (uint64_t)uVar7, in_R9, (int64_t)&var_128h);
    return;
}

// ============================================================
// Function: FUN_1801281e6
// Address: 0x1801281e6
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_138h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_eeh
// WARNING: [rz-ghidra] Detected overlap for variable var_f1h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_131h
// WARNING: [rz-ghidra] Detected overlap for variable var_12eh
// WARNING: [rz-ghidra] Detected overlap for variable var_138h
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Detected overlap for variable var_133h

void fcn.180127ea0(int64_t arg1, int64_t arg2, int64_t arg_80h)
{
    uint8_t uVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    uint64_t arg2_00;
    uint8_t *puVar4;
    uint64_t uVar5;
    undefined8 in_R9;
    uint8_t *puVar6;
    uint32_t uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 *in_stack_00000028;
    int64_t var_138h;
    int64_t var_128h;
    undefined4 uStack_120;
    undefined4 uStack_11c;
    int64_t var_118h;
    undefined4 uStack_110;
    undefined4 uStack_10c;
    int64_t var_108h;
    undefined4 uStack_100;
    undefined4 uStack_fc;
    undefined var_f8h [4];
    int64_t var_f4h;
    undefined4 uStack_ec;
    undefined var_e8h [8];
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    undefined auStack_d8 [8];
    undefined4 uStack_d0;
    undefined4 uStack_cc;
    undefined auStack_c8 [8];
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    undefined auStack_b8 [8];
    undefined8 uStack_b0;
    undefined auStack_a8 [8];
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    undefined auStack_98 [8];
    undefined4 uStack_90;
    undefined4 uStack_8c;
    int64_t var_80h;
    int64_t var_74h;
    int64_t var_64h;
    int64_t var_5ch;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    uVar7 = (uint32_t)*(uint8_t *)(arg2 + 10) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 9) * 0x10000 +
            (uint32_t)*(uint8_t *)(arg2 + 8) * 0x1000000 + (uint32_t)*(uint8_t *)(arg2 + 0xb);
    arg2_00 = fcn.18046d050(uVar7);
    if (((((uint32_t)*(uint8_t *)arg2 * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 1)) * 0x100 +
         (uint32_t)*(uint8_t *)(arg2 + 2)) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 3) == 0x57bc0000) &&
       ((((uint32_t)*(uint8_t *)(arg2 + 4) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 5)) * 0x100 +
        (uint32_t)*(uint8_t *)(arg2 + 6)) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 7) == 0)) {
        uVar5 = ((uint32_t)*(uint8_t *)(arg2 + 10) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 9) * 0x10000 +
                 (uint32_t)*(uint8_t *)(arg2 + 8) * 0x1000000 + (uint32_t)*(uint8_t *)(arg2 + 0xb)) + arg2_00;
        puVar4 = (uint8_t *)(arg2 + 0x10);
        *(int64_t *)0x180782380 = arg2;
        *(uint64_t *)0x180782390 = uVar5;
        *(uint64_t *)0x180782398 = arg2_00;
        *(uint64_t *)0x1807823c0 = arg2_00;
        do {
            uVar1 = *puVar4;
            if (uVar1 < 0x20) {
                if (uVar1 < 0x18) {
                    if (uVar1 < 0x10) {
                        if (uVar1 < 8) {
                            if (uVar1 == 7) {
                                func_0x0001801310b0(puVar4 + 3, (uint32_t)puVar4[2] + (uint32_t)puVar4[1] * 0x100 + 1);
                                puVar6 = puVar4 + (uint64_t)puVar4[2] + (uint64_t)puVar4[1] * 0x100 + 4;
                            } else if (uVar1 == 6) {
                                func_0x000180131050(((*(uint64_t *)0x1807823c0 +
                                                     (uint64_t)CONCAT11(puVar4[1], puVar4[2]) * -0x100) -
                                                    (uint64_t)puVar4[3]) + -1, puVar4[4] + 1);
                                puVar6 = puVar4 + 5;
                            } else {
                                puVar6 = puVar4;
                                if (uVar1 == 4) {
                                    func_0x000180131050(((*(uint64_t *)0x1807823c0 +
                                                         (uint64_t)CONCAT11(puVar4[1], puVar4[2]) * -0x100) -
                                                        (uint64_t)puVar4[3]) + -1, 
                                                        (uint32_t)puVar4[5] + (uint32_t)puVar4[4] * 0x100 + 1);
                                    puVar6 = puVar4 + 6;
                                }
                            }
                        } else {
                            func_0x0001801310b0(puVar4 + 2, (uint32_t)puVar4[1] + (uint32_t)uVar1 * 0x100 + -0x7ff);
                            puVar6 = puVar4 + (uint64_t)puVar4[1] + (uint64_t)*puVar4 * 0x100 + -0x7fd;
                        }
                    } else {
                        func_0x000180131050(((*(uint64_t *)0x1807823c0 + (uint64_t)CONCAT11(uVar1, puVar4[1]) * -0x100)
                                            - (uint64_t)puVar4[2]) + 0xfffff, 
                                            (uint32_t)puVar4[4] + (uint32_t)puVar4[3] * 0x100 + 1);
                        puVar6 = puVar4 + 5;
                    }
                } else {
                    func_0x000180131050(((*(uint64_t *)0x1807823c0 + (uint64_t)CONCAT11(uVar1, puVar4[1]) * -0x100) -
                                        (uint64_t)puVar4[2]) + 0x17ffff, puVar4[3] + 1);
                    puVar6 = puVar4 + 4;
                }
            } else if (uVar1 < 0x80) {
                if (uVar1 < 0x40) {
                    func_0x0001801310b0(puVar4 + 1, uVar1 - 0x1f);
                    puVar6 = puVar4 + ((uint64_t)*puVar4 - 0x1e);
                } else {
                    func_0x000180131050(((*(uint64_t *)0x1807823c0 + (uint64_t)uVar1 * -0x100) - (uint64_t)puVar4[1]) +
                                        0x3fff, puVar4[2] + 1);
                    puVar6 = puVar4 + 3;
                }
            } else {
                func_0x000180131050((*(uint64_t *)0x1807823c0 - puVar4[1]) + -1, uVar1 - 0x7f);
                puVar6 = puVar4 + 2;
            }
        } while ((puVar6 != puVar4) && (puVar4 = puVar6, *(uint64_t *)0x1807823c0 <= uVar5));
    }
    if (in_stack_00000028 == (undefined4 *)0x0) {
        func_0x0001804986e0(&var_128h, 0, 0xa0);
        auVar2 = _var_f8h;
        uVar8 = var_f8h;
        auVar3._11_5_ = 0;
        auVar3._0_11_ = stack0xffffffffffffff0d;
        _var_f8h = auVar3 << 0x28;
        auVar3 = _var_f8h;
        uStack_ec = auVar2._12_4_;
        uVar9 = uStack_ec;
        _var_f8h = auVar3._0_10_;
        var_f4h._6_2_ = 0;
        _var_f8h = (unkuint9)0;
        auVar2 = _var_f8h;
        var_f4h._0_4_ = (uint32_t)auVar3._4_3_;
        var_f4h._4_4_ = auVar2._8_4_;
        uStack_cc = 0x7f7fffff;
        uStack_bc = 0x3f800000;
        auStack_b8._0_4_ = 0x3f800000;
        auStack_b8._4_4_ = 0x3f800000;
    } else {
        var_128h._0_4_ = *in_stack_00000028;
        var_128h._4_4_ = in_stack_00000028[1];
        uStack_120 = in_stack_00000028[2];
        uStack_11c = in_stack_00000028[3];
        var_118h._0_4_ = in_stack_00000028[4];
        var_118h._4_4_ = in_stack_00000028[5];
        uStack_110 = in_stack_00000028[6];
        uStack_10c = in_stack_00000028[7];
        var_108h._0_4_ = in_stack_00000028[8];
        var_108h._4_4_ = in_stack_00000028[9];
        uStack_100 = in_stack_00000028[10];
        uStack_fc = in_stack_00000028[0xb];
        uVar8 = in_stack_00000028[0xc];
        var_f4h._0_4_ = in_stack_00000028[0xd];
        var_f4h._4_4_ = in_stack_00000028[0xe];
        uVar9 = in_stack_00000028[0xf];
        var_e8h._0_4_ = in_stack_00000028[0x10];
        var_e8h._4_4_ = in_stack_00000028[0x11];
        uStack_e0 = in_stack_00000028[0x12];
        uStack_dc = in_stack_00000028[0x13];
        auStack_d8._0_4_ = in_stack_00000028[0x14];
        auStack_d8._4_4_ = in_stack_00000028[0x15];
        uStack_d0 = in_stack_00000028[0x16];
        uStack_cc = in_stack_00000028[0x17];
        auStack_c8._0_4_ = in_stack_00000028[0x18];
        auStack_c8._4_4_ = in_stack_00000028[0x19];
        uStack_c0 = in_stack_00000028[0x1a];
        uStack_bc = in_stack_00000028[0x1b];
        auStack_b8._0_4_ = in_stack_00000028[0x1c];
        auStack_b8._4_4_ = in_stack_00000028[0x1d];
        uStack_b0._0_4_ = in_stack_00000028[0x1e];
        uStack_b0._4_4_ = in_stack_00000028[0x1f];
        auStack_a8._0_4_ = in_stack_00000028[0x20];
        auStack_a8._4_4_ = in_stack_00000028[0x21];
        uStack_a0 = in_stack_00000028[0x22];
        uStack_9c = in_stack_00000028[0x23];
        auStack_98._0_4_ = in_stack_00000028[0x24];
        auStack_98._4_4_ = in_stack_00000028[0x25];
        uStack_90 = in_stack_00000028[0x26];
        uStack_8c = in_stack_00000028[0x27];
    }
    auVar2._4_4_ = (uint32_t)var_f4h;
    auVar2._0_4_ = uVar8;
    auVar2._8_4_ = var_f4h._4_4_;
    auVar2._12_4_ = uVar9;
    stack0xffffffffffffff0d = auVar2._5_11_;
    var_f4h._0_1_ = 1;
    var_f8h = (undefined  [4])uVar8;
    fcn.1801279b0(arg1, arg2_00, (uint64_t)uVar7, in_R9, (int64_t)&var_128h);
    return;
}

// ============================================================
// Function: FUN_1801281f3
// Address: 0x1801281f3
// Size: 286 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_138h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_eeh
// WARNING: [rz-ghidra] Detected overlap for variable var_f1h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_131h
// WARNING: [rz-ghidra] Detected overlap for variable var_12eh
// WARNING: [rz-ghidra] Detected overlap for variable var_138h
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Detected overlap for variable var_133h

void fcn.180127ea0(int64_t arg1, int64_t arg2, int64_t arg_80h)
{
    uint8_t uVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    uint64_t arg2_00;
    uint8_t *puVar4;
    uint64_t uVar5;
    undefined8 in_R9;
    uint8_t *puVar6;
    uint32_t uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 *in_stack_00000028;
    int64_t var_138h;
    int64_t var_128h;
    undefined4 uStack_120;
    undefined4 uStack_11c;
    int64_t var_118h;
    undefined4 uStack_110;
    undefined4 uStack_10c;
    int64_t var_108h;
    undefined4 uStack_100;
    undefined4 uStack_fc;
    undefined var_f8h [4];
    int64_t var_f4h;
    undefined4 uStack_ec;
    undefined var_e8h [8];
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    undefined auStack_d8 [8];
    undefined4 uStack_d0;
    undefined4 uStack_cc;
    undefined auStack_c8 [8];
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    undefined auStack_b8 [8];
    undefined8 uStack_b0;
    undefined auStack_a8 [8];
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    undefined auStack_98 [8];
    undefined4 uStack_90;
    undefined4 uStack_8c;
    int64_t var_80h;
    int64_t var_74h;
    int64_t var_64h;
    int64_t var_5ch;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    uVar7 = (uint32_t)*(uint8_t *)(arg2 + 10) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 9) * 0x10000 +
            (uint32_t)*(uint8_t *)(arg2 + 8) * 0x1000000 + (uint32_t)*(uint8_t *)(arg2 + 0xb);
    arg2_00 = fcn.18046d050(uVar7);
    if (((((uint32_t)*(uint8_t *)arg2 * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 1)) * 0x100 +
         (uint32_t)*(uint8_t *)(arg2 + 2)) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 3) == 0x57bc0000) &&
       ((((uint32_t)*(uint8_t *)(arg2 + 4) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 5)) * 0x100 +
        (uint32_t)*(uint8_t *)(arg2 + 6)) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 7) == 0)) {
        uVar5 = ((uint32_t)*(uint8_t *)(arg2 + 10) * 0x100 + (uint32_t)*(uint8_t *)(arg2 + 9) * 0x10000 +
                 (uint32_t)*(uint8_t *)(arg2 + 8) * 0x1000000 + (uint32_t)*(uint8_t *)(arg2 + 0xb)) + arg2_00;
        puVar4 = (uint8_t *)(arg2 + 0x10);
        *(int64_t *)0x180782380 = arg2;
        *(uint64_t *)0x180782390 = uVar5;
        *(uint64_t *)0x180782398 = arg2_00;
        *(uint64_t *)0x1807823c0 = arg2_00;
        do {
            uVar1 = *puVar4;
            if (uVar1 < 0x20) {
                if (uVar1 < 0x18) {
                    if (uVar1 < 0x10) {
                        if (uVar1 < 8) {
                            if (uVar1 == 7) {
                                func_0x0001801310b0(puVar4 + 3, (uint32_t)puVar4[2] + (uint32_t)puVar4[1] * 0x100 + 1);
                                puVar6 = puVar4 + (uint64_t)puVar4[2] + (uint64_t)puVar4[1] * 0x100 + 4;
                            } else if (uVar1 == 6) {
                                func_0x000180131050(((*(uint64_t *)0x1807823c0 +
                                                     (uint64_t)CONCAT11(puVar4[1], puVar4[2]) * -0x100) -
                                                    (uint64_t)puVar4[3]) + -1, puVar4[4] + 1);
                                puVar6 = puVar4 + 5;
                            } else {
                                puVar6 = puVar4;
                                if (uVar1 == 4) {
                                    func_0x000180131050(((*(uint64_t *)0x1807823c0 +
                                                         (uint64_t)CONCAT11(puVar4[1], puVar4[2]) * -0x100) -
                                                        (uint64_t)puVar4[3]) + -1, 
                                                        (uint32_t)puVar4[5] + (uint32_t)puVar4[4] * 0x100 + 1);
                                    puVar6 = puVar4 + 6;
                                }
                            }
                        } else {
                            func_0x0001801310b0(puVar4 + 2, (uint32_t)puVar4[1] + (uint32_t)uVar1 * 0x100 + -0x7ff);
                            puVar6 = puVar4 + (uint64_t)puVar4[1] + (uint64_t)*puVar4 * 0x100 + -0x7fd;
                        }
                    } else {
                        func_0x000180131050(((*(uint64_t *)0x1807823c0 + (uint64_t)CONCAT11(uVar1, puVar4[1]) * -0x100)
                                            - (uint64_t)puVar4[2]) + 0xfffff, 
                                            (uint32_t)puVar4[4] + (uint32_t)puVar4[3] * 0x100 + 1);
                        puVar6 = puVar4 + 5;
                    }
                } else {
                    func_0x000180131050(((*(uint64_t *)0x1807823c0 + (uint64_t)CONCAT11(uVar1, puVar4[1]) * -0x100) -
                                        (uint64_t)puVar4[2]) + 0x17ffff, puVar4[3] + 1);
                    puVar6 = puVar4 + 4;
                }
            } else if (uVar1 < 0x80) {
                if (uVar1 < 0x40) {
                    func_0x0001801310b0(puVar4 + 1, uVar1 - 0x1f);
                    puVar6 = puVar4 + ((uint64_t)*puVar4 - 0x1e);
                } else {
                    func_0x000180131050(((*(uint64_t *)0x1807823c0 + (uint64_t)uVar1 * -0x100) - (uint64_t)puVar4[1]) +
                                        0x3fff, puVar4[2] + 1);
                    puVar6 = puVar4 + 3;
                }
            } else {
                func_0x000180131050((*(uint64_t *)0x1807823c0 - puVar4[1]) + -1, uVar1 - 0x7f);
                puVar6 = puVar4 + 2;
            }
        } while ((puVar6 != puVar4) && (puVar4 = puVar6, *(uint64_t *)0x1807823c0 <= uVar5));
    }
    if (in_stack_00000028 == (undefined4 *)0x0) {
        func_0x0001804986e0(&var_128h, 0, 0xa0);
        auVar2 = _var_f8h;
        uVar8 = var_f8h;
        auVar3._11_5_ = 0;
        auVar3._0_11_ = stack0xffffffffffffff0d;
        _var_f8h = auVar3 << 0x28;
        auVar3 = _var_f8h;
        uStack_ec = auVar2._12_4_;
        uVar9 = uStack_ec;
        _var_f8h = auVar3._0_10_;
        var_f4h._6_2_ = 0;
        _var_f8h = (unkuint9)0;
        auVar2 = _var_f8h;
        var_f4h._0_4_ = (uint32_t)auVar3._4_3_;
        var_f4h._4_4_ = auVar2._8_4_;
        uStack_cc = 0x7f7fffff;
        uStack_bc = 0x3f800000;
        auStack_b8._0_4_ = 0x3f800000;
        auStack_b8._4_4_ = 0x3f800000;
    } else {
        var_128h._0_4_ = *in_stack_00000028;
        var_128h._4_4_ = in_stack_00000028[1];
        uStack_120 = in_stack_00000028[2];
        uStack_11c = in_stack_00000028[3];
        var_118h._0_4_ = in_stack_00000028[4];
        var_118h._4_4_ = in_stack_00000028[5];
        uStack_110 = in_stack_00000028[6];
        uStack_10c = in_stack_00000028[7];
        var_108h._0_4_ = in_stack_00000028[8];
        var_108h._4_4_ = in_stack_00000028[9];
        uStack_100 = in_stack_00000028[10];
        uStack_fc = in_stack_00000028[0xb];
        uVar8 = in_stack_00000028[0xc];
        var_f4h._0_4_ = in_stack_00000028[0xd];
        var_f4h._4_4_ = in_stack_00000028[0xe];
        uVar9 = in_stack_00000028[0xf];
        var_e8h._0_4_ = in_stack_00000028[0x10];
        var_e8h._4_4_ = in_stack_00000028[0x11];
        uStack_e0 = in_stack_00000028[0x12];
        uStack_dc = in_stack_00000028[0x13];
        auStack_d8._0_4_ = in_stack_00000028[0x14];
        auStack_d8._4_4_ = in_stack_00000028[0x15];
        uStack_d0 = in_stack_00000028[0x16];
        uStack_cc = in_stack_00000028[0x17];
        auStack_c8._0_4_ = in_stack_00000028[0x18];
        auStack_c8._4_4_ = in_stack_00000028[0x19];
        uStack_c0 = in_stack_00000028[0x1a];
        uStack_bc = in_stack_00000028[0x1b];
        auStack_b8._0_4_ = in_stack_00000028[0x1c];
        auStack_b8._4_4_ = in_stack_00000028[0x1d];
        uStack_b0._0_4_ = in_stack_00000028[0x1e];
        uStack_b0._4_4_ = in_stack_00000028[0x1f];
        auStack_a8._0_4_ = in_stack_00000028[0x20];
        auStack_a8._4_4_ = in_stack_00000028[0x21];
        uStack_a0 = in_stack_00000028[0x22];
        uStack_9c = in_stack_00000028[0x23];
        auStack_98._0_4_ = in_stack_00000028[0x24];
        auStack_98._4_4_ = in_stack_00000028[0x25];
        uStack_90 = in_stack_00000028[0x26];
        uStack_8c = in_stack_00000028[0x27];
    }
    auVar2._4_4_ = (uint32_t)var_f4h;
    auVar2._0_4_ = uVar8;
    auVar2._8_4_ = var_f4h._4_4_;
    auVar2._12_4_ = uVar9;
    stack0xffffffffffffff0d = auVar2._5_11_;
    var_f4h._0_1_ = 1;
    var_f8h = (undefined  [4])uVar8;
    fcn.1801279b0(arg1, arg2_00, (uint64_t)uVar7, in_R9, (int64_t)&var_128h);
    return;
}

// ============================================================
// Function: FUN_180128320
// Address: 0x180128320
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180128320(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_28h;
    
    piVar6 = *(int64_t **)(arg1 + 0x2a8);
    piVar1 = piVar6 + *(int32_t *)(arg1 + 0x2a0);
    for (; piVar6 != piVar1; piVar6 = piVar6 + 1) {
        iVar2 = *piVar6;
        if (*(int64_t *)(iVar2 + 0x18) == arg2) {
            *(int64_t *)(iVar2 + 0x18) = arg3;
        }
        iVar2 = *(int64_t *)(iVar2 + 0x68);
        if ((iVar2 != 0) &&
           (((arg2 != 0 || (*(int64_t *)(iVar2 + 0x12e8) != 0)) || (*(float *)(iVar2 + 0x12fc) != 0.0)))) {
            if (*(int64_t *)(iVar2 + 0x70) == arg2) {
                *(int64_t *)(iVar2 + 0x70) = arg3;
            }
            iVar3 = *(int64_t *)0x180781f28;
            *(int64_t *)0x180781f28 = iVar3;
            if (*(int64_t *)(iVar2 + 0x12e8) == arg2) {
                if (iVar2 == *(int64_t *)0x180781f28) {
                    func_0x0001801072d0(arg3, *(undefined4 *)(iVar2 + 0x12fc), *(undefined4 *)(iVar2 + 0x12f8));
                } else {
                    *(int64_t *)0x180781f28 = iVar2;
                    func_0x0001801072d0(arg3, *(undefined4 *)(iVar2 + 0x12fc), *(undefined4 *)(iVar2 + 0x12f8));
                    *(int64_t *)0x180781f28 = iVar3;
                }
            }
            piVar4 = *(int64_t **)(iVar2 + 0x20e8);
            piVar5 = piVar4 + (int64_t)*(int32_t *)(iVar2 + 0x20e0) * 2;
            for (; piVar4 != piVar5; piVar4 = piVar4 + 2) {
                if (*piVar4 == arg2) {
                    *piVar4 = arg3;
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18012834f
// Address: 0x18012834f
// Size: 224 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180128320(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_28h;
    
    piVar6 = *(int64_t **)(arg1 + 0x2a8);
    piVar1 = piVar6 + *(int32_t *)(arg1 + 0x2a0);
    for (; piVar6 != piVar1; piVar6 = piVar6 + 1) {
        iVar2 = *piVar6;
        if (*(int64_t *)(iVar2 + 0x18) == arg2) {
            *(int64_t *)(iVar2 + 0x18) = arg3;
        }
        iVar2 = *(int64_t *)(iVar2 + 0x68);
        if ((iVar2 != 0) &&
           (((arg2 != 0 || (*(int64_t *)(iVar2 + 0x12e8) != 0)) || (*(float *)(iVar2 + 0x12fc) != 0.0)))) {
            if (*(int64_t *)(iVar2 + 0x70) == arg2) {
                *(int64_t *)(iVar2 + 0x70) = arg3;
            }
            iVar3 = *(int64_t *)0x180781f28;
            *(int64_t *)0x180781f28 = iVar3;
            if (*(int64_t *)(iVar2 + 0x12e8) == arg2) {
                if (iVar2 == *(int64_t *)0x180781f28) {
                    func_0x0001801072d0(arg3, *(undefined4 *)(iVar2 + 0x12fc), *(undefined4 *)(iVar2 + 0x12f8));
                } else {
                    *(int64_t *)0x180781f28 = iVar2;
                    func_0x0001801072d0(arg3, *(undefined4 *)(iVar2 + 0x12fc), *(undefined4 *)(iVar2 + 0x12f8));
                    *(int64_t *)0x180781f28 = iVar3;
                }
            }
            piVar4 = *(int64_t **)(iVar2 + 0x20e8);
            piVar5 = piVar4 + (int64_t)*(int32_t *)(iVar2 + 0x20e0) * 2;
            for (; piVar4 != piVar5; piVar4 = piVar4 + 2) {
                if (*piVar4 == arg2) {
                    *piVar4 = arg3;
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18012842f
// Address: 0x18012842f
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180128320(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_28h;
    
    piVar6 = *(int64_t **)(arg1 + 0x2a8);
    piVar1 = piVar6 + *(int32_t *)(arg1 + 0x2a0);
    for (; piVar6 != piVar1; piVar6 = piVar6 + 1) {
        iVar2 = *piVar6;
        if (*(int64_t *)(iVar2 + 0x18) == arg2) {
            *(int64_t *)(iVar2 + 0x18) = arg3;
        }
        iVar2 = *(int64_t *)(iVar2 + 0x68);
        if ((iVar2 != 0) &&
           (((arg2 != 0 || (*(int64_t *)(iVar2 + 0x12e8) != 0)) || (*(float *)(iVar2 + 0x12fc) != 0.0)))) {
            if (*(int64_t *)(iVar2 + 0x70) == arg2) {
                *(int64_t *)(iVar2 + 0x70) = arg3;
            }
            iVar3 = *(int64_t *)0x180781f28;
            *(int64_t *)0x180781f28 = iVar3;
            if (*(int64_t *)(iVar2 + 0x12e8) == arg2) {
                if (iVar2 == *(int64_t *)0x180781f28) {
                    func_0x0001801072d0(arg3, *(undefined4 *)(iVar2 + 0x12fc), *(undefined4 *)(iVar2 + 0x12f8));
                } else {
                    *(int64_t *)0x180781f28 = iVar2;
                    func_0x0001801072d0(arg3, *(undefined4 *)(iVar2 + 0x12fc), *(undefined4 *)(iVar2 + 0x12f8));
                    *(int64_t *)0x180781f28 = iVar3;
                }
            }
            piVar4 = *(int64_t **)(iVar2 + 0x20e8);
            piVar5 = piVar4 + (int64_t)*(int32_t *)(iVar2 + 0x20e0) * 2;
            for (; piVar4 != piVar5; piVar4 = piVar4 + 2) {
                if (*piVar4 == arg2) {
                    *piVar4 = arg3;
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180128440
// Address: 0x180128440
// Size: 182 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180128440(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg_38h)
{
    float fVar1;
    uint16_t uVar2;
    uint16_t uVar3;
    uint16_t *puVar4;
    int64_t var_8h;
    
    puVar4 = (uint16_t *)fcn.18012b530();
    if (puVar4 == (uint16_t *)0x0) {
        return 0;
    }
    if (arg3 != 0) {
        *(uint16_t *)arg3 = *puVar4;
        *(uint16_t *)(arg3 + 2) = puVar4[1];
        *(uint16_t *)(arg3 + 4) = puVar4[2];
        *(uint16_t *)(arg3 + 6) = puVar4[3];
        uVar2 = *puVar4;
        fVar1 = *(float *)(arg1 + 0x54);
        *(float *)(arg3 + 0xc) = (float)(uint32_t)puVar4[1] * *(float *)(arg1 + 0x58);
        *(float *)(arg3 + 8) = (float)(uint32_t)uVar2 * fVar1;
        uVar2 = *puVar4;
        uVar3 = puVar4[2];
        fVar1 = *(float *)(arg1 + 0x54);
        *(float *)(arg3 + 0x14) = (float)((uint32_t)puVar4[3] + (uint32_t)puVar4[1]) * *(float *)(arg1 + 0x58);
        *(float *)(arg3 + 0x10) = (float)((uint32_t)uVar3 + (uint32_t)uVar2) * fVar1;
    }
    return 1;
}

// ============================================================
// Function: FUN_180128500
// Address: 0x180128500
// Size: 389 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ceh
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d1h
// WARNING: [rz-ghidra] Detected overlap for variable var_d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_d2h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_58h

void fcn.180128500(int64_t arg1, int64_t arg_28h)
{
    uint16_t *puVar1;
    int64_t *piVar2;
    undefined8 *puVar3;
    int64_t *piVar4;
    uint16_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint32_t uVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    int64_t *piVar11;
    uint16_t *puVar12;
    int64_t iVar13;
    int64_t *piVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    
    if ((*(int64_t *)(arg1 + 0x38) != 0) && (*(int32_t *)(*(int64_t *)(arg1 + 0x38) + 0x18) != *(int32_t *)(arg1 + 4)))
    {
        func_0x000180129f40(&var_8h, arg1);
        func_0x00018012a970(arg1);
        func_0x000180129840(arg1, (undefined4)var_8h, var_8h._4_4_);
        func_0x00018012a190(arg1);
        iVar9 = *(int64_t *)(arg1 + 0x80);
        iVar13 = (int64_t)*(int32_t *)(arg1 + 0x78) * 0xa0 + iVar9;
        for (; iVar9 != iVar13; iVar9 = iVar9 + 0xa0) {
            iVar6 = *(int64_t *)(iVar9 + 0x88);
            if (iVar6 == 0) {
                iVar6 = *(int64_t *)(arg1 + 0x2b8);
            }
            if (*(code **)(iVar6 + 0x18) != (code *)0x0) {
                (**(code **)(iVar6 + 0x18))(arg1);
            }
        }
        piVar11 = *(int64_t **)(arg1 + 0x70);
        piVar2 = piVar11 + *(int32_t *)(arg1 + 0x68);
        for (; piVar11 != piVar2; piVar11 = piVar11 + 1) {
            iVar9 = *piVar11;
            puVar10 = *(undefined8 **)(iVar9 + 0x28);
            puVar3 = puVar10 + *(int32_t *)(iVar9 + 0x20);
            for (; puVar10 != puVar3; puVar10 = puVar10 + 1) {
                func_0x000180129250(arg1, iVar9, *puVar10);
            }
        }
    }
    if (*(int64_t *)(arg1 + 0x2b0) == 0) {
        func_0x00018012a190(arg1);
    }
    if (*(int32_t *)(arg1 + 0x78) == 0) {
        fcn.180127690(arg1, 0);
    }
    piVar11 = *(int64_t **)(arg1 + 0x2a8);
    piVar2 = piVar11 + *(int32_t *)(arg1 + 0x2a0);
    do {
        if (piVar11 == piVar2) {
code_r0x000180128673:
            if (*(char *)(arg1 + 0x51) != '\0') {
                *(undefined *)(arg1 + 0x52) = 1;
                return;
            }
            *(undefined *)(*(int64_t *)(arg1 + 0x2b0) + 0xb9) = 1;
            piVar11 = *(int64_t **)(arg1 + 0x70);
            piVar2 = piVar11 + *(int32_t *)(arg1 + 0x68);
            do {
                if (piVar11 == piVar2) {
                    *(undefined *)(arg1 + 0x52) = 1;
                    return;
                }
                iVar9 = *piVar11;
                iVar13 = func_0x00018012ec80(iVar9, *(undefined4 *)(iVar9 + 0x1c), 0xbf800000);
                uVar7 = (uint64_t)*(uint16_t *)(iVar9 + 0x32);
                if ((*(uint16_t *)(iVar9 + 0x32) != 0) &&
                   (((uint64_t)(int64_t)*(int32_t *)(iVar13 + 0x20) <= uVar7 ||
                    (*(int16_t *)(*(int64_t *)(iVar13 + 0x28) + uVar7 * 2) == -1)))) {
                    func_0x00018012b6e0(iVar13, uVar7, 0);
                }
                uVar7 = (uint64_t)*(uint16_t *)(iVar9 + 0x30);
                if ((*(uint16_t *)(iVar9 + 0x30) != 0) &&
                   (((uint64_t)(int64_t)*(int32_t *)(iVar13 + 0x20) <= uVar7 ||
                    (*(int16_t *)(*(int64_t *)(iVar13 + 0x28) + uVar7 * 2) == -1)))) {
                    func_0x00018012b6e0(iVar13, uVar7, 0);
                }
                piVar14 = *(int64_t **)(iVar9 + 0x28);
                piVar4 = piVar14 + *(int32_t *)(iVar9 + 0x20);
                for (; piVar14 != piVar4; piVar14 = piVar14 + 1) {
                    puVar12 = (uint16_t *)0x180645724;
                    if (*(uint16_t **)(*piVar14 + 0x40) != (uint16_t *)0x0) {
                        puVar12 = *(uint16_t **)(*piVar14 + 0x40);
                    }
                    uVar5 = *puVar12;
                    while (uVar5 != 0) {
                        uVar8 = (uint32_t)uVar5;
                        if (uVar5 <= puVar12[1]) {
                            do {
                                if (0xffff < uVar8) break;
                                uVar7 = (uint64_t)(uVar8 & 0xffff);
                                if (((uint64_t)(int64_t)*(int32_t *)(iVar13 + 0x20) <= uVar7) ||
                                   (*(int16_t *)(*(int64_t *)(iVar13 + 0x28) + uVar7 * 2) == -1)) {
                                    func_0x00018012b6e0(iVar13, uVar7, 0);
                                }
                                uVar8 = uVar8 + 1;
                            } while (uVar8 <= puVar12[1]);
                        }
                        puVar1 = puVar12 + 2;
                        puVar12 = puVar12 + 2;
                        uVar5 = *puVar1;
                    }
                }
                piVar11 = piVar11 + 1;
            } while( true );
        }
        if (*(int64_t *)(*piVar11 + 0x68) != 0) {
            *(uint8_t *)(arg1 + 0x51) = (uint8_t)(*(uint32_t *)(*(int64_t *)(*piVar11 + 0x68) + 0x34) >> 4) & 1;
            goto code_r0x000180128673;
        }
        piVar11 = piVar11 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_180128685
// Address: 0x180128685
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ceh
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d1h
// WARNING: [rz-ghidra] Detected overlap for variable var_d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_d2h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_58h

void fcn.180128500(int64_t arg1, int64_t arg_28h)
{
    uint16_t *puVar1;
    int64_t *piVar2;
    undefined8 *puVar3;
    int64_t *piVar4;
    uint16_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint32_t uVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    int64_t *piVar11;
    uint16_t *puVar12;
    int64_t iVar13;
    int64_t *piVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    
    if ((*(int64_t *)(arg1 + 0x38) != 0) && (*(int32_t *)(*(int64_t *)(arg1 + 0x38) + 0x18) != *(int32_t *)(arg1 + 4)))
    {
        func_0x000180129f40(&var_8h, arg1);
        func_0x00018012a970(arg1);
        func_0x000180129840(arg1, (undefined4)var_8h, var_8h._4_4_);
        func_0x00018012a190(arg1);
        iVar9 = *(int64_t *)(arg1 + 0x80);
        iVar13 = (int64_t)*(int32_t *)(arg1 + 0x78) * 0xa0 + iVar9;
        for (; iVar9 != iVar13; iVar9 = iVar9 + 0xa0) {
            iVar6 = *(int64_t *)(iVar9 + 0x88);
            if (iVar6 == 0) {
                iVar6 = *(int64_t *)(arg1 + 0x2b8);
            }
            if (*(code **)(iVar6 + 0x18) != (code *)0x0) {
                (**(code **)(iVar6 + 0x18))(arg1);
            }
        }
        piVar11 = *(int64_t **)(arg1 + 0x70);
        piVar2 = piVar11 + *(int32_t *)(arg1 + 0x68);
        for (; piVar11 != piVar2; piVar11 = piVar11 + 1) {
            iVar9 = *piVar11;
            puVar10 = *(undefined8 **)(iVar9 + 0x28);
            puVar3 = puVar10 + *(int32_t *)(iVar9 + 0x20);
            for (; puVar10 != puVar3; puVar10 = puVar10 + 1) {
                func_0x000180129250(arg1, iVar9, *puVar10);
            }
        }
    }
    if (*(int64_t *)(arg1 + 0x2b0) == 0) {
        func_0x00018012a190(arg1);
    }
    if (*(int32_t *)(arg1 + 0x78) == 0) {
        fcn.180127690(arg1, 0);
    }
    piVar11 = *(int64_t **)(arg1 + 0x2a8);
    piVar2 = piVar11 + *(int32_t *)(arg1 + 0x2a0);
    do {
        if (piVar11 == piVar2) {
code_r0x000180128673:
            if (*(char *)(arg1 + 0x51) != '\0') {
                *(undefined *)(arg1 + 0x52) = 1;
                return;
            }
            *(undefined *)(*(int64_t *)(arg1 + 0x2b0) + 0xb9) = 1;
            piVar11 = *(int64_t **)(arg1 + 0x70);
            piVar2 = piVar11 + *(int32_t *)(arg1 + 0x68);
            do {
                if (piVar11 == piVar2) {
                    *(undefined *)(arg1 + 0x52) = 1;
                    return;
                }
                iVar9 = *piVar11;
                iVar13 = func_0x00018012ec80(iVar9, *(undefined4 *)(iVar9 + 0x1c), 0xbf800000);
                uVar7 = (uint64_t)*(uint16_t *)(iVar9 + 0x32);
                if ((*(uint16_t *)(iVar9 + 0x32) != 0) &&
                   (((uint64_t)(int64_t)*(int32_t *)(iVar13 + 0x20) <= uVar7 ||
                    (*(int16_t *)(*(int64_t *)(iVar13 + 0x28) + uVar7 * 2) == -1)))) {
                    func_0x00018012b6e0(iVar13, uVar7, 0);
                }
                uVar7 = (uint64_t)*(uint16_t *)(iVar9 + 0x30);
                if ((*(uint16_t *)(iVar9 + 0x30) != 0) &&
                   (((uint64_t)(int64_t)*(int32_t *)(iVar13 + 0x20) <= uVar7 ||
                    (*(int16_t *)(*(int64_t *)(iVar13 + 0x28) + uVar7 * 2) == -1)))) {
                    func_0x00018012b6e0(iVar13, uVar7, 0);
                }
                piVar14 = *(int64_t **)(iVar9 + 0x28);
                piVar4 = piVar14 + *(int32_t *)(iVar9 + 0x20);
                for (; piVar14 != piVar4; piVar14 = piVar14 + 1) {
                    puVar12 = (uint16_t *)0x180645724;
                    if (*(uint16_t **)(*piVar14 + 0x40) != (uint16_t *)0x0) {
                        puVar12 = *(uint16_t **)(*piVar14 + 0x40);
                    }
                    uVar5 = *puVar12;
                    while (uVar5 != 0) {
                        uVar8 = (uint32_t)uVar5;
                        if (uVar5 <= puVar12[1]) {
                            do {
                                if (0xffff < uVar8) break;
                                uVar7 = (uint64_t)(uVar8 & 0xffff);
                                if (((uint64_t)(int64_t)*(int32_t *)(iVar13 + 0x20) <= uVar7) ||
                                   (*(int16_t *)(*(int64_t *)(iVar13 + 0x28) + uVar7 * 2) == -1)) {
                                    func_0x00018012b6e0(iVar13, uVar7, 0);
                                }
                                uVar8 = uVar8 + 1;
                            } while (uVar8 <= puVar12[1]);
                        }
                        puVar1 = puVar12 + 2;
                        puVar12 = puVar12 + 2;
                        uVar5 = *puVar1;
                    }
                }
                piVar11 = piVar11 + 1;
            } while( true );
        }
        if (*(int64_t *)(*piVar11 + 0x68) != 0) {
            *(uint8_t *)(arg1 + 0x51) = (uint8_t)(*(uint32_t *)(*(int64_t *)(*piVar11 + 0x68) + 0x34) >> 4) & 1;
            goto code_r0x000180128673;
        }
        piVar11 = piVar11 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1801286ab
// Address: 0x1801286ab
// Size: 294 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ceh
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d1h
// WARNING: [rz-ghidra] Detected overlap for variable var_d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_d2h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_58h

void fcn.180128500(int64_t arg1, int64_t arg_28h)
{
    uint16_t *puVar1;
    int64_t *piVar2;
    undefined8 *puVar3;
    int64_t *piVar4;
    uint16_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint32_t uVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    int64_t *piVar11;
    uint16_t *puVar12;
    int64_t iVar13;
    int64_t *piVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    
    if ((*(int64_t *)(arg1 + 0x38) != 0) && (*(int32_t *)(*(int64_t *)(arg1 + 0x38) + 0x18) != *(int32_t *)(arg1 + 4)))
    {
        func_0x000180129f40(&var_8h, arg1);
        func_0x00018012a970(arg1);
        func_0x000180129840(arg1, (undefined4)var_8h, var_8h._4_4_);
        func_0x00018012a190(arg1);
        iVar9 = *(int64_t *)(arg1 + 0x80);
        iVar13 = (int64_t)*(int32_t *)(arg1 + 0x78) * 0xa0 + iVar9;
        for (; iVar9 != iVar13; iVar9 = iVar9 + 0xa0) {
            iVar6 = *(int64_t *)(iVar9 + 0x88);
            if (iVar6 == 0) {
                iVar6 = *(int64_t *)(arg1 + 0x2b8);
            }
            if (*(code **)(iVar6 + 0x18) != (code *)0x0) {
                (**(code **)(iVar6 + 0x18))(arg1);
            }
        }
        piVar11 = *(int64_t **)(arg1 + 0x70);
        piVar2 = piVar11 + *(int32_t *)(arg1 + 0x68);
        for (; piVar11 != piVar2; piVar11 = piVar11 + 1) {
            iVar9 = *piVar11;
            puVar10 = *(undefined8 **)(iVar9 + 0x28);
            puVar3 = puVar10 + *(int32_t *)(iVar9 + 0x20);
            for (; puVar10 != puVar3; puVar10 = puVar10 + 1) {
                func_0x000180129250(arg1, iVar9, *puVar10);
            }
        }
    }
    if (*(int64_t *)(arg1 + 0x2b0) == 0) {
        func_0x00018012a190(arg1);
    }
    if (*(int32_t *)(arg1 + 0x78) == 0) {
        fcn.180127690(arg1, 0);
    }
    piVar11 = *(int64_t **)(arg1 + 0x2a8);
    piVar2 = piVar11 + *(int32_t *)(arg1 + 0x2a0);
    do {
        if (piVar11 == piVar2) {
code_r0x000180128673:
            if (*(char *)(arg1 + 0x51) != '\0') {
                *(undefined *)(arg1 + 0x52) = 1;
                return;
            }
            *(undefined *)(*(int64_t *)(arg1 + 0x2b0) + 0xb9) = 1;
            piVar11 = *(int64_t **)(arg1 + 0x70);
            piVar2 = piVar11 + *(int32_t *)(arg1 + 0x68);
            do {
                if (piVar11 == piVar2) {
                    *(undefined *)(arg1 + 0x52) = 1;
                    return;
                }
                iVar9 = *piVar11;
                iVar13 = func_0x00018012ec80(iVar9, *(undefined4 *)(iVar9 + 0x1c), 0xbf800000);
                uVar7 = (uint64_t)*(uint16_t *)(iVar9 + 0x32);
                if ((*(uint16_t *)(iVar9 + 0x32) != 0) &&
                   (((uint64_t)(int64_t)*(int32_t *)(iVar13 + 0x20) <= uVar7 ||
                    (*(int16_t *)(*(int64_t *)(iVar13 + 0x28) + uVar7 * 2) == -1)))) {
                    func_0x00018012b6e0(iVar13, uVar7, 0);
                }
                uVar7 = (uint64_t)*(uint16_t *)(iVar9 + 0x30);
                if ((*(uint16_t *)(iVar9 + 0x30) != 0) &&
                   (((uint64_t)(int64_t)*(int32_t *)(iVar13 + 0x20) <= uVar7 ||
                    (*(int16_t *)(*(int64_t *)(iVar13 + 0x28) + uVar7 * 2) == -1)))) {
                    func_0x00018012b6e0(iVar13, uVar7, 0);
                }
                piVar14 = *(int64_t **)(iVar9 + 0x28);
                piVar4 = piVar14 + *(int32_t *)(iVar9 + 0x20);
                for (; piVar14 != piVar4; piVar14 = piVar14 + 1) {
                    puVar12 = (uint16_t *)0x180645724;
                    if (*(uint16_t **)(*piVar14 + 0x40) != (uint16_t *)0x0) {
                        puVar12 = *(uint16_t **)(*piVar14 + 0x40);
                    }
                    uVar5 = *puVar12;
                    while (uVar5 != 0) {
                        uVar8 = (uint32_t)uVar5;
                        if (uVar5 <= puVar12[1]) {
                            do {
                                if (0xffff < uVar8) break;
                                uVar7 = (uint64_t)(uVar8 & 0xffff);
                                if (((uint64_t)(int64_t)*(int32_t *)(iVar13 + 0x20) <= uVar7) ||
                                   (*(int16_t *)(*(int64_t *)(iVar13 + 0x28) + uVar7 * 2) == -1)) {
                                    func_0x00018012b6e0(iVar13, uVar7, 0);
                                }
                                uVar8 = uVar8 + 1;
                            } while (uVar8 <= puVar12[1]);
                        }
                        puVar1 = puVar12 + 2;
                        puVar12 = puVar12 + 2;
                        uVar5 = *puVar1;
                    }
                }
                piVar11 = piVar11 + 1;
            } while( true );
        }
        if (*(int64_t *)(*piVar11 + 0x68) != 0) {
            *(uint8_t *)(arg1 + 0x51) = (uint8_t)(*(uint32_t *)(*(int64_t *)(*piVar11 + 0x68) + 0x34) >> 4) & 1;
            goto code_r0x000180128673;
        }
        piVar11 = piVar11 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1801287d1
// Address: 0x1801287d1
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ceh
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d1h
// WARNING: [rz-ghidra] Detected overlap for variable var_d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_d2h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_58h

void fcn.180128500(int64_t arg1, int64_t arg_28h)
{
    uint16_t *puVar1;
    int64_t *piVar2;
    undefined8 *puVar3;
    int64_t *piVar4;
    uint16_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint32_t uVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    int64_t *piVar11;
    uint16_t *puVar12;
    int64_t iVar13;
    int64_t *piVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    
    if ((*(int64_t *)(arg1 + 0x38) != 0) && (*(int32_t *)(*(int64_t *)(arg1 + 0x38) + 0x18) != *(int32_t *)(arg1 + 4)))
    {
        func_0x000180129f40(&var_8h, arg1);
        func_0x00018012a970(arg1);
        func_0x000180129840(arg1, (undefined4)var_8h, var_8h._4_4_);
        func_0x00018012a190(arg1);
        iVar9 = *(int64_t *)(arg1 + 0x80);
        iVar13 = (int64_t)*(int32_t *)(arg1 + 0x78) * 0xa0 + iVar9;
        for (; iVar9 != iVar13; iVar9 = iVar9 + 0xa0) {
            iVar6 = *(int64_t *)(iVar9 + 0x88);
            if (iVar6 == 0) {
                iVar6 = *(int64_t *)(arg1 + 0x2b8);
            }
            if (*(code **)(iVar6 + 0x18) != (code *)0x0) {
                (**(code **)(iVar6 + 0x18))(arg1);
            }
        }
        piVar11 = *(int64_t **)(arg1 + 0x70);
        piVar2 = piVar11 + *(int32_t *)(arg1 + 0x68);
        for (; piVar11 != piVar2; piVar11 = piVar11 + 1) {
            iVar9 = *piVar11;
            puVar10 = *(undefined8 **)(iVar9 + 0x28);
            puVar3 = puVar10 + *(int32_t *)(iVar9 + 0x20);
            for (; puVar10 != puVar3; puVar10 = puVar10 + 1) {
                func_0x000180129250(arg1, iVar9, *puVar10);
            }
        }
    }
    if (*(int64_t *)(arg1 + 0x2b0) == 0) {
        func_0x00018012a190(arg1);
    }
    if (*(int32_t *)(arg1 + 0x78) == 0) {
        fcn.180127690(arg1, 0);
    }
    piVar11 = *(int64_t **)(arg1 + 0x2a8);
    piVar2 = piVar11 + *(int32_t *)(arg1 + 0x2a0);
    do {
        if (piVar11 == piVar2) {
code_r0x000180128673:
            if (*(char *)(arg1 + 0x51) != '\0') {
                *(undefined *)(arg1 + 0x52) = 1;
                return;
            }
            *(undefined *)(*(int64_t *)(arg1 + 0x2b0) + 0xb9) = 1;
            piVar11 = *(int64_t **)(arg1 + 0x70);
            piVar2 = piVar11 + *(int32_t *)(arg1 + 0x68);
            do {
                if (piVar11 == piVar2) {
                    *(undefined *)(arg1 + 0x52) = 1;
                    return;
                }
                iVar9 = *piVar11;
                iVar13 = func_0x00018012ec80(iVar9, *(undefined4 *)(iVar9 + 0x1c), 0xbf800000);
                uVar7 = (uint64_t)*(uint16_t *)(iVar9 + 0x32);
                if ((*(uint16_t *)(iVar9 + 0x32) != 0) &&
                   (((uint64_t)(int64_t)*(int32_t *)(iVar13 + 0x20) <= uVar7 ||
                    (*(int16_t *)(*(int64_t *)(iVar13 + 0x28) + uVar7 * 2) == -1)))) {
                    func_0x00018012b6e0(iVar13, uVar7, 0);
                }
                uVar7 = (uint64_t)*(uint16_t *)(iVar9 + 0x30);
                if ((*(uint16_t *)(iVar9 + 0x30) != 0) &&
                   (((uint64_t)(int64_t)*(int32_t *)(iVar13 + 0x20) <= uVar7 ||
                    (*(int16_t *)(*(int64_t *)(iVar13 + 0x28) + uVar7 * 2) == -1)))) {
                    func_0x00018012b6e0(iVar13, uVar7, 0);
                }
                piVar14 = *(int64_t **)(iVar9 + 0x28);
                piVar4 = piVar14 + *(int32_t *)(iVar9 + 0x20);
                for (; piVar14 != piVar4; piVar14 = piVar14 + 1) {
                    puVar12 = (uint16_t *)0x180645724;
                    if (*(uint16_t **)(*piVar14 + 0x40) != (uint16_t *)0x0) {
                        puVar12 = *(uint16_t **)(*piVar14 + 0x40);
                    }
                    uVar5 = *puVar12;
                    while (uVar5 != 0) {
                        uVar8 = (uint32_t)uVar5;
                        if (uVar5 <= puVar12[1]) {
                            do {
                                if (0xffff < uVar8) break;
                                uVar7 = (uint64_t)(uVar8 & 0xffff);
                                if (((uint64_t)(int64_t)*(int32_t *)(iVar13 + 0x20) <= uVar7) ||
                                   (*(int16_t *)(*(int64_t *)(iVar13 + 0x28) + uVar7 * 2) == -1)) {
                                    func_0x00018012b6e0(iVar13, uVar7, 0);
                                }
                                uVar8 = uVar8 + 1;
                            } while (uVar8 <= puVar12[1]);
                        }
                        puVar1 = puVar12 + 2;
                        puVar12 = puVar12 + 2;
                        uVar5 = *puVar1;
                    }
                }
                piVar11 = piVar11 + 1;
            } while( true );
        }
        if (*(int64_t *)(*piVar11 + 0x68) != 0) {
            *(uint8_t *)(arg1 + 0x51) = (uint8_t)(*(uint32_t *)(*(int64_t *)(*piVar11 + 0x68) + 0x34) >> 4) & 1;
            goto code_r0x000180128673;
        }
        piVar11 = piVar11 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1801287f1
// Address: 0x1801287f1
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ceh
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d1h
// WARNING: [rz-ghidra] Detected overlap for variable var_d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_d2h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_58h

void fcn.180128500(int64_t arg1, int64_t arg_28h)
{
    uint16_t *puVar1;
    int64_t *piVar2;
    undefined8 *puVar3;
    int64_t *piVar4;
    uint16_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint32_t uVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    int64_t *piVar11;
    uint16_t *puVar12;
    int64_t iVar13;
    int64_t *piVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    
    if ((*(int64_t *)(arg1 + 0x38) != 0) && (*(int32_t *)(*(int64_t *)(arg1 + 0x38) + 0x18) != *(int32_t *)(arg1 + 4)))
    {
        func_0x000180129f40(&var_8h, arg1);
        func_0x00018012a970(arg1);
        func_0x000180129840(arg1, (undefined4)var_8h, var_8h._4_4_);
        func_0x00018012a190(arg1);
        iVar9 = *(int64_t *)(arg1 + 0x80);
        iVar13 = (int64_t)*(int32_t *)(arg1 + 0x78) * 0xa0 + iVar9;
        for (; iVar9 != iVar13; iVar9 = iVar9 + 0xa0) {
            iVar6 = *(int64_t *)(iVar9 + 0x88);
            if (iVar6 == 0) {
                iVar6 = *(int64_t *)(arg1 + 0x2b8);
            }
            if (*(code **)(iVar6 + 0x18) != (code *)0x0) {
                (**(code **)(iVar6 + 0x18))(arg1);
            }
        }
        piVar11 = *(int64_t **)(arg1 + 0x70);
        piVar2 = piVar11 + *(int32_t *)(arg1 + 0x68);
        for (; piVar11 != piVar2; piVar11 = piVar11 + 1) {
            iVar9 = *piVar11;
            puVar10 = *(undefined8 **)(iVar9 + 0x28);
            puVar3 = puVar10 + *(int32_t *)(iVar9 + 0x20);
            for (; puVar10 != puVar3; puVar10 = puVar10 + 1) {
                func_0x000180129250(arg1, iVar9, *puVar10);
            }
        }
    }
    if (*(int64_t *)(arg1 + 0x2b0) == 0) {
        func_0x00018012a190(arg1);
    }
    if (*(int32_t *)(arg1 + 0x78) == 0) {
        fcn.180127690(arg1, 0);
    }
    piVar11 = *(int64_t **)(arg1 + 0x2a8);
    piVar2 = piVar11 + *(int32_t *)(arg1 + 0x2a0);
    do {
        if (piVar11 == piVar2) {
code_r0x000180128673:
            if (*(char *)(arg1 + 0x51) != '\0') {
                *(undefined *)(arg1 + 0x52) = 1;
                return;
            }
            *(undefined *)(*(int64_t *)(arg1 + 0x2b0) + 0xb9) = 1;
            piVar11 = *(int64_t **)(arg1 + 0x70);
            piVar2 = piVar11 + *(int32_t *)(arg1 + 0x68);
            do {
                if (piVar11 == piVar2) {
                    *(undefined *)(arg1 + 0x52) = 1;
                    return;
                }
                iVar9 = *piVar11;
                iVar13 = func_0x00018012ec80(iVar9, *(undefined4 *)(iVar9 + 0x1c), 0xbf800000);
                uVar7 = (uint64_t)*(uint16_t *)(iVar9 + 0x32);
                if ((*(uint16_t *)(iVar9 + 0x32) != 0) &&
                   (((uint64_t)(int64_t)*(int32_t *)(iVar13 + 0x20) <= uVar7 ||
                    (*(int16_t *)(*(int64_t *)(iVar13 + 0x28) + uVar7 * 2) == -1)))) {
                    func_0x00018012b6e0(iVar13, uVar7, 0);
                }
                uVar7 = (uint64_t)*(uint16_t *)(iVar9 + 0x30);
                if ((*(uint16_t *)(iVar9 + 0x30) != 0) &&
                   (((uint64_t)(int64_t)*(int32_t *)(iVar13 + 0x20) <= uVar7 ||
                    (*(int16_t *)(*(int64_t *)(iVar13 + 0x28) + uVar7 * 2) == -1)))) {
                    func_0x00018012b6e0(iVar13, uVar7, 0);
                }
                piVar14 = *(int64_t **)(iVar9 + 0x28);
                piVar4 = piVar14 + *(int32_t *)(iVar9 + 0x20);
                for (; piVar14 != piVar4; piVar14 = piVar14 + 1) {
                    puVar12 = (uint16_t *)0x180645724;
                    if (*(uint16_t **)(*piVar14 + 0x40) != (uint16_t *)0x0) {
                        puVar12 = *(uint16_t **)(*piVar14 + 0x40);
                    }
                    uVar5 = *puVar12;
                    while (uVar5 != 0) {
                        uVar8 = (uint32_t)uVar5;
                        if (uVar5 <= puVar12[1]) {
                            do {
                                if (0xffff < uVar8) break;
                                uVar7 = (uint64_t)(uVar8 & 0xffff);
                                if (((uint64_t)(int64_t)*(int32_t *)(iVar13 + 0x20) <= uVar7) ||
                                   (*(int16_t *)(*(int64_t *)(iVar13 + 0x28) + uVar7 * 2) == -1)) {
                                    func_0x00018012b6e0(iVar13, uVar7, 0);
                                }
                                uVar8 = uVar8 + 1;
                            } while (uVar8 <= puVar12[1]);
                        }
                        puVar1 = puVar12 + 2;
                        puVar12 = puVar12 + 2;
                        uVar5 = *puVar1;
                    }
                }
                piVar11 = piVar11 + 1;
            } while( true );
        }
        if (*(int64_t *)(*piVar11 + 0x68) != 0) {
            *(uint8_t *)(arg1 + 0x51) = (uint8_t)(*(uint32_t *)(*(int64_t *)(*piVar11 + 0x68) + 0x34) >> 4) & 1;
            goto code_r0x000180128673;
        }
        piVar11 = piVar11 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_180128810
// Address: 0x180128810
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180128810(int64_t arg1, int64_t arg2, int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar4 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar4 + *(int32_t *)(arg1 + 0x68);
    if (piVar4 != piVar1) {
        do {
            iVar6 = *piVar4;
            iVar3 = *(int32_t *)(iVar6 + 0x24);
            if (iVar3 < 0) {
                iVar3 = iVar3 + (iVar3 + 1 >> 1);
                iVar7 = 0;
                if (0 < iVar3) {
                    iVar7 = iVar3;
                }
                func_0x00018011f4f0(iVar6 + 0x20, iVar7);
            }
            piVar4 = piVar4 + 1;
            *(undefined4 *)(iVar6 + 0x20) = 0;
        } while (piVar4 != piVar1);
    }
    iVar6 = *(int64_t *)(arg1 + 0x80);
    iVar5 = (int64_t)*(int32_t *)(arg1 + 0x78) * 0xa0 + iVar6;
    for (; iVar6 != iVar5; iVar6 = iVar6 + 0xa0) {
        iVar2 = *(int64_t *)(iVar6 + 0x80);
        iVar3 = *(int32_t *)(iVar2 + 0x24);
        if (*(int32_t *)(iVar2 + 0x20) == iVar3) {
            iVar7 = *(int32_t *)(iVar2 + 0x20) + 1;
            if (iVar3 == 0) {
                iVar3 = 8;
            } else {
                iVar3 = iVar3 / 2 + iVar3;
            }
            if (iVar7 < iVar3) {
                iVar7 = iVar3;
            }
            func_0x00018011f4f0(iVar2 + 0x20, iVar7);
        }
        *(int64_t *)(*(int64_t *)(iVar2 + 0x28) + (int64_t)*(int32_t *)(iVar2 + 0x20) * 8) = iVar6;
        *(int32_t *)(iVar2 + 0x20) = *(int32_t *)(iVar2 + 0x20) + 1;
    }
    return;
}

// ============================================================
// Function: FUN_180128827
// Address: 0x180128827
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180128810(int64_t arg1, int64_t arg2, int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar4 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar4 + *(int32_t *)(arg1 + 0x68);
    if (piVar4 != piVar1) {
        do {
            iVar6 = *piVar4;
            iVar3 = *(int32_t *)(iVar6 + 0x24);
            if (iVar3 < 0) {
                iVar3 = iVar3 + (iVar3 + 1 >> 1);
                iVar7 = 0;
                if (0 < iVar3) {
                    iVar7 = iVar3;
                }
                func_0x00018011f4f0(iVar6 + 0x20, iVar7);
            }
            piVar4 = piVar4 + 1;
            *(undefined4 *)(iVar6 + 0x20) = 0;
        } while (piVar4 != piVar1);
    }
    iVar6 = *(int64_t *)(arg1 + 0x80);
    iVar5 = (int64_t)*(int32_t *)(arg1 + 0x78) * 0xa0 + iVar6;
    for (; iVar6 != iVar5; iVar6 = iVar6 + 0xa0) {
        iVar2 = *(int64_t *)(iVar6 + 0x80);
        iVar3 = *(int32_t *)(iVar2 + 0x24);
        if (*(int32_t *)(iVar2 + 0x20) == iVar3) {
            iVar7 = *(int32_t *)(iVar2 + 0x20) + 1;
            if (iVar3 == 0) {
                iVar3 = 8;
            } else {
                iVar3 = iVar3 / 2 + iVar3;
            }
            if (iVar7 < iVar3) {
                iVar7 = iVar3;
            }
            func_0x00018011f4f0(iVar2 + 0x20, iVar7);
        }
        *(int64_t *)(*(int64_t *)(iVar2 + 0x28) + (int64_t)*(int32_t *)(iVar2 + 0x20) * 8) = iVar6;
        *(int32_t *)(iVar2 + 0x20) = *(int32_t *)(iVar2 + 0x20) + 1;
    }
    return;
}

// ============================================================
// Function: FUN_180128838
// Address: 0x180128838
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180128810(int64_t arg1, int64_t arg2, int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar4 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar4 + *(int32_t *)(arg1 + 0x68);
    if (piVar4 != piVar1) {
        do {
            iVar6 = *piVar4;
            iVar3 = *(int32_t *)(iVar6 + 0x24);
            if (iVar3 < 0) {
                iVar3 = iVar3 + (iVar3 + 1 >> 1);
                iVar7 = 0;
                if (0 < iVar3) {
                    iVar7 = iVar3;
                }
                func_0x00018011f4f0(iVar6 + 0x20, iVar7);
            }
            piVar4 = piVar4 + 1;
            *(undefined4 *)(iVar6 + 0x20) = 0;
        } while (piVar4 != piVar1);
    }
    iVar6 = *(int64_t *)(arg1 + 0x80);
    iVar5 = (int64_t)*(int32_t *)(arg1 + 0x78) * 0xa0 + iVar6;
    for (; iVar6 != iVar5; iVar6 = iVar6 + 0xa0) {
        iVar2 = *(int64_t *)(iVar6 + 0x80);
        iVar3 = *(int32_t *)(iVar2 + 0x24);
        if (*(int32_t *)(iVar2 + 0x20) == iVar3) {
            iVar7 = *(int32_t *)(iVar2 + 0x20) + 1;
            if (iVar3 == 0) {
                iVar3 = 8;
            } else {
                iVar3 = iVar3 / 2 + iVar3;
            }
            if (iVar7 < iVar3) {
                iVar7 = iVar3;
            }
            func_0x00018011f4f0(iVar2 + 0x20, iVar7);
        }
        *(int64_t *)(*(int64_t *)(iVar2 + 0x28) + (int64_t)*(int32_t *)(iVar2 + 0x20) * 8) = iVar6;
        *(int32_t *)(iVar2 + 0x20) = *(int32_t *)(iVar2 + 0x20) + 1;
    }
    return;
}

// ============================================================
// Function: FUN_180128876
// Address: 0x180128876
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180128810(int64_t arg1, int64_t arg2, int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar4 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar4 + *(int32_t *)(arg1 + 0x68);
    if (piVar4 != piVar1) {
        do {
            iVar6 = *piVar4;
            iVar3 = *(int32_t *)(iVar6 + 0x24);
            if (iVar3 < 0) {
                iVar3 = iVar3 + (iVar3 + 1 >> 1);
                iVar7 = 0;
                if (0 < iVar3) {
                    iVar7 = iVar3;
                }
                func_0x00018011f4f0(iVar6 + 0x20, iVar7);
            }
            piVar4 = piVar4 + 1;
            *(undefined4 *)(iVar6 + 0x20) = 0;
        } while (piVar4 != piVar1);
    }
    iVar6 = *(int64_t *)(arg1 + 0x80);
    iVar5 = (int64_t)*(int32_t *)(arg1 + 0x78) * 0xa0 + iVar6;
    for (; iVar6 != iVar5; iVar6 = iVar6 + 0xa0) {
        iVar2 = *(int64_t *)(iVar6 + 0x80);
        iVar3 = *(int32_t *)(iVar2 + 0x24);
        if (*(int32_t *)(iVar2 + 0x20) == iVar3) {
            iVar7 = *(int32_t *)(iVar2 + 0x20) + 1;
            if (iVar3 == 0) {
                iVar3 = 8;
            } else {
                iVar3 = iVar3 / 2 + iVar3;
            }
            if (iVar7 < iVar3) {
                iVar7 = iVar3;
            }
            func_0x00018011f4f0(iVar2 + 0x20, iVar7);
        }
        *(int64_t *)(*(int64_t *)(iVar2 + 0x28) + (int64_t)*(int32_t *)(iVar2 + 0x20) * 8) = iVar6;
        *(int32_t *)(iVar2 + 0x20) = *(int32_t *)(iVar2 + 0x20) + 1;
    }
    return;
}

// ============================================================
// Function: FUN_1801288a0
// Address: 0x1801288a0
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180128810(int64_t arg1, int64_t arg2, int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar4 = *(int64_t **)(arg1 + 0x70);
    piVar1 = piVar4 + *(int32_t *)(arg1 + 0x68);
    if (piVar4 != piVar1) {
        do {
            iVar6 = *piVar4;
            iVar3 = *(int32_t *)(iVar6 + 0x24);
            if (iVar3 < 0) {
                iVar3 = iVar3 + (iVar3 + 1 >> 1);
                iVar7 = 0;
                if (0 < iVar3) {
                    iVar7 = iVar3;
                }
                func_0x00018011f4f0(iVar6 + 0x20, iVar7);
            }
            piVar4 = piVar4 + 1;
            *(undefined4 *)(iVar6 + 0x20) = 0;
        } while (piVar4 != piVar1);
    }
    iVar6 = *(int64_t *)(arg1 + 0x80);
    iVar5 = (int64_t)*(int32_t *)(arg1 + 0x78) * 0xa0 + iVar6;
    for (; iVar6 != iVar5; iVar6 = iVar6 + 0xa0) {
        iVar2 = *(int64_t *)(iVar6 + 0x80);
        iVar3 = *(int32_t *)(iVar2 + 0x24);
        if (*(int32_t *)(iVar2 + 0x20) == iVar3) {
            iVar7 = *(int32_t *)(iVar2 + 0x20) + 1;
            if (iVar3 == 0) {
                iVar3 = 8;
            } else {
                iVar3 = iVar3 / 2 + iVar3;
            }
            if (iVar7 < iVar3) {
                iVar7 = iVar3;
            }
            func_0x00018011f4f0(iVar2 + 0x20, iVar7);
        }
        *(int64_t *)(*(int64_t *)(iVar2 + 0x28) + (int64_t)*(int32_t *)(iVar2 + 0x20) * 8) = iVar6;
        *(int32_t *)(iVar2 + 0x20) = *(int32_t *)(iVar2 + 0x20) + 1;
    }
    return;
}

