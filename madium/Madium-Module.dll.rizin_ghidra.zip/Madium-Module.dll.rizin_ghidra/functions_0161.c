// Chunk 161 - 50 functions

// ============================================================
// Function: FUN_180216370
// Address: 0x180216370
// Size: 85 bytes
// ============================================================
void fcn.180216370(int64_t arg_80h)
{
    return;
}

// ============================================================
// Function: FUN_1802163c5
// Address: 0x1802163c5
// Size: 866 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1802163c5(int64_t arg_28h, int64_t arg_30h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h)
{
    int32_t *piVar1;
    int32_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int32_t *unaff_RSI;
    int64_t unaff_RDI;
    int64_t unaff_R13;
    int32_t unaff_R15D;
    int64_t var_20h;
    
    iVar4 = func_0x000180215910();
    if (iVar4 == 0) {
        return 0;
    }
    iVar4 = (int32_t)unaff_R13;
    if (*(int64_t *)(unaff_RSI + 0x1a) == unaff_R13) {
        if (*unaff_RSI == 0) {
            uVar5 = 0x180645710;
        } else {
            uVar5 = func_0x00018022ccf0();
        }
        unaff_RSI = (int32_t *)func_0x000180280c20(0, 1, uVar5, 0x1805aadb1, 0x180215c50);
        if (unaff_RSI == (int32_t *)0x0) {
            func_0x000180229480();
            uVar5 = 0x10f;
            goto code_r0x000180216346;
        }
        iVar6 = *(int64_t *)(unaff_RDI + 0x40);
        if ((iVar6 != 0) && (*(int32_t *)(iVar6 + 0x10) == iVar4)) {
            LOCK();
            piVar1 = (int32_t *)(iVar6 + 0x70);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + unaff_R15D;
            UNLOCK();
            if (iVar2 < 2) {
                func_0x000180210740();
            }
        }
        *(int32_t **)(unaff_RDI + 0x40) = unaff_RSI;
    }
    if ((*(int64_t *)(unaff_RSI + 0x1a) != unaff_R13) && (*(int32_t **)(unaff_RDI + 0x40) != unaff_RSI)) {
        if (unaff_RSI[4] == iVar4) {
            LOCK();
            unaff_RSI[0x1c] = unaff_RSI[0x1c] + 1;
            UNLOCK();
        }
        piVar1 = *(int32_t **)(unaff_RDI + 0x40);
        if ((piVar1 != (int32_t *)0x0) && (piVar1[4] == iVar4)) {
            LOCK();
            piVar1 = piVar1 + 0x1c;
            iVar4 = *piVar1;
            *piVar1 = *piVar1 + unaff_R15D;
            UNLOCK();
            if (iVar4 < 2) {
                func_0x000180210740();
            }
        }
        *(int32_t **)(unaff_RDI + 0x40) = unaff_RSI;
    }
    iVar6 = *(int64_t *)(unaff_RDI + 0x38);
    *(int32_t **)(unaff_RDI + 8) = unaff_RSI;
    if (iVar6 == 0) {
        pcVar3 = *(code **)(unaff_RSI + 0x1e);
        uVar5 = func_0x00018027e810(*(undefined8 *)(unaff_RSI + 0x1a));
        iVar6 = (*pcVar3)(uVar5);
        *(int64_t *)(unaff_RDI + 0x38) = iVar6;
        if (iVar6 == 0) {
            func_0x000180229480();
            uVar5 = 0x124;
            goto code_r0x000180216346;
        }
    }
    pcVar3 = *(code **)(*(int64_t *)(unaff_RDI + 8) + 0x80);
    if (pcVar3 != (code *)0x0) {
        uVar5 = (*pcVar3)(iVar6);
        return uVar5;
    }
    func_0x000180229480();
    uVar5 = 0x12a;
code_r0x000180216346:
    func_0x0001802295a0(0x1804bb7b8, uVar5, 0x1804bb800);
    func_0x0001802296d0(6, 0x86, 0);
    return 0;
}

// ============================================================
// Function: FUN_180216730
// Address: 0x180216730
// Size: 53 bytes
// ============================================================
void fcn.180216730(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021673a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 + -iVar1) = 0x180216754;
    iVar1 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + -iVar1));
    if (iVar1 != 0) {
        *(undefined4 *)(iVar1 + 0x70) = 1;
    }
    return;
}

// ============================================================
// Function: FUN_1802167a0
// Address: 0x1802167a0
// Size: 76 bytes
// ============================================================
void fcn.1802167a0(undefined8 param_1, int32_t *param_2)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802167ac;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802167bc;
    iVar3 = fcn.180281b80(*(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2));
    if ((*param_2 != -1) && (iVar3 != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802167ce;
        iVar1 = fcn.180203a00(iVar3);
        if ((*param_2 != 0) && (*param_2 != iVar1)) {
            *param_2 = -1;
            return;
        }
        *param_2 = iVar1;
    }
    return;
}

// ============================================================
// Function: FUN_1802167f0
// Address: 0x1802167f0
// Size: 328 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1802167f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 uVar6;
    int32_t in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180216810;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180216821;
    iVar4 = func_0x00018020e970();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021682c;
    iVar1 = func_0x00018020eae0(in_RCX);
    if (iVar1 << 3 < 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021683a;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180216852;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180216864;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        uVar5 = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180216873;
        uVar5 = func_0x00018020e940(in_RCX);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021687b;
        iVar2 = func_0x00018020efb0(uVar5);
        if ((iVar2 - 1U < 2) && (in_R9D == 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180216896;
            iVar1 = func_0x000180282e50(in_RDX, iVar1 << 3, iVar4);
            uVar5 = 0;
            if (iVar2 == 2) {
                uVar5 = 0x180284300;
            }
            uVar6 = 0x180282270;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802168bc;
            iVar1 = func_0x0001802830c0(in_RDX, iVar1 << 3, iVar4);
            uVar5 = 0;
            if (iVar2 == 2) {
                uVar5 = 0x180284300;
            }
            uVar6 = 0x180282850;
        }
        *(undefined8 *)(iVar4 + 0xf8) = uVar6;
        *(undefined8 *)(iVar4 + 0x100) = uVar5;
        if (iVar1 < 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802168ea;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180216902;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180216914;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            uVar5 = 0;
        } else {
            uVar5 = 1;
        }
    }
    return uVar5;
}

// ============================================================
// Function: FUN_180216940
// Address: 0x180216940
// Size: 71 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180216940(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    code *pcVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021695f;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180216973;
    iVar5 = func_0x00018020e970();
    if (*(int64_t *)(iVar5 + 0x100) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802169bb;
        iVar3 = func_0x0001802007d0(in_RCX);
        *(undefined8 *)((int64_t)&var_10h + iVar4) = *(undefined8 *)(iVar5 + 0xf8);
        *(int64_t *)((int64_t)&var_8h + iVar4) = in_RCX + 0x28;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802169e8;
            func_0x000180284340(in_R8, in_RDX, in_R9, iVar5);
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802169e1;
            func_0x000180284600();
        }
    } else {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
        pcVar1 = *(code **)(iVar5 + 0x100);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180216998;
        uVar2 = func_0x0001802007d0(in_RCX);
        *(undefined4 *)((int64_t)&var_10h + iVar4) = uVar2;
        *(int64_t *)((int64_t)&var_8h + iVar4) = in_RCX + 0x28;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802169af;
        (*pcVar1)(in_R8, in_RDX, in_R9, iVar5);
    }
    return 1;
}

// ============================================================
// Function: FUN_180216987
// Address: 0x180216987
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180216940(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    code *pcVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021695f;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180216973;
    iVar5 = func_0x00018020e970();
    if (*(int64_t *)(iVar5 + 0x100) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802169bb;
        iVar3 = func_0x0001802007d0(in_RCX);
        *(undefined8 *)((int64_t)&var_10h + iVar4) = *(undefined8 *)(iVar5 + 0xf8);
        *(int64_t *)((int64_t)&var_8h + iVar4) = in_RCX + 0x28;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802169e8;
            func_0x000180284340(in_R8, in_RDX, in_R9, iVar5);
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802169e1;
            func_0x000180284600();
        }
    } else {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
        pcVar1 = *(code **)(iVar5 + 0x100);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180216998;
        uVar2 = func_0x0001802007d0(in_RCX);
        *(undefined4 *)((int64_t)&var_10h + iVar4) = uVar2;
        *(int64_t *)((int64_t)&var_8h + iVar4) = in_RCX + 0x28;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802169af;
        (*pcVar1)(in_R8, in_RDX, in_R9, iVar5);
    }
    return 1;
}

// ============================================================
// Function: FUN_1802169b6
// Address: 0x1802169b6
// Size: 81 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180216940(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    code *pcVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021695f;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180216973;
    iVar5 = func_0x00018020e970();
    if (*(int64_t *)(iVar5 + 0x100) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802169bb;
        iVar3 = func_0x0001802007d0(in_RCX);
        *(undefined8 *)((int64_t)&var_10h + iVar4) = *(undefined8 *)(iVar5 + 0xf8);
        *(int64_t *)((int64_t)&var_8h + iVar4) = in_RCX + 0x28;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802169e8;
            func_0x000180284340(in_R8, in_RDX, in_R9, iVar5);
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802169e1;
            func_0x000180284600();
        }
    } else {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
        pcVar1 = *(code **)(iVar5 + 0x100);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180216998;
        uVar2 = func_0x0001802007d0(in_RCX);
        *(undefined4 *)((int64_t)&var_10h + iVar4) = uVar2;
        *(int64_t *)((int64_t)&var_8h + iVar4) = in_RCX + 0x28;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802169af;
        (*pcVar1)(in_R8, in_RDX, in_R9, iVar5);
    }
    return 1;
}

// ============================================================
// Function: FUN_180216a10
// Address: 0x180216a10
// Size: 144 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180216a10(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    int64_t in_RDX;
    int64_t iVar5;
    int64_t in_R8;
    uint64_t in_R9;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180216a2e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216a42;
    iVar2 = func_0x00018020e950();
    uVar6 = (uint64_t)iVar2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216a4d;
    iVar4 = func_0x00018020e970(in_RCX);
    if (uVar6 <= in_R9) {
        iVar5 = in_R8;
        do {
            pcVar1 = *(code **)(iVar4 + 0xf8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216a74;
            (*pcVar1)(iVar5, (in_RDX - in_R8) + iVar5, iVar4);
            iVar5 = iVar5 + uVar6;
        } while ((uint64_t)(iVar5 - in_R8) <= in_R9 - uVar6);
    }
    return 1;
}

// ============================================================
// Function: FUN_180216aa0
// Address: 0x180216aa0
// Size: 143 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180216aa0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined4 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180216ab8;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x180216acc;
    iVar3 = fcn.18020e970();
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x180216ad7;
    uVar1 = fcn.18020ec00(*(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                          *(int64_t *)((int64_t)&arg_48h + iVar2), *(int64_t *)((int64_t)&arg_50h + iVar2), 
                          *(int64_t *)((int64_t)&arg_58h + iVar2), *(int64_t *)(&stack0x00000060 + iVar2), 
                          *(int64_t *)(&stack0x00000068 + iVar2), *(int64_t *)(&stack0x00000070 + iVar2), 
                          *(int64_t *)(&stack0x00000088 + iVar2));
    *(undefined4 *)((int64_t)&arg_48h + iVar2) = uVar1;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = *(undefined8 *)(iVar3 + 0xf8);
    *(int64_t *)((int64_t)&var_10h + iVar2) = (int64_t)&arg_48h + iVar2;
    *(int64_t *)((int64_t)&var_8h + iVar2) = in_RCX + 0x28;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x180216b0b;
    fcn.180284d60(*(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                  *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x180216b17;
    fcn.18020ed90(*(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                  *(int64_t *)((int64_t)&arg_48h + iVar2), *(int64_t *)((int64_t)&arg_50h + iVar2), 
                  *(int64_t *)((int64_t)&arg_58h + iVar2), *(int64_t *)(&stack0x00000060 + iVar2), 
                  *(int64_t *)(&stack0x00000068 + iVar2), *(int64_t *)(&stack0x00000070 + iVar2), 
                  *(int64_t *)(&stack0x00000088 + iVar2), *(int64_t *)(&stack0x00000090 + iVar2), 
                  *(int64_t *)(&stack0x00000140 + iVar2));
    return 1;
}

// ============================================================
// Function: FUN_180216b30
// Address: 0x180216b30
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180216b30(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180216b4e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216b62;
    iVar4 = fcn.18020e970();
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216b6d;
    uVar2 = fcn.18020ec00(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)((int64_t)&arg_50h + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3), 
                          *(int64_t *)(&stack0x00000068 + iVar3), *(int64_t *)(&stack0x00000070 + iVar3), 
                          *(int64_t *)(&stack0x00000088 + iVar3));
    *(undefined4 *)((int64_t)&arg_48h + iVar3) = uVar2;
    uVar1 = *(undefined8 *)(iVar4 + 0xf8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216b80;
    uVar2 = fcn.1802007d0(in_RCX);
    *(undefined8 *)((int64_t)&var_20h + iVar3) = uVar1;
    *(undefined4 *)((int64_t)&var_18h + iVar3) = uVar2;
    *(int64_t *)((int64_t)&var_10h + iVar3) = (int64_t)&arg_48h + iVar3;
    *(int64_t *)((int64_t)&var_8h + iVar3) = in_RCX + 0x28;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216bad;
    fcn.1802850a0(*(int64_t *)((int64_t)&var_10h + iVar3), *(int64_t *)((int64_t)&var_18h + iVar3), 
                  *(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216bb9;
    fcn.18020ed90(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                  *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)((int64_t)&arg_50h + iVar3), 
                  *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3), 
                  *(int64_t *)(&stack0x00000068 + iVar3), *(int64_t *)(&stack0x00000070 + iVar3), 
                  *(int64_t *)(&stack0x00000088 + iVar3), *(int64_t *)(&stack0x00000090 + iVar3), 
                  *(int64_t *)(&stack0x00000140 + iVar3));
    return 1;
}

// ============================================================
// Function: FUN_180216be0
// Address: 0x180216be0
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180216be0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180216bfe;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216c12;
    iVar4 = fcn.18020e970();
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216c1d;
    uVar2 = fcn.18020ec00(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)((int64_t)&arg_50h + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3), 
                          *(int64_t *)(&stack0x00000068 + iVar3), *(int64_t *)(&stack0x00000070 + iVar3), 
                          *(int64_t *)(&stack0x00000088 + iVar3));
    *(undefined4 *)((int64_t)&arg_48h + iVar3) = uVar2;
    uVar1 = *(undefined8 *)(iVar4 + 0xf8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216c30;
    uVar2 = fcn.1802007d0(in_RCX);
    *(undefined8 *)((int64_t)&var_20h + iVar3) = uVar1;
    *(undefined4 *)((int64_t)&var_18h + iVar3) = uVar2;
    *(int64_t *)((int64_t)&var_10h + iVar3) = (int64_t)&arg_48h + iVar3;
    *(int64_t *)((int64_t)&var_8h + iVar3) = in_RCX + 0x28;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216c5d;
    fcn.180284ff0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                  *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3), 
                  *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216c69;
    fcn.18020ed90(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                  *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)((int64_t)&arg_50h + iVar3), 
                  *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)((int64_t)&arg_60h + iVar3), 
                  *(int64_t *)(&stack0x00000068 + iVar3), *(int64_t *)(&stack0x00000070 + iVar3), 
                  *(int64_t *)(&stack0x00000088 + iVar3), *(int64_t *)(&stack0x00000090 + iVar3), 
                  *(int64_t *)(&stack0x00000140 + iVar3));
    return 1;
}

// ============================================================
// Function: FUN_180216c90
// Address: 0x180216c90
// Size: 127 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180216c90(int64_t arg_28h, int64_t arg_58h, int64_t arg_70h, int64_t arg_88h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 uVar5;
    undefined8 unaff_RBP;
    uint64_t uVar6;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    
    uStack_30 = 0x180216cad;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216cc1;
    iVar4 = fcn.18020e970();
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216cd5;
    iVar1 = func_0x00018020ee60(in_RCX, 0x2000);
    if (iVar1 == 0) {
        if (0xfffffffffffffff < in_R9) {
            *(undefined8 *)((int64_t)&arg_58h + iVar3) = unaff_RBP;
            uVar6 = in_R9 >> 0x3c;
            *(uint64_t *)((int64_t)&arg_70h + iVar3) = in_R9 + uVar6 * -0x1000000000000000;
            do {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216d4c;
                uVar2 = fcn.18020ec00(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                                      *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                                      *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                                      *(int64_t *)(&stack0x00000078 + iVar3));
                uVar5 = *(undefined8 *)(iVar4 + 0xf8);
                *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = uVar2;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216d5f;
                uVar2 = fcn.1802007d0(in_RCX);
                *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar5;
                *(undefined4 *)((int64_t)&var_8h + iVar3) = uVar2;
                *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20) = (int64_t)&iStackX_20 + iVar3 + -8;
                *(int64_t *)(&stack0xfffffffffffffff8 + iVar3) = in_RCX + 0x28;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216d8f;
                func_0x000180284ee0(in_R8, in_RDX, 0x8000000000000000, iVar4);
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216d9b;
                fcn.18020ed90(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000078 + iVar3), 
                              *(int64_t *)(&stack0x00000080 + iVar3), *(int64_t *)(&stack0x00000130 + iVar3));
                in_RDX = in_RDX + 0x1000000000000000;
                in_R8 = in_R8 + 0x1000000000000000;
                uVar6 = uVar6 - 1;
            } while (uVar6 != 0);
            in_R9 = *(uint64_t *)((int64_t)&arg_70h + iVar3);
        }
        if (in_R9 == 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216dc4;
        uVar2 = fcn.18020ec00(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000078 + iVar3));
        uVar5 = *(undefined8 *)(iVar4 + 0xf8);
        *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = uVar2;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216dd7;
        uVar2 = fcn.1802007d0(in_RCX);
        in_R9 = in_R9 * 8;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216ce1;
        uVar2 = fcn.18020ec00(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000078 + iVar3));
        uVar5 = *(undefined8 *)(iVar4 + 0xf8);
        *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = uVar2;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216cf4;
        uVar2 = fcn.1802007d0(in_RCX);
    }
    *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar5;
    *(undefined4 *)((int64_t)&var_8h + iVar3) = uVar2;
    *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20) = (int64_t)&iStackX_20 + iVar3 + -8;
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar3) = in_RCX + 0x28;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216e05;
    func_0x000180284ee0(in_R8, in_RDX, in_R9, iVar4);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216e11;
    fcn.18020ed90(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                  *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                  *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                  *(int64_t *)(&stack0x00000078 + iVar3), *(int64_t *)(&stack0x00000080 + iVar3), 
                  *(int64_t *)(&stack0x00000130 + iVar3));
    return 1;
}

// ============================================================
// Function: FUN_180216d0f
// Address: 0x180216d0f
// Size: 168 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180216c90(int64_t arg_28h, int64_t arg_58h, int64_t arg_70h, int64_t arg_88h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 uVar5;
    undefined8 unaff_RBP;
    uint64_t uVar6;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    
    uStack_30 = 0x180216cad;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216cc1;
    iVar4 = fcn.18020e970();
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216cd5;
    iVar1 = func_0x00018020ee60(in_RCX, 0x2000);
    if (iVar1 == 0) {
        if (0xfffffffffffffff < in_R9) {
            *(undefined8 *)((int64_t)&arg_58h + iVar3) = unaff_RBP;
            uVar6 = in_R9 >> 0x3c;
            *(uint64_t *)((int64_t)&arg_70h + iVar3) = in_R9 + uVar6 * -0x1000000000000000;
            do {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216d4c;
                uVar2 = fcn.18020ec00(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                                      *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                                      *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                                      *(int64_t *)(&stack0x00000078 + iVar3));
                uVar5 = *(undefined8 *)(iVar4 + 0xf8);
                *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = uVar2;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216d5f;
                uVar2 = fcn.1802007d0(in_RCX);
                *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar5;
                *(undefined4 *)((int64_t)&var_8h + iVar3) = uVar2;
                *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20) = (int64_t)&iStackX_20 + iVar3 + -8;
                *(int64_t *)(&stack0xfffffffffffffff8 + iVar3) = in_RCX + 0x28;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216d8f;
                func_0x000180284ee0(in_R8, in_RDX, 0x8000000000000000, iVar4);
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216d9b;
                fcn.18020ed90(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000078 + iVar3), 
                              *(int64_t *)(&stack0x00000080 + iVar3), *(int64_t *)(&stack0x00000130 + iVar3));
                in_RDX = in_RDX + 0x1000000000000000;
                in_R8 = in_R8 + 0x1000000000000000;
                uVar6 = uVar6 - 1;
            } while (uVar6 != 0);
            in_R9 = *(uint64_t *)((int64_t)&arg_70h + iVar3);
        }
        if (in_R9 == 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216dc4;
        uVar2 = fcn.18020ec00(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000078 + iVar3));
        uVar5 = *(undefined8 *)(iVar4 + 0xf8);
        *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = uVar2;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216dd7;
        uVar2 = fcn.1802007d0(in_RCX);
        in_R9 = in_R9 * 8;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216ce1;
        uVar2 = fcn.18020ec00(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000078 + iVar3));
        uVar5 = *(undefined8 *)(iVar4 + 0xf8);
        *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = uVar2;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216cf4;
        uVar2 = fcn.1802007d0(in_RCX);
    }
    *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar5;
    *(undefined4 *)((int64_t)&var_8h + iVar3) = uVar2;
    *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20) = (int64_t)&iStackX_20 + iVar3 + -8;
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar3) = in_RCX + 0x28;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216e05;
    func_0x000180284ee0(in_R8, in_RDX, in_R9, iVar4);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216e11;
    fcn.18020ed90(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                  *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                  *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                  *(int64_t *)(&stack0x00000078 + iVar3), *(int64_t *)(&stack0x00000080 + iVar3), 
                  *(int64_t *)(&stack0x00000130 + iVar3));
    return 1;
}

// ============================================================
// Function: FUN_180216db7
// Address: 0x180216db7
// Size: 121 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180216c90(int64_t arg_28h, int64_t arg_58h, int64_t arg_70h, int64_t arg_88h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 uVar5;
    undefined8 unaff_RBP;
    uint64_t uVar6;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    
    uStack_30 = 0x180216cad;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216cc1;
    iVar4 = fcn.18020e970();
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216cd5;
    iVar1 = func_0x00018020ee60(in_RCX, 0x2000);
    if (iVar1 == 0) {
        if (0xfffffffffffffff < in_R9) {
            *(undefined8 *)((int64_t)&arg_58h + iVar3) = unaff_RBP;
            uVar6 = in_R9 >> 0x3c;
            *(uint64_t *)((int64_t)&arg_70h + iVar3) = in_R9 + uVar6 * -0x1000000000000000;
            do {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216d4c;
                uVar2 = fcn.18020ec00(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                                      *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                                      *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                                      *(int64_t *)(&stack0x00000078 + iVar3));
                uVar5 = *(undefined8 *)(iVar4 + 0xf8);
                *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = uVar2;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216d5f;
                uVar2 = fcn.1802007d0(in_RCX);
                *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar5;
                *(undefined4 *)((int64_t)&var_8h + iVar3) = uVar2;
                *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20) = (int64_t)&iStackX_20 + iVar3 + -8;
                *(int64_t *)(&stack0xfffffffffffffff8 + iVar3) = in_RCX + 0x28;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216d8f;
                func_0x000180284ee0(in_R8, in_RDX, 0x8000000000000000, iVar4);
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216d9b;
                fcn.18020ed90(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000078 + iVar3), 
                              *(int64_t *)(&stack0x00000080 + iVar3), *(int64_t *)(&stack0x00000130 + iVar3));
                in_RDX = in_RDX + 0x1000000000000000;
                in_R8 = in_R8 + 0x1000000000000000;
                uVar6 = uVar6 - 1;
            } while (uVar6 != 0);
            in_R9 = *(uint64_t *)((int64_t)&arg_70h + iVar3);
        }
        if (in_R9 == 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216dc4;
        uVar2 = fcn.18020ec00(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000078 + iVar3));
        uVar5 = *(undefined8 *)(iVar4 + 0xf8);
        *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = uVar2;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216dd7;
        uVar2 = fcn.1802007d0(in_RCX);
        in_R9 = in_R9 * 8;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216ce1;
        uVar2 = fcn.18020ec00(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000078 + iVar3));
        uVar5 = *(undefined8 *)(iVar4 + 0xf8);
        *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = uVar2;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216cf4;
        uVar2 = fcn.1802007d0(in_RCX);
    }
    *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar5;
    *(undefined4 *)((int64_t)&var_8h + iVar3) = uVar2;
    *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20) = (int64_t)&iStackX_20 + iVar3 + -8;
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar3) = in_RCX + 0x28;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216e05;
    func_0x000180284ee0(in_R8, in_RDX, in_R9, iVar4);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180216e11;
    fcn.18020ed90(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                  *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                  *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                  *(int64_t *)(&stack0x00000078 + iVar3), *(int64_t *)(&stack0x00000080 + iVar3), 
                  *(int64_t *)(&stack0x00000130 + iVar3));
    return 1;
}

// ============================================================
// Function: FUN_180216e30
// Address: 0x180216e30
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180216e30(int64_t arg_28h, int64_t arg_38h, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180216e4f;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216e63;
    iVar2 = fcn.18020ec00(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                          *(int64_t *)(&stack0x00000068 + iVar3), *(int64_t *)(&stack0x00000070 + iVar3), 
                          *(int64_t *)(&stack0x00000088 + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216e6d;
    iVar4 = fcn.18020e970(in_RCX);
    if (iVar2 < 0) {
        uVar5 = 0;
    } else {
        *(int32_t *)((int64_t)&arg_28h + iVar3) = iVar2;
        iVar1 = *(int64_t *)(iVar4 + 0x100);
        *(undefined8 *)((int64_t)&arg_58h + iVar3) = unaff_RBP;
        if (iVar1 == 0) {
            uVar5 = *(undefined8 *)(iVar4 + 0xf8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216ed4;
            uVar6 = func_0x00018020e930(in_RCX);
            *(undefined8 *)((int64_t)&var_20h + iVar3) = uVar5;
            *(int64_t *)((int64_t)&var_18h + iVar3) = (int64_t)&arg_28h + iVar3;
            *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar6;
            *(int64_t *)((int64_t)&var_8h + iVar3) = in_RCX + 0x28;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216efe;
            func_0x0001802847d0(in_R8, in_RDX, in_R9, iVar4);
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216e9c;
            uVar5 = func_0x00018020e930(in_RCX);
            *(int64_t *)((int64_t)&var_20h + iVar3) = iVar1;
            *(int64_t *)((int64_t)&var_18h + iVar3) = (int64_t)&arg_28h + iVar3;
            *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar5;
            *(int64_t *)((int64_t)&var_8h + iVar3) = in_RCX + 0x28;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216ec6;
            func_0x000180284950(in_R8, in_RDX, in_R9, iVar4);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216f0a;
        fcn.18020ed90(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                      *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                      *(int64_t *)(&stack0x00000068 + iVar3), *(int64_t *)(&stack0x00000070 + iVar3), 
                      *(int64_t *)(&stack0x00000088 + iVar3), *(int64_t *)(&stack0x00000090 + iVar3), 
                      *(int64_t *)(&stack0x00000140 + iVar3));
        uVar5 = 1;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_180216e89
// Address: 0x180216e89
// Size: 139 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180216e30(int64_t arg_28h, int64_t arg_38h, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180216e4f;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216e63;
    iVar2 = fcn.18020ec00(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                          *(int64_t *)(&stack0x00000068 + iVar3), *(int64_t *)(&stack0x00000070 + iVar3), 
                          *(int64_t *)(&stack0x00000088 + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216e6d;
    iVar4 = fcn.18020e970(in_RCX);
    if (iVar2 < 0) {
        uVar5 = 0;
    } else {
        *(int32_t *)((int64_t)&arg_28h + iVar3) = iVar2;
        iVar1 = *(int64_t *)(iVar4 + 0x100);
        *(undefined8 *)((int64_t)&arg_58h + iVar3) = unaff_RBP;
        if (iVar1 == 0) {
            uVar5 = *(undefined8 *)(iVar4 + 0xf8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216ed4;
            uVar6 = func_0x00018020e930(in_RCX);
            *(undefined8 *)((int64_t)&var_20h + iVar3) = uVar5;
            *(int64_t *)((int64_t)&var_18h + iVar3) = (int64_t)&arg_28h + iVar3;
            *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar6;
            *(int64_t *)((int64_t)&var_8h + iVar3) = in_RCX + 0x28;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216efe;
            func_0x0001802847d0(in_R8, in_RDX, in_R9, iVar4);
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216e9c;
            uVar5 = func_0x00018020e930(in_RCX);
            *(int64_t *)((int64_t)&var_20h + iVar3) = iVar1;
            *(int64_t *)((int64_t)&var_18h + iVar3) = (int64_t)&arg_28h + iVar3;
            *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar5;
            *(int64_t *)((int64_t)&var_8h + iVar3) = in_RCX + 0x28;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216ec6;
            func_0x000180284950(in_R8, in_RDX, in_R9, iVar4);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216f0a;
        fcn.18020ed90(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                      *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                      *(int64_t *)(&stack0x00000068 + iVar3), *(int64_t *)(&stack0x00000070 + iVar3), 
                      *(int64_t *)(&stack0x00000088 + iVar3), *(int64_t *)(&stack0x00000090 + iVar3), 
                      *(int64_t *)(&stack0x00000140 + iVar3));
        uVar5 = 1;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_180216f14
// Address: 0x180216f14
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180216e30(int64_t arg_28h, int64_t arg_38h, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180216e4f;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216e63;
    iVar2 = fcn.18020ec00(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                          *(int64_t *)(&stack0x00000068 + iVar3), *(int64_t *)(&stack0x00000070 + iVar3), 
                          *(int64_t *)(&stack0x00000088 + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216e6d;
    iVar4 = fcn.18020e970(in_RCX);
    if (iVar2 < 0) {
        uVar5 = 0;
    } else {
        *(int32_t *)((int64_t)&arg_28h + iVar3) = iVar2;
        iVar1 = *(int64_t *)(iVar4 + 0x100);
        *(undefined8 *)((int64_t)&arg_58h + iVar3) = unaff_RBP;
        if (iVar1 == 0) {
            uVar5 = *(undefined8 *)(iVar4 + 0xf8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216ed4;
            uVar6 = func_0x00018020e930(in_RCX);
            *(undefined8 *)((int64_t)&var_20h + iVar3) = uVar5;
            *(int64_t *)((int64_t)&var_18h + iVar3) = (int64_t)&arg_28h + iVar3;
            *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar6;
            *(int64_t *)((int64_t)&var_8h + iVar3) = in_RCX + 0x28;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216efe;
            func_0x0001802847d0(in_R8, in_RDX, in_R9, iVar4);
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216e9c;
            uVar5 = func_0x00018020e930(in_RCX);
            *(int64_t *)((int64_t)&var_20h + iVar3) = iVar1;
            *(int64_t *)((int64_t)&var_18h + iVar3) = (int64_t)&arg_28h + iVar3;
            *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar5;
            *(int64_t *)((int64_t)&var_8h + iVar3) = in_RCX + 0x28;
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216ec6;
            func_0x000180284950(in_R8, in_RDX, in_R9, iVar4);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180216f0a;
        fcn.18020ed90(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                      *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                      *(int64_t *)(&stack0x00000068 + iVar3), *(int64_t *)(&stack0x00000070 + iVar3), 
                      *(int64_t *)(&stack0x00000088 + iVar3), *(int64_t *)(&stack0x00000090 + iVar3), 
                      *(int64_t *)(&stack0x00000140 + iVar3));
        uVar5 = 1;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_180216f30
// Address: 0x180216f30
// Size: 113 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180216f30(int64_t arg_28h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180216f40;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180216f4b;
    iVar2 = fcn.18020e970();
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180216f6f;
    fcn.180244fc0(iVar2 + 0x100, 0x1c0);
    iVar2 = *(int64_t *)(iVar2 + 0x2c0);
    if (iVar2 != in_RCX + 0x28) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180216f91;
        fcn.180224990(iVar2, 0x1804be3f0, 0xa56);
    }
    return 1;
}

// ============================================================
// Function: FUN_180216fb0
// Address: 0x180216fb0
// Size: 1170 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180216fb0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h)
{
    char *pcVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    undefined8 *in_RCX;
    int64_t iVar10;
    undefined4 in_EDX;
    int64_t iVar11;
    int32_t in_R8D;
    undefined8 *in_R9;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180216fce;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar11 = (int64_t)in_R8D;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180216fe2;
    iVar7 = fcn.18020e970();
    // switch table (38 cases) at 0x1802173f0
    switch(in_EDX) {
    case 0:
        *(undefined8 *)(iVar7 + 0xf8) = 0;
        uVar3 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18021701c;
        uVar4 = func_0x00018020ef90(uVar3);
        *(undefined4 *)(iVar7 + 0x2c8) = uVar4;
        *(undefined8 **)(iVar7 + 0x2c0) = in_RCX + 5;
        *(undefined4 *)(iVar7 + 0x2cc) = 0xffffffff;
        *(undefined4 *)(iVar7 + 0x2d0) = 0;
        *(undefined4 *)(iVar7 + 0x2d8) = 0xffffffff;
        return 1;
    default:
        return 0xffffffff;
    case 8:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180217352;
        iVar11 = fcn.18020e970(in_R9);
        if (*(int64_t *)(iVar7 + 0x288) != 0) {
            if (*(int64_t *)(iVar7 + 0x288) != iVar7) {
                return 0;
            }
            *(int64_t *)(iVar11 + 0x288) = iVar11;
        }
        if (*(undefined8 **)(iVar7 + 0x2c0) == in_RCX + 5) {
            *(undefined8 **)(iVar11 + 0x2c0) = in_R9 + 5;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802173a5;
        iVar10 = fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                               *(int64_t *)((int64_t)&iStackX_10 + iVar6));
        *(int64_t *)(iVar11 + 0x2c0) = iVar10;
        if (iVar10 != 0) {
            iVar5 = *(int32_t *)(iVar7 + 0x2c8);
            uVar3 = *(undefined8 *)(iVar7 + 0x2c0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802173cb;
            func_0x000180498030(iVar10, uVar3, (int64_t)iVar5);
            return 1;
        }
        break;
    case 9:
        if (0 < in_R8D) {
            if ((0x10 < in_R8D) && (*(int32_t *)(iVar7 + 0x2c8) < in_R8D)) {
                puVar2 = *(undefined8 **)(iVar7 + 0x2c0);
                if (puVar2 != in_RCX + 5) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18021709b;
                    fcn.180224990(puVar2, 0x1804be3f0, 0xa72);
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802170b0;
                iVar6 = fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6));
                *(int64_t *)(iVar7 + 0x2c0) = iVar6;
                if (iVar6 == 0) {
                    return 0;
                }
            }
            *(int32_t *)(iVar7 + 0x2c8) = in_R8D;
            return 1;
        }
        break;
    case 0x10:
        if (((in_R8D - 1U < 0x10) && (*(int32_t *)(in_RCX + 2) != 0)) && (-1 < *(int32_t *)(iVar7 + 0x2cc))) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180217137;
            func_0x000180498030(in_R9, in_RCX + 7, iVar11);
            return 1;
        }
        break;
    case 0x11:
        if ((in_R8D - 1U < 0x10) && (*(int32_t *)(in_RCX + 2) == 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802170f5;
            func_0x000180498030(in_RCX + 7, in_R9, iVar11);
            *(int32_t *)(iVar7 + 0x2cc) = in_R8D;
            return 1;
        }
        break;
    case 0x12:
        if (in_R8D == -1) {
            iVar5 = *(int32_t *)(iVar7 + 0x2c8);
            uVar3 = *(undefined8 *)(iVar7 + 0x2c0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18021715c;
            func_0x000180498030(uVar3, in_R9, (int64_t)iVar5);
            *(undefined4 *)(iVar7 + 0x2d0) = 1;
            return 1;
        }
        if ((3 < in_R8D) && (7 < *(int32_t *)(iVar7 + 0x2c8) - in_R8D)) {
            uVar3 = *(undefined8 *)(iVar7 + 0x2c0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18021719c;
            func_0x000180498030(uVar3, in_R9, iVar11);
            if (*(int32_t *)(in_RCX + 2) != 0) {
                iVar5 = *(int32_t *)(iVar7 + 0x2c8);
                iVar10 = *(int64_t *)(iVar7 + 0x2c0);
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802171b9;
                iVar5 = func_0x00018021b830(iVar10 + iVar11, iVar5 - in_R8D);
                if (iVar5 < 1) {
                    return 0;
                }
            }
            *(undefined4 *)(iVar7 + 0x2d0) = 1;
            return 1;
        }
        break;
    case 0x13:
        if ((*(int32_t *)(iVar7 + 0x2d0) != 0) && (*(int32_t *)(iVar7 + 0xf8) != 0)) {
            iVar5 = *(int32_t *)(iVar7 + 0x2c8);
            uVar3 = *(undefined8 *)(iVar7 + 0x2c0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180217209;
            func_0x000180286d70(iVar7 + 0x100, uVar3, (int64_t)iVar5);
            iVar5 = *(int32_t *)(iVar7 + 0x2c8);
            if ((in_R8D < 1) || (iVar5 < in_R8D)) {
                in_R8D = iVar5;
            }
            iVar11 = *(int64_t *)(iVar7 + 0x2c0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180217232;
            func_0x000180498030(in_R9, ((int64_t)iVar5 - (int64_t)in_R8D) + iVar11);
            iVar5 = *(int32_t *)(iVar7 + 0x2c8);
            iVar6 = *(int64_t *)(iVar7 + 0x2c0);
            iVar11 = 8;
            do {
                iVar10 = iVar11 + -1;
                pcVar1 = (char *)(iVar11 + -9 + iVar5 + iVar6);
                *pcVar1 = *pcVar1 + '\x01';
                if (*pcVar1 != '\0') break;
                iVar11 = iVar10;
            } while (iVar10 != 0);
            *(undefined4 *)(iVar7 + 0xfc) = 1;
            return 1;
        }
        break;
    case 0x16:
        if (in_R8D == 0xd) {
            in_RCX[7] = *in_R9;
            *(undefined4 *)(in_RCX + 8) = *(undefined4 *)(in_R9 + 1);
            *(undefined *)((int64_t)in_RCX + 0x44) = *(undefined *)((int64_t)in_R9 + 0xc);
            *(undefined4 *)(iVar7 + 0x2d8) = 0xd;
            *(undefined8 *)(iVar7 + 0x2e0) = 0;
            uVar8 = (uint32_t)
                    CONCAT11(*(undefined *)((int64_t)in_RCX + iVar11 + 0x36), 
                             *(undefined *)((int64_t)in_RCX + iVar11 + 0x37));
            if (7 < uVar8) {
                uVar9 = uVar8 - 8;
                if (*(int32_t *)(in_RCX + 2) == 0) {
                    if (uVar9 < 0x10) {
                        return 0;
                    }
                    uVar9 = uVar8 - 0x18;
                }
                *(char *)((int64_t)in_RCX + iVar11 + 0x37) = (char)uVar9;
                *(char *)((int64_t)in_RCX + iVar11 + 0x36) = (char)(uVar9 >> 8);
                return 0x10;
            }
        }
        break;
    case 0x18:
        if (((*(int32_t *)(iVar7 + 0x2d0) != 0) && (*(int32_t *)(iVar7 + 0xf8) != 0)) && (*(int32_t *)(in_RCX + 2) == 0)
           ) {
            iVar5 = *(int32_t *)(iVar7 + 0x2c8);
            iVar10 = *(int64_t *)(iVar7 + 0x2c0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802172a8;
            func_0x000180498030((iVar5 - iVar11) + iVar10, in_R9, iVar11);
            iVar5 = *(int32_t *)(iVar7 + 0x2c8);
            uVar3 = *(undefined8 *)(iVar7 + 0x2c0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802172c2;
            func_0x000180286d70(iVar7 + 0x100, uVar3, (int64_t)iVar5);
            *(undefined4 *)(iVar7 + 0xfc) = 1;
            return 1;
        }
        break;
    case 0x25:
        *(undefined4 *)in_R9 = *(undefined4 *)(iVar7 + 0x2c8);
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180217450
// Address: 0x180217450
// Size: 346 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180217450(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021746a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021747b;
    iVar4 = fcn.18020e970();
    if (in_R8 == 0) {
        if (in_RDX == 0) {
            return 1;
        }
    } else if (in_RDX == 0) {
        iVar2 = *(int32_t *)(iVar4 + 0x2c8);
        if (*(int32_t *)(iVar4 + 0xf8) == 0) {
            uVar1 = *(undefined8 *)(iVar4 + 0x2c0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021757c;
            func_0x000180498030(uVar1, in_R8, (int64_t)iVar2);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021756e;
            func_0x000180286d70(iVar4 + 0x100);
        }
        *(undefined4 *)(iVar4 + 0xfc) = 1;
        *(undefined4 *)(iVar4 + 0x2d0) = 0;
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021749f;
    iVar2 = func_0x00018020eae0(in_RCX);
    if (0 < iVar2 << 3) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802174e9;
        func_0x0001802830c0(in_RDX, iVar2 << 3, iVar4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802174ff;
        func_0x000180286a30(iVar4 + 0x100, iVar4, 0x180282850);
        *(undefined8 *)(iVar4 + 0x2e8) = 0;
        if ((in_R8 != 0) || ((*(int32_t *)(iVar4 + 0xfc) != 0 && (in_R8 = *(int64_t *)(iVar4 + 0x2c0), in_R8 != 0)))) {
            iVar2 = *(int32_t *)(iVar4 + 0x2c8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180217539;
            func_0x000180286d70(iVar4 + 0x100, in_R8, (int64_t)iVar2);
            *(undefined4 *)(iVar4 + 0xfc) = 1;
        }
        *(undefined4 *)(iVar4 + 0xf8) = 1;
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802174ab;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802174c3;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802174d5;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1802175b0
// Address: 0x1802175b0
// Size: 401 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1802175b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 uVar6;
    undefined8 in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802175ce;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802175e2;
    iVar4 = fcn.18020e970();
    if (*(int32_t *)(iVar4 + 0xf8) != 0) {
        if (-1 < *(int32_t *)(iVar4 + 0x2d8)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18021760c;
            uVar5 = func_0x000180218ee0(in_RCX, in_RDX, in_R8, in_R9);
            return uVar5;
        }
        if (*(int32_t *)(iVar4 + 0xfc) != 0) {
            if (in_R8 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802176b6;
                iVar2 = fcn.1802007d0(in_RCX);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802176f6;
                    uVar6 = func_0x00018020e930(in_RCX);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18021770b;
                    func_0x000180286fa0(iVar4 + 0x100, uVar6, 0x10);
                    *(undefined4 *)(iVar4 + 0x2cc) = 0x10;
                    *(undefined4 *)(iVar4 + 0xfc) = 0;
                    return 0;
                }
                iVar2 = *(int32_t *)(iVar4 + 0x2cc);
                if (-1 < iVar2) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802176d0;
                    uVar6 = func_0x00018020e930(in_RCX);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802176e2;
                    uVar5 = func_0x000180286830(iVar4 + 0x100, uVar6, (int64_t)iVar2);
                    if ((int32_t)uVar5 == 0) {
                        *(undefined4 *)(iVar4 + 0xfc) = 0;
                        return uVar5;
                    }
                }
            } else {
                if (in_RDX == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18021763e;
                    iVar2 = func_0x000180285790(iVar4 + 0x100, in_R8, in_R9);
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180217648;
                    iVar2 = fcn.1802007d0(in_RCX);
                    iVar1 = *(int64_t *)(iVar4 + 0x2e8);
                    if (iVar2 == 0) {
                        if (iVar1 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802176a6;
                            iVar2 = func_0x0001802858c0(iVar4 + 0x100, in_R8, in_RDX, in_R9);
                        } else {
                            *(int64_t *)((int64_t)&var_8h + iVar3) = iVar1;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180217698;
                            iVar2 = func_0x000180285cf0(iVar4 + 0x100);
                        }
                    } else if (iVar1 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180217680;
                        iVar2 = func_0x000180286050(iVar4 + 0x100);
                    } else {
                        *(int64_t *)((int64_t)&var_8h + iVar3) = iVar1;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180217672;
                        iVar2 = func_0x0001802864d0(iVar4 + 0x100);
                    }
                }
                if (iVar2 == 0) {
                    return in_R9 & 0xffffffff;
                }
            }
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180217750
// Address: 0x180217750
// Size: 197 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180217750(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t in_EDX;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180217765;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180217772;
    iVar2 = fcn.18020e970();
    if (in_EDX == 8) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180217782;
        iVar1 = fcn.18020e970(in_R9);
        if (*(int64_t *)(iVar2 + 0x1f0) != 0) {
            if (*(int64_t *)(iVar2 + 0x1f0) != iVar2) {
                return 0;
            }
            *(int64_t *)(iVar1 + 0x1f0) = iVar1;
        }
        if (*(int64_t *)(iVar2 + 0x1f8) != 0) {
            if (*(int64_t *)(iVar2 + 0x1f8) != iVar2 + 0xf8) {
                return 0;
            }
            *(int64_t *)(iVar1 + 0x1f8) = iVar1 + 0xf8;
        }
    } else {
        if (in_EDX != 0) {
            return 0xffffffff;
        }
        *(undefined8 *)(iVar2 + 0x1f0) = 0;
        *(undefined8 *)(iVar2 + 0x1f8) = 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_180217820
// Address: 0x180217820
// Size: 416 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180217820(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined4 *in_R8;
    int32_t in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180217842;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180217856;
    iVar8 = fcn.18020e970();
    if (in_R8 == (undefined4 *)0x0) {
        if (in_RDX == 0) {
            return 1;
        }
    } else if (in_RDX == 0) goto code_r0x00018021798e;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18021787a;
    iVar6 = func_0x00018020eae0(in_RCX);
    iVar2 = (iVar6 / 2) * 8;
    if (iVar6 < 1) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180217892;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802178aa;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                      *(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7));
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802178bc;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar7));
        return 0;
    }
    iVar1 = iVar6 / 2 + in_RDX;
    if (in_R9D == 0) {
        *(undefined8 *)(iVar8 + 0x210) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18021794f;
        func_0x000180282e50(in_RDX, iVar2, iVar8);
        uVar9 = 0x180282270;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802178e1;
        iVar6 = func_0x0001802262e0(in_RDX, iVar1);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802178ea;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180217902;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                          *(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7));
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180217914;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar7));
            return 0;
        }
        *(undefined8 *)(iVar8 + 0x210) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180217934;
        func_0x0001802830c0(in_RDX, iVar2, iVar8);
        uVar9 = 0x180282850;
    }
    *(undefined8 *)(iVar8 + 0x200) = uVar9;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180217972;
    func_0x0001802830c0(iVar1, iVar2, iVar8 + 0xf8);
    *(undefined8 *)(iVar8 + 0x208) = 0x180282850;
    *(int64_t *)(iVar8 + 0x1f0) = iVar8;
    if (in_R8 == (undefined4 *)0x0) {
        return 1;
    }
code_r0x00018021798e:
    *(int64_t *)(iVar8 + 0x1f8) = iVar8 + 0xf8;
    uVar3 = in_R8[1];
    uVar4 = in_R8[2];
    uVar5 = in_R8[3];
    *(undefined4 *)(in_RCX + 0x28) = *in_R8;
    *(undefined4 *)(in_RCX + 0x2c) = uVar3;
    *(undefined4 *)(in_RCX + 0x30) = uVar4;
    *(undefined4 *)(in_RCX + 0x34) = uVar5;
    return 1;
}

// ============================================================
// Function: FUN_1802179c0
// Address: 0x1802179c0
// Size: 269 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch

undefined8 fcn.1802179c0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802179de;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802179f2;
    iVar7 = fcn.18020e970();
    iVar1 = *(int64_t *)(iVar7 + 0x1f0);
    if ((((iVar1 != 0) && (iVar2 = *(int64_t *)(iVar7 + 0x1f8), iVar2 != 0)) && (in_RDX != 0)) &&
       ((in_R8 != 0 && (0xf < in_R9)))) {
        if (in_R9 < 0x1000001) {
            pcVar3 = *(code **)(iVar7 + 0x210);
            if (pcVar3 != (code *)0x0) {
                *(int64_t *)((int64_t)&var_10h + iVar6) = in_RCX + 0x28;
                *(int64_t *)((int64_t)&var_8h + iVar6) = iVar2;
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180217a99;
                (*pcVar3)(in_R8, in_RDX, in_R9, iVar1);
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180217aa8;
            uVar4 = fcn.1802007d0(in_RCX);
            *(undefined4 *)((int64_t)&var_10h + iVar6) = uVar4;
            *(uint64_t *)((int64_t)&var_8h + iVar6) = in_R9;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180217ac2;
            iVar5 = fcn.180288640(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6));
            if (iVar5 == 0) {
                return 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180217a2b;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180217a43;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180217a55;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar6));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180217ad0
// Address: 0x180217ad0
// Size: 722 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined4 fcn.180217ad0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined4 in_EDX;
    uint16_t uVar8;
    uint64_t uVar9;
    int32_t in_R8D;
    undefined8 *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180217af0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar9 = (uint64_t)in_R8D;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180217b04;
    iVar4 = fcn.18020e970();
    // switch table (38 cases) at 0x180217d54
    switch(in_EDX) {
    case 0:
        *(undefined4 *)(iVar4 + 0x108) = 8;
        *(undefined8 *)(iVar4 + 0xf8) = 0;
        *(undefined8 *)(iVar4 + 0x100) = 0;
        *(undefined4 *)(iVar4 + 0x10c) = 0xc;
        *(undefined4 *)(iVar4 + 0x110) = 0xffffffff;
        return 1;
    default:
        return 0xffffffff;
    case 8:
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180217d0e;
        iVar3 = fcn.18020e970(in_R9);
        if (*(int64_t *)(iVar4 + 0x148) != 0) {
            if (*(int64_t *)(iVar4 + 0x148) != iVar4) {
                return 0;
            }
            *(int64_t *)(iVar3 + 0x148) = iVar3;
        }
        return 1;
    case 9:
        in_R8D = 0xf - in_R8D;
    case 0x14:
        if (in_R8D - 2U < 7) {
            *(int32_t *)(iVar4 + 0x108) = in_R8D;
            return 1;
        }
        break;
    case 0x10:
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180217ccc;
        iVar2 = fcn.1802007d0(in_RCX);
        if ((iVar2 != 0) && (*(int32_t *)(iVar4 + 0x100) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180217ceb;
            iVar3 = func_0x0001802885f0(iVar4 + 0x118, in_R9, uVar9);
            if (iVar3 != 0) {
                *(undefined8 *)(iVar4 + 0xfc) = 0;
                *(undefined4 *)(iVar4 + 0x104) = 0;
                return 1;
            }
        }
        break;
    case 0x11:
        if (((uVar9 & 1) == 0) && (in_R8D - 4U < 0xd)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180217c8a;
            iVar2 = fcn.1802007d0(in_RCX);
            if (in_R9 != (undefined8 *)0x0) {
                if (iVar2 != 0) {
                    return 0;
                }
                *(undefined4 *)(iVar4 + 0x100) = 1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180217ca9;
                uVar7 = func_0x00018020e930(in_RCX);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180217cb7;
                func_0x000180498030(uVar7, in_R9, uVar9);
            }
            *(int32_t *)(iVar4 + 0x10c) = in_R8D;
            return 1;
        }
        break;
    case 0x12:
        if (in_R8D == 4) {
            *(undefined4 *)(in_RCX + 0x28) = *(undefined4 *)in_R9;
            return 1;
        }
        break;
    case 0x16:
        if (in_R8D == 0xd) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180217b8e;
            puVar5 = (undefined8 *)func_0x00018020e930(in_RCX);
            *puVar5 = *in_R9;
            *(undefined4 *)(puVar5 + 1) = *(undefined4 *)(in_R9 + 1);
            *(undefined *)((int64_t)puVar5 + 0xc) = *(undefined *)((int64_t)in_R9 + 0xc);
            *(undefined4 *)(iVar4 + 0x110) = 0xd;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180217bb7;
            iVar6 = func_0x00018020e930(in_RCX);
            uVar1 = *(undefined *)(iVar6 + -2 + uVar9);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180217bc8;
            iVar6 = func_0x00018020e930(in_RCX);
            uVar8 = CONCAT11(uVar1, *(undefined *)(iVar6 + -1 + uVar9));
            if (7 < uVar8) {
                uVar8 = uVar8 - 8;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180217bea;
                iVar2 = fcn.1802007d0(in_RCX);
                if (iVar2 == 0) {
                    if ((int32_t)(uint32_t)uVar8 < *(int32_t *)(iVar4 + 0x10c)) {
                        return 0;
                    }
                    uVar8 = uVar8 - (int16_t)*(int32_t *)(iVar4 + 0x10c);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180217c11;
                iVar6 = func_0x00018020e930(in_RCX);
                *(char *)(iVar6 + -2 + uVar9) = (char)(uVar8 >> 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180217c1e;
                iVar3 = func_0x00018020e930(in_RCX);
                *(char *)(iVar3 + -1 + uVar9) = (char)uVar8;
                return *(undefined4 *)(iVar4 + 0x10c);
            }
        }
        break;
    case 0x25:
        *(int32_t *)in_R9 = 0xf - *(int32_t *)(iVar4 + 0x108);
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180217db0
// Address: 0x180217db0
// Size: 278 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180217db0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180217dca;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180217ddb;
    iVar5 = fcn.18020e970();
    if (in_R8 == 0) {
        if (in_RDX == 0) {
            return 1;
        }
    } else if (in_RDX == 0) goto code_r0x000180217e88;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180217dff;
    iVar3 = func_0x00018020eae0(in_RCX);
    if (iVar3 << 3 < 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180217e0b;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180217e23;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180217e35;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180217e46;
    func_0x0001802830c0(in_RDX, iVar3 << 3, iVar5);
    uVar1 = *(undefined4 *)(iVar5 + 0x108);
    uVar2 = *(undefined4 *)(iVar5 + 0x10c);
    *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + -8) = 0x180282850;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180217e6e;
    func_0x000180288500(iVar5 + 0x118, uVar2, uVar1, iVar5);
    *(undefined8 *)(iVar5 + 0x150) = 0;
    *(undefined4 *)(iVar5 + 0xf8) = 1;
    if (in_R8 == 0) {
        return 1;
    }
code_r0x000180217e88:
    iVar3 = *(int32_t *)(iVar5 + 0x108);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180217ea2;
    func_0x000180498030(in_RCX + 0x28, in_R8, (int64_t)(0xf - iVar3));
    *(undefined4 *)(iVar5 + 0xfc) = 1;
    return 1;
}

// ============================================================
// Function: FUN_180217ed0
// Address: 0x180217ed0
// Size: 584 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180217ed0(int64_t param_1, int64_t param_2, int64_t param_3, int64_t param_4)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t var_8h;
    undefined8 uStack_40;
    int64_t var_18h;
    
    uStack_40 = 0x180217ee5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&var_8h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar3);
    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180217f08;
    iVar4 = fcn.18020e970();
    iVar5 = iVar4 + 0x118;
    if (*(int32_t *)(iVar4 + 0xf8) == 0) goto code_r0x0001802180fc;
    if (-1 < *(int32_t *)(iVar4 + 0x110)) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180217f39;
        func_0x000180218d10(param_1, param_2, param_3, param_4);
        goto code_r0x0001802180fc;
    }
    if (((param_3 == 0) && (param_2 != 0)) || (*(int32_t *)(iVar4 + 0xfc) == 0)) goto code_r0x0001802180fc;
    if (param_2 == 0) {
        if (param_3 == 0) {
            iVar2 = *(int32_t *)(iVar4 + 0x108);
            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180217f83;
            iVar2 = func_0x000180288540(iVar5, param_1 + 0x28, (int64_t)(0xf - iVar2), param_4);
            if (iVar2 == 0) {
                *(undefined4 *)(iVar4 + 0x104) = 1;
            }
        } else if ((*(int32_t *)(iVar4 + 0x104) != 0) || (param_4 == 0)) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180217fbc;
            func_0x000180287890(iVar5, param_3, param_4);
        }
        goto code_r0x0001802180fc;
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180217fcb;
    iVar2 = fcn.1802007d0(param_1);
    if ((iVar2 == 0) && (*(int32_t *)(iVar4 + 0x100) == 0)) goto code_r0x0001802180fc;
    if (*(int32_t *)(iVar4 + 0x104) == 0) {
        iVar2 = *(int32_t *)(iVar4 + 0x108);
        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180218001;
        iVar2 = func_0x000180288540(iVar5, param_1 + 0x28, (int64_t)(0xf - iVar2), param_4);
        if (iVar2 != 0) goto code_r0x0001802180fc;
        *(undefined4 *)(iVar4 + 0x104) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18021801b;
    iVar2 = fcn.1802007d0(param_1);
    iVar1 = *(int64_t *)(iVar4 + 0x150);
    if (iVar2 != 0) {
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18021804b;
            iVar2 = func_0x000180287e20(iVar5);
        } else {
            *(int64_t *)((int64_t)&var_18h + iVar3) = iVar1;
            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180218041;
            iVar2 = func_0x000180288170(iVar5);
        }
        if (iVar2 == 0) {
            *(undefined4 *)(iVar4 + 0x100) = 1;
        }
        goto code_r0x0001802180fc;
    }
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180218085;
        iVar2 = func_0x000180287a20(iVar5, param_3, param_2, param_4);
    } else {
        *(int64_t *)((int64_t)&var_18h + iVar3) = iVar1;
        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18021807b;
        iVar2 = func_0x000180287c00(iVar5);
    }
    if (iVar2 == 0) {
        iVar2 = *(int32_t *)(iVar4 + 0x10c);
        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x1802180a4;
        iVar5 = func_0x0001802885f0(iVar5, &stack0xfffffffffffffff8 + iVar3, (int64_t)iVar2);
        if (iVar5 == 0) goto code_r0x0001802180d3;
        iVar2 = *(int32_t *)(iVar4 + 0x10c);
        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x1802180b8;
        uVar6 = func_0x00018020e930(param_1);
        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x1802180c8;
        iVar2 = func_0x0001802262e0(&stack0xfffffffffffffff8 + iVar3, uVar6, (int64_t)iVar2);
        if ((iVar2 != 0) || ((int32_t)param_4 == -1)) goto code_r0x0001802180d3;
    } else {
code_r0x0001802180d3:
        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x1802180de;
        fcn.180244fc0(param_2, param_4);
    }
    *(undefined8 *)(iVar4 + 0xfc) = 0;
    *(undefined4 *)(iVar4 + 0x104) = 0;
code_r0x0001802180fc:
    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180218109;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_8h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_180218120
// Address: 0x180218120
// Size: 252 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180218120(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180218140;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180218151;
    iVar4 = fcn.18020e970();
    if (in_R8 == 0) {
        if (in_RDX == 0) {
            return 1;
        }
code_r0x000180218168:
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180218170;
        iVar1 = func_0x00018020eae0(in_RCX);
        if (iVar1 << 3 < 1) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021817e;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180218196;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802181a8;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802181b4;
        iVar2 = fcn.1802007d0(in_RCX);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802181cc;
            func_0x000180282e50(in_RDX, iVar1 << 3, iVar4);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802181c5;
            func_0x0001802830c0();
        }
        if (in_R8 == 0) {
            in_RCX = 0;
            goto code_r0x0001802181f3;
        }
    } else if (in_RDX != 0) goto code_r0x000180218168;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802181dd;
    iVar1 = func_0x00018020e980(in_RCX);
    if (iVar1 < 0) {
        return 0;
    }
    in_RCX = in_RCX + 0x28;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802181f3;
    func_0x000180498030(in_RCX, in_R8, (int64_t)iVar1);
code_r0x0001802181f3:
    *(int64_t *)(iVar4 + 0xf8) = in_RCX;
    return 1;
}

// ============================================================
// Function: FUN_180218220
// Address: 0x180218220
// Size: 457 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180218220(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined8 in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021823e;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180218252;
    iVar5 = fcn.18020e970();
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021825d;
    iVar2 = func_0x00018020e980(in_RCX);
    if (in_R8 == 0) {
code_r0x0001802182f6:
        uVar6 = 0;
    } else {
        if (in_R9 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180218275;
            iVar3 = fcn.1802007d0(in_RCX);
            if (((iVar3 != 0) || ((0xf < in_R9 && ((in_R9 & 7) == 0)))) && ((iVar2 == 4 || ((in_R9 & 7) == 0)))) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802182c3;
                iVar3 = func_0x000180214190(in_RDX, in_R8, in_R9 & 0xffffffff);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180218302;
                    iVar3 = fcn.1802007d0(in_RCX);
                    if (in_RDX == 0) {
                        if (iVar3 != 0) {
                            if (iVar2 == 4) {
                                in_R9 = in_R9 + 7 & 0xfffffffffffffff8;
                            }
                            return (uint64_t)((int32_t)in_R9 + 8);
                        }
                        return (uint64_t)((int32_t)in_R9 - 8);
                    }
                    uVar1 = *(undefined8 *)(iVar5 + 0xf8);
                    if (iVar2 == 4) {
                        if (iVar3 == 0) {
                            *(undefined8 *)((int64_t)&var_10h + iVar4) = 0x180282270;
                            *(uint64_t *)((int64_t)&var_8h + iVar4) = in_R9;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180218380;
                            uVar6 = func_0x000180288970();
                            if (uVar6 == 0) {
                                return 0xffffffff;
                            }
                            return uVar6 & 0xffffffff;
                        }
                        *(undefined8 *)((int64_t)&var_10h + iVar4) = 0x180282850;
                        *(uint64_t *)((int64_t)&var_8h + iVar4) = in_R9;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180218357;
                        uVar6 = func_0x000180288c50();
                        if (uVar6 == 0) {
                            return 0xffffffff;
                        }
                        return uVar6 & 0xffffffff;
                    }
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&var_10h + iVar4) = 0x180282270;
                        *(uint64_t *)((int64_t)&var_8h + iVar4) = in_R9;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802183d6;
                        uVar6 = func_0x0001802888d0(iVar5, uVar1, in_RDX, in_R8);
                        if (uVar6 == 0) {
                            return 0xffffffff;
                        }
                        return uVar6 & 0xffffffff;
                    }
                    *(undefined8 *)((int64_t)&var_10h + iVar4) = 0x180282850;
                    *(uint64_t *)((int64_t)&var_8h + iVar4) = in_R9;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802183ad;
                    uVar6 = func_0x000180288ae0();
                    if (uVar6 == 0) {
                        return 0xffffffff;
                    }
                    return uVar6 & 0xffffffff;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802182cc;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802182e4;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802182f6;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar4));
                goto code_r0x0001802182f6;
            }
        }
        uVar6 = 0xffffffff;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1802183f0
// Address: 0x1802183f0
// Size: 458 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1802183f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 *in_RCX;
    undefined4 in_EDX;
    uint32_t in_R8D;
    undefined4 *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180218410;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180218424;
    iVar4 = fcn.18020e970();
    // switch table (38 cases) at 0x180218578
    switch(in_EDX) {
    case 0:
        *(undefined8 *)(iVar4 + 0x1f0) = 0;
        uVar6 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021845e;
        uVar1 = func_0x00018020ef90(uVar6);
        *(undefined4 *)(iVar4 + 0x2e8) = uVar1;
        *(undefined8 **)(iVar4 + 0x2a8) = in_RCX + 5;
        uVar6 = 1;
        *(undefined4 *)(iVar4 + 0x2ec) = 0x10;
        *(undefined8 *)(iVar4 + 0x2e0) = 0;
        break;
    default:
        uVar6 = 0xffffffff;
        break;
    case 8:
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180218538;
        iVar5 = fcn.18020e970(in_R9);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180218555;
        uVar6 = func_0x0001802891b0(iVar5 + 0x1f8, iVar4 + 0x1f8, iVar5, iVar5 + 0xf8);
        break;
    case 9:
        if (in_R8D - 1 < 0xf) {
            *(uint32_t *)(iVar4 + 0x2e8) = in_R8D;
            return 1;
        }
        goto code_r0x00018021852c;
    case 0x10:
        if (in_R8D == *(uint32_t *)(iVar4 + 0x2ec)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021850f;
            iVar2 = fcn.1802007d0(in_RCX);
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180218525;
                func_0x000180498030(in_R9, iVar4 + 0x2b0, (int64_t)(int32_t)in_R8D);
                return 1;
            }
        }
        goto code_r0x00018021852c;
    case 0x11:
        if (in_R9 == (undefined4 *)0x0) {
            if (in_R8D < 0x11) {
                *(uint32_t *)(iVar4 + 0x2ec) = in_R8D;
                return 1;
            }
        } else if (in_R8D == *(uint32_t *)(iVar4 + 0x2ec)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802184e2;
            iVar2 = fcn.1802007d0(in_RCX);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802184f8;
                func_0x000180498030(iVar4 + 0x2b0, in_R9, (int64_t)(int32_t)in_R8D);
                return 1;
            }
        }
code_r0x00018021852c:
        uVar6 = 0;
        break;
    case 0x25:
        *in_R9 = *(undefined4 *)(iVar4 + 0x2e8);
        uVar6 = 1;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1802185c0
// Address: 0x1802185c0
// Size: 407 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1802185c0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802185e0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802185f1;
    iVar5 = fcn.18020e970();
    if (in_R8 == 0) {
        if (in_RDX == 0) {
            return 1;
        }
    } else if (in_RDX == 0) {
        iVar3 = *(int32_t *)(iVar5 + 0x2e8);
        if (*(int32_t *)(iVar5 + 0x1f0) == 0) {
            uVar2 = *(undefined8 *)(iVar5 + 0x2a8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021872d;
            func_0x000180498030(uVar2, in_R8, (int64_t)iVar3);
        } else {
            iVar1 = *(int32_t *)(iVar5 + 0x2ec);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021871f;
            func_0x0001802898e0(iVar5 + 0x1f8, in_R8, (int64_t)iVar3, (int64_t)iVar1);
        }
        *(undefined4 *)(iVar5 + 500) = 1;
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180218615;
    iVar3 = func_0x00018020eae0(in_RCX);
    if (iVar3 << 3 < 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180218623;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021863b;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18021864d;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180218661;
        func_0x0001802830c0(in_RDX, iVar3 << 3, iVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180218672;
        func_0x000180282e50(in_RDX, iVar3 << 3, iVar5 + 0xf8);
        *(undefined8 *)((int64_t)&var_20h + iVar4) = 0;
        *(undefined8 *)((int64_t)&var_18h + iVar4) = 0x180282270;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802186a4;
        iVar3 = func_0x000180289740(iVar5 + 0x1f8, iVar5, iVar5 + 0xf8, 0x180282850);
        if (iVar3 != 0) {
            if ((in_R8 != 0) || ((*(int32_t *)(iVar5 + 500) != 0 && (in_R8 = *(int64_t *)(iVar5 + 0x2a8), in_R8 != 0))))
            {
                iVar3 = *(int32_t *)(iVar5 + 0x2ec);
                iVar1 = *(int32_t *)(iVar5 + 0x2e8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802186de;
                iVar3 = func_0x0001802898e0(iVar5 + 0x1f8, in_R8, (int64_t)iVar1, (int64_t)iVar3);
                if (iVar3 != 1) {
                    return 0;
                }
                *(undefined4 *)(iVar5 + 500) = 1;
            }
            *(undefined4 *)(iVar5 + 0x1f0) = 1;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180218760
// Address: 0x180218760
// Size: 790 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int32_t fcn.180218760(int64_t arg1, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RDX;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t in_R8;
    uint64_t in_R9;
    uint32_t *puVar8;
    bool bVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    uint64_t uVar7;
    
    uStack_30 = 0x180218787;
    var_8h = arg1;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar1 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802187a0;
    iVar4 = fcn.18020e970();
    if ((*(int32_t *)(iVar4 + 500) != 0) && (*(int32_t *)(iVar4 + 0x1f0) != 0)) {
        if (in_R8 != 0) {
            if (in_RDX == 0) {
                iVar5 = iVar4 + 0x2d0;
                *(int64_t *)(&stack0xfffffffffffffff8 + iVar3) = iVar5;
                puVar8 = (uint32_t *)(iVar4 + 0x2e4);
            } else {
                puVar8 = (uint32_t *)(iVar4 + 0x2e0);
                uVar6 = *puVar8;
                *(int64_t *)(&stack0xfffffffffffffff8 + iVar3) = iVar4 + 0x2c0;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180218805;
                iVar2 = func_0x000180214190((int32_t)uVar6 + in_RDX, in_R8, in_R9 & 0xffffffff);
                if (iVar2 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021880e;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3)
                                 );
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180218826;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), *(int64_t *)(&stack0x00000000 + iVar3)
                                  , *(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&var_10h + iVar3), 
                                  *(int64_t *)(&stack0x00000028 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180218838;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar3));
                    return 0;
                }
                iVar5 = iVar4 + 0x2c0;
            }
            uVar6 = *puVar8;
            if (0 < (int32_t)uVar6) {
                uVar7 = (uint64_t)(0x10 - uVar6);
                if (in_R9 < uVar7) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021886e;
                    func_0x000180498030((int32_t)uVar6 + iVar5, in_R8, in_R9);
                    *puVar8 = *puVar8 + (int32_t)in_R9;
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180218881;
                func_0x000180498030((int32_t)uVar6 + iVar5, in_R8, uVar7);
                in_R9 = in_R9 - uVar7;
                in_R8 = in_R8 + uVar7;
                if (in_RDX == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802188a3;
                    iVar1 = func_0x000180288fd0(iVar4 + 0x1f8, *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3), 0x10);
                    if (iVar1 == 0) {
                        return -1;
                    }
                    *puVar8 = 0;
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802188bb;
                    iVar1 = fcn.1802007d0(*(undefined8 *)((int64_t)&arg_38h + iVar3));
                    if (iVar1 == 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802188e0;
                        iVar1 = func_0x0001802892a0(iVar4 + 0x1f8, *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3), 
                                                    in_RDX, 0x10);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802188d9;
                        iVar1 = func_0x0001802894e0();
                    }
                    if (iVar1 == 0) {
                        return -1;
                    }
                    in_RDX = in_RDX + 0x10;
                    *puVar8 = 0;
                }
                iVar1 = 0x10;
            }
            uVar6 = (uint32_t)in_R9 & 0xf;
            uVar7 = (uint64_t)uVar6;
            if (in_R9 != uVar7) {
                if (in_RDX == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180218922;
                    iVar2 = func_0x000180288fd0(iVar4 + 0x1f8, in_R8, in_R9 - uVar7);
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021892e;
                    iVar2 = fcn.1802007d0(*(undefined8 *)((int64_t)&arg_38h + iVar3));
                    if (iVar2 == 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021894a;
                        iVar2 = func_0x0001802892a0(iVar4 + 0x1f8, in_R8, in_RDX, in_R9 - uVar7);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180218943;
                        iVar2 = func_0x0001802894e0();
                    }
                }
                if (iVar2 == 0) {
                    return -1;
                }
                iVar1 = iVar1 + ((uint32_t)in_R9 - uVar6);
                in_R8 = in_R8 + (in_R9 - uVar7);
            }
            if (uVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180218976;
                func_0x000180498030(*(undefined8 *)(&stack0xfffffffffffffff8 + iVar3), in_R8, uVar7);
                *puVar8 = uVar6;
                return iVar1;
            }
            return iVar1;
        }
        if (0 < *(int32_t *)(iVar4 + 0x2e0)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180218992;
            iVar2 = fcn.1802007d0(arg1);
            iVar1 = *(int32_t *)(iVar4 + 0x2e0);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802189ba;
                iVar1 = func_0x0001802892a0(iVar4 + 0x1f8, iVar4 + 0x2c0, in_RDX, (int64_t)iVar1);
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802189b3;
                iVar1 = func_0x0001802894e0();
            }
            if (iVar1 == 0) {
                return -1;
            }
            iVar1 = *(int32_t *)(iVar4 + 0x2e0);
            *(undefined4 *)(iVar4 + 0x2e0) = 0;
        }
        iVar2 = *(int32_t *)(iVar4 + 0x2e4);
        if (0 < iVar2) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802189f0;
            iVar2 = func_0x000180288fd0(iVar4 + 0x1f8, iVar4 + 0x2d0, (int64_t)iVar2);
            if (iVar2 == 0) {
                return -1;
            }
            *(undefined4 *)(iVar4 + 0x2e4) = 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180218a02;
        iVar2 = fcn.1802007d0(arg1);
        if (iVar2 == 0) {
            iVar2 = *(int32_t *)(iVar4 + 0x2ec);
            if (iVar2 < 0) {
                return -1;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180218a27;
            iVar2 = func_0x000180289720(iVar4 + 0x1f8, iVar4 + 0x2b0, (int64_t)iVar2);
            bVar9 = iVar2 == 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180218a44;
            iVar2 = func_0x000180289ac0(iVar4 + 0x1f8, iVar4 + 0x2b0, 0x10);
            bVar9 = iVar2 == 1;
        }
        if (bVar9) {
            *(undefined4 *)(iVar4 + 500) = 0;
            return iVar1;
        }
    }
    return -1;
}

// ============================================================
// Function: FUN_180218a80
// Address: 0x180218a80
// Size: 40 bytes
// ============================================================
undefined8 fcn.180218a80(void)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x180218a8a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 + -iVar1) = 0x180218a92;
    iVar2 = fcn.18020e970();
    *(undefined8 *)((int64_t)&uStack_8 + -iVar1) = 0x180218a9e;
    fcn.180289160(iVar2 + 0x1f8);
    return 1;
}

// ============================================================
// Function: FUN_180218d10
// Address: 0x180218d10
// Size: 178 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_10ch because it doesn't fit into ProtoModel

void fcn.180218d10(int64_t arg_150h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar8;
    undefined8 *in_R8;
    uint64_t in_R9;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_38;
    
    uStack_38 = 0x180218d24;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&var_10h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar3);
    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218d47;
    iVar4 = fcn.18020e970();
    iVar7 = iVar4 + 0x118;
    if ((in_RDX == in_R8) && ((int64_t)*(int32_t *)(iVar4 + 0x10c) + 8U <= in_R9)) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218d76;
        iVar2 = fcn.1802007d0(in_RCX);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218d82;
            puVar5 = (undefined8 *)func_0x00018020e930(in_RCX);
            *in_RDX = *puVar5;
        }
        *(undefined8 *)(in_RCX + 0x2c) = *in_R8;
        iVar8 = in_R9 - (int64_t)(*(int32_t *)(iVar4 + 0x10c) + 8);
        iVar2 = *(int32_t *)(iVar4 + 0x108);
        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218dba;
        iVar2 = func_0x000180288540(iVar7, in_RCX + 0x28, (int64_t)(0xf - iVar2), iVar8);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RBX;
            iVar2 = *(int32_t *)(iVar4 + 0x110);
            *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218dd6;
            uVar6 = func_0x00018020e930(in_RCX);
            *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218de4;
            func_0x000180287890(iVar7, uVar6, (int64_t)iVar2);
            in_RDX = in_RDX + 1;
            *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218df4;
            iVar2 = fcn.1802007d0(in_RCX);
            iVar1 = *(int64_t *)(iVar4 + 0x150);
            if (iVar2 == 0) {
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218e72;
                    iVar2 = func_0x000180287a20(iVar7, in_R8 + 1, in_RDX, iVar8);
                } else {
                    *(int64_t *)(&stack0xfffffffffffffff0 + iVar3) = iVar1;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218e68;
                    iVar2 = func_0x000180287c00(iVar7);
                }
                if (iVar2 == 0) {
                    iVar2 = *(int32_t *)(iVar4 + 0x10c);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218e91;
                    iVar7 = func_0x0001802885f0(iVar7, (int64_t)&stack0x00000000 + iVar3, (int64_t)iVar2);
                    if (iVar7 != 0) {
                        iVar2 = *(int32_t *)(iVar4 + 0x10c);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218eab;
                        iVar2 = func_0x0001802262e0((int64_t)&stack0x00000000 + iVar3, iVar8 + (int64_t)(in_R8 + 1), 
                                                    (int64_t)iVar2);
                        if (iVar2 == 0) goto code_r0x000180218ec3;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218ebe;
                fcn.180244fc0(in_RDX, iVar8);
            } else {
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218e29;
                    iVar2 = func_0x000180287e20(iVar7);
                } else {
                    *(int64_t *)(&stack0xfffffffffffffff0 + iVar3) = iVar1;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218e1f;
                    iVar2 = func_0x000180288170(iVar7);
                }
                if (iVar2 == 0) {
                    iVar2 = *(int32_t *)(iVar4 + 0x10c);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218e44;
                    func_0x0001802885f0(iVar7, iVar8 + (int64_t)in_RDX, (int64_t)iVar2);
                }
            }
        }
    }
code_r0x000180218ec3:
    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218ed0;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_10h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_180218dc2
// Address: 0x180218dc2
// Size: 75 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_10ch because it doesn't fit into ProtoModel

void fcn.180218d10(int64_t arg_150h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar8;
    undefined8 *in_R8;
    uint64_t in_R9;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_38;
    
    uStack_38 = 0x180218d24;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&var_10h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar3);
    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218d47;
    iVar4 = fcn.18020e970();
    iVar7 = iVar4 + 0x118;
    if ((in_RDX == in_R8) && ((int64_t)*(int32_t *)(iVar4 + 0x10c) + 8U <= in_R9)) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218d76;
        iVar2 = fcn.1802007d0(in_RCX);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218d82;
            puVar5 = (undefined8 *)func_0x00018020e930(in_RCX);
            *in_RDX = *puVar5;
        }
        *(undefined8 *)(in_RCX + 0x2c) = *in_R8;
        iVar8 = in_R9 - (int64_t)(*(int32_t *)(iVar4 + 0x10c) + 8);
        iVar2 = *(int32_t *)(iVar4 + 0x108);
        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218dba;
        iVar2 = func_0x000180288540(iVar7, in_RCX + 0x28, (int64_t)(0xf - iVar2), iVar8);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RBX;
            iVar2 = *(int32_t *)(iVar4 + 0x110);
            *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218dd6;
            uVar6 = func_0x00018020e930(in_RCX);
            *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218de4;
            func_0x000180287890(iVar7, uVar6, (int64_t)iVar2);
            in_RDX = in_RDX + 1;
            *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218df4;
            iVar2 = fcn.1802007d0(in_RCX);
            iVar1 = *(int64_t *)(iVar4 + 0x150);
            if (iVar2 == 0) {
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218e72;
                    iVar2 = func_0x000180287a20(iVar7, in_R8 + 1, in_RDX, iVar8);
                } else {
                    *(int64_t *)(&stack0xfffffffffffffff0 + iVar3) = iVar1;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218e68;
                    iVar2 = func_0x000180287c00(iVar7);
                }
                if (iVar2 == 0) {
                    iVar2 = *(int32_t *)(iVar4 + 0x10c);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218e91;
                    iVar7 = func_0x0001802885f0(iVar7, (int64_t)&stack0x00000000 + iVar3, (int64_t)iVar2);
                    if (iVar7 != 0) {
                        iVar2 = *(int32_t *)(iVar4 + 0x10c);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218eab;
                        iVar2 = func_0x0001802262e0((int64_t)&stack0x00000000 + iVar3, iVar8 + (int64_t)(in_R8 + 1), 
                                                    (int64_t)iVar2);
                        if (iVar2 == 0) goto code_r0x000180218ec3;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218ebe;
                fcn.180244fc0(in_RDX, iVar8);
            } else {
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218e29;
                    iVar2 = func_0x000180287e20(iVar7);
                } else {
                    *(int64_t *)(&stack0xfffffffffffffff0 + iVar3) = iVar1;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218e1f;
                    iVar2 = func_0x000180288170(iVar7);
                }
                if (iVar2 == 0) {
                    iVar2 = *(int32_t *)(iVar4 + 0x10c);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218e44;
                    func_0x0001802885f0(iVar7, iVar8 + (int64_t)in_RDX, (int64_t)iVar2);
                }
            }
        }
    }
code_r0x000180218ec3:
    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218ed0;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_10h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_180218e0d
// Address: 0x180218e0d
// Size: 209 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_10ch because it doesn't fit into ProtoModel

void fcn.180218d10(int64_t arg_150h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar8;
    undefined8 *in_R8;
    uint64_t in_R9;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_38;
    
    uStack_38 = 0x180218d24;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&var_10h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar3);
    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218d47;
    iVar4 = fcn.18020e970();
    iVar7 = iVar4 + 0x118;
    if ((in_RDX == in_R8) && ((int64_t)*(int32_t *)(iVar4 + 0x10c) + 8U <= in_R9)) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218d76;
        iVar2 = fcn.1802007d0(in_RCX);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218d82;
            puVar5 = (undefined8 *)func_0x00018020e930(in_RCX);
            *in_RDX = *puVar5;
        }
        *(undefined8 *)(in_RCX + 0x2c) = *in_R8;
        iVar8 = in_R9 - (int64_t)(*(int32_t *)(iVar4 + 0x10c) + 8);
        iVar2 = *(int32_t *)(iVar4 + 0x108);
        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218dba;
        iVar2 = func_0x000180288540(iVar7, in_RCX + 0x28, (int64_t)(0xf - iVar2), iVar8);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RBX;
            iVar2 = *(int32_t *)(iVar4 + 0x110);
            *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218dd6;
            uVar6 = func_0x00018020e930(in_RCX);
            *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218de4;
            func_0x000180287890(iVar7, uVar6, (int64_t)iVar2);
            in_RDX = in_RDX + 1;
            *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218df4;
            iVar2 = fcn.1802007d0(in_RCX);
            iVar1 = *(int64_t *)(iVar4 + 0x150);
            if (iVar2 == 0) {
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218e72;
                    iVar2 = func_0x000180287a20(iVar7, in_R8 + 1, in_RDX, iVar8);
                } else {
                    *(int64_t *)(&stack0xfffffffffffffff0 + iVar3) = iVar1;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218e68;
                    iVar2 = func_0x000180287c00(iVar7);
                }
                if (iVar2 == 0) {
                    iVar2 = *(int32_t *)(iVar4 + 0x10c);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218e91;
                    iVar7 = func_0x0001802885f0(iVar7, (int64_t)&stack0x00000000 + iVar3, (int64_t)iVar2);
                    if (iVar7 != 0) {
                        iVar2 = *(int32_t *)(iVar4 + 0x10c);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218eab;
                        iVar2 = func_0x0001802262e0((int64_t)&stack0x00000000 + iVar3, iVar8 + (int64_t)(in_R8 + 1), 
                                                    (int64_t)iVar2);
                        if (iVar2 == 0) goto code_r0x000180218ec3;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218ebe;
                fcn.180244fc0(in_RDX, iVar8);
            } else {
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218e29;
                    iVar2 = func_0x000180287e20(iVar7);
                } else {
                    *(int64_t *)(&stack0xfffffffffffffff0 + iVar3) = iVar1;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218e1f;
                    iVar2 = func_0x000180288170(iVar7);
                }
                if (iVar2 == 0) {
                    iVar2 = *(int32_t *)(iVar4 + 0x10c);
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218e44;
                    func_0x0001802885f0(iVar7, iVar8 + (int64_t)in_RDX, (int64_t)iVar2);
                }
            }
        }
    }
code_r0x000180218ec3:
    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x180218ed0;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_10h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_180218ee0
// Address: 0x180218ee0
// Size: 193 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 fcn.180218ee0(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_98h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 in_RCX;
    int64_t in_RDX;
    undefined8 uVar7;
    undefined8 unaff_RBX;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t in_R8;
    uint64_t in_R9;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [3];
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x180218ef7;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f0b;
    iVar6 = fcn.18020e970();
    uVar8 = 0xffffffff;
    if (in_RDX != in_R8) {
        return 0xffffffff;
    }
    if (in_R9 < 0x18) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f2f;
    iVar4 = fcn.1802007d0(in_RCX);
    if (iVar4 != 0) {
        piVar1 = (int64_t *)(iVar6 + 0x2e0);
        *piVar1 = *piVar1 + 1;
        if (*piVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f42;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f5a;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar5));
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f6c;
            fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x10));
            goto code_r0x0001802190ae;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f79;
    iVar4 = fcn.1802007d0(in_RCX);
    uVar7 = 0x18;
    if (iVar4 != 0) {
        uVar7 = 0x13;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f99;
    iVar4 = func_0x000180210b80(in_RCX, uVar7, 8, in_RDX);
    if (0 < iVar4) {
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBX;
        iVar4 = *(int32_t *)(iVar6 + 0x2d8);
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R14;
        iVar2 = iVar6 + 0x100;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218fc1;
        uVar7 = func_0x00018020e930(in_RCX);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218fcf;
        iVar4 = func_0x000180285790(iVar2, uVar7, (int64_t)iVar4);
        if (iVar4 == 0) {
            in_RDX = in_RDX + 8;
            iVar9 = in_R9 - 0x18;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218feb;
            iVar4 = fcn.1802007d0(in_RCX);
            iVar3 = *(int64_t *)(iVar6 + 0x2e8);
            if (iVar4 == 0) {
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180219057;
                    iVar4 = func_0x0001802858c0(iVar2, in_R8 + 8, in_RDX, iVar9);
                } else {
                    *(int64_t *)((int64_t)&var_8h + iVar5) = iVar3;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18021904d;
                    iVar4 = func_0x000180285cf0(iVar2);
                }
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180219063;
                    uVar7 = func_0x00018020e930(in_RCX);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180219074;
                    func_0x000180286fa0(iVar2, uVar7, 0x10);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18021907f;
                    uVar7 = func_0x00018020e930(in_RCX);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180219090;
                    iVar4 = func_0x0001802262e0(uVar7, in_R8 + 8 + iVar9, 0x10);
                    if (iVar4 == 0) {
                        uVar8 = (undefined4)iVar9;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18021909f;
                        fcn.180244fc0(in_RDX, iVar9);
                    }
                }
            } else {
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18021901b;
                    iVar4 = func_0x000180286050(iVar2);
                } else {
                    *(int64_t *)((int64_t)&var_8h + iVar5) = iVar3;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180219011;
                    iVar4 = func_0x0001802864d0(iVar2);
                }
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180219035;
                    func_0x000180286fa0(iVar2, iVar9 + in_RDX, 0x10);
                    uVar8 = (undefined4)in_R9;
                }
            }
        }
    }
code_r0x0001802190ae:
    *(undefined4 *)(iVar6 + 0xfc) = 0;
    *(undefined4 *)(iVar6 + 0x2d8) = 0xffffffff;
    return uVar8;
}

// ============================================================
// Function: FUN_180218fa1
// Address: 0x180218fa1
// Size: 269 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 fcn.180218ee0(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_98h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 in_RCX;
    int64_t in_RDX;
    undefined8 uVar7;
    undefined8 unaff_RBX;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t in_R8;
    uint64_t in_R9;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [3];
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x180218ef7;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f0b;
    iVar6 = fcn.18020e970();
    uVar8 = 0xffffffff;
    if (in_RDX != in_R8) {
        return 0xffffffff;
    }
    if (in_R9 < 0x18) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f2f;
    iVar4 = fcn.1802007d0(in_RCX);
    if (iVar4 != 0) {
        piVar1 = (int64_t *)(iVar6 + 0x2e0);
        *piVar1 = *piVar1 + 1;
        if (*piVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f42;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f5a;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar5));
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f6c;
            fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x10));
            goto code_r0x0001802190ae;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f79;
    iVar4 = fcn.1802007d0(in_RCX);
    uVar7 = 0x18;
    if (iVar4 != 0) {
        uVar7 = 0x13;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f99;
    iVar4 = func_0x000180210b80(in_RCX, uVar7, 8, in_RDX);
    if (0 < iVar4) {
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBX;
        iVar4 = *(int32_t *)(iVar6 + 0x2d8);
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R14;
        iVar2 = iVar6 + 0x100;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218fc1;
        uVar7 = func_0x00018020e930(in_RCX);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218fcf;
        iVar4 = func_0x000180285790(iVar2, uVar7, (int64_t)iVar4);
        if (iVar4 == 0) {
            in_RDX = in_RDX + 8;
            iVar9 = in_R9 - 0x18;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218feb;
            iVar4 = fcn.1802007d0(in_RCX);
            iVar3 = *(int64_t *)(iVar6 + 0x2e8);
            if (iVar4 == 0) {
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180219057;
                    iVar4 = func_0x0001802858c0(iVar2, in_R8 + 8, in_RDX, iVar9);
                } else {
                    *(int64_t *)((int64_t)&var_8h + iVar5) = iVar3;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18021904d;
                    iVar4 = func_0x000180285cf0(iVar2);
                }
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180219063;
                    uVar7 = func_0x00018020e930(in_RCX);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180219074;
                    func_0x000180286fa0(iVar2, uVar7, 0x10);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18021907f;
                    uVar7 = func_0x00018020e930(in_RCX);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180219090;
                    iVar4 = func_0x0001802262e0(uVar7, in_R8 + 8 + iVar9, 0x10);
                    if (iVar4 == 0) {
                        uVar8 = (undefined4)iVar9;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18021909f;
                        fcn.180244fc0(in_RDX, iVar9);
                    }
                }
            } else {
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18021901b;
                    iVar4 = func_0x000180286050(iVar2);
                } else {
                    *(int64_t *)((int64_t)&var_8h + iVar5) = iVar3;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180219011;
                    iVar4 = func_0x0001802864d0(iVar2);
                }
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180219035;
                    func_0x000180286fa0(iVar2, iVar9 + in_RDX, 0x10);
                    uVar8 = (undefined4)in_R9;
                }
            }
        }
    }
code_r0x0001802190ae:
    *(undefined4 *)(iVar6 + 0xfc) = 0;
    *(undefined4 *)(iVar6 + 0x2d8) = 0xffffffff;
    return uVar8;
}

// ============================================================
// Function: FUN_1802190ae
// Address: 0x1802190ae
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 fcn.180218ee0(int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_98h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 in_RCX;
    int64_t in_RDX;
    undefined8 uVar7;
    undefined8 unaff_RBX;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t in_R8;
    uint64_t in_R9;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [3];
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x180218ef7;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f0b;
    iVar6 = fcn.18020e970();
    uVar8 = 0xffffffff;
    if (in_RDX != in_R8) {
        return 0xffffffff;
    }
    if (in_R9 < 0x18) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f2f;
    iVar4 = fcn.1802007d0(in_RCX);
    if (iVar4 != 0) {
        piVar1 = (int64_t *)(iVar6 + 0x2e0);
        *piVar1 = *piVar1 + 1;
        if (*piVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f42;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f5a;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar5), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar5));
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f6c;
            fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x10));
            goto code_r0x0001802190ae;
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f79;
    iVar4 = fcn.1802007d0(in_RCX);
    uVar7 = 0x18;
    if (iVar4 != 0) {
        uVar7 = 0x13;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218f99;
    iVar4 = func_0x000180210b80(in_RCX, uVar7, 8, in_RDX);
    if (0 < iVar4) {
        *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBX;
        iVar4 = *(int32_t *)(iVar6 + 0x2d8);
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R14;
        iVar2 = iVar6 + 0x100;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218fc1;
        uVar7 = func_0x00018020e930(in_RCX);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218fcf;
        iVar4 = func_0x000180285790(iVar2, uVar7, (int64_t)iVar4);
        if (iVar4 == 0) {
            in_RDX = in_RDX + 8;
            iVar9 = in_R9 - 0x18;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180218feb;
            iVar4 = fcn.1802007d0(in_RCX);
            iVar3 = *(int64_t *)(iVar6 + 0x2e8);
            if (iVar4 == 0) {
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180219057;
                    iVar4 = func_0x0001802858c0(iVar2, in_R8 + 8, in_RDX, iVar9);
                } else {
                    *(int64_t *)((int64_t)&var_8h + iVar5) = iVar3;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18021904d;
                    iVar4 = func_0x000180285cf0(iVar2);
                }
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180219063;
                    uVar7 = func_0x00018020e930(in_RCX);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180219074;
                    func_0x000180286fa0(iVar2, uVar7, 0x10);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18021907f;
                    uVar7 = func_0x00018020e930(in_RCX);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180219090;
                    iVar4 = func_0x0001802262e0(uVar7, in_R8 + 8 + iVar9, 0x10);
                    if (iVar4 == 0) {
                        uVar8 = (undefined4)iVar9;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18021909f;
                        fcn.180244fc0(in_RDX, iVar9);
                    }
                }
            } else {
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18021901b;
                    iVar4 = func_0x000180286050(iVar2);
                } else {
                    *(int64_t *)((int64_t)&var_8h + iVar5) = iVar3;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180219011;
                    iVar4 = func_0x0001802864d0(iVar2);
                }
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180219035;
                    func_0x000180286fa0(iVar2, iVar9 + in_RDX, 0x10);
                    uVar8 = (undefined4)in_R9;
                }
            }
        }
    }
code_r0x0001802190ae:
    *(undefined4 *)(iVar6 + 0xfc) = 0;
    *(undefined4 *)(iVar6 + 0x2d8) = 0xffffffff;
    return uVar8;
}

// ============================================================
// Function: FUN_1802190e0
// Address: 0x1802190e0
// Size: 188 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1802190e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    undefined4 *puVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    int64_t in_RDX;
    uint64_t uVar11;
    int32_t iVar12;
    uint64_t in_R8;
    undefined8 unaff_R15;
    undefined4 extraout_XMM0_Da;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802190f8;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    piVar1 = *(int64_t **)(in_RCX + 0x40);
    iVar12 = (int32_t)in_R8;
    uVar11 = 0xffffffff;
    if ((*(uint32_t *)(in_RCX + 0x30) & 0x200) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x180219154;
        func_0x000180219ce0(extraout_XMM0_Da, 0xf);
        if (iVar12 == 0) {
            uVar11 = 0;
        } else if (in_RDX == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x180219169;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9));
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x180219181;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar9), 
                          *(int64_t *)((int64_t)&arg_38h + iVar9));
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x180219193;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar9));
        } else {
            piVar2 = (int64_t *)piVar1[1];
            *(undefined8 *)((int64_t)&arg_28h + iVar9) = unaff_R15;
            iVar3 = *piVar2;
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1802191a9;
            func_0x0001802199d0(in_RCX);
            iVar10 = *piVar1;
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1802191b5;
            iVar10 = func_0x0001802264b0(iVar10, iVar12 + iVar3);
            if (iVar10 != 0) {
                iVar10 = *(int64_t *)(*piVar1 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1802191cf;
                func_0x000180498030(iVar10 + iVar3, in_RDX, (int64_t)iVar12);
                puVar4 = (undefined4 *)*piVar1;
                uVar11 = in_R8 & 0xffffffff;
                puVar5 = (undefined4 *)piVar1[1];
                uVar6 = puVar4[1];
                uVar7 = puVar4[2];
                uVar8 = puVar4[3];
                *puVar5 = *puVar4;
                puVar5[1] = uVar6;
                puVar5[2] = uVar7;
                puVar5[3] = uVar8;
                uVar6 = puVar4[5];
                uVar7 = puVar4[6];
                uVar8 = puVar4[7];
                puVar5[4] = puVar4[4];
                puVar5[5] = uVar6;
                puVar5[6] = uVar7;
                puVar5[7] = uVar8;
            }
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18021911b;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9));
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x180219133;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar9), 
                      *(int64_t *)((int64_t)&arg_38h + iVar9));
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x180219145;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar9));
    }
    return uVar11;
}

// ============================================================
// Function: FUN_18021919c
// Address: 0x18021919c
// Size: 79 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1802190e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    undefined4 *puVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    int64_t in_RDX;
    uint64_t uVar11;
    int32_t iVar12;
    uint64_t in_R8;
    undefined8 unaff_R15;
    undefined4 extraout_XMM0_Da;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802190f8;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    piVar1 = *(int64_t **)(in_RCX + 0x40);
    iVar12 = (int32_t)in_R8;
    uVar11 = 0xffffffff;
    if ((*(uint32_t *)(in_RCX + 0x30) & 0x200) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x180219154;
        func_0x000180219ce0(extraout_XMM0_Da, 0xf);
        if (iVar12 == 0) {
            uVar11 = 0;
        } else if (in_RDX == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x180219169;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9));
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x180219181;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar9), 
                          *(int64_t *)((int64_t)&arg_38h + iVar9));
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x180219193;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar9));
        } else {
            piVar2 = (int64_t *)piVar1[1];
            *(undefined8 *)((int64_t)&arg_28h + iVar9) = unaff_R15;
            iVar3 = *piVar2;
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1802191a9;
            func_0x0001802199d0(in_RCX);
            iVar10 = *piVar1;
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1802191b5;
            iVar10 = func_0x0001802264b0(iVar10, iVar12 + iVar3);
            if (iVar10 != 0) {
                iVar10 = *(int64_t *)(*piVar1 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1802191cf;
                func_0x000180498030(iVar10 + iVar3, in_RDX, (int64_t)iVar12);
                puVar4 = (undefined4 *)*piVar1;
                uVar11 = in_R8 & 0xffffffff;
                puVar5 = (undefined4 *)piVar1[1];
                uVar6 = puVar4[1];
                uVar7 = puVar4[2];
                uVar8 = puVar4[3];
                *puVar5 = *puVar4;
                puVar5[1] = uVar6;
                puVar5[2] = uVar7;
                puVar5[3] = uVar8;
                uVar6 = puVar4[5];
                uVar7 = puVar4[6];
                uVar8 = puVar4[7];
                puVar5[4] = puVar4[4];
                puVar5[5] = uVar6;
                puVar5[6] = uVar7;
                puVar5[7] = uVar8;
            }
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18021911b;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9));
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x180219133;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar9), 
                      *(int64_t *)((int64_t)&arg_38h + iVar9));
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x180219145;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar9));
    }
    return uVar11;
}

// ============================================================
// Function: FUN_1802191eb
// Address: 0x1802191eb
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1802190e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    undefined4 *puVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    int64_t in_RDX;
    uint64_t uVar11;
    int32_t iVar12;
    uint64_t in_R8;
    undefined8 unaff_R15;
    undefined4 extraout_XMM0_Da;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802190f8;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    piVar1 = *(int64_t **)(in_RCX + 0x40);
    iVar12 = (int32_t)in_R8;
    uVar11 = 0xffffffff;
    if ((*(uint32_t *)(in_RCX + 0x30) & 0x200) == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x180219154;
        func_0x000180219ce0(extraout_XMM0_Da, 0xf);
        if (iVar12 == 0) {
            uVar11 = 0;
        } else if (in_RDX == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x180219169;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9));
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x180219181;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar9), 
                          *(int64_t *)((int64_t)&arg_38h + iVar9));
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x180219193;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar9));
        } else {
            piVar2 = (int64_t *)piVar1[1];
            *(undefined8 *)((int64_t)&arg_28h + iVar9) = unaff_R15;
            iVar3 = *piVar2;
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1802191a9;
            func_0x0001802199d0(in_RCX);
            iVar10 = *piVar1;
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1802191b5;
            iVar10 = func_0x0001802264b0(iVar10, iVar12 + iVar3);
            if (iVar10 != 0) {
                iVar10 = *(int64_t *)(*piVar1 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1802191cf;
                func_0x000180498030(iVar10 + iVar3, in_RDX, (int64_t)iVar12);
                puVar4 = (undefined4 *)*piVar1;
                uVar11 = in_R8 & 0xffffffff;
                puVar5 = (undefined4 *)piVar1[1];
                uVar6 = puVar4[1];
                uVar7 = puVar4[2];
                uVar8 = puVar4[3];
                *puVar5 = *puVar4;
                puVar5[1] = uVar6;
                puVar5[2] = uVar7;
                puVar5[3] = uVar8;
                uVar6 = puVar4[5];
                uVar7 = puVar4[6];
                uVar8 = puVar4[7];
                puVar5[4] = puVar4[4];
                puVar5[5] = uVar6;
                puVar5[6] = uVar7;
                puVar5[7] = uVar8;
            }
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x18021911b;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9));
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x180219133;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar9), *(int64_t *)((int64_t)&var_10h + iVar9), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar9 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar9), 
                      *(int64_t *)((int64_t)&arg_38h + iVar9));
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x180219145;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar9));
    }
    return uVar11;
}

// ============================================================
// Function: FUN_180219200
// Address: 0x180219200
// Size: 185 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180219200(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t iVar4;
    undefined8 unaff_RSI;
    uint64_t uVar5;
    uint64_t *puVar6;
    uint64_t in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021921b;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    puVar6 = (*(uint64_t ***)(in_RCX + 0x40))[1];
    if ((*(uint32_t *)(in_RCX + 0x30) & 0x200) != 0) {
        puVar6 = **(uint64_t ***)(in_RCX + 0x40);
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021924a;
    func_0x000180219ce0();
    if (((int32_t)in_R8 < 0) || (uVar5 = *puVar6, (uint64_t)(int64_t)(int32_t)in_R8 <= uVar5)) {
        uVar5 = in_R8 & 0xffffffff;
    }
    if ((in_RDX == 0) || ((int32_t)uVar5 < 1)) {
        if (*puVar6 == 0) {
            uVar1 = *(uint32_t *)(in_RCX + 0x38);
            if (uVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802192b5;
                func_0x00018021b250(in_RCX, 9);
            }
            return (uint64_t)uVar1;
        }
    } else {
        uVar2 = puVar6[1];
        iVar4 = (int64_t)(int32_t)uVar5;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180219273;
        func_0x000180498030(in_RDX, uVar2, iVar4);
        *puVar6 = *puVar6 - iVar4;
        puVar6[2] = puVar6[2] - iVar4;
        puVar6[1] = puVar6[1] + iVar4;
    }
    return uVar5 & 0xffffffff;
}

// ============================================================
// Function: FUN_1802192c0
// Address: 0x1802192c0
// Size: 224 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1802192c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined4 *puVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t in_RCX;
    int64_t in_RDX;
    uint64_t uVar13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802192d2;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1802192e3;
    uVar11 = fcn.180498cd0(in_RDX);
    if (uVar11 < 0x80000000) {
        uVar1 = *(uint32_t *)(in_RCX + 0x30);
        uVar13 = 0xffffffff;
        *(undefined8 *)((int64_t)&arg_28h + iVar10) = unaff_R14;
        piVar2 = *(int64_t **)(in_RCX + 0x40);
        if ((uVar1 & 0x200) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x180219358;
            fcn.180219ce0(in_RCX, 0xf);
            if ((int32_t)uVar11 == 0) {
                uVar13 = 0;
            } else if (in_RDX == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x18021936d;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x180219385;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8)
                              , *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar10), *(int64_t *)((int64_t)&arg_38h + iVar10));
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x180219397;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar10));
            } else {
                piVar3 = (int64_t *)piVar2[1];
                *(undefined8 *)((int64_t)&arg_30h + iVar10) = unaff_R15;
                iVar4 = *piVar3;
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1802193ad;
                fcn.1802199d0(in_RCX);
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1802193bc;
                iVar12 = fcn.1802264b0(*(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                       *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                       *(int64_t *)(&stack0x00000058 + iVar10));
                if (iVar12 != 0) {
                    iVar12 = *(int64_t *)(*piVar2 + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1802193d6;
                    fcn.180498030(iVar12 + iVar4, in_RDX, (int64_t)(int32_t)uVar11);
                    puVar5 = (undefined4 *)*piVar2;
                    uVar13 = uVar11 & 0xffffffff;
                    puVar6 = (undefined4 *)piVar2[1];
                    uVar7 = puVar5[1];
                    uVar8 = puVar5[2];
                    uVar9 = puVar5[3];
                    *puVar6 = *puVar5;
                    puVar6[1] = uVar7;
                    puVar6[2] = uVar8;
                    puVar6[3] = uVar9;
                    uVar7 = puVar5[5];
                    uVar8 = puVar5[6];
                    uVar9 = puVar5[7];
                    puVar6[4] = puVar5[4];
                    puVar6[5] = uVar7;
                    puVar6[6] = uVar8;
                    puVar6[7] = uVar9;
                }
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x18021931c;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x180219334;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar10)
                          , *(int64_t *)((int64_t)&arg_38h + iVar10));
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x180219346;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar10));
        }
        return uVar13;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1802193a0
// Address: 0x1802193a0
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1802192c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined4 *puVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t in_RCX;
    int64_t in_RDX;
    uint64_t uVar13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802192d2;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1802192e3;
    uVar11 = fcn.180498cd0(in_RDX);
    if (uVar11 < 0x80000000) {
        uVar1 = *(uint32_t *)(in_RCX + 0x30);
        uVar13 = 0xffffffff;
        *(undefined8 *)((int64_t)&arg_28h + iVar10) = unaff_R14;
        piVar2 = *(int64_t **)(in_RCX + 0x40);
        if ((uVar1 & 0x200) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x180219358;
            fcn.180219ce0(in_RCX, 0xf);
            if ((int32_t)uVar11 == 0) {
                uVar13 = 0;
            } else if (in_RDX == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x18021936d;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x180219385;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8)
                              , *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar10), *(int64_t *)((int64_t)&arg_38h + iVar10));
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x180219397;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar10));
            } else {
                piVar3 = (int64_t *)piVar2[1];
                *(undefined8 *)((int64_t)&arg_30h + iVar10) = unaff_R15;
                iVar4 = *piVar3;
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1802193ad;
                fcn.1802199d0(in_RCX);
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1802193bc;
                iVar12 = fcn.1802264b0(*(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                       *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                       *(int64_t *)(&stack0x00000058 + iVar10));
                if (iVar12 != 0) {
                    iVar12 = *(int64_t *)(*piVar2 + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1802193d6;
                    fcn.180498030(iVar12 + iVar4, in_RDX, (int64_t)(int32_t)uVar11);
                    puVar5 = (undefined4 *)*piVar2;
                    uVar13 = uVar11 & 0xffffffff;
                    puVar6 = (undefined4 *)piVar2[1];
                    uVar7 = puVar5[1];
                    uVar8 = puVar5[2];
                    uVar9 = puVar5[3];
                    *puVar6 = *puVar5;
                    puVar6[1] = uVar7;
                    puVar6[2] = uVar8;
                    puVar6[3] = uVar9;
                    uVar7 = puVar5[5];
                    uVar8 = puVar5[6];
                    uVar9 = puVar5[7];
                    puVar6[4] = puVar5[4];
                    puVar6[5] = uVar7;
                    puVar6[6] = uVar8;
                    puVar6[7] = uVar9;
                }
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x18021931c;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x180219334;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar10)
                          , *(int64_t *)((int64_t)&arg_38h + iVar10));
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x180219346;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar10));
        }
        return uVar13;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1802193f2
// Address: 0x1802193f2
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1802192c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined4 *puVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t in_RCX;
    int64_t in_RDX;
    uint64_t uVar13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802192d2;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1802192e3;
    uVar11 = fcn.180498cd0(in_RDX);
    if (uVar11 < 0x80000000) {
        uVar1 = *(uint32_t *)(in_RCX + 0x30);
        uVar13 = 0xffffffff;
        *(undefined8 *)((int64_t)&arg_28h + iVar10) = unaff_R14;
        piVar2 = *(int64_t **)(in_RCX + 0x40);
        if ((uVar1 & 0x200) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x180219358;
            fcn.180219ce0(in_RCX, 0xf);
            if ((int32_t)uVar11 == 0) {
                uVar13 = 0;
            } else if (in_RDX == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x18021936d;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x180219385;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8)
                              , *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar10), *(int64_t *)((int64_t)&arg_38h + iVar10));
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x180219397;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar10));
            } else {
                piVar3 = (int64_t *)piVar2[1];
                *(undefined8 *)((int64_t)&arg_30h + iVar10) = unaff_R15;
                iVar4 = *piVar3;
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1802193ad;
                fcn.1802199d0(in_RCX);
                *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1802193bc;
                iVar12 = fcn.1802264b0(*(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), 
                                       *(int64_t *)((int64_t)&iStackX_20 + iVar10), 
                                       *(int64_t *)(&stack0x00000058 + iVar10));
                if (iVar12 != 0) {
                    iVar12 = *(int64_t *)(*piVar2 + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x1802193d6;
                    fcn.180498030(iVar12 + iVar4, in_RDX, (int64_t)(int32_t)uVar11);
                    puVar5 = (undefined4 *)*piVar2;
                    uVar13 = uVar11 & 0xffffffff;
                    puVar6 = (undefined4 *)piVar2[1];
                    uVar7 = puVar5[1];
                    uVar8 = puVar5[2];
                    uVar9 = puVar5[3];
                    *puVar6 = *puVar5;
                    puVar6[1] = uVar7;
                    puVar6[2] = uVar8;
                    puVar6[3] = uVar9;
                    uVar7 = puVar5[5];
                    uVar8 = puVar5[6];
                    uVar9 = puVar5[7];
                    puVar6[4] = puVar5[4];
                    puVar6[5] = uVar7;
                    puVar6[6] = uVar8;
                    puVar6[7] = uVar9;
                }
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x18021931c;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x180219334;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar10)
                          , *(int64_t *)((int64_t)&arg_38h + iVar10));
            *(undefined8 *)((int64_t)&uStack_20 + iVar10) = 0x180219346;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar10));
        }
        return uVar13;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180219410
// Address: 0x180219410
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180219410(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int32_t iVar4;
    int64_t in_RCX;
    undefined *in_RDX;
    uint32_t uVar5;
    uint64_t *puVar6;
    int64_t iVar8;
    undefined8 unaff_RSI;
    uint64_t uVar9;
    int32_t in_R8D;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    uint64_t uVar7;
    
    uStack_10 = 0x18021942b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    puVar6 = (*(uint64_t ***)(in_RCX + 0x40))[1];
    if ((*(uint32_t *)(in_RCX + 0x30) & 0x200) != 0) {
        puVar6 = **(uint64_t ***)(in_RCX + 0x40);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180219455;
    fcn.180219ce0();
    iVar4 = 0x7fffffff;
    if (*puVar6 < 0x7fffffff) {
        iVar4 = (int32_t)*puVar6;
    }
    iVar1 = in_R8D + -1;
    if (iVar4 <= in_R8D + -1) {
        iVar1 = iVar4;
    }
    if (iVar1 < 1) {
        *in_RDX = 0;
        return 0;
    }
    uVar9 = puVar6[1];
    uVar3 = 0;
    uVar5 = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RSI;
    uVar7 = uVar3;
    if (0 < iVar1) {
        do {
            uVar5 = (int32_t)uVar7 + 1;
            if (*(char *)(uVar9 + uVar3) == '\n') break;
            uVar3 = uVar3 + 1;
            uVar7 = (uint64_t)uVar5;
        } while ((int64_t)uVar3 < (int64_t)iVar1);
    }
    puVar6 = (*(uint64_t ***)(in_RCX + 0x40))[1];
    if ((*(uint32_t *)(in_RCX + 0x30) & 0x200) != 0) {
        puVar6 = **(uint64_t ***)(in_RCX + 0x40);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802194c1;
    fcn.180219ce0(in_RCX, 0xf);
    if (((int32_t)uVar5 < 0) || (uVar9 = *puVar6, (uint64_t)(int64_t)(int32_t)uVar5 <= uVar9)) {
        uVar9 = (uint64_t)uVar5;
    }
    if ((in_RDX == (undefined *)0x0) || ((int32_t)uVar9 < 1)) {
        if ((*puVar6 == 0) && (uVar9 = (uint64_t)*(uint32_t *)(in_RCX + 0x38), *(uint32_t *)(in_RCX + 0x38) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180219516;
            func_0x00018021b250(in_RCX, 9);
        }
        if ((int32_t)uVar9 < 1) goto code_r0x000180219521;
    } else {
        uVar7 = puVar6[1];
        iVar8 = (int64_t)(int32_t)uVar9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802194ed;
        fcn.180498030(in_RDX, uVar7, iVar8);
        *puVar6 = *puVar6 - iVar8;
        puVar6[2] = puVar6[2] - iVar8;
        puVar6[1] = puVar6[1] + iVar8;
    }
    in_RDX[uVar9 & 0xffffffff] = 0;
code_r0x000180219521:
    return uVar9 & 0xffffffff;
}

// ============================================================
// Function: FUN_180219480
// Address: 0x180219480
// Size: 168 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180219410(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int32_t iVar4;
    int64_t in_RCX;
    undefined *in_RDX;
    uint32_t uVar5;
    uint64_t *puVar6;
    int64_t iVar8;
    undefined8 unaff_RSI;
    uint64_t uVar9;
    int32_t in_R8D;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    uint64_t uVar7;
    
    uStack_10 = 0x18021942b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    puVar6 = (*(uint64_t ***)(in_RCX + 0x40))[1];
    if ((*(uint32_t *)(in_RCX + 0x30) & 0x200) != 0) {
        puVar6 = **(uint64_t ***)(in_RCX + 0x40);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180219455;
    fcn.180219ce0();
    iVar4 = 0x7fffffff;
    if (*puVar6 < 0x7fffffff) {
        iVar4 = (int32_t)*puVar6;
    }
    iVar1 = in_R8D + -1;
    if (iVar4 <= in_R8D + -1) {
        iVar1 = iVar4;
    }
    if (iVar1 < 1) {
        *in_RDX = 0;
        return 0;
    }
    uVar9 = puVar6[1];
    uVar3 = 0;
    uVar5 = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RSI;
    uVar7 = uVar3;
    if (0 < iVar1) {
        do {
            uVar5 = (int32_t)uVar7 + 1;
            if (*(char *)(uVar9 + uVar3) == '\n') break;
            uVar3 = uVar3 + 1;
            uVar7 = (uint64_t)uVar5;
        } while ((int64_t)uVar3 < (int64_t)iVar1);
    }
    puVar6 = (*(uint64_t ***)(in_RCX + 0x40))[1];
    if ((*(uint32_t *)(in_RCX + 0x30) & 0x200) != 0) {
        puVar6 = **(uint64_t ***)(in_RCX + 0x40);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802194c1;
    fcn.180219ce0(in_RCX, 0xf);
    if (((int32_t)uVar5 < 0) || (uVar9 = *puVar6, (uint64_t)(int64_t)(int32_t)uVar5 <= uVar9)) {
        uVar9 = (uint64_t)uVar5;
    }
    if ((in_RDX == (undefined *)0x0) || ((int32_t)uVar9 < 1)) {
        if ((*puVar6 == 0) && (uVar9 = (uint64_t)*(uint32_t *)(in_RCX + 0x38), *(uint32_t *)(in_RCX + 0x38) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180219516;
            func_0x00018021b250(in_RCX, 9);
        }
        if ((int32_t)uVar9 < 1) goto code_r0x000180219521;
    } else {
        uVar7 = puVar6[1];
        iVar8 = (int64_t)(int32_t)uVar9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802194ed;
        fcn.180498030(in_RDX, uVar7, iVar8);
        *puVar6 = *puVar6 - iVar8;
        puVar6[2] = puVar6[2] - iVar8;
        puVar6[1] = puVar6[1] + iVar8;
    }
    in_RDX[uVar9 & 0xffffffff] = 0;
code_r0x000180219521:
    return uVar9 & 0xffffffff;
}

// ============================================================
// Function: FUN_180219528
// Address: 0x180219528
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180219410(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int32_t iVar4;
    int64_t in_RCX;
    undefined *in_RDX;
    uint32_t uVar5;
    uint64_t *puVar6;
    int64_t iVar8;
    undefined8 unaff_RSI;
    uint64_t uVar9;
    int32_t in_R8D;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    uint64_t uVar7;
    
    uStack_10 = 0x18021942b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    puVar6 = (*(uint64_t ***)(in_RCX + 0x40))[1];
    if ((*(uint32_t *)(in_RCX + 0x30) & 0x200) != 0) {
        puVar6 = **(uint64_t ***)(in_RCX + 0x40);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180219455;
    fcn.180219ce0();
    iVar4 = 0x7fffffff;
    if (*puVar6 < 0x7fffffff) {
        iVar4 = (int32_t)*puVar6;
    }
    iVar1 = in_R8D + -1;
    if (iVar4 <= in_R8D + -1) {
        iVar1 = iVar4;
    }
    if (iVar1 < 1) {
        *in_RDX = 0;
        return 0;
    }
    uVar9 = puVar6[1];
    uVar3 = 0;
    uVar5 = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RSI;
    uVar7 = uVar3;
    if (0 < iVar1) {
        do {
            uVar5 = (int32_t)uVar7 + 1;
            if (*(char *)(uVar9 + uVar3) == '\n') break;
            uVar3 = uVar3 + 1;
            uVar7 = (uint64_t)uVar5;
        } while ((int64_t)uVar3 < (int64_t)iVar1);
    }
    puVar6 = (*(uint64_t ***)(in_RCX + 0x40))[1];
    if ((*(uint32_t *)(in_RCX + 0x30) & 0x200) != 0) {
        puVar6 = **(uint64_t ***)(in_RCX + 0x40);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802194c1;
    fcn.180219ce0(in_RCX, 0xf);
    if (((int32_t)uVar5 < 0) || (uVar9 = *puVar6, (uint64_t)(int64_t)(int32_t)uVar5 <= uVar9)) {
        uVar9 = (uint64_t)uVar5;
    }
    if ((in_RDX == (undefined *)0x0) || ((int32_t)uVar9 < 1)) {
        if ((*puVar6 == 0) && (uVar9 = (uint64_t)*(uint32_t *)(in_RCX + 0x38), *(uint32_t *)(in_RCX + 0x38) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180219516;
            func_0x00018021b250(in_RCX, 9);
        }
        if ((int32_t)uVar9 < 1) goto code_r0x000180219521;
    } else {
        uVar7 = puVar6[1];
        iVar8 = (int64_t)(int32_t)uVar9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802194ed;
        fcn.180498030(in_RDX, uVar7, iVar8);
        *puVar6 = *puVar6 - iVar8;
        puVar6[2] = puVar6[2] - iVar8;
        puVar6[1] = puVar6[1] + iVar8;
    }
    in_RDX[uVar9 & 0xffffffff] = 0;
code_r0x000180219521:
    return uVar9 & 0xffffffff;
}

