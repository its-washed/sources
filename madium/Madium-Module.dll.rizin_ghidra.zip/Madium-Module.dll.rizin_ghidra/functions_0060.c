// Chunk 60 - 50 functions

// ============================================================
// Function: FUN_1800c3d3e
// Address: 0x1800c3d3e
// Size: 743 bytes
// ============================================================
uint64_t fcn.1800c3d3e(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_60h, int64_t arg_68h,
                      int64_t arg_70h)
{
    int32_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    uint64_t uVar5;
    char cVar6;
    char *pcVar7;
    undefined4 *puVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint64_t unaff_RBX;
    int64_t iVar11;
    int64_t unaff_RDI;
    uint64_t uVar12;
    uint64_t *unaff_R12;
    int64_t unaff_R13;
    uint64_t uVar13;
    int64_t var_20h;
    
    uVar13 = 0;
    do {
        iVar3 = arg_68h;
        if (*unaff_R12 <= uVar13) break;
        uVar2 = *(uint64_t *)(*(int64_t *)(unaff_R13 + 0x28) + uVar13 * 8);
        iVar3 = *(int64_t *)(*(int64_t *)(unaff_R13 + 0x38) + uVar13 * 8);
        piVar4 = *(int64_t **)(unaff_RDI + 0x10);
        if ((piVar4[2] != 0) && (uVar2 != piVar4[3])) {
            uVar10 = (uVar2 >> 5 ^ uVar2) >> 4;
            uVar12 = 0;
            do {
                uVar10 = uVar10 & piVar4[1] - 1U;
                iVar9 = *piVar4 + uVar10 * 0x18;
                uVar5 = *(uint64_t *)(*piVar4 + uVar10 * 0x18);
                if (uVar5 == uVar2) goto code_r0x0001800c3dd9;
                if (uVar5 == piVar4[3]) break;
                uVar10 = uVar10 + 1 + uVar12;
                uVar12 = uVar12 + 1;
            } while (uVar12 <= piVar4[1] - 1U);
        }
        iVar9 = 0;
code_r0x0001800c3dd9:
        pcVar7 = (char *)(iVar9 + 0x10);
        if (iVar9 == 0) {
            pcVar7 = (char *)0x8;
        }
        if (*pcVar7 == '\0') {
            iVar1 = *(int32_t *)(iVar3 + 8);
            iVar9 = 0;
            if (iVar1 == *(int32_t *)0x180782758) {
                iVar9 = iVar3;
            }
            if (iVar9 == 0) {
                iVar9 = 0;
                if (iVar1 == *(int32_t *)0x1807826c0) {
                    iVar9 = iVar3;
                }
                if (iVar9 == 0) {
                    iVar9 = 0;
                    if (iVar1 == *(int32_t *)0x180782708) {
                        iVar9 = iVar3;
                    }
                    if (iVar9 != 0) goto code_r0x0001800c3e95;
                    iVar9 = 0;
                    if (iVar1 == *(int32_t *)0x180782674) {
                        iVar9 = iVar3;
                    }
                    if (iVar9 != 0) goto code_r0x0001800c3e95;
                } else {
code_r0x0001800c3e95:
                    cVar6 = func_0x0001800c3740();
                    if (cVar6 != '\0') goto code_r0x0001800c3e52;
                }
code_r0x0001800c3eab:
                cVar6 = func_0x0001800c3440();
                if (cVar6 != '\0') {
                    puVar8 = (undefined4 *)func_0x0001800ac540(*(undefined8 *)(unaff_RDI + 8));
                    *puVar8 = 1;
                }
            } else {
                iVar11 = *(int64_t *)(iVar9 + 0x20);
                iVar9 = iVar11 + *(int64_t *)(iVar9 + 0x28) * 0x18;
                for (; iVar11 != iVar9; iVar11 = iVar11 + 0x18) {
                    if (((*(int64_t *)(iVar11 + 8) != 0) && (cVar6 = func_0x0001800c3440(), cVar6 == '\0')) ||
                       (cVar6 = func_0x0001800c3440(), cVar6 == '\0')) goto code_r0x0001800c3eab;
                }
code_r0x0001800c3e52:
                puVar8 = (undefined4 *)func_0x0001800ac540(*(undefined8 *)(unaff_RDI + 8));
                *puVar8 = 0;
            }
        }
        piVar4 = *(int64_t **)(unaff_RDI + 8);
        if ((piVar4[2] != 0) && (uVar2 != piVar4[3])) {
            uVar10 = (uVar2 >> 5 ^ uVar2) >> 4;
            uVar12 = 0;
            do {
                uVar10 = uVar10 & piVar4[1] - 1U;
                uVar5 = *(uint64_t *)(*piVar4 + uVar10 * 0x10);
                if (uVar5 == uVar2) goto code_r0x0001800c400b;
                if (uVar5 == piVar4[3]) break;
                uVar10 = uVar10 + 1 + uVar12;
                uVar12 = uVar12 + 1;
            } while (uVar12 <= piVar4[1] - 1U);
        }
        iVar1 = *(int32_t *)(iVar3 + 8);
        iVar9 = 0;
        if (iVar1 == *(int32_t *)0x1807826c0) {
            iVar9 = iVar3;
        }
        if (iVar9 == 0) {
            iVar9 = 0;
            if (iVar1 == *(int32_t *)0x180782708) {
                iVar9 = iVar3;
            }
            if (iVar9 == 0) {
                iVar9 = 0;
                if (iVar1 == *(int32_t *)0x180782674) {
                    iVar9 = iVar3;
                }
                if (iVar9 == 0) {
                    iVar9 = 0;
                    if (iVar1 == *(int32_t *)0x18078270c) {
                        iVar9 = iVar3;
                    }
                    if (iVar9 == 0) {
                        iVar9 = 0;
                        if (iVar1 == *(int32_t *)0x180782668) {
                            iVar9 = iVar3;
                        }
                        if ((iVar9 == 0) || (1 < *(int32_t *)(iVar9 + 0x20) - 0xeU)) goto code_r0x0001800c3ffc;
                        cVar6 = func_0x0001800c3830();
                    } else {
                        cVar6 = func_0x0001800c3830();
                    }
                    if (cVar6 == '\0') {
                        func_0x0001800c3830();
                    }
                } else {
                    func_0x0001800c3830();
                }
            } else {
                func_0x0001800c3830();
            }
        } else {
            func_0x0001800c3830();
        }
code_r0x0001800c3ffc:
        func_0x0001800c3930();
code_r0x0001800c400b:
        unaff_RBX = *(uint64_t *)(unaff_R13 + 0x30);
        uVar13 = uVar13 + 1;
        iVar3 = unaff_R13 + 0x38;
    } while (uVar13 < unaff_RBX);
    arg_68h = iVar3;
    if (unaff_RBX < *unaff_R12) {
        do {
            func_0x0001800c3930();
            unaff_RBX = unaff_RBX + 1;
        } while (unaff_RBX < *unaff_R12);
    }
    return arg_68h & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c4025
// Address: 0x1800c4025
// Size: 7 bytes
// ============================================================
uint64_t fcn.1800c4025(int64_t arg_68h)
{
    uint64_t in_RAX;
    uint64_t unaff_RBX;
    uint64_t *unaff_R12;
    
    if (unaff_RBX < *unaff_R12) {
        do {
            func_0x0001800c3930();
            unaff_RBX = unaff_RBX + 1;
        } while (unaff_RBX < *unaff_R12);
    }
    return in_RAX & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c402c
// Address: 0x1800c402c
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_60h
// WARNING: Variable defined which should be unmapped: arg_38h
// WARNING: Variable defined which should be unmapped: arg_28h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800c3d3e(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_60h, int64_t arg_68h,
                      int64_t arg_70h)
{
    int32_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    uint64_t uVar5;
    char cVar6;
    char *pcVar7;
    undefined4 *puVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint64_t unaff_RBX;
    int64_t iVar11;
    int64_t unaff_RDI;
    uint64_t uVar12;
    uint64_t *unaff_R12;
    int64_t unaff_R13;
    uint64_t uVar13;
    int64_t var_20h;
    
    uVar13 = 0;
    do {
        iVar3 = arg_68h;
        if (*unaff_R12 <= uVar13) break;
        uVar2 = *(uint64_t *)(*(int64_t *)(unaff_R13 + 0x28) + uVar13 * 8);
        iVar3 = *(int64_t *)(*(int64_t *)(unaff_R13 + 0x38) + uVar13 * 8);
        piVar4 = *(int64_t **)(unaff_RDI + 0x10);
        if ((piVar4[2] != 0) && (uVar2 != piVar4[3])) {
            uVar10 = (uVar2 >> 5 ^ uVar2) >> 4;
            uVar12 = 0;
            do {
                uVar10 = uVar10 & piVar4[1] - 1U;
                iVar9 = *piVar4 + uVar10 * 0x18;
                uVar5 = *(uint64_t *)(*piVar4 + uVar10 * 0x18);
                if (uVar5 == uVar2) goto code_r0x0001800c3dd9;
                if (uVar5 == piVar4[3]) break;
                uVar10 = uVar10 + 1 + uVar12;
                uVar12 = uVar12 + 1;
            } while (uVar12 <= piVar4[1] - 1U);
        }
        iVar9 = 0;
code_r0x0001800c3dd9:
        pcVar7 = (char *)(iVar9 + 0x10);
        if (iVar9 == 0) {
            pcVar7 = (char *)0x8;
        }
        if (*pcVar7 == '\0') {
            iVar1 = *(int32_t *)(iVar3 + 8);
            iVar9 = 0;
            if (iVar1 == *(int32_t *)0x180782758) {
                iVar9 = iVar3;
            }
            if (iVar9 == 0) {
                iVar9 = 0;
                if (iVar1 == *(int32_t *)0x1807826c0) {
                    iVar9 = iVar3;
                }
                if (iVar9 == 0) {
                    iVar9 = 0;
                    if (iVar1 == *(int32_t *)0x180782708) {
                        iVar9 = iVar3;
                    }
                    if (iVar9 != 0) goto code_r0x0001800c3e95;
                    iVar9 = 0;
                    if (iVar1 == *(int32_t *)0x180782674) {
                        iVar9 = iVar3;
                    }
                    if (iVar9 != 0) goto code_r0x0001800c3e95;
                } else {
code_r0x0001800c3e95:
                    cVar6 = func_0x0001800c3740();
                    if (cVar6 != '\0') goto code_r0x0001800c3e52;
                }
code_r0x0001800c3eab:
                cVar6 = func_0x0001800c3440();
                if (cVar6 != '\0') {
                    puVar8 = (undefined4 *)func_0x0001800ac540(*(undefined8 *)(unaff_RDI + 8));
                    *puVar8 = 1;
                }
            } else {
                iVar11 = *(int64_t *)(iVar9 + 0x20);
                iVar9 = iVar11 + *(int64_t *)(iVar9 + 0x28) * 0x18;
                for (; iVar11 != iVar9; iVar11 = iVar11 + 0x18) {
                    if (((*(int64_t *)(iVar11 + 8) != 0) && (cVar6 = func_0x0001800c3440(), cVar6 == '\0')) ||
                       (cVar6 = func_0x0001800c3440(), cVar6 == '\0')) goto code_r0x0001800c3eab;
                }
code_r0x0001800c3e52:
                puVar8 = (undefined4 *)func_0x0001800ac540(*(undefined8 *)(unaff_RDI + 8));
                *puVar8 = 0;
            }
        }
        piVar4 = *(int64_t **)(unaff_RDI + 8);
        if ((piVar4[2] != 0) && (uVar2 != piVar4[3])) {
            uVar10 = (uVar2 >> 5 ^ uVar2) >> 4;
            uVar12 = 0;
            do {
                uVar10 = uVar10 & piVar4[1] - 1U;
                uVar5 = *(uint64_t *)(*piVar4 + uVar10 * 0x10);
                if (uVar5 == uVar2) goto code_r0x0001800c400b;
                if (uVar5 == piVar4[3]) break;
                uVar10 = uVar10 + 1 + uVar12;
                uVar12 = uVar12 + 1;
            } while (uVar12 <= piVar4[1] - 1U);
        }
        iVar1 = *(int32_t *)(iVar3 + 8);
        iVar9 = 0;
        if (iVar1 == *(int32_t *)0x1807826c0) {
            iVar9 = iVar3;
        }
        if (iVar9 == 0) {
            iVar9 = 0;
            if (iVar1 == *(int32_t *)0x180782708) {
                iVar9 = iVar3;
            }
            if (iVar9 == 0) {
                iVar9 = 0;
                if (iVar1 == *(int32_t *)0x180782674) {
                    iVar9 = iVar3;
                }
                if (iVar9 == 0) {
                    iVar9 = 0;
                    if (iVar1 == *(int32_t *)0x18078270c) {
                        iVar9 = iVar3;
                    }
                    if (iVar9 == 0) {
                        iVar9 = 0;
                        if (iVar1 == *(int32_t *)0x180782668) {
                            iVar9 = iVar3;
                        }
                        if ((iVar9 == 0) || (1 < *(int32_t *)(iVar9 + 0x20) - 0xeU)) goto code_r0x0001800c3ffc;
                        cVar6 = func_0x0001800c3830();
                    } else {
                        cVar6 = func_0x0001800c3830();
                    }
                    if (cVar6 == '\0') {
                        func_0x0001800c3830();
                    }
                } else {
                    func_0x0001800c3830();
                }
            } else {
                func_0x0001800c3830();
            }
        } else {
            func_0x0001800c3830();
        }
code_r0x0001800c3ffc:
        func_0x0001800c3930();
code_r0x0001800c400b:
        unaff_RBX = *(uint64_t *)(unaff_R13 + 0x30);
        uVar13 = uVar13 + 1;
        iVar3 = unaff_R13 + 0x38;
    } while (uVar13 < unaff_RBX);
    arg_68h = iVar3;
    if (unaff_RBX < *unaff_R12) {
        do {
            func_0x0001800c3930();
            unaff_RBX = unaff_RBX + 1;
        } while (unaff_RBX < *unaff_R12);
    }
    return arg_68h & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c4045
// Address: 0x1800c4045
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_60h
// WARNING: Variable defined which should be unmapped: arg_38h
// WARNING: Variable defined which should be unmapped: arg_28h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800c3d3e(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_60h, int64_t arg_68h,
                      int64_t arg_70h)
{
    int32_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    uint64_t uVar5;
    char cVar6;
    char *pcVar7;
    undefined4 *puVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint64_t unaff_RBX;
    int64_t iVar11;
    int64_t unaff_RDI;
    uint64_t uVar12;
    uint64_t *unaff_R12;
    int64_t unaff_R13;
    uint64_t uVar13;
    int64_t var_20h;
    
    uVar13 = 0;
    do {
        iVar3 = arg_68h;
        if (*unaff_R12 <= uVar13) break;
        uVar2 = *(uint64_t *)(*(int64_t *)(unaff_R13 + 0x28) + uVar13 * 8);
        iVar3 = *(int64_t *)(*(int64_t *)(unaff_R13 + 0x38) + uVar13 * 8);
        piVar4 = *(int64_t **)(unaff_RDI + 0x10);
        if ((piVar4[2] != 0) && (uVar2 != piVar4[3])) {
            uVar10 = (uVar2 >> 5 ^ uVar2) >> 4;
            uVar12 = 0;
            do {
                uVar10 = uVar10 & piVar4[1] - 1U;
                iVar9 = *piVar4 + uVar10 * 0x18;
                uVar5 = *(uint64_t *)(*piVar4 + uVar10 * 0x18);
                if (uVar5 == uVar2) goto code_r0x0001800c3dd9;
                if (uVar5 == piVar4[3]) break;
                uVar10 = uVar10 + 1 + uVar12;
                uVar12 = uVar12 + 1;
            } while (uVar12 <= piVar4[1] - 1U);
        }
        iVar9 = 0;
code_r0x0001800c3dd9:
        pcVar7 = (char *)(iVar9 + 0x10);
        if (iVar9 == 0) {
            pcVar7 = (char *)0x8;
        }
        if (*pcVar7 == '\0') {
            iVar1 = *(int32_t *)(iVar3 + 8);
            iVar9 = 0;
            if (iVar1 == *(int32_t *)0x180782758) {
                iVar9 = iVar3;
            }
            if (iVar9 == 0) {
                iVar9 = 0;
                if (iVar1 == *(int32_t *)0x1807826c0) {
                    iVar9 = iVar3;
                }
                if (iVar9 == 0) {
                    iVar9 = 0;
                    if (iVar1 == *(int32_t *)0x180782708) {
                        iVar9 = iVar3;
                    }
                    if (iVar9 != 0) goto code_r0x0001800c3e95;
                    iVar9 = 0;
                    if (iVar1 == *(int32_t *)0x180782674) {
                        iVar9 = iVar3;
                    }
                    if (iVar9 != 0) goto code_r0x0001800c3e95;
                } else {
code_r0x0001800c3e95:
                    cVar6 = func_0x0001800c3740();
                    if (cVar6 != '\0') goto code_r0x0001800c3e52;
                }
code_r0x0001800c3eab:
                cVar6 = func_0x0001800c3440();
                if (cVar6 != '\0') {
                    puVar8 = (undefined4 *)func_0x0001800ac540(*(undefined8 *)(unaff_RDI + 8));
                    *puVar8 = 1;
                }
            } else {
                iVar11 = *(int64_t *)(iVar9 + 0x20);
                iVar9 = iVar11 + *(int64_t *)(iVar9 + 0x28) * 0x18;
                for (; iVar11 != iVar9; iVar11 = iVar11 + 0x18) {
                    if (((*(int64_t *)(iVar11 + 8) != 0) && (cVar6 = func_0x0001800c3440(), cVar6 == '\0')) ||
                       (cVar6 = func_0x0001800c3440(), cVar6 == '\0')) goto code_r0x0001800c3eab;
                }
code_r0x0001800c3e52:
                puVar8 = (undefined4 *)func_0x0001800ac540(*(undefined8 *)(unaff_RDI + 8));
                *puVar8 = 0;
            }
        }
        piVar4 = *(int64_t **)(unaff_RDI + 8);
        if ((piVar4[2] != 0) && (uVar2 != piVar4[3])) {
            uVar10 = (uVar2 >> 5 ^ uVar2) >> 4;
            uVar12 = 0;
            do {
                uVar10 = uVar10 & piVar4[1] - 1U;
                uVar5 = *(uint64_t *)(*piVar4 + uVar10 * 0x10);
                if (uVar5 == uVar2) goto code_r0x0001800c400b;
                if (uVar5 == piVar4[3]) break;
                uVar10 = uVar10 + 1 + uVar12;
                uVar12 = uVar12 + 1;
            } while (uVar12 <= piVar4[1] - 1U);
        }
        iVar1 = *(int32_t *)(iVar3 + 8);
        iVar9 = 0;
        if (iVar1 == *(int32_t *)0x1807826c0) {
            iVar9 = iVar3;
        }
        if (iVar9 == 0) {
            iVar9 = 0;
            if (iVar1 == *(int32_t *)0x180782708) {
                iVar9 = iVar3;
            }
            if (iVar9 == 0) {
                iVar9 = 0;
                if (iVar1 == *(int32_t *)0x180782674) {
                    iVar9 = iVar3;
                }
                if (iVar9 == 0) {
                    iVar9 = 0;
                    if (iVar1 == *(int32_t *)0x18078270c) {
                        iVar9 = iVar3;
                    }
                    if (iVar9 == 0) {
                        iVar9 = 0;
                        if (iVar1 == *(int32_t *)0x180782668) {
                            iVar9 = iVar3;
                        }
                        if ((iVar9 == 0) || (1 < *(int32_t *)(iVar9 + 0x20) - 0xeU)) goto code_r0x0001800c3ffc;
                        cVar6 = func_0x0001800c3830();
                    } else {
                        cVar6 = func_0x0001800c3830();
                    }
                    if (cVar6 == '\0') {
                        func_0x0001800c3830();
                    }
                } else {
                    func_0x0001800c3830();
                }
            } else {
                func_0x0001800c3830();
            }
        } else {
            func_0x0001800c3830();
        }
code_r0x0001800c3ffc:
        func_0x0001800c3930();
code_r0x0001800c400b:
        unaff_RBX = *(uint64_t *)(unaff_R13 + 0x30);
        uVar13 = uVar13 + 1;
        iVar3 = unaff_R13 + 0x38;
    } while (uVar13 < unaff_RBX);
    arg_68h = iVar3;
    if (unaff_RBX < *unaff_R12) {
        do {
            func_0x0001800c3930();
            unaff_RBX = unaff_RBX + 1;
        } while (unaff_RBX < *unaff_R12);
    }
    return arg_68h & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c4050
// Address: 0x1800c4050
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_60h
// WARNING: Variable defined which should be unmapped: arg_38h
// WARNING: Variable defined which should be unmapped: arg_28h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800c3d3e(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_60h, int64_t arg_68h,
                      int64_t arg_70h)
{
    int32_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    uint64_t uVar5;
    char cVar6;
    char *pcVar7;
    undefined4 *puVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint64_t unaff_RBX;
    int64_t iVar11;
    int64_t unaff_RDI;
    uint64_t uVar12;
    uint64_t *unaff_R12;
    int64_t unaff_R13;
    uint64_t uVar13;
    int64_t var_20h;
    
    uVar13 = 0;
    do {
        iVar3 = arg_68h;
        if (*unaff_R12 <= uVar13) break;
        uVar2 = *(uint64_t *)(*(int64_t *)(unaff_R13 + 0x28) + uVar13 * 8);
        iVar3 = *(int64_t *)(*(int64_t *)(unaff_R13 + 0x38) + uVar13 * 8);
        piVar4 = *(int64_t **)(unaff_RDI + 0x10);
        if ((piVar4[2] != 0) && (uVar2 != piVar4[3])) {
            uVar10 = (uVar2 >> 5 ^ uVar2) >> 4;
            uVar12 = 0;
            do {
                uVar10 = uVar10 & piVar4[1] - 1U;
                iVar9 = *piVar4 + uVar10 * 0x18;
                uVar5 = *(uint64_t *)(*piVar4 + uVar10 * 0x18);
                if (uVar5 == uVar2) goto code_r0x0001800c3dd9;
                if (uVar5 == piVar4[3]) break;
                uVar10 = uVar10 + 1 + uVar12;
                uVar12 = uVar12 + 1;
            } while (uVar12 <= piVar4[1] - 1U);
        }
        iVar9 = 0;
code_r0x0001800c3dd9:
        pcVar7 = (char *)(iVar9 + 0x10);
        if (iVar9 == 0) {
            pcVar7 = (char *)0x8;
        }
        if (*pcVar7 == '\0') {
            iVar1 = *(int32_t *)(iVar3 + 8);
            iVar9 = 0;
            if (iVar1 == *(int32_t *)0x180782758) {
                iVar9 = iVar3;
            }
            if (iVar9 == 0) {
                iVar9 = 0;
                if (iVar1 == *(int32_t *)0x1807826c0) {
                    iVar9 = iVar3;
                }
                if (iVar9 == 0) {
                    iVar9 = 0;
                    if (iVar1 == *(int32_t *)0x180782708) {
                        iVar9 = iVar3;
                    }
                    if (iVar9 != 0) goto code_r0x0001800c3e95;
                    iVar9 = 0;
                    if (iVar1 == *(int32_t *)0x180782674) {
                        iVar9 = iVar3;
                    }
                    if (iVar9 != 0) goto code_r0x0001800c3e95;
                } else {
code_r0x0001800c3e95:
                    cVar6 = func_0x0001800c3740();
                    if (cVar6 != '\0') goto code_r0x0001800c3e52;
                }
code_r0x0001800c3eab:
                cVar6 = func_0x0001800c3440();
                if (cVar6 != '\0') {
                    puVar8 = (undefined4 *)func_0x0001800ac540(*(undefined8 *)(unaff_RDI + 8));
                    *puVar8 = 1;
                }
            } else {
                iVar11 = *(int64_t *)(iVar9 + 0x20);
                iVar9 = iVar11 + *(int64_t *)(iVar9 + 0x28) * 0x18;
                for (; iVar11 != iVar9; iVar11 = iVar11 + 0x18) {
                    if (((*(int64_t *)(iVar11 + 8) != 0) && (cVar6 = func_0x0001800c3440(), cVar6 == '\0')) ||
                       (cVar6 = func_0x0001800c3440(), cVar6 == '\0')) goto code_r0x0001800c3eab;
                }
code_r0x0001800c3e52:
                puVar8 = (undefined4 *)func_0x0001800ac540(*(undefined8 *)(unaff_RDI + 8));
                *puVar8 = 0;
            }
        }
        piVar4 = *(int64_t **)(unaff_RDI + 8);
        if ((piVar4[2] != 0) && (uVar2 != piVar4[3])) {
            uVar10 = (uVar2 >> 5 ^ uVar2) >> 4;
            uVar12 = 0;
            do {
                uVar10 = uVar10 & piVar4[1] - 1U;
                uVar5 = *(uint64_t *)(*piVar4 + uVar10 * 0x10);
                if (uVar5 == uVar2) goto code_r0x0001800c400b;
                if (uVar5 == piVar4[3]) break;
                uVar10 = uVar10 + 1 + uVar12;
                uVar12 = uVar12 + 1;
            } while (uVar12 <= piVar4[1] - 1U);
        }
        iVar1 = *(int32_t *)(iVar3 + 8);
        iVar9 = 0;
        if (iVar1 == *(int32_t *)0x1807826c0) {
            iVar9 = iVar3;
        }
        if (iVar9 == 0) {
            iVar9 = 0;
            if (iVar1 == *(int32_t *)0x180782708) {
                iVar9 = iVar3;
            }
            if (iVar9 == 0) {
                iVar9 = 0;
                if (iVar1 == *(int32_t *)0x180782674) {
                    iVar9 = iVar3;
                }
                if (iVar9 == 0) {
                    iVar9 = 0;
                    if (iVar1 == *(int32_t *)0x18078270c) {
                        iVar9 = iVar3;
                    }
                    if (iVar9 == 0) {
                        iVar9 = 0;
                        if (iVar1 == *(int32_t *)0x180782668) {
                            iVar9 = iVar3;
                        }
                        if ((iVar9 == 0) || (1 < *(int32_t *)(iVar9 + 0x20) - 0xeU)) goto code_r0x0001800c3ffc;
                        cVar6 = func_0x0001800c3830();
                    } else {
                        cVar6 = func_0x0001800c3830();
                    }
                    if (cVar6 == '\0') {
                        func_0x0001800c3830();
                    }
                } else {
                    func_0x0001800c3830();
                }
            } else {
                func_0x0001800c3830();
            }
        } else {
            func_0x0001800c3830();
        }
code_r0x0001800c3ffc:
        func_0x0001800c3930();
code_r0x0001800c400b:
        unaff_RBX = *(uint64_t *)(unaff_R13 + 0x30);
        uVar13 = uVar13 + 1;
        iVar3 = unaff_R13 + 0x38;
    } while (uVar13 < unaff_RBX);
    arg_68h = iVar3;
    if (unaff_RBX < *unaff_R12) {
        do {
            func_0x0001800c3930();
            unaff_RBX = unaff_RBX + 1;
        } while (unaff_RBX < *unaff_R12);
    }
    return arg_68h & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c4080
// Address: 0x1800c4080
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1800c4080(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    char cVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    undefined8 *puVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar7 = *(uint64_t *)(arg2 + 0x30);
    if (uVar7 != 0) {
        uVar9 = 0;
        do {
            if (*(uint64_t *)(arg2 + 0x40) <= uVar9) break;
            iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x38) + uVar9 * 8);
            iVar2 = *(int32_t *)(iVar3 + 8);
            iVar5 = 0;
            if (iVar2 == *(int32_t *)0x1807826c0) {
                iVar5 = iVar3;
            }
            if (iVar5 == 0) {
                iVar5 = 0;
                if (iVar2 == *(int32_t *)0x180782708) {
                    iVar5 = iVar3;
                }
                if (iVar5 == 0) {
                    iVar5 = 0;
                    if (iVar2 == *(int32_t *)0x180782674) {
                        iVar5 = iVar3;
                    }
                    if (iVar5 == 0) {
                        iVar5 = 0;
                        if (iVar2 == *(int32_t *)0x18078270c) {
                            iVar5 = iVar3;
                        }
                        if (iVar5 == 0) {
                            iVar5 = 0;
                            if (iVar2 == *(int32_t *)0x180782668) {
                                iVar5 = iVar3;
                            }
                            if ((iVar5 == 0) || (1 < *(int32_t *)(iVar5 + 0x20) - 0xeU)) {
                                cVar4 = iVar2 == *(int32_t *)0x180782728;
                                goto code_r0x0001800c4199;
                            }
                            cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x28));
                            if (cVar4 == '\0') {
                                uVar6 = *(undefined8 *)(iVar5 + 0x30);
                                goto code_r0x0001800c414f;
                            }
                        } else {
                            cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x30));
                            if (cVar4 == '\0') {
                                uVar6 = *(undefined8 *)(iVar5 + 0x40);
code_r0x0001800c414f:
                                cVar4 = func_0x0001800c3830(arg1, uVar6);
                                if (cVar4 == '\0') goto code_r0x0001800c4199;
                            }
                        }
                        cVar4 = '\x01';
                    } else {
                        cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x20));
                    }
                } else {
                    cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x20));
                }
            } else {
                cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x20));
            }
code_r0x0001800c4199:
            func_0x0001800c3930(arg1, iVar3, cVar4);
            uVar7 = *(uint64_t *)(arg2 + 0x30);
            uVar9 = uVar9 + 1;
        } while (uVar9 < uVar7);
    }
    if (uVar7 < *(uint64_t *)(arg2 + 0x40)) {
        do {
            func_0x0001800c3930(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 0x38) + uVar7 * 8), 0);
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg2 + 0x40));
    }
    puVar8 = *(undefined8 **)(arg2 + 0x28);
    uVar7 = *(uint64_t *)(arg2 + 0x30);
    puVar1 = puVar8 + uVar7;
    for (; puVar8 != puVar1; puVar8 = puVar8 + 1) {
        uVar7 = func_0x0001800c3930(arg1, *puVar8, 1);
    }
    return uVar7 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c4090
// Address: 0x1800c4090
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1800c4080(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    char cVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    undefined8 *puVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar7 = *(uint64_t *)(arg2 + 0x30);
    if (uVar7 != 0) {
        uVar9 = 0;
        do {
            if (*(uint64_t *)(arg2 + 0x40) <= uVar9) break;
            iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x38) + uVar9 * 8);
            iVar2 = *(int32_t *)(iVar3 + 8);
            iVar5 = 0;
            if (iVar2 == *(int32_t *)0x1807826c0) {
                iVar5 = iVar3;
            }
            if (iVar5 == 0) {
                iVar5 = 0;
                if (iVar2 == *(int32_t *)0x180782708) {
                    iVar5 = iVar3;
                }
                if (iVar5 == 0) {
                    iVar5 = 0;
                    if (iVar2 == *(int32_t *)0x180782674) {
                        iVar5 = iVar3;
                    }
                    if (iVar5 == 0) {
                        iVar5 = 0;
                        if (iVar2 == *(int32_t *)0x18078270c) {
                            iVar5 = iVar3;
                        }
                        if (iVar5 == 0) {
                            iVar5 = 0;
                            if (iVar2 == *(int32_t *)0x180782668) {
                                iVar5 = iVar3;
                            }
                            if ((iVar5 == 0) || (1 < *(int32_t *)(iVar5 + 0x20) - 0xeU)) {
                                cVar4 = iVar2 == *(int32_t *)0x180782728;
                                goto code_r0x0001800c4199;
                            }
                            cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x28));
                            if (cVar4 == '\0') {
                                uVar6 = *(undefined8 *)(iVar5 + 0x30);
                                goto code_r0x0001800c414f;
                            }
                        } else {
                            cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x30));
                            if (cVar4 == '\0') {
                                uVar6 = *(undefined8 *)(iVar5 + 0x40);
code_r0x0001800c414f:
                                cVar4 = func_0x0001800c3830(arg1, uVar6);
                                if (cVar4 == '\0') goto code_r0x0001800c4199;
                            }
                        }
                        cVar4 = '\x01';
                    } else {
                        cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x20));
                    }
                } else {
                    cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x20));
                }
            } else {
                cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x20));
            }
code_r0x0001800c4199:
            func_0x0001800c3930(arg1, iVar3, cVar4);
            uVar7 = *(uint64_t *)(arg2 + 0x30);
            uVar9 = uVar9 + 1;
        } while (uVar9 < uVar7);
    }
    if (uVar7 < *(uint64_t *)(arg2 + 0x40)) {
        do {
            func_0x0001800c3930(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 0x38) + uVar7 * 8), 0);
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg2 + 0x40));
    }
    puVar8 = *(undefined8 **)(arg2 + 0x28);
    uVar7 = *(uint64_t *)(arg2 + 0x30);
    puVar1 = puVar8 + uVar7;
    for (; puVar8 != puVar1; puVar8 = puVar8 + 1) {
        uVar7 = func_0x0001800c3930(arg1, *puVar8, 1);
    }
    return uVar7 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c4098
// Address: 0x1800c4098
// Size: 299 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1800c4080(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    char cVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    undefined8 *puVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar7 = *(uint64_t *)(arg2 + 0x30);
    if (uVar7 != 0) {
        uVar9 = 0;
        do {
            if (*(uint64_t *)(arg2 + 0x40) <= uVar9) break;
            iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x38) + uVar9 * 8);
            iVar2 = *(int32_t *)(iVar3 + 8);
            iVar5 = 0;
            if (iVar2 == *(int32_t *)0x1807826c0) {
                iVar5 = iVar3;
            }
            if (iVar5 == 0) {
                iVar5 = 0;
                if (iVar2 == *(int32_t *)0x180782708) {
                    iVar5 = iVar3;
                }
                if (iVar5 == 0) {
                    iVar5 = 0;
                    if (iVar2 == *(int32_t *)0x180782674) {
                        iVar5 = iVar3;
                    }
                    if (iVar5 == 0) {
                        iVar5 = 0;
                        if (iVar2 == *(int32_t *)0x18078270c) {
                            iVar5 = iVar3;
                        }
                        if (iVar5 == 0) {
                            iVar5 = 0;
                            if (iVar2 == *(int32_t *)0x180782668) {
                                iVar5 = iVar3;
                            }
                            if ((iVar5 == 0) || (1 < *(int32_t *)(iVar5 + 0x20) - 0xeU)) {
                                cVar4 = iVar2 == *(int32_t *)0x180782728;
                                goto code_r0x0001800c4199;
                            }
                            cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x28));
                            if (cVar4 == '\0') {
                                uVar6 = *(undefined8 *)(iVar5 + 0x30);
                                goto code_r0x0001800c414f;
                            }
                        } else {
                            cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x30));
                            if (cVar4 == '\0') {
                                uVar6 = *(undefined8 *)(iVar5 + 0x40);
code_r0x0001800c414f:
                                cVar4 = func_0x0001800c3830(arg1, uVar6);
                                if (cVar4 == '\0') goto code_r0x0001800c4199;
                            }
                        }
                        cVar4 = '\x01';
                    } else {
                        cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x20));
                    }
                } else {
                    cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x20));
                }
            } else {
                cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x20));
            }
code_r0x0001800c4199:
            func_0x0001800c3930(arg1, iVar3, cVar4);
            uVar7 = *(uint64_t *)(arg2 + 0x30);
            uVar9 = uVar9 + 1;
        } while (uVar9 < uVar7);
    }
    if (uVar7 < *(uint64_t *)(arg2 + 0x40)) {
        do {
            func_0x0001800c3930(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 0x38) + uVar7 * 8), 0);
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg2 + 0x40));
    }
    puVar8 = *(undefined8 **)(arg2 + 0x28);
    uVar7 = *(uint64_t *)(arg2 + 0x30);
    puVar1 = puVar8 + uVar7;
    for (; puVar8 != puVar1; puVar8 = puVar8 + 1) {
        uVar7 = func_0x0001800c3930(arg1, *puVar8, 1);
    }
    return uVar7 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c41c3
// Address: 0x1800c41c3
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1800c4080(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    char cVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    undefined8 *puVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar7 = *(uint64_t *)(arg2 + 0x30);
    if (uVar7 != 0) {
        uVar9 = 0;
        do {
            if (*(uint64_t *)(arg2 + 0x40) <= uVar9) break;
            iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x38) + uVar9 * 8);
            iVar2 = *(int32_t *)(iVar3 + 8);
            iVar5 = 0;
            if (iVar2 == *(int32_t *)0x1807826c0) {
                iVar5 = iVar3;
            }
            if (iVar5 == 0) {
                iVar5 = 0;
                if (iVar2 == *(int32_t *)0x180782708) {
                    iVar5 = iVar3;
                }
                if (iVar5 == 0) {
                    iVar5 = 0;
                    if (iVar2 == *(int32_t *)0x180782674) {
                        iVar5 = iVar3;
                    }
                    if (iVar5 == 0) {
                        iVar5 = 0;
                        if (iVar2 == *(int32_t *)0x18078270c) {
                            iVar5 = iVar3;
                        }
                        if (iVar5 == 0) {
                            iVar5 = 0;
                            if (iVar2 == *(int32_t *)0x180782668) {
                                iVar5 = iVar3;
                            }
                            if ((iVar5 == 0) || (1 < *(int32_t *)(iVar5 + 0x20) - 0xeU)) {
                                cVar4 = iVar2 == *(int32_t *)0x180782728;
                                goto code_r0x0001800c4199;
                            }
                            cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x28));
                            if (cVar4 == '\0') {
                                uVar6 = *(undefined8 *)(iVar5 + 0x30);
                                goto code_r0x0001800c414f;
                            }
                        } else {
                            cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x30));
                            if (cVar4 == '\0') {
                                uVar6 = *(undefined8 *)(iVar5 + 0x40);
code_r0x0001800c414f:
                                cVar4 = func_0x0001800c3830(arg1, uVar6);
                                if (cVar4 == '\0') goto code_r0x0001800c4199;
                            }
                        }
                        cVar4 = '\x01';
                    } else {
                        cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x20));
                    }
                } else {
                    cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x20));
                }
            } else {
                cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x20));
            }
code_r0x0001800c4199:
            func_0x0001800c3930(arg1, iVar3, cVar4);
            uVar7 = *(uint64_t *)(arg2 + 0x30);
            uVar9 = uVar9 + 1;
        } while (uVar9 < uVar7);
    }
    if (uVar7 < *(uint64_t *)(arg2 + 0x40)) {
        do {
            func_0x0001800c3930(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 0x38) + uVar7 * 8), 0);
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg2 + 0x40));
    }
    puVar8 = *(undefined8 **)(arg2 + 0x28);
    uVar7 = *(uint64_t *)(arg2 + 0x30);
    puVar1 = puVar8 + uVar7;
    for (; puVar8 != puVar1; puVar8 = puVar8 + 1) {
        uVar7 = func_0x0001800c3930(arg1, *puVar8, 1);
    }
    return uVar7 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c4200
// Address: 0x1800c4200
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1800c4080(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    char cVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    undefined8 *puVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar7 = *(uint64_t *)(arg2 + 0x30);
    if (uVar7 != 0) {
        uVar9 = 0;
        do {
            if (*(uint64_t *)(arg2 + 0x40) <= uVar9) break;
            iVar3 = *(int64_t *)(*(int64_t *)(arg2 + 0x38) + uVar9 * 8);
            iVar2 = *(int32_t *)(iVar3 + 8);
            iVar5 = 0;
            if (iVar2 == *(int32_t *)0x1807826c0) {
                iVar5 = iVar3;
            }
            if (iVar5 == 0) {
                iVar5 = 0;
                if (iVar2 == *(int32_t *)0x180782708) {
                    iVar5 = iVar3;
                }
                if (iVar5 == 0) {
                    iVar5 = 0;
                    if (iVar2 == *(int32_t *)0x180782674) {
                        iVar5 = iVar3;
                    }
                    if (iVar5 == 0) {
                        iVar5 = 0;
                        if (iVar2 == *(int32_t *)0x18078270c) {
                            iVar5 = iVar3;
                        }
                        if (iVar5 == 0) {
                            iVar5 = 0;
                            if (iVar2 == *(int32_t *)0x180782668) {
                                iVar5 = iVar3;
                            }
                            if ((iVar5 == 0) || (1 < *(int32_t *)(iVar5 + 0x20) - 0xeU)) {
                                cVar4 = iVar2 == *(int32_t *)0x180782728;
                                goto code_r0x0001800c4199;
                            }
                            cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x28));
                            if (cVar4 == '\0') {
                                uVar6 = *(undefined8 *)(iVar5 + 0x30);
                                goto code_r0x0001800c414f;
                            }
                        } else {
                            cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x30));
                            if (cVar4 == '\0') {
                                uVar6 = *(undefined8 *)(iVar5 + 0x40);
code_r0x0001800c414f:
                                cVar4 = func_0x0001800c3830(arg1, uVar6);
                                if (cVar4 == '\0') goto code_r0x0001800c4199;
                            }
                        }
                        cVar4 = '\x01';
                    } else {
                        cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x20));
                    }
                } else {
                    cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x20));
                }
            } else {
                cVar4 = func_0x0001800c3830(arg1, *(undefined8 *)(iVar5 + 0x20));
            }
code_r0x0001800c4199:
            func_0x0001800c3930(arg1, iVar3, cVar4);
            uVar7 = *(uint64_t *)(arg2 + 0x30);
            uVar9 = uVar9 + 1;
        } while (uVar9 < uVar7);
    }
    if (uVar7 < *(uint64_t *)(arg2 + 0x40)) {
        do {
            func_0x0001800c3930(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 0x38) + uVar7 * 8), 0);
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg2 + 0x40));
    }
    puVar8 = *(undefined8 **)(arg2 + 0x28);
    uVar7 = *(uint64_t *)(arg2 + 0x30);
    puVar1 = puVar8 + uVar7;
    for (; puVar8 != puVar1; puVar8 = puVar8 + 1) {
        uVar7 = func_0x0001800c3930(arg1, *puVar8, 1);
    }
    return uVar7 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c4230
// Address: 0x1800c4230
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined fcn.1800c4230(int64_t arg1, int64_t arg2)
{
    undefined uVar1;
    int64_t var_8h;
    
    uVar1 = fcn.1800c3830(arg1, *(undefined8 *)(arg2 + 0x38));
    fcn.1800c3930(arg1, *(undefined8 *)(arg2 + 0x38), uVar1);
    fcn.1800c3930(arg1, *(undefined8 *)(arg2 + 0x30), 1);
    return 0;
}

// ============================================================
// Function: FUN_1800c4280
// Address: 0x1800c4280
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined fcn.1800c4280(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    fcn.1800c3930(arg1, *(undefined8 *)(arg2 + 0x30), 0);
    fcn.1800c3930(arg1, *(undefined8 *)(arg2 + 0x28), 1);
    return 0;
}

// ============================================================
// Function: FUN_1800c42c0
// Address: 0x1800c42c0
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1800c42c0(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    char cVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar8 = *(int64_t **)(arg2 + 0x28);
    uVar5 = *(uint64_t *)(arg2 + 0x30);
    piVar1 = piVar8 + uVar5;
    do {
        if (piVar8 == piVar1) {
            return uVar5 & 0xffffffffffffff00;
        }
        iVar3 = *piVar8;
        iVar2 = *(int32_t *)(iVar3 + 8);
        iVar6 = 0;
        if (iVar2 == *(int32_t *)0x1807826c0) {
            iVar6 = iVar3;
        }
        if (iVar6 == 0) {
            iVar6 = 0;
            if (iVar2 == *(int32_t *)0x180782708) {
                iVar6 = iVar3;
            }
            if (iVar6 == 0) {
                iVar6 = 0;
                if (iVar2 == *(int32_t *)0x180782674) {
                    iVar6 = iVar3;
                }
                if (iVar6 == 0) {
                    iVar6 = 0;
                    if (iVar2 == *(int32_t *)0x18078270c) {
                        iVar6 = iVar3;
                    }
                    if (iVar6 == 0) {
                        iVar6 = 0;
                        if (iVar2 == *(int32_t *)0x180782668) {
                            iVar6 = iVar3;
                        }
                        if ((iVar6 == 0) || (1 < *(int32_t *)(iVar6 + 0x20) - 0xeU)) {
                            cVar4 = iVar2 == *(int32_t *)0x180782728;
                            goto code_r0x0001800c43c5;
                        }
                        cVar4 = fcn.1800c3830(arg1, *(undefined8 *)(iVar6 + 0x28));
                        if (cVar4 == '\0') {
                            uVar7 = *(undefined8 *)(iVar6 + 0x30);
                            goto code_r0x0001800c437b;
                        }
                    } else {
                        cVar4 = fcn.1800c3830(arg1, *(undefined8 *)(iVar6 + 0x30));
                        if (cVar4 == '\0') {
                            uVar7 = *(undefined8 *)(iVar6 + 0x40);
code_r0x0001800c437b:
                            cVar4 = fcn.1800c3830(arg1, uVar7);
                            if (cVar4 == '\0') goto code_r0x0001800c43c5;
                        }
                    }
                    cVar4 = '\x01';
                } else {
                    cVar4 = fcn.1800c3830(arg1, *(undefined8 *)(iVar6 + 0x20));
                }
            } else {
                cVar4 = fcn.1800c3830(arg1, *(undefined8 *)(iVar6 + 0x20));
            }
        } else {
            cVar4 = fcn.1800c3830(arg1, *(undefined8 *)(iVar6 + 0x20));
        }
code_r0x0001800c43c5:
        uVar5 = fcn.1800c3930(arg1, iVar3, cVar4);
        piVar8 = piVar8 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800c42e7
// Address: 0x1800c42e7
// Size: 255 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1800c42c0(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    char cVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar8 = *(int64_t **)(arg2 + 0x28);
    uVar5 = *(uint64_t *)(arg2 + 0x30);
    piVar1 = piVar8 + uVar5;
    do {
        if (piVar8 == piVar1) {
            return uVar5 & 0xffffffffffffff00;
        }
        iVar3 = *piVar8;
        iVar2 = *(int32_t *)(iVar3 + 8);
        iVar6 = 0;
        if (iVar2 == *(int32_t *)0x1807826c0) {
            iVar6 = iVar3;
        }
        if (iVar6 == 0) {
            iVar6 = 0;
            if (iVar2 == *(int32_t *)0x180782708) {
                iVar6 = iVar3;
            }
            if (iVar6 == 0) {
                iVar6 = 0;
                if (iVar2 == *(int32_t *)0x180782674) {
                    iVar6 = iVar3;
                }
                if (iVar6 == 0) {
                    iVar6 = 0;
                    if (iVar2 == *(int32_t *)0x18078270c) {
                        iVar6 = iVar3;
                    }
                    if (iVar6 == 0) {
                        iVar6 = 0;
                        if (iVar2 == *(int32_t *)0x180782668) {
                            iVar6 = iVar3;
                        }
                        if ((iVar6 == 0) || (1 < *(int32_t *)(iVar6 + 0x20) - 0xeU)) {
                            cVar4 = iVar2 == *(int32_t *)0x180782728;
                            goto code_r0x0001800c43c5;
                        }
                        cVar4 = fcn.1800c3830(arg1, *(undefined8 *)(iVar6 + 0x28));
                        if (cVar4 == '\0') {
                            uVar7 = *(undefined8 *)(iVar6 + 0x30);
                            goto code_r0x0001800c437b;
                        }
                    } else {
                        cVar4 = fcn.1800c3830(arg1, *(undefined8 *)(iVar6 + 0x30));
                        if (cVar4 == '\0') {
                            uVar7 = *(undefined8 *)(iVar6 + 0x40);
code_r0x0001800c437b:
                            cVar4 = fcn.1800c3830(arg1, uVar7);
                            if (cVar4 == '\0') goto code_r0x0001800c43c5;
                        }
                    }
                    cVar4 = '\x01';
                } else {
                    cVar4 = fcn.1800c3830(arg1, *(undefined8 *)(iVar6 + 0x20));
                }
            } else {
                cVar4 = fcn.1800c3830(arg1, *(undefined8 *)(iVar6 + 0x20));
            }
        } else {
            cVar4 = fcn.1800c3830(arg1, *(undefined8 *)(iVar6 + 0x20));
        }
code_r0x0001800c43c5:
        uVar5 = fcn.1800c3930(arg1, iVar3, cVar4);
        piVar8 = piVar8 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800c43e6
// Address: 0x1800c43e6
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1800c42c0(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    char cVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar8 = *(int64_t **)(arg2 + 0x28);
    uVar5 = *(uint64_t *)(arg2 + 0x30);
    piVar1 = piVar8 + uVar5;
    do {
        if (piVar8 == piVar1) {
            return uVar5 & 0xffffffffffffff00;
        }
        iVar3 = *piVar8;
        iVar2 = *(int32_t *)(iVar3 + 8);
        iVar6 = 0;
        if (iVar2 == *(int32_t *)0x1807826c0) {
            iVar6 = iVar3;
        }
        if (iVar6 == 0) {
            iVar6 = 0;
            if (iVar2 == *(int32_t *)0x180782708) {
                iVar6 = iVar3;
            }
            if (iVar6 == 0) {
                iVar6 = 0;
                if (iVar2 == *(int32_t *)0x180782674) {
                    iVar6 = iVar3;
                }
                if (iVar6 == 0) {
                    iVar6 = 0;
                    if (iVar2 == *(int32_t *)0x18078270c) {
                        iVar6 = iVar3;
                    }
                    if (iVar6 == 0) {
                        iVar6 = 0;
                        if (iVar2 == *(int32_t *)0x180782668) {
                            iVar6 = iVar3;
                        }
                        if ((iVar6 == 0) || (1 < *(int32_t *)(iVar6 + 0x20) - 0xeU)) {
                            cVar4 = iVar2 == *(int32_t *)0x180782728;
                            goto code_r0x0001800c43c5;
                        }
                        cVar4 = fcn.1800c3830(arg1, *(undefined8 *)(iVar6 + 0x28));
                        if (cVar4 == '\0') {
                            uVar7 = *(undefined8 *)(iVar6 + 0x30);
                            goto code_r0x0001800c437b;
                        }
                    } else {
                        cVar4 = fcn.1800c3830(arg1, *(undefined8 *)(iVar6 + 0x30));
                        if (cVar4 == '\0') {
                            uVar7 = *(undefined8 *)(iVar6 + 0x40);
code_r0x0001800c437b:
                            cVar4 = fcn.1800c3830(arg1, uVar7);
                            if (cVar4 == '\0') goto code_r0x0001800c43c5;
                        }
                    }
                    cVar4 = '\x01';
                } else {
                    cVar4 = fcn.1800c3830(arg1, *(undefined8 *)(iVar6 + 0x20));
                }
            } else {
                cVar4 = fcn.1800c3830(arg1, *(undefined8 *)(iVar6 + 0x20));
            }
        } else {
            cVar4 = fcn.1800c3830(arg1, *(undefined8 *)(iVar6 + 0x20));
        }
code_r0x0001800c43c5:
        uVar5 = fcn.1800c3930(arg1, iVar3, cVar4);
        piVar8 = piVar8 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800c4400
// Address: 0x1800c4400
// Size: 78 bytes
// ============================================================
uint64_t fcn.1800c4400(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    undefined8 *puVar1;
    uint64_t uVar2;
    undefined8 *puVar3;
    
    puVar3 = *(undefined8 **)(arg2 + 0x38);
    puVar1 = puVar3 + *(int64_t *)(arg2 + 0x40);
    for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
        fcn.1800c3930(arg1, *puVar3, 1);
    }
    uVar2 = (**(code **)**(undefined8 **)(arg2 + 0x48))(*(undefined8 **)(arg2 + 0x48), arg1);
    return uVar2 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c4450
// Address: 0x1800c4450
// Size: 230 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c4450(int64_t arg1, int64_t arg2, int64_t arg_80h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_30h;
    int64_t var_18h;
    
    iVar8 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782728) {
        iVar8 = arg2;
    }
    while (iVar8 == 0) {
        iVar2 = *(int32_t *)(arg2 + 8);
        iVar8 = 0;
        if (iVar2 == *(int32_t *)0x1807826c0) {
            iVar8 = arg2;
        }
        if (iVar8 == 0) {
            iVar8 = 0;
            if (iVar2 == *(int32_t *)0x180782708) {
                iVar8 = arg2;
            }
            if (iVar8 == 0) {
                iVar8 = 0;
                if (iVar2 == *(int32_t *)0x180782674) {
                    iVar8 = arg2;
                }
                if (iVar8 == 0) {
                    iVar8 = 0;
                    if (iVar2 == *(int32_t *)0x18078270c) {
                        iVar8 = arg2;
                    }
                    if (iVar8 == 0) {
                        iVar8 = 0;
                        if (iVar2 == *(int32_t *)0x180782668) {
                            iVar8 = arg2;
                        }
                        if (iVar8 == 0) {
                            return;
                        }
                        if (1 < *(int32_t *)(iVar8 + 0x20) - 0xeU) {
                            return;
                        }
                        fcn.1800c4450(arg1, *(int64_t *)(iVar8 + 0x28), var_10h);
                        arg2 = *(int64_t *)(iVar8 + 0x30);
                    } else {
                        fcn.1800c4450(arg1, *(int64_t *)(iVar8 + 0x30), var_10h);
                        arg2 = *(int64_t *)(iVar8 + 0x40);
                    }
                } else {
                    arg2 = *(int64_t *)(iVar8 + 0x20);
                }
            } else {
                arg2 = *(int64_t *)(iVar8 + 0x20);
            }
        } else {
            arg2 = *(int64_t *)(iVar8 + 0x20);
        }
        iVar8 = 0;
        if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782728) {
            iVar8 = arg2;
        }
    }
    piVar1 = (int64_t *)(arg1 + 0x10);
    iVar3 = *(int64_t *)(arg1 + 0x18);
    if (((uint64_t)(iVar3 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x20)) &&
       (iVar6 = func_0x0001800c1560(piVar1, iVar8 + 0x20), iVar6 == 0)) {
        iVar6 = 0x10;
        if (iVar3 != 0) {
            iVar6 = iVar3 * 2;
        }
        func_0x0001800c1660(&var_48h, arg1 + 0x28, iVar6);
        uVar11 = 0;
        if (*(int64_t *)(arg1 + 0x18) != 0) {
            do {
                uVar4 = *(uint64_t *)(*piVar1 + uVar11 * 8);
                if (uVar4 != *(uint64_t *)(arg1 + 0x28)) {
                    uVar7 = (uVar4 >> 5 ^ uVar4) >> 4;
                    uVar9 = 0;
                    do {
                        uVar7 = uVar7 & var_40h - 1U;
                        uVar5 = *(uint64_t *)(var_48h + uVar7 * 8);
                        puVar10 = (uint64_t *)(var_48h + uVar7 * 8);
                        if (uVar5 == var_30h) {
                            *puVar10 = uVar4;
                            goto code_r0x0001800c460a;
                        }
                        if (uVar5 == uVar4) goto code_r0x0001800c460a;
                        uVar7 = uVar7 + 1 + uVar9;
                        uVar9 = uVar9 + 1;
                    } while (uVar9 <= var_40h - 1U);
                    puVar10 = (uint64_t *)0x0;
code_r0x0001800c460a:
                    *puVar10 = *(uint64_t *)(*piVar1 + uVar11 * 8);
                }
                uVar11 = uVar11 + 1;
            } while (uVar11 < *(uint64_t *)(arg1 + 0x18));
        }
        iVar3 = *piVar1;
        *(int64_t *)(arg1 + 0x18) = var_40h;
        *piVar1 = var_48h;
        if (iVar3 != 0) {
            func_0x0001800f4640();
        }
    }
    func_0x0001800c15e0(piVar1, iVar8 + 0x20);
    return;
}

// ============================================================
// Function: FUN_1800c4536
// Address: 0x1800c4536
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c4450(int64_t arg1, int64_t arg2, int64_t arg_80h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_30h;
    int64_t var_18h;
    
    iVar8 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782728) {
        iVar8 = arg2;
    }
    while (iVar8 == 0) {
        iVar2 = *(int32_t *)(arg2 + 8);
        iVar8 = 0;
        if (iVar2 == *(int32_t *)0x1807826c0) {
            iVar8 = arg2;
        }
        if (iVar8 == 0) {
            iVar8 = 0;
            if (iVar2 == *(int32_t *)0x180782708) {
                iVar8 = arg2;
            }
            if (iVar8 == 0) {
                iVar8 = 0;
                if (iVar2 == *(int32_t *)0x180782674) {
                    iVar8 = arg2;
                }
                if (iVar8 == 0) {
                    iVar8 = 0;
                    if (iVar2 == *(int32_t *)0x18078270c) {
                        iVar8 = arg2;
                    }
                    if (iVar8 == 0) {
                        iVar8 = 0;
                        if (iVar2 == *(int32_t *)0x180782668) {
                            iVar8 = arg2;
                        }
                        if (iVar8 == 0) {
                            return;
                        }
                        if (1 < *(int32_t *)(iVar8 + 0x20) - 0xeU) {
                            return;
                        }
                        fcn.1800c4450(arg1, *(int64_t *)(iVar8 + 0x28), var_10h);
                        arg2 = *(int64_t *)(iVar8 + 0x30);
                    } else {
                        fcn.1800c4450(arg1, *(int64_t *)(iVar8 + 0x30), var_10h);
                        arg2 = *(int64_t *)(iVar8 + 0x40);
                    }
                } else {
                    arg2 = *(int64_t *)(iVar8 + 0x20);
                }
            } else {
                arg2 = *(int64_t *)(iVar8 + 0x20);
            }
        } else {
            arg2 = *(int64_t *)(iVar8 + 0x20);
        }
        iVar8 = 0;
        if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782728) {
            iVar8 = arg2;
        }
    }
    piVar1 = (int64_t *)(arg1 + 0x10);
    iVar3 = *(int64_t *)(arg1 + 0x18);
    if (((uint64_t)(iVar3 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x20)) &&
       (iVar6 = func_0x0001800c1560(piVar1, iVar8 + 0x20), iVar6 == 0)) {
        iVar6 = 0x10;
        if (iVar3 != 0) {
            iVar6 = iVar3 * 2;
        }
        func_0x0001800c1660(&var_48h, arg1 + 0x28, iVar6);
        uVar11 = 0;
        if (*(int64_t *)(arg1 + 0x18) != 0) {
            do {
                uVar4 = *(uint64_t *)(*piVar1 + uVar11 * 8);
                if (uVar4 != *(uint64_t *)(arg1 + 0x28)) {
                    uVar7 = (uVar4 >> 5 ^ uVar4) >> 4;
                    uVar9 = 0;
                    do {
                        uVar7 = uVar7 & var_40h - 1U;
                        uVar5 = *(uint64_t *)(var_48h + uVar7 * 8);
                        puVar10 = (uint64_t *)(var_48h + uVar7 * 8);
                        if (uVar5 == var_30h) {
                            *puVar10 = uVar4;
                            goto code_r0x0001800c460a;
                        }
                        if (uVar5 == uVar4) goto code_r0x0001800c460a;
                        uVar7 = uVar7 + 1 + uVar9;
                        uVar9 = uVar9 + 1;
                    } while (uVar9 <= var_40h - 1U);
                    puVar10 = (uint64_t *)0x0;
code_r0x0001800c460a:
                    *puVar10 = *(uint64_t *)(*piVar1 + uVar11 * 8);
                }
                uVar11 = uVar11 + 1;
            } while (uVar11 < *(uint64_t *)(arg1 + 0x18));
        }
        iVar3 = *piVar1;
        *(int64_t *)(arg1 + 0x18) = var_40h;
        *piVar1 = var_48h;
        if (iVar3 != 0) {
            func_0x0001800f4640();
        }
    }
    func_0x0001800c15e0(piVar1, iVar8 + 0x20);
    return;
}

// ============================================================
// Function: FUN_1800c4569
// Address: 0x1800c4569
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c4450(int64_t arg1, int64_t arg2, int64_t arg_80h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_30h;
    int64_t var_18h;
    
    iVar8 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782728) {
        iVar8 = arg2;
    }
    while (iVar8 == 0) {
        iVar2 = *(int32_t *)(arg2 + 8);
        iVar8 = 0;
        if (iVar2 == *(int32_t *)0x1807826c0) {
            iVar8 = arg2;
        }
        if (iVar8 == 0) {
            iVar8 = 0;
            if (iVar2 == *(int32_t *)0x180782708) {
                iVar8 = arg2;
            }
            if (iVar8 == 0) {
                iVar8 = 0;
                if (iVar2 == *(int32_t *)0x180782674) {
                    iVar8 = arg2;
                }
                if (iVar8 == 0) {
                    iVar8 = 0;
                    if (iVar2 == *(int32_t *)0x18078270c) {
                        iVar8 = arg2;
                    }
                    if (iVar8 == 0) {
                        iVar8 = 0;
                        if (iVar2 == *(int32_t *)0x180782668) {
                            iVar8 = arg2;
                        }
                        if (iVar8 == 0) {
                            return;
                        }
                        if (1 < *(int32_t *)(iVar8 + 0x20) - 0xeU) {
                            return;
                        }
                        fcn.1800c4450(arg1, *(int64_t *)(iVar8 + 0x28), var_10h);
                        arg2 = *(int64_t *)(iVar8 + 0x30);
                    } else {
                        fcn.1800c4450(arg1, *(int64_t *)(iVar8 + 0x30), var_10h);
                        arg2 = *(int64_t *)(iVar8 + 0x40);
                    }
                } else {
                    arg2 = *(int64_t *)(iVar8 + 0x20);
                }
            } else {
                arg2 = *(int64_t *)(iVar8 + 0x20);
            }
        } else {
            arg2 = *(int64_t *)(iVar8 + 0x20);
        }
        iVar8 = 0;
        if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782728) {
            iVar8 = arg2;
        }
    }
    piVar1 = (int64_t *)(arg1 + 0x10);
    iVar3 = *(int64_t *)(arg1 + 0x18);
    if (((uint64_t)(iVar3 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x20)) &&
       (iVar6 = func_0x0001800c1560(piVar1, iVar8 + 0x20), iVar6 == 0)) {
        iVar6 = 0x10;
        if (iVar3 != 0) {
            iVar6 = iVar3 * 2;
        }
        func_0x0001800c1660(&var_48h, arg1 + 0x28, iVar6);
        uVar11 = 0;
        if (*(int64_t *)(arg1 + 0x18) != 0) {
            do {
                uVar4 = *(uint64_t *)(*piVar1 + uVar11 * 8);
                if (uVar4 != *(uint64_t *)(arg1 + 0x28)) {
                    uVar7 = (uVar4 >> 5 ^ uVar4) >> 4;
                    uVar9 = 0;
                    do {
                        uVar7 = uVar7 & var_40h - 1U;
                        uVar5 = *(uint64_t *)(var_48h + uVar7 * 8);
                        puVar10 = (uint64_t *)(var_48h + uVar7 * 8);
                        if (uVar5 == var_30h) {
                            *puVar10 = uVar4;
                            goto code_r0x0001800c460a;
                        }
                        if (uVar5 == uVar4) goto code_r0x0001800c460a;
                        uVar7 = uVar7 + 1 + uVar9;
                        uVar9 = uVar9 + 1;
                    } while (uVar9 <= var_40h - 1U);
                    puVar10 = (uint64_t *)0x0;
code_r0x0001800c460a:
                    *puVar10 = *(uint64_t *)(*piVar1 + uVar11 * 8);
                }
                uVar11 = uVar11 + 1;
            } while (uVar11 < *(uint64_t *)(arg1 + 0x18));
        }
        iVar3 = *piVar1;
        *(int64_t *)(arg1 + 0x18) = var_40h;
        *piVar1 = var_48h;
        if (iVar3 != 0) {
            func_0x0001800f4640();
        }
    }
    func_0x0001800c15e0(piVar1, iVar8 + 0x20);
    return;
}

// ============================================================
// Function: FUN_1800c45a6
// Address: 0x1800c45a6
// Size: 124 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c4450(int64_t arg1, int64_t arg2, int64_t arg_80h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_30h;
    int64_t var_18h;
    
    iVar8 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782728) {
        iVar8 = arg2;
    }
    while (iVar8 == 0) {
        iVar2 = *(int32_t *)(arg2 + 8);
        iVar8 = 0;
        if (iVar2 == *(int32_t *)0x1807826c0) {
            iVar8 = arg2;
        }
        if (iVar8 == 0) {
            iVar8 = 0;
            if (iVar2 == *(int32_t *)0x180782708) {
                iVar8 = arg2;
            }
            if (iVar8 == 0) {
                iVar8 = 0;
                if (iVar2 == *(int32_t *)0x180782674) {
                    iVar8 = arg2;
                }
                if (iVar8 == 0) {
                    iVar8 = 0;
                    if (iVar2 == *(int32_t *)0x18078270c) {
                        iVar8 = arg2;
                    }
                    if (iVar8 == 0) {
                        iVar8 = 0;
                        if (iVar2 == *(int32_t *)0x180782668) {
                            iVar8 = arg2;
                        }
                        if (iVar8 == 0) {
                            return;
                        }
                        if (1 < *(int32_t *)(iVar8 + 0x20) - 0xeU) {
                            return;
                        }
                        fcn.1800c4450(arg1, *(int64_t *)(iVar8 + 0x28), var_10h);
                        arg2 = *(int64_t *)(iVar8 + 0x30);
                    } else {
                        fcn.1800c4450(arg1, *(int64_t *)(iVar8 + 0x30), var_10h);
                        arg2 = *(int64_t *)(iVar8 + 0x40);
                    }
                } else {
                    arg2 = *(int64_t *)(iVar8 + 0x20);
                }
            } else {
                arg2 = *(int64_t *)(iVar8 + 0x20);
            }
        } else {
            arg2 = *(int64_t *)(iVar8 + 0x20);
        }
        iVar8 = 0;
        if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782728) {
            iVar8 = arg2;
        }
    }
    piVar1 = (int64_t *)(arg1 + 0x10);
    iVar3 = *(int64_t *)(arg1 + 0x18);
    if (((uint64_t)(iVar3 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x20)) &&
       (iVar6 = func_0x0001800c1560(piVar1, iVar8 + 0x20), iVar6 == 0)) {
        iVar6 = 0x10;
        if (iVar3 != 0) {
            iVar6 = iVar3 * 2;
        }
        func_0x0001800c1660(&var_48h, arg1 + 0x28, iVar6);
        uVar11 = 0;
        if (*(int64_t *)(arg1 + 0x18) != 0) {
            do {
                uVar4 = *(uint64_t *)(*piVar1 + uVar11 * 8);
                if (uVar4 != *(uint64_t *)(arg1 + 0x28)) {
                    uVar7 = (uVar4 >> 5 ^ uVar4) >> 4;
                    uVar9 = 0;
                    do {
                        uVar7 = uVar7 & var_40h - 1U;
                        uVar5 = *(uint64_t *)(var_48h + uVar7 * 8);
                        puVar10 = (uint64_t *)(var_48h + uVar7 * 8);
                        if (uVar5 == var_30h) {
                            *puVar10 = uVar4;
                            goto code_r0x0001800c460a;
                        }
                        if (uVar5 == uVar4) goto code_r0x0001800c460a;
                        uVar7 = uVar7 + 1 + uVar9;
                        uVar9 = uVar9 + 1;
                    } while (uVar9 <= var_40h - 1U);
                    puVar10 = (uint64_t *)0x0;
code_r0x0001800c460a:
                    *puVar10 = *(uint64_t *)(*piVar1 + uVar11 * 8);
                }
                uVar11 = uVar11 + 1;
            } while (uVar11 < *(uint64_t *)(arg1 + 0x18));
        }
        iVar3 = *piVar1;
        *(int64_t *)(arg1 + 0x18) = var_40h;
        *piVar1 = var_48h;
        if (iVar3 != 0) {
            func_0x0001800f4640();
        }
    }
    func_0x0001800c15e0(piVar1, iVar8 + 0x20);
    return;
}

// ============================================================
// Function: FUN_1800c4622
// Address: 0x1800c4622
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c4450(int64_t arg1, int64_t arg2, int64_t arg_80h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_30h;
    int64_t var_18h;
    
    iVar8 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782728) {
        iVar8 = arg2;
    }
    while (iVar8 == 0) {
        iVar2 = *(int32_t *)(arg2 + 8);
        iVar8 = 0;
        if (iVar2 == *(int32_t *)0x1807826c0) {
            iVar8 = arg2;
        }
        if (iVar8 == 0) {
            iVar8 = 0;
            if (iVar2 == *(int32_t *)0x180782708) {
                iVar8 = arg2;
            }
            if (iVar8 == 0) {
                iVar8 = 0;
                if (iVar2 == *(int32_t *)0x180782674) {
                    iVar8 = arg2;
                }
                if (iVar8 == 0) {
                    iVar8 = 0;
                    if (iVar2 == *(int32_t *)0x18078270c) {
                        iVar8 = arg2;
                    }
                    if (iVar8 == 0) {
                        iVar8 = 0;
                        if (iVar2 == *(int32_t *)0x180782668) {
                            iVar8 = arg2;
                        }
                        if (iVar8 == 0) {
                            return;
                        }
                        if (1 < *(int32_t *)(iVar8 + 0x20) - 0xeU) {
                            return;
                        }
                        fcn.1800c4450(arg1, *(int64_t *)(iVar8 + 0x28), var_10h);
                        arg2 = *(int64_t *)(iVar8 + 0x30);
                    } else {
                        fcn.1800c4450(arg1, *(int64_t *)(iVar8 + 0x30), var_10h);
                        arg2 = *(int64_t *)(iVar8 + 0x40);
                    }
                } else {
                    arg2 = *(int64_t *)(iVar8 + 0x20);
                }
            } else {
                arg2 = *(int64_t *)(iVar8 + 0x20);
            }
        } else {
            arg2 = *(int64_t *)(iVar8 + 0x20);
        }
        iVar8 = 0;
        if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782728) {
            iVar8 = arg2;
        }
    }
    piVar1 = (int64_t *)(arg1 + 0x10);
    iVar3 = *(int64_t *)(arg1 + 0x18);
    if (((uint64_t)(iVar3 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x20)) &&
       (iVar6 = func_0x0001800c1560(piVar1, iVar8 + 0x20), iVar6 == 0)) {
        iVar6 = 0x10;
        if (iVar3 != 0) {
            iVar6 = iVar3 * 2;
        }
        func_0x0001800c1660(&var_48h, arg1 + 0x28, iVar6);
        uVar11 = 0;
        if (*(int64_t *)(arg1 + 0x18) != 0) {
            do {
                uVar4 = *(uint64_t *)(*piVar1 + uVar11 * 8);
                if (uVar4 != *(uint64_t *)(arg1 + 0x28)) {
                    uVar7 = (uVar4 >> 5 ^ uVar4) >> 4;
                    uVar9 = 0;
                    do {
                        uVar7 = uVar7 & var_40h - 1U;
                        uVar5 = *(uint64_t *)(var_48h + uVar7 * 8);
                        puVar10 = (uint64_t *)(var_48h + uVar7 * 8);
                        if (uVar5 == var_30h) {
                            *puVar10 = uVar4;
                            goto code_r0x0001800c460a;
                        }
                        if (uVar5 == uVar4) goto code_r0x0001800c460a;
                        uVar7 = uVar7 + 1 + uVar9;
                        uVar9 = uVar9 + 1;
                    } while (uVar9 <= var_40h - 1U);
                    puVar10 = (uint64_t *)0x0;
code_r0x0001800c460a:
                    *puVar10 = *(uint64_t *)(*piVar1 + uVar11 * 8);
                }
                uVar11 = uVar11 + 1;
            } while (uVar11 < *(uint64_t *)(arg1 + 0x18));
        }
        iVar3 = *piVar1;
        *(int64_t *)(arg1 + 0x18) = var_40h;
        *piVar1 = var_48h;
        if (iVar3 != 0) {
            func_0x0001800f4640();
        }
    }
    func_0x0001800c15e0(piVar1, iVar8 + 0x20);
    return;
}

// ============================================================
// Function: FUN_1800c463e
// Address: 0x1800c463e
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c4450(int64_t arg1, int64_t arg2, int64_t arg_80h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_30h;
    int64_t var_18h;
    
    iVar8 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782728) {
        iVar8 = arg2;
    }
    while (iVar8 == 0) {
        iVar2 = *(int32_t *)(arg2 + 8);
        iVar8 = 0;
        if (iVar2 == *(int32_t *)0x1807826c0) {
            iVar8 = arg2;
        }
        if (iVar8 == 0) {
            iVar8 = 0;
            if (iVar2 == *(int32_t *)0x180782708) {
                iVar8 = arg2;
            }
            if (iVar8 == 0) {
                iVar8 = 0;
                if (iVar2 == *(int32_t *)0x180782674) {
                    iVar8 = arg2;
                }
                if (iVar8 == 0) {
                    iVar8 = 0;
                    if (iVar2 == *(int32_t *)0x18078270c) {
                        iVar8 = arg2;
                    }
                    if (iVar8 == 0) {
                        iVar8 = 0;
                        if (iVar2 == *(int32_t *)0x180782668) {
                            iVar8 = arg2;
                        }
                        if (iVar8 == 0) {
                            return;
                        }
                        if (1 < *(int32_t *)(iVar8 + 0x20) - 0xeU) {
                            return;
                        }
                        fcn.1800c4450(arg1, *(int64_t *)(iVar8 + 0x28), var_10h);
                        arg2 = *(int64_t *)(iVar8 + 0x30);
                    } else {
                        fcn.1800c4450(arg1, *(int64_t *)(iVar8 + 0x30), var_10h);
                        arg2 = *(int64_t *)(iVar8 + 0x40);
                    }
                } else {
                    arg2 = *(int64_t *)(iVar8 + 0x20);
                }
            } else {
                arg2 = *(int64_t *)(iVar8 + 0x20);
            }
        } else {
            arg2 = *(int64_t *)(iVar8 + 0x20);
        }
        iVar8 = 0;
        if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782728) {
            iVar8 = arg2;
        }
    }
    piVar1 = (int64_t *)(arg1 + 0x10);
    iVar3 = *(int64_t *)(arg1 + 0x18);
    if (((uint64_t)(iVar3 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x20)) &&
       (iVar6 = func_0x0001800c1560(piVar1, iVar8 + 0x20), iVar6 == 0)) {
        iVar6 = 0x10;
        if (iVar3 != 0) {
            iVar6 = iVar3 * 2;
        }
        func_0x0001800c1660(&var_48h, arg1 + 0x28, iVar6);
        uVar11 = 0;
        if (*(int64_t *)(arg1 + 0x18) != 0) {
            do {
                uVar4 = *(uint64_t *)(*piVar1 + uVar11 * 8);
                if (uVar4 != *(uint64_t *)(arg1 + 0x28)) {
                    uVar7 = (uVar4 >> 5 ^ uVar4) >> 4;
                    uVar9 = 0;
                    do {
                        uVar7 = uVar7 & var_40h - 1U;
                        uVar5 = *(uint64_t *)(var_48h + uVar7 * 8);
                        puVar10 = (uint64_t *)(var_48h + uVar7 * 8);
                        if (uVar5 == var_30h) {
                            *puVar10 = uVar4;
                            goto code_r0x0001800c460a;
                        }
                        if (uVar5 == uVar4) goto code_r0x0001800c460a;
                        uVar7 = uVar7 + 1 + uVar9;
                        uVar9 = uVar9 + 1;
                    } while (uVar9 <= var_40h - 1U);
                    puVar10 = (uint64_t *)0x0;
code_r0x0001800c460a:
                    *puVar10 = *(uint64_t *)(*piVar1 + uVar11 * 8);
                }
                uVar11 = uVar11 + 1;
            } while (uVar11 < *(uint64_t *)(arg1 + 0x18));
        }
        iVar3 = *piVar1;
        *(int64_t *)(arg1 + 0x18) = var_40h;
        *piVar1 = var_48h;
        if (iVar3 != 0) {
            func_0x0001800f4640();
        }
    }
    func_0x0001800c15e0(piVar1, iVar8 + 0x20);
    return;
}

// ============================================================
// Function: FUN_1800c4653
// Address: 0x1800c4653
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800c4450(int64_t arg1, int64_t arg2, int64_t arg_80h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_30h;
    int64_t var_18h;
    
    iVar8 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782728) {
        iVar8 = arg2;
    }
    while (iVar8 == 0) {
        iVar2 = *(int32_t *)(arg2 + 8);
        iVar8 = 0;
        if (iVar2 == *(int32_t *)0x1807826c0) {
            iVar8 = arg2;
        }
        if (iVar8 == 0) {
            iVar8 = 0;
            if (iVar2 == *(int32_t *)0x180782708) {
                iVar8 = arg2;
            }
            if (iVar8 == 0) {
                iVar8 = 0;
                if (iVar2 == *(int32_t *)0x180782674) {
                    iVar8 = arg2;
                }
                if (iVar8 == 0) {
                    iVar8 = 0;
                    if (iVar2 == *(int32_t *)0x18078270c) {
                        iVar8 = arg2;
                    }
                    if (iVar8 == 0) {
                        iVar8 = 0;
                        if (iVar2 == *(int32_t *)0x180782668) {
                            iVar8 = arg2;
                        }
                        if (iVar8 == 0) {
                            return;
                        }
                        if (1 < *(int32_t *)(iVar8 + 0x20) - 0xeU) {
                            return;
                        }
                        fcn.1800c4450(arg1, *(int64_t *)(iVar8 + 0x28), var_10h);
                        arg2 = *(int64_t *)(iVar8 + 0x30);
                    } else {
                        fcn.1800c4450(arg1, *(int64_t *)(iVar8 + 0x30), var_10h);
                        arg2 = *(int64_t *)(iVar8 + 0x40);
                    }
                } else {
                    arg2 = *(int64_t *)(iVar8 + 0x20);
                }
            } else {
                arg2 = *(int64_t *)(iVar8 + 0x20);
            }
        } else {
            arg2 = *(int64_t *)(iVar8 + 0x20);
        }
        iVar8 = 0;
        if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782728) {
            iVar8 = arg2;
        }
    }
    piVar1 = (int64_t *)(arg1 + 0x10);
    iVar3 = *(int64_t *)(arg1 + 0x18);
    if (((uint64_t)(iVar3 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x20)) &&
       (iVar6 = func_0x0001800c1560(piVar1, iVar8 + 0x20), iVar6 == 0)) {
        iVar6 = 0x10;
        if (iVar3 != 0) {
            iVar6 = iVar3 * 2;
        }
        func_0x0001800c1660(&var_48h, arg1 + 0x28, iVar6);
        uVar11 = 0;
        if (*(int64_t *)(arg1 + 0x18) != 0) {
            do {
                uVar4 = *(uint64_t *)(*piVar1 + uVar11 * 8);
                if (uVar4 != *(uint64_t *)(arg1 + 0x28)) {
                    uVar7 = (uVar4 >> 5 ^ uVar4) >> 4;
                    uVar9 = 0;
                    do {
                        uVar7 = uVar7 & var_40h - 1U;
                        uVar5 = *(uint64_t *)(var_48h + uVar7 * 8);
                        puVar10 = (uint64_t *)(var_48h + uVar7 * 8);
                        if (uVar5 == var_30h) {
                            *puVar10 = uVar4;
                            goto code_r0x0001800c460a;
                        }
                        if (uVar5 == uVar4) goto code_r0x0001800c460a;
                        uVar7 = uVar7 + 1 + uVar9;
                        uVar9 = uVar9 + 1;
                    } while (uVar9 <= var_40h - 1U);
                    puVar10 = (uint64_t *)0x0;
code_r0x0001800c460a:
                    *puVar10 = *(uint64_t *)(*piVar1 + uVar11 * 8);
                }
                uVar11 = uVar11 + 1;
            } while (uVar11 < *(uint64_t *)(arg1 + 0x18));
        }
        iVar3 = *piVar1;
        *(int64_t *)(arg1 + 0x18) = var_40h;
        *piVar1 = var_48h;
        if (iVar3 != 0) {
            func_0x0001800f4640();
        }
    }
    func_0x0001800c15e0(piVar1, iVar8 + 0x20);
    return;
}

// ============================================================
// Function: FUN_1800c4660
// Address: 0x1800c4660
// Size: 120 bytes
// ============================================================
undefined8 fcn.1800c4660(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_20h;
    int64_t in_stack_00000030;
    
    piVar4 = *(int64_t **)(arg2 + 0x38);
    piVar1 = piVar4 + *(int64_t *)(arg2 + 0x40);
    for (; piVar4 != piVar1; piVar4 = piVar4 + 1) {
        fcn.1800c4450(arg1, *piVar4, in_stack_00000030);
    }
    if (*(char *)(arg2 + 0x48) != '\0') {
        iVar2 = *(int64_t *)(arg2 + 0x20);
        iVar3 = 0;
        if (*(int32_t *)(iVar2 + 8) == *(int32_t *)0x18078269c) {
            iVar3 = iVar2;
        }
        if (iVar3 == 0) {
            if (*(int32_t *)(iVar2 + 8) == *(int32_t *)0x180782730) {
                iVar3 = iVar2;
            }
            if (iVar3 == 0) {
                return 1;
            }
        }
        fcn.1800c4450(arg1, *(int64_t *)(iVar3 + 0x20), in_stack_00000030);
    }
    return 1;
}

// ============================================================
// Function: FUN_1800c46e0
// Address: 0x1800c46e0
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800c46e0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t in_stack_00000050;
    
    iVar2 = *(int64_t *)(arg2 + 0x20);
    iVar1 = iVar2 + *(int64_t *)(arg2 + 0x28) * 0x18;
    for (; iVar2 != iVar1; iVar2 = iVar2 + 0x18) {
        if (*(int64_t *)(iVar2 + 8) != 0) {
            fcn.1800c4450(arg1, *(int64_t *)(iVar2 + 8), in_stack_00000050);
        }
        fcn.1800c4450(arg1, *(int64_t *)(iVar2 + 0x10), in_stack_00000050);
    }
    return 1;
}

// ============================================================
// Function: FUN_1800c4740
// Address: 0x1800c4740
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800c4740(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000050;
    
    uVar4 = 0;
    if (*(int64_t *)(arg2 + 0x40) == 0) {
        return 1;
    }
    do {
        if (*(uint64_t *)(arg2 + 0x30) <= uVar4) {
            return 1;
        }
        iVar2 = *(int64_t *)(*(int64_t *)(arg2 + 0x38) + uVar4 * 8);
        iVar3 = 0;
        if (*(int32_t *)(iVar2 + 8) == *(int32_t *)0x180782728) {
            iVar3 = iVar2;
        }
        while (iVar3 == 0) {
            iVar1 = *(int32_t *)(iVar2 + 8);
            iVar3 = 0;
            if (iVar1 == *(int32_t *)0x1807826c0) {
                iVar3 = iVar2;
            }
            if (iVar3 == 0) {
                iVar3 = 0;
                if (iVar1 == *(int32_t *)0x180782708) {
                    iVar3 = iVar2;
                }
                if (iVar3 == 0) {
                    iVar3 = 0;
                    if (iVar1 == *(int32_t *)0x180782674) {
                        iVar3 = iVar2;
                    }
                    if (iVar3 == 0) {
                        iVar3 = 0;
                        if (iVar1 == *(int32_t *)0x18078270c) {
                            iVar3 = iVar2;
                        }
                        if (iVar3 == 0) {
                            iVar3 = 0;
                            if (iVar1 == *(int32_t *)0x180782668) {
                                iVar3 = iVar2;
                            }
                            if ((iVar3 == 0) || (1 < *(int32_t *)(iVar3 + 0x20) - 0xeU)) goto code_r0x0001800c4849;
                            fcn.1800c4450(arg1, *(int64_t *)(iVar3 + 0x28), in_stack_00000050);
                            iVar2 = *(int64_t *)(iVar3 + 0x30);
                        } else {
                            fcn.1800c4450(arg1, *(int64_t *)(iVar3 + 0x30), in_stack_00000050);
                            iVar2 = *(int64_t *)(iVar3 + 0x40);
                        }
                    } else {
                        iVar2 = *(int64_t *)(iVar3 + 0x20);
                    }
                } else {
                    iVar2 = *(int64_t *)(iVar3 + 0x20);
                }
            } else {
                iVar2 = *(int64_t *)(iVar3 + 0x20);
            }
            iVar3 = 0;
            if (*(int32_t *)(iVar2 + 8) == *(int32_t *)0x180782728) {
                iVar3 = iVar2;
            }
        }
        func_0x0001800c02a0(arg1 + 0x10);
code_r0x0001800c4849:
        uVar4 = uVar4 + 1;
        if (*(uint64_t *)(arg2 + 0x40) <= uVar4) {
            return 1;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800c4761
// Address: 0x1800c4761
// Size: 268 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800c4740(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000050;
    
    uVar4 = 0;
    if (*(int64_t *)(arg2 + 0x40) == 0) {
        return 1;
    }
    do {
        if (*(uint64_t *)(arg2 + 0x30) <= uVar4) {
            return 1;
        }
        iVar2 = *(int64_t *)(*(int64_t *)(arg2 + 0x38) + uVar4 * 8);
        iVar3 = 0;
        if (*(int32_t *)(iVar2 + 8) == *(int32_t *)0x180782728) {
            iVar3 = iVar2;
        }
        while (iVar3 == 0) {
            iVar1 = *(int32_t *)(iVar2 + 8);
            iVar3 = 0;
            if (iVar1 == *(int32_t *)0x1807826c0) {
                iVar3 = iVar2;
            }
            if (iVar3 == 0) {
                iVar3 = 0;
                if (iVar1 == *(int32_t *)0x180782708) {
                    iVar3 = iVar2;
                }
                if (iVar3 == 0) {
                    iVar3 = 0;
                    if (iVar1 == *(int32_t *)0x180782674) {
                        iVar3 = iVar2;
                    }
                    if (iVar3 == 0) {
                        iVar3 = 0;
                        if (iVar1 == *(int32_t *)0x18078270c) {
                            iVar3 = iVar2;
                        }
                        if (iVar3 == 0) {
                            iVar3 = 0;
                            if (iVar1 == *(int32_t *)0x180782668) {
                                iVar3 = iVar2;
                            }
                            if ((iVar3 == 0) || (1 < *(int32_t *)(iVar3 + 0x20) - 0xeU)) goto code_r0x0001800c4849;
                            fcn.1800c4450(arg1, *(int64_t *)(iVar3 + 0x28), in_stack_00000050);
                            iVar2 = *(int64_t *)(iVar3 + 0x30);
                        } else {
                            fcn.1800c4450(arg1, *(int64_t *)(iVar3 + 0x30), in_stack_00000050);
                            iVar2 = *(int64_t *)(iVar3 + 0x40);
                        }
                    } else {
                        iVar2 = *(int64_t *)(iVar3 + 0x20);
                    }
                } else {
                    iVar2 = *(int64_t *)(iVar3 + 0x20);
                }
            } else {
                iVar2 = *(int64_t *)(iVar3 + 0x20);
            }
            iVar3 = 0;
            if (*(int32_t *)(iVar2 + 8) == *(int32_t *)0x180782728) {
                iVar3 = iVar2;
            }
        }
        func_0x0001800c02a0(arg1 + 0x10);
code_r0x0001800c4849:
        uVar4 = uVar4 + 1;
        if (*(uint64_t *)(arg2 + 0x40) <= uVar4) {
            return 1;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800c486d
// Address: 0x1800c486d
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800c4740(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000050;
    
    uVar4 = 0;
    if (*(int64_t *)(arg2 + 0x40) == 0) {
        return 1;
    }
    do {
        if (*(uint64_t *)(arg2 + 0x30) <= uVar4) {
            return 1;
        }
        iVar2 = *(int64_t *)(*(int64_t *)(arg2 + 0x38) + uVar4 * 8);
        iVar3 = 0;
        if (*(int32_t *)(iVar2 + 8) == *(int32_t *)0x180782728) {
            iVar3 = iVar2;
        }
        while (iVar3 == 0) {
            iVar1 = *(int32_t *)(iVar2 + 8);
            iVar3 = 0;
            if (iVar1 == *(int32_t *)0x1807826c0) {
                iVar3 = iVar2;
            }
            if (iVar3 == 0) {
                iVar3 = 0;
                if (iVar1 == *(int32_t *)0x180782708) {
                    iVar3 = iVar2;
                }
                if (iVar3 == 0) {
                    iVar3 = 0;
                    if (iVar1 == *(int32_t *)0x180782674) {
                        iVar3 = iVar2;
                    }
                    if (iVar3 == 0) {
                        iVar3 = 0;
                        if (iVar1 == *(int32_t *)0x18078270c) {
                            iVar3 = iVar2;
                        }
                        if (iVar3 == 0) {
                            iVar3 = 0;
                            if (iVar1 == *(int32_t *)0x180782668) {
                                iVar3 = iVar2;
                            }
                            if ((iVar3 == 0) || (1 < *(int32_t *)(iVar3 + 0x20) - 0xeU)) goto code_r0x0001800c4849;
                            fcn.1800c4450(arg1, *(int64_t *)(iVar3 + 0x28), in_stack_00000050);
                            iVar2 = *(int64_t *)(iVar3 + 0x30);
                        } else {
                            fcn.1800c4450(arg1, *(int64_t *)(iVar3 + 0x30), in_stack_00000050);
                            iVar2 = *(int64_t *)(iVar3 + 0x40);
                        }
                    } else {
                        iVar2 = *(int64_t *)(iVar3 + 0x20);
                    }
                } else {
                    iVar2 = *(int64_t *)(iVar3 + 0x20);
                }
            } else {
                iVar2 = *(int64_t *)(iVar3 + 0x20);
            }
            iVar3 = 0;
            if (*(int32_t *)(iVar2 + 8) == *(int32_t *)0x180782728) {
                iVar3 = iVar2;
            }
        }
        func_0x0001800c02a0(arg1 + 0x10);
code_r0x0001800c4849:
        uVar4 = uVar4 + 1;
        if (*(uint64_t *)(arg2 + 0x40) <= uVar4) {
            return 1;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800c4880
// Address: 0x1800c4880
// Size: 170 bytes
// ============================================================
undefined8
fcn.1800c4880(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
             int64_t arg_30h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    
    piVar4 = *(int64_t **)(arg2 + 0x38);
    piVar1 = piVar4 + *(int64_t *)(arg2 + 0x40);
    for (; piVar4 != piVar1; piVar4 = piVar4 + 1) {
        fcn.1800c4450(arg1, *piVar4, arg_30h);
    }
    piVar4 = *(int64_t **)(arg2 + 0x28);
    piVar1 = piVar4 + *(int64_t *)(arg2 + 0x30);
    do {
        if (piVar4 == piVar1) {
            return 1;
        }
        iVar3 = *piVar4;
        iVar2 = 0;
        if (*(int32_t *)(iVar3 + 8) == *(int32_t *)0x18078269c) {
            iVar2 = iVar3;
        }
        if (iVar2 == 0) {
            iVar2 = 0;
            if (*(int32_t *)(iVar3 + 8) == *(int32_t *)0x180782730) {
                iVar2 = iVar3;
            }
            if (iVar2 != 0) {
                fcn.1800c4450(arg1, *(int64_t *)(iVar2 + 0x20), arg_30h);
                iVar3 = *(int64_t *)(iVar2 + 0x28);
                goto code_r0x0001800c490e;
            }
        } else {
            iVar3 = *(int64_t *)(iVar2 + 0x20);
code_r0x0001800c490e:
            fcn.1800c4450(arg1, iVar3, arg_30h);
        }
        piVar4 = piVar4 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800c4930
// Address: 0x1800c4930
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800c4930(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t in_stack_00000050;
    
    iVar1 = *(int64_t *)(arg2 + 0x30);
    iVar2 = 0;
    if (*(int32_t *)(iVar1 + 8) == *(int32_t *)0x18078269c) {
        iVar2 = iVar1;
    }
    if (iVar2 != 0) {
        fcn.1800c4450(arg1, *(int64_t *)(iVar2 + 0x20), in_stack_00000050);
        return 1;
    }
    iVar2 = 0;
    if (*(int32_t *)(iVar1 + 8) == *(int32_t *)0x180782730) {
        iVar2 = iVar1;
    }
    if (iVar2 != 0) {
        fcn.1800c4450(arg1, *(int64_t *)(iVar2 + 0x20), in_stack_00000050);
        fcn.1800c4450(arg1, *(int64_t *)(iVar2 + 0x28), in_stack_00000050);
    }
    return 1;
}

// ============================================================
// Function: FUN_1800c49a0
// Address: 0x1800c49a0
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800c49a0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t in_stack_00000050;
    
    iVar1 = *(int64_t *)(arg2 + 0x28);
    iVar2 = 0;
    if (*(int32_t *)(iVar1 + 8) == *(int32_t *)0x18078269c) {
        iVar2 = iVar1;
    }
    if (iVar2 != 0) {
        fcn.1800c4450(arg1, *(int64_t *)(iVar2 + 0x20), in_stack_00000050);
        return 1;
    }
    iVar2 = 0;
    if (*(int32_t *)(iVar1 + 8) == *(int32_t *)0x180782730) {
        iVar2 = iVar1;
    }
    if (iVar2 != 0) {
        fcn.1800c4450(arg1, *(int64_t *)(iVar2 + 0x20), in_stack_00000050);
        fcn.1800c4450(arg1, *(int64_t *)(iVar2 + 0x28), in_stack_00000050);
    }
    return 1;
}

// ============================================================
// Function: FUN_1800c4a10
// Address: 0x1800c4a10
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800c4a10(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000050;
    
    piVar5 = *(int64_t **)(arg2 + 0x38);
    piVar1 = piVar5 + *(int64_t *)(arg2 + 0x40);
    do {
        if (piVar5 == piVar1) {
            return 1;
        }
        iVar3 = *piVar5;
        iVar4 = 0;
        if (*(int32_t *)(iVar3 + 8) == *(int32_t *)0x180782728) {
            iVar4 = iVar3;
        }
        while (iVar4 == 0) {
            iVar2 = *(int32_t *)(iVar3 + 8);
            iVar4 = 0;
            if (iVar2 == *(int32_t *)0x1807826c0) {
                iVar4 = iVar3;
            }
            if (iVar4 == 0) {
                iVar4 = 0;
                if (iVar2 == *(int32_t *)0x180782708) {
                    iVar4 = iVar3;
                }
                if (iVar4 == 0) {
                    iVar4 = 0;
                    if (iVar2 == *(int32_t *)0x180782674) {
                        iVar4 = iVar3;
                    }
                    if (iVar4 == 0) {
                        iVar4 = 0;
                        if (iVar2 == *(int32_t *)0x18078270c) {
                            iVar4 = iVar3;
                        }
                        if (iVar4 == 0) {
                            iVar4 = 0;
                            if (iVar2 == *(int32_t *)0x180782668) {
                                iVar4 = iVar3;
                            }
                            if ((iVar4 == 0) || (1 < *(int32_t *)(iVar4 + 0x20) - 0xeU)) goto code_r0x0001800c4b16;
                            fcn.1800c4450(arg1, *(int64_t *)(iVar4 + 0x28), in_stack_00000050);
                            iVar3 = *(int64_t *)(iVar4 + 0x30);
                        } else {
                            fcn.1800c4450(arg1, *(int64_t *)(iVar4 + 0x30), in_stack_00000050);
                            iVar3 = *(int64_t *)(iVar4 + 0x40);
                        }
                    } else {
                        iVar3 = *(int64_t *)(iVar4 + 0x20);
                    }
                } else {
                    iVar3 = *(int64_t *)(iVar4 + 0x20);
                }
            } else {
                iVar3 = *(int64_t *)(iVar4 + 0x20);
            }
            iVar4 = 0;
            if (*(int32_t *)(iVar3 + 8) == *(int32_t *)0x180782728) {
                iVar4 = iVar3;
            }
        }
        func_0x0001800c02a0(arg1 + 0x10);
code_r0x0001800c4b16:
        piVar5 = piVar5 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800c4a37
// Address: 0x1800c4a37
// Size: 241 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800c4a10(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000050;
    
    piVar5 = *(int64_t **)(arg2 + 0x38);
    piVar1 = piVar5 + *(int64_t *)(arg2 + 0x40);
    do {
        if (piVar5 == piVar1) {
            return 1;
        }
        iVar3 = *piVar5;
        iVar4 = 0;
        if (*(int32_t *)(iVar3 + 8) == *(int32_t *)0x180782728) {
            iVar4 = iVar3;
        }
        while (iVar4 == 0) {
            iVar2 = *(int32_t *)(iVar3 + 8);
            iVar4 = 0;
            if (iVar2 == *(int32_t *)0x1807826c0) {
                iVar4 = iVar3;
            }
            if (iVar4 == 0) {
                iVar4 = 0;
                if (iVar2 == *(int32_t *)0x180782708) {
                    iVar4 = iVar3;
                }
                if (iVar4 == 0) {
                    iVar4 = 0;
                    if (iVar2 == *(int32_t *)0x180782674) {
                        iVar4 = iVar3;
                    }
                    if (iVar4 == 0) {
                        iVar4 = 0;
                        if (iVar2 == *(int32_t *)0x18078270c) {
                            iVar4 = iVar3;
                        }
                        if (iVar4 == 0) {
                            iVar4 = 0;
                            if (iVar2 == *(int32_t *)0x180782668) {
                                iVar4 = iVar3;
                            }
                            if ((iVar4 == 0) || (1 < *(int32_t *)(iVar4 + 0x20) - 0xeU)) goto code_r0x0001800c4b16;
                            fcn.1800c4450(arg1, *(int64_t *)(iVar4 + 0x28), in_stack_00000050);
                            iVar3 = *(int64_t *)(iVar4 + 0x30);
                        } else {
                            fcn.1800c4450(arg1, *(int64_t *)(iVar4 + 0x30), in_stack_00000050);
                            iVar3 = *(int64_t *)(iVar4 + 0x40);
                        }
                    } else {
                        iVar3 = *(int64_t *)(iVar4 + 0x20);
                    }
                } else {
                    iVar3 = *(int64_t *)(iVar4 + 0x20);
                }
            } else {
                iVar3 = *(int64_t *)(iVar4 + 0x20);
            }
            iVar4 = 0;
            if (*(int32_t *)(iVar3 + 8) == *(int32_t *)0x180782728) {
                iVar4 = iVar3;
            }
        }
        func_0x0001800c02a0(arg1 + 0x10);
code_r0x0001800c4b16:
        piVar5 = piVar5 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800c4b28
// Address: 0x1800c4b28
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800c4a10(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000050;
    
    piVar5 = *(int64_t **)(arg2 + 0x38);
    piVar1 = piVar5 + *(int64_t *)(arg2 + 0x40);
    do {
        if (piVar5 == piVar1) {
            return 1;
        }
        iVar3 = *piVar5;
        iVar4 = 0;
        if (*(int32_t *)(iVar3 + 8) == *(int32_t *)0x180782728) {
            iVar4 = iVar3;
        }
        while (iVar4 == 0) {
            iVar2 = *(int32_t *)(iVar3 + 8);
            iVar4 = 0;
            if (iVar2 == *(int32_t *)0x1807826c0) {
                iVar4 = iVar3;
            }
            if (iVar4 == 0) {
                iVar4 = 0;
                if (iVar2 == *(int32_t *)0x180782708) {
                    iVar4 = iVar3;
                }
                if (iVar4 == 0) {
                    iVar4 = 0;
                    if (iVar2 == *(int32_t *)0x180782674) {
                        iVar4 = iVar3;
                    }
                    if (iVar4 == 0) {
                        iVar4 = 0;
                        if (iVar2 == *(int32_t *)0x18078270c) {
                            iVar4 = iVar3;
                        }
                        if (iVar4 == 0) {
                            iVar4 = 0;
                            if (iVar2 == *(int32_t *)0x180782668) {
                                iVar4 = iVar3;
                            }
                            if ((iVar4 == 0) || (1 < *(int32_t *)(iVar4 + 0x20) - 0xeU)) goto code_r0x0001800c4b16;
                            fcn.1800c4450(arg1, *(int64_t *)(iVar4 + 0x28), in_stack_00000050);
                            iVar3 = *(int64_t *)(iVar4 + 0x30);
                        } else {
                            fcn.1800c4450(arg1, *(int64_t *)(iVar4 + 0x30), in_stack_00000050);
                            iVar3 = *(int64_t *)(iVar4 + 0x40);
                        }
                    } else {
                        iVar3 = *(int64_t *)(iVar4 + 0x20);
                    }
                } else {
                    iVar3 = *(int64_t *)(iVar4 + 0x20);
                }
            } else {
                iVar3 = *(int64_t *)(iVar4 + 0x20);
            }
            iVar4 = 0;
            if (*(int32_t *)(iVar3 + 8) == *(int32_t *)0x180782728) {
                iVar4 = iVar3;
            }
        }
        func_0x0001800c02a0(arg1 + 0x10);
code_r0x0001800c4b16:
        piVar5 = piVar5 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800c4b40
// Address: 0x1800c4b40
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800c4b40(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000050;
    
    piVar5 = *(int64_t **)(arg2 + 0x28);
    piVar1 = piVar5 + *(int64_t *)(arg2 + 0x30);
    do {
        if (piVar5 == piVar1) {
            return 1;
        }
        iVar3 = *piVar5;
        iVar4 = 0;
        if (*(int32_t *)(iVar3 + 8) == *(int32_t *)0x180782728) {
            iVar4 = iVar3;
        }
        while (iVar4 == 0) {
            iVar2 = *(int32_t *)(iVar3 + 8);
            iVar4 = 0;
            if (iVar2 == *(int32_t *)0x1807826c0) {
                iVar4 = iVar3;
            }
            if (iVar4 == 0) {
                iVar4 = 0;
                if (iVar2 == *(int32_t *)0x180782708) {
                    iVar4 = iVar3;
                }
                if (iVar4 == 0) {
                    iVar4 = 0;
                    if (iVar2 == *(int32_t *)0x180782674) {
                        iVar4 = iVar3;
                    }
                    if (iVar4 == 0) {
                        iVar4 = 0;
                        if (iVar2 == *(int32_t *)0x18078270c) {
                            iVar4 = iVar3;
                        }
                        if (iVar4 == 0) {
                            iVar4 = 0;
                            if (iVar2 == *(int32_t *)0x180782668) {
                                iVar4 = iVar3;
                            }
                            if ((iVar4 == 0) || (1 < *(int32_t *)(iVar4 + 0x20) - 0xeU)) goto code_r0x0001800c4c46;
                            fcn.1800c4450(arg1, *(int64_t *)(iVar4 + 0x28), in_stack_00000050);
                            iVar3 = *(int64_t *)(iVar4 + 0x30);
                        } else {
                            fcn.1800c4450(arg1, *(int64_t *)(iVar4 + 0x30), in_stack_00000050);
                            iVar3 = *(int64_t *)(iVar4 + 0x40);
                        }
                    } else {
                        iVar3 = *(int64_t *)(iVar4 + 0x20);
                    }
                } else {
                    iVar3 = *(int64_t *)(iVar4 + 0x20);
                }
            } else {
                iVar3 = *(int64_t *)(iVar4 + 0x20);
            }
            iVar4 = 0;
            if (*(int32_t *)(iVar3 + 8) == *(int32_t *)0x180782728) {
                iVar4 = iVar3;
            }
        }
        func_0x0001800c02a0(arg1 + 0x10);
code_r0x0001800c4c46:
        piVar5 = piVar5 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800c4b67
// Address: 0x1800c4b67
// Size: 241 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800c4b40(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000050;
    
    piVar5 = *(int64_t **)(arg2 + 0x28);
    piVar1 = piVar5 + *(int64_t *)(arg2 + 0x30);
    do {
        if (piVar5 == piVar1) {
            return 1;
        }
        iVar3 = *piVar5;
        iVar4 = 0;
        if (*(int32_t *)(iVar3 + 8) == *(int32_t *)0x180782728) {
            iVar4 = iVar3;
        }
        while (iVar4 == 0) {
            iVar2 = *(int32_t *)(iVar3 + 8);
            iVar4 = 0;
            if (iVar2 == *(int32_t *)0x1807826c0) {
                iVar4 = iVar3;
            }
            if (iVar4 == 0) {
                iVar4 = 0;
                if (iVar2 == *(int32_t *)0x180782708) {
                    iVar4 = iVar3;
                }
                if (iVar4 == 0) {
                    iVar4 = 0;
                    if (iVar2 == *(int32_t *)0x180782674) {
                        iVar4 = iVar3;
                    }
                    if (iVar4 == 0) {
                        iVar4 = 0;
                        if (iVar2 == *(int32_t *)0x18078270c) {
                            iVar4 = iVar3;
                        }
                        if (iVar4 == 0) {
                            iVar4 = 0;
                            if (iVar2 == *(int32_t *)0x180782668) {
                                iVar4 = iVar3;
                            }
                            if ((iVar4 == 0) || (1 < *(int32_t *)(iVar4 + 0x20) - 0xeU)) goto code_r0x0001800c4c46;
                            fcn.1800c4450(arg1, *(int64_t *)(iVar4 + 0x28), in_stack_00000050);
                            iVar3 = *(int64_t *)(iVar4 + 0x30);
                        } else {
                            fcn.1800c4450(arg1, *(int64_t *)(iVar4 + 0x30), in_stack_00000050);
                            iVar3 = *(int64_t *)(iVar4 + 0x40);
                        }
                    } else {
                        iVar3 = *(int64_t *)(iVar4 + 0x20);
                    }
                } else {
                    iVar3 = *(int64_t *)(iVar4 + 0x20);
                }
            } else {
                iVar3 = *(int64_t *)(iVar4 + 0x20);
            }
            iVar4 = 0;
            if (*(int32_t *)(iVar3 + 8) == *(int32_t *)0x180782728) {
                iVar4 = iVar3;
            }
        }
        func_0x0001800c02a0(arg1 + 0x10);
code_r0x0001800c4c46:
        piVar5 = piVar5 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800c4c58
// Address: 0x1800c4c58
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800c4b40(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000050;
    
    piVar5 = *(int64_t **)(arg2 + 0x28);
    piVar1 = piVar5 + *(int64_t *)(arg2 + 0x30);
    do {
        if (piVar5 == piVar1) {
            return 1;
        }
        iVar3 = *piVar5;
        iVar4 = 0;
        if (*(int32_t *)(iVar3 + 8) == *(int32_t *)0x180782728) {
            iVar4 = iVar3;
        }
        while (iVar4 == 0) {
            iVar2 = *(int32_t *)(iVar3 + 8);
            iVar4 = 0;
            if (iVar2 == *(int32_t *)0x1807826c0) {
                iVar4 = iVar3;
            }
            if (iVar4 == 0) {
                iVar4 = 0;
                if (iVar2 == *(int32_t *)0x180782708) {
                    iVar4 = iVar3;
                }
                if (iVar4 == 0) {
                    iVar4 = 0;
                    if (iVar2 == *(int32_t *)0x180782674) {
                        iVar4 = iVar3;
                    }
                    if (iVar4 == 0) {
                        iVar4 = 0;
                        if (iVar2 == *(int32_t *)0x18078270c) {
                            iVar4 = iVar3;
                        }
                        if (iVar4 == 0) {
                            iVar4 = 0;
                            if (iVar2 == *(int32_t *)0x180782668) {
                                iVar4 = iVar3;
                            }
                            if ((iVar4 == 0) || (1 < *(int32_t *)(iVar4 + 0x20) - 0xeU)) goto code_r0x0001800c4c46;
                            fcn.1800c4450(arg1, *(int64_t *)(iVar4 + 0x28), in_stack_00000050);
                            iVar3 = *(int64_t *)(iVar4 + 0x30);
                        } else {
                            fcn.1800c4450(arg1, *(int64_t *)(iVar4 + 0x30), in_stack_00000050);
                            iVar3 = *(int64_t *)(iVar4 + 0x40);
                        }
                    } else {
                        iVar3 = *(int64_t *)(iVar4 + 0x20);
                    }
                } else {
                    iVar3 = *(int64_t *)(iVar4 + 0x20);
                }
            } else {
                iVar3 = *(int64_t *)(iVar4 + 0x20);
            }
            iVar4 = 0;
            if (*(int32_t *)(iVar3 + 8) == *(int32_t *)0x180782728) {
                iVar4 = iVar3;
            }
        }
        func_0x0001800c02a0(arg1 + 0x10);
code_r0x0001800c4c46:
        piVar5 = piVar5 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800c4c70
// Address: 0x1800c4c70
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800c4c70(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x10) = 0;
        *(undefined8 *)(arg1 + 0x18) = 0;
    }
    *(undefined8 *)arg1 = 0x18063f2c0;
    if ((arg2 & 1U) != 0) {
        func_0x000180459c3c(arg1, 0x38);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800c4cd0
// Address: 0x1800c4cd0
// Size: 49 bytes
// ============================================================
void fcn.1800c4cd0(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        fcn.1800f4640();
        *(undefined8 *)(arg1 + 0x10) = 0;
        *(undefined8 *)(arg1 + 0x18) = 0;
    }
    *(undefined8 *)arg1 = 0x18063f2c0;
    return;
}

// ============================================================
// Function: FUN_1800c4d10
// Address: 0x1800c4d10
// Size: 6159 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x0001800c60a3)
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h

void fcn.1800c4d10(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t **ppiVar1;
    undefined8 uVar2;
    int32_t iVar3;
    uint64_t uVar4;
    char *pcVar5;
    int64_t **ppiVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    code *pcVar9;
    undefined auVar10 [16];
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    int32_t iVar17;
    int32_t iVar18;
    int32_t iVar19;
    undefined auVar20 [16];
    bool bVar21;
    undefined4 uVar22;
    int64_t *piVar23;
    int32_t *piVar24;
    int32_t *piVar25;
    uint64_t uVar26;
    int32_t *piVar27;
    int64_t iVar28;
    int64_t *piVar29;
    uint32_t *puVar30;
    int64_t iVar31;
    uint64_t uVar32;
    undefined8 *puVar33;
    uint64_t uVar34;
    int64_t iVar35;
    int64_t **ppiVar36;
    undefined *puVar37;
    undefined *puVar38;
    undefined *puVar39;
    undefined *puVar40;
    int64_t **ppiVar41;
    undefined4 *puVar42;
    int64_t iVar43;
    int64_t **ppiVar44;
    int64_t **ppiVar45;
    int64_t **ppiVar46;
    int64_t *piVar47;
    bool bVar48;
    undefined8 uStack_150;
    undefined auStack_148 [8];
    undefined auStack_140 [24];
    int64_t var_128h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t iStack_c8;
    int64_t *piStack_c0;
    int64_t **ppiStack_b8;
    int64_t **ppiStack_b0;
    uint64_t uStack_a8;
    int64_t **ppiStack_a0;
    int64_t **ppiStack_98;
    uint64_t uStack_90;
    undefined auStack_88 [8];
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    
    puVar37 = auStack_148;
    puVar38 = auStack_148;
    puVar39 = auStack_148;
    var_60h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_148;
    var_110h = arg2;
    *(undefined8 *)arg2 = 0;
    *(undefined8 *)(arg2 + 8) = 0;
    iVar3 = *(int32_t *)(arg3 + 8);
    iVar31 = 0;
    if (iVar3 == *(int32_t *)0x1807826c0) {
        iVar31 = arg3;
    }
    iStack_c8 = arg1;
    uStack_90 = arg3;
    if (iVar31 == 0) {
        if (iVar3 == *(int32_t *)0x180782670) {
            *(undefined4 *)arg2 = 1;
            puVar40 = auStack_148;
            goto code_r0x0001800c6341;
        }
        iVar31 = 0;
        if (iVar3 == *(int32_t *)0x1807826cc) {
            iVar31 = arg3;
        }
        if (iVar31 != 0) {
            *(undefined4 *)arg2 = 2;
            *(undefined *)(arg2 + 8) = *(undefined *)(iVar31 + 0x20);
            puVar40 = auStack_148;
            goto code_r0x0001800c6341;
        }
        iVar31 = 0;
        if (iVar3 == *(int32_t *)0x1807826b4) {
            iVar31 = arg3;
        }
        if (iVar31 != 0) {
            *(undefined4 *)arg2 = 3;
            *(undefined8 *)(arg2 + 8) = *(undefined8 *)(iVar31 + 0x20);
            puVar40 = auStack_148;
            goto code_r0x0001800c6341;
        }
        iVar31 = 0;
        if (iVar3 == *(int32_t *)0x18078271c) {
            iVar31 = arg3;
        }
        if (iVar31 != 0) {
            *(undefined4 *)arg2 = 4;
            *(undefined8 *)(arg2 + 8) = *(undefined8 *)(iVar31 + 0x20);
            puVar40 = auStack_148;
            goto code_r0x0001800c6341;
        }
        iVar31 = 0;
        if (iVar3 == *(int32_t *)0x18078273c) {
            iVar31 = arg3;
        }
        if (iVar31 != 0) {
            *(undefined4 *)arg2 = 6;
            *(undefined8 *)(arg2 + 8) = *(undefined8 *)(iVar31 + 0x20);
            *(undefined4 *)(arg2 + 4) = *(undefined4 *)(iVar31 + 0x28);
            puVar40 = auStack_148;
            goto code_r0x0001800c6341;
        }
        iVar31 = 0;
        if (iVar3 == *(int32_t *)0x180782728) {
            iVar31 = arg3;
        }
        if (iVar31 != 0) {
            iVar31 = func_0x0001800c13d0(*(undefined8 *)(arg1 + 0x18));
            if ((iVar31 != 0) && (piVar23 = (int64_t *)(iVar31 + 8), piVar23 != (int64_t *)0x0))
            goto code_r0x0001800c632f;
            puVar40 = auStack_148;
            if (*(char *)0x180777ff8 != '\0') {
                iVar31 = func_0x0001800c13d0(arg1 + 0x80);
                goto code_r0x0001800c4e71;
            }
            goto code_r0x0001800c6341;
        }
        puVar40 = auStack_148;
        if ((iVar3 == *(int32_t *)0x180782738) || (puVar40 = auStack_148, iVar3 == *(int32_t *)0x1807826b8))
        goto code_r0x0001800c6341;
        uVar26 = 0;
        if (iVar3 == *(int32_t *)0x180782740) {
            uVar26 = arg3;
        }
        if (uVar26 != 0) {
            fcn.1800c4d10(arg1, (int64_t)auStack_88, *(int64_t *)(uVar26 + 0x20));
            piVar23 = *(int64_t **)(arg1 + 0x20);
            if (piVar23 != (int64_t *)0x0) {
                if ((piVar23[2] != 0) && (uVar26 != piVar23[3])) {
                    uVar34 = (uVar26 >> 5 ^ uVar26) >> 4;
                    uVar32 = 0;
                    do {
                        uVar34 = uVar34 & piVar23[1] - 1U;
                        var_e8h = uVar34 * 0x10;
                        uVar4 = *(uint64_t *)(var_e8h + *piVar23);
                        if (uVar4 == uVar26) {
                            var_e8h = *piVar23 + 8 + var_e8h;
                            goto code_r0x0001800c4f47;
                        }
                        if (uVar4 == piVar23[3]) break;
                        uVar34 = uVar34 + 1 + uVar32;
                        uVar32 = uVar32 + 1;
                    } while (uVar32 <= piVar23[1] - 1U);
                }
                var_e8h = 0;
code_r0x0001800c4f47:
                uVar34 = 0;
                if (((int32_t *)var_e8h != (int32_t *)0x0) && (*(int32_t *)var_e8h != 0)) {
                    ppiVar1 = (int32_t **)(arg1 + 0x60);
                    iVar31 = *(int64_t *)(arg1 + 0x68) - (int64_t)*ppiVar1 >> 3;
                    piVar25 = (int32_t *)(iVar31 * -0x5555555555555555);
                    arg2 = *(int64_t *)(uVar26 + 0x40) + (int64_t)piVar25;
                    if ((int32_t *)((*(int64_t *)(arg1 + 0x70) - (int64_t)*ppiVar1 >> 3) * -0x5555555555555555) <
                        (uint64_t)arg2) {
                        if ((int32_t *)0xaaaaaaaaaaaaaaa < (uint64_t)arg2) goto code_r0x0001800c650d;
                        uVar32 = arg2 * 0x18;
                        if (uVar32 == 0) {
code_r0x0001800c4ffc:
                            func_0x000180498030(uVar34, *ppiVar1, *(int64_t *)(arg1 + 0x68) - (int64_t)*ppiVar1);
                            func_0x0001800c7c80(ppiVar1, uVar34, piVar25, arg2);
                            goto code_r0x0001800c501f;
                        }
                        if (uVar32 < 0x1000) {
                            uVar34 = func_0x000180459890();
                            goto code_r0x0001800c4ffc;
                        }
                        if (uVar32 < uVar32 + 0x27) {
                            iVar35 = func_0x000180459890(uVar32 + 0x27);
                            if (iVar35 != 0) {
                                uVar34 = iVar35 + 0x27U & 0xffffffffffffffe0;
                                *(int64_t *)(uVar34 - 8) = iVar35;
                                goto code_r0x0001800c4ffc;
                            }
code_r0x0001800c62d3:
                            pcVar9 = (code *)swi(0x29);
                            iVar31 = (*pcVar9)(5);
                            puVar39 = auStack_140;
                            goto code_r0x0001800c62da;
                        }
                        goto code_r0x0001800c6513;
                    }
code_r0x0001800c501f:
                    var_118h._0_1_ = '\x01';
                    piStack_c0 = (int64_t *)0x0;
                    piVar23 = *(int64_t **)(uVar26 + 0x40);
                    iVar35 = arg1;
                    if (piVar23 == (int64_t *)0x0) {
code_r0x0001800c5211:
                        var_128h = (int64_t)piVar23;
                        puVar42 = (undefined4 *)
                                  func_0x0001800a9050(auStack_88, *(undefined8 *)(iVar35 + 0x38), *(undefined4 *)var_e8h
                                                      , *ppiVar1 + iVar31 * 2);
                        uVar11 = puVar42[1];
                        uVar12 = puVar42[2];
                        uVar13 = puVar42[3];
                        uVar2 = *(undefined8 *)(puVar42 + 4);
                        *(undefined4 *)var_110h = *puVar42;
                        *(undefined4 *)(var_110h + 4) = uVar11;
                        *(undefined4 *)(var_110h + 8) = uVar12;
                        *(undefined4 *)(var_110h + 0xc) = uVar13;
                        *(undefined8 *)(var_110h + 0x10) = uVar2;
                    } else {
                        do {
                            fcn.1800c4d10(iVar35, (int64_t)&var_108h, 
                                          *(int64_t *)(*(int64_t *)(uVar26 + 0x38) + (int64_t)piStack_c0 * 8));
                            if (*(char *)0x180778018 == '\0') {
                                bVar48 = (int32_t)var_108h == 0;
code_r0x0001800c507a:
                                if (bVar48) goto code_r0x0001800c507c;
                                piVar27 = *(int32_t **)(arg1 + 0x68);
                                if (piVar27 == *(int32_t **)(arg1 + 0x70)) {
                                    iVar35 = (int64_t)piVar27 - (int64_t)*ppiVar1;
                                    iVar35 = iVar35 / 6 + (iVar35 >> 0x3f);
                                    iVar35 = (iVar35 >> 2) - (iVar35 >> 0x3f);
                                    if (iVar35 == 0xaaaaaaaaaaaaaaa) {
                                        func_0x000180010010();
                                        pcVar9 = (code *)swi(3);
                                        (*pcVar9)();
                                        return;
                                    }
                                    uVar32 = ((int64_t)*(int32_t **)(arg1 + 0x70) - (int64_t)*ppiVar1 >> 3) *
                                             -0x5555555555555555;
                                    uVar34 = 0xaaaaaaaaaaaaaaa - (uVar32 >> 1);
                                    if (uVar34 <= uVar32 && uVar32 - uVar34 != 0) goto code_r0x0001800c6501;
                                    var_f0h = iVar35 + 1;
                                    piVar24 = (int32_t *)(uVar32 + (uVar32 >> 1));
                                    arg2 = var_f0h;
                                    if ((uint64_t)var_f0h <= piVar24) {
                                        arg2 = (int64_t)piVar24;
                                    }
                                    if ((int32_t *)0xaaaaaaaaaaaaaaa < (uint64_t)arg2) goto code_r0x0001800c6501;
                                    uVar34 = arg2 * 0x18;
                                    if (uVar34 == 0) {
                                        uVar34 = 0;
                                    } else if (uVar34 < 0x1000) {
                                        uVar34 = func_0x000180459890();
                                    } else {
                                        if (uVar34 + 0x27 <= uVar34) goto code_r0x0001800c6501;
                                        iVar43 = func_0x000180459890(uVar34 + 0x27);
                                        if (iVar43 == 0) goto code_r0x0001800c62d3;
                                        uVar34 = iVar43 + 0x27U & 0xffffffffffffffe0;
                                        *(int64_t *)(uVar34 - 8) = iVar43;
                                    }
                                    puVar42 = (undefined4 *)(uVar34 + iVar35 * 0x18);
                                    *puVar42 = (int32_t)var_108h;
                                    puVar42[1] = var_108h._4_4_;
                                    puVar42[2] = (int32_t)var_100h;
                                    puVar42[3] = var_100h._4_4_;
                                    *(int64_t *)(uVar34 + 0x10 + iVar35 * 0x18) = var_f8h;
                                    piVar24 = *ppiVar1;
                                    if (piVar27 == *(int32_t **)(arg1 + 0x68)) {
                                        iVar43 = (int64_t)*(int32_t **)(arg1 + 0x68) - (int64_t)piVar24;
                                        uVar32 = uVar34;
                                        piVar27 = piVar24;
                                    } else {
                                        func_0x000180498030(uVar34, piVar24, (int64_t)piVar27 - (int64_t)piVar24);
                                        iVar43 = *(int64_t *)(arg1 + 0x68) - (int64_t)piVar27;
                                        uVar32 = uVar34 + (iVar35 * 3 + 3) * 8;
                                    }
                                    func_0x000180498030(uVar32, piVar27, iVar43);
                                    func_0x0001800c7c80(ppiVar1, uVar34, var_f0h, arg2);
                                    iVar35 = iStack_c8;
                                } else {
                                    *piVar27 = (int32_t)var_108h;
                                    piVar27[1] = var_108h._4_4_;
                                    piVar27[2] = (int32_t)var_100h;
                                    piVar27[3] = var_100h._4_4_;
                                    *(int64_t *)(piVar27 + 4) = var_f8h;
                                    *(int64_t *)(arg1 + 0x68) = *(int64_t *)(arg1 + 0x68) + 0x18;
                                }
                            } else {
                                if ((int32_t)var_108h != 0) {
                                    bVar48 = (int32_t)var_108h == 7;
                                    goto code_r0x0001800c507a;
                                }
code_r0x0001800c507c:
                                var_118h._0_1_ = '\0';
                            }
                            piStack_c0 = (int64_t *)((int64_t)piStack_c0 + 1);
                            piVar23 = *(int64_t **)(uVar26 + 0x40);
                        } while (piStack_c0 < piVar23);
                        if ((char)var_118h != '\0') goto code_r0x0001800c5211;
                    }
                    uVar26 = 0;
                    puVar33 = *(undefined8 **)(arg1 + 0x68);
                    piVar27 = *ppiVar1;
                    iVar35 = (int64_t)puVar33 - (int64_t)piVar27 >> 3;
                    bVar48 = (int32_t *)(iVar35 * -0x5555555555555555) <= piVar25;
                    arg2 = var_110h;
                    if (bVar48) {
                        puVar40 = auStack_148;
                        if (bVar48 && (int64_t)piVar25 + iVar35 * 0x5555555555555555 != 0) {
                            iVar31 = *(int64_t *)(arg1 + 0x70) - (int64_t)piVar27 >> 3;
                            piVar27 = (int32_t *)(iVar31 * -0x5555555555555555);
                            if (piVar27 <= piVar25 && (int64_t)piVar25 + iVar31 * 0x5555555555555555 != 0) {
                                if ((int32_t *)0xaaaaaaaaaaaaaaa < piVar25) {
code_r0x0001800c650d:
                                    func_0x000180010010();
                                    pcVar9 = (code *)swi(3);
                                    (*pcVar9)();
                                    return;
                                }
                                piVar24 = (int32_t *)(0xaaaaaaaaaaaaaaa - ((uint64_t)piVar27 >> 1));
                                if ((piVar24 <= piVar27 && (int64_t)piVar27 - (int64_t)piVar24 != 0) ||
                                   ((piVar27 = (int32_t *)(((uint64_t)piVar27 >> 1) + (int64_t)piVar27),
                                    arg2 = (int64_t)piVar25, piVar25 <= piVar27 &&
                                    (arg2 = (int64_t)piVar27, (int32_t *)0xaaaaaaaaaaaaaaa < piVar27)))) {
code_r0x0001800c6513:
                                    func_0x000180004720();
code_r0x0001800c6519:
                                    func_0x000180010010();
                                    pcVar9 = (code *)swi(3);
                                    (*pcVar9)();
                                    return;
                                }
                                uVar34 = arg2 * 0x18;
                                if (uVar34 != 0) {
                                    if (uVar34 < 0x1000) {
                                        uVar26 = func_0x000180459890();
                                    } else {
                                        if (uVar34 + 0x27 <= uVar34) goto code_r0x0001800c6513;
                                        iVar31 = func_0x000180459890(uVar34 + 0x27);
                                        if (iVar31 == 0) goto code_r0x0001800c62d3;
                                        uVar26 = iVar31 + 0x27U & 0xffffffffffffffe0;
                                        *(int64_t *)(uVar26 - 8) = iVar31;
                                    }
                                }
                                puVar33 = (undefined8 *)(uVar26 + iVar35 * 8);
                                for (iVar31 = (int64_t)piVar25 + iVar35 * 0x5555555555555555; iVar31 != 0;
                                    iVar31 = iVar31 + -1) {
                                    puVar33[2] = 0;
                                    *puVar33 = 0;
                                    puVar33[1] = 0;
                                    puVar33 = puVar33 + 3;
                                }
                                func_0x000180498030(uVar26, *ppiVar1, *(int64_t *)(arg1 + 0x68) - (int64_t)*ppiVar1);
                                func_0x0001800c7c80(ppiVar1, uVar26, piVar25, arg2);
                                puVar38 = auStack_148;
                                goto code_r0x0001800c538c;
                            }
                            for (iVar31 = (int64_t)piVar25 + iVar35 * 0x5555555555555555; iVar31 != 0;
                                iVar31 = iVar31 + -1) {
                                puVar33[2] = 0;
                                *puVar33 = 0;
                                puVar33[1] = 0;
                                puVar33 = puVar33 + 3;
                            }
                            *(undefined8 **)(arg1 + 0x68) = puVar33;
                            puVar40 = auStack_148;
                        }
                    } else {
                        *(int32_t **)(arg1 + 0x68) = piVar27 + iVar31 * 2;
                        puVar40 = auStack_148;
                    }
                    goto code_r0x0001800c6341;
                }
            }
            uVar34 = 0;
            puVar40 = auStack_148;
            if (*(int64_t *)(uVar26 + 0x40) != 0) {
                do {
                    fcn.1800c4d10(arg1, (int64_t)auStack_88, *(int64_t *)(*(int64_t *)(uVar26 + 0x38) + uVar34 * 8));
                    uVar34 = uVar34 + 1;
                    puVar40 = auStack_148;
                } while (uVar34 < *(uint64_t *)(uVar26 + 0x40));
            }
            goto code_r0x0001800c6341;
        }
        iVar31 = 0;
        if (iVar3 == *(int32_t *)0x18078269c) {
            iVar31 = arg3;
        }
        if (iVar31 == 0) {
            iVar31 = 0;
            if (iVar3 == *(int32_t *)0x180782730) {
                iVar31 = arg3;
            }
            if (iVar31 == 0) {
                iVar31 = 0;
                if (iVar3 == *(int32_t *)0x1807826a0) {
                    iVar31 = arg3;
                }
                if (iVar31 == 0) {
                    var_f0h = 0;
                    if (iVar3 == *(int32_t *)0x180782758) {
                        var_f0h = arg3;
                    }
                    if (var_f0h == 0) {
                        iVar31 = 0;
                        if (iVar3 == *(int32_t *)0x180782768) {
                            iVar31 = arg3;
                        }
                        if (iVar31 != 0) {
                            fcn.1800c4d10(arg1, (int64_t)&var_108h, *(int64_t *)(iVar31 + 0x28));
                            puVar40 = auStack_148;
                            if ((int32_t)var_108h != 0) {
                                iVar3 = *(int32_t *)(iVar31 + 0x20);
                                if (iVar3 == 0) {
                                    *(undefined4 *)arg2 = 2;
                                    if (((int32_t)var_108h == 1) ||
                                       (((int32_t)var_108h == 2 && ((char)var_100h == '\0')))) {
                                        *(undefined *)(arg2 + 8) = 1;
                                        puVar40 = auStack_148;
                                    } else {
                                        *(undefined *)(arg2 + 8) = 0;
                                        puVar40 = auStack_148;
                                    }
                                } else if (iVar3 == 1) {
                                    if ((int32_t)var_108h == 3) {
                                        *(undefined4 *)arg2 = 3;
                                        *(uint64_t *)(arg2 + 8) = var_100h ^ 0x8000000000000000;
                                        puVar40 = auStack_148;
                                    } else {
                                        puVar40 = auStack_148;
                                        if ((int32_t)var_108h == 5) {
                                            *(undefined4 *)arg2 = 5;
                                            auVar10._8_4_ = (uint32_t)var_f8h ^ 0x80000000;
                                            auVar10._0_8_ = var_100h ^ 0x8000000080000000;
                                            auVar10._12_4_ = var_f8h._4_4_ ^ 0x80000000;
                                            *(undefined (*) [16])(arg2 + 8) = auVar10;
                                            puVar40 = auStack_148;
                                        }
                                    }
                                } else {
                                    puVar40 = auStack_148;
                                    if ((iVar3 == 2) && (puVar40 = auStack_148, (int32_t)var_108h == 6)) {
                                        *(undefined4 *)arg2 = 3;
                                        *(double *)(arg2 + 8) = (double)((uint64_t)var_108h >> 0x20);
                                        puVar40 = auStack_148;
                                    }
                                }
                            }
                            goto code_r0x0001800c6341;
                        }
                        iVar31 = 0;
                        if (iVar3 == *(int32_t *)0x180782668) {
                            iVar31 = arg3;
                        }
                        if (iVar31 != 0) {
                            fcn.1800c4d10(arg1, (int64_t)&var_e0h, *(int64_t *)(iVar31 + 0x28));
                            fcn.1800c4d10(arg1, (int64_t)&var_108h, *(int64_t *)(iVar31 + 0x30));
                            puVar40 = auStack_148;
                            if ((int32_t)var_e0h != 0) {
                                var_128h = *(int64_t *)(arg1 + 0x38);
                                func_0x0001800c28b0(arg2, *(undefined4 *)(iVar31 + 0x20), &var_e0h, &var_108h);
                                puVar40 = auStack_148;
                            }
                            goto code_r0x0001800c6341;
                        }
                        iVar31 = 0;
                        if (iVar3 == *(int32_t *)0x180782708) {
                            iVar31 = arg3;
                        }
                        if (iVar31 != 0) {
                            fcn.1800c4d10(arg1, (int64_t)&var_e0h, *(int64_t *)(iVar31 + 0x20));
                            *(int32_t *)arg2 = (int32_t)var_e0h;
                            *(int32_t *)(arg2 + 4) = var_e0h._4_4_;
                            *(float *)(arg2 + 8) = (float)var_d8h;
                            *(float *)(arg2 + 0xc) = var_d8h._4_4_;
                            goto code_r0x0001800c633b;
                        }
                        iVar31 = 0;
                        if (iVar3 == *(int32_t *)0x18078270c) {
                            iVar31 = arg3;
                        }
                        if (iVar31 != 0) {
                            fcn.1800c4d10(arg1, (int64_t)&var_e0h, *(int64_t *)(iVar31 + 0x20));
                            fcn.1800c4d10(arg1, (int64_t)&var_108h, *(int64_t *)(iVar31 + 0x30));
                            fcn.1800c4d10(arg1, (int64_t)auStack_88, *(int64_t *)(iVar31 + 0x40));
                            puVar40 = auStack_148;
                            if ((int32_t)var_e0h != 0) {
                                if (((int32_t)var_e0h == 1) || (((int32_t)var_e0h == 2 && ((char)var_d8h == '\0')))) {
                                    piVar23 = (int64_t *)auStack_88;
                                } else {
                                    piVar23 = &var_108h;
                                }
                                goto code_r0x0001800c632f;
                            }
                            goto code_r0x0001800c6341;
                        }
                        iVar31 = 0;
                        if (iVar3 == *(int32_t *)0x18078275c) {
                            iVar31 = arg3;
                        }
                        if (iVar31 == 0) {
                            iVar31 = 0;
                            if (iVar3 == *(int32_t *)0x180782674) {
                                iVar31 = arg3;
                            }
                            puVar40 = auStack_148;
                            if (iVar31 != 0) goto code_r0x0001800c6322;
                            goto code_r0x0001800c6341;
                        }
                        bVar48 = true;
                        piVar29 = *(int64_t **)(iVar31 + 0x30);
                        piVar23 = piVar29 + *(int64_t *)(iVar31 + 0x38);
                        if (piVar29 != piVar23) {
                            do {
                                piVar25 = (int32_t *)fcn.1800c4d10(arg1, (int64_t)auStack_88, *piVar29);
                                bVar21 = false;
                                if (*piVar25 == 6) {
                                    bVar21 = bVar48;
                                }
                                piVar29 = piVar29 + 1;
                                bVar48 = bVar21;
                            } while (piVar29 != piVar23);
                            puVar38 = auStack_148;
                            if (!bVar21) goto code_r0x0001800c538c;
                        }
                        uVar26 = *(uint64_t *)(iVar31 + 0x28);
                        if (uVar26 == 0) {
                            *(undefined8 *)var_110h = 6;
                            *(undefined8 *)(var_110h + 8) = 0x1805aadb1;
                            puVar40 = auStack_148;
                            arg2 = var_110h;
                            goto code_r0x0001800c6341;
                        }
                        var_e8h = *(int64_t *)(arg1 + 0x38);
                        iVar35 = *(int64_t *)(arg1 + 8);
                        var_f0h = iVar35;
                        uVar32 = 0;
                        uVar34 = 0;
                        iVar43 = *(int64_t *)(iVar31 + 0x20);
                        do {
                            uVar32 = *(int64_t *)(iVar43 + 8 + uVar34 * 0x10) + uVar32;
                            if (uVar34 < *(uint64_t *)(iVar31 + 0x38)) {
                                iVar35 = func_0x0001800c13d0(iVar35);
                                puVar30 = (uint32_t *)(iVar35 + 0xc);
                                if (iVar35 == 0) {
                                    puVar30 = (uint32_t *)0x4;
                                }
                                uVar32 = *puVar30 + uVar32;
                                iVar35 = var_f0h;
                            }
                            uVar34 = uVar34 + 1;
                        } while (uVar34 < uVar26);
                        puVar38 = auStack_148;
                        if (0x1000 < uVar32) goto code_r0x0001800c538c;
                        *(undefined4 *)var_110h = 6;
                        *(int32_t *)(var_110h + 4) = (int32_t)uVar32;
                        if (uVar32 == 0) {
                            *(undefined8 *)(var_110h + 8) = 0x1805aadb1;
                            puVar40 = auStack_148;
                            arg2 = var_110h;
                            goto code_r0x0001800c6341;
                        }
                        var_78h = 0;
                        var_70h = 0xf;
                        stack0xffffffffffffff79 = SUB1615(ZEXT816(0), 1);
                        auVar20[15] = 0;
                        auVar20._0_15_ = stack0xffffffffffffff79;
                        _auStack_88 = auVar20 << 8;
                        func_0x00018000b240(auStack_88, uVar32);
                        iVar35 = var_f0h;
                        uVar26 = 0;
                        if (*(int64_t *)(iVar31 + 0x28) != 0) {
                            do {
                                func_0x00018000d970(auStack_88, 
                                                    *(undefined8 *)(*(int64_t *)(iVar31 + 0x20) + uVar26 * 0x10), 
                                                    *(undefined8 *)(*(int64_t *)(iVar31 + 0x20) + 8 + uVar26 * 0x10));
                                if (uVar26 < *(uint64_t *)(iVar31 + 0x38)) {
                                    iVar43 = func_0x0001800c13d0(iVar35, *(int64_t *)(iVar31 + 0x30) + uVar26 * 8);
                                    puVar42 = (undefined4 *)(iVar43 + 0xc);
                                    if (iVar43 == 0) {
                                        puVar42 = (undefined4 *)0x4;
                                    }
                                    puVar33 = (undefined8 *)(iVar43 + 0x10);
                                    if (iVar43 == 0) {
                                        puVar33 = (undefined8 *)0x8;
                                    }
                                    func_0x00018000d970(auStack_88, *puVar33, *puVar42);
                                }
                                uVar26 = uVar26 + 1;
                            } while (uVar26 < *(uint64_t *)(iVar31 + 0x28));
                        }
                        arg2 = var_110h;
                        *(undefined4 *)var_110h = 6;
                        *(int32_t *)(var_110h + 4) = (int32_t)uVar32;
                        puVar38 = auStack_88;
                        if (0xf < (uint64_t)var_70h) {
                            puVar38 = (undefined *)auStack_88;
                        }
                        func_0x0001800d6f20(var_e8h, &var_f0h, puVar38, uVar32);
                        *(int64_t *)(arg2 + 8) = var_f0h;
                        puVar40 = auStack_148;
                        if ((uint64_t)var_70h < 0x10) goto code_r0x0001800c6341;
                        iVar31 = (int64_t)auStack_88;
                        if (0xfff < var_70h + 1U) {
                            if (0x1f < ((int64_t)auStack_88 - *(int64_t *)((int64_t)auStack_88 + -8)) - 8U)
                            goto code_r0x0001800c62d3;
                            func_0x000180459c3c();
                            puVar40 = auStack_148;
                            goto code_r0x0001800c6341;
                        }
code_r0x0001800c62da:
                        *(undefined8 *)(puVar39 + -8) = 0x1800c62e2;
                        func_0x000180459c3c(iVar31);
                        puVar40 = puVar39;
                    } else {
                        piVar23 = *(int64_t **)(var_f0h + 0x28);
                        if (*(char *)0x180778018 == '\0') {
                            uVar26 = 0;
                            puVar40 = auStack_148;
                            if (piVar23 != (int64_t *)0x0) {
                                do {
                                    iVar31 = *(int64_t *)(var_f0h + 0x20);
                                    iVar35 = *(int64_t *)(iVar31 + 8 + uVar26 * 0x18);
                                    if (iVar35 != 0) {
                                        fcn.1800c4d10(arg1, (int64_t)auStack_88, iVar35);
                                    }
                                    fcn.1800c4d10(arg1, (int64_t)auStack_88, *(int64_t *)(iVar31 + 0x10 + uVar26 * 0x18)
                                                 );
                                    uVar26 = uVar26 + 1;
                                    puVar40 = auStack_148;
                                } while (uVar26 < *(uint64_t *)(var_f0h + 0x28));
                            }
                            goto code_r0x0001800c6341;
                        }
                        ppiVar45 = (int64_t **)0x0;
                        piVar47 = (int64_t *)0x0;
                        _auStack_88 = ZEXT816(0);
                        piVar29 = (int64_t *)0x0;
                        var_78h = 0;
                        ppiVar44 = (int64_t **)0x0;
                        var_70h = 0;
                        piStack_c0 = (int64_t *)0x0;
                        if (piVar23 != (int64_t *)0x0) {
                            do {
                                piVar23 = piStack_c0;
                                iVar31 = *(int64_t *)(var_f0h + 0x20);
                                fcn.1800c4d10(arg1, (int64_t)&var_108h, 
                                              *(int64_t *)(iVar31 + 0x10 + (int64_t)piStack_c0 * 0x18));
                                iVar31 = *(int64_t *)(iVar31 + 8 + (int64_t)piVar23 * 0x18);
                                if ((((iVar31 != 0) &&
                                     (fcn.1800c4d10(arg1, (int64_t)&var_e0h, iVar31), (int32_t)var_e0h == 6)) &&
                                    ((int32_t)var_108h != 0)) && (((int32_t)var_108h != 7 && (var_e0h._4_4_ != 0)))) {
                                    func_0x0001800d6f20(*(undefined8 *)(arg1 + 0x38), &var_e8h, 
                                                        CONCAT44(var_d8h._4_4_, (float)var_d8h), var_e0h._4_4_);
                                    iVar31 = var_f8h;
                                    uVar11 = (int32_t)var_108h;
                                    uVar12 = var_108h._4_4_;
                                    uVar13 = (int32_t)var_100h;
                                    uVar22 = var_100h._4_4_;
                                    if ((int64_t *)((uint64_t)((int64_t)piVar47 * 3) >> 2) <= piVar29) {
                                        if ((piVar29 != (int64_t *)0x0) && ((int64_t **)var_e8h != ppiVar44)) {
                                            uVar26 = ((uint64_t)var_e8h >> 5 ^ var_e8h) >> 4;
                                            uVar34 = 0;
                                            do {
                                                uVar26 = uVar26 & (int64_t)piVar47 - 1U;
                                                if (ppiVar45[uVar26 * 4] == (int64_t *)var_e8h)
                                                goto code_r0x0001800c5a90;
                                                if ((int64_t **)ppiVar45[uVar26 * 4] == ppiVar44) break;
                                                uVar26 = uVar26 + 1 + uVar34;
                                                uVar34 = uVar34 + 1;
                                            } while (uVar34 <= (int64_t)piVar47 - 1U);
                                        }
                                        func_0x0001800c7bf0(&ppiStack_b8, &var_70h);
                                        if (piVar47 != (int64_t *)0x0) {
                                            piVar23 = (int64_t *)0x0;
                                            do {
                                                ppiVar41 = (int64_t **)ppiVar45[(int64_t)piVar23 * 4];
                                                if (ppiVar41 != ppiVar44) {
                                                    uVar26 = ((uint64_t)ppiVar41 >> 5 ^ (uint64_t)ppiVar41) >> 4;
                                                    uVar34 = 0;
                                                    do {
                                                        uVar26 = uVar26 & (int64_t)ppiStack_b0 - 1U;
                                                        ppiVar46 = ppiStack_b8 + uVar26 * 4;
                                                        if ((int64_t **)*ppiVar46 == ppiStack_a0) {
                                                            *ppiVar46 = (int64_t *)ppiVar41;
                                                            uStack_a8 = uStack_a8 + 1;
                                                            goto code_r0x0001800c5a42;
                                                        }
                                                        if ((int64_t **)*ppiVar46 == ppiVar41)
                                                        goto code_r0x0001800c5a42;
                                                        uVar26 = uVar26 + 1 + uVar34;
                                                        uVar34 = uVar34 + 1;
                                                    } while (uVar34 <= (int64_t)ppiStack_b0 - 1U);
                                                    ppiVar46 = (int64_t **)0x0;
code_r0x0001800c5a42:
                                                    *ppiVar46 = ppiVar45[(int64_t)piVar23 * 4];
                                                    ppiVar41 = ppiVar45 + (int64_t)piVar23 * 4 + 1;
                                                    uVar14 = *(undefined4 *)((int64_t)ppiVar41 + 4);
                                                    uVar15 = *(undefined4 *)(ppiVar41 + 1);
                                                    uVar16 = *(undefined4 *)((int64_t)ppiVar41 + 0xc);
                                                    *(undefined4 *)(ppiVar46 + 1) = *(undefined4 *)ppiVar41;
                                                    *(undefined4 *)((int64_t)ppiVar46 + 0xc) = uVar14;
                                                    *(undefined4 *)(ppiVar46 + 2) = uVar15;
                                                    *(undefined4 *)((int64_t)ppiVar46 + 0x14) = uVar16;
                                                    ppiVar46[3] = ppiVar45[(int64_t)piVar23 * 4 + 3];
                                                }
                                                piVar23 = (int64_t *)((int64_t)piVar23 + 1);
                                                arg1 = iStack_c8;
                                            } while (piVar23 < piVar47);
                                        }
                                        var_80h = (int64_t)ppiStack_b0;
                                        auStack_88 = (undefined  [8])ppiStack_b8;
                                        ppiStack_b8 = ppiVar45;
                                        if (ppiVar45 != (int64_t **)0x0) {
                                            fcn.1800f4640(ppiVar45);
                                        }
                                    }
code_r0x0001800c5a90:
                                    iVar35 = func_0x0001800c7b60(auStack_88, &var_e8h);
                                    *(undefined4 *)(iVar35 + 8) = uVar11;
                                    *(undefined4 *)(iVar35 + 0xc) = uVar12;
                                    *(undefined4 *)(iVar35 + 0x10) = uVar13;
                                    *(undefined4 *)(iVar35 + 0x14) = uVar22;
                                    *(int64_t *)(iVar35 + 0x18) = iVar31;
                                    piVar29 = (int64_t *)var_78h;
                                    ppiVar44 = (int64_t **)var_70h;
                                    ppiVar45 = (int64_t **)auStack_88;
                                    piVar47 = (int64_t *)var_80h;
                                }
                                piStack_c0 = (int64_t *)((int64_t)piStack_c0 + 1);
                                piVar23 = *(int64_t **)(var_f0h + 0x28);
                            } while (piStack_c0 < piVar23);
                        }
                        iVar31 = iStack_c8;
                        puVar40 = auStack_148;
                        if (piVar29 == piVar23) {
                            *(undefined4 *)var_110h = 7;
                            ppiVar46 = (int64_t **)(iStack_c8 + 0x40);
                            *(int64_t *)(var_110h + 8) =
                                 (*(int64_t *)(iStack_c8 + 0x48) - (int64_t)*ppiVar46 >> 3) * -0x3333333333333333;
                            ppiVar41 = *(int64_t ***)(iStack_c8 + 0x48);
                            if (ppiVar41 == *(int64_t ***)(iStack_c8 + 0x50)) {
                                iVar35 = ((int64_t)ppiVar41 - (int64_t)*ppiVar46) / 0x28;
                                if (iVar35 == 0x666666666666666) goto code_r0x0001800c6519;
                                uVar26 = ((int64_t)*(int64_t ***)(iStack_c8 + 0x50) - (int64_t)*ppiVar46 >> 3) *
                                         -0x3333333333333333;
                                uVar34 = 0x666666666666666 - (uVar26 >> 1);
                                if (uVar34 <= uVar26 && uVar26 - uVar34 != 0) {
code_r0x0001800c64fb:
                                    func_0x000180004720();
code_r0x0001800c6501:
                                    func_0x000180004720();
                                    pcVar9 = (code *)swi(3);
                                    (*pcVar9)();
                                    return;
                                }
                                var_f0h = iVar35 + 1;
                                uVar26 = uVar26 + (uVar26 >> 1);
                                uVar34 = var_f0h;
                                if ((uint64_t)var_f0h <= uVar26) {
                                    uVar34 = uVar26;
                                }
                                if (0x666666666666666 < uVar34) goto code_r0x0001800c64fb;
                                var_e8h = uVar34 * 0x28;
                                if (var_e8h == 0) {
                                    ppiVar44 = (int64_t **)0x0;
                                    puVar38 = auStack_148;
                                } else if ((uint64_t)var_e8h < 0x1000) {
                                    ppiVar44 = (int64_t **)func_0x000180459890(var_e8h);
                                } else {
                                    if (var_e8h + 0x27U <= (uint64_t)var_e8h) goto code_r0x0001800c64fb;
                                    piVar23 = (int64_t *)func_0x000180459890();
                                    if (piVar23 == (int64_t *)0x0) {
                                        pcVar9 = (code *)swi(0x29);
                                        piVar23 = (int64_t *)(*pcVar9)(5);
                                        puVar37 = auStack_140;
                                    }
                                    ppiVar44 = (int64_t **)((int64_t)piVar23 + 0x27U & 0xffffffffffffffe0);
                                    ppiVar44[-1] = piVar23;
                                    puVar38 = puVar37;
                                }
                                ppiStack_a0 = ppiVar44 + iVar35 * 5;
                                ppiStack_98 = ppiStack_a0 + 5;
                                *ppiStack_a0 = (int64_t *)ppiVar45;
                                ppiStack_a0[1] = (int64_t *)var_80h;
                                ppiStack_a0[2] = piVar29;
                                ppiStack_a0[3] = (int64_t *)var_70h;
                                ppiVar45 = (int64_t **)0x0;
                                _auStack_88 = ZEXT816(0);
                                var_78h = 0;
                                ppiVar6 = *(int64_t ***)(iVar31 + 0x48);
                                ppiStack_b8 = ppiVar46;
                                ppiStack_b0 = ppiVar44;
                                uStack_a8 = uVar34;
                                if (ppiVar41 == ppiVar6) {
                                    ppiVar41 = (int64_t **)*ppiVar46;
                                    *(int64_t ***)(puVar38 + 0x68) = ppiVar44;
                                    *(int64_t ***)(puVar38 + 0x70) = ppiVar44;
                                    *(int64_t ***)(puVar38 + 0x78) = ppiVar46;
                                    ppiVar36 = ppiVar44;
                                    for (; ppiVar41 != ppiVar6; ppiVar41 = ppiVar41 + 5) {
                                        *ppiVar36 = (int64_t *)0x0;
                                        ppiVar36[1] = (int64_t *)0x0;
                                        ppiVar36[2] = ppiVar41[2];
                                        ppiVar36[3] = ppiVar41[3];
                                        piVar23 = ppiVar41[1];
                                        if (piVar23 != (int64_t *)0x0) {
                                            *(undefined8 *)(puVar38 + -8) = 0x1800c5cd1;
                                            piVar23 = (int64_t *)func_0x000180459890((int64_t)piVar23 << 5);
                                            *ppiVar36 = piVar23;
                                            piVar23 = (int64_t *)0x0;
                                            if (ppiVar41[1] != (int64_t *)0x0) {
                                                do {
                                                    piVar7 = *ppiVar36;
                                                    piVar8 = *ppiVar41;
                                                    piVar29 = piVar8 + (int64_t)piVar23 * 4;
                                                    uVar11 = *(undefined4 *)((int64_t)piVar29 + 4);
                                                    uVar12 = *(undefined4 *)(piVar29 + 1);
                                                    uVar13 = *(undefined4 *)((int64_t)piVar29 + 0xc);
                                                    piVar47 = piVar7 + (int64_t)piVar23 * 4;
                                                    *(undefined4 *)piVar47 = *(undefined4 *)piVar29;
                                                    *(undefined4 *)((int64_t)piVar47 + 4) = uVar11;
                                                    *(undefined4 *)(piVar47 + 1) = uVar12;
                                                    *(undefined4 *)((int64_t)piVar47 + 0xc) = uVar13;
                                                    piVar8 = piVar8 + (int64_t)piVar23 * 4 + 2;
                                                    uVar11 = *(undefined4 *)((int64_t)piVar8 + 4);
                                                    uVar12 = *(undefined4 *)(piVar8 + 1);
                                                    uVar13 = *(undefined4 *)((int64_t)piVar8 + 0xc);
                                                    piVar7 = piVar7 + (int64_t)piVar23 * 4 + 2;
                                                    *(undefined4 *)piVar7 = *(undefined4 *)piVar8;
                                                    *(undefined4 *)((int64_t)piVar7 + 4) = uVar11;
                                                    *(undefined4 *)(piVar7 + 1) = uVar12;
                                                    *(undefined4 *)((int64_t)piVar7 + 0xc) = uVar13;
                                                    piVar23 = (int64_t *)((int64_t)piVar23 + 1);
                                                    ppiVar36[1] = piVar23;
                                                } while (piVar23 < ppiVar41[1]);
                                            }
                                        }
                                        ppiVar36 = ppiVar36 + 5;
                                        *(int64_t ***)(puVar38 + 0x70) = ppiVar36;
                                    }
                                } else {
                                    ppiVar6 = ppiVar44;
                                    for (ppiVar36 = (int64_t **)*ppiVar46; ppiVar36 != ppiVar41; ppiVar36 = ppiVar36 + 5
                                        ) {
                                        *ppiVar6 = *ppiVar36;
                                        ppiVar6[1] = ppiVar36[1];
                                        ppiVar6[2] = ppiVar36[2];
                                        ppiVar6[3] = ppiVar36[3];
                                        *ppiVar36 = (int64_t *)0x0;
                                        ppiVar36[1] = (int64_t *)0x0;
                                        ppiVar36[2] = (int64_t *)0x0;
                                        ppiVar6 = ppiVar6 + 5;
                                    }
                                    ppiVar36 = *(int64_t ***)(iVar31 + 0x48);
                                    ppiVar6 = ppiVar44 + (iVar35 + 1) * 5;
                                    for (; ppiVar41 != ppiVar36; ppiVar41 = ppiVar41 + 5) {
                                        *ppiVar6 = *ppiVar41;
                                        ppiVar6[1] = ppiVar41[1];
                                        ppiVar6[2] = ppiVar41[2];
                                        ppiVar6[3] = ppiVar41[3];
                                        *ppiVar41 = (int64_t *)0x0;
                                        ppiVar41[1] = (int64_t *)0x0;
                                        ppiVar41[2] = (int64_t *)0x0;
                                        ppiVar6 = ppiVar6 + 5;
                                    }
                                }
                                piVar23 = *ppiVar46;
                                if (piVar23 != (int64_t *)0x0) {
                                    piVar29 = *(int64_t **)(iVar31 + 0x48);
                                    for (; piVar23 != piVar29; piVar23 = piVar23 + 5) {
                                        if (*piVar23 != 0) {
                                            *(undefined8 *)(puVar38 + -8) = 0x1800c5ddd;
                                            fcn.1800f4640();
                                            *piVar23 = 0;
                                            piVar23[1] = 0;
                                        }
                                    }
                                    piVar23 = *ppiVar46;
                                    piVar29 = piVar23;
                                    if ((0xfff < (uint64_t)((*(int64_t *)(iVar31 + 0x50) - (int64_t)piVar23 >> 3) * 8))
                                       && (piVar29 = (int64_t *)piVar23[-1],
                                          0x1f < (uint64_t)((int64_t)piVar23 + (-8 - (int64_t)piVar29)))) {
                                        piVar29 = (int64_t *)0x5;
                                        pcVar9 = (code *)swi(0x29);
                                        (*pcVar9)(5);
                                        puVar38 = puVar38 + 8;
                                    }
                                    *(undefined8 *)(puVar38 + -8) = 0x1800c5e49;
                                    func_0x000180459c3c(piVar29);
                                }
                                *ppiVar46 = (int64_t *)ppiVar44;
                                *(int64_t ***)(iVar31 + 0x48) = ppiVar44 + *(int64_t *)(puVar38 + 0x58) * 5;
                                *(int64_t *)(iVar31 + 0x50) = *(int64_t *)(puVar38 + 0x60) + (int64_t)ppiVar44;
                                puVar40 = puVar38;
                            } else {
                                *ppiVar41 = (int64_t *)ppiVar45;
                                ppiVar41[1] = piVar47;
                                ppiVar41[2] = piVar29;
                                ppiVar41[3] = (int64_t *)ppiVar44;
                                ppiVar45 = (int64_t **)0x0;
                                *(int64_t *)(iStack_c8 + 0x48) = *(int64_t *)(iStack_c8 + 0x48) + 0x28;
                                puVar40 = auStack_148;
                            }
                        }
                        puVar38 = puVar40;
                        if (ppiVar45 != (int64_t **)0x0) {
                            *(undefined8 *)(puVar40 + -8) = 0x1800c5b44;
                            fcn.1800f4640(ppiVar45);
                            arg2 = *(int64_t *)(puVar40 + 0x38);
                            goto code_r0x0001800c6341;
                        }
code_r0x0001800c538c:
                        arg2 = *(int64_t *)(puVar38 + 0x38);
                        puVar40 = puVar38;
                    }
                } else {
                    (**(code **)**(undefined8 **)(iVar31 + 0x90))();
                    puVar40 = auStack_148;
                }
            } else {
                fcn.1800c4d10(arg1, (int64_t)&var_e0h, *(int64_t *)(iVar31 + 0x28));
                fcn.1800c4d10(arg1, (int64_t)&var_108h, *(int64_t *)(iVar31 + 0x20));
                puVar40 = auStack_148;
                if ((((*(char *)0x180778018 != '\0') && (puVar40 = auStack_148, (int32_t)var_108h == 7)) &&
                    (puVar40 = auStack_148, (int32_t)var_e0h == 6)) &&
                   ((iVar31 = *(int64_t *)(arg1 + 0x40), puVar40 = auStack_148,
                    (uint64_t)var_100h < (uint64_t)((*(int64_t *)(arg1 + 0x48) - iVar31 >> 3) * -0x3333333333333333) &&
                    (puVar40 = auStack_148, var_e0h._4_4_ != 0)))) {
                    iVar35 = var_100h * 0x28;
                    func_0x0001800d6f20(*(undefined8 *)(arg1 + 0x38), &var_f0h, CONCAT44(var_d8h._4_4_, (float)var_d8h)
                                        , var_e0h._4_4_);
                    iVar31 = func_0x0001800c13d0(iVar31 + iVar35);
                    goto code_r0x0001800c4e71;
                }
            }
            goto code_r0x0001800c6341;
        }
        fcn.1800c4d10(arg1, (int64_t)&var_e0h, *(int64_t *)(iVar31 + 0x20));
        if ((*(char *)0x180778018 != '\0') && ((int32_t)var_e0h == 7)) {
            puVar40 = auStack_148;
            if (CONCAT44(var_d8h._4_4_, (float)var_d8h) <
                (uint64_t)((*(int64_t *)(arg1 + 0x48) - *(int64_t *)(arg1 + 0x40) >> 3) * -0x3333333333333333)) {
                iVar31 = func_0x0001800c13d0(*(int64_t *)(arg1 + 0x40) + CONCAT44(var_d8h._4_4_, (float)var_d8h) * 0x28)
                ;
code_r0x0001800c4e71:
                puVar40 = auStack_148;
                if ((iVar31 != 0) &&
                   (piVar23 = (int64_t *)(iVar31 + 8), puVar40 = auStack_148, piVar23 != (int64_t *)0x0))
                goto code_r0x0001800c632f;
            }
            goto code_r0x0001800c6341;
        }
        if ((int32_t)var_e0h == 5) {
            pcVar5 = *(char **)(iVar31 + 0x28);
            puVar40 = auStack_148;
            if (pcVar5 != (char *)0x0) {
                if (((*pcVar5 == 'x') && (pcVar5[1] == '\0')) || ((*pcVar5 == 'X' && (pcVar5[1] == '\0')))) {
                    *(undefined4 *)arg2 = 3;
                    *(double *)(arg2 + 8) = (double)(float)var_d8h;
                    puVar40 = auStack_148;
                } else if (((*pcVar5 == 'y') && (pcVar5[1] == '\0')) || ((*pcVar5 == 'Y' && (pcVar5[1] == '\0')))) {
                    *(undefined4 *)arg2 = 3;
                    *(double *)(arg2 + 8) = (double)var_d8h._4_4_;
                    puVar40 = auStack_148;
                } else if (((*pcVar5 == 'z') && (pcVar5[1] == '\0')) ||
                          ((puVar40 = auStack_148, *pcVar5 == 'Z' && (puVar40 = auStack_148, pcVar5[1] == '\0')))) {
                    *(undefined4 *)arg2 = 3;
                    *(double *)(arg2 + 8) = (double)(float)var_d0h;
                    puVar40 = auStack_148;
                }
            }
            goto code_r0x0001800c6341;
        }
        puVar40 = auStack_148;
        if (*(char *)(arg1 + 0x28) == '\0') goto code_r0x0001800c6341;
        iVar35 = 0;
        if (*(int32_t *)(*(int64_t *)(iVar31 + 0x20) + 8) == *(int32_t *)0x180782738) {
            iVar35 = *(int64_t *)(iVar31 + 0x20);
        }
        puVar40 = auStack_148;
        if (iVar35 == 0) goto code_r0x0001800c6341;
        if (*(int64_t *)(iVar35 + 0x20) != 0) {
            iVar43 = 0;
            do {
                iVar28 = iVar43 + 1;
                if (*(char *)(*(int64_t *)(iVar35 + 0x20) + iVar43) != *(char *)(iVar43 + 0x180625d34))
                goto code_r0x0001800c5758;
                iVar43 = iVar28;
            } while (iVar28 != 5);
            pcVar5 = *(char **)(iVar31 + 0x28);
            if (pcVar5 == (char *)0x0) {
code_r0x0001800c5728:
                var_108h = 0;
                var_100h = 0;
            } else if (((*pcVar5 == 'p') && (pcVar5[1] == 'i')) && (pcVar5[2] == '\0')) {
                var_108h = 3;
                var_100h = 0x400921fb54442d18;
            } else {
                iVar43 = 0;
                do {
                    iVar28 = iVar43 + 1;
                    if (pcVar5[iVar43] != *(char *)(iVar43 + 0x18063c6c4)) {
                        iVar43 = 0;
                        goto code_r0x0001800c5601;
                    }
                    iVar43 = iVar28;
                } while (iVar28 != 5);
                var_108h = 3;
                var_100h = 0x7ff0000000000000;
            }
            goto code_r0x0001800c573e;
        }
        goto code_r0x0001800c5758;
    }
code_r0x0001800c6322:
    piVar23 = (int64_t *)fcn.1800c4d10(arg1, (int64_t)auStack_88, *(int64_t *)(iVar31 + 0x20));
code_r0x0001800c632f:
    uVar11 = *(undefined4 *)((int64_t)piVar23 + 4);
    uVar12 = *(undefined4 *)(piVar23 + 1);
    uVar13 = *(undefined4 *)((int64_t)piVar23 + 0xc);
    *(undefined4 *)arg2 = *(undefined4 *)piVar23;
    *(undefined4 *)(arg2 + 4) = uVar11;
    *(undefined4 *)(arg2 + 8) = uVar12;
    *(undefined4 *)(arg2 + 0xc) = uVar13;
    var_d0h._0_4_ = (float)piVar23[2];
    var_d0h._4_4_ = (undefined4)((uint64_t)piVar23[2] >> 0x20);
code_r0x0001800c633b:
    *(uint64_t *)(arg2 + 0x10) = CONCAT44(var_d0h._4_4_, (float)var_d0h);
    puVar40 = auStack_148;
    goto code_r0x0001800c6341;
    while (iVar43 = iVar28, iVar28 != 4) {
code_r0x0001800c5601:
        iVar28 = iVar43 + 1;
        arg2 = var_110h;
        if (pcVar5[iVar43] != *(char *)(iVar43 + 0x18063e358)) {
            if ((*pcVar5 == 'e') && (pcVar5[1] == '\0')) {
                var_108h = 3;
                var_100h = 0x4005bf0a8b145769;
                goto code_r0x0001800c573e;
            }
            iVar43 = 0;
            goto code_r0x0001800c5670;
        }
    }
    var_108h = 3;
    var_100h = 0x7ff8000000000000;
    goto code_r0x0001800c573e;
    while (iVar43 = iVar28, iVar28 != 4) {
code_r0x0001800c5670:
        iVar28 = iVar43 + 1;
        if (pcVar5[iVar43] != *(char *)(iVar43 + 0x18063e350)) {
            iVar43 = 0;
            goto code_r0x0001800c56b0;
        }
    }
    var_108h = 3;
    var_100h = 0x3ff9e3779b97f4a8;
    goto code_r0x0001800c573e;
    while (iVar43 = iVar28, iVar28 != 6) {
code_r0x0001800c56b0:
        iVar28 = iVar43 + 1;
        if (pcVar5[iVar43] != *(char *)(iVar43 + 0x18063e370)) {
            iVar43 = 0;
            goto code_r0x0001800c56f0;
        }
    }
    var_108h = 3;
    var_100h = 0x3ff6a09e667f3bcd;
    goto code_r0x0001800c573e;
    while (iVar43 = iVar28, iVar28 != 4) {
code_r0x0001800c56f0:
        iVar28 = iVar43 + 1;
        if (pcVar5[iVar43] != *(char *)(iVar43 + 0x18063e36c)) goto code_r0x0001800c5728;
    }
    var_108h = 3;
    var_100h = 0x401921fb54442d18;
code_r0x0001800c573e:
    var_f8h = 0;
    *(int32_t *)arg2 = (int32_t)var_108h;
    *(int32_t *)(arg2 + 4) = 0;
    *(int32_t *)(arg2 + 8) = (int32_t)var_100h;
    *(int32_t *)(arg2 + 0xc) = var_100h._4_4_;
    *(undefined8 *)(arg2 + 0x10) = 0;
code_r0x0001800c5758:
    puVar40 = auStack_148;
    if ((*(code **)(arg1 + 0x30) != (code *)0x0) && (puVar40 = auStack_148, *(int32_t *)arg2 == 0)) {
        (**(code **)(arg1 + 0x30))(*(undefined8 *)(iVar35 + 0x20), *(undefined8 *)(iVar31 + 0x28), arg2);
        puVar40 = auStack_148;
    }
code_r0x0001800c6341:
    *(uint64_t *)(puVar40 + 0x58) = uStack_90;
    piVar23 = *(int64_t **)(iStack_c8 + 8);
    if ((*(char *)0x180777ff8 == '\0') || (*(char *)0x180778018 == '\0')) {
        if (*(int32_t *)arg2 == 0) {
            if ((((*(char *)(iStack_c8 + 0x58) == '\0') || (*(char *)0x180778018 != '\0')) && (piVar23[2] != 0)) &&
               (uStack_90 != piVar23[3])) {
                uVar26 = (uStack_90 >> 5 ^ uStack_90) >> 4;
                uVar34 = 0;
                do {
                    uVar26 = uVar26 & piVar23[1] - 1U;
                    iVar31 = uVar26 * 0x20;
                    uVar32 = *(uint64_t *)(iVar31 + *piVar23);
                    if (uVar32 == uStack_90) {
                        puVar42 = (undefined4 *)(*piVar23 + 8 + iVar31);
                        if (puVar42 != (undefined4 *)0x0) {
                            *puVar42 = 0;
                        }
                        break;
                    }
                    if (uVar32 == piVar23[3]) break;
                    uVar26 = uVar26 + 1 + uVar34;
                    uVar34 = uVar34 + 1;
                } while (uVar34 <= piVar23[1] - 1U);
            }
            goto code_r0x0001800c64c7;
        }
    } else {
        if (*(int32_t *)arg2 == 7) goto code_r0x0001800c64c7;
        if (*(int32_t *)arg2 == 0) {
            if (((*(char *)(iStack_c8 + 0x58) == '\0') && (piVar23[2] != 0)) && (uStack_90 != piVar23[3])) {
                uVar26 = (uStack_90 >> 5 ^ uStack_90) >> 4;
                uVar34 = 0;
                do {
                    uVar26 = uVar26 & piVar23[1] - 1U;
                    iVar31 = uVar26 * 0x20;
                    uVar32 = *(uint64_t *)(iVar31 + *piVar23);
                    if (uVar32 == uStack_90) {
                        puVar42 = (undefined4 *)(*piVar23 + 8 + iVar31);
                        if (puVar42 != (undefined4 *)0x0) {
                            *(undefined8 *)(puVar40 + -8) = 0x1800c643d;
                            func_0x0001800c6520(iStack_c8, piVar23, uStack_90, puVar42);
                            *puVar42 = 0;
                        }
                        break;
                    }
                    if (uVar32 == piVar23[3]) break;
                    uVar26 = uVar26 + 1 + uVar34;
                    uVar34 = uVar34 + 1;
                } while (uVar34 <= piVar23[1] - 1U);
            }
            goto code_r0x0001800c64c7;
        }
        *(undefined8 *)(puVar40 + -8) = 0x1800c638d;
        func_0x0001800c6520(iStack_c8, piVar23, uStack_90, 0);
    }
    iVar3 = *(int32_t *)arg2;
    iVar17 = *(int32_t *)(arg2 + 4);
    iVar18 = *(int32_t *)(arg2 + 8);
    iVar19 = *(int32_t *)(arg2 + 0xc);
    uVar2 = *(undefined8 *)(arg2 + 0x10);
    *(undefined8 *)(puVar40 + -8) = 0x1800c63a4;
    piVar25 = (int32_t *)func_0x0001800c05e0(piVar23, puVar40 + 0x58);
    *piVar25 = iVar3;
    piVar25[1] = iVar17;
    piVar25[2] = iVar18;
    piVar25[3] = iVar19;
    *(undefined8 *)(piVar25 + 4) = uVar2;
code_r0x0001800c64c7:
    *(undefined8 *)(puVar40 + -8) = 0x1800c64d6;
    func_0x000180459870(var_60h ^ (uint64_t)puVar40);
    return;
}

// ============================================================
// Function: FUN_1800c6520
// Address: 0x1800c6520
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_37h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800c6520(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_90h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    undefined *puVar8;
    int64_t *unaff_RSI;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_78 [8];
    undefined auStack_70 [32];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    undefined4 var_37h;
    int64_t var_33h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    ppiVar1 = *(int64_t ***)(arg1 + 0xa8);
    if (ppiVar1 == (int64_t **)0x0) {
        return;
    }
    if (arg4 == 0) {
        if ((*(int64_t *)(arg2 + 0x10) != 0) && (arg3 != *(int64_t *)(arg2 + 0x18))) {
            uVar9 = *(int64_t *)(arg2 + 8) - 1;
            uVar5 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            uVar7 = 0;
            do {
                uVar5 = uVar5 & uVar9;
                piVar11 = (int64_t *)(uVar5 * 0x20 + *(int64_t *)arg2);
                iVar10 = *piVar11;
                if (iVar10 == arg3) {
                    arg4 = (int64_t)(piVar11 + 1);
                    goto code_r0x0001800c65ab;
                }
                if (iVar10 == *(int64_t *)(arg2 + 0x18)) break;
                uVar5 = uVar5 + 1 + uVar7;
                uVar7 = uVar7 + 1;
            } while (uVar7 <= uVar9);
        }
        arg4 = 0;
code_r0x0001800c65ab:
        if ((int64_t *)arg4 != (int64_t *)0x0) goto code_r0x0001800c65b0;
        var_50h._0_4_ = 0;
        var_50h._4_4_ = 0;
        var_40h = 0;
        var_48h = 0;
    } else {
code_r0x0001800c65b0:
        var_50h._0_4_ = *(undefined4 *)arg4;
        var_50h._4_4_ = *(undefined4 *)(arg4 + 4);
        var_48h = *(int64_t *)(arg4 + 8);
        var_40h = *(int64_t *)(arg4 + 0x10);
    }
    piVar11 = ppiVar1[1];
    if (piVar11 != ppiVar1[2]) {
        var_48h._4_4_ = (undefined4)((uint64_t)var_48h >> 0x20);
        *(undefined4 *)((int64_t)piVar11 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar11 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar11 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar11 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar11 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar11 + 0x27) = var_33h._2_1_;
        *piVar11 = arg3;
        piVar11[3] = var_40h;
        *(bool *)(piVar11 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        ppiVar1[1] = ppiVar1[1] + 5;
        return;
    }
    iVar10 = ((int64_t)piVar11 - (int64_t)*ppiVar1) / 0x28;
    if (iVar10 == 0x666666666666666) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = ((int64_t)ppiVar1[2] - (int64_t)*ppiVar1 >> 3) * -0x3333333333333333;
    uVar7 = 0x666666666666666 - (uVar5 >> 1);
    if (uVar7 <= uVar5 && uVar5 - uVar7 != 0) {
code_r0x0001800c683f:
        func_0x000180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (uVar5 >> 1) + uVar5;
    uVar7 = iVar10 + 1;
    uVar9 = uVar7;
    if (uVar7 <= uVar5) {
        uVar9 = uVar5;
    }
    if (0x666666666666666 < uVar9) goto code_r0x0001800c683f;
    uVar5 = uVar9 * 0x28;
    if (uVar5 == 0) {
        unaff_RSI = (int64_t *)0x0;
code_r0x0001800c6723:
        piVar6 = unaff_RSI + iVar10 * 5;
        *(undefined4 *)((int64_t)piVar6 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar6 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar6 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar6 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar6 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar6 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar6 + 0x27) = var_33h._2_1_;
        *piVar6 = arg3;
        piVar6[3] = var_40h;
        *(bool *)(piVar6 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        piVar2 = *ppiVar1;
        if (piVar11 == ppiVar1[1]) {
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar2;
            piVar6 = unaff_RSI;
            piVar11 = piVar2;
        } else {
            func_0x000180498030(unaff_RSI, piVar2, (int64_t)piVar11 - (int64_t)piVar2);
            piVar6 = piVar6 + 5;
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar11;
        }
        func_0x000180498030(piVar6, piVar11, iVar10);
        piVar11 = *ppiVar1;
        if (piVar11 == (int64_t *)0x0) goto code_r0x0001800c67f4;
        piVar6 = piVar11;
        puVar8 = auStack_78;
        if ((0xfff < (uint64_t)(((int64_t)ppiVar1[2] - (int64_t)piVar11 >> 3) * 8)) &&
           (piVar6 = (int64_t *)piVar11[-1], puVar8 = auStack_78,
           0x1f < (uint64_t)((int64_t)piVar11 + (-8 - (int64_t)piVar6)))) goto code_r0x0001800c67e2;
    } else {
        if (uVar5 < 0x1000) {
            unaff_RSI = (int64_t *)func_0x000180459890(uVar5);
            goto code_r0x0001800c6723;
        }
        if (uVar5 + 0x27 <= uVar5) goto code_r0x0001800c683f;
        iVar4 = func_0x000180459890();
        if (iVar4 != 0) {
            unaff_RSI = (int64_t *)(iVar4 + 0x27U & 0xffffffffffffffe0);
            unaff_RSI[-1] = iVar4;
            goto code_r0x0001800c6723;
        }
code_r0x0001800c67e2:
        piVar6 = (int64_t *)0x5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar8 = auStack_70;
    }
    *(undefined8 *)(puVar8 + -8) = 0x1800c67f4;
    func_0x000180459c3c(piVar6);
code_r0x0001800c67f4:
    *ppiVar1 = unaff_RSI;
    ppiVar1[1] = unaff_RSI + uVar7 * 5;
    ppiVar1[2] = unaff_RSI + uVar9 * 5;
    return;
}

// ============================================================
// Function: FUN_1800c653d
// Address: 0x1800c653d
// Size: 257 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_37h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800c6520(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_90h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    undefined *puVar8;
    int64_t *unaff_RSI;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_78 [8];
    undefined auStack_70 [32];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    undefined4 var_37h;
    int64_t var_33h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    ppiVar1 = *(int64_t ***)(arg1 + 0xa8);
    if (ppiVar1 == (int64_t **)0x0) {
        return;
    }
    if (arg4 == 0) {
        if ((*(int64_t *)(arg2 + 0x10) != 0) && (arg3 != *(int64_t *)(arg2 + 0x18))) {
            uVar9 = *(int64_t *)(arg2 + 8) - 1;
            uVar5 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            uVar7 = 0;
            do {
                uVar5 = uVar5 & uVar9;
                piVar11 = (int64_t *)(uVar5 * 0x20 + *(int64_t *)arg2);
                iVar10 = *piVar11;
                if (iVar10 == arg3) {
                    arg4 = (int64_t)(piVar11 + 1);
                    goto code_r0x0001800c65ab;
                }
                if (iVar10 == *(int64_t *)(arg2 + 0x18)) break;
                uVar5 = uVar5 + 1 + uVar7;
                uVar7 = uVar7 + 1;
            } while (uVar7 <= uVar9);
        }
        arg4 = 0;
code_r0x0001800c65ab:
        if ((int64_t *)arg4 != (int64_t *)0x0) goto code_r0x0001800c65b0;
        var_50h._0_4_ = 0;
        var_50h._4_4_ = 0;
        var_40h = 0;
        var_48h = 0;
    } else {
code_r0x0001800c65b0:
        var_50h._0_4_ = *(undefined4 *)arg4;
        var_50h._4_4_ = *(undefined4 *)(arg4 + 4);
        var_48h = *(int64_t *)(arg4 + 8);
        var_40h = *(int64_t *)(arg4 + 0x10);
    }
    piVar11 = ppiVar1[1];
    if (piVar11 != ppiVar1[2]) {
        var_48h._4_4_ = (undefined4)((uint64_t)var_48h >> 0x20);
        *(undefined4 *)((int64_t)piVar11 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar11 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar11 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar11 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar11 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar11 + 0x27) = var_33h._2_1_;
        *piVar11 = arg3;
        piVar11[3] = var_40h;
        *(bool *)(piVar11 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        ppiVar1[1] = ppiVar1[1] + 5;
        return;
    }
    iVar10 = ((int64_t)piVar11 - (int64_t)*ppiVar1) / 0x28;
    if (iVar10 == 0x666666666666666) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = ((int64_t)ppiVar1[2] - (int64_t)*ppiVar1 >> 3) * -0x3333333333333333;
    uVar7 = 0x666666666666666 - (uVar5 >> 1);
    if (uVar7 <= uVar5 && uVar5 - uVar7 != 0) {
code_r0x0001800c683f:
        func_0x000180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (uVar5 >> 1) + uVar5;
    uVar7 = iVar10 + 1;
    uVar9 = uVar7;
    if (uVar7 <= uVar5) {
        uVar9 = uVar5;
    }
    if (0x666666666666666 < uVar9) goto code_r0x0001800c683f;
    uVar5 = uVar9 * 0x28;
    if (uVar5 == 0) {
        unaff_RSI = (int64_t *)0x0;
code_r0x0001800c6723:
        piVar6 = unaff_RSI + iVar10 * 5;
        *(undefined4 *)((int64_t)piVar6 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar6 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar6 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar6 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar6 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar6 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar6 + 0x27) = var_33h._2_1_;
        *piVar6 = arg3;
        piVar6[3] = var_40h;
        *(bool *)(piVar6 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        piVar2 = *ppiVar1;
        if (piVar11 == ppiVar1[1]) {
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar2;
            piVar6 = unaff_RSI;
            piVar11 = piVar2;
        } else {
            func_0x000180498030(unaff_RSI, piVar2, (int64_t)piVar11 - (int64_t)piVar2);
            piVar6 = piVar6 + 5;
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar11;
        }
        func_0x000180498030(piVar6, piVar11, iVar10);
        piVar11 = *ppiVar1;
        if (piVar11 == (int64_t *)0x0) goto code_r0x0001800c67f4;
        piVar6 = piVar11;
        puVar8 = auStack_78;
        if ((0xfff < (uint64_t)(((int64_t)ppiVar1[2] - (int64_t)piVar11 >> 3) * 8)) &&
           (piVar6 = (int64_t *)piVar11[-1], puVar8 = auStack_78,
           0x1f < (uint64_t)((int64_t)piVar11 + (-8 - (int64_t)piVar6)))) goto code_r0x0001800c67e2;
    } else {
        if (uVar5 < 0x1000) {
            unaff_RSI = (int64_t *)func_0x000180459890(uVar5);
            goto code_r0x0001800c6723;
        }
        if (uVar5 + 0x27 <= uVar5) goto code_r0x0001800c683f;
        iVar4 = func_0x000180459890();
        if (iVar4 != 0) {
            unaff_RSI = (int64_t *)(iVar4 + 0x27U & 0xffffffffffffffe0);
            unaff_RSI[-1] = iVar4;
            goto code_r0x0001800c6723;
        }
code_r0x0001800c67e2:
        piVar6 = (int64_t *)0x5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar8 = auStack_70;
    }
    *(undefined8 *)(puVar8 + -8) = 0x1800c67f4;
    func_0x000180459c3c(piVar6);
code_r0x0001800c67f4:
    *ppiVar1 = unaff_RSI;
    ppiVar1[1] = unaff_RSI + uVar7 * 5;
    ppiVar1[2] = unaff_RSI + uVar9 * 5;
    return;
}

// ============================================================
// Function: FUN_1800c663e
// Address: 0x1800c663e
// Size: 487 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_37h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800c6520(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_90h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    undefined *puVar8;
    int64_t *unaff_RSI;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_78 [8];
    undefined auStack_70 [32];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    undefined4 var_37h;
    int64_t var_33h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    ppiVar1 = *(int64_t ***)(arg1 + 0xa8);
    if (ppiVar1 == (int64_t **)0x0) {
        return;
    }
    if (arg4 == 0) {
        if ((*(int64_t *)(arg2 + 0x10) != 0) && (arg3 != *(int64_t *)(arg2 + 0x18))) {
            uVar9 = *(int64_t *)(arg2 + 8) - 1;
            uVar5 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            uVar7 = 0;
            do {
                uVar5 = uVar5 & uVar9;
                piVar11 = (int64_t *)(uVar5 * 0x20 + *(int64_t *)arg2);
                iVar10 = *piVar11;
                if (iVar10 == arg3) {
                    arg4 = (int64_t)(piVar11 + 1);
                    goto code_r0x0001800c65ab;
                }
                if (iVar10 == *(int64_t *)(arg2 + 0x18)) break;
                uVar5 = uVar5 + 1 + uVar7;
                uVar7 = uVar7 + 1;
            } while (uVar7 <= uVar9);
        }
        arg4 = 0;
code_r0x0001800c65ab:
        if ((int64_t *)arg4 != (int64_t *)0x0) goto code_r0x0001800c65b0;
        var_50h._0_4_ = 0;
        var_50h._4_4_ = 0;
        var_40h = 0;
        var_48h = 0;
    } else {
code_r0x0001800c65b0:
        var_50h._0_4_ = *(undefined4 *)arg4;
        var_50h._4_4_ = *(undefined4 *)(arg4 + 4);
        var_48h = *(int64_t *)(arg4 + 8);
        var_40h = *(int64_t *)(arg4 + 0x10);
    }
    piVar11 = ppiVar1[1];
    if (piVar11 != ppiVar1[2]) {
        var_48h._4_4_ = (undefined4)((uint64_t)var_48h >> 0x20);
        *(undefined4 *)((int64_t)piVar11 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar11 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar11 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar11 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar11 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar11 + 0x27) = var_33h._2_1_;
        *piVar11 = arg3;
        piVar11[3] = var_40h;
        *(bool *)(piVar11 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        ppiVar1[1] = ppiVar1[1] + 5;
        return;
    }
    iVar10 = ((int64_t)piVar11 - (int64_t)*ppiVar1) / 0x28;
    if (iVar10 == 0x666666666666666) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = ((int64_t)ppiVar1[2] - (int64_t)*ppiVar1 >> 3) * -0x3333333333333333;
    uVar7 = 0x666666666666666 - (uVar5 >> 1);
    if (uVar7 <= uVar5 && uVar5 - uVar7 != 0) {
code_r0x0001800c683f:
        func_0x000180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (uVar5 >> 1) + uVar5;
    uVar7 = iVar10 + 1;
    uVar9 = uVar7;
    if (uVar7 <= uVar5) {
        uVar9 = uVar5;
    }
    if (0x666666666666666 < uVar9) goto code_r0x0001800c683f;
    uVar5 = uVar9 * 0x28;
    if (uVar5 == 0) {
        unaff_RSI = (int64_t *)0x0;
code_r0x0001800c6723:
        piVar6 = unaff_RSI + iVar10 * 5;
        *(undefined4 *)((int64_t)piVar6 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar6 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar6 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar6 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar6 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar6 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar6 + 0x27) = var_33h._2_1_;
        *piVar6 = arg3;
        piVar6[3] = var_40h;
        *(bool *)(piVar6 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        piVar2 = *ppiVar1;
        if (piVar11 == ppiVar1[1]) {
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar2;
            piVar6 = unaff_RSI;
            piVar11 = piVar2;
        } else {
            func_0x000180498030(unaff_RSI, piVar2, (int64_t)piVar11 - (int64_t)piVar2);
            piVar6 = piVar6 + 5;
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar11;
        }
        func_0x000180498030(piVar6, piVar11, iVar10);
        piVar11 = *ppiVar1;
        if (piVar11 == (int64_t *)0x0) goto code_r0x0001800c67f4;
        piVar6 = piVar11;
        puVar8 = auStack_78;
        if ((0xfff < (uint64_t)(((int64_t)ppiVar1[2] - (int64_t)piVar11 >> 3) * 8)) &&
           (piVar6 = (int64_t *)piVar11[-1], puVar8 = auStack_78,
           0x1f < (uint64_t)((int64_t)piVar11 + (-8 - (int64_t)piVar6)))) goto code_r0x0001800c67e2;
    } else {
        if (uVar5 < 0x1000) {
            unaff_RSI = (int64_t *)func_0x000180459890(uVar5);
            goto code_r0x0001800c6723;
        }
        if (uVar5 + 0x27 <= uVar5) goto code_r0x0001800c683f;
        iVar4 = func_0x000180459890();
        if (iVar4 != 0) {
            unaff_RSI = (int64_t *)(iVar4 + 0x27U & 0xffffffffffffffe0);
            unaff_RSI[-1] = iVar4;
            goto code_r0x0001800c6723;
        }
code_r0x0001800c67e2:
        piVar6 = (int64_t *)0x5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar8 = auStack_70;
    }
    *(undefined8 *)(puVar8 + -8) = 0x1800c67f4;
    func_0x000180459c3c(piVar6);
code_r0x0001800c67f4:
    *ppiVar1 = unaff_RSI;
    ppiVar1[1] = unaff_RSI + uVar7 * 5;
    ppiVar1[2] = unaff_RSI + uVar9 * 5;
    return;
}

// ============================================================
// Function: FUN_1800c6825
// Address: 0x1800c6825
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_37h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800c6520(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_90h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    undefined *puVar8;
    int64_t *unaff_RSI;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_78 [8];
    undefined auStack_70 [32];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    undefined4 var_37h;
    int64_t var_33h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    ppiVar1 = *(int64_t ***)(arg1 + 0xa8);
    if (ppiVar1 == (int64_t **)0x0) {
        return;
    }
    if (arg4 == 0) {
        if ((*(int64_t *)(arg2 + 0x10) != 0) && (arg3 != *(int64_t *)(arg2 + 0x18))) {
            uVar9 = *(int64_t *)(arg2 + 8) - 1;
            uVar5 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            uVar7 = 0;
            do {
                uVar5 = uVar5 & uVar9;
                piVar11 = (int64_t *)(uVar5 * 0x20 + *(int64_t *)arg2);
                iVar10 = *piVar11;
                if (iVar10 == arg3) {
                    arg4 = (int64_t)(piVar11 + 1);
                    goto code_r0x0001800c65ab;
                }
                if (iVar10 == *(int64_t *)(arg2 + 0x18)) break;
                uVar5 = uVar5 + 1 + uVar7;
                uVar7 = uVar7 + 1;
            } while (uVar7 <= uVar9);
        }
        arg4 = 0;
code_r0x0001800c65ab:
        if ((int64_t *)arg4 != (int64_t *)0x0) goto code_r0x0001800c65b0;
        var_50h._0_4_ = 0;
        var_50h._4_4_ = 0;
        var_40h = 0;
        var_48h = 0;
    } else {
code_r0x0001800c65b0:
        var_50h._0_4_ = *(undefined4 *)arg4;
        var_50h._4_4_ = *(undefined4 *)(arg4 + 4);
        var_48h = *(int64_t *)(arg4 + 8);
        var_40h = *(int64_t *)(arg4 + 0x10);
    }
    piVar11 = ppiVar1[1];
    if (piVar11 != ppiVar1[2]) {
        var_48h._4_4_ = (undefined4)((uint64_t)var_48h >> 0x20);
        *(undefined4 *)((int64_t)piVar11 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar11 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar11 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar11 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar11 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar11 + 0x27) = var_33h._2_1_;
        *piVar11 = arg3;
        piVar11[3] = var_40h;
        *(bool *)(piVar11 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        ppiVar1[1] = ppiVar1[1] + 5;
        return;
    }
    iVar10 = ((int64_t)piVar11 - (int64_t)*ppiVar1) / 0x28;
    if (iVar10 == 0x666666666666666) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = ((int64_t)ppiVar1[2] - (int64_t)*ppiVar1 >> 3) * -0x3333333333333333;
    uVar7 = 0x666666666666666 - (uVar5 >> 1);
    if (uVar7 <= uVar5 && uVar5 - uVar7 != 0) {
code_r0x0001800c683f:
        func_0x000180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (uVar5 >> 1) + uVar5;
    uVar7 = iVar10 + 1;
    uVar9 = uVar7;
    if (uVar7 <= uVar5) {
        uVar9 = uVar5;
    }
    if (0x666666666666666 < uVar9) goto code_r0x0001800c683f;
    uVar5 = uVar9 * 0x28;
    if (uVar5 == 0) {
        unaff_RSI = (int64_t *)0x0;
code_r0x0001800c6723:
        piVar6 = unaff_RSI + iVar10 * 5;
        *(undefined4 *)((int64_t)piVar6 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar6 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar6 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar6 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar6 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar6 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar6 + 0x27) = var_33h._2_1_;
        *piVar6 = arg3;
        piVar6[3] = var_40h;
        *(bool *)(piVar6 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        piVar2 = *ppiVar1;
        if (piVar11 == ppiVar1[1]) {
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar2;
            piVar6 = unaff_RSI;
            piVar11 = piVar2;
        } else {
            func_0x000180498030(unaff_RSI, piVar2, (int64_t)piVar11 - (int64_t)piVar2);
            piVar6 = piVar6 + 5;
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar11;
        }
        func_0x000180498030(piVar6, piVar11, iVar10);
        piVar11 = *ppiVar1;
        if (piVar11 == (int64_t *)0x0) goto code_r0x0001800c67f4;
        piVar6 = piVar11;
        puVar8 = auStack_78;
        if ((0xfff < (uint64_t)(((int64_t)ppiVar1[2] - (int64_t)piVar11 >> 3) * 8)) &&
           (piVar6 = (int64_t *)piVar11[-1], puVar8 = auStack_78,
           0x1f < (uint64_t)((int64_t)piVar11 + (-8 - (int64_t)piVar6)))) goto code_r0x0001800c67e2;
    } else {
        if (uVar5 < 0x1000) {
            unaff_RSI = (int64_t *)func_0x000180459890(uVar5);
            goto code_r0x0001800c6723;
        }
        if (uVar5 + 0x27 <= uVar5) goto code_r0x0001800c683f;
        iVar4 = func_0x000180459890();
        if (iVar4 != 0) {
            unaff_RSI = (int64_t *)(iVar4 + 0x27U & 0xffffffffffffffe0);
            unaff_RSI[-1] = iVar4;
            goto code_r0x0001800c6723;
        }
code_r0x0001800c67e2:
        piVar6 = (int64_t *)0x5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar8 = auStack_70;
    }
    *(undefined8 *)(puVar8 + -8) = 0x1800c67f4;
    func_0x000180459c3c(piVar6);
code_r0x0001800c67f4:
    *ppiVar1 = unaff_RSI;
    ppiVar1[1] = unaff_RSI + uVar7 * 5;
    ppiVar1[2] = unaff_RSI + uVar9 * 5;
    return;
}

// ============================================================
// Function: FUN_1800c6832
// Address: 0x1800c6832
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_37h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800c6520(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_90h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    undefined *puVar8;
    int64_t *unaff_RSI;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_78 [8];
    undefined auStack_70 [32];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    undefined4 var_37h;
    int64_t var_33h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    ppiVar1 = *(int64_t ***)(arg1 + 0xa8);
    if (ppiVar1 == (int64_t **)0x0) {
        return;
    }
    if (arg4 == 0) {
        if ((*(int64_t *)(arg2 + 0x10) != 0) && (arg3 != *(int64_t *)(arg2 + 0x18))) {
            uVar9 = *(int64_t *)(arg2 + 8) - 1;
            uVar5 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            uVar7 = 0;
            do {
                uVar5 = uVar5 & uVar9;
                piVar11 = (int64_t *)(uVar5 * 0x20 + *(int64_t *)arg2);
                iVar10 = *piVar11;
                if (iVar10 == arg3) {
                    arg4 = (int64_t)(piVar11 + 1);
                    goto code_r0x0001800c65ab;
                }
                if (iVar10 == *(int64_t *)(arg2 + 0x18)) break;
                uVar5 = uVar5 + 1 + uVar7;
                uVar7 = uVar7 + 1;
            } while (uVar7 <= uVar9);
        }
        arg4 = 0;
code_r0x0001800c65ab:
        if ((int64_t *)arg4 != (int64_t *)0x0) goto code_r0x0001800c65b0;
        var_50h._0_4_ = 0;
        var_50h._4_4_ = 0;
        var_40h = 0;
        var_48h = 0;
    } else {
code_r0x0001800c65b0:
        var_50h._0_4_ = *(undefined4 *)arg4;
        var_50h._4_4_ = *(undefined4 *)(arg4 + 4);
        var_48h = *(int64_t *)(arg4 + 8);
        var_40h = *(int64_t *)(arg4 + 0x10);
    }
    piVar11 = ppiVar1[1];
    if (piVar11 != ppiVar1[2]) {
        var_48h._4_4_ = (undefined4)((uint64_t)var_48h >> 0x20);
        *(undefined4 *)((int64_t)piVar11 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar11 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar11 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar11 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar11 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar11 + 0x27) = var_33h._2_1_;
        *piVar11 = arg3;
        piVar11[3] = var_40h;
        *(bool *)(piVar11 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        ppiVar1[1] = ppiVar1[1] + 5;
        return;
    }
    iVar10 = ((int64_t)piVar11 - (int64_t)*ppiVar1) / 0x28;
    if (iVar10 == 0x666666666666666) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = ((int64_t)ppiVar1[2] - (int64_t)*ppiVar1 >> 3) * -0x3333333333333333;
    uVar7 = 0x666666666666666 - (uVar5 >> 1);
    if (uVar7 <= uVar5 && uVar5 - uVar7 != 0) {
code_r0x0001800c683f:
        func_0x000180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (uVar5 >> 1) + uVar5;
    uVar7 = iVar10 + 1;
    uVar9 = uVar7;
    if (uVar7 <= uVar5) {
        uVar9 = uVar5;
    }
    if (0x666666666666666 < uVar9) goto code_r0x0001800c683f;
    uVar5 = uVar9 * 0x28;
    if (uVar5 == 0) {
        unaff_RSI = (int64_t *)0x0;
code_r0x0001800c6723:
        piVar6 = unaff_RSI + iVar10 * 5;
        *(undefined4 *)((int64_t)piVar6 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar6 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar6 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar6 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar6 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar6 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar6 + 0x27) = var_33h._2_1_;
        *piVar6 = arg3;
        piVar6[3] = var_40h;
        *(bool *)(piVar6 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        piVar2 = *ppiVar1;
        if (piVar11 == ppiVar1[1]) {
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar2;
            piVar6 = unaff_RSI;
            piVar11 = piVar2;
        } else {
            func_0x000180498030(unaff_RSI, piVar2, (int64_t)piVar11 - (int64_t)piVar2);
            piVar6 = piVar6 + 5;
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar11;
        }
        func_0x000180498030(piVar6, piVar11, iVar10);
        piVar11 = *ppiVar1;
        if (piVar11 == (int64_t *)0x0) goto code_r0x0001800c67f4;
        piVar6 = piVar11;
        puVar8 = auStack_78;
        if ((0xfff < (uint64_t)(((int64_t)ppiVar1[2] - (int64_t)piVar11 >> 3) * 8)) &&
           (piVar6 = (int64_t *)piVar11[-1], puVar8 = auStack_78,
           0x1f < (uint64_t)((int64_t)piVar11 + (-8 - (int64_t)piVar6)))) goto code_r0x0001800c67e2;
    } else {
        if (uVar5 < 0x1000) {
            unaff_RSI = (int64_t *)func_0x000180459890(uVar5);
            goto code_r0x0001800c6723;
        }
        if (uVar5 + 0x27 <= uVar5) goto code_r0x0001800c683f;
        iVar4 = func_0x000180459890();
        if (iVar4 != 0) {
            unaff_RSI = (int64_t *)(iVar4 + 0x27U & 0xffffffffffffffe0);
            unaff_RSI[-1] = iVar4;
            goto code_r0x0001800c6723;
        }
code_r0x0001800c67e2:
        piVar6 = (int64_t *)0x5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar8 = auStack_70;
    }
    *(undefined8 *)(puVar8 + -8) = 0x1800c67f4;
    func_0x000180459c3c(piVar6);
code_r0x0001800c67f4:
    *ppiVar1 = unaff_RSI;
    ppiVar1[1] = unaff_RSI + uVar7 * 5;
    ppiVar1[2] = unaff_RSI + uVar9 * 5;
    return;
}

// ============================================================
// Function: FUN_1800c6839
// Address: 0x1800c6839
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_37h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800c6520(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_90h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    undefined *puVar8;
    int64_t *unaff_RSI;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_78 [8];
    undefined auStack_70 [32];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    undefined4 var_37h;
    int64_t var_33h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    ppiVar1 = *(int64_t ***)(arg1 + 0xa8);
    if (ppiVar1 == (int64_t **)0x0) {
        return;
    }
    if (arg4 == 0) {
        if ((*(int64_t *)(arg2 + 0x10) != 0) && (arg3 != *(int64_t *)(arg2 + 0x18))) {
            uVar9 = *(int64_t *)(arg2 + 8) - 1;
            uVar5 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            uVar7 = 0;
            do {
                uVar5 = uVar5 & uVar9;
                piVar11 = (int64_t *)(uVar5 * 0x20 + *(int64_t *)arg2);
                iVar10 = *piVar11;
                if (iVar10 == arg3) {
                    arg4 = (int64_t)(piVar11 + 1);
                    goto code_r0x0001800c65ab;
                }
                if (iVar10 == *(int64_t *)(arg2 + 0x18)) break;
                uVar5 = uVar5 + 1 + uVar7;
                uVar7 = uVar7 + 1;
            } while (uVar7 <= uVar9);
        }
        arg4 = 0;
code_r0x0001800c65ab:
        if ((int64_t *)arg4 != (int64_t *)0x0) goto code_r0x0001800c65b0;
        var_50h._0_4_ = 0;
        var_50h._4_4_ = 0;
        var_40h = 0;
        var_48h = 0;
    } else {
code_r0x0001800c65b0:
        var_50h._0_4_ = *(undefined4 *)arg4;
        var_50h._4_4_ = *(undefined4 *)(arg4 + 4);
        var_48h = *(int64_t *)(arg4 + 8);
        var_40h = *(int64_t *)(arg4 + 0x10);
    }
    piVar11 = ppiVar1[1];
    if (piVar11 != ppiVar1[2]) {
        var_48h._4_4_ = (undefined4)((uint64_t)var_48h >> 0x20);
        *(undefined4 *)((int64_t)piVar11 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar11 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar11 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar11 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar11 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar11 + 0x27) = var_33h._2_1_;
        *piVar11 = arg3;
        piVar11[3] = var_40h;
        *(bool *)(piVar11 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        ppiVar1[1] = ppiVar1[1] + 5;
        return;
    }
    iVar10 = ((int64_t)piVar11 - (int64_t)*ppiVar1) / 0x28;
    if (iVar10 == 0x666666666666666) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = ((int64_t)ppiVar1[2] - (int64_t)*ppiVar1 >> 3) * -0x3333333333333333;
    uVar7 = 0x666666666666666 - (uVar5 >> 1);
    if (uVar7 <= uVar5 && uVar5 - uVar7 != 0) {
code_r0x0001800c683f:
        func_0x000180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (uVar5 >> 1) + uVar5;
    uVar7 = iVar10 + 1;
    uVar9 = uVar7;
    if (uVar7 <= uVar5) {
        uVar9 = uVar5;
    }
    if (0x666666666666666 < uVar9) goto code_r0x0001800c683f;
    uVar5 = uVar9 * 0x28;
    if (uVar5 == 0) {
        unaff_RSI = (int64_t *)0x0;
code_r0x0001800c6723:
        piVar6 = unaff_RSI + iVar10 * 5;
        *(undefined4 *)((int64_t)piVar6 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar6 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar6 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar6 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar6 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar6 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar6 + 0x27) = var_33h._2_1_;
        *piVar6 = arg3;
        piVar6[3] = var_40h;
        *(bool *)(piVar6 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        piVar2 = *ppiVar1;
        if (piVar11 == ppiVar1[1]) {
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar2;
            piVar6 = unaff_RSI;
            piVar11 = piVar2;
        } else {
            func_0x000180498030(unaff_RSI, piVar2, (int64_t)piVar11 - (int64_t)piVar2);
            piVar6 = piVar6 + 5;
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar11;
        }
        func_0x000180498030(piVar6, piVar11, iVar10);
        piVar11 = *ppiVar1;
        if (piVar11 == (int64_t *)0x0) goto code_r0x0001800c67f4;
        piVar6 = piVar11;
        puVar8 = auStack_78;
        if ((0xfff < (uint64_t)(((int64_t)ppiVar1[2] - (int64_t)piVar11 >> 3) * 8)) &&
           (piVar6 = (int64_t *)piVar11[-1], puVar8 = auStack_78,
           0x1f < (uint64_t)((int64_t)piVar11 + (-8 - (int64_t)piVar6)))) goto code_r0x0001800c67e2;
    } else {
        if (uVar5 < 0x1000) {
            unaff_RSI = (int64_t *)func_0x000180459890(uVar5);
            goto code_r0x0001800c6723;
        }
        if (uVar5 + 0x27 <= uVar5) goto code_r0x0001800c683f;
        iVar4 = func_0x000180459890();
        if (iVar4 != 0) {
            unaff_RSI = (int64_t *)(iVar4 + 0x27U & 0xffffffffffffffe0);
            unaff_RSI[-1] = iVar4;
            goto code_r0x0001800c6723;
        }
code_r0x0001800c67e2:
        piVar6 = (int64_t *)0x5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar8 = auStack_70;
    }
    *(undefined8 *)(puVar8 + -8) = 0x1800c67f4;
    func_0x000180459c3c(piVar6);
code_r0x0001800c67f4:
    *ppiVar1 = unaff_RSI;
    ppiVar1[1] = unaff_RSI + uVar7 * 5;
    ppiVar1[2] = unaff_RSI + uVar9 * 5;
    return;
}

// ============================================================
// Function: FUN_1800c683f
// Address: 0x1800c683f
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_37h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800c6520(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_90h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    undefined *puVar8;
    int64_t *unaff_RSI;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_78 [8];
    undefined auStack_70 [32];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    undefined4 var_37h;
    int64_t var_33h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    ppiVar1 = *(int64_t ***)(arg1 + 0xa8);
    if (ppiVar1 == (int64_t **)0x0) {
        return;
    }
    if (arg4 == 0) {
        if ((*(int64_t *)(arg2 + 0x10) != 0) && (arg3 != *(int64_t *)(arg2 + 0x18))) {
            uVar9 = *(int64_t *)(arg2 + 8) - 1;
            uVar5 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            uVar7 = 0;
            do {
                uVar5 = uVar5 & uVar9;
                piVar11 = (int64_t *)(uVar5 * 0x20 + *(int64_t *)arg2);
                iVar10 = *piVar11;
                if (iVar10 == arg3) {
                    arg4 = (int64_t)(piVar11 + 1);
                    goto code_r0x0001800c65ab;
                }
                if (iVar10 == *(int64_t *)(arg2 + 0x18)) break;
                uVar5 = uVar5 + 1 + uVar7;
                uVar7 = uVar7 + 1;
            } while (uVar7 <= uVar9);
        }
        arg4 = 0;
code_r0x0001800c65ab:
        if ((int64_t *)arg4 != (int64_t *)0x0) goto code_r0x0001800c65b0;
        var_50h._0_4_ = 0;
        var_50h._4_4_ = 0;
        var_40h = 0;
        var_48h = 0;
    } else {
code_r0x0001800c65b0:
        var_50h._0_4_ = *(undefined4 *)arg4;
        var_50h._4_4_ = *(undefined4 *)(arg4 + 4);
        var_48h = *(int64_t *)(arg4 + 8);
        var_40h = *(int64_t *)(arg4 + 0x10);
    }
    piVar11 = ppiVar1[1];
    if (piVar11 != ppiVar1[2]) {
        var_48h._4_4_ = (undefined4)((uint64_t)var_48h >> 0x20);
        *(undefined4 *)((int64_t)piVar11 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar11 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar11 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar11 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar11 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar11 + 0x27) = var_33h._2_1_;
        *piVar11 = arg3;
        piVar11[3] = var_40h;
        *(bool *)(piVar11 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        ppiVar1[1] = ppiVar1[1] + 5;
        return;
    }
    iVar10 = ((int64_t)piVar11 - (int64_t)*ppiVar1) / 0x28;
    if (iVar10 == 0x666666666666666) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = ((int64_t)ppiVar1[2] - (int64_t)*ppiVar1 >> 3) * -0x3333333333333333;
    uVar7 = 0x666666666666666 - (uVar5 >> 1);
    if (uVar7 <= uVar5 && uVar5 - uVar7 != 0) {
code_r0x0001800c683f:
        func_0x000180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (uVar5 >> 1) + uVar5;
    uVar7 = iVar10 + 1;
    uVar9 = uVar7;
    if (uVar7 <= uVar5) {
        uVar9 = uVar5;
    }
    if (0x666666666666666 < uVar9) goto code_r0x0001800c683f;
    uVar5 = uVar9 * 0x28;
    if (uVar5 == 0) {
        unaff_RSI = (int64_t *)0x0;
code_r0x0001800c6723:
        piVar6 = unaff_RSI + iVar10 * 5;
        *(undefined4 *)((int64_t)piVar6 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar6 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar6 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar6 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar6 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar6 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar6 + 0x27) = var_33h._2_1_;
        *piVar6 = arg3;
        piVar6[3] = var_40h;
        *(bool *)(piVar6 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        piVar2 = *ppiVar1;
        if (piVar11 == ppiVar1[1]) {
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar2;
            piVar6 = unaff_RSI;
            piVar11 = piVar2;
        } else {
            func_0x000180498030(unaff_RSI, piVar2, (int64_t)piVar11 - (int64_t)piVar2);
            piVar6 = piVar6 + 5;
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar11;
        }
        func_0x000180498030(piVar6, piVar11, iVar10);
        piVar11 = *ppiVar1;
        if (piVar11 == (int64_t *)0x0) goto code_r0x0001800c67f4;
        piVar6 = piVar11;
        puVar8 = auStack_78;
        if ((0xfff < (uint64_t)(((int64_t)ppiVar1[2] - (int64_t)piVar11 >> 3) * 8)) &&
           (piVar6 = (int64_t *)piVar11[-1], puVar8 = auStack_78,
           0x1f < (uint64_t)((int64_t)piVar11 + (-8 - (int64_t)piVar6)))) goto code_r0x0001800c67e2;
    } else {
        if (uVar5 < 0x1000) {
            unaff_RSI = (int64_t *)func_0x000180459890(uVar5);
            goto code_r0x0001800c6723;
        }
        if (uVar5 + 0x27 <= uVar5) goto code_r0x0001800c683f;
        iVar4 = func_0x000180459890();
        if (iVar4 != 0) {
            unaff_RSI = (int64_t *)(iVar4 + 0x27U & 0xffffffffffffffe0);
            unaff_RSI[-1] = iVar4;
            goto code_r0x0001800c6723;
        }
code_r0x0001800c67e2:
        piVar6 = (int64_t *)0x5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar8 = auStack_70;
    }
    *(undefined8 *)(puVar8 + -8) = 0x1800c67f4;
    func_0x000180459c3c(piVar6);
code_r0x0001800c67f4:
    *ppiVar1 = unaff_RSI;
    ppiVar1[1] = unaff_RSI + uVar7 * 5;
    ppiVar1[2] = unaff_RSI + uVar9 * 5;
    return;
}

// ============================================================
// Function: FUN_1800c6850
// Address: 0x1800c6850
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_37h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800c6850(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_90h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    undefined *puVar8;
    int64_t *unaff_RSI;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_78 [8];
    undefined auStack_70 [32];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    undefined4 var_37h;
    int64_t var_33h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    ppiVar1 = *(int64_t ***)(arg1 + 0xb0);
    if (ppiVar1 == (int64_t **)0x0) {
        return;
    }
    if (arg4 == 0) {
        if ((*(int64_t *)(arg2 + 0x10) != 0) && (arg3 != *(int64_t *)(arg2 + 0x18))) {
            uVar9 = *(int64_t *)(arg2 + 8) - 1;
            uVar5 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            uVar7 = 0;
            do {
                uVar5 = uVar5 & uVar9;
                piVar11 = (int64_t *)(uVar5 * 0x20 + *(int64_t *)arg2);
                iVar10 = *piVar11;
                if (iVar10 == arg3) {
                    arg4 = (int64_t)(piVar11 + 1);
                    goto code_r0x0001800c68db;
                }
                if (iVar10 == *(int64_t *)(arg2 + 0x18)) break;
                uVar5 = uVar5 + 1 + uVar7;
                uVar7 = uVar7 + 1;
            } while (uVar7 <= uVar9);
        }
        arg4 = 0;
code_r0x0001800c68db:
        if ((int64_t *)arg4 != (int64_t *)0x0) goto code_r0x0001800c68e0;
        var_50h._0_4_ = 0;
        var_50h._4_4_ = 0;
        var_40h = 0;
        var_48h = 0;
    } else {
code_r0x0001800c68e0:
        var_50h._0_4_ = *(undefined4 *)arg4;
        var_50h._4_4_ = *(undefined4 *)(arg4 + 4);
        var_48h = *(int64_t *)(arg4 + 8);
        var_40h = *(int64_t *)(arg4 + 0x10);
    }
    piVar11 = ppiVar1[1];
    if (piVar11 != ppiVar1[2]) {
        var_48h._4_4_ = (undefined4)((uint64_t)var_48h >> 0x20);
        *(undefined4 *)((int64_t)piVar11 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar11 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar11 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar11 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar11 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar11 + 0x27) = var_33h._2_1_;
        *piVar11 = arg3;
        piVar11[3] = var_40h;
        *(bool *)(piVar11 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        ppiVar1[1] = ppiVar1[1] + 5;
        return;
    }
    iVar10 = ((int64_t)piVar11 - (int64_t)*ppiVar1) / 0x28;
    if (iVar10 == 0x666666666666666) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = ((int64_t)ppiVar1[2] - (int64_t)*ppiVar1 >> 3) * -0x3333333333333333;
    uVar7 = 0x666666666666666 - (uVar5 >> 1);
    if (uVar7 <= uVar5 && uVar5 - uVar7 != 0) {
code_r0x0001800c6b6f:
        func_0x000180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (uVar5 >> 1) + uVar5;
    uVar7 = iVar10 + 1;
    uVar9 = uVar7;
    if (uVar7 <= uVar5) {
        uVar9 = uVar5;
    }
    if (0x666666666666666 < uVar9) goto code_r0x0001800c6b6f;
    uVar5 = uVar9 * 0x28;
    if (uVar5 == 0) {
        unaff_RSI = (int64_t *)0x0;
code_r0x0001800c6a53:
        piVar6 = unaff_RSI + iVar10 * 5;
        *(undefined4 *)((int64_t)piVar6 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar6 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar6 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar6 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar6 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar6 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar6 + 0x27) = var_33h._2_1_;
        *piVar6 = arg3;
        piVar6[3] = var_40h;
        *(bool *)(piVar6 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        piVar2 = *ppiVar1;
        if (piVar11 == ppiVar1[1]) {
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar2;
            piVar6 = unaff_RSI;
            piVar11 = piVar2;
        } else {
            func_0x000180498030(unaff_RSI, piVar2, (int64_t)piVar11 - (int64_t)piVar2);
            piVar6 = piVar6 + 5;
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar11;
        }
        func_0x000180498030(piVar6, piVar11, iVar10);
        piVar11 = *ppiVar1;
        if (piVar11 == (int64_t *)0x0) goto code_r0x0001800c6b24;
        piVar6 = piVar11;
        puVar8 = auStack_78;
        if ((0xfff < (uint64_t)(((int64_t)ppiVar1[2] - (int64_t)piVar11 >> 3) * 8)) &&
           (piVar6 = (int64_t *)piVar11[-1], puVar8 = auStack_78,
           0x1f < (uint64_t)((int64_t)piVar11 + (-8 - (int64_t)piVar6)))) goto code_r0x0001800c6b12;
    } else {
        if (uVar5 < 0x1000) {
            unaff_RSI = (int64_t *)func_0x000180459890(uVar5);
            goto code_r0x0001800c6a53;
        }
        if (uVar5 + 0x27 <= uVar5) goto code_r0x0001800c6b6f;
        iVar4 = func_0x000180459890();
        if (iVar4 != 0) {
            unaff_RSI = (int64_t *)(iVar4 + 0x27U & 0xffffffffffffffe0);
            unaff_RSI[-1] = iVar4;
            goto code_r0x0001800c6a53;
        }
code_r0x0001800c6b12:
        piVar6 = (int64_t *)0x5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar8 = auStack_70;
    }
    *(undefined8 *)(puVar8 + -8) = 0x1800c6b24;
    func_0x000180459c3c(piVar6);
code_r0x0001800c6b24:
    *ppiVar1 = unaff_RSI;
    ppiVar1[1] = unaff_RSI + uVar7 * 5;
    ppiVar1[2] = unaff_RSI + uVar9 * 5;
    return;
}

// ============================================================
// Function: FUN_1800c686d
// Address: 0x1800c686d
// Size: 257 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_37h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800c6850(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_90h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    undefined *puVar8;
    int64_t *unaff_RSI;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_78 [8];
    undefined auStack_70 [32];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    undefined4 var_37h;
    int64_t var_33h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    ppiVar1 = *(int64_t ***)(arg1 + 0xb0);
    if (ppiVar1 == (int64_t **)0x0) {
        return;
    }
    if (arg4 == 0) {
        if ((*(int64_t *)(arg2 + 0x10) != 0) && (arg3 != *(int64_t *)(arg2 + 0x18))) {
            uVar9 = *(int64_t *)(arg2 + 8) - 1;
            uVar5 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            uVar7 = 0;
            do {
                uVar5 = uVar5 & uVar9;
                piVar11 = (int64_t *)(uVar5 * 0x20 + *(int64_t *)arg2);
                iVar10 = *piVar11;
                if (iVar10 == arg3) {
                    arg4 = (int64_t)(piVar11 + 1);
                    goto code_r0x0001800c68db;
                }
                if (iVar10 == *(int64_t *)(arg2 + 0x18)) break;
                uVar5 = uVar5 + 1 + uVar7;
                uVar7 = uVar7 + 1;
            } while (uVar7 <= uVar9);
        }
        arg4 = 0;
code_r0x0001800c68db:
        if ((int64_t *)arg4 != (int64_t *)0x0) goto code_r0x0001800c68e0;
        var_50h._0_4_ = 0;
        var_50h._4_4_ = 0;
        var_40h = 0;
        var_48h = 0;
    } else {
code_r0x0001800c68e0:
        var_50h._0_4_ = *(undefined4 *)arg4;
        var_50h._4_4_ = *(undefined4 *)(arg4 + 4);
        var_48h = *(int64_t *)(arg4 + 8);
        var_40h = *(int64_t *)(arg4 + 0x10);
    }
    piVar11 = ppiVar1[1];
    if (piVar11 != ppiVar1[2]) {
        var_48h._4_4_ = (undefined4)((uint64_t)var_48h >> 0x20);
        *(undefined4 *)((int64_t)piVar11 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar11 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar11 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar11 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar11 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar11 + 0x27) = var_33h._2_1_;
        *piVar11 = arg3;
        piVar11[3] = var_40h;
        *(bool *)(piVar11 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        ppiVar1[1] = ppiVar1[1] + 5;
        return;
    }
    iVar10 = ((int64_t)piVar11 - (int64_t)*ppiVar1) / 0x28;
    if (iVar10 == 0x666666666666666) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = ((int64_t)ppiVar1[2] - (int64_t)*ppiVar1 >> 3) * -0x3333333333333333;
    uVar7 = 0x666666666666666 - (uVar5 >> 1);
    if (uVar7 <= uVar5 && uVar5 - uVar7 != 0) {
code_r0x0001800c6b6f:
        func_0x000180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (uVar5 >> 1) + uVar5;
    uVar7 = iVar10 + 1;
    uVar9 = uVar7;
    if (uVar7 <= uVar5) {
        uVar9 = uVar5;
    }
    if (0x666666666666666 < uVar9) goto code_r0x0001800c6b6f;
    uVar5 = uVar9 * 0x28;
    if (uVar5 == 0) {
        unaff_RSI = (int64_t *)0x0;
code_r0x0001800c6a53:
        piVar6 = unaff_RSI + iVar10 * 5;
        *(undefined4 *)((int64_t)piVar6 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar6 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar6 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar6 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar6 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar6 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar6 + 0x27) = var_33h._2_1_;
        *piVar6 = arg3;
        piVar6[3] = var_40h;
        *(bool *)(piVar6 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        piVar2 = *ppiVar1;
        if (piVar11 == ppiVar1[1]) {
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar2;
            piVar6 = unaff_RSI;
            piVar11 = piVar2;
        } else {
            func_0x000180498030(unaff_RSI, piVar2, (int64_t)piVar11 - (int64_t)piVar2);
            piVar6 = piVar6 + 5;
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar11;
        }
        func_0x000180498030(piVar6, piVar11, iVar10);
        piVar11 = *ppiVar1;
        if (piVar11 == (int64_t *)0x0) goto code_r0x0001800c6b24;
        piVar6 = piVar11;
        puVar8 = auStack_78;
        if ((0xfff < (uint64_t)(((int64_t)ppiVar1[2] - (int64_t)piVar11 >> 3) * 8)) &&
           (piVar6 = (int64_t *)piVar11[-1], puVar8 = auStack_78,
           0x1f < (uint64_t)((int64_t)piVar11 + (-8 - (int64_t)piVar6)))) goto code_r0x0001800c6b12;
    } else {
        if (uVar5 < 0x1000) {
            unaff_RSI = (int64_t *)func_0x000180459890(uVar5);
            goto code_r0x0001800c6a53;
        }
        if (uVar5 + 0x27 <= uVar5) goto code_r0x0001800c6b6f;
        iVar4 = func_0x000180459890();
        if (iVar4 != 0) {
            unaff_RSI = (int64_t *)(iVar4 + 0x27U & 0xffffffffffffffe0);
            unaff_RSI[-1] = iVar4;
            goto code_r0x0001800c6a53;
        }
code_r0x0001800c6b12:
        piVar6 = (int64_t *)0x5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar8 = auStack_70;
    }
    *(undefined8 *)(puVar8 + -8) = 0x1800c6b24;
    func_0x000180459c3c(piVar6);
code_r0x0001800c6b24:
    *ppiVar1 = unaff_RSI;
    ppiVar1[1] = unaff_RSI + uVar7 * 5;
    ppiVar1[2] = unaff_RSI + uVar9 * 5;
    return;
}

// ============================================================
// Function: FUN_1800c696e
// Address: 0x1800c696e
// Size: 487 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_37h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800c6850(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_90h)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    undefined *puVar8;
    int64_t *unaff_RSI;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_78 [8];
    undefined auStack_70 [32];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    undefined4 var_37h;
    int64_t var_33h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    ppiVar1 = *(int64_t ***)(arg1 + 0xb0);
    if (ppiVar1 == (int64_t **)0x0) {
        return;
    }
    if (arg4 == 0) {
        if ((*(int64_t *)(arg2 + 0x10) != 0) && (arg3 != *(int64_t *)(arg2 + 0x18))) {
            uVar9 = *(int64_t *)(arg2 + 8) - 1;
            uVar5 = ((uint64_t)arg3 >> 5 ^ arg3) >> 4;
            uVar7 = 0;
            do {
                uVar5 = uVar5 & uVar9;
                piVar11 = (int64_t *)(uVar5 * 0x20 + *(int64_t *)arg2);
                iVar10 = *piVar11;
                if (iVar10 == arg3) {
                    arg4 = (int64_t)(piVar11 + 1);
                    goto code_r0x0001800c68db;
                }
                if (iVar10 == *(int64_t *)(arg2 + 0x18)) break;
                uVar5 = uVar5 + 1 + uVar7;
                uVar7 = uVar7 + 1;
            } while (uVar7 <= uVar9);
        }
        arg4 = 0;
code_r0x0001800c68db:
        if ((int64_t *)arg4 != (int64_t *)0x0) goto code_r0x0001800c68e0;
        var_50h._0_4_ = 0;
        var_50h._4_4_ = 0;
        var_40h = 0;
        var_48h = 0;
    } else {
code_r0x0001800c68e0:
        var_50h._0_4_ = *(undefined4 *)arg4;
        var_50h._4_4_ = *(undefined4 *)(arg4 + 4);
        var_48h = *(int64_t *)(arg4 + 8);
        var_40h = *(int64_t *)(arg4 + 0x10);
    }
    piVar11 = ppiVar1[1];
    if (piVar11 != ppiVar1[2]) {
        var_48h._4_4_ = (undefined4)((uint64_t)var_48h >> 0x20);
        *(undefined4 *)((int64_t)piVar11 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar11 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar11 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar11 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar11 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar11 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar11 + 0x27) = var_33h._2_1_;
        *piVar11 = arg3;
        piVar11[3] = var_40h;
        *(bool *)(piVar11 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        ppiVar1[1] = ppiVar1[1] + 5;
        return;
    }
    iVar10 = ((int64_t)piVar11 - (int64_t)*ppiVar1) / 0x28;
    if (iVar10 == 0x666666666666666) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = ((int64_t)ppiVar1[2] - (int64_t)*ppiVar1 >> 3) * -0x3333333333333333;
    uVar7 = 0x666666666666666 - (uVar5 >> 1);
    if (uVar7 <= uVar5 && uVar5 - uVar7 != 0) {
code_r0x0001800c6b6f:
        func_0x000180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (uVar5 >> 1) + uVar5;
    uVar7 = iVar10 + 1;
    uVar9 = uVar7;
    if (uVar7 <= uVar5) {
        uVar9 = uVar5;
    }
    if (0x666666666666666 < uVar9) goto code_r0x0001800c6b6f;
    uVar5 = uVar9 * 0x28;
    if (uVar5 == 0) {
        unaff_RSI = (int64_t *)0x0;
code_r0x0001800c6a53:
        piVar6 = unaff_RSI + iVar10 * 5;
        *(undefined4 *)((int64_t)piVar6 + 0x21) = var_37h;
        *(undefined2 *)((int64_t)piVar6 + 0x25) = (undefined2)var_33h;
        *(undefined4 *)(piVar6 + 1) = (undefined4)var_50h;
        *(undefined4 *)((int64_t)piVar6 + 0xc) = var_50h._4_4_;
        *(undefined4 *)(piVar6 + 2) = (undefined4)var_48h;
        *(undefined4 *)((int64_t)piVar6 + 0x14) = var_48h._4_4_;
        *(undefined *)((int64_t)piVar6 + 0x27) = var_33h._2_1_;
        *piVar6 = arg3;
        piVar6[3] = var_40h;
        *(bool *)(piVar6 + 4) = (int64_t *)arg4 == (int64_t *)0x0;
        piVar2 = *ppiVar1;
        if (piVar11 == ppiVar1[1]) {
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar2;
            piVar6 = unaff_RSI;
            piVar11 = piVar2;
        } else {
            func_0x000180498030(unaff_RSI, piVar2, (int64_t)piVar11 - (int64_t)piVar2);
            piVar6 = piVar6 + 5;
            iVar10 = (int64_t)ppiVar1[1] - (int64_t)piVar11;
        }
        func_0x000180498030(piVar6, piVar11, iVar10);
        piVar11 = *ppiVar1;
        if (piVar11 == (int64_t *)0x0) goto code_r0x0001800c6b24;
        piVar6 = piVar11;
        puVar8 = auStack_78;
        if ((0xfff < (uint64_t)(((int64_t)ppiVar1[2] - (int64_t)piVar11 >> 3) * 8)) &&
           (piVar6 = (int64_t *)piVar11[-1], puVar8 = auStack_78,
           0x1f < (uint64_t)((int64_t)piVar11 + (-8 - (int64_t)piVar6)))) goto code_r0x0001800c6b12;
    } else {
        if (uVar5 < 0x1000) {
            unaff_RSI = (int64_t *)func_0x000180459890(uVar5);
            goto code_r0x0001800c6a53;
        }
        if (uVar5 + 0x27 <= uVar5) goto code_r0x0001800c6b6f;
        iVar4 = func_0x000180459890();
        if (iVar4 != 0) {
            unaff_RSI = (int64_t *)(iVar4 + 0x27U & 0xffffffffffffffe0);
            unaff_RSI[-1] = iVar4;
            goto code_r0x0001800c6a53;
        }
code_r0x0001800c6b12:
        piVar6 = (int64_t *)0x5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar8 = auStack_70;
    }
    *(undefined8 *)(puVar8 + -8) = 0x1800c6b24;
    func_0x000180459c3c(piVar6);
code_r0x0001800c6b24:
    *ppiVar1 = unaff_RSI;
    ppiVar1[1] = unaff_RSI + uVar7 * 5;
    ppiVar1[2] = unaff_RSI + uVar9 * 5;
    return;
}

