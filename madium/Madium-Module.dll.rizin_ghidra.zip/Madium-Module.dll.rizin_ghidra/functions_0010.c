// Chunk 10 - 50 functions

// ============================================================
// Function: FUN_1800183a0
// Address: 0x1800183a0
// Size: 184 bytes
// ============================================================
void fcn.1800183a0(int64_t arg_50h, int64_t arg_58h)
{
    return;
}

// ============================================================
// Function: FUN_180018458
// Address: 0x180018458
// Size: 12 bytes
// ============================================================
void fcn.180018458(void)
{
    code *pcVar1;
    
    fcn.180004720();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180018470
// Address: 0x180018470
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180018470(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x98) {
            func_0x0001800178f0(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180018505;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180018489
// Address: 0x180018489
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180018470(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x98) {
            func_0x0001800178f0(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180018505;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800184dc
// Address: 0x1800184dc
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180018470(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x98) {
            func_0x0001800178f0(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180018505;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180018520
// Address: 0x180018520
// Size: 706 bytes
// ============================================================
int64_t fcn.180018520(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 *puVar5;
    int64_t *piVar6;
    undefined8 *puVar7;
    undefined *puVar8;
    int64_t iVar9;
    uint64_t uVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    uint64_t uVar13;
    int64_t var_8h;
    undefined auStack_88 [8];
    undefined auStack_80 [24];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar8 = auStack_88;
    if (arg1 != arg2) {
        iVar3 = arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            iVar3 = *(int64_t *)arg2;
        }
        func_0x00018000f180(arg1, iVar3, *(undefined8 *)(arg2 + 0x10));
    }
    piVar6 = (int64_t *)(arg1 + 0x20);
    if (piVar6 != (int64_t *)(arg2 + 0x20)) {
        puVar7 = *(undefined8 **)(int64_t *)(arg2 + 0x20);
        iVar9 = *(int64_t *)(arg2 + 0x28) - (int64_t)puVar7 >> 3;
        uVar10 = iVar9 * -0x79435e50d79435e5;
        puVar12 = (undefined8 *)*piVar6;
        iVar3 = *(int64_t *)(arg1 + 0x30) - (int64_t)puVar12 >> 3;
        uVar4 = iVar3 * -0x79435e50d79435e5;
        if (uVar10 < uVar4 || uVar10 + iVar3 * 0x79435e50d79435e5 == 0) {
            puVar11 = *(undefined8 **)(arg1 + 0x28);
            iVar3 = (int64_t)puVar11 - (int64_t)puVar12 >> 3;
            if (uVar10 < (uint64_t)(iVar3 * -0x79435e50d79435e5) || uVar10 + iVar3 * 0x79435e50d79435e5 == 0) {
                puVar11 = puVar12 + iVar9;
                for (; uVar10 != 0; uVar10 = uVar10 - 1) {
                    if (puVar12 != puVar7) {
                        puVar5 = puVar7;
                        if (0xf < (uint64_t)puVar7[3]) {
                            puVar5 = (undefined8 *)*puVar7;
                        }
                        func_0x00018000f180(puVar12, puVar5, puVar7[2]);
                    }
                    piVar6 = puVar7 + 4;
                    if (puVar12 + 4 != piVar6) {
                        if (0xf < (uint64_t)puVar7[7]) {
                            piVar6 = (int64_t *)*piVar6;
                        }
                        func_0x00018000f180(puVar12 + 4, piVar6, puVar7[6]);
                    }
                    func_0x000180016c50(puVar12 + 8, puVar7 + 8);
                    func_0x000180016c50(puVar12 + 0xd, puVar7 + 0xd);
                    *(undefined4 *)(puVar12 + 0x12) = *(undefined4 *)(puVar7 + 0x12);
                    puVar12 = puVar12 + 0x13;
                    puVar7 = puVar7 + 0x13;
                }
                puVar7 = *(undefined8 **)(arg1 + 0x28);
                for (puVar12 = puVar11; puVar12 != puVar7; puVar12 = puVar12 + 0x13) {
                    func_0x0001800178f0(puVar12);
                }
            } else {
                if (puVar12 != puVar11) {
                    do {
                        func_0x000180018a80(puVar12, puVar7);
                        puVar12 = puVar12 + 0x13;
                        puVar7 = puVar7 + 0x13;
                        puVar11 = *(undefined8 **)(arg1 + 0x28);
                    } while (puVar12 != puVar11);
                }
                var_58h = (int64_t)piVar6;
                var_68h = (int64_t)puVar11;
                for (iVar3 = uVar10 + iVar3 * 0x79435e50d79435e5; iVar3 != 0; iVar3 = iVar3 + -1) {
                    var_60h = (int64_t)puVar11;
                    func_0x000180018b70(puVar11, puVar7);
                    puVar11 = puVar11 + 0x13;
                    puVar7 = puVar7 + 0x13;
                }
            }
            *(undefined8 **)(arg1 + 0x28) = puVar11;
        } else {
            if (0x1af286bca1af286 < uVar10) {
                func_0x000180010010();
                pcVar1 = (code *)swi(3);
                iVar3 = (*pcVar1)();
                return iVar3;
            }
            uVar2 = 0x1af286bca1af286 - (uVar4 >> 1);
            uVar13 = 0x1af286bca1af286;
            if ((uVar4 < uVar2 || uVar4 - uVar2 == 0) && (uVar13 = uVar4 + (uVar4 >> 1), uVar13 < uVar10)) {
                uVar13 = uVar10;
            }
            if (puVar12 != (undefined8 *)0x0) {
                puVar11 = *(undefined8 **)(arg1 + 0x28);
                for (; puVar12 != puVar11; puVar12 = puVar12 + 0x13) {
                    func_0x0001800178f0(puVar12);
                }
                iVar3 = *piVar6;
                iVar9 = iVar3;
                puVar8 = auStack_88;
                if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x30) - iVar3 >> 3) * 8)) &&
                   (iVar9 = *(int64_t *)(iVar3 + -8), puVar8 = auStack_88, 0x1f < (iVar3 - iVar9) - 8U)) {
                    iVar9 = 5;
                    pcVar1 = (code *)swi(0x29);
                    (*pcVar1)(5);
                    puVar8 = auStack_80;
                }
                *(undefined8 *)(puVar8 + -8) = 0x180018634;
                func_0x000180459c3c(iVar9);
                *piVar6 = 0;
                *(undefined8 *)(arg1 + 0x28) = 0;
                *(undefined8 *)(arg1 + 0x30) = 0;
            }
            *(undefined8 *)(puVar8 + -8) = 0x18001864c;
            func_0x0001800189f0(piVar6, uVar13);
            iVar3 = *piVar6;
            *(int64_t *)(puVar8 + 0x20) = iVar3;
            *(int64_t *)(puVar8 + 0x28) = iVar3;
            *(int64_t **)(puVar8 + 0x30) = piVar6;
            for (; uVar10 != 0; uVar10 = uVar10 - 1) {
                *(undefined8 *)(puVar8 + -8) = 0x18001866e;
                func_0x000180018b70(iVar3, puVar7);
                iVar3 = iVar3 + 0x98;
                *(int64_t *)(puVar8 + 0x28) = iVar3;
                puVar7 = puVar7 + 0x13;
            }
            *(int64_t *)(arg1 + 0x28) = iVar3;
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800187f0
// Address: 0x1800187f0
// Size: 307 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800187f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    if (arg2 != 0) {
        do {
            func_0x00018000b4d0(arg3, arg1);
            piVar1 = (int64_t *)(arg3 + 0x20);
            *piVar1 = 0;
            *(undefined8 *)(arg3 + 0x28) = 0;
            *(undefined8 *)(arg3 + 0x30) = 0;
            uVar4 = (*(int64_t *)(arg1 + 0x28) - *(int64_t *)(arg1 + 0x20) >> 3) * -0x79435e50d79435e5;
            if (uVar4 != 0) {
                if (0x1af286bca1af286 < uVar4) {
                    func_0x000180010010();
                    pcVar3 = (code *)swi(3);
                    iVar5 = (*pcVar3)();
                    return iVar5;
                }
                func_0x0001800189f0(piVar1);
                iVar5 = *piVar1;
                iVar2 = *(int64_t *)(arg1 + 0x28);
                for (iVar6 = *(int64_t *)(arg1 + 0x20); iVar6 != iVar2; iVar6 = iVar6 + 0x98) {
                    func_0x000180018b70(iVar5, iVar6);
                    iVar5 = iVar5 + 0x98;
                }
                *(int64_t *)(arg3 + 0x28) = iVar5;
            }
            arg3 = arg3 + 0x38;
            arg1 = arg1 + 0x38;
            arg2 = arg2 + -1;
        } while (arg2 != 0);
    }
    return arg3;
}

// ============================================================
// Function: FUN_180018940
// Address: 0x180018940
// Size: 42 bytes
// ============================================================
int64_t fcn.180018940(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    
    if (arg1 != arg2) {
        puVar1 = (undefined8 *)(arg2 + 0x10);
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            arg2 = *(int64_t *)arg2;
        }
        fcn.18000f180(arg1, arg2, *puVar1);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180018970
// Address: 0x180018970
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180018970(int64_t arg1)
{
    int64_t iVar1;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    for (arg1 = *(int64_t *)arg1; arg1 != iVar1; arg1 = arg1 + 0x98) {
        func_0x0001800178f0(arg1);
    }
    return;
}

// ============================================================
// Function: FUN_1800189b0
// Address: 0x1800189b0
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800189b0(int64_t arg1)
{
    int64_t iVar1;
    int64_t unaff_RBX;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    for (arg1 = *(int64_t *)arg1; arg1 != iVar1; arg1 = arg1 + 0x38) {
        fcn.180018470(arg1 + 0x20, unaff_RBX);
        func_0x000180004e40(arg1);
    }
    return;
}

// ============================================================
// Function: FUN_1800189f0
// Address: 0x1800189f0
// Size: 135 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800189f0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    if ((uint64_t)arg2 < 0x1af286bca1af287) {
        uVar5 = arg2 * 0x98;
        if (uVar5 == 0) {
            uVar3 = 0;
        } else if (uVar5 < 0x1000) {
            uVar3 = func_0x000180459890(uVar5);
        } else {
            if (uVar5 + 0x27 <= uVar5) goto code_r0x000180018a71;
            iVar2 = func_0x000180459890();
            iVar4 = iVar2;
            if (iVar2 == 0) {
                iVar4 = 5;
                pcVar1 = (code *)swi(0x29);
                iVar2 = (*pcVar1)();
            }
            uVar3 = iVar2 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar3 - 8) = iVar4;
        }
        *(uint64_t *)arg1 = uVar3;
        *(uint64_t *)(arg1 + 8) = uVar3;
        *(uint64_t *)(arg1 + 0x10) = uVar3 + uVar5;
        return;
    }
code_r0x000180018a71:
    fcn.180004720();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180018a80
// Address: 0x180018a80
// Size: 124 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180018a80(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t var_8h;
    
    if (arg1 != arg2) {
        iVar1 = arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            iVar1 = *(int64_t *)arg2;
        }
        fcn.18000f180(arg1, iVar1, *(undefined8 *)(arg2 + 0x10));
    }
    piVar2 = (int64_t *)(arg2 + 0x20);
    if ((int64_t *)(arg1 + 0x20) != piVar2) {
        if (0xf < *(uint64_t *)(arg2 + 0x38)) {
            piVar2 = (int64_t *)*piVar2;
        }
        fcn.18000f180(arg1 + 0x20, piVar2, *(undefined8 *)(arg2 + 0x30));
    }
    func_0x000180016c50(arg1 + 0x40, arg2 + 0x40);
    func_0x000180016c50(arg1 + 0x68, arg2 + 0x68);
    *(undefined4 *)(arg1 + 0x90) = *(undefined4 *)(arg2 + 0x90);
    return arg1;
}

// ============================================================
// Function: FUN_180018b00
// Address: 0x180018b00
// Size: 97 bytes
// ============================================================
int64_t fcn.180018b00(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t unaff_RBP;
    
    fcn.180498cd0(arg3);
    puVar4 = (undefined4 *)fcn.18000d970(unaff_RBP);
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    uVar1 = puVar4[1];
    uVar2 = puVar4[2];
    uVar3 = puVar4[3];
    *(undefined4 *)arg1 = *puVar4;
    *(undefined4 *)(arg1 + 4) = uVar1;
    *(undefined4 *)(arg1 + 8) = uVar2;
    *(undefined4 *)(arg1 + 0xc) = uVar3;
    uVar1 = puVar4[5];
    uVar2 = puVar4[6];
    uVar3 = puVar4[7];
    *(undefined4 *)(arg1 + 0x10) = puVar4[4];
    *(undefined4 *)(arg1 + 0x14) = uVar1;
    *(undefined4 *)(arg1 + 0x18) = uVar2;
    *(undefined4 *)(arg1 + 0x1c) = uVar3;
    *(undefined *)puVar4 = 0;
    *(undefined8 *)(puVar4 + 4) = 0;
    *(undefined8 *)(puVar4 + 6) = 0xf;
    return arg1;
}

// ============================================================
// Function: FUN_180018b70
// Address: 0x180018b70
// Size: 264 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.180018b70(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    char cVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    func_0x00018000b4d0();
    func_0x00018000b4d0(arg1 + 0x20, arg2 + 0x20);
    puVar1 = (undefined4 *)(arg1 + 0x40);
    *(undefined *)(arg1 + 0x60) = 0xff;
    cVar2 = *(char *)(arg2 + 0x60);
    if (cVar2 != -1) {
        if (cVar2 == '\0') {
            *(undefined *)puVar1 = *(undefined *)(arg2 + 0x40);
            *(undefined *)(arg1 + 0x60) = 0;
        } else if (cVar2 == '\x01') {
            *puVar1 = *(undefined4 *)(arg2 + 0x40);
            *(undefined *)(arg1 + 0x60) = 1;
        } else if (cVar2 == '\x02') {
            *puVar1 = *(undefined4 *)(arg2 + 0x40);
            *(undefined *)(arg1 + 0x60) = 2;
        } else {
            func_0x00018000b4d0(puVar1, arg2 + 0x40);
            *(undefined *)(arg1 + 0x60) = 3;
        }
    }
    puVar1 = (undefined4 *)(arg1 + 0x68);
    *(undefined *)(arg1 + 0x88) = 0xff;
    cVar2 = *(char *)(arg2 + 0x88);
    if (cVar2 != -1) {
        if (cVar2 == '\0') {
            *(undefined *)puVar1 = *(undefined *)(arg2 + 0x68);
            *(undefined *)(arg1 + 0x88) = 0;
        } else if (cVar2 == '\x01') {
            *puVar1 = *(undefined4 *)(arg2 + 0x68);
            *(undefined *)(arg1 + 0x88) = 1;
        } else if (cVar2 == '\x02') {
            *puVar1 = *(undefined4 *)(arg2 + 0x68);
            *(undefined *)(arg1 + 0x88) = 2;
        } else {
            func_0x00018000b4d0(puVar1, arg2 + 0x68);
            *(undefined *)(arg1 + 0x88) = 3;
        }
    }
    *(undefined4 *)(arg1 + 0x90) = *(undefined4 *)(arg2 + 0x90);
    return arg1;
}

// ============================================================
// Function: FUN_180018c80
// Address: 0x180018c80
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180018c80(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_60h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x10);
    if (uVar2 < (uint64_t)arg2) {
        func_0x00018000f930();
        pcVar3 = (code *)swi(3);
        iVar4 = (*pcVar3)();
        return iVar4;
    }
    if (*(uint64_t *)(arg1 + 0x18) - uVar2 < (uint64_t)arg4) {
        iVar4 = func_0x000180018d80(arg1, arg4, (undefined)var_8h, arg2, arg3, arg4);
        return iVar4;
    }
    *(uint64_t *)(arg1 + 0x10) = uVar2 + arg4;
    iVar4 = arg1;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar4 = *(int64_t *)arg1;
    }
    uVar1 = iVar4 + arg2;
    iVar5 = arg4;
    if ((uVar1 < (uint64_t)(arg3 + arg4)) && ((uint64_t)arg3 <= uVar2 + iVar4)) {
        if ((uint64_t)arg3 < uVar1) {
            iVar5 = uVar1 - arg3;
        } else {
            iVar5 = 0;
        }
    }
    func_0x000180498030(uVar1 + arg4, uVar1, (uVar2 - arg2) + 1);
    func_0x000180498030(uVar1, arg3, iVar5);
    func_0x000180498030(uVar1 + iVar5, iVar5 + arg3 + arg4, arg4 - iVar5);
    return arg1;
}

// ============================================================
// Function: FUN_180018cb2
// Address: 0x180018cb2
// Size: 150 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180018c80(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_60h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x10);
    if (uVar2 < (uint64_t)arg2) {
        func_0x00018000f930();
        pcVar3 = (code *)swi(3);
        iVar4 = (*pcVar3)();
        return iVar4;
    }
    if (*(uint64_t *)(arg1 + 0x18) - uVar2 < (uint64_t)arg4) {
        iVar4 = func_0x000180018d80(arg1, arg4, (undefined)var_8h, arg2, arg3, arg4);
        return iVar4;
    }
    *(uint64_t *)(arg1 + 0x10) = uVar2 + arg4;
    iVar4 = arg1;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar4 = *(int64_t *)arg1;
    }
    uVar1 = iVar4 + arg2;
    iVar5 = arg4;
    if ((uVar1 < (uint64_t)(arg3 + arg4)) && ((uint64_t)arg3 <= uVar2 + iVar4)) {
        if ((uint64_t)arg3 < uVar1) {
            iVar5 = uVar1 - arg3;
        } else {
            iVar5 = 0;
        }
    }
    func_0x000180498030(uVar1 + arg4, uVar1, (uVar2 - arg2) + 1);
    func_0x000180498030(uVar1, arg3, iVar5);
    func_0x000180498030(uVar1 + iVar5, iVar5 + arg3 + arg4, arg4 - iVar5);
    return arg1;
}

// ============================================================
// Function: FUN_180018d48
// Address: 0x180018d48
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180018c80(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_60h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x10);
    if (uVar2 < (uint64_t)arg2) {
        func_0x00018000f930();
        pcVar3 = (code *)swi(3);
        iVar4 = (*pcVar3)();
        return iVar4;
    }
    if (*(uint64_t *)(arg1 + 0x18) - uVar2 < (uint64_t)arg4) {
        iVar4 = func_0x000180018d80(arg1, arg4, (undefined)var_8h, arg2, arg3, arg4);
        return iVar4;
    }
    *(uint64_t *)(arg1 + 0x10) = uVar2 + arg4;
    iVar4 = arg1;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar4 = *(int64_t *)arg1;
    }
    uVar1 = iVar4 + arg2;
    iVar5 = arg4;
    if ((uVar1 < (uint64_t)(arg3 + arg4)) && ((uint64_t)arg3 <= uVar2 + iVar4)) {
        if ((uint64_t)arg3 < uVar1) {
            iVar5 = uVar1 - arg3;
        } else {
            iVar5 = 0;
        }
    }
    func_0x000180498030(uVar1 + arg4, uVar1, (uVar2 - arg2) + 1);
    func_0x000180498030(uVar1, arg3, iVar5);
    func_0x000180498030(uVar1 + iVar5, iVar5 + arg3 + arg4, arg4 - iVar5);
    return arg1;
}

// ============================================================
// Function: FUN_180018d80
// Address: 0x180018d80
// Size: 46 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180018d80(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    fcn.180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x000180018e23;
            }
            unaff_RDI = func_0x000180459890(uVar2);
        }
code_r0x000180018e4a:
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        iVar6 = unaff_RDI + arg4;
        iVar3 = (iVar3 - arg4) + 1;
        if (uVar4 < 0x10) {
            func_0x000180498030(unaff_RDI, arg1, arg4);
            func_0x000180498030(iVar6, arg_28h, arg_30h);
            func_0x000180498030(arg_30h + iVar6, arg4 + arg1, iVar3);
            goto code_r0x000180018efe;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, arg4);
        func_0x000180498030(iVar6, arg_28h, arg_30h);
        func_0x000180498030(arg_30h + iVar6, uVar8 + arg4, iVar3);
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x000180018efe;
            }
            goto code_r0x000180018ec6;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x000180018e23:
        iVar6 = func_0x000180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x000180018e4a;
        }
code_r0x000180018ec6:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x180018ed5;
    func_0x000180459c3c(uVar8);
code_r0x000180018efe:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_180018dae
// Address: 0x180018dae
// Size: 373 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180018d80(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    fcn.180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x000180018e23;
            }
            unaff_RDI = func_0x000180459890(uVar2);
        }
code_r0x000180018e4a:
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        iVar6 = unaff_RDI + arg4;
        iVar3 = (iVar3 - arg4) + 1;
        if (uVar4 < 0x10) {
            func_0x000180498030(unaff_RDI, arg1, arg4);
            func_0x000180498030(iVar6, arg_28h, arg_30h);
            func_0x000180498030(arg_30h + iVar6, arg4 + arg1, iVar3);
            goto code_r0x000180018efe;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, arg4);
        func_0x000180498030(iVar6, arg_28h, arg_30h);
        func_0x000180498030(arg_30h + iVar6, uVar8 + arg4, iVar3);
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x000180018efe;
            }
            goto code_r0x000180018ec6;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x000180018e23:
        iVar6 = func_0x000180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x000180018e4a;
        }
code_r0x000180018ec6:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x180018ed5;
    func_0x000180459c3c(uVar8);
code_r0x000180018efe:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_180018f23
// Address: 0x180018f23
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180018d80(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    fcn.180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x000180018e23;
            }
            unaff_RDI = func_0x000180459890(uVar2);
        }
code_r0x000180018e4a:
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        iVar6 = unaff_RDI + arg4;
        iVar3 = (iVar3 - arg4) + 1;
        if (uVar4 < 0x10) {
            func_0x000180498030(unaff_RDI, arg1, arg4);
            func_0x000180498030(iVar6, arg_28h, arg_30h);
            func_0x000180498030(arg_30h + iVar6, arg4 + arg1, iVar3);
            goto code_r0x000180018efe;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, arg4);
        func_0x000180498030(iVar6, arg_28h, arg_30h);
        func_0x000180498030(arg_30h + iVar6, uVar8 + arg4, iVar3);
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x000180018efe;
            }
            goto code_r0x000180018ec6;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x000180018e23:
        iVar6 = func_0x000180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x000180018e4a;
        }
code_r0x000180018ec6:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x180018ed5;
    func_0x000180459c3c(uVar8);
code_r0x000180018efe:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_180018f29
// Address: 0x180018f29
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180018d80(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    fcn.180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x000180018e23;
            }
            unaff_RDI = func_0x000180459890(uVar2);
        }
code_r0x000180018e4a:
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        iVar6 = unaff_RDI + arg4;
        iVar3 = (iVar3 - arg4) + 1;
        if (uVar4 < 0x10) {
            func_0x000180498030(unaff_RDI, arg1, arg4);
            func_0x000180498030(iVar6, arg_28h, arg_30h);
            func_0x000180498030(arg_30h + iVar6, arg4 + arg1, iVar3);
            goto code_r0x000180018efe;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, arg4);
        func_0x000180498030(iVar6, arg_28h, arg_30h);
        func_0x000180498030(arg_30h + iVar6, uVar8 + arg4, iVar3);
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x000180018efe;
            }
            goto code_r0x000180018ec6;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x000180018e23:
        iVar6 = func_0x000180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x000180018e4a;
        }
code_r0x000180018ec6:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x180018ed5;
    func_0x000180459c3c(uVar8);
code_r0x000180018efe:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_180018f30
// Address: 0x180018f30
// Size: 62 bytes
// ============================================================
int32_t fcn.180018f30(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t *piVar3;
    
    iVar2 = fcn.180085dd0(arg1, 2);
    if (iVar2 != 0) {
        piVar3 = (int64_t *)fcn.180085430(arg1, 2);
        iVar1 = *piVar3;
        if (iVar1 != 0) {
            return *(int32_t *)(iVar1 + 0x10) + 0x10 + (int32_t)iVar1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180018f70
// Address: 0x180018f70
// Size: 125 bytes
// ============================================================
undefined8 fcn.180018f70(void)
{
    int64_t unaff_GS_OFFSET;
    
    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
        *(int32_t *)0x1807827f4) {
        fcn.180459d18(0x1807827f4);
        if (*(int32_t *)0x1807827f4 == -1) {
            *(undefined8 *)0x1807827f8 = fcn.180459890(1);
            fcn.180459c24(0x1804a2230);
            fcn.180459cac(0x1807827f4);
            return 0x1807827f8;
        }
    }
    return 0x1807827f8;
}

// ============================================================
// Function: FUN_180018ff0
// Address: 0x180018ff0
// Size: 1210 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

undefined8 fcn.180018ff0(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    int32_t *piVar1;
    uint8_t uVar2;
    undefined (**ppauVar3) [16];
    uint64_t uVar4;
    int64_t *piVar5;
    code *pcVar6;
    undefined auVar7 [16];
    char cVar8;
    int16_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    undefined (**ppauVar12) [16];
    undefined (**ppauVar13) [16];
    int64_t *piVar14;
    int64_t iVar15;
    uint8_t *puVar16;
    uint32_t uVar17;
    undefined (*pauVar18) [16];
    undefined8 uVar19;
    undefined8 uVar20;
    int64_t iVar21;
    undefined *puVar22;
    undefined4 uVar23;
    int64_t var_1h;
    int64_t var_20h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    func_0x000180013530();
    if ((*(uint8_t *)(arg1 + 1) & 0x40) != 0) {
        ppauVar13 = *(undefined (***) [16])(arg1 + 0x28);
        ppauVar3 = *(undefined (***) [16])(arg1 + 0x40);
        ppauVar12 = ppauVar13;
        if (ppauVar3 <= ppauVar13) {
            ppauVar12 = *(undefined (***) [16])0x180782430;
        }
        if (((*(int32_t *)((int64_t)ppauVar12 + 0xc) == 9) && ((uint8_t)(**ppauVar12)[3] == *(uint32_t *)0x1807823dc))
           && (*ppauVar12 != (undefined (*) [16])0xfffffffffffffff0)) {
            ppauVar12 = ppauVar13 + 2;
            if (ppauVar3 <= ppauVar13 + 2) {
                ppauVar12 = *(undefined (***) [16])0x180782430;
            }
            if ((ppauVar12 != *(undefined (***) [16])0x180782430) && (*(int32_t *)((int64_t)ppauVar12 + 0xc) == 6)) {
                if (ppauVar3 <= ppauVar13) {
                    ppauVar13 = *(undefined (***) [16])0x180782430;
                }
                if (*(int32_t *)((int64_t)ppauVar13 + 0xc) == 9) {
                    pauVar18 = *ppauVar13 + 1;
                } else if (*(int32_t *)((int64_t)ppauVar13 + 0xc) == 2) {
                    pauVar18 = *ppauVar13;
                } else {
                    pauVar18 = (undefined (*) [16])0x0;
                }
                if (*(int64_t *)(*pauVar18 + 8) != 0) {
                    LOCK();
                    piVar1 = (int32_t *)(*(int64_t *)(*pauVar18 + 8) + 8);
                    *piVar1 = *piVar1 + 1;
                    UNLOCK();
                }
                uVar4 = *(uint64_t *)*pauVar18;
                piVar5 = *(int64_t **)(*pauVar18 + 8);
                auVar7 = *pauVar18;
                ppauVar13 = (undefined (**) [16])(*(int64_t *)(arg1 + 0x28) + 0x10);
                if (*(undefined (***) [16])(arg1 + 0x40) <= ppauVar13) {
                    ppauVar13 = *(undefined (***) [16])0x180782430;
                }
                if (*(int32_t *)((int64_t)ppauVar13 + 0xc) == 6) {
                    pauVar18 = *ppauVar13;
                    iVar9 = *(int16_t *)(*pauVar18 + 6);
                    puVar22 = pauVar18[1] + 8;
                    if (iVar9 == -0x8000) {
                        pcVar6 = *(code **)(*(int64_t *)(arg1 + 0x20) + 0x530);
                        if (pcVar6 == (code *)0x0) {
                            iVar9 = -1;
                        } else {
                            iVar9 = (*pcVar6)(arg1, puVar22, *(undefined4 *)(pauVar18[1] + 4));
                        }
                        *(int16_t *)(*pauVar18 + 6) = iVar9;
                    }
                    iVar11 = (int32_t)iVar9;
                } else {
                    puVar22 = (undefined *)0x0;
                    iVar11 = stack0x00000008;
                }
                iVar10 = fcn.180018f30(arg1);
                if (((iVar10 == 0x3ca42478) || (iVar10 == -0x5257bc02)) &&
                   (piVar14 = (int64_t *)func_0x000180008740(), uVar4 == *(uint64_t *)(*piVar14 + 0x18))) {
                    uVar23 = fcn.180018f70();
                    uVar20 = 0x180620398;
                    uVar19 = 0x180047c30;
                } else if (((iVar10 == -0xa27d8a5) || (iVar10 == 0x74a042bb)) &&
                          (piVar14 = (int64_t *)func_0x000180008740(), uVar4 == *(uint64_t *)(*piVar14 + 0x18))) {
                    uVar23 = fcn.180018f70();
                    uVar20 = 0x1806203a0;
                    uVar19 = 0x180048190;
                } else {
                    if (((iVar10 != -0x3feafd11) && (iVar10 != -0x7bfecae1)) ||
                       (piVar14 = (int64_t *)func_0x000180008740(), uVar4 != *(uint64_t *)(*piVar14 + 0x18))) {
                        if (-1 < iVar11) {
                            var_60h = 0;
                            piVar14 = (int64_t *)var_60h;
                            _var_68h = ZEXT816(0);
                            if (piVar5 != (int64_t *)0x0) {
                                LOCK();
                                *(int32_t *)((int64_t)piVar5 + 0xc) = *(int32_t *)((int64_t)piVar5 + 0xc) + 1;
                                UNLOCK();
                                piVar14 = piVar5;
                                _var_68h = auVar7;
                            }
                            var_58h = 0;
                            if (uVar4 != 0) {
                                var_58h = ((((((((uVar4 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                                (int64_t)uVar4 >> 8 & 0xffU) * 0x100000001b3 ^
                                               (int64_t)uVar4 >> 0x10 & 0xffU) * 0x100000001b3 ^
                                              (int64_t)uVar4 >> 0x18 & 0xffU) * 0x100000001b3 ^
                                             (int64_t)uVar4 >> 0x20 & 0xffU) * 0x100000001b3 ^
                                            (int64_t)uVar4 >> 0x28 & 0xffU) * 0x100000001b3 ^
                                           (int64_t)uVar4 >> 0x30 & 0xffU) * 0x100000001b3 ^
                                          (int64_t)uVar4 >> 0x38 & 0xffU) * 0x100000001b3;
                            }
                            iVar15 = func_0x00018001bae0(0, &var_78h, &var_68h, var_58h);
                            iVar21 = *(int64_t *)0x180782008;
                            if (*(int64_t *)(iVar15 + 8) != 0) {
                                iVar21 = *(int64_t *)(iVar15 + 8);
                            }
                            if (piVar14 != (int64_t *)0x0) {
                                LOCK();
                                piVar1 = (int32_t *)((int64_t)piVar14 + 0xc);
                                iVar11 = *piVar1;
                                *piVar1 = *piVar1 + -1;
                                UNLOCK();
                                if (iVar11 == 1) {
                                    (**(code **)(*piVar14 + 8))(piVar14);
                                }
                            }
                            if (((iVar21 != *(int64_t *)0x180782008) &&
                                (*(int64_t *)0x0 = func_0x00018001b140(*(undefined8 *)(uVar4 + 0x18), puVar22),
                                *(int64_t *)0x0 != 0)) &&
                               (cVar8 = func_0x00018001b3d0(iVar21 + 0x28, (int64_t)&var_1h + 7), cVar8 != '\0')) {
                                puVar16 = (uint8_t *)func_0x00018001b5e0(iVar21 + 0x28, (int64_t)&var_1h + 7);
                                uVar2 = *puVar16;
                                if (((uint8_t)(*(uint32_t *)(stack0x00000008 + 0x8c) >> 4) & 1) != uVar2) {
                                    func_0x0001800869f0(arg1, *(code **)0x180781ef8, 0, 0, 0);
                                    func_0x0001800859a0(arg1, 1);
                                    *(uint32_t *)(stack0x00000008 + 0x8c) =
                                         *(uint32_t *)(stack0x00000008 + 0x8c) & 0xffffffef;
                                    *(uint32_t *)(stack0x00000008 + 0x8c) =
                                         *(uint32_t *)(stack0x00000008 + 0x8c) | (uint32_t)uVar2 << 4;
                                    iVar11 = func_0x0001800878a0(arg1, 2, 1);
                                    uVar17 = 0;
                                    if (uVar2 == 0) {
                                        uVar17 = 0x10;
                                    }
                                    *(uint32_t *)(stack0x00000008 + 0x8c) =
                                         uVar17 | *(uint32_t *)(stack0x00000008 + 0x8c) & 0xffffffef;
                                    if (iVar11 != 0) {
                                        func_0x000180087960(arg1);
                                        pcVar6 = (code *)swi(3);
                                        uVar19 = (*pcVar6)();
                                        return uVar19;
                                    }
                                    if (piVar5 == (int64_t *)0x0) {
                                        return 1;
                                    }
                                    LOCK();
                                    piVar14 = piVar5 + 1;
                                    iVar11 = *(int32_t *)piVar14;
                                    *(int32_t *)piVar14 = *(int32_t *)piVar14 + -1;
                                    UNLOCK();
                                    if (iVar11 != 1) {
                                        return 1;
                                    }
                                    (**(code **)*piVar5)(piVar5);
                                    LOCK();
                                    piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
                                    iVar11 = *piVar1;
                                    *piVar1 = *piVar1 + -1;
                                    UNLOCK();
                                    if (iVar11 != 1) {
                                        return 1;
                                    }
                                    (**(code **)(*piVar5 + 8))(piVar5);
                                    return 1;
                                }
                            }
                        }
                        if (piVar5 != (int64_t *)0x0) {
                            LOCK();
                            piVar14 = piVar5 + 1;
                            iVar11 = *(int32_t *)piVar14;
                            *(int32_t *)piVar14 = *(int32_t *)piVar14 + -1;
                            UNLOCK();
                            if (iVar11 == 1) {
                                (**(code **)*piVar5)(piVar5);
                                LOCK();
                                piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
                                iVar11 = *piVar1;
                                *piVar1 = *piVar1 + -1;
                                UNLOCK();
                                if (iVar11 == 1) {
                                    (**(code **)(*piVar5 + 8))(piVar5);
                                }
                            }
                        }
                        goto code_r0x000180019484;
                    }
                    uVar23 = fcn.180018f70();
                    uVar20 = 0x1806203b0;
                    uVar19 = 0x1800505a0;
                }
                func_0x00018001afc0(uVar23, arg1, uVar19, uVar20);
                if (piVar5 != (int64_t *)0x0) {
                    LOCK();
                    piVar14 = piVar5 + 1;
                    iVar11 = *(int32_t *)piVar14;
                    *(int32_t *)piVar14 = *(int32_t *)piVar14 + -1;
                    UNLOCK();
                    if (iVar11 == 1) {
                        (**(code **)*piVar5)(piVar5);
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
                        iVar11 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar11 == 1) {
                            (**(code **)(*piVar5 + 8))(piVar5);
                            return 1;
                        }
                    }
                }
                return 1;
            }
        }
    }
code_r0x000180019484:
    uVar19 = (**(code **)0x180781ef8)(arg1);
    return uVar19;
}

// ============================================================
// Function: FUN_1800194d0
// Address: 0x1800194d0
// Size: 441 bytes
// ============================================================
uint64_t fcn.1800194d0(int64_t arg1)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint32_t uVar4;
    int64_t **ppiVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t *piVar9;
    int32_t iVar10;
    int64_t var_38h;
    int64_t var_30h;
    
    func_0x000180013530();
    if ((*(uint8_t *)(arg1 + 1) & 0x40) != 0) {
        ppiVar8 = *(int64_t ***)(arg1 + 0x28);
        ppiVar5 = ppiVar8;
        if (*(int64_t ***)(arg1 + 0x40) <= ppiVar8) {
            ppiVar5 = *(int64_t ***)0x180782430;
        }
        if (((*(int32_t *)((int64_t)ppiVar5 + 0xc) == 9) &&
            (*(uint8_t *)((int64_t)*ppiVar5 + 3) == *(uint32_t *)0x1807823dc)) &&
           (*ppiVar5 != (int64_t *)0xfffffffffffffff0)) {
            if (*(int64_t ***)(arg1 + 0x40) <= ppiVar8) {
                ppiVar8 = *(int64_t ***)0x180782430;
            }
            if (*(int32_t *)((int64_t)ppiVar8 + 0xc) == 9) {
                piVar9 = *ppiVar8 + 2;
            } else if (*(int32_t *)((int64_t)ppiVar8 + 0xc) == 2) {
                piVar9 = *ppiVar8;
            } else {
                piVar9 = (int64_t *)0x0;
            }
            if (piVar9[1] != 0) {
                LOCK();
                piVar1 = (int32_t *)(piVar9[1] + 8);
                *piVar1 = *piVar1 + 1;
                UNLOCK();
            }
            iVar2 = *piVar9;
            piVar9 = (int64_t *)piVar9[1];
            iVar3 = *(int64_t *)(arg1 + 8);
            if (iVar3 == 0) {
                uVar4 = (**(code **)0x180781ef0)(arg1);
code_r0x000180019605:
                if (piVar9 != (int64_t *)0x0) {
                    LOCK();
                    piVar6 = piVar9 + 1;
                    iVar10 = *(int32_t *)piVar6;
                    *(int32_t *)piVar6 = *(int32_t *)piVar6 + -1;
                    UNLOCK();
                    if (iVar10 == 1) {
                        (**(code **)*piVar9)(piVar9);
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar9 + 0xc);
                        iVar10 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar10 == 1) {
                            (**(code **)(*piVar9 + 8))(piVar9);
                        }
                    }
                }
                return (uint64_t)uVar4;
            }
            iVar10 = *(int32_t *)(iVar3 + 0x10) + 0x10 + (int32_t)iVar3;
            if ((iVar10 == 0x3ca42478) || (iVar10 == -0x5257bc02)) {
                piVar6 = (int64_t *)func_0x000180008740();
                if (iVar2 == *(int64_t *)(*piVar6 + 0x18)) {
                    uVar4 = func_0x000180047c30(arg1);
                    goto code_r0x000180019605;
                }
            }
            if ((iVar10 == -0xa27d8a5) || (iVar10 == 0x74a042bb)) {
                piVar6 = (int64_t *)func_0x000180008740();
                if (iVar2 == *(int64_t *)(*piVar6 + 0x18)) {
                    uVar4 = func_0x000180048190(arg1);
                    goto code_r0x000180019605;
                }
            }
            if ((iVar10 == -0x3feafd11) || (iVar10 == -0x7bfecae1)) {
                piVar6 = (int64_t *)func_0x000180008740();
                if (iVar2 == *(int64_t *)(*piVar6 + 0x18)) {
                    uVar4 = func_0x0001800505a0(arg1);
                    goto code_r0x000180019605;
                }
            }
            if (piVar9 != (int64_t *)0x0) {
                LOCK();
                piVar6 = piVar9 + 1;
                iVar10 = *(int32_t *)piVar6;
                *(int32_t *)piVar6 = *(int32_t *)piVar6 + -1;
                UNLOCK();
                if (iVar10 == 1) {
                    (**(code **)*piVar9)(piVar9);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar9 + 0xc);
                    iVar10 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar10 == 1) {
                        (**(code **)(*piVar9 + 8))(piVar9);
                    }
                }
            }
        }
    }
    // WARNING: Could not recover jumptable at 0x000180019686. Too many branches
    // WARNING: Treating indirect jump as call
    uVar7 = (**(code **)0x180781ef0)(arg1);
    return uVar7;
}

// ============================================================
// Function: FUN_180019690
// Address: 0x180019690
// Size: 977 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

undefined8 fcn.180019690(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    int32_t *piVar1;
    uint8_t uVar2;
    undefined (**ppauVar3) [16];
    uint64_t uVar4;
    int64_t *piVar5;
    code *pcVar6;
    undefined auVar7 [16];
    char cVar8;
    int16_t iVar9;
    int32_t iVar10;
    undefined (**ppauVar11) [16];
    undefined (**ppauVar12) [16];
    int64_t iVar13;
    uint8_t *puVar14;
    undefined8 uVar15;
    uint32_t uVar16;
    int64_t *piVar17;
    undefined (*pauVar18) [16];
    int64_t iVar19;
    undefined *puVar20;
    int64_t var_1h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    
    func_0x000180013530();
    if ((*(uint8_t *)(arg1 + 1) & 0x40) != 0) {
        ppauVar12 = *(undefined (***) [16])(arg1 + 0x28);
        ppauVar3 = *(undefined (***) [16])(arg1 + 0x40);
        ppauVar11 = ppauVar12;
        if (ppauVar3 <= ppauVar12) {
            ppauVar11 = *(undefined (***) [16])0x180782430;
        }
        if (((*(int32_t *)((int64_t)ppauVar11 + 0xc) == 9) && ((uint8_t)(**ppauVar11)[3] == *(uint32_t *)0x1807823dc))
           && (*ppauVar11 != (undefined (*) [16])0xfffffffffffffff0)) {
            ppauVar11 = ppauVar12 + 2;
            if (ppauVar3 <= ppauVar12 + 2) {
                ppauVar11 = *(undefined (***) [16])0x180782430;
            }
            if ((ppauVar11 != *(undefined (***) [16])0x180782430) && (*(int32_t *)((int64_t)ppauVar11 + 0xc) == 6)) {
                if (ppauVar3 <= ppauVar12) {
                    ppauVar12 = *(undefined (***) [16])0x180782430;
                }
                if (*(int32_t *)((int64_t)ppauVar12 + 0xc) == 9) {
                    pauVar18 = *ppauVar12 + 1;
                } else if (*(int32_t *)((int64_t)ppauVar12 + 0xc) == 2) {
                    pauVar18 = *ppauVar12;
                } else {
                    pauVar18 = (undefined (*) [16])0x0;
                }
                if (*(int64_t *)(*pauVar18 + 8) != 0) {
                    LOCK();
                    piVar1 = (int32_t *)(*(int64_t *)(*pauVar18 + 8) + 8);
                    *piVar1 = *piVar1 + 1;
                    UNLOCK();
                }
                uVar4 = *(uint64_t *)*pauVar18;
                piVar5 = *(int64_t **)(*pauVar18 + 8);
                auVar7 = *pauVar18;
                ppauVar12 = (undefined (**) [16])(*(int64_t *)(arg1 + 0x28) + 0x10);
                if (*(undefined (***) [16])(arg1 + 0x40) <= ppauVar12) {
                    ppauVar12 = *(undefined (***) [16])0x180782430;
                }
                if (*(int32_t *)((int64_t)ppauVar12 + 0xc) == 6) {
                    pauVar18 = *ppauVar12;
                    iVar9 = *(int16_t *)(*pauVar18 + 6);
                    puVar20 = pauVar18[1] + 8;
                    if (iVar9 == -0x8000) {
                        pcVar6 = *(code **)(*(int64_t *)(arg1 + 0x20) + 0x530);
                        if (pcVar6 == (code *)0x0) {
                            iVar9 = -1;
                        } else {
                            iVar9 = (*pcVar6)(arg1, puVar20, *(undefined4 *)(pauVar18[1] + 4));
                        }
                        *(int16_t *)(*pauVar18 + 6) = iVar9;
                    }
                    iVar10 = (int32_t)iVar9;
                } else {
                    puVar20 = (undefined *)0x0;
                    iVar10 = stack0x00000008;
                }
                if (-1 < iVar10) {
                    var_40h = 0;
                    piVar17 = (int64_t *)var_40h;
                    _var_48h = ZEXT816(0);
                    if (piVar5 != (int64_t *)0x0) {
                        LOCK();
                        *(int32_t *)((int64_t)piVar5 + 0xc) = *(int32_t *)((int64_t)piVar5 + 0xc) + 1;
                        UNLOCK();
                        piVar17 = piVar5;
                        _var_48h = auVar7;
                    }
                    var_38h = 0;
                    if (uVar4 != 0) {
                        var_38h = ((((((((uVar4 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                        (int64_t)uVar4 >> 8 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar4 >> 0x10 & 0xffU) *
                                       0x100000001b3 ^ (int64_t)uVar4 >> 0x18 & 0xffU) * 0x100000001b3 ^
                                     (int64_t)uVar4 >> 0x20 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar4 >> 0x28 & 0xffU) *
                                    0x100000001b3 ^ (int64_t)uVar4 >> 0x30 & 0xffU) * 0x100000001b3 ^
                                  (int64_t)uVar4 >> 0x38 & 0xffU) * 0x100000001b3;
                    }
                    iVar13 = func_0x00018001bae0(0, &var_58h, &var_48h, var_38h);
                    iVar19 = *(int64_t *)0x180782008;
                    if (*(int64_t *)(iVar13 + 8) != 0) {
                        iVar19 = *(int64_t *)(iVar13 + 8);
                    }
                    if (piVar17 != (int64_t *)0x0) {
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar17 + 0xc);
                        iVar10 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar10 == 1) {
                            (**(code **)(*piVar17 + 8))(piVar17);
                        }
                    }
                    if (((iVar19 != *(int64_t *)0x180782008) &&
                        (*(int64_t *)0x0 = func_0x00018001b140(*(undefined8 *)(uVar4 + 0x18), puVar20),
                        *(int64_t *)0x0 != 0)) &&
                       (cVar8 = func_0x00018001b3d0(iVar19 + 0x28, (int64_t)&var_1h + 7), cVar8 != '\0')) {
                        puVar14 = (uint8_t *)func_0x00018001b5e0(iVar19 + 0x28, (int64_t)&var_1h + 7);
                        uVar2 = *puVar14;
                        if (((uint8_t)(*(uint32_t *)(stack0x00000008 + 0x8c) >> 4) & 1) != uVar2) {
                            func_0x0001800869f0(arg1, *(code **)0x180781f00, 0, 0, 0);
                            func_0x0001800859a0(arg1, 1);
                            *(uint32_t *)(stack0x00000008 + 0x8c) = *(uint32_t *)(stack0x00000008 + 0x8c) & 0xffffffef;
                            *(uint32_t *)(stack0x00000008 + 0x8c) =
                                 *(uint32_t *)(stack0x00000008 + 0x8c) | (uint32_t)uVar2 << 4;
                            iVar10 = func_0x0001800878a0(arg1, 3, 0);
                            uVar16 = 0;
                            if (uVar2 == 0) {
                                uVar16 = 0x10;
                            }
                            *(uint32_t *)(stack0x00000008 + 0x8c) =
                                 uVar16 | *(uint32_t *)(stack0x00000008 + 0x8c) & 0xffffffef;
                            if (iVar10 == 0) {
                                if (piVar5 != (int64_t *)0x0) {
                                    LOCK();
                                    piVar17 = piVar5 + 1;
                                    iVar10 = *(int32_t *)piVar17;
                                    *(int32_t *)piVar17 = *(int32_t *)piVar17 + -1;
                                    UNLOCK();
                                    if (iVar10 == 1) {
                                        (**(code **)*piVar5)(piVar5);
                                        LOCK();
                                        piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
                                        iVar10 = *piVar1;
                                        *piVar1 = *piVar1 + -1;
                                        UNLOCK();
                                        if (iVar10 == 1) {
                                            (**(code **)(*piVar5 + 8))(piVar5);
                                        }
                                    }
                                }
                                return 0;
                            }
                            func_0x000180087960(arg1);
                            pcVar6 = (code *)swi(3);
                            uVar15 = (*pcVar6)();
                            return uVar15;
                        }
                    }
                }
                if (piVar5 != (int64_t *)0x0) {
                    LOCK();
                    piVar17 = piVar5 + 1;
                    iVar10 = *(int32_t *)piVar17;
                    *(int32_t *)piVar17 = *(int32_t *)piVar17 + -1;
                    UNLOCK();
                    if (iVar10 == 1) {
                        (**(code **)*piVar5)(piVar5);
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
                        iVar10 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar10 == 1) {
                            (**(code **)(*piVar5 + 8))(piVar5);
                        }
                    }
                }
            }
        }
    }
    uVar15 = (**(code **)0x180781f00)(arg1);
    return uVar15;
}

// ============================================================
// Function: FUN_180019a70
// Address: 0x180019a70
// Size: 5104 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.180019a70(undefined8 placeholder_0, int64_t arg2)
{
    int32_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t *piVar9;
    uint64_t uVar10;
    int64_t **ppiVar11;
    uint64_t uVar12;
    undefined8 uVar13;
    undefined *puVar14;
    undefined *puVar15;
    undefined *puVar16;
    int64_t **ppiVar17;
    int64_t iVar18;
    int64_t **ppiVar19;
    undefined8 uStack_120;
    undefined auStack_118 [8];
    undefined auStack_110 [24];
    int64_t var_f8h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_98h;
    int64_t var_60h;
    int64_t var_58h;
    
    ppiVar17 = *(int64_t ***)0x180781fe8;
    puVar14 = auStack_118;
    puVar15 = auStack_118;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_118;
    ppiVar4 = *(int64_t ***)0x180781fe0;
    if (*(int64_t ***)0x180781fe0 != *(int64_t ***)0x180781fe8) {
        do {
            (**(code **)(**ppiVar4 + 8))();
            ppiVar4 = ppiVar4 + 1;
        } while (ppiVar4 != ppiVar17);
    }
    func_0x00018001b4c0(0x180782000);
    func_0x00018001b520();
    func_0x00018001b1d0(&var_f8h);
    func_0x00018001b200();
    func_0x000180005a40(&var_f8h);
    ppiVar4 = (int64_t **)func_0x00018001b240(&var_f8h);
    ppiVar17 = *(int64_t ***)0x180781fe8;
    if (*(int64_t ***)0x180781fe8 == *(int64_t ***)0x180781ff0) {
        iVar18 = (int64_t)*(int64_t ***)0x180781fe8 - (int64_t)*(int64_t ***)0x180781fe0 >> 3;
        if (iVar18 != 0x1fffffffffffffff) {
            uVar10 = (int64_t)*(int64_t ***)0x180781ff0 - (int64_t)*(int64_t ***)0x180781fe0 >> 3;
            puVar16 = auStack_118;
            if (0x1fffffffffffffff - (uVar10 >> 1) < uVar10) goto code_r0x00018001ae0c;
            uVar12 = iVar18 + 1;
            uVar10 = uVar10 + (uVar10 >> 1);
            uVar6 = uVar12;
            if (uVar12 <= uVar10) {
                uVar6 = uVar10;
            }
            puVar16 = auStack_118;
            if (0x1fffffffffffffff < uVar6) goto code_r0x00018001ae0c;
            uVar10 = uVar6 * 8;
            if (uVar10 == 0) {
                ppiVar19 = (int64_t **)0x0;
                puVar15 = auStack_118;
            } else if (uVar10 < 0x1000) {
                ppiVar19 = (int64_t **)fcn.180459890();
            } else {
                puVar16 = auStack_118;
                if (uVar10 + 0x27 <= uVar10) goto code_r0x00018001ae0c;
                piVar5 = (int64_t *)fcn.180459890(uVar10 + 0x27);
                if (piVar5 == (int64_t *)0x0) {
                    pcVar2 = (code *)swi(0x29);
                    piVar5 = (int64_t *)(*pcVar2)(5);
                    puVar14 = auStack_110;
                }
                ppiVar19 = (int64_t **)((int64_t)piVar5 + 0x27U & 0xffffffffffffffe0);
                ppiVar19[-1] = piVar5;
                puVar15 = puVar14;
            }
            var_c0h = (int64_t)(ppiVar19 + iVar18);
            var_b8h = var_c0h + 8;
            var_d8h = 0x180781fe0;
            piVar5 = *ppiVar4;
            *ppiVar4 = (int64_t *)0x0;
            *(int64_t **)var_c0h = piVar5;
            ppiVar7 = *(int64_t ***)0x180781fe8;
            ppiVar4 = ppiVar19;
            ppiVar11 = *(int64_t ***)0x180781fe0;
            if (ppiVar17 == *(int64_t ***)0x180781fe8) {
                for (; ppiVar11 != ppiVar7; ppiVar11 = ppiVar11 + 1) {
                    piVar5 = *ppiVar11;
                    *ppiVar11 = (int64_t *)0x0;
                    *ppiVar4 = piVar5;
                    ppiVar4 = ppiVar4 + 1;
                }
            } else {
                for (; ppiVar8 = (int64_t **)var_b8h, *(int64_t ***)0x180781fe8 = ppiVar7, ppiVar11 != ppiVar17;
                    ppiVar11 = ppiVar11 + 1) {
                    piVar5 = *ppiVar11;
                    *ppiVar11 = (int64_t *)0x0;
                    *ppiVar4 = piVar5;
                    ppiVar4 = ppiVar4 + 1;
                    ppiVar7 = *(int64_t ***)0x180781fe8;
                }
                for (; var_c0h = (int64_t)ppiVar19, ppiVar17 != ppiVar7; ppiVar17 = ppiVar17 + 1) {
                    piVar5 = *ppiVar17;
                    *ppiVar17 = (int64_t *)0x0;
                    *ppiVar8 = piVar5;
                    ppiVar8 = ppiVar8 + 1;
                }
            }
            var_d0h = 0;
            *(undefined8 *)(puVar15 + -8) = 0x180019c98;
            var_c8h = uVar6;
            func_0x00018001c0c0(ppiVar11, ppiVar19, uVar12);
            *(undefined8 *)(puVar15 + -8) = 0x180019ca1;
            func_0x00018001c010(&var_d8h);
            goto code_r0x000180019ca2;
        }
        func_0x000180010010();
        puVar15 = auStack_118;
code_r0x00018001ae18:
        *(undefined8 *)(puVar15 + -8) = 0x18001ae1d;
        func_0x000180010010();
code_r0x00018001ae1e:
        *(undefined8 *)(puVar15 + -8) = 0x18001ae23;
        func_0x000180010010();
code_r0x00018001ae24:
        *(undefined8 *)(puVar15 + -8) = 0x18001ae29;
        func_0x000180010010();
code_r0x00018001ae2a:
        *(undefined8 *)(puVar15 + -8) = 0x18001ae2f;
        func_0x000180010010();
code_r0x00018001ae30:
        *(undefined8 *)(puVar15 + -8) = 0x18001ae35;
        func_0x000180010010();
code_r0x00018001ae36:
        *(undefined8 *)(puVar15 + -8) = 0x18001ae3b;
        func_0x000180010010();
code_r0x00018001ae3c:
        *(undefined8 *)(puVar15 + -8) = 0x18001ae41;
        func_0x000180010010();
    } else {
        piVar5 = *ppiVar4;
        *ppiVar4 = (int64_t *)0x0;
        *ppiVar17 = piVar5;
        *(int64_t ***)0x180781fe8 = *(int64_t ***)0x180781fe8 + 1;
        puVar15 = auStack_118;
code_r0x000180019ca2:
        if (*(int64_t *)(puVar15 + 0x20) != 0) {
            *(undefined8 *)(puVar15 + -8) = 0x180019cb6;
            func_0x000180459c3c(*(int64_t *)(puVar15 + 0x20), 8);
        }
        *(undefined8 *)(puVar15 + -8) = 0x180019cc0;
        piVar5 = (int64_t *)fcn.180459890(8);
        *piVar5 = 0x180620468;
        ppiVar17 = *(int64_t ***)0x180781fe8;
        *(int64_t **)(puVar15 + 0x20) = piVar5;
        if (*(int64_t ***)0x180781fe8 == *(int64_t ***)0x180781ff0) {
            iVar18 = (int64_t)*(int64_t ***)0x180781fe8 - (int64_t)*(int64_t ***)0x180781fe0 >> 3;
            if (iVar18 != 0x1fffffffffffffff) {
                uVar10 = (int64_t)*(int64_t ***)0x180781ff0 - (int64_t)*(int64_t ***)0x180781fe0 >> 3;
                if (uVar10 <= 0x1fffffffffffffff - (uVar10 >> 1)) {
                    uVar12 = iVar18 + 1;
                    uVar10 = (uVar10 >> 1) + uVar10;
                    uVar6 = uVar12;
                    if (uVar12 <= uVar10) {
                        uVar6 = uVar10;
                    }
                    if (uVar6 < 0x2000000000000000) {
                        uVar10 = uVar6 * 8;
                        if (uVar10 == 0) {
                            ppiVar4 = (int64_t **)0x0;
                        } else if (uVar10 < 0x1000) {
                            *(undefined8 *)(puVar15 + -8) = 0x180019d9e;
                            ppiVar4 = (int64_t **)fcn.180459890();
                        } else {
                            if (uVar10 + 0x27 <= uVar10) goto code_r0x00018001ae06;
                            *(undefined8 *)(puVar15 + -8) = 0x180019d7f;
                            piVar9 = (int64_t *)fcn.180459890(uVar10 + 0x27);
                            if (piVar9 == (int64_t *)0x0) {
                                pcVar2 = (code *)swi(0x29);
                                piVar9 = (int64_t *)(*pcVar2)(5);
                                puVar15 = puVar15 + 8;
                            }
                            ppiVar4 = (int64_t **)((int64_t)piVar9 + 0x27U & 0xffffffffffffffe0);
                            ppiVar4[-1] = piVar9;
                        }
                        var_c0h = (int64_t)(ppiVar4 + iVar18);
                        var_b8h = var_c0h + 8;
                        var_d8h = 0x180781fe0;
                        *(undefined8 *)(puVar15 + 0x20) = 0;
                        *(int64_t **)var_c0h = piVar5;
                        ppiVar7 = *(int64_t ***)0x180781fe8;
                        ppiVar19 = ppiVar4;
                        ppiVar11 = *(int64_t ***)0x180781fe0;
                        if (ppiVar17 == *(int64_t ***)0x180781fe8) {
                            for (; ppiVar11 != ppiVar7; ppiVar11 = ppiVar11 + 1) {
                                piVar5 = *ppiVar11;
                                *ppiVar11 = (int64_t *)0x0;
                                *ppiVar19 = piVar5;
                                ppiVar19 = ppiVar19 + 1;
                            }
                        } else {
                            for (; ppiVar8 = (int64_t **)var_b8h, *(int64_t ***)0x180781fe8 = ppiVar7,
                                ppiVar11 != ppiVar17; ppiVar11 = ppiVar11 + 1) {
                                piVar5 = *ppiVar11;
                                *ppiVar11 = (int64_t *)0x0;
                                *ppiVar19 = piVar5;
                                ppiVar19 = ppiVar19 + 1;
                                ppiVar7 = *(int64_t ***)0x180781fe8;
                            }
                            for (; var_c0h = (int64_t)ppiVar4, ppiVar17 != ppiVar7; ppiVar17 = ppiVar17 + 1) {
                                piVar5 = *ppiVar17;
                                *ppiVar17 = (int64_t *)0x0;
                                *ppiVar8 = piVar5;
                                ppiVar8 = ppiVar8 + 1;
                            }
                        }
                        var_d0h = 0;
                        *(undefined8 *)(puVar15 + -8) = 0x180019e68;
                        var_c8h = uVar6;
                        func_0x00018001c0c0(ppiVar11, ppiVar4, uVar12);
                        *(undefined8 *)(puVar15 + -8) = 0x180019e71;
                        func_0x00018001c010(&var_d8h);
                        goto code_r0x000180019e72;
                    }
                }
code_r0x00018001ae06:
                *(undefined8 *)(puVar15 + -8) = 0x18001ae0b;
                fcn.180004720();
                puVar16 = puVar15;
code_r0x00018001ae0c:
                *(undefined8 *)(puVar16 + -8) = 0x18001ae11;
                fcn.180004720();
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            goto code_r0x00018001ae18;
        }
        *(undefined8 *)(puVar15 + 0x20) = 0;
        **(int64_t ***)0x180781fe8 = piVar5;
        *(int64_t ***)0x180781fe8 = *(int64_t ***)0x180781fe8 + 1;
code_r0x000180019e72:
        *(undefined8 *)(puVar15 + -8) = 0x180019e7c;
        func_0x000180005a40(puVar15 + 0x20);
        *(undefined8 *)(puVar15 + -8) = 0x180019e86;
        piVar5 = (int64_t *)fcn.180459890(8);
        *piVar5 = 0x180620510;
        ppiVar17 = *(int64_t ***)0x180781fe8;
        *(int64_t **)(puVar15 + 0x30) = piVar5;
        if (*(int64_t ***)0x180781fe8 == *(int64_t ***)0x180781ff0) {
            iVar18 = (int64_t)*(int64_t ***)0x180781fe8 - (int64_t)*(int64_t ***)0x180781fe0 >> 3;
            if (iVar18 != 0x1fffffffffffffff) {
                uVar10 = iVar18 + 1;
                uVar12 = (int64_t)*(int64_t ***)0x180781ff0 - (int64_t)*(int64_t ***)0x180781fe0 >> 3;
                if (0x1fffffffffffffff - (uVar12 >> 1) < uVar12) {
                    uVar6 = 0x1fffffffffffffff;
                } else {
                    uVar6 = (uVar12 >> 1) + uVar12;
                    if (uVar6 < uVar10) {
                        uVar6 = uVar10;
                    }
                }
                *(uint64_t *)(puVar15 + 0x20) = uVar6;
                *(undefined8 *)(puVar15 + -8) = 0x180019f10;
                ppiVar7 = (int64_t **)func_0x00018001ba60(uVar12, puVar15 + 0x20);
                var_c0h = (int64_t)(ppiVar7 + iVar18);
                var_b8h = var_c0h + 8;
                var_d8h = 0x180781fe0;
                var_c8h = *(int64_t *)(puVar15 + 0x20);
                *(int64_t **)var_c0h = piVar5;
                ppiVar11 = *(int64_t ***)0x180781fe8;
                ppiVar4 = ppiVar7;
                ppiVar19 = *(int64_t ***)0x180781fe0;
                if (ppiVar17 == *(int64_t ***)0x180781fe8) {
                    for (; ppiVar19 != ppiVar11; ppiVar19 = ppiVar19 + 1) {
                        piVar5 = *ppiVar19;
                        *ppiVar19 = (int64_t *)0x0;
                        *ppiVar4 = piVar5;
                        ppiVar4 = ppiVar4 + 1;
                    }
                } else {
                    for (; ppiVar8 = (int64_t **)var_b8h, *(int64_t ***)0x180781fe8 = ppiVar11, ppiVar19 != ppiVar17;
                        ppiVar19 = ppiVar19 + 1) {
                        piVar5 = *ppiVar19;
                        *ppiVar19 = (int64_t *)0x0;
                        *ppiVar4 = piVar5;
                        ppiVar4 = ppiVar4 + 1;
                        ppiVar11 = *(int64_t ***)0x180781fe8;
                    }
                    for (; var_c0h = (int64_t)ppiVar7, ppiVar17 != ppiVar11; ppiVar17 = ppiVar17 + 1) {
                        piVar5 = *ppiVar17;
                        *ppiVar17 = (int64_t *)0x0;
                        *ppiVar8 = piVar5;
                        ppiVar8 = ppiVar8 + 1;
                    }
                }
                var_d0h = 0;
                *(undefined8 *)(puVar15 + -8) = 0x180019fd8;
                func_0x00018001c0c0(ppiVar19, ppiVar7, uVar10);
                *(undefined8 *)(puVar15 + -8) = 0x180019fe1;
                func_0x00018001c010(&var_d8h);
                goto code_r0x000180019fe2;
            }
            goto code_r0x00018001ae1e;
        }
        **(int64_t ***)0x180781fe8 = piVar5;
        *(int64_t ***)0x180781fe8 = *(int64_t ***)0x180781fe8 + 1;
code_r0x000180019fe2:
        *(undefined8 *)(puVar15 + -8) = 0x180019fec;
        piVar5 = (int64_t *)fcn.180459890(8);
        *piVar5 = 0x1806205d0;
        ppiVar17 = *(int64_t ***)0x180781fe8;
        *(int64_t **)(puVar15 + 0x30) = piVar5;
        if (*(int64_t ***)0x180781fe8 == *(int64_t ***)0x180781ff0) {
            iVar18 = (int64_t)*(int64_t ***)0x180781fe8 - (int64_t)*(int64_t ***)0x180781fe0 >> 3;
            if (iVar18 != 0x1fffffffffffffff) {
                uVar10 = (int64_t)*(int64_t ***)0x180781ff0 - (int64_t)*(int64_t ***)0x180781fe0 >> 3;
                if (0x1fffffffffffffff - (uVar10 >> 1) < uVar10) {
                    uVar12 = 0x1fffffffffffffff;
                } else {
                    uVar12 = (uVar10 >> 1) + uVar10;
                    if (uVar12 < iVar18 + 1U) {
                        uVar12 = iVar18 + 1U;
                    }
                }
                *(uint64_t *)(puVar15 + 0x20) = uVar12;
                *(undefined8 *)(puVar15 + -8) = 0x18001a077;
                ppiVar8 = (int64_t **)func_0x00018001ba60(uVar10, puVar15 + 0x20);
                var_c0h = (int64_t)(ppiVar8 + iVar18);
                ppiVar4 = (int64_t **)(var_c0h + 8);
                var_d8h = 0x180781fe0;
                var_c8h = *(int64_t *)(puVar15 + 0x20);
                *(int64_t **)var_c0h = piVar5;
                ppiVar7 = *(int64_t ***)0x180781fe8;
                ppiVar19 = ppiVar8;
                ppiVar11 = *(int64_t ***)0x180781fe0;
                var_b8h = (int64_t)ppiVar4;
                if (ppiVar17 == *(int64_t ***)0x180781fe8) {
                    for (; ppiVar11 != ppiVar7; ppiVar11 = ppiVar11 + 1) {
                        piVar5 = *ppiVar11;
                        *ppiVar11 = (int64_t *)0x0;
                        *ppiVar19 = piVar5;
                        ppiVar19 = ppiVar19 + 1;
                    }
                } else {
                    for (; ppiVar11 != ppiVar17; ppiVar11 = ppiVar11 + 1) {
                        piVar5 = *ppiVar11;
                        *ppiVar11 = (int64_t *)0x0;
                        *ppiVar19 = piVar5;
                        ppiVar19 = ppiVar19 + 1;
                    }
                    *(undefined8 *)(puVar15 + -8) = 0x18001a111;
                    func_0x00018001b830(ppiVar19, ppiVar19);
                    ppiVar11 = *(int64_t ***)0x180781fe8;
                    ppiVar19 = ppiVar4;
                    for (; var_c0h = (int64_t)ppiVar8, ppiVar17 != ppiVar11; ppiVar17 = ppiVar17 + 1) {
                        piVar5 = *ppiVar17;
                        *ppiVar17 = (int64_t *)0x0;
                        *ppiVar19 = piVar5;
                        ppiVar19 = ppiVar19 + 1;
                    }
                }
                *(undefined8 *)(puVar15 + -8) = 0x18001a142;
                func_0x00018001b830(ppiVar19, ppiVar19);
                var_d0h = 0;
                *(undefined8 *)(puVar15 + -8) = 0x18001a15a;
                func_0x00018001c0c0();
                *(undefined8 *)(puVar15 + -8) = 0x18001a163;
                func_0x00018001c010(&var_d8h);
                goto code_r0x00018001a164;
            }
            goto code_r0x00018001ae24;
        }
        **(int64_t ***)0x180781fe8 = piVar5;
        *(int64_t ***)0x180781fe8 = *(int64_t ***)0x180781fe8 + 1;
code_r0x00018001a164:
        *(undefined8 *)(puVar15 + -8) = 0x18001a16e;
        piVar5 = (int64_t *)fcn.180459890(8);
        *piVar5 = 0x180620618;
        ppiVar17 = *(int64_t ***)0x180781fe8;
        *(int64_t **)(puVar15 + 0x30) = piVar5;
        if (*(int64_t ***)0x180781fe8 == *(int64_t ***)0x180781ff0) {
            iVar18 = (int64_t)*(int64_t ***)0x180781fe8 - (int64_t)*(int64_t ***)0x180781fe0 >> 3;
            if (iVar18 != 0x1fffffffffffffff) {
                uVar10 = (int64_t)*(int64_t ***)0x180781ff0 - (int64_t)*(int64_t ***)0x180781fe0 >> 3;
                if (0x1fffffffffffffff - (uVar10 >> 1) < uVar10) {
                    uVar12 = 0x1fffffffffffffff;
                } else {
                    uVar12 = (uVar10 >> 1) + uVar10;
                    if (uVar12 < iVar18 + 1U) {
                        uVar12 = iVar18 + 1U;
                    }
                }
                *(uint64_t *)(puVar15 + 0x20) = uVar12;
                *(undefined8 *)(puVar15 + -8) = 0x18001a1f9;
                ppiVar8 = (int64_t **)func_0x00018001ba60(uVar10, puVar15 + 0x20);
                var_c0h = (int64_t)(ppiVar8 + iVar18);
                ppiVar4 = (int64_t **)(var_c0h + 8);
                var_d8h = 0x180781fe0;
                var_c8h = *(int64_t *)(puVar15 + 0x20);
                *(int64_t **)var_c0h = piVar5;
                ppiVar7 = *(int64_t ***)0x180781fe8;
                ppiVar19 = ppiVar8;
                ppiVar11 = *(int64_t ***)0x180781fe0;
                var_b8h = (int64_t)ppiVar4;
                if (ppiVar17 == *(int64_t ***)0x180781fe8) {
                    for (; ppiVar11 != ppiVar7; ppiVar11 = ppiVar11 + 1) {
                        piVar5 = *ppiVar11;
                        *ppiVar11 = (int64_t *)0x0;
                        *ppiVar19 = piVar5;
                        ppiVar19 = ppiVar19 + 1;
                    }
                } else {
                    for (; ppiVar11 != ppiVar17; ppiVar11 = ppiVar11 + 1) {
                        piVar5 = *ppiVar11;
                        *ppiVar11 = (int64_t *)0x0;
                        *ppiVar19 = piVar5;
                        ppiVar19 = ppiVar19 + 1;
                    }
                    *(undefined8 *)(puVar15 + -8) = 0x18001a291;
                    func_0x00018001b830(ppiVar19, ppiVar19);
                    ppiVar11 = *(int64_t ***)0x180781fe8;
                    ppiVar19 = ppiVar4;
                    for (; var_c0h = (int64_t)ppiVar8, ppiVar17 != ppiVar11; ppiVar17 = ppiVar17 + 1) {
                        piVar5 = *ppiVar17;
                        *ppiVar17 = (int64_t *)0x0;
                        *ppiVar19 = piVar5;
                        ppiVar19 = ppiVar19 + 1;
                    }
                }
                *(undefined8 *)(puVar15 + -8) = 0x18001a2c2;
                func_0x00018001b830(ppiVar19, ppiVar19);
                var_d0h = 0;
                *(undefined8 *)(puVar15 + -8) = 0x18001a2da;
                func_0x00018001c0c0();
                *(undefined8 *)(puVar15 + -8) = 0x18001a2e3;
                func_0x00018001c010(&var_d8h);
                goto code_r0x00018001a2e4;
            }
            goto code_r0x00018001ae2a;
        }
        **(int64_t ***)0x180781fe8 = piVar5;
        *(int64_t ***)0x180781fe8 = *(int64_t ***)0x180781fe8 + 1;
code_r0x00018001a2e4:
        *(undefined8 *)(puVar15 + -8) = 0x18001a2ee;
        piVar5 = (int64_t *)fcn.180459890(8);
        *piVar5 = 0x180620498;
        ppiVar17 = *(int64_t ***)0x180781fe8;
        *(int64_t **)(puVar15 + 0x30) = piVar5;
        if (*(int64_t ***)0x180781fe8 == *(int64_t ***)0x180781ff0) {
            iVar18 = (int64_t)*(int64_t ***)0x180781fe8 - (int64_t)*(int64_t ***)0x180781fe0 >> 3;
            if (iVar18 != 0x1fffffffffffffff) {
                uVar10 = (int64_t)*(int64_t ***)0x180781ff0 - (int64_t)*(int64_t ***)0x180781fe0 >> 3;
                if (0x1fffffffffffffff - (uVar10 >> 1) < uVar10) {
                    uVar12 = 0x1fffffffffffffff;
                } else {
                    uVar12 = (uVar10 >> 1) + uVar10;
                    if (uVar12 < iVar18 + 1U) {
                        uVar12 = iVar18 + 1U;
                    }
                }
                *(uint64_t *)(puVar15 + 0x20) = uVar12;
                *(undefined8 *)(puVar15 + -8) = 0x18001a379;
                ppiVar8 = (int64_t **)func_0x00018001ba60(uVar10, puVar15 + 0x20);
                var_c0h = (int64_t)(ppiVar8 + iVar18);
                ppiVar4 = (int64_t **)(var_c0h + 8);
                var_d8h = 0x180781fe0;
                var_c8h = *(int64_t *)(puVar15 + 0x20);
                *(int64_t **)var_c0h = piVar5;
                ppiVar7 = *(int64_t ***)0x180781fe8;
                ppiVar19 = ppiVar8;
                ppiVar11 = *(int64_t ***)0x180781fe0;
                var_b8h = (int64_t)ppiVar4;
                if (ppiVar17 == *(int64_t ***)0x180781fe8) {
                    for (; ppiVar11 != ppiVar7; ppiVar11 = ppiVar11 + 1) {
                        piVar5 = *ppiVar11;
                        *ppiVar11 = (int64_t *)0x0;
                        *ppiVar19 = piVar5;
                        ppiVar19 = ppiVar19 + 1;
                    }
                } else {
                    for (; ppiVar11 != ppiVar17; ppiVar11 = ppiVar11 + 1) {
                        piVar5 = *ppiVar11;
                        *ppiVar11 = (int64_t *)0x0;
                        *ppiVar19 = piVar5;
                        ppiVar19 = ppiVar19 + 1;
                    }
                    *(undefined8 *)(puVar15 + -8) = 0x18001a411;
                    func_0x00018001b830(ppiVar19, ppiVar19);
                    ppiVar11 = *(int64_t ***)0x180781fe8;
                    ppiVar19 = ppiVar4;
                    for (; var_c0h = (int64_t)ppiVar8, ppiVar17 != ppiVar11; ppiVar17 = ppiVar17 + 1) {
                        piVar5 = *ppiVar17;
                        *ppiVar17 = (int64_t *)0x0;
                        *ppiVar19 = piVar5;
                        ppiVar19 = ppiVar19 + 1;
                    }
                }
                *(undefined8 *)(puVar15 + -8) = 0x18001a442;
                func_0x00018001b830(ppiVar19, ppiVar19);
                var_d0h = 0;
                *(undefined8 *)(puVar15 + -8) = 0x18001a45a;
                func_0x00018001c0c0();
                *(undefined8 *)(puVar15 + -8) = 0x18001a463;
                func_0x00018001c010(&var_d8h);
                goto code_r0x00018001a464;
            }
            goto code_r0x00018001ae30;
        }
        **(int64_t ***)0x180781fe8 = piVar5;
        *(int64_t ***)0x180781fe8 = *(int64_t ***)0x180781fe8 + 1;
code_r0x00018001a464:
        *(undefined8 *)(puVar15 + -8) = 0x18001a46e;
        piVar5 = (int64_t *)fcn.180459890(8);
        *piVar5 = 0x180620558;
        ppiVar17 = *(int64_t ***)0x180781fe8;
        *(int64_t **)(puVar15 + 0x30) = piVar5;
        if (*(int64_t ***)0x180781fe8 == *(int64_t ***)0x180781ff0) {
            iVar18 = (int64_t)*(int64_t ***)0x180781fe8 - (int64_t)*(int64_t ***)0x180781fe0 >> 3;
            if (iVar18 != 0x1fffffffffffffff) {
                uVar10 = (int64_t)*(int64_t ***)0x180781ff0 - (int64_t)*(int64_t ***)0x180781fe0 >> 3;
                if (0x1fffffffffffffff - (uVar10 >> 1) < uVar10) goto code_r0x00018001ae5a;
                uVar12 = iVar18 + 1;
                uVar10 = (uVar10 >> 1) + uVar10;
                uVar6 = uVar12;
                if (uVar12 <= uVar10) {
                    uVar6 = uVar10;
                }
                if (0x1fffffffffffffff < uVar6) goto code_r0x00018001ae5a;
                uVar10 = uVar6 * 8;
                if (uVar10 == 0) {
                    ppiVar4 = (int64_t **)0x0;
                } else if (uVar10 < 0x1000) {
                    *(undefined8 *)(puVar15 + -8) = 0x18001a547;
                    ppiVar4 = (int64_t **)fcn.180459890();
                } else {
                    if (uVar10 + 0x27 <= uVar10) goto code_r0x00018001ae5a;
                    *(undefined8 *)(puVar15 + -8) = 0x18001a528;
                    piVar9 = (int64_t *)fcn.180459890(uVar10 + 0x27);
                    if (piVar9 == (int64_t *)0x0) {
                        pcVar2 = (code *)swi(0x29);
                        piVar9 = (int64_t *)(*pcVar2)(5);
                        puVar15 = puVar15 + 8;
                    }
                    ppiVar4 = (int64_t **)((int64_t)piVar9 + 0x27U & 0xffffffffffffffe0);
                    ppiVar4[-1] = piVar9;
                }
                var_c0h = (int64_t)(ppiVar4 + iVar18);
                var_b8h = var_c0h + 8;
                var_d8h = 0x180781fe0;
                *(int64_t **)var_c0h = piVar5;
                ppiVar7 = *(int64_t ***)0x180781fe8;
                ppiVar19 = ppiVar4;
                ppiVar11 = *(int64_t ***)0x180781fe0;
                if (ppiVar17 == *(int64_t ***)0x180781fe8) {
                    for (; ppiVar11 != ppiVar7; ppiVar11 = ppiVar11 + 1) {
                        piVar5 = *ppiVar11;
                        *ppiVar11 = (int64_t *)0x0;
                        *ppiVar19 = piVar5;
                        ppiVar19 = ppiVar19 + 1;
                    }
                } else {
                    for (; ppiVar8 = (int64_t **)var_b8h, *(int64_t ***)0x180781fe8 = ppiVar7, ppiVar11 != ppiVar17;
                        ppiVar11 = ppiVar11 + 1) {
                        piVar5 = *ppiVar11;
                        *ppiVar11 = (int64_t *)0x0;
                        *ppiVar19 = piVar5;
                        ppiVar19 = ppiVar19 + 1;
                        ppiVar7 = *(int64_t ***)0x180781fe8;
                    }
                    for (; var_c0h = (int64_t)ppiVar4, ppiVar17 != ppiVar7; ppiVar17 = ppiVar17 + 1) {
                        piVar5 = *ppiVar17;
                        *ppiVar17 = (int64_t *)0x0;
                        *ppiVar8 = piVar5;
                        ppiVar8 = ppiVar8 + 1;
                    }
                }
                var_d0h = 0;
                *(undefined8 *)(puVar15 + -8) = 0x18001a608;
                var_c8h = uVar6;
                func_0x00018001c0c0(ppiVar11, ppiVar4, uVar12);
                *(undefined8 *)(puVar15 + -8) = 0x18001a611;
                func_0x00018001c010(&var_d8h);
                goto code_r0x00018001a612;
            }
            goto code_r0x00018001ae36;
        }
        **(int64_t ***)0x180781fe8 = piVar5;
        *(int64_t ***)0x180781fe8 = *(int64_t ***)0x180781fe8 + 1;
code_r0x00018001a612:
        *(undefined8 *)(puVar15 + -8) = 0x18001a61c;
        piVar5 = (int64_t *)fcn.180459890(8);
        *piVar5 = 0x1806204f8;
        ppiVar17 = *(int64_t ***)0x180781fe8;
        *(int64_t **)(puVar15 + 0x30) = piVar5;
        if (*(int64_t ***)0x180781fe8 == *(int64_t ***)0x180781ff0) {
            iVar18 = (int64_t)*(int64_t ***)0x180781fe8 - (int64_t)*(int64_t ***)0x180781fe0 >> 3;
            if (iVar18 != 0x1fffffffffffffff) {
                uVar12 = (int64_t)*(int64_t ***)0x180781ff0 - (int64_t)*(int64_t ***)0x180781fe0 >> 3;
                uVar10 = 0x1fffffffffffffff;
                if ((uVar12 <= 0x1fffffffffffffff - (uVar12 >> 1)) &&
                   (uVar10 = (uVar12 >> 1) + uVar12, uVar10 < iVar18 + 1U)) {
                    uVar10 = iVar18 + 1U;
                }
                *(uint64_t *)(puVar15 + 0x20) = uVar10;
                *(undefined8 *)(puVar15 + -8) = 0x18001a6a5;
                ppiVar8 = (int64_t **)func_0x00018001ba60(uVar12, puVar15 + 0x20);
                var_c0h = (int64_t)(ppiVar8 + iVar18);
                ppiVar4 = (int64_t **)(var_c0h + 8);
                var_d8h = 0x180781fe0;
                var_c8h = *(int64_t *)(puVar15 + 0x20);
                *(int64_t **)var_c0h = piVar5;
                ppiVar7 = *(int64_t ***)0x180781fe8;
                ppiVar19 = ppiVar8;
                ppiVar11 = *(int64_t ***)0x180781fe0;
                var_b8h = (int64_t)ppiVar4;
                if (ppiVar17 == *(int64_t ***)0x180781fe8) {
                    for (; ppiVar11 != ppiVar7; ppiVar11 = ppiVar11 + 1) {
                        piVar5 = *ppiVar11;
                        *ppiVar11 = (int64_t *)0x0;
                        *ppiVar19 = piVar5;
                        ppiVar19 = ppiVar19 + 1;
                    }
                } else {
                    for (; ppiVar11 != ppiVar17; ppiVar11 = ppiVar11 + 1) {
                        piVar5 = *ppiVar11;
                        *ppiVar11 = (int64_t *)0x0;
                        *ppiVar19 = piVar5;
                        ppiVar19 = ppiVar19 + 1;
                    }
                    *(undefined8 *)(puVar15 + -8) = 0x18001a741;
                    func_0x00018001b830(ppiVar19, ppiVar19);
                    ppiVar11 = *(int64_t ***)0x180781fe8;
                    ppiVar19 = ppiVar4;
                    for (; var_c0h = (int64_t)ppiVar8, ppiVar17 != ppiVar11; ppiVar17 = ppiVar17 + 1) {
                        piVar5 = *ppiVar17;
                        *ppiVar17 = (int64_t *)0x0;
                        *ppiVar19 = piVar5;
                        ppiVar19 = ppiVar19 + 1;
                    }
                }
                *(undefined8 *)(puVar15 + -8) = 0x18001a772;
                func_0x00018001b830(ppiVar19, ppiVar19);
                var_d0h = 0;
                *(undefined8 *)(puVar15 + -8) = 0x18001a787;
                func_0x00018001c0c0();
                *(undefined8 *)(puVar15 + -8) = 0x18001a790;
                func_0x00018001c010(&var_d8h);
                goto code_r0x00018001a791;
            }
            goto code_r0x00018001ae3c;
        }
        **(int64_t ***)0x180781fe8 = piVar5;
        *(int64_t ***)0x180781fe8 = *(int64_t ***)0x180781fe8 + 1;
code_r0x00018001a791:
        piVar5 = (int64_t *)0x0;
        *(undefined8 *)(puVar15 + -8) = 0x18001a79b;
        piVar9 = (int64_t *)fcn.180459890(8);
        *piVar9 = 0x180620630;
        *(int64_t **)(puVar15 + 0x20) = piVar9;
        if (*(int64_t ***)0x180781fe8 == *(int64_t ***)0x180781ff0) {
            *(undefined8 *)(puVar15 + -8) = 0x18001a7d4;
            func_0x00018001b870(0x180620630, *(int64_t ***)0x180781fe8, puVar15 + 0x20);
            piVar9 = *(int64_t **)(puVar15 + 0x20);
        } else {
            **(int64_t ***)0x180781fe8 = piVar9;
            *(int64_t ***)0x180781fe8 = *(int64_t ***)0x180781fe8 + 1;
            piVar9 = piVar5;
        }
        if (piVar9 != (int64_t *)0x0) {
            *(undefined8 *)(puVar15 + -8) = 0x18001a7e8;
            func_0x000180459c3c(piVar9, 8);
        }
        *(undefined8 *)(puVar15 + -8) = 0x18001a7f2;
        piVar9 = (int64_t *)fcn.180459890(8);
        *piVar9 = 0x180620588;
        *(int64_t **)(puVar15 + 0x20) = piVar9;
        if (*(int64_t ***)0x180781fe8 == *(int64_t ***)0x180781ff0) {
            *(undefined8 *)(puVar15 + -8) = 0x18001a82b;
            func_0x00018001b870(0x180620588, *(int64_t ***)0x180781fe8, puVar15 + 0x20);
            piVar9 = *(int64_t **)(puVar15 + 0x20);
        } else {
            **(int64_t ***)0x180781fe8 = piVar9;
            *(int64_t ***)0x180781fe8 = *(int64_t ***)0x180781fe8 + 1;
            piVar9 = piVar5;
        }
        if (piVar9 != (int64_t *)0x0) {
            *(undefined8 *)(puVar15 + -8) = 0x18001a83f;
            func_0x000180459c3c(piVar9, 8);
        }
        *(undefined8 *)(puVar15 + -8) = 0x18001a849;
        piVar9 = (int64_t *)fcn.180459890(8);
        *piVar9 = 0x1806205b8;
        *(int64_t **)(puVar15 + 0x20) = piVar9;
        if (*(int64_t ***)0x180781fe8 == *(int64_t ***)0x180781ff0) {
            *(undefined8 *)(puVar15 + -8) = 0x18001a882;
            func_0x00018001b870(0x1806205b8, *(int64_t ***)0x180781fe8, puVar15 + 0x20);
            piVar9 = *(int64_t **)(puVar15 + 0x20);
        } else {
            **(int64_t ***)0x180781fe8 = piVar9;
            *(int64_t ***)0x180781fe8 = *(int64_t ***)0x180781fe8 + 1;
            piVar9 = piVar5;
        }
        if (piVar9 != (int64_t *)0x0) {
            *(undefined8 *)(puVar15 + -8) = 0x18001a896;
            func_0x000180459c3c(piVar9, 8);
        }
        *(undefined8 *)(puVar15 + -8) = 0x18001a8a0;
        piVar9 = (int64_t *)fcn.180459890(8);
        *piVar9 = 0x180620660;
        *(int64_t **)(puVar15 + 0x20) = piVar9;
        if (*(int64_t ***)0x180781fe8 == *(int64_t ***)0x180781ff0) {
            *(undefined8 *)(puVar15 + -8) = 0x18001a8d9;
            func_0x00018001b870(0x180620660, *(int64_t ***)0x180781fe8, puVar15 + 0x20);
            piVar9 = *(int64_t **)(puVar15 + 0x20);
        } else {
            **(int64_t ***)0x180781fe8 = piVar9;
            *(int64_t ***)0x180781fe8 = *(int64_t ***)0x180781fe8 + 1;
            piVar9 = piVar5;
        }
        if (piVar9 != (int64_t *)0x0) {
            *(undefined8 *)(puVar15 + -8) = 0x18001a8ed;
            func_0x000180459c3c(piVar9, 8);
        }
        *(undefined8 *)(puVar15 + -8) = 0x18001a8f7;
        ppiVar4 = (int64_t **)func_0x00018001b270(puVar15 + 0x20);
        ppiVar17 = *(int64_t ***)0x180781fe8;
        if (*(int64_t ***)0x180781fe8 == *(int64_t ***)0x180781ff0) {
            *(undefined8 *)(puVar15 + -8) = 0x18001a923;
            func_0x00018001b870();
        } else {
            piVar9 = *ppiVar4;
            *ppiVar4 = (int64_t *)0x0;
            *ppiVar17 = piVar9;
            *(int64_t ***)0x180781fe8 = *(int64_t ***)0x180781fe8 + 1;
        }
        if (*(int64_t *)(puVar15 + 0x20) != 0) {
            *(undefined8 *)(puVar15 + -8) = 0x18001a938;
            func_0x000180459c3c(*(int64_t *)(puVar15 + 0x20), 8);
        }
        *(undefined8 *)(puVar15 + -8) = 0x18001a942;
        piVar9 = (int64_t *)fcn.180459890(8);
        *piVar9 = 0x1806205e8;
        *(int64_t **)(puVar15 + 0x20) = piVar9;
        if (*(int64_t ***)0x180781fe8 == *(int64_t ***)0x180781ff0) {
            *(undefined8 *)(puVar15 + -8) = 0x18001a97d;
            func_0x00018001b870(0x1806205e8, *(int64_t ***)0x180781fe8, puVar15 + 0x20);
        } else {
            *(undefined8 *)(puVar15 + 0x20) = 0;
            **(int64_t ***)0x180781fe8 = piVar9;
            *(int64_t ***)0x180781fe8 = *(int64_t ***)0x180781fe8 + 1;
        }
        *(undefined8 *)(puVar15 + -8) = 0x18001a988;
        func_0x000180005a40(puVar15 + 0x20);
        *(undefined8 *)(puVar15 + -8) = 0x18001a992;
        func_0x00018001b2a0(puVar15 + 0x20);
        *(undefined8 *)(puVar15 + -8) = 0x18001a99b;
        func_0x00018001b200();
        *(undefined8 *)(puVar15 + -8) = 0x18001a9a6;
        func_0x000180005a40(puVar15 + 0x20);
        *(undefined8 *)(puVar15 + -8) = 0x18001a9b0;
        func_0x00018001b2d0(puVar15 + 0x20);
        *(undefined8 *)(puVar15 + -8) = 0x18001a9b9;
        func_0x00018001b200();
        *(undefined8 *)(puVar15 + -8) = 0x18001a9c4;
        func_0x000180005a40(puVar15 + 0x20);
        *(undefined8 *)(puVar15 + -8) = 0x18001a9ce;
        func_0x00018001b300(puVar15 + 0x20);
        *(undefined8 *)(puVar15 + -8) = 0x18001a9d7;
        func_0x00018001b200();
        *(undefined8 *)(puVar15 + -8) = 0x18001a9e2;
        func_0x000180005a40(puVar15 + 0x20);
        *(undefined8 *)(puVar15 + -8) = 0x18001a9ec;
        func_0x00018001b330(puVar15 + 0x20);
        *(undefined8 *)(puVar15 + -8) = 0x18001a9f5;
        func_0x00018001b200();
        *(undefined8 *)(puVar15 + -8) = 0x18001aa00;
        func_0x000180005a40(puVar15 + 0x20);
        *(undefined8 *)(puVar15 + -8) = 0x18001aa0a;
        func_0x00018001b360(puVar15 + 0x20);
        *(undefined8 *)(puVar15 + -8) = 0x18001aa13;
        func_0x00018001b200();
        *(undefined8 *)(puVar15 + -8) = 0x18001aa1e;
        func_0x000180005a40(puVar15 + 0x20);
        *(undefined8 *)(puVar15 + -8) = 0x18001aa2b;
        func_0x000180086fd0(arg2, 0, 0);
        ppiVar4 = *(int64_t ***)0x180781fe8;
        for (ppiVar17 = *(int64_t ***)0x180781fe0; ppiVar17 != ppiVar4; ppiVar17 = ppiVar17 + 1) {
            piVar9 = *ppiVar17;
            pcVar2 = *(code **)*piVar9;
            *(undefined8 *)(puVar15 + -8) = 0x18001aa4b;
            (*pcVar2)(piVar9, arg2);
        }
        *(undefined8 *)(puVar15 + -8) = 0x18001aa68;
        func_0x000180086cc0(arg2, 0xffffd8ee, 0x1805aaed0);
        iVar18 = *(int64_t *)(arg2 + 0x40);
        ppiVar17 = (int64_t **)(iVar18 + -0x10);
        if ((ppiVar17 != *(int64_t ***)0x180782430) && (*(int32_t *)(iVar18 + -4) == 0)) {
            *(int64_t ***)(arg2 + 0x40) = ppiVar17;
            goto code_r0x00018001aa83;
        }
        if (*(int32_t *)(iVar18 + -4) == 9) {
            piVar5 = *ppiVar17 + 2;
        } else if (*(int32_t *)(iVar18 + -4) == 2) {
            piVar5 = *ppiVar17;
        }
        if (piVar5[1] != 0) {
            LOCK();
            piVar1 = (int32_t *)(piVar5[1] + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        iVar18 = *piVar5;
        *(int64_t *)(puVar15 + 0x30) = iVar18;
        piVar5 = (int64_t *)piVar5[1];
        *(int64_t **)(puVar15 + 0x38) = piVar5;
        if (iVar18 == 0) {
            *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
code_r0x00018001adc9:
            if (piVar5 != (int64_t *)0x0) {
                LOCK();
                piVar9 = piVar5 + 1;
                iVar3 = *(int32_t *)piVar9;
                *(int32_t *)piVar9 = *(int32_t *)piVar9 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    pcVar2 = *(code **)*piVar5;
                    *(undefined8 *)(puVar15 + -8) = 0x18001adea;
                    (*pcVar2)(piVar5);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
                    iVar3 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar3 == 1) {
                        pcVar2 = *(code **)(*piVar5 + 8);
                        *(undefined8 *)(puVar15 + -8) = 0x18001ae01;
                        (*pcVar2)(piVar5);
                    }
                }
            }
code_r0x00018001aa83:
            *(undefined8 *)(puVar15 + -8) = 0x18001aa8f;
            func_0x000180459870(var_58h ^ (uint64_t)puVar15);
            return;
        }
        if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
            *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
            *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
        }
        if ((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg2 + 0x40) + 0x10U <= **(uint64_t **)(arg2 + 0x18))) {
code_r0x00018001ab3f:
            piVar9 = *(int64_t **)(arg2 + 0x40);
            iVar3 = *(int32_t *)((int64_t)piVar9 + -4);
            if (iVar3 == 7) {
                iVar18 = *(int64_t *)(piVar9[-2] + 0x10);
            } else if (iVar3 == 9) {
                iVar18 = *(int64_t *)(piVar9[-2] + 8) + (int64_t)(int64_t *)(piVar9[-2] + 8);
            } else if (iVar3 == 0xd) {
                iVar18 = *(int64_t *)(*(int64_t *)(piVar9[-2] + 0x10) + 0x38);
            } else {
                iVar18 = *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x440 + (int64_t)iVar3 * 8);
            }
            if (iVar18 != 0) {
                *piVar9 = iVar18;
                *(undefined4 *)((int64_t)piVar9 + 0xc) = 7;
                piVar9 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + 0x10);
                *(int64_t **)(arg2 + 0x40) = piVar9;
            }
            if (((int64_t **)(piVar9 + -2) == *(int64_t ***)0x180782430) || (*(int32_t *)((int64_t)piVar9 + -4) != 0)) {
                *(undefined8 *)(puVar15 + -8) = 0x18001abd6;
                func_0x000180086cc0(arg2, 0xffffffff, 0x1805aae90);
                *(undefined8 *)(puVar15 + -8) = 0x18001abe0;
                iVar3 = func_0x000180085cd0(arg2, 0xffffffff);
                if (iVar3 != 0) {
                    *(undefined8 *)(puVar15 + -8) = 0x18001abf2;
                    piVar9 = (int64_t *)fcn.180085430(arg2, 0xffffffff);
                    *(undefined8 *)0x180781ef8 = *(undefined8 *)(*piVar9 + 0x20);
                    *(code **)(*piVar9 + 0x20) = fcn.180018ff0;
                    *(undefined8 *)(puVar15 + -8) = 0x18001ac18;
                    func_0x0001800858c0(arg2, 0xfffffffe);
                    *(undefined8 *)(puVar15 + -8) = 0x18001ac29;
                    func_0x000180086cc0(arg2, 0xffffffff, 0x1806203c0);
                    *(undefined8 *)(puVar15 + -8) = 0x18001ac33;
                    iVar3 = func_0x000180085cd0(arg2, 0xffffffff);
                    if (iVar3 != 0) {
                        *(undefined8 *)(puVar15 + -8) = 0x18001ac45;
                        piVar9 = (int64_t *)fcn.180085430(arg2, 0xffffffff);
                        *(undefined8 *)0x180781f00 = *(undefined8 *)(*piVar9 + 0x20);
                        *(code **)(*piVar9 + 0x20) = fcn.180019690;
                        *(undefined8 *)(puVar15 + -8) = 0x18001ac6b;
                        func_0x0001800858c0(arg2, 0xfffffffe);
                        *(undefined8 *)(puVar15 + -8) = 0x18001ac7c;
                        func_0x000180086cc0(arg2, 0xffffffff, 0x1806203d0);
                        *(undefined8 *)(puVar15 + -8) = 0x18001ac86;
                        iVar3 = func_0x000180085cd0(arg2, 0xffffffff);
                        if (iVar3 != 0) {
                            *(undefined8 *)(puVar15 + -8) = 0x18001ac98;
                            piVar9 = (int64_t *)fcn.180085430(arg2, 0xffffffff);
                            *(undefined8 *)0x180781ef0 = *(undefined8 *)(*piVar9 + 0x20);
                            *(code **)(*piVar9 + 0x20) = fcn.1800194d0;
                            *(undefined8 *)(puVar15 + -8) = 0x18001acbe;
                            func_0x0001800858c0(arg2, 0xfffffffe);
                            *(undefined8 *)(puVar15 + -8) = 0x18001accb;
                            func_0x0001800858c0(arg2, 0xfffffffd);
                            *(undefined8 *)(puVar15 + -8) = 0x18001acd8;
                            func_0x000180086fd0(arg2, 0, 0);
                            *(undefined8 *)(puVar15 + -8) = 0x18001acec;
                            func_0x000180087370(arg2, 0xfffffffe, 0x1806203dc);
                            *(undefined8 *)(puVar15 + -8) = 0x18001acf9;
                            func_0x000180086fd0(arg2, 0, 0);
                            *(undefined8 *)(puVar15 + -8) = 0x18001ad0d;
                            func_0x000180087370(arg2, 0xfffffffe, 0x1806203e0);
                            *(undefined8 *)(puVar15 + -8) = 0x18001ad1a;
                            func_0x000180086fd0(arg2, 0, 0);
                            *(undefined8 *)(puVar15 + -8) = 0x18001ad27;
                            func_0x000180085bf0(arg2, 0xffffd8ee);
                            *(undefined8 *)(puVar15 + -8) = 0x18001ad3b;
                            func_0x000180087370(arg2, 0xfffffffe, 0x1805aae90);
                            *(undefined8 *)(puVar15 + -8) = 0x18001ad4b;
                            func_0x0001800870a0(arg2, 0xffffffff, 1);
                            *(undefined8 *)(puVar15 + -8) = 0x18001ad58;
                            func_0x000180087650(arg2, 0xfffffffe);
                            *(undefined8 *)(puVar15 + -8) = 0x18001ad6c;
                            func_0x000180087370(arg2, 0xffffd8f0, 0x1805aae80);
                            var_60h = 0;
                            *(undefined8 *)(puVar15 + -8) = 0x18001ad7f;
                            uVar13 = func_0x00018000a260(puVar15 + 0x20, puVar15 + 0x30);
                            *(undefined8 *)(puVar15 + -8) = 0x18001ad8c;
                            func_0x00018001b390(&var_d8h, uVar13);
                            *(undefined8 *)(puVar15 + -8) = 0x18001ad9a;
                            func_0x000180014540(&var_d8h, &var_98h);
                            *(undefined8 *)(puVar15 + -8) = 0x18001ada4;
                            func_0x000180013d00(&var_d8h);
                            *(undefined8 *)(puVar15 + -8) = 0x18001adaf;
                            func_0x00018001ae60(puVar15 + 0x20);
                            *(undefined8 *)(puVar15 + -8) = 0x18001adb9;
                            func_0x000180013d00(&var_98h);
                            goto code_r0x00018001adc9;
                        }
                    }
                }
                uVar13 = 0xfffffffc;
            } else {
                uVar13 = 0xfffffffd;
            }
            *(undefined8 *)(puVar15 + -8) = 0x18001adc8;
            func_0x0001800858c0(arg2, uVar13);
            goto code_r0x00018001adc9;
        }
        *(undefined8 *)(puVar15 + -8) = 0x18001ab37;
        iVar3 = func_0x000180085510(arg2, 1);
        if (iVar3 != 0) goto code_r0x00018001ab3f;
    }
    *(undefined8 *)(puVar15 + -8) = 0x18001ae51;
    func_0x000180099450(arg2, 0x18063d8d0);
    *(undefined8 *)(puVar15 + -8) = 0x18001ae59;
    func_0x000180087960(arg2);
code_r0x00018001ae5a:
    *(undefined8 *)(puVar15 + -8) = 0x18001ae5f;
    fcn.180004720();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_18001ae60
// Address: 0x18001ae60
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001ae60(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    piVar4 = *(int64_t **)(arg1 + 8);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001ae6f
// Address: 0x18001ae6f
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001ae60(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    piVar4 = *(int64_t **)(arg1 + 8);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001aea5
// Address: 0x18001aea5
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001ae60(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    piVar4 = *(int64_t **)(arg1 + 8);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001aeb0
// Address: 0x18001aeb0
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18001aeb0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (arg3 != 0) {
        uVar5 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
        uVar2 = 0x18001afa0;
        if ((char)arg_30h == '\0') {
            uVar2 = 0;
        }
        func_0x0001800869f0(arg2, arg3, arg4, 0, uVar2);
        func_0x000180087370(arg2, uVar5 & 0xffffffff, arg4);
        puVar1 = *(undefined8 **)(arg_28h + 8);
        puVar4 = *(undefined8 **)arg_28h;
        if ((int64_t)puVar1 - (int64_t)puVar4 >> 3 != 0) {
            for (; puVar4 != puVar1; puVar4 = puVar4 + 1) {
                func_0x000180086cc0(arg2, uVar5 & 0xffffffff, arg4);
                iVar3 = *(int64_t *)(arg2 + 0x40) + -0x10;
                if ((iVar3 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
                    func_0x000180087370(arg2, uVar5 & 0xffffffff, *puVar4);
                } else {
                    *(int64_t *)(arg2 + 0x40) = iVar3;
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001aec6
// Address: 0x18001aec6
// Size: 212 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18001aeb0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (arg3 != 0) {
        uVar5 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
        uVar2 = 0x18001afa0;
        if ((char)arg_30h == '\0') {
            uVar2 = 0;
        }
        func_0x0001800869f0(arg2, arg3, arg4, 0, uVar2);
        func_0x000180087370(arg2, uVar5 & 0xffffffff, arg4);
        puVar1 = *(undefined8 **)(arg_28h + 8);
        puVar4 = *(undefined8 **)arg_28h;
        if ((int64_t)puVar1 - (int64_t)puVar4 >> 3 != 0) {
            for (; puVar4 != puVar1; puVar4 = puVar4 + 1) {
                func_0x000180086cc0(arg2, uVar5 & 0xffffffff, arg4);
                iVar3 = *(int64_t *)(arg2 + 0x40) + -0x10;
                if ((iVar3 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
                    func_0x000180087370(arg2, uVar5 & 0xffffffff, *puVar4);
                } else {
                    *(int64_t *)(arg2 + 0x40) = iVar3;
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001af9a
// Address: 0x18001af9a
// Size: 1 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18001aeb0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (arg3 != 0) {
        uVar5 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
        uVar2 = 0x18001afa0;
        if ((char)arg_30h == '\0') {
            uVar2 = 0;
        }
        func_0x0001800869f0(arg2, arg3, arg4, 0, uVar2);
        func_0x000180087370(arg2, uVar5 & 0xffffffff, arg4);
        puVar1 = *(undefined8 **)(arg_28h + 8);
        puVar4 = *(undefined8 **)arg_28h;
        if ((int64_t)puVar1 - (int64_t)puVar4 >> 3 != 0) {
            for (; puVar4 != puVar1; puVar4 = puVar4 + 1) {
                func_0x000180086cc0(arg2, uVar5 & 0xffffffff, arg4);
                iVar3 = *(int64_t *)(arg2 + 0x40) + -0x10;
                if ((iVar3 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
                    func_0x000180087370(arg2, uVar5 & 0xffffffff, *puVar4);
                } else {
                    *(int64_t *)(arg2 + 0x40) = iVar3;
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001afc0
// Address: 0x18001afc0
// Size: 373 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h

void fcn.18001afc0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t *piVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined8 *puVar7;
    undefined4 *puVar8;
    int64_t iVar9;
    int64_t var_58h;
    
    func_0x000180086ba0(arg2, arg3, 0);
    if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
        *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
        *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
    }
    puVar7 = (undefined8 *)fcn.180085370(arg2, 0xffffd8f0);
    iVar9 = *(int64_t *)(arg2 + 0x40);
    puVar8 = (undefined4 *)func_0x0001800a0ea0(*puVar7, iVar9 + -0x10);
    uVar3 = puVar8[1];
    uVar4 = puVar8[2];
    uVar5 = puVar8[3];
    *(undefined4 *)(iVar9 + -0x10) = *puVar8;
    *(undefined4 *)(iVar9 + -0xc) = uVar3;
    *(undefined4 *)(iVar9 + -8) = uVar4;
    *(undefined4 *)(iVar9 + -4) = uVar5;
    iVar9 = *(int64_t *)(arg2 + 0x40) + -0x10;
    if ((iVar9 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) < 1)) {
        *(int64_t *)(arg2 + 0x40) = iVar9;
        func_0x0001800869f0(arg2, arg3, arg4, 0, 0);
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U)) {
            iVar6 = func_0x000180085510(arg2, 1);
            if (iVar6 == 0) goto code_r0x00018001b11d;
        }
        piVar1 = *(int64_t **)(arg2 + 0x40);
        *piVar1 = arg3;
        *(undefined4 *)(piVar1 + 1) = 0;
        *(undefined4 *)((int64_t)piVar1 + 0xc) = 2;
        *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
        if ((*(uint8_t *)(arg2 + 1) & 4) != 0) {
            *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfb;
            *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(*(int64_t *)(arg2 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) = arg2;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg2 + 0x18) < *(int64_t *)(arg2 + 0x40) + 0x10U)) {
            iVar6 = func_0x000180085510(arg2, 1);
            if (iVar6 == 0) {
code_r0x00018001b11d:
                func_0x000180099450(arg2, 0x18063d8d0);
                func_0x000180087960(arg2);
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
        }
        puVar8 = *(undefined4 **)(arg2 + 0x40);
        *puVar8 = puVar8[-8];
        puVar8[1] = puVar8[-7];
        puVar8[2] = puVar8[-6];
        puVar8[3] = puVar8[-5];
        *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + 0x10;
        func_0x000180087440(arg2, 0xffffd8f0);
    }
    return;
}

// ============================================================
// Function: FUN_18001b140
// Address: 0x18001b140
// Size: 143 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18001b140(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    var_8h = **(int64_t **)0x180782608;
    var_10h = arg2;
    if (var_8h == 0) {
        var_8h = (**(code **)0x180782578)();
    }
    piVar1 = (int64_t *)(**(code **)0x180782660)(var_8h + 0x50, &var_10h);
    if (piVar1 == (int64_t *)0x0) {
        var_8h = var_8h + 0x80;
    } else {
        var_8h = *piVar1;
    }
    if (*(int32_t *)(arg1 + 0x250) != 0) {
        puVar2 = (undefined8 *)(**(code **)0x180782580)((int32_t *)(arg1 + 0x250), &var_8h);
        if ((puVar2 != (undefined8 *)0x0) && (*(int32_t *)(puVar2 + 1) == 0)) {
            return *puVar2;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18001b1d0
// Address: 0x18001b1d0
// Size: 41 bytes
// ============================================================
int64_t fcn.18001b1d0(int64_t arg1)
{
    undefined8 *puVar1;
    
    puVar1 = (undefined8 *)fcn.180459890(8);
    *puVar1 = 0x180620648;
    *(undefined8 **)arg1 = puVar1;
    return arg1;
}

// ============================================================
// Function: FUN_18001b240
// Address: 0x18001b240
// Size: 41 bytes
// ============================================================
int64_t fcn.18001b240(int64_t arg1)
{
    undefined8 *puVar1;
    
    puVar1 = (undefined8 *)fcn.180459890(8);
    *puVar1 = 0x1806204b0;
    *(undefined8 **)arg1 = puVar1;
    return arg1;
}

// ============================================================
// Function: FUN_18001b270
// Address: 0x18001b270
// Size: 41 bytes
// ============================================================
int64_t fcn.18001b270(int64_t arg1)
{
    undefined8 *puVar1;
    
    puVar1 = (undefined8 *)fcn.180459890(8);
    *puVar1 = 0x1806205a0;
    *(undefined8 **)arg1 = puVar1;
    return arg1;
}

// ============================================================
// Function: FUN_18001b2a0
// Address: 0x18001b2a0
// Size: 41 bytes
// ============================================================
int64_t fcn.18001b2a0(int64_t arg1)
{
    undefined8 *puVar1;
    
    puVar1 = (undefined8 *)fcn.180459890(8);
    *puVar1 = 0x180620570;
    *(undefined8 **)arg1 = puVar1;
    return arg1;
}

// ============================================================
// Function: FUN_18001b2d0
// Address: 0x18001b2d0
// Size: 41 bytes
// ============================================================
int64_t fcn.18001b2d0(int64_t arg1)
{
    undefined8 *puVar1;
    
    puVar1 = (undefined8 *)fcn.180459890(8);
    *puVar1 = 0x180620528;
    *(undefined8 **)arg1 = puVar1;
    return arg1;
}

// ============================================================
// Function: FUN_18001b300
// Address: 0x18001b300
// Size: 41 bytes
// ============================================================
int64_t fcn.18001b300(int64_t arg1)
{
    undefined8 *puVar1;
    
    puVar1 = (undefined8 *)fcn.180459890(8);
    *puVar1 = 0x180620540;
    *(undefined8 **)arg1 = puVar1;
    return arg1;
}

// ============================================================
// Function: FUN_18001b330
// Address: 0x18001b330
// Size: 41 bytes
// ============================================================
int64_t fcn.18001b330(int64_t arg1)
{
    undefined8 *puVar1;
    
    puVar1 = (undefined8 *)fcn.180459890(8);
    *puVar1 = 0x180620480;
    *(undefined8 **)arg1 = puVar1;
    return arg1;
}

// ============================================================
// Function: FUN_18001b360
// Address: 0x18001b360
// Size: 41 bytes
// ============================================================
int64_t fcn.18001b360(int64_t arg1)
{
    undefined8 *puVar1;
    
    puVar1 = (undefined8 *)fcn.180459890(8);
    *puVar1 = 0x180620600;
    *(undefined8 **)arg1 = puVar1;
    return arg1;
}

// ============================================================
// Function: FUN_18001b490
// Address: 0x18001b490
// Size: 35 bytes
// ============================================================
void fcn.18001b490(int64_t arg1)
{
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t in_stack_00000008;
    
    fcn.18001bbf0(in_stack_00000008);
    if ((*(int64_t *)arg1 != 0) &&
       (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)arg1, in_R9, unaff_RBX), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar1 = (undefined4 *)fcn.18046b77c();
        *puVar1 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_18001b4c0
// Address: 0x18001b4c0
// Size: 81 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001b4c0(int64_t arg1)
{
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        fcn.18001bbf0(var_8h);
        *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
        *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(arg1 + 0x10) = 0;
        var_8h = *(int64_t *)(arg1 + 8);
        fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
    }
    return;
}

// ============================================================
// Function: FUN_18001b520
// Address: 0x18001b520
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001b520(void)
{
    int64_t *piVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t var_8h;
    
    ppiVar2 = *(int64_t ***)0x180781fe8;
    ppiVar3 = *(int64_t ***)0x180781fe0;
    if (*(int64_t ***)0x180781fe0 != *(int64_t ***)0x180781fe8) {
        do {
            piVar1 = *ppiVar3;
            if (piVar1 != (int64_t *)0x0) {
                (**(code **)(*piVar1 + 0x10))(piVar1, 1);
            }
            ppiVar3 = ppiVar3 + 1;
        } while (ppiVar3 != ppiVar2);
        *(int64_t ***)0x180781fe8 = *(int64_t ***)0x180781fe0;
    }
    return;
}

// ============================================================
// Function: FUN_18001b580
// Address: 0x18001b580
// Size: 31 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018001b5b8: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018001b5bd)
// WARNING: Removing unreachable block (ram,0x00018001b5c5)
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001b580(int64_t arg1, int64_t arg_30h)
{
    int64_t *piVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    undefined8 *puVar5;
    undefined8 unaff_RBX;
    int64_t var_8h;
    undefined8 auStack_30 [5];
    
    piVar1 = *(int64_t **)arg1;
    *(undefined8 *)piVar1[1] = 0;
    puVar5 = (undefined8 *)*piVar1;
    if (puVar5 == (undefined8 *)0x0) {
        puVar5 = *(undefined8 **)arg1;
    } else {
        unaff_RBX = *puVar5;
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
        auStack_30[0] = 0x18001b5bd;
    }
    if (puVar5 != (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, puVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001b59f
// Address: 0x18001b59f
// Size: 43 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018001b5b8: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018001b5bd)
// WARNING: Removing unreachable block (ram,0x00018001b5c5)
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001b580(int64_t arg1, int64_t arg_30h)
{
    int64_t *piVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    undefined8 *puVar5;
    undefined8 unaff_RBX;
    int64_t var_8h;
    undefined8 auStack_30 [5];
    
    piVar1 = *(int64_t **)arg1;
    *(undefined8 *)piVar1[1] = 0;
    puVar5 = (undefined8 *)*piVar1;
    if (puVar5 == (undefined8 *)0x0) {
        puVar5 = *(undefined8 **)arg1;
    } else {
        unaff_RBX = *puVar5;
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
        auStack_30[0] = 0x18001b5bd;
    }
    if (puVar5 != (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, puVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001b5ca
// Address: 0x18001b5ca
// Size: 18 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018001b5b8: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018001b5bd)
// WARNING: Removing unreachable block (ram,0x00018001b5c5)
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001b580(int64_t arg1, int64_t arg_30h)
{
    int64_t *piVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    undefined8 *puVar5;
    undefined8 unaff_RBX;
    int64_t var_8h;
    undefined8 auStack_30 [5];
    
    piVar1 = *(int64_t **)arg1;
    *(undefined8 *)piVar1[1] = 0;
    puVar5 = (undefined8 *)*piVar1;
    if (puVar5 == (undefined8 *)0x0) {
        puVar5 = *(undefined8 **)arg1;
    } else {
        unaff_RBX = *puVar5;
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
        auStack_30[0] = 0x18001b5bd;
    }
    if (puVar5 != (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, puVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001b5e0
// Address: 0x18001b5e0
// Size: 543 bytes
// ============================================================
undefined8 * fcn.18001b5e0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    undefined8 *puVar4;
    code *pcVar5;
    undefined8 *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined8 *puVar9;
    float fVar10;
    float fVar11;
    int64_t var_48h;
    int64_t var_40h;
    
    uVar8 = (((((((((uint64_t)*(uint8_t *)arg2 ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 1))
                  * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 2)) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 3)
                ) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 4)) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 5)
              ) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 6)) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 7))
            * 0x100000001b3;
    uVar7 = uVar8 & *(uint64_t *)(arg1 + 0x30);
    puVar6 = *(undefined8 **)(*(int64_t *)(arg1 + 0x18) + 8 + uVar7 * 0x10);
    piVar1 = (int64_t *)(arg1 + 8);
    puVar9 = (undefined8 *)*piVar1;
    if (puVar6 != (undefined8 *)*piVar1) {
        iVar2 = puVar6[2];
        while (*(int64_t *)arg2 != iVar2) {
            puVar9 = puVar6;
            if (puVar6 == *(undefined8 **)(*(int64_t *)(arg1 + 0x18) + uVar7 * 0x10)) goto code_r0x00018001b6ab;
            puVar6 = (undefined8 *)puVar6[1];
            iVar2 = puVar6[2];
        }
        goto code_r0x00018001b7e1;
    }
code_r0x00018001b6ab:
    if (*(int64_t *)(arg1 + 0x10) == 0x7ffffffffffffff) {
        func_0x0001804546d4(0x180620428);
        pcVar5 = (code *)swi(3);
        puVar6 = (undefined8 *)(*pcVar5)();
        return puVar6;
    }
    puVar6 = (undefined8 *)fcn.180459890(0x20);
    puVar6[2] = *(undefined8 *)arg2;
    *(undefined *)(puVar6 + 3) = 0;
    uVar7 = *(int64_t *)(arg1 + 0x10) + 1;
    if ((int64_t)uVar7 < 0) {
        fVar10 = (float)(uVar7 >> 1 | (uint64_t)((uint32_t)uVar7 & 1));
        fVar10 = fVar10 + fVar10;
    } else {
        fVar10 = (float)uVar7;
    }
    uVar7 = *(uint64_t *)(arg1 + 0x38);
    if ((int64_t)uVar7 < 0) {
        fVar11 = (float)(uVar7 >> 1 | (uint64_t)((uint32_t)uVar7 & 1));
        fVar11 = fVar11 + fVar11;
    } else {
        fVar11 = (float)uVar7;
    }
    if (*(float *)arg1 <= fVar10 / fVar11 && fVar10 / fVar11 != *(float *)arg1) {
        func_0x00018001bda0(arg1);
        uVar7 = uVar8 & *(uint64_t *)(arg1 + 0x30);
        puVar3 = *(undefined8 **)(*(int64_t *)(arg1 + 0x18) + 8 + uVar7 * 0x10);
        puVar9 = (undefined8 *)*piVar1;
        if (puVar3 != puVar9) {
            iVar2 = puVar3[2];
            puVar9 = puVar3;
            while (puVar6[2] != iVar2) {
                if (puVar9 == *(undefined8 **)(*(int64_t *)(arg1 + 0x18) + uVar7 * 0x10)) goto code_r0x00018001b792;
                puVar9 = (undefined8 *)puVar9[1];
                iVar2 = puVar9[2];
            }
            puVar9 = (undefined8 *)*puVar9;
        }
    }
code_r0x00018001b792:
    puVar3 = (undefined8 *)puVar9[1];
    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
    *puVar6 = puVar9;
    puVar6[1] = puVar3;
    *puVar3 = puVar6;
    puVar9[1] = puVar6;
    iVar2 = *(int64_t *)(arg1 + 0x18);
    uVar8 = *(uint64_t *)(arg1 + 0x30) & uVar8;
    puVar4 = *(undefined8 **)(iVar2 + uVar8 * 0x10);
    if (puVar4 == (undefined8 *)*piVar1) {
        *(undefined8 **)(iVar2 + uVar8 * 0x10) = puVar6;
    } else {
        if (puVar4 == puVar9) {
            *(undefined8 **)(iVar2 + uVar8 * 0x10) = puVar6;
            goto code_r0x00018001b7e1;
        }
        if (*(undefined8 **)(iVar2 + 8 + uVar8 * 0x10) != puVar3) goto code_r0x00018001b7e1;
    }
    *(undefined8 **)(iVar2 + 8 + uVar8 * 0x10) = puVar6;
code_r0x00018001b7e1:
    return puVar6 + 3;
}

