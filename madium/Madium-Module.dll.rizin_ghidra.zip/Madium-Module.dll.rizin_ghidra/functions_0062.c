// Chunk 62 - 50 functions

// ============================================================
// Function: FUN_1800c89d0
// Address: 0x1800c89d0
// Size: 25 bytes
// ============================================================
uint64_t fcn.1800c89d0(int64_t arg1, int64_t arg2, int64_t arg_68h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t unaff_RSI;
    uint64_t uVar3;
    int64_t unaff_RDI;
    uint64_t uVar4;
    int64_t var_8h;
    int64_t var_38h;
    int64_t var_30h;
    
    uVar3 = 0;
    if (*(int64_t *)(arg2 + 0x40) != 0) {
        do {
            piVar1 = (int64_t *)fcn.1800c7ec0(arg1, &var_38h, *(undefined8 *)(*(int64_t *)(arg2 + 0x38) + uVar3 * 8));
            uVar3 = uVar3 + 1;
            uVar2 = *(int64_t *)(arg1 + 0x40) + *piVar1;
            *(undefined8 *)(arg1 + 0x48) = 0;
            uVar4 = uVar2 & 0x8080808080808080;
            *(uint64_t *)(arg1 + 0x40) = uVar4 - (uVar4 >> 7) | uVar4 ^ uVar2;
        } while (uVar3 < *(uint64_t *)(arg2 + 0x40));
    }
    var_38h = 1;
    var_30h = 0;
    uVar3 = fcn.1800c86e0(unaff_RDI, unaff_RSI);
    return uVar3 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c89e9
// Address: 0x1800c89e9
// Size: 98 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800c89d0(int64_t arg1, int64_t arg2, int64_t arg_68h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t unaff_RSI;
    uint64_t uVar3;
    int64_t unaff_RDI;
    uint64_t uVar4;
    int64_t var_8h;
    int64_t var_38h;
    int64_t var_30h;
    
    uVar3 = 0;
    if (*(int64_t *)(arg2 + 0x40) != 0) {
        do {
            piVar1 = (int64_t *)fcn.1800c7ec0(arg1, &var_38h, *(undefined8 *)(*(int64_t *)(arg2 + 0x38) + uVar3 * 8));
            uVar3 = uVar3 + 1;
            uVar2 = *(int64_t *)(arg1 + 0x40) + *piVar1;
            *(undefined8 *)(arg1 + 0x48) = 0;
            uVar4 = uVar2 & 0x8080808080808080;
            *(uint64_t *)(arg1 + 0x40) = uVar4 - (uVar4 >> 7) | uVar4 ^ uVar2;
        } while (uVar3 < *(uint64_t *)(arg2 + 0x40));
    }
    var_38h = 1;
    var_30h = 0;
    uVar3 = fcn.1800c86e0(unaff_RDI, unaff_RSI);
    return uVar3 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c8a4b
// Address: 0x1800c8a4b
// Size: 48 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800c89d0(int64_t arg1, int64_t arg2, int64_t arg_68h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t unaff_RSI;
    uint64_t uVar3;
    int64_t unaff_RDI;
    uint64_t uVar4;
    int64_t var_8h;
    int64_t var_38h;
    int64_t var_30h;
    
    uVar3 = 0;
    if (*(int64_t *)(arg2 + 0x40) != 0) {
        do {
            piVar1 = (int64_t *)fcn.1800c7ec0(arg1, &var_38h, *(undefined8 *)(*(int64_t *)(arg2 + 0x38) + uVar3 * 8));
            uVar3 = uVar3 + 1;
            uVar2 = *(int64_t *)(arg1 + 0x40) + *piVar1;
            *(undefined8 *)(arg1 + 0x48) = 0;
            uVar4 = uVar2 & 0x8080808080808080;
            *(uint64_t *)(arg1 + 0x40) = uVar4 - (uVar4 >> 7) | uVar4 ^ uVar2;
        } while (uVar3 < *(uint64_t *)(arg2 + 0x40));
    }
    var_38h = 1;
    var_30h = 0;
    uVar3 = fcn.1800c86e0(unaff_RDI, unaff_RSI);
    return uVar3 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c8a80
// Address: 0x1800c8a80
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined fcn.1800c8a80(int64_t arg1, int64_t arg2)
{
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_28h;
    undefined4 uStackY_20;
    undefined4 uStackY_1c;
    int64_t var_18h;
    
    fcn.1800c7ec0(arg1, &var_28h, *(undefined8 *)(arg2 + 0x28));
    var_18h._0_4_ = (undefined4)var_28h;
    var_18h._4_4_ = var_28h._4_4_;
    fcn.1800c86e0(CONCAT44(uStackY_1c, uStackY_20), unaff_RDI);
    return 0;
}

// ============================================================
// Function: FUN_1800c8ad0
// Address: 0x1800c8ad0
// Size: 202 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800c8ad0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    uVar3 = fcn.1800aca90(*(undefined8 *)(arg1 + 0x10), *(undefined8 *)(arg2 + 0x28));
    if ((char)uVar3 != '\0') {
        puVar1 = *(undefined8 **)(arg2 + 0x38);
        if (puVar1 != (undefined8 *)0x0) {
            uVar3 = (**(code **)*puVar1)(puVar1, arg1);
        }
        return uVar3 & 0xffffffffffffff00;
    }
    cVar2 = fcn.1800ac9f0(*(undefined8 *)(arg1 + 0x10), *(undefined8 *)(arg2 + 0x28));
    if (cVar2 != '\0') {
        uVar3 = (**(code **)**(undefined8 **)(arg2 + 0x30))(*(undefined8 **)(arg2 + 0x30), arg1);
        return uVar3 & 0xffffffffffffff00;
    }
    if ((*(int64_t *)(arg2 + 0x38) == 0) ||
       (iVar4 = 2, *(int32_t *)(*(int64_t *)(arg2 + 0x38) + 8) == *(int32_t *)0x180782724)) {
        iVar4 = 1;
    }
    uVar3 = *(int64_t *)(arg1 + 0x40) + iVar4;
    *(undefined8 *)(arg1 + 0x48) = 0;
    uVar5 = uVar3 & 0x8080808080808080;
    *(uint64_t *)(arg1 + 0x40) = uVar5 - (uVar5 >> 7) | uVar5 ^ uVar3;
    return CONCAT71((unkuint7)(uVar5 >> 0xf), 1);
}

// ============================================================
// Function: FUN_1800c8ba0
// Address: 0x1800c8ba0
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

uint64_t fcn.1800c8ba0(int64_t arg1, int64_t arg2, int64_t arg_40h, int64_t arg_48h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t *puVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar12 = 0;
    puVar4 = (undefined *)*(BADSPACEBASE **)0x20;
    if (*(int64_t *)(arg2 + 0x40) != 0) {
        do {
            fcn.1800c7ec0(arg1, &var_48h);
            if ((var_40h != 0) && (uVar12 < *(uint64_t *)(arg2 + 0x30))) {
                iVar3 = *(int64_t *)(arg2 + 0x28);
                piVar1 = (int64_t *)(arg1 + 0x18);
                iVar10 = *(int64_t *)(arg1 + 0x20);
                if (((uint64_t)(iVar10 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x28)) &&
                   (iVar2 = func_0x0001800ac7f0(piVar1), iVar2 == 0)) {
                    uVar8 = *(uint64_t *)(arg1 + 0x30);
                    if (iVar10 == 0) {
                        uVar9 = 0x10;
                        iVar2 = func_0x000180459890(0x100);
                        uVar5 = 0;
                        iVar10 = iVar2;
                        uVar13 = 0x10;
code_r0x0001800c8cc0:
                        do {
                            uVar6 = uVar5 + 1;
                            *(uint64_t *)(iVar10 + uVar5 * 0x10) = *(uint64_t *)(arg1 + 0x30);
                            *(undefined8 *)(iVar10 + 8 + uVar5 * 0x10) = 0;
                            uVar5 = uVar6;
                        } while (uVar6 < uVar9);
                    } else {
                        uVar9 = iVar10 * 2;
                        if (uVar9 == 0) {
                            iVar2 = 0;
                            uVar13 = 0;
                        } else {
                            iVar2 = func_0x000180459890(iVar10 << 5);
                            uVar5 = 0;
                            iVar10 = iVar2;
                            uVar13 = uVar9;
                            if (uVar9 != 0) goto code_r0x0001800c8cc0;
                        }
                    }
                    uVar9 = 0;
                    if (*(int64_t *)(arg1 + 0x20) != 0) {
                        do {
                            uVar5 = *(uint64_t *)(*piVar1 + uVar9 * 0x10);
                            if (uVar5 != *(uint64_t *)(arg1 + 0x30)) {
                                uVar6 = (uVar5 >> 5 ^ uVar5) >> 4;
                                uVar11 = 0;
                                do {
                                    uVar6 = uVar6 & uVar13 - 1;
                                    puVar7 = (uint64_t *)(uVar6 * 0x10 + iVar2);
                                    if (*puVar7 == uVar8) {
                                        *puVar7 = uVar5;
                                        goto code_r0x0001800c8d56;
                                    }
                                    if (*puVar7 == uVar5) goto code_r0x0001800c8d56;
                                    uVar6 = uVar6 + 1 + uVar11;
                                    uVar11 = uVar11 + 1;
                                } while (uVar11 <= uVar13 - 1);
                                puVar7 = (uint64_t *)0x0;
code_r0x0001800c8d56:
                                iVar10 = *piVar1;
                                *puVar7 = *(uint64_t *)(iVar10 + uVar9 * 0x10);
                                puVar7[1] = *(uint64_t *)(iVar10 + 8 + uVar9 * 0x10);
                            }
                            uVar9 = uVar9 + 1;
                        } while (uVar9 < *(uint64_t *)(arg1 + 0x20));
                    }
                    iVar10 = *piVar1;
                    *piVar1 = iVar2;
                    *(uint64_t *)(arg1 + 0x20) = uVar13;
                    if (iVar10 != 0) {
                        func_0x0001800f4640();
                    }
                }
                iVar3 = func_0x0001800ac6e0(piVar1, iVar3 + uVar12 * 8);
                *(int64_t *)(iVar3 + 8) = var_40h;
            }
            uVar12 = uVar12 + 1;
            uVar8 = var_48h + *(int64_t *)(arg1 + 0x40);
            *(undefined8 *)(arg1 + 0x48) = 0;
            uVar9 = uVar8 & 0x8080808080808080;
            puVar4 = (undefined *)(uVar9 >> 7);
            *(uint64_t *)(arg1 + 0x40) = uVar9 - (int64_t)puVar4 | uVar9 ^ uVar8;
        } while (uVar12 < *(uint64_t *)(arg2 + 0x40));
    }
    return (uint64_t)puVar4 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c8bc6
// Address: 0x1800c8bc6
// Size: 579 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

uint64_t fcn.1800c8ba0(int64_t arg1, int64_t arg2, int64_t arg_40h, int64_t arg_48h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t *puVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar12 = 0;
    puVar4 = (undefined *)*(BADSPACEBASE **)0x20;
    if (*(int64_t *)(arg2 + 0x40) != 0) {
        do {
            fcn.1800c7ec0(arg1, &var_48h);
            if ((var_40h != 0) && (uVar12 < *(uint64_t *)(arg2 + 0x30))) {
                iVar3 = *(int64_t *)(arg2 + 0x28);
                piVar1 = (int64_t *)(arg1 + 0x18);
                iVar10 = *(int64_t *)(arg1 + 0x20);
                if (((uint64_t)(iVar10 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x28)) &&
                   (iVar2 = func_0x0001800ac7f0(piVar1), iVar2 == 0)) {
                    uVar8 = *(uint64_t *)(arg1 + 0x30);
                    if (iVar10 == 0) {
                        uVar9 = 0x10;
                        iVar2 = func_0x000180459890(0x100);
                        uVar5 = 0;
                        iVar10 = iVar2;
                        uVar13 = 0x10;
code_r0x0001800c8cc0:
                        do {
                            uVar6 = uVar5 + 1;
                            *(uint64_t *)(iVar10 + uVar5 * 0x10) = *(uint64_t *)(arg1 + 0x30);
                            *(undefined8 *)(iVar10 + 8 + uVar5 * 0x10) = 0;
                            uVar5 = uVar6;
                        } while (uVar6 < uVar9);
                    } else {
                        uVar9 = iVar10 * 2;
                        if (uVar9 == 0) {
                            iVar2 = 0;
                            uVar13 = 0;
                        } else {
                            iVar2 = func_0x000180459890(iVar10 << 5);
                            uVar5 = 0;
                            iVar10 = iVar2;
                            uVar13 = uVar9;
                            if (uVar9 != 0) goto code_r0x0001800c8cc0;
                        }
                    }
                    uVar9 = 0;
                    if (*(int64_t *)(arg1 + 0x20) != 0) {
                        do {
                            uVar5 = *(uint64_t *)(*piVar1 + uVar9 * 0x10);
                            if (uVar5 != *(uint64_t *)(arg1 + 0x30)) {
                                uVar6 = (uVar5 >> 5 ^ uVar5) >> 4;
                                uVar11 = 0;
                                do {
                                    uVar6 = uVar6 & uVar13 - 1;
                                    puVar7 = (uint64_t *)(uVar6 * 0x10 + iVar2);
                                    if (*puVar7 == uVar8) {
                                        *puVar7 = uVar5;
                                        goto code_r0x0001800c8d56;
                                    }
                                    if (*puVar7 == uVar5) goto code_r0x0001800c8d56;
                                    uVar6 = uVar6 + 1 + uVar11;
                                    uVar11 = uVar11 + 1;
                                } while (uVar11 <= uVar13 - 1);
                                puVar7 = (uint64_t *)0x0;
code_r0x0001800c8d56:
                                iVar10 = *piVar1;
                                *puVar7 = *(uint64_t *)(iVar10 + uVar9 * 0x10);
                                puVar7[1] = *(uint64_t *)(iVar10 + 8 + uVar9 * 0x10);
                            }
                            uVar9 = uVar9 + 1;
                        } while (uVar9 < *(uint64_t *)(arg1 + 0x20));
                    }
                    iVar10 = *piVar1;
                    *piVar1 = iVar2;
                    *(uint64_t *)(arg1 + 0x20) = uVar13;
                    if (iVar10 != 0) {
                        func_0x0001800f4640();
                    }
                }
                iVar3 = func_0x0001800ac6e0(piVar1, iVar3 + uVar12 * 8);
                *(int64_t *)(iVar3 + 8) = var_40h;
            }
            uVar12 = uVar12 + 1;
            uVar8 = var_48h + *(int64_t *)(arg1 + 0x40);
            *(undefined8 *)(arg1 + 0x48) = 0;
            uVar9 = uVar8 & 0x8080808080808080;
            puVar4 = (undefined *)(uVar9 >> 7);
            *(uint64_t *)(arg1 + 0x40) = uVar9 - (int64_t)puVar4 | uVar9 ^ uVar8;
        } while (uVar12 < *(uint64_t *)(arg2 + 0x40));
    }
    return (uint64_t)puVar4 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c8e09
// Address: 0x1800c8e09
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

uint64_t fcn.1800c8ba0(int64_t arg1, int64_t arg2, int64_t arg_40h, int64_t arg_48h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t *puVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar12 = 0;
    puVar4 = (undefined *)*(BADSPACEBASE **)0x20;
    if (*(int64_t *)(arg2 + 0x40) != 0) {
        do {
            fcn.1800c7ec0(arg1, &var_48h);
            if ((var_40h != 0) && (uVar12 < *(uint64_t *)(arg2 + 0x30))) {
                iVar3 = *(int64_t *)(arg2 + 0x28);
                piVar1 = (int64_t *)(arg1 + 0x18);
                iVar10 = *(int64_t *)(arg1 + 0x20);
                if (((uint64_t)(iVar10 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x28)) &&
                   (iVar2 = func_0x0001800ac7f0(piVar1), iVar2 == 0)) {
                    uVar8 = *(uint64_t *)(arg1 + 0x30);
                    if (iVar10 == 0) {
                        uVar9 = 0x10;
                        iVar2 = func_0x000180459890(0x100);
                        uVar5 = 0;
                        iVar10 = iVar2;
                        uVar13 = 0x10;
code_r0x0001800c8cc0:
                        do {
                            uVar6 = uVar5 + 1;
                            *(uint64_t *)(iVar10 + uVar5 * 0x10) = *(uint64_t *)(arg1 + 0x30);
                            *(undefined8 *)(iVar10 + 8 + uVar5 * 0x10) = 0;
                            uVar5 = uVar6;
                        } while (uVar6 < uVar9);
                    } else {
                        uVar9 = iVar10 * 2;
                        if (uVar9 == 0) {
                            iVar2 = 0;
                            uVar13 = 0;
                        } else {
                            iVar2 = func_0x000180459890(iVar10 << 5);
                            uVar5 = 0;
                            iVar10 = iVar2;
                            uVar13 = uVar9;
                            if (uVar9 != 0) goto code_r0x0001800c8cc0;
                        }
                    }
                    uVar9 = 0;
                    if (*(int64_t *)(arg1 + 0x20) != 0) {
                        do {
                            uVar5 = *(uint64_t *)(*piVar1 + uVar9 * 0x10);
                            if (uVar5 != *(uint64_t *)(arg1 + 0x30)) {
                                uVar6 = (uVar5 >> 5 ^ uVar5) >> 4;
                                uVar11 = 0;
                                do {
                                    uVar6 = uVar6 & uVar13 - 1;
                                    puVar7 = (uint64_t *)(uVar6 * 0x10 + iVar2);
                                    if (*puVar7 == uVar8) {
                                        *puVar7 = uVar5;
                                        goto code_r0x0001800c8d56;
                                    }
                                    if (*puVar7 == uVar5) goto code_r0x0001800c8d56;
                                    uVar6 = uVar6 + 1 + uVar11;
                                    uVar11 = uVar11 + 1;
                                } while (uVar11 <= uVar13 - 1);
                                puVar7 = (uint64_t *)0x0;
code_r0x0001800c8d56:
                                iVar10 = *piVar1;
                                *puVar7 = *(uint64_t *)(iVar10 + uVar9 * 0x10);
                                puVar7[1] = *(uint64_t *)(iVar10 + 8 + uVar9 * 0x10);
                            }
                            uVar9 = uVar9 + 1;
                        } while (uVar9 < *(uint64_t *)(arg1 + 0x20));
                    }
                    iVar10 = *piVar1;
                    *piVar1 = iVar2;
                    *(uint64_t *)(arg1 + 0x20) = uVar13;
                    if (iVar10 != 0) {
                        func_0x0001800f4640();
                    }
                }
                iVar3 = func_0x0001800ac6e0(piVar1, iVar3 + uVar12 * 8);
                *(int64_t *)(iVar3 + 8) = var_40h;
            }
            uVar12 = uVar12 + 1;
            uVar8 = var_48h + *(int64_t *)(arg1 + 0x40);
            *(undefined8 *)(arg1 + 0x48) = 0;
            uVar9 = uVar8 & 0x8080808080808080;
            puVar4 = (undefined *)(uVar9 >> 7);
            *(uint64_t *)(arg1 + 0x40) = uVar9 - (int64_t)puVar4 | uVar9 ^ uVar8;
        } while (uVar12 < *(uint64_t *)(arg2 + 0x40));
    }
    return (uint64_t)puVar4 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c8e20
// Address: 0x1800c8e20
// Size: 328 bytes
// ============================================================
uint64_t fcn.1800c8e20(int64_t arg1, int64_t arg2, int64_t arg_40h, int64_t arg_48h)
{
    uint64_t in_RAX;
    uint64_t *puVar1;
    int64_t *piVar2;
    uint64_t uVar3;
    undefined8 *puVar4;
    undefined8 *puVar5;
    undefined8 *puVar6;
    undefined8 *puVar7;
    uint64_t uVar8;
    undefined8 *puVar9;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_48h;
    
    puVar9 = (undefined8 *)0x0;
    puVar6 = puVar9;
    puVar7 = puVar9;
    if (*(int64_t *)(arg2 + 0x30) != 0) {
        do {
            puVar5 = *(undefined8 **)(*(int64_t *)(arg2 + 0x28) + (int64_t)puVar7 * 8);
            in_RAX = (uint64_t)*(uint32_t *)0x180782728;
            puVar4 = puVar9;
            if (*(uint32_t *)(puVar5 + 1) == *(uint32_t *)0x180782728) {
                puVar4 = puVar5;
            }
            if (puVar4 != (undefined8 *)0x0) {
                in_RAX = func_0x0001800ac7f0(arg1 + 0x18, puVar4 + 4);
                puVar5 = (undefined8 *)(in_RAX + 8);
                if (in_RAX == 0) {
                    puVar5 = puVar9;
                }
                if (puVar5 != (undefined8 *)0x0) {
                    *puVar5 = 0;
                }
            }
            puVar7 = (undefined8 *)((int64_t)puVar7 + 1);
        } while (puVar7 < *(undefined8 **)(arg2 + 0x30));
    }
    do {
        if (puVar6 < *(undefined8 **)(arg2 + 0x30)) {
            puVar1 = (uint64_t *)
                     fcn.1800c7ec0(arg1, &var_58h, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + (int64_t)puVar6 * 8));
            uVar3 = *puVar1 & 0x8080808080808080;
            puVar7 = (undefined8 *)(uVar3 - (uVar3 >> 7) | uVar3 ^ *puVar1);
        } else {
            puVar7 = puVar9;
            if (*(undefined8 **)(arg2 + 0x40) <= puVar6) {
                return in_RAX & 0xffffffffffffff00;
            }
        }
        if (puVar6 < *(undefined8 **)(arg2 + 0x40)) {
            piVar2 = (int64_t *)
                     fcn.1800c7ec0(arg1, &var_48h, *(undefined8 *)(*(int64_t *)(arg2 + 0x38) + (int64_t)puVar6 * 8));
            uVar3 = *piVar2 + (int64_t)puVar7 & 0x8080808080808080;
            puVar7 = (undefined8 *)(uVar3 - (uVar3 >> 7) | uVar3 ^ *piVar2 + (int64_t)puVar7);
        }
        *(undefined8 *)(arg1 + 0x48) = 0;
        if (puVar7 == (undefined8 *)0x0) {
            puVar7 = (undefined8 *)0x1;
        }
        uVar3 = *(int64_t *)(arg1 + 0x40) + (int64_t)puVar7;
        uVar8 = uVar3 & 0x8080808080808080;
        in_RAX = uVar8 >> 7;
        *(uint64_t *)(arg1 + 0x40) = uVar8 - in_RAX | uVar8 ^ uVar3;
        puVar6 = (undefined8 *)((int64_t)puVar6 + 1);
    } while( true );
}

// ============================================================
// Function: FUN_1800c8f70
// Address: 0x1800c8f70
// Size: 170 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800c8f70(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    uint64_t uVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar5 = *(int32_t *)0x180782728;
    iVar2 = 0;
    if (*(int32_t *)(*(int64_t *)(arg2 + 0x30) + 8) == *(int32_t *)0x180782728) {
        iVar2 = *(int64_t *)(arg2 + 0x30);
    }
    if (iVar2 != 0) {
        iVar2 = fcn.1800ac7f0(arg1 + 0x18, iVar2 + 0x20);
        puVar3 = (undefined8 *)(iVar2 + 8);
        if (iVar2 == 0) {
            puVar3 = (undefined8 *)0x0;
        }
        if (puVar3 != (undefined8 *)0x0) {
            *puVar3 = 0;
            iVar5 = *(int32_t *)0x180782728;
        }
    }
    iVar1 = *(int32_t *)(*(int64_t *)(arg2 + 0x30) + 8);
    *(undefined8 *)(arg1 + 0x48) = 0;
    uVar6 = (uint64_t)(iVar1 != iVar5) + 1 + *(int64_t *)(arg1 + 0x40);
    uVar4 = uVar6 & 0x8080808080808080;
    *(uint64_t *)(arg1 + 0x40) = uVar4 - (uVar4 >> 7) | uVar6 ^ uVar4;
    return CONCAT71((unkuint7)(uVar4 >> 0xf), 1);
}

// ============================================================
// Function: FUN_1800c9060
// Address: 0x1800c9060
// Size: 176 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1800c9060(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t *piVar3;
    uint64_t uVar4;
    int64_t **ppiVar5;
    uint64_t uVar6;
    int64_t **ppiVar7;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar3 = *(int64_t **)(arg1 + 0x10);
    if ((piVar3[2] != 0) && (ppiVar5 = (int64_t **)(piVar3 + 3), (int64_t *)arg2 != *ppiVar5)) {
        piVar1 = piVar3 + 1;
        iVar2 = *piVar3;
        uVar4 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar6 = 0;
        do {
            uVar4 = uVar4 & *piVar1 - 1U;
            ppiVar7 = (int64_t **)(uVar4 * 0x20 + iVar2);
            piVar3 = *ppiVar7;
            if (piVar3 == (int64_t *)arg2) {
                piVar3 = (int64_t *)0x0;
                ppiVar5 = ppiVar7 + 1;
                if (ppiVar7 == (int64_t **)0x0) {
                    ppiVar5 = (int64_t **)0x0;
                }
                if ((ppiVar5 != (int64_t **)0x0) && (*(int32_t *)ppiVar5 == 3)) {
                    piVar3 = ppiVar5[1];
                    *(int64_t **)arg3 = piVar3;
                    return CONCAT71((unkint7)((uint64_t)piVar3 >> 8), 1);
                }
                break;
            }
            if (piVar3 == *ppiVar5) break;
            uVar4 = uVar4 + 1 + uVar6;
            uVar6 = uVar6 + 1;
        } while (uVar6 <= *piVar1 - 1U);
    }
    return (uint64_t)piVar3 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c9110
// Address: 0x1800c9110
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800c9110(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    char cVar6;
    uint64_t in_RAX;
    uint64_t uVar7;
    undefined8 *puVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar11 = 0;
    if (*(int64_t *)(arg2 + 0x30) == 0) {
        return in_RAX & 0xffffffffffffff00;
    }
    do {
        puVar2 = *(undefined8 **)(*(int64_t *)(arg2 + 0x28) + uVar11 * 8);
        (**(code **)*puVar2)(puVar2, arg1);
        uVar1 = *(uint32_t *)(puVar2 + 1);
        uVar7 = (uint64_t)uVar1;
        uVar3 = *(undefined8 *)(arg1 + 0x10);
        puVar8 = (undefined8 *)0x0;
        if (uVar1 == *(uint32_t *)0x180782718) {
            puVar8 = puVar2;
        }
        if (puVar8 == (undefined8 *)0x0) {
            if (((uVar1 == *(uint32_t *)0x1807826d0) || (uVar1 == *(uint32_t *)0x180782700)) ||
               (uVar1 == *(uint32_t *)0x180782750)) break;
            puVar8 = (undefined8 *)0x0;
            if (uVar1 == *(uint32_t *)0x180782724) {
                puVar8 = puVar2;
            }
            if (puVar8 != (undefined8 *)0x0) {
                uVar5 = puVar8[5];
                cVar6 = fcn.1800ac9f0(uVar3, uVar5);
                if (cVar6 == '\0') {
                    uVar7 = fcn.1800aca90(uVar3, uVar5);
                    if ((((char)uVar7 == '\0') || (iVar9 = puVar8[7], iVar9 == 0)) &&
                       ((iVar9 = puVar8[7], iVar9 == 0 ||
                        (uVar7 = func_0x0001800acb30(uVar3, puVar8[6]), (char)uVar7 == '\0'))))
                    goto code_r0x0001800c9227;
                } else {
                    iVar9 = puVar8[6];
                }
                uVar7 = func_0x0001800acb30(uVar3, iVar9);
                if ((char)uVar7 != '\0') break;
            }
        } else {
            uVar4 = puVar8[6];
            if (uVar4 != 0) {
                iVar9 = puVar8[5];
                uVar10 = 0;
                do {
                    uVar7 = func_0x0001800acb30(uVar3, *(undefined8 *)(iVar9 + uVar10 * 8));
                    if ((char)uVar7 != '\0') goto code_r0x0001800c9234;
                    uVar10 = uVar10 + 1;
                } while (uVar10 < uVar4);
            }
        }
code_r0x0001800c9227:
        uVar11 = uVar11 + 1;
    } while (uVar11 < *(uint64_t *)(arg2 + 0x30));
code_r0x0001800c9234:
    return uVar7 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c912c
// Address: 0x1800c912c
// Size: 296 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800c9110(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    char cVar6;
    uint64_t in_RAX;
    uint64_t uVar7;
    undefined8 *puVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar11 = 0;
    if (*(int64_t *)(arg2 + 0x30) == 0) {
        return in_RAX & 0xffffffffffffff00;
    }
    do {
        puVar2 = *(undefined8 **)(*(int64_t *)(arg2 + 0x28) + uVar11 * 8);
        (**(code **)*puVar2)(puVar2, arg1);
        uVar1 = *(uint32_t *)(puVar2 + 1);
        uVar7 = (uint64_t)uVar1;
        uVar3 = *(undefined8 *)(arg1 + 0x10);
        puVar8 = (undefined8 *)0x0;
        if (uVar1 == *(uint32_t *)0x180782718) {
            puVar8 = puVar2;
        }
        if (puVar8 == (undefined8 *)0x0) {
            if (((uVar1 == *(uint32_t *)0x1807826d0) || (uVar1 == *(uint32_t *)0x180782700)) ||
               (uVar1 == *(uint32_t *)0x180782750)) break;
            puVar8 = (undefined8 *)0x0;
            if (uVar1 == *(uint32_t *)0x180782724) {
                puVar8 = puVar2;
            }
            if (puVar8 != (undefined8 *)0x0) {
                uVar5 = puVar8[5];
                cVar6 = fcn.1800ac9f0(uVar3, uVar5);
                if (cVar6 == '\0') {
                    uVar7 = fcn.1800aca90(uVar3, uVar5);
                    if ((((char)uVar7 == '\0') || (iVar9 = puVar8[7], iVar9 == 0)) &&
                       ((iVar9 = puVar8[7], iVar9 == 0 ||
                        (uVar7 = func_0x0001800acb30(uVar3, puVar8[6]), (char)uVar7 == '\0'))))
                    goto code_r0x0001800c9227;
                } else {
                    iVar9 = puVar8[6];
                }
                uVar7 = func_0x0001800acb30(uVar3, iVar9);
                if ((char)uVar7 != '\0') break;
            }
        } else {
            uVar4 = puVar8[6];
            if (uVar4 != 0) {
                iVar9 = puVar8[5];
                uVar10 = 0;
                do {
                    uVar7 = func_0x0001800acb30(uVar3, *(undefined8 *)(iVar9 + uVar10 * 8));
                    if ((char)uVar7 != '\0') goto code_r0x0001800c9234;
                    uVar10 = uVar10 + 1;
                } while (uVar10 < uVar4);
            }
        }
code_r0x0001800c9227:
        uVar11 = uVar11 + 1;
    } while (uVar11 < *(uint64_t *)(arg2 + 0x30));
code_r0x0001800c9234:
    return uVar7 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c9254
// Address: 0x1800c9254
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1800c9110(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    char cVar6;
    uint64_t in_RAX;
    uint64_t uVar7;
    undefined8 *puVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar11 = 0;
    if (*(int64_t *)(arg2 + 0x30) == 0) {
        return in_RAX & 0xffffffffffffff00;
    }
    do {
        puVar2 = *(undefined8 **)(*(int64_t *)(arg2 + 0x28) + uVar11 * 8);
        (**(code **)*puVar2)(puVar2, arg1);
        uVar1 = *(uint32_t *)(puVar2 + 1);
        uVar7 = (uint64_t)uVar1;
        uVar3 = *(undefined8 *)(arg1 + 0x10);
        puVar8 = (undefined8 *)0x0;
        if (uVar1 == *(uint32_t *)0x180782718) {
            puVar8 = puVar2;
        }
        if (puVar8 == (undefined8 *)0x0) {
            if (((uVar1 == *(uint32_t *)0x1807826d0) || (uVar1 == *(uint32_t *)0x180782700)) ||
               (uVar1 == *(uint32_t *)0x180782750)) break;
            puVar8 = (undefined8 *)0x0;
            if (uVar1 == *(uint32_t *)0x180782724) {
                puVar8 = puVar2;
            }
            if (puVar8 != (undefined8 *)0x0) {
                uVar5 = puVar8[5];
                cVar6 = fcn.1800ac9f0(uVar3, uVar5);
                if (cVar6 == '\0') {
                    uVar7 = fcn.1800aca90(uVar3, uVar5);
                    if ((((char)uVar7 == '\0') || (iVar9 = puVar8[7], iVar9 == 0)) &&
                       ((iVar9 = puVar8[7], iVar9 == 0 ||
                        (uVar7 = func_0x0001800acb30(uVar3, puVar8[6]), (char)uVar7 == '\0'))))
                    goto code_r0x0001800c9227;
                } else {
                    iVar9 = puVar8[6];
                }
                uVar7 = func_0x0001800acb30(uVar3, iVar9);
                if ((char)uVar7 != '\0') break;
            }
        } else {
            uVar4 = puVar8[6];
            if (uVar4 != 0) {
                iVar9 = puVar8[5];
                uVar10 = 0;
                do {
                    uVar7 = func_0x0001800acb30(uVar3, *(undefined8 *)(iVar9 + uVar10 * 8));
                    if ((char)uVar7 != '\0') goto code_r0x0001800c9234;
                    uVar10 = uVar10 + 1;
                } while (uVar10 < uVar4);
            }
        }
code_r0x0001800c9227:
        uVar11 = uVar11 + 1;
    } while (uVar11 < *(uint64_t *)(arg2 + 0x30));
code_r0x0001800c9234:
    return uVar7 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c9260
// Address: 0x1800c9260
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800c9260(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x18) = 0;
        *(undefined8 *)(arg1 + 0x20) = 0;
    }
    *(undefined8 *)arg1 = 0x18063f2c0;
    if ((arg2 & 1U) != 0) {
        func_0x000180459c3c(arg1, 0x50);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800c92c0
// Address: 0x1800c92c0
// Size: 664 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1800c92c0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    uint64_t *puVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    bool bVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    
    var_88h = 0x180641090;
    var_78h = arg_28h;
    var_70h = 0;
    _var_68h = ZEXT816(0);
    var_58h = 0;
    var_48h = 0;
    var_40h = 0;
    uVar11 = 0;
    var_80h = arg4;
    if (arg3 != 0) {
        do {
            iVar4 = var_58h;
            if (6 < uVar11) break;
            puVar1 = (uint64_t *)(arg2 + uVar11 * 8);
            if ((uint64_t)(var_68h * 3) >> 2 <= (uint64_t)var_60h) {
                if ((var_60h != 0) && (uVar7 = *puVar1, uVar7 != var_58h)) {
                    uVar5 = (uVar7 >> 5 ^ uVar7) >> 4;
                    uVar8 = 0;
                    do {
                        uVar5 = uVar5 & var_68h - 1U;
                        uVar2 = *(uint64_t *)(var_70h + uVar5 * 0x10);
                        if (uVar2 == uVar7) goto code_r0x0001800c94e1;
                        if (uVar2 == var_58h) break;
                        uVar5 = uVar5 + 1 + uVar8;
                        uVar8 = uVar8 + 1;
                    } while (uVar8 <= var_68h - 1U);
                }
                if (var_68h == 0) {
                    uVar7 = 0x10;
                    iVar3 = func_0x000180459890(0x100);
                    uVar8 = 0;
                    iVar9 = iVar3;
                    uVar5 = 0x10;
code_r0x0001800c9400:
                    do {
                        *(int64_t *)(iVar9 + uVar8 * 0x10) = var_58h;
                        *(undefined8 *)(iVar9 + 8 + uVar8 * 0x10) = 0;
                        uVar8 = uVar8 + 1;
                    } while (uVar8 < uVar7);
code_r0x0001800c941d:
                    uVar7 = var_68h;
                } else {
                    uVar7 = var_68h * 2;
                    if (uVar7 != 0) {
                        iVar3 = func_0x000180459890(var_68h << 5);
                        uVar8 = 0;
                        iVar9 = iVar3;
                        uVar5 = uVar7;
                        if (uVar7 != 0) goto code_r0x0001800c9400;
                        goto code_r0x0001800c941d;
                    }
                    uVar5 = 0;
                    iVar3 = 0;
                    uVar7 = var_68h;
                }
                iVar9 = var_70h;
                uVar8 = 0;
                if (uVar7 != 0) {
                    do {
                        uVar2 = *(uint64_t *)(var_70h + uVar8 * 0x10);
                        if (uVar2 != var_58h) {
                            uVar7 = (uVar2 >> 5 ^ uVar2) >> 4;
                            uVar6 = 0;
                            do {
                                uVar7 = uVar7 & uVar5 - 1;
                                puVar10 = (uint64_t *)(uVar7 * 0x10 + iVar3);
                                if (*puVar10 == iVar4) {
                                    *puVar10 = uVar2;
                                    goto code_r0x0001800c94a4;
                                }
                                if (*puVar10 == uVar2) goto code_r0x0001800c94a4;
                                uVar7 = uVar7 + 1 + uVar6;
                                uVar6 = uVar6 + 1;
                            } while (uVar6 <= uVar5 - 1);
                            puVar10 = (uint64_t *)0x0;
code_r0x0001800c94a4:
                            *puVar10 = *(uint64_t *)(var_70h + uVar8 * 0x10);
                            puVar10[1] = *(uint64_t *)(var_70h + 8 + uVar8 * 0x10);
                            uVar7 = var_68h;
                        }
                        uVar8 = uVar8 + 1;
                    } while (uVar8 < uVar7);
                }
                var_68h = uVar5;
                bVar12 = var_70h != 0;
                var_70h = iVar3;
                if (bVar12) {
                    func_0x0001800f4640(iVar9);
                }
            }
code_r0x0001800c94e1:
            iVar4 = func_0x0001800ac6e0(&var_70h, puVar1);
            *(int64_t *)(iVar4 + 8) = 0xffLL << ((char)uVar11 * '\b' + 8U & 0x3f);
            uVar11 = uVar11 + 1;
        } while (uVar11 < (uint64_t)arg3);
    }
    (***(code ***)arg1)(arg1, &var_88h);
    iVar4 = var_48h;
    if (var_70h != 0) {
        func_0x0001800f4640();
    }
    return iVar4;
}

// ============================================================
// Function: FUN_1800c9620
// Address: 0x1800c9620
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.1800c9620(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t *puVar2;
    undefined4 *puVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t *puVar11;
    int32_t *piVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t iVar15;
    uint64_t uVar16;
    int32_t *piVar17;
    uint64_t uVar18;
    uint64_t uVar19;
    uint64_t *puVar20;
    uint64_t uVar21;
    uint64_t uVar22;
    uint64_t *puVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar8 = *(int32_t *)0x180782728;
    iVar10 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x18078269c) {
        iVar10 = arg2;
    }
    if (iVar10 == 0) {
        iVar10 = 0;
        if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782730) {
            iVar10 = arg2;
        }
        if (iVar10 == 0) {
            return;
        }
        iVar9 = 0;
        if (*(int32_t *)(*(int64_t *)(iVar10 + 0x20) + 8) == *(int32_t *)0x180782728) {
            iVar9 = *(int64_t *)(iVar10 + 0x20);
        }
        if (iVar9 == 0) {
            return;
        }
        iVar15 = fcn.1800ac7f0();
        iVar9 = iVar15 + 8;
        if (iVar15 == 0) {
            iVar9 = 0;
        }
        if (iVar9 == 0) {
            return;
        }
        iVar10 = *(int64_t *)(iVar10 + 0x28);
        iVar15 = 0;
        if (*(int32_t *)(iVar10 + 8) == *(int32_t *)0x1807826b4) {
            iVar15 = iVar10;
        }
        if (iVar15 != 0) {
            puVar11 = (uint32_t *)func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), iVar9);
            if (*(double *)(iVar15 + 0x20) != (double)(uint64_t)(*puVar11 + 1)) {
                return;
            }
            *puVar11 = *puVar11 + 1;
            return;
        }
        iVar15 = 0;
        if (*(int32_t *)(iVar10 + 8) == iVar8) {
            iVar15 = iVar10;
        }
        if (iVar15 == 0) {
            return;
        }
        iVar10 = fcn.1800ac7f0(arg1 + 0x68, iVar15 + 0x20);
        piVar17 = (int32_t *)(iVar10 + 8);
        if (iVar10 == 0) {
            piVar17 = (int32_t *)0x0;
        }
        if (piVar17 == (int32_t *)0x0) {
            return;
        }
        piVar12 = (int32_t *)func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), iVar9);
        if (*piVar12 != 0) {
            return;
        }
        *piVar12 = *piVar17;
        return;
    }
    iVar9 = 0;
    if (*(int32_t *)(*(int64_t *)(iVar10 + 0x20) + 8) == *(int32_t *)0x180782728) {
        iVar9 = *(int64_t *)(iVar10 + 0x20);
    }
    if (iVar9 == 0) {
        return;
    }
    iVar9 = fcn.1800ac7f0(arg1 + 0x10, iVar9 + 0x20);
    puVar23 = (uint64_t *)(iVar9 + 8);
    if (iVar9 == 0) {
        puVar23 = (uint64_t *)0x0;
    }
    if (puVar23 == (uint64_t *)0x0) {
        return;
    }
    uVar4 = *(uint64_t *)(iVar10 + 0x28);
    uVar18 = *puVar23;
    piVar1 = (int64_t *)(arg1 + 0x38);
    var_58h = uVar18;
    var_50h = uVar4;
    iVar10 = func_0x0001800ca160(piVar1, &var_58h);
    if (iVar10 != 0) {
        return;
    }
    iVar10 = *(int64_t *)(arg1 + 0x40);
    if (*(uint64_t *)(arg1 + 0x48) < (uint64_t)(iVar10 * 3) >> 2) goto code_r0x0001800c98c6;
    uVar18 = *(uint64_t *)(arg1 + 0x58);
    puVar2 = (uint64_t *)(arg1 + 0x50);
    uVar16 = *puVar2;
    if (iVar10 == 0) {
        uVar19 = 0x10;
        iVar9 = func_0x000180459890();
        var_18h = 0x10;
        uVar13 = 0;
        iVar10 = iVar9;
        uVar22 = 0x10;
        var_10h = iVar9;
code_r0x0001800c9770:
        do {
            uVar5 = *(undefined4 *)(arg1 + 0x54);
            uVar6 = *(undefined4 *)(arg1 + 0x58);
            uVar7 = *(undefined4 *)(arg1 + 0x5c);
            uVar14 = uVar13 + 1;
            puVar3 = (undefined4 *)(iVar9 + uVar13 * 0x10);
            *puVar3 = *(undefined4 *)puVar2;
            puVar3[1] = uVar5;
            puVar3[2] = uVar6;
            puVar3[3] = uVar7;
            uVar13 = uVar14;
        } while (uVar14 < uVar19);
    } else {
        uVar19 = iVar10 * 2;
        if (uVar19 == 0) {
            iVar10 = 0;
            uVar22 = 0;
            var_10h = 0;
            var_18h = 0;
        } else {
            iVar9 = func_0x000180459890();
            uVar13 = 0;
            iVar10 = iVar9;
            uVar22 = uVar19;
            var_10h = iVar9;
            var_18h = uVar19;
            if (uVar19 != 0) goto code_r0x0001800c9770;
        }
    }
    uVar19 = 0;
    if (*(int64_t *)(arg1 + 0x40) != 0) {
        do {
            uVar22 = *(uint64_t *)(*piVar1 + uVar19 * 0x10);
            iVar9 = *piVar1 + uVar19 * 0x10;
            if ((uVar22 != *puVar2) || (*(int64_t *)(iVar9 + 8) != *(int64_t *)(arg1 + 0x58))) {
                uVar13 = *(uint64_t *)(iVar9 + 8);
                uVar14 = ((uVar13 ^ uVar22) >> 5 ^ uVar13 ^ uVar22) >> 4;
                uVar21 = 0;
                while( true ) {
                    uVar14 = uVar14 & var_18h - 1U;
                    puVar20 = (uint64_t *)(iVar10 + uVar14 * 0x10);
                    iVar10 = var_10h;
                    if ((*puVar20 == uVar16) && (puVar20[1] == uVar18)) {
                        *puVar20 = uVar22;
                        puVar20[1] = *(uint64_t *)(iVar9 + 8);
                        goto code_r0x0001800c985e;
                    }
                    if ((*puVar20 == uVar22) && (puVar20[1] == uVar13)) goto code_r0x0001800c985e;
                    iVar15 = uVar14 + uVar21;
                    uVar21 = uVar21 + 1;
                    if (var_18h - 1U < uVar21) break;
                    uVar14 = iVar15 + 1;
                }
                puVar20 = (uint64_t *)0x0;
code_r0x0001800c985e:
                iVar9 = *piVar1;
                *puVar20 = *(uint64_t *)(iVar9 + uVar19 * 0x10);
                puVar20[1] = *(uint64_t *)(iVar9 + 8 + uVar19 * 0x10);
            }
            uVar19 = uVar19 + 1;
            uVar22 = var_18h;
        } while (uVar19 < *(uint64_t *)(arg1 + 0x40));
    }
    iVar9 = *piVar1;
    *piVar1 = iVar10;
    *(uint64_t *)(arg1 + 0x40) = uVar22;
    uVar18 = var_58h;
    if (iVar9 != 0) {
        func_0x0001800f4640();
        uVar18 = var_58h;
    }
code_r0x0001800c98c6:
    iVar10 = *piVar1;
    uVar22 = *(int64_t *)(arg1 + 0x40) - 1;
    uVar16 = ((uVar4 ^ uVar18) >> 5 ^ uVar4 ^ uVar18) >> 4;
    uVar19 = 0;
    while( true ) {
        uVar16 = uVar16 & uVar22;
        uVar13 = *(uint64_t *)(iVar10 + uVar16 * 0x10);
        iVar9 = iVar10 + uVar16 * 0x10;
        if ((uVar13 == *(uint64_t *)(arg1 + 0x50)) && (*(int64_t *)(iVar9 + 8) == *(int64_t *)(arg1 + 0x58))) break;
        if ((uVar13 == uVar18) && (*(uint64_t *)(iVar9 + 8) == uVar4)) goto code_r0x0001800c9937;
        iVar9 = uVar16 + uVar19;
        uVar19 = uVar19 + 1;
        if (uVar22 < uVar19) goto code_r0x0001800c9937;
        uVar16 = iVar9 + 1;
    }
    *(uint64_t *)(iVar10 + uVar16 * 0x10) = uVar18;
    *(uint64_t *)(iVar9 + 8) = uVar4;
    *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 1;
code_r0x0001800c9937:
    iVar10 = func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), puVar23);
    *(int32_t *)(iVar10 + 4) = *(int32_t *)(iVar10 + 4) + 1;
    return;
}

// ============================================================
// Function: FUN_1800c966a
// Address: 0x1800c966a
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.1800c9620(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t *puVar2;
    undefined4 *puVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t *puVar11;
    int32_t *piVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t iVar15;
    uint64_t uVar16;
    int32_t *piVar17;
    uint64_t uVar18;
    uint64_t uVar19;
    uint64_t *puVar20;
    uint64_t uVar21;
    uint64_t uVar22;
    uint64_t *puVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar8 = *(int32_t *)0x180782728;
    iVar10 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x18078269c) {
        iVar10 = arg2;
    }
    if (iVar10 == 0) {
        iVar10 = 0;
        if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782730) {
            iVar10 = arg2;
        }
        if (iVar10 == 0) {
            return;
        }
        iVar9 = 0;
        if (*(int32_t *)(*(int64_t *)(iVar10 + 0x20) + 8) == *(int32_t *)0x180782728) {
            iVar9 = *(int64_t *)(iVar10 + 0x20);
        }
        if (iVar9 == 0) {
            return;
        }
        iVar15 = fcn.1800ac7f0();
        iVar9 = iVar15 + 8;
        if (iVar15 == 0) {
            iVar9 = 0;
        }
        if (iVar9 == 0) {
            return;
        }
        iVar10 = *(int64_t *)(iVar10 + 0x28);
        iVar15 = 0;
        if (*(int32_t *)(iVar10 + 8) == *(int32_t *)0x1807826b4) {
            iVar15 = iVar10;
        }
        if (iVar15 != 0) {
            puVar11 = (uint32_t *)func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), iVar9);
            if (*(double *)(iVar15 + 0x20) != (double)(uint64_t)(*puVar11 + 1)) {
                return;
            }
            *puVar11 = *puVar11 + 1;
            return;
        }
        iVar15 = 0;
        if (*(int32_t *)(iVar10 + 8) == iVar8) {
            iVar15 = iVar10;
        }
        if (iVar15 == 0) {
            return;
        }
        iVar10 = fcn.1800ac7f0(arg1 + 0x68, iVar15 + 0x20);
        piVar17 = (int32_t *)(iVar10 + 8);
        if (iVar10 == 0) {
            piVar17 = (int32_t *)0x0;
        }
        if (piVar17 == (int32_t *)0x0) {
            return;
        }
        piVar12 = (int32_t *)func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), iVar9);
        if (*piVar12 != 0) {
            return;
        }
        *piVar12 = *piVar17;
        return;
    }
    iVar9 = 0;
    if (*(int32_t *)(*(int64_t *)(iVar10 + 0x20) + 8) == *(int32_t *)0x180782728) {
        iVar9 = *(int64_t *)(iVar10 + 0x20);
    }
    if (iVar9 == 0) {
        return;
    }
    iVar9 = fcn.1800ac7f0(arg1 + 0x10, iVar9 + 0x20);
    puVar23 = (uint64_t *)(iVar9 + 8);
    if (iVar9 == 0) {
        puVar23 = (uint64_t *)0x0;
    }
    if (puVar23 == (uint64_t *)0x0) {
        return;
    }
    uVar4 = *(uint64_t *)(iVar10 + 0x28);
    uVar18 = *puVar23;
    piVar1 = (int64_t *)(arg1 + 0x38);
    var_58h = uVar18;
    var_50h = uVar4;
    iVar10 = func_0x0001800ca160(piVar1, &var_58h);
    if (iVar10 != 0) {
        return;
    }
    iVar10 = *(int64_t *)(arg1 + 0x40);
    if (*(uint64_t *)(arg1 + 0x48) < (uint64_t)(iVar10 * 3) >> 2) goto code_r0x0001800c98c6;
    uVar18 = *(uint64_t *)(arg1 + 0x58);
    puVar2 = (uint64_t *)(arg1 + 0x50);
    uVar16 = *puVar2;
    if (iVar10 == 0) {
        uVar19 = 0x10;
        iVar9 = func_0x000180459890();
        var_18h = 0x10;
        uVar13 = 0;
        iVar10 = iVar9;
        uVar22 = 0x10;
        var_10h = iVar9;
code_r0x0001800c9770:
        do {
            uVar5 = *(undefined4 *)(arg1 + 0x54);
            uVar6 = *(undefined4 *)(arg1 + 0x58);
            uVar7 = *(undefined4 *)(arg1 + 0x5c);
            uVar14 = uVar13 + 1;
            puVar3 = (undefined4 *)(iVar9 + uVar13 * 0x10);
            *puVar3 = *(undefined4 *)puVar2;
            puVar3[1] = uVar5;
            puVar3[2] = uVar6;
            puVar3[3] = uVar7;
            uVar13 = uVar14;
        } while (uVar14 < uVar19);
    } else {
        uVar19 = iVar10 * 2;
        if (uVar19 == 0) {
            iVar10 = 0;
            uVar22 = 0;
            var_10h = 0;
            var_18h = 0;
        } else {
            iVar9 = func_0x000180459890();
            uVar13 = 0;
            iVar10 = iVar9;
            uVar22 = uVar19;
            var_10h = iVar9;
            var_18h = uVar19;
            if (uVar19 != 0) goto code_r0x0001800c9770;
        }
    }
    uVar19 = 0;
    if (*(int64_t *)(arg1 + 0x40) != 0) {
        do {
            uVar22 = *(uint64_t *)(*piVar1 + uVar19 * 0x10);
            iVar9 = *piVar1 + uVar19 * 0x10;
            if ((uVar22 != *puVar2) || (*(int64_t *)(iVar9 + 8) != *(int64_t *)(arg1 + 0x58))) {
                uVar13 = *(uint64_t *)(iVar9 + 8);
                uVar14 = ((uVar13 ^ uVar22) >> 5 ^ uVar13 ^ uVar22) >> 4;
                uVar21 = 0;
                while( true ) {
                    uVar14 = uVar14 & var_18h - 1U;
                    puVar20 = (uint64_t *)(iVar10 + uVar14 * 0x10);
                    iVar10 = var_10h;
                    if ((*puVar20 == uVar16) && (puVar20[1] == uVar18)) {
                        *puVar20 = uVar22;
                        puVar20[1] = *(uint64_t *)(iVar9 + 8);
                        goto code_r0x0001800c985e;
                    }
                    if ((*puVar20 == uVar22) && (puVar20[1] == uVar13)) goto code_r0x0001800c985e;
                    iVar15 = uVar14 + uVar21;
                    uVar21 = uVar21 + 1;
                    if (var_18h - 1U < uVar21) break;
                    uVar14 = iVar15 + 1;
                }
                puVar20 = (uint64_t *)0x0;
code_r0x0001800c985e:
                iVar9 = *piVar1;
                *puVar20 = *(uint64_t *)(iVar9 + uVar19 * 0x10);
                puVar20[1] = *(uint64_t *)(iVar9 + 8 + uVar19 * 0x10);
            }
            uVar19 = uVar19 + 1;
            uVar22 = var_18h;
        } while (uVar19 < *(uint64_t *)(arg1 + 0x40));
    }
    iVar9 = *piVar1;
    *piVar1 = iVar10;
    *(uint64_t *)(arg1 + 0x40) = uVar22;
    uVar18 = var_58h;
    if (iVar9 != 0) {
        func_0x0001800f4640();
        uVar18 = var_58h;
    }
code_r0x0001800c98c6:
    iVar10 = *piVar1;
    uVar22 = *(int64_t *)(arg1 + 0x40) - 1;
    uVar16 = ((uVar4 ^ uVar18) >> 5 ^ uVar4 ^ uVar18) >> 4;
    uVar19 = 0;
    while( true ) {
        uVar16 = uVar16 & uVar22;
        uVar13 = *(uint64_t *)(iVar10 + uVar16 * 0x10);
        iVar9 = iVar10 + uVar16 * 0x10;
        if ((uVar13 == *(uint64_t *)(arg1 + 0x50)) && (*(int64_t *)(iVar9 + 8) == *(int64_t *)(arg1 + 0x58))) break;
        if ((uVar13 == uVar18) && (*(uint64_t *)(iVar9 + 8) == uVar4)) goto code_r0x0001800c9937;
        iVar9 = uVar16 + uVar19;
        uVar19 = uVar19 + 1;
        if (uVar22 < uVar19) goto code_r0x0001800c9937;
        uVar16 = iVar9 + 1;
    }
    *(uint64_t *)(iVar10 + uVar16 * 0x10) = uVar18;
    *(uint64_t *)(iVar9 + 8) = uVar4;
    *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 1;
code_r0x0001800c9937:
    iVar10 = func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), puVar23);
    *(int32_t *)(iVar10 + 4) = *(int32_t *)(iVar10 + 4) + 1;
    return;
}

// ============================================================
// Function: FUN_1800c969c
// Address: 0x1800c969c
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.1800c9620(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t *puVar2;
    undefined4 *puVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t *puVar11;
    int32_t *piVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t iVar15;
    uint64_t uVar16;
    int32_t *piVar17;
    uint64_t uVar18;
    uint64_t uVar19;
    uint64_t *puVar20;
    uint64_t uVar21;
    uint64_t uVar22;
    uint64_t *puVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar8 = *(int32_t *)0x180782728;
    iVar10 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x18078269c) {
        iVar10 = arg2;
    }
    if (iVar10 == 0) {
        iVar10 = 0;
        if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782730) {
            iVar10 = arg2;
        }
        if (iVar10 == 0) {
            return;
        }
        iVar9 = 0;
        if (*(int32_t *)(*(int64_t *)(iVar10 + 0x20) + 8) == *(int32_t *)0x180782728) {
            iVar9 = *(int64_t *)(iVar10 + 0x20);
        }
        if (iVar9 == 0) {
            return;
        }
        iVar15 = fcn.1800ac7f0();
        iVar9 = iVar15 + 8;
        if (iVar15 == 0) {
            iVar9 = 0;
        }
        if (iVar9 == 0) {
            return;
        }
        iVar10 = *(int64_t *)(iVar10 + 0x28);
        iVar15 = 0;
        if (*(int32_t *)(iVar10 + 8) == *(int32_t *)0x1807826b4) {
            iVar15 = iVar10;
        }
        if (iVar15 != 0) {
            puVar11 = (uint32_t *)func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), iVar9);
            if (*(double *)(iVar15 + 0x20) != (double)(uint64_t)(*puVar11 + 1)) {
                return;
            }
            *puVar11 = *puVar11 + 1;
            return;
        }
        iVar15 = 0;
        if (*(int32_t *)(iVar10 + 8) == iVar8) {
            iVar15 = iVar10;
        }
        if (iVar15 == 0) {
            return;
        }
        iVar10 = fcn.1800ac7f0(arg1 + 0x68, iVar15 + 0x20);
        piVar17 = (int32_t *)(iVar10 + 8);
        if (iVar10 == 0) {
            piVar17 = (int32_t *)0x0;
        }
        if (piVar17 == (int32_t *)0x0) {
            return;
        }
        piVar12 = (int32_t *)func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), iVar9);
        if (*piVar12 != 0) {
            return;
        }
        *piVar12 = *piVar17;
        return;
    }
    iVar9 = 0;
    if (*(int32_t *)(*(int64_t *)(iVar10 + 0x20) + 8) == *(int32_t *)0x180782728) {
        iVar9 = *(int64_t *)(iVar10 + 0x20);
    }
    if (iVar9 == 0) {
        return;
    }
    iVar9 = fcn.1800ac7f0(arg1 + 0x10, iVar9 + 0x20);
    puVar23 = (uint64_t *)(iVar9 + 8);
    if (iVar9 == 0) {
        puVar23 = (uint64_t *)0x0;
    }
    if (puVar23 == (uint64_t *)0x0) {
        return;
    }
    uVar4 = *(uint64_t *)(iVar10 + 0x28);
    uVar18 = *puVar23;
    piVar1 = (int64_t *)(arg1 + 0x38);
    var_58h = uVar18;
    var_50h = uVar4;
    iVar10 = func_0x0001800ca160(piVar1, &var_58h);
    if (iVar10 != 0) {
        return;
    }
    iVar10 = *(int64_t *)(arg1 + 0x40);
    if (*(uint64_t *)(arg1 + 0x48) < (uint64_t)(iVar10 * 3) >> 2) goto code_r0x0001800c98c6;
    uVar18 = *(uint64_t *)(arg1 + 0x58);
    puVar2 = (uint64_t *)(arg1 + 0x50);
    uVar16 = *puVar2;
    if (iVar10 == 0) {
        uVar19 = 0x10;
        iVar9 = func_0x000180459890();
        var_18h = 0x10;
        uVar13 = 0;
        iVar10 = iVar9;
        uVar22 = 0x10;
        var_10h = iVar9;
code_r0x0001800c9770:
        do {
            uVar5 = *(undefined4 *)(arg1 + 0x54);
            uVar6 = *(undefined4 *)(arg1 + 0x58);
            uVar7 = *(undefined4 *)(arg1 + 0x5c);
            uVar14 = uVar13 + 1;
            puVar3 = (undefined4 *)(iVar9 + uVar13 * 0x10);
            *puVar3 = *(undefined4 *)puVar2;
            puVar3[1] = uVar5;
            puVar3[2] = uVar6;
            puVar3[3] = uVar7;
            uVar13 = uVar14;
        } while (uVar14 < uVar19);
    } else {
        uVar19 = iVar10 * 2;
        if (uVar19 == 0) {
            iVar10 = 0;
            uVar22 = 0;
            var_10h = 0;
            var_18h = 0;
        } else {
            iVar9 = func_0x000180459890();
            uVar13 = 0;
            iVar10 = iVar9;
            uVar22 = uVar19;
            var_10h = iVar9;
            var_18h = uVar19;
            if (uVar19 != 0) goto code_r0x0001800c9770;
        }
    }
    uVar19 = 0;
    if (*(int64_t *)(arg1 + 0x40) != 0) {
        do {
            uVar22 = *(uint64_t *)(*piVar1 + uVar19 * 0x10);
            iVar9 = *piVar1 + uVar19 * 0x10;
            if ((uVar22 != *puVar2) || (*(int64_t *)(iVar9 + 8) != *(int64_t *)(arg1 + 0x58))) {
                uVar13 = *(uint64_t *)(iVar9 + 8);
                uVar14 = ((uVar13 ^ uVar22) >> 5 ^ uVar13 ^ uVar22) >> 4;
                uVar21 = 0;
                while( true ) {
                    uVar14 = uVar14 & var_18h - 1U;
                    puVar20 = (uint64_t *)(iVar10 + uVar14 * 0x10);
                    iVar10 = var_10h;
                    if ((*puVar20 == uVar16) && (puVar20[1] == uVar18)) {
                        *puVar20 = uVar22;
                        puVar20[1] = *(uint64_t *)(iVar9 + 8);
                        goto code_r0x0001800c985e;
                    }
                    if ((*puVar20 == uVar22) && (puVar20[1] == uVar13)) goto code_r0x0001800c985e;
                    iVar15 = uVar14 + uVar21;
                    uVar21 = uVar21 + 1;
                    if (var_18h - 1U < uVar21) break;
                    uVar14 = iVar15 + 1;
                }
                puVar20 = (uint64_t *)0x0;
code_r0x0001800c985e:
                iVar9 = *piVar1;
                *puVar20 = *(uint64_t *)(iVar9 + uVar19 * 0x10);
                puVar20[1] = *(uint64_t *)(iVar9 + 8 + uVar19 * 0x10);
            }
            uVar19 = uVar19 + 1;
            uVar22 = var_18h;
        } while (uVar19 < *(uint64_t *)(arg1 + 0x40));
    }
    iVar9 = *piVar1;
    *piVar1 = iVar10;
    *(uint64_t *)(arg1 + 0x40) = uVar22;
    uVar18 = var_58h;
    if (iVar9 != 0) {
        func_0x0001800f4640();
        uVar18 = var_58h;
    }
code_r0x0001800c98c6:
    iVar10 = *piVar1;
    uVar22 = *(int64_t *)(arg1 + 0x40) - 1;
    uVar16 = ((uVar4 ^ uVar18) >> 5 ^ uVar4 ^ uVar18) >> 4;
    uVar19 = 0;
    while( true ) {
        uVar16 = uVar16 & uVar22;
        uVar13 = *(uint64_t *)(iVar10 + uVar16 * 0x10);
        iVar9 = iVar10 + uVar16 * 0x10;
        if ((uVar13 == *(uint64_t *)(arg1 + 0x50)) && (*(int64_t *)(iVar9 + 8) == *(int64_t *)(arg1 + 0x58))) break;
        if ((uVar13 == uVar18) && (*(uint64_t *)(iVar9 + 8) == uVar4)) goto code_r0x0001800c9937;
        iVar9 = uVar16 + uVar19;
        uVar19 = uVar19 + 1;
        if (uVar22 < uVar19) goto code_r0x0001800c9937;
        uVar16 = iVar9 + 1;
    }
    *(uint64_t *)(iVar10 + uVar16 * 0x10) = uVar18;
    *(uint64_t *)(iVar9 + 8) = uVar4;
    *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 1;
code_r0x0001800c9937:
    iVar10 = func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), puVar23);
    *(int32_t *)(iVar10 + 4) = *(int32_t *)(iVar10 + 4) + 1;
    return;
}

// ============================================================
// Function: FUN_1800c96ec
// Address: 0x1800c96ec
// Size: 451 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.1800c9620(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t *puVar2;
    undefined4 *puVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t *puVar11;
    int32_t *piVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t iVar15;
    uint64_t uVar16;
    int32_t *piVar17;
    uint64_t uVar18;
    uint64_t uVar19;
    uint64_t *puVar20;
    uint64_t uVar21;
    uint64_t uVar22;
    uint64_t *puVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar8 = *(int32_t *)0x180782728;
    iVar10 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x18078269c) {
        iVar10 = arg2;
    }
    if (iVar10 == 0) {
        iVar10 = 0;
        if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782730) {
            iVar10 = arg2;
        }
        if (iVar10 == 0) {
            return;
        }
        iVar9 = 0;
        if (*(int32_t *)(*(int64_t *)(iVar10 + 0x20) + 8) == *(int32_t *)0x180782728) {
            iVar9 = *(int64_t *)(iVar10 + 0x20);
        }
        if (iVar9 == 0) {
            return;
        }
        iVar15 = fcn.1800ac7f0();
        iVar9 = iVar15 + 8;
        if (iVar15 == 0) {
            iVar9 = 0;
        }
        if (iVar9 == 0) {
            return;
        }
        iVar10 = *(int64_t *)(iVar10 + 0x28);
        iVar15 = 0;
        if (*(int32_t *)(iVar10 + 8) == *(int32_t *)0x1807826b4) {
            iVar15 = iVar10;
        }
        if (iVar15 != 0) {
            puVar11 = (uint32_t *)func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), iVar9);
            if (*(double *)(iVar15 + 0x20) != (double)(uint64_t)(*puVar11 + 1)) {
                return;
            }
            *puVar11 = *puVar11 + 1;
            return;
        }
        iVar15 = 0;
        if (*(int32_t *)(iVar10 + 8) == iVar8) {
            iVar15 = iVar10;
        }
        if (iVar15 == 0) {
            return;
        }
        iVar10 = fcn.1800ac7f0(arg1 + 0x68, iVar15 + 0x20);
        piVar17 = (int32_t *)(iVar10 + 8);
        if (iVar10 == 0) {
            piVar17 = (int32_t *)0x0;
        }
        if (piVar17 == (int32_t *)0x0) {
            return;
        }
        piVar12 = (int32_t *)func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), iVar9);
        if (*piVar12 != 0) {
            return;
        }
        *piVar12 = *piVar17;
        return;
    }
    iVar9 = 0;
    if (*(int32_t *)(*(int64_t *)(iVar10 + 0x20) + 8) == *(int32_t *)0x180782728) {
        iVar9 = *(int64_t *)(iVar10 + 0x20);
    }
    if (iVar9 == 0) {
        return;
    }
    iVar9 = fcn.1800ac7f0(arg1 + 0x10, iVar9 + 0x20);
    puVar23 = (uint64_t *)(iVar9 + 8);
    if (iVar9 == 0) {
        puVar23 = (uint64_t *)0x0;
    }
    if (puVar23 == (uint64_t *)0x0) {
        return;
    }
    uVar4 = *(uint64_t *)(iVar10 + 0x28);
    uVar18 = *puVar23;
    piVar1 = (int64_t *)(arg1 + 0x38);
    var_58h = uVar18;
    var_50h = uVar4;
    iVar10 = func_0x0001800ca160(piVar1, &var_58h);
    if (iVar10 != 0) {
        return;
    }
    iVar10 = *(int64_t *)(arg1 + 0x40);
    if (*(uint64_t *)(arg1 + 0x48) < (uint64_t)(iVar10 * 3) >> 2) goto code_r0x0001800c98c6;
    uVar18 = *(uint64_t *)(arg1 + 0x58);
    puVar2 = (uint64_t *)(arg1 + 0x50);
    uVar16 = *puVar2;
    if (iVar10 == 0) {
        uVar19 = 0x10;
        iVar9 = func_0x000180459890();
        var_18h = 0x10;
        uVar13 = 0;
        iVar10 = iVar9;
        uVar22 = 0x10;
        var_10h = iVar9;
code_r0x0001800c9770:
        do {
            uVar5 = *(undefined4 *)(arg1 + 0x54);
            uVar6 = *(undefined4 *)(arg1 + 0x58);
            uVar7 = *(undefined4 *)(arg1 + 0x5c);
            uVar14 = uVar13 + 1;
            puVar3 = (undefined4 *)(iVar9 + uVar13 * 0x10);
            *puVar3 = *(undefined4 *)puVar2;
            puVar3[1] = uVar5;
            puVar3[2] = uVar6;
            puVar3[3] = uVar7;
            uVar13 = uVar14;
        } while (uVar14 < uVar19);
    } else {
        uVar19 = iVar10 * 2;
        if (uVar19 == 0) {
            iVar10 = 0;
            uVar22 = 0;
            var_10h = 0;
            var_18h = 0;
        } else {
            iVar9 = func_0x000180459890();
            uVar13 = 0;
            iVar10 = iVar9;
            uVar22 = uVar19;
            var_10h = iVar9;
            var_18h = uVar19;
            if (uVar19 != 0) goto code_r0x0001800c9770;
        }
    }
    uVar19 = 0;
    if (*(int64_t *)(arg1 + 0x40) != 0) {
        do {
            uVar22 = *(uint64_t *)(*piVar1 + uVar19 * 0x10);
            iVar9 = *piVar1 + uVar19 * 0x10;
            if ((uVar22 != *puVar2) || (*(int64_t *)(iVar9 + 8) != *(int64_t *)(arg1 + 0x58))) {
                uVar13 = *(uint64_t *)(iVar9 + 8);
                uVar14 = ((uVar13 ^ uVar22) >> 5 ^ uVar13 ^ uVar22) >> 4;
                uVar21 = 0;
                while( true ) {
                    uVar14 = uVar14 & var_18h - 1U;
                    puVar20 = (uint64_t *)(iVar10 + uVar14 * 0x10);
                    iVar10 = var_10h;
                    if ((*puVar20 == uVar16) && (puVar20[1] == uVar18)) {
                        *puVar20 = uVar22;
                        puVar20[1] = *(uint64_t *)(iVar9 + 8);
                        goto code_r0x0001800c985e;
                    }
                    if ((*puVar20 == uVar22) && (puVar20[1] == uVar13)) goto code_r0x0001800c985e;
                    iVar15 = uVar14 + uVar21;
                    uVar21 = uVar21 + 1;
                    if (var_18h - 1U < uVar21) break;
                    uVar14 = iVar15 + 1;
                }
                puVar20 = (uint64_t *)0x0;
code_r0x0001800c985e:
                iVar9 = *piVar1;
                *puVar20 = *(uint64_t *)(iVar9 + uVar19 * 0x10);
                puVar20[1] = *(uint64_t *)(iVar9 + 8 + uVar19 * 0x10);
            }
            uVar19 = uVar19 + 1;
            uVar22 = var_18h;
        } while (uVar19 < *(uint64_t *)(arg1 + 0x40));
    }
    iVar9 = *piVar1;
    *piVar1 = iVar10;
    *(uint64_t *)(arg1 + 0x40) = uVar22;
    uVar18 = var_58h;
    if (iVar9 != 0) {
        func_0x0001800f4640();
        uVar18 = var_58h;
    }
code_r0x0001800c98c6:
    iVar10 = *piVar1;
    uVar22 = *(int64_t *)(arg1 + 0x40) - 1;
    uVar16 = ((uVar4 ^ uVar18) >> 5 ^ uVar4 ^ uVar18) >> 4;
    uVar19 = 0;
    while( true ) {
        uVar16 = uVar16 & uVar22;
        uVar13 = *(uint64_t *)(iVar10 + uVar16 * 0x10);
        iVar9 = iVar10 + uVar16 * 0x10;
        if ((uVar13 == *(uint64_t *)(arg1 + 0x50)) && (*(int64_t *)(iVar9 + 8) == *(int64_t *)(arg1 + 0x58))) break;
        if ((uVar13 == uVar18) && (*(uint64_t *)(iVar9 + 8) == uVar4)) goto code_r0x0001800c9937;
        iVar9 = uVar16 + uVar19;
        uVar19 = uVar19 + 1;
        if (uVar22 < uVar19) goto code_r0x0001800c9937;
        uVar16 = iVar9 + 1;
    }
    *(uint64_t *)(iVar10 + uVar16 * 0x10) = uVar18;
    *(uint64_t *)(iVar9 + 8) = uVar4;
    *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 1;
code_r0x0001800c9937:
    iVar10 = func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), puVar23);
    *(int32_t *)(iVar10 + 4) = *(int32_t *)(iVar10 + 4) + 1;
    return;
}

// ============================================================
// Function: FUN_1800c98af
// Address: 0x1800c98af
// Size: 161 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.1800c9620(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t *puVar2;
    undefined4 *puVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t *puVar11;
    int32_t *piVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t iVar15;
    uint64_t uVar16;
    int32_t *piVar17;
    uint64_t uVar18;
    uint64_t uVar19;
    uint64_t *puVar20;
    uint64_t uVar21;
    uint64_t uVar22;
    uint64_t *puVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar8 = *(int32_t *)0x180782728;
    iVar10 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x18078269c) {
        iVar10 = arg2;
    }
    if (iVar10 == 0) {
        iVar10 = 0;
        if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782730) {
            iVar10 = arg2;
        }
        if (iVar10 == 0) {
            return;
        }
        iVar9 = 0;
        if (*(int32_t *)(*(int64_t *)(iVar10 + 0x20) + 8) == *(int32_t *)0x180782728) {
            iVar9 = *(int64_t *)(iVar10 + 0x20);
        }
        if (iVar9 == 0) {
            return;
        }
        iVar15 = fcn.1800ac7f0();
        iVar9 = iVar15 + 8;
        if (iVar15 == 0) {
            iVar9 = 0;
        }
        if (iVar9 == 0) {
            return;
        }
        iVar10 = *(int64_t *)(iVar10 + 0x28);
        iVar15 = 0;
        if (*(int32_t *)(iVar10 + 8) == *(int32_t *)0x1807826b4) {
            iVar15 = iVar10;
        }
        if (iVar15 != 0) {
            puVar11 = (uint32_t *)func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), iVar9);
            if (*(double *)(iVar15 + 0x20) != (double)(uint64_t)(*puVar11 + 1)) {
                return;
            }
            *puVar11 = *puVar11 + 1;
            return;
        }
        iVar15 = 0;
        if (*(int32_t *)(iVar10 + 8) == iVar8) {
            iVar15 = iVar10;
        }
        if (iVar15 == 0) {
            return;
        }
        iVar10 = fcn.1800ac7f0(arg1 + 0x68, iVar15 + 0x20);
        piVar17 = (int32_t *)(iVar10 + 8);
        if (iVar10 == 0) {
            piVar17 = (int32_t *)0x0;
        }
        if (piVar17 == (int32_t *)0x0) {
            return;
        }
        piVar12 = (int32_t *)func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), iVar9);
        if (*piVar12 != 0) {
            return;
        }
        *piVar12 = *piVar17;
        return;
    }
    iVar9 = 0;
    if (*(int32_t *)(*(int64_t *)(iVar10 + 0x20) + 8) == *(int32_t *)0x180782728) {
        iVar9 = *(int64_t *)(iVar10 + 0x20);
    }
    if (iVar9 == 0) {
        return;
    }
    iVar9 = fcn.1800ac7f0(arg1 + 0x10, iVar9 + 0x20);
    puVar23 = (uint64_t *)(iVar9 + 8);
    if (iVar9 == 0) {
        puVar23 = (uint64_t *)0x0;
    }
    if (puVar23 == (uint64_t *)0x0) {
        return;
    }
    uVar4 = *(uint64_t *)(iVar10 + 0x28);
    uVar18 = *puVar23;
    piVar1 = (int64_t *)(arg1 + 0x38);
    var_58h = uVar18;
    var_50h = uVar4;
    iVar10 = func_0x0001800ca160(piVar1, &var_58h);
    if (iVar10 != 0) {
        return;
    }
    iVar10 = *(int64_t *)(arg1 + 0x40);
    if (*(uint64_t *)(arg1 + 0x48) < (uint64_t)(iVar10 * 3) >> 2) goto code_r0x0001800c98c6;
    uVar18 = *(uint64_t *)(arg1 + 0x58);
    puVar2 = (uint64_t *)(arg1 + 0x50);
    uVar16 = *puVar2;
    if (iVar10 == 0) {
        uVar19 = 0x10;
        iVar9 = func_0x000180459890();
        var_18h = 0x10;
        uVar13 = 0;
        iVar10 = iVar9;
        uVar22 = 0x10;
        var_10h = iVar9;
code_r0x0001800c9770:
        do {
            uVar5 = *(undefined4 *)(arg1 + 0x54);
            uVar6 = *(undefined4 *)(arg1 + 0x58);
            uVar7 = *(undefined4 *)(arg1 + 0x5c);
            uVar14 = uVar13 + 1;
            puVar3 = (undefined4 *)(iVar9 + uVar13 * 0x10);
            *puVar3 = *(undefined4 *)puVar2;
            puVar3[1] = uVar5;
            puVar3[2] = uVar6;
            puVar3[3] = uVar7;
            uVar13 = uVar14;
        } while (uVar14 < uVar19);
    } else {
        uVar19 = iVar10 * 2;
        if (uVar19 == 0) {
            iVar10 = 0;
            uVar22 = 0;
            var_10h = 0;
            var_18h = 0;
        } else {
            iVar9 = func_0x000180459890();
            uVar13 = 0;
            iVar10 = iVar9;
            uVar22 = uVar19;
            var_10h = iVar9;
            var_18h = uVar19;
            if (uVar19 != 0) goto code_r0x0001800c9770;
        }
    }
    uVar19 = 0;
    if (*(int64_t *)(arg1 + 0x40) != 0) {
        do {
            uVar22 = *(uint64_t *)(*piVar1 + uVar19 * 0x10);
            iVar9 = *piVar1 + uVar19 * 0x10;
            if ((uVar22 != *puVar2) || (*(int64_t *)(iVar9 + 8) != *(int64_t *)(arg1 + 0x58))) {
                uVar13 = *(uint64_t *)(iVar9 + 8);
                uVar14 = ((uVar13 ^ uVar22) >> 5 ^ uVar13 ^ uVar22) >> 4;
                uVar21 = 0;
                while( true ) {
                    uVar14 = uVar14 & var_18h - 1U;
                    puVar20 = (uint64_t *)(iVar10 + uVar14 * 0x10);
                    iVar10 = var_10h;
                    if ((*puVar20 == uVar16) && (puVar20[1] == uVar18)) {
                        *puVar20 = uVar22;
                        puVar20[1] = *(uint64_t *)(iVar9 + 8);
                        goto code_r0x0001800c985e;
                    }
                    if ((*puVar20 == uVar22) && (puVar20[1] == uVar13)) goto code_r0x0001800c985e;
                    iVar15 = uVar14 + uVar21;
                    uVar21 = uVar21 + 1;
                    if (var_18h - 1U < uVar21) break;
                    uVar14 = iVar15 + 1;
                }
                puVar20 = (uint64_t *)0x0;
code_r0x0001800c985e:
                iVar9 = *piVar1;
                *puVar20 = *(uint64_t *)(iVar9 + uVar19 * 0x10);
                puVar20[1] = *(uint64_t *)(iVar9 + 8 + uVar19 * 0x10);
            }
            uVar19 = uVar19 + 1;
            uVar22 = var_18h;
        } while (uVar19 < *(uint64_t *)(arg1 + 0x40));
    }
    iVar9 = *piVar1;
    *piVar1 = iVar10;
    *(uint64_t *)(arg1 + 0x40) = uVar22;
    uVar18 = var_58h;
    if (iVar9 != 0) {
        func_0x0001800f4640();
        uVar18 = var_58h;
    }
code_r0x0001800c98c6:
    iVar10 = *piVar1;
    uVar22 = *(int64_t *)(arg1 + 0x40) - 1;
    uVar16 = ((uVar4 ^ uVar18) >> 5 ^ uVar4 ^ uVar18) >> 4;
    uVar19 = 0;
    while( true ) {
        uVar16 = uVar16 & uVar22;
        uVar13 = *(uint64_t *)(iVar10 + uVar16 * 0x10);
        iVar9 = iVar10 + uVar16 * 0x10;
        if ((uVar13 == *(uint64_t *)(arg1 + 0x50)) && (*(int64_t *)(iVar9 + 8) == *(int64_t *)(arg1 + 0x58))) break;
        if ((uVar13 == uVar18) && (*(uint64_t *)(iVar9 + 8) == uVar4)) goto code_r0x0001800c9937;
        iVar9 = uVar16 + uVar19;
        uVar19 = uVar19 + 1;
        if (uVar22 < uVar19) goto code_r0x0001800c9937;
        uVar16 = iVar9 + 1;
    }
    *(uint64_t *)(iVar10 + uVar16 * 0x10) = uVar18;
    *(uint64_t *)(iVar9 + 8) = uVar4;
    *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 1;
code_r0x0001800c9937:
    iVar10 = func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), puVar23);
    *(int32_t *)(iVar10 + 4) = *(int32_t *)(iVar10 + 4) + 1;
    return;
}

// ============================================================
// Function: FUN_1800c9950
// Address: 0x1800c9950
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.1800c9620(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t *puVar2;
    undefined4 *puVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t *puVar11;
    int32_t *piVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t iVar15;
    uint64_t uVar16;
    int32_t *piVar17;
    uint64_t uVar18;
    uint64_t uVar19;
    uint64_t *puVar20;
    uint64_t uVar21;
    uint64_t uVar22;
    uint64_t *puVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar8 = *(int32_t *)0x180782728;
    iVar10 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x18078269c) {
        iVar10 = arg2;
    }
    if (iVar10 == 0) {
        iVar10 = 0;
        if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782730) {
            iVar10 = arg2;
        }
        if (iVar10 == 0) {
            return;
        }
        iVar9 = 0;
        if (*(int32_t *)(*(int64_t *)(iVar10 + 0x20) + 8) == *(int32_t *)0x180782728) {
            iVar9 = *(int64_t *)(iVar10 + 0x20);
        }
        if (iVar9 == 0) {
            return;
        }
        iVar15 = fcn.1800ac7f0();
        iVar9 = iVar15 + 8;
        if (iVar15 == 0) {
            iVar9 = 0;
        }
        if (iVar9 == 0) {
            return;
        }
        iVar10 = *(int64_t *)(iVar10 + 0x28);
        iVar15 = 0;
        if (*(int32_t *)(iVar10 + 8) == *(int32_t *)0x1807826b4) {
            iVar15 = iVar10;
        }
        if (iVar15 != 0) {
            puVar11 = (uint32_t *)func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), iVar9);
            if (*(double *)(iVar15 + 0x20) != (double)(uint64_t)(*puVar11 + 1)) {
                return;
            }
            *puVar11 = *puVar11 + 1;
            return;
        }
        iVar15 = 0;
        if (*(int32_t *)(iVar10 + 8) == iVar8) {
            iVar15 = iVar10;
        }
        if (iVar15 == 0) {
            return;
        }
        iVar10 = fcn.1800ac7f0(arg1 + 0x68, iVar15 + 0x20);
        piVar17 = (int32_t *)(iVar10 + 8);
        if (iVar10 == 0) {
            piVar17 = (int32_t *)0x0;
        }
        if (piVar17 == (int32_t *)0x0) {
            return;
        }
        piVar12 = (int32_t *)func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), iVar9);
        if (*piVar12 != 0) {
            return;
        }
        *piVar12 = *piVar17;
        return;
    }
    iVar9 = 0;
    if (*(int32_t *)(*(int64_t *)(iVar10 + 0x20) + 8) == *(int32_t *)0x180782728) {
        iVar9 = *(int64_t *)(iVar10 + 0x20);
    }
    if (iVar9 == 0) {
        return;
    }
    iVar9 = fcn.1800ac7f0(arg1 + 0x10, iVar9 + 0x20);
    puVar23 = (uint64_t *)(iVar9 + 8);
    if (iVar9 == 0) {
        puVar23 = (uint64_t *)0x0;
    }
    if (puVar23 == (uint64_t *)0x0) {
        return;
    }
    uVar4 = *(uint64_t *)(iVar10 + 0x28);
    uVar18 = *puVar23;
    piVar1 = (int64_t *)(arg1 + 0x38);
    var_58h = uVar18;
    var_50h = uVar4;
    iVar10 = func_0x0001800ca160(piVar1, &var_58h);
    if (iVar10 != 0) {
        return;
    }
    iVar10 = *(int64_t *)(arg1 + 0x40);
    if (*(uint64_t *)(arg1 + 0x48) < (uint64_t)(iVar10 * 3) >> 2) goto code_r0x0001800c98c6;
    uVar18 = *(uint64_t *)(arg1 + 0x58);
    puVar2 = (uint64_t *)(arg1 + 0x50);
    uVar16 = *puVar2;
    if (iVar10 == 0) {
        uVar19 = 0x10;
        iVar9 = func_0x000180459890();
        var_18h = 0x10;
        uVar13 = 0;
        iVar10 = iVar9;
        uVar22 = 0x10;
        var_10h = iVar9;
code_r0x0001800c9770:
        do {
            uVar5 = *(undefined4 *)(arg1 + 0x54);
            uVar6 = *(undefined4 *)(arg1 + 0x58);
            uVar7 = *(undefined4 *)(arg1 + 0x5c);
            uVar14 = uVar13 + 1;
            puVar3 = (undefined4 *)(iVar9 + uVar13 * 0x10);
            *puVar3 = *(undefined4 *)puVar2;
            puVar3[1] = uVar5;
            puVar3[2] = uVar6;
            puVar3[3] = uVar7;
            uVar13 = uVar14;
        } while (uVar14 < uVar19);
    } else {
        uVar19 = iVar10 * 2;
        if (uVar19 == 0) {
            iVar10 = 0;
            uVar22 = 0;
            var_10h = 0;
            var_18h = 0;
        } else {
            iVar9 = func_0x000180459890();
            uVar13 = 0;
            iVar10 = iVar9;
            uVar22 = uVar19;
            var_10h = iVar9;
            var_18h = uVar19;
            if (uVar19 != 0) goto code_r0x0001800c9770;
        }
    }
    uVar19 = 0;
    if (*(int64_t *)(arg1 + 0x40) != 0) {
        do {
            uVar22 = *(uint64_t *)(*piVar1 + uVar19 * 0x10);
            iVar9 = *piVar1 + uVar19 * 0x10;
            if ((uVar22 != *puVar2) || (*(int64_t *)(iVar9 + 8) != *(int64_t *)(arg1 + 0x58))) {
                uVar13 = *(uint64_t *)(iVar9 + 8);
                uVar14 = ((uVar13 ^ uVar22) >> 5 ^ uVar13 ^ uVar22) >> 4;
                uVar21 = 0;
                while( true ) {
                    uVar14 = uVar14 & var_18h - 1U;
                    puVar20 = (uint64_t *)(iVar10 + uVar14 * 0x10);
                    iVar10 = var_10h;
                    if ((*puVar20 == uVar16) && (puVar20[1] == uVar18)) {
                        *puVar20 = uVar22;
                        puVar20[1] = *(uint64_t *)(iVar9 + 8);
                        goto code_r0x0001800c985e;
                    }
                    if ((*puVar20 == uVar22) && (puVar20[1] == uVar13)) goto code_r0x0001800c985e;
                    iVar15 = uVar14 + uVar21;
                    uVar21 = uVar21 + 1;
                    if (var_18h - 1U < uVar21) break;
                    uVar14 = iVar15 + 1;
                }
                puVar20 = (uint64_t *)0x0;
code_r0x0001800c985e:
                iVar9 = *piVar1;
                *puVar20 = *(uint64_t *)(iVar9 + uVar19 * 0x10);
                puVar20[1] = *(uint64_t *)(iVar9 + 8 + uVar19 * 0x10);
            }
            uVar19 = uVar19 + 1;
            uVar22 = var_18h;
        } while (uVar19 < *(uint64_t *)(arg1 + 0x40));
    }
    iVar9 = *piVar1;
    *piVar1 = iVar10;
    *(uint64_t *)(arg1 + 0x40) = uVar22;
    uVar18 = var_58h;
    if (iVar9 != 0) {
        func_0x0001800f4640();
        uVar18 = var_58h;
    }
code_r0x0001800c98c6:
    iVar10 = *piVar1;
    uVar22 = *(int64_t *)(arg1 + 0x40) - 1;
    uVar16 = ((uVar4 ^ uVar18) >> 5 ^ uVar4 ^ uVar18) >> 4;
    uVar19 = 0;
    while( true ) {
        uVar16 = uVar16 & uVar22;
        uVar13 = *(uint64_t *)(iVar10 + uVar16 * 0x10);
        iVar9 = iVar10 + uVar16 * 0x10;
        if ((uVar13 == *(uint64_t *)(arg1 + 0x50)) && (*(int64_t *)(iVar9 + 8) == *(int64_t *)(arg1 + 0x58))) break;
        if ((uVar13 == uVar18) && (*(uint64_t *)(iVar9 + 8) == uVar4)) goto code_r0x0001800c9937;
        iVar9 = uVar16 + uVar19;
        uVar19 = uVar19 + 1;
        if (uVar22 < uVar19) goto code_r0x0001800c9937;
        uVar16 = iVar9 + 1;
    }
    *(uint64_t *)(iVar10 + uVar16 * 0x10) = uVar18;
    *(uint64_t *)(iVar9 + 8) = uVar4;
    *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 1;
code_r0x0001800c9937:
    iVar10 = func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), puVar23);
    *(int32_t *)(iVar10 + 4) = *(int32_t *)(iVar10 + 4) + 1;
    return;
}

// ============================================================
// Function: FUN_1800c9955
// Address: 0x1800c9955
// Size: 250 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.1800c9620(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t *puVar2;
    undefined4 *puVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t *puVar11;
    int32_t *piVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t iVar15;
    uint64_t uVar16;
    int32_t *piVar17;
    uint64_t uVar18;
    uint64_t uVar19;
    uint64_t *puVar20;
    uint64_t uVar21;
    uint64_t uVar22;
    uint64_t *puVar23;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar8 = *(int32_t *)0x180782728;
    iVar10 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x18078269c) {
        iVar10 = arg2;
    }
    if (iVar10 == 0) {
        iVar10 = 0;
        if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782730) {
            iVar10 = arg2;
        }
        if (iVar10 == 0) {
            return;
        }
        iVar9 = 0;
        if (*(int32_t *)(*(int64_t *)(iVar10 + 0x20) + 8) == *(int32_t *)0x180782728) {
            iVar9 = *(int64_t *)(iVar10 + 0x20);
        }
        if (iVar9 == 0) {
            return;
        }
        iVar15 = fcn.1800ac7f0();
        iVar9 = iVar15 + 8;
        if (iVar15 == 0) {
            iVar9 = 0;
        }
        if (iVar9 == 0) {
            return;
        }
        iVar10 = *(int64_t *)(iVar10 + 0x28);
        iVar15 = 0;
        if (*(int32_t *)(iVar10 + 8) == *(int32_t *)0x1807826b4) {
            iVar15 = iVar10;
        }
        if (iVar15 != 0) {
            puVar11 = (uint32_t *)func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), iVar9);
            if (*(double *)(iVar15 + 0x20) != (double)(uint64_t)(*puVar11 + 1)) {
                return;
            }
            *puVar11 = *puVar11 + 1;
            return;
        }
        iVar15 = 0;
        if (*(int32_t *)(iVar10 + 8) == iVar8) {
            iVar15 = iVar10;
        }
        if (iVar15 == 0) {
            return;
        }
        iVar10 = fcn.1800ac7f0(arg1 + 0x68, iVar15 + 0x20);
        piVar17 = (int32_t *)(iVar10 + 8);
        if (iVar10 == 0) {
            piVar17 = (int32_t *)0x0;
        }
        if (piVar17 == (int32_t *)0x0) {
            return;
        }
        piVar12 = (int32_t *)func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), iVar9);
        if (*piVar12 != 0) {
            return;
        }
        *piVar12 = *piVar17;
        return;
    }
    iVar9 = 0;
    if (*(int32_t *)(*(int64_t *)(iVar10 + 0x20) + 8) == *(int32_t *)0x180782728) {
        iVar9 = *(int64_t *)(iVar10 + 0x20);
    }
    if (iVar9 == 0) {
        return;
    }
    iVar9 = fcn.1800ac7f0(arg1 + 0x10, iVar9 + 0x20);
    puVar23 = (uint64_t *)(iVar9 + 8);
    if (iVar9 == 0) {
        puVar23 = (uint64_t *)0x0;
    }
    if (puVar23 == (uint64_t *)0x0) {
        return;
    }
    uVar4 = *(uint64_t *)(iVar10 + 0x28);
    uVar18 = *puVar23;
    piVar1 = (int64_t *)(arg1 + 0x38);
    var_58h = uVar18;
    var_50h = uVar4;
    iVar10 = func_0x0001800ca160(piVar1, &var_58h);
    if (iVar10 != 0) {
        return;
    }
    iVar10 = *(int64_t *)(arg1 + 0x40);
    if (*(uint64_t *)(arg1 + 0x48) < (uint64_t)(iVar10 * 3) >> 2) goto code_r0x0001800c98c6;
    uVar18 = *(uint64_t *)(arg1 + 0x58);
    puVar2 = (uint64_t *)(arg1 + 0x50);
    uVar16 = *puVar2;
    if (iVar10 == 0) {
        uVar19 = 0x10;
        iVar9 = func_0x000180459890();
        var_18h = 0x10;
        uVar13 = 0;
        iVar10 = iVar9;
        uVar22 = 0x10;
        var_10h = iVar9;
code_r0x0001800c9770:
        do {
            uVar5 = *(undefined4 *)(arg1 + 0x54);
            uVar6 = *(undefined4 *)(arg1 + 0x58);
            uVar7 = *(undefined4 *)(arg1 + 0x5c);
            uVar14 = uVar13 + 1;
            puVar3 = (undefined4 *)(iVar9 + uVar13 * 0x10);
            *puVar3 = *(undefined4 *)puVar2;
            puVar3[1] = uVar5;
            puVar3[2] = uVar6;
            puVar3[3] = uVar7;
            uVar13 = uVar14;
        } while (uVar14 < uVar19);
    } else {
        uVar19 = iVar10 * 2;
        if (uVar19 == 0) {
            iVar10 = 0;
            uVar22 = 0;
            var_10h = 0;
            var_18h = 0;
        } else {
            iVar9 = func_0x000180459890();
            uVar13 = 0;
            iVar10 = iVar9;
            uVar22 = uVar19;
            var_10h = iVar9;
            var_18h = uVar19;
            if (uVar19 != 0) goto code_r0x0001800c9770;
        }
    }
    uVar19 = 0;
    if (*(int64_t *)(arg1 + 0x40) != 0) {
        do {
            uVar22 = *(uint64_t *)(*piVar1 + uVar19 * 0x10);
            iVar9 = *piVar1 + uVar19 * 0x10;
            if ((uVar22 != *puVar2) || (*(int64_t *)(iVar9 + 8) != *(int64_t *)(arg1 + 0x58))) {
                uVar13 = *(uint64_t *)(iVar9 + 8);
                uVar14 = ((uVar13 ^ uVar22) >> 5 ^ uVar13 ^ uVar22) >> 4;
                uVar21 = 0;
                while( true ) {
                    uVar14 = uVar14 & var_18h - 1U;
                    puVar20 = (uint64_t *)(iVar10 + uVar14 * 0x10);
                    iVar10 = var_10h;
                    if ((*puVar20 == uVar16) && (puVar20[1] == uVar18)) {
                        *puVar20 = uVar22;
                        puVar20[1] = *(uint64_t *)(iVar9 + 8);
                        goto code_r0x0001800c985e;
                    }
                    if ((*puVar20 == uVar22) && (puVar20[1] == uVar13)) goto code_r0x0001800c985e;
                    iVar15 = uVar14 + uVar21;
                    uVar21 = uVar21 + 1;
                    if (var_18h - 1U < uVar21) break;
                    uVar14 = iVar15 + 1;
                }
                puVar20 = (uint64_t *)0x0;
code_r0x0001800c985e:
                iVar9 = *piVar1;
                *puVar20 = *(uint64_t *)(iVar9 + uVar19 * 0x10);
                puVar20[1] = *(uint64_t *)(iVar9 + 8 + uVar19 * 0x10);
            }
            uVar19 = uVar19 + 1;
            uVar22 = var_18h;
        } while (uVar19 < *(uint64_t *)(arg1 + 0x40));
    }
    iVar9 = *piVar1;
    *piVar1 = iVar10;
    *(uint64_t *)(arg1 + 0x40) = uVar22;
    uVar18 = var_58h;
    if (iVar9 != 0) {
        func_0x0001800f4640();
        uVar18 = var_58h;
    }
code_r0x0001800c98c6:
    iVar10 = *piVar1;
    uVar22 = *(int64_t *)(arg1 + 0x40) - 1;
    uVar16 = ((uVar4 ^ uVar18) >> 5 ^ uVar4 ^ uVar18) >> 4;
    uVar19 = 0;
    while( true ) {
        uVar16 = uVar16 & uVar22;
        uVar13 = *(uint64_t *)(iVar10 + uVar16 * 0x10);
        iVar9 = iVar10 + uVar16 * 0x10;
        if ((uVar13 == *(uint64_t *)(arg1 + 0x50)) && (*(int64_t *)(iVar9 + 8) == *(int64_t *)(arg1 + 0x58))) break;
        if ((uVar13 == uVar18) && (*(uint64_t *)(iVar9 + 8) == uVar4)) goto code_r0x0001800c9937;
        iVar9 = uVar16 + uVar19;
        uVar19 = uVar19 + 1;
        if (uVar22 < uVar19) goto code_r0x0001800c9937;
        uVar16 = iVar9 + 1;
    }
    *(uint64_t *)(iVar10 + uVar16 * 0x10) = uVar18;
    *(uint64_t *)(iVar9 + 8) = uVar4;
    *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 1;
code_r0x0001800c9937:
    iVar10 = func_0x0001800c03e0(*(undefined8 *)(arg1 + 8), puVar23);
    *(int32_t *)(iVar10 + 4) = *(int32_t *)(iVar10 + 4) + 1;
    return;
}

// ============================================================
// Function: FUN_1800c9a50
// Address: 0x1800c9a50
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.1800c9a50(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t *puVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t *puVar13;
    uint64_t uVar14;
    int64_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar5 = *(int32_t *)0x180782758;
    if (*(int64_t *)(arg2 + 0x30) != 1) {
        return 1;
    }
    if (*(int64_t *)(arg2 + 0x40) != 1) {
        return 1;
    }
    iVar8 = **(int64_t **)(arg2 + 0x38);
    iVar15 = 0;
    if (*(int32_t *)(iVar8 + 8) == *(int32_t *)0x180782758) {
        iVar15 = iVar8;
    }
    if (iVar15 == 0) {
        iVar7 = 0;
        if (*(int32_t *)(iVar8 + 8) == *(int32_t *)0x180782740) {
            iVar7 = iVar8;
        }
        if (iVar7 == 0) {
            return 1;
        }
        if (*(char *)(iVar7 + 0x48) != '\0') {
            return 1;
        }
        if (*(int64_t *)(iVar7 + 0x40) != 2) {
            return 1;
        }
        iVar8 = 0;
        if (*(int32_t *)(*(int64_t *)(iVar7 + 0x20) + 8) == *(int32_t *)0x180782738) {
            iVar8 = *(int64_t *)(iVar7 + 0x20);
        }
        if (iVar8 == 0) {
            return 1;
        }
        if (*(int64_t *)(iVar8 + 0x20) == 0) {
            return 1;
        }
        iVar6 = func_0x000180498f10(*(int64_t *)(iVar8 + 0x20), 0x180622870);
        if (iVar6 != 0) {
            return 1;
        }
        if (*(int32_t *)(**(int64_t **)(iVar7 + 0x38) + 8) == iVar5) {
            iVar15 = **(int64_t **)(iVar7 + 0x38);
        }
        if (iVar15 == 0) {
            return 1;
        }
    }
    if (*(int64_t *)(iVar15 + 0x28) != 0) {
        return 1;
    }
    uVar3 = *(undefined8 *)(arg2 + 0x28);
    piVar1 = (int64_t *)(arg1 + 0x10);
    iVar8 = *(int64_t *)(arg1 + 0x18);
    if ((*(uint64_t *)(arg1 + 0x20) < (uint64_t)(iVar8 * 3) >> 2) || (iVar7 = fcn.1800ac7f0(piVar1), iVar7 != 0))
    goto code_r0x0001800c9caa;
    puVar2 = (uint64_t *)(arg1 + 0x28);
    uVar4 = *puVar2;
    if (iVar8 == 0) {
        uVar12 = 0x10;
        iVar7 = func_0x000180459890(0x100);
        uVar9 = 0;
        iVar8 = iVar7;
        uVar14 = 0x10;
code_r0x0001800c9bd0:
        do {
            uVar10 = uVar9 + 1;
            *(uint64_t *)(iVar8 + uVar9 * 0x10) = *puVar2;
            *(undefined8 *)(iVar8 + 8 + uVar9 * 0x10) = 0;
            uVar9 = uVar10;
        } while (uVar10 < uVar12);
    } else {
        uVar12 = iVar8 * 2;
        if (uVar12 == 0) {
            iVar7 = 0;
            uVar14 = 0;
        } else {
            iVar7 = func_0x000180459890(iVar8 << 5);
            uVar9 = 0;
            iVar8 = iVar7;
            uVar14 = uVar12;
            if (uVar12 != 0) goto code_r0x0001800c9bd0;
        }
    }
    uVar12 = 0;
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        do {
            uVar9 = *(uint64_t *)(*piVar1 + uVar12 * 0x10);
            if (uVar9 != *puVar2) {
                uVar10 = (uVar9 >> 5 ^ uVar9) >> 4;
                uVar11 = 0;
                do {
                    uVar10 = uVar10 & uVar14 - 1;
                    puVar13 = (uint64_t *)(uVar10 * 0x10 + iVar7);
                    if (*puVar13 == uVar4) {
                        *puVar13 = uVar9;
                        goto code_r0x0001800c9c67;
                    }
                    if (*puVar13 == uVar9) goto code_r0x0001800c9c67;
                    uVar10 = uVar10 + 1 + uVar11;
                    uVar11 = uVar11 + 1;
                } while (uVar11 <= uVar14 - 1);
                puVar13 = (uint64_t *)0x0;
code_r0x0001800c9c67:
                iVar8 = *piVar1;
                *puVar13 = *(uint64_t *)(iVar8 + uVar12 * 0x10);
                puVar13[1] = *(uint64_t *)(iVar8 + 8 + uVar12 * 0x10);
            }
            uVar12 = uVar12 + 1;
        } while (uVar12 < *(uint64_t *)(arg1 + 0x18));
    }
    iVar8 = *piVar1;
    *(uint64_t *)(arg1 + 0x18) = uVar14;
    *piVar1 = iVar7;
    if (iVar8 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c9caa:
    iVar8 = func_0x0001800ac6e0(piVar1, uVar3);
    *(int64_t *)(iVar8 + 8) = iVar15;
    return 1;
}

// ============================================================
// Function: FUN_1800c9a77
// Address: 0x1800c9a77
// Size: 233 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.1800c9a50(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t *puVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t *puVar13;
    uint64_t uVar14;
    int64_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar5 = *(int32_t *)0x180782758;
    if (*(int64_t *)(arg2 + 0x30) != 1) {
        return 1;
    }
    if (*(int64_t *)(arg2 + 0x40) != 1) {
        return 1;
    }
    iVar8 = **(int64_t **)(arg2 + 0x38);
    iVar15 = 0;
    if (*(int32_t *)(iVar8 + 8) == *(int32_t *)0x180782758) {
        iVar15 = iVar8;
    }
    if (iVar15 == 0) {
        iVar7 = 0;
        if (*(int32_t *)(iVar8 + 8) == *(int32_t *)0x180782740) {
            iVar7 = iVar8;
        }
        if (iVar7 == 0) {
            return 1;
        }
        if (*(char *)(iVar7 + 0x48) != '\0') {
            return 1;
        }
        if (*(int64_t *)(iVar7 + 0x40) != 2) {
            return 1;
        }
        iVar8 = 0;
        if (*(int32_t *)(*(int64_t *)(iVar7 + 0x20) + 8) == *(int32_t *)0x180782738) {
            iVar8 = *(int64_t *)(iVar7 + 0x20);
        }
        if (iVar8 == 0) {
            return 1;
        }
        if (*(int64_t *)(iVar8 + 0x20) == 0) {
            return 1;
        }
        iVar6 = func_0x000180498f10(*(int64_t *)(iVar8 + 0x20), 0x180622870);
        if (iVar6 != 0) {
            return 1;
        }
        if (*(int32_t *)(**(int64_t **)(iVar7 + 0x38) + 8) == iVar5) {
            iVar15 = **(int64_t **)(iVar7 + 0x38);
        }
        if (iVar15 == 0) {
            return 1;
        }
    }
    if (*(int64_t *)(iVar15 + 0x28) != 0) {
        return 1;
    }
    uVar3 = *(undefined8 *)(arg2 + 0x28);
    piVar1 = (int64_t *)(arg1 + 0x10);
    iVar8 = *(int64_t *)(arg1 + 0x18);
    if ((*(uint64_t *)(arg1 + 0x20) < (uint64_t)(iVar8 * 3) >> 2) || (iVar7 = fcn.1800ac7f0(piVar1), iVar7 != 0))
    goto code_r0x0001800c9caa;
    puVar2 = (uint64_t *)(arg1 + 0x28);
    uVar4 = *puVar2;
    if (iVar8 == 0) {
        uVar12 = 0x10;
        iVar7 = func_0x000180459890(0x100);
        uVar9 = 0;
        iVar8 = iVar7;
        uVar14 = 0x10;
code_r0x0001800c9bd0:
        do {
            uVar10 = uVar9 + 1;
            *(uint64_t *)(iVar8 + uVar9 * 0x10) = *puVar2;
            *(undefined8 *)(iVar8 + 8 + uVar9 * 0x10) = 0;
            uVar9 = uVar10;
        } while (uVar10 < uVar12);
    } else {
        uVar12 = iVar8 * 2;
        if (uVar12 == 0) {
            iVar7 = 0;
            uVar14 = 0;
        } else {
            iVar7 = func_0x000180459890(iVar8 << 5);
            uVar9 = 0;
            iVar8 = iVar7;
            uVar14 = uVar12;
            if (uVar12 != 0) goto code_r0x0001800c9bd0;
        }
    }
    uVar12 = 0;
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        do {
            uVar9 = *(uint64_t *)(*piVar1 + uVar12 * 0x10);
            if (uVar9 != *puVar2) {
                uVar10 = (uVar9 >> 5 ^ uVar9) >> 4;
                uVar11 = 0;
                do {
                    uVar10 = uVar10 & uVar14 - 1;
                    puVar13 = (uint64_t *)(uVar10 * 0x10 + iVar7);
                    if (*puVar13 == uVar4) {
                        *puVar13 = uVar9;
                        goto code_r0x0001800c9c67;
                    }
                    if (*puVar13 == uVar9) goto code_r0x0001800c9c67;
                    uVar10 = uVar10 + 1 + uVar11;
                    uVar11 = uVar11 + 1;
                } while (uVar11 <= uVar14 - 1);
                puVar13 = (uint64_t *)0x0;
code_r0x0001800c9c67:
                iVar8 = *piVar1;
                *puVar13 = *(uint64_t *)(iVar8 + uVar12 * 0x10);
                puVar13[1] = *(uint64_t *)(iVar8 + 8 + uVar12 * 0x10);
            }
            uVar12 = uVar12 + 1;
        } while (uVar12 < *(uint64_t *)(arg1 + 0x18));
    }
    iVar8 = *piVar1;
    *(uint64_t *)(arg1 + 0x18) = uVar14;
    *piVar1 = iVar7;
    if (iVar8 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c9caa:
    iVar8 = func_0x0001800ac6e0(piVar1, uVar3);
    *(int64_t *)(iVar8 + 8) = iVar15;
    return 1;
}

// ============================================================
// Function: FUN_1800c9b60
// Address: 0x1800c9b60
// Size: 325 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.1800c9a50(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t *puVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t *puVar13;
    uint64_t uVar14;
    int64_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar5 = *(int32_t *)0x180782758;
    if (*(int64_t *)(arg2 + 0x30) != 1) {
        return 1;
    }
    if (*(int64_t *)(arg2 + 0x40) != 1) {
        return 1;
    }
    iVar8 = **(int64_t **)(arg2 + 0x38);
    iVar15 = 0;
    if (*(int32_t *)(iVar8 + 8) == *(int32_t *)0x180782758) {
        iVar15 = iVar8;
    }
    if (iVar15 == 0) {
        iVar7 = 0;
        if (*(int32_t *)(iVar8 + 8) == *(int32_t *)0x180782740) {
            iVar7 = iVar8;
        }
        if (iVar7 == 0) {
            return 1;
        }
        if (*(char *)(iVar7 + 0x48) != '\0') {
            return 1;
        }
        if (*(int64_t *)(iVar7 + 0x40) != 2) {
            return 1;
        }
        iVar8 = 0;
        if (*(int32_t *)(*(int64_t *)(iVar7 + 0x20) + 8) == *(int32_t *)0x180782738) {
            iVar8 = *(int64_t *)(iVar7 + 0x20);
        }
        if (iVar8 == 0) {
            return 1;
        }
        if (*(int64_t *)(iVar8 + 0x20) == 0) {
            return 1;
        }
        iVar6 = func_0x000180498f10(*(int64_t *)(iVar8 + 0x20), 0x180622870);
        if (iVar6 != 0) {
            return 1;
        }
        if (*(int32_t *)(**(int64_t **)(iVar7 + 0x38) + 8) == iVar5) {
            iVar15 = **(int64_t **)(iVar7 + 0x38);
        }
        if (iVar15 == 0) {
            return 1;
        }
    }
    if (*(int64_t *)(iVar15 + 0x28) != 0) {
        return 1;
    }
    uVar3 = *(undefined8 *)(arg2 + 0x28);
    piVar1 = (int64_t *)(arg1 + 0x10);
    iVar8 = *(int64_t *)(arg1 + 0x18);
    if ((*(uint64_t *)(arg1 + 0x20) < (uint64_t)(iVar8 * 3) >> 2) || (iVar7 = fcn.1800ac7f0(piVar1), iVar7 != 0))
    goto code_r0x0001800c9caa;
    puVar2 = (uint64_t *)(arg1 + 0x28);
    uVar4 = *puVar2;
    if (iVar8 == 0) {
        uVar12 = 0x10;
        iVar7 = func_0x000180459890(0x100);
        uVar9 = 0;
        iVar8 = iVar7;
        uVar14 = 0x10;
code_r0x0001800c9bd0:
        do {
            uVar10 = uVar9 + 1;
            *(uint64_t *)(iVar8 + uVar9 * 0x10) = *puVar2;
            *(undefined8 *)(iVar8 + 8 + uVar9 * 0x10) = 0;
            uVar9 = uVar10;
        } while (uVar10 < uVar12);
    } else {
        uVar12 = iVar8 * 2;
        if (uVar12 == 0) {
            iVar7 = 0;
            uVar14 = 0;
        } else {
            iVar7 = func_0x000180459890(iVar8 << 5);
            uVar9 = 0;
            iVar8 = iVar7;
            uVar14 = uVar12;
            if (uVar12 != 0) goto code_r0x0001800c9bd0;
        }
    }
    uVar12 = 0;
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        do {
            uVar9 = *(uint64_t *)(*piVar1 + uVar12 * 0x10);
            if (uVar9 != *puVar2) {
                uVar10 = (uVar9 >> 5 ^ uVar9) >> 4;
                uVar11 = 0;
                do {
                    uVar10 = uVar10 & uVar14 - 1;
                    puVar13 = (uint64_t *)(uVar10 * 0x10 + iVar7);
                    if (*puVar13 == uVar4) {
                        *puVar13 = uVar9;
                        goto code_r0x0001800c9c67;
                    }
                    if (*puVar13 == uVar9) goto code_r0x0001800c9c67;
                    uVar10 = uVar10 + 1 + uVar11;
                    uVar11 = uVar11 + 1;
                } while (uVar11 <= uVar14 - 1);
                puVar13 = (uint64_t *)0x0;
code_r0x0001800c9c67:
                iVar8 = *piVar1;
                *puVar13 = *(uint64_t *)(iVar8 + uVar12 * 0x10);
                puVar13[1] = *(uint64_t *)(iVar8 + 8 + uVar12 * 0x10);
            }
            uVar12 = uVar12 + 1;
        } while (uVar12 < *(uint64_t *)(arg1 + 0x18));
    }
    iVar8 = *piVar1;
    *(uint64_t *)(arg1 + 0x18) = uVar14;
    *piVar1 = iVar7;
    if (iVar8 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c9caa:
    iVar8 = func_0x0001800ac6e0(piVar1, uVar3);
    *(int64_t *)(iVar8 + 8) = iVar15;
    return 1;
}

// ============================================================
// Function: FUN_1800c9ca5
// Address: 0x1800c9ca5
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.1800c9a50(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t *puVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t *puVar13;
    uint64_t uVar14;
    int64_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar5 = *(int32_t *)0x180782758;
    if (*(int64_t *)(arg2 + 0x30) != 1) {
        return 1;
    }
    if (*(int64_t *)(arg2 + 0x40) != 1) {
        return 1;
    }
    iVar8 = **(int64_t **)(arg2 + 0x38);
    iVar15 = 0;
    if (*(int32_t *)(iVar8 + 8) == *(int32_t *)0x180782758) {
        iVar15 = iVar8;
    }
    if (iVar15 == 0) {
        iVar7 = 0;
        if (*(int32_t *)(iVar8 + 8) == *(int32_t *)0x180782740) {
            iVar7 = iVar8;
        }
        if (iVar7 == 0) {
            return 1;
        }
        if (*(char *)(iVar7 + 0x48) != '\0') {
            return 1;
        }
        if (*(int64_t *)(iVar7 + 0x40) != 2) {
            return 1;
        }
        iVar8 = 0;
        if (*(int32_t *)(*(int64_t *)(iVar7 + 0x20) + 8) == *(int32_t *)0x180782738) {
            iVar8 = *(int64_t *)(iVar7 + 0x20);
        }
        if (iVar8 == 0) {
            return 1;
        }
        if (*(int64_t *)(iVar8 + 0x20) == 0) {
            return 1;
        }
        iVar6 = func_0x000180498f10(*(int64_t *)(iVar8 + 0x20), 0x180622870);
        if (iVar6 != 0) {
            return 1;
        }
        if (*(int32_t *)(**(int64_t **)(iVar7 + 0x38) + 8) == iVar5) {
            iVar15 = **(int64_t **)(iVar7 + 0x38);
        }
        if (iVar15 == 0) {
            return 1;
        }
    }
    if (*(int64_t *)(iVar15 + 0x28) != 0) {
        return 1;
    }
    uVar3 = *(undefined8 *)(arg2 + 0x28);
    piVar1 = (int64_t *)(arg1 + 0x10);
    iVar8 = *(int64_t *)(arg1 + 0x18);
    if ((*(uint64_t *)(arg1 + 0x20) < (uint64_t)(iVar8 * 3) >> 2) || (iVar7 = fcn.1800ac7f0(piVar1), iVar7 != 0))
    goto code_r0x0001800c9caa;
    puVar2 = (uint64_t *)(arg1 + 0x28);
    uVar4 = *puVar2;
    if (iVar8 == 0) {
        uVar12 = 0x10;
        iVar7 = func_0x000180459890(0x100);
        uVar9 = 0;
        iVar8 = iVar7;
        uVar14 = 0x10;
code_r0x0001800c9bd0:
        do {
            uVar10 = uVar9 + 1;
            *(uint64_t *)(iVar8 + uVar9 * 0x10) = *puVar2;
            *(undefined8 *)(iVar8 + 8 + uVar9 * 0x10) = 0;
            uVar9 = uVar10;
        } while (uVar10 < uVar12);
    } else {
        uVar12 = iVar8 * 2;
        if (uVar12 == 0) {
            iVar7 = 0;
            uVar14 = 0;
        } else {
            iVar7 = func_0x000180459890(iVar8 << 5);
            uVar9 = 0;
            iVar8 = iVar7;
            uVar14 = uVar12;
            if (uVar12 != 0) goto code_r0x0001800c9bd0;
        }
    }
    uVar12 = 0;
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        do {
            uVar9 = *(uint64_t *)(*piVar1 + uVar12 * 0x10);
            if (uVar9 != *puVar2) {
                uVar10 = (uVar9 >> 5 ^ uVar9) >> 4;
                uVar11 = 0;
                do {
                    uVar10 = uVar10 & uVar14 - 1;
                    puVar13 = (uint64_t *)(uVar10 * 0x10 + iVar7);
                    if (*puVar13 == uVar4) {
                        *puVar13 = uVar9;
                        goto code_r0x0001800c9c67;
                    }
                    if (*puVar13 == uVar9) goto code_r0x0001800c9c67;
                    uVar10 = uVar10 + 1 + uVar11;
                    uVar11 = uVar11 + 1;
                } while (uVar11 <= uVar14 - 1);
                puVar13 = (uint64_t *)0x0;
code_r0x0001800c9c67:
                iVar8 = *piVar1;
                *puVar13 = *(uint64_t *)(iVar8 + uVar12 * 0x10);
                puVar13[1] = *(uint64_t *)(iVar8 + 8 + uVar12 * 0x10);
            }
            uVar12 = uVar12 + 1;
        } while (uVar12 < *(uint64_t *)(arg1 + 0x18));
    }
    iVar8 = *piVar1;
    *(uint64_t *)(arg1 + 0x18) = uVar14;
    *piVar1 = iVar7;
    if (iVar8 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c9caa:
    iVar8 = func_0x0001800ac6e0(piVar1, uVar3);
    *(int64_t *)(iVar8 + 8) = iVar15;
    return 1;
}

// ============================================================
// Function: FUN_1800c9cc8
// Address: 0x1800c9cc8
// Size: 9 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.1800c9a50(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t *puVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t *puVar13;
    uint64_t uVar14;
    int64_t iVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar5 = *(int32_t *)0x180782758;
    if (*(int64_t *)(arg2 + 0x30) != 1) {
        return 1;
    }
    if (*(int64_t *)(arg2 + 0x40) != 1) {
        return 1;
    }
    iVar8 = **(int64_t **)(arg2 + 0x38);
    iVar15 = 0;
    if (*(int32_t *)(iVar8 + 8) == *(int32_t *)0x180782758) {
        iVar15 = iVar8;
    }
    if (iVar15 == 0) {
        iVar7 = 0;
        if (*(int32_t *)(iVar8 + 8) == *(int32_t *)0x180782740) {
            iVar7 = iVar8;
        }
        if (iVar7 == 0) {
            return 1;
        }
        if (*(char *)(iVar7 + 0x48) != '\0') {
            return 1;
        }
        if (*(int64_t *)(iVar7 + 0x40) != 2) {
            return 1;
        }
        iVar8 = 0;
        if (*(int32_t *)(*(int64_t *)(iVar7 + 0x20) + 8) == *(int32_t *)0x180782738) {
            iVar8 = *(int64_t *)(iVar7 + 0x20);
        }
        if (iVar8 == 0) {
            return 1;
        }
        if (*(int64_t *)(iVar8 + 0x20) == 0) {
            return 1;
        }
        iVar6 = func_0x000180498f10(*(int64_t *)(iVar8 + 0x20), 0x180622870);
        if (iVar6 != 0) {
            return 1;
        }
        if (*(int32_t *)(**(int64_t **)(iVar7 + 0x38) + 8) == iVar5) {
            iVar15 = **(int64_t **)(iVar7 + 0x38);
        }
        if (iVar15 == 0) {
            return 1;
        }
    }
    if (*(int64_t *)(iVar15 + 0x28) != 0) {
        return 1;
    }
    uVar3 = *(undefined8 *)(arg2 + 0x28);
    piVar1 = (int64_t *)(arg1 + 0x10);
    iVar8 = *(int64_t *)(arg1 + 0x18);
    if ((*(uint64_t *)(arg1 + 0x20) < (uint64_t)(iVar8 * 3) >> 2) || (iVar7 = fcn.1800ac7f0(piVar1), iVar7 != 0))
    goto code_r0x0001800c9caa;
    puVar2 = (uint64_t *)(arg1 + 0x28);
    uVar4 = *puVar2;
    if (iVar8 == 0) {
        uVar12 = 0x10;
        iVar7 = func_0x000180459890(0x100);
        uVar9 = 0;
        iVar8 = iVar7;
        uVar14 = 0x10;
code_r0x0001800c9bd0:
        do {
            uVar10 = uVar9 + 1;
            *(uint64_t *)(iVar8 + uVar9 * 0x10) = *puVar2;
            *(undefined8 *)(iVar8 + 8 + uVar9 * 0x10) = 0;
            uVar9 = uVar10;
        } while (uVar10 < uVar12);
    } else {
        uVar12 = iVar8 * 2;
        if (uVar12 == 0) {
            iVar7 = 0;
            uVar14 = 0;
        } else {
            iVar7 = func_0x000180459890(iVar8 << 5);
            uVar9 = 0;
            iVar8 = iVar7;
            uVar14 = uVar12;
            if (uVar12 != 0) goto code_r0x0001800c9bd0;
        }
    }
    uVar12 = 0;
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        do {
            uVar9 = *(uint64_t *)(*piVar1 + uVar12 * 0x10);
            if (uVar9 != *puVar2) {
                uVar10 = (uVar9 >> 5 ^ uVar9) >> 4;
                uVar11 = 0;
                do {
                    uVar10 = uVar10 & uVar14 - 1;
                    puVar13 = (uint64_t *)(uVar10 * 0x10 + iVar7);
                    if (*puVar13 == uVar4) {
                        *puVar13 = uVar9;
                        goto code_r0x0001800c9c67;
                    }
                    if (*puVar13 == uVar9) goto code_r0x0001800c9c67;
                    uVar10 = uVar10 + 1 + uVar11;
                    uVar11 = uVar11 + 1;
                } while (uVar11 <= uVar14 - 1);
                puVar13 = (uint64_t *)0x0;
code_r0x0001800c9c67:
                iVar8 = *piVar1;
                *puVar13 = *(uint64_t *)(iVar8 + uVar12 * 0x10);
                puVar13[1] = *(uint64_t *)(iVar8 + 8 + uVar12 * 0x10);
            }
            uVar12 = uVar12 + 1;
        } while (uVar12 < *(uint64_t *)(arg1 + 0x18));
    }
    iVar8 = *piVar1;
    *(uint64_t *)(arg1 + 0x18) = uVar14;
    *piVar1 = iVar7;
    if (iVar8 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c9caa:
    iVar8 = func_0x0001800ac6e0(piVar1, uVar3);
    *(int64_t *)(iVar8 + 8) = iVar15;
    return 1;
}

// ============================================================
// Function: FUN_1800c9ce0
// Address: 0x1800c9ce0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1800c9ce0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    uint64_t in_RAX;
    uint64_t uVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar2 = 0;
    if (*(int64_t *)(arg2 + 0x30) != 0) {
        do {
            in_RAX = fcn.1800c9620(arg1, *(int64_t *)(*(int64_t *)(arg2 + 0x28) + uVar2 * 8));
            uVar2 = uVar2 + 1;
        } while (uVar2 < *(uint64_t *)(arg2 + 0x30));
    }
    uVar2 = 0;
    if (*(int64_t *)(arg2 + 0x40) != 0) {
        do {
            puVar1 = *(undefined8 **)(*(int64_t *)(arg2 + 0x38) + uVar2 * 8);
            in_RAX = (**(code **)*puVar1)(puVar1, arg1);
            uVar2 = uVar2 + 1;
        } while (uVar2 < *(uint64_t *)(arg2 + 0x40));
    }
    return in_RAX & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c9d60
// Address: 0x1800c9d60
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800c9d60(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t var_8h;
    
    fcn.1800c9620(arg1, *(int64_t *)(arg2 + 0x28));
    uVar1 = (**(code **)**(undefined8 **)(arg2 + 0x30))(*(undefined8 **)(arg2 + 0x30), arg1);
    return uVar1 & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c9da0
// Address: 0x1800c9da0
// Size: 134 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.1800c9da0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    double dVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    int64_t var_10h;
    
    iVar5 = 0;
    if (*(int32_t *)(*(int64_t *)(arg2 + 0x30) + 8) == *(int32_t *)0x1807826b4) {
        iVar5 = *(int64_t *)(arg2 + 0x30);
    }
    iVar4 = 0;
    if (*(int32_t *)(*(int64_t *)(arg2 + 0x38) + 8) == *(int32_t *)0x1807826b4) {
        iVar4 = *(int64_t *)(arg2 + 0x38);
    }
    if (iVar5 == 0) {
        return 1;
    }
    if (iVar4 == 0) {
        return 1;
    }
    if (*(double *)(iVar5 + 0x20) != 1.0) {
        return 1;
    }
    dVar2 = *(double *)(iVar4 + 0x20);
    if (dVar2 < 1.0) {
        return 1;
    }
    if (16.0 < dVar2) {
        return 1;
    }
    if (*(int64_t *)(arg2 + 0x40) != 0) {
        return 1;
    }
    piVar1 = (int64_t *)(arg1 + 0x68);
    iVar5 = *(int64_t *)(arg1 + 0x70);
    if ((*(uint64_t *)(arg1 + 0x78) < (uint64_t)(iVar5 * 3) >> 2) || (iVar4 = fcn.1800ac7f0(piVar1), iVar4 != 0))
    goto code_r0x0001800c9fbf;
    uVar3 = *(uint64_t *)(arg1 + 0x80);
    if (iVar5 == 0) {
        uVar9 = 0x10;
        iVar4 = func_0x000180459890(0x100);
        uVar6 = 0;
        iVar5 = iVar4;
        uVar11 = 0x10;
code_r0x0001800c9ee0:
        do {
            uVar7 = uVar6 + 1;
            *(uint64_t *)(iVar5 + uVar6 * 0x10) = *(uint64_t *)(arg1 + 0x80);
            *(undefined4 *)(iVar5 + 8 + uVar6 * 0x10) = 0;
            uVar6 = uVar7;
        } while (uVar7 < uVar9);
    } else {
        uVar9 = iVar5 * 2;
        if (uVar9 == 0) {
            iVar4 = 0;
            uVar11 = 0;
        } else {
            iVar4 = func_0x000180459890(iVar5 << 5);
            uVar6 = 0;
            iVar5 = iVar4;
            uVar11 = uVar9;
            if (uVar9 != 0) goto code_r0x0001800c9ee0;
        }
    }
    uVar9 = 0;
    if (*(int64_t *)(arg1 + 0x70) != 0) {
        do {
            uVar6 = *(uint64_t *)(*piVar1 + uVar9 * 0x10);
            if (uVar6 != *(uint64_t *)(arg1 + 0x80)) {
                uVar7 = (uVar6 >> 5 ^ uVar6) >> 4;
                uVar8 = 0;
                do {
                    uVar7 = uVar7 & uVar11 - 1;
                    puVar10 = (uint64_t *)(uVar7 * 0x10 + iVar4);
                    if (*puVar10 == uVar3) {
                        *puVar10 = uVar6;
                        goto code_r0x0001800c9f77;
                    }
                    if (*puVar10 == uVar6) goto code_r0x0001800c9f77;
                    uVar7 = uVar7 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar11 - 1);
                puVar10 = (uint64_t *)0x0;
code_r0x0001800c9f77:
                iVar5 = *piVar1;
                *puVar10 = *(uint64_t *)(iVar5 + uVar9 * 0x10);
                *(undefined4 *)(puVar10 + 1) = *(undefined4 *)(iVar5 + 8 + uVar9 * 0x10);
            }
            uVar9 = uVar9 + 1;
        } while (uVar9 < *(uint64_t *)(arg1 + 0x70));
    }
    iVar5 = *piVar1;
    *piVar1 = iVar4;
    *(uint64_t *)(arg1 + 0x70) = uVar11;
    if (iVar5 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c9fbf:
    iVar5 = func_0x0001800ac6e0(piVar1, arg2 + 0x28);
    *(int32_t *)(iVar5 + 8) = (int32_t)(int64_t)dVar2;
    return 1;
}

// ============================================================
// Function: FUN_1800c9e26
// Address: 0x1800c9e26
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.1800c9da0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    double dVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    int64_t var_10h;
    
    iVar5 = 0;
    if (*(int32_t *)(*(int64_t *)(arg2 + 0x30) + 8) == *(int32_t *)0x1807826b4) {
        iVar5 = *(int64_t *)(arg2 + 0x30);
    }
    iVar4 = 0;
    if (*(int32_t *)(*(int64_t *)(arg2 + 0x38) + 8) == *(int32_t *)0x1807826b4) {
        iVar4 = *(int64_t *)(arg2 + 0x38);
    }
    if (iVar5 == 0) {
        return 1;
    }
    if (iVar4 == 0) {
        return 1;
    }
    if (*(double *)(iVar5 + 0x20) != 1.0) {
        return 1;
    }
    dVar2 = *(double *)(iVar4 + 0x20);
    if (dVar2 < 1.0) {
        return 1;
    }
    if (16.0 < dVar2) {
        return 1;
    }
    if (*(int64_t *)(arg2 + 0x40) != 0) {
        return 1;
    }
    piVar1 = (int64_t *)(arg1 + 0x68);
    iVar5 = *(int64_t *)(arg1 + 0x70);
    if ((*(uint64_t *)(arg1 + 0x78) < (uint64_t)(iVar5 * 3) >> 2) || (iVar4 = fcn.1800ac7f0(piVar1), iVar4 != 0))
    goto code_r0x0001800c9fbf;
    uVar3 = *(uint64_t *)(arg1 + 0x80);
    if (iVar5 == 0) {
        uVar9 = 0x10;
        iVar4 = func_0x000180459890(0x100);
        uVar6 = 0;
        iVar5 = iVar4;
        uVar11 = 0x10;
code_r0x0001800c9ee0:
        do {
            uVar7 = uVar6 + 1;
            *(uint64_t *)(iVar5 + uVar6 * 0x10) = *(uint64_t *)(arg1 + 0x80);
            *(undefined4 *)(iVar5 + 8 + uVar6 * 0x10) = 0;
            uVar6 = uVar7;
        } while (uVar7 < uVar9);
    } else {
        uVar9 = iVar5 * 2;
        if (uVar9 == 0) {
            iVar4 = 0;
            uVar11 = 0;
        } else {
            iVar4 = func_0x000180459890(iVar5 << 5);
            uVar6 = 0;
            iVar5 = iVar4;
            uVar11 = uVar9;
            if (uVar9 != 0) goto code_r0x0001800c9ee0;
        }
    }
    uVar9 = 0;
    if (*(int64_t *)(arg1 + 0x70) != 0) {
        do {
            uVar6 = *(uint64_t *)(*piVar1 + uVar9 * 0x10);
            if (uVar6 != *(uint64_t *)(arg1 + 0x80)) {
                uVar7 = (uVar6 >> 5 ^ uVar6) >> 4;
                uVar8 = 0;
                do {
                    uVar7 = uVar7 & uVar11 - 1;
                    puVar10 = (uint64_t *)(uVar7 * 0x10 + iVar4);
                    if (*puVar10 == uVar3) {
                        *puVar10 = uVar6;
                        goto code_r0x0001800c9f77;
                    }
                    if (*puVar10 == uVar6) goto code_r0x0001800c9f77;
                    uVar7 = uVar7 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar11 - 1);
                puVar10 = (uint64_t *)0x0;
code_r0x0001800c9f77:
                iVar5 = *piVar1;
                *puVar10 = *(uint64_t *)(iVar5 + uVar9 * 0x10);
                *(undefined4 *)(puVar10 + 1) = *(undefined4 *)(iVar5 + 8 + uVar9 * 0x10);
            }
            uVar9 = uVar9 + 1;
        } while (uVar9 < *(uint64_t *)(arg1 + 0x70));
    }
    iVar5 = *piVar1;
    *piVar1 = iVar4;
    *(uint64_t *)(arg1 + 0x70) = uVar11;
    if (iVar5 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c9fbf:
    iVar5 = func_0x0001800ac6e0(piVar1, arg2 + 0x28);
    *(int32_t *)(iVar5 + 8) = (int32_t)(int64_t)dVar2;
    return 1;
}

// ============================================================
// Function: FUN_1800c9e76
// Address: 0x1800c9e76
// Size: 324 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.1800c9da0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    double dVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    int64_t var_10h;
    
    iVar5 = 0;
    if (*(int32_t *)(*(int64_t *)(arg2 + 0x30) + 8) == *(int32_t *)0x1807826b4) {
        iVar5 = *(int64_t *)(arg2 + 0x30);
    }
    iVar4 = 0;
    if (*(int32_t *)(*(int64_t *)(arg2 + 0x38) + 8) == *(int32_t *)0x1807826b4) {
        iVar4 = *(int64_t *)(arg2 + 0x38);
    }
    if (iVar5 == 0) {
        return 1;
    }
    if (iVar4 == 0) {
        return 1;
    }
    if (*(double *)(iVar5 + 0x20) != 1.0) {
        return 1;
    }
    dVar2 = *(double *)(iVar4 + 0x20);
    if (dVar2 < 1.0) {
        return 1;
    }
    if (16.0 < dVar2) {
        return 1;
    }
    if (*(int64_t *)(arg2 + 0x40) != 0) {
        return 1;
    }
    piVar1 = (int64_t *)(arg1 + 0x68);
    iVar5 = *(int64_t *)(arg1 + 0x70);
    if ((*(uint64_t *)(arg1 + 0x78) < (uint64_t)(iVar5 * 3) >> 2) || (iVar4 = fcn.1800ac7f0(piVar1), iVar4 != 0))
    goto code_r0x0001800c9fbf;
    uVar3 = *(uint64_t *)(arg1 + 0x80);
    if (iVar5 == 0) {
        uVar9 = 0x10;
        iVar4 = func_0x000180459890(0x100);
        uVar6 = 0;
        iVar5 = iVar4;
        uVar11 = 0x10;
code_r0x0001800c9ee0:
        do {
            uVar7 = uVar6 + 1;
            *(uint64_t *)(iVar5 + uVar6 * 0x10) = *(uint64_t *)(arg1 + 0x80);
            *(undefined4 *)(iVar5 + 8 + uVar6 * 0x10) = 0;
            uVar6 = uVar7;
        } while (uVar7 < uVar9);
    } else {
        uVar9 = iVar5 * 2;
        if (uVar9 == 0) {
            iVar4 = 0;
            uVar11 = 0;
        } else {
            iVar4 = func_0x000180459890(iVar5 << 5);
            uVar6 = 0;
            iVar5 = iVar4;
            uVar11 = uVar9;
            if (uVar9 != 0) goto code_r0x0001800c9ee0;
        }
    }
    uVar9 = 0;
    if (*(int64_t *)(arg1 + 0x70) != 0) {
        do {
            uVar6 = *(uint64_t *)(*piVar1 + uVar9 * 0x10);
            if (uVar6 != *(uint64_t *)(arg1 + 0x80)) {
                uVar7 = (uVar6 >> 5 ^ uVar6) >> 4;
                uVar8 = 0;
                do {
                    uVar7 = uVar7 & uVar11 - 1;
                    puVar10 = (uint64_t *)(uVar7 * 0x10 + iVar4);
                    if (*puVar10 == uVar3) {
                        *puVar10 = uVar6;
                        goto code_r0x0001800c9f77;
                    }
                    if (*puVar10 == uVar6) goto code_r0x0001800c9f77;
                    uVar7 = uVar7 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar11 - 1);
                puVar10 = (uint64_t *)0x0;
code_r0x0001800c9f77:
                iVar5 = *piVar1;
                *puVar10 = *(uint64_t *)(iVar5 + uVar9 * 0x10);
                *(undefined4 *)(puVar10 + 1) = *(undefined4 *)(iVar5 + 8 + uVar9 * 0x10);
            }
            uVar9 = uVar9 + 1;
        } while (uVar9 < *(uint64_t *)(arg1 + 0x70));
    }
    iVar5 = *piVar1;
    *piVar1 = iVar4;
    *(uint64_t *)(arg1 + 0x70) = uVar11;
    if (iVar5 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c9fbf:
    iVar5 = func_0x0001800ac6e0(piVar1, arg2 + 0x28);
    *(int32_t *)(iVar5 + 8) = (int32_t)(int64_t)dVar2;
    return 1;
}

// ============================================================
// Function: FUN_1800c9fba
// Address: 0x1800c9fba
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.1800c9da0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    double dVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    int64_t var_10h;
    
    iVar5 = 0;
    if (*(int32_t *)(*(int64_t *)(arg2 + 0x30) + 8) == *(int32_t *)0x1807826b4) {
        iVar5 = *(int64_t *)(arg2 + 0x30);
    }
    iVar4 = 0;
    if (*(int32_t *)(*(int64_t *)(arg2 + 0x38) + 8) == *(int32_t *)0x1807826b4) {
        iVar4 = *(int64_t *)(arg2 + 0x38);
    }
    if (iVar5 == 0) {
        return 1;
    }
    if (iVar4 == 0) {
        return 1;
    }
    if (*(double *)(iVar5 + 0x20) != 1.0) {
        return 1;
    }
    dVar2 = *(double *)(iVar4 + 0x20);
    if (dVar2 < 1.0) {
        return 1;
    }
    if (16.0 < dVar2) {
        return 1;
    }
    if (*(int64_t *)(arg2 + 0x40) != 0) {
        return 1;
    }
    piVar1 = (int64_t *)(arg1 + 0x68);
    iVar5 = *(int64_t *)(arg1 + 0x70);
    if ((*(uint64_t *)(arg1 + 0x78) < (uint64_t)(iVar5 * 3) >> 2) || (iVar4 = fcn.1800ac7f0(piVar1), iVar4 != 0))
    goto code_r0x0001800c9fbf;
    uVar3 = *(uint64_t *)(arg1 + 0x80);
    if (iVar5 == 0) {
        uVar9 = 0x10;
        iVar4 = func_0x000180459890(0x100);
        uVar6 = 0;
        iVar5 = iVar4;
        uVar11 = 0x10;
code_r0x0001800c9ee0:
        do {
            uVar7 = uVar6 + 1;
            *(uint64_t *)(iVar5 + uVar6 * 0x10) = *(uint64_t *)(arg1 + 0x80);
            *(undefined4 *)(iVar5 + 8 + uVar6 * 0x10) = 0;
            uVar6 = uVar7;
        } while (uVar7 < uVar9);
    } else {
        uVar9 = iVar5 * 2;
        if (uVar9 == 0) {
            iVar4 = 0;
            uVar11 = 0;
        } else {
            iVar4 = func_0x000180459890(iVar5 << 5);
            uVar6 = 0;
            iVar5 = iVar4;
            uVar11 = uVar9;
            if (uVar9 != 0) goto code_r0x0001800c9ee0;
        }
    }
    uVar9 = 0;
    if (*(int64_t *)(arg1 + 0x70) != 0) {
        do {
            uVar6 = *(uint64_t *)(*piVar1 + uVar9 * 0x10);
            if (uVar6 != *(uint64_t *)(arg1 + 0x80)) {
                uVar7 = (uVar6 >> 5 ^ uVar6) >> 4;
                uVar8 = 0;
                do {
                    uVar7 = uVar7 & uVar11 - 1;
                    puVar10 = (uint64_t *)(uVar7 * 0x10 + iVar4);
                    if (*puVar10 == uVar3) {
                        *puVar10 = uVar6;
                        goto code_r0x0001800c9f77;
                    }
                    if (*puVar10 == uVar6) goto code_r0x0001800c9f77;
                    uVar7 = uVar7 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar11 - 1);
                puVar10 = (uint64_t *)0x0;
code_r0x0001800c9f77:
                iVar5 = *piVar1;
                *puVar10 = *(uint64_t *)(iVar5 + uVar9 * 0x10);
                *(undefined4 *)(puVar10 + 1) = *(undefined4 *)(iVar5 + 8 + uVar9 * 0x10);
            }
            uVar9 = uVar9 + 1;
        } while (uVar9 < *(uint64_t *)(arg1 + 0x70));
    }
    iVar5 = *piVar1;
    *piVar1 = iVar4;
    *(uint64_t *)(arg1 + 0x70) = uVar11;
    if (iVar5 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c9fbf:
    iVar5 = func_0x0001800ac6e0(piVar1, arg2 + 0x28);
    *(int32_t *)(iVar5 + 8) = (int32_t)(int64_t)dVar2;
    return 1;
}

// ============================================================
// Function: FUN_1800c9fe1
// Address: 0x1800c9fe1
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.1800c9da0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    double dVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    int64_t var_10h;
    
    iVar5 = 0;
    if (*(int32_t *)(*(int64_t *)(arg2 + 0x30) + 8) == *(int32_t *)0x1807826b4) {
        iVar5 = *(int64_t *)(arg2 + 0x30);
    }
    iVar4 = 0;
    if (*(int32_t *)(*(int64_t *)(arg2 + 0x38) + 8) == *(int32_t *)0x1807826b4) {
        iVar4 = *(int64_t *)(arg2 + 0x38);
    }
    if (iVar5 == 0) {
        return 1;
    }
    if (iVar4 == 0) {
        return 1;
    }
    if (*(double *)(iVar5 + 0x20) != 1.0) {
        return 1;
    }
    dVar2 = *(double *)(iVar4 + 0x20);
    if (dVar2 < 1.0) {
        return 1;
    }
    if (16.0 < dVar2) {
        return 1;
    }
    if (*(int64_t *)(arg2 + 0x40) != 0) {
        return 1;
    }
    piVar1 = (int64_t *)(arg1 + 0x68);
    iVar5 = *(int64_t *)(arg1 + 0x70);
    if ((*(uint64_t *)(arg1 + 0x78) < (uint64_t)(iVar5 * 3) >> 2) || (iVar4 = fcn.1800ac7f0(piVar1), iVar4 != 0))
    goto code_r0x0001800c9fbf;
    uVar3 = *(uint64_t *)(arg1 + 0x80);
    if (iVar5 == 0) {
        uVar9 = 0x10;
        iVar4 = func_0x000180459890(0x100);
        uVar6 = 0;
        iVar5 = iVar4;
        uVar11 = 0x10;
code_r0x0001800c9ee0:
        do {
            uVar7 = uVar6 + 1;
            *(uint64_t *)(iVar5 + uVar6 * 0x10) = *(uint64_t *)(arg1 + 0x80);
            *(undefined4 *)(iVar5 + 8 + uVar6 * 0x10) = 0;
            uVar6 = uVar7;
        } while (uVar7 < uVar9);
    } else {
        uVar9 = iVar5 * 2;
        if (uVar9 == 0) {
            iVar4 = 0;
            uVar11 = 0;
        } else {
            iVar4 = func_0x000180459890(iVar5 << 5);
            uVar6 = 0;
            iVar5 = iVar4;
            uVar11 = uVar9;
            if (uVar9 != 0) goto code_r0x0001800c9ee0;
        }
    }
    uVar9 = 0;
    if (*(int64_t *)(arg1 + 0x70) != 0) {
        do {
            uVar6 = *(uint64_t *)(*piVar1 + uVar9 * 0x10);
            if (uVar6 != *(uint64_t *)(arg1 + 0x80)) {
                uVar7 = (uVar6 >> 5 ^ uVar6) >> 4;
                uVar8 = 0;
                do {
                    uVar7 = uVar7 & uVar11 - 1;
                    puVar10 = (uint64_t *)(uVar7 * 0x10 + iVar4);
                    if (*puVar10 == uVar3) {
                        *puVar10 = uVar6;
                        goto code_r0x0001800c9f77;
                    }
                    if (*puVar10 == uVar6) goto code_r0x0001800c9f77;
                    uVar7 = uVar7 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar11 - 1);
                puVar10 = (uint64_t *)0x0;
code_r0x0001800c9f77:
                iVar5 = *piVar1;
                *puVar10 = *(uint64_t *)(iVar5 + uVar9 * 0x10);
                *(undefined4 *)(puVar10 + 1) = *(undefined4 *)(iVar5 + 8 + uVar9 * 0x10);
            }
            uVar9 = uVar9 + 1;
        } while (uVar9 < *(uint64_t *)(arg1 + 0x70));
    }
    iVar5 = *piVar1;
    *piVar1 = iVar4;
    *(uint64_t *)(arg1 + 0x70) = uVar11;
    if (iVar5 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800c9fbf:
    iVar5 = func_0x0001800ac6e0(piVar1, arg2 + 0x28);
    *(int32_t *)(iVar5 + 8) = (int32_t)(int64_t)dVar2;
    return 1;
}

// ============================================================
// Function: FUN_1800c9ff0
// Address: 0x1800c9ff0
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800c9ff0(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    fcn.1800ca030();
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x90);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800ca030
// Address: 0x1800ca030
// Size: 102 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800ca030(int64_t arg1)
{
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 0x68) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x68) = 0;
        *(undefined8 *)(arg1 + 0x70) = 0;
    }
    if (*(int64_t *)(arg1 + 0x38) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x38) = 0;
        *(undefined8 *)(arg1 + 0x40) = 0;
    }
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        func_0x0001800f4640();
        *(undefined8 *)(arg1 + 0x10) = 0;
        *(undefined8 *)(arg1 + 0x18) = 0;
    }
    *(undefined8 *)arg1 = 0x18063f2c0;
    return;
}

// ============================================================
// Function: FUN_1800ca0a0
// Address: 0x1800ca0a0
// Size: 178 bytes
// ============================================================
void fcn.1800ca0a0(int64_t arg1, int64_t arg2)
{
    undefined auVar1 [16];
    undefined auVar2 [16];
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_60h;
    int64_t var_58h;
    uint64_t uStack_50;
    int64_t var_48h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uStack_20;
    undefined8 uStack_18;
    
    var_98h = 0x1806412a0;
    _var_88h = ZEXT816(0);
    _var_78h = ZEXT816(0);
    var_60h = 0;
    _var_58h = ZEXT816(0);
    _var_48h = ZEXT816(0);
    var_30h = 0;
    _var_28h = ZEXT816(0);
    uStack_18 = 0;
    var_90h = arg1;
    (***(code ***)arg2)(arg2, &var_98h);
    if (var_30h != 0) {
        func_0x0001800f4640();
        var_30h = 0;
        auVar1._8_8_ = 0;
        auVar1._0_8_ = uStack_20;
        _var_28h = auVar1 << 0x40;
    }
    if (var_60h != 0) {
        func_0x0001800f4640();
        var_60h = 0;
        auVar2._8_8_ = 0;
        auVar2._0_8_ = uStack_50;
        _var_58h = auVar2 << 0x40;
    }
    if (var_88h != 0) {
        func_0x0001800f4640();
    }
    return;
}

// ============================================================
// Function: FUN_1800ca160
// Address: 0x1800ca160
// Size: 169 bytes
// ============================================================
uint64_t * fcn.1800ca160(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    uint64_t uVar7;
    
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        uVar1 = *(uint64_t *)arg2;
        if ((uVar1 != *(uint64_t *)(arg1 + 0x18)) || (*(int64_t *)(arg2 + 8) != *(int64_t *)(arg1 + 0x20))) {
            uVar2 = *(uint64_t *)(arg2 + 8);
            uVar7 = *(int64_t *)(arg1 + 8) - 1;
            uVar3 = ((uVar2 ^ uVar1) >> 5 ^ uVar2 ^ uVar1) >> 4;
            uVar5 = 0;
            while( true ) {
                uVar3 = uVar3 & uVar7;
                puVar6 = (uint64_t *)(uVar3 * 0x10 + *(int64_t *)arg1);
                if ((*puVar6 == uVar1) && (puVar6[1] == uVar2)) {
                    return puVar6;
                }
                if ((*puVar6 == *(uint64_t *)(arg1 + 0x18)) && (puVar6[1] == *(uint64_t *)(arg1 + 0x20))) break;
                iVar4 = uVar3 + uVar5;
                uVar5 = uVar5 + 1;
                if (uVar7 < uVar5) {
                    return (uint64_t *)0x0;
                }
                uVar3 = iVar4 + 1;
            }
        }
    }
    return (uint64_t *)0x0;
}

// ============================================================
// Function: FUN_1800ca210
// Address: 0x1800ca210
// Size: 1456 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

uint32_t fcn.1800ca210(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
                      int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint32_t uVar12;
    undefined8 *puVar13;
    uint64_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    piVar8 = (int64_t *)0x0;
    while( true ) {
        while( true ) {
            iVar4 = *(int32_t *)(arg1 + 8);
            piVar7 = piVar8;
            if (iVar4 == *(int32_t *)0x1807826bc) {
                piVar7 = (int64_t *)arg1;
            }
            if (piVar7 != (int64_t *)0x0) break;
            piVar7 = piVar8;
            if (iVar4 == *(int32_t *)0x180782704) {
                piVar7 = (int64_t *)arg1;
            }
            if (piVar7 != (int64_t *)0x0) {
                return 4;
            }
            piVar7 = piVar8;
            if (iVar4 == *(int32_t *)0x1807826ac) {
                piVar7 = (int64_t *)arg1;
            }
            if (piVar7 != (int64_t *)0x0) {
                return 5;
            }
            piVar7 = piVar8;
            if (iVar4 == *(int32_t *)0x18078277c) {
                piVar7 = (int64_t *)arg1;
            }
            if (piVar7 != (int64_t *)0x0) {
                piVar11 = (int64_t *)piVar7[4];
                uVar12 = 0x100;
                piVar7 = piVar11 + piVar7[5];
                if (piVar11 != piVar7) {
                    do {
                        uVar5 = fcn.1800ca210(*piVar11, arg2, arg3, (uint64_t)(uint8_t)placeholder_3, arg_28h, arg_30h, 
                                              arg_38h, arg_40h);
                        if (uVar5 == 0) {
                            piVar8 = (int64_t *)0x1;
                            uVar3 = uVar12;
                        } else {
                            uVar3 = uVar5;
                            if ((uVar12 != 0x100) && (uVar3 = uVar12, uVar12 != uVar5)) {
                                return 0xf;
                            }
                        }
                        uVar12 = uVar3;
                        piVar11 = piVar11 + 1;
                    } while (piVar11 != piVar7);
                    if (uVar12 != 0x100) {
                        if (((char)piVar8 != '\0') && (uVar12 != 0xf)) {
                            return uVar12 | 0x80;
                        }
                        return uVar12;
                    }
                }
                return 0xf;
            }
            piVar7 = piVar8;
            if (iVar4 == *(int32_t *)0x180782694) {
                piVar7 = (int64_t *)arg1;
            }
            if (piVar7 != (int64_t *)0x0) {
                return 0xf;
            }
            piVar7 = piVar8;
            if (iVar4 == *(int32_t *)0x180782784) {
                piVar7 = (int64_t *)arg1;
            }
            if (piVar7 == (int64_t *)0x0) {
                if (iVar4 == *(int32_t *)0x1807826c8) {
                    piVar8 = (int64_t *)arg1;
                }
                if (piVar8 != (int64_t *)0x0) {
                    return 0;
                }
                if (iVar4 == *(int32_t *)0x180782680) {
                    return 1;
                }
                if (iVar4 == *(int32_t *)0x18078272c) {
                    return 3;
                }
                return 0xf;
            }
            arg1 = piVar7[4];
        }
        if (*(uint8_t *)(piVar7 + 6) != 0) {
            return 0xf;
        }
        piVar7 = piVar7 + 10;
        iVar6 = fcn.1800ac7f0(arg3, piVar7);
        piVar11 = (int64_t *)(iVar6 + 8);
        if (iVar6 == 0) {
            piVar11 = piVar8;
        }
        if ((piVar11 == (int64_t *)0x0) || (iVar6 = *piVar11, iVar6 == 0)) break;
        if (*(char *)0x180778058 == '\0') {
            if ((uint8_t)placeholder_3 == 0) {
                return 0xf;
            }
            arg2 = iVar6 + 0x40;
            arg1 = *(int64_t *)(iVar6 + 0x60);
            placeholder_3._0_1_ = 0;
        } else {
            iVar6 = func_0x0001800c1560(arg_40h, iVar6 + 0x28);
            if (iVar6 != 0) {
                if (*(int64_t *)(arg_40h + 0x10) == 0) {
                    return 0xf;
                }
                piVar7 = *(int64_t **)(arg_40h + 8);
                puVar1 = *(undefined8 **)arg_40h;
                if (piVar7 < (int64_t *)0x21) {
                    if (piVar7 != (int64_t *)0x0) {
                        if (piVar7 < (int64_t *)0x2) goto code_r0x0001800ca400;
                        puVar13 = (undefined8 *)(arg_40h + 0x18);
                        if ((puVar1 <= puVar13) && (puVar13 <= puVar1 + (int64_t)((int64_t)piVar7 + -1)))
                        goto code_r0x0001800ca400;
                        uVar2 = *puVar13;
                        do {
                            piVar8 = (int64_t *)((int64_t)piVar8 + 2);
                        } while (piVar8 < (int64_t *)((uint64_t)piVar7 & 0xfffffffffffffffe));
                        puVar13 = puVar1;
                        for (uVar14 = (((uint64_t)piVar7 >> 1) << 4) >> 3; uVar14 != 0; uVar14 = uVar14 - 1) {
                            *puVar13 = uVar2;
                            puVar13 = puVar13 + 1;
                        }
                        for (; piVar8 < piVar7; piVar8 = (int64_t *)((int64_t)piVar8 + 1)) {
code_r0x0001800ca400:
                            puVar1[(int64_t)piVar8] = *(undefined8 *)(arg_40h + 0x18);
                        }
                    }
                    *(undefined8 *)(arg_40h + 0x10) = 0;
                    return 0xf;
                }
                func_0x0001800f4640(puVar1);
                *(undefined8 *)arg_40h = 0;
                *(undefined8 *)(arg_40h + 8) = 0;
                *(undefined8 *)(arg_40h + 0x10) = 0;
                return 0xf;
            }
            func_0x0001800ccb10(arg_40h, piVar7);
            placeholder_3._0_1_ = 0;
            arg1 = *(int64_t *)(*piVar11 + 0x60);
            arg2 = *piVar11 + 0x40;
        }
    }
    piVar10 = *(int64_t **)arg2;
    iVar6 = *piVar7;
    piVar11 = piVar10 + (int64_t)*(int64_t **)(arg2 + 8);
    for (; piVar10 != piVar11; piVar10 = piVar10 + 1) {
        if (*(int64_t *)(*piVar10 + 0x20) == iVar6) {
            return 0xf;
        }
    }
    if (arg_28h != 0) {
        if (iVar6 == 0) goto code_r0x0001800ca64f;
        iVar4 = func_0x000180498f10(iVar6);
        if (iVar4 == 0) {
            return 8;
        }
    }
    piVar11 = piVar8;
    if (iVar6 != 0) {
        while (piVar9 = (int64_t *)((int64_t)piVar11 + 1), piVar10 = piVar8,
              *(uint8_t *)(iVar6 + (int64_t)piVar11) == *(uint8_t *)((int64_t)piVar11 + 0x18063da4c)) {
            piVar11 = piVar9;
            if (piVar9 == (int64_t *)0x4) {
                return 0;
            }
        }
        while (piVar9 = (int64_t *)((int64_t)piVar10 + 1), piVar11 = piVar8,
              *(uint8_t *)(iVar6 + (int64_t)piVar10) == *(uint8_t *)(piVar10 + 0x300c7d91)) {
            piVar10 = piVar9;
            if (piVar9 == (int64_t *)0x8) {
                return 1;
            }
        }
        while (piVar9 = (int64_t *)((int64_t)piVar11 + 1), piVar10 = piVar8,
              *(uint8_t *)(iVar6 + (int64_t)piVar11) == *(uint8_t *)(piVar11 + 0x300c7c5a)) {
            piVar11 = piVar9;
            if (piVar9 == (int64_t *)0x7) {
                return 2;
            }
        }
        while (piVar9 = (int64_t *)((int64_t)piVar10 + 1), piVar11 = piVar8,
              *(uint8_t *)(iVar6 + (int64_t)piVar10) == *(uint8_t *)(piVar10 + 0x300c7c34)) {
            piVar10 = piVar9;
            if (piVar9 == (int64_t *)0x8) {
                return 10;
            }
        }
        while (piVar9 = (int64_t *)((int64_t)piVar11 + 1), piVar10 = piVar8,
              *(uint8_t *)(iVar6 + (int64_t)piVar11) == *(uint8_t *)((int64_t)piVar11 + 0x180625fe4)) {
            piVar11 = piVar9;
            if (piVar9 == (int64_t *)0x7) {
                return 3;
            }
        }
        while (piVar9 = (int64_t *)((int64_t)piVar10 + 1), piVar11 = piVar8,
              *(uint8_t *)(iVar6 + (int64_t)piVar10) == *(uint8_t *)((int64_t)piVar10 + 0x18063cb4c)) {
            piVar10 = piVar9;
            if (piVar9 == (int64_t *)0x7) {
                return 6;
            }
        }
        while (piVar9 = (int64_t *)((int64_t)piVar11 + 1), piVar10 = piVar8,
              *(uint8_t *)(iVar6 + (int64_t)piVar11) == *(uint8_t *)((int64_t)piVar11 + 0x18062598c)) {
            piVar11 = piVar9;
            if (piVar9 == (int64_t *)0x7) {
                return 9;
            }
        }
        while (piVar9 = (int64_t *)((int64_t)piVar10 + 1), piVar11 = piVar8,
              *(uint8_t *)(iVar6 + (int64_t)piVar10) == *(uint8_t *)(piVar10 + 0x300c7c35)) {
            piVar10 = piVar9;
            if (piVar9 == (int64_t *)0x7) {
                return 8;
            }
        }
        while (piVar9 = (int64_t *)((int64_t)piVar11 + 1), piVar10 = piVar8,
              *(uint8_t *)(iVar6 + (int64_t)piVar11) == *(uint8_t *)(piVar11 + 0x300c8299)) {
            piVar11 = piVar9;
            if (piVar9 == (int64_t *)0x4) {
                return 0xf;
            }
        }
        while (piVar11 = (int64_t *)((int64_t)piVar10 + 1),
              *(uint8_t *)(iVar6 + (int64_t)piVar10) == *(uint8_t *)(piVar10 + 0x300c829a)) {
            piVar10 = piVar11;
            if (piVar11 == (int64_t *)0x8) {
                return 0xf;
            }
        }
    }
code_r0x0001800ca64f:
    iVar6 = fcn.1800ac7f0(arg_30h, piVar7);
    piVar7 = (int64_t *)(iVar6 + 8);
    if (iVar6 == 0) {
        piVar7 = piVar8;
    }
    if (piVar7 == (int64_t *)0x0) {
        return 7;
    }
    *(undefined *)(*(int64_t *)(arg_38h + 0x2d8) + 0x24 + (uint64_t)*(uint8_t *)piVar7 * 0x28) = 1;
    return *(uint8_t *)piVar7 + 0x40;
}

// ============================================================
// Function: FUN_1800ca7c0
// Address: 0x1800ca7c0
// Size: 157 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800ca7c0(undefined8 placeholder_0, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar4 = 0;
    if (*(int32_t *)(*(int64_t *)(arg2 + 0x20) + 8) == *(int32_t *)0x180782738) {
        iVar4 = *(int64_t *)(arg2 + 0x20);
    }
    if (iVar4 != 0) {
        iVar4 = *(int64_t *)(iVar4 + 0x20);
        iVar1 = fcn.1800aa2c0();
        if ((iVar1 == 0) && (iVar4 != 0)) {
            iVar2 = 0;
            do {
                iVar3 = iVar2 + 1;
                if (*(char *)(iVar4 + iVar2) != *(char *)(iVar2 + 0x18063e1a8)) {
                    return 0;
                }
                iVar2 = iVar3;
            } while (iVar3 != 7);
            if ((*(int64_t *)(arg2 + 0x28) != 0) && (iVar1 = fcn.180498f10(*(int64_t *)(arg2 + 0x28), arg4), iVar1 == 0)
               ) {
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1800ca860
// Address: 0x1800ca860
// Size: 1022 bytes
// ============================================================
int64_t fcn.1800ca860(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    code *pcVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    uint64_t *puVar15;
    undefined *puVar16;
    uint64_t uVar17;
    uint64_t uVar18;
    uint64_t uVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_78 [8];
    undefined auStack_70 [24];
    int64_t var_58h;
    int64_t var_50h;
    
    var_50h = *(int64_t *)(arg1 + 0x80);
    var_58h = *(int64_t *)(arg1 + 0x88);
    piVar13 = *(int64_t **)(arg2 + 0x28);
    piVar2 = piVar13 + *(int64_t *)(arg2 + 0x30);
    do {
        if (piVar13 == piVar2) {
            return var_58h - var_50h >> 4;
        }
        iVar10 = 0;
        if (*(int32_t *)(*piVar13 + 8) == *(int32_t *)0x18078266c) {
            iVar10 = *piVar13;
        }
        if (iVar10 != 0) {
            iVar8 = *(int64_t *)(arg1 + 0x60);
            piVar1 = (int64_t *)(arg1 + 0x58);
            if (((uint64_t)(iVar8 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x68)) &&
               (iVar7 = fcn.1800ac7f0(piVar1), iVar7 == 0)) {
                uVar11 = *(uint64_t *)(arg1 + 0x70);
                if (iVar8 == 0) {
                    uVar18 = 0x10;
                    iVar7 = func_0x000180459890(0x100);
                    uVar17 = 0;
                    iVar8 = iVar7;
                    uVar12 = 0x10;
code_r0x0001800ca970:
                    do {
                        uVar14 = uVar17 + 1;
                        *(uint64_t *)(iVar8 + uVar17 * 0x10) = *(uint64_t *)(arg1 + 0x70);
                        *(undefined8 *)(iVar8 + 8 + uVar17 * 0x10) = 0;
                        uVar17 = uVar14;
                    } while (uVar14 < uVar18);
                } else {
                    uVar18 = iVar8 * 2;
                    if (uVar18 == 0) {
                        iVar7 = 0;
                        uVar12 = 0;
                    } else {
                        iVar7 = func_0x000180459890(iVar8 << 5);
                        uVar17 = 0;
                        iVar8 = iVar7;
                        uVar12 = uVar18;
                        if (uVar18 != 0) goto code_r0x0001800ca970;
                    }
                }
                uVar18 = 0;
                if (*(int64_t *)(arg1 + 0x60) != 0) {
                    do {
                        uVar17 = *(uint64_t *)(*piVar1 + uVar18 * 0x10);
                        if (uVar17 != *(uint64_t *)(arg1 + 0x70)) {
                            uVar14 = (uVar17 >> 5 ^ uVar17) >> 4;
                            uVar19 = 0;
                            do {
                                uVar14 = uVar14 & uVar12 - 1;
                                puVar15 = (uint64_t *)(uVar14 * 0x10 + iVar7);
                                if (*puVar15 == uVar11) {
                                    *puVar15 = uVar17;
                                    goto code_r0x0001800caa16;
                                }
                                if (*puVar15 == uVar17) goto code_r0x0001800caa16;
                                uVar14 = uVar14 + 1 + uVar19;
                                uVar19 = uVar19 + 1;
                            } while (uVar19 <= uVar12 - 1);
                            puVar15 = (uint64_t *)0x0;
code_r0x0001800caa16:
                            iVar8 = *piVar1;
                            *puVar15 = *(uint64_t *)(iVar8 + uVar18 * 0x10);
                            puVar15[1] = *(uint64_t *)(iVar8 + 8 + uVar18 * 0x10);
                        }
                        uVar18 = uVar18 + 1;
                    } while (uVar18 < *(uint64_t *)(arg1 + 0x60));
                }
                iVar8 = *piVar1;
                *piVar1 = iVar7;
                *(uint64_t *)(arg1 + 0x60) = uVar12;
                if (iVar8 != 0) {
                    func_0x0001800f4640();
                }
            }
            iVar8 = func_0x0001800c1340(piVar1);
            uVar3 = *(undefined8 *)(iVar10 + 0x28);
            uVar4 = *(undefined8 *)(iVar8 + 8);
            puVar5 = *(undefined8 **)(arg1 + 0x88);
            if (puVar5 == *(undefined8 **)(arg1 + 0x90)) {
                iVar7 = (int64_t)puVar5 - *(int64_t *)(arg1 + 0x80) >> 4;
                if (iVar7 == 0xfffffffffffffff) {
                    func_0x000180010010();
                    pcVar6 = (code *)swi(3);
                    iVar10 = (*pcVar6)();
                    return iVar10;
                }
                uVar11 = (int64_t)*(undefined8 **)(arg1 + 0x90) - *(int64_t *)(arg1 + 0x80) >> 4;
                puVar16 = auStack_78;
                if (0xfffffffffffffff - (uVar11 >> 1) < uVar11) goto code_r0x0001800cac52;
                uVar11 = (uVar11 >> 1) + uVar11;
                uVar18 = iVar7 + 1;
                uVar17 = uVar18;
                if (uVar18 <= uVar11) {
                    uVar17 = uVar11;
                }
                puVar16 = auStack_78;
                if (0xfffffffffffffff < uVar17) goto code_r0x0001800cac52;
                uVar17 = uVar17 * 0x10;
                if (uVar17 != 0) {
                    if (uVar17 < 0x1000) {
                        uVar11 = func_0x000180459890(uVar17);
                        goto code_r0x0001800cab37;
                    }
                    puVar16 = auStack_78;
                    if (uVar17 + 0x27 <= uVar17) goto code_r0x0001800cac52;
                    iVar9 = func_0x000180459890();
                    if (iVar9 != 0) {
                        uVar11 = iVar9 + 0x27U & 0xffffffffffffffe0;
                        *(int64_t *)(uVar11 - 8) = iVar9;
                        goto code_r0x0001800cab37;
                    }
code_r0x0001800cac4b:
                    pcVar6 = (code *)swi(0x29);
                    (*pcVar6)(5);
                    puVar16 = auStack_70;
code_r0x0001800cac52:
                    *(undefined8 *)(puVar16 + -8) = 0x1800cac57;
                    func_0x000180004720();
                    pcVar6 = (code *)swi(3);
                    iVar10 = (*pcVar6)();
                    return iVar10;
                }
                uVar11 = 0;
code_r0x0001800cab37:
                iVar7 = iVar7 * 0x10;
                *(undefined8 *)(iVar7 + uVar11) = uVar3;
                *(undefined8 *)(iVar7 + 8 + uVar11) = uVar4;
                uVar12 = uVar11;
                if (puVar5 != *(undefined8 **)(arg1 + 0x88)) {
                    func_0x000180498030(uVar11, *(int64_t *)(arg1 + 0x80), (int64_t)puVar5 - *(int64_t *)(arg1 + 0x80));
                    uVar12 = iVar7 + 0x10 + uVar11;
                }
                func_0x000180498030(uVar12);
                iVar7 = *(int64_t *)(arg1 + 0x80);
                if (iVar7 != 0) {
                    iVar9 = iVar7;
                    if ((0xfff < (*(int64_t *)(arg1 + 0x90) - iVar7 & 0xfffffffffffffff0U)) &&
                       (iVar9 = *(int64_t *)(iVar7 + -8), 0x1f < (iVar7 - iVar9) - 8U)) goto code_r0x0001800cac4b;
                    fcn.180459c3c(iVar9);
                }
                *(uint64_t *)(arg1 + 0x80) = uVar11;
                *(uint64_t *)(arg1 + 0x88) = uVar18 * 0x10 + uVar11;
                *(uint64_t *)(arg1 + 0x90) = uVar17 + uVar11;
            } else {
                *puVar5 = uVar3;
                puVar5[1] = uVar4;
                *(int64_t *)(arg1 + 0x88) = *(int64_t *)(arg1 + 0x88) + 0x10;
            }
            *(int64_t *)(iVar8 + 8) = iVar10;
        }
        piVar13 = piVar13 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800cac60
// Address: 0x1800cac60
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.1800cac60(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t *puVar7;
    uint64_t uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 0x88) - *(int64_t *)(arg1 + 0x80);
    do {
        if ((uint64_t)(iVar3 >> 4) <= (uint64_t)arg2) {
            return;
        }
        iVar3 = *(int64_t *)(arg1 + 0x88);
        iVar9 = *(int64_t *)(arg1 + 0x60);
        uVar1 = *(undefined8 *)(iVar3 + -8);
        if (((uint64_t)(iVar9 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x68)) &&
           (iVar4 = fcn.1800ac7f0(arg1 + 0x58), iVar4 == 0)) {
            uVar2 = *(uint64_t *)(arg1 + 0x70);
            if (iVar9 == 0) {
                uVar8 = 0x10;
                iVar4 = func_0x000180459890(0x100);
                uVar5 = 0;
                iVar9 = iVar4;
                uVar11 = 0x10;
code_r0x0001800cad50:
                do {
                    uVar6 = uVar5 + 1;
                    *(uint64_t *)(iVar9 + uVar5 * 0x10) = *(uint64_t *)(arg1 + 0x70);
                    *(undefined8 *)(iVar9 + 8 + uVar5 * 0x10) = 0;
                    uVar5 = uVar6;
                } while (uVar6 < uVar8);
            } else {
                uVar8 = iVar9 * 2;
                if (uVar8 == 0) {
                    iVar4 = 0;
                    uVar11 = 0;
                } else {
                    iVar4 = func_0x000180459890(iVar9 << 5);
                    uVar5 = 0;
                    iVar9 = iVar4;
                    uVar11 = uVar8;
                    if (uVar8 != 0) goto code_r0x0001800cad50;
                }
            }
            uVar8 = 0;
            if (*(int64_t *)(arg1 + 0x60) != 0) {
                do {
                    uVar5 = *(uint64_t *)(*(int64_t *)(arg1 + 0x58) + uVar8 * 0x10);
                    if (uVar5 != *(uint64_t *)(arg1 + 0x70)) {
                        uVar6 = (uVar5 >> 5 ^ uVar5) >> 4;
                        uVar10 = 0;
                        do {
                            uVar6 = uVar6 & uVar11 - 1;
                            puVar7 = (uint64_t *)(uVar6 * 0x10 + iVar4);
                            if (*puVar7 == uVar2) {
                                *puVar7 = uVar5;
                                goto code_r0x0001800cade6;
                            }
                            if (*puVar7 == uVar5) goto code_r0x0001800cade6;
                            uVar6 = uVar6 + 1 + uVar10;
                            uVar10 = uVar10 + 1;
                        } while (uVar10 <= uVar11 - 1);
                        puVar7 = (uint64_t *)0x0;
code_r0x0001800cade6:
                        iVar9 = *(int64_t *)(arg1 + 0x58);
                        *puVar7 = *(uint64_t *)(iVar9 + uVar8 * 0x10);
                        puVar7[1] = *(uint64_t *)(iVar9 + 8 + uVar8 * 0x10);
                    }
                    uVar8 = uVar8 + 1;
                } while (uVar8 < *(uint64_t *)(arg1 + 0x60));
            }
            iVar9 = *(int64_t *)(arg1 + 0x58);
            *(int64_t *)(arg1 + 0x58) = iVar4;
            *(uint64_t *)(arg1 + 0x60) = uVar11;
            if (iVar9 != 0) {
                func_0x0001800f4640();
            }
        }
        iVar3 = func_0x0001800c1340(arg1 + 0x58, iVar3 + -0x10);
        *(undefined8 *)(iVar3 + 8) = uVar1;
        *(int64_t *)(arg1 + 0x88) = *(int64_t *)(arg1 + 0x88) + -0x10;
        iVar3 = *(int64_t *)(arg1 + 0x88) - *(int64_t *)(arg1 + 0x80);
    } while( true );
}

// ============================================================
// Function: FUN_1800cac8b
// Address: 0x1800cac8b
// Size: 504 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.1800cac60(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t *puVar7;
    uint64_t uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 0x88) - *(int64_t *)(arg1 + 0x80);
    do {
        if ((uint64_t)(iVar3 >> 4) <= (uint64_t)arg2) {
            return;
        }
        iVar3 = *(int64_t *)(arg1 + 0x88);
        iVar9 = *(int64_t *)(arg1 + 0x60);
        uVar1 = *(undefined8 *)(iVar3 + -8);
        if (((uint64_t)(iVar9 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x68)) &&
           (iVar4 = fcn.1800ac7f0(arg1 + 0x58), iVar4 == 0)) {
            uVar2 = *(uint64_t *)(arg1 + 0x70);
            if (iVar9 == 0) {
                uVar8 = 0x10;
                iVar4 = func_0x000180459890(0x100);
                uVar5 = 0;
                iVar9 = iVar4;
                uVar11 = 0x10;
code_r0x0001800cad50:
                do {
                    uVar6 = uVar5 + 1;
                    *(uint64_t *)(iVar9 + uVar5 * 0x10) = *(uint64_t *)(arg1 + 0x70);
                    *(undefined8 *)(iVar9 + 8 + uVar5 * 0x10) = 0;
                    uVar5 = uVar6;
                } while (uVar6 < uVar8);
            } else {
                uVar8 = iVar9 * 2;
                if (uVar8 == 0) {
                    iVar4 = 0;
                    uVar11 = 0;
                } else {
                    iVar4 = func_0x000180459890(iVar9 << 5);
                    uVar5 = 0;
                    iVar9 = iVar4;
                    uVar11 = uVar8;
                    if (uVar8 != 0) goto code_r0x0001800cad50;
                }
            }
            uVar8 = 0;
            if (*(int64_t *)(arg1 + 0x60) != 0) {
                do {
                    uVar5 = *(uint64_t *)(*(int64_t *)(arg1 + 0x58) + uVar8 * 0x10);
                    if (uVar5 != *(uint64_t *)(arg1 + 0x70)) {
                        uVar6 = (uVar5 >> 5 ^ uVar5) >> 4;
                        uVar10 = 0;
                        do {
                            uVar6 = uVar6 & uVar11 - 1;
                            puVar7 = (uint64_t *)(uVar6 * 0x10 + iVar4);
                            if (*puVar7 == uVar2) {
                                *puVar7 = uVar5;
                                goto code_r0x0001800cade6;
                            }
                            if (*puVar7 == uVar5) goto code_r0x0001800cade6;
                            uVar6 = uVar6 + 1 + uVar10;
                            uVar10 = uVar10 + 1;
                        } while (uVar10 <= uVar11 - 1);
                        puVar7 = (uint64_t *)0x0;
code_r0x0001800cade6:
                        iVar9 = *(int64_t *)(arg1 + 0x58);
                        *puVar7 = *(uint64_t *)(iVar9 + uVar8 * 0x10);
                        puVar7[1] = *(uint64_t *)(iVar9 + 8 + uVar8 * 0x10);
                    }
                    uVar8 = uVar8 + 1;
                } while (uVar8 < *(uint64_t *)(arg1 + 0x60));
            }
            iVar9 = *(int64_t *)(arg1 + 0x58);
            *(int64_t *)(arg1 + 0x58) = iVar4;
            *(uint64_t *)(arg1 + 0x60) = uVar11;
            if (iVar9 != 0) {
                func_0x0001800f4640();
            }
        }
        iVar3 = func_0x0001800c1340(arg1 + 0x58, iVar3 + -0x10);
        *(undefined8 *)(iVar3 + 8) = uVar1;
        *(int64_t *)(arg1 + 0x88) = *(int64_t *)(arg1 + 0x88) + -0x10;
        iVar3 = *(int64_t *)(arg1 + 0x88) - *(int64_t *)(arg1 + 0x80);
    } while( true );
}

// ============================================================
// Function: FUN_1800cae83
// Address: 0x1800cae83
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.1800cac60(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t *puVar7;
    uint64_t uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 0x88) - *(int64_t *)(arg1 + 0x80);
    do {
        if ((uint64_t)(iVar3 >> 4) <= (uint64_t)arg2) {
            return;
        }
        iVar3 = *(int64_t *)(arg1 + 0x88);
        iVar9 = *(int64_t *)(arg1 + 0x60);
        uVar1 = *(undefined8 *)(iVar3 + -8);
        if (((uint64_t)(iVar9 * 3) >> 2 <= *(uint64_t *)(arg1 + 0x68)) &&
           (iVar4 = fcn.1800ac7f0(arg1 + 0x58), iVar4 == 0)) {
            uVar2 = *(uint64_t *)(arg1 + 0x70);
            if (iVar9 == 0) {
                uVar8 = 0x10;
                iVar4 = func_0x000180459890(0x100);
                uVar5 = 0;
                iVar9 = iVar4;
                uVar11 = 0x10;
code_r0x0001800cad50:
                do {
                    uVar6 = uVar5 + 1;
                    *(uint64_t *)(iVar9 + uVar5 * 0x10) = *(uint64_t *)(arg1 + 0x70);
                    *(undefined8 *)(iVar9 + 8 + uVar5 * 0x10) = 0;
                    uVar5 = uVar6;
                } while (uVar6 < uVar8);
            } else {
                uVar8 = iVar9 * 2;
                if (uVar8 == 0) {
                    iVar4 = 0;
                    uVar11 = 0;
                } else {
                    iVar4 = func_0x000180459890(iVar9 << 5);
                    uVar5 = 0;
                    iVar9 = iVar4;
                    uVar11 = uVar8;
                    if (uVar8 != 0) goto code_r0x0001800cad50;
                }
            }
            uVar8 = 0;
            if (*(int64_t *)(arg1 + 0x60) != 0) {
                do {
                    uVar5 = *(uint64_t *)(*(int64_t *)(arg1 + 0x58) + uVar8 * 0x10);
                    if (uVar5 != *(uint64_t *)(arg1 + 0x70)) {
                        uVar6 = (uVar5 >> 5 ^ uVar5) >> 4;
                        uVar10 = 0;
                        do {
                            uVar6 = uVar6 & uVar11 - 1;
                            puVar7 = (uint64_t *)(uVar6 * 0x10 + iVar4);
                            if (*puVar7 == uVar2) {
                                *puVar7 = uVar5;
                                goto code_r0x0001800cade6;
                            }
                            if (*puVar7 == uVar5) goto code_r0x0001800cade6;
                            uVar6 = uVar6 + 1 + uVar10;
                            uVar10 = uVar10 + 1;
                        } while (uVar10 <= uVar11 - 1);
                        puVar7 = (uint64_t *)0x0;
code_r0x0001800cade6:
                        iVar9 = *(int64_t *)(arg1 + 0x58);
                        *puVar7 = *(uint64_t *)(iVar9 + uVar8 * 0x10);
                        puVar7[1] = *(uint64_t *)(iVar9 + 8 + uVar8 * 0x10);
                    }
                    uVar8 = uVar8 + 1;
                } while (uVar8 < *(uint64_t *)(arg1 + 0x60));
            }
            iVar9 = *(int64_t *)(arg1 + 0x58);
            *(int64_t *)(arg1 + 0x58) = iVar4;
            *(uint64_t *)(arg1 + 0x60) = uVar11;
            if (iVar9 != 0) {
                func_0x0001800f4640();
            }
        }
        iVar3 = func_0x0001800c1340(arg1 + 0x58, iVar3 + -0x10);
        *(undefined8 *)(iVar3 + 8) = uVar1;
        *(int64_t *)(arg1 + 0x88) = *(int64_t *)(arg1 + 0x88) + -0x10;
        iVar3 = *(int64_t *)(arg1 + 0x88) - *(int64_t *)(arg1 + 0x80);
    } while( true );
}

// ============================================================
// Function: FUN_1800cae90
// Address: 0x1800cae90
// Size: 177 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t * fcn.1800cae90(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t **ppiVar2;
    uint64_t uVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    int64_t var_8h;
    
    if ((*(int64_t *)(arg1 + 0xd0) != 0) && (arg2 != *(int64_t *)(arg1 + 0xd8))) {
        uVar6 = *(int64_t *)(arg1 + 200) - 1;
        uVar1 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar3 = 0;
        do {
            uVar1 = uVar1 & uVar6;
            piVar5 = (int64_t *)(uVar1 * 0x10 + *(int64_t *)(arg1 + 0xc0));
            if (*piVar5 == arg2) {
                ppiVar4 = (int64_t **)(piVar5 + 1);
                if (piVar5 == (int64_t *)0x0) {
                    ppiVar4 = (int64_t **)0x0;
                }
                if (ppiVar4 == (int64_t **)0x0) {
                    return (int64_t *)0x0;
                }
                ppiVar2 = (int64_t **)0x0;
                if (*(int32_t *)(*ppiVar4 + 1) == *(int32_t *)0x180782704) {
                    ppiVar2 = (int64_t **)*ppiVar4;
                }
                if (ppiVar2 == (int64_t **)0x0) {
                    return (int64_t *)0x0;
                }
                return ppiVar2[6];
            }
            if (*piVar5 == *(int64_t *)(arg1 + 0xd8)) {
                return (int64_t *)0x0;
            }
            uVar1 = uVar1 + 1 + uVar3;
            uVar3 = uVar3 + 1;
        } while (uVar3 <= uVar6);
    }
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_1800caf50
// Address: 0x1800caf50
// Size: 265 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 fcn.1800caf50(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 uVar1;
    int64_t iVar2;
    int64_t *piVar3;
    undefined4 *puVar4;
    unkbyte7 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar2 = 0;
    if (*(int32_t *)(arg3 + 8) == *(int32_t *)0x1807826bc) {
        iVar2 = arg3;
    }
    var_10h = arg2;
    if ((iVar2 != 0) && (*(char *)(iVar2 + 0x30) == '\0')) {
        iVar2 = fcn.1800ac7f0(arg1 + 0x58, iVar2 + 0x50);
        piVar3 = (int64_t *)(iVar2 + 8);
        if (iVar2 == 0) {
            piVar3 = (int64_t *)0x0;
        }
        if ((piVar3 != (int64_t *)0x0) && (*piVar3 != 0)) {
            arg3 = *(int64_t *)(*piVar3 + 0x60);
        }
    }
    piVar3 = (int64_t *)func_0x0001800cc970(arg1 + 0xc0, &var_10h);
    *piVar3 = arg3;
    _var_38h = ZEXT816(0);
    _var_28h = ZEXT816(0);
    var_48h = 0;
    var_40h = 0;
    uVar1 = fcn.1800ca210(arg3, (int64_t)&var_48h, arg1 + 0x58, CONCAT71(in_R9, 1), *(int64_t *)(arg1 + 0x20), 
                          *(int64_t *)(arg1 + 0x28), *(int64_t *)(arg1 + 0x50), (int64_t)&var_38h);
    puVar4 = (undefined4 *)func_0x0001800ac540(*(undefined8 *)(arg1 + 0x18), &var_10h);
    *puVar4 = uVar1;
    if (var_38h != 0) {
        func_0x0001800f4640();
    }
    return uVar1;
}

// ============================================================
// Function: FUN_1800cb060
// Address: 0x1800cb060
// Size: 270 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.1800cb060(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_a0h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int32_t *piVar4;
    unkbyte7 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar2 = 0;
    if (*(int32_t *)(arg3 + 8) == *(int32_t *)0x1807826bc) {
        iVar2 = arg3;
    }
    var_10h = arg2;
    if ((iVar2 != 0) && (*(char *)(iVar2 + 0x30) == '\0')) {
        iVar2 = fcn.1800ac7f0(arg1 + 0x58, iVar2 + 0x50);
        piVar3 = (int64_t *)(iVar2 + 8);
        if (iVar2 == 0) {
            piVar3 = (int64_t *)0x0;
        }
        if ((piVar3 != (int64_t *)0x0) && (*piVar3 != 0)) {
            arg3 = *(int64_t *)(*piVar3 + 0x60);
        }
    }
    piVar3 = (int64_t *)func_0x0001800cc970(arg1 + 0x98, &var_10h);
    *piVar3 = arg3;
    _var_38h = ZEXT816(0);
    _var_28h = ZEXT816(0);
    var_48h = 0;
    var_40h = 0;
    iVar1 = fcn.1800ca210(arg3, (int64_t)&var_48h, arg1 + 0x58, CONCAT71(in_R9, 1), *(int64_t *)(arg1 + 0x20), 
                          *(int64_t *)(arg1 + 0x28), *(int64_t *)(arg1 + 0x50), (int64_t)&var_38h);
    if (iVar1 != 0xf) {
        piVar4 = (int32_t *)func_0x0001800ac540(*(undefined8 *)(arg1 + 0x10), &var_10h);
        *piVar4 = iVar1;
    }
    if (var_38h != 0) {
        func_0x0001800f4640();
    }
    return iVar1;
}

// ============================================================
// Function: FUN_1800cb170
// Address: 0x1800cb170
// Size: 91 bytes
// ============================================================
undefined fcn.1800cb170(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int64_t arg2_00;
    undefined8 *puVar2;
    
    arg2_00 = fcn.1800ca860(arg1, arg2);
    puVar2 = *(undefined8 **)(arg2 + 0x28);
    puVar1 = puVar2 + *(int64_t *)(arg2 + 0x30);
    for (; puVar2 != puVar1; puVar2 = puVar2 + 1) {
        (***(code ***)(undefined8 *)*puVar2)((undefined8 *)*puVar2, arg1);
    }
    fcn.1800cac60(arg1, arg2_00);
    return 0;
}

// ============================================================
// Function: FUN_1800cb1d0
// Address: 0x1800cb1d0
// Size: 107 bytes
// ============================================================
uint64_t fcn.1800cb1d0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                      int64_t arg_30h)
{
    undefined8 *puVar1;
    int64_t arg2_00;
    uint64_t uVar2;
    undefined8 *puVar3;
    
    arg2_00 = fcn.1800ca860(arg1, *(int64_t *)(arg2 + 0x30));
    puVar3 = *(undefined8 **)(*(int64_t *)(arg2 + 0x30) + 0x28);
    puVar1 = puVar3 + *(int64_t *)(*(int64_t *)(arg2 + 0x30) + 0x30);
    for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
        (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg1);
    }
    (**(code **)**(undefined8 **)(arg2 + 0x28))(*(undefined8 **)(arg2 + 0x28), arg1);
    uVar2 = fcn.1800cac60(arg1, arg2_00);
    return uVar2 & 0xffffffffffffff00;
}

