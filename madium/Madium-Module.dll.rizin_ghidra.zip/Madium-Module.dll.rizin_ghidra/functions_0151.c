// Chunk 151 - 50 functions

// ============================================================
// Function: FUN_1801feb70
// Address: 0x1801feb70
// Size: 53 bytes
// ============================================================
undefined8 fcn.1801feb70(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    uint8_t *puVar1;
    int64_t iVar2;
    undefined8 uVar3;
    uint8_t *puVar4;
    uint8_t **in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RSI;
    uint8_t *puVar5;
    uint32_t *in_R8;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801feb80;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    puVar4 = in_RCX[1];
    if (puVar4 == (uint8_t *)0x0) {
        return 0;
    }
    puVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RSI;
    puVar5 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6));
    if (puVar4 < puVar5) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801febd8;
    uVar3 = fcn.180274e70(puVar1);
    *in_RDX = uVar3;
    if (in_R8 != (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801febe8;
        puVar4 = (uint8_t *)fcn.1801f8d10(uVar3);
        *in_R8 = (uint32_t)(puVar5 == puVar4);
    }
    return 1;
}

// ============================================================
// Function: FUN_1801feba5
// Address: 0x1801feba5
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801feb70(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    uint8_t *puVar1;
    int64_t iVar2;
    undefined8 uVar3;
    uint8_t *puVar4;
    uint8_t **in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RSI;
    uint8_t *puVar5;
    uint32_t *in_R8;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801feb80;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    puVar4 = in_RCX[1];
    if (puVar4 == (uint8_t *)0x0) {
        return 0;
    }
    puVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RSI;
    puVar5 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6));
    if (puVar4 < puVar5) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801febd8;
    uVar3 = fcn.180274e70(puVar1);
    *in_RDX = uVar3;
    if (in_R8 != (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801febe8;
        puVar4 = (uint8_t *)fcn.1801f8d10(uVar3);
        *in_R8 = (uint32_t)(puVar5 == puVar4);
    }
    return 1;
}

// ============================================================
// Function: FUN_1801febd0
// Address: 0x1801febd0
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801feb70(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    uint8_t *puVar1;
    int64_t iVar2;
    undefined8 uVar3;
    uint8_t *puVar4;
    uint8_t **in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RSI;
    uint8_t *puVar5;
    uint32_t *in_R8;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801feb80;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    puVar4 = in_RCX[1];
    if (puVar4 == (uint8_t *)0x0) {
        return 0;
    }
    puVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RSI;
    puVar5 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6));
    if (puVar4 < puVar5) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801febd8;
    uVar3 = fcn.180274e70(puVar1);
    *in_RDX = uVar3;
    if (in_R8 != (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801febe8;
        puVar4 = (uint8_t *)fcn.1801f8d10(uVar3);
        *in_R8 = (uint32_t)(puVar5 == puVar4);
    }
    return 1;
}

// ============================================================
// Function: FUN_1801fec10
// Address: 0x1801fec10
// Size: 79 bytes
// ============================================================
undefined8 fcn.1801fec10(uint8_t **param_1, undefined8 *param_2)
{
    uint8_t *puVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fec1c;
    iVar2 = fcn.18045a350();
    if ((param_1[1] != (uint8_t *)0x0) &&
       (puVar1 = *param_1, (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar1 >> 6)) <= param_1[1])) {
        *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801fec51;
        uVar3 = fcn.180274e70(puVar1);
        *param_2 = uVar3;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801fec60
// Address: 0x1801fec60
// Size: 150 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.1801fec60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h,
             int64_t arg_b0h, int64_t arg_128h)
{
    undefined8 *puVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t in_RDX;
    int64_t iVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801fec75;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar1 = *(undefined8 **)((int64_t)&arg_b0h + iVar5);
    *(undefined4 *)((int64_t)&arg_28h + iVar5) = 0;
    *puVar1 = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fec9d;
    iVar3 = func_0x0001801fd7f0();
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
        *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x203;
        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b8fe8;
        *(undefined8 *)((int64_t)&var_8h + iVar5) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fece2;
        func_0x0001801e4990(in_RDX, 7, *(undefined8 *)((int64_t)&arg_a8h + iVar5), 0x1804b9008);
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_98h + iVar5) = unaff_RSI;
    uVar7 = *(undefined8 *)((int64_t)&arg_a8h + iVar5);
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fed0e;
    uVar6 = func_0x0001801fefa0(in_RDX, *(undefined8 *)((int64_t)&arg_38h + iVar5), uVar7, (int64_t)&arg_b0h + iVar5);
    if ((int32_t)uVar6 == 0) {
        return uVar6;
    }
    *(undefined8 *)((int64_t)&arg_88h + iVar5) = unaff_RBX;
    iVar2 = *(int64_t *)((int64_t)&arg_b0h + iVar5);
    *(undefined8 *)((int64_t)&arg_90h + iVar5) = unaff_RBP;
    if (iVar2 == 0) {
code_r0x0001801fef31:
        uVar7 = 1;
    } else {
        if (*(char *)(iVar2 + 0x102) == '\0') {
            iVar8 = 5;
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
            uVar6 = 0x1804b92d8;
            *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x217;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fed87;
            iVar3 = func_0x0001801e5ad0(iVar2 + 0xa0, 
                                        *(int64_t *)((int64_t)&arg_48h + iVar5) +
                                        *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                        *(uint32_t *)((int64_t)&arg_58h + iVar5) >> 1 & 1);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fedb9;
                iVar3 = func_0x0001801e5970(iVar2 + 0xa0, 0);
                iVar8 = (int64_t)iVar3;
                if (iVar3 == 0) {
    // switch table (6 cases) at 0x1801fef64
                    switch(*(undefined *)(iVar2 + 0x102)) {
                    case 1:
                    case 2:
                        goto code_r0x0001801fee06;
                    default:
                        goto code_r0x0001801fef31;
                    }
                }
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
                uVar6 = 0x1804b90e8;
                *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x22c;
                goto code_r0x0001801feef3;
            }
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
            uVar6 = 0x1804b90c8;
            *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x222;
code_r0x0001801feeee:
            iVar8 = 1;
        }
code_r0x0001801feef3:
        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b8fe8;
        *(undefined8 *)((int64_t)&var_8h + iVar5) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fef0f;
        func_0x0001801e4990(in_RDX, iVar8, uVar7, uVar6);
        uVar7 = 0;
    }
    return uVar7;
code_r0x0001801fee06:
    uVar4 = *(uint32_t *)((int64_t)&arg_58h + iVar5);
    if ((uVar4 & 2) != 0) {
    // switch table (7 cases) at 0x1801fef7c
        switch(*(undefined *)(iVar2 + 0x102)) {
        default:
code_r0x0001801fee31:
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fee4a;
            func_0x0001801e7b80(in_RDX + 0x300, iVar2, 
                                *(int64_t *)((int64_t)&arg_48h + iVar5) + *(int64_t *)((int64_t)&arg_40h + iVar5));
            break;
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fee2d;
            iVar3 = func_0x0001801e5980(iVar2 + 0xa0, 0);
            if (iVar3 == 0) goto code_r0x0001801fee31;
        }
        uVar4 = *(uint32_t *)((int64_t)&arg_58h + iVar5);
    }
    if ((*(uint32_t *)(iVar2 + 0x100) & 0x4000000) == 0) {
        if ((*(int64_t *)((int64_t)&arg_48h + iVar5) != 0) || ((uVar4 & 2) != 0)) {
            uVar6 = *(undefined8 *)(iVar2 + 0x78);
            *(uint32_t *)((int64_t)&var_10h + iVar5) = uVar4 >> 1 & 1;
            *(undefined8 *)((int64_t)&var_8h + iVar5) = *(undefined8 *)((int64_t)&arg_48h + iVar5);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fee92;
            iVar3 = func_0x0001801e6d70(uVar6, in_R8, *(undefined8 *)((int64_t)&arg_40h + iVar5), 
                                        *(undefined8 *)((int64_t)&arg_50h + iVar5));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
                uVar6 = 0x1804b91a0;
                *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x26a;
                goto code_r0x0001801feeee;
            }
        }
        if (*(char *)(iVar2 + 0x102) == '\x02') {
            uVar6 = *(undefined8 *)(iVar2 + 0x78);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801feecf;
            iVar3 = func_0x0001801e6a70(uVar6, (int64_t)&arg_30h + iVar5, (int64_t)&arg_28h + iVar5);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
                uVar6 = 0x1804b92f8;
                *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x279;
                goto code_r0x0001801feeee;
            }
        }
        if (*(int32_t *)((int64_t)&arg_28h + iVar5) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fef29;
            func_0x0001801e7bf0(in_RDX + 0x300, iVar2);
        }
        *puVar1 = *(undefined8 *)((int64_t)&arg_48h + iVar5);
    }
    goto code_r0x0001801fef31;
}

// ============================================================
// Function: FUN_1801fecf6
// Address: 0x1801fecf6
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.1801fec60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h,
             int64_t arg_b0h, int64_t arg_128h)
{
    undefined8 *puVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t in_RDX;
    int64_t iVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801fec75;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar1 = *(undefined8 **)((int64_t)&arg_b0h + iVar5);
    *(undefined4 *)((int64_t)&arg_28h + iVar5) = 0;
    *puVar1 = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fec9d;
    iVar3 = func_0x0001801fd7f0();
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
        *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x203;
        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b8fe8;
        *(undefined8 *)((int64_t)&var_8h + iVar5) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fece2;
        func_0x0001801e4990(in_RDX, 7, *(undefined8 *)((int64_t)&arg_a8h + iVar5), 0x1804b9008);
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_98h + iVar5) = unaff_RSI;
    uVar7 = *(undefined8 *)((int64_t)&arg_a8h + iVar5);
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fed0e;
    uVar6 = func_0x0001801fefa0(in_RDX, *(undefined8 *)((int64_t)&arg_38h + iVar5), uVar7, (int64_t)&arg_b0h + iVar5);
    if ((int32_t)uVar6 == 0) {
        return uVar6;
    }
    *(undefined8 *)((int64_t)&arg_88h + iVar5) = unaff_RBX;
    iVar2 = *(int64_t *)((int64_t)&arg_b0h + iVar5);
    *(undefined8 *)((int64_t)&arg_90h + iVar5) = unaff_RBP;
    if (iVar2 == 0) {
code_r0x0001801fef31:
        uVar7 = 1;
    } else {
        if (*(char *)(iVar2 + 0x102) == '\0') {
            iVar8 = 5;
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
            uVar6 = 0x1804b92d8;
            *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x217;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fed87;
            iVar3 = func_0x0001801e5ad0(iVar2 + 0xa0, 
                                        *(int64_t *)((int64_t)&arg_48h + iVar5) +
                                        *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                        *(uint32_t *)((int64_t)&arg_58h + iVar5) >> 1 & 1);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fedb9;
                iVar3 = func_0x0001801e5970(iVar2 + 0xa0, 0);
                iVar8 = (int64_t)iVar3;
                if (iVar3 == 0) {
    // switch table (6 cases) at 0x1801fef64
                    switch(*(undefined *)(iVar2 + 0x102)) {
                    case 1:
                    case 2:
                        goto code_r0x0001801fee06;
                    default:
                        goto code_r0x0001801fef31;
                    }
                }
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
                uVar6 = 0x1804b90e8;
                *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x22c;
                goto code_r0x0001801feef3;
            }
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
            uVar6 = 0x1804b90c8;
            *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x222;
code_r0x0001801feeee:
            iVar8 = 1;
        }
code_r0x0001801feef3:
        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b8fe8;
        *(undefined8 *)((int64_t)&var_8h + iVar5) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fef0f;
        func_0x0001801e4990(in_RDX, iVar8, uVar7, uVar6);
        uVar7 = 0;
    }
    return uVar7;
code_r0x0001801fee06:
    uVar4 = *(uint32_t *)((int64_t)&arg_58h + iVar5);
    if ((uVar4 & 2) != 0) {
    // switch table (7 cases) at 0x1801fef7c
        switch(*(undefined *)(iVar2 + 0x102)) {
        default:
code_r0x0001801fee31:
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fee4a;
            func_0x0001801e7b80(in_RDX + 0x300, iVar2, 
                                *(int64_t *)((int64_t)&arg_48h + iVar5) + *(int64_t *)((int64_t)&arg_40h + iVar5));
            break;
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fee2d;
            iVar3 = func_0x0001801e5980(iVar2 + 0xa0, 0);
            if (iVar3 == 0) goto code_r0x0001801fee31;
        }
        uVar4 = *(uint32_t *)((int64_t)&arg_58h + iVar5);
    }
    if ((*(uint32_t *)(iVar2 + 0x100) & 0x4000000) == 0) {
        if ((*(int64_t *)((int64_t)&arg_48h + iVar5) != 0) || ((uVar4 & 2) != 0)) {
            uVar6 = *(undefined8 *)(iVar2 + 0x78);
            *(uint32_t *)((int64_t)&var_10h + iVar5) = uVar4 >> 1 & 1;
            *(undefined8 *)((int64_t)&var_8h + iVar5) = *(undefined8 *)((int64_t)&arg_48h + iVar5);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fee92;
            iVar3 = func_0x0001801e6d70(uVar6, in_R8, *(undefined8 *)((int64_t)&arg_40h + iVar5), 
                                        *(undefined8 *)((int64_t)&arg_50h + iVar5));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
                uVar6 = 0x1804b91a0;
                *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x26a;
                goto code_r0x0001801feeee;
            }
        }
        if (*(char *)(iVar2 + 0x102) == '\x02') {
            uVar6 = *(undefined8 *)(iVar2 + 0x78);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801feecf;
            iVar3 = func_0x0001801e6a70(uVar6, (int64_t)&arg_30h + iVar5, (int64_t)&arg_28h + iVar5);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
                uVar6 = 0x1804b92f8;
                *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x279;
                goto code_r0x0001801feeee;
            }
        }
        if (*(int32_t *)((int64_t)&arg_28h + iVar5) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fef29;
            func_0x0001801e7bf0(in_RDX + 0x300, iVar2);
        }
        *puVar1 = *(undefined8 *)((int64_t)&arg_48h + iVar5);
    }
    goto code_r0x0001801fef31;
}

// ============================================================
// Function: FUN_1801fed16
// Address: 0x1801fed16
// Size: 560 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.1801fec60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h,
             int64_t arg_b0h, int64_t arg_128h)
{
    undefined8 *puVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t in_RDX;
    int64_t iVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801fec75;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar1 = *(undefined8 **)((int64_t)&arg_b0h + iVar5);
    *(undefined4 *)((int64_t)&arg_28h + iVar5) = 0;
    *puVar1 = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fec9d;
    iVar3 = func_0x0001801fd7f0();
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
        *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x203;
        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b8fe8;
        *(undefined8 *)((int64_t)&var_8h + iVar5) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fece2;
        func_0x0001801e4990(in_RDX, 7, *(undefined8 *)((int64_t)&arg_a8h + iVar5), 0x1804b9008);
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_98h + iVar5) = unaff_RSI;
    uVar7 = *(undefined8 *)((int64_t)&arg_a8h + iVar5);
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fed0e;
    uVar6 = func_0x0001801fefa0(in_RDX, *(undefined8 *)((int64_t)&arg_38h + iVar5), uVar7, (int64_t)&arg_b0h + iVar5);
    if ((int32_t)uVar6 == 0) {
        return uVar6;
    }
    *(undefined8 *)((int64_t)&arg_88h + iVar5) = unaff_RBX;
    iVar2 = *(int64_t *)((int64_t)&arg_b0h + iVar5);
    *(undefined8 *)((int64_t)&arg_90h + iVar5) = unaff_RBP;
    if (iVar2 == 0) {
code_r0x0001801fef31:
        uVar7 = 1;
    } else {
        if (*(char *)(iVar2 + 0x102) == '\0') {
            iVar8 = 5;
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
            uVar6 = 0x1804b92d8;
            *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x217;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fed87;
            iVar3 = func_0x0001801e5ad0(iVar2 + 0xa0, 
                                        *(int64_t *)((int64_t)&arg_48h + iVar5) +
                                        *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                        *(uint32_t *)((int64_t)&arg_58h + iVar5) >> 1 & 1);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fedb9;
                iVar3 = func_0x0001801e5970(iVar2 + 0xa0, 0);
                iVar8 = (int64_t)iVar3;
                if (iVar3 == 0) {
    // switch table (6 cases) at 0x1801fef64
                    switch(*(undefined *)(iVar2 + 0x102)) {
                    case 1:
                    case 2:
                        goto code_r0x0001801fee06;
                    default:
                        goto code_r0x0001801fef31;
                    }
                }
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
                uVar6 = 0x1804b90e8;
                *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x22c;
                goto code_r0x0001801feef3;
            }
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
            uVar6 = 0x1804b90c8;
            *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x222;
code_r0x0001801feeee:
            iVar8 = 1;
        }
code_r0x0001801feef3:
        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b8fe8;
        *(undefined8 *)((int64_t)&var_8h + iVar5) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fef0f;
        func_0x0001801e4990(in_RDX, iVar8, uVar7, uVar6);
        uVar7 = 0;
    }
    return uVar7;
code_r0x0001801fee06:
    uVar4 = *(uint32_t *)((int64_t)&arg_58h + iVar5);
    if ((uVar4 & 2) != 0) {
    // switch table (7 cases) at 0x1801fef7c
        switch(*(undefined *)(iVar2 + 0x102)) {
        default:
code_r0x0001801fee31:
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fee4a;
            func_0x0001801e7b80(in_RDX + 0x300, iVar2, 
                                *(int64_t *)((int64_t)&arg_48h + iVar5) + *(int64_t *)((int64_t)&arg_40h + iVar5));
            break;
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fee2d;
            iVar3 = func_0x0001801e5980(iVar2 + 0xa0, 0);
            if (iVar3 == 0) goto code_r0x0001801fee31;
        }
        uVar4 = *(uint32_t *)((int64_t)&arg_58h + iVar5);
    }
    if ((*(uint32_t *)(iVar2 + 0x100) & 0x4000000) == 0) {
        if ((*(int64_t *)((int64_t)&arg_48h + iVar5) != 0) || ((uVar4 & 2) != 0)) {
            uVar6 = *(undefined8 *)(iVar2 + 0x78);
            *(uint32_t *)((int64_t)&var_10h + iVar5) = uVar4 >> 1 & 1;
            *(undefined8 *)((int64_t)&var_8h + iVar5) = *(undefined8 *)((int64_t)&arg_48h + iVar5);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fee92;
            iVar3 = func_0x0001801e6d70(uVar6, in_R8, *(undefined8 *)((int64_t)&arg_40h + iVar5), 
                                        *(undefined8 *)((int64_t)&arg_50h + iVar5));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
                uVar6 = 0x1804b91a0;
                *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x26a;
                goto code_r0x0001801feeee;
            }
        }
        if (*(char *)(iVar2 + 0x102) == '\x02') {
            uVar6 = *(undefined8 *)(iVar2 + 0x78);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801feecf;
            iVar3 = func_0x0001801e6a70(uVar6, (int64_t)&arg_30h + iVar5, (int64_t)&arg_28h + iVar5);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
                uVar6 = 0x1804b92f8;
                *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x279;
                goto code_r0x0001801feeee;
            }
        }
        if (*(int32_t *)((int64_t)&arg_28h + iVar5) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fef29;
            func_0x0001801e7bf0(in_RDX + 0x300, iVar2);
        }
        *puVar1 = *(undefined8 *)((int64_t)&arg_48h + iVar5);
    }
    goto code_r0x0001801fef31;
}

// ============================================================
// Function: FUN_1801fef46
// Address: 0x1801fef46
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.1801fec60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h,
             int64_t arg_b0h, int64_t arg_128h)
{
    undefined8 *puVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t in_RDX;
    int64_t iVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801fec75;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar1 = *(undefined8 **)((int64_t)&arg_b0h + iVar5);
    *(undefined4 *)((int64_t)&arg_28h + iVar5) = 0;
    *puVar1 = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fec9d;
    iVar3 = func_0x0001801fd7f0();
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
        *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x203;
        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b8fe8;
        *(undefined8 *)((int64_t)&var_8h + iVar5) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fece2;
        func_0x0001801e4990(in_RDX, 7, *(undefined8 *)((int64_t)&arg_a8h + iVar5), 0x1804b9008);
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_98h + iVar5) = unaff_RSI;
    uVar7 = *(undefined8 *)((int64_t)&arg_a8h + iVar5);
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fed0e;
    uVar6 = func_0x0001801fefa0(in_RDX, *(undefined8 *)((int64_t)&arg_38h + iVar5), uVar7, (int64_t)&arg_b0h + iVar5);
    if ((int32_t)uVar6 == 0) {
        return uVar6;
    }
    *(undefined8 *)((int64_t)&arg_88h + iVar5) = unaff_RBX;
    iVar2 = *(int64_t *)((int64_t)&arg_b0h + iVar5);
    *(undefined8 *)((int64_t)&arg_90h + iVar5) = unaff_RBP;
    if (iVar2 == 0) {
code_r0x0001801fef31:
        uVar7 = 1;
    } else {
        if (*(char *)(iVar2 + 0x102) == '\0') {
            iVar8 = 5;
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
            uVar6 = 0x1804b92d8;
            *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x217;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fed87;
            iVar3 = func_0x0001801e5ad0(iVar2 + 0xa0, 
                                        *(int64_t *)((int64_t)&arg_48h + iVar5) +
                                        *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                        *(uint32_t *)((int64_t)&arg_58h + iVar5) >> 1 & 1);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fedb9;
                iVar3 = func_0x0001801e5970(iVar2 + 0xa0, 0);
                iVar8 = (int64_t)iVar3;
                if (iVar3 == 0) {
    // switch table (6 cases) at 0x1801fef64
                    switch(*(undefined *)(iVar2 + 0x102)) {
                    case 1:
                    case 2:
                        goto code_r0x0001801fee06;
                    default:
                        goto code_r0x0001801fef31;
                    }
                }
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
                uVar6 = 0x1804b90e8;
                *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x22c;
                goto code_r0x0001801feef3;
            }
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
            uVar6 = 0x1804b90c8;
            *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x222;
code_r0x0001801feeee:
            iVar8 = 1;
        }
code_r0x0001801feef3:
        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b8fe8;
        *(undefined8 *)((int64_t)&var_8h + iVar5) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fef0f;
        func_0x0001801e4990(in_RDX, iVar8, uVar7, uVar6);
        uVar7 = 0;
    }
    return uVar7;
code_r0x0001801fee06:
    uVar4 = *(uint32_t *)((int64_t)&arg_58h + iVar5);
    if ((uVar4 & 2) != 0) {
    // switch table (7 cases) at 0x1801fef7c
        switch(*(undefined *)(iVar2 + 0x102)) {
        default:
code_r0x0001801fee31:
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fee4a;
            func_0x0001801e7b80(in_RDX + 0x300, iVar2, 
                                *(int64_t *)((int64_t)&arg_48h + iVar5) + *(int64_t *)((int64_t)&arg_40h + iVar5));
            break;
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fee2d;
            iVar3 = func_0x0001801e5980(iVar2 + 0xa0, 0);
            if (iVar3 == 0) goto code_r0x0001801fee31;
        }
        uVar4 = *(uint32_t *)((int64_t)&arg_58h + iVar5);
    }
    if ((*(uint32_t *)(iVar2 + 0x100) & 0x4000000) == 0) {
        if ((*(int64_t *)((int64_t)&arg_48h + iVar5) != 0) || ((uVar4 & 2) != 0)) {
            uVar6 = *(undefined8 *)(iVar2 + 0x78);
            *(uint32_t *)((int64_t)&var_10h + iVar5) = uVar4 >> 1 & 1;
            *(undefined8 *)((int64_t)&var_8h + iVar5) = *(undefined8 *)((int64_t)&arg_48h + iVar5);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fee92;
            iVar3 = func_0x0001801e6d70(uVar6, in_R8, *(undefined8 *)((int64_t)&arg_40h + iVar5), 
                                        *(undefined8 *)((int64_t)&arg_50h + iVar5));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
                uVar6 = 0x1804b91a0;
                *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x26a;
                goto code_r0x0001801feeee;
            }
        }
        if (*(char *)(iVar2 + 0x102) == '\x02') {
            uVar6 = *(undefined8 *)(iVar2 + 0x78);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801feecf;
            iVar3 = func_0x0001801e6a70(uVar6, (int64_t)&arg_30h + iVar5, (int64_t)&arg_28h + iVar5);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
                uVar6 = 0x1804b92f8;
                *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x279;
                goto code_r0x0001801feeee;
            }
        }
        if (*(int32_t *)((int64_t)&arg_28h + iVar5) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fef29;
            func_0x0001801e7bf0(in_RDX + 0x300, iVar2);
        }
        *puVar1 = *(undefined8 *)((int64_t)&arg_48h + iVar5);
    }
    goto code_r0x0001801fef31;
}

// ============================================================
// Function: FUN_1801fef4e
// Address: 0x1801fef4e
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.1801fec60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h,
             int64_t arg_b0h, int64_t arg_128h)
{
    undefined8 *puVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t in_RDX;
    int64_t iVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801fec75;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar1 = *(undefined8 **)((int64_t)&arg_b0h + iVar5);
    *(undefined4 *)((int64_t)&arg_28h + iVar5) = 0;
    *puVar1 = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fec9d;
    iVar3 = func_0x0001801fd7f0();
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
        *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x203;
        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b8fe8;
        *(undefined8 *)((int64_t)&var_8h + iVar5) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fece2;
        func_0x0001801e4990(in_RDX, 7, *(undefined8 *)((int64_t)&arg_a8h + iVar5), 0x1804b9008);
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_98h + iVar5) = unaff_RSI;
    uVar7 = *(undefined8 *)((int64_t)&arg_a8h + iVar5);
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fed0e;
    uVar6 = func_0x0001801fefa0(in_RDX, *(undefined8 *)((int64_t)&arg_38h + iVar5), uVar7, (int64_t)&arg_b0h + iVar5);
    if ((int32_t)uVar6 == 0) {
        return uVar6;
    }
    *(undefined8 *)((int64_t)&arg_88h + iVar5) = unaff_RBX;
    iVar2 = *(int64_t *)((int64_t)&arg_b0h + iVar5);
    *(undefined8 *)((int64_t)&arg_90h + iVar5) = unaff_RBP;
    if (iVar2 == 0) {
code_r0x0001801fef31:
        uVar7 = 1;
    } else {
        if (*(char *)(iVar2 + 0x102) == '\0') {
            iVar8 = 5;
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
            uVar6 = 0x1804b92d8;
            *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x217;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fed87;
            iVar3 = func_0x0001801e5ad0(iVar2 + 0xa0, 
                                        *(int64_t *)((int64_t)&arg_48h + iVar5) +
                                        *(int64_t *)((int64_t)&arg_40h + iVar5), 
                                        *(uint32_t *)((int64_t)&arg_58h + iVar5) >> 1 & 1);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fedb9;
                iVar3 = func_0x0001801e5970(iVar2 + 0xa0, 0);
                iVar8 = (int64_t)iVar3;
                if (iVar3 == 0) {
    // switch table (6 cases) at 0x1801fef64
                    switch(*(undefined *)(iVar2 + 0x102)) {
                    case 1:
                    case 2:
                        goto code_r0x0001801fee06;
                    default:
                        goto code_r0x0001801fef31;
                    }
                }
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
                uVar6 = 0x1804b90e8;
                *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x22c;
                goto code_r0x0001801feef3;
            }
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
            uVar6 = 0x1804b90c8;
            *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x222;
code_r0x0001801feeee:
            iVar8 = 1;
        }
code_r0x0001801feef3:
        *(undefined8 *)((int64_t)&var_10h + iVar5) = 0x1804b8fe8;
        *(undefined8 *)((int64_t)&var_8h + iVar5) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fef0f;
        func_0x0001801e4990(in_RDX, iVar8, uVar7, uVar6);
        uVar7 = 0;
    }
    return uVar7;
code_r0x0001801fee06:
    uVar4 = *(uint32_t *)((int64_t)&arg_58h + iVar5);
    if ((uVar4 & 2) != 0) {
    // switch table (7 cases) at 0x1801fef7c
        switch(*(undefined *)(iVar2 + 0x102)) {
        default:
code_r0x0001801fee31:
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fee4a;
            func_0x0001801e7b80(in_RDX + 0x300, iVar2, 
                                *(int64_t *)((int64_t)&arg_48h + iVar5) + *(int64_t *)((int64_t)&arg_40h + iVar5));
            break;
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fee2d;
            iVar3 = func_0x0001801e5980(iVar2 + 0xa0, 0);
            if (iVar3 == 0) goto code_r0x0001801fee31;
        }
        uVar4 = *(uint32_t *)((int64_t)&arg_58h + iVar5);
    }
    if ((*(uint32_t *)(iVar2 + 0x100) & 0x4000000) == 0) {
        if ((*(int64_t *)((int64_t)&arg_48h + iVar5) != 0) || ((uVar4 & 2) != 0)) {
            uVar6 = *(undefined8 *)(iVar2 + 0x78);
            *(uint32_t *)((int64_t)&var_10h + iVar5) = uVar4 >> 1 & 1;
            *(undefined8 *)((int64_t)&var_8h + iVar5) = *(undefined8 *)((int64_t)&arg_48h + iVar5);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fee92;
            iVar3 = func_0x0001801e6d70(uVar6, in_R8, *(undefined8 *)((int64_t)&arg_40h + iVar5), 
                                        *(undefined8 *)((int64_t)&arg_50h + iVar5));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
                uVar6 = 0x1804b91a0;
                *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x26a;
                goto code_r0x0001801feeee;
            }
        }
        if (*(char *)(iVar2 + 0x102) == '\x02') {
            uVar6 = *(undefined8 *)(iVar2 + 0x78);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801feecf;
            iVar3 = func_0x0001801e6a70(uVar6, (int64_t)&arg_30h + iVar5, (int64_t)&arg_28h + iVar5);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x1804b92c0;
                uVar6 = 0x1804b92f8;
                *(undefined4 *)((int64_t)&var_18h + iVar5) = 0x279;
                goto code_r0x0001801feeee;
            }
        }
        if (*(int32_t *)((int64_t)&arg_28h + iVar5) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801fef29;
            func_0x0001801e7bf0(in_RDX + 0x300, iVar2);
        }
        *puVar1 = *(undefined8 *)((int64_t)&arg_48h + iVar5);
    }
    goto code_r0x0001801fef31;
}

// ============================================================
// Function: FUN_1801fefa0
// Address: 0x1801fefa0
// Size: 83 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_5c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_558h because it doesn't fit into ProtoModel

undefined8 fcn.1801fefa0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined4 uVar1;
    uint64_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    uint64_t *puVar7;
    int64_t *in_R9;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_30;
    
    uStack_30 = 0x1801fefb2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801fefcd;
    iVar5 = fcn.1801e7870(*(int64_t *)(&stack0x00000028 + iVar4));
    if (iVar5 != 0) {
        *in_R9 = iVar5;
        return 1;
    }
    uVar1 = *(undefined4 *)(in_RCX + 0x5d0);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_R13;
    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_R14;
    uVar8 = in_RDX >> 2;
    if ((((uint8_t)~(uint8_t)((uint32_t)uVar1 >> 0x18) >> 1 ^ (uint8_t)in_RDX) & 1) == 0) {
        iVar5 = 0x558;
        if ((in_RDX & 2) == 0) {
            iVar5 = 0x550;
        }
        puVar7 = (uint64_t *)(iVar5 + in_RCX);
        iVar5 = 0x2a0;
        if ((in_RDX & 2) == 0) {
            iVar5 = 0x240;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801ff057;
        iVar3 = fcn.1801e5ad0(iVar5 + in_RCX, uVar8 + 1, 0);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = 0x1804b91f8;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x1b1;
code_r0x0001801ff148:
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -0x18) = 0x1804b8fe8;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801ff16b;
            fcn.1801e4990(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000028 + iVar4), 
                          *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000078 + iVar4), 
                          *(int64_t *)(&stack0x00000080 + iVar4), *(int64_t *)(&stack0x00000088 + iVar4), 
                          *(int64_t *)(&stack0x00000098 + iVar4), *(int64_t *)(&stack0x000000a0 + iVar4), 
                          *(int64_t *)(&stack0x000000a8 + iVar4), *(int64_t *)(&stack0x000000b0 + iVar4), 
                          *(int64_t *)(&stack0x00000158 + iVar4));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801ff085;
        iVar3 = fcn.1801e5970(iVar5 + in_RCX, 0);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = 0x1804b91f8;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x1b8;
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -0x18) = 0x1804b8fe8;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801ff0c7;
            fcn.1801e4990(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000028 + iVar4), 
                          *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000078 + iVar4), 
                          *(int64_t *)(&stack0x00000080 + iVar4), *(int64_t *)(&stack0x00000088 + iVar4), 
                          *(int64_t *)(&stack0x00000098 + iVar4), *(int64_t *)(&stack0x000000a0 + iVar4), 
                          *(int64_t *)(&stack0x000000a8 + iVar4), *(int64_t *)(&stack0x000000b0 + iVar4), 
                          *(int64_t *)(&stack0x00000158 + iVar4));
            return 0;
        }
        iVar6 = 0;
        uVar2 = *puVar7;
        while (uVar2 <= uVar8) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801ff0f3;
            iVar6 = fcn.1801e3d00(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), 
                                  *(int64_t *)((int64_t)&var_8h + iVar4));
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = 0x1804b91f8;
                *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x1ca;
                goto code_r0x0001801ff148;
            }
            *puVar7 = *puVar7 + 1;
            uVar2 = *puVar7;
        }
    } else {
        iVar5 = 0x548;
        if ((in_RDX & 2) == 0) {
            iVar5 = 0x540;
        }
        iVar6 = 0;
        if (*(uint64_t *)(iVar5 + in_RCX) <= uVar8) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = 0x1804b91f8;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x1e1;
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -0x18) = 0x1804b8fe8;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801ff1c7;
            fcn.1801e4990(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000028 + iVar4), 
                          *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000078 + iVar4), 
                          *(int64_t *)(&stack0x00000080 + iVar4), *(int64_t *)(&stack0x00000088 + iVar4), 
                          *(int64_t *)(&stack0x00000098 + iVar4), *(int64_t *)(&stack0x000000a0 + iVar4), 
                          *(int64_t *)(&stack0x000000a8 + iVar4), *(int64_t *)(&stack0x000000b0 + iVar4), 
                          *(int64_t *)(&stack0x00000158 + iVar4));
            return 0;
        }
    }
    *in_R9 = iVar6;
    return 1;
}

// ============================================================
// Function: FUN_1801feff3
// Address: 0x1801feff3
// Size: 314 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_5c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_558h because it doesn't fit into ProtoModel

undefined8 fcn.1801fefa0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined4 uVar1;
    uint64_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    uint64_t *puVar7;
    int64_t *in_R9;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_30;
    
    uStack_30 = 0x1801fefb2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801fefcd;
    iVar5 = fcn.1801e7870(*(int64_t *)(&stack0x00000028 + iVar4));
    if (iVar5 != 0) {
        *in_R9 = iVar5;
        return 1;
    }
    uVar1 = *(undefined4 *)(in_RCX + 0x5d0);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_R13;
    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_R14;
    uVar8 = in_RDX >> 2;
    if ((((uint8_t)~(uint8_t)((uint32_t)uVar1 >> 0x18) >> 1 ^ (uint8_t)in_RDX) & 1) == 0) {
        iVar5 = 0x558;
        if ((in_RDX & 2) == 0) {
            iVar5 = 0x550;
        }
        puVar7 = (uint64_t *)(iVar5 + in_RCX);
        iVar5 = 0x2a0;
        if ((in_RDX & 2) == 0) {
            iVar5 = 0x240;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801ff057;
        iVar3 = fcn.1801e5ad0(iVar5 + in_RCX, uVar8 + 1, 0);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = 0x1804b91f8;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x1b1;
code_r0x0001801ff148:
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -0x18) = 0x1804b8fe8;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801ff16b;
            fcn.1801e4990(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000028 + iVar4), 
                          *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000078 + iVar4), 
                          *(int64_t *)(&stack0x00000080 + iVar4), *(int64_t *)(&stack0x00000088 + iVar4), 
                          *(int64_t *)(&stack0x00000098 + iVar4), *(int64_t *)(&stack0x000000a0 + iVar4), 
                          *(int64_t *)(&stack0x000000a8 + iVar4), *(int64_t *)(&stack0x000000b0 + iVar4), 
                          *(int64_t *)(&stack0x00000158 + iVar4));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801ff085;
        iVar3 = fcn.1801e5970(iVar5 + in_RCX, 0);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = 0x1804b91f8;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x1b8;
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -0x18) = 0x1804b8fe8;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801ff0c7;
            fcn.1801e4990(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000028 + iVar4), 
                          *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000078 + iVar4), 
                          *(int64_t *)(&stack0x00000080 + iVar4), *(int64_t *)(&stack0x00000088 + iVar4), 
                          *(int64_t *)(&stack0x00000098 + iVar4), *(int64_t *)(&stack0x000000a0 + iVar4), 
                          *(int64_t *)(&stack0x000000a8 + iVar4), *(int64_t *)(&stack0x000000b0 + iVar4), 
                          *(int64_t *)(&stack0x00000158 + iVar4));
            return 0;
        }
        iVar6 = 0;
        uVar2 = *puVar7;
        while (uVar2 <= uVar8) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801ff0f3;
            iVar6 = fcn.1801e3d00(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), 
                                  *(int64_t *)((int64_t)&var_8h + iVar4));
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = 0x1804b91f8;
                *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x1ca;
                goto code_r0x0001801ff148;
            }
            *puVar7 = *puVar7 + 1;
            uVar2 = *puVar7;
        }
    } else {
        iVar5 = 0x548;
        if ((in_RDX & 2) == 0) {
            iVar5 = 0x540;
        }
        iVar6 = 0;
        if (*(uint64_t *)(iVar5 + in_RCX) <= uVar8) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = 0x1804b91f8;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x1e1;
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -0x18) = 0x1804b8fe8;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801ff1c7;
            fcn.1801e4990(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000028 + iVar4), 
                          *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000078 + iVar4), 
                          *(int64_t *)(&stack0x00000080 + iVar4), *(int64_t *)(&stack0x00000088 + iVar4), 
                          *(int64_t *)(&stack0x00000098 + iVar4), *(int64_t *)(&stack0x000000a0 + iVar4), 
                          *(int64_t *)(&stack0x000000a8 + iVar4), *(int64_t *)(&stack0x000000b0 + iVar4), 
                          *(int64_t *)(&stack0x00000158 + iVar4));
            return 0;
        }
    }
    *in_R9 = iVar6;
    return 1;
}

// ============================================================
// Function: FUN_1801ff12d
// Address: 0x1801ff12d
// Size: 161 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_5c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_558h because it doesn't fit into ProtoModel

undefined8 fcn.1801fefa0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined4 uVar1;
    uint64_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    uint64_t *puVar7;
    int64_t *in_R9;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_30;
    
    uStack_30 = 0x1801fefb2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801fefcd;
    iVar5 = fcn.1801e7870(*(int64_t *)(&stack0x00000028 + iVar4));
    if (iVar5 != 0) {
        *in_R9 = iVar5;
        return 1;
    }
    uVar1 = *(undefined4 *)(in_RCX + 0x5d0);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_R13;
    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_R14;
    uVar8 = in_RDX >> 2;
    if ((((uint8_t)~(uint8_t)((uint32_t)uVar1 >> 0x18) >> 1 ^ (uint8_t)in_RDX) & 1) == 0) {
        iVar5 = 0x558;
        if ((in_RDX & 2) == 0) {
            iVar5 = 0x550;
        }
        puVar7 = (uint64_t *)(iVar5 + in_RCX);
        iVar5 = 0x2a0;
        if ((in_RDX & 2) == 0) {
            iVar5 = 0x240;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801ff057;
        iVar3 = fcn.1801e5ad0(iVar5 + in_RCX, uVar8 + 1, 0);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = 0x1804b91f8;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x1b1;
code_r0x0001801ff148:
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -0x18) = 0x1804b8fe8;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801ff16b;
            fcn.1801e4990(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000028 + iVar4), 
                          *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000078 + iVar4), 
                          *(int64_t *)(&stack0x00000080 + iVar4), *(int64_t *)(&stack0x00000088 + iVar4), 
                          *(int64_t *)(&stack0x00000098 + iVar4), *(int64_t *)(&stack0x000000a0 + iVar4), 
                          *(int64_t *)(&stack0x000000a8 + iVar4), *(int64_t *)(&stack0x000000b0 + iVar4), 
                          *(int64_t *)(&stack0x00000158 + iVar4));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801ff085;
        iVar3 = fcn.1801e5970(iVar5 + in_RCX, 0);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = 0x1804b91f8;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x1b8;
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -0x18) = 0x1804b8fe8;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801ff0c7;
            fcn.1801e4990(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000028 + iVar4), 
                          *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000078 + iVar4), 
                          *(int64_t *)(&stack0x00000080 + iVar4), *(int64_t *)(&stack0x00000088 + iVar4), 
                          *(int64_t *)(&stack0x00000098 + iVar4), *(int64_t *)(&stack0x000000a0 + iVar4), 
                          *(int64_t *)(&stack0x000000a8 + iVar4), *(int64_t *)(&stack0x000000b0 + iVar4), 
                          *(int64_t *)(&stack0x00000158 + iVar4));
            return 0;
        }
        iVar6 = 0;
        uVar2 = *puVar7;
        while (uVar2 <= uVar8) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801ff0f3;
            iVar6 = fcn.1801e3d00(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), 
                                  *(int64_t *)((int64_t)&var_8h + iVar4));
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = 0x1804b91f8;
                *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x1ca;
                goto code_r0x0001801ff148;
            }
            *puVar7 = *puVar7 + 1;
            uVar2 = *puVar7;
        }
    } else {
        iVar5 = 0x548;
        if ((in_RDX & 2) == 0) {
            iVar5 = 0x540;
        }
        iVar6 = 0;
        if (*(uint64_t *)(iVar5 + in_RCX) <= uVar8) {
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -8) = 0x1804b91f8;
            *(undefined4 *)((int64_t)&var_8h + iVar4) = 0x1e1;
            *(undefined8 *)((int64_t)aiStackX_18 + iVar4 + -0x18) = 0x1804b8fe8;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801ff1c7;
            fcn.1801e4990(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), *(int64_t *)(&stack0x00000028 + iVar4), 
                          *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000078 + iVar4), 
                          *(int64_t *)(&stack0x00000080 + iVar4), *(int64_t *)(&stack0x00000088 + iVar4), 
                          *(int64_t *)(&stack0x00000098 + iVar4), *(int64_t *)(&stack0x000000a0 + iVar4), 
                          *(int64_t *)(&stack0x000000a8 + iVar4), *(int64_t *)(&stack0x000000b0 + iVar4), 
                          *(int64_t *)(&stack0x00000158 + iVar4));
            return 0;
        }
    }
    *in_R9 = iVar6;
    return 1;
}

// ============================================================
// Function: FUN_1801ff1d0
// Address: 0x1801ff1d0
// Size: 214 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h

void fcn.1801ff1d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_118h, int64_t arg_120h, int64_t arg_128h, int64_t arg_130h)
{
    undefined uVar1;
    uint8_t *puVar2;
    code *pcVar3;
    uint8_t **ppuVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint8_t *puVar8;
    uint64_t uVar9;
    int64_t iVar10;
    undefined4 uVar11;
    undefined8 *in_RCX;
    int64_t iVar12;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    uint8_t **in_R8;
    undefined8 uVar13;
    int32_t in_R9D;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_f8h;
    int32_t var_f0h;
    int64_t var_ech;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801ff1e5;
    var_ech._0_4_ = in_R9D;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7);
    var_f8h = arg_30h;
    puVar2 = *in_R8;
    *(int64_t **)((int64_t)&arg_38h + iVar7) = in_RDX;
    *(uint32_t *)((int64_t)&arg_30h + iVar7) = (uint32_t)*puVar2;
    var_c8h = 1;
    if ((int32_t)var_ech == 0) {
        *(undefined4 *)((int64_t)&arg_58h + iVar7) = 0;
    } else if (((int32_t)var_ech == 1) || ((int32_t)var_ech != 2)) {
        *(undefined4 *)((int64_t)&arg_58h + iVar7) = 2;
    } else {
        *(undefined4 *)((int64_t)&arg_58h + iVar7) = 1;
    }
    *(undefined8 *)((int64_t)&arg_128h + iVar7) = unaff_R13;
    *(undefined8 *)((int64_t)&arg_120h + iVar7) = unaff_R14;
    if (in_RDX[1] == 0) {
        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x428;
        *(undefined8 *)((int64_t)&var_8h + iVar7) = 0x1804b8fe8;
        *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff29f;
        fcn.1801e4990(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                      *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7), 
                      *(int64_t *)((int64_t)&arg_40h + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7), 
                      *(int64_t *)(&stack0x00000080 + iVar7), *(int64_t *)(&stack0x00000088 + iVar7), 
                      *(int64_t *)(&stack0x00000090 + iVar7), *(int64_t *)(&stack0x000000a0 + iVar7), 
                      *(int64_t *)(&stack0x000000a8 + iVar7), *(int64_t *)(&stack0x000000b0 + iVar7), 
                      *(int64_t *)(&stack0x000000b8 + iVar7), *(int64_t *)(&stack0x00000160 + iVar7));
code_r0x0001802003f7:
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180200413;
        func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7));
        return;
    }
    *(undefined8 *)((int64_t)&arg_130h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_118h + iVar7) = unaff_R15;
    unique0x1000495e = in_R8;
code_r0x0001801ff2c2:
    ppuVar4 = stack0xffffffffffffff18;
    var_d0h = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
    if (in_RCX[0x7c] != 0) {
        var_d0h = *in_RDX;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff2fb;
    iVar6 = fcn.1801feb70(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                          *(int64_t *)((int64_t)&arg_30h + iVar7));
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x439;
        goto code_r0x0001802003d6;
    }
    if (var_f0h == 0) {
        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x441;
        goto code_r0x0001802003d6;
    }
    if ((((var_e0h != 0) && (var_e0h != 2)) && (var_e0h != 3)) && ((var_e0h != 0x1c && (var_e0h != 0x1d)))) {
        *(uint32_t *)(var_f8h + 0x10) = *(uint32_t *)(var_f8h + 0x10) | 4;
    }
    // switch table (31 cases) at 0x180200420
    switch(var_e0h) {
    case 0:
        in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff392;
        func_0x0001801fda60(in_RDX);
        goto code_r0x0001801ff4b7;
    case 1:
        in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff369;
        iVar6 = func_0x0001801fd680(in_RDX);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b8fd0;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x35;
            break;
        }
        uVar13 = in_RCX[0x11];
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff380;
        func_0x000180207ed0(uVar13, (int32_t)var_ech);
        goto code_r0x0001801ff4b7;
    case 2:
    case 3:
        if (*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x46a;
        } else {
            uVar1 = *(undefined *)(in_RCX + 0x9f);
            *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff3bd;
            iVar6 = func_0x0001801fea00(*(undefined8 *)((int64_t)&arg_38h + iVar7), (int64_t)&arg_48h + iVar7);
            if ((iVar6 == 0) || (uVar9 = *(uint64_t *)((int64_t)&arg_48h + iVar7), 0xfffffffffffffff < uVar9)) {
code_r0x0001801ffd9f:
                uVar11 = 0x89;
            } else {
                if ((uint64_t)in_RCX[0xbd] < uVar9) {
                    uVar13 = in_RCX[0xbc];
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff402;
                    iVar10 = func_0x0001802249c0(uVar13, uVar9 << 4, 0x1804b8fe8, 0x4f);
                    if (iVar10 == 0) goto code_r0x0001801ffd9f;
                    uVar9 = *(uint64_t *)((int64_t)&arg_48h + iVar7);
                    in_RCX[0xbd] = uVar9;
                    in_RCX[0xbc] = iVar10;
                }
                var_a0h = in_RCX[0xbc];
                var_98h = uVar9;
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff440;
                iVar6 = func_0x0001801fcd10(*(undefined8 *)((int64_t)&arg_38h + iVar7), uVar1, &var_a0h, 0);
                if (iVar6 == 0) goto code_r0x0001801ffd9f;
                if (**stack0xffffffffffffff18 != 5) {
code_r0x0001801ff487:
                    uVar13 = in_RCX[0x79];
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff4a3;
                    iVar6 = func_0x000180202e50(uVar13, &var_a0h, *(undefined4 *)((int64_t)&arg_58h + iVar7), arg_28h);
                    if (iVar6 != 0) {
                        *(int16_t *)((int64_t)in_RCX + 0x4fa) = *(int16_t *)((int64_t)in_RCX + 0x4fa) + 1;
                        goto code_r0x0001801ff4b2;
                    }
                    goto code_r0x0001801ffd9f;
                }
                puVar2 = stack0xffffffffffffff18[7];
                uVar13 = in_RCX[0x7b];
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff464;
                puVar8 = (uint8_t *)func_0x000180205200(uVar13);
                if (((puVar8 <= puVar2) && ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x10) == 0)) ||
                   (*(uint64_t *)(var_a0h + 8) < (uint64_t)in_RCX[0xb8])) goto code_r0x0001801ff487;
                uVar11 = 0x7a;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9018;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = uVar11;
        }
        break;
    case 4:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff51a;
            iVar6 = func_0x0001801fd6a0(*(undefined8 *)((int64_t)&arg_38h + iVar7), &var_a0h);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9080;
                *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x99;
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff536;
                iVar6 = fcn.1801fefa0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar7));
                if (iVar6 == 0) goto code_r0x0001802003f7;
                iVar10 = *(int64_t *)((int64_t)&arg_48h + iVar7);
                if (iVar10 == 0) goto code_r0x0001801ff4b2;
                if (*(char *)(iVar10 + 0x102) == '\0') {
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9080;
                    *(undefined4 *)((int64_t)&var_10h + iVar7) = 0xaa;
                } else {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff571;
                    iVar6 = fcn.1801e5ad0(iVar10 + 0xa0, var_90h, 1);
                    if (iVar6 == 0) {
                        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9080;
                        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0xbd;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff588;
                        iVar6 = fcn.1801e5970(iVar10 + 0xa0, 0);
                        if (iVar6 == 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff5aa;
                            func_0x0001801e7a50(in_RCX + 0x60, iVar10, var_98h, var_90h);
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff5b9;
                            fcn.1801e7fb0(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                          *(int64_t *)((int64_t)&var_10h + iVar7), 
                                          *(int64_t *)((int64_t)&var_18h + iVar7), 
                                          *(int64_t *)((int64_t)&var_20h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar7), 
                                          *(int64_t *)(&stack0x00000060 + iVar7), *(int64_t *)(&stack0x00000068 + iVar7)
                                          , *(int64_t *)(&stack0x00000070 + iVar7), 
                                          *(int64_t *)(&stack0x00000078 + iVar7));
                            goto code_r0x0001801ff4b2;
                        }
                        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9080;
                        *(undefined4 *)((int64_t)&var_10h + iVar7) = 199;
                    }
                }
            }
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x47a;
        }
        break;
    case 5:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff5e6;
            iVar6 = func_0x0001801fd780(in_RDX, &var_68h);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff605;
                iVar6 = fcn.1801fefa0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar7));
                if (iVar6 != 0) {
                    iVar10 = *(int64_t *)((int64_t)&arg_48h + iVar7);
                    if (iVar10 != 0) {
                        if (*(char *)(iVar10 + 0x101) == '\0') {
                            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9100;
                            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0xf5;
                            break;
                        }
                        *(uint32_t *)(iVar10 + 0x100) = *(uint32_t *)(iVar10 + 0x100) | 0x8000000;
                        *(int64_t *)(iVar10 + 0x50) = var_60h;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff64a;
                        fcn.1801e7da0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                    }
                    goto code_r0x0001801ff4b7;
                }
                goto code_r0x0001802003f7;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9100;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0xe4;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x488;
        }
        break;
    case 6:
        if (*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x494;
        } else {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff66d;
            iVar6 = func_0x0001801fd180(in_RDX, 0, &var_a0h);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9148;
                *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x115;
            } else {
                if (var_98h == 0) goto code_r0x0001801ff4b7;
                uVar9 = (uint64_t)(*(uint32_t *)(var_f8h + 0x10) & 3);
                iVar10 = in_RCX[uVar9 + 0x82];
                if (iVar10 == 0) goto code_r0x0001802003f7;
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff6bb;
                iVar6 = fcn.1801e5ad0(in_RCX + (uVar9 + 3) * 0xc, var_98h + var_a0h, 0);
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9148;
                    *(undefined4 *)((int64_t)&var_10h + iVar7) = 300;
                } else {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff6cd;
                    iVar6 = fcn.1801e5970(in_RCX + (uVar9 + 3) * 0xc, 0);
                    iVar5 = var_90h;
                    iVar12 = var_a0h;
                    if (iVar6 == 0) {
                        *(undefined4 *)((int64_t)&var_8h + iVar7) = 0;
                        *(int64_t *)(&stack0x00000000 + iVar7) = var_98h;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff6f6;
                        iVar6 = func_0x0001801e6d70(iVar10, ppuVar4, iVar12, iVar5);
                        if (iVar6 != 0) {
                            *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x10000000;
                            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
                            iVar10 = var_98h;
                            goto code_r0x0001801ff4bc;
                        }
                        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9148;
                        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x13c;
                    } else {
                        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9148;
                        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x133;
                    }
                }
            }
        }
        break;
    case 7:
        if (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5) {
            if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) == 0) {
                in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff746;
                iVar6 = func_0x0001801fd520(in_RDX, &var_c0h, &var_d8h);
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b91c0;
                    *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x150;
                } else {
                    if (var_d8h != 0) {
                        uVar13 = *in_RCX;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff760;
                        uVar13 = func_0x000180192480(uVar13);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff774;
                        iVar6 = func_0x0001801bfd70(uVar13, in_RCX + 0xd, var_c0h, var_d8h);
                        if (iVar6 != 0) goto code_r0x0001801ff4b7;
                        goto code_r0x0001802003f7;
                    }
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b91c0;
                    *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x15d;
                }
            } else {
                *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
                *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4ac;
            }
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4a0;
        }
        break;
    case 8:
    case 9:
    case 10:
    case 0xb:
    case 0xc:
    case 0xd:
    case 0xe:
    case 0xf:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) != 2) && (*(int32_t *)((int64_t)&arg_30h + iVar7) != 5)) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4c2;
            break;
        }
        *(int64_t *)((int64_t)&var_8h + iVar7) = (int64_t)&arg_48h + iVar7;
        *(int64_t *)(&stack0x00000000 + iVar7) = var_e0h;
        in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff7b9;
        iVar6 = fcn.1801fec60(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                              *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                              *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)(&stack0x00000060 + iVar7), 
                              *(int64_t *)(&stack0x00000068 + iVar7), *(int64_t *)(&stack0x00000070 + iVar7), 
                              *(int64_t *)(&stack0x00000078 + iVar7), *(int64_t *)(&stack0x00000080 + iVar7), 
                              *(int64_t *)(&stack0x00000088 + iVar7), *(int64_t *)(&stack0x00000100 + iVar7));
        if (iVar6 != 0) {
            iVar10 = *(int64_t *)((int64_t)&arg_48h + iVar7);
            goto code_r0x0001801ff4bc;
        }
        goto code_r0x0001802003f7;
    case 0x10:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff7f4;
            iVar6 = func_0x0001801fd2c0(in_RDX, (int64_t)&arg_48h + iVar7);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff80d;
                func_0x0001801e5b80(in_RCX + 0x14, *(undefined8 *)((int64_t)&arg_48h + iVar7));
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff823;
                func_0x0001801e82d0(in_RCX + 0x60, 0x1801e35f0, in_RCX);
                goto code_r0x0001801ff4b7;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9320;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x2a9;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4d1;
        }
        break;
    case 0x11:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
            *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff85b;
            iVar6 = func_0x0001801fd320(in_RDX, (int64_t)&arg_48h + iVar7, (int64_t)&arg_50h + iVar7);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff87a;
                iVar6 = fcn.1801fefa0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar7));
                if (iVar6 != 0) {
                    if (var_b8h != 0) {
                        if (*(char *)(var_b8h + 0x101) == '\0') {
                            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9340;
                            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x2d0;
                            break;
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff8ad;
                        func_0x0001801e5b80(var_b8h + 0x80, *(undefined8 *)((int64_t)&arg_50h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff8bc;
                        fcn.1801e7fb0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar7), *(int64_t *)(&stack0x00000060 + iVar7), 
                                      *(int64_t *)(&stack0x00000068 + iVar7), *(int64_t *)(&stack0x00000070 + iVar7), 
                                      *(int64_t *)(&stack0x00000078 + iVar7));
                    }
                    goto code_r0x0001801ff4b7;
                }
                goto code_r0x0001802003f7;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9340;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x2bf;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4de;
        }
        break;
    case 0x12:
    case 0x13:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) != 2) && (*(int32_t *)((int64_t)&arg_30h + iVar7) != 5)) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4ed;
            break;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff8e7;
        iVar6 = func_0x0001801fd3a0(*(undefined8 *)((int64_t)&arg_38h + iVar7), (int64_t)&arg_50h + iVar7);
        if (iVar6 == 0) {
            uVar11 = 0x2e4;
code_r0x000180200148:
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9388;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = uVar11;
            break;
        }
        uVar9 = *(uint64_t *)((int64_t)&arg_50h + iVar7);
        if (0x1000000000000000 < uVar9) {
            uVar11 = 0x2ec;
            goto code_r0x000180200148;
        }
        if (var_e0h == 0x12) {
            if ((uint64_t)in_RCX[0xa1] < uVar9) {
                in_RCX[0xa1] = uVar9;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff96b;
            func_0x0001801e82d0(in_RCX + 0x60, 0x180200640, in_RCX);
        } else {
            if (var_e0h != 0x13) {
                uVar11 = 0x303;
                goto code_r0x000180200148;
            }
            if ((uint64_t)in_RCX[0xa2] < uVar9) {
                in_RCX[0xa2] = uVar9;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff940;
            func_0x0001801e82d0(in_RCX + 0x60, 0x180200680, in_RCX);
        }
code_r0x0001801ff4b2:
        in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
        goto code_r0x0001801ff4b7;
    case 0x14:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff999;
            iVar6 = func_0x0001801fd240(in_RDX, (int64_t)&arg_50h + iVar7);
            if (iVar6 != 0) goto code_r0x0001801ff4b7;
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b93c8;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x314;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4fc;
        }
        break;
    case 0x15:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
            *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff9ff;
            iVar6 = func_0x0001801fd950(in_RDX, (int64_t)&arg_50h + iVar7, (int64_t)&arg_48h + iVar7);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b93e8;
                *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x329;
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffa1e;
                iVar6 = fcn.1801fefa0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar7));
                if (iVar6 == 0) goto code_r0x0001802003f7;
                if ((var_b0h == 0) || (*(char *)(var_b0h + 0x102) != '\0')) goto code_r0x0001801ff4b7;
                *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b93e8;
                *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x343;
            }
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x509;
        }
        break;
    case 0x16:
    case 0x17:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffa91;
            iVar6 = func_0x0001801fd9d0(*(undefined8 *)((int64_t)&arg_38h + iVar7), (int64_t)&arg_50h + iVar7);
            if (iVar6 == 0) {
                uVar11 = 0x356;
            } else {
                if (*(uint64_t *)((int64_t)&arg_50h + iVar7) < 0x1000000000000001) goto code_r0x0001801ff4b2;
                uVar11 = 0x364;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9440;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = uVar11;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x518;
        }
        break;
    case 0x18:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) != 2) && (*(int32_t *)((int64_t)&arg_30h + iVar7) != 5)) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x527;
            *(undefined8 *)((int64_t)&var_8h + iVar7) = 0x1804b8fe8;
            *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffaf9;
            fcn.1801e4990(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                          *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                          *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7), 
                          *(int64_t *)((int64_t)&arg_40h + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7), 
                          *(int64_t *)(&stack0x00000080 + iVar7), *(int64_t *)(&stack0x00000088 + iVar7), 
                          *(int64_t *)(&stack0x00000090 + iVar7), *(int64_t *)(&stack0x000000a0 + iVar7), 
                          *(int64_t *)(&stack0x000000a8 + iVar7), *(int64_t *)(&stack0x000000b0 + iVar7), 
                          *(int64_t *)(&stack0x000000b8 + iVar7), *(int64_t *)(&stack0x00000160 + iVar7));
        }
        in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffb0a;
        iVar6 = func_0x0001801fd430(in_RDX, &var_a0h);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9480;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x376;
            break;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffb1e;
        func_0x0001801e4240(in_RCX, &var_a0h);
code_r0x0001801ff4b7:
        iVar10 = *(int64_t *)((int64_t)&arg_40h + iVar7);
code_r0x0001801ff4bc:
        pcVar3 = (code *)in_RCX[0x7c];
        if (pcVar3 != (code *)0x0) {
            uVar13 = 0x202;
            iVar12 = *in_RDX - var_d0h;
            if (var_e0h == 0) {
                uVar13 = 0x204;
            } else if (((var_e0h & 0xfffffffffffffff8U) == 8) || (var_e0h == 6)) {
                uVar13 = 0x203;
                iVar12 = iVar12 - iVar10;
            }
            *(undefined8 *)((int64_t)&var_10h + iVar7) = in_RCX[0x7d];
            *(undefined8 *)((int64_t)&var_8h + iVar7) = in_RCX[0x7e];
            *(int64_t *)(&stack0x00000000 + iVar7) = iVar12;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffd4b;
            (*pcVar3)(0, 1, uVar13);
        }
        if (in_RDX[1] == 0) goto code_r0x0001802003f7;
        goto code_r0x0001801ff2c2;
    case 0x19:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffb46;
            iVar6 = func_0x0001801fd720(in_RDX, &var_a8h);
            if (iVar6 == 0) {
                uVar11 = 0x389;
            } else {
                if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) != 0) goto code_r0x0001801ff4b7;
                uVar11 = 0x39e;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b94a0;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = uVar11;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x533;
        }
        break;
    case 0x1a:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffb98;
            iVar6 = func_0x0001801fd5c0(in_RDX, (int64_t)&arg_50h + iVar7);
            if (iVar6 == 0) {
                var_c8h = 7;
                uVar11 = 0x3b7;
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffbb3;
                iVar10 = func_0x0001802248d0(9, 0x1804b8fe8, 0x3c3);
                if (iVar10 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffbd4;
                    iVar6 = func_0x000180244550(&var_a0h, iVar10, 9, 0);
                    if (iVar6 != 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffbea;
                        iVar6 = func_0x0001801fe400(&var_a0h, *(undefined8 *)((int64_t)&arg_50h + iVar7));
                        if (iVar6 == 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180200298;
                            func_0x000180243fb0(&var_a0h);
                        } else {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffbfb;
                            func_0x000180244200();
                            uVar13 = in_RCX[0x13];
                            *(undefined8 *)((int64_t)&var_20h + iVar7) = 0;
                            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1802004a0;
                            *(undefined8 *)((int64_t)&var_10h + iVar7) = 9;
                            *(int64_t *)((int64_t)&var_8h + iVar7) = iVar10;
                            *(undefined4 *)(&stack0x00000000 + iVar7) = 1;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffc3c;
                            iVar12 = func_0x000180201cf0(uVar13, 0, 2, 0x1b);
                            if (iVar12 != 0) goto code_r0x0001801ff4b7;
                        }
                    }
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1802002a9;
                func_0x000180224990(iVar10, 0x1804b8fe8, 0x3da);
                uVar11 = 0x3dd;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b94e0;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = uVar11;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x540;
        }
        break;
    case 0x1b:
        if (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffc6c;
            iVar6 = func_0x0001801fd620(in_RDX, (int64_t)&arg_50h + iVar7);
            if (iVar6 != 0) goto code_r0x0001801ff4b7;
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9500;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x3eb;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x54d;
        }
        break;
    case 0x1c:
code_r0x0001801ffcb1:
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffcbf;
        iVar6 = func_0x0001801fd080(*(undefined8 *)((int64_t)&arg_38h + iVar7), &var_a0h);
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffcd3;
            func_0x0001801e4870(in_RCX, &var_a0h);
            goto code_r0x0001801ff4b2;
        }
        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9520;
        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x3fd;
        break;
    case 0x1d:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5))
        goto code_r0x0001801ffcb1;
        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x55b;
        break;
    case 0x1e:
        if (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffcf0;
            iVar6 = func_0x0001801fd2a0(in_RDX);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffd00;
                func_0x0001801e3ed0(in_RCX);
                goto code_r0x0001801ff4b7;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9540;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x40e;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x56b;
        }
        break;
    default:
        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x577;
    }
code_r0x0001802003d6:
    *(undefined8 *)((int64_t)&var_8h + iVar7) = 0x1804b8fe8;
    *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1802003e5;
    fcn.1801e4990(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                  *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                  *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                  *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7), 
                  *(int64_t *)((int64_t)&arg_40h + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7), 
                  *(int64_t *)(&stack0x00000080 + iVar7), *(int64_t *)(&stack0x00000088 + iVar7), 
                  *(int64_t *)(&stack0x00000090 + iVar7), *(int64_t *)(&stack0x000000a0 + iVar7), 
                  *(int64_t *)(&stack0x000000a8 + iVar7), *(int64_t *)(&stack0x000000b0 + iVar7), 
                  *(int64_t *)(&stack0x000000b8 + iVar7), *(int64_t *)(&stack0x00000160 + iVar7));
    goto code_r0x0001802003f7;
}

// ============================================================
// Function: FUN_1801ff2a6
// Address: 0x1801ff2a6
// Size: 4433 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h

void fcn.1801ff1d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_118h, int64_t arg_120h, int64_t arg_128h, int64_t arg_130h)
{
    undefined uVar1;
    uint8_t *puVar2;
    code *pcVar3;
    uint8_t **ppuVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint8_t *puVar8;
    uint64_t uVar9;
    int64_t iVar10;
    undefined4 uVar11;
    undefined8 *in_RCX;
    int64_t iVar12;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    uint8_t **in_R8;
    undefined8 uVar13;
    int32_t in_R9D;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_f8h;
    int32_t var_f0h;
    int64_t var_ech;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801ff1e5;
    var_ech._0_4_ = in_R9D;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7);
    var_f8h = arg_30h;
    puVar2 = *in_R8;
    *(int64_t **)((int64_t)&arg_38h + iVar7) = in_RDX;
    *(uint32_t *)((int64_t)&arg_30h + iVar7) = (uint32_t)*puVar2;
    var_c8h = 1;
    if ((int32_t)var_ech == 0) {
        *(undefined4 *)((int64_t)&arg_58h + iVar7) = 0;
    } else if (((int32_t)var_ech == 1) || ((int32_t)var_ech != 2)) {
        *(undefined4 *)((int64_t)&arg_58h + iVar7) = 2;
    } else {
        *(undefined4 *)((int64_t)&arg_58h + iVar7) = 1;
    }
    *(undefined8 *)((int64_t)&arg_128h + iVar7) = unaff_R13;
    *(undefined8 *)((int64_t)&arg_120h + iVar7) = unaff_R14;
    if (in_RDX[1] == 0) {
        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x428;
        *(undefined8 *)((int64_t)&var_8h + iVar7) = 0x1804b8fe8;
        *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff29f;
        fcn.1801e4990(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                      *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7), 
                      *(int64_t *)((int64_t)&arg_40h + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7), 
                      *(int64_t *)(&stack0x00000080 + iVar7), *(int64_t *)(&stack0x00000088 + iVar7), 
                      *(int64_t *)(&stack0x00000090 + iVar7), *(int64_t *)(&stack0x000000a0 + iVar7), 
                      *(int64_t *)(&stack0x000000a8 + iVar7), *(int64_t *)(&stack0x000000b0 + iVar7), 
                      *(int64_t *)(&stack0x000000b8 + iVar7), *(int64_t *)(&stack0x00000160 + iVar7));
code_r0x0001802003f7:
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180200413;
        func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7));
        return;
    }
    *(undefined8 *)((int64_t)&arg_130h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_118h + iVar7) = unaff_R15;
    unique0x1000495e = in_R8;
code_r0x0001801ff2c2:
    ppuVar4 = stack0xffffffffffffff18;
    var_d0h = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
    if (in_RCX[0x7c] != 0) {
        var_d0h = *in_RDX;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff2fb;
    iVar6 = fcn.1801feb70(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                          *(int64_t *)((int64_t)&arg_30h + iVar7));
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x439;
        goto code_r0x0001802003d6;
    }
    if (var_f0h == 0) {
        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x441;
        goto code_r0x0001802003d6;
    }
    if ((((var_e0h != 0) && (var_e0h != 2)) && (var_e0h != 3)) && ((var_e0h != 0x1c && (var_e0h != 0x1d)))) {
        *(uint32_t *)(var_f8h + 0x10) = *(uint32_t *)(var_f8h + 0x10) | 4;
    }
    // switch table (31 cases) at 0x180200420
    switch(var_e0h) {
    case 0:
        in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff392;
        func_0x0001801fda60(in_RDX);
        goto code_r0x0001801ff4b7;
    case 1:
        in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff369;
        iVar6 = func_0x0001801fd680(in_RDX);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b8fd0;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x35;
            break;
        }
        uVar13 = in_RCX[0x11];
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff380;
        func_0x000180207ed0(uVar13, (int32_t)var_ech);
        goto code_r0x0001801ff4b7;
    case 2:
    case 3:
        if (*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x46a;
        } else {
            uVar1 = *(undefined *)(in_RCX + 0x9f);
            *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff3bd;
            iVar6 = func_0x0001801fea00(*(undefined8 *)((int64_t)&arg_38h + iVar7), (int64_t)&arg_48h + iVar7);
            if ((iVar6 == 0) || (uVar9 = *(uint64_t *)((int64_t)&arg_48h + iVar7), 0xfffffffffffffff < uVar9)) {
code_r0x0001801ffd9f:
                uVar11 = 0x89;
            } else {
                if ((uint64_t)in_RCX[0xbd] < uVar9) {
                    uVar13 = in_RCX[0xbc];
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff402;
                    iVar10 = func_0x0001802249c0(uVar13, uVar9 << 4, 0x1804b8fe8, 0x4f);
                    if (iVar10 == 0) goto code_r0x0001801ffd9f;
                    uVar9 = *(uint64_t *)((int64_t)&arg_48h + iVar7);
                    in_RCX[0xbd] = uVar9;
                    in_RCX[0xbc] = iVar10;
                }
                var_a0h = in_RCX[0xbc];
                var_98h = uVar9;
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff440;
                iVar6 = func_0x0001801fcd10(*(undefined8 *)((int64_t)&arg_38h + iVar7), uVar1, &var_a0h, 0);
                if (iVar6 == 0) goto code_r0x0001801ffd9f;
                if (**stack0xffffffffffffff18 != 5) {
code_r0x0001801ff487:
                    uVar13 = in_RCX[0x79];
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff4a3;
                    iVar6 = func_0x000180202e50(uVar13, &var_a0h, *(undefined4 *)((int64_t)&arg_58h + iVar7), arg_28h);
                    if (iVar6 != 0) {
                        *(int16_t *)((int64_t)in_RCX + 0x4fa) = *(int16_t *)((int64_t)in_RCX + 0x4fa) + 1;
                        goto code_r0x0001801ff4b2;
                    }
                    goto code_r0x0001801ffd9f;
                }
                puVar2 = stack0xffffffffffffff18[7];
                uVar13 = in_RCX[0x7b];
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff464;
                puVar8 = (uint8_t *)func_0x000180205200(uVar13);
                if (((puVar8 <= puVar2) && ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x10) == 0)) ||
                   (*(uint64_t *)(var_a0h + 8) < (uint64_t)in_RCX[0xb8])) goto code_r0x0001801ff487;
                uVar11 = 0x7a;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9018;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = uVar11;
        }
        break;
    case 4:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff51a;
            iVar6 = func_0x0001801fd6a0(*(undefined8 *)((int64_t)&arg_38h + iVar7), &var_a0h);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9080;
                *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x99;
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff536;
                iVar6 = fcn.1801fefa0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar7));
                if (iVar6 == 0) goto code_r0x0001802003f7;
                iVar10 = *(int64_t *)((int64_t)&arg_48h + iVar7);
                if (iVar10 == 0) goto code_r0x0001801ff4b2;
                if (*(char *)(iVar10 + 0x102) == '\0') {
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9080;
                    *(undefined4 *)((int64_t)&var_10h + iVar7) = 0xaa;
                } else {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff571;
                    iVar6 = fcn.1801e5ad0(iVar10 + 0xa0, var_90h, 1);
                    if (iVar6 == 0) {
                        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9080;
                        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0xbd;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff588;
                        iVar6 = fcn.1801e5970(iVar10 + 0xa0, 0);
                        if (iVar6 == 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff5aa;
                            func_0x0001801e7a50(in_RCX + 0x60, iVar10, var_98h, var_90h);
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff5b9;
                            fcn.1801e7fb0(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                          *(int64_t *)((int64_t)&var_10h + iVar7), 
                                          *(int64_t *)((int64_t)&var_18h + iVar7), 
                                          *(int64_t *)((int64_t)&var_20h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar7), 
                                          *(int64_t *)(&stack0x00000060 + iVar7), *(int64_t *)(&stack0x00000068 + iVar7)
                                          , *(int64_t *)(&stack0x00000070 + iVar7), 
                                          *(int64_t *)(&stack0x00000078 + iVar7));
                            goto code_r0x0001801ff4b2;
                        }
                        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9080;
                        *(undefined4 *)((int64_t)&var_10h + iVar7) = 199;
                    }
                }
            }
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x47a;
        }
        break;
    case 5:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff5e6;
            iVar6 = func_0x0001801fd780(in_RDX, &var_68h);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff605;
                iVar6 = fcn.1801fefa0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar7));
                if (iVar6 != 0) {
                    iVar10 = *(int64_t *)((int64_t)&arg_48h + iVar7);
                    if (iVar10 != 0) {
                        if (*(char *)(iVar10 + 0x101) == '\0') {
                            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9100;
                            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0xf5;
                            break;
                        }
                        *(uint32_t *)(iVar10 + 0x100) = *(uint32_t *)(iVar10 + 0x100) | 0x8000000;
                        *(int64_t *)(iVar10 + 0x50) = var_60h;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff64a;
                        fcn.1801e7da0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                    }
                    goto code_r0x0001801ff4b7;
                }
                goto code_r0x0001802003f7;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9100;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0xe4;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x488;
        }
        break;
    case 6:
        if (*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x494;
        } else {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff66d;
            iVar6 = func_0x0001801fd180(in_RDX, 0, &var_a0h);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9148;
                *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x115;
            } else {
                if (var_98h == 0) goto code_r0x0001801ff4b7;
                uVar9 = (uint64_t)(*(uint32_t *)(var_f8h + 0x10) & 3);
                iVar10 = in_RCX[uVar9 + 0x82];
                if (iVar10 == 0) goto code_r0x0001802003f7;
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff6bb;
                iVar6 = fcn.1801e5ad0(in_RCX + (uVar9 + 3) * 0xc, var_98h + var_a0h, 0);
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9148;
                    *(undefined4 *)((int64_t)&var_10h + iVar7) = 300;
                } else {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff6cd;
                    iVar6 = fcn.1801e5970(in_RCX + (uVar9 + 3) * 0xc, 0);
                    iVar5 = var_90h;
                    iVar12 = var_a0h;
                    if (iVar6 == 0) {
                        *(undefined4 *)((int64_t)&var_8h + iVar7) = 0;
                        *(int64_t *)(&stack0x00000000 + iVar7) = var_98h;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff6f6;
                        iVar6 = func_0x0001801e6d70(iVar10, ppuVar4, iVar12, iVar5);
                        if (iVar6 != 0) {
                            *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x10000000;
                            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
                            iVar10 = var_98h;
                            goto code_r0x0001801ff4bc;
                        }
                        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9148;
                        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x13c;
                    } else {
                        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9148;
                        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x133;
                    }
                }
            }
        }
        break;
    case 7:
        if (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5) {
            if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) == 0) {
                in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff746;
                iVar6 = func_0x0001801fd520(in_RDX, &var_c0h, &var_d8h);
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b91c0;
                    *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x150;
                } else {
                    if (var_d8h != 0) {
                        uVar13 = *in_RCX;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff760;
                        uVar13 = func_0x000180192480(uVar13);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff774;
                        iVar6 = func_0x0001801bfd70(uVar13, in_RCX + 0xd, var_c0h, var_d8h);
                        if (iVar6 != 0) goto code_r0x0001801ff4b7;
                        goto code_r0x0001802003f7;
                    }
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b91c0;
                    *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x15d;
                }
            } else {
                *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
                *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4ac;
            }
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4a0;
        }
        break;
    case 8:
    case 9:
    case 10:
    case 0xb:
    case 0xc:
    case 0xd:
    case 0xe:
    case 0xf:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) != 2) && (*(int32_t *)((int64_t)&arg_30h + iVar7) != 5)) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4c2;
            break;
        }
        *(int64_t *)((int64_t)&var_8h + iVar7) = (int64_t)&arg_48h + iVar7;
        *(int64_t *)(&stack0x00000000 + iVar7) = var_e0h;
        in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff7b9;
        iVar6 = fcn.1801fec60(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                              *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                              *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)(&stack0x00000060 + iVar7), 
                              *(int64_t *)(&stack0x00000068 + iVar7), *(int64_t *)(&stack0x00000070 + iVar7), 
                              *(int64_t *)(&stack0x00000078 + iVar7), *(int64_t *)(&stack0x00000080 + iVar7), 
                              *(int64_t *)(&stack0x00000088 + iVar7), *(int64_t *)(&stack0x00000100 + iVar7));
        if (iVar6 != 0) {
            iVar10 = *(int64_t *)((int64_t)&arg_48h + iVar7);
            goto code_r0x0001801ff4bc;
        }
        goto code_r0x0001802003f7;
    case 0x10:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff7f4;
            iVar6 = func_0x0001801fd2c0(in_RDX, (int64_t)&arg_48h + iVar7);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff80d;
                func_0x0001801e5b80(in_RCX + 0x14, *(undefined8 *)((int64_t)&arg_48h + iVar7));
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff823;
                func_0x0001801e82d0(in_RCX + 0x60, 0x1801e35f0, in_RCX);
                goto code_r0x0001801ff4b7;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9320;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x2a9;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4d1;
        }
        break;
    case 0x11:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
            *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff85b;
            iVar6 = func_0x0001801fd320(in_RDX, (int64_t)&arg_48h + iVar7, (int64_t)&arg_50h + iVar7);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff87a;
                iVar6 = fcn.1801fefa0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar7));
                if (iVar6 != 0) {
                    if (var_b8h != 0) {
                        if (*(char *)(var_b8h + 0x101) == '\0') {
                            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9340;
                            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x2d0;
                            break;
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff8ad;
                        func_0x0001801e5b80(var_b8h + 0x80, *(undefined8 *)((int64_t)&arg_50h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff8bc;
                        fcn.1801e7fb0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar7), *(int64_t *)(&stack0x00000060 + iVar7), 
                                      *(int64_t *)(&stack0x00000068 + iVar7), *(int64_t *)(&stack0x00000070 + iVar7), 
                                      *(int64_t *)(&stack0x00000078 + iVar7));
                    }
                    goto code_r0x0001801ff4b7;
                }
                goto code_r0x0001802003f7;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9340;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x2bf;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4de;
        }
        break;
    case 0x12:
    case 0x13:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) != 2) && (*(int32_t *)((int64_t)&arg_30h + iVar7) != 5)) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4ed;
            break;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff8e7;
        iVar6 = func_0x0001801fd3a0(*(undefined8 *)((int64_t)&arg_38h + iVar7), (int64_t)&arg_50h + iVar7);
        if (iVar6 == 0) {
            uVar11 = 0x2e4;
code_r0x000180200148:
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9388;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = uVar11;
            break;
        }
        uVar9 = *(uint64_t *)((int64_t)&arg_50h + iVar7);
        if (0x1000000000000000 < uVar9) {
            uVar11 = 0x2ec;
            goto code_r0x000180200148;
        }
        if (var_e0h == 0x12) {
            if ((uint64_t)in_RCX[0xa1] < uVar9) {
                in_RCX[0xa1] = uVar9;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff96b;
            func_0x0001801e82d0(in_RCX + 0x60, 0x180200640, in_RCX);
        } else {
            if (var_e0h != 0x13) {
                uVar11 = 0x303;
                goto code_r0x000180200148;
            }
            if ((uint64_t)in_RCX[0xa2] < uVar9) {
                in_RCX[0xa2] = uVar9;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff940;
            func_0x0001801e82d0(in_RCX + 0x60, 0x180200680, in_RCX);
        }
code_r0x0001801ff4b2:
        in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
        goto code_r0x0001801ff4b7;
    case 0x14:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff999;
            iVar6 = func_0x0001801fd240(in_RDX, (int64_t)&arg_50h + iVar7);
            if (iVar6 != 0) goto code_r0x0001801ff4b7;
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b93c8;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x314;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4fc;
        }
        break;
    case 0x15:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
            *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff9ff;
            iVar6 = func_0x0001801fd950(in_RDX, (int64_t)&arg_50h + iVar7, (int64_t)&arg_48h + iVar7);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b93e8;
                *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x329;
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffa1e;
                iVar6 = fcn.1801fefa0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar7));
                if (iVar6 == 0) goto code_r0x0001802003f7;
                if ((var_b0h == 0) || (*(char *)(var_b0h + 0x102) != '\0')) goto code_r0x0001801ff4b7;
                *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b93e8;
                *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x343;
            }
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x509;
        }
        break;
    case 0x16:
    case 0x17:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffa91;
            iVar6 = func_0x0001801fd9d0(*(undefined8 *)((int64_t)&arg_38h + iVar7), (int64_t)&arg_50h + iVar7);
            if (iVar6 == 0) {
                uVar11 = 0x356;
            } else {
                if (*(uint64_t *)((int64_t)&arg_50h + iVar7) < 0x1000000000000001) goto code_r0x0001801ff4b2;
                uVar11 = 0x364;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9440;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = uVar11;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x518;
        }
        break;
    case 0x18:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) != 2) && (*(int32_t *)((int64_t)&arg_30h + iVar7) != 5)) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x527;
            *(undefined8 *)((int64_t)&var_8h + iVar7) = 0x1804b8fe8;
            *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffaf9;
            fcn.1801e4990(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                          *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                          *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7), 
                          *(int64_t *)((int64_t)&arg_40h + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7), 
                          *(int64_t *)(&stack0x00000080 + iVar7), *(int64_t *)(&stack0x00000088 + iVar7), 
                          *(int64_t *)(&stack0x00000090 + iVar7), *(int64_t *)(&stack0x000000a0 + iVar7), 
                          *(int64_t *)(&stack0x000000a8 + iVar7), *(int64_t *)(&stack0x000000b0 + iVar7), 
                          *(int64_t *)(&stack0x000000b8 + iVar7), *(int64_t *)(&stack0x00000160 + iVar7));
        }
        in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffb0a;
        iVar6 = func_0x0001801fd430(in_RDX, &var_a0h);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9480;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x376;
            break;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffb1e;
        func_0x0001801e4240(in_RCX, &var_a0h);
code_r0x0001801ff4b7:
        iVar10 = *(int64_t *)((int64_t)&arg_40h + iVar7);
code_r0x0001801ff4bc:
        pcVar3 = (code *)in_RCX[0x7c];
        if (pcVar3 != (code *)0x0) {
            uVar13 = 0x202;
            iVar12 = *in_RDX - var_d0h;
            if (var_e0h == 0) {
                uVar13 = 0x204;
            } else if (((var_e0h & 0xfffffffffffffff8U) == 8) || (var_e0h == 6)) {
                uVar13 = 0x203;
                iVar12 = iVar12 - iVar10;
            }
            *(undefined8 *)((int64_t)&var_10h + iVar7) = in_RCX[0x7d];
            *(undefined8 *)((int64_t)&var_8h + iVar7) = in_RCX[0x7e];
            *(int64_t *)(&stack0x00000000 + iVar7) = iVar12;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffd4b;
            (*pcVar3)(0, 1, uVar13);
        }
        if (in_RDX[1] == 0) goto code_r0x0001802003f7;
        goto code_r0x0001801ff2c2;
    case 0x19:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffb46;
            iVar6 = func_0x0001801fd720(in_RDX, &var_a8h);
            if (iVar6 == 0) {
                uVar11 = 0x389;
            } else {
                if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) != 0) goto code_r0x0001801ff4b7;
                uVar11 = 0x39e;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b94a0;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = uVar11;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x533;
        }
        break;
    case 0x1a:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffb98;
            iVar6 = func_0x0001801fd5c0(in_RDX, (int64_t)&arg_50h + iVar7);
            if (iVar6 == 0) {
                var_c8h = 7;
                uVar11 = 0x3b7;
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffbb3;
                iVar10 = func_0x0001802248d0(9, 0x1804b8fe8, 0x3c3);
                if (iVar10 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffbd4;
                    iVar6 = func_0x000180244550(&var_a0h, iVar10, 9, 0);
                    if (iVar6 != 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffbea;
                        iVar6 = func_0x0001801fe400(&var_a0h, *(undefined8 *)((int64_t)&arg_50h + iVar7));
                        if (iVar6 == 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180200298;
                            func_0x000180243fb0(&var_a0h);
                        } else {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffbfb;
                            func_0x000180244200();
                            uVar13 = in_RCX[0x13];
                            *(undefined8 *)((int64_t)&var_20h + iVar7) = 0;
                            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1802004a0;
                            *(undefined8 *)((int64_t)&var_10h + iVar7) = 9;
                            *(int64_t *)((int64_t)&var_8h + iVar7) = iVar10;
                            *(undefined4 *)(&stack0x00000000 + iVar7) = 1;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffc3c;
                            iVar12 = func_0x000180201cf0(uVar13, 0, 2, 0x1b);
                            if (iVar12 != 0) goto code_r0x0001801ff4b7;
                        }
                    }
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1802002a9;
                func_0x000180224990(iVar10, 0x1804b8fe8, 0x3da);
                uVar11 = 0x3dd;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b94e0;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = uVar11;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x540;
        }
        break;
    case 0x1b:
        if (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffc6c;
            iVar6 = func_0x0001801fd620(in_RDX, (int64_t)&arg_50h + iVar7);
            if (iVar6 != 0) goto code_r0x0001801ff4b7;
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9500;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x3eb;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x54d;
        }
        break;
    case 0x1c:
code_r0x0001801ffcb1:
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffcbf;
        iVar6 = func_0x0001801fd080(*(undefined8 *)((int64_t)&arg_38h + iVar7), &var_a0h);
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffcd3;
            func_0x0001801e4870(in_RCX, &var_a0h);
            goto code_r0x0001801ff4b2;
        }
        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9520;
        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x3fd;
        break;
    case 0x1d:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5))
        goto code_r0x0001801ffcb1;
        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x55b;
        break;
    case 0x1e:
        if (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffcf0;
            iVar6 = func_0x0001801fd2a0(in_RDX);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffd00;
                func_0x0001801e3ed0(in_RCX);
                goto code_r0x0001801ff4b7;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9540;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x40e;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x56b;
        }
        break;
    default:
        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x577;
    }
code_r0x0001802003d6:
    *(undefined8 *)((int64_t)&var_8h + iVar7) = 0x1804b8fe8;
    *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1802003e5;
    fcn.1801e4990(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                  *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                  *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                  *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7), 
                  *(int64_t *)((int64_t)&arg_40h + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7), 
                  *(int64_t *)(&stack0x00000080 + iVar7), *(int64_t *)(&stack0x00000088 + iVar7), 
                  *(int64_t *)(&stack0x00000090 + iVar7), *(int64_t *)(&stack0x000000a0 + iVar7), 
                  *(int64_t *)(&stack0x000000a8 + iVar7), *(int64_t *)(&stack0x000000b0 + iVar7), 
                  *(int64_t *)(&stack0x000000b8 + iVar7), *(int64_t *)(&stack0x00000160 + iVar7));
    goto code_r0x0001802003f7;
}

// ============================================================
// Function: FUN_1802003f7
// Address: 0x1802003f7
// Size: 165 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h

void fcn.1801ff1d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_118h, int64_t arg_120h, int64_t arg_128h, int64_t arg_130h)
{
    undefined uVar1;
    uint8_t *puVar2;
    code *pcVar3;
    uint8_t **ppuVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint8_t *puVar8;
    uint64_t uVar9;
    int64_t iVar10;
    undefined4 uVar11;
    undefined8 *in_RCX;
    int64_t iVar12;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    uint8_t **in_R8;
    undefined8 uVar13;
    int32_t in_R9D;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_f8h;
    int32_t var_f0h;
    int64_t var_ech;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801ff1e5;
    var_ech._0_4_ = in_R9D;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7);
    var_f8h = arg_30h;
    puVar2 = *in_R8;
    *(int64_t **)((int64_t)&arg_38h + iVar7) = in_RDX;
    *(uint32_t *)((int64_t)&arg_30h + iVar7) = (uint32_t)*puVar2;
    var_c8h = 1;
    if ((int32_t)var_ech == 0) {
        *(undefined4 *)((int64_t)&arg_58h + iVar7) = 0;
    } else if (((int32_t)var_ech == 1) || ((int32_t)var_ech != 2)) {
        *(undefined4 *)((int64_t)&arg_58h + iVar7) = 2;
    } else {
        *(undefined4 *)((int64_t)&arg_58h + iVar7) = 1;
    }
    *(undefined8 *)((int64_t)&arg_128h + iVar7) = unaff_R13;
    *(undefined8 *)((int64_t)&arg_120h + iVar7) = unaff_R14;
    if (in_RDX[1] == 0) {
        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x428;
        *(undefined8 *)((int64_t)&var_8h + iVar7) = 0x1804b8fe8;
        *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff29f;
        fcn.1801e4990(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                      *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                      *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7), 
                      *(int64_t *)((int64_t)&arg_40h + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7), 
                      *(int64_t *)(&stack0x00000080 + iVar7), *(int64_t *)(&stack0x00000088 + iVar7), 
                      *(int64_t *)(&stack0x00000090 + iVar7), *(int64_t *)(&stack0x000000a0 + iVar7), 
                      *(int64_t *)(&stack0x000000a8 + iVar7), *(int64_t *)(&stack0x000000b0 + iVar7), 
                      *(int64_t *)(&stack0x000000b8 + iVar7), *(int64_t *)(&stack0x00000160 + iVar7));
code_r0x0001802003f7:
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180200413;
        func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar7));
        return;
    }
    *(undefined8 *)((int64_t)&arg_130h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_118h + iVar7) = unaff_R15;
    unique0x1000495e = in_R8;
code_r0x0001801ff2c2:
    ppuVar4 = stack0xffffffffffffff18;
    var_d0h = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
    if (in_RCX[0x7c] != 0) {
        var_d0h = *in_RDX;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff2fb;
    iVar6 = fcn.1801feb70(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                          *(int64_t *)((int64_t)&arg_30h + iVar7));
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x439;
        goto code_r0x0001802003d6;
    }
    if (var_f0h == 0) {
        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x441;
        goto code_r0x0001802003d6;
    }
    if ((((var_e0h != 0) && (var_e0h != 2)) && (var_e0h != 3)) && ((var_e0h != 0x1c && (var_e0h != 0x1d)))) {
        *(uint32_t *)(var_f8h + 0x10) = *(uint32_t *)(var_f8h + 0x10) | 4;
    }
    // switch table (31 cases) at 0x180200420
    switch(var_e0h) {
    case 0:
        in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff392;
        func_0x0001801fda60(in_RDX);
        goto code_r0x0001801ff4b7;
    case 1:
        in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff369;
        iVar6 = func_0x0001801fd680(in_RDX);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b8fd0;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x35;
            break;
        }
        uVar13 = in_RCX[0x11];
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff380;
        func_0x000180207ed0(uVar13, (int32_t)var_ech);
        goto code_r0x0001801ff4b7;
    case 2:
    case 3:
        if (*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x46a;
        } else {
            uVar1 = *(undefined *)(in_RCX + 0x9f);
            *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff3bd;
            iVar6 = func_0x0001801fea00(*(undefined8 *)((int64_t)&arg_38h + iVar7), (int64_t)&arg_48h + iVar7);
            if ((iVar6 == 0) || (uVar9 = *(uint64_t *)((int64_t)&arg_48h + iVar7), 0xfffffffffffffff < uVar9)) {
code_r0x0001801ffd9f:
                uVar11 = 0x89;
            } else {
                if ((uint64_t)in_RCX[0xbd] < uVar9) {
                    uVar13 = in_RCX[0xbc];
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff402;
                    iVar10 = func_0x0001802249c0(uVar13, uVar9 << 4, 0x1804b8fe8, 0x4f);
                    if (iVar10 == 0) goto code_r0x0001801ffd9f;
                    uVar9 = *(uint64_t *)((int64_t)&arg_48h + iVar7);
                    in_RCX[0xbd] = uVar9;
                    in_RCX[0xbc] = iVar10;
                }
                var_a0h = in_RCX[0xbc];
                var_98h = uVar9;
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff440;
                iVar6 = func_0x0001801fcd10(*(undefined8 *)((int64_t)&arg_38h + iVar7), uVar1, &var_a0h, 0);
                if (iVar6 == 0) goto code_r0x0001801ffd9f;
                if (**stack0xffffffffffffff18 != 5) {
code_r0x0001801ff487:
                    uVar13 = in_RCX[0x79];
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff4a3;
                    iVar6 = func_0x000180202e50(uVar13, &var_a0h, *(undefined4 *)((int64_t)&arg_58h + iVar7), arg_28h);
                    if (iVar6 != 0) {
                        *(int16_t *)((int64_t)in_RCX + 0x4fa) = *(int16_t *)((int64_t)in_RCX + 0x4fa) + 1;
                        goto code_r0x0001801ff4b2;
                    }
                    goto code_r0x0001801ffd9f;
                }
                puVar2 = stack0xffffffffffffff18[7];
                uVar13 = in_RCX[0x7b];
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff464;
                puVar8 = (uint8_t *)func_0x000180205200(uVar13);
                if (((puVar8 <= puVar2) && ((*(uint8_t *)((int64_t)in_RCX + 0x5d4) & 0x10) == 0)) ||
                   (*(uint64_t *)(var_a0h + 8) < (uint64_t)in_RCX[0xb8])) goto code_r0x0001801ff487;
                uVar11 = 0x7a;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9018;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = uVar11;
        }
        break;
    case 4:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff51a;
            iVar6 = func_0x0001801fd6a0(*(undefined8 *)((int64_t)&arg_38h + iVar7), &var_a0h);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9080;
                *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x99;
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff536;
                iVar6 = fcn.1801fefa0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar7));
                if (iVar6 == 0) goto code_r0x0001802003f7;
                iVar10 = *(int64_t *)((int64_t)&arg_48h + iVar7);
                if (iVar10 == 0) goto code_r0x0001801ff4b2;
                if (*(char *)(iVar10 + 0x102) == '\0') {
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9080;
                    *(undefined4 *)((int64_t)&var_10h + iVar7) = 0xaa;
                } else {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff571;
                    iVar6 = fcn.1801e5ad0(iVar10 + 0xa0, var_90h, 1);
                    if (iVar6 == 0) {
                        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9080;
                        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0xbd;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff588;
                        iVar6 = fcn.1801e5970(iVar10 + 0xa0, 0);
                        if (iVar6 == 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff5aa;
                            func_0x0001801e7a50(in_RCX + 0x60, iVar10, var_98h, var_90h);
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff5b9;
                            fcn.1801e7fb0(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                          *(int64_t *)((int64_t)&var_10h + iVar7), 
                                          *(int64_t *)((int64_t)&var_18h + iVar7), 
                                          *(int64_t *)((int64_t)&var_20h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar7), 
                                          *(int64_t *)(&stack0x00000060 + iVar7), *(int64_t *)(&stack0x00000068 + iVar7)
                                          , *(int64_t *)(&stack0x00000070 + iVar7), 
                                          *(int64_t *)(&stack0x00000078 + iVar7));
                            goto code_r0x0001801ff4b2;
                        }
                        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9080;
                        *(undefined4 *)((int64_t)&var_10h + iVar7) = 199;
                    }
                }
            }
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x47a;
        }
        break;
    case 5:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff5e6;
            iVar6 = func_0x0001801fd780(in_RDX, &var_68h);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff605;
                iVar6 = fcn.1801fefa0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar7));
                if (iVar6 != 0) {
                    iVar10 = *(int64_t *)((int64_t)&arg_48h + iVar7);
                    if (iVar10 != 0) {
                        if (*(char *)(iVar10 + 0x101) == '\0') {
                            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9100;
                            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0xf5;
                            break;
                        }
                        *(uint32_t *)(iVar10 + 0x100) = *(uint32_t *)(iVar10 + 0x100) | 0x8000000;
                        *(int64_t *)(iVar10 + 0x50) = var_60h;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff64a;
                        fcn.1801e7da0(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
                    }
                    goto code_r0x0001801ff4b7;
                }
                goto code_r0x0001802003f7;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9100;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0xe4;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x488;
        }
        break;
    case 6:
        if (*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x494;
        } else {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff66d;
            iVar6 = func_0x0001801fd180(in_RDX, 0, &var_a0h);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9148;
                *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x115;
            } else {
                if (var_98h == 0) goto code_r0x0001801ff4b7;
                uVar9 = (uint64_t)(*(uint32_t *)(var_f8h + 0x10) & 3);
                iVar10 = in_RCX[uVar9 + 0x82];
                if (iVar10 == 0) goto code_r0x0001802003f7;
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff6bb;
                iVar6 = fcn.1801e5ad0(in_RCX + (uVar9 + 3) * 0xc, var_98h + var_a0h, 0);
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9148;
                    *(undefined4 *)((int64_t)&var_10h + iVar7) = 300;
                } else {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff6cd;
                    iVar6 = fcn.1801e5970(in_RCX + (uVar9 + 3) * 0xc, 0);
                    iVar5 = var_90h;
                    iVar12 = var_a0h;
                    if (iVar6 == 0) {
                        *(undefined4 *)((int64_t)&var_8h + iVar7) = 0;
                        *(int64_t *)(&stack0x00000000 + iVar7) = var_98h;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff6f6;
                        iVar6 = func_0x0001801e6d70(iVar10, ppuVar4, iVar12, iVar5);
                        if (iVar6 != 0) {
                            *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x10000000;
                            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
                            iVar10 = var_98h;
                            goto code_r0x0001801ff4bc;
                        }
                        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9148;
                        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x13c;
                    } else {
                        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9148;
                        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x133;
                    }
                }
            }
        }
        break;
    case 7:
        if (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5) {
            if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) == 0) {
                in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff746;
                iVar6 = func_0x0001801fd520(in_RDX, &var_c0h, &var_d8h);
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b91c0;
                    *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x150;
                } else {
                    if (var_d8h != 0) {
                        uVar13 = *in_RCX;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff760;
                        uVar13 = func_0x000180192480(uVar13);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff774;
                        iVar6 = func_0x0001801bfd70(uVar13, in_RCX + 0xd, var_c0h, var_d8h);
                        if (iVar6 != 0) goto code_r0x0001801ff4b7;
                        goto code_r0x0001802003f7;
                    }
                    *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b91c0;
                    *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x15d;
                }
            } else {
                *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
                *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4ac;
            }
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4a0;
        }
        break;
    case 8:
    case 9:
    case 10:
    case 0xb:
    case 0xc:
    case 0xd:
    case 0xe:
    case 0xf:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) != 2) && (*(int32_t *)((int64_t)&arg_30h + iVar7) != 5)) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4c2;
            break;
        }
        *(int64_t *)((int64_t)&var_8h + iVar7) = (int64_t)&arg_48h + iVar7;
        *(int64_t *)(&stack0x00000000 + iVar7) = var_e0h;
        in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff7b9;
        iVar6 = fcn.1801fec60(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                              *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                              *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)(&stack0x00000060 + iVar7), 
                              *(int64_t *)(&stack0x00000068 + iVar7), *(int64_t *)(&stack0x00000070 + iVar7), 
                              *(int64_t *)(&stack0x00000078 + iVar7), *(int64_t *)(&stack0x00000080 + iVar7), 
                              *(int64_t *)(&stack0x00000088 + iVar7), *(int64_t *)(&stack0x00000100 + iVar7));
        if (iVar6 != 0) {
            iVar10 = *(int64_t *)((int64_t)&arg_48h + iVar7);
            goto code_r0x0001801ff4bc;
        }
        goto code_r0x0001802003f7;
    case 0x10:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff7f4;
            iVar6 = func_0x0001801fd2c0(in_RDX, (int64_t)&arg_48h + iVar7);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff80d;
                func_0x0001801e5b80(in_RCX + 0x14, *(undefined8 *)((int64_t)&arg_48h + iVar7));
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff823;
                func_0x0001801e82d0(in_RCX + 0x60, 0x1801e35f0, in_RCX);
                goto code_r0x0001801ff4b7;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9320;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x2a9;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4d1;
        }
        break;
    case 0x11:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
            *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff85b;
            iVar6 = func_0x0001801fd320(in_RDX, (int64_t)&arg_48h + iVar7, (int64_t)&arg_50h + iVar7);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff87a;
                iVar6 = fcn.1801fefa0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar7));
                if (iVar6 != 0) {
                    if (var_b8h != 0) {
                        if (*(char *)(var_b8h + 0x101) == '\0') {
                            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9340;
                            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x2d0;
                            break;
                        }
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff8ad;
                        func_0x0001801e5b80(var_b8h + 0x80, *(undefined8 *)((int64_t)&arg_50h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff8bc;
                        fcn.1801e7fb0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar7), *(int64_t *)(&stack0x00000060 + iVar7), 
                                      *(int64_t *)(&stack0x00000068 + iVar7), *(int64_t *)(&stack0x00000070 + iVar7), 
                                      *(int64_t *)(&stack0x00000078 + iVar7));
                    }
                    goto code_r0x0001801ff4b7;
                }
                goto code_r0x0001802003f7;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9340;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x2bf;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4de;
        }
        break;
    case 0x12:
    case 0x13:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) != 2) && (*(int32_t *)((int64_t)&arg_30h + iVar7) != 5)) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4ed;
            break;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff8e7;
        iVar6 = func_0x0001801fd3a0(*(undefined8 *)((int64_t)&arg_38h + iVar7), (int64_t)&arg_50h + iVar7);
        if (iVar6 == 0) {
            uVar11 = 0x2e4;
code_r0x000180200148:
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9388;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = uVar11;
            break;
        }
        uVar9 = *(uint64_t *)((int64_t)&arg_50h + iVar7);
        if (0x1000000000000000 < uVar9) {
            uVar11 = 0x2ec;
            goto code_r0x000180200148;
        }
        if (var_e0h == 0x12) {
            if ((uint64_t)in_RCX[0xa1] < uVar9) {
                in_RCX[0xa1] = uVar9;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff96b;
            func_0x0001801e82d0(in_RCX + 0x60, 0x180200640, in_RCX);
        } else {
            if (var_e0h != 0x13) {
                uVar11 = 0x303;
                goto code_r0x000180200148;
            }
            if ((uint64_t)in_RCX[0xa2] < uVar9) {
                in_RCX[0xa2] = uVar9;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff940;
            func_0x0001801e82d0(in_RCX + 0x60, 0x180200680, in_RCX);
        }
code_r0x0001801ff4b2:
        in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
        goto code_r0x0001801ff4b7;
    case 0x14:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff999;
            iVar6 = func_0x0001801fd240(in_RDX, (int64_t)&arg_50h + iVar7);
            if (iVar6 != 0) goto code_r0x0001801ff4b7;
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b93c8;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x314;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x4fc;
        }
        break;
    case 0x15:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
            *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ff9ff;
            iVar6 = func_0x0001801fd950(in_RDX, (int64_t)&arg_50h + iVar7, (int64_t)&arg_48h + iVar7);
            if (iVar6 == 0) {
                *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b93e8;
                *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x329;
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffa1e;
                iVar6 = fcn.1801fefa0(*(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar7));
                if (iVar6 == 0) goto code_r0x0001802003f7;
                if ((var_b0h == 0) || (*(char *)(var_b0h + 0x102) != '\0')) goto code_r0x0001801ff4b7;
                *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b93e8;
                *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x343;
            }
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x509;
        }
        break;
    case 0x16:
    case 0x17:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffa91;
            iVar6 = func_0x0001801fd9d0(*(undefined8 *)((int64_t)&arg_38h + iVar7), (int64_t)&arg_50h + iVar7);
            if (iVar6 == 0) {
                uVar11 = 0x356;
            } else {
                if (*(uint64_t *)((int64_t)&arg_50h + iVar7) < 0x1000000000000001) goto code_r0x0001801ff4b2;
                uVar11 = 0x364;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9440;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = uVar11;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x518;
        }
        break;
    case 0x18:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) != 2) && (*(int32_t *)((int64_t)&arg_30h + iVar7) != 5)) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x527;
            *(undefined8 *)((int64_t)&var_8h + iVar7) = 0x1804b8fe8;
            *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffaf9;
            fcn.1801e4990(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                          *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                          *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7), 
                          *(int64_t *)((int64_t)&arg_40h + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7), 
                          *(int64_t *)(&stack0x00000080 + iVar7), *(int64_t *)(&stack0x00000088 + iVar7), 
                          *(int64_t *)(&stack0x00000090 + iVar7), *(int64_t *)(&stack0x000000a0 + iVar7), 
                          *(int64_t *)(&stack0x000000a8 + iVar7), *(int64_t *)(&stack0x000000b0 + iVar7), 
                          *(int64_t *)(&stack0x000000b8 + iVar7), *(int64_t *)(&stack0x00000160 + iVar7));
        }
        in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffb0a;
        iVar6 = func_0x0001801fd430(in_RDX, &var_a0h);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9480;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x376;
            break;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffb1e;
        func_0x0001801e4240(in_RCX, &var_a0h);
code_r0x0001801ff4b7:
        iVar10 = *(int64_t *)((int64_t)&arg_40h + iVar7);
code_r0x0001801ff4bc:
        pcVar3 = (code *)in_RCX[0x7c];
        if (pcVar3 != (code *)0x0) {
            uVar13 = 0x202;
            iVar12 = *in_RDX - var_d0h;
            if (var_e0h == 0) {
                uVar13 = 0x204;
            } else if (((var_e0h & 0xfffffffffffffff8U) == 8) || (var_e0h == 6)) {
                uVar13 = 0x203;
                iVar12 = iVar12 - iVar10;
            }
            *(undefined8 *)((int64_t)&var_10h + iVar7) = in_RCX[0x7d];
            *(undefined8 *)((int64_t)&var_8h + iVar7) = in_RCX[0x7e];
            *(int64_t *)(&stack0x00000000 + iVar7) = iVar12;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffd4b;
            (*pcVar3)(0, 1, uVar13);
        }
        if (in_RDX[1] == 0) goto code_r0x0001802003f7;
        goto code_r0x0001801ff2c2;
    case 0x19:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffb46;
            iVar6 = func_0x0001801fd720(in_RDX, &var_a8h);
            if (iVar6 == 0) {
                uVar11 = 0x389;
            } else {
                if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) != 0) goto code_r0x0001801ff4b7;
                uVar11 = 0x39e;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b94a0;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = uVar11;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x533;
        }
        break;
    case 0x1a:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5)) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffb98;
            iVar6 = func_0x0001801fd5c0(in_RDX, (int64_t)&arg_50h + iVar7);
            if (iVar6 == 0) {
                var_c8h = 7;
                uVar11 = 0x3b7;
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffbb3;
                iVar10 = func_0x0001802248d0(9, 0x1804b8fe8, 0x3c3);
                if (iVar10 != 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffbd4;
                    iVar6 = func_0x000180244550(&var_a0h, iVar10, 9, 0);
                    if (iVar6 != 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffbea;
                        iVar6 = func_0x0001801fe400(&var_a0h, *(undefined8 *)((int64_t)&arg_50h + iVar7));
                        if (iVar6 == 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x180200298;
                            func_0x000180243fb0(&var_a0h);
                        } else {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffbfb;
                            func_0x000180244200();
                            uVar13 = in_RCX[0x13];
                            *(undefined8 *)((int64_t)&var_20h + iVar7) = 0;
                            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1802004a0;
                            *(undefined8 *)((int64_t)&var_10h + iVar7) = 9;
                            *(int64_t *)((int64_t)&var_8h + iVar7) = iVar10;
                            *(undefined4 *)(&stack0x00000000 + iVar7) = 1;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffc3c;
                            iVar12 = func_0x000180201cf0(uVar13, 0, 2, 0x1b);
                            if (iVar12 != 0) goto code_r0x0001801ff4b7;
                        }
                    }
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1802002a9;
                func_0x000180224990(iVar10, 0x1804b8fe8, 0x3da);
                uVar11 = 0x3dd;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b94e0;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = uVar11;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x540;
        }
        break;
    case 0x1b:
        if (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffc6c;
            iVar6 = func_0x0001801fd620(in_RDX, (int64_t)&arg_50h + iVar7);
            if (iVar6 != 0) goto code_r0x0001801ff4b7;
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9500;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x3eb;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x54d;
        }
        break;
    case 0x1c:
code_r0x0001801ffcb1:
        *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffcbf;
        iVar6 = func_0x0001801fd080(*(undefined8 *)((int64_t)&arg_38h + iVar7), &var_a0h);
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffcd3;
            func_0x0001801e4870(in_RCX, &var_a0h);
            goto code_r0x0001801ff4b2;
        }
        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9520;
        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x3fd;
        break;
    case 0x1d:
        if ((*(int32_t *)((int64_t)&arg_30h + iVar7) == 2) || (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5))
        goto code_r0x0001801ffcb1;
        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x55b;
        break;
    case 0x1e:
        if (*(int32_t *)((int64_t)&arg_30h + iVar7) == 5) {
            in_RDX = *(int64_t **)((int64_t)&arg_38h + iVar7);
            *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffcf0;
            iVar6 = func_0x0001801fd2a0(in_RDX);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1801ffd00;
                func_0x0001801e3ed0(in_RCX);
                goto code_r0x0001801ff4b7;
            }
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9540;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x40e;
        } else {
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
            *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x56b;
        }
        break;
    default:
        *(undefined8 *)((int64_t)&var_18h + iVar7) = 0x1804b9590;
        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0x577;
    }
code_r0x0001802003d6:
    *(undefined8 *)((int64_t)&var_8h + iVar7) = 0x1804b8fe8;
    *(undefined8 *)(&stack0x00000000 + iVar7) = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar7) = 0x1802003e5;
    fcn.1801e4990(*(int64_t *)(&stack0x00000000 + iVar7), *(int64_t *)((int64_t)&var_8h + iVar7), 
                  *(int64_t *)((int64_t)&var_10h + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                  *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                  *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7), 
                  *(int64_t *)((int64_t)&arg_40h + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7), 
                  *(int64_t *)(&stack0x00000080 + iVar7), *(int64_t *)(&stack0x00000088 + iVar7), 
                  *(int64_t *)(&stack0x00000090 + iVar7), *(int64_t *)(&stack0x000000a0 + iVar7), 
                  *(int64_t *)(&stack0x000000a8 + iVar7), *(int64_t *)(&stack0x000000b0 + iVar7), 
                  *(int64_t *)(&stack0x000000b8 + iVar7), *(int64_t *)(&stack0x00000160 + iVar7));
    goto code_r0x0001802003f7;
}

// ============================================================
// Function: FUN_1802004a0
// Address: 0x1802004a0
// Size: 35 bytes
// ============================================================
void fcn.1802004a0(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18022499a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == (code *)0x180224990) {
        if (param_1 != 0) {
            *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_1802004d0
// Address: 0x1802004d0
// Size: 358 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h

void fcn.1802004d0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_68h)
{
    char cVar1;
    char *pcVar2;
    char *pcVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 uVar7;
    char **in_RDX;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802004e5;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_58h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6);
    pcVar2 = in_RDX[3];
    if (in_RCX == 0) goto code_r0x000180200617;
    *(uint32_t *)(in_RCX + 0x5d0) = *(uint32_t *)(in_RCX + 0x5d0) & 0xefffffff;
    *(char **)((int64_t)&arg_40h + iVar6) = in_RDX[4];
    *(char **)((int64_t)&arg_48h + iVar6) = in_RDX[5];
    pcVar3 = *in_RDX;
    *(undefined8 *)((int64_t)&arg_50h + iVar6) = 0;
    cVar1 = *pcVar3;
    if (cVar1 == '\x01') {
        *(uint32_t *)((int64_t)&arg_50h + iVar6) = *(uint32_t *)((int64_t)&arg_50h + iVar6) & 0xfffffffc;
        uVar7 = *(undefined8 *)(in_RCX + 0x88);
code_r0x0001802005a7:
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802005af;
        func_0x000180207230(uVar7, pcVar2);
    } else if (cVar1 == '\x02') {
        iVar5 = 1;
code_r0x000180200578:
        uVar7 = *(undefined8 *)(in_RCX + 0x88);
        *(uint32_t *)((int64_t)&arg_50h + iVar6) = *(uint32_t *)((int64_t)&arg_50h + iVar6) & 0xfffffffc | 2;
        if (iVar5 != 2) goto code_r0x0001802005a7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180200599;
        func_0x000180208210();
    } else {
        if (cVar1 != '\x03') {
            if (cVar1 != '\x05') goto code_r0x000180200617;
            iVar5 = 3;
            goto code_r0x000180200578;
        }
        uVar7 = *(undefined8 *)(in_RCX + 0x88);
        *(uint32_t *)((int64_t)&arg_50h + iVar6) = *(uint32_t *)((int64_t)&arg_50h + iVar6) & 0xfffffffd | 1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180200571;
        func_0x000180208210(uVar7);
    }
    uVar4 = *(uint64_t *)(*in_RDX + 0x48);
    if (uVar4 < 0x8000000000000000) {
        pcVar2 = in_RDX[5];
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = *(undefined8 *)(*in_RDX + 0x50);
        *(int64_t *)((int64_t)&var_20h + iVar6) = (int64_t)&arg_40h + iVar6;
        *(char **)((int64_t)&var_18h + iVar6) = pcVar2;
        *(uint64_t *)((int64_t)&arg_38h + iVar6) = uVar4;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802005f9;
        iVar5 = fcn.1801ff1d0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                              *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                              *(int64_t *)((int64_t)&arg_48h + iVar6), *(int64_t *)(&stack0x00000108 + iVar6), 
                              *(int64_t *)(&stack0x00000110 + iVar6), *(int64_t *)(&stack0x00000118 + iVar6), 
                              *(int64_t *)(&stack0x00000120 + iVar6));
        if (iVar5 != 0) {
            uVar7 = *(undefined8 *)(in_RCX + 0x3c8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020060e;
            func_0x000180203250(uVar7, (int64_t)&arg_40h + iVar6);
        }
    }
code_r0x000180200617:
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180200624;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_58h + iVar6) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_180200640
// Address: 0x180200640
// Size: 49 bytes
// ============================================================
void fcn.180200640(int64_t *param_1, int64_t param_2)
{
    int64_t **ppiVar1;
    char cVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    code *pcVar5;
    uint32_t uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t iVar14;
    int64_t *piVar15;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar16;
    undefined8 auStackX_8 [4];
    
    iVar14 = fcn.18045a350();
    iVar14 = -iVar14;
    if ((*(uint8_t *)(param_1 + 0x20) & 2) != 0) {
        return;
    }
    param_2 = param_2 + 0x300;
    *(undefined8 *)(&stack0x00000048 + iVar14) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar14 + 0x18) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar14 + 0x10) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar14 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_8 + iVar14) = 0x1801e7fc3;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar8 = *(uint32_t *)(param_1 + 0x20);
    uVar3 = *(undefined8 *)(param_2 + 8);
    *(undefined8 *)(&stack0x000000c0 + iVar9 + iVar14) = unaff_R14;
    bVar16 = true;
    *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e7fe9;
    uVar6 = func_0x0001801e3b40(uVar3);
    if ((uVar8 & 1) == uVar6) {
        uVar8 = *(uint32_t *)(param_1 + 0x20);
        uVar4 = param_1[7];
        pcVar5 = *(code **)(param_2 + 0x70);
        if (pcVar5 != (code *)0x0) {
            uVar3 = *(undefined8 *)(param_2 + 0x78);
            *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e801c;
            uVar10 = (*pcVar5)((uVar8 & 2) != 0, uVar3);
            bVar16 = uVar4 >> 2 < uVar10;
        }
    }
    cVar2 = *(char *)((int64_t)param_1 + 0x101);
    *(undefined8 *)(&stack0x000000b8 + iVar9 + iVar14) = unaff_RDI;
    if (cVar2 == '\x03') {
        iVar11 = param_1[0xe];
        *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e8040;
        iVar7 = func_0x0001801e6440(iVar11);
        if (iVar7 == 0) goto code_r0x0001801e8094;
        if ((*(char *)((int64_t)param_1 + 0x101) != '\0') && (*(char *)((int64_t)param_1 + 0x101) == '\x03')) {
            iVar11 = param_1[0xe];
            *(undefined *)((int64_t)param_1 + 0x101) = 4;
            *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e8063;
            func_0x0001801e6180(iVar11);
            param_1[0xe] = 0;
            if ((char)*(uint32_t *)((int64_t)param_1 + 0x104) < '\0') {
                *(uint32_t *)((int64_t)param_1 + 0x104) = *(uint32_t *)((int64_t)param_1 + 0x104) & 0xffffff7f;
                piVar15 = (int64_t *)(param_2 + 0x60);
                *piVar15 = *piVar15 + -1;
                if (*piVar15 == 0) {
                    uVar3 = *(undefined8 *)(param_2 + 8);
                    *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e808b;
                    func_0x0001801e3de0(uVar3);
                }
            }
        }
    } else {
code_r0x0001801e8094:
        if (((*(uint8_t *)((int64_t)param_1 + 0x104) & 0x80) != 0) && (*(char *)((int64_t)param_1 + 0x101) == '\x02')) {
            iVar11 = param_1[0xe];
            *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e80b2;
            iVar7 = func_0x0001801e6440(iVar11);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e80c1;
                func_0x0001801e8310(param_2, param_1);
            }
        }
    }
    uVar8 = *(uint32_t *)((int64_t)param_1 + 0x104);
    if ((uVar8 & 0x40) == 0) {
        if ((((uVar8 & 0x20) == 0) || ((*(char *)((int64_t)param_1 + 0x102) != '\0' && ((uVar8 & 0x10) == 0)))) ||
           ((cVar2 = *(char *)((int64_t)param_1 + 0x101), cVar2 != '\0' && ((cVar2 != '\x04' && (cVar2 != '\x06')))))) {
            *(uint32_t *)((int64_t)param_1 + 0x104) = uVar8 & 0xffffffbf;
        } else {
            piVar15 = param_1 + 4;
            *(uint32_t *)((int64_t)param_1 + 0x104) = uVar8 | 0x40;
            ppiVar1 = (int64_t **)(param_2 + 0x30);
            piVar13 = *ppiVar1;
            *piVar15 = (int64_t)piVar13;
            piVar13[1] = (int64_t)piVar15;
            *ppiVar1 = piVar15;
            param_1[5] = (int64_t)ppiVar1;
        }
    }
    if ((bVar16) && ((*(uint32_t *)((int64_t)param_1 + 0x104) & 0x40) == 0)) {
        if ((*(char *)((int64_t)param_1 + 0x102) == '\0') || (*(char *)((int64_t)param_1 + 0x102) != '\x01')) {
code_r0x0001801e816c:
            if ((*(uint8_t *)((int64_t)param_1 + 0x104) & 0xc) == 0) {
                if (((*(uint32_t *)(param_1 + 0x20) >> 0x1b & 1) == 0) &&
                   (((uVar8 = *(uint32_t *)(param_1 + 0x20) >> 8 & 0xff, uVar8 == 1 || (uVar8 == 2)) || (uVar8 == 3))))
                {
                    iVar11 = param_1[0xe];
                    *(undefined **)(&stack0x00000030 + iVar9 + iVar14) = &stack0x000000b0 + iVar9 + iVar14;
                    *(undefined8 *)(&stack0x000000b0 + iVar9 + iVar14) = 2;
                    *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e81d0;
                    iVar7 = func_0x0001801e6230(iVar11, 0, &stack0x00000060 + iVar9 + iVar14, 
                                                &stack0x00000040 + iVar9 + iVar14);
                    if (iVar7 != 0) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e81e2;
                        iVar11 = func_0x0001801e5c20(param_1 + 0x10, 0);
                        *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e81f1;
                        iVar12 = func_0x0001801bc820(param_1 + 0x10);
                        if (((((&stack0x00000080)[iVar9 + iVar14] & 2) != 0) &&
                            (*(int64_t *)(&stack0x00000070 + iVar9 + iVar14) == 0)) ||
                           (*(uint64_t *)(&stack0x00000068 + iVar9 + iVar14) < (uint64_t)(iVar12 + iVar11)))
                        goto code_r0x0001801e8209;
                    }
                }
                goto code_r0x0001801e8245;
            }
        } else if ((*(uint32_t *)((int64_t)param_1 + 0x104) & 2) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e8164;
            iVar7 = func_0x0001801e59a0(param_1 + 0x14, 0);
            if (iVar7 == 0) goto code_r0x0001801e816c;
        }
code_r0x0001801e8209:
        if ((*(uint32_t *)(param_1 + 0x20) & 0x1000000) == 0) {
            iVar14 = *(int64_t *)(param_2 + 0x10);
            *param_1 = iVar14;
            *(int64_t **)(iVar14 + 8) = param_1;
            *(int64_t **)(param_2 + 0x10) = param_1;
            param_1[1] = (int64_t)(int64_t **)(param_2 + 0x10);
            if (*(int64_t *)(param_2 + 0x68) == 0) {
                *(int64_t **)(param_2 + 0x68) = param_1;
            }
            *(uint32_t *)(param_1 + 0x20) = *(uint32_t *)(param_1 + 0x20) | 0x1000000;
        }
    } else {
code_r0x0001801e8245:
        if ((*(uint32_t *)(param_1 + 0x20) & 0x1000000) != 0) {
            if (*(int64_t **)(param_2 + 0x68) == param_1) {
                piVar15 = (int64_t *)param_1[1];
                if (piVar15 == (int64_t *)(param_2 + 0x10)) {
                    piVar15 = (int64_t *)piVar15[1];
                }
                piVar13 = (int64_t *)0x0;
                if (piVar15 != (int64_t *)(param_2 + 0x10)) {
                    piVar13 = piVar15;
                }
                *(int64_t **)(param_2 + 0x68) = piVar13;
                if (piVar13 == param_1) {
                    *(undefined8 *)(param_2 + 0x68) = 0;
                }
            }
            *(int64_t *)(*param_1 + 8) = param_1[1];
            *(int64_t *)param_1[1] = *param_1;
            *(uint32_t *)(param_1 + 0x20) = *(uint32_t *)(param_1 + 0x20) & 0xfeffffff;
            *param_1 = 0;
            param_1[1] = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180200680
// Address: 0x180200680
// Size: 49 bytes
// ============================================================
void fcn.180200680(int64_t *param_1, int64_t param_2)
{
    int64_t **ppiVar1;
    char cVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    code *pcVar5;
    uint32_t uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t iVar14;
    int64_t *piVar15;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar16;
    undefined8 auStackX_8 [4];
    
    iVar14 = fcn.18045a350();
    iVar14 = -iVar14;
    if ((*(uint8_t *)(param_1 + 0x20) & 2) == 0) {
        return;
    }
    param_2 = param_2 + 0x300;
    *(undefined8 *)(&stack0x00000048 + iVar14) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar14 + 0x18) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar14 + 0x10) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar14 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_8 + iVar14) = 0x1801e7fc3;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar8 = *(uint32_t *)(param_1 + 0x20);
    uVar3 = *(undefined8 *)(param_2 + 8);
    *(undefined8 *)(&stack0x000000c0 + iVar9 + iVar14) = unaff_R14;
    bVar16 = true;
    *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e7fe9;
    uVar6 = func_0x0001801e3b40(uVar3);
    if ((uVar8 & 1) == uVar6) {
        uVar8 = *(uint32_t *)(param_1 + 0x20);
        uVar4 = param_1[7];
        pcVar5 = *(code **)(param_2 + 0x70);
        if (pcVar5 != (code *)0x0) {
            uVar3 = *(undefined8 *)(param_2 + 0x78);
            *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e801c;
            uVar10 = (*pcVar5)((uVar8 & 2) != 0, uVar3);
            bVar16 = uVar4 >> 2 < uVar10;
        }
    }
    cVar2 = *(char *)((int64_t)param_1 + 0x101);
    *(undefined8 *)(&stack0x000000b8 + iVar9 + iVar14) = unaff_RDI;
    if (cVar2 == '\x03') {
        iVar11 = param_1[0xe];
        *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e8040;
        iVar7 = func_0x0001801e6440(iVar11);
        if (iVar7 == 0) goto code_r0x0001801e8094;
        if ((*(char *)((int64_t)param_1 + 0x101) != '\0') && (*(char *)((int64_t)param_1 + 0x101) == '\x03')) {
            iVar11 = param_1[0xe];
            *(undefined *)((int64_t)param_1 + 0x101) = 4;
            *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e8063;
            func_0x0001801e6180(iVar11);
            param_1[0xe] = 0;
            if ((char)*(uint32_t *)((int64_t)param_1 + 0x104) < '\0') {
                *(uint32_t *)((int64_t)param_1 + 0x104) = *(uint32_t *)((int64_t)param_1 + 0x104) & 0xffffff7f;
                piVar15 = (int64_t *)(param_2 + 0x60);
                *piVar15 = *piVar15 + -1;
                if (*piVar15 == 0) {
                    uVar3 = *(undefined8 *)(param_2 + 8);
                    *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e808b;
                    func_0x0001801e3de0(uVar3);
                }
            }
        }
    } else {
code_r0x0001801e8094:
        if (((*(uint8_t *)((int64_t)param_1 + 0x104) & 0x80) != 0) && (*(char *)((int64_t)param_1 + 0x101) == '\x02')) {
            iVar11 = param_1[0xe];
            *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e80b2;
            iVar7 = func_0x0001801e6440(iVar11);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e80c1;
                func_0x0001801e8310(param_2, param_1);
            }
        }
    }
    uVar8 = *(uint32_t *)((int64_t)param_1 + 0x104);
    if ((uVar8 & 0x40) == 0) {
        if ((((uVar8 & 0x20) == 0) || ((*(char *)((int64_t)param_1 + 0x102) != '\0' && ((uVar8 & 0x10) == 0)))) ||
           ((cVar2 = *(char *)((int64_t)param_1 + 0x101), cVar2 != '\0' && ((cVar2 != '\x04' && (cVar2 != '\x06')))))) {
            *(uint32_t *)((int64_t)param_1 + 0x104) = uVar8 & 0xffffffbf;
        } else {
            piVar15 = param_1 + 4;
            *(uint32_t *)((int64_t)param_1 + 0x104) = uVar8 | 0x40;
            ppiVar1 = (int64_t **)(param_2 + 0x30);
            piVar13 = *ppiVar1;
            *piVar15 = (int64_t)piVar13;
            piVar13[1] = (int64_t)piVar15;
            *ppiVar1 = piVar15;
            param_1[5] = (int64_t)ppiVar1;
        }
    }
    if ((bVar16) && ((*(uint32_t *)((int64_t)param_1 + 0x104) & 0x40) == 0)) {
        if ((*(char *)((int64_t)param_1 + 0x102) == '\0') || (*(char *)((int64_t)param_1 + 0x102) != '\x01')) {
code_r0x0001801e816c:
            if ((*(uint8_t *)((int64_t)param_1 + 0x104) & 0xc) == 0) {
                if (((*(uint32_t *)(param_1 + 0x20) >> 0x1b & 1) == 0) &&
                   (((uVar8 = *(uint32_t *)(param_1 + 0x20) >> 8 & 0xff, uVar8 == 1 || (uVar8 == 2)) || (uVar8 == 3))))
                {
                    iVar11 = param_1[0xe];
                    *(undefined **)(&stack0x00000030 + iVar9 + iVar14) = &stack0x000000b0 + iVar9 + iVar14;
                    *(undefined8 *)(&stack0x000000b0 + iVar9 + iVar14) = 2;
                    *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e81d0;
                    iVar7 = func_0x0001801e6230(iVar11, 0, &stack0x00000060 + iVar9 + iVar14, 
                                                &stack0x00000040 + iVar9 + iVar14);
                    if (iVar7 != 0) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e81e2;
                        iVar11 = func_0x0001801e5c20(param_1 + 0x10, 0);
                        *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e81f1;
                        iVar12 = func_0x0001801bc820(param_1 + 0x10);
                        if (((((&stack0x00000080)[iVar9 + iVar14] & 2) != 0) &&
                            (*(int64_t *)(&stack0x00000070 + iVar9 + iVar14) == 0)) ||
                           (*(uint64_t *)(&stack0x00000068 + iVar9 + iVar14) < (uint64_t)(iVar12 + iVar11)))
                        goto code_r0x0001801e8209;
                    }
                }
                goto code_r0x0001801e8245;
            }
        } else if ((*(uint32_t *)((int64_t)param_1 + 0x104) & 2) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar14) = 0x1801e8164;
            iVar7 = func_0x0001801e59a0(param_1 + 0x14, 0);
            if (iVar7 == 0) goto code_r0x0001801e816c;
        }
code_r0x0001801e8209:
        if ((*(uint32_t *)(param_1 + 0x20) & 0x1000000) == 0) {
            iVar14 = *(int64_t *)(param_2 + 0x10);
            *param_1 = iVar14;
            *(int64_t **)(iVar14 + 8) = param_1;
            *(int64_t **)(param_2 + 0x10) = param_1;
            param_1[1] = (int64_t)(int64_t **)(param_2 + 0x10);
            if (*(int64_t *)(param_2 + 0x68) == 0) {
                *(int64_t **)(param_2 + 0x68) = param_1;
            }
            *(uint32_t *)(param_1 + 0x20) = *(uint32_t *)(param_1 + 0x20) | 0x1000000;
        }
    } else {
code_r0x0001801e8245:
        if ((*(uint32_t *)(param_1 + 0x20) & 0x1000000) != 0) {
            if (*(int64_t **)(param_2 + 0x68) == param_1) {
                piVar15 = (int64_t *)param_1[1];
                if (piVar15 == (int64_t *)(param_2 + 0x10)) {
                    piVar15 = (int64_t *)piVar15[1];
                }
                piVar13 = (int64_t *)0x0;
                if (piVar15 != (int64_t *)(param_2 + 0x10)) {
                    piVar13 = piVar15;
                }
                *(int64_t **)(param_2 + 0x68) = piVar13;
                if (piVar13 == param_1) {
                    *(undefined8 *)(param_2 + 0x68) = 0;
                }
            }
            *(int64_t *)(*param_1 + 8) = param_1[1];
            *(int64_t *)param_1[1] = *param_1;
            *(uint32_t *)(param_1 + 0x20) = *(uint32_t *)(param_1 + 0x20) & 0xfeffffff;
            *param_1 = 0;
            param_1[1] = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1802006c0
// Address: 0x1802006c0
// Size: 67 bytes
// ============================================================
bool fcn.1802006c0(uint8_t *param_1, uint8_t *param_2)
{
    uint8_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802006ca;
    iVar3 = fcn.18045a350();
    uVar1 = *param_1;
    if ((uVar1 == *param_2) && (uVar1 < 0x15)) {
        *(undefined8 *)((int64_t)&uStack_8 - iVar3) = 0x1802006e6;
        iVar2 = fcn.180497f30(param_1 + 1, param_2 + 1, uVar1);
        return iVar2 != 0;
    }
    return true;
}

// ============================================================
// Function: FUN_180200710
// Address: 0x180200710
// Size: 172 bytes
// ============================================================
void fcn.180200710(int64_t arg_28h, int64_t arg_38h, int64_t arg_48h, int64_t arg_58h, int64_t arg_68h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020071c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_68h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar3);
    *(undefined4 *)((int64_t)&iStackX_20 + iVar3 + -8) = 0;
    *(undefined (*) [16])((int64_t)&arg_28h + iVar3) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_38h + iVar3) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_48h + iVar3) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_58h + iVar3) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020075f;
    iVar2 = fcn.180275b20((int64_t)&arg_28h + iVar3, 4);
    if (iVar2 != 0) {
        uVar1 = *(undefined8 *)(in_RCX + 0x20);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200777;
        iVar2 = fcn.180275760((int64_t)&arg_28h + iVar3, uVar1, 0, 0);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020078d;
            fcn.1802758b0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802007a2;
            fcn.1802754d0((int64_t)&arg_28h + iVar3, (int64_t)&iStackX_20 + iVar3 + -8, 4);
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802007b3;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_68h + iVar3) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1802007e0
// Address: 0x1802007e0
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 * fcn.1802007e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined4 *in_R8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802007f5;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (0x14 < *(uint8_t *)in_R8) {
        return (undefined4 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180200835;
    puVar8 = (undefined4 *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar7));
    if (puVar8 != (undefined4 *)0x0) {
        uVar3 = in_R8[1];
        uVar4 = in_R8[2];
        uVar5 = in_R8[3];
        *puVar8 = *in_R8;
        puVar8[1] = uVar3;
        puVar8[2] = uVar4;
        puVar8[3] = uVar5;
        puVar8[4] = in_R8[4];
        *(uint8_t *)(puVar8 + 5) = *(uint8_t *)(in_R8 + 5);
        *(int64_t *)(puVar8 + 8) = in_RCX + 8;
        *(int64_t **)(puVar8 + 10) = in_RDX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180200868;
        fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        iVar1 = in_RDX[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180200871;
        iVar6 = fcn.180228e00(iVar1);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180200881;
            fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
            uVar2 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020088a;
            iVar6 = fcn.180228e00(uVar2);
            if (iVar6 == 0) {
                *in_RDX = *in_RDX + 1;
                return puVar8;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020089a;
            fcn.180228b10(*(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802008af;
    fcn.180224990(puVar8, 0x1804b98f0, 0x11a);
    return (undefined4 *)0x0;
}

// ============================================================
// Function: FUN_18020081f
// Address: 0x18020081f
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 * fcn.1802007e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined4 *in_R8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802007f5;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (0x14 < *(uint8_t *)in_R8) {
        return (undefined4 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180200835;
    puVar8 = (undefined4 *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar7));
    if (puVar8 != (undefined4 *)0x0) {
        uVar3 = in_R8[1];
        uVar4 = in_R8[2];
        uVar5 = in_R8[3];
        *puVar8 = *in_R8;
        puVar8[1] = uVar3;
        puVar8[2] = uVar4;
        puVar8[3] = uVar5;
        puVar8[4] = in_R8[4];
        *(uint8_t *)(puVar8 + 5) = *(uint8_t *)(in_R8 + 5);
        *(int64_t *)(puVar8 + 8) = in_RCX + 8;
        *(int64_t **)(puVar8 + 10) = in_RDX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180200868;
        fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        iVar1 = in_RDX[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180200871;
        iVar6 = fcn.180228e00(iVar1);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180200881;
            fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
            uVar2 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020088a;
            iVar6 = fcn.180228e00(uVar2);
            if (iVar6 == 0) {
                *in_RDX = *in_RDX + 1;
                return puVar8;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020089a;
            fcn.180228b10(*(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802008af;
    fcn.180224990(puVar8, 0x1804b98f0, 0x11a);
    return (undefined4 *)0x0;
}

// ============================================================
// Function: FUN_1802008c6
// Address: 0x1802008c6
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 * fcn.1802007e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined4 *in_R8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802007f5;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (0x14 < *(uint8_t *)in_R8) {
        return (undefined4 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180200835;
    puVar8 = (undefined4 *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar7));
    if (puVar8 != (undefined4 *)0x0) {
        uVar3 = in_R8[1];
        uVar4 = in_R8[2];
        uVar5 = in_R8[3];
        *puVar8 = *in_R8;
        puVar8[1] = uVar3;
        puVar8[2] = uVar4;
        puVar8[3] = uVar5;
        puVar8[4] = in_R8[4];
        *(uint8_t *)(puVar8 + 5) = *(uint8_t *)(in_R8 + 5);
        *(int64_t *)(puVar8 + 8) = in_RCX + 8;
        *(int64_t **)(puVar8 + 10) = in_RDX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180200868;
        fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        iVar1 = in_RDX[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180200871;
        iVar6 = fcn.180228e00(iVar1);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180200881;
            fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
            uVar2 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020088a;
            iVar6 = fcn.180228e00(uVar2);
            if (iVar6 == 0) {
                *in_RDX = *in_RDX + 1;
                return puVar8;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020089a;
            fcn.180228b10(*(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802008af;
    fcn.180224990(puVar8, 0x1804b98f0, 0x11a);
    return (undefined4 *)0x0;
}

// ============================================================
// Function: FUN_1802008d0
// Address: 0x1802008d0
// Size: 107 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1802008d0(int64_t arg_28h)
{
    undefined8 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802008e0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *(undefined8 *)(in_RDX + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802008f4;
    func_0x000180229280(uVar1, 0);
    uVar1 = *(undefined8 *)(in_RDX + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180200907;
    func_0x000180228ce0(uVar1, 0x180200960, in_RCX);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180200913;
    fcn.180228b10(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)(&stack0x00000038 + iVar4));
    uVar1 = *(undefined8 *)(in_RDX + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020091c;
    func_0x000180228ec0(uVar1);
    uVar1 = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x18022499a;
    iVar5 = fcn.18045a350(in_RDX, 0x1804b98f0, 0xfa);
    iVar5 = -iVar5;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (in_RDX != 0) {
            *(undefined8 *)(&stack0x00000040 + iVar5 + iVar4) = uVar1;
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18047ca3c;
            iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, in_RDX);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18047ca46;
                uVar3 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18047ca4d;
                uVar3 = fcn.18046b63c(uVar3);
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18047ca54;
                puVar6 = (undefined4 *)fcn.18046b77c();
                *puVar6 = uVar3;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_180200940
// Address: 0x180200940
// Size: 31 bytes
// ============================================================
void fcn.180200940(int64_t param_1, undefined8 param_2)
{
    undefined8 uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)(&stack0x00000030 + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = 0x1802008e0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *(undefined8 *)(param_1 + 8);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1802008f4;
    func_0x000180229280(uVar1, 0);
    uVar1 = *(undefined8 *)(param_1 + 8);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x180200907;
    func_0x000180228ce0(uVar1, 0x180200960, param_2);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x180200913;
    fcn.180228b10(*(int64_t *)(&stack0x00000050 + iVar4 + iVar5), *(int64_t *)(&stack0x00000058 + iVar4 + iVar5), 
                  *(int64_t *)(&stack0x00000060 + iVar4 + iVar5));
    uVar1 = *(undefined8 *)(param_1 + 8);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x18020091c;
    func_0x000180228ec0(uVar1);
    uVar1 = *(undefined8 *)(&stack0x00000050 + iVar4 + iVar5);
    *(undefined8 *)(&stack0x00000040 + iVar4 + iVar5) = 0x18022499a;
    iVar6 = fcn.18045a350(param_1, 0x1804b98f0, 0xfa);
    iVar6 = -iVar6;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (param_1 != 0) {
            *(undefined8 *)(&stack0x00000068 + iVar6 + iVar4 + iVar5) = uVar1;
            *(undefined8 *)(&stack0x00000040 + iVar6 + iVar4 + iVar5) = 0x18047ca3c;
            iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar2 == 0) {
                *(undefined8 *)(&stack0x00000040 + iVar6 + iVar4 + iVar5) = 0x18047ca46;
                uVar3 = (*(code *)0x699ff6)();
                *(undefined8 *)(&stack0x00000040 + iVar6 + iVar4 + iVar5) = 0x18047ca4d;
                uVar3 = fcn.18046b63c(uVar3);
                *(undefined8 *)(&stack0x00000040 + iVar6 + iVar4 + iVar5) = 0x18047ca54;
                puVar7 = (undefined4 *)fcn.18046b77c();
                *puVar7 = uVar3;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_180200960
// Address: 0x180200960
// Size: 82 bytes
// ============================================================
void fcn.180200960(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 uVar6;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020096c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200981;
    fcn.180228b10(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                  *(int64_t *)(&stack0x00000038 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200991;
    fcn.180228b10(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                  *(int64_t *)(&stack0x00000038 + iVar3));
    **(int64_t **)(param_1 + 0x28) = **(int64_t **)(param_1 + 0x28) + -1;
    uVar6 = *(undefined8 *)((int64_t)auStackX_18 + iVar3);
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x18022499a;
    iVar4 = fcn.18045a350(param_1, 0x1804b98f0, 0xe9);
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (param_1 != 0) {
            *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = uVar6;
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_1802009c0
// Address: 0x1802009c0
// Size: 291 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1802009c0(int64_t arg_30h, int64_t arg_78h, int64_t arg_88h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    undefined8 *in_RCX;
    uint64_t uVar12;
    uint32_t in_R8D;
    undefined4 *in_R9;
    bool bVar13;
    bool bVar14;
    undefined auStackX_8 [4];
    int64_t var_ch;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1802009d6;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(uint64_t *)((int64_t)&arg_30h + iVar9) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar9);
    puVar1 = *(undefined8 **)((int64_t)&arg_88h + iVar9);
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x1802009fe;
    iVar10 = func_0x000180200b70();
    if (iVar10 != 0) {
        if (in_R8D == 1) {
            bVar13 = false;
            bVar14 = *(int64_t *)(iVar10 + 0x20) == 0;
        } else {
            bVar13 = *(uint64_t *)(iVar10 + 0x20) < 0x3fffffffffffffff;
            bVar14 = *(uint64_t *)(iVar10 + 0x20) == 0x3fffffffffffffff;
        }
        if (bVar13 || bVar14) {
            uVar12 = 0;
            do {
                if (7 < uVar12) goto code_r0x000180200ac2;
                uVar2 = in_RCX[5];
                uVar3 = *in_RCX;
                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x180200a4f;
                iVar8 = func_0x0001801f99a0(uVar3, uVar2, in_R9);
                if (iVar8 == 0) goto code_r0x000180200ac2;
                uVar4 = *in_R9;
                uVar5 = in_R9[1];
                uVar6 = in_R9[2];
                uVar7 = in_R9[3];
                *(undefined4 *)(auStackX_8 + iVar9) = in_R9[4];
                *(undefined *)((int64_t)&var_ch + iVar9) = *(undefined *)(in_R9 + 5);
                *(undefined8 **)((int64_t)&var_18h + iVar9) = in_RCX + 1;
                *(undefined4 *)((int64_t)&var_8h + iVar9) = uVar4;
                *(undefined4 *)((int64_t)&var_8h + iVar9 + 4) = uVar5;
                *(undefined4 *)(&stack0x00000000 + iVar9) = uVar6;
                *(undefined4 *)(&stack0x00000004 + iVar9) = uVar7;
                *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x180200a81;
                iVar11 = fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar9));
                uVar12 = uVar12 + 1;
            } while (iVar11 != 0);
            *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x180200a94;
            iVar11 = fcn.1802007e0(*(int64_t *)((int64_t)&var_8h + iVar9), *(int64_t *)(&stack0x00000000 + iVar9), 
                                   *(int64_t *)(auStackX_8 + iVar9));
            if (iVar11 != 0) {
                uVar2 = *(undefined8 *)(iVar10 + 0x20);
                *(undefined8 *)(iVar11 + 0x18) = uVar2;
                *(uint32_t *)(iVar11 + 0x30) =
                     *(uint32_t *)(iVar11 + 0x30) ^ (*(uint32_t *)(iVar11 + 0x30) ^ in_R8D) & 3;
                if (puVar1 != (undefined8 *)0x0) {
                    *puVar1 = uVar2;
                }
                *(int64_t *)(iVar10 + 0x20) = *(int64_t *)(iVar10 + 0x20) + 1;
            }
        }
    }
code_r0x000180200ac2:
    *(undefined8 *)((int64_t)&uStack_30 + iVar9) = 0x180200acf;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_30h + iVar9) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar9));
    return;
}

// ============================================================
// Function: FUN_180200af0
// Address: 0x180200af0
// Size: 120 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h

void fcn.180200af0(int64_t arg_30h, int64_t arg_40h, int64_t arg_58h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined4 *in_RDX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180200afa;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_58h + iVar5) = *(uint64_t *)0x1806a3940 ^ (int64_t)&stack0x00000000 + iVar5;
    uVar1 = *in_RDX;
    uVar2 = in_RDX[1];
    uVar3 = in_RDX[2];
    uVar4 = in_RDX[3];
    *(undefined4 *)((int64_t)&arg_30h + iVar5) = in_RDX[4];
    *(undefined *)((int64_t)&arg_30h + iVar5 + 4) = *(undefined *)(in_RDX + 5);
    *(int64_t *)((int64_t)&arg_40h + iVar5) = in_RCX + 8;
    *(undefined4 *)((int64_t)&var_20h + iVar5) = uVar1;
    *(undefined4 *)((int64_t)&var_20h + iVar5 + 4) = uVar2;
    *(undefined4 *)(&stack0x00000028 + iVar5) = uVar3;
    *(undefined4 *)(&stack0x0000002c + iVar5) = uVar4;
    if (0x14 < (uint8_t)uVar1) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x180200b43;
        fcn.180459870(*(uint64_t *)((int64_t)&arg_58h + iVar5) ^ (int64_t)&stack0x00000000 + iVar5);
        return;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x180200b56;
    fcn.180229240(*(int64_t *)(&stack0x00000028 + iVar5));
    *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x180200b63;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_58h + iVar5) ^ (int64_t)&stack0x00000000 + iVar5);
    return;
}

// ============================================================
// Function: FUN_180200b70
// Address: 0x180200b70
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180200b70(int64_t arg_28h, int64_t arg_38h, int64_t arg_68h, int64_t arg_70h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180200b80;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200b9c;
    iVar4 = fcn.180229240(*(int64_t *)((int64_t)&iStackX_20 + iVar3));
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&arg_68h + iVar3) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200bc1;
        iVar4 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200be0;
            fcn.180229130(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&iStackX_20 + iVar3 + -8) = 0x180195290;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c09;
            iVar5 = fcn.180229290(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
            *(int64_t *)(iVar4 + 8) = iVar5;
            if (iVar5 != 0) {
                *(undefined8 *)(iVar4 + 0x10) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c22;
                fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar3));
                uVar1 = *(undefined8 *)(in_RCX + 0x20);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c2b;
                iVar2 = fcn.180228e00(uVar1);
                if (iVar2 == 0) {
                    return iVar4;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c4b;
            fcn.180228ec0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c60;
            fcn.180224990(iVar4, 0x1804b98f0, 0xde);
        }
        iVar4 = 0;
    }
    return iVar4;
}

// ============================================================
// Function: FUN_180200bab
// Address: 0x180200bab
// Size: 151 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180200b70(int64_t arg_28h, int64_t arg_38h, int64_t arg_68h, int64_t arg_70h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180200b80;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200b9c;
    iVar4 = fcn.180229240(*(int64_t *)((int64_t)&iStackX_20 + iVar3));
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&arg_68h + iVar3) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200bc1;
        iVar4 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200be0;
            fcn.180229130(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&iStackX_20 + iVar3 + -8) = 0x180195290;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c09;
            iVar5 = fcn.180229290(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
            *(int64_t *)(iVar4 + 8) = iVar5;
            if (iVar5 != 0) {
                *(undefined8 *)(iVar4 + 0x10) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c22;
                fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar3));
                uVar1 = *(undefined8 *)(in_RCX + 0x20);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c2b;
                iVar2 = fcn.180228e00(uVar1);
                if (iVar2 == 0) {
                    return iVar4;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c4b;
            fcn.180228ec0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c60;
            fcn.180224990(iVar4, 0x1804b98f0, 0xde);
        }
        iVar4 = 0;
    }
    return iVar4;
}

// ============================================================
// Function: FUN_180200c42
// Address: 0x180200c42
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180200b70(int64_t arg_28h, int64_t arg_38h, int64_t arg_68h, int64_t arg_70h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180200b80;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200b9c;
    iVar4 = fcn.180229240(*(int64_t *)((int64_t)&iStackX_20 + iVar3));
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&arg_68h + iVar3) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200bc1;
        iVar4 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200be0;
            fcn.180229130(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&iStackX_20 + iVar3 + -8) = 0x180195290;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c09;
            iVar5 = fcn.180229290(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
            *(int64_t *)(iVar4 + 8) = iVar5;
            if (iVar5 != 0) {
                *(undefined8 *)(iVar4 + 0x10) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c22;
                fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar3));
                uVar1 = *(undefined8 *)(in_RCX + 0x20);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c2b;
                iVar2 = fcn.180228e00(uVar1);
                if (iVar2 == 0) {
                    return iVar4;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c4b;
            fcn.180228ec0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c60;
            fcn.180224990(iVar4, 0x1804b98f0, 0xde);
        }
        iVar4 = 0;
    }
    return iVar4;
}

// ============================================================
// Function: FUN_180200c67
// Address: 0x180200c67
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180200b70(int64_t arg_28h, int64_t arg_38h, int64_t arg_68h, int64_t arg_70h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180200b80;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200b9c;
    iVar4 = fcn.180229240(*(int64_t *)((int64_t)&iStackX_20 + iVar3));
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&arg_68h + iVar3) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200bc1;
        iVar4 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200be0;
            fcn.180229130(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&iStackX_20 + iVar3 + -8) = 0x180195290;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c09;
            iVar5 = fcn.180229290(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
            *(int64_t *)(iVar4 + 8) = iVar5;
            if (iVar5 != 0) {
                *(undefined8 *)(iVar4 + 0x10) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c22;
                fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar3));
                uVar1 = *(undefined8 *)(in_RCX + 0x20);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c2b;
                iVar2 = fcn.180228e00(uVar1);
                if (iVar2 == 0) {
                    return iVar4;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c4b;
            fcn.180228ec0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180200c60;
            fcn.180224990(iVar4, 0x1804b98f0, 0xde);
        }
        iVar4 = 0;
    }
    return iVar4;
}

// ============================================================
// Function: FUN_180200c80
// Address: 0x180200c80
// Size: 162 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h

undefined8 fcn.180200c80(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180200c95;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_R8 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180200cae;
        iVar3 = fcn.180200af0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2));
        if (iVar3 != 0) {
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180200cbe;
    iVar3 = fcn.180200b70(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                          *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180200cd4;
        iVar4 = fcn.1802007e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2));
        if (iVar4 != 0) {
            uVar1 = *(undefined8 *)(iVar3 + 0x20);
            *(uint32_t *)(iVar4 + 0x30) = *(uint32_t *)(iVar4 + 0x30) & 0xfffffffd;
            *(uint32_t *)(iVar4 + 0x30) = *(uint32_t *)(iVar4 + 0x30) | 1;
            *(undefined8 *)(iVar4 + 0x18) = uVar1;
            *(int64_t *)(iVar3 + 0x20) = *(int64_t *)(iVar3 + 0x20) + 1;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180200ce7;
        fcn.1802008d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    }
    return 0;
}

// ============================================================
// Function: FUN_180200d30
// Address: 0x180200d30
// Size: 70 bytes
// ============================================================
undefined8 fcn.180200d30(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 in_RDX;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180200d3c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180200d55;
    iVar2 = fcn.180229240(*(int64_t *)((int64_t)&iStackX_20 + iVar1));
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180200d6b;
    fcn.1802008d0(*(int64_t *)((int64_t)&iStackX_20 + iVar1 + -8));
    return 1;
}

// ============================================================
// Function: FUN_180200d80
// Address: 0x180200d80
// Size: 192 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

void fcn.180200d80(int64_t arg_28h, int64_t arg_40h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined4 *in_R8;
    int64_t var_8h;
    undefined8 uStackX_10;
    undefined var_18h [4];
    int64_t var_1ch;
    undefined8 uStack_20;
    
    uStack_20 = 0x180200d8e;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_40h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar6);
    if ((in_R8 != (undefined4 *)0x0) && ((uint8_t)(*(char *)in_R8 - 8U) < 0xd)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180200dba;
        iVar7 = fcn.180200b70(*(int64_t *)((int64_t)&uStackX_10 + iVar6 + -8), *(int64_t *)(var_18h + iVar6), 
                              *(int64_t *)(&stack0x00000048 + iVar6), *(int64_t *)(&stack0x00000050 + iVar6));
        if ((iVar7 != 0) && ((*(uint8_t *)(iVar7 + 0x28) & 1) == 0)) {
            uVar1 = in_R8[4];
            uVar2 = *in_R8;
            uVar3 = in_R8[1];
            uVar4 = in_R8[2];
            uVar5 = in_R8[3];
            *(char *)((int64_t)&var_1ch + iVar6) = *(char *)(in_R8 + 5);
            *(undefined4 *)(var_18h + iVar6) = uVar1;
            *(int64_t *)((int64_t)&arg_28h + iVar6) = in_RCX + 8;
            *(undefined4 *)((int64_t)&uStackX_10 + iVar6 + -8) = uVar2;
            *(undefined4 *)((int64_t)&uStackX_10 + iVar6 + -4) = uVar3;
            *(undefined4 *)((int64_t)&uStackX_10 + iVar6) = uVar4;
            *(undefined4 *)(var_18h + iVar6 + -4) = uVar5;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180200df6;
            iVar8 = fcn.180229240(*(int64_t *)((int64_t)&uStackX_10 + iVar6));
            if (iVar8 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180200e09;
                iVar8 = fcn.1802007e0(*(int64_t *)((int64_t)&uStackX_10 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&uStackX_10 + iVar6), *(int64_t *)(var_18h + iVar6));
                if (iVar8 != 0) {
                    *(uint32_t *)(iVar8 + 0x30) = *(uint32_t *)(iVar8 + 0x30) & 0xfffffffc;
                    *(undefined8 *)(iVar8 + 0x18) = 0xffffffffffffffff;
                    *(uint32_t *)(iVar7 + 0x28) = *(uint32_t *)(iVar7 + 0x28) | 1;
                    *(int64_t *)(iVar7 + 0x18) = iVar8;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180200e38;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_40h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_180200e40
// Address: 0x180200e40
// Size: 97 bytes
// ============================================================
void fcn.180200e40(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180200e50;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        uVar1 = *(undefined8 *)(arg1 + 0x20);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180200e61;
        fcn.180229280(uVar1, 0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180200e74;
        fcn.180228ce0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180200e7d;
        fcn.180228ec0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180200e86;
        fcn.180228ec0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180200e9b;
        fcn.180224990(arg1, 0x1804b98f0, 0xad);
    }
    return;
}

// ============================================================
// Function: FUN_180200eb0
// Address: 0x180200eb0
// Size: 41 bytes
// ============================================================
void fcn.180200eb0(void)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180200eba;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180200ed4;
    fcn.1802009c0(*(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000070 + iVar1), 
                  *(int64_t *)(&stack0x00000080 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180200ee0
// Address: 0x180200ee0
// Size: 173 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch

void fcn.180200ee0(int64_t arg_28h, int64_t arg_38h, int64_t arg_50h, int64_t arg_58h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 *in_RCX;
    undefined4 *in_RDX;
    int32_t iVar10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180200ef5;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_50h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar8);
    iVar10 = 0;
    do {
        uVar1 = in_RCX[5];
        uVar2 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180200f1f;
        iVar7 = func_0x0001801f99a0(uVar2, uVar1, in_RDX);
        if (iVar7 != 0) {
            uVar3 = *in_RDX;
            uVar4 = in_RDX[1];
            uVar5 = in_RDX[2];
            uVar6 = in_RDX[3];
            *(undefined4 *)((int64_t)&arg_28h + iVar8) = in_RDX[4];
            *(undefined *)((int64_t)&arg_28h + iVar8 + 4) = *(undefined *)(in_RDX + 5);
            *(undefined8 **)((int64_t)&arg_38h + iVar8) = in_RCX + 1;
            *(undefined4 *)((int64_t)&var_18h + iVar8) = uVar3;
            *(undefined4 *)((int64_t)&var_18h + iVar8 + 4) = uVar4;
            *(undefined4 *)((int64_t)&var_20h + iVar8) = uVar5;
            *(undefined4 *)((int64_t)&var_20h + iVar8 + 4) = uVar6;
            if (0x14 < (uint8_t)uVar3) break;
            *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180200f59;
            iVar9 = fcn.180229240(*(int64_t *)((int64_t)&var_20h + iVar8));
            if (iVar9 == 0) break;
        }
        iVar10 = iVar10 + 1;
    } while (iVar10 < 10);
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x180200f74;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_50h + iVar8) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_180200f90
// Address: 0x180200f90
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h

undefined8 fcn.180200f90(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t in_RDX;
    undefined8 *in_R8;
    undefined8 *in_R9;
    int64_t var_8h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180200fa0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180200fb3;
        iVar1 = fcn.180200af0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                              *(int64_t *)(&stack0x00000048 + iVar1));
        if (iVar1 != 0) {
            if (in_R8 != (undefined8 *)0x0) {
                *in_R8 = *(undefined8 *)(iVar1 + 0x18);
            }
            if (in_R9 != (undefined8 *)0x0) {
                *in_R9 = *(undefined8 *)(*(int64_t *)(iVar1 + 0x28) + 0x10);
            }
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180201000
// Address: 0x180201000
// Size: 322 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.180201000(int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180201015;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RDX < 0x15) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020103c;
        puVar3 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8));
        if (puVar3 != (undefined8 *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020105d;
            iVar1 = fcn.18021b9c0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                                  *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180201078;
                fcn.180229130(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar2));
                *(undefined8 *)((int64_t)&iStackX_20 + iVar2 + -8) = 0x180195290;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802010a1;
                iVar4 = fcn.180229290(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8));
                puVar3[3] = iVar4;
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802010bd;
                    fcn.180229130(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar2));
                    *(undefined8 *)((int64_t)&iStackX_20 + iVar2 + -8) = 0x180195290;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802010e6;
                    iVar4 = fcn.180229290(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8));
                    puVar3[4] = iVar4;
                    if (iVar4 != 0) {
                        *puVar3 = in_RCX;
                        puVar3[5] = in_RDX;
                        return puVar3;
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180201112;
            fcn.180228ec0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020111b;
            fcn.180228ec0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180201130;
            fcn.180224990(puVar3, 0x1804b98f0, 0x85);
        }
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_180201150
// Address: 0x180201150
// Size: 36 bytes
// ============================================================
int32_t fcn.180201150(int64_t param_1, int64_t param_2)
{
    uint32_t uVar1;
    uint64_t uVar2;
    uint64_t *puVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    bool bVar7;
    
    fcn.18045a350();
    puVar3 = (uint64_t *)(param_1 + 0x30);
    uVar5 = 0x10;
    iVar4 = (param_2 + 0x30) - (int64_t)puVar3;
    for (; ((uint64_t)puVar3 & 7) != 0; puVar3 = (uint64_t *)((int64_t)puVar3 + 1)) {
        bVar7 = *(uint8_t *)puVar3 < *(uint8_t *)((int64_t)puVar3 + iVar4);
        if (*(uint8_t *)puVar3 != *(uint8_t *)((int64_t)puVar3 + iVar4)) goto code_r0x000180497f73;
        uVar5 = uVar5 - 1;
    }
    if (uVar5 >> 3 != 0) {
        uVar6 = uVar5 >> 5;
        if (uVar6 != 0) {
            do {
                uVar2 = *puVar3;
                if (uVar2 != *(uint64_t *)((int64_t)puVar3 + iVar4)) goto code_r0x000180497fe4;
                uVar2 = puVar3[1];
                if (uVar2 != *(uint64_t *)((int64_t)puVar3 + iVar4 + 8)) {
code_r0x000180497fe0:
                    puVar3 = puVar3 + 1;
                    goto code_r0x000180497fe4;
                }
                uVar2 = puVar3[2];
                if (uVar2 != *(uint64_t *)((int64_t)puVar3 + iVar4 + 0x10)) {
code_r0x000180497fdc:
                    puVar3 = puVar3 + 1;
                    goto code_r0x000180497fe0;
                }
                uVar2 = puVar3[3];
                if (uVar2 != *(uint64_t *)((int64_t)puVar3 + iVar4 + 0x18)) {
                    puVar3 = puVar3 + 1;
                    goto code_r0x000180497fdc;
                }
                puVar3 = puVar3 + 4;
                uVar6 = uVar6 - 1;
            } while (uVar6 != 0);
            uVar5 = uVar5 & 0x1f;
        }
        uVar6 = uVar5 >> 3;
        if (uVar6 != 0) {
            do {
                uVar2 = *puVar3;
                if (uVar2 != *(uint64_t *)((int64_t)puVar3 + iVar4)) {
code_r0x000180497fe4:
                    uVar5 = *(uint64_t *)(iVar4 + (int64_t)puVar3);
                    uVar1 = (uint32_t)
                            ((uVar2 >> 0x38 | (uVar2 & 0xff000000000000) >> 0x28 | (uVar2 & 0xff0000000000) >> 0x18 |
                              (uVar2 & 0xff00000000) >> 8 | (uVar2 & 0xff000000) << 8 | (uVar2 & 0xff0000) << 0x18 |
                              (uVar2 & 0xff00) << 0x28 | uVar2 << 0x38) <
                            (uVar5 >> 0x38 | (uVar5 & 0xff000000000000) >> 0x28 | (uVar5 & 0xff0000000000) >> 0x18 |
                             (uVar5 & 0xff00000000) >> 8 | (uVar5 & 0xff000000) << 8 | (uVar5 & 0xff0000) << 0x18 |
                             (uVar5 & 0xff00) << 0x28 | uVar5 << 0x38));
                    return (1 - uVar1) - (uint32_t)(uVar1 != 0);
                }
                puVar3 = puVar3 + 1;
                uVar6 = uVar6 - 1;
            } while (uVar6 != 0);
            uVar5 = uVar5 & 7;
        }
    }
    while( true ) {
        if (uVar5 == 0) {
            return 0;
        }
        bVar7 = *(uint8_t *)puVar3 < *(uint8_t *)((int64_t)puVar3 + iVar4);
        if (*(uint8_t *)puVar3 != *(uint8_t *)((int64_t)puVar3 + iVar4)) break;
        puVar3 = (uint64_t *)((int64_t)puVar3 + 1);
        uVar5 = uVar5 - 1;
    }
code_r0x000180497f73:
    return (1 - (uint32_t)bVar7) - (uint32_t)(bVar7 != 0);
}

// ============================================================
// Function: FUN_180201190
// Address: 0x180201190
// Size: 519 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180201190(int64_t arg_48h, int64_t arg_98h)
{
    int64_t *piVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t **ppiVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t **ppiVar9;
    int64_t iVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    int64_t in_RCX;
    int64_t **ppiVar13;
    int64_t *in_RDX;
    int64_t *in_R8;
    undefined8 uVar14;
    undefined4 *in_R9;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1802011a6;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_48h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar7);
    if ((*(uint8_t *)(in_RCX + 0x18) & 1) != 0) goto code_r0x00018020125a;
    *(int64_t **)((int64_t)&var_18h + iVar7) = in_RDX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802011e1;
    iVar8 = fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar7));
    for (iVar10 = iVar8; iVar10 != 0; iVar10 = *(int64_t *)(iVar10 + 8)) {
        if (*(int64_t **)(iVar10 + 0x18) == in_R8) goto code_r0x00018020125a;
        if (*(int64_t **)(iVar10 + 0x18) < in_R8) break;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180201218;
    ppiVar9 = (int64_t **)fcn.180224d60(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7));
    if (ppiVar9 == (int64_t **)0x0) goto code_r0x00018020125a;
    ppiVar9[2] = in_RDX;
    ppiVar9[3] = in_R8;
    uVar2 = in_R9[1];
    uVar3 = in_R9[2];
    uVar4 = in_R9[3];
    *(undefined4 *)(ppiVar9 + 4) = *in_R9;
    *(undefined4 *)((int64_t)ppiVar9 + 0x24) = uVar2;
    *(undefined4 *)(ppiVar9 + 5) = uVar3;
    *(undefined4 *)((int64_t)ppiVar9 + 0x2c) = uVar4;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18020123f;
    iVar6 = func_0x000180201920(in_RCX, ppiVar9);
    if (iVar6 == 0) {
        uVar14 = 0x12d;
code_r0x000180201249:
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180201258;
        fcn.180224990(ppiVar9, 0x1804b9908, uVar14);
    } else {
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18020128f;
            fcn.180228fb0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                          *(int64_t *)((int64_t)&var_18h + iVar7));
            uVar14 = *(undefined8 *)(in_RCX + 8);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18020129b;
            iVar6 = func_0x0001802018e0(in_RCX, uVar14);
            if (iVar6 == 0) {
                uVar14 = 0x136;
                goto code_r0x000180201249;
            }
        } else {
            piVar1 = ppiVar9[3];
            ppiVar11 = (int64_t **)(&stack0xfffffffffffffff8 + iVar7);
            *(int64_t *)(&stack0xfffffffffffffff8 + iVar7) = iVar8;
            iVar10 = iVar8;
            do {
                if (*(int64_t **)(iVar10 + 0x18) <= piVar1) break;
                ppiVar11 = (int64_t **)(iVar10 + 8);
                iVar10 = *(int64_t *)(iVar10 + 8);
            } while (iVar10 != 0);
            ppiVar9[1] = *ppiVar11;
            *ppiVar11 = (int64_t *)ppiVar9;
            if (*(int64_t *)(&stack0xfffffffffffffff8 + iVar7) != iVar8) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802012e8;
                fcn.180228fb0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7));
                uVar14 = *(undefined8 *)(in_RCX + 8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1802012f4;
                iVar6 = func_0x0001802018e0(in_RCX, uVar14);
                if (iVar6 == 0) {
                    uVar14 = 0x13e;
                    goto code_r0x000180201249;
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18020130f;
        ppiVar11 = (int64_t **)fcn.180229240(*(int64_t *)(&stack0x00000000 + iVar7));
        if (ppiVar11 == (int64_t **)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180201323;
            fcn.180228fb0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                          *(int64_t *)((int64_t)&var_18h + iVar7));
            uVar14 = *(undefined8 *)(in_RCX + 0x10);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18020132f;
            func_0x0001802018e0(in_RCX, uVar14);
        } else {
            piVar1 = ppiVar9[2];
            *(int64_t ***)(&stack0xfffffffffffffff8 + iVar7) = ppiVar11;
            ppiVar5 = ppiVar11;
            ppiVar13 = (int64_t **)(&stack0xfffffffffffffff8 + iVar7);
            do {
                ppiVar12 = ppiVar5;
                if (ppiVar12[2] <= piVar1) break;
                ppiVar5 = (int64_t **)*ppiVar12;
                ppiVar13 = ppiVar12;
            } while (*ppiVar12 != (int64_t *)0x0);
            *ppiVar9 = *ppiVar13;
            *ppiVar13 = (int64_t *)ppiVar9;
            if (*(int64_t ***)(&stack0xfffffffffffffff8 + iVar7) != ppiVar11) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x18020137d;
                fcn.180228fb0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7));
                uVar14 = *(undefined8 *)(in_RCX + 0x10);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180201389;
                func_0x0001802018e0(in_RCX, uVar14);
            }
        }
    }
code_r0x00018020125a:
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x180201267;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_48h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar7));
    return;
}

// ============================================================
// Function: FUN_1802013a0
// Address: 0x1802013a0
// Size: 60 bytes
// ============================================================
void fcn.1802013a0(int64_t arg_28h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_98h, int64_t arg_100h
                  )
{
    uint8_t uVar1;
    int64_t **ppiVar2;
    undefined8 uVar3;
    int64_t **ppiVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802013ac;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_58h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6);
    uVar1 = *(uint8_t *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = in_RDX;
    if ((uVar1 & 1) == 0) {
        *(undefined8 *)((int64_t)&arg_98h + iVar6) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802013e9;
        ppiVar7 = (int64_t **)fcn.180229240(*(int64_t *)((int64_t)&iStackX_20 + iVar6));
        if (ppiVar7 != (int64_t **)0x0) {
            *(undefined8 *)((int64_t)&arg_70h + iVar6) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_68h + iVar6) = unaff_RDI;
            ppiVar8 = ppiVar7;
            do {
                ppiVar2 = (int64_t **)ppiVar8[1];
                if (ppiVar8 != ppiVar7) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201416;
                    func_0x0001802019d0(in_RCX, ppiVar8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020142b;
                    fcn.180224990(ppiVar8, 0x1804b9908, 0x1af);
                }
                ppiVar8 = ppiVar2;
            } while (ppiVar2 != (int64_t **)0x0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201449;
            fcn.180228b10(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                          *(int64_t *)(&stack0x00000038 + iVar6));
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201455;
            ppiVar8 = (int64_t **)fcn.180229240(*(int64_t *)((int64_t)&iStackX_20 + iVar6));
            if (ppiVar8 == ppiVar7) {
                if (*ppiVar7 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201489;
                    fcn.180228b10(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6));
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020146e;
                    fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6));
                    uVar3 = *(undefined8 *)(in_RCX + 0x10);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201477;
                    iVar5 = fcn.180228e00(uVar3);
                    if (iVar5 != 0) {
                        *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 1;
                    }
                }
            } else {
                ppiVar2 = (int64_t **)*ppiVar8;
                while (ppiVar4 = ppiVar2, ppiVar4 != ppiVar7) {
                    ppiVar8 = ppiVar4;
                    ppiVar2 = (int64_t **)*ppiVar4;
                }
                *ppiVar8 = *ppiVar7;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802014c9;
            fcn.180224990(ppiVar7, 0x1804b9908, 0x1b5);
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802014e3;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_58h + iVar6) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1802013dc
// Address: 0x1802013dc
// Size: 25 bytes
// ============================================================
void fcn.1802013a0(int64_t arg_28h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_98h, int64_t arg_100h
                  )
{
    uint8_t uVar1;
    int64_t **ppiVar2;
    undefined8 uVar3;
    int64_t **ppiVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802013ac;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_58h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6);
    uVar1 = *(uint8_t *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = in_RDX;
    if ((uVar1 & 1) == 0) {
        *(undefined8 *)((int64_t)&arg_98h + iVar6) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802013e9;
        ppiVar7 = (int64_t **)fcn.180229240(*(int64_t *)((int64_t)&iStackX_20 + iVar6));
        if (ppiVar7 != (int64_t **)0x0) {
            *(undefined8 *)((int64_t)&arg_70h + iVar6) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_68h + iVar6) = unaff_RDI;
            ppiVar8 = ppiVar7;
            do {
                ppiVar2 = (int64_t **)ppiVar8[1];
                if (ppiVar8 != ppiVar7) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201416;
                    func_0x0001802019d0(in_RCX, ppiVar8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020142b;
                    fcn.180224990(ppiVar8, 0x1804b9908, 0x1af);
                }
                ppiVar8 = ppiVar2;
            } while (ppiVar2 != (int64_t **)0x0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201449;
            fcn.180228b10(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                          *(int64_t *)(&stack0x00000038 + iVar6));
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201455;
            ppiVar8 = (int64_t **)fcn.180229240(*(int64_t *)((int64_t)&iStackX_20 + iVar6));
            if (ppiVar8 == ppiVar7) {
                if (*ppiVar7 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201489;
                    fcn.180228b10(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6));
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020146e;
                    fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6));
                    uVar3 = *(undefined8 *)(in_RCX + 0x10);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201477;
                    iVar5 = fcn.180228e00(uVar3);
                    if (iVar5 != 0) {
                        *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 1;
                    }
                }
            } else {
                ppiVar2 = (int64_t **)*ppiVar8;
                while (ppiVar4 = ppiVar2, ppiVar4 != ppiVar7) {
                    ppiVar8 = ppiVar4;
                    ppiVar2 = (int64_t **)*ppiVar4;
                }
                *ppiVar8 = *ppiVar7;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802014c9;
            fcn.180224990(ppiVar7, 0x1804b9908, 0x1b5);
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802014e3;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_58h + iVar6) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1802013f5
// Address: 0x1802013f5
// Size: 104 bytes
// ============================================================
void fcn.1802013a0(int64_t arg_28h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_98h, int64_t arg_100h
                  )
{
    uint8_t uVar1;
    int64_t **ppiVar2;
    undefined8 uVar3;
    int64_t **ppiVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802013ac;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_58h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6);
    uVar1 = *(uint8_t *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = in_RDX;
    if ((uVar1 & 1) == 0) {
        *(undefined8 *)((int64_t)&arg_98h + iVar6) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802013e9;
        ppiVar7 = (int64_t **)fcn.180229240(*(int64_t *)((int64_t)&iStackX_20 + iVar6));
        if (ppiVar7 != (int64_t **)0x0) {
            *(undefined8 *)((int64_t)&arg_70h + iVar6) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_68h + iVar6) = unaff_RDI;
            ppiVar8 = ppiVar7;
            do {
                ppiVar2 = (int64_t **)ppiVar8[1];
                if (ppiVar8 != ppiVar7) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201416;
                    func_0x0001802019d0(in_RCX, ppiVar8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020142b;
                    fcn.180224990(ppiVar8, 0x1804b9908, 0x1af);
                }
                ppiVar8 = ppiVar2;
            } while (ppiVar2 != (int64_t **)0x0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201449;
            fcn.180228b10(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                          *(int64_t *)(&stack0x00000038 + iVar6));
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201455;
            ppiVar8 = (int64_t **)fcn.180229240(*(int64_t *)((int64_t)&iStackX_20 + iVar6));
            if (ppiVar8 == ppiVar7) {
                if (*ppiVar7 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201489;
                    fcn.180228b10(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6));
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020146e;
                    fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6));
                    uVar3 = *(undefined8 *)(in_RCX + 0x10);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201477;
                    iVar5 = fcn.180228e00(uVar3);
                    if (iVar5 != 0) {
                        *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 1;
                    }
                }
            } else {
                ppiVar2 = (int64_t **)*ppiVar8;
                while (ppiVar4 = ppiVar2, ppiVar4 != ppiVar7) {
                    ppiVar8 = ppiVar4;
                    ppiVar2 = (int64_t **)*ppiVar4;
                }
                *ppiVar8 = *ppiVar7;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802014c9;
            fcn.180224990(ppiVar7, 0x1804b9908, 0x1b5);
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802014e3;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_58h + iVar6) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_18020145d
// Address: 0x18020145d
// Size: 121 bytes
// ============================================================
void fcn.1802013a0(int64_t arg_28h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_98h, int64_t arg_100h
                  )
{
    uint8_t uVar1;
    int64_t **ppiVar2;
    undefined8 uVar3;
    int64_t **ppiVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802013ac;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_58h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6);
    uVar1 = *(uint8_t *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = in_RDX;
    if ((uVar1 & 1) == 0) {
        *(undefined8 *)((int64_t)&arg_98h + iVar6) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802013e9;
        ppiVar7 = (int64_t **)fcn.180229240(*(int64_t *)((int64_t)&iStackX_20 + iVar6));
        if (ppiVar7 != (int64_t **)0x0) {
            *(undefined8 *)((int64_t)&arg_70h + iVar6) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_68h + iVar6) = unaff_RDI;
            ppiVar8 = ppiVar7;
            do {
                ppiVar2 = (int64_t **)ppiVar8[1];
                if (ppiVar8 != ppiVar7) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201416;
                    func_0x0001802019d0(in_RCX, ppiVar8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020142b;
                    fcn.180224990(ppiVar8, 0x1804b9908, 0x1af);
                }
                ppiVar8 = ppiVar2;
            } while (ppiVar2 != (int64_t **)0x0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201449;
            fcn.180228b10(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                          *(int64_t *)(&stack0x00000038 + iVar6));
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201455;
            ppiVar8 = (int64_t **)fcn.180229240(*(int64_t *)((int64_t)&iStackX_20 + iVar6));
            if (ppiVar8 == ppiVar7) {
                if (*ppiVar7 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201489;
                    fcn.180228b10(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6));
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020146e;
                    fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6));
                    uVar3 = *(undefined8 *)(in_RCX + 0x10);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201477;
                    iVar5 = fcn.180228e00(uVar3);
                    if (iVar5 != 0) {
                        *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 1;
                    }
                }
            } else {
                ppiVar2 = (int64_t **)*ppiVar8;
                while (ppiVar4 = ppiVar2, ppiVar4 != ppiVar7) {
                    ppiVar8 = ppiVar4;
                    ppiVar2 = (int64_t **)*ppiVar4;
                }
                *ppiVar8 = *ppiVar7;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802014c9;
            fcn.180224990(ppiVar7, 0x1804b9908, 0x1b5);
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802014e3;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_58h + iVar6) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1802014d6
// Address: 0x1802014d6
// Size: 22 bytes
// ============================================================
void fcn.1802013a0(int64_t arg_28h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_98h, int64_t arg_100h
                  )
{
    uint8_t uVar1;
    int64_t **ppiVar2;
    undefined8 uVar3;
    int64_t **ppiVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802013ac;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_58h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6);
    uVar1 = *(uint8_t *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = in_RDX;
    if ((uVar1 & 1) == 0) {
        *(undefined8 *)((int64_t)&arg_98h + iVar6) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802013e9;
        ppiVar7 = (int64_t **)fcn.180229240(*(int64_t *)((int64_t)&iStackX_20 + iVar6));
        if (ppiVar7 != (int64_t **)0x0) {
            *(undefined8 *)((int64_t)&arg_70h + iVar6) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_68h + iVar6) = unaff_RDI;
            ppiVar8 = ppiVar7;
            do {
                ppiVar2 = (int64_t **)ppiVar8[1];
                if (ppiVar8 != ppiVar7) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201416;
                    func_0x0001802019d0(in_RCX, ppiVar8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020142b;
                    fcn.180224990(ppiVar8, 0x1804b9908, 0x1af);
                }
                ppiVar8 = ppiVar2;
            } while (ppiVar2 != (int64_t **)0x0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201449;
            fcn.180228b10(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                          *(int64_t *)(&stack0x00000038 + iVar6));
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201455;
            ppiVar8 = (int64_t **)fcn.180229240(*(int64_t *)((int64_t)&iStackX_20 + iVar6));
            if (ppiVar8 == ppiVar7) {
                if (*ppiVar7 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201489;
                    fcn.180228b10(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6));
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020146e;
                    fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)(&stack0x00000038 + iVar6));
                    uVar3 = *(undefined8 *)(in_RCX + 0x10);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201477;
                    iVar5 = fcn.180228e00(uVar3);
                    if (iVar5 != 0) {
                        *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 1;
                    }
                }
            } else {
                ppiVar2 = (int64_t **)*ppiVar8;
                while (ppiVar4 = ppiVar2, ppiVar4 != ppiVar7) {
                    ppiVar8 = ppiVar4;
                    ppiVar2 = (int64_t **)*ppiVar4;
                }
                *ppiVar8 = *ppiVar7;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802014c9;
            fcn.180224990(ppiVar7, 0x1804b9908, 0x1b5);
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802014e3;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_58h + iVar6) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1802014f0
// Address: 0x1802014f0
// Size: 96 bytes
// ============================================================
void fcn.1802014f0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180201500;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020150f;
        fcn.180228ec0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        if (*(int64_t *)(arg1 + 8) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180201524;
            fcn.180228c50(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020152d;
            fcn.180228ec0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
        }
        uVar1 = *(undefined8 *)arg1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180201535;
        fcn.180211410(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020154a;
        fcn.180224990(arg1, 0x1804b9908, 0xb0);
    }
    return;
}

// ============================================================
// Function: FUN_180201550
// Address: 0x180201550
// Size: 218 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180201550(int64_t arg_28h, int64_t arg_58h, int64_t arg_68h, int64_t arg_a8h, int64_t arg_b8h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    undefined8 *in_RCX;
    undefined8 in_RDX;
    int64_t in_R8;
    undefined8 *in_R9;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180201563;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_68h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4);
    puVar1 = *(undefined8 **)((int64_t)&arg_b8h + iVar4);
    if ((*(uint8_t *)(in_RCX + 3) & 1) == 0) {
        uVar2 = *in_RCX;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 0;
        *(undefined4 *)((int64_t)&iStackX_10 + iVar4 + -8) = 0x10;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802015b4;
        iVar3 = func_0x000180212930(uVar2, (int64_t)&arg_58h + iVar4, (int64_t)&var_18h + iVar4, in_RDX);
        if ((iVar3 != 0) && (*(int32_t *)((int64_t)&var_18h + iVar4) == 0x10)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802015cd;
            puVar5 = (undefined8 *)fcn.180229240(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
            for (; in_R8 != 0; in_R8 = in_R8 + -1) {
                if (puVar5 == (undefined8 *)0x0) goto code_r0x000180201606;
                puVar5 = (undefined8 *)*puVar5;
            }
            if (puVar5 != (undefined8 *)0x0) {
                if (in_R9 != (undefined8 *)0x0) {
                    *in_R9 = puVar5[2];
                }
                if (puVar1 != (undefined8 *)0x0) {
                    *puVar1 = puVar5[3];
                }
            }
        }
    }
code_r0x000180201606:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180201616;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_68h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4));
    return;
}

