// Chunk 153 - 50 functions

// ============================================================
// Function: FUN_180203ab2
// Address: 0x180203ab2
// Size: 40 bytes
// ============================================================
void fcn.180203ab2(int64_t arg_30h)
{
    undefined8 *unaff_RSI;
    
    unaff_RSI[1] = 0;
    *unaff_RSI = 0;
    fcn.180224990();
    return;
}

// ============================================================
// Function: FUN_180203ada
// Address: 0x180203ada
// Size: 1 bytes
// ============================================================
void fcn.180203ab2(int64_t arg_30h)
{
    undefined8 *unaff_RSI;
    
    unaff_RSI[1] = 0;
    *unaff_RSI = 0;
    fcn.180224990();
    return;
}

// ============================================================
// Function: FUN_180203ae0
// Address: 0x180203ae0
// Size: 40 bytes
// ============================================================
int64_t fcn.180203ae0(int64_t arg_30h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar4 = 0x18;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1) = 0x180224d70;
    iVar2 = fcn.18045a350(0x18, 0x1804b9950, 0x24);
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar1) = 0x180224d7b;
    iVar3 = fcn.1802248d0(*(int64_t *)(&stack0x00000040 + iVar2 + iVar1), *(int64_t *)(&stack0x00000048 + iVar2 + iVar1)
                         );
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar1) = 0x180224d90;
        fcn.1804986e0(iVar3, 0, uVar4);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_180203b30
// Address: 0x180203b30
// Size: 294 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined (*) [16] fcn.180203b30(int64_t arg_28h)
{
    int64_t iVar1;
    undefined (*pauVar2) [16];
    undefined (**in_RCX) [16];
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180203b40;
    iVar1 = fcn.18045a350();
    pauVar2 = *in_RCX;
    if (pauVar2 == (undefined (*) [16])0x0) {
        *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x180203b67;
        pauVar2 = (undefined (*) [16])func_0x000180224d60(0xb0, 0x1804b9950, 99);
        if (pauVar2 == (undefined (*) [16])0x0) {
            return (undefined (*) [16])0x0;
        }
        *(undefined (**) [16])pauVar2[8] = in_RCX[1];
        *(undefined8 *)(pauVar2[8] + 8) = 0;
        in_RCX[1] = pauVar2;
        if (*(int64_t *)pauVar2[8] != 0) {
            *(undefined (**) [16])(*(int64_t *)pauVar2[8] + 0x88) = pauVar2;
        }
        if (*in_RCX == (undefined (*) [16])0x0) {
            *in_RCX = pauVar2;
        }
    }
    *pauVar2 = ZEXT816(0);
    pauVar2[1] = ZEXT816(0);
    pauVar2[2] = ZEXT816(0);
    pauVar2[3] = ZEXT816(0);
    pauVar2[4] = ZEXT816(0);
    pauVar2[5] = ZEXT816(0);
    *(undefined8 *)pauVar2[6] = 0;
    *(uint32_t *)(pauVar2[7] + 0xc) = *(uint32_t *)(pauVar2[7] + 0xc) & 0xffffffc0;
    *(undefined8 *)(pauVar2[9] + 8) = 0;
    *(undefined8 *)(pauVar2[6] + 8) = 0;
    *(undefined8 *)pauVar2[7] = 0;
    if (*in_RCX == pauVar2) {
        *in_RCX = *(undefined (**) [16])(pauVar2[8] + 8);
    }
    if (in_RCX[1] == pauVar2) {
        in_RCX[1] = *(undefined (**) [16])pauVar2[8];
    }
    if (*(int64_t *)pauVar2[8] != 0) {
        *(undefined8 *)(*(int64_t *)pauVar2[8] + 0x88) = *(undefined8 *)(pauVar2[8] + 8);
    }
    if (*(int64_t *)(pauVar2[8] + 8) != 0) {
        *(undefined8 *)(*(int64_t *)(pauVar2[8] + 8) + 0x80) = *(undefined8 *)pauVar2[8];
    }
    *(undefined8 *)(pauVar2[8] + 8) = 0;
    *(undefined8 *)pauVar2[8] = 0;
    in_RCX[2] = (undefined (*) [16])(*in_RCX[2] + 1);
    return pauVar2;
}

// ============================================================
// Function: FUN_180203c60
// Address: 0x180203c60
// Size: 248 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180203c60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    int64_t iVar7;
    undefined4 *in_RDX;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180203c7a;
    iVar5 = fcn.18045a350();
    uVar8 = *(uint64_t *)(in_RCX + 0xa0);
    if (*(uint64_t *)(in_RCX + 0x98) == uVar8) {
        if (uVar8 == 0) {
            uVar8 = 4;
        } else {
            uVar8 = (uVar8 * 8) / 5;
            if (0x200 < uVar8) {
                uVar8 = 0x200;
            }
        }
        if (*(uint64_t *)(in_RCX + 0x98) != uVar8) {
            uVar6 = *(undefined8 *)(in_RCX + 0x90);
            *(undefined8 *)((int64_t)&uStack_10 - iVar5) = 0x180203cf3;
            iVar5 = func_0x0001802249c0(uVar6, uVar8 << 5, 0x1804b9950, 0xad);
            if (iVar5 != 0) {
                *(int64_t *)(in_RCX + 0x90) = iVar5;
                *(uint64_t *)(in_RCX + 0xa0) = uVar8;
                goto code_r0x000180203d06;
            }
        }
        uVar6 = 0;
    } else {
code_r0x000180203d06:
        uVar2 = in_RDX[1];
        uVar3 = in_RDX[2];
        uVar4 = in_RDX[3];
        iVar5 = *(int64_t *)(in_RCX + 0x90);
        iVar7 = *(int64_t *)(in_RCX + 0x98) * 0x20;
        puVar1 = (undefined4 *)(iVar7 + iVar5);
        *puVar1 = *in_RDX;
        puVar1[1] = uVar2;
        puVar1[2] = uVar3;
        puVar1[3] = uVar4;
        uVar2 = in_RDX[5];
        uVar3 = in_RDX[6];
        uVar4 = in_RDX[7];
        puVar1 = (undefined4 *)(iVar7 + 0x10 + iVar5);
        *puVar1 = in_RDX[4];
        puVar1[1] = uVar2;
        puVar1[2] = uVar3;
        puVar1[3] = uVar4;
        *(int64_t *)(in_RCX + 0x98) = *(int64_t *)(in_RCX + 0x98) + 1;
        uVar6 = 1;
        *(uint32_t *)(in_RCX + 0xa8) = *(uint32_t *)(in_RCX + 0xa8) | 1;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_180203d60
// Address: 0x180203d60
// Size: 89 bytes
// ============================================================
undefined8 fcn.180203d60(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    uStack_10 = 0x180203d6c;
    iVar1 = fcn.18045a350();
    if ((*(uint8_t *)(param_1 + 0xa8) & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180203d98;
        fcn.18046f0d0(*(int64_t *)(&stack0x00000028 + -iVar1));
        *(uint32_t *)(param_1 + 0xa8) = *(uint32_t *)(param_1 + 0xa8) & 0xfffffffe;
        return *(undefined8 *)(param_1 + 0x90);
    }
    return *(undefined8 *)(param_1 + 0x90);
}

// ============================================================
// Function: FUN_180203e10
// Address: 0x180203e10
// Size: 2404 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_2f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_24fh
// WARNING: [rz-ghidra] Detected overlap for variable var_23bh

void fcn.180203e10(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_58h, int64_t arg_60h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 in_RCX;
    int64_t *in_RDX;
    undefined8 uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *in_R8;
    undefined8 uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_260h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_228h;
    int64_t var_28h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180203e2a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5);
    uVar1 = *(undefined4 *)((int64_t)in_RDX + 4);
    uVar2 = *(undefined4 *)(in_RDX + 1);
    uVar3 = *(undefined4 *)((int64_t)in_RDX + 0xc);
    *(undefined4 *)((int64_t)&arg_60h + iVar5) = *(undefined4 *)in_RDX;
    *(undefined4 *)((int64_t)&arg_60h + iVar5 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000068 + iVar5) = uVar2;
    *(undefined4 *)(&stack0x0000006c + iVar5) = uVar3;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180203e5f;
    iVar4 = func_0x0001801feb70(in_RDX, (int64_t)&var_10h + iVar5, 0);
    if (iVar4 == 0) {
        *in_R8 = -1;
        goto code_r0x0001802046d5;
    }
    // switch table (31 cases) at 0x1802046f8
    switch(*(undefined8 *)((int64_t)&var_10h + iVar5)) {
    case 0:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180203eac;
        func_0x0001801fae90(in_RCX, 0x1804b9d20, 0x1804b9d18);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180203eb4;
        uVar9 = func_0x0001801fda60(in_RDX);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180203ec6;
        func_0x0001801faf20(in_RCX, 0x1804b9d30, uVar9);
        goto code_r0x0001802046d5;
    case 1:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180203ed3;
        iVar4 = func_0x0001801fd680(in_RDX);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180203ef1;
            func_0x0001801fae90(in_RCX, 0x1804b9d20, 0x1804b9d40);
            goto code_r0x0001802046d5;
        }
        break;
    case 2:
    case 3:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180203f03;
        iVar4 = func_0x0001801fea00(in_RDX, (int64_t)&arg_50h + iVar5);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&var_20h + iVar5) = 0x20;
            *(int64_t **)((int64_t)&var_18h + iVar5) = &var_228h;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180203f34;
            iVar4 = func_0x0001801fcd10(in_RDX, 3, (int64_t)&var_18h + iVar5, (int64_t)&arg_58h + iVar5);
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180203f52;
                func_0x0001801fae90(in_RCX, 0x1804b9d20, 0x1804b9d48);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180203f77;
                func_0x0001801faf20(in_RCX, 0x1804b9d50, *(uint64_t *)((int64_t)&arg_28h + iVar5) / 1000000);
                if ((*(uint8_t *)((int64_t)&arg_48h + iVar5) & 1) != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180203f92;
                    func_0x0001801faf20(in_RCX, 0x1804b9d5c, *(undefined8 *)((int64_t)&arg_30h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180203fa6;
                    func_0x0001801faf20(in_RCX, 0x1804b9d64, *(undefined8 *)((int64_t)&arg_38h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180203fba;
                    func_0x0001801faf20(in_RCX, 0x1804b9d6c, *(undefined8 *)((int64_t)&arg_40h + iVar5));
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180203fc9;
                func_0x0001801fa090(in_RCX, 0x1804b9d70);
                uVar7 = 0;
                uVar8 = uVar7;
                if (*(int64_t *)((int64_t)&var_20h + iVar5) != 0) {
                    do {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180203fde;
                        func_0x0001801fa090(in_RCX, 0);
                        uVar9 = *(undefined8 *)(uVar8 + *(int64_t *)((int64_t)&var_18h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180203ff1;
                        func_0x0001801faf20(in_RCX, 0, uVar9);
                        if (*(int64_t *)(uVar8 + 8 + *(int64_t *)((int64_t)&var_18h + iVar5)) !=
                            *(int64_t *)(uVar8 + *(int64_t *)((int64_t)&var_18h + iVar5))) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020400b;
                            func_0x0001801faf20(in_RCX);
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204013;
                        func_0x0001801fa0c0(in_RCX);
                        uVar7 = uVar7 + 1;
                        uVar8 = uVar8 + 0x10;
                    } while (uVar7 < *(uint64_t *)((int64_t)&var_20h + iVar5));
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204029;
                func_0x0001801fa0c0(in_RCX);
                goto code_r0x0001802046d5;
            }
        }
        break;
    case 4:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020403a;
        iVar4 = func_0x0001801fd6a0(in_RDX, &var_260h);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204058;
            func_0x0001801fae90(in_RCX, 0x1804b9d20, 0x1804b9d80);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020406b;
            func_0x0001801faf20(in_RCX, 0x1804b9d90, CONCAT44(var_260h._4_4_, (uint32_t)var_260h));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020407e;
            func_0x0001801faf20(in_RCX, 0x1804b9da0, var_258h);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204091;
            func_0x0001801faf20(in_RCX, 0x1804b9db0, CONCAT71(var_250h._1_7_, (undefined)var_250h));
            goto code_r0x0001802046d5;
        }
        break;
    case 5:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802040a2;
        iVar4 = func_0x0001801fd780(in_RDX, &var_260h);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802040c0;
            func_0x0001801fae90(in_RCX, 0x1804b9d20, 0x1804b9dc0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802040d3;
            func_0x0001801faf20(in_RCX, 0x1804b9d90, CONCAT44(var_260h._4_4_, (uint32_t)var_260h));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802040e6;
            func_0x0001801faf20(in_RCX, 0x1804b9da0, var_258h);
            goto code_r0x0001802046d5;
        }
        break;
    case 6:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802040fc;
        iVar4 = func_0x0001801fd180(in_RDX, 1, &var_260h);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020411a;
            func_0x0001801fae90(in_RCX, 0x1804b9d20, 0x1804b9dd0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020412d;
            func_0x0001801faf20(in_RCX, 0x18063c880, CONCAT44(var_260h._4_4_, (uint32_t)var_260h));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204140;
            func_0x0001801faf20(in_RCX, 0x1804b9d30, var_258h);
            *in_R8 = *in_R8 + var_258h;
            goto code_r0x0001802046d5;
        }
        break;
    case 7:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802045f9;
        iVar4 = func_0x0001801fd520(in_RDX, (int64_t)&var_8h + iVar5, &var_260h);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204613;
            func_0x0001801fae90(in_RCX, 0x1804b9d20, 0x1804b9f80);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204622;
            func_0x0001801fa430(in_RCX, 0x1804b9f8c);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204631;
            func_0x0001801fa430(in_RCX, 0x1804b9f94);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204649;
            func_0x0001801fa0e0(in_RCX, 0x1804af9c4, *(undefined8 *)((int64_t)&var_8h + iVar5), 
                                CONCAT44(var_260h._4_4_, (uint32_t)var_260h));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204651;
            func_0x0001801fa460(in_RCX);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204659;
            func_0x0001801fa460(in_RCX);
            goto code_r0x0001802046d5;
        }
        break;
    case 8:
    case 9:
    case 10:
    case 0xb:
    case 0xc:
    case 0xd:
    case 0xe:
    case 0xf:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020415d;
        iVar4 = func_0x0001801fd7f0(in_RDX, 1, &var_260h);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020417b;
            func_0x0001801fae90(in_RCX, 0x1804b9d20, 0x1804b9dd8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020418e;
            func_0x0001801faf20(in_RCX, 0x1804b9d90, CONCAT44(var_260h._4_4_, (uint32_t)var_260h));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802041a1;
            func_0x0001801faf20(in_RCX, 0x18063c880, var_258h);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802041b4;
            func_0x0001801faf20(in_RCX, 0x1804b9d30, CONCAT71(var_250h._1_7_, (undefined)var_250h));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802041cc;
            func_0x0001801fa130(in_RCX, 0x1804b9de0, (uint8_t)var_240h & 1);
            if (((uint32_t)var_240h & 2) != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802041e5;
                func_0x0001801fa130(in_RCX, 0x1804b9df0, 1);
            }
            if (((uint32_t)var_240h & 1) == 0) {
                *in_R8 = -1;
            } else {
                *in_R8 = CONCAT71(var_250h._1_7_, (undefined)var_250h) + *in_R8;
            }
            goto code_r0x0001802046d5;
        }
        break;
    case 0x10:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204217;
        iVar4 = func_0x0001801fd2c0(in_RDX, (int64_t)&var_8h + iVar5);
        if (iVar4 != 0) {
            uVar9 = 0x1804b9df8;
            uVar6 = 0x1804b9d20;
code_r0x00018020422d:
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204235;
            func_0x0001801fae90(in_RCX, uVar6, uVar9);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204249;
            func_0x0001801faf20(in_RCX, 0x1804b9e08, *(undefined8 *)((int64_t)&var_8h + iVar5));
            goto code_r0x0001802046d5;
        }
        break;
    case 0x11:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802042ab;
        iVar4 = func_0x0001801fd320(in_RDX, (int64_t)&var_8h + iVar5, &var_260h);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802042c9;
            func_0x0001801fae90(in_RCX, 0x1804b9d20, 0x1804b9e50);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802042dd;
            func_0x0001801faf20(in_RCX, 0x1804b9d90, *(undefined8 *)((int64_t)&var_8h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802042f0;
            func_0x0001801faf20(in_RCX, 0x1804b9e08, CONCAT44(var_260h._4_4_, (uint32_t)var_260h));
            goto code_r0x0001802046d5;
        }
        break;
    case 0x12:
    case 0x13:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020425b;
        iVar4 = func_0x0001801fd3a0(in_RDX, (int64_t)&var_8h + iVar5);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204279;
            func_0x0001801fae90(in_RCX, 0x1804b9d20, 0x1804b9e10);
            uVar9 = 0x1804b9e30;
            if (*(int64_t *)((int64_t)&var_10h + iVar5) == 0x12) {
                uVar9 = 0x1804b9e20;
            }
            uVar6 = 0x1804b9e40;
            goto code_r0x00018020422d;
        }
        break;
    case 0x14:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204509;
        iVar4 = func_0x0001801fd240(in_RDX, &var_260h);
        if (iVar4 != 0) {
            uVar9 = 0x1804b9f48;
            uVar6 = 0x1804b9d20;
code_r0x00018020451f:
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204527;
            func_0x0001801fae90(in_RCX, uVar6, uVar9);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020453a;
            func_0x0001801faf20(in_RCX, 0x18063efe8, CONCAT44(var_260h._4_4_, (uint32_t)var_260h));
            goto code_r0x0001802046d5;
        }
        break;
    case 0x15:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204550;
        iVar4 = func_0x0001801fd950(in_RDX, &var_260h, (int64_t)&var_8h + iVar5);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020456e;
            func_0x0001801fae90(in_RCX, 0x1804b9d20, 0x1804b9f58);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204581;
            func_0x0001801faf20(in_RCX, 0x1804b9d90, CONCAT44(var_260h._4_4_, (uint32_t)var_260h));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204595;
            func_0x0001801faf20(in_RCX, 0x18063efe8, *(undefined8 *)((int64_t)&var_8h + iVar5));
            goto code_r0x0001802046d5;
        }
        break;
    case 0x16:
    case 0x17:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802045a6;
        iVar4 = func_0x0001801fd9d0(in_RDX, &var_260h);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802045c4;
            func_0x0001801fae90(in_RCX, 0x1804b9d20, 0x1804b9f70);
            uVar9 = 0x1804b9e30;
            if (*(int64_t *)((int64_t)&var_10h + iVar5) == 0x16) {
                uVar9 = 0x1804b9e20;
            }
            uVar6 = 0x1804b9e40;
            goto code_r0x00018020451f;
        }
        break;
    case 0x18:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204441;
        iVar4 = func_0x0001801fd430(in_RDX, &var_260h);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020445f;
            func_0x0001801fae90(in_RCX, 0x1804b9d20, 0x1804b9ef8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204472;
            func_0x0001801faf20(in_RCX, 0x1804b9f10, CONCAT44(var_260h._4_4_, (uint32_t)var_260h));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204485;
            func_0x0001801faf20(in_RCX, 0x1804b9f20, var_258h);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020449d;
            func_0x0001801fa0e0(in_RCX, 0x1804b7000, (int64_t)&var_250h + 1, (undefined)var_250h);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802044b6;
            func_0x0001801fa0e0(in_RCX, 0x1804b6fb8, (int64_t)&var_240h + 5, 0x10);
            goto code_r0x0001802046d5;
        }
        break;
    case 0x19:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802044c7;
        iVar4 = func_0x0001801fd720(in_RDX, &var_260h);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802044e5;
            func_0x0001801fae90(in_RCX, 0x1804b9d20, 0x1804b9f30);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802044f8;
            func_0x0001801faf20(in_RCX, 0x1804b9f10, CONCAT44(var_260h._4_4_, (uint32_t)var_260h));
            goto code_r0x0001802046d5;
        }
        break;
    case 0x1a:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204301;
        iVar4 = func_0x0001801fd5c0(in_RDX, &var_260h);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020431f;
            func_0x0001801fae90(in_RCX, 0x1804b9d20, 0x1804b9e60);
            goto code_r0x0001802046d5;
        }
        break;
    case 0x1b:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204330;
        iVar4 = func_0x0001801fd620(in_RDX, &var_260h);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020434e;
            func_0x0001801fae90(in_RCX, 0x1804b9d20, 0x1804b9e70);
            goto code_r0x0001802046d5;
        }
        break;
    case 0x1c:
    case 0x1d:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020435f;
        iVar4 = func_0x0001801fd080(in_RDX, &var_260h);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020437d;
            func_0x0001801fae90(in_RCX, 0x1804b9d20, 0x1804b9e80);
            uVar9 = 0x1804b6df8;
            if (((uint32_t)var_260h & 1) != 0) {
                uVar9 = 0x1804b9e98;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802043a2;
            func_0x0001801fae90(in_RCX, 0x1804b9ea8, uVar9);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802043b5;
            func_0x0001801faf20(in_RCX, 0x1804b9eb8, var_258h);
            if (((uint32_t)var_260h & 1) == 0) {
code_r0x0001802043d6:
                if (CONCAT71(var_250h._1_7_, (undefined)var_250h) != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802043ee;
                    func_0x0001801faf20(in_RCX, 0x1804b9ed0);
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802043cf;
                func_0x0001801faf20(in_RCX, 0x1804b9da0, var_258h);
                if (((uint32_t)var_260h & 1) == 0) goto code_r0x0001802043d6;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204405;
            func_0x0001801faed0(in_RCX, 0x180641940, var_248h, CONCAT44(var_240h._4_4_, (uint32_t)var_240h));
            goto code_r0x0001802046d5;
        }
        break;
    case 0x1e:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204412;
        iVar4 = func_0x0001801fd2a0(in_RDX);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204430;
            func_0x0001801fae90(in_RCX, 0x1804b9d20, 0x1804b9ee8);
            goto code_r0x0001802046d5;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204671;
    func_0x0001801fae90(in_RCX, 0x1804b9d20, 0x1806414d0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204685;
    func_0x0001801faf20(in_RCX, 0x1804b9f98, *(undefined8 *)((int64_t)&var_10h + iVar5));
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180204694;
    func_0x0001801fa430(in_RCX, 0x1804b9f94);
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802046bb;
    func_0x0001801fa0e0(in_RCX, 0x1804af9c4, *(undefined8 *)((int64_t)&arg_60h + iVar5), 
                        *(undefined8 *)(&stack0x00000068 + iVar5));
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802046c3;
    func_0x0001801fa460(in_RCX);
    *in_RDX = *in_RDX + in_RDX[1];
    in_RDX[1] = 0;
code_r0x0001802046d5:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802046e4;
    func_0x000180459870(var_28h ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_180204780
// Address: 0x180204780
// Size: 302 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_2f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_24fh
// WARNING: [rz-ghidra] Detected overlap for variable var_23bh

void fcn.180204780(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_98h)
{
    char cVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 in_RCX;
    uint64_t uVar9;
    uint32_t *in_RDX;
    uint64_t uVar10;
    uint64_t uVar11;
    undefined8 in_R8;
    int64_t iVar12;
    int64_t *in_R9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180204792;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047ad;
    func_0x0001801fa430();
    cVar1 = *(char *)in_RDX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047b5;
    iVar7 = func_0x000180205040(cVar1);
    iVar12 = 0x1806414d0;
    if (iVar7 != 0) {
        iVar12 = iVar7;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047d2;
    func_0x0001801fae90(in_RCX, 0x1804b9cf8, iVar12);
    if (((*in_RDX & 0xff) != 4) && ((*in_RDX & 0xff) != 6)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047f3;
        func_0x0001801faf20(in_RCX, 0x1804b9d08, in_R8);
    }
    cVar1 = *(char *)(in_RDX + 2);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020480b;
    func_0x0001801fa0e0(in_RCX, 0x1804b9fb4, (char *)((int64_t)in_RDX + 9), cVar1);
    if (*(char *)in_RDX != '\x05') {
        cVar1 = *(char *)((int64_t)in_RDX + 0x1d);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204828;
        func_0x0001801fa0e0(in_RCX, 0x1804b9fbc, (char *)((int64_t)in_RDX + 0x1e), cVar1);
    }
    if (*(int64_t *)(in_RDX + 0x10) != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020483e;
        func_0x0001801fa430(in_RCX, 0x1804b9f8c);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020484d;
        func_0x0001801fa430(in_RCX, 0x1804b9f94);
        uVar2 = *(undefined8 *)(in_RDX + 0x10);
        uVar3 = *(undefined8 *)(in_RDX + 0xe);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204864;
        func_0x0001801fa0e0(in_RCX, 0x1804af9c4, uVar3, uVar2);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020486c;
        func_0x0001801fa460(in_RCX);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204874;
        func_0x0001801fa460(in_RCX);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020487c;
    func_0x0001801fa460(in_RCX);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204890;
    func_0x0001801faf20(in_RCX, 0x1804b9fc8, *(undefined8 *)((int64_t)&arg_60h + iVar6));
    if (((*in_RDX & 0xff) != 4) && ((*in_RDX & 0xff) != 6)) {
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802048bb;
        func_0x0001801fa090(in_RCX);
        uVar4 = *(uint64_t *)((int64_t)&arg_58h + iVar6);
        uVar10 = 0;
        *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0;
        if (uVar4 != 0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_R15;
            uVar11 = uVar10;
            while (uVar9 = in_R9[1], uVar9 < 0x8000000000000000) {
                iVar12 = *in_R9;
                *(int64_t *)((int64_t)&var_8h + iVar6) = iVar12;
                *(uint64_t *)((int64_t)&iStackX_18 + iVar6 + -8) = uVar9;
                while (uVar9 != 0) {
                    if (uVar10 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020493e;
                        func_0x0001801fa430(in_RCX);
                        iVar12 = *(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204955;
                        iVar5 = fcn.180203e10(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                                              *(int64_t *)((int64_t)&var_20h + iVar6), 
                                              *(int64_t *)(&stack0x00000028 + iVar6), 
                                              *(int64_t *)(&stack0x00000030 + iVar6), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6));
                        if (iVar5 != 0) {
                            iVar7 = *(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204970;
                            func_0x0001801faf20(in_RCX, 0x1804b9fac, iVar12 - iVar7);
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204978;
                        func_0x0001801fa460(in_RCX);
                        uVar10 = *(uint64_t *)((int64_t)&arg_40h + iVar6);
                        uVar9 = *(uint64_t *)((int64_t)&iStackX_18 + iVar6 + -8);
                        iVar12 = *(int64_t *)((int64_t)&var_8h + iVar6);
                    } else {
                        uVar8 = uVar9;
                        if (uVar10 <= uVar9) {
                            uVar8 = uVar10;
                        }
                        if (uVar9 < uVar8) goto code_r0x0001802049a5;
                        iVar12 = iVar12 + uVar8;
                        uVar9 = uVar9 - uVar8;
                        uVar10 = uVar10 - uVar8;
                        *(int64_t *)((int64_t)&var_8h + iVar6) = iVar12;
                        *(uint64_t *)((int64_t)&arg_40h + iVar6) = uVar10;
                        *(uint64_t *)((int64_t)&iStackX_18 + iVar6 + -8) = uVar9;
                    }
                }
                uVar11 = uVar11 + 1;
                in_R9 = in_R9 + 2;
                if (uVar4 <= uVar11) break;
            }
        }
code_r0x0001802049a5:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802049ad;
        func_0x0001801fa0c0(in_RCX);
    }
    return;
}

// ============================================================
// Function: FUN_1802048ae
// Address: 0x1802048ae
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_2f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_24fh
// WARNING: [rz-ghidra] Detected overlap for variable var_23bh

void fcn.180204780(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_98h)
{
    char cVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 in_RCX;
    uint64_t uVar9;
    uint32_t *in_RDX;
    uint64_t uVar10;
    uint64_t uVar11;
    undefined8 in_R8;
    int64_t iVar12;
    int64_t *in_R9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180204792;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047ad;
    func_0x0001801fa430();
    cVar1 = *(char *)in_RDX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047b5;
    iVar7 = func_0x000180205040(cVar1);
    iVar12 = 0x1806414d0;
    if (iVar7 != 0) {
        iVar12 = iVar7;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047d2;
    func_0x0001801fae90(in_RCX, 0x1804b9cf8, iVar12);
    if (((*in_RDX & 0xff) != 4) && ((*in_RDX & 0xff) != 6)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047f3;
        func_0x0001801faf20(in_RCX, 0x1804b9d08, in_R8);
    }
    cVar1 = *(char *)(in_RDX + 2);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020480b;
    func_0x0001801fa0e0(in_RCX, 0x1804b9fb4, (char *)((int64_t)in_RDX + 9), cVar1);
    if (*(char *)in_RDX != '\x05') {
        cVar1 = *(char *)((int64_t)in_RDX + 0x1d);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204828;
        func_0x0001801fa0e0(in_RCX, 0x1804b9fbc, (char *)((int64_t)in_RDX + 0x1e), cVar1);
    }
    if (*(int64_t *)(in_RDX + 0x10) != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020483e;
        func_0x0001801fa430(in_RCX, 0x1804b9f8c);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020484d;
        func_0x0001801fa430(in_RCX, 0x1804b9f94);
        uVar2 = *(undefined8 *)(in_RDX + 0x10);
        uVar3 = *(undefined8 *)(in_RDX + 0xe);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204864;
        func_0x0001801fa0e0(in_RCX, 0x1804af9c4, uVar3, uVar2);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020486c;
        func_0x0001801fa460(in_RCX);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204874;
        func_0x0001801fa460(in_RCX);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020487c;
    func_0x0001801fa460(in_RCX);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204890;
    func_0x0001801faf20(in_RCX, 0x1804b9fc8, *(undefined8 *)((int64_t)&arg_60h + iVar6));
    if (((*in_RDX & 0xff) != 4) && ((*in_RDX & 0xff) != 6)) {
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802048bb;
        func_0x0001801fa090(in_RCX);
        uVar4 = *(uint64_t *)((int64_t)&arg_58h + iVar6);
        uVar10 = 0;
        *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0;
        if (uVar4 != 0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_R15;
            uVar11 = uVar10;
            while (uVar9 = in_R9[1], uVar9 < 0x8000000000000000) {
                iVar12 = *in_R9;
                *(int64_t *)((int64_t)&var_8h + iVar6) = iVar12;
                *(uint64_t *)((int64_t)&iStackX_18 + iVar6 + -8) = uVar9;
                while (uVar9 != 0) {
                    if (uVar10 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020493e;
                        func_0x0001801fa430(in_RCX);
                        iVar12 = *(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204955;
                        iVar5 = fcn.180203e10(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                                              *(int64_t *)((int64_t)&var_20h + iVar6), 
                                              *(int64_t *)(&stack0x00000028 + iVar6), 
                                              *(int64_t *)(&stack0x00000030 + iVar6), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6));
                        if (iVar5 != 0) {
                            iVar7 = *(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204970;
                            func_0x0001801faf20(in_RCX, 0x1804b9fac, iVar12 - iVar7);
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204978;
                        func_0x0001801fa460(in_RCX);
                        uVar10 = *(uint64_t *)((int64_t)&arg_40h + iVar6);
                        uVar9 = *(uint64_t *)((int64_t)&iStackX_18 + iVar6 + -8);
                        iVar12 = *(int64_t *)((int64_t)&var_8h + iVar6);
                    } else {
                        uVar8 = uVar9;
                        if (uVar10 <= uVar9) {
                            uVar8 = uVar10;
                        }
                        if (uVar9 < uVar8) goto code_r0x0001802049a5;
                        iVar12 = iVar12 + uVar8;
                        uVar9 = uVar9 - uVar8;
                        uVar10 = uVar10 - uVar8;
                        *(int64_t *)((int64_t)&var_8h + iVar6) = iVar12;
                        *(uint64_t *)((int64_t)&arg_40h + iVar6) = uVar10;
                        *(uint64_t *)((int64_t)&iStackX_18 + iVar6 + -8) = uVar9;
                    }
                }
                uVar11 = uVar11 + 1;
                in_R9 = in_R9 + 2;
                if (uVar4 <= uVar11) break;
            }
        }
code_r0x0001802049a5:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802049ad;
        func_0x0001801fa0c0(in_RCX);
    }
    return;
}

// ============================================================
// Function: FUN_1802048d2
// Address: 0x1802048d2
// Size: 211 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_2f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_24fh
// WARNING: [rz-ghidra] Detected overlap for variable var_23bh

void fcn.180204780(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_98h)
{
    char cVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 in_RCX;
    uint64_t uVar9;
    uint32_t *in_RDX;
    uint64_t uVar10;
    uint64_t uVar11;
    undefined8 in_R8;
    int64_t iVar12;
    int64_t *in_R9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180204792;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047ad;
    func_0x0001801fa430();
    cVar1 = *(char *)in_RDX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047b5;
    iVar7 = func_0x000180205040(cVar1);
    iVar12 = 0x1806414d0;
    if (iVar7 != 0) {
        iVar12 = iVar7;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047d2;
    func_0x0001801fae90(in_RCX, 0x1804b9cf8, iVar12);
    if (((*in_RDX & 0xff) != 4) && ((*in_RDX & 0xff) != 6)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047f3;
        func_0x0001801faf20(in_RCX, 0x1804b9d08, in_R8);
    }
    cVar1 = *(char *)(in_RDX + 2);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020480b;
    func_0x0001801fa0e0(in_RCX, 0x1804b9fb4, (char *)((int64_t)in_RDX + 9), cVar1);
    if (*(char *)in_RDX != '\x05') {
        cVar1 = *(char *)((int64_t)in_RDX + 0x1d);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204828;
        func_0x0001801fa0e0(in_RCX, 0x1804b9fbc, (char *)((int64_t)in_RDX + 0x1e), cVar1);
    }
    if (*(int64_t *)(in_RDX + 0x10) != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020483e;
        func_0x0001801fa430(in_RCX, 0x1804b9f8c);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020484d;
        func_0x0001801fa430(in_RCX, 0x1804b9f94);
        uVar2 = *(undefined8 *)(in_RDX + 0x10);
        uVar3 = *(undefined8 *)(in_RDX + 0xe);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204864;
        func_0x0001801fa0e0(in_RCX, 0x1804af9c4, uVar3, uVar2);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020486c;
        func_0x0001801fa460(in_RCX);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204874;
        func_0x0001801fa460(in_RCX);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020487c;
    func_0x0001801fa460(in_RCX);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204890;
    func_0x0001801faf20(in_RCX, 0x1804b9fc8, *(undefined8 *)((int64_t)&arg_60h + iVar6));
    if (((*in_RDX & 0xff) != 4) && ((*in_RDX & 0xff) != 6)) {
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802048bb;
        func_0x0001801fa090(in_RCX);
        uVar4 = *(uint64_t *)((int64_t)&arg_58h + iVar6);
        uVar10 = 0;
        *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0;
        if (uVar4 != 0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_R15;
            uVar11 = uVar10;
            while (uVar9 = in_R9[1], uVar9 < 0x8000000000000000) {
                iVar12 = *in_R9;
                *(int64_t *)((int64_t)&var_8h + iVar6) = iVar12;
                *(uint64_t *)((int64_t)&iStackX_18 + iVar6 + -8) = uVar9;
                while (uVar9 != 0) {
                    if (uVar10 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020493e;
                        func_0x0001801fa430(in_RCX);
                        iVar12 = *(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204955;
                        iVar5 = fcn.180203e10(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                                              *(int64_t *)((int64_t)&var_20h + iVar6), 
                                              *(int64_t *)(&stack0x00000028 + iVar6), 
                                              *(int64_t *)(&stack0x00000030 + iVar6), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6));
                        if (iVar5 != 0) {
                            iVar7 = *(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204970;
                            func_0x0001801faf20(in_RCX, 0x1804b9fac, iVar12 - iVar7);
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204978;
                        func_0x0001801fa460(in_RCX);
                        uVar10 = *(uint64_t *)((int64_t)&arg_40h + iVar6);
                        uVar9 = *(uint64_t *)((int64_t)&iStackX_18 + iVar6 + -8);
                        iVar12 = *(int64_t *)((int64_t)&var_8h + iVar6);
                    } else {
                        uVar8 = uVar9;
                        if (uVar10 <= uVar9) {
                            uVar8 = uVar10;
                        }
                        if (uVar9 < uVar8) goto code_r0x0001802049a5;
                        iVar12 = iVar12 + uVar8;
                        uVar9 = uVar9 - uVar8;
                        uVar10 = uVar10 - uVar8;
                        *(int64_t *)((int64_t)&var_8h + iVar6) = iVar12;
                        *(uint64_t *)((int64_t)&arg_40h + iVar6) = uVar10;
                        *(uint64_t *)((int64_t)&iStackX_18 + iVar6 + -8) = uVar9;
                    }
                }
                uVar11 = uVar11 + 1;
                in_R9 = in_R9 + 2;
                if (uVar4 <= uVar11) break;
            }
        }
code_r0x0001802049a5:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802049ad;
        func_0x0001801fa0c0(in_RCX);
    }
    return;
}

// ============================================================
// Function: FUN_1802049a5
// Address: 0x1802049a5
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_2f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_24fh
// WARNING: [rz-ghidra] Detected overlap for variable var_23bh

void fcn.180204780(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_98h)
{
    char cVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 in_RCX;
    uint64_t uVar9;
    uint32_t *in_RDX;
    uint64_t uVar10;
    uint64_t uVar11;
    undefined8 in_R8;
    int64_t iVar12;
    int64_t *in_R9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180204792;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047ad;
    func_0x0001801fa430();
    cVar1 = *(char *)in_RDX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047b5;
    iVar7 = func_0x000180205040(cVar1);
    iVar12 = 0x1806414d0;
    if (iVar7 != 0) {
        iVar12 = iVar7;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047d2;
    func_0x0001801fae90(in_RCX, 0x1804b9cf8, iVar12);
    if (((*in_RDX & 0xff) != 4) && ((*in_RDX & 0xff) != 6)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047f3;
        func_0x0001801faf20(in_RCX, 0x1804b9d08, in_R8);
    }
    cVar1 = *(char *)(in_RDX + 2);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020480b;
    func_0x0001801fa0e0(in_RCX, 0x1804b9fb4, (char *)((int64_t)in_RDX + 9), cVar1);
    if (*(char *)in_RDX != '\x05') {
        cVar1 = *(char *)((int64_t)in_RDX + 0x1d);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204828;
        func_0x0001801fa0e0(in_RCX, 0x1804b9fbc, (char *)((int64_t)in_RDX + 0x1e), cVar1);
    }
    if (*(int64_t *)(in_RDX + 0x10) != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020483e;
        func_0x0001801fa430(in_RCX, 0x1804b9f8c);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020484d;
        func_0x0001801fa430(in_RCX, 0x1804b9f94);
        uVar2 = *(undefined8 *)(in_RDX + 0x10);
        uVar3 = *(undefined8 *)(in_RDX + 0xe);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204864;
        func_0x0001801fa0e0(in_RCX, 0x1804af9c4, uVar3, uVar2);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020486c;
        func_0x0001801fa460(in_RCX);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204874;
        func_0x0001801fa460(in_RCX);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020487c;
    func_0x0001801fa460(in_RCX);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204890;
    func_0x0001801faf20(in_RCX, 0x1804b9fc8, *(undefined8 *)((int64_t)&arg_60h + iVar6));
    if (((*in_RDX & 0xff) != 4) && ((*in_RDX & 0xff) != 6)) {
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802048bb;
        func_0x0001801fa090(in_RCX);
        uVar4 = *(uint64_t *)((int64_t)&arg_58h + iVar6);
        uVar10 = 0;
        *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0;
        if (uVar4 != 0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_R15;
            uVar11 = uVar10;
            while (uVar9 = in_R9[1], uVar9 < 0x8000000000000000) {
                iVar12 = *in_R9;
                *(int64_t *)((int64_t)&var_8h + iVar6) = iVar12;
                *(uint64_t *)((int64_t)&iStackX_18 + iVar6 + -8) = uVar9;
                while (uVar9 != 0) {
                    if (uVar10 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020493e;
                        func_0x0001801fa430(in_RCX);
                        iVar12 = *(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204955;
                        iVar5 = fcn.180203e10(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                                              *(int64_t *)((int64_t)&var_20h + iVar6), 
                                              *(int64_t *)(&stack0x00000028 + iVar6), 
                                              *(int64_t *)(&stack0x00000030 + iVar6), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6));
                        if (iVar5 != 0) {
                            iVar7 = *(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204970;
                            func_0x0001801faf20(in_RCX, 0x1804b9fac, iVar12 - iVar7);
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204978;
                        func_0x0001801fa460(in_RCX);
                        uVar10 = *(uint64_t *)((int64_t)&arg_40h + iVar6);
                        uVar9 = *(uint64_t *)((int64_t)&iStackX_18 + iVar6 + -8);
                        iVar12 = *(int64_t *)((int64_t)&var_8h + iVar6);
                    } else {
                        uVar8 = uVar9;
                        if (uVar10 <= uVar9) {
                            uVar8 = uVar10;
                        }
                        if (uVar9 < uVar8) goto code_r0x0001802049a5;
                        iVar12 = iVar12 + uVar8;
                        uVar9 = uVar9 - uVar8;
                        uVar10 = uVar10 - uVar8;
                        *(int64_t *)((int64_t)&var_8h + iVar6) = iVar12;
                        *(uint64_t *)((int64_t)&arg_40h + iVar6) = uVar10;
                        *(uint64_t *)((int64_t)&iStackX_18 + iVar6 + -8) = uVar9;
                    }
                }
                uVar11 = uVar11 + 1;
                in_R9 = in_R9 + 2;
                if (uVar4 <= uVar11) break;
            }
        }
code_r0x0001802049a5:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802049ad;
        func_0x0001801fa0c0(in_RCX);
    }
    return;
}

// ============================================================
// Function: FUN_1802049b2
// Address: 0x1802049b2
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_2f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_24fh
// WARNING: [rz-ghidra] Detected overlap for variable var_23bh

void fcn.180204780(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_98h)
{
    char cVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 in_RCX;
    uint64_t uVar9;
    uint32_t *in_RDX;
    uint64_t uVar10;
    uint64_t uVar11;
    undefined8 in_R8;
    int64_t iVar12;
    int64_t *in_R9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180204792;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047ad;
    func_0x0001801fa430();
    cVar1 = *(char *)in_RDX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047b5;
    iVar7 = func_0x000180205040(cVar1);
    iVar12 = 0x1806414d0;
    if (iVar7 != 0) {
        iVar12 = iVar7;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047d2;
    func_0x0001801fae90(in_RCX, 0x1804b9cf8, iVar12);
    if (((*in_RDX & 0xff) != 4) && ((*in_RDX & 0xff) != 6)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802047f3;
        func_0x0001801faf20(in_RCX, 0x1804b9d08, in_R8);
    }
    cVar1 = *(char *)(in_RDX + 2);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020480b;
    func_0x0001801fa0e0(in_RCX, 0x1804b9fb4, (char *)((int64_t)in_RDX + 9), cVar1);
    if (*(char *)in_RDX != '\x05') {
        cVar1 = *(char *)((int64_t)in_RDX + 0x1d);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204828;
        func_0x0001801fa0e0(in_RCX, 0x1804b9fbc, (char *)((int64_t)in_RDX + 0x1e), cVar1);
    }
    if (*(int64_t *)(in_RDX + 0x10) != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020483e;
        func_0x0001801fa430(in_RCX, 0x1804b9f8c);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020484d;
        func_0x0001801fa430(in_RCX, 0x1804b9f94);
        uVar2 = *(undefined8 *)(in_RDX + 0x10);
        uVar3 = *(undefined8 *)(in_RDX + 0xe);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204864;
        func_0x0001801fa0e0(in_RCX, 0x1804af9c4, uVar3, uVar2);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020486c;
        func_0x0001801fa460(in_RCX);
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204874;
        func_0x0001801fa460(in_RCX);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020487c;
    func_0x0001801fa460(in_RCX);
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204890;
    func_0x0001801faf20(in_RCX, 0x1804b9fc8, *(undefined8 *)((int64_t)&arg_60h + iVar6));
    if (((*in_RDX & 0xff) != 4) && ((*in_RDX & 0xff) != 6)) {
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802048bb;
        func_0x0001801fa090(in_RCX);
        uVar4 = *(uint64_t *)((int64_t)&arg_58h + iVar6);
        uVar10 = 0;
        *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0;
        if (uVar4 != 0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_R15;
            uVar11 = uVar10;
            while (uVar9 = in_R9[1], uVar9 < 0x8000000000000000) {
                iVar12 = *in_R9;
                *(int64_t *)((int64_t)&var_8h + iVar6) = iVar12;
                *(uint64_t *)((int64_t)&iStackX_18 + iVar6 + -8) = uVar9;
                while (uVar9 != 0) {
                    if (uVar10 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18020493e;
                        func_0x0001801fa430(in_RCX);
                        iVar12 = *(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204955;
                        iVar5 = fcn.180203e10(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_18 + iVar6), 
                                              *(int64_t *)((int64_t)&var_20h + iVar6), 
                                              *(int64_t *)(&stack0x00000028 + iVar6), 
                                              *(int64_t *)(&stack0x00000030 + iVar6), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar6), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar6));
                        if (iVar5 != 0) {
                            iVar7 = *(int64_t *)((int64_t)&iStackX_18 + iVar6 + -8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204970;
                            func_0x0001801faf20(in_RCX, 0x1804b9fac, iVar12 - iVar7);
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180204978;
                        func_0x0001801fa460(in_RCX);
                        uVar10 = *(uint64_t *)((int64_t)&arg_40h + iVar6);
                        uVar9 = *(uint64_t *)((int64_t)&iStackX_18 + iVar6 + -8);
                        iVar12 = *(int64_t *)((int64_t)&var_8h + iVar6);
                    } else {
                        uVar8 = uVar9;
                        if (uVar10 <= uVar9) {
                            uVar8 = uVar10;
                        }
                        if (uVar9 < uVar8) goto code_r0x0001802049a5;
                        iVar12 = iVar12 + uVar8;
                        uVar9 = uVar9 - uVar8;
                        uVar10 = uVar10 - uVar8;
                        *(int64_t *)((int64_t)&var_8h + iVar6) = iVar12;
                        *(uint64_t *)((int64_t)&arg_40h + iVar6) = uVar10;
                        *(uint64_t *)((int64_t)&iStackX_18 + iVar6 + -8) = uVar9;
                    }
                }
                uVar11 = uVar11 + 1;
                in_R9 = in_R9 + 2;
                if (uVar4 <= uVar11) break;
            }
        }
code_r0x0001802049a5:
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802049ad;
        func_0x0001801fa0c0(in_RCX);
    }
    return;
}

// ============================================================
// Function: FUN_1802049c0
// Address: 0x1802049c0
// Size: 804 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1802049c0(int64_t arg_28h, int64_t arg_48h, int64_t arg_78h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    uint64_t *in_RDX;
    undefined8 uVar5;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802049d0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_48h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar4);
    *(undefined8 *)((int64_t)&var_18h + iVar4) = 0x1804b9bf8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204a0c;
    iVar3 = func_0x0001801fa270();
    if (iVar3 == 0) goto code_r0x000180204c88;
    uVar5 = 0x18064232c;
    if ((*(uint8_t *)(in_RDX + 4) & 2) != 0) {
        uVar5 = 0x1804b6e04;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204a39;
    func_0x0001801fae90(in_RCX, 0x1804b6e0c, uVar5);
    uVar1 = *in_RDX;
    if ((*(uint8_t *)(in_RDX + 4) & 1) == 0) {
    // switch table (16 cases) at 0x180204ca4
        switch(uVar1) {
        case 1:
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204a85;
            func_0x0001801fae90(in_RCX, 0x1804b9c60, 0x1804b9a80);
            break;
        case 2:
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204aa0;
            func_0x0001801fae90(in_RCX, 0x1804b9c60, 0x1804b9a90);
            break;
        case 3:
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204abb;
            func_0x0001801fae90(in_RCX, 0x1804b9c60, 0x1804b9aa8);
            break;
        case 4:
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204ad6;
            func_0x0001801fae90(in_RCX, 0x1804b9c60, 0x1804b9ac0);
            break;
        case 5:
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204af1;
            func_0x0001801fae90(in_RCX, 0x1804b9c60, 0x1804b9ad8);
            break;
        case 6:
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204b0c;
            func_0x0001801fae90(in_RCX, 0x1804b9c60, 0x1804b9af0);
            break;
        case 7:
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204b27;
            func_0x0001801fae90(in_RCX, 0x1804b9c60, 0x1804b9b08);
            break;
        case 8:
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204b42;
            func_0x0001801fae90(in_RCX, 0x1804b9c60, 0x1804b9b20);
            break;
        case 9:
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204b5d;
            func_0x0001801fae90(in_RCX, 0x1804b9c60, 0x1804b9b40);
            break;
        case 10:
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204b78;
            func_0x0001801fae90(in_RCX, 0x1804b9c60, 0x1804b9b60);
            break;
        case 0xb:
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204b93;
            func_0x0001801fae90(in_RCX, 0x1804b9c60, 0x1804b9b78);
            break;
        case 0xc:
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204bae;
            func_0x0001801fae90(in_RCX, 0x1804b9c60, 0x1804b9b88);
            break;
        case 0xd:
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204bc9;
            func_0x0001801fae90(in_RCX, 0x1804b9c60, 0x1804b9ba0);
            break;
        case 0xe:
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204be4;
            func_0x0001801fae90(in_RCX, 0x1804b9c60, 0x1804b9bb8);
            break;
        case 0xf:
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204bff;
            func_0x0001801fae90(in_RCX, 0x1804b9c60, 0x1804b9bd0);
            break;
        case 0x10:
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204c17;
            func_0x0001801fae90(in_RCX, 0x1804b9c60, 0x1804b9be8);
            break;
        default:
            if ((uVar1 < 0x100) || (0x1ff < uVar1)) {
                uVar5 = 0x1804b9c60;
                goto code_r0x000180204c61;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204c44;
            func_0x000180245f70((int64_t)&arg_28h + iVar4, 0x20, 0x1804b9c48, uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204c58;
            func_0x0001801fae90(in_RCX, 0x1804b9c60, (int64_t)&arg_28h + iVar4);
        }
    } else {
        uVar5 = 0x1804b9c30;
code_r0x000180204c61:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204c69;
        func_0x0001801faf20(in_RCX, uVar5);
    }
    uVar1 = in_RDX[3];
    uVar2 = in_RDX[2];
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204c80;
    func_0x0001801faed0(in_RCX, 0x180641940, uVar2, uVar1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204c88;
    func_0x0001801fa180(in_RCX);
code_r0x000180204c88:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180204c95;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_48h + iVar4) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_180204cf0
// Address: 0x180204cf0
// Size: 129 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180204cf0(int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180204d00;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar2 + -8) = 0x1804b9968;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180204d2d;
    iVar1 = fcn.1801fa270(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&arg_38h + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180204d47;
        fcn.1801fae90(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180204d5e;
        fcn.1801fa0e0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                      *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180204d66;
        fcn.1801fa180(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8));
    }
    return;
}

// ============================================================
// Function: FUN_180204d80
// Address: 0x180204d80
// Size: 199 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180204d80(int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180204d95;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0x1804b9a30;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180204dc5;
    iVar1 = fcn.1801fa270(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&arg_38h + iVar2));
    if (iVar1 != 0) {
        if ((in_R8D != 0) && ((((in_R8D == 1 || (in_R8D == 2)) || (in_R8D == 3)) || (in_R8D == 4)))) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180204e2f;
            fcn.1801fae90(*(int64_t *)((int64_t)&var_18h + iVar2));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180204e37;
        fcn.1801fa180(*(int64_t *)((int64_t)&var_18h + iVar2));
    }
    return;
}

// ============================================================
// Function: FUN_180204e50
// Address: 0x180204e50
// Size: 164 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable arg_65h

void fcn.180204e50(int64_t arg_38h)
{
    undefined uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180204e60;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = 0x1804b9cb8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180204e8d;
    iVar2 = fcn.1801fa270(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180204ea0;
        fcn.1801fa430(in_RCX, 0x1804b9cec);
        uVar1 = *(undefined *)(in_RDX + 0x78);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180204ea9;
        fcn.180205040(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180204ebb;
        fcn.1801fae90(*(int64_t *)((int64_t)&var_18h + iVar3));
        if ((*(char *)(in_RDX + 0x78) != '\x04') && (*(char *)(in_RDX + 0x78) != '\x06')) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180204ed9;
            fcn.1801faf20(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                          *(int64_t *)(&stack0x00000058 + iVar3), *(int64_t *)(&stack0x00000088 + iVar3), 
                          *(int64_t *)(&stack0x00000090 + iVar3));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180204ee1;
        fcn.1801fa460(*(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180204ee9;
        fcn.1801fa180(*(int64_t *)((int64_t)&var_18h + iVar3));
    }
    return;
}

// ============================================================
// Function: FUN_180204f00
// Address: 0x180204f00
// Size: 147 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180204f00(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_a0h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180204f1a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0x1804ba008;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180204f4d;
    iVar1 = fcn.1801fa270(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&arg_38h + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&var_20h + iVar2) = *(undefined8 *)(&stack0x00000060 + iVar2);
        *(undefined8 *)((int64_t)&var_18h + iVar2) = *(undefined8 *)((int64_t)&arg_58h + iVar2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180204f76;
        fcn.180204780(*(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                      *(int64_t *)(&stack0x00000088 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180204f7e;
        fcn.1801fa180(*(int64_t *)((int64_t)&var_18h + iVar2));
    }
    return;
}

// ============================================================
// Function: FUN_180204fa0
// Address: 0x180204fa0
// Size: 147 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180204fa0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_a0h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180204fba;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0x1804b9fe0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180204fed;
    iVar1 = fcn.1801fa270(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&arg_38h + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&var_20h + iVar2) = *(undefined8 *)(&stack0x00000060 + iVar2);
        *(undefined8 *)((int64_t)&var_18h + iVar2) = *(undefined8 *)((int64_t)&arg_58h + iVar2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180205016;
        fcn.180204780(*(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                      *(int64_t *)((int64_t)&arg_48h + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                      *(int64_t *)(&stack0x00000088 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020501e;
        fcn.1801fa180(*(int64_t *)((int64_t)&var_18h + iVar2));
    }
    return;
}

// ============================================================
// Function: FUN_180205100
// Address: 0x180205100
// Size: 43 bytes
// ============================================================
void fcn.180205100(int64_t param_1)
{
    undefined (*pauVar1) [16];
    undefined8 *puVar2;
    
    fcn.18045a350();
    if (*(char *)(param_1 + 0x421) != '\0') {
        return;
    }
    *(undefined *)(param_1 + 0x421) = 1;
    pauVar1 = *(undefined (**) [16])(param_1 + 0x48);
    while (pauVar1 != (undefined (*) [16])0x0) {
        *(undefined8 *)(param_1 + 0x48) = *(undefined8 *)*pauVar1;
        if (*(undefined (**) [16])(param_1 + 0x50) == pauVar1) {
            *(undefined8 *)(param_1 + 0x50) = *(undefined8 *)(*pauVar1 + 8);
        }
        puVar2 = *(undefined8 **)(*pauVar1 + 8);
        if (puVar2 != (undefined8 *)0x0) {
            *puVar2 = *(undefined8 *)*pauVar1;
            puVar2 = *(undefined8 **)(*pauVar1 + 8);
        }
        if (*(int64_t *)*pauVar1 != 0) {
            *(undefined8 **)(*(int64_t *)*pauVar1 + 8) = puVar2;
        }
        *(int64_t *)(param_1 + 0x58) = *(int64_t *)(param_1 + 0x58) + -1;
        *pauVar1 = ZEXT816(0);
        if (*(undefined (***) [16])(param_1 + 0x38) != (undefined (**) [16])0x0) {
            **(undefined (***) [16])(param_1 + 0x38) = pauVar1;
        }
        *(undefined8 *)(*pauVar1 + 8) = *(undefined8 *)(param_1 + 0x38);
        *(undefined8 *)*pauVar1 = 0;
        *(undefined (**) [16])(param_1 + 0x38) = pauVar1;
        if (*(int64_t *)(param_1 + 0x30) == 0) {
            *(undefined (**) [16])(param_1 + 0x30) = pauVar1;
        }
        *(int64_t *)(param_1 + 0x40) = *(int64_t *)(param_1 + 0x40) + 1;
        pauVar1 = *(undefined (**) [16])(param_1 + 0x48);
    }
    return;
}

// ============================================================
// Function: FUN_180205130
// Address: 0x180205130
// Size: 47 bytes
// ============================================================
undefined8 fcn.180205130(undefined8 param_1, uint32_t param_2)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020513a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (3 < param_2) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180205155;
    fcn.18020d2a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1));
    return 1;
}

// ============================================================
// Function: FUN_180205160
// Address: 0x180205160
// Size: 26 bytes
// ============================================================
void fcn.180205160(int64_t arg1, int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    uint32_t uVar2;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180205174;
        iVar1 = fcn.18045a350();
        iVar1 = -iVar1;
        *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar1) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020518d;
        fcn.1802057e0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180205196;
        fcn.1802057e0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802051a2;
        fcn.180205880(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802051ae;
        fcn.180205880(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        uVar2 = 0;
        do {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802051be;
            fcn.18020d2a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1));
            uVar2 = uVar2 + 1;
        } while (uVar2 < 4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802051e4;
        fcn.180224990(arg1, 0x1804ba028, 0x10b);
    }
    return;
}

// ============================================================
// Function: FUN_18020517a
// Address: 0x18020517a
// Size: 111 bytes
// ============================================================
void fcn.180205160(int64_t arg1, int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    uint32_t uVar2;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180205174;
        iVar1 = fcn.18045a350();
        iVar1 = -iVar1;
        *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar1) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020518d;
        fcn.1802057e0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180205196;
        fcn.1802057e0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802051a2;
        fcn.180205880(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802051ae;
        fcn.180205880(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        uVar2 = 0;
        do {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802051be;
            fcn.18020d2a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1));
            uVar2 = uVar2 + 1;
        } while (uVar2 < 4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802051e4;
        fcn.180224990(arg1, 0x1804ba028, 0x10b);
    }
    return;
}

// ============================================================
// Function: FUN_1802051e9
// Address: 0x1802051e9
// Size: 1 bytes
// ============================================================
void fcn.180205160(int64_t arg1, int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    uint32_t uVar2;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180205174;
        iVar1 = fcn.18045a350();
        iVar1 = -iVar1;
        *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar1) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020518d;
        fcn.1802057e0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180205196;
        fcn.1802057e0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802051a2;
        fcn.180205880(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802051ae;
        fcn.180205880(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        uVar2 = 0;
        do {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802051be;
            fcn.18020d2a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1));
            uVar2 = uVar2 + 1;
        } while (uVar2 < 4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802051e4;
        fcn.180224990(arg1, 0x1804ba028, 0x10b);
    }
    return;
}

// ============================================================
// Function: FUN_180205200
// Address: 0x180205200
// Size: 62 bytes
// ============================================================
undefined8 fcn.180205200(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020520a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180205224;
    iVar1 = fcn.18020d3c0(param_1 + 0xa8, 3, 1);
    if (iVar1 == 0) {
        return 0xffffffffffffffff;
    }
    return *(undefined8 *)(iVar1 + 0x50);
}

// ============================================================
// Function: FUN_180205240
// Address: 0x180205240
// Size: 60 bytes
// ============================================================
undefined8 fcn.180205240(int64_t param_1, undefined8 param_2)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020524a;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar2) = 0x18020525f;
    iVar2 = fcn.18020d3c0(param_1 + 0xa8, param_2, 1);
    if (iVar2 == 0) {
        return 0xffffffffffffffff;
    }
    iVar1 = *(int32_t *)(iVar2 + 0x60);
    if (iVar1 == 1) {
        return 0x10000000000000;
    }
    if (iVar1 == 2) {
        return 0x10000000000000;
    }
    if (iVar1 != 3) {
        return 0xffffffffffffffff;
    }
    return 0x1000000000;
}

// ============================================================
// Function: FUN_1802052d0
// Address: 0x1802052d0
// Size: 142 bytes
// ============================================================
void fcn.1802052d0(int64_t arg_28h, int64_t arg_30h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 *in_RDX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802052da;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    in_RDX[4] = 0;
    in_RDX[5] = 0;
    *(undefined *)(in_RDX + 0xf) = 0;
    if (*(undefined8 **)(in_RCX + 0x38) != (undefined8 *)0x0) {
        **(undefined8 **)(in_RCX + 0x38) = in_RDX;
    }
    in_RDX[1] = *(undefined8 *)(in_RCX + 0x38);
    *in_RDX = 0;
    *(undefined8 **)(in_RCX + 0x38) = in_RDX;
    if (*(int64_t *)(in_RCX + 0x30) == 0) {
        *(undefined8 **)(in_RCX + 0x30) = in_RDX;
    }
    *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + 1;
    pcVar1 = *(code **)(in_RCX + 0x428);
    if (pcVar1 != (code *)0x0) {
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = *(undefined8 *)(in_RCX + 0x430);
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = *(undefined8 *)(in_RCX + 0x438);
        *(undefined8 *)((int64_t)&var_20h + iVar2) = in_RDX[2];
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180205359;
        (*pcVar1)(0, 1, 0x200, in_RDX + 0x10);
    }
    return;
}

// ============================================================
// Function: FUN_180205360
// Address: 0x180205360
// Size: 170 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.180205360(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180205375;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    in_RCX = in_RCX + 0xa8;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180205394;
    iVar3 = fcn.18020d3c0(in_RCX, 3, 1);
    if (iVar3 == 0) {
        return false;
    }
    if (*(char *)(iVar3 + 0x68) == '\x02') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802053af;
        iVar1 = func_0x00018020d810(in_RCX, 3);
        if (iVar1 == 0) {
            return false;
        }
    }
    if ((in_EDX != 0) && (*(char *)(iVar3 + 0x68) == '\x03')) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802053ca;
        iVar1 = func_0x00018020d430(in_RCX, 3);
        return iVar1 != 0;
    }
    return true;
}

// ============================================================
// Function: FUN_180205410
// Address: 0x180205410
// Size: 165 bytes
// ============================================================
undefined8 * fcn.180205410(undefined8 *param_1)
{
    int64_t iVar1;
    undefined8 *puVar2;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020541c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((param_1[2] != 0) && (param_1[4] != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020544b;
        puVar2 = (undefined8 *)
                 fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1));
        if (puVar2 != (undefined8 *)0x0) {
            puVar2[0x12] = param_1[5];
            puVar2[0x13] = param_1[6];
            puVar2[0x14] = param_1[7];
            *puVar2 = *param_1;
            puVar2[1] = param_1[1];
            puVar2[2] = param_1[2];
            puVar2[3] = param_1[3];
            *(undefined *)(puVar2 + 0x84) = *(undefined *)(param_1 + 8);
            puVar2[4] = param_1[4];
            return puVar2;
        }
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_180205530
// Address: 0x180205530
// Size: 131 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h

undefined8
fcn.180205530(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_78h, int64_t arg_80h)
{
    undefined uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint32_t in_EDX;
    undefined4 in_R8D;
    undefined8 in_R9;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020553c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_EDX < 4) {
        uVar1 = *(undefined *)(in_RCX + 0x420);
        *(undefined4 *)((int64_t)&arg_40h + iVar3) = 0;
        *(undefined *)((int64_t)&arg_38h + iVar3) = uVar1;
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = *(undefined8 *)((int64_t)&arg_80h + iVar3);
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = *(undefined8 *)((int64_t)&arg_78h + iVar3);
        *(undefined8 *)((int64_t)&var_20h + iVar3) = in_R9;
        *(undefined4 *)((int64_t)&var_18h + iVar3) = in_R8D;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180205594;
        iVar2 = fcn.18020d890(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)((int64_t)&arg_40h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                              *(int64_t *)(&stack0x00000058 + iVar3), *(int64_t *)(&stack0x00000098 + iVar3), 
                              *(int64_t *)(&stack0x000000d8 + iVar3), *(int64_t *)(&stack0x000000f0 + iVar3), 
                              *(int64_t *)(&stack0x00000158 + iVar3), *(int64_t *)(&stack0x00000160 + iVar3), 
                              *(int64_t *)(&stack0x00000168 + iVar3), *(int64_t *)(&stack0x00000170 + iVar3), 
                              *(int64_t *)(&stack0x00000178 + iVar3), *(int64_t *)(&stack0x00000180 + iVar3));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802055a0;
            fcn.180206560(in_RCX);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802055c0
// Address: 0x1802055c0
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1802055c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t **in_RDX;
    undefined8 unaff_RBX;
    int64_t *piVar5;
    undefined8 unaff_RBP;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802055d6;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int64_t *)(in_RCX + 0x88) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802055ee;
        iVar3 = func_0x000180205ce0();
        if (iVar3 == 0) {
            return 0;
        }
        if (*(int64_t *)(in_RCX + 0x88) == 0) {
            return 0;
        }
    }
    piVar1 = *(int64_t **)(in_RCX + 0x78);
    if (piVar1 == (int64_t *)0x0) {
        return 0;
    }
    iVar2 = piVar1[9];
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(int64_t *)(in_RCX + 0x78) = iVar2;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    if (*(int64_t **)(in_RCX + 0x80) == piVar1) {
        *(int64_t *)(in_RCX + 0x80) = piVar1[10];
    }
    if (piVar1[10] != 0) {
        *(int64_t *)(piVar1[10] + 0x48) = piVar1[9];
    }
    if (piVar1[9] != 0) {
        *(int64_t *)(piVar1[9] + 0x50) = piVar1[10];
    }
    *(int64_t *)(in_RCX + 0x88) = *(int64_t *)(in_RCX + 0x88) + -1;
    *(undefined (*) [16])(piVar1 + 9) = ZEXT816(0);
    *piVar1 = (int64_t)(piVar1 + 0xe);
    piVar1[4] = piVar1[0x19];
    piVar1[5] = piVar1[0x21];
    piVar1[3] = piVar1[0x22];
    piVar1[0xd] = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802056a6;
    iVar3 = func_0x00018026bea0(piVar1 + 0x1a);
    piVar5 = piVar1 + 0x1a;
    if (iVar3 == 0) {
        piVar5 = (int64_t *)0x0;
    }
    piVar1[1] = (int64_t)piVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802056c1;
    iVar3 = func_0x00018026bea0((int64_t *)((int64_t)piVar1 + 0xec));
    piVar1[7] = piVar1[0x23];
    piVar5 = (int64_t *)((int64_t)piVar1 + 0xec);
    if (iVar3 == 0) {
        piVar5 = (int64_t *)0x0;
    }
    piVar1[2] = (int64_t)piVar5;
    piVar1[8] = piVar1[0x24];
    piVar1[6] = in_RCX;
    *in_RDX = piVar1;
    return 1;
}

// ============================================================
// Function: FUN_180205615
// Address: 0x180205615
// Size: 243 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1802055c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t **in_RDX;
    undefined8 unaff_RBX;
    int64_t *piVar5;
    undefined8 unaff_RBP;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802055d6;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int64_t *)(in_RCX + 0x88) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802055ee;
        iVar3 = func_0x000180205ce0();
        if (iVar3 == 0) {
            return 0;
        }
        if (*(int64_t *)(in_RCX + 0x88) == 0) {
            return 0;
        }
    }
    piVar1 = *(int64_t **)(in_RCX + 0x78);
    if (piVar1 == (int64_t *)0x0) {
        return 0;
    }
    iVar2 = piVar1[9];
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(int64_t *)(in_RCX + 0x78) = iVar2;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    if (*(int64_t **)(in_RCX + 0x80) == piVar1) {
        *(int64_t *)(in_RCX + 0x80) = piVar1[10];
    }
    if (piVar1[10] != 0) {
        *(int64_t *)(piVar1[10] + 0x48) = piVar1[9];
    }
    if (piVar1[9] != 0) {
        *(int64_t *)(piVar1[9] + 0x50) = piVar1[10];
    }
    *(int64_t *)(in_RCX + 0x88) = *(int64_t *)(in_RCX + 0x88) + -1;
    *(undefined (*) [16])(piVar1 + 9) = ZEXT816(0);
    *piVar1 = (int64_t)(piVar1 + 0xe);
    piVar1[4] = piVar1[0x19];
    piVar1[5] = piVar1[0x21];
    piVar1[3] = piVar1[0x22];
    piVar1[0xd] = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802056a6;
    iVar3 = func_0x00018026bea0(piVar1 + 0x1a);
    piVar5 = piVar1 + 0x1a;
    if (iVar3 == 0) {
        piVar5 = (int64_t *)0x0;
    }
    piVar1[1] = (int64_t)piVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802056c1;
    iVar3 = func_0x00018026bea0((int64_t *)((int64_t)piVar1 + 0xec));
    piVar1[7] = piVar1[0x23];
    piVar5 = (int64_t *)((int64_t)piVar1 + 0xec);
    if (iVar3 == 0) {
        piVar5 = (int64_t *)0x0;
    }
    piVar1[2] = (int64_t)piVar5;
    piVar1[8] = piVar1[0x24];
    piVar1[6] = in_RCX;
    *in_RDX = piVar1;
    return 1;
}

// ============================================================
// Function: FUN_180205708
// Address: 0x180205708
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1802055c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t **in_RDX;
    undefined8 unaff_RBX;
    int64_t *piVar5;
    undefined8 unaff_RBP;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802055d6;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int64_t *)(in_RCX + 0x88) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802055ee;
        iVar3 = func_0x000180205ce0();
        if (iVar3 == 0) {
            return 0;
        }
        if (*(int64_t *)(in_RCX + 0x88) == 0) {
            return 0;
        }
    }
    piVar1 = *(int64_t **)(in_RCX + 0x78);
    if (piVar1 == (int64_t *)0x0) {
        return 0;
    }
    iVar2 = piVar1[9];
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
    *(int64_t *)(in_RCX + 0x78) = iVar2;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    if (*(int64_t **)(in_RCX + 0x80) == piVar1) {
        *(int64_t *)(in_RCX + 0x80) = piVar1[10];
    }
    if (piVar1[10] != 0) {
        *(int64_t *)(piVar1[10] + 0x48) = piVar1[9];
    }
    if (piVar1[9] != 0) {
        *(int64_t *)(piVar1[9] + 0x50) = piVar1[10];
    }
    *(int64_t *)(in_RCX + 0x88) = *(int64_t *)(in_RCX + 0x88) + -1;
    *(undefined (*) [16])(piVar1 + 9) = ZEXT816(0);
    *piVar1 = (int64_t)(piVar1 + 0xe);
    piVar1[4] = piVar1[0x19];
    piVar1[5] = piVar1[0x21];
    piVar1[3] = piVar1[0x22];
    piVar1[0xd] = 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802056a6;
    iVar3 = func_0x00018026bea0(piVar1 + 0x1a);
    piVar5 = piVar1 + 0x1a;
    if (iVar3 == 0) {
        piVar5 = (int64_t *)0x0;
    }
    piVar1[1] = (int64_t)piVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802056c1;
    iVar3 = func_0x00018026bea0((int64_t *)((int64_t)piVar1 + 0xec));
    piVar1[7] = piVar1[0x23];
    piVar5 = (int64_t *)((int64_t)piVar1 + 0xec);
    if (iVar3 == 0) {
        piVar5 = (int64_t *)0x0;
    }
    piVar1[2] = (int64_t)piVar5;
    piVar1[8] = piVar1[0x24];
    piVar1[6] = in_RCX;
    *in_RDX = piVar1;
    return 1;
}

// ============================================================
// Function: FUN_1802057b0
// Address: 0x1802057b0
// Size: 39 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch

undefined8
fcn.1802057b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_98h, int64_t arg_a8h,
             int64_t arg_e8h, int64_t arg_f0h, int64_t arg_100h, int64_t arg_160h)
{
    char *pcVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined auVar4 [16];
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    uint32_t uVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    undefined8 uVar14;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar15;
    undefined8 unaff_R12;
    int64_t iVar16;
    undefined8 unaff_R13;
    uint64_t uVar17;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar18;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_10 [2];
    
    auStack_10[1] = 0x1802057ba;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    *(undefined8 *)(in_RDX + 0x20) = 0;
    *(undefined8 *)(in_RDX + 0x28) = 0;
    *(undefined *)(in_RDX + 0x78) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar11) = *(undefined8 *)(in_RDX + 0x10);
    *(undefined8 *)((int64_t)&var_20h + iVar11) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar11) = unaff_RSI;
    *(undefined8 *)(&stack0x00000010 + iVar11) = unaff_RDI;
    *(undefined8 *)(&stack0x00000008 + iVar11) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar11) = unaff_R14;
    *(undefined8 *)((int64_t)auStack_10 + iVar11 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_10 + iVar11) = 0x180206998;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    uVar17 = 0;
    auVar4._4_4_ = unaff_XMM6_Db;
    auVar4._0_4_ = unaff_XMM6_Da;
    auVar4._8_4_ = unaff_XMM6_Dc;
    auVar4._12_4_ = unaff_XMM6_Dd;
    *(undefined (*) [16])((int64_t)&arg_98h + iVar12 + iVar11) = auVar4;
    *(undefined8 *)((int64_t)&arg_f0h + iVar12 + iVar11) = 0;
    uVar15 = *(uint64_t *)(in_RDX + 0x10);
    *(undefined8 *)((int64_t)&arg_58h + iVar12 + iVar11) = 0xffffffffffffffff;
    if (uVar15 < 0x8000000000000000) {
        *(uint64_t *)((int64_t)&arg_70h + iVar12 + iVar11) = uVar15;
        *(int64_t *)((int64_t)&arg_68h + iVar12 + iVar11) = in_RDX + 0x80;
        uVar5 = *(undefined4 *)((int64_t)&arg_68h + iVar12 + iVar11);
        uVar6 = *(undefined4 *)((int64_t)&arg_68h + iVar12 + iVar11 + 4);
        uVar7 = *(undefined4 *)((int64_t)&arg_70h + iVar12 + iVar11);
        uVar8 = *(undefined4 *)((int64_t)&arg_70h + iVar12 + iVar11 + 4);
        *(undefined8 *)((int64_t)auStack_10 + iVar12 + iVar11) = 0x1802069f2;
        iVar13 = func_0x000180205c30();
        if (iVar13 != 0) {
            *(undefined8 *)((int64_t)&arg_e8h + iVar12 + iVar11) = unaff_RBX;
            pcVar1 = (char *)(iVar13 + 0x70);
            *(undefined8 *)((int64_t)&arg_28h + iVar12 + iVar11) = 0;
            *(undefined8 *)((int64_t)&arg_a8h + iVar12 + iVar11) = unaff_R12;
            *(int64_t *)((int64_t)&var_20h + iVar12 + iVar11) = (int64_t)&arg_78h + iVar12 + iVar11;
            *(char **)((int64_t)&var_18h + iVar12 + iVar11) = pcVar1;
            *(undefined8 *)((int64_t)auStack_10 + iVar12 + iVar11) = 0x180206a3e;
            iVar9 = func_0x0001801f8d60((int64_t)&arg_68h + iVar12 + iVar11, 0, 1, 0);
            if (((iVar9 != 0) && (*pcVar1 == '\x01')) &&
               ((*(int32_t *)(iVar13 + 0x74) == 1 || (*(int32_t *)(iVar13 + 0x74) == 0)))) {
                *(undefined8 *)((int64_t)auStack_10 + iVar12 + iVar11) = 0x180206a6d;
                iVar9 = func_0x00018020d3f0(in_RCX + 0xa8, 0);
                if (iVar9 == 1) {
                    if (*pcVar1 == '\x01') {
                        uVar15 = *(uint64_t *)(iVar13 + 0xb0);
                        iVar18 = *(int64_t *)(iVar13 + 0xa8);
                        if (uVar15 != 0) {
                            if (*(uint64_t *)(iVar13 + 0x60) < uVar15) {
                                *(undefined8 *)((int64_t)auStack_10 + iVar12 + iVar11) = 0x180206aa2;
                                iVar13 = func_0x0001802065f0(in_RCX + 0x60, iVar13, uVar15);
                                if (iVar13 == 0) {
                                    return 0;
                                }
                            }
                            *(undefined8 *)((int64_t)auStack_10 + iVar12 + iVar11) = 0x180206ac0;
                            func_0x000180498030(iVar13 + 0x128, iVar18, uVar15);
                            iVar18 = iVar13 + 0x128;
                            uVar17 = uVar15;
                        }
                        *(int64_t *)(iVar13 + 0xa8) = iVar18;
                    }
                    *(undefined4 *)((int64_t)&arg_68h + iVar12 + iVar11) = uVar5;
                    *(undefined4 *)((int64_t)&arg_68h + iVar12 + iVar11 + 4) = uVar6;
                    *(undefined4 *)((int64_t)&arg_70h + iVar12 + iVar11) = uVar7;
                    *(undefined4 *)((int64_t)&arg_70h + iVar12 + iVar11 + 4) = uVar8;
                    *(undefined8 *)((int64_t)auStack_10 + iVar12 + iVar11) = 0x180206af5;
                    uVar14 = fcn.18020d3c0(in_RCX + 0xa8, 0, 1);
                    *(undefined8 *)((int64_t)auStack_10 + iVar12 + iVar11) = 0x180206b05;
                    iVar9 = func_0x0001801f8980(uVar14, (int64_t)&arg_78h + iVar12 + iVar11);
                    if (iVar9 != 0) {
                        *(uint64_t *)(in_RDX + 0x28) = *(uint64_t *)(in_RDX + 0x28) | 1;
                        *(undefined8 *)((int64_t)&arg_28h + iVar12 + iVar11) = 0;
                        *(undefined8 *)((int64_t)&var_20h + iVar12 + iVar11) = 0;
                        *(int64_t *)((int64_t)&var_18h + iVar12 + iVar11) = iVar13 + 0x70;
                        *(undefined8 *)((int64_t)auStack_10 + iVar12 + iVar11) = 0x180206b37;
                        iVar9 = func_0x0001801f8d60((int64_t)&arg_68h + iVar12 + iVar11, 0, 0, 0);
                        if (iVar9 == 1) {
                            *(undefined8 *)((int64_t)auStack_10 + iVar12 + iVar11) = 0x180206b4b;
                            iVar9 = func_0x0001802067d0(in_RCX, iVar13);
                            if (iVar9 != 0) {
                                iVar18 = *(int64_t *)(iVar13 + 0xc0);
                                if (*(uint64_t *)(iVar13 + 0x60) < *(int64_t *)(iVar13 + 0xb8) + uVar17) {
                                    *(undefined8 *)((int64_t)auStack_10 + iVar12 + iVar11) = 0x180206b79;
                                    iVar13 = func_0x0001802065f0(in_RCX + 0x60, iVar13);
                                }
                                if (iVar13 != 0) {
                                    uVar10 = *(uint32_t *)(iVar13 + 0x70);
                                    uVar14 = *(undefined8 *)(iVar13 + 0xb8);
                                    uVar2 = *(undefined8 *)(iVar13 + 0xc0);
                                    *(int64_t *)((int64_t)&arg_48h + iVar12 + iVar11) =
                                         (int64_t)&arg_58h + iVar12 + iVar11;
                                    iVar16 = uVar17 + 0x128 + iVar13;
                                    uVar3 = *(undefined8 *)(iVar13 + 200);
                                    *(uint8_t *)((int64_t)&arg_40h + iVar12 + iVar11) = (uint8_t)(uVar10 >> 9) & 1;
                                    *(undefined4 *)((int64_t)&arg_38h + iVar12 + iVar11) = 0;
                                    *(undefined8 *)((int64_t)&arg_30h + iVar12 + iVar11) = uVar3;
                                    *(int64_t *)((int64_t)&arg_28h + iVar12 + iVar11) = iVar18 - (in_RDX + 0x80);
                                    *(int64_t *)((int64_t)&var_20h + iVar12 + iVar11) = in_RDX + 0x80;
                                    *(int64_t *)((int64_t)&var_18h + iVar12 + iVar11) =
                                         (int64_t)&arg_f0h + iVar12 + iVar11;
                                    *(undefined8 *)((int64_t)auStack_10 + iVar12 + iVar11) = 0x180206bea;
                                    iVar9 = func_0x000180205920(in_RCX, iVar16, uVar2, uVar14);
                                    if (iVar9 != 0) {
                                        *(undefined8 *)((int64_t)auStack_10 + iVar12 + iVar11) = 0x180206bfd;
                                        iVar9 = func_0x0001802068f0(in_RCX, iVar13);
                                        if (iVar9 != 0) {
                                            *(uint64_t *)(in_RDX + 0x20) = *(uint64_t *)(in_RDX + 0x20) | 1;
                                            uVar14 = *(undefined8 *)((int64_t)&arg_f0h + iVar12 + iVar11);
                                            uVar15 = *(uint64_t *)(iVar13 + 200);
                                            *(undefined8 *)(iVar13 + 0xb8) = uVar14;
                                            *(undefined8 *)(iVar13 + 0x58) = uVar14;
                                            *(undefined8 *)(iVar13 + 0x110) =
                                                 *(undefined8 *)((int64_t)&arg_100h + iVar12 + iVar11);
                                            *(undefined8 *)(iVar13 + 0x118) =
                                                 *(undefined8 *)((int64_t)&arg_58h + iVar12 + iVar11);
                                            *(int64_t *)(iVar13 + 0xc0) = iVar16;
                                            *(undefined8 *)((int64_t)auStack_10 + iVar12 + iVar11) = 0x180206c4e;
                                            uVar10 = func_0x000180206d40(iVar13);
                                            if (*(uint64_t *)(in_RCX + 0x90 + (uint64_t)uVar10 * 8) < uVar15) {
                                                *(uint64_t *)(in_RCX + 0x90 + (uint64_t)uVar10 * 8) = uVar15;
                                            }
                                            uVar5 = *(undefined4 *)(in_RDX + 0x3c);
                                            uVar6 = *(undefined4 *)(in_RDX + 0x40);
                                            uVar7 = *(undefined4 *)(in_RDX + 0x44);
                                            *(undefined4 *)(iVar13 + 0xd0) = *(undefined4 *)(in_RDX + 0x38);
                                            *(undefined4 *)(iVar13 + 0xd4) = uVar5;
                                            *(undefined4 *)(iVar13 + 0xd8) = uVar6;
                                            *(undefined4 *)(iVar13 + 0xdc) = uVar7;
                                            *(undefined8 *)(iVar13 + 0xe0) = *(undefined8 *)(in_RDX + 0x48);
                                            *(undefined4 *)(iVar13 + 0xe8) = *(undefined4 *)(in_RDX + 0x50);
                                            uVar5 = *(undefined4 *)(in_RDX + 0x58);
                                            uVar6 = *(undefined4 *)(in_RDX + 0x5c);
                                            uVar7 = *(undefined4 *)(in_RDX + 0x60);
                                            *(undefined4 *)(iVar13 + 0xec) = *(undefined4 *)(in_RDX + 0x54);
                                            *(undefined4 *)(iVar13 + 0xf0) = uVar5;
                                            *(undefined4 *)(iVar13 + 0xf4) = uVar6;
                                            *(undefined4 *)(iVar13 + 0xf8) = uVar7;
                                            *(undefined8 *)(iVar13 + 0xfc) = *(undefined8 *)(in_RDX + 100);
                                            *(undefined4 *)(iVar13 + 0x104) = *(undefined4 *)(in_RDX + 0x6c);
                                            *(undefined8 *)(iVar13 + 0x108) = *(undefined8 *)(in_RDX + 0x70);
                                            *(undefined8 *)(iVar13 + 0x120) = *(undefined8 *)(in_RDX + 0x30);
                                            *(undefined8 *)((int64_t)auStack_10 + iVar12 + iVar11) = 0x180206cc7;
                                            func_0x0001802050b0(in_RCX + 0x60, iVar13);
                                            if (*(int64_t *)(in_RCX + 0x80) != 0) {
                                                *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x48) = iVar13;
                                            }
                                            *(undefined8 *)(iVar13 + 0x50) = *(undefined8 *)(in_RCX + 0x80);
                                            *(undefined8 *)(iVar13 + 0x48) = 0;
                                            *(int64_t *)(in_RCX + 0x80) = iVar13;
                                            if (*(int64_t *)(in_RCX + 0x78) == 0) {
                                                *(int64_t *)(in_RCX + 0x78) = iVar13;
                                            }
                                            *(int64_t *)(in_RCX + 0x88) = *(int64_t *)(in_RCX + 0x88) + 1;
                                            return 1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return 0;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802057e0
// Address: 0x1802057e0
// Size: 26 bytes
// ============================================================
void fcn.1802057e0(int64_t arg_28h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *in_RCX;
    int64_t iVar4;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802057ec;
    iVar2 = fcn.18045a350();
    iVar3 = *in_RCX;
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar2) = unaff_RDI;
        do {
            iVar1 = *(int64_t *)(iVar3 + 0x48);
            iVar4 = iVar1;
            if (*in_RCX == iVar3) {
                *in_RCX = iVar1;
                iVar4 = *(int64_t *)(iVar3 + 0x48);
            }
            if (in_RCX[1] == iVar3) {
                in_RCX[1] = *(int64_t *)(iVar3 + 0x50);
                iVar4 = *(int64_t *)(iVar3 + 0x48);
            }
            if (*(int64_t *)(iVar3 + 0x50) != 0) {
                *(int64_t *)(*(int64_t *)(iVar3 + 0x50) + 0x48) = iVar4;
            }
            if (*(int64_t *)(iVar3 + 0x48) != 0) {
                *(undefined8 *)(*(int64_t *)(iVar3 + 0x48) + 0x50) = *(undefined8 *)(iVar3 + 0x50);
            }
            in_RCX[2] = in_RCX[2] + -1;
            *(undefined (*) [16])(iVar3 + 0x48) = ZEXT816(0);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x180205863;
            fcn.180224990(iVar3, 0x1804ba028, 0xe1);
            iVar3 = iVar1;
        } while (iVar1 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_1802057fa
// Address: 0x1802057fa
// Size: 118 bytes
// ============================================================
void fcn.1802057e0(int64_t arg_28h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *in_RCX;
    int64_t iVar4;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802057ec;
    iVar2 = fcn.18045a350();
    iVar3 = *in_RCX;
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar2) = unaff_RDI;
        do {
            iVar1 = *(int64_t *)(iVar3 + 0x48);
            iVar4 = iVar1;
            if (*in_RCX == iVar3) {
                *in_RCX = iVar1;
                iVar4 = *(int64_t *)(iVar3 + 0x48);
            }
            if (in_RCX[1] == iVar3) {
                in_RCX[1] = *(int64_t *)(iVar3 + 0x50);
                iVar4 = *(int64_t *)(iVar3 + 0x48);
            }
            if (*(int64_t *)(iVar3 + 0x50) != 0) {
                *(int64_t *)(*(int64_t *)(iVar3 + 0x50) + 0x48) = iVar4;
            }
            if (*(int64_t *)(iVar3 + 0x48) != 0) {
                *(undefined8 *)(*(int64_t *)(iVar3 + 0x48) + 0x50) = *(undefined8 *)(iVar3 + 0x50);
            }
            in_RCX[2] = in_RCX[2] + -1;
            *(undefined (*) [16])(iVar3 + 0x48) = ZEXT816(0);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x180205863;
            fcn.180224990(iVar3, 0x1804ba028, 0xe1);
            iVar3 = iVar1;
        } while (iVar1 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_180205870
// Address: 0x180205870
// Size: 6 bytes
// ============================================================
void fcn.1802057e0(int64_t arg_28h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *in_RCX;
    int64_t iVar4;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802057ec;
    iVar2 = fcn.18045a350();
    iVar3 = *in_RCX;
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar2) = unaff_RDI;
        do {
            iVar1 = *(int64_t *)(iVar3 + 0x48);
            iVar4 = iVar1;
            if (*in_RCX == iVar3) {
                *in_RCX = iVar1;
                iVar4 = *(int64_t *)(iVar3 + 0x48);
            }
            if (in_RCX[1] == iVar3) {
                in_RCX[1] = *(int64_t *)(iVar3 + 0x50);
                iVar4 = *(int64_t *)(iVar3 + 0x48);
            }
            if (*(int64_t *)(iVar3 + 0x50) != 0) {
                *(int64_t *)(*(int64_t *)(iVar3 + 0x50) + 0x48) = iVar4;
            }
            if (*(int64_t *)(iVar3 + 0x48) != 0) {
                *(undefined8 *)(*(int64_t *)(iVar3 + 0x48) + 0x50) = *(undefined8 *)(iVar3 + 0x50);
            }
            in_RCX[2] = in_RCX[2] + -1;
            *(undefined (*) [16])(iVar3 + 0x48) = ZEXT816(0);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x180205863;
            fcn.180224990(iVar3, 0x1804ba028, 0xe1);
            iVar3 = iVar1;
        } while (iVar1 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_180205880
// Address: 0x180205880
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180205880(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    undefined (*pauVar1) [16];
    undefined8 uVar2;
    int64_t iVar3;
    undefined (*pauVar4) [16];
    int64_t in_RCX;
    undefined (**in_RDX) [16];
    undefined (*pauVar5) [16];
    undefined8 unaff_RDI;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180205890;
    iVar3 = fcn.18045a350();
    pauVar4 = *in_RDX;
    if (pauVar4 != (undefined (*) [16])0x0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar3) = unaff_RDI;
        do {
            pauVar1 = *(undefined (**) [16])*pauVar4;
            pauVar5 = pauVar1;
            if (*in_RDX == pauVar4) {
                *in_RDX = pauVar1;
                pauVar5 = *(undefined (**) [16])*pauVar4;
            }
            if (in_RDX[1] == pauVar4) {
                in_RDX[1] = *(undefined (**) [16])(*pauVar4 + 8);
                pauVar5 = *(undefined (**) [16])*pauVar4;
            }
            if (*(undefined (***) [16])(*pauVar4 + 8) != (undefined (**) [16])0x0) {
                **(undefined (***) [16])(*pauVar4 + 8) = pauVar5;
            }
            if (*(int64_t *)*pauVar4 != 0) {
                *(undefined8 *)(*(int64_t *)*pauVar4 + 8) = *(undefined8 *)(*pauVar4 + 8);
            }
            in_RDX[2] = (undefined (*) [16])(in_RDX[2][-1] + 0xf);
            *pauVar4 = ZEXT816(0);
            uVar2 = *(undefined8 *)(in_RCX + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x180205904;
            func_0x0001801de180(uVar2, pauVar4);
            pauVar4 = pauVar1;
        } while (pauVar1 != (undefined (*) [16])0x0);
    }
    return;
}

// ============================================================
// Function: FUN_1802058a1
// Address: 0x1802058a1
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180205880(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    undefined (*pauVar1) [16];
    undefined8 uVar2;
    int64_t iVar3;
    undefined (*pauVar4) [16];
    int64_t in_RCX;
    undefined (**in_RDX) [16];
    undefined (*pauVar5) [16];
    undefined8 unaff_RDI;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180205890;
    iVar3 = fcn.18045a350();
    pauVar4 = *in_RDX;
    if (pauVar4 != (undefined (*) [16])0x0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar3) = unaff_RDI;
        do {
            pauVar1 = *(undefined (**) [16])*pauVar4;
            pauVar5 = pauVar1;
            if (*in_RDX == pauVar4) {
                *in_RDX = pauVar1;
                pauVar5 = *(undefined (**) [16])*pauVar4;
            }
            if (in_RDX[1] == pauVar4) {
                in_RDX[1] = *(undefined (**) [16])(*pauVar4 + 8);
                pauVar5 = *(undefined (**) [16])*pauVar4;
            }
            if (*(undefined (***) [16])(*pauVar4 + 8) != (undefined (**) [16])0x0) {
                **(undefined (***) [16])(*pauVar4 + 8) = pauVar5;
            }
            if (*(int64_t *)*pauVar4 != 0) {
                *(undefined8 *)(*(int64_t *)*pauVar4 + 8) = *(undefined8 *)(*pauVar4 + 8);
            }
            in_RDX[2] = (undefined (*) [16])(in_RDX[2][-1] + 0xf);
            *pauVar4 = ZEXT816(0);
            uVar2 = *(undefined8 *)(in_RCX + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x180205904;
            func_0x0001801de180(uVar2, pauVar4);
            pauVar4 = pauVar1;
        } while (pauVar1 != (undefined (*) [16])0x0);
    }
    return;
}

// ============================================================
// Function: FUN_180205911
// Address: 0x180205911
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180205880(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    undefined (*pauVar1) [16];
    undefined8 uVar2;
    int64_t iVar3;
    undefined (*pauVar4) [16];
    int64_t in_RCX;
    undefined (**in_RDX) [16];
    undefined (*pauVar5) [16];
    undefined8 unaff_RDI;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180205890;
    iVar3 = fcn.18045a350();
    pauVar4 = *in_RDX;
    if (pauVar4 != (undefined (*) [16])0x0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar3) = unaff_RDI;
        do {
            pauVar1 = *(undefined (**) [16])*pauVar4;
            pauVar5 = pauVar1;
            if (*in_RDX == pauVar4) {
                *in_RDX = pauVar1;
                pauVar5 = *(undefined (**) [16])*pauVar4;
            }
            if (in_RDX[1] == pauVar4) {
                in_RDX[1] = *(undefined (**) [16])(*pauVar4 + 8);
                pauVar5 = *(undefined (**) [16])*pauVar4;
            }
            if (*(undefined (***) [16])(*pauVar4 + 8) != (undefined (**) [16])0x0) {
                **(undefined (***) [16])(*pauVar4 + 8) = pauVar5;
            }
            if (*(int64_t *)*pauVar4 != 0) {
                *(undefined8 *)(*(int64_t *)*pauVar4 + 8) = *(undefined8 *)(*pauVar4 + 8);
            }
            in_RDX[2] = (undefined (*) [16])(in_RDX[2][-1] + 0xf);
            *pauVar4 = ZEXT816(0);
            uVar2 = *(undefined8 *)(in_RCX + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x180205904;
            func_0x0001801de180(uVar2, pauVar4);
            pauVar4 = pauVar1;
        } while (pauVar1 != (undefined (*) [16])0x0);
    }
    return;
}

// ============================================================
// Function: FUN_180205920
// Address: 0x180205920
// Size: 703 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.180205920(int64_t arg_28h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h,
                  int64_t arg_d0h, int64_t arg_170h)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    char cVar3;
    undefined4 uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    undefined8 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t uVar13;
    int64_t iVar14;
    uint64_t uVar15;
    undefined8 in_R8;
    uint64_t in_R9;
    undefined8 uStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_48;
    int64_t var_20h;
    int64_t var_8h;
    
    uStack_48 = 0x180205937;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    *(uint64_t *)((int64_t)&arg_28h + iVar10) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar10)
    ;
    iVar9 = *(int32_t *)((int64_t)&arg_c0h + iVar10);
    piVar6 = *(int64_t **)((int64_t)&arg_d0h + iVar10);
    *(undefined8 *)((int64_t)&var_10h + iVar10) = *(undefined8 *)((int64_t)&arg_a0h + iVar10);
    *(undefined8 *)((int64_t)&var_8h + iVar10) = in_R8;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar10) = in_RDX;
    *(undefined8 *)(&stack0x00000000 + iVar10) = *(undefined8 *)((int64_t)&arg_a8h + iVar10);
    *(undefined4 *)(&stack0xfffffffffffffff0 + iVar10) = 0;
    *(undefined4 *)(&stack0xfffffffffffffff4 + iVar10) = 0;
    *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x1802059a0;
    iVar11 = fcn.18020d3c0(in_RCX + 0xa8, iVar9, 1);
    if ((((in_R9 < 0x80000000) && (uVar7 = *(uint64_t *)(&stack0x000000b0 + iVar10), uVar7 < 0x80000000)) &&
        (iVar11 != 0)) && (*(uint32_t *)(iVar11 + 100) < in_R9)) {
        uVar4 = *(undefined4 *)(iVar11 + 0x60);
        *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x1802059e2;
        uVar12 = func_0x0001801f9b40(uVar4);
        if (*(uint64_t *)(in_RCX + 0x3f0) < uVar12) {
            uVar12 = *(uint64_t *)((int64_t)&arg_b8h + iVar10);
            if (iVar9 == 3) {
                uVar2 = *(uint8_t *)((int64_t)&arg_c8h + iVar10);
                if (1 < uVar2) goto code_r0x000180205bad;
                cVar3 = *(char *)(iVar11 + 0x68);
                uVar15 = (uint64_t)uVar2;
                if (cVar3 == '\x03') {
                    uVar15 = (uint64_t)(*(uint32_t *)(iVar11 + 0x50) & 1);
                }
                if (cVar3 == '\x01') {
                    *piVar6 = ((uint64_t)((uint32_t)*(undefined8 *)(iVar11 + 0x50) & 1) ^ (uint64_t)uVar2) +
                              *(int64_t *)(iVar11 + 0x50);
                    uVar13 = 0;
                } else if (cVar3 == '\x02') {
                    uVar13 = (uint64_t)(*(uint32_t *)(iVar11 + 0x50) & 1 ^ (uint32_t)uVar2);
                    *piVar6 = *(int64_t *)(iVar11 + 0x50) - uVar13;
                } else {
                    uVar13 = 0;
                    if (cVar3 == '\x03') {
                        *piVar6 = *(int64_t *)(iVar11 + 0x50);
                        uVar13 = 0;
                    }
                }
                if ((1 < uVar15) || (((int32_t)uVar13 != 0 && (*(uint64_t *)(in_RCX + 0x3f8) <= uVar12))))
                goto code_r0x000180205bad;
            } else {
                *piVar6 = 0;
                uVar15 = 0;
            }
            uVar8 = *(undefined8 *)(iVar11 + 0x30 + uVar15 * 8);
            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180205a8c;
            iVar9 = func_0x00018020e980(uVar8);
            if (7 < iVar9) {
                iVar14 = (int64_t)iVar9;
                *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180205ab0;
                func_0x000180498030((int64_t)&var_18h + iVar10, iVar11 + 0x6a + uVar15 * 0x10, iVar14);
                puVar1 = (uint8_t *)((int64_t)&var_10h + iVar14 + iVar10 + 7);
                *puVar1 = *puVar1 ^ (uint8_t)uVar12;
                puVar1 = (uint8_t *)((int64_t)&var_10h + iVar14 + iVar10 + 6);
                *puVar1 = *puVar1 ^ (uint8_t)(uVar12 >> 8);
                *(undefined4 *)(&stack0xffffffffffffffe8 + iVar10) = 0;
                puVar1 = (uint8_t *)((int64_t)&var_10h + iVar14 + iVar10 + 5);
                *puVar1 = *puVar1 ^ (uint8_t)(uVar12 >> 0x10);
                puVar1 = (uint8_t *)((int64_t)&var_10h + iVar14 + iVar10 + 4);
                *puVar1 = *puVar1 ^ (uint8_t)(uVar12 >> 0x18);
                puVar1 = (uint8_t *)((int64_t)&var_10h + iVar14 + iVar10 + 3);
                *puVar1 = *puVar1 ^ (uint8_t)(uVar12 >> 0x20);
                puVar1 = (uint8_t *)((int64_t)&var_10h + iVar14 + iVar10 + 2);
                *puVar1 = *puVar1 ^ (uint8_t)(uVar12 >> 0x28);
                puVar1 = (uint8_t *)((int64_t)&var_10h + iVar14 + iVar10 + 1);
                *puVar1 = *puVar1 ^ (uint8_t)(uVar12 >> 0x30);
                puVar1 = (uint8_t *)((int64_t)&var_10h + iVar14 + iVar10);
                *puVar1 = *puVar1 ^ (uint8_t)(uVar12 >> 0x38);
                *(int64_t *)((int64_t)&var_20h + iVar10) = (int64_t)&var_18h + iVar10;
                *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180205b22;
                iVar9 = func_0x000180211b70(uVar8, 0, 0, 0);
                if (iVar9 == 1) {
                    uVar5 = *(uint32_t *)(iVar11 + 100);
                    iVar14 = *(int64_t *)((int64_t)&var_8h + iVar10);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180205b4a;
                    iVar9 = func_0x000180210b80(uVar8, 0x11, (uint64_t)uVar5, (in_R9 - uVar5) + iVar14);
                    if (iVar9 == 1) {
                        *(int32_t *)((int64_t)&var_20h + iVar10) = (int32_t)uVar7;
                        *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180205b68;
                        iVar9 = func_0x000180211bb0(uVar8, 0, &stack0xfffffffffffffff0 + iVar10, 
                                                    *(undefined8 *)(&stack0x00000000 + iVar10));
                        if (iVar9 == 1) {
                            *(int32_t *)((int64_t)&var_20h + iVar10) = (int32_t)in_R9 - *(int32_t *)(iVar11 + 100);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180205b8b;
                            iVar9 = func_0x000180211bb0(uVar8, *(undefined8 *)((int64_t)&uStackX_8 + iVar10), 
                                                        &stack0xfffffffffffffff0 + iVar10, iVar14);
                            if (iVar9 == 1) {
                                *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180205b9f;
                                iVar9 = func_0x000180211b40(uVar8, 0, &stack0xfffffffffffffff4 + iVar10);
                                if (iVar9 == 1) {
                                    **(int64_t **)((int64_t)&var_10h + iVar10) =
                                         (int64_t)*(int32_t *)(&stack0xfffffffffffffff0 + iVar10);
                                } else {
                                    *(int64_t *)(in_RCX + 0x3f0) = *(int64_t *)(in_RCX + 0x3f0) + 1;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
code_r0x000180205bad:
    *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180205bba;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_28h + iVar10) ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar10));
    return;
}

// ============================================================
// Function: FUN_180205c30
// Address: 0x180205c30
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180205c30(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180205c40;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    iVar2 = *(int64_t *)(in_RCX + 0x60);
    if (iVar2 == 0) {
        if (in_RDX < 0xfffffffffffffed7) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180205c74;
            iVar2 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
            if (iVar2 != 0) {
                *(undefined (*) [16])(iVar2 + 0x48) = ZEXT816(0);
                *(uint64_t *)(iVar2 + 0x60) = in_RDX;
                *(undefined8 *)(iVar2 + 0x58) = 0;
                *(undefined8 *)(iVar2 + 0x68) = 0;
                if (*(int64_t *)(in_RCX + 0x68) != 0) {
                    *(int64_t *)(*(int64_t *)(in_RCX + 0x68) + 0x48) = iVar2;
                }
                *(undefined8 *)(iVar2 + 0x50) = *(undefined8 *)(in_RCX + 0x68);
                *(undefined8 *)(iVar2 + 0x48) = 0;
                *(int64_t *)(in_RCX + 0x68) = iVar2;
                if (*(int64_t *)(in_RCX + 0x60) == 0) {
                    *(int64_t *)(in_RCX + 0x60) = iVar2;
                }
                *(int64_t *)(in_RCX + 0x70) = *(int64_t *)(in_RCX + 0x70) + 1;
                return iVar2;
            }
        }
        iVar2 = 0;
    }
    return iVar2;
}

// ============================================================
// Function: FUN_180205ce0
// Address: 0x180205ce0
// Size: 478 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000180205eba)
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_29h
// WARNING: [rz-ghidra] Detected overlap for variable var_19h

void fcn.180205ce0(int64_t arg_30h, int64_t arg_38h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined (*pauVar6) [16];
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180205d02;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_30h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5);
    pauVar6 = *(undefined (**) [16])(in_RCX + 0x30);
    if (pauVar6 != (undefined (*) [16])0x0) {
        do {
            uVar1 = *(uint64_t *)pauVar6[1];
            *(int64_t *)(in_RCX + 1000) = *(int64_t *)(in_RCX + 1000) + uVar1;
            *(undefined *)((int64_t)&var_18h + iVar5) = 0xff;
            iVar4 = 0;
            *(undefined4 *)(&stack0x00000029 + iVar5) = 0;
            *(undefined (*) [16])((int64_t)&var_18h + iVar5 + 1) = ZEXT816(0);
            if (uVar1 < 0x8000000000000000) {
                *(undefined (**) [16])((int64_t)&var_8h + iVar5) = pauVar6 + 8;
                *(uint64_t *)((int64_t)&var_10h + iVar5) = uVar1;
                uVar2 = uVar1;
                uVar7 = 0;
                for (uVar8 = 0; ((uVar2 != 0 && (iVar4 = (int32_t)uVar7, 6 < uVar2)) && (uVar8 < 0x40));
                    uVar8 = uVar8 + 1) {
                    *(uint64_t *)(&stack0x00000000 + iVar5) = uVar1;
                    *(int64_t *)(&stack0xfffffffffffffff8 + iVar5) = (int64_t)&var_18h + iVar5;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180205dbe;
                    iVar4 = func_0x000180205ec0(in_RCX, pauVar6, (int64_t)&var_8h + iVar5, uVar8);
                    uVar2 = *(uint64_t *)((int64_t)&var_10h + iVar5);
                    if (iVar4 != 0) {
                        uVar7 = 1;
                    }
                    iVar4 = (int32_t)uVar7;
                }
            }
            if (*(undefined (**) [16])(in_RCX + 0x30) == pauVar6) {
                *(undefined8 *)(in_RCX + 0x30) = *(undefined8 *)*pauVar6;
            }
            if (*(undefined (**) [16])(in_RCX + 0x38) == pauVar6) {
                *(undefined8 *)(in_RCX + 0x38) = *(undefined8 *)(*pauVar6 + 8);
            }
            if (*(undefined8 **)(*pauVar6 + 8) != (undefined8 *)0x0) {
                **(undefined8 **)(*pauVar6 + 8) = *(undefined8 *)*pauVar6;
            }
            if (*(int64_t *)*pauVar6 != 0) {
                *(undefined8 *)(*(int64_t *)*pauVar6 + 8) = *(undefined8 *)(*pauVar6 + 8);
            }
            *(int64_t *)(in_RCX + 0x40) = *(int64_t *)(in_RCX + 0x40) + -1;
            *pauVar6 = ZEXT816(0);
            if ((iVar4 == 0) ||
               ((pauVar6[7][8] == '\0' && (*(uint64_t *)(in_RCX + 0x20) <= *(uint64_t *)(in_RCX + 0x28))))) {
                if (pauVar6[7][8] != '\0') {
                    pauVar6[7][8] = 0;
                    *(int64_t *)(in_RCX + 0x28) = *(int64_t *)(in_RCX + 0x28) + -1;
                }
                uVar3 = *(undefined8 *)(in_RCX + 0x10);
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180205e7c;
                func_0x0001801de180(uVar3, pauVar6);
            } else {
                if (*(undefined (***) [16])(in_RCX + 0x50) != (undefined (**) [16])0x0) {
                    **(undefined (***) [16])(in_RCX + 0x50) = pauVar6;
                }
                *(undefined8 *)(*pauVar6 + 8) = *(undefined8 *)(in_RCX + 0x50);
                *(undefined8 *)*pauVar6 = 0;
                *(undefined (**) [16])(in_RCX + 0x50) = pauVar6;
                if (*(int64_t *)(in_RCX + 0x48) == 0) {
                    *(undefined (**) [16])(in_RCX + 0x48) = pauVar6;
                }
                *(int64_t *)(in_RCX + 0x58) = *(int64_t *)(in_RCX + 0x58) + 1;
                if (pauVar6[7][8] == '\0') {
                    pauVar6[7][8] = 1;
                    *(int64_t *)(in_RCX + 0x28) = *(int64_t *)(in_RCX + 0x28) + 1;
                }
            }
            pauVar6 = *(undefined (**) [16])(in_RCX + 0x30);
        } while (pauVar6 != (undefined (*) [16])0x0);
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180205e9c;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_30h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_180205ec0
// Address: 0x180205ec0
// Size: 1692 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

undefined8
fcn.180205ec0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_98h, int64_t arg_d8h, int64_t arg_e8h,
             int64_t arg_f0h)
{
    uint32_t *puVar1;
    char cVar2;
    undefined4 uVar3;
    code *pcVar4;
    undefined8 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int32_t iVar10;
    uint32_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    int64_t iVar16;
    undefined8 uVar17;
    uint64_t uVar18;
    int64_t iVar19;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t iVar20;
    int64_t *in_R8;
    undefined4 *puVar21;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180205ee2;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    uVar3 = *(undefined4 *)in_R8;
    uVar6 = *(undefined4 *)((int64_t)in_R8 + 4);
    uVar7 = *(undefined4 *)(in_R8 + 1);
    uVar8 = *(undefined4 *)((int64_t)in_R8 + 0xc);
    iVar19 = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar12) = 0xffffffffffffffff;
    *(undefined8 *)((int64_t)&arg_48h + iVar12) = 0;
    *(int64_t *)((int64_t)&arg_38h + iVar12) = *in_R8;
    *(undefined4 *)((int64_t)&arg_68h + iVar12) = uVar3;
    *(undefined4 *)((int64_t)&arg_68h + iVar12 + 4) = uVar6;
    *(undefined4 *)((int64_t)&arg_70h + iVar12) = uVar7;
    *(undefined4 *)((int64_t)&arg_70h + iVar12 + 4) = uVar8;
    *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x180205f21;
    iVar13 = fcn.180205c30(*(int64_t *)(&stack0xfffffffffffffff8 + iVar12));
    if (iVar13 == 0) {
        return 0;
    }
    uVar17 = *(undefined8 *)(in_RCX + 0x18);
    puVar1 = (uint32_t *)(iVar13 + 0x70);
    uVar14 = 1LL << ((uint8_t)in_R9 & 0x3f);
    uVar18 = *(uint64_t *)(in_RDX + 0x20);
    uVar15 = uVar14 & *(uint64_t *)(in_RDX + 0x28);
    *(uint64_t *)((int64_t)&arg_60h + iVar12) = uVar15;
    *(undefined8 *)((int64_t)&var_8h + iVar12) = 0;
    *(int64_t *)(&stack0x00000000 + iVar12) = (int64_t)&arg_78h + iVar12;
    *(uint32_t **)(&stack0xfffffffffffffff8 + iVar12) = puVar1;
    *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x180205f7f;
    iVar9 = func_0x0001801f8d60(in_R8, uVar17, uVar15 == 0, 0);
    if (iVar9 == 0) {
code_r0x000180206529:
        uVar18 = *(uint64_t *)(in_RDX + 0x20);
        if (iVar19 != 0) {
            *(uint64_t *)(in_RDX + 0x20) = uVar18 | 1LL << (in_R9 & 0x3f);
            iVar12 = *in_R8;
            if ((uint64_t)in_R8[1] < (uint64_t)(iVar19 - iVar12)) {
                return 0;
            }
            *in_R8 = iVar19;
            iVar19 = in_R8[1] - (iVar19 - iVar12);
            goto code_r0x0001802061e3;
        }
    } else {
        iVar19 = *in_R8;
        puVar21 = *(undefined4 **)((int64_t)&arg_e8h + iVar12);
        if (in_R9 == 0) {
            uVar3 = *(undefined4 *)(iVar13 + 0x7c);
            uVar6 = *(undefined4 *)(iVar13 + 0x80);
            uVar7 = *(undefined4 *)(iVar13 + 0x84);
            *puVar21 = *(undefined4 *)(iVar13 + 0x78);
            puVar21[1] = uVar3;
            puVar21[2] = uVar6;
            puVar21[3] = uVar7;
            puVar21[4] = *(undefined4 *)(iVar13 + 0x88);
            *(undefined *)(puVar21 + 5) = *(undefined *)(iVar13 + 0x8c);
        }
        if ((uVar14 & uVar18) != 0) goto code_r0x000180206529;
        if (in_R9 == 0) {
            puVar21 = (undefined4 *)0x0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x180205fd2;
        iVar9 = func_0x000180206870(in_RCX, iVar13, puVar21);
        if (iVar9 == 0) goto code_r0x000180206529;
        if (((*puVar1 & 0xff) == 4) || ((*puVar1 & 0xff) == 6)) {
            if (*(uint64_t *)(iVar13 + 0xb8) <= *(uint64_t *)(iVar13 + 0x60)) {
code_r0x00018020642a:
                uVar17 = *(undefined8 *)(iVar13 + 0xc0);
                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x180206447;
                func_0x000180498030(iVar13 + 0x128, uVar17);
                iVar19 = 0;
                *(uint64_t *)(in_RDX + 0x20) = *(uint64_t *)(in_RDX + 0x20) | 1LL << (in_R9 & 0x3f);
                *(undefined8 *)(iVar13 + 0x58) = *(undefined8 *)(iVar13 + 0xb8);
                *(undefined8 *)(iVar13 + 0x110) = *(undefined8 *)((int64_t)&arg_f0h + iVar12);
                *(int64_t *)(iVar13 + 0xc0) = iVar13 + 0x128;
                *(undefined8 *)(iVar13 + 200) = 0xffffffffffffffff;
                *(undefined8 *)(iVar13 + 0x118) = 0;
                uVar3 = *(undefined4 *)(in_RDX + 0x3c);
                uVar6 = *(undefined4 *)(in_RDX + 0x40);
                uVar7 = *(undefined4 *)(in_RDX + 0x44);
                *(undefined4 *)(iVar13 + 0xd0) = *(undefined4 *)(in_RDX + 0x38);
                *(undefined4 *)(iVar13 + 0xd4) = uVar3;
                *(undefined4 *)(iVar13 + 0xd8) = uVar6;
                *(undefined4 *)(iVar13 + 0xdc) = uVar7;
                *(undefined8 *)(iVar13 + 0xe0) = *(undefined8 *)(in_RDX + 0x48);
                *(undefined4 *)(iVar13 + 0xe8) = *(undefined4 *)(in_RDX + 0x50);
                uVar3 = *(undefined4 *)(in_RDX + 0x58);
                uVar6 = *(undefined4 *)(in_RDX + 0x5c);
                uVar7 = *(undefined4 *)(in_RDX + 0x60);
                *(undefined4 *)(iVar13 + 0xec) = *(undefined4 *)(in_RDX + 0x54);
                *(undefined4 *)(iVar13 + 0xf0) = uVar3;
                *(undefined4 *)(iVar13 + 0xf4) = uVar6;
                *(undefined4 *)(iVar13 + 0xf8) = uVar7;
                *(undefined8 *)(iVar13 + 0xfc) = *(undefined8 *)(in_RDX + 100);
                *(undefined4 *)(iVar13 + 0x104) = *(undefined4 *)(in_RDX + 0x6c);
                *(undefined8 *)(iVar13 + 0x108) = *(undefined8 *)(in_RDX + 0x70);
                *(undefined8 *)(iVar13 + 0x120) = *(undefined8 *)(in_RDX + 0x30);
                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1802064ed;
                func_0x0001802050b0(in_RCX + 0x60, iVar13);
                if (*(int64_t *)(in_RCX + 0x80) != 0) {
                    *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x48) = iVar13;
                }
                *(undefined8 *)(iVar13 + 0x50) = *(undefined8 *)(in_RCX + 0x80);
                *(int64_t *)(iVar13 + 0x48) = iVar19;
                *(int64_t *)(in_RCX + 0x80) = iVar13;
                if (*(int64_t *)(in_RCX + 0x78) == iVar19) {
                    *(int64_t *)(in_RCX + 0x78) = iVar13;
                }
                *(int64_t *)(in_RCX + 0x88) = *(int64_t *)(in_RCX + 0x88) + 1;
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x18020641e;
            iVar13 = func_0x0001802065f0(in_RCX + 0x60, iVar13);
            if (iVar13 != 0) goto code_r0x00018020642a;
            goto code_r0x000180206529;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x180205ff9;
        iVar9 = func_0x000180205be0(puVar1);
        *(int32_t *)((int64_t)&arg_d8h + iVar12) = iVar9;
        *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x180206011;
        iVar10 = func_0x00018020d3f0(in_RCX + 0xa8, iVar9);
        if (iVar10 == 0) {
code_r0x0001802063e2:
            iVar12 = *in_R8;
            if ((uint64_t)(iVar19 - iVar12) <= (uint64_t)in_R8[1]) {
                *in_R8 = iVar19;
                in_R8[1] = in_R8[1] - (iVar19 - iVar12);
            }
            return 1;
        }
        if (iVar10 != 1) goto code_r0x000180206529;
        if ((iVar9 == 3) && (*(char *)(in_RCX + 0x421) == '\0')) goto code_r0x0001802063e2;
        cVar2 = *(char *)puVar1;
        uVar18 = 0;
        *(undefined8 *)((int64_t)&arg_40h + iVar12) = 0;
        if (cVar2 == '\x01') {
            uVar18 = *(uint64_t *)(iVar13 + 0xb0);
            iVar16 = *(int64_t *)(iVar13 + 0xa8);
            *(int64_t *)((int64_t)&arg_58h + iVar12) = iVar16;
            if (uVar18 == 0) {
                uVar18 = *(uint64_t *)((int64_t)&arg_40h + iVar12);
            } else {
                if (*(uint64_t *)(iVar13 + 0x60) < uVar18) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x180206074;
                    iVar13 = func_0x0001802065f0(in_RCX + 0x60, iVar13, uVar18);
                    if (iVar13 == 0) goto code_r0x000180206529;
                    iVar16 = *(int64_t *)((int64_t)&arg_58h + iVar12);
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x18020609a;
                func_0x000180498030(iVar13 + 0x128, iVar16, uVar18);
                iVar16 = iVar13 + 0x128;
            }
            *(int64_t *)(iVar13 + 0xa8) = iVar16;
        }
        uVar6 = *(undefined4 *)((int64_t)&arg_68h + iVar12 + 4);
        uVar7 = *(undefined4 *)((int64_t)&arg_70h + iVar12);
        uVar8 = *(undefined4 *)((int64_t)&arg_70h + iVar12 + 4);
        uVar3 = *(undefined4 *)((int64_t)&arg_d8h + iVar12);
        *(undefined4 *)in_R8 = *(undefined4 *)((int64_t)&arg_68h + iVar12);
        *(undefined4 *)((int64_t)in_R8 + 4) = uVar6;
        *(undefined4 *)(in_R8 + 1) = uVar7;
        *(undefined4 *)((int64_t)in_R8 + 0xc) = uVar8;
        *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1802060d4;
        uVar17 = fcn.18020d3c0(in_RCX + 0xa8, uVar3, 1);
        *(undefined8 *)((int64_t)&arg_40h + iVar12) = uVar17;
        if (*(int64_t *)((int64_t)&arg_60h + iVar12) == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1802060f4;
            iVar9 = func_0x0001801f8980(uVar17, (int64_t)&arg_78h + iVar12);
            if (iVar9 != 0) {
                *(uint64_t *)(in_RDX + 0x28) = *(uint64_t *)(in_RDX + 0x28) | 1LL << (in_R9 & 0x3f);
                uVar17 = *(undefined8 *)(in_RCX + 0x18);
                *(undefined8 *)((int64_t)&var_8h + iVar12) = 0;
                *(undefined8 *)(&stack0x00000000 + iVar12) = 0;
                *(int64_t *)(&stack0xfffffffffffffff8 + iVar12) = iVar13 + 0x70;
                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x18020612f;
                iVar9 = func_0x0001801f8d60(in_R8, uVar17, 0, 0);
                if (iVar9 == 1) goto code_r0x000180206138;
            }
            goto code_r0x000180206529;
        }
code_r0x000180206138:
        *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x180206143;
        iVar9 = func_0x0001802067d0(in_RCX, iVar13);
        if (iVar9 == 0) goto code_r0x000180206529;
        pcVar4 = *(code **)(in_RCX + 0x428);
        if (pcVar4 != (code *)0x0) {
            iVar16 = *(int64_t *)(iVar13 + 0xb8);
            *(undefined8 *)((int64_t)&var_8h + iVar12) = *(undefined8 *)(in_RCX + 0x430);
            *(undefined8 *)(&stack0x00000000 + iVar12) = *(undefined8 *)(in_RCX + 0x438);
            *(int64_t *)(&stack0xfffffffffffffff8 + iVar12) =
                 (iVar19 - iVar16) - *(int64_t *)((int64_t)&arg_38h + iVar12);
            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x180206196;
            (*pcVar4)(0, 1, 0x201);
        }
        iVar16 = *(int64_t *)((int64_t)&arg_38h + iVar12);
        iVar20 = *(int64_t *)(iVar13 + 0xc0) - iVar16;
        if (*(uint64_t *)(iVar13 + 0x60) < *(int64_t *)(iVar13 + 0xb8) + uVar18) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1802061c1;
            iVar13 = func_0x0001802065f0(in_RCX + 0x60, iVar13);
            iVar16 = *(int64_t *)((int64_t)&arg_38h + iVar12);
        }
        if (iVar13 != 0) {
            uVar11 = *(uint32_t *)(iVar13 + 0x70);
            *(int64_t *)((int64_t)&arg_28h + iVar12) = (int64_t)&arg_50h + iVar12;
            *(uint8_t *)((int64_t)&var_20h + iVar12) = (uint8_t)(uVar11 >> 9) & 1;
            *(undefined4 *)((int64_t)&var_18h + iVar12) = *(undefined4 *)((int64_t)&arg_d8h + iVar12);
            *(undefined8 *)((int64_t)&var_10h + iVar12) = *(undefined8 *)(iVar13 + 200);
            *(int64_t *)((int64_t)&var_8h + iVar12) = iVar20;
            *(int64_t *)(&stack0x00000000 + iVar12) = iVar16;
            *(int64_t *)(&stack0xfffffffffffffff8 + iVar12) = (int64_t)&arg_48h + iVar12;
            *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x18020626e;
            iVar9 = fcn.180205920(*(int64_t *)(&stack0xfffffffffffffff8 + iVar12), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar12), *(int64_t *)((int64_t)&arg_78h + iVar12), 
                                  *(int64_t *)(&stack0x00000088 + iVar12), *(int64_t *)(&stack0x00000090 + iVar12), 
                                  *(int64_t *)((int64_t)&arg_98h + iVar12), *(int64_t *)(&stack0x000000a0 + iVar12), 
                                  *(int64_t *)(&stack0x00000140 + iVar12));
            if (iVar9 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x180206281;
                iVar9 = func_0x0001802068f0(in_RCX, iVar13);
                if (iVar9 != 0) {
                    if (((char)*(uint32_t *)(iVar13 + 0x70) == '\x05') &&
                       ((((uint8_t)(*(uint32_t *)(iVar13 + 0x70) >> 9) ^
                         *(uint8_t *)(*(int64_t *)((int64_t)&arg_40h + iVar12) + 0x50)) & 1) != 0)) {
                        uVar17 = *(undefined8 *)(iVar13 + 200);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1802062bb;
                        iVar9 = func_0x00018020d610(in_RCX + 0xa8, 3);
                        if (iVar9 != 0) {
                            pcVar4 = *(code **)(in_RCX + 0x410);
                            *(undefined8 *)(in_RCX + 0x3f8) = uVar17;
                            if (pcVar4 != (code *)0x0) {
                                uVar5 = *(undefined8 *)(in_RCX + 0x418);
                                *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1802062de;
                                (*pcVar4)(uVar17, uVar5);
                            }
                        }
                    }
                    *(uint64_t *)(in_RDX + 0x20) = *(uint64_t *)(in_RDX + 0x20) | 1LL << (in_R9 & 0x3f);
                    uVar17 = *(undefined8 *)((int64_t)&arg_48h + iVar12);
                    uVar14 = *(uint64_t *)(iVar13 + 200);
                    *(undefined8 *)(iVar13 + 0xb8) = uVar17;
                    *(undefined8 *)(iVar13 + 0x58) = uVar17;
                    *(undefined8 *)(iVar13 + 0x110) = *(undefined8 *)((int64_t)&arg_f0h + iVar12);
                    *(undefined8 *)(iVar13 + 0x118) = *(undefined8 *)((int64_t)&arg_50h + iVar12);
                    *(uint64_t *)(iVar13 + 0xc0) = uVar18 + 0x128 + iVar13;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x18020632b;
                    uVar11 = func_0x000180206d40(iVar13);
                    if (*(uint64_t *)(in_RCX + 0x90 + (uint64_t)uVar11 * 8) < uVar14) {
                        *(uint64_t *)(in_RCX + 0x90 + (uint64_t)uVar11 * 8) = uVar14;
                    }
                    uVar3 = *(undefined4 *)(in_RDX + 0x3c);
                    uVar6 = *(undefined4 *)(in_RDX + 0x40);
                    uVar7 = *(undefined4 *)(in_RDX + 0x44);
                    *(undefined4 *)(iVar13 + 0xd0) = *(undefined4 *)(in_RDX + 0x38);
                    *(undefined4 *)(iVar13 + 0xd4) = uVar3;
                    *(undefined4 *)(iVar13 + 0xd8) = uVar6;
                    *(undefined4 *)(iVar13 + 0xdc) = uVar7;
                    *(undefined8 *)(iVar13 + 0xe0) = *(undefined8 *)(in_RDX + 0x48);
                    *(undefined4 *)(iVar13 + 0xe8) = *(undefined4 *)(in_RDX + 0x50);
                    uVar3 = *(undefined4 *)(in_RDX + 0x58);
                    uVar6 = *(undefined4 *)(in_RDX + 0x5c);
                    uVar7 = *(undefined4 *)(in_RDX + 0x60);
                    *(undefined4 *)(iVar13 + 0xec) = *(undefined4 *)(in_RDX + 0x54);
                    *(undefined4 *)(iVar13 + 0xf0) = uVar3;
                    *(undefined4 *)(iVar13 + 0xf4) = uVar6;
                    *(undefined4 *)(iVar13 + 0xf8) = uVar7;
                    *(undefined8 *)(iVar13 + 0xfc) = *(undefined8 *)(in_RDX + 100);
                    *(undefined4 *)(iVar13 + 0x104) = *(undefined4 *)(in_RDX + 0x6c);
                    *(undefined8 *)(iVar13 + 0x108) = *(undefined8 *)(in_RDX + 0x70);
                    *(undefined8 *)(iVar13 + 0x120) = *(undefined8 *)(in_RDX + 0x30);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar12) = 0x1802063a4;
                    func_0x0001802050b0(in_RCX + 0x60, iVar13);
                    if (*(int64_t *)(in_RCX + 0x80) != 0) {
                        *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x48) = iVar13;
                    }
                    *(undefined8 *)(iVar13 + 0x50) = *(undefined8 *)(in_RCX + 0x80);
                    *(undefined8 *)(iVar13 + 0x48) = 0;
                    *(int64_t *)(in_RCX + 0x80) = iVar13;
                    if (*(int64_t *)(in_RCX + 0x78) == 0) {
                        *(int64_t *)(in_RCX + 0x78) = iVar13;
                    }
                    *(int64_t *)(in_RCX + 0x88) = *(int64_t *)(in_RCX + 0x88) + 1;
                    return 0;
                }
            }
            goto code_r0x000180206529;
        }
        uVar18 = *(uint64_t *)(in_RDX + 0x20);
    }
    *(uint64_t *)(in_RDX + 0x20) = uVar18 | 1LL << (in_R9 & 0x3f);
    *in_R8 = *in_R8 + in_R8[1];
    iVar19 = 0;
code_r0x0001802061e3:
    in_R8[1] = iVar19;
    return 0;
}

// ============================================================
// Function: FUN_1802065f0
// Address: 0x1802065f0
// Size: 475 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1802065f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18020660e;
    iVar3 = fcn.18045a350();
    if ((in_RDX != 0) && (in_R8 < 0xfffffffffffffed7)) {
        iVar1 = *(int64_t *)(in_RDX + 0x50);
        if (*in_RCX == in_RDX) {
            *in_RCX = *(int64_t *)(in_RDX + 0x48);
        }
        if (in_RCX[1] == in_RDX) {
            in_RCX[1] = *(int64_t *)(in_RDX + 0x50);
        }
        iVar2 = *(int64_t *)(in_RDX + 0x50);
        if (iVar2 != 0) {
            *(undefined8 *)(iVar2 + 0x48) = *(undefined8 *)(in_RDX + 0x48);
        }
        if (*(int64_t *)(in_RDX + 0x48) != 0) {
            *(int64_t *)(*(int64_t *)(in_RDX + 0x48) + 0x50) = *(int64_t *)(in_RDX + 0x50);
        }
        in_RCX[2] = in_RCX[2] + -1;
        *(undefined (*) [16])(in_RDX + 0x48) = ZEXT816(0);
        if (*(int64_t *)(in_RDX + 0x68) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 - iVar3) = 0x1802066b0;
            iVar3 = func_0x0001802249c0(in_RDX, in_R8 + 0x128, 0x1804ba028, 0x270);
            if (iVar3 != 0) {
                if (iVar1 == 0) {
                    if (*in_RCX != 0) {
                        *(int64_t *)(*in_RCX + 0x50) = iVar3;
                    }
                    *(int64_t *)(iVar3 + 0x48) = *in_RCX;
                    *(undefined8 *)(iVar3 + 0x50) = 0;
                    *in_RCX = iVar3;
                    if (in_RCX[1] == 0) {
                        in_RCX[2] = in_RCX[2] + 1;
                        in_RCX[1] = iVar3;
                        *(uint64_t *)(iVar3 + 0x60) = in_R8;
                        return iVar3;
                    }
                } else {
                    *(int64_t *)(iVar3 + 0x50) = iVar1;
                    *(undefined8 *)(iVar3 + 0x48) = *(undefined8 *)(iVar1 + 0x48);
                    if (*(int64_t *)(iVar1 + 0x48) != 0) {
                        *(int64_t *)(*(int64_t *)(iVar1 + 0x48) + 0x50) = iVar3;
                    }
                    *(int64_t *)(iVar1 + 0x48) = iVar3;
                    if (in_RCX[1] == iVar1) {
                        in_RCX[1] = iVar3;
                    }
                }
                in_RCX[2] = in_RCX[2] + 1;
                *(uint64_t *)(iVar3 + 0x60) = in_R8;
                return iVar3;
            }
            if (iVar1 == 0) {
                if (*in_RCX != 0) {
                    *(int64_t *)(*in_RCX + 0x50) = in_RDX;
                }
                *(int64_t *)(in_RDX + 0x48) = *in_RCX;
                *(undefined8 *)(in_RDX + 0x50) = 0;
                *in_RCX = in_RDX;
                if (in_RCX[1] == 0) {
                    in_RCX[1] = in_RDX;
                }
            } else {
                *(int64_t *)(in_RDX + 0x50) = iVar1;
                *(undefined8 *)(in_RDX + 0x48) = *(undefined8 *)(iVar1 + 0x48);
                if (*(int64_t *)(iVar1 + 0x48) != 0) {
                    *(int64_t *)(*(int64_t *)(iVar1 + 0x48) + 0x50) = in_RDX;
                }
                *(int64_t *)(iVar1 + 0x48) = in_RDX;
                if (in_RCX[1] == iVar1) {
                    in_RCX[1] = in_RDX;
                }
            }
            in_RCX[2] = in_RCX[2] + 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802067d0
// Address: 0x1802067d0
// Size: 148 bytes
// ============================================================
bool fcn.1802067d0(int64_t param_1, int64_t param_2)
{
    uint32_t uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802067da;
    iVar4 = fcn.18045a350();
    uVar1 = *(uint32_t *)(param_2 + 0x70);
    // switch table (6 cases) at 0x18020684c
    switch(uVar1 & 0xff) {
    default:
        iVar5 = 0x90;
        break;
    case 2:
    case 5:
        iVar5 = 0xa0;
        break;
    case 3:
        iVar5 = 0x98;
    }
    uVar2 = *(undefined8 *)(iVar5 + param_1);
    *(undefined8 *)((int64_t)&uStack_8 - iVar4) = 0x18020683b;
    iVar3 = func_0x0001801f92c0(param_2 + 0xa2, uVar1 >> 10 & 0xf, uVar2, param_2 + 200);
    return iVar3 != 0;
}

// ============================================================
// Function: FUN_180206870
// Address: 0x180206870
// Size: 121 bytes
// ============================================================
bool fcn.180206870(undefined8 param_1, int64_t param_2, uint8_t *param_3)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020687a;
    iVar4 = fcn.18045a350();
    if (((*(int32_t *)(param_2 + 0x74) == 1) || (*(int32_t *)(param_2 + 0x74) == 0)) &&
       (uVar2 = *(uint32_t *)(param_2 + 0x70) & 0xff, uVar2 != 2)) {
        if (param_3 == (uint8_t *)0x0) {
            return true;
        }
        if ((((uVar2 - 4 & 0xfffffffd) != 0) && (uVar1 = *param_3, uVar1 < 0x14)) &&
           (uVar1 == *(uint8_t *)(param_2 + 0x78))) {
            *(undefined8 *)((int64_t)&uStack_8 - iVar4) = 0x1802068c3;
            iVar3 = func_0x000180497f30(param_3 + 1, param_2 + 0x79, uVar1);
            return iVar3 == 0;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1802068f0
// Address: 0x1802068f0
// Size: 144 bytes
// ============================================================
bool fcn.1802068f0(int64_t param_1, int64_t param_2)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802068fc;
    iVar5 = fcn.18045a350();
    uVar6 = 0;
    // switch table (6 cases) at 0x180206968
    switch(*(undefined *)(param_2 + 0x70)) {
    case 2:
    case 5:
        uVar6 = 2;
        break;
    case 3:
        uVar6 = 1;
    }
    pcVar1 = *(code **)(param_1 + 0x400);
    if (pcVar1 != (code *)0x0) {
        uVar2 = *(undefined8 *)(param_1 + 0x408);
        uVar3 = *(undefined8 *)(param_2 + 200);
        *(undefined8 *)((int64_t)&uStack_10 - iVar5) = 0x180206950;
        iVar4 = (*pcVar1)(uVar3, uVar6, uVar2);
        return iVar4 != 0;
    }
    return true;
}

// ============================================================
// Function: FUN_180206980
// Address: 0x180206980
// Size: 126 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

undefined8
fcn.1802057b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_98h, int64_t arg_a8h,
             int64_t arg_e8h, int64_t arg_f0h, int64_t arg_100h, int64_t arg_160h)
{
    char *pcVar1;
    undefined auVar2 [16];
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    undefined8 uVar12;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar13;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    uint64_t uVar14;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar15;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_10 [2];
    
    auStack_10[1] = 0x1802057ba;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(undefined8 *)(in_RDX + 0x20) = 0;
    *(undefined8 *)(in_RDX + 0x28) = 0;
    *(undefined *)(in_RDX + 0x78) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = *(undefined8 *)(in_RDX + 0x10);
    *(undefined8 *)((int64_t)&var_20h + iVar9) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar9) = unaff_RSI;
    *(undefined8 *)(&stack0x00000010 + iVar9) = unaff_RDI;
    *(undefined8 *)(&stack0x00000008 + iVar9) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar9) = unaff_R14;
    *(undefined8 *)((int64_t)auStack_10 + iVar9 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_10 + iVar9) = 0x180206998;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    uVar14 = 0;
    auVar2._4_4_ = unaff_XMM6_Db;
    auVar2._0_4_ = unaff_XMM6_Da;
    auVar2._8_4_ = unaff_XMM6_Dc;
    auVar2._12_4_ = unaff_XMM6_Dd;
    *(undefined (*) [16])((int64_t)&arg_98h + iVar10 + iVar9) = auVar2;
    *(undefined8 *)((int64_t)&arg_f0h + iVar10 + iVar9) = 0;
    uVar13 = *(uint64_t *)(in_RDX + 0x10);
    *(undefined8 *)((int64_t)&arg_58h + iVar10 + iVar9) = 0xffffffffffffffff;
    if (uVar13 < 0x8000000000000000) {
        *(uint64_t *)((int64_t)&arg_70h + iVar10 + iVar9) = uVar13;
        *(int64_t *)((int64_t)&arg_68h + iVar10 + iVar9) = in_RDX + 0x80;
        uVar3 = *(undefined4 *)((int64_t)&arg_68h + iVar10 + iVar9);
        uVar4 = *(undefined4 *)((int64_t)&arg_68h + iVar10 + iVar9 + 4);
        uVar5 = *(undefined4 *)((int64_t)&arg_70h + iVar10 + iVar9);
        uVar6 = *(undefined4 *)((int64_t)&arg_70h + iVar10 + iVar9 + 4);
        *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x1802069f2;
        iVar11 = fcn.180205c30(*(int64_t *)((int64_t)&var_18h + iVar10 + iVar9));
        if (iVar11 != 0) {
            *(undefined8 *)((int64_t)&arg_e8h + iVar10 + iVar9) = unaff_RBX;
            pcVar1 = (char *)(iVar11 + 0x70);
            *(undefined8 *)((int64_t)&arg_28h + iVar10 + iVar9) = 0;
            *(undefined8 *)((int64_t)&arg_a8h + iVar10 + iVar9) = unaff_R12;
            *(int64_t *)((int64_t)&var_20h + iVar10 + iVar9) = (int64_t)&arg_78h + iVar10 + iVar9;
            *(char **)((int64_t)&var_18h + iVar10 + iVar9) = pcVar1;
            *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206a3e;
            iVar7 = func_0x0001801f8d60((int64_t)&arg_68h + iVar10 + iVar9, 0, 1, 0);
            if (((iVar7 != 0) && (*pcVar1 == '\x01')) &&
               ((*(int32_t *)(iVar11 + 0x74) == 1 || (*(int32_t *)(iVar11 + 0x74) == 0)))) {
                *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206a6d;
                iVar7 = func_0x00018020d3f0(in_RCX + 0xa8, 0);
                if (iVar7 == 1) {
                    if (*pcVar1 == '\x01') {
                        uVar13 = *(uint64_t *)(iVar11 + 0xb0);
                        iVar15 = *(int64_t *)(iVar11 + 0xa8);
                        if (uVar13 != 0) {
                            if (*(uint64_t *)(iVar11 + 0x60) < uVar13) {
                                *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206aa2;
                                iVar11 = fcn.1802065f0(*(int64_t *)((int64_t)&var_18h + iVar10 + iVar9), 
                                                       *(int64_t *)((int64_t)&var_20h + iVar10 + iVar9), 
                                                       *(int64_t *)((int64_t)&arg_28h + iVar10 + iVar9));
                                if (iVar11 == 0) {
                                    return 0;
                                }
                            }
                            *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206ac0;
                            func_0x000180498030(iVar11 + 0x128, iVar15, uVar13);
                            iVar15 = iVar11 + 0x128;
                            uVar14 = uVar13;
                        }
                        *(int64_t *)(iVar11 + 0xa8) = iVar15;
                    }
                    *(undefined4 *)((int64_t)&arg_68h + iVar10 + iVar9) = uVar3;
                    *(undefined4 *)((int64_t)&arg_68h + iVar10 + iVar9 + 4) = uVar4;
                    *(undefined4 *)((int64_t)&arg_70h + iVar10 + iVar9) = uVar5;
                    *(undefined4 *)((int64_t)&arg_70h + iVar10 + iVar9 + 4) = uVar6;
                    *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206af5;
                    uVar12 = fcn.18020d3c0(in_RCX + 0xa8, 0, 1);
                    *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206b05;
                    iVar7 = func_0x0001801f8980(uVar12, (int64_t)&arg_78h + iVar10 + iVar9);
                    if (iVar7 != 0) {
                        *(uint64_t *)(in_RDX + 0x28) = *(uint64_t *)(in_RDX + 0x28) | 1;
                        *(undefined8 *)((int64_t)&arg_28h + iVar10 + iVar9) = 0;
                        *(undefined8 *)((int64_t)&var_20h + iVar10 + iVar9) = 0;
                        *(int64_t *)((int64_t)&var_18h + iVar10 + iVar9) = iVar11 + 0x70;
                        *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206b37;
                        iVar7 = func_0x0001801f8d60((int64_t)&arg_68h + iVar10 + iVar9, 0, 0, 0);
                        if (iVar7 == 1) {
                            *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206b4b;
                            iVar7 = fcn.1802067d0(in_RCX, iVar11);
                            if (iVar7 != 0) {
                                iVar15 = *(int64_t *)(iVar11 + 0xc0);
                                if (*(uint64_t *)(iVar11 + 0x60) < *(int64_t *)(iVar11 + 0xb8) + uVar14) {
                                    *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206b79;
                                    iVar11 = fcn.1802065f0(*(int64_t *)((int64_t)&var_18h + iVar10 + iVar9), 
                                                           *(int64_t *)((int64_t)&var_20h + iVar10 + iVar9), 
                                                           *(int64_t *)((int64_t)&arg_28h + iVar10 + iVar9));
                                }
                                if (iVar11 != 0) {
                                    uVar8 = *(uint32_t *)(iVar11 + 0x70);
                                    *(int64_t *)((int64_t)&arg_48h + iVar10 + iVar9) =
                                         (int64_t)&arg_58h + iVar10 + iVar9;
                                    uVar12 = *(undefined8 *)(iVar11 + 200);
                                    *(uint8_t *)((int64_t)&arg_40h + iVar10 + iVar9) = (uint8_t)(uVar8 >> 9) & 1;
                                    *(undefined4 *)((int64_t)&arg_38h + iVar10 + iVar9) = 0;
                                    *(undefined8 *)((int64_t)&arg_30h + iVar10 + iVar9) = uVar12;
                                    *(int64_t *)((int64_t)&arg_28h + iVar10 + iVar9) = iVar15 - (in_RDX + 0x80);
                                    *(int64_t *)((int64_t)&var_20h + iVar10 + iVar9) = in_RDX + 0x80;
                                    *(int64_t *)((int64_t)&var_18h + iVar10 + iVar9) =
                                         (int64_t)&arg_f0h + iVar10 + iVar9;
                                    *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206bea;
                                    iVar7 = fcn.180205920(*(int64_t *)((int64_t)&var_18h + iVar10 + iVar9), 
                                                          *(int64_t *)(&stack0x00000090 + iVar10 + iVar9), 
                                                          *(int64_t *)((int64_t)&arg_98h + iVar10 + iVar9), 
                                                          *(int64_t *)((int64_t)&arg_a8h + iVar10 + iVar9), 
                                                          *(int64_t *)(&stack0x000000b0 + iVar10 + iVar9), 
                                                          *(int64_t *)(&stack0x000000b8 + iVar10 + iVar9), 
                                                          *(int64_t *)(&stack0x000000c0 + iVar10 + iVar9), 
                                                          *(int64_t *)((int64_t)&arg_160h + iVar10 + iVar9));
                                    if (iVar7 != 0) {
                                        *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206bfd;
                                        iVar7 = fcn.1802068f0(in_RCX, iVar11);
                                        if (iVar7 != 0) {
                                            *(uint64_t *)(in_RDX + 0x20) = *(uint64_t *)(in_RDX + 0x20) | 1;
                                            uVar12 = *(undefined8 *)((int64_t)&arg_f0h + iVar10 + iVar9);
                                            uVar13 = *(uint64_t *)(iVar11 + 200);
                                            *(undefined8 *)(iVar11 + 0xb8) = uVar12;
                                            *(undefined8 *)(iVar11 + 0x58) = uVar12;
                                            *(undefined8 *)(iVar11 + 0x110) =
                                                 *(undefined8 *)((int64_t)&arg_100h + iVar10 + iVar9);
                                            *(undefined8 *)(iVar11 + 0x118) =
                                                 *(undefined8 *)((int64_t)&arg_58h + iVar10 + iVar9);
                                            *(uint64_t *)(iVar11 + 0xc0) = uVar14 + 0x128 + iVar11;
                                            *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206c4e;
                                            uVar8 = func_0x000180206d40(iVar11);
                                            if (*(uint64_t *)(in_RCX + 0x90 + (uint64_t)uVar8 * 8) < uVar13) {
                                                *(uint64_t *)(in_RCX + 0x90 + (uint64_t)uVar8 * 8) = uVar13;
                                            }
                                            uVar3 = *(undefined4 *)(in_RDX + 0x3c);
                                            uVar4 = *(undefined4 *)(in_RDX + 0x40);
                                            uVar5 = *(undefined4 *)(in_RDX + 0x44);
                                            *(undefined4 *)(iVar11 + 0xd0) = *(undefined4 *)(in_RDX + 0x38);
                                            *(undefined4 *)(iVar11 + 0xd4) = uVar3;
                                            *(undefined4 *)(iVar11 + 0xd8) = uVar4;
                                            *(undefined4 *)(iVar11 + 0xdc) = uVar5;
                                            *(undefined8 *)(iVar11 + 0xe0) = *(undefined8 *)(in_RDX + 0x48);
                                            *(undefined4 *)(iVar11 + 0xe8) = *(undefined4 *)(in_RDX + 0x50);
                                            uVar3 = *(undefined4 *)(in_RDX + 0x58);
                                            uVar4 = *(undefined4 *)(in_RDX + 0x5c);
                                            uVar5 = *(undefined4 *)(in_RDX + 0x60);
                                            *(undefined4 *)(iVar11 + 0xec) = *(undefined4 *)(in_RDX + 0x54);
                                            *(undefined4 *)(iVar11 + 0xf0) = uVar3;
                                            *(undefined4 *)(iVar11 + 0xf4) = uVar4;
                                            *(undefined4 *)(iVar11 + 0xf8) = uVar5;
                                            *(undefined8 *)(iVar11 + 0xfc) = *(undefined8 *)(in_RDX + 100);
                                            *(undefined4 *)(iVar11 + 0x104) = *(undefined4 *)(in_RDX + 0x6c);
                                            *(undefined8 *)(iVar11 + 0x108) = *(undefined8 *)(in_RDX + 0x70);
                                            *(undefined8 *)(iVar11 + 0x120) = *(undefined8 *)(in_RDX + 0x30);
                                            *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206cc7;
                                            func_0x0001802050b0(in_RCX + 0x60, iVar11);
                                            if (*(int64_t *)(in_RCX + 0x80) != 0) {
                                                *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x48) = iVar11;
                                            }
                                            *(undefined8 *)(iVar11 + 0x50) = *(undefined8 *)(in_RCX + 0x80);
                                            *(undefined8 *)(iVar11 + 0x48) = 0;
                                            *(int64_t *)(in_RCX + 0x80) = iVar11;
                                            if (*(int64_t *)(in_RCX + 0x78) == 0) {
                                                *(int64_t *)(in_RCX + 0x78) = iVar11;
                                            }
                                            *(int64_t *)(in_RCX + 0x88) = *(int64_t *)(in_RCX + 0x88) + 1;
                                            return 1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return 0;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802069fe
// Address: 0x1802069fe
// Size: 789 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

undefined8
fcn.1802057b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_98h, int64_t arg_a8h,
             int64_t arg_e8h, int64_t arg_f0h, int64_t arg_100h, int64_t arg_160h)
{
    char *pcVar1;
    undefined auVar2 [16];
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    undefined8 uVar12;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar13;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    uint64_t uVar14;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar15;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_10 [2];
    
    auStack_10[1] = 0x1802057ba;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(undefined8 *)(in_RDX + 0x20) = 0;
    *(undefined8 *)(in_RDX + 0x28) = 0;
    *(undefined *)(in_RDX + 0x78) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = *(undefined8 *)(in_RDX + 0x10);
    *(undefined8 *)((int64_t)&var_20h + iVar9) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar9) = unaff_RSI;
    *(undefined8 *)(&stack0x00000010 + iVar9) = unaff_RDI;
    *(undefined8 *)(&stack0x00000008 + iVar9) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar9) = unaff_R14;
    *(undefined8 *)((int64_t)auStack_10 + iVar9 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_10 + iVar9) = 0x180206998;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    uVar14 = 0;
    auVar2._4_4_ = unaff_XMM6_Db;
    auVar2._0_4_ = unaff_XMM6_Da;
    auVar2._8_4_ = unaff_XMM6_Dc;
    auVar2._12_4_ = unaff_XMM6_Dd;
    *(undefined (*) [16])((int64_t)&arg_98h + iVar10 + iVar9) = auVar2;
    *(undefined8 *)((int64_t)&arg_f0h + iVar10 + iVar9) = 0;
    uVar13 = *(uint64_t *)(in_RDX + 0x10);
    *(undefined8 *)((int64_t)&arg_58h + iVar10 + iVar9) = 0xffffffffffffffff;
    if (uVar13 < 0x8000000000000000) {
        *(uint64_t *)((int64_t)&arg_70h + iVar10 + iVar9) = uVar13;
        *(int64_t *)((int64_t)&arg_68h + iVar10 + iVar9) = in_RDX + 0x80;
        uVar3 = *(undefined4 *)((int64_t)&arg_68h + iVar10 + iVar9);
        uVar4 = *(undefined4 *)((int64_t)&arg_68h + iVar10 + iVar9 + 4);
        uVar5 = *(undefined4 *)((int64_t)&arg_70h + iVar10 + iVar9);
        uVar6 = *(undefined4 *)((int64_t)&arg_70h + iVar10 + iVar9 + 4);
        *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x1802069f2;
        iVar11 = fcn.180205c30(*(int64_t *)((int64_t)&var_18h + iVar10 + iVar9));
        if (iVar11 != 0) {
            *(undefined8 *)((int64_t)&arg_e8h + iVar10 + iVar9) = unaff_RBX;
            pcVar1 = (char *)(iVar11 + 0x70);
            *(undefined8 *)((int64_t)&arg_28h + iVar10 + iVar9) = 0;
            *(undefined8 *)((int64_t)&arg_a8h + iVar10 + iVar9) = unaff_R12;
            *(int64_t *)((int64_t)&var_20h + iVar10 + iVar9) = (int64_t)&arg_78h + iVar10 + iVar9;
            *(char **)((int64_t)&var_18h + iVar10 + iVar9) = pcVar1;
            *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206a3e;
            iVar7 = func_0x0001801f8d60((int64_t)&arg_68h + iVar10 + iVar9, 0, 1, 0);
            if (((iVar7 != 0) && (*pcVar1 == '\x01')) &&
               ((*(int32_t *)(iVar11 + 0x74) == 1 || (*(int32_t *)(iVar11 + 0x74) == 0)))) {
                *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206a6d;
                iVar7 = func_0x00018020d3f0(in_RCX + 0xa8, 0);
                if (iVar7 == 1) {
                    if (*pcVar1 == '\x01') {
                        uVar13 = *(uint64_t *)(iVar11 + 0xb0);
                        iVar15 = *(int64_t *)(iVar11 + 0xa8);
                        if (uVar13 != 0) {
                            if (*(uint64_t *)(iVar11 + 0x60) < uVar13) {
                                *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206aa2;
                                iVar11 = fcn.1802065f0(*(int64_t *)((int64_t)&var_18h + iVar10 + iVar9), 
                                                       *(int64_t *)((int64_t)&var_20h + iVar10 + iVar9), 
                                                       *(int64_t *)((int64_t)&arg_28h + iVar10 + iVar9));
                                if (iVar11 == 0) {
                                    return 0;
                                }
                            }
                            *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206ac0;
                            func_0x000180498030(iVar11 + 0x128, iVar15, uVar13);
                            iVar15 = iVar11 + 0x128;
                            uVar14 = uVar13;
                        }
                        *(int64_t *)(iVar11 + 0xa8) = iVar15;
                    }
                    *(undefined4 *)((int64_t)&arg_68h + iVar10 + iVar9) = uVar3;
                    *(undefined4 *)((int64_t)&arg_68h + iVar10 + iVar9 + 4) = uVar4;
                    *(undefined4 *)((int64_t)&arg_70h + iVar10 + iVar9) = uVar5;
                    *(undefined4 *)((int64_t)&arg_70h + iVar10 + iVar9 + 4) = uVar6;
                    *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206af5;
                    uVar12 = fcn.18020d3c0(in_RCX + 0xa8, 0, 1);
                    *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206b05;
                    iVar7 = func_0x0001801f8980(uVar12, (int64_t)&arg_78h + iVar10 + iVar9);
                    if (iVar7 != 0) {
                        *(uint64_t *)(in_RDX + 0x28) = *(uint64_t *)(in_RDX + 0x28) | 1;
                        *(undefined8 *)((int64_t)&arg_28h + iVar10 + iVar9) = 0;
                        *(undefined8 *)((int64_t)&var_20h + iVar10 + iVar9) = 0;
                        *(int64_t *)((int64_t)&var_18h + iVar10 + iVar9) = iVar11 + 0x70;
                        *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206b37;
                        iVar7 = func_0x0001801f8d60((int64_t)&arg_68h + iVar10 + iVar9, 0, 0, 0);
                        if (iVar7 == 1) {
                            *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206b4b;
                            iVar7 = fcn.1802067d0(in_RCX, iVar11);
                            if (iVar7 != 0) {
                                iVar15 = *(int64_t *)(iVar11 + 0xc0);
                                if (*(uint64_t *)(iVar11 + 0x60) < *(int64_t *)(iVar11 + 0xb8) + uVar14) {
                                    *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206b79;
                                    iVar11 = fcn.1802065f0(*(int64_t *)((int64_t)&var_18h + iVar10 + iVar9), 
                                                           *(int64_t *)((int64_t)&var_20h + iVar10 + iVar9), 
                                                           *(int64_t *)((int64_t)&arg_28h + iVar10 + iVar9));
                                }
                                if (iVar11 != 0) {
                                    uVar8 = *(uint32_t *)(iVar11 + 0x70);
                                    *(int64_t *)((int64_t)&arg_48h + iVar10 + iVar9) =
                                         (int64_t)&arg_58h + iVar10 + iVar9;
                                    uVar12 = *(undefined8 *)(iVar11 + 200);
                                    *(uint8_t *)((int64_t)&arg_40h + iVar10 + iVar9) = (uint8_t)(uVar8 >> 9) & 1;
                                    *(undefined4 *)((int64_t)&arg_38h + iVar10 + iVar9) = 0;
                                    *(undefined8 *)((int64_t)&arg_30h + iVar10 + iVar9) = uVar12;
                                    *(int64_t *)((int64_t)&arg_28h + iVar10 + iVar9) = iVar15 - (in_RDX + 0x80);
                                    *(int64_t *)((int64_t)&var_20h + iVar10 + iVar9) = in_RDX + 0x80;
                                    *(int64_t *)((int64_t)&var_18h + iVar10 + iVar9) =
                                         (int64_t)&arg_f0h + iVar10 + iVar9;
                                    *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206bea;
                                    iVar7 = fcn.180205920(*(int64_t *)((int64_t)&var_18h + iVar10 + iVar9), 
                                                          *(int64_t *)(&stack0x00000090 + iVar10 + iVar9), 
                                                          *(int64_t *)((int64_t)&arg_98h + iVar10 + iVar9), 
                                                          *(int64_t *)((int64_t)&arg_a8h + iVar10 + iVar9), 
                                                          *(int64_t *)(&stack0x000000b0 + iVar10 + iVar9), 
                                                          *(int64_t *)(&stack0x000000b8 + iVar10 + iVar9), 
                                                          *(int64_t *)(&stack0x000000c0 + iVar10 + iVar9), 
                                                          *(int64_t *)((int64_t)&arg_160h + iVar10 + iVar9));
                                    if (iVar7 != 0) {
                                        *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206bfd;
                                        iVar7 = fcn.1802068f0(in_RCX, iVar11);
                                        if (iVar7 != 0) {
                                            *(uint64_t *)(in_RDX + 0x20) = *(uint64_t *)(in_RDX + 0x20) | 1;
                                            uVar12 = *(undefined8 *)((int64_t)&arg_f0h + iVar10 + iVar9);
                                            uVar13 = *(uint64_t *)(iVar11 + 200);
                                            *(undefined8 *)(iVar11 + 0xb8) = uVar12;
                                            *(undefined8 *)(iVar11 + 0x58) = uVar12;
                                            *(undefined8 *)(iVar11 + 0x110) =
                                                 *(undefined8 *)((int64_t)&arg_100h + iVar10 + iVar9);
                                            *(undefined8 *)(iVar11 + 0x118) =
                                                 *(undefined8 *)((int64_t)&arg_58h + iVar10 + iVar9);
                                            *(uint64_t *)(iVar11 + 0xc0) = uVar14 + 0x128 + iVar11;
                                            *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206c4e;
                                            uVar8 = func_0x000180206d40(iVar11);
                                            if (*(uint64_t *)(in_RCX + 0x90 + (uint64_t)uVar8 * 8) < uVar13) {
                                                *(uint64_t *)(in_RCX + 0x90 + (uint64_t)uVar8 * 8) = uVar13;
                                            }
                                            uVar3 = *(undefined4 *)(in_RDX + 0x3c);
                                            uVar4 = *(undefined4 *)(in_RDX + 0x40);
                                            uVar5 = *(undefined4 *)(in_RDX + 0x44);
                                            *(undefined4 *)(iVar11 + 0xd0) = *(undefined4 *)(in_RDX + 0x38);
                                            *(undefined4 *)(iVar11 + 0xd4) = uVar3;
                                            *(undefined4 *)(iVar11 + 0xd8) = uVar4;
                                            *(undefined4 *)(iVar11 + 0xdc) = uVar5;
                                            *(undefined8 *)(iVar11 + 0xe0) = *(undefined8 *)(in_RDX + 0x48);
                                            *(undefined4 *)(iVar11 + 0xe8) = *(undefined4 *)(in_RDX + 0x50);
                                            uVar3 = *(undefined4 *)(in_RDX + 0x58);
                                            uVar4 = *(undefined4 *)(in_RDX + 0x5c);
                                            uVar5 = *(undefined4 *)(in_RDX + 0x60);
                                            *(undefined4 *)(iVar11 + 0xec) = *(undefined4 *)(in_RDX + 0x54);
                                            *(undefined4 *)(iVar11 + 0xf0) = uVar3;
                                            *(undefined4 *)(iVar11 + 0xf4) = uVar4;
                                            *(undefined4 *)(iVar11 + 0xf8) = uVar5;
                                            *(undefined8 *)(iVar11 + 0xfc) = *(undefined8 *)(in_RDX + 100);
                                            *(undefined4 *)(iVar11 + 0x104) = *(undefined4 *)(in_RDX + 0x6c);
                                            *(undefined8 *)(iVar11 + 0x108) = *(undefined8 *)(in_RDX + 0x70);
                                            *(undefined8 *)(iVar11 + 0x120) = *(undefined8 *)(in_RDX + 0x30);
                                            *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206cc7;
                                            func_0x0001802050b0(in_RCX + 0x60, iVar11);
                                            if (*(int64_t *)(in_RCX + 0x80) != 0) {
                                                *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x48) = iVar11;
                                            }
                                            *(undefined8 *)(iVar11 + 0x50) = *(undefined8 *)(in_RCX + 0x80);
                                            *(undefined8 *)(iVar11 + 0x48) = 0;
                                            *(int64_t *)(in_RCX + 0x80) = iVar11;
                                            if (*(int64_t *)(in_RCX + 0x78) == 0) {
                                                *(int64_t *)(in_RCX + 0x78) = iVar11;
                                            }
                                            *(int64_t *)(in_RCX + 0x88) = *(int64_t *)(in_RCX + 0x88) + 1;
                                            return 1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return 0;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180206d13
// Address: 0x180206d13
// Size: 25 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

undefined8
fcn.1802057b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_98h, int64_t arg_a8h,
             int64_t arg_e8h, int64_t arg_f0h, int64_t arg_100h, int64_t arg_160h)
{
    char *pcVar1;
    undefined auVar2 [16];
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    undefined8 uVar12;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar13;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    uint64_t uVar14;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar15;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_10 [2];
    
    auStack_10[1] = 0x1802057ba;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(undefined8 *)(in_RDX + 0x20) = 0;
    *(undefined8 *)(in_RDX + 0x28) = 0;
    *(undefined *)(in_RDX + 0x78) = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar9) = *(undefined8 *)(in_RDX + 0x10);
    *(undefined8 *)((int64_t)&var_20h + iVar9) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar9) = unaff_RSI;
    *(undefined8 *)(&stack0x00000010 + iVar9) = unaff_RDI;
    *(undefined8 *)(&stack0x00000008 + iVar9) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar9) = unaff_R14;
    *(undefined8 *)((int64_t)auStack_10 + iVar9 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_10 + iVar9) = 0x180206998;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    uVar14 = 0;
    auVar2._4_4_ = unaff_XMM6_Db;
    auVar2._0_4_ = unaff_XMM6_Da;
    auVar2._8_4_ = unaff_XMM6_Dc;
    auVar2._12_4_ = unaff_XMM6_Dd;
    *(undefined (*) [16])((int64_t)&arg_98h + iVar10 + iVar9) = auVar2;
    *(undefined8 *)((int64_t)&arg_f0h + iVar10 + iVar9) = 0;
    uVar13 = *(uint64_t *)(in_RDX + 0x10);
    *(undefined8 *)((int64_t)&arg_58h + iVar10 + iVar9) = 0xffffffffffffffff;
    if (uVar13 < 0x8000000000000000) {
        *(uint64_t *)((int64_t)&arg_70h + iVar10 + iVar9) = uVar13;
        *(int64_t *)((int64_t)&arg_68h + iVar10 + iVar9) = in_RDX + 0x80;
        uVar3 = *(undefined4 *)((int64_t)&arg_68h + iVar10 + iVar9);
        uVar4 = *(undefined4 *)((int64_t)&arg_68h + iVar10 + iVar9 + 4);
        uVar5 = *(undefined4 *)((int64_t)&arg_70h + iVar10 + iVar9);
        uVar6 = *(undefined4 *)((int64_t)&arg_70h + iVar10 + iVar9 + 4);
        *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x1802069f2;
        iVar11 = fcn.180205c30(*(int64_t *)((int64_t)&var_18h + iVar10 + iVar9));
        if (iVar11 != 0) {
            *(undefined8 *)((int64_t)&arg_e8h + iVar10 + iVar9) = unaff_RBX;
            pcVar1 = (char *)(iVar11 + 0x70);
            *(undefined8 *)((int64_t)&arg_28h + iVar10 + iVar9) = 0;
            *(undefined8 *)((int64_t)&arg_a8h + iVar10 + iVar9) = unaff_R12;
            *(int64_t *)((int64_t)&var_20h + iVar10 + iVar9) = (int64_t)&arg_78h + iVar10 + iVar9;
            *(char **)((int64_t)&var_18h + iVar10 + iVar9) = pcVar1;
            *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206a3e;
            iVar7 = func_0x0001801f8d60((int64_t)&arg_68h + iVar10 + iVar9, 0, 1, 0);
            if (((iVar7 != 0) && (*pcVar1 == '\x01')) &&
               ((*(int32_t *)(iVar11 + 0x74) == 1 || (*(int32_t *)(iVar11 + 0x74) == 0)))) {
                *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206a6d;
                iVar7 = func_0x00018020d3f0(in_RCX + 0xa8, 0);
                if (iVar7 == 1) {
                    if (*pcVar1 == '\x01') {
                        uVar13 = *(uint64_t *)(iVar11 + 0xb0);
                        iVar15 = *(int64_t *)(iVar11 + 0xa8);
                        if (uVar13 != 0) {
                            if (*(uint64_t *)(iVar11 + 0x60) < uVar13) {
                                *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206aa2;
                                iVar11 = fcn.1802065f0(*(int64_t *)((int64_t)&var_18h + iVar10 + iVar9), 
                                                       *(int64_t *)((int64_t)&var_20h + iVar10 + iVar9), 
                                                       *(int64_t *)((int64_t)&arg_28h + iVar10 + iVar9));
                                if (iVar11 == 0) {
                                    return 0;
                                }
                            }
                            *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206ac0;
                            func_0x000180498030(iVar11 + 0x128, iVar15, uVar13);
                            iVar15 = iVar11 + 0x128;
                            uVar14 = uVar13;
                        }
                        *(int64_t *)(iVar11 + 0xa8) = iVar15;
                    }
                    *(undefined4 *)((int64_t)&arg_68h + iVar10 + iVar9) = uVar3;
                    *(undefined4 *)((int64_t)&arg_68h + iVar10 + iVar9 + 4) = uVar4;
                    *(undefined4 *)((int64_t)&arg_70h + iVar10 + iVar9) = uVar5;
                    *(undefined4 *)((int64_t)&arg_70h + iVar10 + iVar9 + 4) = uVar6;
                    *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206af5;
                    uVar12 = fcn.18020d3c0(in_RCX + 0xa8, 0, 1);
                    *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206b05;
                    iVar7 = func_0x0001801f8980(uVar12, (int64_t)&arg_78h + iVar10 + iVar9);
                    if (iVar7 != 0) {
                        *(uint64_t *)(in_RDX + 0x28) = *(uint64_t *)(in_RDX + 0x28) | 1;
                        *(undefined8 *)((int64_t)&arg_28h + iVar10 + iVar9) = 0;
                        *(undefined8 *)((int64_t)&var_20h + iVar10 + iVar9) = 0;
                        *(int64_t *)((int64_t)&var_18h + iVar10 + iVar9) = iVar11 + 0x70;
                        *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206b37;
                        iVar7 = func_0x0001801f8d60((int64_t)&arg_68h + iVar10 + iVar9, 0, 0, 0);
                        if (iVar7 == 1) {
                            *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206b4b;
                            iVar7 = fcn.1802067d0(in_RCX, iVar11);
                            if (iVar7 != 0) {
                                iVar15 = *(int64_t *)(iVar11 + 0xc0);
                                if (*(uint64_t *)(iVar11 + 0x60) < *(int64_t *)(iVar11 + 0xb8) + uVar14) {
                                    *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206b79;
                                    iVar11 = fcn.1802065f0(*(int64_t *)((int64_t)&var_18h + iVar10 + iVar9), 
                                                           *(int64_t *)((int64_t)&var_20h + iVar10 + iVar9), 
                                                           *(int64_t *)((int64_t)&arg_28h + iVar10 + iVar9));
                                }
                                if (iVar11 != 0) {
                                    uVar8 = *(uint32_t *)(iVar11 + 0x70);
                                    *(int64_t *)((int64_t)&arg_48h + iVar10 + iVar9) =
                                         (int64_t)&arg_58h + iVar10 + iVar9;
                                    uVar12 = *(undefined8 *)(iVar11 + 200);
                                    *(uint8_t *)((int64_t)&arg_40h + iVar10 + iVar9) = (uint8_t)(uVar8 >> 9) & 1;
                                    *(undefined4 *)((int64_t)&arg_38h + iVar10 + iVar9) = 0;
                                    *(undefined8 *)((int64_t)&arg_30h + iVar10 + iVar9) = uVar12;
                                    *(int64_t *)((int64_t)&arg_28h + iVar10 + iVar9) = iVar15 - (in_RDX + 0x80);
                                    *(int64_t *)((int64_t)&var_20h + iVar10 + iVar9) = in_RDX + 0x80;
                                    *(int64_t *)((int64_t)&var_18h + iVar10 + iVar9) =
                                         (int64_t)&arg_f0h + iVar10 + iVar9;
                                    *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206bea;
                                    iVar7 = fcn.180205920(*(int64_t *)((int64_t)&var_18h + iVar10 + iVar9), 
                                                          *(int64_t *)(&stack0x00000090 + iVar10 + iVar9), 
                                                          *(int64_t *)((int64_t)&arg_98h + iVar10 + iVar9), 
                                                          *(int64_t *)((int64_t)&arg_a8h + iVar10 + iVar9), 
                                                          *(int64_t *)(&stack0x000000b0 + iVar10 + iVar9), 
                                                          *(int64_t *)(&stack0x000000b8 + iVar10 + iVar9), 
                                                          *(int64_t *)(&stack0x000000c0 + iVar10 + iVar9), 
                                                          *(int64_t *)((int64_t)&arg_160h + iVar10 + iVar9));
                                    if (iVar7 != 0) {
                                        *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206bfd;
                                        iVar7 = fcn.1802068f0(in_RCX, iVar11);
                                        if (iVar7 != 0) {
                                            *(uint64_t *)(in_RDX + 0x20) = *(uint64_t *)(in_RDX + 0x20) | 1;
                                            uVar12 = *(undefined8 *)((int64_t)&arg_f0h + iVar10 + iVar9);
                                            uVar13 = *(uint64_t *)(iVar11 + 200);
                                            *(undefined8 *)(iVar11 + 0xb8) = uVar12;
                                            *(undefined8 *)(iVar11 + 0x58) = uVar12;
                                            *(undefined8 *)(iVar11 + 0x110) =
                                                 *(undefined8 *)((int64_t)&arg_100h + iVar10 + iVar9);
                                            *(undefined8 *)(iVar11 + 0x118) =
                                                 *(undefined8 *)((int64_t)&arg_58h + iVar10 + iVar9);
                                            *(uint64_t *)(iVar11 + 0xc0) = uVar14 + 0x128 + iVar11;
                                            *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206c4e;
                                            uVar8 = func_0x000180206d40(iVar11);
                                            if (*(uint64_t *)(in_RCX + 0x90 + (uint64_t)uVar8 * 8) < uVar13) {
                                                *(uint64_t *)(in_RCX + 0x90 + (uint64_t)uVar8 * 8) = uVar13;
                                            }
                                            uVar3 = *(undefined4 *)(in_RDX + 0x3c);
                                            uVar4 = *(undefined4 *)(in_RDX + 0x40);
                                            uVar5 = *(undefined4 *)(in_RDX + 0x44);
                                            *(undefined4 *)(iVar11 + 0xd0) = *(undefined4 *)(in_RDX + 0x38);
                                            *(undefined4 *)(iVar11 + 0xd4) = uVar3;
                                            *(undefined4 *)(iVar11 + 0xd8) = uVar4;
                                            *(undefined4 *)(iVar11 + 0xdc) = uVar5;
                                            *(undefined8 *)(iVar11 + 0xe0) = *(undefined8 *)(in_RDX + 0x48);
                                            *(undefined4 *)(iVar11 + 0xe8) = *(undefined4 *)(in_RDX + 0x50);
                                            uVar3 = *(undefined4 *)(in_RDX + 0x58);
                                            uVar4 = *(undefined4 *)(in_RDX + 0x5c);
                                            uVar5 = *(undefined4 *)(in_RDX + 0x60);
                                            *(undefined4 *)(iVar11 + 0xec) = *(undefined4 *)(in_RDX + 0x54);
                                            *(undefined4 *)(iVar11 + 0xf0) = uVar3;
                                            *(undefined4 *)(iVar11 + 0xf4) = uVar4;
                                            *(undefined4 *)(iVar11 + 0xf8) = uVar5;
                                            *(undefined8 *)(iVar11 + 0xfc) = *(undefined8 *)(in_RDX + 100);
                                            *(undefined4 *)(iVar11 + 0x104) = *(undefined4 *)(in_RDX + 0x6c);
                                            *(undefined8 *)(iVar11 + 0x108) = *(undefined8 *)(in_RDX + 0x70);
                                            *(undefined8 *)(iVar11 + 0x120) = *(undefined8 *)(in_RDX + 0x30);
                                            *(undefined8 *)((int64_t)auStack_10 + iVar10 + iVar9) = 0x180206cc7;
                                            func_0x0001802050b0(in_RCX + 0x60, iVar11);
                                            if (*(int64_t *)(in_RCX + 0x80) != 0) {
                                                *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x48) = iVar11;
                                            }
                                            *(undefined8 *)(iVar11 + 0x50) = *(undefined8 *)(in_RCX + 0x80);
                                            *(undefined8 *)(iVar11 + 0x48) = 0;
                                            *(int64_t *)(in_RCX + 0x80) = iVar11;
                                            if (*(int64_t *)(in_RCX + 0x78) == 0) {
                                                *(int64_t *)(in_RCX + 0x78) = iVar11;
                                            }
                                            *(int64_t *)(in_RCX + 0x88) = *(int64_t *)(in_RCX + 0x88) + 1;
                                            return 1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return 0;
        }
    }
    return 0;
}

