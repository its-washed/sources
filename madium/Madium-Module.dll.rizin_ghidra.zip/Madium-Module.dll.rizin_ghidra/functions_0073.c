// Chunk 73 - 50 functions

// ============================================================
// Function: FUN_1800f3a40
// Address: 0x1800f3a40
// Size: 81 bytes
// ============================================================
void fcn.1800f3a40(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    var_18h = arg3;
    var_20h = arg4;
    fcn.1800f3a30();
    fcn.180471af0(0, (int64_t)&var_18h);
    return;
}

// ============================================================
// Function: FUN_1800f3aa0
// Address: 0x1800f3aa0
// Size: 44 bytes
// ============================================================
uint32_t fcn.1800f3aa0(int64_t arg1)
{
    uint32_t in_EAX;
    
    if (*(int32_t *)(arg1 + 0x14) != -1) {
        in_EAX = fcn.180498f10(0x180644588, arg1 + 0x18);
        if (in_EAX == 0) {
            return 1;
        }
    }
    return in_EAX & 0xffffff00;
}

// ============================================================
// Function: FUN_1800f3b20
// Address: 0x1800f3b20
// Size: 36 bytes
// ============================================================
void fcn.1800f3b20(int64_t arg1)
{
    int64_t in_stack_00000010;
    
    fcn.180126a10(in_stack_00000010);
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        fcn.180460d90();
    }
    return;
}

// ============================================================
// Function: FUN_1800f3b50
// Address: 0x1800f3b50
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800f3b50(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t var_8h;
    
    piVar1 = (int32_t *)(arg1 + 0x50);
    iVar2 = *(int32_t *)(arg1 + 0x54);
    if (*(int32_t *)(arg1 + 0x50) == iVar2) {
        iVar3 = *(int32_t *)(arg1 + 0x50) + 1;
        if (iVar2 == 0) {
            iVar2 = 8;
        } else {
            iVar2 = iVar2 / 2 + iVar2;
        }
        if (iVar3 < iVar2) {
            iVar3 = iVar2;
        }
        func_0x00018011f4f0(piVar1, iVar3);
    }
    *(undefined8 *)(*(int64_t *)(arg1 + 0x58) + (int64_t)*piVar1 * 8) = *(undefined8 *)arg2;
    *piVar1 = *piVar1 + 1;
    return;
}

// ============================================================
// Function: FUN_1800f3bc0
// Address: 0x1800f3bc0
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

void fcn.1800f3bc0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    uint32_t uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int16_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int16_t iVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    uint64_t uVar14;
    int16_t iVar15;
    int32_t iVar16;
    int64_t iVar17;
    int32_t iVar18;
    int32_t iVar19;
    int16_t iVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    undefined auVar25 [16];
    float fVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar3 = *(uint32_t *)(arg1 + 0x50);
    uVar12 = (uint32_t)arg2;
    if ((2 < (int32_t)uVar3) && ((arg2 & 0xff000000U) != 0)) {
        iVar5 = *(int64_t *)(arg1 + 0x58);
        uVar1 = **(undefined4 **)(arg1 + 0x38);
        uVar2 = (*(undefined4 **)(arg1 + 0x38))[1];
        if ((*(uint8_t *)(arg1 + 0x30) & 4) == 0) {
            func_0x000180124680(arg1, (uVar3 - 2) * 3, uVar3);
            uVar14 = 0;
            do {
                iVar6 = uVar14 * 8;
                uVar13 = (int32_t)uVar14 + 1;
                uVar14 = (uint64_t)uVar13;
                **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar5 + iVar6);
                iVar6 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar6 + 8) = uVar1;
                *(undefined4 *)(iVar6 + 0xc) = uVar2;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar12;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x14;
            } while ((int32_t)uVar13 < (int32_t)uVar3);
            iVar16 = 2;
            do {
                **(undefined2 **)(arg1 + 0x48) = *(undefined2 *)(arg1 + 0x34);
                iVar11 = (int16_t)iVar16;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar11 + -1 + *(int16_t *)(arg1 + 0x34);
                iVar16 = iVar16 + 1;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11 + *(int16_t *)(arg1 + 0x34);
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 6;
            } while (iVar16 < (int32_t)uVar3);
            *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + (uVar3 & 0xffff);
            *(undefined4 *)(arg1 + 0x50) = 0;
        } else {
            fVar26 = *(float *)(arg1 + 0xd0);
            func_0x000180124680(arg1, uVar3 * 9 + -6, uVar3 * 2);
            uVar4 = *(undefined4 *)(arg1 + 0x34);
            iVar16 = 2;
            do {
                iVar11 = (int16_t)iVar16;
                iVar16 = iVar16 + 1;
                iVar20 = (int16_t)uVar4;
                iVar11 = iVar11 * 2 + iVar20;
                **(int16_t **)(arg1 + 0x48) = iVar20;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar11 + -2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 6;
            } while (iVar16 < (int32_t)uVar3);
            iVar6 = *(int64_t *)(arg1 + 0x38);
            if (*(int32_t *)(iVar6 + 0x4c) < (int32_t)uVar3) {
                if (*(int64_t *)(iVar6 + 0x50) != 0) {
                    fcn.180460d90();
                }
                uVar8 = func_0x00018046d050();
                *(undefined8 *)(iVar6 + 0x50) = uVar8;
                *(uint32_t *)(iVar6 + 0x4c) = uVar3;
            }
            iVar19 = uVar3 - 1;
            iVar10 = 0;
            iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + 0x50);
            iVar16 = iVar19;
            iVar18 = iVar10;
            if ((int32_t)uVar3 < 4) goto code_r0x0001800f3e44;
            do {
                iVar9 = (int64_t)iVar10;
                iVar17 = (int64_t)iVar16;
                fVar21 = *(float *)(iVar5 + iVar9 * 8) - *(float *)(iVar5 + iVar17 * 8);
                fVar23 = *(float *)(iVar5 + 4 + iVar9 * 8) - *(float *)(iVar5 + 4 + iVar17 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + iVar17 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 4 + iVar17 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                fVar21 = *(float *)(iVar5 + 8 + iVar9 * 8) - *(float *)(iVar5 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 0xc + iVar9 * 8) - *(float *)(iVar5 + 4 + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + iVar9 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 4 + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                fVar21 = *(float *)(iVar5 + 0x10 + iVar9 * 8) - *(float *)(iVar5 + 8 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 0x14 + iVar9 * 8) - *(float *)(iVar5 + 0xc + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + 8 + iVar9 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 0xc + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                fVar21 = *(float *)(iVar5 + 0x18 + iVar9 * 8) - *(float *)(iVar5 + 0x10 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 0x1c + iVar9 * 8) - *(float *)(iVar5 + 0x14 + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                iVar16 = iVar10 + 3;
                *(float *)(iVar6 + 0x10 + iVar9 * 8) = fVar23;
                iVar10 = iVar10 + 4;
                *(uint32_t *)(iVar6 + 0x14 + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
            } while (iVar10 < (int32_t)(uVar3 - 3));
            while (iVar18 = iVar10, iVar10 < (int32_t)uVar3) {
code_r0x0001800f3e44:
                iVar9 = (int64_t)iVar16;
                fVar21 = *(float *)(iVar5 + (int64_t)iVar18 * 8) - *(float *)(iVar5 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 4 + (int64_t)iVar18 * 8) - *(float *)(iVar5 + 4 + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + iVar9 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 4 + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                iVar16 = iVar18;
                iVar10 = iVar18 + 1;
            }
            fVar26 = fVar26 * 0.5;
            iVar16 = 0;
            do {
                iVar9 = (int64_t)iVar16;
                fVar23 = (*(float *)(iVar6 + (int64_t)iVar19 * 8) + *(float *)(iVar6 + iVar9 * 8)) * 0.5;
                fVar24 = (*(float *)(iVar6 + 4 + (int64_t)iVar19 * 8) + *(float *)(iVar6 + 4 + iVar9 * 8)) * 0.5;
                fVar21 = fVar24 * fVar24 + fVar23 * fVar23;
                if (1e-06 < fVar21) {
                    fVar21 = 1.0 / fVar21;
                    fVar22 = 100.0;
                    if (fVar21 <= 100.0) {
                        fVar22 = fVar21;
                    }
                    fVar23 = fVar23 * fVar22;
                    fVar24 = fVar24 * fVar22;
                }
                iVar11 = (int16_t)iVar19 * 2;
                iVar7 = (int16_t)iVar16 * 2;
                fVar23 = fVar26 * fVar23;
                fVar24 = fVar26 * fVar24;
                iVar15 = iVar7 + iVar20;
                **(float **)(arg1 + 0x40) = *(float *)(iVar5 + iVar9 * 8) - fVar23;
                *(float *)(*(int64_t *)(arg1 + 0x40) + 4) = *(float *)(iVar5 + 4 + iVar9 * 8) - fVar24;
                iVar17 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar17 + 8) = uVar1;
                *(undefined4 *)(iVar17 + 0xc) = uVar2;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar12;
                *(float *)(*(int64_t *)(arg1 + 0x40) + 0x14) = fVar23 + *(float *)(iVar5 + iVar9 * 8);
                *(float *)(*(int64_t *)(arg1 + 0x40) + 0x18) = fVar24 + *(float *)(iVar5 + 4 + iVar9 * 8);
                iVar9 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar9 + 0x1c) = uVar1;
                *(undefined4 *)(iVar9 + 0x20) = uVar2;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar12 & 0xffffff;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x28;
                **(int16_t **)(arg1 + 0x48) = iVar15;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar11 + iVar20;
                iVar11 = iVar11 + iVar20 + 1;
                iVar18 = iVar16 + 1;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar7 + iVar20 + 1;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar15;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
                iVar19 = iVar16;
                iVar16 = iVar18;
            } while (iVar18 < (int32_t)uVar3);
            *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + (uVar3 * 2 & 0xffff);
            *(undefined4 *)(arg1 + 0x50) = 0;
        }
        return;
    }
    *(undefined4 *)(arg1 + 0x50) = 0;
    return;
}

// ============================================================
// Function: FUN_1800f3bf5
// Address: 0x1800f3bf5
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

void fcn.1800f3bc0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    uint32_t uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int16_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int16_t iVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    uint64_t uVar14;
    int16_t iVar15;
    int32_t iVar16;
    int64_t iVar17;
    int32_t iVar18;
    int32_t iVar19;
    int16_t iVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    undefined auVar25 [16];
    float fVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar3 = *(uint32_t *)(arg1 + 0x50);
    uVar12 = (uint32_t)arg2;
    if ((2 < (int32_t)uVar3) && ((arg2 & 0xff000000U) != 0)) {
        iVar5 = *(int64_t *)(arg1 + 0x58);
        uVar1 = **(undefined4 **)(arg1 + 0x38);
        uVar2 = (*(undefined4 **)(arg1 + 0x38))[1];
        if ((*(uint8_t *)(arg1 + 0x30) & 4) == 0) {
            func_0x000180124680(arg1, (uVar3 - 2) * 3, uVar3);
            uVar14 = 0;
            do {
                iVar6 = uVar14 * 8;
                uVar13 = (int32_t)uVar14 + 1;
                uVar14 = (uint64_t)uVar13;
                **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar5 + iVar6);
                iVar6 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar6 + 8) = uVar1;
                *(undefined4 *)(iVar6 + 0xc) = uVar2;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar12;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x14;
            } while ((int32_t)uVar13 < (int32_t)uVar3);
            iVar16 = 2;
            do {
                **(undefined2 **)(arg1 + 0x48) = *(undefined2 *)(arg1 + 0x34);
                iVar11 = (int16_t)iVar16;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar11 + -1 + *(int16_t *)(arg1 + 0x34);
                iVar16 = iVar16 + 1;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11 + *(int16_t *)(arg1 + 0x34);
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 6;
            } while (iVar16 < (int32_t)uVar3);
            *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + (uVar3 & 0xffff);
            *(undefined4 *)(arg1 + 0x50) = 0;
        } else {
            fVar26 = *(float *)(arg1 + 0xd0);
            func_0x000180124680(arg1, uVar3 * 9 + -6, uVar3 * 2);
            uVar4 = *(undefined4 *)(arg1 + 0x34);
            iVar16 = 2;
            do {
                iVar11 = (int16_t)iVar16;
                iVar16 = iVar16 + 1;
                iVar20 = (int16_t)uVar4;
                iVar11 = iVar11 * 2 + iVar20;
                **(int16_t **)(arg1 + 0x48) = iVar20;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar11 + -2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 6;
            } while (iVar16 < (int32_t)uVar3);
            iVar6 = *(int64_t *)(arg1 + 0x38);
            if (*(int32_t *)(iVar6 + 0x4c) < (int32_t)uVar3) {
                if (*(int64_t *)(iVar6 + 0x50) != 0) {
                    fcn.180460d90();
                }
                uVar8 = func_0x00018046d050();
                *(undefined8 *)(iVar6 + 0x50) = uVar8;
                *(uint32_t *)(iVar6 + 0x4c) = uVar3;
            }
            iVar19 = uVar3 - 1;
            iVar10 = 0;
            iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + 0x50);
            iVar16 = iVar19;
            iVar18 = iVar10;
            if ((int32_t)uVar3 < 4) goto code_r0x0001800f3e44;
            do {
                iVar9 = (int64_t)iVar10;
                iVar17 = (int64_t)iVar16;
                fVar21 = *(float *)(iVar5 + iVar9 * 8) - *(float *)(iVar5 + iVar17 * 8);
                fVar23 = *(float *)(iVar5 + 4 + iVar9 * 8) - *(float *)(iVar5 + 4 + iVar17 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + iVar17 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 4 + iVar17 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                fVar21 = *(float *)(iVar5 + 8 + iVar9 * 8) - *(float *)(iVar5 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 0xc + iVar9 * 8) - *(float *)(iVar5 + 4 + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + iVar9 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 4 + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                fVar21 = *(float *)(iVar5 + 0x10 + iVar9 * 8) - *(float *)(iVar5 + 8 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 0x14 + iVar9 * 8) - *(float *)(iVar5 + 0xc + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + 8 + iVar9 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 0xc + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                fVar21 = *(float *)(iVar5 + 0x18 + iVar9 * 8) - *(float *)(iVar5 + 0x10 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 0x1c + iVar9 * 8) - *(float *)(iVar5 + 0x14 + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                iVar16 = iVar10 + 3;
                *(float *)(iVar6 + 0x10 + iVar9 * 8) = fVar23;
                iVar10 = iVar10 + 4;
                *(uint32_t *)(iVar6 + 0x14 + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
            } while (iVar10 < (int32_t)(uVar3 - 3));
            while (iVar18 = iVar10, iVar10 < (int32_t)uVar3) {
code_r0x0001800f3e44:
                iVar9 = (int64_t)iVar16;
                fVar21 = *(float *)(iVar5 + (int64_t)iVar18 * 8) - *(float *)(iVar5 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 4 + (int64_t)iVar18 * 8) - *(float *)(iVar5 + 4 + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + iVar9 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 4 + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                iVar16 = iVar18;
                iVar10 = iVar18 + 1;
            }
            fVar26 = fVar26 * 0.5;
            iVar16 = 0;
            do {
                iVar9 = (int64_t)iVar16;
                fVar23 = (*(float *)(iVar6 + (int64_t)iVar19 * 8) + *(float *)(iVar6 + iVar9 * 8)) * 0.5;
                fVar24 = (*(float *)(iVar6 + 4 + (int64_t)iVar19 * 8) + *(float *)(iVar6 + 4 + iVar9 * 8)) * 0.5;
                fVar21 = fVar24 * fVar24 + fVar23 * fVar23;
                if (1e-06 < fVar21) {
                    fVar21 = 1.0 / fVar21;
                    fVar22 = 100.0;
                    if (fVar21 <= 100.0) {
                        fVar22 = fVar21;
                    }
                    fVar23 = fVar23 * fVar22;
                    fVar24 = fVar24 * fVar22;
                }
                iVar11 = (int16_t)iVar19 * 2;
                iVar7 = (int16_t)iVar16 * 2;
                fVar23 = fVar26 * fVar23;
                fVar24 = fVar26 * fVar24;
                iVar15 = iVar7 + iVar20;
                **(float **)(arg1 + 0x40) = *(float *)(iVar5 + iVar9 * 8) - fVar23;
                *(float *)(*(int64_t *)(arg1 + 0x40) + 4) = *(float *)(iVar5 + 4 + iVar9 * 8) - fVar24;
                iVar17 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar17 + 8) = uVar1;
                *(undefined4 *)(iVar17 + 0xc) = uVar2;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar12;
                *(float *)(*(int64_t *)(arg1 + 0x40) + 0x14) = fVar23 + *(float *)(iVar5 + iVar9 * 8);
                *(float *)(*(int64_t *)(arg1 + 0x40) + 0x18) = fVar24 + *(float *)(iVar5 + 4 + iVar9 * 8);
                iVar9 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar9 + 0x1c) = uVar1;
                *(undefined4 *)(iVar9 + 0x20) = uVar2;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar12 & 0xffffff;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x28;
                **(int16_t **)(arg1 + 0x48) = iVar15;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar11 + iVar20;
                iVar11 = iVar11 + iVar20 + 1;
                iVar18 = iVar16 + 1;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar7 + iVar20 + 1;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar15;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
                iVar19 = iVar16;
                iVar16 = iVar18;
            } while (iVar18 < (int32_t)uVar3);
            *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + (uVar3 * 2 & 0xffff);
            *(undefined4 *)(arg1 + 0x50) = 0;
        }
        return;
    }
    *(undefined4 *)(arg1 + 0x50) = 0;
    return;
}

// ============================================================
// Function: FUN_1800f3c18
// Address: 0x1800f3c18
// Size: 1079 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

void fcn.1800f3bc0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    uint32_t uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int16_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int16_t iVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    uint64_t uVar14;
    int16_t iVar15;
    int32_t iVar16;
    int64_t iVar17;
    int32_t iVar18;
    int32_t iVar19;
    int16_t iVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    undefined auVar25 [16];
    float fVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar3 = *(uint32_t *)(arg1 + 0x50);
    uVar12 = (uint32_t)arg2;
    if ((2 < (int32_t)uVar3) && ((arg2 & 0xff000000U) != 0)) {
        iVar5 = *(int64_t *)(arg1 + 0x58);
        uVar1 = **(undefined4 **)(arg1 + 0x38);
        uVar2 = (*(undefined4 **)(arg1 + 0x38))[1];
        if ((*(uint8_t *)(arg1 + 0x30) & 4) == 0) {
            func_0x000180124680(arg1, (uVar3 - 2) * 3, uVar3);
            uVar14 = 0;
            do {
                iVar6 = uVar14 * 8;
                uVar13 = (int32_t)uVar14 + 1;
                uVar14 = (uint64_t)uVar13;
                **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar5 + iVar6);
                iVar6 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar6 + 8) = uVar1;
                *(undefined4 *)(iVar6 + 0xc) = uVar2;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar12;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x14;
            } while ((int32_t)uVar13 < (int32_t)uVar3);
            iVar16 = 2;
            do {
                **(undefined2 **)(arg1 + 0x48) = *(undefined2 *)(arg1 + 0x34);
                iVar11 = (int16_t)iVar16;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar11 + -1 + *(int16_t *)(arg1 + 0x34);
                iVar16 = iVar16 + 1;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11 + *(int16_t *)(arg1 + 0x34);
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 6;
            } while (iVar16 < (int32_t)uVar3);
            *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + (uVar3 & 0xffff);
            *(undefined4 *)(arg1 + 0x50) = 0;
        } else {
            fVar26 = *(float *)(arg1 + 0xd0);
            func_0x000180124680(arg1, uVar3 * 9 + -6, uVar3 * 2);
            uVar4 = *(undefined4 *)(arg1 + 0x34);
            iVar16 = 2;
            do {
                iVar11 = (int16_t)iVar16;
                iVar16 = iVar16 + 1;
                iVar20 = (int16_t)uVar4;
                iVar11 = iVar11 * 2 + iVar20;
                **(int16_t **)(arg1 + 0x48) = iVar20;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar11 + -2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 6;
            } while (iVar16 < (int32_t)uVar3);
            iVar6 = *(int64_t *)(arg1 + 0x38);
            if (*(int32_t *)(iVar6 + 0x4c) < (int32_t)uVar3) {
                if (*(int64_t *)(iVar6 + 0x50) != 0) {
                    fcn.180460d90();
                }
                uVar8 = func_0x00018046d050();
                *(undefined8 *)(iVar6 + 0x50) = uVar8;
                *(uint32_t *)(iVar6 + 0x4c) = uVar3;
            }
            iVar19 = uVar3 - 1;
            iVar10 = 0;
            iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + 0x50);
            iVar16 = iVar19;
            iVar18 = iVar10;
            if ((int32_t)uVar3 < 4) goto code_r0x0001800f3e44;
            do {
                iVar9 = (int64_t)iVar10;
                iVar17 = (int64_t)iVar16;
                fVar21 = *(float *)(iVar5 + iVar9 * 8) - *(float *)(iVar5 + iVar17 * 8);
                fVar23 = *(float *)(iVar5 + 4 + iVar9 * 8) - *(float *)(iVar5 + 4 + iVar17 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + iVar17 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 4 + iVar17 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                fVar21 = *(float *)(iVar5 + 8 + iVar9 * 8) - *(float *)(iVar5 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 0xc + iVar9 * 8) - *(float *)(iVar5 + 4 + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + iVar9 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 4 + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                fVar21 = *(float *)(iVar5 + 0x10 + iVar9 * 8) - *(float *)(iVar5 + 8 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 0x14 + iVar9 * 8) - *(float *)(iVar5 + 0xc + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + 8 + iVar9 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 0xc + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                fVar21 = *(float *)(iVar5 + 0x18 + iVar9 * 8) - *(float *)(iVar5 + 0x10 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 0x1c + iVar9 * 8) - *(float *)(iVar5 + 0x14 + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                iVar16 = iVar10 + 3;
                *(float *)(iVar6 + 0x10 + iVar9 * 8) = fVar23;
                iVar10 = iVar10 + 4;
                *(uint32_t *)(iVar6 + 0x14 + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
            } while (iVar10 < (int32_t)(uVar3 - 3));
            while (iVar18 = iVar10, iVar10 < (int32_t)uVar3) {
code_r0x0001800f3e44:
                iVar9 = (int64_t)iVar16;
                fVar21 = *(float *)(iVar5 + (int64_t)iVar18 * 8) - *(float *)(iVar5 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 4 + (int64_t)iVar18 * 8) - *(float *)(iVar5 + 4 + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + iVar9 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 4 + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                iVar16 = iVar18;
                iVar10 = iVar18 + 1;
            }
            fVar26 = fVar26 * 0.5;
            iVar16 = 0;
            do {
                iVar9 = (int64_t)iVar16;
                fVar23 = (*(float *)(iVar6 + (int64_t)iVar19 * 8) + *(float *)(iVar6 + iVar9 * 8)) * 0.5;
                fVar24 = (*(float *)(iVar6 + 4 + (int64_t)iVar19 * 8) + *(float *)(iVar6 + 4 + iVar9 * 8)) * 0.5;
                fVar21 = fVar24 * fVar24 + fVar23 * fVar23;
                if (1e-06 < fVar21) {
                    fVar21 = 1.0 / fVar21;
                    fVar22 = 100.0;
                    if (fVar21 <= 100.0) {
                        fVar22 = fVar21;
                    }
                    fVar23 = fVar23 * fVar22;
                    fVar24 = fVar24 * fVar22;
                }
                iVar11 = (int16_t)iVar19 * 2;
                iVar7 = (int16_t)iVar16 * 2;
                fVar23 = fVar26 * fVar23;
                fVar24 = fVar26 * fVar24;
                iVar15 = iVar7 + iVar20;
                **(float **)(arg1 + 0x40) = *(float *)(iVar5 + iVar9 * 8) - fVar23;
                *(float *)(*(int64_t *)(arg1 + 0x40) + 4) = *(float *)(iVar5 + 4 + iVar9 * 8) - fVar24;
                iVar17 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar17 + 8) = uVar1;
                *(undefined4 *)(iVar17 + 0xc) = uVar2;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar12;
                *(float *)(*(int64_t *)(arg1 + 0x40) + 0x14) = fVar23 + *(float *)(iVar5 + iVar9 * 8);
                *(float *)(*(int64_t *)(arg1 + 0x40) + 0x18) = fVar24 + *(float *)(iVar5 + 4 + iVar9 * 8);
                iVar9 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar9 + 0x1c) = uVar1;
                *(undefined4 *)(iVar9 + 0x20) = uVar2;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar12 & 0xffffff;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x28;
                **(int16_t **)(arg1 + 0x48) = iVar15;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar11 + iVar20;
                iVar11 = iVar11 + iVar20 + 1;
                iVar18 = iVar16 + 1;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar7 + iVar20 + 1;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar15;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
                iVar19 = iVar16;
                iVar16 = iVar18;
            } while (iVar18 < (int32_t)uVar3);
            *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + (uVar3 * 2 & 0xffff);
            *(undefined4 *)(arg1 + 0x50) = 0;
        }
        return;
    }
    *(undefined4 *)(arg1 + 0x50) = 0;
    return;
}

// ============================================================
// Function: FUN_1800f404f
// Address: 0x1800f404f
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

void fcn.1800f3bc0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    uint32_t uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int16_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int16_t iVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    uint64_t uVar14;
    int16_t iVar15;
    int32_t iVar16;
    int64_t iVar17;
    int32_t iVar18;
    int32_t iVar19;
    int16_t iVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    undefined auVar25 [16];
    float fVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar3 = *(uint32_t *)(arg1 + 0x50);
    uVar12 = (uint32_t)arg2;
    if ((2 < (int32_t)uVar3) && ((arg2 & 0xff000000U) != 0)) {
        iVar5 = *(int64_t *)(arg1 + 0x58);
        uVar1 = **(undefined4 **)(arg1 + 0x38);
        uVar2 = (*(undefined4 **)(arg1 + 0x38))[1];
        if ((*(uint8_t *)(arg1 + 0x30) & 4) == 0) {
            func_0x000180124680(arg1, (uVar3 - 2) * 3, uVar3);
            uVar14 = 0;
            do {
                iVar6 = uVar14 * 8;
                uVar13 = (int32_t)uVar14 + 1;
                uVar14 = (uint64_t)uVar13;
                **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar5 + iVar6);
                iVar6 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar6 + 8) = uVar1;
                *(undefined4 *)(iVar6 + 0xc) = uVar2;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar12;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x14;
            } while ((int32_t)uVar13 < (int32_t)uVar3);
            iVar16 = 2;
            do {
                **(undefined2 **)(arg1 + 0x48) = *(undefined2 *)(arg1 + 0x34);
                iVar11 = (int16_t)iVar16;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar11 + -1 + *(int16_t *)(arg1 + 0x34);
                iVar16 = iVar16 + 1;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11 + *(int16_t *)(arg1 + 0x34);
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 6;
            } while (iVar16 < (int32_t)uVar3);
            *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + (uVar3 & 0xffff);
            *(undefined4 *)(arg1 + 0x50) = 0;
        } else {
            fVar26 = *(float *)(arg1 + 0xd0);
            func_0x000180124680(arg1, uVar3 * 9 + -6, uVar3 * 2);
            uVar4 = *(undefined4 *)(arg1 + 0x34);
            iVar16 = 2;
            do {
                iVar11 = (int16_t)iVar16;
                iVar16 = iVar16 + 1;
                iVar20 = (int16_t)uVar4;
                iVar11 = iVar11 * 2 + iVar20;
                **(int16_t **)(arg1 + 0x48) = iVar20;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar11 + -2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 6;
            } while (iVar16 < (int32_t)uVar3);
            iVar6 = *(int64_t *)(arg1 + 0x38);
            if (*(int32_t *)(iVar6 + 0x4c) < (int32_t)uVar3) {
                if (*(int64_t *)(iVar6 + 0x50) != 0) {
                    fcn.180460d90();
                }
                uVar8 = func_0x00018046d050();
                *(undefined8 *)(iVar6 + 0x50) = uVar8;
                *(uint32_t *)(iVar6 + 0x4c) = uVar3;
            }
            iVar19 = uVar3 - 1;
            iVar10 = 0;
            iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + 0x50);
            iVar16 = iVar19;
            iVar18 = iVar10;
            if ((int32_t)uVar3 < 4) goto code_r0x0001800f3e44;
            do {
                iVar9 = (int64_t)iVar10;
                iVar17 = (int64_t)iVar16;
                fVar21 = *(float *)(iVar5 + iVar9 * 8) - *(float *)(iVar5 + iVar17 * 8);
                fVar23 = *(float *)(iVar5 + 4 + iVar9 * 8) - *(float *)(iVar5 + 4 + iVar17 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + iVar17 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 4 + iVar17 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                fVar21 = *(float *)(iVar5 + 8 + iVar9 * 8) - *(float *)(iVar5 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 0xc + iVar9 * 8) - *(float *)(iVar5 + 4 + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + iVar9 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 4 + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                fVar21 = *(float *)(iVar5 + 0x10 + iVar9 * 8) - *(float *)(iVar5 + 8 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 0x14 + iVar9 * 8) - *(float *)(iVar5 + 0xc + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + 8 + iVar9 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 0xc + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                fVar21 = *(float *)(iVar5 + 0x18 + iVar9 * 8) - *(float *)(iVar5 + 0x10 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 0x1c + iVar9 * 8) - *(float *)(iVar5 + 0x14 + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                iVar16 = iVar10 + 3;
                *(float *)(iVar6 + 0x10 + iVar9 * 8) = fVar23;
                iVar10 = iVar10 + 4;
                *(uint32_t *)(iVar6 + 0x14 + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
            } while (iVar10 < (int32_t)(uVar3 - 3));
            while (iVar18 = iVar10, iVar10 < (int32_t)uVar3) {
code_r0x0001800f3e44:
                iVar9 = (int64_t)iVar16;
                fVar21 = *(float *)(iVar5 + (int64_t)iVar18 * 8) - *(float *)(iVar5 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 4 + (int64_t)iVar18 * 8) - *(float *)(iVar5 + 4 + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + iVar9 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 4 + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                iVar16 = iVar18;
                iVar10 = iVar18 + 1;
            }
            fVar26 = fVar26 * 0.5;
            iVar16 = 0;
            do {
                iVar9 = (int64_t)iVar16;
                fVar23 = (*(float *)(iVar6 + (int64_t)iVar19 * 8) + *(float *)(iVar6 + iVar9 * 8)) * 0.5;
                fVar24 = (*(float *)(iVar6 + 4 + (int64_t)iVar19 * 8) + *(float *)(iVar6 + 4 + iVar9 * 8)) * 0.5;
                fVar21 = fVar24 * fVar24 + fVar23 * fVar23;
                if (1e-06 < fVar21) {
                    fVar21 = 1.0 / fVar21;
                    fVar22 = 100.0;
                    if (fVar21 <= 100.0) {
                        fVar22 = fVar21;
                    }
                    fVar23 = fVar23 * fVar22;
                    fVar24 = fVar24 * fVar22;
                }
                iVar11 = (int16_t)iVar19 * 2;
                iVar7 = (int16_t)iVar16 * 2;
                fVar23 = fVar26 * fVar23;
                fVar24 = fVar26 * fVar24;
                iVar15 = iVar7 + iVar20;
                **(float **)(arg1 + 0x40) = *(float *)(iVar5 + iVar9 * 8) - fVar23;
                *(float *)(*(int64_t *)(arg1 + 0x40) + 4) = *(float *)(iVar5 + 4 + iVar9 * 8) - fVar24;
                iVar17 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar17 + 8) = uVar1;
                *(undefined4 *)(iVar17 + 0xc) = uVar2;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar12;
                *(float *)(*(int64_t *)(arg1 + 0x40) + 0x14) = fVar23 + *(float *)(iVar5 + iVar9 * 8);
                *(float *)(*(int64_t *)(arg1 + 0x40) + 0x18) = fVar24 + *(float *)(iVar5 + 4 + iVar9 * 8);
                iVar9 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar9 + 0x1c) = uVar1;
                *(undefined4 *)(iVar9 + 0x20) = uVar2;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar12 & 0xffffff;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x28;
                **(int16_t **)(arg1 + 0x48) = iVar15;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar11 + iVar20;
                iVar11 = iVar11 + iVar20 + 1;
                iVar18 = iVar16 + 1;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar7 + iVar20 + 1;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar15;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
                iVar19 = iVar16;
                iVar16 = iVar18;
            } while (iVar18 < (int32_t)uVar3);
            *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + (uVar3 * 2 & 0xffff);
            *(undefined4 *)(arg1 + 0x50) = 0;
        }
        return;
    }
    *(undefined4 *)(arg1 + 0x50) = 0;
    return;
}

// ============================================================
// Function: FUN_1800f406f
// Address: 0x1800f406f
// Size: 155 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

void fcn.1800f3bc0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    uint32_t uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int16_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int16_t iVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    uint64_t uVar14;
    int16_t iVar15;
    int32_t iVar16;
    int64_t iVar17;
    int32_t iVar18;
    int32_t iVar19;
    int16_t iVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    undefined auVar25 [16];
    float fVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar3 = *(uint32_t *)(arg1 + 0x50);
    uVar12 = (uint32_t)arg2;
    if ((2 < (int32_t)uVar3) && ((arg2 & 0xff000000U) != 0)) {
        iVar5 = *(int64_t *)(arg1 + 0x58);
        uVar1 = **(undefined4 **)(arg1 + 0x38);
        uVar2 = (*(undefined4 **)(arg1 + 0x38))[1];
        if ((*(uint8_t *)(arg1 + 0x30) & 4) == 0) {
            func_0x000180124680(arg1, (uVar3 - 2) * 3, uVar3);
            uVar14 = 0;
            do {
                iVar6 = uVar14 * 8;
                uVar13 = (int32_t)uVar14 + 1;
                uVar14 = (uint64_t)uVar13;
                **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar5 + iVar6);
                iVar6 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar6 + 8) = uVar1;
                *(undefined4 *)(iVar6 + 0xc) = uVar2;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar12;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x14;
            } while ((int32_t)uVar13 < (int32_t)uVar3);
            iVar16 = 2;
            do {
                **(undefined2 **)(arg1 + 0x48) = *(undefined2 *)(arg1 + 0x34);
                iVar11 = (int16_t)iVar16;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar11 + -1 + *(int16_t *)(arg1 + 0x34);
                iVar16 = iVar16 + 1;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11 + *(int16_t *)(arg1 + 0x34);
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 6;
            } while (iVar16 < (int32_t)uVar3);
            *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + (uVar3 & 0xffff);
            *(undefined4 *)(arg1 + 0x50) = 0;
        } else {
            fVar26 = *(float *)(arg1 + 0xd0);
            func_0x000180124680(arg1, uVar3 * 9 + -6, uVar3 * 2);
            uVar4 = *(undefined4 *)(arg1 + 0x34);
            iVar16 = 2;
            do {
                iVar11 = (int16_t)iVar16;
                iVar16 = iVar16 + 1;
                iVar20 = (int16_t)uVar4;
                iVar11 = iVar11 * 2 + iVar20;
                **(int16_t **)(arg1 + 0x48) = iVar20;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar11 + -2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 6;
            } while (iVar16 < (int32_t)uVar3);
            iVar6 = *(int64_t *)(arg1 + 0x38);
            if (*(int32_t *)(iVar6 + 0x4c) < (int32_t)uVar3) {
                if (*(int64_t *)(iVar6 + 0x50) != 0) {
                    fcn.180460d90();
                }
                uVar8 = func_0x00018046d050();
                *(undefined8 *)(iVar6 + 0x50) = uVar8;
                *(uint32_t *)(iVar6 + 0x4c) = uVar3;
            }
            iVar19 = uVar3 - 1;
            iVar10 = 0;
            iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + 0x50);
            iVar16 = iVar19;
            iVar18 = iVar10;
            if ((int32_t)uVar3 < 4) goto code_r0x0001800f3e44;
            do {
                iVar9 = (int64_t)iVar10;
                iVar17 = (int64_t)iVar16;
                fVar21 = *(float *)(iVar5 + iVar9 * 8) - *(float *)(iVar5 + iVar17 * 8);
                fVar23 = *(float *)(iVar5 + 4 + iVar9 * 8) - *(float *)(iVar5 + 4 + iVar17 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + iVar17 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 4 + iVar17 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                fVar21 = *(float *)(iVar5 + 8 + iVar9 * 8) - *(float *)(iVar5 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 0xc + iVar9 * 8) - *(float *)(iVar5 + 4 + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + iVar9 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 4 + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                fVar21 = *(float *)(iVar5 + 0x10 + iVar9 * 8) - *(float *)(iVar5 + 8 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 0x14 + iVar9 * 8) - *(float *)(iVar5 + 0xc + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + 8 + iVar9 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 0xc + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                fVar21 = *(float *)(iVar5 + 0x18 + iVar9 * 8) - *(float *)(iVar5 + 0x10 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 0x1c + iVar9 * 8) - *(float *)(iVar5 + 0x14 + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                iVar16 = iVar10 + 3;
                *(float *)(iVar6 + 0x10 + iVar9 * 8) = fVar23;
                iVar10 = iVar10 + 4;
                *(uint32_t *)(iVar6 + 0x14 + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
            } while (iVar10 < (int32_t)(uVar3 - 3));
            while (iVar18 = iVar10, iVar10 < (int32_t)uVar3) {
code_r0x0001800f3e44:
                iVar9 = (int64_t)iVar16;
                fVar21 = *(float *)(iVar5 + (int64_t)iVar18 * 8) - *(float *)(iVar5 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 4 + (int64_t)iVar18 * 8) - *(float *)(iVar5 + 4 + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + iVar9 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 4 + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                iVar16 = iVar18;
                iVar10 = iVar18 + 1;
            }
            fVar26 = fVar26 * 0.5;
            iVar16 = 0;
            do {
                iVar9 = (int64_t)iVar16;
                fVar23 = (*(float *)(iVar6 + (int64_t)iVar19 * 8) + *(float *)(iVar6 + iVar9 * 8)) * 0.5;
                fVar24 = (*(float *)(iVar6 + 4 + (int64_t)iVar19 * 8) + *(float *)(iVar6 + 4 + iVar9 * 8)) * 0.5;
                fVar21 = fVar24 * fVar24 + fVar23 * fVar23;
                if (1e-06 < fVar21) {
                    fVar21 = 1.0 / fVar21;
                    fVar22 = 100.0;
                    if (fVar21 <= 100.0) {
                        fVar22 = fVar21;
                    }
                    fVar23 = fVar23 * fVar22;
                    fVar24 = fVar24 * fVar22;
                }
                iVar11 = (int16_t)iVar19 * 2;
                iVar7 = (int16_t)iVar16 * 2;
                fVar23 = fVar26 * fVar23;
                fVar24 = fVar26 * fVar24;
                iVar15 = iVar7 + iVar20;
                **(float **)(arg1 + 0x40) = *(float *)(iVar5 + iVar9 * 8) - fVar23;
                *(float *)(*(int64_t *)(arg1 + 0x40) + 4) = *(float *)(iVar5 + 4 + iVar9 * 8) - fVar24;
                iVar17 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar17 + 8) = uVar1;
                *(undefined4 *)(iVar17 + 0xc) = uVar2;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar12;
                *(float *)(*(int64_t *)(arg1 + 0x40) + 0x14) = fVar23 + *(float *)(iVar5 + iVar9 * 8);
                *(float *)(*(int64_t *)(arg1 + 0x40) + 0x18) = fVar24 + *(float *)(iVar5 + 4 + iVar9 * 8);
                iVar9 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar9 + 0x1c) = uVar1;
                *(undefined4 *)(iVar9 + 0x20) = uVar2;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar12 & 0xffffff;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x28;
                **(int16_t **)(arg1 + 0x48) = iVar15;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar11 + iVar20;
                iVar11 = iVar11 + iVar20 + 1;
                iVar18 = iVar16 + 1;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar7 + iVar20 + 1;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar15;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
                iVar19 = iVar16;
                iVar16 = iVar18;
            } while (iVar18 < (int32_t)uVar3);
            *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + (uVar3 * 2 & 0xffff);
            *(undefined4 *)(arg1 + 0x50) = 0;
        }
        return;
    }
    *(undefined4 *)(arg1 + 0x50) = 0;
    return;
}

// ============================================================
// Function: FUN_1800f410a
// Address: 0x1800f410a
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

void fcn.1800f3bc0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    uint32_t uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int16_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int16_t iVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    uint64_t uVar14;
    int16_t iVar15;
    int32_t iVar16;
    int64_t iVar17;
    int32_t iVar18;
    int32_t iVar19;
    int16_t iVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    undefined auVar25 [16];
    float fVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar3 = *(uint32_t *)(arg1 + 0x50);
    uVar12 = (uint32_t)arg2;
    if ((2 < (int32_t)uVar3) && ((arg2 & 0xff000000U) != 0)) {
        iVar5 = *(int64_t *)(arg1 + 0x58);
        uVar1 = **(undefined4 **)(arg1 + 0x38);
        uVar2 = (*(undefined4 **)(arg1 + 0x38))[1];
        if ((*(uint8_t *)(arg1 + 0x30) & 4) == 0) {
            func_0x000180124680(arg1, (uVar3 - 2) * 3, uVar3);
            uVar14 = 0;
            do {
                iVar6 = uVar14 * 8;
                uVar13 = (int32_t)uVar14 + 1;
                uVar14 = (uint64_t)uVar13;
                **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar5 + iVar6);
                iVar6 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar6 + 8) = uVar1;
                *(undefined4 *)(iVar6 + 0xc) = uVar2;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar12;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x14;
            } while ((int32_t)uVar13 < (int32_t)uVar3);
            iVar16 = 2;
            do {
                **(undefined2 **)(arg1 + 0x48) = *(undefined2 *)(arg1 + 0x34);
                iVar11 = (int16_t)iVar16;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar11 + -1 + *(int16_t *)(arg1 + 0x34);
                iVar16 = iVar16 + 1;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11 + *(int16_t *)(arg1 + 0x34);
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 6;
            } while (iVar16 < (int32_t)uVar3);
            *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + (uVar3 & 0xffff);
            *(undefined4 *)(arg1 + 0x50) = 0;
        } else {
            fVar26 = *(float *)(arg1 + 0xd0);
            func_0x000180124680(arg1, uVar3 * 9 + -6, uVar3 * 2);
            uVar4 = *(undefined4 *)(arg1 + 0x34);
            iVar16 = 2;
            do {
                iVar11 = (int16_t)iVar16;
                iVar16 = iVar16 + 1;
                iVar20 = (int16_t)uVar4;
                iVar11 = iVar11 * 2 + iVar20;
                **(int16_t **)(arg1 + 0x48) = iVar20;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar11 + -2;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 6;
            } while (iVar16 < (int32_t)uVar3);
            iVar6 = *(int64_t *)(arg1 + 0x38);
            if (*(int32_t *)(iVar6 + 0x4c) < (int32_t)uVar3) {
                if (*(int64_t *)(iVar6 + 0x50) != 0) {
                    fcn.180460d90();
                }
                uVar8 = func_0x00018046d050();
                *(undefined8 *)(iVar6 + 0x50) = uVar8;
                *(uint32_t *)(iVar6 + 0x4c) = uVar3;
            }
            iVar19 = uVar3 - 1;
            iVar10 = 0;
            iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + 0x50);
            iVar16 = iVar19;
            iVar18 = iVar10;
            if ((int32_t)uVar3 < 4) goto code_r0x0001800f3e44;
            do {
                iVar9 = (int64_t)iVar10;
                iVar17 = (int64_t)iVar16;
                fVar21 = *(float *)(iVar5 + iVar9 * 8) - *(float *)(iVar5 + iVar17 * 8);
                fVar23 = *(float *)(iVar5 + 4 + iVar9 * 8) - *(float *)(iVar5 + 4 + iVar17 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + iVar17 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 4 + iVar17 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                fVar21 = *(float *)(iVar5 + 8 + iVar9 * 8) - *(float *)(iVar5 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 0xc + iVar9 * 8) - *(float *)(iVar5 + 4 + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + iVar9 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 4 + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                fVar21 = *(float *)(iVar5 + 0x10 + iVar9 * 8) - *(float *)(iVar5 + 8 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 0x14 + iVar9 * 8) - *(float *)(iVar5 + 0xc + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + 8 + iVar9 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 0xc + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                fVar21 = *(float *)(iVar5 + 0x18 + iVar9 * 8) - *(float *)(iVar5 + 0x10 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 0x1c + iVar9 * 8) - *(float *)(iVar5 + 0x14 + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                iVar16 = iVar10 + 3;
                *(float *)(iVar6 + 0x10 + iVar9 * 8) = fVar23;
                iVar10 = iVar10 + 4;
                *(uint32_t *)(iVar6 + 0x14 + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
            } while (iVar10 < (int32_t)(uVar3 - 3));
            while (iVar18 = iVar10, iVar10 < (int32_t)uVar3) {
code_r0x0001800f3e44:
                iVar9 = (int64_t)iVar16;
                fVar21 = *(float *)(iVar5 + (int64_t)iVar18 * 8) - *(float *)(iVar5 + iVar9 * 8);
                fVar23 = *(float *)(iVar5 + 4 + (int64_t)iVar18 * 8) - *(float *)(iVar5 + 4 + iVar9 * 8);
                fVar24 = fVar23 * fVar23 + fVar21 * fVar21;
                if (0.0 < fVar24) {
                    auVar25 = rsqrtss(ZEXT416((uint32_t)fVar24), ZEXT416((uint32_t)fVar24));
                    fVar21 = fVar21 * auVar25._0_4_;
                    fVar23 = fVar23 * auVar25._0_4_;
                }
                *(float *)(iVar6 + iVar9 * 8) = fVar23;
                *(uint32_t *)(iVar6 + 4 + iVar9 * 8) = (uint32_t)fVar21 ^ 0x80000000;
                iVar16 = iVar18;
                iVar10 = iVar18 + 1;
            }
            fVar26 = fVar26 * 0.5;
            iVar16 = 0;
            do {
                iVar9 = (int64_t)iVar16;
                fVar23 = (*(float *)(iVar6 + (int64_t)iVar19 * 8) + *(float *)(iVar6 + iVar9 * 8)) * 0.5;
                fVar24 = (*(float *)(iVar6 + 4 + (int64_t)iVar19 * 8) + *(float *)(iVar6 + 4 + iVar9 * 8)) * 0.5;
                fVar21 = fVar24 * fVar24 + fVar23 * fVar23;
                if (1e-06 < fVar21) {
                    fVar21 = 1.0 / fVar21;
                    fVar22 = 100.0;
                    if (fVar21 <= 100.0) {
                        fVar22 = fVar21;
                    }
                    fVar23 = fVar23 * fVar22;
                    fVar24 = fVar24 * fVar22;
                }
                iVar11 = (int16_t)iVar19 * 2;
                iVar7 = (int16_t)iVar16 * 2;
                fVar23 = fVar26 * fVar23;
                fVar24 = fVar26 * fVar24;
                iVar15 = iVar7 + iVar20;
                **(float **)(arg1 + 0x40) = *(float *)(iVar5 + iVar9 * 8) - fVar23;
                *(float *)(*(int64_t *)(arg1 + 0x40) + 4) = *(float *)(iVar5 + 4 + iVar9 * 8) - fVar24;
                iVar17 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar17 + 8) = uVar1;
                *(undefined4 *)(iVar17 + 0xc) = uVar2;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) = uVar12;
                *(float *)(*(int64_t *)(arg1 + 0x40) + 0x14) = fVar23 + *(float *)(iVar5 + iVar9 * 8);
                *(float *)(*(int64_t *)(arg1 + 0x40) + 0x18) = fVar24 + *(float *)(iVar5 + 4 + iVar9 * 8);
                iVar9 = *(int64_t *)(arg1 + 0x40);
                *(undefined4 *)(iVar9 + 0x1c) = uVar1;
                *(undefined4 *)(iVar9 + 0x20) = uVar2;
                *(uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0x24) = uVar12 & 0xffffff;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x28;
                **(int16_t **)(arg1 + 0x48) = iVar15;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 2) = iVar11 + iVar20;
                iVar11 = iVar11 + iVar20 + 1;
                iVar18 = iVar16 + 1;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 4) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 6) = iVar11;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 8) = iVar7 + iVar20 + 1;
                *(int16_t *)(*(int64_t *)(arg1 + 0x48) + 10) = iVar15;
                *(int64_t *)(arg1 + 0x48) = *(int64_t *)(arg1 + 0x48) + 0xc;
                iVar19 = iVar16;
                iVar16 = iVar18;
            } while (iVar18 < (int32_t)uVar3);
            *(int32_t *)(arg1 + 0x34) = *(int32_t *)(arg1 + 0x34) + (uVar3 * 2 & 0xffff);
            *(undefined4 *)(arg1 + 0x50) = 0;
        }
        return;
    }
    *(undefined4 *)(arg1 + 0x50) = 0;
    return;
}

// ============================================================
// Function: FUN_1800f4230
// Address: 0x1800f4230
// Size: 108 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800f4230(int64_t arg1)
{
    int64_t iVar1;
    undefined2 *puVar2;
    int64_t var_8h;
    
    puVar2 = (undefined2 *)arg1;
    for (iVar1 = 0x9b; iVar1 != 0; iVar1 = iVar1 + -1) {
        *puVar2 = 0xffff;
        puVar2 = puVar2 + 1;
    }
    if (*(int64_t *)(arg1 + 0x140) != 0) {
        *(undefined8 *)(arg1 + 0x138) = 0;
        fcn.180460d90();
        *(undefined8 *)(arg1 + 0x140) = 0;
    }
    if (*(int64_t *)(arg1 + 0x150) != 0) {
        *(undefined8 *)(arg1 + 0x148) = 0;
        fcn.180460d90();
        *(undefined8 *)(arg1 + 0x150) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800f42a0
// Address: 0x1800f42a0
// Size: 24 bytes
// ============================================================
void fcn.1800f42a0(int64_t arg1)
{
    if (*(int64_t *)(arg1 + 8) != 0) {
        fcn.180460d90();
    }
    return;
}

// ============================================================
// Function: FUN_1800f42c0
// Address: 0x1800f42c0
// Size: 458 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800f42c0(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x10) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x20) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x30) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x40) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x50) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x60) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x70) = 0;
    *(undefined8 *)(arg1 + 0x90) = 0;
    *(undefined8 *)(arg1 + 0x98) = 0;
    *(undefined8 *)(arg1 + 0xd8) = 0;
    *(undefined8 *)(arg1 + 0xe0) = 0;
    *(undefined8 *)(arg1 + 0xe8) = 0;
    *(undefined8 *)(arg1 + 0xf0) = 0;
    *(undefined8 *)(arg1 + 0xf8) = 0;
    *(undefined *)(arg1 + 200) = 0;
    *(undefined8 *)(arg1 + 0xd0) = 0;
    *(undefined4 *)(arg1 + 0xcc) = 0;
    iVar1 = *(int32_t *)(arg1 + 0xdc);
    if (iVar1 < 0) {
        iVar3 = iVar1 / 2 + iVar1;
        iVar4 = 0;
        if (0 < iVar3) {
            iVar4 = iVar3;
        }
        if (iVar1 < iVar4) {
            uVar2 = fcn.18046d050((int64_t)iVar4 << 3);
            if (*(int64_t *)(arg1 + 0xe0) != 0) {
                fcn.180498030(uVar2, *(int64_t *)(arg1 + 0xe0), (int64_t)*(int32_t *)(arg1 + 0xd8) << 3);
                fcn.180460d90(*(undefined8 *)(arg1 + 0xe0));
            }
            *(undefined8 *)(arg1 + 0xe0) = uVar2;
            *(int32_t *)(arg1 + 0xdc) = iVar4;
        }
    }
    *(undefined4 *)(arg1 + 0xd8) = 0;
    *(undefined8 *)(arg1 + 0xf8) = 0;
    *(undefined8 *)(arg1 + 0xf0) = 0;
    *(undefined8 *)(arg1 + 0xe8) = 0;
    *(undefined8 *)(arg1 + 0x100) = 0;
    *(undefined8 *)(arg1 + 0x108) = 0;
    *(undefined (*) [16])(arg1 + 0x110) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x120) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x148) = 0;
    *(undefined8 *)(arg1 + 0x150) = 0;
    *(undefined8 *)(arg1 + 0x158) = 0;
    *(undefined8 *)(arg1 + 0x160) = 0;
    *(undefined8 *)(arg1 + 0x78) = 0;
    *(undefined8 *)(arg1 + 0x80) = 0xffffffffffffffff;
    *(undefined4 *)(arg1 + 0x88) = 0xffffffff;
    *(undefined4 *)(arg1 + 0xb0) = 0xbf800000;
    *(undefined4 *)(arg1 + 0xac) = 0xbf800000;
    *(undefined4 *)(arg1 + 0x8c) = 0;
    *(undefined4 *)(arg1 + 0xa4) = 0x3f800000;
    *(undefined4 *)(arg1 + 0xa0) = 0x3f800000;
    *(undefined *)(arg1 + 0xa8) = 0;
    *(undefined2 *)(arg1 + 0xaa) = 0xffff;
    *(undefined8 *)(arg1 + 0xc0) = 0;
    *(undefined8 *)(arg1 + 0xb8) = 0;
    *(undefined4 *)(arg1 + 0x140) = 0x7f7fffff;
    *(undefined4 *)(arg1 + 0x144) = 0x7f7fffff;
    *(undefined4 *)(arg1 + 0x138) = 0x7f7fffff;
    *(undefined4 *)(arg1 + 0x13c) = 0x7f7fffff;
    *(undefined4 *)(arg1 + 0x130) = 0x7f7fffff;
    *(undefined4 *)(arg1 + 0x134) = 0x7f7fffff;
    return arg1;
}

// ============================================================
// Function: FUN_1800f4650
// Address: 0x1800f4650
// Size: 702 bytes
// ============================================================
int64_t fcn.1800f4650(int64_t arg1)
{
    undefined8 *puVar1;
    int64_t iVar2;
    
    puVar1 = (undefined8 *)(arg1 + 0x140);
    iVar2 = 0x3e;
    do {
        *puVar1 = 0;
        puVar1[1] = 0;
        puVar1 = puVar1 + 2;
        iVar2 = iVar2 + -1;
    } while (iVar2 != 0);
    *(undefined4 *)arg1 = 0;
    *(undefined4 *)(arg1 + 4) = 0x3f800000;
    *(undefined4 *)(arg1 + 8) = 0x3f800000;
    *(undefined4 *)(arg1 + 0xc) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x10) = 0x3f19999a;
    *(undefined4 *)(arg1 + 0x14) = 0x41000000;
    *(undefined8 *)(arg1 + 0x18) = 0x41000000;
    *(undefined4 *)(arg1 + 0x20) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x24) = 0x40800000;
    *(undefined4 *)(arg1 + 0x28) = 0x42000000;
    *(undefined8 *)(arg1 + 0x2c) = 0x42000000;
    *(undefined8 *)(arg1 + 0x34) = 0x3f000000;
    *(undefined4 *)(arg1 + 0x3c) = 0;
    *(undefined8 *)(arg1 + 0x40) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x48) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x4c) = 0x40800000;
    *(undefined8 *)(arg1 + 0x50) = 0x40400000;
    *(undefined4 *)(arg1 + 0x58) = 0;
    *(undefined4 *)(arg1 + 0x5c) = 0x41000000;
    *(undefined4 *)(arg1 + 0x60) = 0x40800000;
    *(undefined4 *)(arg1 + 100) = 0x40800000;
    *(undefined4 *)(arg1 + 0x68) = 0x40800000;
    *(undefined4 *)(arg1 + 0x6c) = 0x40800000;
    *(undefined8 *)(arg1 + 0x70) = 0x40000000;
    *(undefined4 *)(arg1 + 0x78) = 0;
    *(undefined4 *)(arg1 + 0x7c) = 0x41a80000;
    *(undefined4 *)(arg1 + 0x80) = 0x40c00000;
    *(undefined4 *)(arg1 + 0x84) = 0x41600000;
    *(undefined4 *)(arg1 + 0x88) = 0x41100000;
    *(undefined4 *)(arg1 + 0x8c) = 0x40000000;
    *(undefined8 *)(arg1 + 0x90) = 0x41400000;
    *(undefined8 *)(arg1 + 0x98) = 0x40800000;
    *(undefined4 *)(arg1 + 0xa0) = 0;
    *(undefined8 *)(arg1 + 0xa4) = 0x40a00000;
    *(undefined4 *)(arg1 + 0xac) = 0x3f800000;
    *(undefined4 *)(arg1 + 0xb0) = 0x42a00000;
    *(undefined4 *)(arg1 + 0xb4) = 0xbf800000;
    *(undefined4 *)(arg1 + 0xb8) = 0;
    *(undefined4 *)(arg1 + 0xbc) = 0x3f800000;
    *(undefined4 *)(arg1 + 0xc0) = 0x3f800000;
    *(undefined4 *)(arg1 + 0xc4) = 0x3f1c61aa;
    *(undefined8 *)(arg1 + 200) = 0x3f000000;
    *(undefined4 *)(arg1 + 0xd0) = 0x40000;
    *(undefined8 *)(arg1 + 0xd4) = 0x3f800000;
    *(undefined4 *)(arg1 + 0xdc) = 0;
    *(undefined4 *)(arg1 + 0xe0) = 0x40000000;
    *(undefined4 *)(arg1 + 0xe4) = 0x40400000;
    *(undefined4 *)(arg1 + 0xe8) = 0x40400000;
    *(undefined4 *)(arg1 + 0xec) = 1;
    *(undefined4 *)(arg1 + 0xf0) = 0x3f000000;
    *(undefined8 *)(arg1 + 0xf4) = 0x3f000000;
    *(undefined4 *)(arg1 + 0xfc) = 0;
    *(undefined4 *)(arg1 + 0x100) = 0x3f800000;
    *(undefined8 *)(arg1 + 0x104) = 0x40400000;
    *(undefined4 *)(arg1 + 0x10c) = 0x3f000000;
    *(undefined4 *)(arg1 + 0x110) = 0x41a00000;
    *(undefined4 *)(arg1 + 0x114) = 0x40400000;
    *(undefined4 *)(arg1 + 0x118) = 0x41980000;
    *(undefined4 *)(arg1 + 0x11c) = 0x41980000;
    *(undefined4 *)(arg1 + 0x120) = 0x40400000;
    *(undefined4 *)(arg1 + 0x124) = 0x40400000;
    *(undefined *)(arg1 + 0x128) = 1;
    *(undefined4 *)(arg1 + 300) = 0x40000000;
    *(undefined4 *)(arg1 + 0x130) = 0x3f800000;
    *(undefined2 *)(arg1 + 0x134) = 0x101;
    *(undefined *)(arg1 + 0x136) = 1;
    *(undefined4 *)(arg1 + 0x138) = 0x3fa00000;
    *(undefined4 *)(arg1 + 0x13c) = 0x3e99999a;
    *(undefined4 *)(arg1 + 0x520) = 0x3e19999a;
    *(undefined4 *)(arg1 + 0x524) = 0x3e19999a;
    *(undefined4 *)(arg1 + 0x528) = 0x3ecccccd;
    *(undefined4 *)(arg1 + 0x52c) = 0xa400;
    *(undefined4 *)(arg1 + 0x530) = 0x30400;
    *(undefined8 *)(arg1 + 0x534) = 0x3f800000;
    fcn.180123270(arg1);
    return arg1;
}

// ============================================================
// Function: FUN_1800f4f10
// Address: 0x1800f4f10
// Size: 573 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800f4f10(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    
    *(undefined8 *)(arg1 + 0xd4) = 0;
    *(undefined8 *)(arg1 + 0xacc) = 0;
    *(undefined8 *)(arg1 + 0xad4) = 0;
    *(undefined8 *)(arg1 + 0xadc) = 0;
    *(undefined8 *)(arg1 + 0xae4) = 0;
    *(undefined8 *)(arg1 + 0xaec) = 0;
    *(undefined8 *)(arg1 + 0xba4) = 0;
    *(undefined8 *)(arg1 + 0xbac) = 0;
    *(undefined8 *)(arg1 + 0xbb4) = 0;
    *(undefined8 *)(arg1 + 0xbbc) = 0;
    *(undefined8 *)(arg1 + 0xbc4) = 0;
    *(undefined8 *)(arg1 + 0xbe8) = 0;
    *(undefined8 *)(arg1 + 0xbf0) = 0;
    fcn.1804986e0(arg1, 0, 0xc18);
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 0x20) = 0x1806442b0;
    *(undefined4 *)(arg1 + 8) = 0xbf800000;
    *(undefined8 *)(arg1 + 0x28) = 0x1806442c0;
    *(undefined4 *)(arg1 + 0xc) = 0xbf800000;
    *(undefined4 *)(arg1 + 0x18) = 0x3c888889;
    *(undefined4 *)(arg1 + 0x1c) = 0x40a00000;
    *(undefined8 *)(arg1 + 0x30) = 0;
    *(undefined8 *)(arg1 + 0x38) = 0;
    *(undefined8 *)(arg1 + 0x40) = 0;
    *(undefined4 *)(arg1 + 0x48) = 0x1000000;
    *(undefined4 *)(arg1 + 0xbf8) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x10) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x14) = 0x3f800000;
    *(undefined8 *)(arg1 + 0x4c) = 0x10001;
    *(undefined4 *)(arg1 + 0x54) = 0x1000000;
    *(undefined2 *)(arg1 + 0x58) = 0x101;
    *(undefined4 *)(arg1 + 0x5c) = 0x1010000;
    *(undefined4 *)(arg1 + 0x60) = 0x10000;
    *(undefined2 *)(arg1 + 100) = 0x100;
    *(undefined4 *)(arg1 + 0x68) = 0x42700000;
    *(undefined4 *)(arg1 + 0x84) = 0x10100;
    *(undefined *)(arg1 + 0x88) = 0;
    *(undefined4 *)(arg1 + 0x80) = 0x1010101;
    *(undefined4 *)(arg1 + 0x6c) = 0x3e99999a;
    *(undefined4 *)(arg1 + 0x70) = 0x40c00000;
    *(undefined4 *)(arg1 + 0x74) = 0x40c00000;
    *(undefined4 *)(arg1 + 0x78) = 0x3e8ccccd;
    *(undefined4 *)(arg1 + 0x7c) = 0x3d4ccccd;
    *(undefined8 *)(arg1 + 0x98) = 0;
    *(undefined8 *)(arg1 + 0x90) = 0;
    *(undefined8 *)(arg1 + 0xb0) = 0;
    *(undefined8 *)(arg1 + 0xa8) = 0;
    *(undefined8 *)(arg1 + 0xa0) = 0;
    *(undefined4 *)(arg1 + 0xe8) = 0xff7fffff;
    *(undefined4 *)(arg1 + 0xec) = 0xff7fffff;
    *(undefined4 *)(arg1 + 0xac4) = 0xff7fffff;
    *(undefined4 *)(arg1 + 0xac8) = 0xff7fffff;
    *(undefined4 *)(arg1 + 0x100) = 0;
    *(undefined4 *)(arg1 + 0xb90) = 0xbf800000;
    *(undefined4 *)(arg1 + 0xb7c) = 0xbf800000;
    *(undefined4 *)(arg1 + 0xb94) = 0xbf800000;
    *(undefined4 *)(arg1 + 0xb80) = 0xbf800000;
    *(undefined4 *)(arg1 + 0xb98) = 0xbf800000;
    *(undefined4 *)(arg1 + 0xb84) = 0xbf800000;
    *(undefined4 *)(arg1 + 0xb9c) = 0xbf800000;
    *(undefined4 *)(arg1 + 0xb88) = 0xbf800000;
    *(undefined4 *)(arg1 + 0xba0) = 0xbf800000;
    *(undefined4 *)(arg1 + 0xb8c) = 0xbf800000;
    iVar1 = 0;
    do {
        iVar2 = iVar1 + 1;
        *(undefined4 *)(arg1 + 0x118 + iVar1 * 0x10) = 0xbf800000;
        *(undefined4 *)(arg1 + 0x114 + iVar1 * 0x10) = 0xbf800000;
        iVar1 = iVar2;
    } while (iVar2 != 0x9b);
    *(undefined *)(arg1 + 0xbe5) = 1;
    return arg1;
}

// ============================================================
// Function: FUN_1800f5150
// Address: 0x1800f5150
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1800f5150(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    int32_t *piVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar8 = (int32_t)arg2;
    if ((iVar8 != 0) && (*(char *)(arg1 + 0xbe5) != '\0')) {
        iVar5 = *(int64_t *)(arg1 + 0xe0);
        iVar4 = *(int32_t *)(iVar5 + 0x157c);
        piVar1 = (int32_t *)(iVar5 + 0x1558);
        *(int32_t *)(iVar5 + 0x157c) = iVar4 + 1;
        iVar6 = *(int32_t *)(iVar5 + 0x155c);
        if (*piVar1 == iVar6) {
            iVar7 = *piVar1 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar7 < iVar6) {
                iVar7 = iVar6;
            }
            func_0x00018011f9d0(piVar1, iVar7);
        }
        iVar6 = *piVar1;
        iVar5 = *(int64_t *)(iVar5 + 0x1560);
        puVar2 = (undefined4 *)((int64_t)iVar6 * 0x1c + iVar5);
        *puVar2 = 6;
        puVar2[1] = 2;
        puVar2[2] = iVar4;
        puVar2[3] = iVar8;
        piVar3 = (int32_t *)((int64_t)iVar6 * 0x1c + 0xc + iVar5);
        *piVar3 = iVar8;
        piVar3[1] = 0;
        piVar3[2] = 0;
        piVar3[3] = 0;
        *piVar1 = *piVar1 + 1;
    }
    return;
}

// ============================================================
// Function: FUN_1800f517b
// Address: 0x1800f517b
// Size: 138 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1800f5150(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    int32_t *piVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar8 = (int32_t)arg2;
    if ((iVar8 != 0) && (*(char *)(arg1 + 0xbe5) != '\0')) {
        iVar5 = *(int64_t *)(arg1 + 0xe0);
        iVar4 = *(int32_t *)(iVar5 + 0x157c);
        piVar1 = (int32_t *)(iVar5 + 0x1558);
        *(int32_t *)(iVar5 + 0x157c) = iVar4 + 1;
        iVar6 = *(int32_t *)(iVar5 + 0x155c);
        if (*piVar1 == iVar6) {
            iVar7 = *piVar1 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar7 < iVar6) {
                iVar7 = iVar6;
            }
            func_0x00018011f9d0(piVar1, iVar7);
        }
        iVar6 = *piVar1;
        iVar5 = *(int64_t *)(iVar5 + 0x1560);
        puVar2 = (undefined4 *)((int64_t)iVar6 * 0x1c + iVar5);
        *puVar2 = 6;
        puVar2[1] = 2;
        puVar2[2] = iVar4;
        puVar2[3] = iVar8;
        piVar3 = (int32_t *)((int64_t)iVar6 * 0x1c + 0xc + iVar5);
        *piVar3 = iVar8;
        piVar3[1] = 0;
        piVar3[2] = 0;
        piVar3[3] = 0;
        *piVar1 = *piVar1 + 1;
    }
    return;
}

// ============================================================
// Function: FUN_1800f5205
// Address: 0x1800f5205
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1800f5150(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    int32_t *piVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar8 = (int32_t)arg2;
    if ((iVar8 != 0) && (*(char *)(arg1 + 0xbe5) != '\0')) {
        iVar5 = *(int64_t *)(arg1 + 0xe0);
        iVar4 = *(int32_t *)(iVar5 + 0x157c);
        piVar1 = (int32_t *)(iVar5 + 0x1558);
        *(int32_t *)(iVar5 + 0x157c) = iVar4 + 1;
        iVar6 = *(int32_t *)(iVar5 + 0x155c);
        if (*piVar1 == iVar6) {
            iVar7 = *piVar1 + 1;
            if (iVar6 == 0) {
                iVar6 = 8;
            } else {
                iVar6 = iVar6 / 2 + iVar6;
            }
            if (iVar7 < iVar6) {
                iVar7 = iVar6;
            }
            func_0x00018011f9d0(piVar1, iVar7);
        }
        iVar6 = *piVar1;
        iVar5 = *(int64_t *)(iVar5 + 0x1560);
        puVar2 = (undefined4 *)((int64_t)iVar6 * 0x1c + iVar5);
        *puVar2 = 6;
        puVar2[1] = 2;
        puVar2[2] = iVar4;
        puVar2[3] = iVar8;
        piVar3 = (int32_t *)((int64_t)iVar6 * 0x1c + 0xc + iVar5);
        *piVar3 = iVar8;
        piVar3[1] = 0;
        piVar3[2] = 0;
        piVar3[3] = 0;
        *piVar1 = *piVar1 + 1;
    }
    return;
}

// ============================================================
// Function: FUN_1800f5210
// Address: 0x1800f5210
// Size: 188 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.1800f5210(int64_t arg1)
{
    uint16_t in_DX;
    int64_t var_8h;
    int64_t var_10h;
    
    if (((in_DX != 0) || (*(int16_t *)(arg1 + 0xbe6) != 0)) && (*(char *)(arg1 + 0xbe5) != '\0')) {
        if ((in_DX & 0xfc00) == 0xd800) {
            if (*(int16_t *)(arg1 + 0xbe6) != 0) {
                fcn.1800f5150(arg1, 0xfffd);
            }
            *(uint16_t *)(arg1 + 0xbe6) = in_DX;
            return;
        }
        if (*(int16_t *)(arg1 + 0xbe6) != 0) {
            if ((in_DX & 0xfc00) == 0xdc00) {
                in_DX = 0xfffd;
            } else {
                fcn.1800f5150(arg1, 0xfffd);
            }
            *(undefined2 *)(arg1 + 0xbe6) = 0;
        }
        fcn.1800f5150(arg1, (uint64_t)in_DX);
    }
    return;
}

// ============================================================
// Function: FUN_1800f52d0
// Address: 0x1800f52d0
// Size: 149 bytes
// ============================================================
void fcn.1800f52d0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    
    iVar1 = *(int64_t *)(arg1 + 0xe0);
    uVar5 = 0x200;
    do {
        if (6 < (int32_t)uVar5 - 0x290U) {
            *(undefined *)(iVar1 + (uVar5 - 0x1ec) * 0x10) = 0;
            *(undefined4 *)(iVar1 + -0x1ebc + uVar5 * 0x10) = 0xbf800000;
            *(undefined4 *)(iVar1 + -0x1eb8 + uVar5 * 0x10) = 0xbf800000;
        }
        uVar4 = (int32_t)uVar5 + 1;
        uVar5 = (uint64_t)uVar4;
    } while ((int32_t)uVar4 < 0x29b);
    *(undefined8 *)(arg1 + 0x108) = 0;
    iVar3 = *(int32_t *)(arg1 + 0xbec);
    if (iVar3 < 0) {
        iVar3 = iVar3 + iVar3 / 2;
        iVar2 = 0;
        if (0 < iVar3) {
            iVar2 = iVar3;
        }
        func_0x00018011f8d0((undefined4 *)(arg1 + 0xbe8), iVar2);
    }
    *(undefined4 *)(arg1 + 0xbe8) = 0;
    return;
}

// ============================================================
// Function: FUN_1800f5370
// Address: 0x1800f5370
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_17h
// WARNING: [rz-ghidra] Detected overlap for variable var_15h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

void fcn.1800f5370(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    int32_t *piVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint8_t uVar7;
    int32_t iVar8;
    uint8_t *puVar9;
    uint32_t uVar10;
    int32_t iVar11;
    int32_t iVar12;
    int64_t iVar13;
    uint8_t in_R8B;
    int32_t iVar14;
    uint64_t uVar15;
    int64_t iVar16;
    float fVar17;
    float in_XMM3_Da;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_14h;
    
    iVar12 = (int32_t)arg2;
    if ((iVar12 != 0) && (uVar15 = arg2 & 0xffffffff, *(char *)(arg1 + 0xbe5) != '\0')) {
        iVar5 = *(int64_t *)(arg1 + 0xe0);
        if (*(char *)(iVar5 + 0x8d) != '\0') {
            if (iVar12 == 0x8000) {
                uVar15 = 0x1000;
            } else if (iVar12 == 0x1000) {
                uVar15 = 0x8000;
            } else if (iVar12 == 0x212) {
                uVar15 = 0x20f;
            } else if (iVar12 == 0x216) {
                uVar15 = 0x213;
            } else if (iVar12 == 0x20f) {
                uVar15 = 0x212;
            } else {
                uVar15 = arg2 & 0xffffffff;
                if (iVar12 == 0x213) {
                    uVar15 = 0x216;
                }
            }
        }
        piVar1 = (int32_t *)(iVar5 + 0x1558);
        iVar12 = *piVar1;
        uVar10 = iVar12 - 1;
        iVar14 = (int32_t)uVar15;
        iVar16 = iVar5;
        if (-1 < (int32_t)uVar10) {
            iVar6 = *(int64_t *)(iVar5 + 0x1560);
            do {
                iVar13 = (uint64_t)uVar10 * 0x1c;
                if ((*(int32_t *)(iVar13 + iVar6) == 5) && (*(int32_t *)(iVar13 + 0xc + iVar6) == iVar14)) {
                    fVar17 = *(float *)(iVar13 + 0x14 + iVar6);
                    uVar7 = *(uint8_t *)(iVar13 + 0x10 + iVar6);
                    goto code_r0x0001800f5450;
                }
                uVar10 = uVar10 - 1;
            } while (-1 < (int32_t)uVar10);
        }
        puVar9 = (uint8_t *)func_0x0001801077f0(iVar5, uVar15);
        fVar17 = *(float *)(puVar9 + 0xc);
        uVar7 = *puVar9;
code_r0x0001800f5450:
        if ((uVar7 != in_R8B) || (fVar17 != in_XMM3_Da)) {
            iVar4 = *(int32_t *)(iVar16 + 0x157c);
            *(int32_t *)(iVar16 + 0x157c) = iVar4 + 1;
            iVar8 = *(int32_t *)(iVar5 + 0x155c);
            if (iVar12 == iVar8) {
                if (iVar8 == 0) {
                    iVar8 = 8;
                } else {
                    iVar8 = iVar8 / 2 + iVar8;
                }
                iVar11 = iVar12 + 1;
                if (iVar12 + 1 < iVar8) {
                    iVar11 = iVar8;
                }
                func_0x00018011f9d0(piVar1, iVar11);
            }
            iVar12 = *piVar1;
            iVar5 = *(int64_t *)(iVar5 + 0x1560);
            puVar2 = (undefined4 *)((int64_t)iVar12 * 0x1c + iVar5);
            *puVar2 = 5;
            puVar2[1] = (iVar14 - 0x278U < 0x18) + 2;
            puVar2[2] = iVar4;
            puVar2[3] = iVar14;
            piVar3 = (int32_t *)((int64_t)iVar12 * 0x1c + 0xc + iVar5);
            *piVar3 = iVar14;
            piVar3[1] = (uint32_t)in_R8B;
            piVar3[2] = (int32_t)in_XMM3_Da;
            piVar3[3] = 0;
            *piVar1 = *piVar1 + 1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f5398
// Address: 0x1800f5398
// Size: 387 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_17h
// WARNING: [rz-ghidra] Detected overlap for variable var_15h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

void fcn.1800f5370(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    int32_t *piVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint8_t uVar7;
    int32_t iVar8;
    uint8_t *puVar9;
    uint32_t uVar10;
    int32_t iVar11;
    int32_t iVar12;
    int64_t iVar13;
    uint8_t in_R8B;
    int32_t iVar14;
    uint64_t uVar15;
    int64_t iVar16;
    float fVar17;
    float in_XMM3_Da;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_14h;
    
    iVar12 = (int32_t)arg2;
    if ((iVar12 != 0) && (uVar15 = arg2 & 0xffffffff, *(char *)(arg1 + 0xbe5) != '\0')) {
        iVar5 = *(int64_t *)(arg1 + 0xe0);
        if (*(char *)(iVar5 + 0x8d) != '\0') {
            if (iVar12 == 0x8000) {
                uVar15 = 0x1000;
            } else if (iVar12 == 0x1000) {
                uVar15 = 0x8000;
            } else if (iVar12 == 0x212) {
                uVar15 = 0x20f;
            } else if (iVar12 == 0x216) {
                uVar15 = 0x213;
            } else if (iVar12 == 0x20f) {
                uVar15 = 0x212;
            } else {
                uVar15 = arg2 & 0xffffffff;
                if (iVar12 == 0x213) {
                    uVar15 = 0x216;
                }
            }
        }
        piVar1 = (int32_t *)(iVar5 + 0x1558);
        iVar12 = *piVar1;
        uVar10 = iVar12 - 1;
        iVar14 = (int32_t)uVar15;
        iVar16 = iVar5;
        if (-1 < (int32_t)uVar10) {
            iVar6 = *(int64_t *)(iVar5 + 0x1560);
            do {
                iVar13 = (uint64_t)uVar10 * 0x1c;
                if ((*(int32_t *)(iVar13 + iVar6) == 5) && (*(int32_t *)(iVar13 + 0xc + iVar6) == iVar14)) {
                    fVar17 = *(float *)(iVar13 + 0x14 + iVar6);
                    uVar7 = *(uint8_t *)(iVar13 + 0x10 + iVar6);
                    goto code_r0x0001800f5450;
                }
                uVar10 = uVar10 - 1;
            } while (-1 < (int32_t)uVar10);
        }
        puVar9 = (uint8_t *)func_0x0001801077f0(iVar5, uVar15);
        fVar17 = *(float *)(puVar9 + 0xc);
        uVar7 = *puVar9;
code_r0x0001800f5450:
        if ((uVar7 != in_R8B) || (fVar17 != in_XMM3_Da)) {
            iVar4 = *(int32_t *)(iVar16 + 0x157c);
            *(int32_t *)(iVar16 + 0x157c) = iVar4 + 1;
            iVar8 = *(int32_t *)(iVar5 + 0x155c);
            if (iVar12 == iVar8) {
                if (iVar8 == 0) {
                    iVar8 = 8;
                } else {
                    iVar8 = iVar8 / 2 + iVar8;
                }
                iVar11 = iVar12 + 1;
                if (iVar12 + 1 < iVar8) {
                    iVar11 = iVar8;
                }
                func_0x00018011f9d0(piVar1, iVar11);
            }
            iVar12 = *piVar1;
            iVar5 = *(int64_t *)(iVar5 + 0x1560);
            puVar2 = (undefined4 *)((int64_t)iVar12 * 0x1c + iVar5);
            *puVar2 = 5;
            puVar2[1] = (iVar14 - 0x278U < 0x18) + 2;
            puVar2[2] = iVar4;
            puVar2[3] = iVar14;
            piVar3 = (int32_t *)((int64_t)iVar12 * 0x1c + 0xc + iVar5);
            *piVar3 = iVar14;
            piVar3[1] = (uint32_t)in_R8B;
            piVar3[2] = (int32_t)in_XMM3_Da;
            piVar3[3] = 0;
            *piVar1 = *piVar1 + 1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f551b
// Address: 0x1800f551b
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_17h
// WARNING: [rz-ghidra] Detected overlap for variable var_15h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

void fcn.1800f5370(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    int32_t *piVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint8_t uVar7;
    int32_t iVar8;
    uint8_t *puVar9;
    uint32_t uVar10;
    int32_t iVar11;
    int32_t iVar12;
    int64_t iVar13;
    uint8_t in_R8B;
    int32_t iVar14;
    uint64_t uVar15;
    int64_t iVar16;
    float fVar17;
    float in_XMM3_Da;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_14h;
    
    iVar12 = (int32_t)arg2;
    if ((iVar12 != 0) && (uVar15 = arg2 & 0xffffffff, *(char *)(arg1 + 0xbe5) != '\0')) {
        iVar5 = *(int64_t *)(arg1 + 0xe0);
        if (*(char *)(iVar5 + 0x8d) != '\0') {
            if (iVar12 == 0x8000) {
                uVar15 = 0x1000;
            } else if (iVar12 == 0x1000) {
                uVar15 = 0x8000;
            } else if (iVar12 == 0x212) {
                uVar15 = 0x20f;
            } else if (iVar12 == 0x216) {
                uVar15 = 0x213;
            } else if (iVar12 == 0x20f) {
                uVar15 = 0x212;
            } else {
                uVar15 = arg2 & 0xffffffff;
                if (iVar12 == 0x213) {
                    uVar15 = 0x216;
                }
            }
        }
        piVar1 = (int32_t *)(iVar5 + 0x1558);
        iVar12 = *piVar1;
        uVar10 = iVar12 - 1;
        iVar14 = (int32_t)uVar15;
        iVar16 = iVar5;
        if (-1 < (int32_t)uVar10) {
            iVar6 = *(int64_t *)(iVar5 + 0x1560);
            do {
                iVar13 = (uint64_t)uVar10 * 0x1c;
                if ((*(int32_t *)(iVar13 + iVar6) == 5) && (*(int32_t *)(iVar13 + 0xc + iVar6) == iVar14)) {
                    fVar17 = *(float *)(iVar13 + 0x14 + iVar6);
                    uVar7 = *(uint8_t *)(iVar13 + 0x10 + iVar6);
                    goto code_r0x0001800f5450;
                }
                uVar10 = uVar10 - 1;
            } while (-1 < (int32_t)uVar10);
        }
        puVar9 = (uint8_t *)func_0x0001801077f0(iVar5, uVar15);
        fVar17 = *(float *)(puVar9 + 0xc);
        uVar7 = *puVar9;
code_r0x0001800f5450:
        if ((uVar7 != in_R8B) || (fVar17 != in_XMM3_Da)) {
            iVar4 = *(int32_t *)(iVar16 + 0x157c);
            *(int32_t *)(iVar16 + 0x157c) = iVar4 + 1;
            iVar8 = *(int32_t *)(iVar5 + 0x155c);
            if (iVar12 == iVar8) {
                if (iVar8 == 0) {
                    iVar8 = 8;
                } else {
                    iVar8 = iVar8 / 2 + iVar8;
                }
                iVar11 = iVar12 + 1;
                if (iVar12 + 1 < iVar8) {
                    iVar11 = iVar8;
                }
                func_0x00018011f9d0(piVar1, iVar11);
            }
            iVar12 = *piVar1;
            iVar5 = *(int64_t *)(iVar5 + 0x1560);
            puVar2 = (undefined4 *)((int64_t)iVar12 * 0x1c + iVar5);
            *puVar2 = 5;
            puVar2[1] = (iVar14 - 0x278U < 0x18) + 2;
            puVar2[2] = iVar4;
            puVar2[3] = iVar14;
            piVar3 = (int32_t *)((int64_t)iVar12 * 0x1c + 0xc + iVar5);
            *piVar3 = iVar14;
            piVar3[1] = (uint32_t)in_R8B;
            piVar3[2] = (int32_t)in_XMM3_Da;
            piVar3[3] = 0;
            *piVar1 = *piVar1 + 1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f5530
// Address: 0x1800f5530
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.1800f5530(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    float *pfVar3;
    float fVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    uint32_t uVar10;
    int32_t iVar11;
    int64_t iVar12;
    float in_XMM1_Da;
    float in_XMM2_Da;
    float fVar13;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(char *)(arg1 + 0xbe5) != '\0') {
        iVar6 = *(int64_t *)(arg1 + 0xe0);
        if (-3.402823e+38 < in_XMM2_Da) {
            iVar8 = (int32_t)in_XMM2_Da;
            if ((in_XMM2_Da < 0.0) && ((float)iVar8 != in_XMM2_Da)) {
                iVar8 = iVar8 + -1;
            }
            in_XMM2_Da = (float)iVar8;
        }
        if (-3.402823e+38 < in_XMM1_Da) {
            iVar8 = (int32_t)in_XMM1_Da;
            if ((in_XMM1_Da < 0.0) && ((float)iVar8 != in_XMM1_Da)) {
                iVar8 = iVar8 + -1;
            }
            in_XMM1_Da = (float)iVar8;
        }
        piVar1 = (int32_t *)(iVar6 + 0x1558);
        iVar8 = *piVar1;
        uVar10 = iVar8 - 1;
        if (-1 < (int32_t)uVar10) {
            iVar7 = *(int64_t *)(iVar6 + 0x1560);
            do {
                iVar12 = (uint64_t)uVar10 * 0x1c;
                if (*(int32_t *)(iVar12 + iVar7) == 1) {
                    fVar4 = *(float *)(iVar12 + 0xc + iVar7);
                    fVar13 = *(float *)(iVar12 + 0x10 + iVar7);
                    goto code_r0x0001800f55e8;
                }
                uVar10 = uVar10 - 1;
            } while (-1 < (int32_t)uVar10);
        }
        fVar4 = *(float *)(iVar6 + 0x118);
        fVar13 = *(float *)(iVar6 + 0x11c);
code_r0x0001800f55e8:
        if ((fVar4 != in_XMM1_Da) || (fVar13 != in_XMM2_Da)) {
            iVar5 = *(int32_t *)(iVar6 + 0x157c);
            *(int32_t *)(iVar6 + 0x157c) = iVar5 + 1;
            iVar9 = *(int32_t *)(iVar6 + 0x155c);
            fVar13 = *(float *)(iVar6 + 0x1578);
            if (iVar8 == iVar9) {
                if (iVar9 == 0) {
                    iVar9 = 8;
                } else {
                    iVar9 = iVar9 / 2 + iVar9;
                }
                iVar11 = iVar8 + 1;
                if (iVar8 + 1 < iVar9) {
                    iVar11 = iVar9;
                }
                func_0x00018011f9d0(piVar1, iVar11);
            }
            iVar8 = *piVar1;
            iVar6 = *(int64_t *)(iVar6 + 0x1560);
            puVar2 = (undefined4 *)((int64_t)iVar8 * 0x1c + iVar6);
            *puVar2 = 1;
            puVar2[1] = 1;
            puVar2[2] = iVar5;
            puVar2[3] = in_XMM1_Da;
            pfVar3 = (float *)((int64_t)iVar8 * 0x1c + 0xc + iVar6);
            *pfVar3 = in_XMM1_Da;
            pfVar3[1] = in_XMM2_Da;
            pfVar3[2] = fVar13;
            pfVar3[3] = 0.0;
            *piVar1 = *piVar1 + 1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f5556
// Address: 0x1800f5556
// Size: 338 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.1800f5530(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    float *pfVar3;
    float fVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    uint32_t uVar10;
    int32_t iVar11;
    int64_t iVar12;
    float in_XMM1_Da;
    float in_XMM2_Da;
    float fVar13;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(char *)(arg1 + 0xbe5) != '\0') {
        iVar6 = *(int64_t *)(arg1 + 0xe0);
        if (-3.402823e+38 < in_XMM2_Da) {
            iVar8 = (int32_t)in_XMM2_Da;
            if ((in_XMM2_Da < 0.0) && ((float)iVar8 != in_XMM2_Da)) {
                iVar8 = iVar8 + -1;
            }
            in_XMM2_Da = (float)iVar8;
        }
        if (-3.402823e+38 < in_XMM1_Da) {
            iVar8 = (int32_t)in_XMM1_Da;
            if ((in_XMM1_Da < 0.0) && ((float)iVar8 != in_XMM1_Da)) {
                iVar8 = iVar8 + -1;
            }
            in_XMM1_Da = (float)iVar8;
        }
        piVar1 = (int32_t *)(iVar6 + 0x1558);
        iVar8 = *piVar1;
        uVar10 = iVar8 - 1;
        if (-1 < (int32_t)uVar10) {
            iVar7 = *(int64_t *)(iVar6 + 0x1560);
            do {
                iVar12 = (uint64_t)uVar10 * 0x1c;
                if (*(int32_t *)(iVar12 + iVar7) == 1) {
                    fVar4 = *(float *)(iVar12 + 0xc + iVar7);
                    fVar13 = *(float *)(iVar12 + 0x10 + iVar7);
                    goto code_r0x0001800f55e8;
                }
                uVar10 = uVar10 - 1;
            } while (-1 < (int32_t)uVar10);
        }
        fVar4 = *(float *)(iVar6 + 0x118);
        fVar13 = *(float *)(iVar6 + 0x11c);
code_r0x0001800f55e8:
        if ((fVar4 != in_XMM1_Da) || (fVar13 != in_XMM2_Da)) {
            iVar5 = *(int32_t *)(iVar6 + 0x157c);
            *(int32_t *)(iVar6 + 0x157c) = iVar5 + 1;
            iVar9 = *(int32_t *)(iVar6 + 0x155c);
            fVar13 = *(float *)(iVar6 + 0x1578);
            if (iVar8 == iVar9) {
                if (iVar9 == 0) {
                    iVar9 = 8;
                } else {
                    iVar9 = iVar9 / 2 + iVar9;
                }
                iVar11 = iVar8 + 1;
                if (iVar8 + 1 < iVar9) {
                    iVar11 = iVar9;
                }
                func_0x00018011f9d0(piVar1, iVar11);
            }
            iVar8 = *piVar1;
            iVar6 = *(int64_t *)(iVar6 + 0x1560);
            puVar2 = (undefined4 *)((int64_t)iVar8 * 0x1c + iVar6);
            *puVar2 = 1;
            puVar2[1] = 1;
            puVar2[2] = iVar5;
            puVar2[3] = in_XMM1_Da;
            pfVar3 = (float *)((int64_t)iVar8 * 0x1c + 0xc + iVar6);
            *pfVar3 = in_XMM1_Da;
            pfVar3[1] = in_XMM2_Da;
            pfVar3[2] = fVar13;
            pfVar3[3] = 0.0;
            *piVar1 = *piVar1 + 1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f56a8
// Address: 0x1800f56a8
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.1800f5530(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    float *pfVar3;
    float fVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    uint32_t uVar10;
    int32_t iVar11;
    int64_t iVar12;
    float in_XMM1_Da;
    float in_XMM2_Da;
    float fVar13;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    if (*(char *)(arg1 + 0xbe5) != '\0') {
        iVar6 = *(int64_t *)(arg1 + 0xe0);
        if (-3.402823e+38 < in_XMM2_Da) {
            iVar8 = (int32_t)in_XMM2_Da;
            if ((in_XMM2_Da < 0.0) && ((float)iVar8 != in_XMM2_Da)) {
                iVar8 = iVar8 + -1;
            }
            in_XMM2_Da = (float)iVar8;
        }
        if (-3.402823e+38 < in_XMM1_Da) {
            iVar8 = (int32_t)in_XMM1_Da;
            if ((in_XMM1_Da < 0.0) && ((float)iVar8 != in_XMM1_Da)) {
                iVar8 = iVar8 + -1;
            }
            in_XMM1_Da = (float)iVar8;
        }
        piVar1 = (int32_t *)(iVar6 + 0x1558);
        iVar8 = *piVar1;
        uVar10 = iVar8 - 1;
        if (-1 < (int32_t)uVar10) {
            iVar7 = *(int64_t *)(iVar6 + 0x1560);
            do {
                iVar12 = (uint64_t)uVar10 * 0x1c;
                if (*(int32_t *)(iVar12 + iVar7) == 1) {
                    fVar4 = *(float *)(iVar12 + 0xc + iVar7);
                    fVar13 = *(float *)(iVar12 + 0x10 + iVar7);
                    goto code_r0x0001800f55e8;
                }
                uVar10 = uVar10 - 1;
            } while (-1 < (int32_t)uVar10);
        }
        fVar4 = *(float *)(iVar6 + 0x118);
        fVar13 = *(float *)(iVar6 + 0x11c);
code_r0x0001800f55e8:
        if ((fVar4 != in_XMM1_Da) || (fVar13 != in_XMM2_Da)) {
            iVar5 = *(int32_t *)(iVar6 + 0x157c);
            *(int32_t *)(iVar6 + 0x157c) = iVar5 + 1;
            iVar9 = *(int32_t *)(iVar6 + 0x155c);
            fVar13 = *(float *)(iVar6 + 0x1578);
            if (iVar8 == iVar9) {
                if (iVar9 == 0) {
                    iVar9 = 8;
                } else {
                    iVar9 = iVar9 / 2 + iVar9;
                }
                iVar11 = iVar8 + 1;
                if (iVar8 + 1 < iVar9) {
                    iVar11 = iVar9;
                }
                func_0x00018011f9d0(piVar1, iVar11);
            }
            iVar8 = *piVar1;
            iVar6 = *(int64_t *)(iVar6 + 0x1560);
            puVar2 = (undefined4 *)((int64_t)iVar8 * 0x1c + iVar6);
            *puVar2 = 1;
            puVar2[1] = 1;
            puVar2[2] = iVar5;
            puVar2[3] = in_XMM1_Da;
            pfVar3 = (float *)((int64_t)iVar8 * 0x1c + 0xc + iVar6);
            *pfVar3 = in_XMM1_Da;
            pfVar3[1] = in_XMM2_Da;
            pfVar3[2] = fVar13;
            pfVar3[3] = 0.0;
            *piVar1 = *piVar1 + 1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f56b0
// Address: 0x1800f56b0
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_15h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_49h

void fcn.1800f56b0(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    char *pcVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    int32_t *piVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    uint8_t uVar12;
    char cVar13;
    int32_t iVar14;
    uint32_t uVar15;
    uint8_t in_R8B;
    uint32_t uVar16;
    uint64_t uVar17;
    int32_t iVar18;
    uint64_t uVar19;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_47h;
    int64_t var_28h;
    int64_t var_17h;
    int64_t var_8h;
    
    uVar19 = arg2 & 0xffffffff;
    if (*(char *)(arg1 + 0xbe5) == '\0') {
        return;
    }
    pcVar1 = (char *)(arg1 + 0xb7b);
    iVar8 = *(int64_t *)(arg1 + 0xe0);
    piVar2 = (int32_t *)(iVar8 + 0x1558);
    if ((((*(char *)(arg1 + 0x5d) != '\0') && ((int32_t)arg2 == 0)) && (*pcVar1 != (char)arg2)) &&
       (uVar19 = 1, in_R8B == 0)) {
        *pcVar1 = (char)arg2;
    }
    do {
        iVar5 = *piVar2;
        uVar16 = iVar5 - 1;
        uVar17 = (uint64_t)uVar16;
        iVar18 = (int32_t)uVar19;
        if (-1 < (int32_t)uVar16) {
            iVar9 = *(int64_t *)(iVar8 + 0x1560);
            uVar19 = uVar17;
            do {
                iVar11 = uVar19 * 0x1c;
                if ((*(int32_t *)(iVar11 + iVar9) == 3) && (*(int32_t *)(iVar11 + 0xc + iVar9) == iVar18)) {
                    uVar12 = *(uint8_t *)(iVar11 + 0x10 + iVar9);
                    goto code_r0x0001800f5764;
                }
                uVar15 = (int32_t)uVar19 - 1;
                uVar19 = (uint64_t)uVar15;
            } while (-1 < (int32_t)uVar15);
        }
        uVar12 = *(uint8_t *)((int64_t)iVar18 + 0x120 + iVar8);
code_r0x0001800f5764:
        if (uVar12 == in_R8B) {
            return;
        }
        if (((*(char *)(arg1 + 0x5d) == '\0') || (iVar18 != 0)) || (in_R8B == 0)) {
code_r0x0001800f57d8:
            iVar6 = *(int32_t *)(iVar8 + 0x157c);
            *(int32_t *)(iVar8 + 0x157c) = iVar6 + 1;
            iVar10 = *(int32_t *)(iVar8 + 0x155c);
            iVar7 = *(int32_t *)(iVar8 + 0x1578);
            if (iVar5 == iVar10) {
                if (iVar10 == 0) {
                    iVar10 = 8;
                } else {
                    iVar10 = iVar10 / 2 + iVar10;
                }
                iVar14 = iVar5 + 1;
                if (iVar5 + 1 < iVar10) {
                    iVar14 = iVar10;
                }
                func_0x00018011f9d0(piVar2, iVar14);
            }
            iVar5 = *piVar2;
            iVar8 = *(int64_t *)(iVar8 + 0x1560);
            puVar3 = (undefined4 *)((int64_t)iVar5 * 0x1c + iVar8);
            *puVar3 = 3;
            puVar3[1] = 1;
            puVar3[2] = iVar6;
            puVar3[3] = iVar18;
            piVar4 = (int32_t *)((int64_t)iVar5 * 0x1c + 0xc + iVar8);
            *piVar4 = iVar18;
            piVar4[1] = (uint32_t)in_R8B;
            piVar4[2] = iVar7;
            piVar4[3] = 0;
            *piVar2 = *piVar2 + 1;
            return;
        }
        if (-1 < (int32_t)uVar16) {
            iVar9 = *(int64_t *)(iVar8 + 0x1560);
            do {
                iVar11 = uVar17 * 0x1c;
                if ((*(int32_t *)(iVar11 + iVar9) == 5) && (*(int32_t *)(iVar11 + 0xc + iVar9) == 0x8000)) {
                    cVar13 = *(char *)(iVar11 + 0x10 + iVar9);
                    goto code_r0x0001800f57b4;
                }
                uVar16 = (int32_t)uVar17 - 1;
                uVar17 = (uint64_t)uVar16;
            } while (-1 < (int32_t)uVar16);
        }
        cVar13 = *(char *)(iVar8 + 0x13b);
code_r0x0001800f57b4:
        if (cVar13 == '\0') goto code_r0x0001800f57d8;
        *pcVar1 = '\x01';
        in_R8B = 1;
        uVar19 = 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800f56c8
// Address: 0x1800f56c8
// Size: 448 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_15h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_49h

void fcn.1800f56b0(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    char *pcVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    int32_t *piVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    uint8_t uVar12;
    char cVar13;
    int32_t iVar14;
    uint32_t uVar15;
    uint8_t in_R8B;
    uint32_t uVar16;
    uint64_t uVar17;
    int32_t iVar18;
    uint64_t uVar19;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_47h;
    int64_t var_28h;
    int64_t var_17h;
    int64_t var_8h;
    
    uVar19 = arg2 & 0xffffffff;
    if (*(char *)(arg1 + 0xbe5) == '\0') {
        return;
    }
    pcVar1 = (char *)(arg1 + 0xb7b);
    iVar8 = *(int64_t *)(arg1 + 0xe0);
    piVar2 = (int32_t *)(iVar8 + 0x1558);
    if ((((*(char *)(arg1 + 0x5d) != '\0') && ((int32_t)arg2 == 0)) && (*pcVar1 != (char)arg2)) &&
       (uVar19 = 1, in_R8B == 0)) {
        *pcVar1 = (char)arg2;
    }
    do {
        iVar5 = *piVar2;
        uVar16 = iVar5 - 1;
        uVar17 = (uint64_t)uVar16;
        iVar18 = (int32_t)uVar19;
        if (-1 < (int32_t)uVar16) {
            iVar9 = *(int64_t *)(iVar8 + 0x1560);
            uVar19 = uVar17;
            do {
                iVar11 = uVar19 * 0x1c;
                if ((*(int32_t *)(iVar11 + iVar9) == 3) && (*(int32_t *)(iVar11 + 0xc + iVar9) == iVar18)) {
                    uVar12 = *(uint8_t *)(iVar11 + 0x10 + iVar9);
                    goto code_r0x0001800f5764;
                }
                uVar15 = (int32_t)uVar19 - 1;
                uVar19 = (uint64_t)uVar15;
            } while (-1 < (int32_t)uVar15);
        }
        uVar12 = *(uint8_t *)((int64_t)iVar18 + 0x120 + iVar8);
code_r0x0001800f5764:
        if (uVar12 == in_R8B) {
            return;
        }
        if (((*(char *)(arg1 + 0x5d) == '\0') || (iVar18 != 0)) || (in_R8B == 0)) {
code_r0x0001800f57d8:
            iVar6 = *(int32_t *)(iVar8 + 0x157c);
            *(int32_t *)(iVar8 + 0x157c) = iVar6 + 1;
            iVar10 = *(int32_t *)(iVar8 + 0x155c);
            iVar7 = *(int32_t *)(iVar8 + 0x1578);
            if (iVar5 == iVar10) {
                if (iVar10 == 0) {
                    iVar10 = 8;
                } else {
                    iVar10 = iVar10 / 2 + iVar10;
                }
                iVar14 = iVar5 + 1;
                if (iVar5 + 1 < iVar10) {
                    iVar14 = iVar10;
                }
                func_0x00018011f9d0(piVar2, iVar14);
            }
            iVar5 = *piVar2;
            iVar8 = *(int64_t *)(iVar8 + 0x1560);
            puVar3 = (undefined4 *)((int64_t)iVar5 * 0x1c + iVar8);
            *puVar3 = 3;
            puVar3[1] = 1;
            puVar3[2] = iVar6;
            puVar3[3] = iVar18;
            piVar4 = (int32_t *)((int64_t)iVar5 * 0x1c + 0xc + iVar8);
            *piVar4 = iVar18;
            piVar4[1] = (uint32_t)in_R8B;
            piVar4[2] = iVar7;
            piVar4[3] = 0;
            *piVar2 = *piVar2 + 1;
            return;
        }
        if (-1 < (int32_t)uVar16) {
            iVar9 = *(int64_t *)(iVar8 + 0x1560);
            do {
                iVar11 = uVar17 * 0x1c;
                if ((*(int32_t *)(iVar11 + iVar9) == 5) && (*(int32_t *)(iVar11 + 0xc + iVar9) == 0x8000)) {
                    cVar13 = *(char *)(iVar11 + 0x10 + iVar9);
                    goto code_r0x0001800f57b4;
                }
                uVar16 = (int32_t)uVar17 - 1;
                uVar17 = (uint64_t)uVar16;
            } while (-1 < (int32_t)uVar16);
        }
        cVar13 = *(char *)(iVar8 + 0x13b);
code_r0x0001800f57b4:
        if (cVar13 == '\0') goto code_r0x0001800f57d8;
        *pcVar1 = '\x01';
        in_R8B = 1;
        uVar19 = 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800f5888
// Address: 0x1800f5888
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_15h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_49h

void fcn.1800f56b0(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    char *pcVar1;
    int32_t *piVar2;
    undefined4 *puVar3;
    int32_t *piVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    uint8_t uVar12;
    char cVar13;
    int32_t iVar14;
    uint32_t uVar15;
    uint8_t in_R8B;
    uint32_t uVar16;
    uint64_t uVar17;
    int32_t iVar18;
    uint64_t uVar19;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_47h;
    int64_t var_28h;
    int64_t var_17h;
    int64_t var_8h;
    
    uVar19 = arg2 & 0xffffffff;
    if (*(char *)(arg1 + 0xbe5) == '\0') {
        return;
    }
    pcVar1 = (char *)(arg1 + 0xb7b);
    iVar8 = *(int64_t *)(arg1 + 0xe0);
    piVar2 = (int32_t *)(iVar8 + 0x1558);
    if ((((*(char *)(arg1 + 0x5d) != '\0') && ((int32_t)arg2 == 0)) && (*pcVar1 != (char)arg2)) &&
       (uVar19 = 1, in_R8B == 0)) {
        *pcVar1 = (char)arg2;
    }
    do {
        iVar5 = *piVar2;
        uVar16 = iVar5 - 1;
        uVar17 = (uint64_t)uVar16;
        iVar18 = (int32_t)uVar19;
        if (-1 < (int32_t)uVar16) {
            iVar9 = *(int64_t *)(iVar8 + 0x1560);
            uVar19 = uVar17;
            do {
                iVar11 = uVar19 * 0x1c;
                if ((*(int32_t *)(iVar11 + iVar9) == 3) && (*(int32_t *)(iVar11 + 0xc + iVar9) == iVar18)) {
                    uVar12 = *(uint8_t *)(iVar11 + 0x10 + iVar9);
                    goto code_r0x0001800f5764;
                }
                uVar15 = (int32_t)uVar19 - 1;
                uVar19 = (uint64_t)uVar15;
            } while (-1 < (int32_t)uVar15);
        }
        uVar12 = *(uint8_t *)((int64_t)iVar18 + 0x120 + iVar8);
code_r0x0001800f5764:
        if (uVar12 == in_R8B) {
            return;
        }
        if (((*(char *)(arg1 + 0x5d) == '\0') || (iVar18 != 0)) || (in_R8B == 0)) {
code_r0x0001800f57d8:
            iVar6 = *(int32_t *)(iVar8 + 0x157c);
            *(int32_t *)(iVar8 + 0x157c) = iVar6 + 1;
            iVar10 = *(int32_t *)(iVar8 + 0x155c);
            iVar7 = *(int32_t *)(iVar8 + 0x1578);
            if (iVar5 == iVar10) {
                if (iVar10 == 0) {
                    iVar10 = 8;
                } else {
                    iVar10 = iVar10 / 2 + iVar10;
                }
                iVar14 = iVar5 + 1;
                if (iVar5 + 1 < iVar10) {
                    iVar14 = iVar10;
                }
                func_0x00018011f9d0(piVar2, iVar14);
            }
            iVar5 = *piVar2;
            iVar8 = *(int64_t *)(iVar8 + 0x1560);
            puVar3 = (undefined4 *)((int64_t)iVar5 * 0x1c + iVar8);
            *puVar3 = 3;
            puVar3[1] = 1;
            puVar3[2] = iVar6;
            puVar3[3] = iVar18;
            piVar4 = (int32_t *)((int64_t)iVar5 * 0x1c + 0xc + iVar8);
            *piVar4 = iVar18;
            piVar4[1] = (uint32_t)in_R8B;
            piVar4[2] = iVar7;
            piVar4[3] = 0;
            *piVar2 = *piVar2 + 1;
            return;
        }
        if (-1 < (int32_t)uVar16) {
            iVar9 = *(int64_t *)(iVar8 + 0x1560);
            do {
                iVar11 = uVar17 * 0x1c;
                if ((*(int32_t *)(iVar11 + iVar9) == 5) && (*(int32_t *)(iVar11 + 0xc + iVar9) == 0x8000)) {
                    cVar13 = *(char *)(iVar11 + 0x10 + iVar9);
                    goto code_r0x0001800f57b4;
                }
                uVar16 = (int32_t)uVar17 - 1;
                uVar17 = (uint64_t)uVar16;
            } while (-1 < (int32_t)uVar16);
        }
        cVar13 = *(char *)(iVar8 + 0x13b);
code_r0x0001800f57b4:
        if (cVar13 == '\0') goto code_r0x0001800f57d8;
        *pcVar1 = '\x01';
        in_R8B = 1;
        uVar19 = 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800f5890
// Address: 0x1800f5890
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.1800f5890(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    float *pfVar3;
    int32_t iVar4;
    float fVar5;
    int64_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    float in_XMM1_Da;
    float in_XMM2_Da;
    int64_t var_28h;
    int64_t var_1ch;
    int64_t var_10h;
    int64_t var_8h;
    
    if ((*(char *)(arg1 + 0xbe5) != '\0') && ((in_XMM1_Da != 0.0 || (in_XMM2_Da != 0.0)))) {
        iVar6 = *(int64_t *)(arg1 + 0xe0);
        iVar4 = *(int32_t *)(iVar6 + 0x157c);
        piVar1 = (int32_t *)(iVar6 + 0x1558);
        *(int32_t *)(iVar6 + 0x157c) = iVar4 + 1;
        fVar5 = *(float *)(iVar6 + 0x1578);
        iVar7 = *(int32_t *)(iVar6 + 0x155c);
        if (*piVar1 == iVar7) {
            iVar8 = *piVar1 + 1;
            if (iVar7 == 0) {
                iVar7 = 8;
            } else {
                iVar7 = iVar7 / 2 + iVar7;
            }
            if (iVar8 < iVar7) {
                iVar8 = iVar7;
            }
            func_0x00018011f9d0(piVar1, iVar8);
        }
        iVar7 = *piVar1;
        iVar6 = *(int64_t *)(iVar6 + 0x1560);
        puVar2 = (undefined4 *)((int64_t)iVar7 * 0x1c + iVar6);
        *puVar2 = 2;
        puVar2[1] = 1;
        puVar2[2] = iVar4;
        puVar2[3] = in_XMM1_Da;
        pfVar3 = (float *)((int64_t)iVar7 * 0x1c + 0xc + iVar6);
        *pfVar3 = in_XMM1_Da;
        pfVar3[1] = in_XMM2_Da;
        pfVar3[2] = fVar5;
        pfVar3[3] = 0.0;
        *piVar1 = *piVar1 + 1;
    }
    return;
}

// ============================================================
// Function: FUN_1800f58bd
// Address: 0x1800f58bd
// Size: 164 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.1800f5890(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    float *pfVar3;
    int32_t iVar4;
    float fVar5;
    int64_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    float in_XMM1_Da;
    float in_XMM2_Da;
    int64_t var_28h;
    int64_t var_1ch;
    int64_t var_10h;
    int64_t var_8h;
    
    if ((*(char *)(arg1 + 0xbe5) != '\0') && ((in_XMM1_Da != 0.0 || (in_XMM2_Da != 0.0)))) {
        iVar6 = *(int64_t *)(arg1 + 0xe0);
        iVar4 = *(int32_t *)(iVar6 + 0x157c);
        piVar1 = (int32_t *)(iVar6 + 0x1558);
        *(int32_t *)(iVar6 + 0x157c) = iVar4 + 1;
        fVar5 = *(float *)(iVar6 + 0x1578);
        iVar7 = *(int32_t *)(iVar6 + 0x155c);
        if (*piVar1 == iVar7) {
            iVar8 = *piVar1 + 1;
            if (iVar7 == 0) {
                iVar7 = 8;
            } else {
                iVar7 = iVar7 / 2 + iVar7;
            }
            if (iVar8 < iVar7) {
                iVar8 = iVar7;
            }
            func_0x00018011f9d0(piVar1, iVar8);
        }
        iVar7 = *piVar1;
        iVar6 = *(int64_t *)(iVar6 + 0x1560);
        puVar2 = (undefined4 *)((int64_t)iVar7 * 0x1c + iVar6);
        *puVar2 = 2;
        puVar2[1] = 1;
        puVar2[2] = iVar4;
        puVar2[3] = in_XMM1_Da;
        pfVar3 = (float *)((int64_t)iVar7 * 0x1c + 0xc + iVar6);
        *pfVar3 = in_XMM1_Da;
        pfVar3[1] = in_XMM2_Da;
        pfVar3[2] = fVar5;
        pfVar3[3] = 0.0;
        *piVar1 = *piVar1 + 1;
    }
    return;
}

// ============================================================
// Function: FUN_1800f5961
// Address: 0x1800f5961
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.1800f5890(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    float *pfVar3;
    int32_t iVar4;
    float fVar5;
    int64_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    float in_XMM1_Da;
    float in_XMM2_Da;
    int64_t var_28h;
    int64_t var_1ch;
    int64_t var_10h;
    int64_t var_8h;
    
    if ((*(char *)(arg1 + 0xbe5) != '\0') && ((in_XMM1_Da != 0.0 || (in_XMM2_Da != 0.0)))) {
        iVar6 = *(int64_t *)(arg1 + 0xe0);
        iVar4 = *(int32_t *)(iVar6 + 0x157c);
        piVar1 = (int32_t *)(iVar6 + 0x1558);
        *(int32_t *)(iVar6 + 0x157c) = iVar4 + 1;
        fVar5 = *(float *)(iVar6 + 0x1578);
        iVar7 = *(int32_t *)(iVar6 + 0x155c);
        if (*piVar1 == iVar7) {
            iVar8 = *piVar1 + 1;
            if (iVar7 == 0) {
                iVar7 = 8;
            } else {
                iVar7 = iVar7 / 2 + iVar7;
            }
            if (iVar8 < iVar7) {
                iVar8 = iVar7;
            }
            func_0x00018011f9d0(piVar1, iVar8);
        }
        iVar7 = *piVar1;
        iVar6 = *(int64_t *)(iVar6 + 0x1560);
        puVar2 = (undefined4 *)((int64_t)iVar7 * 0x1c + iVar6);
        *puVar2 = 2;
        puVar2[1] = 1;
        puVar2[2] = iVar4;
        puVar2[3] = in_XMM1_Da;
        pfVar3 = (float *)((int64_t)iVar7 * 0x1c + 0xc + iVar6);
        *pfVar3 = in_XMM1_Da;
        pfVar3[1] = in_XMM2_Da;
        pfVar3[2] = fVar5;
        pfVar3[3] = 0.0;
        *piVar1 = *piVar1 + 1;
    }
    return;
}

// ============================================================
// Function: FUN_1800f5970
// Address: 0x1800f5970
// Size: 29 bytes
// ============================================================
void fcn.1800f5970(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    int64_t var_18h;
    int64_t var_20h;
    
    fcn.1800f5990();
    return;
}

// ============================================================
// Function: FUN_1800f5990
// Address: 0x1800f5990
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800f5990(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    iVar4 = *(int64_t *)0x180781f28;
    if (*(char *)arg3 == '%') {
        if (*(char *)(arg3 + 1) == 's') {
            if (*(char *)(arg3 + 2) == '\0') {
                iVar4 = 0x1806442d0;
                if (*(int64_t *)arg4 != 0) {
                    iVar4 = *(int64_t *)arg4;
                }
                *(int64_t *)arg1 = iVar4;
                if (arg2 == 0) {
                    return;
                }
                iVar3 = fcn.180498cd0(iVar4);
                *(int64_t *)arg2 = iVar3 + iVar4;
                return;
            }
        } else if ((((*(char *)(arg3 + 1) == '.') && (*(char *)(arg3 + 2) == '*')) && (*(char *)(arg3 + 3) == 's')) &&
                  (*(char *)(arg3 + 4) == '\0')) {
            iVar4 = *(int64_t *)(arg4 + 8);
            iVar1 = *(int32_t *)arg4;
            if (iVar4 != 0) {
                *(int64_t *)arg1 = iVar4;
                *(int64_t *)arg2 = iVar1 + iVar4;
                return;
            }
            *(undefined8 *)arg1 = 0x1806442d0;
            iVar2 = 6;
            if (iVar1 < 6) {
                iVar2 = iVar1;
            }
            *(int64_t *)arg2 = (int64_t)iVar2 + 0x1806442d0;
            return;
        }
    }
    *(undefined8 *)arg1 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2c98);
    if (arg2 != 0) {
        *(undefined8 *)arg2 = *(undefined8 *)(iVar4 + 0x2c98);
    }
    return;
}

// ============================================================
// Function: FUN_1800f5a90
// Address: 0x1800f5a90
// Size: 190 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint32_t fcn.1800f5a90(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t uVar1;
    uint32_t uVar2;
    uint8_t *puVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    int64_t var_8h;
    
    uVar5 = ~(uint32_t)arg3;
    uVar2 = uVar5;
    if (arg2 != 0) {
        do {
            uVar4 = arg2 - 1;
            puVar3 = (uint8_t *)(arg1 + 1);
            if (((*(uint8_t *)arg1 == 0x23) && (1 < uVar4)) && ((*puVar3 == 0x23 && (*(uint8_t *)(arg1 + 2) == 0x23))))
            {
                puVar3 = (uint8_t *)(arg1 + 3);
                uVar4 = arg2 - 3;
                uVar2 = uVar5;
            } else {
                uVar2 = uVar2 >> 8 ^
                        *(uint32_t *)(((uint64_t)(uVar2 & 0xff) ^ (uint64_t)*(uint8_t *)arg1) * 4 + 0x180618620);
            }
            arg1 = (int64_t)puVar3;
            arg2 = uVar4;
        } while (uVar4 != 0);
        return ~uVar2;
    }
    uVar1 = *(uint8_t *)arg1;
    puVar3 = (uint8_t *)(arg1 + 1);
    while (uVar1 != 0) {
        if (((uVar1 == 0x23) && (*puVar3 == 0x23)) && (puVar3[1] == 0x23)) {
            puVar3 = puVar3 + 2;
            uVar2 = uVar5;
        } else {
            uVar2 = uVar2 >> 8 ^ *(uint32_t *)(((uint64_t)(uVar2 & 0xff) ^ (uint64_t)uVar1) * 4 + 0x180618620);
        }
        uVar1 = *puVar3;
        puVar3 = puVar3 + 1;
    }
    return ~uVar2;
}

// ============================================================
// Function: FUN_1800f5b50
// Address: 0x1800f5b50
// Size: 300 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.1800f5b50(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_288 [32];
    int64_t var_268h;
    int64_t var_260h;
    int64_t var_258h;
    int64_t var_38h;
    int64_t var_28h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_288;
    piVar4 = (int64_t *)0x0;
    var_260h._0_4_ = 0;
    var_268h = 0;
    iVar2 = (*(code *)0x699e90)(0xfde9, 0, arg1, 0xffffffff);
    var_260h._0_4_ = 0;
    var_268h = 0;
    iVar3 = (*(code *)0x699e90)(0xfde9, 0, arg2, 0xffffffff);
    if (0x104 < iVar3 + iVar2) {
        piVar4 = (int64_t *)fcn.18046d050((int64_t)(iVar3 + iVar2) * 2);
    }
    piVar5 = &var_258h;
    if (piVar4 != (int64_t *)0x0) {
        piVar5 = piVar4;
    }
    iVar1 = (int64_t)piVar5 + (int64_t)iVar2 * 2;
    var_268h = (int64_t)piVar5;
    var_260h._0_4_ = iVar2;
    (*(code *)0x699e90)(0xfde9, 0, arg1, 0xffffffff);
    var_268h = iVar1;
    var_260h._0_4_ = iVar3;
    (*(code *)0x699e90)(0xfde9, 0, arg2, 0xffffffff);
    func_0x00018046d97c(piVar5, iVar1);
    if (piVar4 != (int64_t *)0x0) {
        fcn.180460d90(piVar4);
    }
    func_0x000180459870(var_38h ^ (uint64_t)auStack_288);
    return;
}

// ============================================================
// Function: FUN_1800f5c80
// Address: 0x1800f5c80
// Size: 396 bytes
// ============================================================
int32_t fcn.1800f5c80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    char cVar2;
    uint32_t uVar3;
    int32_t iVar4;
    uint8_t uVar5;
    uint32_t uVar6;
    uint8_t uVar7;
    uint8_t uVar8;
    uint8_t uVar9;
    uint32_t uVar10;
    int32_t iVar11;
    
    uVar5 = *(uint8_t *)arg2;
    cVar2 = *(char *)((uint64_t)(uVar5 >> 3) + 0x180645400);
    iVar11 = (uint32_t)(cVar2 == '\0') + (int32_t)cVar2;
    if (arg3 == 0) {
        arg3 = iVar11 + arg2;
    }
    if ((uint64_t)arg3 <= (uint64_t)arg2) {
        uVar5 = 0;
    }
    if ((uint8_t *)(arg2 + 1U) < (uint64_t)arg3) {
        uVar7 = *(uint8_t *)(arg2 + 1U);
    } else {
        uVar7 = 0;
    }
    if ((uint8_t *)(arg2 + 2U) < (uint64_t)arg3) {
        uVar9 = *(uint8_t *)(arg2 + 2U);
    } else {
        uVar9 = 0;
    }
    if ((uint8_t *)(arg2 + 3) < (uint64_t)arg3) {
        uVar8 = *(uint8_t *)(arg2 + 3);
    } else {
        uVar8 = 0;
    }
    iVar1 = (int64_t)cVar2 * 4;
    uVar10 = ((((*(uint32_t *)(iVar1 + 0x180645438) & (uint32_t)uVar5) << 6 | uVar7 & 0x3f) << 6 | uVar9 & 0x3f) << 6 |
             uVar8 & 0x3f) >> ((uint8_t)*(undefined4 *)(iVar1 + 0x1806453e8) & 0x1f);
    *(uint32_t *)arg1 = uVar10;
    uVar6 = 0;
    if ((uVar10 & 0xfffff800) == 0xd800) {
        uVar6 = 0x80;
    }
    uVar3 = 0;
    if (0xffff < uVar10) {
        uVar3 = 0x100;
    }
    if ((int32_t)((((uVar9 & 0xc0 | (uint32_t)(uVar8 >> 2)) >> 2 | uVar7 & 0xc0) >> 2 |
                   -(uint32_t)(uVar10 < *(uint32_t *)(iVar1 + 0x1806453d0)) & 0x40 | uVar6 | uVar3) ^ 0x2a) >>
        ((uint8_t)*(undefined4 *)(iVar1 + 0x180645420) & 0x1f) != 0) {
        *(undefined4 *)arg1 = 0xfffd;
        iVar4 = (uint32_t)(uVar5 != 0) + (uint32_t)(uVar8 != 0) + (uint32_t)(uVar9 != 0) + (uint32_t)(uVar7 != 0);
        if (iVar11 < iVar4) {
            iVar4 = iVar11;
        }
        return iVar4;
    }
    return iVar11;
}

// ============================================================
// Function: FUN_1800f5ec0
// Address: 0x1800f5ec0
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1800f5ec0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t *puVar1;
    int32_t iVar2;
    uint64_t uVar3;
    uint64_t arg2_00;
    int64_t var_8h;
    int64_t var_10h;
    
    if (arg1 == arg3) {
        return arg1;
    }
    arg2_00 = arg1;
    uVar3 = arg3;
    if ((uint64_t)arg1 < (uint64_t)arg3) {
        do {
            puVar1 = (uint8_t *)(uVar3 - 1);
            uVar3 = uVar3 - 1;
            arg2_00 = uVar3;
            if ((*puVar1 & 0xc0) != 0x80) break;
            arg2_00 = arg1;
        } while ((uint64_t)arg1 < uVar3);
    }
    iVar2 = fcn.1800f5c80((int64_t)&var_8h, arg2_00, arg2);
    if (((int32_t)var_8h != 0xfffd) && (iVar2 <= (int32_t)arg3 - (int32_t)arg2_00)) {
        arg2_00 = arg3;
    }
    return arg2_00;
}

// ============================================================
// Function: FUN_1800f6060
// Address: 0x1800f6060
// Size: 139 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1800f6060(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint32_t *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar2 = (int64_t)*(int32_t *)arg1;
    puVar3 = *(uint32_t **)(arg1 + 8);
    while (uVar1 = uVar2, uVar1 != 0) {
        uVar2 = uVar1 >> 1;
        if (puVar3[uVar2 * 4] < (uint32_t)arg2) {
            puVar3 = puVar3 + uVar2 * 4 + 4;
            uVar2 = uVar1 + (-1 - uVar2);
        }
    }
    if ((puVar3 != *(uint32_t **)(arg1 + 8) + (int64_t)*(int32_t *)arg1 * 4) && (*puVar3 == (uint32_t)arg2)) {
        return (uint64_t)puVar3[2];
    }
    return arg3 & 0xffffffff;
}

// ============================================================
// Function: FUN_1800f60f0
// Address: 0x1800f60f0
// Size: 113 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800f60f0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint32_t *puVar3;
    int64_t var_8h;
    
    uVar2 = (int64_t)*(int32_t *)arg1;
    puVar3 = *(uint32_t **)(arg1 + 8);
    while (uVar1 = uVar2, uVar1 != 0) {
        uVar2 = uVar1 >> 1;
        if (puVar3[uVar2 * 4] < (uint32_t)arg2) {
            puVar3 = puVar3 + uVar2 * 4 + 4;
            uVar2 = uVar1 + (-1 - uVar2);
        }
    }
    if ((puVar3 != *(uint32_t **)(arg1 + 8) + (int64_t)*(int32_t *)arg1 * 4) && (*puVar3 == (uint32_t)arg2)) {
        return *(undefined8 *)(puVar3 + 2);
    }
    return 0;
}

// ============================================================
// Function: FUN_1800f6170
// Address: 0x1800f6170
// Size: 170 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint32_t * fcn.1800f6170(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint32_t *puVar4;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_10h;
    
    var_18h._0_4_ = (uint32_t)arg2;
    uVar3 = (int64_t)*(int32_t *)arg1;
    puVar4 = *(uint32_t **)(arg1 + 8);
    while (uVar1 = uVar3, uVar1 != 0) {
        uVar3 = uVar1 >> 1;
        if (puVar4[uVar3 * 4] < (uint32_t)var_18h) {
            puVar4 = puVar4 + uVar3 * 4 + 4;
            uVar3 = uVar1 + (-1 - uVar3);
        }
    }
    if ((puVar4 != *(uint32_t **)(arg1 + 8) + (int64_t)*(int32_t *)arg1 * 4) && (*puVar4 == (uint32_t)var_18h)) {
        return puVar4 + 2;
    }
    var_10h._0_4_ = 0xffffffff;
    iVar2 = func_0x00018011f760(arg1, puVar4, &var_18h);
    return (uint32_t *)(iVar2 + 8);
}

// ============================================================
// Function: FUN_1800f6220
// Address: 0x1800f6220
// Size: 170 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800f6220(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint32_t *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStack_10;
    
    var_18h._0_4_ = (uint32_t)arg2;
    uVar2 = (int64_t)*(int32_t *)arg1;
    puVar3 = *(uint32_t **)(arg1 + 8);
    while (uVar1 = uVar2, uVar1 != 0) {
        uVar2 = uVar1 >> 1;
        if (puVar3[uVar2 * 4] < (uint32_t)var_18h) {
            puVar3 = puVar3 + uVar2 * 4 + 4;
            uVar2 = uVar1 + (-1 - uVar2);
        }
    }
    if ((puVar3 != *(uint32_t **)(arg1 + 8) + (int64_t)*(int32_t *)arg1 * 4) && (*puVar3 == (uint32_t)var_18h)) {
        *(int64_t *)(puVar3 + 2) = arg3;
        return;
    }
    iStack_10 = arg3;
    func_0x00018011f760(arg1, puVar3, &var_18h);
    return;
}

// ============================================================
// Function: FUN_1800f62d0
// Address: 0x1800f62d0
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800f62d0(undefined8 placeholder_0, int64_t arg2)
{
    char *pcVar1;
    char *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    char **ppcVar7;
    char *pcVar8;
    char *pcVar9;
    char **ppcVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    char *pcStack_10;
    
    if (*(int32_t *)0x1807829c4 < 0) {
        iVar6 = *(int32_t *)0x1807829c4 + *(int32_t *)0x1807829c4 / 2;
        iVar4 = 0;
        if (0 < iVar6) {
            iVar4 = iVar6;
        }
        func_0x00018011faa0(0x1807829c0, iVar4);
    }
    pcVar8 = (char *)0x1807828c0;
    *(undefined4 *)0x1807829c0 = 0;
    iVar5 = fcn.180498cd0(0x1807828c0);
    if (*(int32_t *)0x1807829c4 < 0) {
        iVar6 = *(int32_t *)0x1807829c4 + *(int32_t *)0x1807829c4 / 2;
        iVar4 = 0;
        if (0 < iVar6) {
            iVar4 = iVar6;
        }
        func_0x00018011faa0(0x1807829c0, iVar4);
    }
    iVar4 = 0;
    *(int32_t *)0x1807829c0 = 0;
    if ((char *)0x1807828c0 < (char *)(iVar5 + 0x1807828c0U)) {
        pcVar9 = (char *)0x1807828c0;
        do {
            if (*pcVar8 == ',') {
                if (iVar4 == *(int32_t *)0x1807829c4) {
                    if (*(int32_t *)0x1807829c4 == 0) {
                        iVar6 = 8;
                    } else {
                        iVar6 = *(int32_t *)0x1807829c4 / 2 + *(int32_t *)0x1807829c4;
                    }
                    iVar3 = iVar4 + 1;
                    if (iVar4 + 1 < iVar6) {
                        iVar3 = iVar6;
                    }
                    func_0x00018011faa0(0x1807829c0, iVar3);
                    iVar4 = *(int32_t *)0x1807829c0;
                }
                ppcVar7 = *(char ***)0x1807829c8;
                (*(char ***)0x1807829c8)[(int64_t)iVar4 * 2] = pcVar9;
                ppcVar7[(int64_t)iVar4 * 2 + 1] = pcVar8;
                iVar4 = *(int32_t *)0x1807829c0 + 1;
                pcVar9 = pcVar8 + 1;
                *(int32_t *)0x1807829c0 = iVar4;
            }
            pcVar8 = pcVar8 + 1;
        } while (pcVar8 < (char *)(iVar5 + 0x1807828c0U));
        if (pcVar9 != pcVar8) {
            var_18h = (int64_t)pcVar9;
            pcStack_10 = pcVar8;
            func_0x00018011f860(0x1807829c0, &var_18h);
            iVar4 = *(int32_t *)0x1807829c0;
        }
    }
    ppcVar10 = *(char ***)0x1807829c8 + (int64_t)iVar4 * 2;
    *(int32_t *)0x1807829d0 = 0;
    ppcVar7 = *(char ***)0x1807829c8;
    do {
        if (ppcVar7 == ppcVar10) {
            return;
        }
        pcVar8 = *ppcVar7;
        pcVar9 = ppcVar7[1];
        if (pcVar8 < pcVar9) {
            do {
                if ((*pcVar8 != ' ') && (*pcVar8 != '\t')) goto code_r0x0001800f647d;
                pcVar8 = pcVar8 + 1;
                *ppcVar7 = pcVar8;
            } while (pcVar8 < pcVar9);
        } else {
code_r0x0001800f647d:
            if (pcVar8 < pcVar9) {
                pcVar2 = *ppcVar7;
                do {
                    pcVar9 = ppcVar7[1];
                    pcVar1 = pcVar9 + -1;
                    if ((pcVar9[-1] != ' ') && (pcVar9[-1] != '\t')) break;
                    ppcVar7[1] = pcVar1;
                    pcVar8 = pcVar2;
                    pcVar9 = pcVar1;
                } while (pcVar2 < pcVar1);
            }
        }
        if ((pcVar8 != pcVar9) && (*pcVar8 != '-')) {
            *(int32_t *)0x1807829d0 = *(int32_t *)0x1807829d0 + 1;
        }
        ppcVar7 = ppcVar7 + 2;
    } while( true );
}

// ============================================================
// Function: FUN_1800f62da
// Address: 0x1800f62da
// Size: 126 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800f62d0(undefined8 placeholder_0, int64_t arg2)
{
    char *pcVar1;
    char *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    char **ppcVar7;
    char *pcVar8;
    char *pcVar9;
    char **ppcVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    char *pcStack_10;
    
    if (*(int32_t *)0x1807829c4 < 0) {
        iVar6 = *(int32_t *)0x1807829c4 + *(int32_t *)0x1807829c4 / 2;
        iVar4 = 0;
        if (0 < iVar6) {
            iVar4 = iVar6;
        }
        func_0x00018011faa0(0x1807829c0, iVar4);
    }
    pcVar8 = (char *)0x1807828c0;
    *(undefined4 *)0x1807829c0 = 0;
    iVar5 = fcn.180498cd0(0x1807828c0);
    if (*(int32_t *)0x1807829c4 < 0) {
        iVar6 = *(int32_t *)0x1807829c4 + *(int32_t *)0x1807829c4 / 2;
        iVar4 = 0;
        if (0 < iVar6) {
            iVar4 = iVar6;
        }
        func_0x00018011faa0(0x1807829c0, iVar4);
    }
    iVar4 = 0;
    *(int32_t *)0x1807829c0 = 0;
    if ((char *)0x1807828c0 < (char *)(iVar5 + 0x1807828c0U)) {
        pcVar9 = (char *)0x1807828c0;
        do {
            if (*pcVar8 == ',') {
                if (iVar4 == *(int32_t *)0x1807829c4) {
                    if (*(int32_t *)0x1807829c4 == 0) {
                        iVar6 = 8;
                    } else {
                        iVar6 = *(int32_t *)0x1807829c4 / 2 + *(int32_t *)0x1807829c4;
                    }
                    iVar3 = iVar4 + 1;
                    if (iVar4 + 1 < iVar6) {
                        iVar3 = iVar6;
                    }
                    func_0x00018011faa0(0x1807829c0, iVar3);
                    iVar4 = *(int32_t *)0x1807829c0;
                }
                ppcVar7 = *(char ***)0x1807829c8;
                (*(char ***)0x1807829c8)[(int64_t)iVar4 * 2] = pcVar9;
                ppcVar7[(int64_t)iVar4 * 2 + 1] = pcVar8;
                iVar4 = *(int32_t *)0x1807829c0 + 1;
                pcVar9 = pcVar8 + 1;
                *(int32_t *)0x1807829c0 = iVar4;
            }
            pcVar8 = pcVar8 + 1;
        } while (pcVar8 < (char *)(iVar5 + 0x1807828c0U));
        if (pcVar9 != pcVar8) {
            var_18h = (int64_t)pcVar9;
            pcStack_10 = pcVar8;
            func_0x00018011f860(0x1807829c0, &var_18h);
            iVar4 = *(int32_t *)0x1807829c0;
        }
    }
    ppcVar10 = *(char ***)0x1807829c8 + (int64_t)iVar4 * 2;
    *(int32_t *)0x1807829d0 = 0;
    ppcVar7 = *(char ***)0x1807829c8;
    do {
        if (ppcVar7 == ppcVar10) {
            return;
        }
        pcVar8 = *ppcVar7;
        pcVar9 = ppcVar7[1];
        if (pcVar8 < pcVar9) {
            do {
                if ((*pcVar8 != ' ') && (*pcVar8 != '\t')) goto code_r0x0001800f647d;
                pcVar8 = pcVar8 + 1;
                *ppcVar7 = pcVar8;
            } while (pcVar8 < pcVar9);
        } else {
code_r0x0001800f647d:
            if (pcVar8 < pcVar9) {
                pcVar2 = *ppcVar7;
                do {
                    pcVar9 = ppcVar7[1];
                    pcVar1 = pcVar9 + -1;
                    if ((pcVar9[-1] != ' ') && (pcVar9[-1] != '\t')) break;
                    ppcVar7[1] = pcVar1;
                    pcVar8 = pcVar2;
                    pcVar9 = pcVar1;
                } while (pcVar2 < pcVar1);
            }
        }
        if ((pcVar8 != pcVar9) && (*pcVar8 != '-')) {
            *(int32_t *)0x1807829d0 = *(int32_t *)0x1807829d0 + 1;
        }
        ppcVar7 = ppcVar7 + 2;
    } while( true );
}

// ============================================================
// Function: FUN_1800f6358
// Address: 0x1800f6358
// Size: 170 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800f62d0(undefined8 placeholder_0, int64_t arg2)
{
    char *pcVar1;
    char *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    char **ppcVar7;
    char *pcVar8;
    char *pcVar9;
    char **ppcVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    char *pcStack_10;
    
    if (*(int32_t *)0x1807829c4 < 0) {
        iVar6 = *(int32_t *)0x1807829c4 + *(int32_t *)0x1807829c4 / 2;
        iVar4 = 0;
        if (0 < iVar6) {
            iVar4 = iVar6;
        }
        func_0x00018011faa0(0x1807829c0, iVar4);
    }
    pcVar8 = (char *)0x1807828c0;
    *(undefined4 *)0x1807829c0 = 0;
    iVar5 = fcn.180498cd0(0x1807828c0);
    if (*(int32_t *)0x1807829c4 < 0) {
        iVar6 = *(int32_t *)0x1807829c4 + *(int32_t *)0x1807829c4 / 2;
        iVar4 = 0;
        if (0 < iVar6) {
            iVar4 = iVar6;
        }
        func_0x00018011faa0(0x1807829c0, iVar4);
    }
    iVar4 = 0;
    *(int32_t *)0x1807829c0 = 0;
    if ((char *)0x1807828c0 < (char *)(iVar5 + 0x1807828c0U)) {
        pcVar9 = (char *)0x1807828c0;
        do {
            if (*pcVar8 == ',') {
                if (iVar4 == *(int32_t *)0x1807829c4) {
                    if (*(int32_t *)0x1807829c4 == 0) {
                        iVar6 = 8;
                    } else {
                        iVar6 = *(int32_t *)0x1807829c4 / 2 + *(int32_t *)0x1807829c4;
                    }
                    iVar3 = iVar4 + 1;
                    if (iVar4 + 1 < iVar6) {
                        iVar3 = iVar6;
                    }
                    func_0x00018011faa0(0x1807829c0, iVar3);
                    iVar4 = *(int32_t *)0x1807829c0;
                }
                ppcVar7 = *(char ***)0x1807829c8;
                (*(char ***)0x1807829c8)[(int64_t)iVar4 * 2] = pcVar9;
                ppcVar7[(int64_t)iVar4 * 2 + 1] = pcVar8;
                iVar4 = *(int32_t *)0x1807829c0 + 1;
                pcVar9 = pcVar8 + 1;
                *(int32_t *)0x1807829c0 = iVar4;
            }
            pcVar8 = pcVar8 + 1;
        } while (pcVar8 < (char *)(iVar5 + 0x1807828c0U));
        if (pcVar9 != pcVar8) {
            var_18h = (int64_t)pcVar9;
            pcStack_10 = pcVar8;
            func_0x00018011f860(0x1807829c0, &var_18h);
            iVar4 = *(int32_t *)0x1807829c0;
        }
    }
    ppcVar10 = *(char ***)0x1807829c8 + (int64_t)iVar4 * 2;
    *(int32_t *)0x1807829d0 = 0;
    ppcVar7 = *(char ***)0x1807829c8;
    do {
        if (ppcVar7 == ppcVar10) {
            return;
        }
        pcVar8 = *ppcVar7;
        pcVar9 = ppcVar7[1];
        if (pcVar8 < pcVar9) {
            do {
                if ((*pcVar8 != ' ') && (*pcVar8 != '\t')) goto code_r0x0001800f647d;
                pcVar8 = pcVar8 + 1;
                *ppcVar7 = pcVar8;
            } while (pcVar8 < pcVar9);
        } else {
code_r0x0001800f647d:
            if (pcVar8 < pcVar9) {
                pcVar2 = *ppcVar7;
                do {
                    pcVar9 = ppcVar7[1];
                    pcVar1 = pcVar9 + -1;
                    if ((pcVar9[-1] != ' ') && (pcVar9[-1] != '\t')) break;
                    ppcVar7[1] = pcVar1;
                    pcVar8 = pcVar2;
                    pcVar9 = pcVar1;
                } while (pcVar2 < pcVar1);
            }
        }
        if ((pcVar8 != pcVar9) && (*pcVar8 != '-')) {
            *(int32_t *)0x1807829d0 = *(int32_t *)0x1807829d0 + 1;
        }
        ppcVar7 = ppcVar7 + 2;
    } while( true );
}

// ============================================================
// Function: FUN_1800f6402
// Address: 0x1800f6402
// Size: 46 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800f62d0(undefined8 placeholder_0, int64_t arg2)
{
    char *pcVar1;
    char *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    char **ppcVar7;
    char *pcVar8;
    char *pcVar9;
    char **ppcVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    char *pcStack_10;
    
    if (*(int32_t *)0x1807829c4 < 0) {
        iVar6 = *(int32_t *)0x1807829c4 + *(int32_t *)0x1807829c4 / 2;
        iVar4 = 0;
        if (0 < iVar6) {
            iVar4 = iVar6;
        }
        func_0x00018011faa0(0x1807829c0, iVar4);
    }
    pcVar8 = (char *)0x1807828c0;
    *(undefined4 *)0x1807829c0 = 0;
    iVar5 = fcn.180498cd0(0x1807828c0);
    if (*(int32_t *)0x1807829c4 < 0) {
        iVar6 = *(int32_t *)0x1807829c4 + *(int32_t *)0x1807829c4 / 2;
        iVar4 = 0;
        if (0 < iVar6) {
            iVar4 = iVar6;
        }
        func_0x00018011faa0(0x1807829c0, iVar4);
    }
    iVar4 = 0;
    *(int32_t *)0x1807829c0 = 0;
    if ((char *)0x1807828c0 < (char *)(iVar5 + 0x1807828c0U)) {
        pcVar9 = (char *)0x1807828c0;
        do {
            if (*pcVar8 == ',') {
                if (iVar4 == *(int32_t *)0x1807829c4) {
                    if (*(int32_t *)0x1807829c4 == 0) {
                        iVar6 = 8;
                    } else {
                        iVar6 = *(int32_t *)0x1807829c4 / 2 + *(int32_t *)0x1807829c4;
                    }
                    iVar3 = iVar4 + 1;
                    if (iVar4 + 1 < iVar6) {
                        iVar3 = iVar6;
                    }
                    func_0x00018011faa0(0x1807829c0, iVar3);
                    iVar4 = *(int32_t *)0x1807829c0;
                }
                ppcVar7 = *(char ***)0x1807829c8;
                (*(char ***)0x1807829c8)[(int64_t)iVar4 * 2] = pcVar9;
                ppcVar7[(int64_t)iVar4 * 2 + 1] = pcVar8;
                iVar4 = *(int32_t *)0x1807829c0 + 1;
                pcVar9 = pcVar8 + 1;
                *(int32_t *)0x1807829c0 = iVar4;
            }
            pcVar8 = pcVar8 + 1;
        } while (pcVar8 < (char *)(iVar5 + 0x1807828c0U));
        if (pcVar9 != pcVar8) {
            var_18h = (int64_t)pcVar9;
            pcStack_10 = pcVar8;
            func_0x00018011f860(0x1807829c0, &var_18h);
            iVar4 = *(int32_t *)0x1807829c0;
        }
    }
    ppcVar10 = *(char ***)0x1807829c8 + (int64_t)iVar4 * 2;
    *(int32_t *)0x1807829d0 = 0;
    ppcVar7 = *(char ***)0x1807829c8;
    do {
        if (ppcVar7 == ppcVar10) {
            return;
        }
        pcVar8 = *ppcVar7;
        pcVar9 = ppcVar7[1];
        if (pcVar8 < pcVar9) {
            do {
                if ((*pcVar8 != ' ') && (*pcVar8 != '\t')) goto code_r0x0001800f647d;
                pcVar8 = pcVar8 + 1;
                *ppcVar7 = pcVar8;
            } while (pcVar8 < pcVar9);
        } else {
code_r0x0001800f647d:
            if (pcVar8 < pcVar9) {
                pcVar2 = *ppcVar7;
                do {
                    pcVar9 = ppcVar7[1];
                    pcVar1 = pcVar9 + -1;
                    if ((pcVar9[-1] != ' ') && (pcVar9[-1] != '\t')) break;
                    ppcVar7[1] = pcVar1;
                    pcVar8 = pcVar2;
                    pcVar9 = pcVar1;
                } while (pcVar2 < pcVar1);
            }
        }
        if ((pcVar8 != pcVar9) && (*pcVar8 != '-')) {
            *(int32_t *)0x1807829d0 = *(int32_t *)0x1807829d0 + 1;
        }
        ppcVar7 = ppcVar7 + 2;
    } while( true );
}

// ============================================================
// Function: FUN_1800f6430
// Address: 0x1800f6430
// Size: 140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800f62d0(undefined8 placeholder_0, int64_t arg2)
{
    char *pcVar1;
    char *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    char **ppcVar7;
    char *pcVar8;
    char *pcVar9;
    char **ppcVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    char *pcStack_10;
    
    if (*(int32_t *)0x1807829c4 < 0) {
        iVar6 = *(int32_t *)0x1807829c4 + *(int32_t *)0x1807829c4 / 2;
        iVar4 = 0;
        if (0 < iVar6) {
            iVar4 = iVar6;
        }
        func_0x00018011faa0(0x1807829c0, iVar4);
    }
    pcVar8 = (char *)0x1807828c0;
    *(undefined4 *)0x1807829c0 = 0;
    iVar5 = fcn.180498cd0(0x1807828c0);
    if (*(int32_t *)0x1807829c4 < 0) {
        iVar6 = *(int32_t *)0x1807829c4 + *(int32_t *)0x1807829c4 / 2;
        iVar4 = 0;
        if (0 < iVar6) {
            iVar4 = iVar6;
        }
        func_0x00018011faa0(0x1807829c0, iVar4);
    }
    iVar4 = 0;
    *(int32_t *)0x1807829c0 = 0;
    if ((char *)0x1807828c0 < (char *)(iVar5 + 0x1807828c0U)) {
        pcVar9 = (char *)0x1807828c0;
        do {
            if (*pcVar8 == ',') {
                if (iVar4 == *(int32_t *)0x1807829c4) {
                    if (*(int32_t *)0x1807829c4 == 0) {
                        iVar6 = 8;
                    } else {
                        iVar6 = *(int32_t *)0x1807829c4 / 2 + *(int32_t *)0x1807829c4;
                    }
                    iVar3 = iVar4 + 1;
                    if (iVar4 + 1 < iVar6) {
                        iVar3 = iVar6;
                    }
                    func_0x00018011faa0(0x1807829c0, iVar3);
                    iVar4 = *(int32_t *)0x1807829c0;
                }
                ppcVar7 = *(char ***)0x1807829c8;
                (*(char ***)0x1807829c8)[(int64_t)iVar4 * 2] = pcVar9;
                ppcVar7[(int64_t)iVar4 * 2 + 1] = pcVar8;
                iVar4 = *(int32_t *)0x1807829c0 + 1;
                pcVar9 = pcVar8 + 1;
                *(int32_t *)0x1807829c0 = iVar4;
            }
            pcVar8 = pcVar8 + 1;
        } while (pcVar8 < (char *)(iVar5 + 0x1807828c0U));
        if (pcVar9 != pcVar8) {
            var_18h = (int64_t)pcVar9;
            pcStack_10 = pcVar8;
            func_0x00018011f860(0x1807829c0, &var_18h);
            iVar4 = *(int32_t *)0x1807829c0;
        }
    }
    ppcVar10 = *(char ***)0x1807829c8 + (int64_t)iVar4 * 2;
    *(int32_t *)0x1807829d0 = 0;
    ppcVar7 = *(char ***)0x1807829c8;
    do {
        if (ppcVar7 == ppcVar10) {
            return;
        }
        pcVar8 = *ppcVar7;
        pcVar9 = ppcVar7[1];
        if (pcVar8 < pcVar9) {
            do {
                if ((*pcVar8 != ' ') && (*pcVar8 != '\t')) goto code_r0x0001800f647d;
                pcVar8 = pcVar8 + 1;
                *ppcVar7 = pcVar8;
            } while (pcVar8 < pcVar9);
        } else {
code_r0x0001800f647d:
            if (pcVar8 < pcVar9) {
                pcVar2 = *ppcVar7;
                do {
                    pcVar9 = ppcVar7[1];
                    pcVar1 = pcVar9 + -1;
                    if ((pcVar9[-1] != ' ') && (pcVar9[-1] != '\t')) break;
                    ppcVar7[1] = pcVar1;
                    pcVar8 = pcVar2;
                    pcVar9 = pcVar1;
                } while (pcVar2 < pcVar1);
            }
        }
        if ((pcVar8 != pcVar9) && (*pcVar8 != '-')) {
            *(int32_t *)0x1807829d0 = *(int32_t *)0x1807829d0 + 1;
        }
        ppcVar7 = ppcVar7 + 2;
    } while( true );
}

// ============================================================
// Function: FUN_1800f64c0
// Address: 0x1800f64c0
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800f64c0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_48h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (arg3 == 0) {
        iVar5 = fcn.180498cd0(arg2);
    } else {
        iVar5 = (int32_t)arg3 - (int32_t)arg2;
    }
    iVar6 = 1;
    if (*(int32_t *)arg1 != 0) {
        iVar6 = *(int32_t *)arg1;
    }
    iVar2 = *(int32_t *)(arg1 + 4);
    iVar1 = iVar6 + iVar5;
    if (iVar2 <= iVar1) {
        iVar4 = iVar2 * 2;
        if (iVar2 * 2 < iVar1) {
            iVar4 = iVar1;
        }
        if (iVar2 < iVar4) {
            uVar3 = fcn.18046d050((int64_t)iVar4);
            if (*(int64_t *)(arg1 + 8) != 0) {
                fcn.180498030(uVar3, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1);
                fcn.180460d90(*(undefined8 *)(arg1 + 8));
            }
            *(undefined8 *)(arg1 + 8) = uVar3;
            *(int32_t *)(arg1 + 4) = iVar4;
        }
    }
    func_0x00018011f640(arg1, iVar1);
    fcn.180498030((int64_t)(iVar6 + -1) + *(int64_t *)(arg1 + 8), arg2, (int64_t)iVar5);
    *(undefined *)((int64_t)iVar1 + -1 + *(int64_t *)(arg1 + 8)) = 0;
    return;
}

// ============================================================
// Function: FUN_1800f6509
// Address: 0x1800f6509
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800f64c0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_48h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (arg3 == 0) {
        iVar5 = fcn.180498cd0(arg2);
    } else {
        iVar5 = (int32_t)arg3 - (int32_t)arg2;
    }
    iVar6 = 1;
    if (*(int32_t *)arg1 != 0) {
        iVar6 = *(int32_t *)arg1;
    }
    iVar2 = *(int32_t *)(arg1 + 4);
    iVar1 = iVar6 + iVar5;
    if (iVar2 <= iVar1) {
        iVar4 = iVar2 * 2;
        if (iVar2 * 2 < iVar1) {
            iVar4 = iVar1;
        }
        if (iVar2 < iVar4) {
            uVar3 = fcn.18046d050((int64_t)iVar4);
            if (*(int64_t *)(arg1 + 8) != 0) {
                fcn.180498030(uVar3, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1);
                fcn.180460d90(*(undefined8 *)(arg1 + 8));
            }
            *(undefined8 *)(arg1 + 8) = uVar3;
            *(int32_t *)(arg1 + 4) = iVar4;
        }
    }
    func_0x00018011f640(arg1, iVar1);
    fcn.180498030((int64_t)(iVar6 + -1) + *(int64_t *)(arg1 + 8), arg2, (int64_t)iVar5);
    *(undefined *)((int64_t)iVar1 + -1 + *(int64_t *)(arg1 + 8)) = 0;
    return;
}

// ============================================================
// Function: FUN_1800f651d
// Address: 0x1800f651d
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800f64c0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_48h)
{
    int32_t iVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (arg3 == 0) {
        iVar5 = fcn.180498cd0(arg2);
    } else {
        iVar5 = (int32_t)arg3 - (int32_t)arg2;
    }
    iVar6 = 1;
    if (*(int32_t *)arg1 != 0) {
        iVar6 = *(int32_t *)arg1;
    }
    iVar2 = *(int32_t *)(arg1 + 4);
    iVar1 = iVar6 + iVar5;
    if (iVar2 <= iVar1) {
        iVar4 = iVar2 * 2;
        if (iVar2 * 2 < iVar1) {
            iVar4 = iVar1;
        }
        if (iVar2 < iVar4) {
            uVar3 = fcn.18046d050((int64_t)iVar4);
            if (*(int64_t *)(arg1 + 8) != 0) {
                fcn.180498030(uVar3, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1);
                fcn.180460d90(*(undefined8 *)(arg1 + 8));
            }
            *(undefined8 *)(arg1 + 8) = uVar3;
            *(int32_t *)(arg1 + 4) = iVar4;
        }
    }
    func_0x00018011f640(arg1, iVar1);
    fcn.180498030((int64_t)(iVar6 + -1) + *(int64_t *)(arg1 + 8), arg2, (int64_t)iVar5);
    *(undefined *)((int64_t)iVar1 + -1 + *(int64_t *)(arg1 + 8)) = 0;
    return;
}

