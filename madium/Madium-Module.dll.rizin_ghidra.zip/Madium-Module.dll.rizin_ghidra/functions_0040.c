// Chunk 40 - 50 functions

// ============================================================
// Function: FUN_18008a510
// Address: 0x18008a510
// Size: 48 bytes
// ============================================================
undefined8 fcn.18008a510(int64_t arg1)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    uVar5 = *(uint64_t *)(arg1 + 0x28);
    uVar2 = uVar5;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar5) {
        uVar2 = *(uint64_t *)0x180782430;
    }
    if ((uVar2 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar2 + 0xc) != -1)) {
        if (*(uint64_t *)(arg1 + 0x40) <= uVar5) {
            uVar5 = *(uint64_t *)0x180782430;
        }
        if (uVar5 == *(uint64_t *)0x180782430) {
            uVar5 = 0;
        }
        if (uVar5 == 0) {
            iVar3 = 0x18063d8c0;
        } else {
            iVar3 = fcn.1800a3b90(arg1);
            iVar3 = iVar3 + 0x18;
            if (iVar3 == 0) {
                fcn.180086510(arg1);
                return 1;
            }
        }
        uVar4 = fcn.180498cd0(iVar3);
        fcn.1800867f0(arg1, iVar3, uVar4);
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 1);
    pcVar1 = (code *)swi(3);
    uVar4 = (*pcVar1)();
    return uVar4;
}

// ============================================================
// Function: FUN_18008a540
// Address: 0x18008a540
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18008a510(int64_t arg1)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    uVar5 = *(uint64_t *)(arg1 + 0x28);
    uVar2 = uVar5;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar5) {
        uVar2 = *(uint64_t *)0x180782430;
    }
    if ((uVar2 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar2 + 0xc) != -1)) {
        if (*(uint64_t *)(arg1 + 0x40) <= uVar5) {
            uVar5 = *(uint64_t *)0x180782430;
        }
        if (uVar5 == *(uint64_t *)0x180782430) {
            uVar5 = 0;
        }
        if (uVar5 == 0) {
            iVar3 = 0x18063d8c0;
        } else {
            iVar3 = fcn.1800a3b90(arg1);
            iVar3 = iVar3 + 0x18;
            if (iVar3 == 0) {
                fcn.180086510(arg1);
                return 1;
            }
        }
        uVar4 = fcn.180498cd0(iVar3);
        fcn.1800867f0(arg1, iVar3, uVar4);
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 1);
    pcVar1 = (code *)swi(3);
    uVar4 = (*pcVar1)();
    return uVar4;
}

// ============================================================
// Function: FUN_18008a580
// Address: 0x18008a580
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18008a510(int64_t arg1)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    uVar5 = *(uint64_t *)(arg1 + 0x28);
    uVar2 = uVar5;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar5) {
        uVar2 = *(uint64_t *)0x180782430;
    }
    if ((uVar2 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar2 + 0xc) != -1)) {
        if (*(uint64_t *)(arg1 + 0x40) <= uVar5) {
            uVar5 = *(uint64_t *)0x180782430;
        }
        if (uVar5 == *(uint64_t *)0x180782430) {
            uVar5 = 0;
        }
        if (uVar5 == 0) {
            iVar3 = 0x18063d8c0;
        } else {
            iVar3 = fcn.1800a3b90(arg1);
            iVar3 = iVar3 + 0x18;
            if (iVar3 == 0) {
                fcn.180086510(arg1);
                return 1;
            }
        }
        uVar4 = fcn.180498cd0(iVar3);
        fcn.1800867f0(arg1, iVar3, uVar4);
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 1);
    pcVar1 = (code *)swi(3);
    uVar4 = (*pcVar1)();
    return uVar4;
}

// ============================================================
// Function: FUN_18008a5ad
// Address: 0x18008a5ad
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18008a510(int64_t arg1)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    uVar5 = *(uint64_t *)(arg1 + 0x28);
    uVar2 = uVar5;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar5) {
        uVar2 = *(uint64_t *)0x180782430;
    }
    if ((uVar2 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar2 + 0xc) != -1)) {
        if (*(uint64_t *)(arg1 + 0x40) <= uVar5) {
            uVar5 = *(uint64_t *)0x180782430;
        }
        if (uVar5 == *(uint64_t *)0x180782430) {
            uVar5 = 0;
        }
        if (uVar5 == 0) {
            iVar3 = 0x18063d8c0;
        } else {
            iVar3 = fcn.1800a3b90(arg1);
            iVar3 = iVar3 + 0x18;
            if (iVar3 == 0) {
                fcn.180086510(arg1);
                return 1;
            }
        }
        uVar4 = fcn.180498cd0(iVar3);
        fcn.1800867f0(arg1, iVar3, uVar4);
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 1);
    pcVar1 = (code *)swi(3);
    uVar4 = (*pcVar1)();
    return uVar4;
}

// ============================================================
// Function: FUN_18008a5d0
// Address: 0x18008a5d0
// Size: 120 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_7h

undefined8 fcn.18008a5d0(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int64_t unaff_RBX;
    
    uVar4 = *(uint64_t *)(arg1 + 0x28);
    if (*(uint64_t *)(arg1 + 0x40) <= *(uint64_t *)(arg1 + 0x28)) {
        uVar4 = *(uint64_t *)0x180782430;
    }
    if ((uVar4 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar4 + 0xc) == 7)) {
        fcn.1800858c0(arg1, 2);
        iVar2 = fcn.180087970(unaff_RBX);
        if (iVar2 != 0) {
            return 2;
        }
        fcn.180086510(arg1);
        return 1;
    }
    fcn.180088470(arg1, 1, 7);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_18008a650
// Address: 0x18008a650
// Size: 224 bytes
// ============================================================
undefined8 fcn.18008a650(int64_t arg1)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    uint64_t uVar9;
    int64_t in_stack_00000010;
    
    uVar9 = *(uint64_t *)(arg1 + 0x28);
    if (*(uint64_t *)(arg1 + 0x40) <= *(uint64_t *)(arg1 + 0x28)) {
        uVar9 = *(uint64_t *)0x180782430;
    }
    if ((uVar9 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar9 + 0xc) == 7)) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
            iVar6 = fcn.180085510(in_stack_00000010);
            if (iVar6 == 0) {
                fcn.180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar2 = (code *)swi(3);
                uVar8 = (*pcVar2)();
                return uVar8;
            }
        }
        puVar7 = (undefined4 *)fcn.180085370(arg1, 0xffffd8ed);
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        uVar3 = puVar7[1];
        uVar4 = puVar7[2];
        uVar5 = puVar7[3];
        *puVar1 = *puVar7;
        puVar1[1] = uVar3;
        puVar1[2] = uVar4;
        puVar1[3] = uVar5;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180085bf0(arg1, 1);
        fcn.180086510(arg1);
        return 3;
    }
    fcn.180088470(arg1, 1, 7);
    pcVar2 = (code *)swi(3);
    uVar8 = (*pcVar2)();
    return uVar8;
}

// ============================================================
// Function: FUN_18008a730
// Address: 0x18008a730
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18008a730(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    uint64_t uVar3;
    int64_t var_8h;
    
    iVar2 = fcn.180088860(arg1, 2);
    uVar3 = *(uint64_t *)(arg1 + 0x28);
    if (*(uint64_t *)(arg1 + 0x40) <= *(uint64_t *)(arg1 + 0x28)) {
        uVar3 = *(uint64_t *)0x180782430;
    }
    if ((uVar3 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar3 + 0xc) == 7)) {
        fcn.1800865e0(arg1, iVar2 + 1);
        fcn.180086ed0(arg1, 1, iVar2 + 1);
        if (*(int64_t *)(arg1 + 0x40) - 0x10U == *(uint64_t *)0x180782430) {
            return 2;
        }
        return (uint64_t)(-(uint32_t)(*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 0) & 2);
    }
    fcn.180088470(arg1, 1, 7);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_18008a762
// Address: 0x18008a762
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18008a730(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    uint64_t uVar3;
    int64_t var_8h;
    
    iVar2 = fcn.180088860(arg1, 2);
    uVar3 = *(uint64_t *)(arg1 + 0x28);
    if (*(uint64_t *)(arg1 + 0x40) <= *(uint64_t *)(arg1 + 0x28)) {
        uVar3 = *(uint64_t *)0x180782430;
    }
    if ((uVar3 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar3 + 0xc) == 7)) {
        fcn.1800865e0(arg1, iVar2 + 1);
        fcn.180086ed0(arg1, 1, iVar2 + 1);
        if (*(int64_t *)(arg1 + 0x40) - 0x10U == *(uint64_t *)0x180782430) {
            return 2;
        }
        return (uint64_t)(-(uint32_t)(*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 0) & 2);
    }
    fcn.180088470(arg1, 1, 7);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_18008a79a
// Address: 0x18008a79a
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18008a730(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    uint64_t uVar3;
    int64_t var_8h;
    
    iVar2 = fcn.180088860(arg1, 2);
    uVar3 = *(uint64_t *)(arg1 + 0x28);
    if (*(uint64_t *)(arg1 + 0x40) <= *(uint64_t *)(arg1 + 0x28)) {
        uVar3 = *(uint64_t *)0x180782430;
    }
    if ((uVar3 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar3 + 0xc) == 7)) {
        fcn.1800865e0(arg1, iVar2 + 1);
        fcn.180086ed0(arg1, 1, iVar2 + 1);
        if (*(int64_t *)(arg1 + 0x40) - 0x10U == *(uint64_t *)0x180782430) {
            return 2;
        }
        return (uint64_t)(-(uint32_t)(*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 0) & 2);
    }
    fcn.180088470(arg1, 1, 7);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_18008a7d0
// Address: 0x18008a7d0
// Size: 226 bytes
// ============================================================
undefined8 fcn.18008a7d0(int64_t arg1)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    undefined8 uVar8;
    uint64_t uVar9;
    int64_t in_stack_00000010;
    
    uVar9 = *(uint64_t *)(arg1 + 0x28);
    if (*(uint64_t *)(arg1 + 0x40) <= *(uint64_t *)(arg1 + 0x28)) {
        uVar9 = *(uint64_t *)0x180782430;
    }
    if ((uVar9 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar9 + 0xc) == 7)) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
            iVar6 = fcn.180085510(in_stack_00000010);
            if (iVar6 == 0) {
                fcn.180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar2 = (code *)swi(3);
                uVar8 = (*pcVar2)();
                return uVar8;
            }
        }
        puVar7 = (undefined4 *)fcn.180085370(arg1, 0xffffd8ed);
        puVar1 = *(undefined4 **)(arg1 + 0x40);
        uVar3 = puVar7[1];
        uVar4 = puVar7[2];
        uVar5 = puVar7[3];
        *puVar1 = *puVar7;
        puVar1[1] = uVar3;
        puVar1[2] = uVar4;
        puVar1[3] = uVar5;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180085bf0(arg1, 1);
        fcn.1800865e0(arg1, 0);
        return 3;
    }
    fcn.180088470(arg1, 1, 7);
    pcVar2 = (code *)swi(3);
    uVar8 = (*pcVar2)();
    return uVar8;
}

// ============================================================
// Function: FUN_18008a8c0
// Address: 0x18008a8c0
// Size: 152 bytes
// ============================================================
int64_t fcn.18008a8c0(int64_t arg1)
{
    int32_t *piVar1;
    int32_t *piVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t *piVar6;
    
    piVar1 = *(int32_t **)(arg1 + 0x28);
    piVar2 = *(int32_t **)(arg1 + 0x40);
    piVar6 = piVar1;
    if (piVar2 <= piVar1) {
        piVar6 = *(int32_t **)0x180782430;
    }
    if ((piVar6 == *(int32_t **)0x180782430) || (piVar6[3] == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1);
        pcVar3 = (code *)swi(3);
        iVar5 = (*pcVar3)();
        return iVar5;
    }
    piVar6 = piVar1;
    if (piVar2 <= piVar1) {
        piVar6 = *(int32_t **)0x180782430;
    }
    if ((piVar6[3] != 0) && ((piVar6[3] != 1 || (*piVar6 != 0)))) {
        return (int64_t)piVar2 - (int64_t)piVar1 >> 4;
    }
    uVar4 = func_0x000180088720(arg1, 2, 0x18063db40, 0);
    fcn.180088560(arg1, 0x18063cc8c, uVar4);
    pcVar3 = (code *)swi(3);
    iVar5 = (*pcVar3)();
    return iVar5;
}

// ============================================================
// Function: FUN_18008a960
// Address: 0x18008a960
// Size: 272 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18008a960(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    char *pcVar5;
    uint64_t uVar6;
    int64_t *piVar7;
    int32_t iVar8;
    int64_t var_8h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar4 = piVar7;
    if (piVar1 <= piVar7) {
        piVar4 = *(int64_t **)0x180782430;
    }
    iVar8 = (int32_t)((int64_t)piVar1 - (int64_t)piVar7 >> 4);
    if ((piVar4 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar4 + 0xc) != 6)) goto code_r0x00018008aa2d;
    if (piVar1 <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) == 6) {
code_r0x00018008aa06:
        pcVar5 = (char *)(*piVar7 + 0x18);
    } else {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar3 = func_0x0001800a8360(arg1);
        if (iVar3 != 0) {
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar7 = *(int64_t **)(arg1 + 0x28);
            if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
                piVar7 = *(int64_t **)0x180782430;
            }
            goto code_r0x00018008aa06;
        }
        pcVar5 = (char *)0x0;
    }
    if (*pcVar5 == '#') {
        fcn.1800865e0(arg1, iVar8 + -1);
        return 1;
    }
code_r0x00018008aa2d:
    iVar3 = fcn.180088860(arg1, 1);
    if (iVar3 < 0) {
        iVar3 = iVar3 + iVar8;
    } else if (iVar8 < iVar3) {
        iVar3 = iVar8;
    }
    if (0 < iVar3) {
        return (uint64_t)(uint32_t)(iVar8 - iVar3);
    }
    func_0x000180088380(arg1, 1, 0x1806225f0);
    pcVar2 = (code *)swi(3);
    uVar6 = (*pcVar2)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008aa90
// Address: 0x18008aa90
// Size: 102 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000180089031)
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18008aa90(int64_t arg1)
{
    uint32_t *puVar1;
    char cVar2;
    undefined4 *puVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    undefined4 *puVar11;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    puVar3 = *(undefined4 **)(arg1 + 0x28);
    puVar11 = *(undefined4 **)(arg1 + 0x40);
    puVar10 = puVar3;
    if (puVar11 <= puVar3) {
        puVar10 = *(undefined4 **)0x180782430;
    }
    if ((puVar10 == *(undefined4 **)0x180782430) || (puVar10[3] == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1);
        pcVar4 = (code *)swi(3);
        iVar9 = (*pcVar4)();
        return iVar9;
    }
    if (*(char *)0x180777030 != '\0') {
        iVar9 = **(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8);
        *(undefined4 *)(*(int64_t *)(arg1 + 0x18) + 0x18) = 0;
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 | 2;
        var_18h = *(int64_t *)(arg1 + 0x40) + (int64_t)(int32_t)((int64_t)puVar11 - (int64_t)puVar3 >> 4) * -0x10;
        var_10h._0_4_ = 0xffffffff;
        iVar8 = func_0x000180094080(arg1, 0x1800890c0, &var_18h, var_18h - *(int64_t *)(arg1 + 0x38), 0);
        if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
            **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
        }
        if ((iVar8 == 0) && (((cVar2 = *(char *)(arg1 + 3), cVar2 == '\x01' || (cVar2 == '\x06')) || (cVar2 == '\x7f')))
           ) {
            return 0xffffffff;
        }
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 & 0xfffffffd;
        iVar9 = (*(code *)(*(int64_t *)(iVar9 + 0x28) + 0x28 + iVar9))(arg1);
        return iVar9;
    }
    var_18h = 0;
    puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
    *puVar1 = *puVar1 | 2;
    iVar8 = func_0x000180094080(arg1, 0x18008aa70, puVar3, (int64_t)puVar3 - *(int64_t *)(arg1 + 0x38));
    if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
        **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
    }
    if ((iVar8 == 0) && (((cVar2 = *(char *)(arg1 + 3), cVar2 == '\x01' || (cVar2 == '\x06')) || (cVar2 == '\x7f')))) {
        return 0xffffffff;
    }
    fcn.180085610(arg1, 1);
    func_0x000180086b20(arg1, iVar8 == 0);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar3 = *(undefined4 **)(arg1 + 0x40);
    puVar11 = *(undefined4 **)(arg1 + 0x28);
    if (puVar3 <= *(undefined4 **)(arg1 + 0x28)) {
        puVar11 = *(undefined4 **)0x180782430;
    }
    for (; puVar11 < puVar3; puVar3 = puVar3 + -4) {
        *puVar3 = puVar3[-4];
        puVar3[1] = puVar3[-3];
        puVar3[2] = puVar3[-2];
        puVar3[3] = puVar3[-1];
    }
    puVar3 = *(undefined4 **)(arg1 + 0x40);
    uVar5 = puVar3[1];
    uVar6 = puVar3[2];
    uVar7 = puVar3[3];
    *puVar11 = *puVar3;
    puVar11[1] = uVar5;
    puVar11[2] = uVar6;
    puVar11[3] = uVar7;
    return *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
}

// ============================================================
// Function: FUN_18008aaf6
// Address: 0x18008aaf6
// Size: 84 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000180089031)
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18008aa90(int64_t arg1)
{
    uint32_t *puVar1;
    char cVar2;
    undefined4 *puVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    undefined4 *puVar11;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    puVar3 = *(undefined4 **)(arg1 + 0x28);
    puVar11 = *(undefined4 **)(arg1 + 0x40);
    puVar10 = puVar3;
    if (puVar11 <= puVar3) {
        puVar10 = *(undefined4 **)0x180782430;
    }
    if ((puVar10 == *(undefined4 **)0x180782430) || (puVar10[3] == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1);
        pcVar4 = (code *)swi(3);
        iVar9 = (*pcVar4)();
        return iVar9;
    }
    if (*(char *)0x180777030 != '\0') {
        iVar9 = **(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8);
        *(undefined4 *)(*(int64_t *)(arg1 + 0x18) + 0x18) = 0;
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 | 2;
        var_18h = *(int64_t *)(arg1 + 0x40) + (int64_t)(int32_t)((int64_t)puVar11 - (int64_t)puVar3 >> 4) * -0x10;
        var_10h._0_4_ = 0xffffffff;
        iVar8 = func_0x000180094080(arg1, 0x1800890c0, &var_18h, var_18h - *(int64_t *)(arg1 + 0x38), 0);
        if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
            **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
        }
        if ((iVar8 == 0) && (((cVar2 = *(char *)(arg1 + 3), cVar2 == '\x01' || (cVar2 == '\x06')) || (cVar2 == '\x7f')))
           ) {
            return 0xffffffff;
        }
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 & 0xfffffffd;
        iVar9 = (*(code *)(*(int64_t *)(iVar9 + 0x28) + 0x28 + iVar9))(arg1);
        return iVar9;
    }
    var_18h = 0;
    puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
    *puVar1 = *puVar1 | 2;
    iVar8 = func_0x000180094080(arg1, 0x18008aa70, puVar3, (int64_t)puVar3 - *(int64_t *)(arg1 + 0x38));
    if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
        **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
    }
    if ((iVar8 == 0) && (((cVar2 = *(char *)(arg1 + 3), cVar2 == '\x01' || (cVar2 == '\x06')) || (cVar2 == '\x7f')))) {
        return 0xffffffff;
    }
    fcn.180085610(arg1, 1);
    func_0x000180086b20(arg1, iVar8 == 0);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar3 = *(undefined4 **)(arg1 + 0x40);
    puVar11 = *(undefined4 **)(arg1 + 0x28);
    if (puVar3 <= *(undefined4 **)(arg1 + 0x28)) {
        puVar11 = *(undefined4 **)0x180782430;
    }
    for (; puVar11 < puVar3; puVar3 = puVar3 + -4) {
        *puVar3 = puVar3[-4];
        puVar3[1] = puVar3[-3];
        puVar3[2] = puVar3[-2];
        puVar3[3] = puVar3[-1];
    }
    puVar3 = *(undefined4 **)(arg1 + 0x40);
    uVar5 = puVar3[1];
    uVar6 = puVar3[2];
    uVar7 = puVar3[3];
    *puVar11 = *puVar3;
    puVar11[1] = uVar5;
    puVar11[2] = uVar6;
    puVar11[3] = uVar7;
    return *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
}

// ============================================================
// Function: FUN_18008ab4a
// Address: 0x18008ab4a
// Size: 138 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000180089031)
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18008aa90(int64_t arg1)
{
    uint32_t *puVar1;
    char cVar2;
    undefined4 *puVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    undefined4 *puVar11;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    puVar3 = *(undefined4 **)(arg1 + 0x28);
    puVar11 = *(undefined4 **)(arg1 + 0x40);
    puVar10 = puVar3;
    if (puVar11 <= puVar3) {
        puVar10 = *(undefined4 **)0x180782430;
    }
    if ((puVar10 == *(undefined4 **)0x180782430) || (puVar10[3] == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1);
        pcVar4 = (code *)swi(3);
        iVar9 = (*pcVar4)();
        return iVar9;
    }
    if (*(char *)0x180777030 != '\0') {
        iVar9 = **(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8);
        *(undefined4 *)(*(int64_t *)(arg1 + 0x18) + 0x18) = 0;
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 | 2;
        var_18h = *(int64_t *)(arg1 + 0x40) + (int64_t)(int32_t)((int64_t)puVar11 - (int64_t)puVar3 >> 4) * -0x10;
        var_10h._0_4_ = 0xffffffff;
        iVar8 = func_0x000180094080(arg1, 0x1800890c0, &var_18h, var_18h - *(int64_t *)(arg1 + 0x38), 0);
        if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
            **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
        }
        if ((iVar8 == 0) && (((cVar2 = *(char *)(arg1 + 3), cVar2 == '\x01' || (cVar2 == '\x06')) || (cVar2 == '\x7f')))
           ) {
            return 0xffffffff;
        }
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 & 0xfffffffd;
        iVar9 = (*(code *)(*(int64_t *)(iVar9 + 0x28) + 0x28 + iVar9))(arg1);
        return iVar9;
    }
    var_18h = 0;
    puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
    *puVar1 = *puVar1 | 2;
    iVar8 = func_0x000180094080(arg1, 0x18008aa70, puVar3, (int64_t)puVar3 - *(int64_t *)(arg1 + 0x38));
    if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
        **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
    }
    if ((iVar8 == 0) && (((cVar2 = *(char *)(arg1 + 3), cVar2 == '\x01' || (cVar2 == '\x06')) || (cVar2 == '\x7f')))) {
        return 0xffffffff;
    }
    fcn.180085610(arg1, 1);
    func_0x000180086b20(arg1, iVar8 == 0);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar3 = *(undefined4 **)(arg1 + 0x40);
    puVar11 = *(undefined4 **)(arg1 + 0x28);
    if (puVar3 <= *(undefined4 **)(arg1 + 0x28)) {
        puVar11 = *(undefined4 **)0x180782430;
    }
    for (; puVar11 < puVar3; puVar3 = puVar3 + -4) {
        *puVar3 = puVar3[-4];
        puVar3[1] = puVar3[-3];
        puVar3[2] = puVar3[-2];
        puVar3[3] = puVar3[-1];
    }
    puVar3 = *(undefined4 **)(arg1 + 0x40);
    uVar5 = puVar3[1];
    uVar6 = puVar3[2];
    uVar7 = puVar3[3];
    *puVar11 = *puVar3;
    puVar11[1] = uVar5;
    puVar11[2] = uVar6;
    puVar11[3] = uVar7;
    return *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
}

// ============================================================
// Function: FUN_18008abd4
// Address: 0x18008abd4
// Size: 22 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000180089031)
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18008aa90(int64_t arg1)
{
    uint32_t *puVar1;
    char cVar2;
    undefined4 *puVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    undefined4 *puVar11;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    puVar3 = *(undefined4 **)(arg1 + 0x28);
    puVar11 = *(undefined4 **)(arg1 + 0x40);
    puVar10 = puVar3;
    if (puVar11 <= puVar3) {
        puVar10 = *(undefined4 **)0x180782430;
    }
    if ((puVar10 == *(undefined4 **)0x180782430) || (puVar10[3] == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1);
        pcVar4 = (code *)swi(3);
        iVar9 = (*pcVar4)();
        return iVar9;
    }
    if (*(char *)0x180777030 != '\0') {
        iVar9 = **(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8);
        *(undefined4 *)(*(int64_t *)(arg1 + 0x18) + 0x18) = 0;
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 | 2;
        var_18h = *(int64_t *)(arg1 + 0x40) + (int64_t)(int32_t)((int64_t)puVar11 - (int64_t)puVar3 >> 4) * -0x10;
        var_10h._0_4_ = 0xffffffff;
        iVar8 = func_0x000180094080(arg1, 0x1800890c0, &var_18h, var_18h - *(int64_t *)(arg1 + 0x38), 0);
        if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
            **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
        }
        if ((iVar8 == 0) && (((cVar2 = *(char *)(arg1 + 3), cVar2 == '\x01' || (cVar2 == '\x06')) || (cVar2 == '\x7f')))
           ) {
            return 0xffffffff;
        }
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 & 0xfffffffd;
        iVar9 = (*(code *)(*(int64_t *)(iVar9 + 0x28) + 0x28 + iVar9))(arg1);
        return iVar9;
    }
    var_18h = 0;
    puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
    *puVar1 = *puVar1 | 2;
    iVar8 = func_0x000180094080(arg1, 0x18008aa70, puVar3, (int64_t)puVar3 - *(int64_t *)(arg1 + 0x38));
    if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
        **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
    }
    if ((iVar8 == 0) && (((cVar2 = *(char *)(arg1 + 3), cVar2 == '\x01' || (cVar2 == '\x06')) || (cVar2 == '\x7f')))) {
        return 0xffffffff;
    }
    fcn.180085610(arg1, 1);
    func_0x000180086b20(arg1, iVar8 == 0);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar3 = *(undefined4 **)(arg1 + 0x40);
    puVar11 = *(undefined4 **)(arg1 + 0x28);
    if (puVar3 <= *(undefined4 **)(arg1 + 0x28)) {
        puVar11 = *(undefined4 **)0x180782430;
    }
    for (; puVar11 < puVar3; puVar3 = puVar3 + -4) {
        *puVar3 = puVar3[-4];
        puVar3[1] = puVar3[-3];
        puVar3[2] = puVar3[-2];
        puVar3[3] = puVar3[-1];
    }
    puVar3 = *(undefined4 **)(arg1 + 0x40);
    uVar5 = puVar3[1];
    uVar6 = puVar3[2];
    uVar7 = puVar3[3];
    *puVar11 = *puVar3;
    puVar11[1] = uVar5;
    puVar11[2] = uVar6;
    puVar11[3] = uVar7;
    return *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
}

// ============================================================
// Function: FUN_18008abf0
// Address: 0x18008abf0
// Size: 384 bytes
// ============================================================
int64_t fcn.18008abf0(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int64_t in_stack_00000010;
    
    if ((int32_t)arg2 == 0) {
        fcn.180085610(arg1, 1);
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar6 = fcn.180085510(in_stack_00000010), iVar6 != 0)) {
            puVar1 = *(undefined4 **)(arg1 + 0x40);
            *puVar1 = 1;
            puVar1[3] = 1;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            puVar1 = *(undefined4 **)(arg1 + 0x40);
            puVar8 = *(undefined4 **)(arg1 + 0x28);
            if (puVar1 <= *(undefined4 **)(arg1 + 0x28)) {
                puVar8 = *(undefined4 **)0x180782430;
            }
            for (; puVar8 < puVar1; puVar1 = puVar1 + -4) {
                *puVar1 = puVar1[-4];
                puVar1[1] = puVar1[-3];
                puVar1[2] = puVar1[-2];
                puVar1[3] = puVar1[-1];
            }
            puVar1 = *(undefined4 **)(arg1 + 0x40);
            uVar3 = puVar1[1];
            uVar4 = puVar1[2];
            uVar5 = puVar1[3];
            *puVar8 = *puVar1;
            puVar8[1] = uVar3;
            puVar8[2] = uVar4;
            puVar8[3] = uVar5;
            return *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
        }
    } else {
        fcn.180085610(arg1, 1);
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar6 = fcn.180085510(in_stack_00000010), iVar6 != 0)) {
            puVar1 = *(undefined4 **)(arg1 + 0x40);
            *puVar1 = 0;
            puVar1[3] = 1;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            puVar8 = *(undefined4 **)(arg1 + 0x40);
            for (puVar1 = puVar8; puVar8 + -8 < puVar1; puVar1 = puVar1 + -4) {
                *puVar1 = puVar1[-4];
                puVar1[1] = puVar1[-3];
                puVar1[2] = puVar1[-2];
                puVar1[3] = puVar1[-1];
            }
            puVar1 = *(undefined4 **)(arg1 + 0x40);
            uVar3 = puVar1[1];
            uVar4 = puVar1[2];
            uVar5 = puVar1[3];
            puVar8[-8] = *puVar1;
            puVar8[-7] = uVar3;
            puVar8[-6] = uVar4;
            puVar8[-5] = uVar5;
            return 2;
        }
    }
    fcn.180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar2 = (code *)swi(3);
    iVar7 = (*pcVar2)();
    return iVar7;
}

// ============================================================
// Function: FUN_18008ad70
// Address: 0x18008ad70
// Size: 255 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000180089045)
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18008ad70(int64_t arg1)
{
    uint32_t *puVar1;
    char cVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    undefined4 *puVar12;
    undefined4 *puVar13;
    int64_t var_8h;
    int64_t var_18h;
    undefined4 uStack_10;
    
    puVar11 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(undefined4 **)(arg1 + 0x40) <= puVar11) {
        puVar11 = *(undefined4 **)0x180782430;
    }
    if ((puVar11 == *(undefined4 **)0x180782430) || (puVar11[3] != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar5 = (code *)swi(3);
        iVar10 = (*pcVar5)();
        return iVar10;
    }
    func_0x000180085bf0(arg1, 1);
    func_0x000180085bf0(arg1, 2);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar13 = *(undefined4 **)0x180782430;
    puVar11 = *(undefined4 **)(arg1 + 0x40);
    uVar6 = puVar11[-3];
    uVar7 = puVar11[-2];
    uVar8 = puVar11[-1];
    puVar12 = *(undefined4 **)(arg1 + 0x28);
    if (puVar11 <= *(undefined4 **)(arg1 + 0x28)) {
        puVar12 = *(undefined4 **)0x180782430;
    }
    *puVar12 = puVar11[-4];
    puVar12[1] = uVar6;
    puVar12[2] = uVar7;
    puVar12[3] = uVar8;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar11 = *(undefined4 **)(arg1 + 0x40);
    puVar12 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    uVar6 = puVar11[-3];
    uVar7 = puVar11[-2];
    uVar8 = puVar11[-1];
    if (puVar11 <= puVar12) {
        puVar12 = puVar13;
    }
    *puVar12 = puVar11[-4];
    puVar12[1] = uVar6;
    puVar12[2] = uVar7;
    puVar12[3] = uVar8;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    iVar10 = *(int64_t *)(arg1 + 0x40);
    if (*(char *)0x180777030 == '\0') {
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 | 2;
        iVar10 = *(int64_t *)(arg1 + 0x28) + 0x10;
        var_18h = *(int64_t *)(arg1 + 0x28) - *(int64_t *)(arg1 + 0x38);
        iVar9 = func_0x000180094080(arg1, 0x18008aa70, iVar10, iVar10 - *(int64_t *)(arg1 + 0x38));
        if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
            **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
        }
        if ((iVar9 == 0) && (((cVar2 = *(char *)(arg1 + 3), cVar2 == '\x01' || (cVar2 == '\x06')) || (cVar2 == '\x7f')))
           ) {
            return 0xffffffff;
        }
        fcn.180085610(arg1, 1);
        func_0x000180086b20(arg1, iVar9 == 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        puVar11 = *(undefined4 **)(arg1 + 0x40);
        uVar6 = puVar11[-3];
        uVar7 = puVar11[-2];
        uVar8 = puVar11[-1];
        puVar13 = *(undefined4 **)(arg1 + 0x28);
        if (puVar11 <= *(undefined4 **)(arg1 + 0x28)) {
            puVar13 = *(undefined4 **)0x180782430;
        }
        *puVar13 = puVar11[-4];
        puVar13[1] = uVar6;
        puVar13[2] = uVar7;
        puVar13[3] = uVar8;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        return *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    }
    iVar4 = *(int64_t *)(arg1 + 0x28);
    iVar3 = **(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8);
    *(undefined4 *)(*(int64_t *)(arg1 + 0x18) + 0x18) = 1;
    puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
    *puVar1 = *puVar1 | 2;
    var_18h = *(int64_t *)(arg1 + 0x40) + (int64_t)((int32_t)(iVar10 - iVar4 >> 4) + -1) * -0x10;
    uStack_10 = 0xffffffff;
    iVar9 = func_0x000180094080(arg1, 0x1800890c0, &var_18h, var_18h - *(int64_t *)(arg1 + 0x38), 
                                *(int64_t *)(arg1 + 0x28) - *(int64_t *)(arg1 + 0x38));
    if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
        **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
    }
    if ((iVar9 == 0) && (((cVar2 = *(char *)(arg1 + 3), cVar2 == '\x01' || (cVar2 == '\x06')) || (cVar2 == '\x7f')))) {
        return 0xffffffff;
    }
    puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
    *puVar1 = *puVar1 & 0xfffffffd;
    iVar10 = (*(code *)(*(int64_t *)(iVar3 + 0x28) + 0x28 + iVar3))(arg1);
    return iVar10;
}

// ============================================================
// Function: FUN_18008ae6f
// Address: 0x18008ae6f
// Size: 98 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000180089045)
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18008ad70(int64_t arg1)
{
    uint32_t *puVar1;
    char cVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    undefined4 *puVar12;
    undefined4 *puVar13;
    int64_t var_8h;
    int64_t var_18h;
    undefined4 uStack_10;
    
    puVar11 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(undefined4 **)(arg1 + 0x40) <= puVar11) {
        puVar11 = *(undefined4 **)0x180782430;
    }
    if ((puVar11 == *(undefined4 **)0x180782430) || (puVar11[3] != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar5 = (code *)swi(3);
        iVar10 = (*pcVar5)();
        return iVar10;
    }
    func_0x000180085bf0(arg1, 1);
    func_0x000180085bf0(arg1, 2);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar13 = *(undefined4 **)0x180782430;
    puVar11 = *(undefined4 **)(arg1 + 0x40);
    uVar6 = puVar11[-3];
    uVar7 = puVar11[-2];
    uVar8 = puVar11[-1];
    puVar12 = *(undefined4 **)(arg1 + 0x28);
    if (puVar11 <= *(undefined4 **)(arg1 + 0x28)) {
        puVar12 = *(undefined4 **)0x180782430;
    }
    *puVar12 = puVar11[-4];
    puVar12[1] = uVar6;
    puVar12[2] = uVar7;
    puVar12[3] = uVar8;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar11 = *(undefined4 **)(arg1 + 0x40);
    puVar12 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    uVar6 = puVar11[-3];
    uVar7 = puVar11[-2];
    uVar8 = puVar11[-1];
    if (puVar11 <= puVar12) {
        puVar12 = puVar13;
    }
    *puVar12 = puVar11[-4];
    puVar12[1] = uVar6;
    puVar12[2] = uVar7;
    puVar12[3] = uVar8;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    iVar10 = *(int64_t *)(arg1 + 0x40);
    if (*(char *)0x180777030 == '\0') {
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 | 2;
        iVar10 = *(int64_t *)(arg1 + 0x28) + 0x10;
        var_18h = *(int64_t *)(arg1 + 0x28) - *(int64_t *)(arg1 + 0x38);
        iVar9 = func_0x000180094080(arg1, 0x18008aa70, iVar10, iVar10 - *(int64_t *)(arg1 + 0x38));
        if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
            **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
        }
        if ((iVar9 == 0) && (((cVar2 = *(char *)(arg1 + 3), cVar2 == '\x01' || (cVar2 == '\x06')) || (cVar2 == '\x7f')))
           ) {
            return 0xffffffff;
        }
        fcn.180085610(arg1, 1);
        func_0x000180086b20(arg1, iVar9 == 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        puVar11 = *(undefined4 **)(arg1 + 0x40);
        uVar6 = puVar11[-3];
        uVar7 = puVar11[-2];
        uVar8 = puVar11[-1];
        puVar13 = *(undefined4 **)(arg1 + 0x28);
        if (puVar11 <= *(undefined4 **)(arg1 + 0x28)) {
            puVar13 = *(undefined4 **)0x180782430;
        }
        *puVar13 = puVar11[-4];
        puVar13[1] = uVar6;
        puVar13[2] = uVar7;
        puVar13[3] = uVar8;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        return *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    }
    iVar4 = *(int64_t *)(arg1 + 0x28);
    iVar3 = **(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8);
    *(undefined4 *)(*(int64_t *)(arg1 + 0x18) + 0x18) = 1;
    puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
    *puVar1 = *puVar1 | 2;
    var_18h = *(int64_t *)(arg1 + 0x40) + (int64_t)((int32_t)(iVar10 - iVar4 >> 4) + -1) * -0x10;
    uStack_10 = 0xffffffff;
    iVar9 = func_0x000180094080(arg1, 0x1800890c0, &var_18h, var_18h - *(int64_t *)(arg1 + 0x38), 
                                *(int64_t *)(arg1 + 0x28) - *(int64_t *)(arg1 + 0x38));
    if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
        **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
    }
    if ((iVar9 == 0) && (((cVar2 = *(char *)(arg1 + 3), cVar2 == '\x01' || (cVar2 == '\x06')) || (cVar2 == '\x7f')))) {
        return 0xffffffff;
    }
    puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
    *puVar1 = *puVar1 & 0xfffffffd;
    iVar10 = (*(code *)(*(int64_t *)(iVar3 + 0x28) + 0x28 + iVar3))(arg1);
    return iVar10;
}

// ============================================================
// Function: FUN_18008aed1
// Address: 0x18008aed1
// Size: 111 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000180089045)
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18008ad70(int64_t arg1)
{
    uint32_t *puVar1;
    char cVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    undefined4 *puVar12;
    undefined4 *puVar13;
    int64_t var_8h;
    int64_t var_18h;
    undefined4 uStack_10;
    
    puVar11 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(undefined4 **)(arg1 + 0x40) <= puVar11) {
        puVar11 = *(undefined4 **)0x180782430;
    }
    if ((puVar11 == *(undefined4 **)0x180782430) || (puVar11[3] != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar5 = (code *)swi(3);
        iVar10 = (*pcVar5)();
        return iVar10;
    }
    func_0x000180085bf0(arg1, 1);
    func_0x000180085bf0(arg1, 2);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar13 = *(undefined4 **)0x180782430;
    puVar11 = *(undefined4 **)(arg1 + 0x40);
    uVar6 = puVar11[-3];
    uVar7 = puVar11[-2];
    uVar8 = puVar11[-1];
    puVar12 = *(undefined4 **)(arg1 + 0x28);
    if (puVar11 <= *(undefined4 **)(arg1 + 0x28)) {
        puVar12 = *(undefined4 **)0x180782430;
    }
    *puVar12 = puVar11[-4];
    puVar12[1] = uVar6;
    puVar12[2] = uVar7;
    puVar12[3] = uVar8;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar11 = *(undefined4 **)(arg1 + 0x40);
    puVar12 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    uVar6 = puVar11[-3];
    uVar7 = puVar11[-2];
    uVar8 = puVar11[-1];
    if (puVar11 <= puVar12) {
        puVar12 = puVar13;
    }
    *puVar12 = puVar11[-4];
    puVar12[1] = uVar6;
    puVar12[2] = uVar7;
    puVar12[3] = uVar8;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    iVar10 = *(int64_t *)(arg1 + 0x40);
    if (*(char *)0x180777030 == '\0') {
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 | 2;
        iVar10 = *(int64_t *)(arg1 + 0x28) + 0x10;
        var_18h = *(int64_t *)(arg1 + 0x28) - *(int64_t *)(arg1 + 0x38);
        iVar9 = func_0x000180094080(arg1, 0x18008aa70, iVar10, iVar10 - *(int64_t *)(arg1 + 0x38));
        if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
            **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
        }
        if ((iVar9 == 0) && (((cVar2 = *(char *)(arg1 + 3), cVar2 == '\x01' || (cVar2 == '\x06')) || (cVar2 == '\x7f')))
           ) {
            return 0xffffffff;
        }
        fcn.180085610(arg1, 1);
        func_0x000180086b20(arg1, iVar9 == 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        puVar11 = *(undefined4 **)(arg1 + 0x40);
        uVar6 = puVar11[-3];
        uVar7 = puVar11[-2];
        uVar8 = puVar11[-1];
        puVar13 = *(undefined4 **)(arg1 + 0x28);
        if (puVar11 <= *(undefined4 **)(arg1 + 0x28)) {
            puVar13 = *(undefined4 **)0x180782430;
        }
        *puVar13 = puVar11[-4];
        puVar13[1] = uVar6;
        puVar13[2] = uVar7;
        puVar13[3] = uVar8;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        return *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    }
    iVar4 = *(int64_t *)(arg1 + 0x28);
    iVar3 = **(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8);
    *(undefined4 *)(*(int64_t *)(arg1 + 0x18) + 0x18) = 1;
    puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
    *puVar1 = *puVar1 | 2;
    var_18h = *(int64_t *)(arg1 + 0x40) + (int64_t)((int32_t)(iVar10 - iVar4 >> 4) + -1) * -0x10;
    uStack_10 = 0xffffffff;
    iVar9 = func_0x000180094080(arg1, 0x1800890c0, &var_18h, var_18h - *(int64_t *)(arg1 + 0x38), 
                                *(int64_t *)(arg1 + 0x28) - *(int64_t *)(arg1 + 0x38));
    if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
        **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
    }
    if ((iVar9 == 0) && (((cVar2 = *(char *)(arg1 + 3), cVar2 == '\x01' || (cVar2 == '\x06')) || (cVar2 == '\x7f')))) {
        return 0xffffffff;
    }
    puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
    *puVar1 = *puVar1 & 0xfffffffd;
    iVar10 = (*(code *)(*(int64_t *)(iVar3 + 0x28) + 0x28 + iVar3))(arg1);
    return iVar10;
}

// ============================================================
// Function: FUN_18008af40
// Address: 0x18008af40
// Size: 20 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x000180089045)
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18008ad70(int64_t arg1)
{
    uint32_t *puVar1;
    char cVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    undefined4 *puVar12;
    undefined4 *puVar13;
    int64_t var_8h;
    int64_t var_18h;
    undefined4 uStack_10;
    
    puVar11 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(undefined4 **)(arg1 + 0x40) <= puVar11) {
        puVar11 = *(undefined4 **)0x180782430;
    }
    if ((puVar11 == *(undefined4 **)0x180782430) || (puVar11[3] != 8)) {
        fcn.180088470(arg1, 2, 8);
        pcVar5 = (code *)swi(3);
        iVar10 = (*pcVar5)();
        return iVar10;
    }
    func_0x000180085bf0(arg1, 1);
    func_0x000180085bf0(arg1, 2);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar13 = *(undefined4 **)0x180782430;
    puVar11 = *(undefined4 **)(arg1 + 0x40);
    uVar6 = puVar11[-3];
    uVar7 = puVar11[-2];
    uVar8 = puVar11[-1];
    puVar12 = *(undefined4 **)(arg1 + 0x28);
    if (puVar11 <= *(undefined4 **)(arg1 + 0x28)) {
        puVar12 = *(undefined4 **)0x180782430;
    }
    *puVar12 = puVar11[-4];
    puVar12[1] = uVar6;
    puVar12[2] = uVar7;
    puVar12[3] = uVar8;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar11 = *(undefined4 **)(arg1 + 0x40);
    puVar12 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    uVar6 = puVar11[-3];
    uVar7 = puVar11[-2];
    uVar8 = puVar11[-1];
    if (puVar11 <= puVar12) {
        puVar12 = puVar13;
    }
    *puVar12 = puVar11[-4];
    puVar12[1] = uVar6;
    puVar12[2] = uVar7;
    puVar12[3] = uVar8;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    iVar10 = *(int64_t *)(arg1 + 0x40);
    if (*(char *)0x180777030 == '\0') {
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 | 2;
        iVar10 = *(int64_t *)(arg1 + 0x28) + 0x10;
        var_18h = *(int64_t *)(arg1 + 0x28) - *(int64_t *)(arg1 + 0x38);
        iVar9 = func_0x000180094080(arg1, 0x18008aa70, iVar10, iVar10 - *(int64_t *)(arg1 + 0x38));
        if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
            **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
        }
        if ((iVar9 == 0) && (((cVar2 = *(char *)(arg1 + 3), cVar2 == '\x01' || (cVar2 == '\x06')) || (cVar2 == '\x7f')))
           ) {
            return 0xffffffff;
        }
        fcn.180085610(arg1, 1);
        func_0x000180086b20(arg1, iVar9 == 0);
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        puVar11 = *(undefined4 **)(arg1 + 0x40);
        uVar6 = puVar11[-3];
        uVar7 = puVar11[-2];
        uVar8 = puVar11[-1];
        puVar13 = *(undefined4 **)(arg1 + 0x28);
        if (puVar11 <= *(undefined4 **)(arg1 + 0x28)) {
            puVar13 = *(undefined4 **)0x180782430;
        }
        *puVar13 = puVar11[-4];
        puVar13[1] = uVar6;
        puVar13[2] = uVar7;
        puVar13[3] = uVar8;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        return *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
    }
    iVar4 = *(int64_t *)(arg1 + 0x28);
    iVar3 = **(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8);
    *(undefined4 *)(*(int64_t *)(arg1 + 0x18) + 0x18) = 1;
    puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
    *puVar1 = *puVar1 | 2;
    var_18h = *(int64_t *)(arg1 + 0x40) + (int64_t)((int32_t)(iVar10 - iVar4 >> 4) + -1) * -0x10;
    uStack_10 = 0xffffffff;
    iVar9 = func_0x000180094080(arg1, 0x1800890c0, &var_18h, var_18h - *(int64_t *)(arg1 + 0x38), 
                                *(int64_t *)(arg1 + 0x28) - *(int64_t *)(arg1 + 0x38));
    if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
        **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
    }
    if ((iVar9 == 0) && (((cVar2 = *(char *)(arg1 + 3), cVar2 == '\x01' || (cVar2 == '\x06')) || (cVar2 == '\x7f')))) {
        return 0xffffffff;
    }
    puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
    *puVar1 = *puVar1 & 0xfffffffd;
    iVar10 = (*(code *)(*(int64_t *)(iVar3 + 0x28) + 0x28 + iVar3))(arg1);
    return iVar10;
}

// ============================================================
// Function: FUN_18008af70
// Address: 0x18008af70
// Size: 757 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

int64_t fcn.18008af70(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t unaff_R14;
    int64_t var_38h;
    
    if ((int32_t)arg2 == 0) {
        fcn.180085610(arg1, 1);
        if (((*(char *)0x180777010 == (char)arg2) || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))
            ) || (iVar6 = fcn.180085510(unaff_R14), iVar6 != 0)) {
            puVar1 = *(undefined4 **)(arg1 + 0x40);
            *puVar1 = 1;
            puVar1[3] = 1;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            puVar1 = *(undefined4 **)(arg1 + 0x40);
            uVar3 = puVar1[-3];
            uVar4 = puVar1[-2];
            uVar5 = puVar1[-1];
            puVar7 = *(undefined4 **)(arg1 + 0x28);
            if (puVar1 <= *(undefined4 **)(arg1 + 0x28)) {
                puVar7 = *(undefined4 **)0x180782430;
            }
            *puVar7 = puVar1[-4];
            puVar7[1] = uVar3;
            puVar7[2] = uVar4;
            puVar7[3] = uVar5;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            return *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4;
        }
    } else if (*(char *)0x180777030 == '\0') {
        fcn.180085610(arg1, 3);
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar6 = fcn.180085510(unaff_R14), iVar6 != 0)) {
            puVar1 = *(undefined4 **)(arg1 + 0x40);
            *puVar1 = 0;
            puVar1[3] = 1;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar6 = fcn.180085510(unaff_R14), iVar6 != 0)) {
                puVar1 = *(undefined4 **)(arg1 + 0x40);
                puVar7 = *(undefined4 **)(arg1 + 0x28);
                if (puVar1 <= *(undefined4 **)(arg1 + 0x28)) {
                    puVar7 = *(undefined4 **)0x180782430;
                }
                uVar3 = puVar7[1];
                uVar4 = puVar7[2];
                uVar5 = puVar7[3];
                *puVar1 = *puVar7;
                puVar1[1] = uVar3;
                puVar1[2] = uVar4;
                puVar1[3] = uVar5;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                if (((*(char *)0x180777010 == '\0') ||
                    (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                   (iVar6 = fcn.180085510(unaff_R14), iVar6 != 0)) {
                    puVar1 = *(undefined4 **)(arg1 + 0x40);
                    *puVar1 = puVar1[-0xc];
                    puVar1[1] = puVar1[-0xb];
                    puVar1[2] = puVar1[-10];
                    puVar1[3] = puVar1[-9];
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                    iVar10 = *(int64_t *)(arg1 + 0x40) + -0x20;
                    iVar8 = iVar10 - *(int64_t *)(arg1 + 0x38);
                    iVar6 = func_0x000180094080(arg1, 0x18008af60, iVar10, iVar8, 0);
                    if (iVar6 != 0) {
                        if (((int32_t)arg2 != 4) || (uVar9 = arg2 & 0xffffffff, iVar6 != 4)) {
                            uVar9 = 5;
                        }
                        func_0x000180093800(arg1, uVar9, *(int64_t *)(arg1 + 0x38) + iVar8);
                    }
                    return 2;
                }
            }
        }
    } else {
        fcn.180085610(arg1, 1);
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar6 = fcn.180085510(unaff_R14), iVar6 != 0)) {
            puVar1 = *(undefined4 **)(arg1 + 0x40);
            *puVar1 = 0;
            puVar1[3] = 1;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            puVar7 = *(undefined4 **)(arg1 + 0x40);
            for (puVar1 = puVar7; puVar7 + -8 < puVar1; puVar1 = puVar1 + -4) {
                *puVar1 = puVar1[-4];
                puVar1[1] = puVar1[-3];
                puVar1[2] = puVar1[-2];
                puVar1[3] = puVar1[-1];
            }
            puVar1 = *(undefined4 **)(arg1 + 0x40);
            uVar3 = puVar1[1];
            uVar4 = puVar1[2];
            uVar5 = puVar1[3];
            puVar7[-8] = *puVar1;
            puVar7[-7] = uVar3;
            puVar7[-6] = uVar4;
            puVar7[-5] = uVar5;
            return 2;
        }
    }
    fcn.180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar2 = (code *)swi(3);
    iVar8 = (*pcVar2)();
    return iVar8;
}

// ============================================================
// Function: FUN_18008b270
// Address: 0x18008b270
// Size: 77 bytes
// ============================================================
undefined8 fcn.18008b270(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    uint64_t uVar3;
    
    uVar3 = *(uint64_t *)(arg1 + 0x28);
    if (*(uint64_t *)(arg1 + 0x40) <= *(uint64_t *)(arg1 + 0x28)) {
        uVar3 = *(uint64_t *)0x180782430;
    }
    if ((uVar3 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar3 + 0xc) != -1)) {
        fcn.1800893a0(arg1, 1, 0);
        return 1;
    }
    fcn.180088560(arg1, 0x18063da20, 1);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_18008b2c0
// Address: 0x18008b2c0
// Size: 174 bytes
// ============================================================
undefined8 fcn.18008b2c0(int64_t arg1)
{
    code *pcVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    int32_t *piVar4;
    
    piVar4 = *(int32_t **)(arg1 + 0x28);
    piVar2 = piVar4;
    if (*(int32_t **)(arg1 + 0x40) <= piVar4) {
        piVar2 = *(int32_t **)0x180782430;
    }
    if ((piVar2 != *(int32_t **)0x180782430) && (2 < piVar2[3] + 1U)) {
        fcn.1800883d0(arg1, 1, 0x18063dbf8);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    if (*(int32_t **)(arg1 + 0x40) <= piVar4) {
        piVar4 = *(int32_t **)0x180782430;
    }
    if ((piVar4[3] != 0) && ((piVar4[3] != 1 || (*piVar4 != 0)))) {
        fcn.180087f70(arg1, 0, 0x81);
        fcn.180086fd0(arg1, 0, 0);
        fcn.180087650(arg1, 0xfffffffe);
        return 1;
    }
    fcn.180087f70(arg1, 0, 0x81);
    return 1;
}

// ============================================================
// Function: FUN_18008b370
// Address: 0x18008b370
// Size: 902 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008b370(int64_t arg1)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    undefined4 *puVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    undefined8 uVar10;
    undefined8 *puVar11;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar5 = fcn.180085510(unaff_retaddr), iVar5 == 0)) {
code_r0x00018008b6de:
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar1 = (code *)swi(3);
        uVar10 = (*pcVar1)();
        return uVar10;
    }
    puVar6 = (undefined4 *)fcn.180085370(arg1, 0xffffd8ee);
    puVar9 = *(undefined4 **)(arg1 + 0x40);
    uVar2 = puVar6[1];
    uVar3 = puVar6[2];
    uVar4 = puVar6[3];
    *puVar9 = *puVar6;
    puVar9[1] = uVar2;
    puVar9[2] = uVar3;
    puVar9[3] = uVar4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    func_0x000180087370(arg1, 0xffffd8ee, 0x1806203dc);
    iVar5 = 0;
    puVar11 = (undefined8 *)0x180611630;
    piVar7 = (int64_t *)0x180611630;
    do {
        iVar5 = iVar5 + 1;
        piVar7 = piVar7 + 2;
    } while (*piVar7 != 0);
    func_0x000180088ce0(arg1, 0xffffd8f0, 0x18063da18, 1);
    func_0x000180086cc0(arg1, 0xffffffff, 0x1806203dc);
    iVar8 = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((iVar8 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 7)) {
        *(int64_t *)(arg1 + 0x40) = iVar8;
        iVar8 = func_0x000180088ce0(arg1, 0xffffd8ee, 0x1806203dc, iVar5);
        if (iVar8 != 0) {
            fcn.180088560(arg1, 0x18063da68, 0x1806203dc);
            pcVar1 = (code *)swi(3);
            uVar10 = (*pcVar1)();
            return uVar10;
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar5 = fcn.180085510(unaff_retaddr), iVar5 == 0)) goto code_r0x00018008b6de;
        puVar9 = *(undefined4 **)(arg1 + 0x40);
        *puVar9 = puVar9[-4];
        puVar9[1] = puVar9[-3];
        puVar9[2] = puVar9[-2];
        puVar9[3] = puVar9[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087370(arg1, 0xfffffffd, 0x1806203dc);
    }
    puVar6 = *(undefined4 **)(arg1 + 0x40);
    puVar9 = puVar6 + -4;
    if (puVar9 < puVar6) {
        do {
            puVar9[-4] = *puVar9;
            puVar9[-3] = puVar9[1];
            puVar9[-2] = puVar9[2];
            puVar9[-1] = puVar9[3];
            puVar6 = *(undefined4 **)(arg1 + 0x40);
            puVar9 = puVar9 + 4;
        } while (puVar9 < puVar6);
    }
    *(undefined4 **)(arg1 + 0x40) = puVar6 + -4;
    iVar8 = 0x180625868;
    do {
        func_0x0001800869f0(arg1, puVar11[1], iVar8, 0, 0);
        func_0x000180087370(arg1, 0xfffffffe, *puVar11);
        iVar8 = puVar11[2];
        puVar11 = puVar11 + 2;
    } while (iVar8 != 0);
    fcn.1800867f0(arg1, 0x18063dbe4, 4);
    func_0x000180087370(arg1, 0xffffd8ee, 0x180625870);
    func_0x0001800869f0(arg1, fcn.18008a730, 0, 0, 0);
    func_0x0001800869f0(arg1, fcn.18008a7d0, 0x180625d3c, 1, 0);
    func_0x000180087370(arg1, 0xfffffffe, 0x180625d3c);
    func_0x0001800869f0(arg1, fcn.18008a5d0, 0, 0, 0);
    func_0x0001800869f0(arg1, fcn.18008a650, 0x180625f3c, 1, 0);
    func_0x000180087370(arg1, 0xfffffffe, 0x180625f3c);
    func_0x0001800869f0(arg1, fcn.18008aa90, 0x180625f90, 0, fcn.18008abf0);
    func_0x000180087370(arg1, 0xfffffffe, 0x180625f90);
    func_0x0001800869f0(arg1, fcn.18008ad70, 0x1806263a8, 0, fcn.18008af70);
    func_0x000180087370(arg1, 0xfffffffe, 0x1806263a8);
    return 1;
}

// ============================================================
// Function: FUN_18008b700
// Address: 0x18008b700
// Size: 219 bytes
// ============================================================
uint64_t fcn.18008b700(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    double *pdVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    double dVar8;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_34h;
    
    iVar5 = 1;
    uVar7 = 0xffffffff;
    iVar6 = (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4);
    if (0 < iVar6) {
        do {
            if (iVar5 < 1) {
                if (iVar5 < -9999) {
                    pdVar3 = (double *)fcn.180085370(arg1, iVar5);
                } else {
                    pdVar3 = (double *)((int64_t)iVar5 * 0x10 + *(int64_t *)(arg1 + 0x40));
                }
            } else {
                pdVar3 = (double *)(*(int64_t *)(arg1 + 0x28) + (int64_t)(iVar5 + -1) * 0x10);
                if (*(double **)(arg1 + 0x40) <= pdVar3) {
                    pdVar3 = *(double **)0x180782430;
                }
            }
            if (*(int32_t *)((int64_t)pdVar3 + 0xc) == 3) {
                dVar8 = *pdVar3;
            } else {
                if ((*(int32_t *)((int64_t)pdVar3 + 0xc) != 6) ||
                   (iVar2 = func_0x0001800992c0((int64_t)*pdVar3 + 0x18, &var_48h), iVar2 == 0)) {
                    fcn.180088470(arg1, iVar5, 3);
                    pcVar1 = (code *)swi(3);
                    uVar4 = (*pcVar1)();
                    return uVar4;
                }
                var_40h = var_48h;
                var_34h._0_4_ = 3;
                dVar8 = (double)var_48h;
            }
            iVar5 = iVar5 + 1;
            uVar7 = uVar7 & (uint32_t)(int64_t)dVar8;
        } while (iVar5 <= iVar6);
    }
    return (uint64_t)uVar7;
}

// ============================================================
// Function: FUN_18008b7e0
// Address: 0x18008b7e0
// Size: 35 bytes
// ============================================================
undefined8 fcn.18008b7e0(int64_t arg1)
{
    undefined4 uVar1;
    
    uVar1 = fcn.18008b700(arg1);
    fcn.1800866d0(arg1, uVar1);
    return 1;
}

// ============================================================
// Function: FUN_18008b810
// Address: 0x18008b810
// Size: 40 bytes
// ============================================================
undefined8 fcn.18008b810(int64_t arg1)
{
    int32_t iVar1;
    
    iVar1 = fcn.18008b700(arg1);
    fcn.180086b20(arg1, iVar1 != 0);
    return 1;
}

// ============================================================
// Function: FUN_18008b840
// Address: 0x18008b840
// Size: 164 bytes
// ============================================================
undefined8 fcn.18008b840(int64_t arg1)
{
    double *pdVar1;
    code *pcVar2;
    uint32_t uVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t unaff_RBP;
    uint32_t uVar6;
    int32_t iVar7;
    
    uVar6 = 0;
    iVar7 = 1;
    iVar4 = (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4);
    if (0 < iVar4) {
        do {
            uVar3 = func_0x000180088a70(arg1, iVar7);
            uVar6 = uVar6 | uVar3;
            iVar7 = iVar7 + 1;
        } while (iVar7 <= iVar4);
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar4 = fcn.180085510(unaff_RBP);
        if (iVar4 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
    }
    pdVar1 = *(double **)(arg1 + 0x40);
    *(undefined4 *)((int64_t)pdVar1 + 0xc) = 3;
    *pdVar1 = (double)(uint64_t)uVar6;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_18008b8f0
// Address: 0x18008b8f0
// Size: 164 bytes
// ============================================================
undefined8 fcn.18008b8f0(int64_t arg1)
{
    double *pdVar1;
    code *pcVar2;
    uint32_t uVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t unaff_RBP;
    uint32_t uVar6;
    int32_t iVar7;
    
    uVar6 = 0;
    iVar7 = 1;
    iVar4 = (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4);
    if (0 < iVar4) {
        do {
            uVar3 = func_0x000180088a70(arg1, iVar7);
            uVar6 = uVar6 ^ uVar3;
            iVar7 = iVar7 + 1;
        } while (iVar7 <= iVar4);
    }
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar4 = fcn.180085510(unaff_RBP);
        if (iVar4 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
    }
    pdVar1 = *(double **)(arg1 + 0x40);
    *(undefined4 *)((int64_t)pdVar1 + 0xc) = 3;
    *pdVar1 = (double)(uint64_t)uVar6;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_18008b9a0
// Address: 0x18008b9a0
// Size: 42 bytes
// ============================================================
undefined8 fcn.18008b9a0(int64_t arg1)
{
    uint32_t uVar1;
    
    uVar1 = fcn.180088a70(arg1, 1);
    fcn.1800866d0(arg1, ~uVar1);
    return 1;
}

// ============================================================
// Function: FUN_18008b9d0
// Address: 0x18008b9d0
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18008b9d0(int64_t arg1)
{
    int32_t iVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int64_t var_8h;
    
    iVar1 = fcn.180088860(arg1, 2);
    uVar2 = fcn.180088a70(arg1, 1);
    if (iVar1 < 0) {
        uVar3 = 0;
        if (-iVar1 < 0x20) {
            uVar3 = uVar2 >> ((uint8_t)-iVar1 & 0x1f);
        }
    } else if (iVar1 < 0x20) {
        uVar3 = uVar2 << ((uint8_t)iVar1 & 0x1f);
    } else {
        uVar3 = 0;
    }
    fcn.1800866d0(arg1, uVar3);
    return 1;
}

// ============================================================
// Function: FUN_18008ba40
// Address: 0x18008ba40
// Size: 107 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008ba40(int64_t arg1)
{
    int32_t iVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = fcn.180088860(arg1, 2);
    uVar2 = fcn.180088a70(arg1, 1);
    iVar4 = -iVar1;
    if (iVar4 < 0) {
        uVar3 = 0;
        if (iVar1 < 0x20) {
            uVar3 = uVar2 >> ((uint8_t)iVar1 & 0x1f);
        }
    } else if (iVar4 < 0x20) {
        uVar3 = uVar2 << ((uint8_t)iVar4 & 0x1f);
    } else {
        uVar3 = 0;
    }
    fcn.1800866d0(arg1, uVar3);
    return 1;
}

// ============================================================
// Function: FUN_18008bab0
// Address: 0x18008bab0
// Size: 127 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18008bab0(int64_t arg1)
{
    uint32_t uVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint8_t uVar4;
    uint32_t uVar5;
    int64_t var_8h;
    
    uVar1 = fcn.180088a70(arg1, 1);
    iVar2 = fcn.180088860(arg1, 2);
    uVar4 = (uint8_t)iVar2;
    if ((iVar2 < 0) || (-1 < (int32_t)uVar1)) {
        iVar3 = -iVar2;
        if (iVar3 < 0) {
            uVar5 = 0;
            if (iVar2 < 0x20) {
                uVar5 = uVar1 >> (uVar4 & 0x1f);
            }
        } else if (iVar3 < 0x20) {
            uVar5 = uVar1 << ((uint8_t)iVar3 & 0x1f);
        } else {
            uVar5 = 0;
        }
    } else {
        uVar5 = 0xffffffff;
        if (iVar2 < 0x20) {
            uVar5 = uVar1 >> (uVar4 & 0x1f) | ~(0xffffffffU >> (uVar4 & 0x1f));
        }
    }
    fcn.1800866d0(arg1, uVar5);
    return 1;
}

// ============================================================
// Function: FUN_18008bb30
// Address: 0x18008bb30
// Size: 75 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18008bb30(int64_t arg1)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t var_8h;
    
    uVar1 = fcn.180088860(arg1, 2);
    uVar2 = fcn.180088a70(arg1, 1);
    uVar1 = uVar1 & 0x1f;
    if (uVar1 != 0) {
        uVar2 = uVar2 << uVar1 | uVar2 >> 0x20 - uVar1;
    }
    fcn.1800866d0(arg1, uVar2);
    return 1;
}

// ============================================================
// Function: FUN_18008bb80
// Address: 0x18008bb80
// Size: 76 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18008bb80(int64_t arg1)
{
    char cVar1;
    uint32_t uVar2;
    uint8_t uVar3;
    int64_t var_8h;
    
    cVar1 = fcn.180088860(arg1, 2);
    uVar2 = fcn.180088a70(arg1, 1);
    uVar3 = -cVar1 & 0x1f;
    if (uVar3 != 0) {
        uVar2 = uVar2 << uVar3 | uVar2 >> 0x20 - uVar3;
    }
    fcn.1800866d0(arg1, uVar2);
    return 1;
}

// ============================================================
// Function: FUN_18008bbd0
// Address: 0x18008bbd0
// Size: 222 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008bbd0(int64_t arg1)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar2 = fcn.180088a70(arg1, 1);
    iVar3 = fcn.180088860(arg1, 2);
    uVar6 = *(int64_t *)(arg1 + 0x28) + 0x20;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar6) {
        uVar6 = *(uint64_t *)0x180782430;
    }
    if ((uVar6 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar6 + 0xc) < 1)) {
        iVar4 = 1;
    } else {
        iVar4 = fcn.180088860(arg1, 3);
    }
    if (iVar3 < 0) {
        func_0x000180088380(arg1, 2, 0x18063dc20);
        pcVar1 = (code *)swi(3);
        uVar5 = (*pcVar1)();
        return uVar5;
    }
    if (iVar4 < 1) {
        func_0x000180088380(arg1, 3, 0x18063dc08);
        pcVar1 = (code *)swi(3);
        uVar5 = (*pcVar1)();
        return uVar5;
    }
    if (iVar4 + iVar3 < 0x21) {
        fcn.1800866d0(arg1, ~(-2 << ((char)iVar4 - 1U & 0x1f)) & uVar2 >> ((uint8_t)iVar3 & 0x1f));
        return 1;
    }
    fcn.180088560(arg1, 0x18063dc58);
    pcVar1 = (code *)swi(3);
    uVar5 = (*pcVar1)();
    return uVar5;
}

// ============================================================
// Function: FUN_18008bcb0
// Address: 0x18008bcb0
// Size: 241 bytes
// ============================================================
undefined8 fcn.18008bcb0(int64_t arg1)
{
    code *pcVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int32_t iVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    uint32_t uVar8;
    
    uVar2 = fcn.180088a70(arg1, 1);
    uVar3 = fcn.180088a70(arg1, 2);
    iVar4 = fcn.180088860(arg1, 3);
    uVar7 = *(int64_t *)(arg1 + 0x28) + 0x30;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar7) {
        uVar7 = *(uint64_t *)0x180782430;
    }
    if ((uVar7 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar7 + 0xc) < 1)) {
        iVar5 = 1;
    } else {
        iVar5 = fcn.180088860(arg1, 4);
    }
    if (iVar4 < 0) {
        func_0x000180088380(arg1, 3, 0x18063dc20);
        pcVar1 = (code *)swi(3);
        uVar6 = (*pcVar1)();
        return uVar6;
    }
    if (iVar5 < 1) {
        func_0x000180088380(arg1, 4, 0x18063dc08);
        pcVar1 = (code *)swi(3);
        uVar6 = (*pcVar1)();
        return uVar6;
    }
    if (iVar5 + iVar4 < 0x21) {
        uVar8 = ~(-2 << ((char)iVar5 - 1U & 0x1f));
        fcn.1800866d0(arg1, ~(uVar8 << ((uint8_t)iVar4 & 0x1f)) & uVar2 | (uVar8 & uVar3) << ((uint8_t)iVar4 & 0x1f));
        return 1;
    }
    fcn.180088560(arg1, 0x18063dc58);
    pcVar1 = (code *)swi(3);
    uVar6 = (*pcVar1)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008bdb0
// Address: 0x18008bdb0
// Size: 172 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18008bdb0(int64_t arg1)
{
    double *pdVar1;
    code *pcVar2;
    uint32_t uVar3;
    int32_t iVar4;
    undefined8 uVar5;
    uint32_t uVar6;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    uVar3 = fcn.180088a70(arg1, 1);
    uVar6 = 0;
    do {
        if ((uVar3 >> (0x1f - uVar6 & 0x1f) & 1) != 0) goto code_r0x00018008bdeb;
        uVar6 = uVar6 + 1;
    } while ((int32_t)uVar6 < 0x20);
    uVar6 = 0x20;
code_r0x00018008bdeb:
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar4 = fcn.180085510(in_stack_00000010);
        if (iVar4 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
    }
    pdVar1 = *(double **)(arg1 + 0x40);
    *(undefined4 *)((int64_t)pdVar1 + 0xc) = 3;
    *pdVar1 = (double)(uint64_t)uVar6;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_18008be60
// Address: 0x18008be60
// Size: 163 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18008be60(int64_t arg1)
{
    double *pdVar1;
    code *pcVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    undefined8 uVar6;
    uint32_t uVar7;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    uVar3 = fcn.180088a70(arg1, 1);
    uVar7 = 0;
    uVar4 = 1;
    do {
        if ((uVar3 & uVar4) != 0) goto code_r0x00018008be92;
        uVar7 = uVar7 + 1;
        uVar4 = uVar4 << 1 | (uint32_t)((int32_t)uVar4 < 0);
    } while ((int32_t)uVar7 < 0x20);
    uVar7 = 0x20;
code_r0x00018008be92:
    if ((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) {
        iVar5 = fcn.180085510(in_stack_00000010);
        if (iVar5 == 0) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar2 = (code *)swi(3);
            uVar6 = (*pcVar2)();
            return uVar6;
        }
    }
    pdVar1 = *(double **)(arg1 + 0x40);
    *(undefined4 *)((int64_t)pdVar1 + 0xc) = 3;
    *pdVar1 = (double)(uint64_t)uVar7;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_18008bf10
// Address: 0x18008bf10
// Size: 42 bytes
// ============================================================
undefined8 fcn.18008bf10(int64_t arg1)
{
    uint32_t uVar1;
    
    uVar1 = fcn.180088a70(arg1, 1);
    fcn.1800866d0(arg1, uVar1 >> 0x18 | (uVar1 & 0xff0000) >> 8 | (uVar1 & 0xff00) << 8 | uVar1 << 0x18);
    return 1;
}

// ============================================================
// Function: FUN_18008bf40
// Address: 0x18008bf40
// Size: 449 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

undefined8 fcn.18008bf40(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    undefined8 uVar5;
    undefined4 *puVar6;
    undefined8 *puVar7;
    int32_t iVar8;
    int64_t unaff_RDI;
    int64_t var_38h;
    
    puVar7 = (undefined8 *)0x180611770;
    iVar8 = 0;
    piVar2 = (int64_t *)0x180611770;
    do {
        iVar8 = iVar8 + 1;
        piVar2 = piVar2 + 2;
    } while (*piVar2 != 0);
    func_0x000180088ce0(arg1, 0xffffd8f0, 0x18063da18, 1);
    func_0x000180086cc0(arg1, 0xffffffff, 0x1806258c8);
    iVar3 = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((iVar3 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 7)) {
        *(int64_t *)(arg1 + 0x40) = iVar3;
        iVar3 = func_0x000180088ce0(arg1, 0xffffd8ee, 0x1806258c8, iVar8);
        if (iVar3 != 0) {
            fcn.180088560(arg1, 0x18063da68, 0x1806258c8);
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar8 = fcn.180085510(unaff_RDI), iVar8 == 0)) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        puVar4 = *(undefined4 **)(arg1 + 0x40);
        *puVar4 = puVar4[-4];
        puVar4[1] = puVar4[-3];
        puVar4[2] = puVar4[-2];
        puVar4[3] = puVar4[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087370(arg1, 0xfffffffd, 0x1806258c8);
    }
    puVar6 = *(undefined4 **)(arg1 + 0x40);
    puVar4 = puVar6 + -4;
    if (puVar4 < puVar6) {
        do {
            puVar4[-4] = *puVar4;
            puVar4[-3] = puVar4[1];
            puVar4[-2] = puVar4[2];
            puVar4[-1] = puVar4[3];
            puVar6 = *(undefined4 **)(arg1 + 0x40);
            puVar4 = puVar4 + 4;
        } while (puVar4 < puVar6);
    }
    *(undefined4 **)(arg1 + 0x40) = puVar6 + -4;
    iVar3 = 0x18063c258;
    do {
        func_0x0001800869f0(arg1, puVar7[1], iVar3, 0, 0);
        func_0x000180087370(arg1, 0xfffffffe, *puVar7);
        iVar3 = puVar7[2];
        puVar7 = puVar7 + 2;
    } while (iVar3 != 0);
    return 1;
}

// ============================================================
// Function: FUN_18008c110
// Address: 0x18008c110
// Size: 63 bytes
// ============================================================
undefined8 fcn.18008c110(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    undefined8 uVar3;
    
    iVar2 = fcn.180088860(arg1, 1);
    if (-1 < iVar2) {
        fcn.180088040(arg1, (int64_t)iVar2);
        return 1;
    }
    fcn.180088380(arg1, 1, 0x18063dcac);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_18008c150
// Address: 0x18008c150
// Size: 129 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008c150(int64_t arg1)
{
    int64_t iVar1;
    undefined4 uVar2;
    code *pcVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018008c206;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar6 + 0x18;
    if (iVar1 != 0) {
        uVar2 = *(undefined4 *)(*piVar6 + 0x14);
        uVar5 = fcn.180088040(arg1, uVar2);
        fcn.180498030(uVar5, iVar1, uVar2);
        return 1;
    }
code_r0x00018008c206:
    fcn.180088470(arg1, 1, 6);
    pcVar3 = (code *)swi(3);
    uVar5 = (*pcVar3)();
    return uVar5;
}

// ============================================================
// Function: FUN_18008c1d1
// Address: 0x18008c1d1
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008c150(int64_t arg1)
{
    int64_t iVar1;
    undefined4 uVar2;
    code *pcVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018008c206;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar6 + 0x18;
    if (iVar1 != 0) {
        uVar2 = *(undefined4 *)(*piVar6 + 0x14);
        uVar5 = fcn.180088040(arg1, uVar2);
        fcn.180498030(uVar5, iVar1, uVar2);
        return 1;
    }
code_r0x00018008c206:
    fcn.180088470(arg1, 1, 6);
    pcVar3 = (code *)swi(3);
    uVar5 = (*pcVar3)();
    return uVar5;
}

// ============================================================
// Function: FUN_18008c206
// Address: 0x18008c206
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008c150(int64_t arg1)
{
    int64_t iVar1;
    undefined4 uVar2;
    code *pcVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018008c206;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar6 + 0x18;
    if (iVar1 != 0) {
        uVar2 = *(undefined4 *)(*piVar6 + 0x14);
        uVar5 = fcn.180088040(arg1, uVar2);
        fcn.180498030(uVar5, iVar1, uVar2);
        return 1;
    }
code_r0x00018008c206:
    fcn.180088470(arg1, 1, 6);
    pcVar3 = (code *)swi(3);
    uVar5 = (*pcVar3)();
    return uVar5;
}

// ============================================================
// Function: FUN_18008c220
// Address: 0x18008c220
// Size: 74 bytes
// ============================================================
undefined8 fcn.18008c220(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    
    piVar3 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar3 + 0xc) == 0xb) {
        iVar1 = *piVar3 + 8;
        if (iVar1 != 0) {
            fcn.1800867f0(arg1, iVar1, *(undefined4 *)(*piVar3 + 4));
            return 1;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar2 = (code *)swi(3);
    uVar4 = (*pcVar2)();
    return uVar4;
}

// ============================================================
// Function: FUN_18008c270
// Address: 0x18008c270
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008c270(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 8 <= (uint64_t)uVar2) {
                fcn.180086660(arg1, *(undefined8 *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008c29f
// Address: 0x18008c29f
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008c270(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 8 <= (uint64_t)uVar2) {
                fcn.180086660(arg1, *(undefined8 *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008c2c7
// Address: 0x18008c2c7
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008c270(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 8 <= (uint64_t)uVar2) {
                fcn.180086660(arg1, *(undefined8 *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

