// Chunk 164 - 50 functions

// ============================================================
// Function: FUN_18021ccc0
// Address: 0x18021ccc0
// Size: 145 bytes
// ============================================================
undefined8 fcn.18021ccc0(int64_t arg_28h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021ccd0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021ccec;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    iVar2 = 0;
    if (iVar1 != 0) {
        iVar2 = *(int32_t *)0x18077e2c0;
    }
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021cd0a;
        iVar2 = fcn.180222950(*(undefined8 *)0x18077e2a8);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021cd1a;
            fcn.18026aee0(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021cd34;
            *(undefined8 *)0x18077e298 = in_RDX;
            *(undefined8 *)0x18077e2b0 = in_RCX;
            fcn.180222910(*(undefined8 *)0x18077e2a8);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021cd60
// Address: 0x18021cd60
// Size: 159 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18021cd60(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 uVar10;
    int32_t iVar11;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18021cd77;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cd88;
    uVar4 = fcn.180192480(in_RDX);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cd98;
    iVar5 = fcn.180245b40(uVar4, 5);
    uVar10 = 1;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cda9;
    fcn.1801dd6c0(in_RCX);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cdb4;
    iVar6 = fcn.18028cae0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cdc1;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cdd9;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cdeb;
        fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_R14;
    if (iVar5 == 0) {
code_r0x00018021d123:
        uVar10 = 0;
    } else {
        iVar11 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021ce1d;
        iVar2 = fcn.180222010(iVar6);
        if (0 < iVar2) {
            do {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021ce30;
                iVar7 = fcn.180222340(iVar6, iVar11);
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021ce43;
                iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                if (iVar2 == 0) {
                    iVar8 = 0;
                    if (*(int64_t *)(iVar7 + 0x10) != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021ce64;
                        iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                        if (iVar8 == 0) goto code_r0x00018021d123;
                    }
                    uVar1 = *(undefined8 *)(iVar5 + 0x28);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021ce86;
                    fcn.180224990(uVar1, 0x1804be6e8, 0x3bd);
                    *(int64_t *)(iVar5 + 0x28) = iVar8;
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021ce9f;
                    iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                    if (iVar2 == 0) {
                        iVar8 = 0;
                        if (*(int64_t *)(iVar7 + 0x10) != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cec0;
                            iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                            if (iVar8 == 0) goto code_r0x00018021d123;
                        }
                        uVar1 = *(undefined8 *)(iVar5 + 0x30);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cee2;
                        fcn.180224990(uVar1, 0x1804be6e8, 0x3bd);
                        *(int64_t *)(iVar5 + 0x30) = iVar8;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cefb;
                        iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                        if (iVar2 == 0) {
                            iVar8 = 0;
                            if (*(int64_t *)(iVar7 + 0x10) != 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cf1c;
                                iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                                if (iVar8 == 0) goto code_r0x00018021d123;
                            }
                            uVar1 = *(undefined8 *)(iVar5 + 0x38);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cf3e;
                            fcn.180224990(uVar1, 0x1804be6e8, 0x3bd);
                            *(int64_t *)(iVar5 + 0x38) = iVar8;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cf57;
                            iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                            if (iVar2 == 0) {
                                iVar8 = 0;
                                if (*(int64_t *)(iVar7 + 0x10) != 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cf78;
                                    iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                                    if (iVar8 == 0) goto code_r0x00018021d123;
                                }
                                uVar1 = *(undefined8 *)(iVar5 + 0x40);
                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cf9a;
                                fcn.180224990(uVar1, 0x1804be6e8, 0x3bd);
                                *(int64_t *)(iVar5 + 0x40) = iVar8;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cfb3;
                                iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                                if (iVar2 == 0) {
                                    iVar8 = 0;
                                    if (*(int64_t *)(iVar7 + 0x10) != 0) {
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cfd4;
                                        iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                                        if (iVar8 == 0) goto code_r0x00018021d123;
                                    }
                                    uVar1 = *(undefined8 *)(iVar5 + 0x48);
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cff6;
                                    fcn.180224990(uVar1, 0x1804be6e8, 0x3bd);
                                    *(int64_t *)(iVar5 + 0x48) = iVar8;
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d00f;
                                    iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                                    if (iVar2 == 0) {
                                        iVar8 = 0;
                                        if (*(int64_t *)(iVar7 + 0x10) != 0) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d030;
                                            iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                                            if (iVar8 == 0) goto code_r0x00018021d123;
                                        }
                                        uVar1 = *(undefined8 *)(iVar5 + 0x50);
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d052;
                                        fcn.180224990(uVar1, 0x1804be6e8, 0x3bd);
                                        *(int64_t *)(iVar5 + 0x50) = iVar8;
                                    } else {
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d06b;
                                        iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                                        if (iVar2 == 0) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d082;
                                            iVar7 = fcn.18027ec90(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                                  *(int64_t *)(&stack0x000000c8 + iVar3));
                                            if (iVar7 == 0) {
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d11f;
                                                iVar2 = fcn.18021d1e0(*(int64_t *)((int64_t)&var_8h + iVar3));
                                                if (iVar2 == 0) goto code_r0x00018021d123;
                                            } else {
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d09b;
                                                iVar8 = fcn.180245b40(uVar4, 5);
                                                if (iVar8 == 0) {
code_r0x00018021d19d:
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d1a2;
                                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20));
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d1ba;
                                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                                                  *(int64_t *)(&stack0x00000028 + iVar3));
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d1cc;
                                                    fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d1d4;
                                                    fcn.18025b1e0(iVar7);
                                                    goto code_r0x00018021d123;
                                                }
                                                if (*(int64_t *)(iVar8 + 0x18) != iVar7) {
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d0b5;
                                                    fcn.18025b180(iVar7);
                                                    if (*(int64_t *)(iVar8 + 0x20) == 0) {
code_r0x00018021d0cd:
                                                        uVar1 = *(undefined8 *)(iVar8 + 0x20);
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d0e3;
                                                        fcn.180224990(uVar1, 0x1804be6e8, 0x6e);
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d0f8;
                                                        iVar9 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3))
                                                        ;
                                                        *(int64_t *)(iVar8 + 0x20) = iVar9;
                                                        if (iVar9 == 0) goto code_r0x00018021d19d;
                                                    } else {
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d0c9;
                                                        iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3)
                                                                              , *(int64_t *)
                                                                                 ((int64_t)aiStackX_8 + iVar3 + 8));
                                                        if (iVar2 != 0) goto code_r0x00018021d0cd;
                                                    }
                                                    *(int64_t *)(iVar8 + 0x18) = iVar7;
                                                }
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d111;
                                                fcn.18025b1e0(iVar7);
                                            }
                                        } else {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d146;
                                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20));
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d15e;
                                            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                                          *(int64_t *)(&stack0x00000028 + iVar3));
                                            *(undefined8 *)((int64_t)&var_8h + iVar3) = *(undefined8 *)(iVar7 + 0x10);
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d181;
                                            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
                                            uVar10 = 0;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                iVar11 = iVar11 + 1;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d18f;
                iVar2 = fcn.180222010(iVar6);
            } while (iVar11 < iVar2);
        }
    }
    return uVar10;
}

// ============================================================
// Function: FUN_18021cdff
// Address: 0x18021cdff
// Size: 834 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18021cd60(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 uVar10;
    int32_t iVar11;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18021cd77;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cd88;
    uVar4 = fcn.180192480(in_RDX);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cd98;
    iVar5 = fcn.180245b40(uVar4, 5);
    uVar10 = 1;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cda9;
    fcn.1801dd6c0(in_RCX);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cdb4;
    iVar6 = fcn.18028cae0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cdc1;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cdd9;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cdeb;
        fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_R14;
    if (iVar5 == 0) {
code_r0x00018021d123:
        uVar10 = 0;
    } else {
        iVar11 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021ce1d;
        iVar2 = fcn.180222010(iVar6);
        if (0 < iVar2) {
            do {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021ce30;
                iVar7 = fcn.180222340(iVar6, iVar11);
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021ce43;
                iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                if (iVar2 == 0) {
                    iVar8 = 0;
                    if (*(int64_t *)(iVar7 + 0x10) != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021ce64;
                        iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                        if (iVar8 == 0) goto code_r0x00018021d123;
                    }
                    uVar1 = *(undefined8 *)(iVar5 + 0x28);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021ce86;
                    fcn.180224990(uVar1, 0x1804be6e8, 0x3bd);
                    *(int64_t *)(iVar5 + 0x28) = iVar8;
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021ce9f;
                    iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                    if (iVar2 == 0) {
                        iVar8 = 0;
                        if (*(int64_t *)(iVar7 + 0x10) != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cec0;
                            iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                            if (iVar8 == 0) goto code_r0x00018021d123;
                        }
                        uVar1 = *(undefined8 *)(iVar5 + 0x30);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cee2;
                        fcn.180224990(uVar1, 0x1804be6e8, 0x3bd);
                        *(int64_t *)(iVar5 + 0x30) = iVar8;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cefb;
                        iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                        if (iVar2 == 0) {
                            iVar8 = 0;
                            if (*(int64_t *)(iVar7 + 0x10) != 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cf1c;
                                iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                                if (iVar8 == 0) goto code_r0x00018021d123;
                            }
                            uVar1 = *(undefined8 *)(iVar5 + 0x38);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cf3e;
                            fcn.180224990(uVar1, 0x1804be6e8, 0x3bd);
                            *(int64_t *)(iVar5 + 0x38) = iVar8;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cf57;
                            iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                            if (iVar2 == 0) {
                                iVar8 = 0;
                                if (*(int64_t *)(iVar7 + 0x10) != 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cf78;
                                    iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                                    if (iVar8 == 0) goto code_r0x00018021d123;
                                }
                                uVar1 = *(undefined8 *)(iVar5 + 0x40);
                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cf9a;
                                fcn.180224990(uVar1, 0x1804be6e8, 0x3bd);
                                *(int64_t *)(iVar5 + 0x40) = iVar8;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cfb3;
                                iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                                if (iVar2 == 0) {
                                    iVar8 = 0;
                                    if (*(int64_t *)(iVar7 + 0x10) != 0) {
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cfd4;
                                        iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                                        if (iVar8 == 0) goto code_r0x00018021d123;
                                    }
                                    uVar1 = *(undefined8 *)(iVar5 + 0x48);
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cff6;
                                    fcn.180224990(uVar1, 0x1804be6e8, 0x3bd);
                                    *(int64_t *)(iVar5 + 0x48) = iVar8;
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d00f;
                                    iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                                    if (iVar2 == 0) {
                                        iVar8 = 0;
                                        if (*(int64_t *)(iVar7 + 0x10) != 0) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d030;
                                            iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                                            if (iVar8 == 0) goto code_r0x00018021d123;
                                        }
                                        uVar1 = *(undefined8 *)(iVar5 + 0x50);
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d052;
                                        fcn.180224990(uVar1, 0x1804be6e8, 0x3bd);
                                        *(int64_t *)(iVar5 + 0x50) = iVar8;
                                    } else {
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d06b;
                                        iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                                        if (iVar2 == 0) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d082;
                                            iVar7 = fcn.18027ec90(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                                  *(int64_t *)(&stack0x000000c8 + iVar3));
                                            if (iVar7 == 0) {
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d11f;
                                                iVar2 = fcn.18021d1e0(*(int64_t *)((int64_t)&var_8h + iVar3));
                                                if (iVar2 == 0) goto code_r0x00018021d123;
                                            } else {
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d09b;
                                                iVar8 = fcn.180245b40(uVar4, 5);
                                                if (iVar8 == 0) {
code_r0x00018021d19d:
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d1a2;
                                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20));
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d1ba;
                                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                                                  *(int64_t *)(&stack0x00000028 + iVar3));
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d1cc;
                                                    fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d1d4;
                                                    fcn.18025b1e0(iVar7);
                                                    goto code_r0x00018021d123;
                                                }
                                                if (*(int64_t *)(iVar8 + 0x18) != iVar7) {
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d0b5;
                                                    fcn.18025b180(iVar7);
                                                    if (*(int64_t *)(iVar8 + 0x20) == 0) {
code_r0x00018021d0cd:
                                                        uVar1 = *(undefined8 *)(iVar8 + 0x20);
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d0e3;
                                                        fcn.180224990(uVar1, 0x1804be6e8, 0x6e);
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d0f8;
                                                        iVar9 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3))
                                                        ;
                                                        *(int64_t *)(iVar8 + 0x20) = iVar9;
                                                        if (iVar9 == 0) goto code_r0x00018021d19d;
                                                    } else {
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d0c9;
                                                        iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3)
                                                                              , *(int64_t *)
                                                                                 ((int64_t)aiStackX_8 + iVar3 + 8));
                                                        if (iVar2 != 0) goto code_r0x00018021d0cd;
                                                    }
                                                    *(int64_t *)(iVar8 + 0x18) = iVar7;
                                                }
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d111;
                                                fcn.18025b1e0(iVar7);
                                            }
                                        } else {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d146;
                                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20));
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d15e;
                                            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                                          *(int64_t *)(&stack0x00000028 + iVar3));
                                            *(undefined8 *)((int64_t)&var_8h + iVar3) = *(undefined8 *)(iVar7 + 0x10);
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d181;
                                            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
                                            uVar10 = 0;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                iVar11 = iVar11 + 1;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d18f;
                iVar2 = fcn.180222010(iVar6);
            } while (iVar11 < iVar2);
        }
    }
    return uVar10;
}

// ============================================================
// Function: FUN_18021d141
// Address: 0x18021d141
// Size: 152 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18021cd60(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 uVar10;
    int32_t iVar11;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18021cd77;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cd88;
    uVar4 = fcn.180192480(in_RDX);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cd98;
    iVar5 = fcn.180245b40(uVar4, 5);
    uVar10 = 1;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cda9;
    fcn.1801dd6c0(in_RCX);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cdb4;
    iVar6 = fcn.18028cae0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cdc1;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20));
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cdd9;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cdeb;
        fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_R14;
    if (iVar5 == 0) {
code_r0x00018021d123:
        uVar10 = 0;
    } else {
        iVar11 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021ce1d;
        iVar2 = fcn.180222010(iVar6);
        if (0 < iVar2) {
            do {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021ce30;
                iVar7 = fcn.180222340(iVar6, iVar11);
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021ce43;
                iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                if (iVar2 == 0) {
                    iVar8 = 0;
                    if (*(int64_t *)(iVar7 + 0x10) != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021ce64;
                        iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                        if (iVar8 == 0) goto code_r0x00018021d123;
                    }
                    uVar1 = *(undefined8 *)(iVar5 + 0x28);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021ce86;
                    fcn.180224990(uVar1, 0x1804be6e8, 0x3bd);
                    *(int64_t *)(iVar5 + 0x28) = iVar8;
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021ce9f;
                    iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                    if (iVar2 == 0) {
                        iVar8 = 0;
                        if (*(int64_t *)(iVar7 + 0x10) != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cec0;
                            iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                            if (iVar8 == 0) goto code_r0x00018021d123;
                        }
                        uVar1 = *(undefined8 *)(iVar5 + 0x30);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cee2;
                        fcn.180224990(uVar1, 0x1804be6e8, 0x3bd);
                        *(int64_t *)(iVar5 + 0x30) = iVar8;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cefb;
                        iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                        if (iVar2 == 0) {
                            iVar8 = 0;
                            if (*(int64_t *)(iVar7 + 0x10) != 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cf1c;
                                iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                                if (iVar8 == 0) goto code_r0x00018021d123;
                            }
                            uVar1 = *(undefined8 *)(iVar5 + 0x38);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cf3e;
                            fcn.180224990(uVar1, 0x1804be6e8, 0x3bd);
                            *(int64_t *)(iVar5 + 0x38) = iVar8;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cf57;
                            iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                            if (iVar2 == 0) {
                                iVar8 = 0;
                                if (*(int64_t *)(iVar7 + 0x10) != 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cf78;
                                    iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                                    if (iVar8 == 0) goto code_r0x00018021d123;
                                }
                                uVar1 = *(undefined8 *)(iVar5 + 0x40);
                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cf9a;
                                fcn.180224990(uVar1, 0x1804be6e8, 0x3bd);
                                *(int64_t *)(iVar5 + 0x40) = iVar8;
                            } else {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cfb3;
                                iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                                if (iVar2 == 0) {
                                    iVar8 = 0;
                                    if (*(int64_t *)(iVar7 + 0x10) != 0) {
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cfd4;
                                        iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                                        if (iVar8 == 0) goto code_r0x00018021d123;
                                    }
                                    uVar1 = *(undefined8 *)(iVar5 + 0x48);
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021cff6;
                                    fcn.180224990(uVar1, 0x1804be6e8, 0x3bd);
                                    *(int64_t *)(iVar5 + 0x48) = iVar8;
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d00f;
                                    iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                                    if (iVar2 == 0) {
                                        iVar8 = 0;
                                        if (*(int64_t *)(iVar7 + 0x10) != 0) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d030;
                                            iVar8 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3));
                                            if (iVar8 == 0) goto code_r0x00018021d123;
                                        }
                                        uVar1 = *(undefined8 *)(iVar5 + 0x50);
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d052;
                                        fcn.180224990(uVar1, 0x1804be6e8, 0x3bd);
                                        *(int64_t *)(iVar5 + 0x50) = iVar8;
                                    } else {
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d06b;
                                        iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8));
                                        if (iVar2 == 0) {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d082;
                                            iVar7 = fcn.18027ec90(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                                  *(int64_t *)(&stack0x000000c8 + iVar3));
                                            if (iVar7 == 0) {
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d11f;
                                                iVar2 = fcn.18021d1e0(*(int64_t *)((int64_t)&var_8h + iVar3));
                                                if (iVar2 == 0) goto code_r0x00018021d123;
                                            } else {
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d09b;
                                                iVar8 = fcn.180245b40(uVar4, 5);
                                                if (iVar8 == 0) {
code_r0x00018021d19d:
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d1a2;
                                                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20));
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d1ba;
                                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                                                  *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                                                  *(int64_t *)(&stack0x00000028 + iVar3));
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d1cc;
                                                    fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d1d4;
                                                    fcn.18025b1e0(iVar7);
                                                    goto code_r0x00018021d123;
                                                }
                                                if (*(int64_t *)(iVar8 + 0x18) != iVar7) {
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d0b5;
                                                    fcn.18025b180(iVar7);
                                                    if (*(int64_t *)(iVar8 + 0x20) == 0) {
code_r0x00018021d0cd:
                                                        uVar1 = *(undefined8 *)(iVar8 + 0x20);
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d0e3;
                                                        fcn.180224990(uVar1, 0x1804be6e8, 0x6e);
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d0f8;
                                                        iVar9 = fcn.1802231e0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3))
                                                        ;
                                                        *(int64_t *)(iVar8 + 0x20) = iVar9;
                                                        if (iVar9 == 0) goto code_r0x00018021d19d;
                                                    } else {
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d0c9;
                                                        iVar2 = fcn.180223670(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                                              *(int64_t *)
                                                                               ((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3)
                                                                              , *(int64_t *)
                                                                                 ((int64_t)aiStackX_8 + iVar3 + 8));
                                                        if (iVar2 != 0) goto code_r0x00018021d0cd;
                                                    }
                                                    *(int64_t *)(iVar8 + 0x18) = iVar7;
                                                }
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d111;
                                                fcn.18025b1e0(iVar7);
                                            }
                                        } else {
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d146;
                                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20));
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d15e;
                                            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                                          *(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                                          *(int64_t *)(&stack0x00000028 + iVar3));
                                            *(undefined8 *)((int64_t)&var_8h + iVar3) = *(undefined8 *)(iVar7 + 0x10);
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d181;
                                            fcn.1802296d0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
                                            uVar10 = 0;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                iVar11 = iVar11 + 1;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18021d18f;
                iVar2 = fcn.180222010(iVar6);
            } while (iVar11 < iVar2);
        }
    }
    return uVar10;
}

// ============================================================
// Function: FUN_18021d1e0
// Address: 0x18021d1e0
// Size: 127 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.18021d1e0(int64_t arg_28h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021d1f0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(int64_t *)(in_RCX + 0x20) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d207;
        iVar2 = fcn.180223670(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
        if (iVar2 == 0) {
            return true;
        }
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x20);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d231;
    fcn.180224990(uVar1, 0x1804be6e8, 0x6e);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d246;
    iVar3 = fcn.1802231e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3));
    *(int64_t *)(in_RCX + 0x20) = iVar3;
    return iVar3 != 0;
}

// ============================================================
// Function: FUN_18021d260
// Address: 0x18021d260
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.18021d260(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h,
             int64_t arg_80h, int64_t arg_88h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_108h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    int64_t iVar4;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021d274;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18021d288;
    iVar1 = fcn.18020f800();
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = 0;
    if (iVar1 < 1) {
        uVar3 = 0;
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar2) = unaff_RSI;
        iVar4 = *(int64_t *)((int64_t)&arg_a0h + iVar2);
        *(undefined8 *)((int64_t)&arg_80h + iVar2) = unaff_RDI;
        if (iVar4 == 0) {
            iVar4 = 0x18077e2d0;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18021d2ca;
        fcn.18020f750(in_RCX);
        *(int64_t *)((int64_t)&arg_40h + iVar2) = (int64_t)&arg_48h + iVar2;
        *(int64_t *)((int64_t)&arg_38h + iVar2) = (int64_t)iVar1;
        *(int64_t *)((int64_t)&arg_30h + iVar2) = iVar4;
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = *(undefined8 *)((int64_t)&arg_98h + iVar2);
        *(undefined8 *)((int64_t)&var_20h + iVar2) = in_R9;
        *(int64_t *)((int64_t)&var_18h + iVar2) = (int64_t)in_R8D;
        *(undefined8 *)((int64_t)&var_10h + iVar2) = in_RDX;
        *(undefined8 *)((int64_t)&var_8h + iVar2) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18021d317;
        uVar3 = fcn.1802574e0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)((int64_t)&var_10h + iVar2), 
                              *(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                              *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar2), *(int64_t *)((int64_t)&arg_98h + iVar2), 
                              *(int64_t *)((int64_t)&arg_a0h + iVar2), *(int64_t *)((int64_t)&arg_a8h + iVar2), 
                              *(int64_t *)(&stack0x000000b8 + iVar2), *(int64_t *)(&stack0x000000c0 + iVar2), 
                              *(int64_t *)(&stack0x000000c8 + iVar2), *(int64_t *)(&stack0x000000d0 + iVar2), 
                              *(int64_t *)(&stack0x000000d8 + iVar2), *(int64_t *)(&stack0x000000e0 + iVar2), 
                              *(int64_t *)(&stack0x000000e8 + iVar2), *(int64_t *)(&stack0x000000f0 + iVar2), 
                              *(int64_t *)(&stack0x00000168 + iVar2));
        if (*(undefined4 **)((int64_t)&arg_a8h + iVar2) != (undefined4 *)0x0) {
            **(undefined4 **)((int64_t)&arg_a8h + iVar2) = *(undefined4 *)((int64_t)&arg_48h + iVar2);
            return uVar3;
        }
    }
    return uVar3;
}

// ============================================================
// Function: FUN_18021d299
// Address: 0x18021d299
// Size: 155 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.18021d260(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h,
             int64_t arg_80h, int64_t arg_88h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_108h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    int64_t iVar4;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021d274;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18021d288;
    iVar1 = fcn.18020f800();
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = 0;
    if (iVar1 < 1) {
        uVar3 = 0;
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar2) = unaff_RSI;
        iVar4 = *(int64_t *)((int64_t)&arg_a0h + iVar2);
        *(undefined8 *)((int64_t)&arg_80h + iVar2) = unaff_RDI;
        if (iVar4 == 0) {
            iVar4 = 0x18077e2d0;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18021d2ca;
        fcn.18020f750(in_RCX);
        *(int64_t *)((int64_t)&arg_40h + iVar2) = (int64_t)&arg_48h + iVar2;
        *(int64_t *)((int64_t)&arg_38h + iVar2) = (int64_t)iVar1;
        *(int64_t *)((int64_t)&arg_30h + iVar2) = iVar4;
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = *(undefined8 *)((int64_t)&arg_98h + iVar2);
        *(undefined8 *)((int64_t)&var_20h + iVar2) = in_R9;
        *(int64_t *)((int64_t)&var_18h + iVar2) = (int64_t)in_R8D;
        *(undefined8 *)((int64_t)&var_10h + iVar2) = in_RDX;
        *(undefined8 *)((int64_t)&var_8h + iVar2) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18021d317;
        uVar3 = fcn.1802574e0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)((int64_t)&var_10h + iVar2), 
                              *(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                              *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar2), *(int64_t *)((int64_t)&arg_98h + iVar2), 
                              *(int64_t *)((int64_t)&arg_a0h + iVar2), *(int64_t *)((int64_t)&arg_a8h + iVar2), 
                              *(int64_t *)(&stack0x000000b8 + iVar2), *(int64_t *)(&stack0x000000c0 + iVar2), 
                              *(int64_t *)(&stack0x000000c8 + iVar2), *(int64_t *)(&stack0x000000d0 + iVar2), 
                              *(int64_t *)(&stack0x000000d8 + iVar2), *(int64_t *)(&stack0x000000e0 + iVar2), 
                              *(int64_t *)(&stack0x000000e8 + iVar2), *(int64_t *)(&stack0x000000f0 + iVar2), 
                              *(int64_t *)(&stack0x00000168 + iVar2));
        if (*(undefined4 **)((int64_t)&arg_a8h + iVar2) != (undefined4 *)0x0) {
            **(undefined4 **)((int64_t)&arg_a8h + iVar2) = *(undefined4 *)((int64_t)&arg_48h + iVar2);
            return uVar3;
        }
    }
    return uVar3;
}

// ============================================================
// Function: FUN_18021d334
// Address: 0x18021d334
// Size: 44 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.18021d260(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_78h,
             int64_t arg_80h, int64_t arg_88h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_108h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    int64_t iVar4;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021d274;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18021d288;
    iVar1 = fcn.18020f800();
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = 0;
    if (iVar1 < 1) {
        uVar3 = 0;
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar2) = unaff_RSI;
        iVar4 = *(int64_t *)((int64_t)&arg_a0h + iVar2);
        *(undefined8 *)((int64_t)&arg_80h + iVar2) = unaff_RDI;
        if (iVar4 == 0) {
            iVar4 = 0x18077e2d0;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18021d2ca;
        fcn.18020f750(in_RCX);
        *(int64_t *)((int64_t)&arg_40h + iVar2) = (int64_t)&arg_48h + iVar2;
        *(int64_t *)((int64_t)&arg_38h + iVar2) = (int64_t)iVar1;
        *(int64_t *)((int64_t)&arg_30h + iVar2) = iVar4;
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = *(undefined8 *)((int64_t)&arg_98h + iVar2);
        *(undefined8 *)((int64_t)&var_20h + iVar2) = in_R9;
        *(int64_t *)((int64_t)&var_18h + iVar2) = (int64_t)in_R8D;
        *(undefined8 *)((int64_t)&var_10h + iVar2) = in_RDX;
        *(undefined8 *)((int64_t)&var_8h + iVar2) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18021d317;
        uVar3 = fcn.1802574e0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)((int64_t)&var_10h + iVar2), 
                              *(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                              *(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar2), *(int64_t *)((int64_t)&arg_98h + iVar2), 
                              *(int64_t *)((int64_t)&arg_a0h + iVar2), *(int64_t *)((int64_t)&arg_a8h + iVar2), 
                              *(int64_t *)(&stack0x000000b8 + iVar2), *(int64_t *)(&stack0x000000c0 + iVar2), 
                              *(int64_t *)(&stack0x000000c8 + iVar2), *(int64_t *)(&stack0x000000d0 + iVar2), 
                              *(int64_t *)(&stack0x000000d8 + iVar2), *(int64_t *)(&stack0x000000e0 + iVar2), 
                              *(int64_t *)(&stack0x000000e8 + iVar2), *(int64_t *)(&stack0x000000f0 + iVar2), 
                              *(int64_t *)(&stack0x00000168 + iVar2));
        if (*(undefined4 **)((int64_t)&arg_a8h + iVar2) != (undefined4 *)0x0) {
            **(undefined4 **)((int64_t)&arg_a8h + iVar2) = *(undefined4 *)((int64_t)&arg_48h + iVar2);
            return uVar3;
        }
    }
    return uVar3;
}

// ============================================================
// Function: FUN_18021d360
// Address: 0x18021d360
// Size: 154 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18021d360(int64_t arg_28h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *in_RCX;
    undefined8 *in_RDX;
    int64_t var_8h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021d370;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d37e;
    iVar2 = fcn.18021d9a0();
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d38f;
        iVar2 = fcn.180214b00(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d3a0;
            iVar2 = fcn.180214b00(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d3b1;
                iVar2 = fcn.180214b00(*(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                                      *(int64_t *)(&stack0x00000038 + iVar3));
                if (iVar2 != 0) {
                    *in_RCX = *in_RDX;
                    return 1;
                }
            }
        }
    }
    uVar1 = in_RCX[2];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d3d4;
    fcn.1802154a0(uVar1);
    uVar1 = in_RCX[3];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d3dd;
    fcn.1802154a0(uVar1);
    uVar1 = in_RCX[1];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d3e6;
    fcn.1802154a0(uVar1);
    *in_RCX = 0;
    return 0;
}

// ============================================================
// Function: FUN_18021d400
// Address: 0x18021d400
// Size: 110 bytes
// ============================================================
void fcn.18021d400(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18021d410;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        uVar1 = *(undefined8 *)(arg1 + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021d41f;
        fcn.1802154a0(uVar1);
        uVar1 = *(undefined8 *)(arg1 + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021d428;
        fcn.1802154a0(uVar1);
        uVar1 = *(undefined8 *)(arg1 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021d431;
        fcn.1802154a0(uVar1);
        uVar1 = *(undefined8 *)(arg1 + 0x10);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021d441;
        fcn.180215310(uVar1);
        uVar1 = *(undefined8 *)(arg1 + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021d44a;
        fcn.180215310(uVar1);
        uVar1 = *(undefined8 *)(arg1 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021d453;
        fcn.180215310(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021d468;
        fcn.180224990(arg1, 0x1804be838, 0xc2);
    }
    return;
}

// ============================================================
// Function: FUN_18021d470
// Address: 0x18021d470
// Size: 157 bytes
// ============================================================
undefined8 * fcn.18021d470(void)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021d47c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d496;
    puVar4 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    if (puVar4 != (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d4a6;
        iVar2 = fcn.18021d510(puVar4);
        if (iVar2 == 0) {
            uVar1 = puVar4[2];
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d4b3;
            fcn.1802154a0(uVar1);
            uVar1 = puVar4[3];
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d4bc;
            fcn.1802154a0(uVar1);
            uVar1 = puVar4[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d4c5;
            fcn.1802154a0(uVar1);
            uVar1 = puVar4[2];
            *puVar4 = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d4d5;
            fcn.180215310(uVar1);
            uVar1 = puVar4[3];
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d4de;
            fcn.180215310(uVar1);
            uVar1 = puVar4[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d4e7;
            fcn.180215310(uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d4fc;
            fcn.180224990(puVar4, 0x1804be838, 0xc2);
            return (undefined8 *)0x0;
        }
    }
    return puVar4;
}

// ============================================================
// Function: FUN_18021d510
// Address: 0x18021d510
// Size: 117 bytes
// ============================================================
undefined8 fcn.18021d510(undefined8 *param_1)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021d51c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = param_1[2];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d52b;
    fcn.1802154a0(uVar1);
    uVar1 = param_1[3];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d534;
    fcn.1802154a0(uVar1);
    uVar1 = param_1[1];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d53d;
    fcn.1802154a0(uVar1);
    *param_1 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d54c;
    iVar2 = fcn.18021d9a0(param_1);
    if (iVar2 == 0) {
        uVar1 = param_1[2];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d559;
        fcn.1802154a0(uVar1);
        uVar1 = param_1[3];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d562;
        fcn.1802154a0(uVar1);
        uVar1 = param_1[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021d56b;
        fcn.1802154a0(uVar1);
        *param_1 = 0;
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_18021d590
// Address: 0x18021d590
// Size: 162 bytes
// ============================================================
void fcn.18021d590(int64_t arg_58h)
{
    undefined4 uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021d59e;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_58h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4);
    if (*in_RCX != 0) {
        iVar2 = in_RCX[1];
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021d5d2;
        iVar3 = func_0x0001802146d0(iVar2, (int64_t)&iStackX_20 + iVar4 + -8, (int64_t)&iStackX_10 + iVar4 + -8);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021d5e3;
            iVar3 = fcn.180214b00(*(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
            if (iVar3 != 0) {
                uVar1 = *(undefined4 *)((int64_t)&iStackX_10 + iVar4 + -8);
                iVar2 = in_RCX[1];
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021d5fa;
                iVar3 = func_0x0001802149b0(iVar2, (int64_t)&iStackX_20 + iVar4 + -8, uVar1);
                if (iVar3 != 0) {
                    iVar2 = in_RCX[1];
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021d60d;
                    func_0x0001802146d0(iVar2, in_RDX, in_R8);
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021d627;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_58h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_18021d640
// Address: 0x18021d640
// Size: 754 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18021d640(int64_t arg_28h)
{
    uint32_t *puVar1;
    uint32_t *puVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    bool bVar10;
    int32_t iVar11;
    uint32_t uVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t iVar15;
    int64_t *in_RCX;
    int64_t in_RDX;
    int64_t iVar16;
    int64_t iVar17;
    uint32_t in_R8D;
    int64_t in_R9;
    uint32_t uVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    uint32_t uVar21;
    uint32_t auStackX_10 [4];
    uint32_t auStackX_20 [2];
    int64_t var_e8h;
    uint32_t auStack_e0 [30];
    uint8_t auStack_68 [16];
    int64_t var_58h;
    undefined8 uStack_48;
    int64_t var_20h;
    int64_t var_10h;
    
    uStack_48 = 0x18021d65c;
    iVar13 = fcn.18045a350();
    iVar13 = -iVar13;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar13);
    iVar15 = 0;
    iVar17 = *in_RCX;
    bVar10 = false;
    if (in_R9 == 0) {
        if (iVar17 == 0) goto code_r0x00018021d912;
    } else {
        if ((in_R9 != iVar17) && ((in_RDX == 0 || ((int32_t)in_R8D < 0)))) goto code_r0x00018021d912;
        *in_RCX = in_R9;
        iVar17 = in_R9;
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar13) = 0x18021d6be;
    iVar11 = func_0x00018020fa50(iVar17);
    if (iVar11 != 0) goto code_r0x00018021d912;
    if (in_RDX == 0) {
code_r0x00018021d8d6:
        *(undefined8 *)((int64_t)&uStack_48 + iVar13) = 0x18021d8e3;
        fcn.180214b00(*(int64_t *)(&stack0xffffffffffffffe8 + iVar13), *(int64_t *)((int64_t)&var_10h + iVar13), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar13), 
                      *(int64_t *)((int64_t)auStackX_20 + iVar13 + -0x20));
        if (!bVar10) goto code_r0x00018021d912;
    } else {
        bVar10 = true;
        *(undefined8 *)((int64_t)&uStack_48 + iVar13) = 0x18021d6dd;
        uVar12 = func_0x00018020f7a0(iVar17);
        if (0x90 < uVar12) goto code_r0x00018021d912;
        if ((int32_t)uVar12 < (int32_t)in_R8D) {
            iVar14 = in_RCX[1];
            *(undefined8 *)((int64_t)&uStack_48 + iVar13) = 0x18021d6fb;
            iVar11 = func_0x000180214880(iVar14, iVar17, arg_28h);
            if (iVar11 == 0) goto code_r0x00018021d912;
            iVar14 = in_RCX[1];
            *(undefined8 *)((int64_t)&uStack_48 + iVar13) = 0x18021d712;
            iVar11 = func_0x0001802149b0(iVar14, in_RDX, (int64_t)(int32_t)in_R8D);
            if (iVar11 == 0) goto code_r0x00018021d912;
            iVar14 = in_RCX[1];
            *(undefined8 *)((int64_t)&uStack_48 + iVar13) = 0x18021d72d;
            iVar11 = func_0x0001802146d0(iVar14, (int64_t)&var_10h + iVar13, (int64_t)&var_20h + iVar13);
            if (iVar11 == 0) goto code_r0x00018021d912;
            in_R8D = *(uint32_t *)((int64_t)&var_20h + iVar13);
        } else {
            if (0x90 < in_R8D) goto code_r0x00018021d912;
            *(undefined8 *)((int64_t)&uStack_48 + iVar13) = 0x18021d757;
            fcn.180498030((int64_t)&var_10h + iVar13, in_RDX, (int64_t)(int32_t)in_R8D);
            *(uint32_t *)((int64_t)&var_20h + iVar13) = in_R8D;
        }
        if (in_R8D != 0x90) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar13) = 0x18021d77d;
            fcn.1804986e0((int64_t)&var_10h + (uint64_t)in_R8D + iVar13, 0, 0x90 - in_R8D);
        }
        iVar16 = 0x80;
        iVar14 = iVar15;
        do {
            puVar1 = (uint32_t *)((int64_t)&var_10h + iVar14 + iVar13);
            uVar12 = puVar1[1];
            uVar3 = puVar1[2];
            uVar4 = puVar1[3];
            puVar2 = (uint32_t *)((int64_t)auStackX_20 + iVar14 + iVar13 + -0x20);
            uVar5 = *puVar2;
            uVar6 = puVar2[1];
            uVar7 = puVar2[2];
            uVar8 = puVar2[3];
            uVar18 = SUB164(*(undefined (*) [16])0x1804be850, 0);
            uVar19 = SUB164(*(undefined (*) [16])0x1804be850, 4);
            uVar20 = SUB164(*(undefined (*) [16])0x1804be850, 8);
            uVar21 = SUB164(*(undefined (*) [16])0x1804be850, 0xc);
            *(uint32_t *)((int64_t)auStack_e0 + iVar14 + -8) = *puVar1 ^ uVar18;
            *(uint32_t *)((int64_t)auStack_e0 + iVar14 + -4) = uVar12 ^ uVar19;
            *(uint32_t *)((int64_t)auStack_e0 + iVar14) = uVar3 ^ uVar20;
            *(uint32_t *)((int64_t)auStack_e0 + iVar14 + 4) = uVar4 ^ uVar21;
            puVar1 = (uint32_t *)((int64_t)auStackX_10 + iVar14 + iVar13);
            uVar12 = *puVar1;
            uVar3 = puVar1[1];
            uVar4 = puVar1[2];
            uVar9 = puVar1[3];
            *(uint32_t *)((int64_t)auStack_e0 + iVar14 + 8) = uVar5 ^ uVar18;
            *(uint32_t *)((int64_t)auStack_e0 + iVar14 + 0xc) = uVar6 ^ uVar19;
            *(uint32_t *)((int64_t)auStack_e0 + iVar14 + 0x10) = uVar7 ^ uVar20;
            *(uint32_t *)((int64_t)auStack_e0 + iVar14 + 0x14) = uVar8 ^ uVar21;
            puVar1 = (uint32_t *)((int64_t)auStackX_20 + iVar14 + iVar13);
            uVar5 = *puVar1;
            uVar6 = puVar1[1];
            uVar7 = puVar1[2];
            uVar8 = puVar1[3];
            *(uint32_t *)((int64_t)auStack_e0 + iVar14 + 0x18) = uVar12 ^ uVar18;
            *(uint32_t *)((int64_t)auStack_e0 + iVar14 + 0x1c) = uVar3 ^ uVar19;
            *(uint32_t *)((int64_t)auStack_e0 + iVar14 + 0x20) = uVar4 ^ uVar20;
            *(uint32_t *)((int64_t)auStack_e0 + iVar14 + 0x24) = uVar9 ^ uVar21;
            *(uint32_t *)((int64_t)auStack_e0 + iVar14 + 0x28) = uVar5 ^ uVar18;
            *(uint32_t *)((int64_t)auStack_e0 + iVar14 + 0x2c) = uVar6 ^ uVar19;
            *(uint32_t *)((int64_t)auStack_e0 + iVar14 + 0x30) = uVar7 ^ uVar20;
            *(uint32_t *)((int64_t)auStack_e0 + iVar14 + 0x34) = uVar8 ^ uVar21;
            iVar14 = iVar14 + 0x40;
        } while (iVar14 < 0x80);
        iVar14 = 0x80;
        do {
            *(uint8_t *)((int64_t)auStack_e0 + iVar14 + -8) = *(uint8_t *)((int64_t)&var_10h + iVar14 + iVar13) ^ 0x36;
            iVar14 = iVar14 + 1;
        } while (iVar14 < 0x90);
        iVar14 = in_RCX[2];
        *(undefined8 *)((int64_t)&uStack_48 + iVar13) = 0x18021d806;
        iVar11 = func_0x000180214880(iVar14, iVar17, arg_28h);
        if (iVar11 != 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar13) = 0x18021d816;
            iVar11 = func_0x00018020f7a0(iVar17);
            iVar14 = in_RCX[2];
            *(undefined8 *)((int64_t)&uStack_48 + iVar13) = 0x18021d826;
            iVar11 = func_0x0001802149b0(iVar14, &var_e8h, (int64_t)iVar11);
            if (iVar11 != 0) {
                do {
                    puVar1 = (uint32_t *)((int64_t)&var_10h + iVar15 + iVar13);
                    uVar12 = puVar1[1];
                    uVar3 = puVar1[2];
                    uVar4 = puVar1[3];
                    puVar2 = (uint32_t *)((int64_t)auStackX_20 + iVar15 + iVar13 + -0x20);
                    uVar5 = *puVar2;
                    uVar6 = puVar2[1];
                    uVar7 = puVar2[2];
                    uVar8 = puVar2[3];
                    uVar18 = SUB164(*(undefined (*) [16])0x1804be860, 0);
                    uVar19 = SUB164(*(undefined (*) [16])0x1804be860, 4);
                    uVar20 = SUB164(*(undefined (*) [16])0x1804be860, 8);
                    uVar21 = SUB164(*(undefined (*) [16])0x1804be860, 0xc);
                    *(uint32_t *)((int64_t)auStack_e0 + iVar15 + -8) = *puVar1 ^ uVar18;
                    *(uint32_t *)((int64_t)auStack_e0 + iVar15 + -4) = uVar12 ^ uVar19;
                    *(uint32_t *)((int64_t)auStack_e0 + iVar15) = uVar3 ^ uVar20;
                    *(uint32_t *)((int64_t)auStack_e0 + iVar15 + 4) = uVar4 ^ uVar21;
                    puVar1 = (uint32_t *)((int64_t)auStackX_10 + iVar15 + iVar13);
                    uVar12 = *puVar1;
                    uVar3 = puVar1[1];
                    uVar4 = puVar1[2];
                    uVar9 = puVar1[3];
                    *(uint32_t *)((int64_t)auStack_e0 + iVar15 + 8) = uVar5 ^ uVar18;
                    *(uint32_t *)((int64_t)auStack_e0 + iVar15 + 0xc) = uVar6 ^ uVar19;
                    *(uint32_t *)((int64_t)auStack_e0 + iVar15 + 0x10) = uVar7 ^ uVar20;
                    *(uint32_t *)((int64_t)auStack_e0 + iVar15 + 0x14) = uVar8 ^ uVar21;
                    puVar1 = (uint32_t *)((int64_t)auStackX_20 + iVar15 + iVar13);
                    uVar5 = *puVar1;
                    uVar6 = puVar1[1];
                    uVar7 = puVar1[2];
                    uVar8 = puVar1[3];
                    *(uint32_t *)((int64_t)auStack_e0 + iVar15 + 0x18) = uVar12 ^ uVar18;
                    *(uint32_t *)((int64_t)auStack_e0 + iVar15 + 0x1c) = uVar3 ^ uVar19;
                    *(uint32_t *)((int64_t)auStack_e0 + iVar15 + 0x20) = uVar4 ^ uVar20;
                    *(uint32_t *)((int64_t)auStack_e0 + iVar15 + 0x24) = uVar9 ^ uVar21;
                    *(uint32_t *)((int64_t)auStack_e0 + iVar15 + 0x28) = uVar5 ^ uVar18;
                    *(uint32_t *)((int64_t)auStack_e0 + iVar15 + 0x2c) = uVar6 ^ uVar19;
                    *(uint32_t *)((int64_t)auStack_e0 + iVar15 + 0x30) = uVar7 ^ uVar20;
                    *(uint32_t *)((int64_t)auStack_e0 + iVar15 + 0x34) = uVar8 ^ uVar21;
                    iVar15 = iVar15 + 0x40;
                } while (iVar15 < 0x80);
                do {
                    *(uint8_t *)((int64_t)auStack_e0 + iVar16 + -8) =
                         *(uint8_t *)((int64_t)&var_10h + iVar16 + iVar13) ^ 0x5c;
                    iVar16 = iVar16 + 1;
                } while (iVar16 < 0x90);
                iVar15 = in_RCX[3];
                *(undefined8 *)((int64_t)&uStack_48 + iVar13) = 0x18021d8b6;
                iVar11 = func_0x000180214880(iVar15, iVar17, arg_28h);
                if (iVar11 != 0) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar13) = 0x18021d8c2;
                    iVar11 = func_0x00018020f7a0(iVar17);
                    iVar17 = in_RCX[3];
                    *(undefined8 *)((int64_t)&uStack_48 + iVar13) = 0x18021d8d2;
                    iVar11 = func_0x0001802149b0(iVar17, &var_e8h, (int64_t)iVar11);
                    if (iVar11 != 0) goto code_r0x00018021d8d6;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar13) = 0x18021d8fd;
    fcn.180244fc0((int64_t)&var_10h + iVar13, 0x90);
    *(undefined8 *)((int64_t)&uStack_48 + iVar13) = 0x18021d90b;
    fcn.180244fc0(&var_e8h, 0x90);
code_r0x00018021d912:
    *(undefined8 *)((int64_t)&uStack_48 + iVar13) = 0x18021d91e;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar13));
    return;
}

// ============================================================
// Function: FUN_18021d940
// Address: 0x18021d940
// Size: 39 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018025c50f: Changing call to branch
// WARNING: Possible PIC construction at 0x00018025cdcc: Changing call to branch

uint64_t fcn.18021d940(int64_t arg_48h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_88h,
                      int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint32_t *puVar1;
    code *pcVar2;
    undefined8 uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int32_t *unaff_RBX;
    undefined *puVar10;
    undefined8 *puVar11;
    undefined8 *puVar12;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t unaff_RDI;
    int64_t in_R8;
    undefined8 unaff_R14;
    
    iVar7 = fcn.18045a350();
    if (*in_RCX == 0) {
        return 0;
    }
    iVar9 = in_RCX[1];
    puVar10 = &stack0x00000028 + -iVar7;
    while( true ) {
        *(undefined8 *)(puVar10 + -8) = 0x1802149ba;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        if (in_R8 == 0) {
            return 1;
        }
        if ((*(uint32_t *)(iVar9 + 0x18) >> 0xb & 1) != 0) break;
        puVar1 = *(uint32_t **)(iVar9 + 0x28);
        if (((puVar1 == (uint32_t *)0x0) || (uVar4 = *puVar1, (uVar4 & 0xc1f0) == 0)) ||
           (*(int64_t *)(puVar1 + 0xc) == 0)) {
            iVar8 = *(int64_t *)(iVar9 + 8);
            if (((iVar8 == 0) || (*(int64_t *)(iVar8 + 0x68) == 0)) || ((*(uint32_t *)(iVar9 + 0x18) >> 8 & 1) != 0)) {
                if (*(code **)(iVar9 + 0x30) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180214abd. Too many branches
    // WARNING: Treating indirect jump as call
                    uVar6 = (**(code **)(iVar9 + 0x30))();
                    return uVar6;
                }
                return 0;
            }
            if (*(code **)(iVar8 + 0x88) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180214aa6. Too many branches
    // WARNING: Treating indirect jump as call
                uVar6 = (**(code **)(iVar8 + 0x88))(*(undefined8 *)(iVar9 + 0x38), in_RDX);
                return uVar6;
            }
            *(undefined8 *)(puVar10 + iVar7 + -8) = 0x180214a8a;
            fcn.180229480(*(int64_t *)(puVar10 + iVar7 + 0x20), *(int64_t *)(puVar10 + iVar7 + 0x28));
            goto code_r0x0001802149eb;
        }
        if (uVar4 == 0x80) {
            *(int32_t **)(puVar10 + iVar7 + 0x38) = unaff_RBX;
            *(int64_t *)(puVar10 + iVar7 + 0x40) = unaff_RBP;
            *(int64_t *)(puVar10 + iVar7 + 0x48) = unaff_RSI;
            *(undefined8 *)(puVar10 + iVar7 + 0x20) = unaff_R14;
            *(undefined8 *)(puVar10 + iVar7 + 0x18) = 0x18025c35b;
            unaff_RBP = in_R8;
            iVar8 = fcn.18045a350();
            iVar8 = -iVar8;
            unaff_RBX = *(int32_t **)(iVar9 + 0x28);
            if ((*(uint32_t *)(iVar9 + 0x18) & 0x800) != 0) {
                *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025c379;
                fcn.180229480(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x40), *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x48)
                             );
                *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025c391;
                fcn.1802295a0(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x40), *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x48)
                              , *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x50), 
                              *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x58), *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x70)
                             );
                *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025c3a3;
                fcn.1802296d0(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x60));
                return 0;
            }
            *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x60) = unaff_RDI;
            if (unaff_RBX != (int32_t *)0x0) {
                if (((*unaff_RBX == 0x80) && (*(int64_t *)(unaff_RBX + 0xc) != 0)) &&
                   (unaff_RDI = *(int64_t *)(unaff_RBX + 10), unaff_RDI != 0)) {
                    iVar9 = 0x1805aadb1;
                    if (*(int64_t *)(unaff_RDI + 0x10) != 0) {
                        iVar9 = *(int64_t *)(unaff_RDI + 0x10);
                    }
                    if (*(int64_t *)(unaff_RDI + 0x98) != 0) {
                        *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025c440;
                        fcn.180229b10();
                        pcVar2 = *(code **)(unaff_RDI + 0x98);
                        uVar3 = *(undefined8 *)(unaff_RBX + 0xc);
                        *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025c453;
                        uVar4 = (*pcVar2)(uVar3, in_RDX, unaff_RBP);
                        if ((int32_t)uVar4 < 1) {
                            *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025c45e;
                            iVar5 = fcn.180229970();
                            if (iVar5 == 0) {
                                *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025c467;
                                fcn.180229480(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x40), 
                                              *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x48));
                                *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025c47f;
                                fcn.1802295a0(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x40), 
                                              *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x48), 
                                              *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x50), 
                                              *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x58), 
                                              *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x70));
                                *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x40) = iVar9;
                                *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025c49e;
                                fcn.1802296d0(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x60));
                            }
                        }
                        *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025c4a3;
                        fcn.180229900();
                        return (uint64_t)uVar4;
                    }
                    *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025c3fd;
                    fcn.180229480(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x40), 
                                  *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x48));
                    *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025c415;
                    fcn.1802295a0(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x40), 
                                  *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x48), 
                                  *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x50), 
                                  *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x58), 
                                  *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x70));
                    *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x40) = iVar9;
                    *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025c434;
                    fcn.1802296d0(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x60));
                    return 0;
                }
                if (*(int64_t *)(unaff_RBX + 0x1e) == 0) {
                    *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025c4b5;
                    fcn.180229480(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x40), 
                                  *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x48));
                    *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025c4cd;
                    fcn.1802295a0(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x40), 
                                  *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x48), 
                                  *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x50), 
                                  *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x58), 
                                  *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x70));
                    *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025c4df;
                    fcn.1802296d0(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x60));
                    return 0;
                }
                if ((*(uint8_t *)(unaff_RBX + 0x28) & 1) != 0) {
                    pcVar2 = *(code **)(*(int64_t *)(unaff_RBX + 0x1e) + 0xf8);
                    *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025c4fb;
                    iVar5 = (*pcVar2)(unaff_RBX, iVar9);
                    if (iVar5 == 0) {
                        return 0;
                    }
                }
                unaff_RBX[0x28] = unaff_RBX[0x28] & 0xfffffffe;
            }
            puVar11 = (undefined8 *)(puVar10 + iVar8 + iVar7 + 0x20 + -8);
            puVar10 = puVar10 + iVar8 + iVar7 + 0x20 + -8;
            *puVar11 = 0x18025c514;
            unaff_RSI = iVar9;
            in_R8 = unaff_RBP;
            unaff_R14 = in_RDX;
        } else {
            if (uVar4 != 0x100) {
                *(undefined8 *)(puVar10 + iVar7 + -8) = 0x180214a54;
                fcn.180229480(*(int64_t *)(puVar10 + iVar7 + 0x20), *(int64_t *)(puVar10 + iVar7 + 0x28));
                goto code_r0x0001802149eb;
            }
            *(int32_t **)(puVar10 + iVar7 + 0x38) = unaff_RBX;
            *(int64_t *)(puVar10 + iVar7 + 0x40) = unaff_RBP;
            *(int64_t *)(puVar10 + iVar7 + 0x48) = unaff_RSI;
            *(undefined8 *)(puVar10 + iVar7 + 0x20) = unaff_R14;
            *(undefined8 *)(puVar10 + iVar7 + 0x18) = 0x18025cc4b;
            unaff_RBP = in_R8;
            iVar8 = fcn.18045a350();
            iVar8 = -iVar8;
            unaff_RBX = *(int32_t **)(iVar9 + 0x28);
            if ((*(uint32_t *)(iVar9 + 0x18) & 0x800) != 0) {
                *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025cc69;
                fcn.180229480(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x40), *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x48)
                             );
                *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025cc81;
                fcn.1802295a0(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x40), *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x48)
                              , *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x50), 
                              *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x58), *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x70)
                             );
                *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025cc93;
                fcn.1802296d0(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x60));
                return 0;
            }
            *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x60) = unaff_RDI;
            if (unaff_RBX != (int32_t *)0x0) {
                if (((*unaff_RBX == 0x100) && (*(int64_t *)(unaff_RBX + 0xc) != 0)) &&
                   (unaff_RDI = *(int64_t *)(unaff_RBX + 10), unaff_RDI != 0)) {
                    iVar9 = 0x1805aadb1;
                    if (*(int64_t *)(unaff_RDI + 0x10) != 0) {
                        iVar9 = *(int64_t *)(unaff_RDI + 0x10);
                    }
                    if (*(int64_t *)(unaff_RDI + 0xb8) == 0) {
                        *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025cced;
                        fcn.180229480(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x40), 
                                      *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x48));
                        *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025cd05;
                        fcn.1802295a0(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x40), 
                                      *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x48), 
                                      *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x50), 
                                      *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x58), 
                                      *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x70));
                        *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x40) = iVar9;
                        *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025cd24;
                        fcn.1802296d0(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x60));
                        return 0;
                    }
                    *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025cd30;
                    fcn.180229b10();
                    pcVar2 = *(code **)(unaff_RDI + 0xb8);
                    uVar3 = *(undefined8 *)(unaff_RBX + 0xc);
                    *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025cd43;
                    uVar4 = (*pcVar2)(uVar3, in_RDX, unaff_RBP);
                    if ((int32_t)uVar4 < 1) {
                        *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025cd4e;
                        iVar5 = fcn.180229970();
                        if (iVar5 == 0) {
                            *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025cd57;
                            fcn.180229480(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x40), 
                                          *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x48));
                            *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025cd6f;
                            fcn.1802295a0(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x40), 
                                          *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x48), 
                                          *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x50), 
                                          *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x58), 
                                          *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x70));
                            *(int64_t *)(puVar10 + iVar8 + iVar7 + 0x40) = iVar9;
                            *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025cd8e;
                            fcn.1802296d0(*(int64_t *)(puVar10 + iVar8 + iVar7 + 0x60));
                        }
                    }
                    *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025cd93;
                    fcn.180229900();
                    return (uint64_t)uVar4;
                }
                if ((*(uint8_t *)(unaff_RBX + 0x28) & 1) != 0) {
                    pcVar2 = *(code **)(*(int64_t *)(unaff_RBX + 0x1e) + 0xf8);
                    *(undefined8 *)(puVar10 + iVar8 + iVar7 + 0x18) = 0x18025cdb4;
                    iVar5 = (*pcVar2)(unaff_RBX, iVar9);
                    if (iVar5 == 0) {
                        return 0;
                    }
                }
                unaff_RBX[0x28] = unaff_RBX[0x28] & 0xfffffffe;
            }
            puVar12 = (undefined8 *)(puVar10 + iVar8 + iVar7 + 0x20 + -8);
            puVar10 = puVar10 + iVar8 + iVar7 + 0x20 + -8;
            *puVar12 = 0x18025cdd1;
            unaff_RSI = iVar9;
            in_R8 = unaff_RBP;
            unaff_R14 = in_RDX;
        }
    }
    *(undefined8 *)(puVar10 + iVar7 + -8) = 0x1802149df;
    fcn.180229480(*(int64_t *)(puVar10 + iVar7 + 0x20), *(int64_t *)(puVar10 + iVar7 + 0x28));
code_r0x0001802149eb:
    *(undefined8 *)(puVar10 + iVar7 + -8) = 0x1802149f7;
    fcn.1802295a0(*(int64_t *)(puVar10 + iVar7 + 0x20), *(int64_t *)(puVar10 + iVar7 + 0x28), 
                  *(int64_t *)(puVar10 + iVar7 + 0x30), *(int64_t *)(puVar10 + iVar7 + 0x38), 
                  *(int64_t *)(puVar10 + iVar7 + 0x50));
    *(undefined8 *)(puVar10 + iVar7 + -8) = 0x180214a09;
    fcn.1802296d0(*(int64_t *)(puVar10 + iVar7 + 0x40));
    return 0;
}

// ============================================================
// Function: FUN_18021d970
// Address: 0x18021d970
// Size: 35 bytes
// ============================================================
int64_t fcn.18021d970(undefined8 *param_1)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021d97a;
    iVar3 = fcn.18045a350();
    uVar1 = *param_1;
    *(undefined8 *)((int64_t)&uStack_8 - iVar3) = 0x18021d985;
    iVar2 = fcn.18020f800(uVar1);
    if (iVar2 < 0) {
        iVar2 = 0;
    }
    return (int64_t)iVar2;
}

// ============================================================
// Function: FUN_18021d9a0
// Address: 0x18021d9a0
// Size: 107 bytes
// ============================================================
bool fcn.18021d9a0(int64_t param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021d9ac;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(int64_t *)(param_1 + 0x10) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021d9c0;
        iVar2 = func_0x000180215470();
        *(int64_t *)(param_1 + 0x10) = iVar2;
        if (iVar2 == 0) {
            return false;
        }
    }
    if (*(int64_t *)(param_1 + 0x18) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021d9d7;
        iVar2 = func_0x000180215470();
        *(int64_t *)(param_1 + 0x18) = iVar2;
        if (iVar2 == 0) {
            return false;
        }
    }
    iVar2 = *(int64_t *)(param_1 + 8);
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021d9ee;
        iVar2 = func_0x000180215470();
        *(int64_t *)(param_1 + 8) = iVar2;
    }
    return iVar2 != 0;
}

// ============================================================
// Function: FUN_18021da10
// Address: 0x18021da10
// Size: 30 bytes
// ============================================================
undefined8 fcn.18021da10(void)
{
    int64_t iVar1;
    undefined4 *puVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021da1a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x18021da22;
    puVar2 = (undefined4 *)fcn.1801dd170();
    *(undefined (*) [16])(puVar2 + 4) = ZEXT816(0);
    *(undefined (*) [16])(puVar2 + 8) = ZEXT816(0);
    *(undefined (*) [16])(puVar2 + 0xc) = ZEXT816(0);
    *(undefined (*) [16])(puVar2 + 0x10) = ZEXT816(0);
    *(undefined8 *)(puVar2 + 0x14) = 0;
    puVar2[0x16] = 0;
    *puVar2 = 0x67452301;
    puVar2[1] = 0xefcdab89;
    puVar2[2] = 0x98badcfe;
    puVar2[3] = 0x10325476;
    return 1;
}

// ============================================================
// Function: FUN_18021da30
// Address: 0x18021da30
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.18021da30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h)
{
    uint32_t *puVar1;
    undefined (*pauVar2) [16];
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t in_RDX;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar9;
    uint64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021da40;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021da4e;
    iVar4 = fcn.1801dd170();
    uVar9 = *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = *(undefined8 *)((int64_t)&arg_28h + iVar3);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = uVar9;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8) = unaff_R12;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + -8) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + -0x10) = 0x18028cff4;
    iVar5 = fcn.18045a350(iVar4, in_RDX);
    iVar5 = -iVar5;
    if (in_R8 != 0) {
        uVar6 = *(uint32_t *)(iVar4 + 0x10) + (int32_t)in_R8 * 8;
        if (uVar6 < *(uint32_t *)(iVar4 + 0x10)) {
            *(int32_t *)(iVar4 + 0x14) = *(int32_t *)(iVar4 + 0x14) + 1;
        }
        puVar1 = (uint32_t *)(iVar4 + 0x58);
        *(uint32_t *)(iVar4 + 0x10) = uVar6;
        uVar7 = (uint64_t)*puVar1;
        pauVar2 = (undefined (*) [16])(iVar4 + 0x18);
        *(int32_t *)(iVar4 + 0x14) = *(int32_t *)(iVar4 + 0x14) + (int32_t)(in_R8 >> 0x1d);
        if (uVar7 != 0) {
            if ((in_R8 < 0x40) && (uVar7 + in_R8 < 0x40)) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x18028d052;
                fcn.180498030(*pauVar2 + uVar7, in_RDX);
                *puVar1 = *puVar1 + (int32_t)in_R8;
                return 1;
            }
            iVar8 = 0x40 - uVar7;
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x18028d074;
            fcn.180498030(*pauVar2 + uVar7, in_RDX, iVar8);
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x18028d085;
            func_0x00018028d110(iVar4, pauVar2, 1);
            *puVar1 = 0;
            *pauVar2 = ZEXT816(0);
            in_RDX = in_RDX + iVar8;
            *(undefined (*) [16])(iVar4 + 0x28) = ZEXT816(0);
            in_R8 = in_R8 - iVar8;
            *(undefined (*) [16])(iVar4 + 0x38) = ZEXT816(0);
            *(undefined (*) [16])(iVar4 + 0x48) = ZEXT816(0);
        }
        if (in_R8 >> 6 != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x18028d0c1;
            func_0x00018028d110(iVar4, in_RDX, in_R8 >> 6);
            in_RDX = in_RDX + (in_R8 & 0xffffffffffffffc0);
            in_R8 = in_R8 - (in_R8 & 0xffffffffffffffc0);
        }
        if (in_R8 != 0) {
            *(int32_t *)(iVar4 + 0x58) = (int32_t)in_R8;
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x18028d0e3;
            fcn.180498030(pauVar2, in_RDX, in_R8);
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18021da70
// Address: 0x18021da70
// Size: 39 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_39h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ah
// WARNING: [rz-ghidra] Detected overlap for variable arg_3bh
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_3dh
// WARNING: [rz-ghidra] Detected overlap for variable arg_3eh
// WARNING: [rz-ghidra] Detected overlap for variable arg_3fh
// WARNING: [rz-ghidra] Detected overlap for variable arg_51h
// WARNING: [rz-ghidra] Detected overlap for variable arg_52h
// WARNING: [rz-ghidra] Detected overlap for variable arg_53h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_55h
// WARNING: [rz-ghidra] Detected overlap for variable arg_56h
// WARNING: [rz-ghidra] Detected overlap for variable arg_57h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

undefined8
fcn.18021da70(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined *in_RDX;
    uint64_t uVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021da7c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021da87;
    puVar4 = (undefined4 *)fcn.1801dd170();
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3) = 0x18028ce2a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar1 = puVar4 + 6;
    uVar6 = (uint64_t)(uint32_t)puVar4[0x16] + 1;
    *(undefined *)((uint64_t)(uint32_t)puVar4[0x16] + (int64_t)puVar1) = 0x80;
    if (0x38 < uVar6) {
        *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3) = 0x18028ce5c;
        fcn.1804986e0(uVar6 + (int64_t)puVar1, 0, 0x40 - uVar6);
        uVar6 = 0;
        *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3) = 0x18028ce6f;
        fcn.18028d110(*(int64_t *)((int64_t)&arg_38h + iVar5 + iVar3), *(int64_t *)(&stack0x00000040 + iVar5 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar5 + iVar3), *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar3), 
                      *(int64_t *)(&stack0x00000078 + iVar5 + iVar3), *(int64_t *)(&stack0x00000080 + iVar5 + iVar3), 
                      *(int64_t *)(&stack0x00000088 + iVar5 + iVar3), *(int64_t *)(&stack0x00000090 + iVar5 + iVar3));
    }
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3) = 0x18028ce83;
    fcn.1804986e0(uVar6 + (int64_t)puVar1, 0, 0x38 - uVar6);
    *(undefined *)(puVar4 + 0x14) = *(undefined *)(puVar4 + 4);
    *(undefined *)((int64_t)puVar4 + 0x51) = *(undefined *)((int64_t)puVar4 + 0x11);
    *(undefined *)((int64_t)puVar4 + 0x52) = *(undefined *)((int64_t)puVar4 + 0x12);
    *(undefined *)((int64_t)puVar4 + 0x53) = *(undefined *)((int64_t)puVar4 + 0x13);
    *(undefined *)(puVar4 + 0x15) = *(undefined *)(puVar4 + 5);
    *(undefined *)((int64_t)puVar4 + 0x55) = *(undefined *)((int64_t)puVar4 + 0x15);
    *(undefined *)((int64_t)puVar4 + 0x56) = *(undefined *)((int64_t)puVar4 + 0x16);
    *(undefined *)((int64_t)puVar4 + 0x57) = *(undefined *)((int64_t)puVar4 + 0x17);
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3) = 0x18028cecc;
    fcn.18028d110(*(int64_t *)((int64_t)&arg_38h + iVar5 + iVar3), *(int64_t *)(&stack0x00000040 + iVar5 + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar5 + iVar3), *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar3), 
                  *(int64_t *)(&stack0x00000078 + iVar5 + iVar3), *(int64_t *)(&stack0x00000080 + iVar5 + iVar3), 
                  *(int64_t *)(&stack0x00000088 + iVar5 + iVar3), *(int64_t *)(&stack0x00000090 + iVar5 + iVar3));
    puVar4[0x16] = 0;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3) = 0x18028cee0;
    fcn.180244fc0(puVar1, 0x40);
    uVar2 = *puVar4;
    *in_RDX = (char)uVar2;
    in_RDX[1] = (char)((uint32_t)uVar2 >> 8);
    in_RDX[2] = (char)((uint32_t)uVar2 >> 0x10);
    in_RDX[3] = (char)((uint32_t)uVar2 >> 0x18);
    uVar2 = puVar4[1];
    in_RDX[5] = (char)((uint32_t)uVar2 >> 8);
    in_RDX[4] = (char)uVar2;
    in_RDX[7] = (char)((uint32_t)uVar2 >> 0x18);
    in_RDX[6] = (char)((uint32_t)uVar2 >> 0x10);
    uVar2 = puVar4[2];
    in_RDX[8] = (char)uVar2;
    in_RDX[9] = (char)((uint32_t)uVar2 >> 8);
    in_RDX[0xb] = (char)((uint32_t)uVar2 >> 0x18);
    in_RDX[10] = (char)((uint32_t)uVar2 >> 0x10);
    uVar2 = puVar4[3];
    in_RDX[0xd] = (char)((uint32_t)uVar2 >> 8);
    in_RDX[0xc] = (char)uVar2;
    in_RDX[0xf] = (char)((uint32_t)uVar2 >> 0x18);
    in_RDX[0xe] = (char)((uint32_t)uVar2 >> 0x10);
    return 1;
}

// ============================================================
// Function: FUN_18021dab0
// Address: 0x18021dab0
// Size: 1597 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.18021dab0(int64_t arg1, int64_t arg2, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    int64_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    uint64_t in_R8;
    uint32_t uVar11;
    uint64_t uVar12;
    uint32_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_40;
    
    uStack_40 = 0x18021dad4;
    var_8h = arg1;
    var_10h = arg2;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar9 = 0;
    uVar12 = in_R8 & 0xffffffff;
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021daeb;
    puVar7 = (undefined8 *)func_0x000180201ea0();
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021daf6;
    iVar8 = func_0x00018021a8d0(arg1);
    if ((puVar7 != (undefined8 *)0x0) && (iVar8 != 0)) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021db18;
        func_0x000180219ce0(arg1, 0xf);
        if (*(int32_t *)(puVar7 + 2) != 1) {
            uVar2 = puVar7[4];
            *(undefined4 *)(puVar7 + 2) = 1;
            *puVar7 = 0;
            *(undefined4 *)(puVar7 + 1) = 0;
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021db35;
            func_0x00018028df70(uVar2);
        }
        iVar4 = *(int32_t *)((int64_t)puVar7 + 4);
        if (0x5dd < iVar4) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021db44;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021db5c;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6));
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021db6e;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
            return -1;
        }
        iVar10 = *(int32_t *)puVar7;
        if (0x5de < iVar10) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021db87;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021db9f;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6));
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dbb1;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
            return -1;
        }
        if (iVar10 < iVar4) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dbc4;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dbdc;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)&var_18h + iVar6));
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dbee;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
            return -1;
        }
        iVar10 = iVar10 - iVar4;
        if (0 < iVar10) {
            do {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dc15;
                iVar3 = func_0x00018021b2c0(iVar8, (int64_t)iVar4 + 0x28 + (int64_t)puVar7, iVar10);
                if (iVar3 < 1) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dd8a;
                    func_0x000180219cf0(arg1);
                    return iVar3;
                }
                iVar4 = *(int32_t *)((int64_t)puVar7 + 4) + iVar3;
                *(int32_t *)((int64_t)puVar7 + 4) = iVar4;
                if (0x5de < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dd4e;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dd66;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                  , *(int64_t *)((int64_t)&var_18h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dd78;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                    return -1;
                }
                if (*(int32_t *)puVar7 < iVar4) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dd15;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dd2d;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                  , *(int64_t *)((int64_t)&var_18h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dd3f;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                    return -1;
                }
                iVar10 = iVar10 - iVar3;
            } while (0 < iVar10);
            arg2 = *(int64_t *)((int64_t)&arg_40h + iVar6);
        }
        *puVar7 = 0;
        if ((arg2 != 0) && (0 < (int32_t)in_R8)) {
            do {
                puVar1 = puVar7 + 5;
                uVar11 = (uint32_t)uVar12;
                uVar13 = uVar11;
                if (0x400 < uVar11) {
                    uVar13 = 0x400;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dc80;
                uVar5 = func_0x00018021b270(*(undefined8 *)((int64_t)&arg_38h + iVar6), 0xffffffff);
                if ((uVar5 >> 8 & 1) == 0) {
                    uVar2 = puVar7[4];
                    *(uint32_t *)(&stack0xffffffffffffffe8 + iVar6) = uVar13;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021de23;
                    iVar4 = func_0x00018028df80(uVar2, puVar1, puVar7, arg2);
                    if (iVar4 == 0) {
code_r0x00018021df6d:
                        if (iVar9 != 0) {
                            return iVar9;
                        }
                        return -1;
                    }
                    iVar4 = *(int32_t *)puVar7;
                    if (0x5de < iVar4) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e09f;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e0b7;
                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e0c9;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                        if (iVar9 != 0) {
                            return iVar9;
                        }
                        return -1;
                    }
                    if (iVar4 < *(int32_t *)((int64_t)puVar7 + 4)) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e066;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e07e;
                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e090;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                        if (iVar9 != 0) {
                            return iVar9;
                        }
                        return -1;
                    }
code_r0x00018021de42:
                    iVar9 = iVar9 + uVar13;
                } else {
                    iVar4 = *(int32_t *)(puVar7 + 1);
                    if (iVar4 < 1) {
                        if (uVar13 < 3) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dfc8;
                            fcn.180498030((int64_t)puVar7 + 0x606, arg2, (int64_t)(int32_t)uVar13);
                            *(uint32_t *)(puVar7 + 1) = uVar13;
                            return iVar9 + uVar13;
                        }
                        uVar13 = ((int32_t)uVar13 / 3 + ((int32_t)uVar13 >> 0x1f) +
                                 (int32_t)(((int64_t)(int32_t)uVar13 / 3 + ((int64_t)(int32_t)uVar13 >> 0x3f) &
                                           0xffffffffU) >> 0x1f)) * 3;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021ddbc;
                        iVar4 = func_0x00018028dec0(puVar1, arg2, uVar13);
                        *(int32_t *)puVar7 = iVar4;
                        if (0x5de < iVar4) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021df7f;
                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021df97;
                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)(&stack0x00000000 + iVar6), 
                                          *(int64_t *)((int64_t)&var_18h + iVar6));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dfa9;
                            fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                            if (iVar9 != 0) {
                                return iVar9;
                            }
                            return -1;
                        }
                        if (iVar4 < *(int32_t *)((int64_t)puVar7 + 4)) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021ddd5;
                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dded;
                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)(&stack0x00000000 + iVar6), 
                                          *(int64_t *)((int64_t)&var_18h + iVar6));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021ddff;
                            fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                            if (iVar9 != 0) {
                                return iVar9;
                            }
                            return -1;
                        }
                        goto code_r0x00018021de42;
                    }
                    if (3 < iVar4) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021df43;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021df5b;
                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021df6d;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                        goto code_r0x00018021df6d;
                    }
                    uVar13 = uVar11;
                    if ((int32_t)(3U - iVar4) <= (int32_t)uVar11) {
                        uVar13 = 3U - iVar4;
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dcc5;
                    fcn.180498030((int64_t)iVar4 + 0x606 + (int64_t)puVar7, arg2, (int64_t)(int32_t)uVar13);
                    iVar4 = *(int32_t *)(puVar7 + 1);
                    iVar9 = iVar9 + uVar13;
                    *(uint32_t *)(puVar7 + 1) = iVar4 + uVar13;
                    if ((int32_t)(iVar4 + uVar13) < 3) {
                        return iVar9;
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dcec;
                    iVar4 = func_0x00018028dec0(puVar1, (int64_t)puVar7 + 0x606);
                    *(int32_t *)puVar7 = iVar4;
                    if (0x5de < iVar4) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021df07;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021df1f;
                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021df31;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                        if (iVar9 != 0) {
                            return iVar9;
                        }
                        return -1;
                    }
                    if (iVar4 < *(int32_t *)((int64_t)puVar7 + 4)) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021decb;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dee3;
                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_18h + iVar6));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021def5;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                        if (iVar9 != 0) {
                            return iVar9;
                        }
                        return -1;
                    }
                    *(undefined4 *)(puVar7 + 1) = 0;
                }
                uVar12 = (uint64_t)(uVar11 - uVar13);
                arg2 = arg2 + (int32_t)uVar13;
                iVar10 = 0;
                *(int64_t *)((int64_t)&arg_40h + iVar6) = arg2;
                *(undefined4 *)((int64_t)puVar7 + 4) = 0;
                if (0 < iVar4) {
                    do {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021de85;
                        iVar10 = func_0x00018021b2c0(iVar8, (int64_t)iVar10 + 0x28 + (int64_t)puVar7, iVar4);
                        if (iVar10 < 1) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e058;
                            func_0x000180219cf0(*(undefined8 *)((int64_t)&arg_38h + iVar6));
                            if (iVar9 != 0) {
                                return iVar9;
                            }
                            return iVar10;
                        }
                        iVar4 = iVar4 - iVar10;
                        iVar10 = *(int32_t *)((int64_t)puVar7 + 4) + iVar10;
                        *(int32_t *)((int64_t)puVar7 + 4) = iVar10;
                        if (0x5de < iVar10) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e017;
                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e02f;
                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)(&stack0x00000000 + iVar6), 
                                          *(int64_t *)((int64_t)&var_18h + iVar6));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e041;
                            fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                            if (iVar9 != 0) {
                                return iVar9;
                            }
                            return -1;
                        }
                        if (*(int32_t *)puVar7 < iVar10) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dfdb;
                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021dff3;
                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)(&stack0x00000000 + iVar6), 
                                          *(int64_t *)((int64_t)&var_18h + iVar6));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e005;
                            fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                            if (iVar9 != 0) {
                                return iVar9;
                            }
                            return -1;
                        }
                    } while (0 < iVar4);
                    arg2 = *(int64_t *)((int64_t)&arg_40h + iVar6);
                }
                *puVar7 = 0;
                if ((int32_t)(uVar11 - uVar13) < 1) {
                    return iVar9;
                }
            } while( true );
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021e0f0
// Address: 0x18021e0f0
// Size: 425 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

int32_t fcn.18021e0f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
                     int64_t arg_70h, int64_t arg_a0h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    int64_t iVar8;
    char *pcVar9;
    char *pcVar10;
    char *pcVar11;
    int32_t iVar12;
    undefined8 unaff_R13;
    char *pcVar13;
    int32_t iVar14;
    uint64_t uVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_40;
    int64_t var_38h;
    
    var_18h._0_4_ = (undefined4)arg3;
    uStack_40 = 0x18021e113;
    var_8h = arg1;
    var_10h = arg2;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar15 = arg3 & 0xffffffff;
    *(undefined4 *)((int64_t)&arg_70h + iVar6) = 0;
    iVar3 = 0;
    if (arg2 != 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e13b;
        puVar7 = (undefined8 *)func_0x000180201ea0();
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e146;
        iVar8 = func_0x00018021a8d0(arg1);
        *(int64_t *)(&stack0x00000000 + iVar6) = iVar8;
        if ((puVar7 != (undefined8 *)0x0) && (iVar8 != 0)) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e16d;
            func_0x000180219ce0(arg1, 0xf);
            if (*(int32_t *)(puVar7 + 2) != 2) {
                uVar1 = puVar7[4];
                *(undefined4 *)(puVar7 + 2) = 2;
                *puVar7 = 0;
                *(undefined4 *)(puVar7 + 1) = 0;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e18a;
                func_0x00018028dc60(uVar1);
            }
            iVar12 = *(int32_t *)puVar7;
            if (0 < iVar12) {
                iVar14 = *(int32_t *)((int64_t)puVar7 + 4);
                if (iVar12 < iVar14) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e1a1;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e1b9;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                  , *(int64_t *)((int64_t)&var_18h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e1cb;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                    return -1;
                }
                iVar2 = (int32_t)arg3;
                iVar3 = iVar12 - iVar14;
                if (iVar2 < iVar12 - iVar14) {
                    iVar3 = iVar2;
                }
                *(int32_t *)((int64_t)&arg_70h + iVar6) = iVar3;
                if (0x5dd < iVar14 + iVar3) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e200;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e218;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                  , *(int64_t *)((int64_t)&var_18h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e22a;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                    return -1;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e253;
                fcn.180498030(arg2, (int64_t)iVar14 + 0x28 + (int64_t)puVar7, (int64_t)iVar3);
                *(int32_t *)((int64_t)puVar7 + 4) = *(int32_t *)((int64_t)puVar7 + 4) + iVar3;
                iVar12 = *(int32_t *)((int64_t)puVar7 + 4);
                uVar15 = (uint64_t)(uint32_t)(iVar2 - iVar3);
                *(int64_t *)((int64_t)&arg_60h + iVar6) = arg2 + iVar3;
                iVar8 = *(int64_t *)(&stack0x00000000 + iVar6);
                *(int32_t *)((int64_t)&arg_68h + iVar6) = iVar2 - iVar3;
                if (*(int32_t *)puVar7 == iVar12) {
                    *puVar7 = 0;
                }
            }
            iVar12 = *(int32_t *)(puVar7 + 3);
            if (-1 < *(int32_t *)(puVar7 + 3)) {
                iVar12 = 0;
            }
            if (0 < (int32_t)uVar15) {
                *(undefined8 *)((int64_t)&var_10h + iVar6) = unaff_R13;
                while( true ) {
                    iVar14 = (int32_t)uVar15;
                    iVar3 = *(int32_t *)(puVar7 + 3);
                    if (iVar3 < 1) break;
                    iVar2 = *(int32_t *)(puVar7 + 1);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e2cf;
                    iVar2 = func_0x00018021ac80(iVar8, (int64_t)iVar2 + 0x606 + (int64_t)puVar7, 0x400 - iVar2);
                    if (iVar2 < 1) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e2e7;
                        iVar3 = func_0x00018021b270(*(undefined8 *)(&stack0x00000000 + iVar6), 8);
                        iVar12 = iVar2;
                        if (iVar3 == 0) {
                            if (*(int32_t *)(puVar7 + 1) == 0) {
                                uVar1 = puVar7[4];
                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e300;
                                iVar3 = func_0x00018028dbf0(uVar1, 0, &stack0xfffffffffffffff8 + iVar6);
                                uVar1 = puVar7[4];
                                if (iVar3 < 0) {
                                    iVar12 = -1;
                                }
                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e30f;
                                func_0x00018028dc60(uVar1);
                            }
                            *(int32_t *)(puVar7 + 3) = iVar12;
                        }
                        if (*(int32_t *)(puVar7 + 1) == 0) break;
                        iVar3 = 0;
                        iVar2 = iVar3;
                    }
                    iVar2 = iVar2 + *(int32_t *)(puVar7 + 1);
                    *(int32_t *)(puVar7 + 1) = iVar2;
                    if (*(int32_t *)((int64_t)puVar7 + 0x14) == 0) {
code_r0x00018021e4a8:
                        if ((0x3ff < iVar2) || (iVar3 < 1)) {
code_r0x00018021e4b5:
                            uVar1 = puVar7[4];
                            *(int32_t *)(&stack0xffffffffffffffe8 + iVar6) = iVar2;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e4d0;
                            iVar3 = func_0x00018028dc70(uVar1, puVar7 + 5, puVar7);
                            *(int32_t *)(puVar7 + 3) = iVar3;
                            *(undefined8 *)((int64_t)puVar7 + 4) = 0;
                            if (-1 < iVar3) {
                                iVar8 = *(int64_t *)((int64_t)&arg_60h + iVar6);
                                iVar3 = iVar14;
                                if (*(int32_t *)puVar7 <= iVar14) {
                                    iVar3 = *(int32_t *)puVar7;
                                }
                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e500;
                                fcn.180498030(iVar8, puVar7 + 5, (int64_t)iVar3);
                                *(int32_t *)((int64_t)&arg_70h + iVar6) =
                                     *(int32_t *)((int64_t)&arg_70h + iVar6) + iVar3;
                                *(int32_t *)((int64_t)puVar7 + 4) = iVar3;
                                if (iVar3 == *(int32_t *)puVar7) {
                                    *puVar7 = 0;
                                }
                                uVar4 = iVar14 - iVar3;
                                *(uint32_t *)((int64_t)&arg_68h + iVar6) = uVar4;
                                *(int64_t *)((int64_t)&arg_60h + iVar6) = iVar8 + iVar3;
                                goto code_r0x00018021e527;
                            }
                            *(undefined4 *)puVar7 = 0;
                            iVar12 = iVar3;
                            if (*(int32_t *)((int64_t)puVar7 + 0x14) != 0) {
                                iVar12 = 0;
                            }
                            break;
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e345;
                        uVar4 = func_0x00018021b270(arg1, 0xffffffff);
                        if ((uVar4 >> 8 & 1) != 0) {
                            *(undefined4 *)(puVar7 + 1) = 0;
                            goto code_r0x00018021e4b5;
                        }
                        if (*(int32_t *)((int64_t)puVar7 + 0x14) == 0) goto code_r0x00018021e4a8;
                        iVar14 = 0;
                        pcVar11 = (char *)((int64_t)puVar7 + 0x606);
                        *(undefined4 *)(&stack0xfffffffffffffff8 + iVar6) = 0;
                        pcVar10 = pcVar11;
                        pcVar13 = pcVar11;
                        pcVar9 = pcVar11;
                        if (0 < iVar2) {
                            do {
                                pcVar13 = pcVar9 + 1;
                                pcVar10 = pcVar11;
                                if (*pcVar9 == '\n') {
                                    pcVar10 = pcVar13;
                                    if (*(int32_t *)((int64_t)puVar7 + 0xc) == 0) {
                                        uVar1 = puVar7[4];
                                        *(int32_t *)(&stack0xffffffffffffffe8 + iVar6) =
                                             (int32_t)pcVar13 - (int32_t)pcVar11;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e3b5;
                                        iVar5 = func_0x00018028dc70(uVar1, puVar7 + 5, &stack0xfffffffffffffff8 + iVar6)
                                        ;
                                        uVar1 = puVar7[4];
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e3c0;
                                        func_0x00018028dc60(uVar1);
                                        if ((0 < iVar5) || (*(int32_t *)(&stack0xfffffffffffffff8 + iVar6) != 0)) {
                                            *(undefined4 *)((int64_t)puVar7 + 0x14) = 0;
                                            pcVar10 = pcVar11;
                                            if (pcVar11 != (char *)((int64_t)puVar7 + 0x606)) {
                                                iVar2 = iVar2 + ((int32_t)puVar7 - (int32_t)pcVar11) + 0x606;
                                                iVar8 = (int64_t)iVar2;
                                                if (0 < iVar2) {
                                                    pcVar9 = pcVar11;
                                                    do {
                                                        pcVar9[(int64_t)puVar7 + (0x606 - (int64_t)pcVar11)] = *pcVar9;
                                                        pcVar9 = pcVar9 + 1;
                                                        iVar8 = iVar8 + -1;
                                                    } while (iVar8 != 0);
                                                }
                                            }
                                            break;
                                        }
                                    } else {
                                        *(undefined4 *)((int64_t)puVar7 + 0xc) = 0;
                                    }
                                }
                                iVar14 = iVar14 + 1;
                                pcVar11 = pcVar10;
                                pcVar9 = pcVar13;
                            } while (iVar14 < iVar2);
                        }
                        if (*(int32_t *)((int64_t)puVar7 + 0x14) == 0) {
                            iVar14 = *(int32_t *)((int64_t)&arg_68h + iVar6);
                            *(undefined4 *)(puVar7 + 1) = 0;
                            goto code_r0x00018021e4b5;
                        }
                        if (pcVar10 == (char *)((int64_t)puVar7 + 0x606)) {
                            if (iVar2 == 0x400) {
                                *(undefined4 *)((int64_t)puVar7 + 0xc) = 1;
code_r0x00018021e446:
                                *(undefined4 *)(puVar7 + 1) = 0;
                            }
                        } else {
                            if (pcVar10 == pcVar13) goto code_r0x00018021e446;
                            iVar14 = (int32_t)pcVar13 - (int32_t)pcVar10;
                            iVar8 = (int64_t)iVar14;
                            if (0 < iVar14) {
                                pcVar11 = pcVar10;
                                do {
                                    pcVar11[(int64_t)puVar7 + (0x606 - (int64_t)pcVar10)] = *pcVar11;
                                    pcVar11 = pcVar11 + 1;
                                    iVar8 = iVar8 + -1;
                                } while (iVar8 != 0);
                            }
                            *(int32_t *)(puVar7 + 1) = iVar14;
                        }
                        if (iVar3 < 1) break;
                        uVar4 = *(uint32_t *)((int64_t)&arg_68h + iVar6);
code_r0x00018021e527:
                        uVar15 = (uint64_t)uVar4;
                        arg1 = *(int64_t *)((int64_t)&arg_58h + iVar6);
                    }
                    if ((int32_t)uVar15 < 1) break;
                    iVar8 = *(int64_t *)(&stack0x00000000 + iVar6);
                }
                iVar3 = *(int32_t *)((int64_t)&arg_70h + iVar6);
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e563;
            func_0x000180219cf0(*(undefined8 *)((int64_t)&arg_58h + iVar6));
            if (iVar3 == 0) {
                iVar3 = iVar12;
            }
            return iVar3;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021e299
// Address: 0x18021e299
// Size: 701 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

int32_t fcn.18021e0f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
                     int64_t arg_70h, int64_t arg_a0h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    int64_t iVar8;
    char *pcVar9;
    char *pcVar10;
    char *pcVar11;
    int32_t iVar12;
    undefined8 unaff_R13;
    char *pcVar13;
    int32_t iVar14;
    uint64_t uVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_40;
    int64_t var_38h;
    
    var_18h._0_4_ = (undefined4)arg3;
    uStack_40 = 0x18021e113;
    var_8h = arg1;
    var_10h = arg2;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar15 = arg3 & 0xffffffff;
    *(undefined4 *)((int64_t)&arg_70h + iVar6) = 0;
    iVar3 = 0;
    if (arg2 != 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e13b;
        puVar7 = (undefined8 *)func_0x000180201ea0();
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e146;
        iVar8 = func_0x00018021a8d0(arg1);
        *(int64_t *)(&stack0x00000000 + iVar6) = iVar8;
        if ((puVar7 != (undefined8 *)0x0) && (iVar8 != 0)) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e16d;
            func_0x000180219ce0(arg1, 0xf);
            if (*(int32_t *)(puVar7 + 2) != 2) {
                uVar1 = puVar7[4];
                *(undefined4 *)(puVar7 + 2) = 2;
                *puVar7 = 0;
                *(undefined4 *)(puVar7 + 1) = 0;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e18a;
                func_0x00018028dc60(uVar1);
            }
            iVar12 = *(int32_t *)puVar7;
            if (0 < iVar12) {
                iVar14 = *(int32_t *)((int64_t)puVar7 + 4);
                if (iVar12 < iVar14) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e1a1;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e1b9;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                  , *(int64_t *)((int64_t)&var_18h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e1cb;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                    return -1;
                }
                iVar2 = (int32_t)arg3;
                iVar3 = iVar12 - iVar14;
                if (iVar2 < iVar12 - iVar14) {
                    iVar3 = iVar2;
                }
                *(int32_t *)((int64_t)&arg_70h + iVar6) = iVar3;
                if (0x5dd < iVar14 + iVar3) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e200;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e218;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                  , *(int64_t *)((int64_t)&var_18h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e22a;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                    return -1;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e253;
                fcn.180498030(arg2, (int64_t)iVar14 + 0x28 + (int64_t)puVar7, (int64_t)iVar3);
                *(int32_t *)((int64_t)puVar7 + 4) = *(int32_t *)((int64_t)puVar7 + 4) + iVar3;
                iVar12 = *(int32_t *)((int64_t)puVar7 + 4);
                uVar15 = (uint64_t)(uint32_t)(iVar2 - iVar3);
                *(int64_t *)((int64_t)&arg_60h + iVar6) = arg2 + iVar3;
                iVar8 = *(int64_t *)(&stack0x00000000 + iVar6);
                *(int32_t *)((int64_t)&arg_68h + iVar6) = iVar2 - iVar3;
                if (*(int32_t *)puVar7 == iVar12) {
                    *puVar7 = 0;
                }
            }
            iVar12 = *(int32_t *)(puVar7 + 3);
            if (-1 < *(int32_t *)(puVar7 + 3)) {
                iVar12 = 0;
            }
            if (0 < (int32_t)uVar15) {
                *(undefined8 *)((int64_t)&var_10h + iVar6) = unaff_R13;
                while( true ) {
                    iVar14 = (int32_t)uVar15;
                    iVar3 = *(int32_t *)(puVar7 + 3);
                    if (iVar3 < 1) break;
                    iVar2 = *(int32_t *)(puVar7 + 1);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e2cf;
                    iVar2 = func_0x00018021ac80(iVar8, (int64_t)iVar2 + 0x606 + (int64_t)puVar7, 0x400 - iVar2);
                    if (iVar2 < 1) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e2e7;
                        iVar3 = func_0x00018021b270(*(undefined8 *)(&stack0x00000000 + iVar6), 8);
                        iVar12 = iVar2;
                        if (iVar3 == 0) {
                            if (*(int32_t *)(puVar7 + 1) == 0) {
                                uVar1 = puVar7[4];
                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e300;
                                iVar3 = func_0x00018028dbf0(uVar1, 0, &stack0xfffffffffffffff8 + iVar6);
                                uVar1 = puVar7[4];
                                if (iVar3 < 0) {
                                    iVar12 = -1;
                                }
                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e30f;
                                func_0x00018028dc60(uVar1);
                            }
                            *(int32_t *)(puVar7 + 3) = iVar12;
                        }
                        if (*(int32_t *)(puVar7 + 1) == 0) break;
                        iVar3 = 0;
                        iVar2 = iVar3;
                    }
                    iVar2 = iVar2 + *(int32_t *)(puVar7 + 1);
                    *(int32_t *)(puVar7 + 1) = iVar2;
                    if (*(int32_t *)((int64_t)puVar7 + 0x14) == 0) {
code_r0x00018021e4a8:
                        if ((0x3ff < iVar2) || (iVar3 < 1)) {
code_r0x00018021e4b5:
                            uVar1 = puVar7[4];
                            *(int32_t *)(&stack0xffffffffffffffe8 + iVar6) = iVar2;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e4d0;
                            iVar3 = func_0x00018028dc70(uVar1, puVar7 + 5, puVar7);
                            *(int32_t *)(puVar7 + 3) = iVar3;
                            *(undefined8 *)((int64_t)puVar7 + 4) = 0;
                            if (-1 < iVar3) {
                                iVar8 = *(int64_t *)((int64_t)&arg_60h + iVar6);
                                iVar3 = iVar14;
                                if (*(int32_t *)puVar7 <= iVar14) {
                                    iVar3 = *(int32_t *)puVar7;
                                }
                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e500;
                                fcn.180498030(iVar8, puVar7 + 5, (int64_t)iVar3);
                                *(int32_t *)((int64_t)&arg_70h + iVar6) =
                                     *(int32_t *)((int64_t)&arg_70h + iVar6) + iVar3;
                                *(int32_t *)((int64_t)puVar7 + 4) = iVar3;
                                if (iVar3 == *(int32_t *)puVar7) {
                                    *puVar7 = 0;
                                }
                                uVar4 = iVar14 - iVar3;
                                *(uint32_t *)((int64_t)&arg_68h + iVar6) = uVar4;
                                *(int64_t *)((int64_t)&arg_60h + iVar6) = iVar8 + iVar3;
                                goto code_r0x00018021e527;
                            }
                            *(undefined4 *)puVar7 = 0;
                            iVar12 = iVar3;
                            if (*(int32_t *)((int64_t)puVar7 + 0x14) != 0) {
                                iVar12 = 0;
                            }
                            break;
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e345;
                        uVar4 = func_0x00018021b270(arg1, 0xffffffff);
                        if ((uVar4 >> 8 & 1) != 0) {
                            *(undefined4 *)(puVar7 + 1) = 0;
                            goto code_r0x00018021e4b5;
                        }
                        if (*(int32_t *)((int64_t)puVar7 + 0x14) == 0) goto code_r0x00018021e4a8;
                        iVar14 = 0;
                        pcVar11 = (char *)((int64_t)puVar7 + 0x606);
                        *(undefined4 *)(&stack0xfffffffffffffff8 + iVar6) = 0;
                        pcVar10 = pcVar11;
                        pcVar13 = pcVar11;
                        pcVar9 = pcVar11;
                        if (0 < iVar2) {
                            do {
                                pcVar13 = pcVar9 + 1;
                                pcVar10 = pcVar11;
                                if (*pcVar9 == '\n') {
                                    pcVar10 = pcVar13;
                                    if (*(int32_t *)((int64_t)puVar7 + 0xc) == 0) {
                                        uVar1 = puVar7[4];
                                        *(int32_t *)(&stack0xffffffffffffffe8 + iVar6) =
                                             (int32_t)pcVar13 - (int32_t)pcVar11;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e3b5;
                                        iVar5 = func_0x00018028dc70(uVar1, puVar7 + 5, &stack0xfffffffffffffff8 + iVar6)
                                        ;
                                        uVar1 = puVar7[4];
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e3c0;
                                        func_0x00018028dc60(uVar1);
                                        if ((0 < iVar5) || (*(int32_t *)(&stack0xfffffffffffffff8 + iVar6) != 0)) {
                                            *(undefined4 *)((int64_t)puVar7 + 0x14) = 0;
                                            pcVar10 = pcVar11;
                                            if (pcVar11 != (char *)((int64_t)puVar7 + 0x606)) {
                                                iVar2 = iVar2 + ((int32_t)puVar7 - (int32_t)pcVar11) + 0x606;
                                                iVar8 = (int64_t)iVar2;
                                                if (0 < iVar2) {
                                                    pcVar9 = pcVar11;
                                                    do {
                                                        pcVar9[(int64_t)puVar7 + (0x606 - (int64_t)pcVar11)] = *pcVar9;
                                                        pcVar9 = pcVar9 + 1;
                                                        iVar8 = iVar8 + -1;
                                                    } while (iVar8 != 0);
                                                }
                                            }
                                            break;
                                        }
                                    } else {
                                        *(undefined4 *)((int64_t)puVar7 + 0xc) = 0;
                                    }
                                }
                                iVar14 = iVar14 + 1;
                                pcVar11 = pcVar10;
                                pcVar9 = pcVar13;
                            } while (iVar14 < iVar2);
                        }
                        if (*(int32_t *)((int64_t)puVar7 + 0x14) == 0) {
                            iVar14 = *(int32_t *)((int64_t)&arg_68h + iVar6);
                            *(undefined4 *)(puVar7 + 1) = 0;
                            goto code_r0x00018021e4b5;
                        }
                        if (pcVar10 == (char *)((int64_t)puVar7 + 0x606)) {
                            if (iVar2 == 0x400) {
                                *(undefined4 *)((int64_t)puVar7 + 0xc) = 1;
code_r0x00018021e446:
                                *(undefined4 *)(puVar7 + 1) = 0;
                            }
                        } else {
                            if (pcVar10 == pcVar13) goto code_r0x00018021e446;
                            iVar14 = (int32_t)pcVar13 - (int32_t)pcVar10;
                            iVar8 = (int64_t)iVar14;
                            if (0 < iVar14) {
                                pcVar11 = pcVar10;
                                do {
                                    pcVar11[(int64_t)puVar7 + (0x606 - (int64_t)pcVar10)] = *pcVar11;
                                    pcVar11 = pcVar11 + 1;
                                    iVar8 = iVar8 + -1;
                                } while (iVar8 != 0);
                            }
                            *(int32_t *)(puVar7 + 1) = iVar14;
                        }
                        if (iVar3 < 1) break;
                        uVar4 = *(uint32_t *)((int64_t)&arg_68h + iVar6);
code_r0x00018021e527:
                        uVar15 = (uint64_t)uVar4;
                        arg1 = *(int64_t *)((int64_t)&arg_58h + iVar6);
                    }
                    if ((int32_t)uVar15 < 1) break;
                    iVar8 = *(int64_t *)(&stack0x00000000 + iVar6);
                }
                iVar3 = *(int32_t *)((int64_t)&arg_70h + iVar6);
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e563;
            func_0x000180219cf0(*(undefined8 *)((int64_t)&arg_58h + iVar6));
            if (iVar3 == 0) {
                iVar3 = iVar12;
            }
            return iVar3;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021e556
// Address: 0x18021e556
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

int32_t fcn.18021e0f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
                     int64_t arg_70h, int64_t arg_a0h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    int64_t iVar8;
    char *pcVar9;
    char *pcVar10;
    char *pcVar11;
    int32_t iVar12;
    undefined8 unaff_R13;
    char *pcVar13;
    int32_t iVar14;
    uint64_t uVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_40;
    int64_t var_38h;
    
    var_18h._0_4_ = (undefined4)arg3;
    uStack_40 = 0x18021e113;
    var_8h = arg1;
    var_10h = arg2;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar15 = arg3 & 0xffffffff;
    *(undefined4 *)((int64_t)&arg_70h + iVar6) = 0;
    iVar3 = 0;
    if (arg2 != 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e13b;
        puVar7 = (undefined8 *)func_0x000180201ea0();
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e146;
        iVar8 = func_0x00018021a8d0(arg1);
        *(int64_t *)(&stack0x00000000 + iVar6) = iVar8;
        if ((puVar7 != (undefined8 *)0x0) && (iVar8 != 0)) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e16d;
            func_0x000180219ce0(arg1, 0xf);
            if (*(int32_t *)(puVar7 + 2) != 2) {
                uVar1 = puVar7[4];
                *(undefined4 *)(puVar7 + 2) = 2;
                *puVar7 = 0;
                *(undefined4 *)(puVar7 + 1) = 0;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e18a;
                func_0x00018028dc60(uVar1);
            }
            iVar12 = *(int32_t *)puVar7;
            if (0 < iVar12) {
                iVar14 = *(int32_t *)((int64_t)puVar7 + 4);
                if (iVar12 < iVar14) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e1a1;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e1b9;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                  , *(int64_t *)((int64_t)&var_18h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e1cb;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                    return -1;
                }
                iVar2 = (int32_t)arg3;
                iVar3 = iVar12 - iVar14;
                if (iVar2 < iVar12 - iVar14) {
                    iVar3 = iVar2;
                }
                *(int32_t *)((int64_t)&arg_70h + iVar6) = iVar3;
                if (0x5dd < iVar14 + iVar3) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e200;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e218;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                  , *(int64_t *)((int64_t)&var_18h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e22a;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                    return -1;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e253;
                fcn.180498030(arg2, (int64_t)iVar14 + 0x28 + (int64_t)puVar7, (int64_t)iVar3);
                *(int32_t *)((int64_t)puVar7 + 4) = *(int32_t *)((int64_t)puVar7 + 4) + iVar3;
                iVar12 = *(int32_t *)((int64_t)puVar7 + 4);
                uVar15 = (uint64_t)(uint32_t)(iVar2 - iVar3);
                *(int64_t *)((int64_t)&arg_60h + iVar6) = arg2 + iVar3;
                iVar8 = *(int64_t *)(&stack0x00000000 + iVar6);
                *(int32_t *)((int64_t)&arg_68h + iVar6) = iVar2 - iVar3;
                if (*(int32_t *)puVar7 == iVar12) {
                    *puVar7 = 0;
                }
            }
            iVar12 = *(int32_t *)(puVar7 + 3);
            if (-1 < *(int32_t *)(puVar7 + 3)) {
                iVar12 = 0;
            }
            if (0 < (int32_t)uVar15) {
                *(undefined8 *)((int64_t)&var_10h + iVar6) = unaff_R13;
                while( true ) {
                    iVar14 = (int32_t)uVar15;
                    iVar3 = *(int32_t *)(puVar7 + 3);
                    if (iVar3 < 1) break;
                    iVar2 = *(int32_t *)(puVar7 + 1);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e2cf;
                    iVar2 = func_0x00018021ac80(iVar8, (int64_t)iVar2 + 0x606 + (int64_t)puVar7, 0x400 - iVar2);
                    if (iVar2 < 1) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e2e7;
                        iVar3 = func_0x00018021b270(*(undefined8 *)(&stack0x00000000 + iVar6), 8);
                        iVar12 = iVar2;
                        if (iVar3 == 0) {
                            if (*(int32_t *)(puVar7 + 1) == 0) {
                                uVar1 = puVar7[4];
                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e300;
                                iVar3 = func_0x00018028dbf0(uVar1, 0, &stack0xfffffffffffffff8 + iVar6);
                                uVar1 = puVar7[4];
                                if (iVar3 < 0) {
                                    iVar12 = -1;
                                }
                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e30f;
                                func_0x00018028dc60(uVar1);
                            }
                            *(int32_t *)(puVar7 + 3) = iVar12;
                        }
                        if (*(int32_t *)(puVar7 + 1) == 0) break;
                        iVar3 = 0;
                        iVar2 = iVar3;
                    }
                    iVar2 = iVar2 + *(int32_t *)(puVar7 + 1);
                    *(int32_t *)(puVar7 + 1) = iVar2;
                    if (*(int32_t *)((int64_t)puVar7 + 0x14) == 0) {
code_r0x00018021e4a8:
                        if ((0x3ff < iVar2) || (iVar3 < 1)) {
code_r0x00018021e4b5:
                            uVar1 = puVar7[4];
                            *(int32_t *)(&stack0xffffffffffffffe8 + iVar6) = iVar2;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e4d0;
                            iVar3 = func_0x00018028dc70(uVar1, puVar7 + 5, puVar7);
                            *(int32_t *)(puVar7 + 3) = iVar3;
                            *(undefined8 *)((int64_t)puVar7 + 4) = 0;
                            if (-1 < iVar3) {
                                iVar8 = *(int64_t *)((int64_t)&arg_60h + iVar6);
                                iVar3 = iVar14;
                                if (*(int32_t *)puVar7 <= iVar14) {
                                    iVar3 = *(int32_t *)puVar7;
                                }
                                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e500;
                                fcn.180498030(iVar8, puVar7 + 5, (int64_t)iVar3);
                                *(int32_t *)((int64_t)&arg_70h + iVar6) =
                                     *(int32_t *)((int64_t)&arg_70h + iVar6) + iVar3;
                                *(int32_t *)((int64_t)puVar7 + 4) = iVar3;
                                if (iVar3 == *(int32_t *)puVar7) {
                                    *puVar7 = 0;
                                }
                                uVar4 = iVar14 - iVar3;
                                *(uint32_t *)((int64_t)&arg_68h + iVar6) = uVar4;
                                *(int64_t *)((int64_t)&arg_60h + iVar6) = iVar8 + iVar3;
                                goto code_r0x00018021e527;
                            }
                            *(undefined4 *)puVar7 = 0;
                            iVar12 = iVar3;
                            if (*(int32_t *)((int64_t)puVar7 + 0x14) != 0) {
                                iVar12 = 0;
                            }
                            break;
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e345;
                        uVar4 = func_0x00018021b270(arg1, 0xffffffff);
                        if ((uVar4 >> 8 & 1) != 0) {
                            *(undefined4 *)(puVar7 + 1) = 0;
                            goto code_r0x00018021e4b5;
                        }
                        if (*(int32_t *)((int64_t)puVar7 + 0x14) == 0) goto code_r0x00018021e4a8;
                        iVar14 = 0;
                        pcVar11 = (char *)((int64_t)puVar7 + 0x606);
                        *(undefined4 *)(&stack0xfffffffffffffff8 + iVar6) = 0;
                        pcVar10 = pcVar11;
                        pcVar13 = pcVar11;
                        pcVar9 = pcVar11;
                        if (0 < iVar2) {
                            do {
                                pcVar13 = pcVar9 + 1;
                                pcVar10 = pcVar11;
                                if (*pcVar9 == '\n') {
                                    pcVar10 = pcVar13;
                                    if (*(int32_t *)((int64_t)puVar7 + 0xc) == 0) {
                                        uVar1 = puVar7[4];
                                        *(int32_t *)(&stack0xffffffffffffffe8 + iVar6) =
                                             (int32_t)pcVar13 - (int32_t)pcVar11;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e3b5;
                                        iVar5 = func_0x00018028dc70(uVar1, puVar7 + 5, &stack0xfffffffffffffff8 + iVar6)
                                        ;
                                        uVar1 = puVar7[4];
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e3c0;
                                        func_0x00018028dc60(uVar1);
                                        if ((0 < iVar5) || (*(int32_t *)(&stack0xfffffffffffffff8 + iVar6) != 0)) {
                                            *(undefined4 *)((int64_t)puVar7 + 0x14) = 0;
                                            pcVar10 = pcVar11;
                                            if (pcVar11 != (char *)((int64_t)puVar7 + 0x606)) {
                                                iVar2 = iVar2 + ((int32_t)puVar7 - (int32_t)pcVar11) + 0x606;
                                                iVar8 = (int64_t)iVar2;
                                                if (0 < iVar2) {
                                                    pcVar9 = pcVar11;
                                                    do {
                                                        pcVar9[(int64_t)puVar7 + (0x606 - (int64_t)pcVar11)] = *pcVar9;
                                                        pcVar9 = pcVar9 + 1;
                                                        iVar8 = iVar8 + -1;
                                                    } while (iVar8 != 0);
                                                }
                                            }
                                            break;
                                        }
                                    } else {
                                        *(undefined4 *)((int64_t)puVar7 + 0xc) = 0;
                                    }
                                }
                                iVar14 = iVar14 + 1;
                                pcVar11 = pcVar10;
                                pcVar9 = pcVar13;
                            } while (iVar14 < iVar2);
                        }
                        if (*(int32_t *)((int64_t)puVar7 + 0x14) == 0) {
                            iVar14 = *(int32_t *)((int64_t)&arg_68h + iVar6);
                            *(undefined4 *)(puVar7 + 1) = 0;
                            goto code_r0x00018021e4b5;
                        }
                        if (pcVar10 == (char *)((int64_t)puVar7 + 0x606)) {
                            if (iVar2 == 0x400) {
                                *(undefined4 *)((int64_t)puVar7 + 0xc) = 1;
code_r0x00018021e446:
                                *(undefined4 *)(puVar7 + 1) = 0;
                            }
                        } else {
                            if (pcVar10 == pcVar13) goto code_r0x00018021e446;
                            iVar14 = (int32_t)pcVar13 - (int32_t)pcVar10;
                            iVar8 = (int64_t)iVar14;
                            if (0 < iVar14) {
                                pcVar11 = pcVar10;
                                do {
                                    pcVar11[(int64_t)puVar7 + (0x606 - (int64_t)pcVar10)] = *pcVar11;
                                    pcVar11 = pcVar11 + 1;
                                    iVar8 = iVar8 + -1;
                                } while (iVar8 != 0);
                            }
                            *(int32_t *)(puVar7 + 1) = iVar14;
                        }
                        if (iVar3 < 1) break;
                        uVar4 = *(uint32_t *)((int64_t)&arg_68h + iVar6);
code_r0x00018021e527:
                        uVar15 = (uint64_t)uVar4;
                        arg1 = *(int64_t *)((int64_t)&arg_58h + iVar6);
                    }
                    if ((int32_t)uVar15 < 1) break;
                    iVar8 = *(int64_t *)(&stack0x00000000 + iVar6);
                }
                iVar3 = *(int32_t *)((int64_t)&arg_70h + iVar6);
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18021e563;
            func_0x000180219cf0(*(undefined8 *)((int64_t)&arg_58h + iVar6));
            if (iVar3 == 0) {
                iVar3 = iVar12;
            }
            return iVar3;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021e590
// Address: 0x18021e590
// Size: 81 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.18021e590(int64_t arg_28h)
{
    undefined8 *puVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    undefined8 in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    int32_t iVar10;
    undefined8 unaff_RSI;
    int32_t iVar11;
    undefined8 uVar12;
    uint32_t uVar13;
    uint64_t uVar14;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    uint32_t uVar15;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 auStack_20 [3];
    
    auStack_20[2] = 0x18021e5a0;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(undefined8 *)((int64_t)auStack_20 + iVar8 + 0x10) = 0x18021e5b1;
    uVar9 = fcn.180498cd0(in_RDX);
    if (0x7fffffff < uVar9) {
        return -1;
    }
    uVar9 = uVar9 & 0xffffffff;
    uVar12 = *(undefined8 *)((int64_t)aiStackX_10 + iVar8 + 8);
    *(undefined8 *)(&stack0x00000038 + iVar8) = *(undefined8 *)((int64_t)&arg_28h + iVar8);
    *(int64_t *)(&stack0x00000030 + iVar8) = in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar8) = in_RCX;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar8 + 8) = unaff_RBP;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar8) = unaff_RSI;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar8 + -8) = uVar12;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar8 + -0x10) = unaff_R12;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8) = unaff_R13;
    *(undefined8 *)((int64_t)auStack_20 + iVar8 + 0x10) = unaff_R14;
    *(undefined8 *)((int64_t)auStack_20 + iVar8 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_20 + iVar8) = 0x18021dad4;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar10 = 0;
    uVar14 = uVar9 & 0xffffffff;
    *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021daeb;
    puVar6 = (undefined8 *)func_0x000180201ea0();
    *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021daf6;
    iVar7 = func_0x00018021a8d0(in_RCX);
    if ((puVar6 != (undefined8 *)0x0) && (iVar7 != 0)) {
        *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021db18;
        func_0x000180219ce0(in_RCX, 0xf);
        if (*(int32_t *)(puVar6 + 2) != 1) {
            uVar12 = puVar6[4];
            *(undefined4 *)(puVar6 + 2) = 1;
            *puVar6 = 0;
            *(undefined4 *)(puVar6 + 1) = 0;
            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021db35;
            func_0x00018028df70(uVar12);
        }
        iVar3 = *(int32_t *)((int64_t)puVar6 + 4);
        if (0x5dd < iVar3) {
            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021db44;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8));
            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021db5c;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 0x10), 
                          *(int64_t *)(&stack0x00000038 + iVar5 + iVar8));
            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021db6e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar8));
            return -1;
        }
        iVar11 = *(int32_t *)puVar6;
        if (0x5de < iVar11) {
            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021db87;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8));
            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021db9f;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 0x10), 
                          *(int64_t *)(&stack0x00000038 + iVar5 + iVar8));
            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dbb1;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar8));
            return -1;
        }
        if (iVar11 < iVar3) {
            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dbc4;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8));
            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dbdc;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 0x10), 
                          *(int64_t *)(&stack0x00000038 + iVar5 + iVar8));
            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dbee;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar8));
            return -1;
        }
        iVar11 = iVar11 - iVar3;
        if (0 < iVar11) {
            do {
                *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dc15;
                iVar2 = func_0x00018021b2c0(iVar7, (int64_t)iVar3 + 0x28 + (int64_t)puVar6, iVar11);
                if (iVar2 < 1) {
                    *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dd8a;
                    func_0x000180219cf0(in_RCX);
                    return iVar2;
                }
                iVar3 = *(int32_t *)((int64_t)puVar6 + 4) + iVar2;
                *(int32_t *)((int64_t)puVar6 + 4) = iVar3;
                if (0x5de < iVar3) {
                    *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dd4e;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8));
                    *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dd66;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 0x10), 
                                  *(int64_t *)(&stack0x00000038 + iVar5 + iVar8));
                    *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dd78;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar8));
                    return -1;
                }
                if (*(int32_t *)puVar6 < iVar3) {
                    *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dd15;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8));
                    *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dd2d;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 0x10), 
                                  *(int64_t *)(&stack0x00000038 + iVar5 + iVar8));
                    *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dd3f;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar8));
                    return -1;
                }
                iVar11 = iVar11 - iVar2;
            } while (0 < iVar11);
            in_RDX = *(int64_t *)(&stack0x00000060 + iVar5 + iVar8);
        }
        *puVar6 = 0;
        if ((in_RDX != 0) && (0 < (int32_t)uVar9)) {
            do {
                puVar1 = puVar6 + 5;
                uVar13 = (uint32_t)uVar14;
                uVar15 = uVar13;
                if (0x400 < uVar13) {
                    uVar15 = 0x400;
                }
                *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dc80;
                uVar4 = func_0x00018021b270(*(undefined8 *)(&stack0x00000058 + iVar5 + iVar8), 0xffffffff);
                if ((uVar4 >> 8 & 1) == 0) {
                    uVar12 = puVar6[4];
                    *(uint32_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8) = uVar15;
                    *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021de23;
                    iVar3 = func_0x00018028df80(uVar12, puVar1, puVar6, in_RDX);
                    if (iVar3 == 0) {
code_r0x00018021df6d:
                        if (iVar10 != 0) {
                            return iVar10;
                        }
                        return -1;
                    }
                    iVar3 = *(int32_t *)puVar6;
                    if (0x5de < iVar3) {
                        *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021e09f;
                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8));
                        *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021e0b7;
                        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 0x10), 
                                      *(int64_t *)(&stack0x00000038 + iVar5 + iVar8));
                        *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021e0c9;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar8));
                        if (iVar10 != 0) {
                            return iVar10;
                        }
                        return -1;
                    }
                    if (iVar3 < *(int32_t *)((int64_t)puVar6 + 4)) {
                        *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021e066;
                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8));
                        *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021e07e;
                        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 0x10), 
                                      *(int64_t *)(&stack0x00000038 + iVar5 + iVar8));
                        *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021e090;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar8));
                        if (iVar10 != 0) {
                            return iVar10;
                        }
                        return -1;
                    }
code_r0x00018021de42:
                    iVar10 = iVar10 + uVar15;
                } else {
                    iVar3 = *(int32_t *)(puVar6 + 1);
                    if (iVar3 < 1) {
                        if (uVar15 < 3) {
                            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dfc8;
                            fcn.180498030((int64_t)puVar6 + 0x606, in_RDX, (int64_t)(int32_t)uVar15);
                            *(uint32_t *)(puVar6 + 1) = uVar15;
                            return iVar10 + uVar15;
                        }
                        uVar15 = ((int32_t)uVar15 / 3 + ((int32_t)uVar15 >> 0x1f) +
                                 (int32_t)(((int64_t)(int32_t)uVar15 / 3 + ((int64_t)(int32_t)uVar15 >> 0x3f) &
                                           0xffffffffU) >> 0x1f)) * 3;
                        *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021ddbc;
                        iVar3 = func_0x00018028dec0(puVar1, in_RDX, uVar15);
                        *(int32_t *)puVar6 = iVar3;
                        if (0x5de < iVar3) {
                            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021df7f;
                            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8));
                            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021df97;
                            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 0x10), 
                                          *(int64_t *)(&stack0x00000038 + iVar5 + iVar8));
                            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dfa9;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar8));
                            if (iVar10 != 0) {
                                return iVar10;
                            }
                            return -1;
                        }
                        if (iVar3 < *(int32_t *)((int64_t)puVar6 + 4)) {
                            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021ddd5;
                            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8));
                            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dded;
                            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 0x10), 
                                          *(int64_t *)(&stack0x00000038 + iVar5 + iVar8));
                            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021ddff;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar8));
                            if (iVar10 != 0) {
                                return iVar10;
                            }
                            return -1;
                        }
                        goto code_r0x00018021de42;
                    }
                    if (3 < iVar3) {
                        *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021df43;
                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8));
                        *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021df5b;
                        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 0x10), 
                                      *(int64_t *)(&stack0x00000038 + iVar5 + iVar8));
                        *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021df6d;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar8));
                        goto code_r0x00018021df6d;
                    }
                    uVar15 = uVar13;
                    if ((int32_t)(3U - iVar3) <= (int32_t)uVar13) {
                        uVar15 = 3U - iVar3;
                    }
                    *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dcc5;
                    fcn.180498030((int64_t)iVar3 + 0x606 + (int64_t)puVar6, in_RDX, (int64_t)(int32_t)uVar15);
                    iVar3 = *(int32_t *)(puVar6 + 1);
                    iVar10 = iVar10 + uVar15;
                    *(uint32_t *)(puVar6 + 1) = iVar3 + uVar15;
                    if ((int32_t)(iVar3 + uVar15) < 3) {
                        return iVar10;
                    }
                    *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dcec;
                    iVar3 = func_0x00018028dec0(puVar1, (int64_t)puVar6 + 0x606);
                    *(int32_t *)puVar6 = iVar3;
                    if (0x5de < iVar3) {
                        *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021df07;
                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8));
                        *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021df1f;
                        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 0x10), 
                                      *(int64_t *)(&stack0x00000038 + iVar5 + iVar8));
                        *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021df31;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar8));
                        if (iVar10 != 0) {
                            return iVar10;
                        }
                        return -1;
                    }
                    if (iVar3 < *(int32_t *)((int64_t)puVar6 + 4)) {
                        *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021decb;
                        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8));
                        *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dee3;
                        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 8), 
                                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 0x10), 
                                      *(int64_t *)(&stack0x00000038 + iVar5 + iVar8));
                        *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021def5;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar8));
                        if (iVar10 != 0) {
                            return iVar10;
                        }
                        return -1;
                    }
                    *(undefined4 *)(puVar6 + 1) = 0;
                }
                uVar14 = (uint64_t)(uVar13 - uVar15);
                in_RDX = in_RDX + (int32_t)uVar15;
                iVar11 = 0;
                *(int64_t *)(&stack0x00000060 + iVar5 + iVar8) = in_RDX;
                *(undefined4 *)((int64_t)puVar6 + 4) = 0;
                if (0 < iVar3) {
                    do {
                        *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021de85;
                        iVar11 = func_0x00018021b2c0(iVar7, (int64_t)iVar11 + 0x28 + (int64_t)puVar6, iVar3);
                        if (iVar11 < 1) {
                            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021e058;
                            func_0x000180219cf0(*(undefined8 *)(&stack0x00000058 + iVar5 + iVar8));
                            if (iVar10 != 0) {
                                return iVar10;
                            }
                            return iVar11;
                        }
                        iVar3 = iVar3 - iVar11;
                        iVar11 = *(int32_t *)((int64_t)puVar6 + 4) + iVar11;
                        *(int32_t *)((int64_t)puVar6 + 4) = iVar11;
                        if (0x5de < iVar11) {
                            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021e017;
                            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8));
                            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021e02f;
                            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 0x10), 
                                          *(int64_t *)(&stack0x00000038 + iVar5 + iVar8));
                            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021e041;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar8));
                            if (iVar10 != 0) {
                                return iVar10;
                            }
                            return -1;
                        }
                        if (*(int32_t *)puVar6 < iVar11) {
                            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dfdb;
                            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8));
                            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021dff3;
                            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + -8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 8), 
                                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + iVar8 + 0x10), 
                                          *(int64_t *)(&stack0x00000038 + iVar5 + iVar8));
                            *(undefined8 *)((int64_t)auStack_20 + iVar5 + iVar8) = 0x18021e005;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5 + iVar8));
                            if (iVar10 != 0) {
                                return iVar10;
                            }
                            return -1;
                        }
                    } while (0 < iVar3);
                    in_RDX = *(int64_t *)(&stack0x00000060 + iVar5 + iVar8);
                }
                *puVar6 = 0;
                if ((int32_t)(uVar13 - uVar15) < 1) {
                    return iVar10;
                }
            } while( true );
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021e5f0
// Address: 0x18021e5f0
// Size: 701 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.18021e5f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int32_t *piVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint64_t in_RDX;
    uint64_t uVar7;
    uint64_t in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021e614;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar7 = 1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021e62d;
    piVar5 = (int32_t *)func_0x000180201ea0();
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021e638;
    iVar6 = func_0x00018021a8d0(in_RCX);
    if ((piVar5 == (int32_t *)0x0) || (iVar6 == 0)) {
        return 0;
    }
    // switch table (101 cases) at 0x18021e824
    switch((int32_t)in_RDX) {
    case 1:
        piVar5[6] = 1;
        piVar5[5] = 1;
        piVar5[4] = 0;
        break;
    case 2:
        if (piVar5[6] < 1) {
            return 1;
        }
        break;
    case 10:
        if (*piVar5 < piVar5[1]) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021e712;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021e72a;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4));
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021e73c;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
            return 0xffffffff;
        }
        uVar2 = *piVar5 - piVar5[1];
code_r0x00018021e748:
        if (0 < (int32_t)uVar2) {
            return (uint64_t)uVar2;
        }
        break;
    case 0xb:
        while( true ) {
            while( true ) {
                if (*piVar5 != piVar5[1]) {
                    do {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021e76d;
                        uVar7 = fcn.18021dab0(in_RCX, 0, *(int64_t *)((int64_t)&var_18h + iVar4), 
                                              *(int64_t *)((int64_t)&var_20h + iVar4), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar4));
                        if ((int32_t)uVar7 < 0) {
                            return uVar7;
                        }
                    } while (*piVar5 != piVar5[1]);
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021e789;
                uVar2 = func_0x00018021b270(in_RCX, 0xffffffff);
                if ((uVar2 >> 8 & 1) == 0) break;
                if (piVar5[2] == 0) goto code_r0x00018021e7e4;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021e7a8;
                iVar3 = func_0x00018028dec0(piVar5 + 10);
                *piVar5 = iVar3;
                *(undefined8 *)(piVar5 + 1) = 0;
            }
            if (piVar5[4] == 0) break;
            uVar1 = *(undefined8 *)(piVar5 + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021e7be;
            iVar3 = func_0x000180203a00(uVar1);
            if (iVar3 == 0) break;
            uVar1 = *(undefined8 *)(piVar5 + 8);
            piVar5[1] = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021e7d5;
            func_0x00018028def0(uVar1, piVar5 + 10, piVar5);
        }
        goto code_r0x00018021e7e4;
    case 0xc:
        goto code_r0x00018021e805;
    case 0xd:
        if (*piVar5 < piVar5[1]) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021e6ae;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021e6c6;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4));
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021e6d8;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
            return 0xffffffff;
        }
        uVar2 = *piVar5 - piVar5[1];
        if (uVar2 != 0) goto code_r0x00018021e748;
        if (piVar5[4] != 0) {
            uVar1 = *(undefined8 *)(piVar5 + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021e6f4;
            iVar3 = func_0x000180203a00(uVar1);
            if (iVar3 != 0) {
                return 1;
            }
        }
        break;
    case 0x65:
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021e7e4;
        func_0x000180219ce0(in_RCX, 0xf);
code_r0x00018021e7e4:
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021e7f5;
        uVar2 = func_0x000180219d10(iVar6, in_RDX & 0xffffffff, in_R8 & 0xffffffff, in_R9);
        uVar7 = (uint64_t)uVar2;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021e7ff;
        func_0x000180219cf0(in_RCX);
        goto code_r0x00018021e805;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18021e68f;
    uVar2 = func_0x000180219d10(iVar6, in_RDX & 0xffffffff, in_R8 & 0xffffffff, in_R9);
    uVar7 = (uint64_t)uVar2;
code_r0x00018021e805:
    return uVar7;
}

// ============================================================
// Function: FUN_18021e8b0
// Address: 0x18021e8b0
// Size: 155 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18021e8b0(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021e8c0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021e8dd;
    iVar2 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (iVar2 != 0) {
        *(undefined4 *)(iVar2 + 0x18) = 1;
        *(undefined4 *)(iVar2 + 0x14) = 1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021e8f8;
        iVar3 = fcn.18028de90();
        *(int64_t *)(iVar2 + 0x20) = iVar3;
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021e92e;
            fcn.18021b240(in_RCX, iVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021e93b;
            fcn.18021b260(in_RCX, 1);
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18021e916;
        fcn.180224990(iVar2, 0x1804be9e0, 0x4d);
    }
    return 0;
}

// ============================================================
// Function: FUN_18021e950
// Address: 0x18021e950
// Size: 119 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18021e950(int64_t arg_28h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021e960;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021e970;
        iVar3 = fcn.180201ea0();
        if (iVar3 != 0) {
            uVar1 = *(undefined8 *)(iVar3 + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021e981;
            fcn.18028de60(uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021e996;
            fcn.180224990(iVar3, 0x1804be9e0, 99);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021e9a0;
            fcn.18021b240(in_RCX, 0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021e9aa;
            fcn.18021b260(in_RCX, 0);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021e9d0
// Address: 0x18021e9d0
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.18021e9d0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_68h,
             int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_c8h)
{
    code **ppcVar1;
    code *pcVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t in_EDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar7;
    undefined8 in_R8;
    int64_t var_8h;
    undefined8 uStackX_10;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021e9e0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18021e9ed;
    iVar6 = fcn.18021a8d0();
    if (iVar6 == 0) {
        return 0;
    }
    uVar7 = *(undefined8 *)((int64_t)&var_18h + iVar5);
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = in_R8;
    *(undefined8 *)((int64_t)&var_18h + iVar5) = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    *(undefined8 *)((int64_t)&uStackX_10 + iVar5) = 0x180219b60;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (iVar6 == 0) {
        return 0xfffffffe;
    }
    if (((*(int64_t *)(iVar6 + 8) == 0) || (*(int64_t *)(*(int64_t *)(iVar6 + 8) + 0x58) == 0)) || (in_EDX != 0xe)) {
        *(undefined8 *)((int64_t)&uStackX_10 + iVar3 + iVar5) = 0x180219caa;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar3 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_10 + iVar3 + iVar5) = 0x180219cc2;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar3 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar3 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar5), 
                      *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_10 + iVar3 + iVar5) = 0x180219cd4;
        fcn.1802296d0(*(int64_t *)(&stack0x00000058 + iVar3 + iVar5));
        return 0xfffffffe;
    }
    pcVar2 = *(code **)(iVar6 + 0x10);
    *(undefined8 *)((int64_t)&arg_68h + iVar3 + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_70h + iVar3 + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_80h + iVar3 + iVar5) = uVar7;
    ppcVar1 = (code **)(iVar6 + 0x18);
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) goto code_r0x000180219c1b;
        pcVar4 = *ppcVar1;
code_r0x000180219bc9:
        *(undefined8 *)((int64_t)&arg_50h + iVar3 + iVar5) = 0;
        *(undefined4 *)((int64_t)&arg_48h + iVar3 + iVar5) = 1;
        *(undefined4 *)((int64_t)&arg_40h + iVar3 + iVar5) = 0;
        *(undefined4 *)((int64_t)&arg_38h + iVar3 + iVar5) = 0xe;
        *(undefined8 *)((int64_t)&uStackX_10 + iVar3 + iVar5) = 0x180219bf1;
        uVar7 = (*pcVar4)();
    } else {
        pcVar4 = *(code **)(iVar6 + 0x18);
        if (pcVar4 != (code *)0x0) goto code_r0x000180219bc9;
        *(undefined4 *)((int64_t)&arg_40h + iVar3 + iVar5) = 1;
        *(undefined4 *)((int64_t)&arg_38h + iVar3 + iVar5) = 0;
        *(undefined8 *)((int64_t)&uStackX_10 + iVar3 + iVar5) = 0x180219c12;
        uVar7 = (*pcVar2)();
    }
    if ((int32_t)uVar7 < 1) {
        return uVar7;
    }
code_r0x000180219c1b:
    pcVar2 = *(code **)(*(int64_t *)(iVar6 + 8) + 0x58);
    *(undefined8 *)((int64_t)&uStackX_10 + iVar3 + iVar5) = 0x180219c2e;
    uVar7 = (*pcVar2)(iVar6, 0xe);
    pcVar2 = *(code **)(iVar6 + 0x10);
    if (pcVar2 == (code *)0x0) {
        if (*ppcVar1 == (code *)0x0) {
            return uVar7;
        }
        pcVar4 = *ppcVar1;
    } else {
        pcVar4 = *ppcVar1;
        if (pcVar4 == (code *)0x0) {
            *(int32_t *)((int64_t)&arg_40h + iVar3 + iVar5) = (int32_t)uVar7;
            *(undefined4 *)((int64_t)&arg_38h + iVar3 + iVar5) = 0;
            *(undefined8 *)((int64_t)&uStackX_10 + iVar3 + iVar5) = 0x180219ca3;
            uVar7 = (*pcVar2)(iVar6, 0x86, (int64_t)&arg_78h + iVar3 + iVar5, 0xe);
            return uVar7;
        }
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar3 + iVar5) = 0;
    *(int32_t *)((int64_t)&arg_48h + iVar3 + iVar5) = (int32_t)uVar7;
    *(undefined4 *)((int64_t)&arg_40h + iVar3 + iVar5) = 0;
    *(undefined4 *)((int64_t)&arg_38h + iVar3 + iVar5) = 0xe;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar3 + iVar5) = 0x180219c70;
    uVar7 = (*pcVar4)(iVar6, 0x86, (int64_t)&arg_78h + iVar3 + iVar5, 0);
    return uVar7;
}

// ============================================================
// Function: FUN_18021ea30
// Address: 0x18021ea30
// Size: 97 bytes
// ============================================================
undefined8 fcn.18021ea30(int64_t arg_28h, int64_t arg_30h, int64_t arg_70h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021ea3a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar1 = *(int64_t *)(in_RCX + 8);
    if (iVar1 == 0) {
        return 0xffffffff;
    }
    pcVar2 = *(code **)(iVar1 + 0x58);
    if (pcVar2 != (code *)0x0) {
        *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0;
        *(undefined8 *)((int64_t)&var_20h + iVar3) = *(undefined8 *)((int64_t)&arg_70h + iVar3);
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18021ea72;
        uVar4 = (*pcVar2)();
        return uVar4;
    }
    if (*(code **)(iVar1 + 0x28) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018021ea84. Too many branches
    // WARNING: Treating indirect jump as call
        uVar4 = (**(code **)(iVar1 + 0x28))();
        return uVar4;
    }
    return 1;
}

// ============================================================
// Function: FUN_18021eaa0
// Address: 0x18021eaa0
// Size: 74 bytes
// ============================================================
undefined8 fcn.18021eaa0(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    
    fcn.18045a350();
    iVar1 = *(int64_t *)(param_1 + 8);
    if (iVar1 == 0) {
        return 0xffffffff;
    }
    if (*(code **)(iVar1 + 0x58) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018021eacd. Too many branches
    // WARNING: Treating indirect jump as call
        uVar2 = (**(code **)(iVar1 + 0x58))();
        return uVar2;
    }
    if (*(code **)(iVar1 + 0x28) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018021eadd. Too many branches
    // WARNING: Treating indirect jump as call
        uVar2 = (**(code **)(iVar1 + 0x28))();
        return uVar2;
    }
    return 1;
}

// ============================================================
// Function: FUN_18021eb10
// Address: 0x18021eb10
// Size: 81 bytes
// ============================================================
void fcn.18021eb10(int32_t *param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 uVar6;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021eb1c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_1 != (int32_t *)0x0) {
        if (*param_1 == 1) {
            uVar6 = *(undefined8 *)(param_1 + 2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021eb47;
            func_0x00018021fe80(uVar6);
        } else if (*param_1 == 2) {
            uVar6 = *(undefined8 *)(param_1 + 2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021eb3c;
            func_0x00018028eb90(uVar6);
        }
    }
    uVar6 = *(undefined8 *)((int64_t)auStackX_18 + iVar3);
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x18022499a;
    iVar4 = fcn.18045a350(param_1, 0x1804bea28, 0x212);
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (param_1 != (int32_t *)0x0) {
            *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = uVar6;
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_18021eb70
// Address: 0x18021eb70
// Size: 57 bytes
// ============================================================
void fcn.18021eb70(void)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021eb7a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 + -iVar1) = 0x18021eb94;
    puVar2 = (undefined4 *)fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + -iVar1));
    if (puVar2 == (undefined4 *)0x0) {
        return;
    }
    *puVar2 = 0;
    return;
}

// ============================================================
// Function: FUN_18021ebb0
// Address: 0x18021ebb0
// Size: 54 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel

undefined8 fcn.18021ebb0(int32_t *param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18021ebbc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18021ebca;
    iVar1 = fcn.18021f850(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000110 + iVar2), 
                          *(int64_t *)(&stack0x00000158 + iVar2));
    if (iVar1 == -1) {
        return 0;
    }
    if (((param_1 != (int32_t *)0x0) && (-1 < iVar1)) && (iVar1 < *param_1)) {
        return *(undefined8 *)(*(int64_t *)(param_1 + 2) + (int64_t)iVar1 * 8);
    }
    return 0;
}

// ============================================================
// Function: FUN_18021ebf0
// Address: 0x18021ebf0
// Size: 137 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18021ebf0(int64_t arg_28h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021ec00;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX != (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021ec16;
        iVar2 = fcn.1802375f0(in_RDX);
        if (iVar2 != 0) {
            if (*in_RCX == 1) {
                uVar1 = *(undefined8 *)(in_RCX + 2);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021ec52;
                fcn.18021fe80(uVar1);
            } else if (*in_RCX == 2) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021ec2f;
                fcn.18028eb90(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
                *in_RCX = 1;
                *(undefined8 *)(in_RCX + 2) = in_RDX;
                return 1;
            }
            *in_RCX = 1;
            *(undefined8 *)(in_RCX + 2) = in_RDX;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021ec80
// Address: 0x18021ec80
// Size: 137 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18021ec80(int64_t arg_28h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t *in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18021ec90;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX != (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021eca6;
        iVar2 = fcn.18028ef00(in_RDX);
        if (iVar2 != 0) {
            if (*in_RCX == 1) {
                uVar1 = *(undefined8 *)(in_RCX + 2);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021ece2;
                fcn.18021fe80(uVar1);
            } else if (*in_RCX == 2) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021ecbf;
                fcn.18028eb90(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
                *in_RCX = 2;
                *(undefined8 *)(in_RCX + 2) = in_RDX;
                return 1;
            }
            *in_RCX = 2;
            *(undefined8 *)(in_RCX + 2) = in_RDX;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18021ed10
// Address: 0x18021ed10
// Size: 67 bytes
// ============================================================
void fcn.18021ed10(int64_t arg_28h, int64_t arg_70h, int64_t arg_198h, int64_t arg_1d8h, int64_t arg_1e0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021ed1f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_198h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5);
    iVar1 = *in_RCX;
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed47;
        func_0x000180221f20();
    } else {
        uVar2 = *(undefined8 *)(iVar1 + 0x98);
        *(undefined8 *)((int64_t)&arg_1e0h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed60;
        iVar3 = fcn.180222950(uVar2);
        if (iVar3 != 0) {
            uVar2 = *(undefined8 *)(iVar1 + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed71;
            func_0x0001802222d0(uVar2);
            uVar2 = *(undefined8 *)(iVar1 + 8);
            *(int64_t *)((int64_t)&var_18h + iVar5) = (int64_t)&arg_28h + iVar5;
            *(undefined4 *)((int64_t)&var_10h + iVar5) = 1;
            *(undefined8 *)((int64_t)&arg_70h + iVar5) = in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed9e;
            iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
            if (iVar3 < 0) {
                uVar2 = *(undefined8 *)(iVar1 + 0x98);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edb4;
                fcn.180222910(uVar2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edc7;
                iVar3 = func_0x00018021f5d0(in_RCX, 1, in_RDX, 0);
                if (iVar3 < 1) {
                    if (-1 < iVar3) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eddb;
                        func_0x000180221f20();
                    }
                    goto code_r0x00018021ee9a;
                }
                uVar2 = *(undefined8 *)(iVar1 + 0x98);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edef;
                iVar3 = fcn.180222950(uVar2);
                if (iVar3 == 0) goto code_r0x00018021ee9a;
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee00;
                func_0x0001802222d0(uVar2);
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(int64_t *)((int64_t)&var_18h + iVar5) = (int64_t)&arg_28h + iVar5;
                *(undefined4 *)((int64_t)&var_10h + iVar5) = 1;
                *(undefined8 *)((int64_t)&arg_70h + iVar5) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee2d;
                iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
            }
            *(undefined8 *)((int64_t)&arg_1d8h + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee3c;
            iVar6 = func_0x000180221f20();
            if (((-1 < iVar3) && (iVar6 != 0)) && (iVar8 = 0, 0 < *(int32_t *)((int64_t)&var_8h + iVar5))) {
                do {
                    uVar2 = *(undefined8 *)(iVar1 + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee5b;
                    iVar7 = fcn.180222340(uVar2, iVar3);
                    uVar2 = *(undefined8 *)(iVar7 + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee6d;
                    iVar4 = func_0x000180237a90(iVar6, uVar2, 1);
                    if (iVar4 == 0) {
                        uVar2 = *(undefined8 *)(iVar1 + 0x98);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eec2;
                        fcn.180222910(uVar2);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eeca;
                        func_0x000180238640(iVar6);
                        goto code_r0x00018021ee9a;
                    }
                    iVar8 = iVar8 + 1;
                    iVar3 = iVar3 + 1;
                } while (iVar8 < *(int32_t *)((int64_t)&var_8h + iVar5));
            }
            uVar2 = *(undefined8 *)(iVar1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee87;
            fcn.180222910(uVar2);
        }
    }
code_r0x00018021ee9a:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eeaa;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_198h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_18021ed53
// Address: 0x18021ed53
// Size: 220 bytes
// ============================================================
void fcn.18021ed10(int64_t arg_28h, int64_t arg_70h, int64_t arg_198h, int64_t arg_1d8h, int64_t arg_1e0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021ed1f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_198h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5);
    iVar1 = *in_RCX;
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed47;
        func_0x000180221f20();
    } else {
        uVar2 = *(undefined8 *)(iVar1 + 0x98);
        *(undefined8 *)((int64_t)&arg_1e0h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed60;
        iVar3 = fcn.180222950(uVar2);
        if (iVar3 != 0) {
            uVar2 = *(undefined8 *)(iVar1 + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed71;
            func_0x0001802222d0(uVar2);
            uVar2 = *(undefined8 *)(iVar1 + 8);
            *(int64_t *)((int64_t)&var_18h + iVar5) = (int64_t)&arg_28h + iVar5;
            *(undefined4 *)((int64_t)&var_10h + iVar5) = 1;
            *(undefined8 *)((int64_t)&arg_70h + iVar5) = in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed9e;
            iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
            if (iVar3 < 0) {
                uVar2 = *(undefined8 *)(iVar1 + 0x98);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edb4;
                fcn.180222910(uVar2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edc7;
                iVar3 = func_0x00018021f5d0(in_RCX, 1, in_RDX, 0);
                if (iVar3 < 1) {
                    if (-1 < iVar3) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eddb;
                        func_0x000180221f20();
                    }
                    goto code_r0x00018021ee9a;
                }
                uVar2 = *(undefined8 *)(iVar1 + 0x98);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edef;
                iVar3 = fcn.180222950(uVar2);
                if (iVar3 == 0) goto code_r0x00018021ee9a;
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee00;
                func_0x0001802222d0(uVar2);
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(int64_t *)((int64_t)&var_18h + iVar5) = (int64_t)&arg_28h + iVar5;
                *(undefined4 *)((int64_t)&var_10h + iVar5) = 1;
                *(undefined8 *)((int64_t)&arg_70h + iVar5) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee2d;
                iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
            }
            *(undefined8 *)((int64_t)&arg_1d8h + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee3c;
            iVar6 = func_0x000180221f20();
            if (((-1 < iVar3) && (iVar6 != 0)) && (iVar8 = 0, 0 < *(int32_t *)((int64_t)&var_8h + iVar5))) {
                do {
                    uVar2 = *(undefined8 *)(iVar1 + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee5b;
                    iVar7 = fcn.180222340(uVar2, iVar3);
                    uVar2 = *(undefined8 *)(iVar7 + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee6d;
                    iVar4 = func_0x000180237a90(iVar6, uVar2, 1);
                    if (iVar4 == 0) {
                        uVar2 = *(undefined8 *)(iVar1 + 0x98);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eec2;
                        fcn.180222910(uVar2);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eeca;
                        func_0x000180238640(iVar6);
                        goto code_r0x00018021ee9a;
                    }
                    iVar8 = iVar8 + 1;
                    iVar3 = iVar3 + 1;
                } while (iVar8 < *(int32_t *)((int64_t)&var_8h + iVar5));
            }
            uVar2 = *(undefined8 *)(iVar1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee87;
            fcn.180222910(uVar2);
        }
    }
code_r0x00018021ee9a:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eeaa;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_198h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_18021ee2f
// Address: 0x18021ee2f
// Size: 99 bytes
// ============================================================
void fcn.18021ed10(int64_t arg_28h, int64_t arg_70h, int64_t arg_198h, int64_t arg_1d8h, int64_t arg_1e0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021ed1f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_198h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5);
    iVar1 = *in_RCX;
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed47;
        func_0x000180221f20();
    } else {
        uVar2 = *(undefined8 *)(iVar1 + 0x98);
        *(undefined8 *)((int64_t)&arg_1e0h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed60;
        iVar3 = fcn.180222950(uVar2);
        if (iVar3 != 0) {
            uVar2 = *(undefined8 *)(iVar1 + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed71;
            func_0x0001802222d0(uVar2);
            uVar2 = *(undefined8 *)(iVar1 + 8);
            *(int64_t *)((int64_t)&var_18h + iVar5) = (int64_t)&arg_28h + iVar5;
            *(undefined4 *)((int64_t)&var_10h + iVar5) = 1;
            *(undefined8 *)((int64_t)&arg_70h + iVar5) = in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed9e;
            iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
            if (iVar3 < 0) {
                uVar2 = *(undefined8 *)(iVar1 + 0x98);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edb4;
                fcn.180222910(uVar2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edc7;
                iVar3 = func_0x00018021f5d0(in_RCX, 1, in_RDX, 0);
                if (iVar3 < 1) {
                    if (-1 < iVar3) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eddb;
                        func_0x000180221f20();
                    }
                    goto code_r0x00018021ee9a;
                }
                uVar2 = *(undefined8 *)(iVar1 + 0x98);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edef;
                iVar3 = fcn.180222950(uVar2);
                if (iVar3 == 0) goto code_r0x00018021ee9a;
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee00;
                func_0x0001802222d0(uVar2);
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(int64_t *)((int64_t)&var_18h + iVar5) = (int64_t)&arg_28h + iVar5;
                *(undefined4 *)((int64_t)&var_10h + iVar5) = 1;
                *(undefined8 *)((int64_t)&arg_70h + iVar5) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee2d;
                iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
            }
            *(undefined8 *)((int64_t)&arg_1d8h + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee3c;
            iVar6 = func_0x000180221f20();
            if (((-1 < iVar3) && (iVar6 != 0)) && (iVar8 = 0, 0 < *(int32_t *)((int64_t)&var_8h + iVar5))) {
                do {
                    uVar2 = *(undefined8 *)(iVar1 + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee5b;
                    iVar7 = fcn.180222340(uVar2, iVar3);
                    uVar2 = *(undefined8 *)(iVar7 + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee6d;
                    iVar4 = func_0x000180237a90(iVar6, uVar2, 1);
                    if (iVar4 == 0) {
                        uVar2 = *(undefined8 *)(iVar1 + 0x98);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eec2;
                        fcn.180222910(uVar2);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eeca;
                        func_0x000180238640(iVar6);
                        goto code_r0x00018021ee9a;
                    }
                    iVar8 = iVar8 + 1;
                    iVar3 = iVar3 + 1;
                } while (iVar8 < *(int32_t *)((int64_t)&var_8h + iVar5));
            }
            uVar2 = *(undefined8 *)(iVar1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee87;
            fcn.180222910(uVar2);
        }
    }
code_r0x00018021ee9a:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eeaa;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_198h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_18021ee92
// Address: 0x18021ee92
// Size: 8 bytes
// ============================================================
void fcn.18021ed10(int64_t arg_28h, int64_t arg_70h, int64_t arg_198h, int64_t arg_1d8h, int64_t arg_1e0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021ed1f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_198h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5);
    iVar1 = *in_RCX;
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed47;
        func_0x000180221f20();
    } else {
        uVar2 = *(undefined8 *)(iVar1 + 0x98);
        *(undefined8 *)((int64_t)&arg_1e0h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed60;
        iVar3 = fcn.180222950(uVar2);
        if (iVar3 != 0) {
            uVar2 = *(undefined8 *)(iVar1 + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed71;
            func_0x0001802222d0(uVar2);
            uVar2 = *(undefined8 *)(iVar1 + 8);
            *(int64_t *)((int64_t)&var_18h + iVar5) = (int64_t)&arg_28h + iVar5;
            *(undefined4 *)((int64_t)&var_10h + iVar5) = 1;
            *(undefined8 *)((int64_t)&arg_70h + iVar5) = in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed9e;
            iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
            if (iVar3 < 0) {
                uVar2 = *(undefined8 *)(iVar1 + 0x98);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edb4;
                fcn.180222910(uVar2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edc7;
                iVar3 = func_0x00018021f5d0(in_RCX, 1, in_RDX, 0);
                if (iVar3 < 1) {
                    if (-1 < iVar3) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eddb;
                        func_0x000180221f20();
                    }
                    goto code_r0x00018021ee9a;
                }
                uVar2 = *(undefined8 *)(iVar1 + 0x98);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edef;
                iVar3 = fcn.180222950(uVar2);
                if (iVar3 == 0) goto code_r0x00018021ee9a;
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee00;
                func_0x0001802222d0(uVar2);
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(int64_t *)((int64_t)&var_18h + iVar5) = (int64_t)&arg_28h + iVar5;
                *(undefined4 *)((int64_t)&var_10h + iVar5) = 1;
                *(undefined8 *)((int64_t)&arg_70h + iVar5) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee2d;
                iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
            }
            *(undefined8 *)((int64_t)&arg_1d8h + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee3c;
            iVar6 = func_0x000180221f20();
            if (((-1 < iVar3) && (iVar6 != 0)) && (iVar8 = 0, 0 < *(int32_t *)((int64_t)&var_8h + iVar5))) {
                do {
                    uVar2 = *(undefined8 *)(iVar1 + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee5b;
                    iVar7 = fcn.180222340(uVar2, iVar3);
                    uVar2 = *(undefined8 *)(iVar7 + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee6d;
                    iVar4 = func_0x000180237a90(iVar6, uVar2, 1);
                    if (iVar4 == 0) {
                        uVar2 = *(undefined8 *)(iVar1 + 0x98);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eec2;
                        fcn.180222910(uVar2);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eeca;
                        func_0x000180238640(iVar6);
                        goto code_r0x00018021ee9a;
                    }
                    iVar8 = iVar8 + 1;
                    iVar3 = iVar3 + 1;
                } while (iVar8 < *(int32_t *)((int64_t)&var_8h + iVar5));
            }
            uVar2 = *(undefined8 *)(iVar1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee87;
            fcn.180222910(uVar2);
        }
    }
code_r0x00018021ee9a:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eeaa;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_198h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_18021ee9a
// Address: 0x18021ee9a
// Size: 28 bytes
// ============================================================
void fcn.18021ed10(int64_t arg_28h, int64_t arg_70h, int64_t arg_198h, int64_t arg_1d8h, int64_t arg_1e0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021ed1f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_198h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5);
    iVar1 = *in_RCX;
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed47;
        func_0x000180221f20();
    } else {
        uVar2 = *(undefined8 *)(iVar1 + 0x98);
        *(undefined8 *)((int64_t)&arg_1e0h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed60;
        iVar3 = fcn.180222950(uVar2);
        if (iVar3 != 0) {
            uVar2 = *(undefined8 *)(iVar1 + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed71;
            func_0x0001802222d0(uVar2);
            uVar2 = *(undefined8 *)(iVar1 + 8);
            *(int64_t *)((int64_t)&var_18h + iVar5) = (int64_t)&arg_28h + iVar5;
            *(undefined4 *)((int64_t)&var_10h + iVar5) = 1;
            *(undefined8 *)((int64_t)&arg_70h + iVar5) = in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed9e;
            iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
            if (iVar3 < 0) {
                uVar2 = *(undefined8 *)(iVar1 + 0x98);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edb4;
                fcn.180222910(uVar2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edc7;
                iVar3 = func_0x00018021f5d0(in_RCX, 1, in_RDX, 0);
                if (iVar3 < 1) {
                    if (-1 < iVar3) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eddb;
                        func_0x000180221f20();
                    }
                    goto code_r0x00018021ee9a;
                }
                uVar2 = *(undefined8 *)(iVar1 + 0x98);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edef;
                iVar3 = fcn.180222950(uVar2);
                if (iVar3 == 0) goto code_r0x00018021ee9a;
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee00;
                func_0x0001802222d0(uVar2);
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(int64_t *)((int64_t)&var_18h + iVar5) = (int64_t)&arg_28h + iVar5;
                *(undefined4 *)((int64_t)&var_10h + iVar5) = 1;
                *(undefined8 *)((int64_t)&arg_70h + iVar5) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee2d;
                iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
            }
            *(undefined8 *)((int64_t)&arg_1d8h + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee3c;
            iVar6 = func_0x000180221f20();
            if (((-1 < iVar3) && (iVar6 != 0)) && (iVar8 = 0, 0 < *(int32_t *)((int64_t)&var_8h + iVar5))) {
                do {
                    uVar2 = *(undefined8 *)(iVar1 + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee5b;
                    iVar7 = fcn.180222340(uVar2, iVar3);
                    uVar2 = *(undefined8 *)(iVar7 + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee6d;
                    iVar4 = func_0x000180237a90(iVar6, uVar2, 1);
                    if (iVar4 == 0) {
                        uVar2 = *(undefined8 *)(iVar1 + 0x98);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eec2;
                        fcn.180222910(uVar2);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eeca;
                        func_0x000180238640(iVar6);
                        goto code_r0x00018021ee9a;
                    }
                    iVar8 = iVar8 + 1;
                    iVar3 = iVar3 + 1;
                } while (iVar8 < *(int32_t *)((int64_t)&var_8h + iVar5));
            }
            uVar2 = *(undefined8 *)(iVar1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee87;
            fcn.180222910(uVar2);
        }
    }
code_r0x00018021ee9a:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eeaa;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_198h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_18021eeb6
// Address: 0x18021eeb6
// Size: 24 bytes
// ============================================================
void fcn.18021ed10(int64_t arg_28h, int64_t arg_70h, int64_t arg_198h, int64_t arg_1d8h, int64_t arg_1e0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021ed1f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_198h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5);
    iVar1 = *in_RCX;
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed47;
        func_0x000180221f20();
    } else {
        uVar2 = *(undefined8 *)(iVar1 + 0x98);
        *(undefined8 *)((int64_t)&arg_1e0h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed60;
        iVar3 = fcn.180222950(uVar2);
        if (iVar3 != 0) {
            uVar2 = *(undefined8 *)(iVar1 + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed71;
            func_0x0001802222d0(uVar2);
            uVar2 = *(undefined8 *)(iVar1 + 8);
            *(int64_t *)((int64_t)&var_18h + iVar5) = (int64_t)&arg_28h + iVar5;
            *(undefined4 *)((int64_t)&var_10h + iVar5) = 1;
            *(undefined8 *)((int64_t)&arg_70h + iVar5) = in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed9e;
            iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
            if (iVar3 < 0) {
                uVar2 = *(undefined8 *)(iVar1 + 0x98);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edb4;
                fcn.180222910(uVar2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edc7;
                iVar3 = func_0x00018021f5d0(in_RCX, 1, in_RDX, 0);
                if (iVar3 < 1) {
                    if (-1 < iVar3) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eddb;
                        func_0x000180221f20();
                    }
                    goto code_r0x00018021ee9a;
                }
                uVar2 = *(undefined8 *)(iVar1 + 0x98);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edef;
                iVar3 = fcn.180222950(uVar2);
                if (iVar3 == 0) goto code_r0x00018021ee9a;
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee00;
                func_0x0001802222d0(uVar2);
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(int64_t *)((int64_t)&var_18h + iVar5) = (int64_t)&arg_28h + iVar5;
                *(undefined4 *)((int64_t)&var_10h + iVar5) = 1;
                *(undefined8 *)((int64_t)&arg_70h + iVar5) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee2d;
                iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
            }
            *(undefined8 *)((int64_t)&arg_1d8h + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee3c;
            iVar6 = func_0x000180221f20();
            if (((-1 < iVar3) && (iVar6 != 0)) && (iVar8 = 0, 0 < *(int32_t *)((int64_t)&var_8h + iVar5))) {
                do {
                    uVar2 = *(undefined8 *)(iVar1 + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee5b;
                    iVar7 = fcn.180222340(uVar2, iVar3);
                    uVar2 = *(undefined8 *)(iVar7 + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee6d;
                    iVar4 = func_0x000180237a90(iVar6, uVar2, 1);
                    if (iVar4 == 0) {
                        uVar2 = *(undefined8 *)(iVar1 + 0x98);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eec2;
                        fcn.180222910(uVar2);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eeca;
                        func_0x000180238640(iVar6);
                        goto code_r0x00018021ee9a;
                    }
                    iVar8 = iVar8 + 1;
                    iVar3 = iVar3 + 1;
                } while (iVar8 < *(int32_t *)((int64_t)&var_8h + iVar5));
            }
            uVar2 = *(undefined8 *)(iVar1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee87;
            fcn.180222910(uVar2);
        }
    }
code_r0x00018021ee9a:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eeaa;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_198h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_18021eece
// Address: 0x18021eece
// Size: 4 bytes
// ============================================================
void fcn.18021ed10(int64_t arg_28h, int64_t arg_70h, int64_t arg_198h, int64_t arg_1d8h, int64_t arg_1e0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021ed1f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_198h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5);
    iVar1 = *in_RCX;
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed47;
        func_0x000180221f20();
    } else {
        uVar2 = *(undefined8 *)(iVar1 + 0x98);
        *(undefined8 *)((int64_t)&arg_1e0h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed60;
        iVar3 = fcn.180222950(uVar2);
        if (iVar3 != 0) {
            uVar2 = *(undefined8 *)(iVar1 + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed71;
            func_0x0001802222d0(uVar2);
            uVar2 = *(undefined8 *)(iVar1 + 8);
            *(int64_t *)((int64_t)&var_18h + iVar5) = (int64_t)&arg_28h + iVar5;
            *(undefined4 *)((int64_t)&var_10h + iVar5) = 1;
            *(undefined8 *)((int64_t)&arg_70h + iVar5) = in_RDX;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ed9e;
            iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
            if (iVar3 < 0) {
                uVar2 = *(undefined8 *)(iVar1 + 0x98);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edb4;
                fcn.180222910(uVar2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edc7;
                iVar3 = func_0x00018021f5d0(in_RCX, 1, in_RDX, 0);
                if (iVar3 < 1) {
                    if (-1 < iVar3) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eddb;
                        func_0x000180221f20();
                    }
                    goto code_r0x00018021ee9a;
                }
                uVar2 = *(undefined8 *)(iVar1 + 0x98);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021edef;
                iVar3 = fcn.180222950(uVar2);
                if (iVar3 == 0) goto code_r0x00018021ee9a;
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee00;
                func_0x0001802222d0(uVar2);
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(int64_t *)((int64_t)&var_18h + iVar5) = (int64_t)&arg_28h + iVar5;
                *(undefined4 *)((int64_t)&var_10h + iVar5) = 1;
                *(undefined8 *)((int64_t)&arg_70h + iVar5) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee2d;
                iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
            }
            *(undefined8 *)((int64_t)&arg_1d8h + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee3c;
            iVar6 = func_0x000180221f20();
            if (((-1 < iVar3) && (iVar6 != 0)) && (iVar8 = 0, 0 < *(int32_t *)((int64_t)&var_8h + iVar5))) {
                do {
                    uVar2 = *(undefined8 *)(iVar1 + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee5b;
                    iVar7 = fcn.180222340(uVar2, iVar3);
                    uVar2 = *(undefined8 *)(iVar7 + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee6d;
                    iVar4 = func_0x000180237a90(iVar6, uVar2, 1);
                    if (iVar4 == 0) {
                        uVar2 = *(undefined8 *)(iVar1 + 0x98);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eec2;
                        fcn.180222910(uVar2);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eeca;
                        func_0x000180238640(iVar6);
                        goto code_r0x00018021ee9a;
                    }
                    iVar8 = iVar8 + 1;
                    iVar3 = iVar3 + 1;
                } while (iVar8 < *(int32_t *)((int64_t)&var_8h + iVar5));
            }
            uVar2 = *(undefined8 *)(iVar1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ee87;
            fcn.180222910(uVar2);
        }
    }
code_r0x00018021ee9a:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021eeaa;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_198h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_18021eee0
// Address: 0x18021eee0
// Size: 70 bytes
// ============================================================
void fcn.18021eee0(int64_t arg_28h, int64_t arg_40h, int64_t arg_98h, int64_t arg_118h, int64_t arg_158h,
                  int64_t arg_160h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021eeee;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_118h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5);
    iVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef19;
    iVar3 = func_0x00018021f5d0();
    if (-1 < iVar3) {
        *(undefined8 *)((int64_t)&arg_158h + iVar5) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef33;
        uVar6 = func_0x000180221f20();
        if (iVar3 != 0) {
            uVar2 = *(undefined8 *)(iVar1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef4a;
            iVar3 = fcn.180222950(uVar2);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef56;
                func_0x000180221d50(uVar6);
            } else {
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef66;
                func_0x0001802222d0(uVar2);
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8) = (int64_t)&arg_28h + iVar5;
                *(undefined4 *)((int64_t)&var_10h + iVar5) = 2;
                *(undefined8 *)((int64_t)&arg_40h + iVar5) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef90;
                iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
                if (iVar3 < 0) {
                    uVar6 = *(undefined8 *)(iVar1 + 0x98);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efa2;
                    fcn.180222910(uVar6);
                } else {
                    iVar8 = 0;
                    *(undefined8 *)((int64_t)&arg_160h + iVar5) = unaff_R14;
                    if (0 < *(int32_t *)((int64_t)&var_8h + iVar5)) {
                        do {
                            uVar2 = *(undefined8 *)(iVar1 + 8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efcb;
                            iVar7 = fcn.180222340(uVar2, iVar3);
                            uVar2 = *(undefined8 *)(iVar7 + 8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efd7;
                            iVar4 = fcn.18028ef00(uVar2);
                            if (iVar4 == 0) {
                                uVar6 = *(undefined8 *)(iVar1 + 0x98);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f050;
                                fcn.180222910(uVar6);
code_r0x00018021f050:
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f05f;
                                fcn.180222050(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                              *(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar5));
                                goto code_r0x00018021f013;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efe6;
                            iVar4 = func_0x000180222110(uVar6, uVar2);
                            if (iVar4 == 0) {
                                uVar6 = *(undefined8 *)(iVar1 + 0x98);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f03a;
                                fcn.180222910(uVar6);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f042;
                                fcn.18028eb90(*(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)(&stack0x00000038 + iVar5));
                                goto code_r0x00018021f050;
                            }
                            iVar8 = iVar8 + 1;
                            iVar3 = iVar3 + 1;
                        } while (iVar8 < *(int32_t *)((int64_t)&var_8h + iVar5));
                    }
                    uVar6 = *(undefined8 *)(iVar1 + 0x98);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f000;
                    fcn.180222910(uVar6);
                }
            }
        }
    }
code_r0x00018021f013:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f023;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_118h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_18021ef26
// Address: 0x18021ef26
// Size: 131 bytes
// ============================================================
void fcn.18021eee0(int64_t arg_28h, int64_t arg_40h, int64_t arg_98h, int64_t arg_118h, int64_t arg_158h,
                  int64_t arg_160h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021eeee;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_118h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5);
    iVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef19;
    iVar3 = func_0x00018021f5d0();
    if (-1 < iVar3) {
        *(undefined8 *)((int64_t)&arg_158h + iVar5) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef33;
        uVar6 = func_0x000180221f20();
        if (iVar3 != 0) {
            uVar2 = *(undefined8 *)(iVar1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef4a;
            iVar3 = fcn.180222950(uVar2);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef56;
                func_0x000180221d50(uVar6);
            } else {
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef66;
                func_0x0001802222d0(uVar2);
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8) = (int64_t)&arg_28h + iVar5;
                *(undefined4 *)((int64_t)&var_10h + iVar5) = 2;
                *(undefined8 *)((int64_t)&arg_40h + iVar5) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef90;
                iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
                if (iVar3 < 0) {
                    uVar6 = *(undefined8 *)(iVar1 + 0x98);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efa2;
                    fcn.180222910(uVar6);
                } else {
                    iVar8 = 0;
                    *(undefined8 *)((int64_t)&arg_160h + iVar5) = unaff_R14;
                    if (0 < *(int32_t *)((int64_t)&var_8h + iVar5)) {
                        do {
                            uVar2 = *(undefined8 *)(iVar1 + 8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efcb;
                            iVar7 = fcn.180222340(uVar2, iVar3);
                            uVar2 = *(undefined8 *)(iVar7 + 8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efd7;
                            iVar4 = fcn.18028ef00(uVar2);
                            if (iVar4 == 0) {
                                uVar6 = *(undefined8 *)(iVar1 + 0x98);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f050;
                                fcn.180222910(uVar6);
code_r0x00018021f050:
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f05f;
                                fcn.180222050(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                              *(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar5));
                                goto code_r0x00018021f013;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efe6;
                            iVar4 = func_0x000180222110(uVar6, uVar2);
                            if (iVar4 == 0) {
                                uVar6 = *(undefined8 *)(iVar1 + 0x98);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f03a;
                                fcn.180222910(uVar6);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f042;
                                fcn.18028eb90(*(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)(&stack0x00000038 + iVar5));
                                goto code_r0x00018021f050;
                            }
                            iVar8 = iVar8 + 1;
                            iVar3 = iVar3 + 1;
                        } while (iVar8 < *(int32_t *)((int64_t)&var_8h + iVar5));
                    }
                    uVar6 = *(undefined8 *)(iVar1 + 0x98);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f000;
                    fcn.180222910(uVar6);
                }
            }
        }
    }
code_r0x00018021f013:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f023;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_118h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_18021efa9
// Address: 0x18021efa9
// Size: 98 bytes
// ============================================================
void fcn.18021eee0(int64_t arg_28h, int64_t arg_40h, int64_t arg_98h, int64_t arg_118h, int64_t arg_158h,
                  int64_t arg_160h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021eeee;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_118h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5);
    iVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef19;
    iVar3 = func_0x00018021f5d0();
    if (-1 < iVar3) {
        *(undefined8 *)((int64_t)&arg_158h + iVar5) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef33;
        uVar6 = func_0x000180221f20();
        if (iVar3 != 0) {
            uVar2 = *(undefined8 *)(iVar1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef4a;
            iVar3 = fcn.180222950(uVar2);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef56;
                func_0x000180221d50(uVar6);
            } else {
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef66;
                func_0x0001802222d0(uVar2);
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8) = (int64_t)&arg_28h + iVar5;
                *(undefined4 *)((int64_t)&var_10h + iVar5) = 2;
                *(undefined8 *)((int64_t)&arg_40h + iVar5) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef90;
                iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
                if (iVar3 < 0) {
                    uVar6 = *(undefined8 *)(iVar1 + 0x98);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efa2;
                    fcn.180222910(uVar6);
                } else {
                    iVar8 = 0;
                    *(undefined8 *)((int64_t)&arg_160h + iVar5) = unaff_R14;
                    if (0 < *(int32_t *)((int64_t)&var_8h + iVar5)) {
                        do {
                            uVar2 = *(undefined8 *)(iVar1 + 8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efcb;
                            iVar7 = fcn.180222340(uVar2, iVar3);
                            uVar2 = *(undefined8 *)(iVar7 + 8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efd7;
                            iVar4 = fcn.18028ef00(uVar2);
                            if (iVar4 == 0) {
                                uVar6 = *(undefined8 *)(iVar1 + 0x98);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f050;
                                fcn.180222910(uVar6);
code_r0x00018021f050:
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f05f;
                                fcn.180222050(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                              *(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar5));
                                goto code_r0x00018021f013;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efe6;
                            iVar4 = func_0x000180222110(uVar6, uVar2);
                            if (iVar4 == 0) {
                                uVar6 = *(undefined8 *)(iVar1 + 0x98);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f03a;
                                fcn.180222910(uVar6);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f042;
                                fcn.18028eb90(*(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)(&stack0x00000038 + iVar5));
                                goto code_r0x00018021f050;
                            }
                            iVar8 = iVar8 + 1;
                            iVar3 = iVar3 + 1;
                        } while (iVar8 < *(int32_t *)((int64_t)&var_8h + iVar5));
                    }
                    uVar6 = *(undefined8 *)(iVar1 + 0x98);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f000;
                    fcn.180222910(uVar6);
                }
            }
        }
    }
code_r0x00018021f013:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f023;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_118h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_18021f00b
// Address: 0x18021f00b
// Size: 8 bytes
// ============================================================
void fcn.18021eee0(int64_t arg_28h, int64_t arg_40h, int64_t arg_98h, int64_t arg_118h, int64_t arg_158h,
                  int64_t arg_160h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021eeee;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_118h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5);
    iVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef19;
    iVar3 = func_0x00018021f5d0();
    if (-1 < iVar3) {
        *(undefined8 *)((int64_t)&arg_158h + iVar5) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef33;
        uVar6 = func_0x000180221f20();
        if (iVar3 != 0) {
            uVar2 = *(undefined8 *)(iVar1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef4a;
            iVar3 = fcn.180222950(uVar2);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef56;
                func_0x000180221d50(uVar6);
            } else {
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef66;
                func_0x0001802222d0(uVar2);
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8) = (int64_t)&arg_28h + iVar5;
                *(undefined4 *)((int64_t)&var_10h + iVar5) = 2;
                *(undefined8 *)((int64_t)&arg_40h + iVar5) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef90;
                iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
                if (iVar3 < 0) {
                    uVar6 = *(undefined8 *)(iVar1 + 0x98);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efa2;
                    fcn.180222910(uVar6);
                } else {
                    iVar8 = 0;
                    *(undefined8 *)((int64_t)&arg_160h + iVar5) = unaff_R14;
                    if (0 < *(int32_t *)((int64_t)&var_8h + iVar5)) {
                        do {
                            uVar2 = *(undefined8 *)(iVar1 + 8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efcb;
                            iVar7 = fcn.180222340(uVar2, iVar3);
                            uVar2 = *(undefined8 *)(iVar7 + 8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efd7;
                            iVar4 = fcn.18028ef00(uVar2);
                            if (iVar4 == 0) {
                                uVar6 = *(undefined8 *)(iVar1 + 0x98);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f050;
                                fcn.180222910(uVar6);
code_r0x00018021f050:
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f05f;
                                fcn.180222050(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                              *(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar5));
                                goto code_r0x00018021f013;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efe6;
                            iVar4 = func_0x000180222110(uVar6, uVar2);
                            if (iVar4 == 0) {
                                uVar6 = *(undefined8 *)(iVar1 + 0x98);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f03a;
                                fcn.180222910(uVar6);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f042;
                                fcn.18028eb90(*(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)(&stack0x00000038 + iVar5));
                                goto code_r0x00018021f050;
                            }
                            iVar8 = iVar8 + 1;
                            iVar3 = iVar3 + 1;
                        } while (iVar8 < *(int32_t *)((int64_t)&var_8h + iVar5));
                    }
                    uVar6 = *(undefined8 *)(iVar1 + 0x98);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f000;
                    fcn.180222910(uVar6);
                }
            }
        }
    }
code_r0x00018021f013:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f023;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_118h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_18021f013
// Address: 0x18021f013
// Size: 27 bytes
// ============================================================
void fcn.18021eee0(int64_t arg_28h, int64_t arg_40h, int64_t arg_98h, int64_t arg_118h, int64_t arg_158h,
                  int64_t arg_160h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021eeee;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_118h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5);
    iVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef19;
    iVar3 = func_0x00018021f5d0();
    if (-1 < iVar3) {
        *(undefined8 *)((int64_t)&arg_158h + iVar5) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef33;
        uVar6 = func_0x000180221f20();
        if (iVar3 != 0) {
            uVar2 = *(undefined8 *)(iVar1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef4a;
            iVar3 = fcn.180222950(uVar2);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef56;
                func_0x000180221d50(uVar6);
            } else {
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef66;
                func_0x0001802222d0(uVar2);
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8) = (int64_t)&arg_28h + iVar5;
                *(undefined4 *)((int64_t)&var_10h + iVar5) = 2;
                *(undefined8 *)((int64_t)&arg_40h + iVar5) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef90;
                iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
                if (iVar3 < 0) {
                    uVar6 = *(undefined8 *)(iVar1 + 0x98);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efa2;
                    fcn.180222910(uVar6);
                } else {
                    iVar8 = 0;
                    *(undefined8 *)((int64_t)&arg_160h + iVar5) = unaff_R14;
                    if (0 < *(int32_t *)((int64_t)&var_8h + iVar5)) {
                        do {
                            uVar2 = *(undefined8 *)(iVar1 + 8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efcb;
                            iVar7 = fcn.180222340(uVar2, iVar3);
                            uVar2 = *(undefined8 *)(iVar7 + 8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efd7;
                            iVar4 = fcn.18028ef00(uVar2);
                            if (iVar4 == 0) {
                                uVar6 = *(undefined8 *)(iVar1 + 0x98);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f050;
                                fcn.180222910(uVar6);
code_r0x00018021f050:
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f05f;
                                fcn.180222050(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                              *(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar5));
                                goto code_r0x00018021f013;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efe6;
                            iVar4 = func_0x000180222110(uVar6, uVar2);
                            if (iVar4 == 0) {
                                uVar6 = *(undefined8 *)(iVar1 + 0x98);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f03a;
                                fcn.180222910(uVar6);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f042;
                                fcn.18028eb90(*(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)(&stack0x00000038 + iVar5));
                                goto code_r0x00018021f050;
                            }
                            iVar8 = iVar8 + 1;
                            iVar3 = iVar3 + 1;
                        } while (iVar8 < *(int32_t *)((int64_t)&var_8h + iVar5));
                    }
                    uVar6 = *(undefined8 *)(iVar1 + 0x98);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f000;
                    fcn.180222910(uVar6);
                }
            }
        }
    }
code_r0x00018021f013:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f023;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_118h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_18021f02e
// Address: 0x18021f02e
// Size: 53 bytes
// ============================================================
void fcn.18021eee0(int64_t arg_28h, int64_t arg_40h, int64_t arg_98h, int64_t arg_118h, int64_t arg_158h,
                  int64_t arg_160h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int32_t iVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18021eeee;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_118h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5);
    iVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef19;
    iVar3 = func_0x00018021f5d0();
    if (-1 < iVar3) {
        *(undefined8 *)((int64_t)&arg_158h + iVar5) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef33;
        uVar6 = func_0x000180221f20();
        if (iVar3 != 0) {
            uVar2 = *(undefined8 *)(iVar1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef4a;
            iVar3 = fcn.180222950(uVar2);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef56;
                func_0x000180221d50(uVar6);
            } else {
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef66;
                func_0x0001802222d0(uVar2);
                uVar2 = *(undefined8 *)(iVar1 + 8);
                *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8) = (int64_t)&arg_28h + iVar5;
                *(undefined4 *)((int64_t)&var_10h + iVar5) = 2;
                *(undefined8 *)((int64_t)&arg_40h + iVar5) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021ef90;
                iVar3 = func_0x000180221b80(uVar2, (int64_t)&var_10h + iVar5, (int64_t)&var_8h + iVar5);
                if (iVar3 < 0) {
                    uVar6 = *(undefined8 *)(iVar1 + 0x98);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efa2;
                    fcn.180222910(uVar6);
                } else {
                    iVar8 = 0;
                    *(undefined8 *)((int64_t)&arg_160h + iVar5) = unaff_R14;
                    if (0 < *(int32_t *)((int64_t)&var_8h + iVar5)) {
                        do {
                            uVar2 = *(undefined8 *)(iVar1 + 8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efcb;
                            iVar7 = fcn.180222340(uVar2, iVar3);
                            uVar2 = *(undefined8 *)(iVar7 + 8);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efd7;
                            iVar4 = fcn.18028ef00(uVar2);
                            if (iVar4 == 0) {
                                uVar6 = *(undefined8 *)(iVar1 + 0x98);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f050;
                                fcn.180222910(uVar6);
code_r0x00018021f050:
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f05f;
                                fcn.180222050(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                              *(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar5));
                                goto code_r0x00018021f013;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021efe6;
                            iVar4 = func_0x000180222110(uVar6, uVar2);
                            if (iVar4 == 0) {
                                uVar6 = *(undefined8 *)(iVar1 + 0x98);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f03a;
                                fcn.180222910(uVar6);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f042;
                                fcn.18028eb90(*(int64_t *)((int64_t)&var_10h + iVar5), 
                                              *(int64_t *)(&stack0x00000038 + iVar5));
                                goto code_r0x00018021f050;
                            }
                            iVar8 = iVar8 + 1;
                            iVar3 = iVar3 + 1;
                        } while (iVar8 < *(int32_t *)((int64_t)&var_8h + iVar5));
                    }
                    uVar6 = *(undefined8 *)(iVar1 + 0x98);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f000;
                    fcn.180222910(uVar6);
                }
            }
        }
    }
code_r0x00018021f013:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18021f023;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_118h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_18021f070
// Address: 0x18021f070
// Size: 89 bytes
// ============================================================
undefined8 fcn.18021f070(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021f07a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021f085;
    iVar1 = fcn.18021f8f0(*(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2));
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021f08e;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021f0a6;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18021f0b8;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0;
    }
    return 1;
}

