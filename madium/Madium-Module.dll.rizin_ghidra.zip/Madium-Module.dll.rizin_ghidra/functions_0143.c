// Chunk 143 - 50 functions

// ============================================================
// Function: FUN_1801e7512
// Address: 0x1801e7512
// Size: 15 bytes
// ============================================================
undefined8 fcn.1801e7512(void)
{
    return 0;
}

// ============================================================
// Function: FUN_1801e7530
// Address: 0x1801e7530
// Size: 90 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801e7530(int64_t arg_28h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e7540;
    iVar3 = func_0x00018045a350();
    if ((*(char *)(in_RCX + 0x101) == '\x02') || (*(char *)(in_RCX + 0x101) == '\x03')) {
        uVar1 = *(undefined8 *)(in_RCX + 0x70);
        *(undefined8 *)((int64_t)&uStack_10 - iVar3) = 0x1801e7563;
        iVar2 = func_0x0001801e6440(uVar1);
        if ((iVar2 == 0) && (-1 < (char)*(uint32_t *)(in_RCX + 0x104))) {
            *(uint32_t *)(in_RCX + 0x104) = *(uint32_t *)(in_RCX + 0x104) | 0x80;
            *(int64_t *)(in_RDX + 0x60) = *(int64_t *)(in_RDX + 0x60) + 1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e7640
// Address: 0x1801e7640
// Size: 258 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1801e7640(int64_t arg_50h, int64_t arg_128h)
{
    undefined8 uVar1;
    undefined uVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 *in_RCX;
    uint32_t uVar6;
    undefined8 in_RDX;
    undefined in_R8B;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e765a;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = in_RDX;
    uVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e7678;
    iVar5 = func_0x000180229240(uVar1, (int64_t)&var_18h + iVar4);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e7698;
        iVar5 = func_0x000180224d60(0x108, 0x1804b74d8, 0x9a);
        if (iVar5 != 0) {
            *(undefined8 *)(iVar5 + 0x38) = in_RDX;
            *(undefined *)(iVar5 + 0x100) = in_R8B;
            uVar1 = in_RCX[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e76b8;
            uVar3 = func_0x0001801e3b40(uVar1);
            uVar6 = (uVar3 << 0x19 ^ *(uint32_t *)(iVar5 + 0x100)) & 0x2000000 ^ *(uint32_t *)(iVar5 + 0x100);
            *(uint32_t *)(iVar5 + 0x100) = uVar6;
            if ((((uVar6 ^ uVar3) & 1) == 0) || ((uVar6 & 2) == 0)) {
                uVar2 = 1;
            } else {
                uVar2 = 0;
            }
            *(undefined *)(iVar5 + 0x101) = uVar2;
            uVar3 = *(uint32_t *)(iVar5 + 0x100);
            if ((((uVar3 >> 0x19 ^ uVar3) & 1) == 0) && ((uVar3 & 2) != 0)) {
                uVar2 = 0;
            } else {
                uVar2 = 1;
            }
            *(undefined *)(iVar5 + 0x102) = uVar2;
            *(undefined8 *)(iVar5 + 0x68) = 0xffffffffffffffff;
            uVar1 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e7722;
            func_0x000180228fb0(uVar1, iVar5);
            return iVar5;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e7750
// Address: 0x1801e7750
// Size: 43 bytes
// ============================================================
void fcn.1801e7750(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_90h)
{
    int32_t iVar1;
    code *pcVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t **in_RCX;
    int64_t *piVar8;
    code *pcVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar10;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar6 = func_0x00018045a350();
    iVar6 = -iVar6;
    in_RCX[0xc] = (int64_t *)0x0;
    pcVar9 = fcn.1801e7530;
    piVar8 = *in_RCX;
    if (piVar8 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + 0x18) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + 0x10) = unaff_R14;
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + 8) = unaff_R15;
        *(undefined8 *)((int64_t)auStackX_8 + iVar6) = 0x180228cf8;
        iVar7 = func_0x00018045a350(piVar8, fcn.1801e7530, in_RCX);
        iVar7 = -iVar7;
        iVar1 = *(int32_t *)(piVar8 + 7);
        *(undefined8 *)((int64_t)&arg_58h + iVar7 + iVar6) = unaff_RSI;
        pcVar2 = (code *)piVar8[6];
        *(undefined8 *)((int64_t)&arg_60h + iVar7 + iVar6) = unaff_RDI;
        iVar10 = (int64_t)(iVar1 + -1);
        if (-1 < iVar1 + -1) {
            *(undefined8 *)((int64_t)&arg_50h + iVar7 + iVar6) = unaff_RBX;
            do {
                puVar5 = *(undefined8 **)(*piVar8 + iVar10 * 8);
                while (puVar5 != (undefined8 *)0x0) {
                    puVar3 = (undefined8 *)puVar5[1];
                    uVar4 = *puVar5;
                    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6) = 0x180228d3f;
                    (*pcVar2)(uVar4, in_RCX, pcVar9);
                    puVar5 = puVar3;
                }
                iVar10 = iVar10 + -1;
            } while (-1 < iVar10);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e7780
// Address: 0x1801e7780
// Size: 57 bytes
// ============================================================
void fcn.1801e7780(undefined8 *param_1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e778c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801e77a4;
    fcn.180228ce0(*(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1), *(int64_t *)(&stack0x00000080 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801e77ac;
    fcn.180228ec0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *param_1 = 0;
    return;
}

// ============================================================
// Function: FUN_1801e77e0
// Address: 0x1801e77e0
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801e77e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t iVar4;
    int64_t iVar5;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e77f5;
    iVar2 = fcn.18045a350();
    iVar3 = *(int64_t *)(in_RCX + 0x38);
    iVar1 = in_RCX + 0x30;
    if (iVar3 == iVar1) {
        iVar3 = *(int64_t *)(iVar3 + 8);
    }
    iVar5 = 0;
    if (iVar3 != iVar1) {
        iVar5 = iVar3 + -0x20;
    }
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar2) = unaff_RBX;
        iVar3 = iVar5;
        do {
            if (iVar3 == iVar5) {
                return;
            }
            iVar4 = *(int64_t *)(iVar3 + 0x28);
            if (iVar4 == iVar1) {
                iVar4 = *(int64_t *)(iVar4 + 8);
            }
            *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801e7843;
            func_0x0001801e7c50(in_RCX, iVar3);
            iVar3 = 0;
            if (iVar4 != iVar1) {
                iVar3 = iVar4 + -0x20;
            }
        } while (iVar3 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_1801e7821
// Address: 0x1801e7821
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801e77e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t iVar4;
    int64_t iVar5;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e77f5;
    iVar2 = fcn.18045a350();
    iVar3 = *(int64_t *)(in_RCX + 0x38);
    iVar1 = in_RCX + 0x30;
    if (iVar3 == iVar1) {
        iVar3 = *(int64_t *)(iVar3 + 8);
    }
    iVar5 = 0;
    if (iVar3 != iVar1) {
        iVar5 = iVar3 + -0x20;
    }
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar2) = unaff_RBX;
        iVar3 = iVar5;
        do {
            if (iVar3 == iVar5) {
                return;
            }
            iVar4 = *(int64_t *)(iVar3 + 0x28);
            if (iVar4 == iVar1) {
                iVar4 = *(int64_t *)(iVar4 + 8);
            }
            *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801e7843;
            func_0x0001801e7c50(in_RCX, iVar3);
            iVar3 = 0;
            if (iVar4 != iVar1) {
                iVar3 = iVar4 + -0x20;
            }
        } while (iVar3 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_1801e785a
// Address: 0x1801e785a
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801e77e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t iVar4;
    int64_t iVar5;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e77f5;
    iVar2 = fcn.18045a350();
    iVar3 = *(int64_t *)(in_RCX + 0x38);
    iVar1 = in_RCX + 0x30;
    if (iVar3 == iVar1) {
        iVar3 = *(int64_t *)(iVar3 + 8);
    }
    iVar5 = 0;
    if (iVar3 != iVar1) {
        iVar5 = iVar3 + -0x20;
    }
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar2) = unaff_RBX;
        iVar3 = iVar5;
        do {
            if (iVar3 == iVar5) {
                return;
            }
            iVar4 = *(int64_t *)(iVar3 + 0x28);
            if (iVar4 == iVar1) {
                iVar4 = *(int64_t *)(iVar4 + 8);
            }
            *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801e7843;
            func_0x0001801e7c50(in_RCX, iVar3);
            iVar3 = 0;
            if (iVar4 != iVar1) {
                iVar3 = iVar4 + -0x20;
            }
        } while (iVar3 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_1801e7870
// Address: 0x1801e7870
// Size: 39 bytes
// ============================================================
void fcn.1801e7870(int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 in_RDX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801e787a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_58h + iVar1) = in_RDX;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801e788f;
    fcn.180229240(*(int64_t *)(&stack0x00000028 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1801e78a0
// Address: 0x1801e78a0
// Size: 231 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801e78a0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h)
{
    undefined8 *puVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 *in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e78bb;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e78dd;
    fcn.180229130(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
    *(undefined8 *)((int64_t)&iStackX_20 + iVar2 + -8) = 0x180195290;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e7906;
    uVar3 = fcn.180229290(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8));
    *in_RCX = uVar3;
    puVar1 = in_RCX + 2;
    in_RCX[9] = 0;
    in_RCX[3] = puVar1;
    *puVar1 = puVar1;
    puVar1 = in_RCX + 4;
    in_RCX[0xd] = 0;
    in_RCX[10] = 0;
    in_RCX[0xb] = 0;
    in_RCX[0xc] = 0;
    uVar3 = *(undefined8 *)((int64_t)&arg_58h + iVar2);
    in_RCX[5] = puVar1;
    *puVar1 = puVar1;
    puVar1 = in_RCX + 6;
    in_RCX[0x11] = uVar3;
    uVar3 = *(undefined8 *)((int64_t)&arg_60h + iVar2);
    in_RCX[7] = puVar1;
    *puVar1 = puVar1;
    in_RCX[0xe] = in_RDX;
    in_RCX[0xf] = in_R8;
    in_RCX[0x10] = in_R9;
    in_RCX[8] = 1;
    in_RCX[1] = uVar3;
    return 1;
}

// ============================================================
// Function: FUN_1801e7990
// Address: 0x1801e7990
// Size: 63 bytes
// ============================================================
bool fcn.1801e7990(int64_t param_1, uint64_t param_2, undefined4 param_3)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e799c;
    iVar3 = fcn.18045a350();
    pcVar1 = *(code **)(param_1 + 0x70);
    if (pcVar1 == (code *)0x0) {
        return true;
    }
    uVar2 = *(undefined8 *)(param_1 + 0x78);
    *(undefined8 *)((int64_t)&uStack_10 - iVar3) = 0x1801e79bf;
    uVar4 = (*pcVar1)(param_3, uVar2);
    return param_2 < uVar4;
}

// ============================================================
// Function: FUN_1801e79e0
// Address: 0x1801e79e0
// Size: 76 bytes
// ============================================================
undefined8 fcn.1801e79e0(undefined8 param_1, int64_t param_2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e79ec;
    iVar3 = fcn.18045a350();
    if ((*(char *)(param_2 + 0x101) != '\0') && (*(char *)(param_2 + 0x101) == '\x02')) {
        uVar1 = *(undefined8 *)(param_2 + 0x70);
        *(undefined8 *)((int64_t)&uStack_10 - iVar3) = 0x1801e7a0e;
        iVar2 = fcn.1801e6210(uVar1, param_2 + 0x68);
        if (iVar2 != 0) {
            *(undefined *)(param_2 + 0x101) = 3;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e7a50
// Address: 0x1801e7a50
// Size: 248 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801e7a50(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    code *UNRECOVERED_JUMPTABLE;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    
    fcn.18045a350();
    // switch table (7 cases) at 0x1801e7b10
    switch((uint64_t)*(uint8_t *)(in_RDX + 0x102)) {
    default:
        uVar1 = 0;
        break;
    case 1:
    case 2:
    case 3:
        UNRECOVERED_JUMPTABLE =
             (code *)((uint64_t)*(uint32_t *)((uint64_t)*(uint8_t *)(in_RDX + 0x102) * 4 + 0x1801e7b2c) + 0x180000000);
    // WARNING: Could not recover jumptable at 0x0001801e7aa4. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (7 cases) at 0x1801e7b2c
        uVar1 = (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
        return uVar1;
    case 4:
    case 5:
    case 6:
        uVar1 = 1;
    }
    return uVar1;
}

// ============================================================
// Function: FUN_1801e7ba0
// Address: 0x1801e7ba0
// Size: 76 bytes
// ============================================================
undefined8 fcn.1801e7ba0(undefined8 param_1, int64_t param_2)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e7bac;
    iVar1 = fcn.18045a350();
    if ((*(char *)(param_2 + 0x102) != '\0') && (*(char *)(param_2 + 0x102) == '\x03')) {
        *(undefined *)(param_2 + 0x102) = 4;
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x1801e7bd1;
        fcn.1801e6b30(*(int64_t *)((int64_t)aiStackX_18 + -iVar1));
        *(undefined8 *)(param_2 + 0x78) = 0;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e7c50
// Address: 0x1801e7c50
// Size: 31 bytes
// ============================================================
void fcn.1801e7c50(undefined8 *placeholder_0, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3,
                  int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RSI;
    int64_t var_18h;
    undefined8 uStack_10;
    
    if (arg2 != 0) {
        uStack_10 = 0x1801e7c69;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
        if (*(int64_t *)(arg2 + 8) != 0) {
            *(int64_t *)(*(int64_t *)arg2 + 8) = *(int64_t *)(arg2 + 8);
            **(int64_t **)(arg2 + 8) = *(int64_t *)arg2;
            *(int64_t *)arg2 = 0;
            *(int64_t *)(arg2 + 8) = 0;
        }
        if (*(int64_t *)(arg2 + 0x18) != 0) {
            *(int64_t *)(*(int64_t *)(arg2 + 0x10) + 8) = *(int64_t *)(arg2 + 0x18);
            **(int64_t **)(arg2 + 0x18) = *(int64_t *)(arg2 + 0x10);
            *(int64_t *)(arg2 + 0x10) = 0;
            *(int64_t *)(arg2 + 0x18) = 0;
        }
        if (*(int64_t *)(arg2 + 0x28) != 0) {
            *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 8) = *(int64_t *)(arg2 + 0x28);
            **(int64_t **)(arg2 + 0x28) = *(int64_t *)(arg2 + 0x20);
            *(int64_t *)(arg2 + 0x20) = 0;
            *(int64_t *)(arg2 + 0x28) = 0;
        }
        iVar1 = *(int64_t *)(arg2 + 0x70);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e7ced;
        func_0x0001801e6180(iVar1);
        *(int64_t *)(arg2 + 0x70) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e7cfa;
        fcn.1801e6b30(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(int64_t *)(arg2 + 0x78) = 0;
        uVar2 = *placeholder_0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e7d09;
        func_0x000180228b10(uVar2, arg2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e7d1e;
        fcn.180224990(arg2, 0x1804b74d8, 0xc3);
    }
    return;
}

// ============================================================
// Function: FUN_1801e7c6f
// Address: 0x1801e7c6f
// Size: 190 bytes
// ============================================================
void fcn.1801e7c50(undefined8 *placeholder_0, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3,
                  int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RSI;
    int64_t var_18h;
    undefined8 uStack_10;
    
    if (arg2 != 0) {
        uStack_10 = 0x1801e7c69;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
        if (*(int64_t *)(arg2 + 8) != 0) {
            *(int64_t *)(*(int64_t *)arg2 + 8) = *(int64_t *)(arg2 + 8);
            **(int64_t **)(arg2 + 8) = *(int64_t *)arg2;
            *(int64_t *)arg2 = 0;
            *(int64_t *)(arg2 + 8) = 0;
        }
        if (*(int64_t *)(arg2 + 0x18) != 0) {
            *(int64_t *)(*(int64_t *)(arg2 + 0x10) + 8) = *(int64_t *)(arg2 + 0x18);
            **(int64_t **)(arg2 + 0x18) = *(int64_t *)(arg2 + 0x10);
            *(int64_t *)(arg2 + 0x10) = 0;
            *(int64_t *)(arg2 + 0x18) = 0;
        }
        if (*(int64_t *)(arg2 + 0x28) != 0) {
            *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 8) = *(int64_t *)(arg2 + 0x28);
            **(int64_t **)(arg2 + 0x28) = *(int64_t *)(arg2 + 0x20);
            *(int64_t *)(arg2 + 0x20) = 0;
            *(int64_t *)(arg2 + 0x28) = 0;
        }
        iVar1 = *(int64_t *)(arg2 + 0x70);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e7ced;
        func_0x0001801e6180(iVar1);
        *(int64_t *)(arg2 + 0x70) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e7cfa;
        fcn.1801e6b30(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(int64_t *)(arg2 + 0x78) = 0;
        uVar2 = *placeholder_0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e7d09;
        func_0x000180228b10(uVar2, arg2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e7d1e;
        fcn.180224990(arg2, 0x1804b74d8, 0xc3);
    }
    return;
}

// ============================================================
// Function: FUN_1801e7d2d
// Address: 0x1801e7d2d
// Size: 1 bytes
// ============================================================
void fcn.1801e7c50(undefined8 *placeholder_0, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3,
                  int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RSI;
    int64_t var_18h;
    undefined8 uStack_10;
    
    if (arg2 != 0) {
        uStack_10 = 0x1801e7c69;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
        if (*(int64_t *)(arg2 + 8) != 0) {
            *(int64_t *)(*(int64_t *)arg2 + 8) = *(int64_t *)(arg2 + 8);
            **(int64_t **)(arg2 + 8) = *(int64_t *)arg2;
            *(int64_t *)arg2 = 0;
            *(int64_t *)(arg2 + 8) = 0;
        }
        if (*(int64_t *)(arg2 + 0x18) != 0) {
            *(int64_t *)(*(int64_t *)(arg2 + 0x10) + 8) = *(int64_t *)(arg2 + 0x18);
            **(int64_t **)(arg2 + 0x18) = *(int64_t *)(arg2 + 0x10);
            *(int64_t *)(arg2 + 0x10) = 0;
            *(int64_t *)(arg2 + 0x18) = 0;
        }
        if (*(int64_t *)(arg2 + 0x28) != 0) {
            *(int64_t *)(*(int64_t *)(arg2 + 0x20) + 8) = *(int64_t *)(arg2 + 0x28);
            **(int64_t **)(arg2 + 0x28) = *(int64_t *)(arg2 + 0x20);
            *(int64_t *)(arg2 + 0x20) = 0;
            *(int64_t *)(arg2 + 0x28) = 0;
        }
        iVar1 = *(int64_t *)(arg2 + 0x70);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e7ced;
        func_0x0001801e6180(iVar1);
        *(int64_t *)(arg2 + 0x70) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e7cfa;
        fcn.1801e6b30(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(int64_t *)(arg2 + 0x78) = 0;
        uVar2 = *placeholder_0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e7d09;
        func_0x000180228b10(uVar2, arg2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e7d1e;
        fcn.180224990(arg2, 0x1804b74d8, 0xc3);
    }
    return;
}

// ============================================================
// Function: FUN_1801e7d30
// Address: 0x1801e7d30
// Size: 106 bytes
// ============================================================
uint64_t fcn.1801e7d30(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_60h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t iVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    undefined8 unaff_R14;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)(*(int64_t *)(in_RDX + 0x10) + 8) = *(undefined8 *)(in_RDX + 0x18);
    **(undefined8 **)(in_RDX + 0x18) = *(undefined8 *)(in_RDX + 0x10);
    *(undefined8 *)(in_RDX + 0x10) = 0;
    *(undefined8 *)(in_RDX + 0x18) = 0;
    if ((*(uint8_t *)(in_RDX + 0x100) & 2) == 0) {
        *(int64_t *)(in_RCX + 0x50) = *(int64_t *)(in_RCX + 0x50) + -1;
    } else {
        *(int64_t *)(in_RCX + 0x58) = *(int64_t *)(in_RCX + 0x58) + -1;
    }
    uVar5 = (uint64_t)(*(uint32_t *)(in_RDX + 0x100) & 2) | 0x20;
    iVar6 = *(int64_t *)(in_RCX + uVar5 * 4);
    if (iVar6 == 0) {
        return uVar5;
    }
    iVar7 = 1;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x1801e5a5b;
    iVar3 = fcn.18045a350();
    if ((*(int64_t *)(iVar6 + 0x50) == 0) && (*(char *)(iVar6 + 0x5b) == '\0')) {
code_r0x0001801e5a86:
        uVar5 = 0;
    } else {
        if (iVar7 != 0) {
            if (*(uint64_t *)(iVar6 + 8) < (uint64_t)(*(int64_t *)(iVar6 + 0x10) + iVar7)) goto code_r0x0001801e5a86;
            *(undefined8 *)((int64_t)auStackX_18 + -iVar3 + iVar4) = 0x1801e5a98;
            func_0x0001801e5e20(iVar6);
            if (*(char *)(iVar6 + 0x5b) == '\0') {
                uVar1 = *(undefined8 *)(iVar6 + 0x28);
                uVar2 = *(undefined8 *)(iVar6 + 0x50);
                *(undefined8 *)((int64_t)auStackX_18 + -iVar3 + iVar4) = 0x1801e5ab1;
                func_0x0001801e5e20(uVar2, iVar7, uVar1, in_R8);
            }
        }
        uVar5 = 1;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_1801e7da0
// Address: 0x1801e7da0
// Size: 244 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801e7da0(int64_t arg_28h, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_18h;
    code *pcStack_10;
    
    pcStack_10 = (code *)0x1801e7db5;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    // switch table (7 cases) at 0x1801e7e78
    switch(*(undefined *)(in_RDX + 0x101)) {
    default:
        return 0;
    case 1:
        *(undefined *)(in_RDX + 0x101) = 2;
    case 2:
        *(undefined8 *)((int64_t)&pcStack_10 + iVar2) = 0x1801e7df9;
        uVar3 = func_0x0001801bc820(in_RDX + 0x80);
        *(undefined8 *)(in_RDX + 0x68) = uVar3;
    case 3:
        uVar3 = *(undefined8 *)(in_RDX + 0x70);
        *(uint32_t *)(in_RDX + 0x104) = *(uint32_t *)(in_RDX + 0x104) | 8;
        *(undefined8 *)(in_RDX + 0x48) = in_R8;
        *(undefined *)(in_RDX + 0x101) = 5;
        *(undefined8 *)((int64_t)&pcStack_10 + iVar2) = 0x1801e7e18;
        func_0x0001801e6180(uVar3);
        *(undefined8 *)(in_RDX + 0x70) = 0;
        if ((char)*(uint32_t *)(in_RDX + 0x104) < '\0') {
            *(uint32_t *)(in_RDX + 0x104) = *(uint32_t *)(in_RDX + 0x104) & 0xffffff7f;
            piVar1 = (int64_t *)(in_RCX + 0x60);
            *piVar1 = *piVar1 + -1;
            if (*piVar1 == 0) {
                uVar3 = *(undefined8 *)(in_RCX + 8);
                *(undefined8 *)((int64_t)&pcStack_10 + iVar2) = 0x1801e7e44;
                func_0x0001801e3de0(uVar3);
            }
        }
        *(code **)((int64_t)&pcStack_10 + iVar2) = case.0x1801e7de3.5;
        func_0x0001801e7fb0(in_RCX, in_RDX);
    case 5:
    case 6:
        return 1;
    }
}

// ============================================================
// Function: FUN_1801e7ea0
// Address: 0x1801e7ea0
// Size: 89 bytes
// ============================================================
undefined8 fcn.1801e7ea0(undefined8 param_1, int64_t param_2)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801e7eaa;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((*(uint32_t *)(param_2 + 0x100) >> 0x1a & 1) == 0) {
        return 0;
    }
    if (((*(uint32_t *)(param_2 + 0x104) & 4) == 0) &&
       ((uVar1 = *(uint32_t *)(param_2 + 0x100) >> 0x10 & 0xff, uVar1 == 1 || (uVar1 == 2)))) {
        *(uint32_t *)(param_2 + 0x104) = *(uint32_t *)(param_2 + 0x104) | 4;
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801e7eef;
        fcn.1801e7fb0(*(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                      *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x00000068 + iVar2), 
                      *(int64_t *)(&stack0x00000070 + iVar2), *(int64_t *)(&stack0x00000080 + iVar2), 
                      *(int64_t *)(&stack0x00000088 + iVar2), *(int64_t *)(&stack0x00000090 + iVar2), 
                      *(int64_t *)(&stack0x00000098 + iVar2));
    }
    return 1;
}

// ============================================================
// Function: FUN_1801e7f00
// Address: 0x1801e7f00
// Size: 172 bytes
// ============================================================
// WARNING: Control flow encountered bad instruction data
// WARNING: Instruction at (ram,0x00018000a08e) overlaps instruction at (ram,0x00018000a08a)
// 
// WARNING: Possible PIC construction at 0x0001800028f0: Changing call to branch
// WARNING: Possible PIC construction at 0x00018001018c: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001800028f5)
// WARNING: Removing unreachable block (ram,0x000180010191)
// WARNING: Removing unreachable block (ram,0x000180010160)
// WARNING: Removing unreachable block (ram,0x000180010181)
// WARNING: Removing unreachable block (ram,0x000180010199)

undefined (*) [16] fcn.1801e7f00(undefined8 param_1, undefined (*param_2) [16], uint64_t param_3)
{
    int64_t *piVar1;
    int32_t *piVar2;
    uint32_t uVar3;
    code *pcVar4;
    uint8_t *puVar5;
    undefined auVar6 [16];
    unkbyte3 Var7;
    int16_t *piVar8;
    uint8_t uVar9;
    undefined uVar10;
    char cVar11;
    uint32_t uVar12;
    int32_t iVar13;
    int32_t iVar14;
    uint32_t uVar15;
    int64_t iVar16;
    undefined8 *puVar17;
    undefined8 uVar18;
    uint64_t *puVar19;
    undefined (*pauVar20) [16];
    undefined8 uVar21;
    int64_t *piVar22;
    int16_t *piVar23;
    int16_t *piVar24;
    undefined (*pauVar25) [16];
    undefined (**ppauVar26) [16];
    undefined (*pauVar27) [16];
    undefined8 uVar28;
    int64_t iVar29;
    undefined *puVar30;
    undefined (**ppauVar31) [16];
    undefined8 *puVar32;
    undefined *puVar33;
    char cVar34;
    int64_t iVar35;
    unkbyte7 Var38;
    char *pcVar36;
    uint64_t uVar37;
    undefined (*pauVar39) [16];
    int16_t *piVar40;
    undefined4 *puVar41;
    undefined8 *puVar42;
    undefined (*unaff_RBX) [16];
    undefined *puVar43;
    undefined *puVar44;
    undefined8 *unaff_RBP;
    undefined *puVar45;
    undefined (*unaff_RSI) [16];
    undefined *puVar46;
    undefined4 *puVar47;
    uint64_t unaff_RDI;
    undefined2 uVar48;
    undefined (**unaff_R12) [16];
    undefined8 unaff_R13;
    uint64_t uVar49;
    undefined4 *puVar50;
    undefined (*unaff_R14) [16];
    uint64_t uVar51;
    undefined (**unaff_R15) [16];
    int64_t unaff_GS_OFFSET;
    bool bVar52;
    undefined4 extraout_XMM0_Da;
    undefined4 uVar53;
    undefined4 extraout_XMM0_Da_00;
    undefined4 extraout_XMM0_Da_01;
    undefined4 extraout_XMM0_Da_02;
    undefined4 extraout_XMM0_Da_03;
    undefined4 extraout_XMM0_Da_04;
    undefined4 extraout_XMM0_Da_05;
    undefined4 extraout_XMM0_Da_06;
    undefined4 extraout_XMM0_Da_07;
    undefined4 extraout_XMM0_Da_08;
    undefined4 uVar54;
    undefined4 extraout_XMM0_Db;
    undefined4 uVar55;
    undefined4 extraout_XMM0_Dc;
    undefined4 uVar56;
    undefined4 extraout_XMM0_Dd;
    undefined (*apauStackX_8 [3]) [16];
    undefined8 uStackX_20;
    undefined auStack_b8 [48];
    undefined auStack_88 [88];
    undefined8 uStack_30;
    undefined auStack_28 [24];
    uint64_t uStack_10;
    uint64_t uStack_8;
    
    uStack_8 = 0x1801e7f0a;
    iVar29 = fcn.18045a350();
    iVar29 = -iVar29;
    puVar44 = (undefined *)((int64_t)&uStackX_20 + iVar29 + -0x20);
    puVar30 = (undefined *)((int64_t)&uStackX_20 + iVar29 + -0x20);
    uVar12 = *(uint32_t *)param_2[0x10];
    uVar37 = (uint64_t)uVar12;
    uVar9 = (uint8_t)(uVar12 >> 0x10);
    if ((uVar12 >> 0x1a & 1) != 0) {
code_r0x0001801e7f87:
        return (undefined (*) [16])0x0;
    }
    uVar15 = (uint32_t)uVar9;
    pauVar20 = (undefined (*) [16])(uint64_t)uVar15;
    uVar51 = (uint64_t)*(uint32_t *)((int64_t)pauVar20 * 4 + 0x1801e7f90);
    puVar33 = (undefined *)(uVar51 + 0x180000000);
    cVar11 = (char)puVar33;
    iVar14 = (int32_t)unaff_R12;
    puVar45 = (undefined *)((int64_t)&uStackX_20 + iVar29 + -0x20);
    uVar53 = extraout_XMM0_Da_08;
    uVar54 = extraout_XMM0_Db;
    uVar55 = extraout_XMM0_Dc;
    uVar56 = extraout_XMM0_Dd;
    // WARNING: Could not find normalized switch variable to match jumptable
    // switch table (7 cases) at 0x1801e7f90
    switch(pauVar20) {
    default:
        goto code_r0x0001801e7f87;
    case (undefined (*) [16])0x1:
    case (undefined (*) [16])0x2:
        uVar15 = *(uint32_t *)(param_2[0x10] + 4);
        *(uint32_t *)param_2[0x10] = uVar12 | 0x4000000;
        *(uint64_t *)param_2[4] = param_3;
        if (((uVar15 & 4) == 0) && ((uVar12 = (uVar12 & 0xff0000) >> 0x10, uVar12 == 1 || (uVar12 == 2)))) {
            *(uint32_t *)(param_2[0x10] + 4) = uVar15 | 4;
            *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x1801e7f7d;
            fcn.1801e7fb0(*(int64_t *)(&stack0x00000028 + iVar29), *(int64_t *)(&stack0x00000030 + iVar29), 
                          *(int64_t *)(&stack0x00000038 + iVar29), *(int64_t *)(&stack0x00000040 + iVar29), 
                          *(int64_t *)(&stack0x00000050 + iVar29), *(int64_t *)(&stack0x00000058 + iVar29), 
                          *(int64_t *)(&stack0x00000060 + iVar29), *(int64_t *)(&stack0x00000068 + iVar29), 
                          *(int64_t *)(&stack0x00000070 + iVar29), *(int64_t *)(&stack0x00000080 + iVar29), 
                          *(int64_t *)(&stack0x00000088 + iVar29), *(int64_t *)(&stack0x00000090 + iVar29), 
                          *(int64_t *)(&stack0x00000098 + iVar29));
        }
        return (undefined (*) [16])0x1;
    case (undefined (*) [16])0x7:
    case (undefined (*) [16])0xcd:
    case (undefined (*) [16])0xce:
    case (undefined (*) [16])0xcf:
    case (undefined (*) [16])0xd7:
    case (undefined (*) [16])0xef:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x8:
    case (undefined (*) [16])0xf0:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x9:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xa:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xb:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xc:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xd:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xe:
    // WARNING: This code block may not be properly labeled as switch case
        *(uint64_t *)(unaff_RBX[4] + 0xd) = *(uint64_t *)(unaff_RBX[4] + 0xd) ^ (int64_t)&uStackX_20 + iVar29 + -0x20;
        return;
    case (undefined (*) [16])0xf:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x10:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x11:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x12:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x13:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x14:
    case (undefined (*) [16])0x9f:
    case (undefined (*) [16])0xab:
    case (undefined (*) [16])0xae:
    // WARNING: This code block may not be properly labeled as switch case
        (*unaff_RBX)[0] = (*unaff_RBX)[0] + uVar9;
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
        *(char *)((int64_t)pauVar20 * 2) = *(char *)((int64_t)pauVar20 * 2) + uVar9;
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
    // WARNING: Bad instruction - Truncating control flow here
        halt_baddata();
    case (undefined (*) [16])0x15:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x16:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x17:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x18:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x19:
    // WARNING: This code block may not be properly labeled as switch case
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
        pauVar20[-8][0xb] = pauVar20[-8][0xb] + cVar11;
        puVar17 = (undefined8 *)((int64_t)&uStack_8 + iVar29);
        *(undefined8 **)((int64_t)&uStack_8 + iVar29) = unaff_RBP;
        cVar11 = '\x0f';
        do {
            unaff_RBP = unaff_RBP + -1;
            puVar17 = puVar17 + -1;
            *puVar17 = *unaff_RBP;
            cVar11 = cVar11 + -1;
        } while ('\0' < cVar11);
        *(int64_t *)(auStack_88 + iVar29) = (int64_t)&uStack_8 + iVar29;
        return (undefined (*) [16])((uint64_t)unaff_RBX & 0xff);
    case (undefined (*) [16])0x1a:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x1b:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x1c:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x1d:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x1e:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x1f:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x20:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x21:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x22:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x23:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x24:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x25:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x26:
    // WARNING: This code block may not be properly labeled as switch case
        *(uint32_t *)(unaff_RBX[4] + 0xd) =
             *(uint32_t *)(unaff_RBX[4] + 0xd) ^ (int32_t)&uStackX_20 + (int32_t)iVar29 + -0x20;
    // WARNING: Bad instruction - Truncating control flow here
        halt_baddata();
    case (undefined (*) [16])0x27:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x28:
    case (undefined (*) [16])0xc6:
    // WARNING: This code block may not be properly labeled as switch case
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x18000a84f;
        func_0x000180005e50((int64_t)&uStackX_20 + iVar29, 1);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x18000a85f;
        func_0x0001800069f0(&stack0x00000030 + iVar29);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x18000a870;
        func_0x00018045bae0(&stack0x00000030 + iVar29, 0x180698c38);
        pcVar4 = (code *)swi(3);
        pauVar20 = (undefined (*) [16])(*pcVar4)();
        return pauVar20;
    case (undefined (*) [16])0x29:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x2a:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x2b:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x2c:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x2d:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x2e:
    case (undefined (*) [16])0xe4:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x2f:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x30:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x31:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x32:
    // WARNING: This code block may not be properly labeled as switch case
        pauVar25 = (undefined (*) [16])((uint64_t)unaff_RBP & 0xffffffff);
        pauVar20 = (undefined (*) [16])(*unaff_RBX + (int64_t)*unaff_RSI);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180010191;
        *(undefined (**) [16])((int64_t)&uStackX_20 + iVar29 + -0x20) = unaff_RBX;
        *(uint64_t *)((int64_t)&uStack_10 + iVar29) = unaff_RDI;
        if (pauVar20 != pauVar25) {
            if (7 < *(uint64_t *)(pauVar20[1] + 8)) {
                puVar30 = (undefined *)((int64_t)&uStack_30 + iVar29);
                if ((0xfff < *(uint64_t *)(pauVar20[1] + 8) * 2 + 2) &&
                   (puVar30 = (undefined *)((int64_t)&uStack_30 + iVar29),
                   0x1f < (*(int64_t *)*pauVar20 - *(int64_t *)(*(int64_t *)*pauVar20 + -8)) - 8U)) {
                    pcVar4 = (code *)swi(0x29);
                    (*pcVar4)(5);
                    puVar30 = auStack_28 + iVar29;
                }
                *(undefined8 *)(puVar30 + -8) = 0x18000b1f9;
                func_0x000180459c3c();
            }
            *(undefined8 *)(pauVar20[1] + 8) = 7;
            *(undefined8 *)pauVar20[1] = 0;
            *(undefined2 *)*pauVar20 = 0;
            uVar53 = *(undefined4 *)(*pauVar25 + 4);
            uVar54 = *(undefined4 *)(*pauVar25 + 8);
            uVar55 = *(undefined4 *)(*pauVar25 + 0xc);
            *(undefined4 *)*pauVar20 = *(undefined4 *)*pauVar25;
            *(undefined4 *)(*pauVar20 + 4) = uVar53;
            *(undefined4 *)(*pauVar20 + 8) = uVar54;
            *(undefined4 *)(*pauVar20 + 0xc) = uVar55;
            uVar53 = *(undefined4 *)(pauVar25[1] + 4);
            uVar54 = *(undefined4 *)(pauVar25[1] + 8);
            uVar55 = *(undefined4 *)(pauVar25[1] + 0xc);
            *(undefined4 *)pauVar20[1] = *(undefined4 *)pauVar25[1];
            *(undefined4 *)(pauVar20[1] + 4) = uVar53;
            *(undefined4 *)(pauVar20[1] + 8) = uVar54;
            *(undefined4 *)(pauVar20[1] + 0xc) = uVar55;
            *(undefined8 *)pauVar25[1] = 0;
            *(undefined8 *)(pauVar25[1] + 8) = 7;
            *(undefined2 *)*pauVar25 = 0;
        }
        return pauVar20;
    case (undefined (*) [16])0x33:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x34:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x35:
    // WARNING: This code block may not be properly labeled as switch case
        *puVar33 = *puVar33;
        unaff_RBX[0x6f7440f][9] = unaff_RBX[0x6f7440f][9] + uVar9;
        break;
    case (undefined (*) [16])0x36:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x37:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x38:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x39:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x3a:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x3b:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x3c:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x3d:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x3e:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x3f:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x40:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x41:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x42:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x43:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x44:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x45:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x46:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x47:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x48:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x49:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x4a:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x4b:
    // WARNING: This code block may not be properly labeled as switch case
        *(uint32_t *)*pauVar20 = *(int32_t *)*pauVar20 + uVar15;
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
        *(uint32_t *)*pauVar20 = *(int32_t *)*pauVar20 + uVar15;
        (*pauVar20)[0xf] = (*pauVar20)[0xf] + cVar11;
    // WARNING: Bad instruction - Truncating control flow here
        halt_baddata();
    case (undefined (*) [16])0x4c:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x4d:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x4e:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x4f:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x50:
    // WARNING: This code block may not be properly labeled as switch case
        pcVar4 = (code *)swi(3);
        pauVar20 = (undefined (*) [16])(*pcVar4)();
        return pauVar20;
    case (undefined (*) [16])0x51:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x52:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x53:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x54:
    case (undefined (*) [16])0x6b:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x55:
    // WARNING: This code block may not be properly labeled as switch case
        out(0x7c, uVar15);
    // WARNING: Bad instruction - Truncating control flow here
        halt_baddata();
    case (undefined (*) [16])0x56:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x57:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x58:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x59:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x5a:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x5b:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x5c:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x5d:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x5e:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x5f:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x60:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x61:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x62:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x63:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x64:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x65:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x66:
    // WARNING: This code block may not be properly labeled as switch case
        uVar51 = (uint64_t)*(uint32_t *)(&stack0x00000088 + iVar29);
        do {
            iVar16 = (param_3 * uVar37 & unaff_RBP[6]) * 0x10;
            ppauVar31 = (undefined (**) [16])(iVar16 + uVar51);
            ppauVar26 = (undefined (**) [16])(uVar51 + 8 + iVar16);
            *(undefined (***) [16])(&stack0x00000070 + iVar29) = ppauVar26;
            pauVar20 = *ppauVar26;
            pauVar25 = unaff_RBX;
            while( true ) {
                unaff_RBX = *(undefined (**) [16])*pauVar25;
                *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x18000b062;
                func_0x00018000d070(pauVar25 + 1);
                *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x18000b06f;
                pauVar27 = (undefined (*) [16])func_0x000180459c3c(pauVar25, 0x20);
                unaff_RBP[2] = unaff_RBP[2] + -1;
                if (pauVar25 == pauVar20) break;
                pauVar25 = unaff_RBX;
                if (unaff_RBX == unaff_R14) {
                    *ppauVar31 = unaff_RBX;
                    goto code_r0x00018000af2c;
                }
            }
            pauVar27 = *(undefined (**) [16])(&stack0x00000070 + iVar29);
            *ppauVar31 = unaff_R14;
            *(undefined (**) [16])*pauVar27 = unaff_R14;
            if (unaff_RBX == unaff_R14) {
code_r0x00018000af2c:
                *unaff_R12 = unaff_RBX;
                *(undefined (***) [16])(*unaff_RBX + 8) = unaff_R12;
                return pauVar27;
            }
            uVar51 = *(uint64_t *)unaff_RBX[1];
            uVar37 = 0x100000001b3;
            param_3 = (((((((uVar51 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (int64_t)uVar51 >> 8 & 0xffU) *
                           0x100000001b3 ^ (int64_t)uVar51 >> 0x10 & 0xffU) * 0x100000001b3 ^
                         (int64_t)uVar51 >> 0x18 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar51 >> 0x20 & 0xffU) *
                        0x100000001b3 ^ (int64_t)uVar51 >> 0x28 & 0xffU) * 0x100000001b3 ^
                      (int64_t)uVar51 >> 0x30 & 0xffU) * 0x100000001b3 ^ (int64_t)uVar51 >> 0x38 & 0xffU;
            uVar51 = *(uint64_t *)(&stack0x00000088 + iVar29);
        } while( true );
    case (undefined (*) [16])0x67:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x68:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x69:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x6a:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x6c:
    // WARNING: This code block may not be properly labeled as switch case
        puVar17 = (undefined8 *)(puVar33 + -(int64_t)pauVar20);
        *(undefined (**) [16])((int64_t)apauStackX_8 + iVar29) = unaff_RBX;
        *(uint64_t *)((int64_t)&uStack_8 + iVar29) = unaff_RDI;
        pauVar20 = (undefined (*) [16])(puVar17 + -2);
        *(undefined8 *)((int64_t)*(int32_t *)(*(int64_t *)*pauVar20 + 4) + -0x10 + (int64_t)puVar17) = 0x1804a54f0;
        iVar14 = *(int32_t *)(*(int64_t *)*pauVar20 + 4);
        *(int32_t *)((int64_t)iVar14 + -0x14 + (int64_t)puVar17) = iVar14 + -0x10;
        *puVar17 = 0x1804a54d0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar29) = 0x18000d222;
        func_0x000180455c14();
        if (((uint64_t)param_2 & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar29) = 0x18000d235;
            func_0x000180459c3c(pauVar20, 0x70);
        }
        return pauVar20;
    case (undefined (*) [16])0x6d:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x6e:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x6f:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x70:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x71:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x72:
    // WARNING: This code block may not be properly labeled as switch case
        pauVar20[0x245c8b4][8] = pauVar20[0x245c8b4][8] + (char)param_2;
    // WARNING: Bad instruction - Truncating control flow here
        halt_baddata();
    case (undefined (*) [16])0x73:
    case (undefined (*) [16])0x8e:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x74:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x75:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x76:
    // WARNING: This code block may not be properly labeled as switch case
    // WARNING: Bad instruction - Truncating control flow here
        halt_baddata();
    case (undefined (*) [16])0x77:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x78:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x7a:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x7b:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x7c:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x7d:
        puVar17 = (undefined8 *)((int64_t)&uStack_8 + iVar29);
    // WARNING: This code block may not be properly labeled as switch case
        *(undefined8 **)((int64_t)&uStack_8 + iVar29) = unaff_RBP;
        cVar11 = '\x15';
        do {
            unaff_RBP = unaff_RBP + -1;
            puVar17 = puVar17 + -1;
            *puVar17 = *unaff_RBP;
            cVar11 = cVar11 + -1;
        } while ('\0' < cVar11);
        *(int64_t *)(auStack_b8 + iVar29) = (int64_t)&uStack_8 + iVar29;
        return pauVar20;
    case (undefined (*) [16])0x7e:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x7f:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x80:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x81:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x82:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x83:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x84:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x85:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x86:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x87:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x88:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x89:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x8a:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x8b:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x8c:
        goto code_r0x00018000a024;
    case (undefined (*) [16])0x8d:
    // WARNING: This code block may not be properly labeled as switch case
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
        (*unaff_RBX)[0] = (*unaff_RBX)[0] + cVar11;
        (*pauVar20)[unaff_GS_OFFSET] = (*pauVar20)[unaff_GS_OFFSET] + (char)((uint64_t)puVar33 >> 8);
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
        *(undefined *)unaff_RBP = *(undefined *)unaff_RBP;
        *(uint32_t *)*pauVar20 = *(int32_t *)*pauVar20 + uVar15;
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
    // WARNING: Bad instruction - Truncating control flow here
        halt_baddata();
    case (undefined (*) [16])0x8f:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x90:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x91:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x92:
    case (undefined (*) [16])0x95:
    // WARNING: This code block may not be properly labeled as switch case
        (*pauVar20)[0] = (*pauVar20)[0] + uVar9;
        do {
            iVar13 = iVar14;
            if ((*(int16_t *)((int64_t)unaff_RBP + -0x3c) != 0x2e) ||
               ((*(int16_t *)((int64_t)unaff_RBP + -0x3a) != 0 &&
                ((*(int16_t *)((int64_t)unaff_RBP + -0x3a) != 0x2e || (*(int16_t *)(unaff_RBP + -7) != 0)))))) break;
            *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x1800080b9;
            iVar13 = func_0x000180454fdc(uVar53, unaff_RBP + -0xd);
            uVar53 = extraout_XMM0_Da;
        } while (iVar13 == 0);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x18000817f;
        func_0x00018000dc80();
        if (iVar13 == 0) {
            cVar11 = '\x01';
            *(int32_t *)((int64_t)unaff_RBP + 0x1ec) = iVar14;
        } else {
            if (iVar13 == 0x12) {
                *(int32_t *)((int64_t)unaff_RBP + 0x1ec) = iVar14;
            } else {
                *(int32_t *)((int64_t)unaff_RBP + 0x1ec) = iVar13;
            }
            cVar11 = '\0';
        }
        *(undefined2 *)((int64_t)unaff_RBP + 0x1e9) = *(undefined2 *)(&stack0x00000031 + iVar29);
        uVar10 = (&stack0x00000033)[iVar29];
        *(char *)(unaff_RBP + 0x3d) = cVar11;
        *(undefined *)((int64_t)unaff_RBP + 0x1eb) = uVar10;
        if (cVar11 != '\0') {
            *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x1800081d4;
            pauVar20 = (undefined (*) [16])func_0x000180459890(0x58);
            *(undefined (**) [16])(&stack0x00000030 + iVar29) = pauVar20;
            *pauVar20 = ZEXT816(0);
            *(undefined4 *)(*pauVar20 + 8) = 1;
            *(undefined4 *)(*pauVar20 + 0xc) = 1;
            *(undefined8 *)*pauVar20 = 0x1805ab200;
            *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x18000820b;
            func_0x000180007eb0(pauVar20 + 1, &stack0x00000070 + iVar29);
            *(undefined (**) [16])*unaff_R14 = pauVar20 + 1;
            piVar22 = *(int64_t **)(*unaff_R14 + 8);
            *(undefined (**) [16])(*unaff_R14 + 8) = pauVar20;
            if (piVar22 != (int64_t *)0x0) {
                LOCK();
                piVar1 = piVar22 + 1;
                iVar14 = *(int32_t *)piVar1;
                *(int32_t *)piVar1 = *(int32_t *)piVar1 + (int32_t)unaff_RSI;
                UNLOCK();
                if (iVar14 == 1) {
                    pcVar4 = *(code **)*piVar22;
                    *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008230;
                    (*pcVar4)(piVar22);
                    LOCK();
                    piVar2 = (int32_t *)((int64_t)piVar22 + 0xc);
                    iVar14 = *piVar2;
                    *piVar2 = *piVar2 + (int32_t)unaff_RSI;
                    UNLOCK();
                    if (iVar14 == 1) {
                        pcVar4 = *(code **)(*piVar22 + 8);
                        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008243;
                        (*pcVar4)(piVar22);
                    }
                }
            }
        }
        uVar53 = *(undefined4 *)((int64_t)unaff_RBP + 0x1ec);
        uVar18 = unaff_RBP[-0xe];
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008252;
        func_0x000180454ffc(uVar18);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x18000825c;
        func_0x00018000dc80(&stack0x00000070 + iVar29);
        *(undefined4 *)unaff_R15 = uVar53;
        *(undefined4 *)((int64_t)unaff_R15 + 4) = *(undefined4 *)((int64_t)&uStackX_20 + iVar29 + 4);
        unaff_R15[1] = (undefined (*) [16])0x1806a45e0;
        uVar37 = unaff_RBP[0x3e];
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008284;
        pauVar20 = (undefined (*) [16])func_0x000180459870(uVar37 ^ (int64_t)&uStackX_20 + iVar29 + -0x20);
        return pauVar20;
    case (undefined (*) [16])0x93:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x94:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x96:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x97:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x98:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x99:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x9a:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x9b:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x9c:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x9d:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0x9e:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xa0:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xa1:
    // WARNING: This code block may not be properly labeled as switch case
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008c8d;
        uVar53 = func_0x000180086cc0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008c9a;
        *(undefined4 *)0x1807823dc = func_0x0001800863e0(uVar53, 0xffffffff);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008cb4;
        uVar53 = func_0x000180086cc0(extraout_XMM0_Da_00, 0xffffffff, 0x1805aaed8);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008cc1;
        *(undefined4 *)0x1807823d4 = func_0x0001800863e0(uVar53, 0xffffffff);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008cd4;
        uVar53 = func_0x0001800858c0(extraout_XMM0_Da_01, 0xfffffffd);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008cfb;
        uVar53 = func_0x000180086cc0(uVar53, 0xffffd8ee, 0x1805aaee4);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008d0f;
        uVar53 = func_0x000180086cc0(uVar53, 0xffffffff, 0x1805aaeec);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008d1a;
        uVar53 = func_0x000180086570(uVar53, 0);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008d25;
        uVar53 = func_0x000180086570(uVar53, 0);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008d30;
        uVar53 = func_0x000180086570(uVar53, 0);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008d43;
        uVar53 = func_0x0001800878a0(uVar53, 3, 1);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008d50;
        *(undefined4 *)0x1807823d8 = func_0x0001800863e0(uVar53, 0xffffffff);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008d63;
        uVar53 = func_0x0001800858c0(extraout_XMM0_Da_02, 0xfffffffd);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008d77;
        uVar53 = func_0x000180086cc0(uVar53, 0xffffd8ee, 0x1805aaef0);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008d8b;
        uVar53 = func_0x000180086cc0(uVar53, 0xffffffff, 0x1805aaeec);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008d96;
        uVar53 = func_0x000180086570(uVar53, 0);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008da1;
        uVar53 = func_0x000180086570(uVar53, 0);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008db6;
        uVar53 = func_0x0001800878a0(uVar53, 2, 1);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008dc3;
        *(undefined4 *)0x1807823d0 = func_0x0001800863e0(uVar53, 0xffffffff);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008dd6;
        uVar53 = func_0x0001800858c0(extraout_XMM0_Da_03, 0xfffffffd);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008dea;
        uVar53 = func_0x000180086cc0(uVar53, 0xffffd8ee, 0x1805aaef8);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008dfe;
        func_0x000180086cc0(uVar53, 0xffffffff, 0x1805aaeec);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008e06;
        *(undefined8 *)0x1807823f0 = func_0x000180086280();
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008e17;
        uVar53 = func_0x0001800858c0(extraout_XMM0_Da_04, 0xfffffffd);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008e2b;
        uVar53 = func_0x000180086cc0(uVar53, 0xffffd8ee, 0x1805aaf04);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008e3f;
        func_0x000180086cc0(uVar53, 0xffffffff, 0x1805aaf0c);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008e47;
        *(undefined8 *)0x1807823e8 = func_0x000180086280();
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008e58;
        uVar53 = func_0x0001800858c0(extraout_XMM0_Da_05, 0xfffffffd);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008e6c;
        func_0x000180086cc0(uVar53, 0xffffd8ee, 0x1805aaf14);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008e74;
        *(undefined8 *)0x1807823e0 = func_0x000180086280();
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008e85;
        func_0x0001800858c0(extraout_XMM0_Da_06, 0xfffffffe);
        *(undefined8 *)0x180781ee8 = *(undefined8 *)(*(int64_t *)unaff_RSI[2] + 0x550);
        *(undefined8 *)(*(int64_t *)unaff_RSI[2] + 0x550) = 0x1800135b0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008eaa;
        func_0x000180018f70();
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008eb2;
        uVar53 = func_0x000180019a70();
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008ebc;
        uVar53 = func_0x0001800858c0(uVar53, 0);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008ed0;
        uVar53 = func_0x000180086cc0(uVar53, 0xffffd8ee, 0x1805aaed0);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008ee4;
        uVar53 = func_0x000180086cc0(uVar53, 0xffffffff, 0x1805aaf20);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008ef1;
        uVar53 = func_0x0001800859a0(uVar53, 0xfffffffe);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008f00;
        uVar53 = func_0x0001800868c0(uVar53, 0x1805aaf30);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008f10;
        uVar53 = func_0x0001800878a0(uVar53, 2, 1);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008f24;
        uVar53 = func_0x000180086cc0(uVar53, 0xffffffff, 0x1805aaf40);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008f38;
        uVar53 = func_0x000180086cc0(uVar53, 0xffffffff, 0x1805aaf48);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008f45;
        uVar53 = func_0x0001800859a0(uVar53, 0xfffffffe);
        *(undefined (***) [16])((int64_t)&uStackX_20 + iVar29) = unaff_R12;
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008f5f;
        uVar53 = func_0x0001800869f0(uVar53, 0x1800087d0, 0, 0);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008f6c;
        uVar53 = func_0x0001800878a0(uVar53, 2, 0);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008f76;
        func_0x0001800858c0(uVar53, 0);
        *(undefined (*) [16])(&stack0x00000350 + iVar29) = ZEXT816(0);
        *(undefined (***) [16])(&stack0x00000360 + iVar29) = unaff_R12;
        *(undefined8 *)(&stack0x00000368 + iVar29) = 0xf;
        (&stack0x00000350)[iVar29] = 0;
        *(undefined (*) [16])(&stack0x00000308 + iVar29) = ZEXT816(0);
        *(undefined (***) [16])(&stack0x00000318 + iVar29) = unaff_R12;
        *(undefined (***) [16])(&stack0x00000320 + iVar29) = unaff_R12;
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180008fcf;
        func_0x000180004830(&stack0x00000308 + iVar29, 0x1805aaf50, 0x1c);
        *(undefined (*) [16])(&stack0x00000070 + iVar29) = ZEXT816(0);
        *(undefined8 *)(&stack0x00000080 + iVar29) = 4;
        *(undefined8 *)(&stack0x00000088 + iVar29) = 0xf;
        *(undefined4 *)(&stack0x00000070 + iVar29) = 0x6f666e49;
        (&stack0x00000074)[iVar29] = 0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x18000901f;
        func_0x0001800758f0(&stack0x00000070 + iVar29, &stack0x00000308 + iVar29, 5, &stack0x00000350 + iVar29);
        if (0xf < *(uint64_t *)(&stack0x00000088 + iVar29)) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x18000903d;
            func_0x000180005a60(&stack0x00000070 + iVar29, *(undefined8 *)(&stack0x00000070 + iVar29));
        }
        if (0xf < *(uint64_t *)(&stack0x00000320 + iVar29)) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180009061;
            func_0x000180005a60(&stack0x00000308 + iVar29, *(undefined8 *)(&stack0x00000308 + iVar29));
        }
        *(undefined (***) [16])(&stack0x00000318 + iVar29) = unaff_R12;
        *(undefined8 *)(&stack0x00000320 + iVar29) = 0xf;
        (&stack0x00000308)[iVar29] = 0;
        param_2 = *(undefined (**) [16])(&stack0x00000368 + iVar29);
    case (undefined (*) [16])0x79:
    // WARNING: This code block may not be properly labeled as switch case
        if ((undefined (*) [16])0xf < param_2) {
            iVar16 = *(int64_t *)(&stack0x00000350 + iVar29);
            iVar35 = iVar16;
            puVar44 = (undefined *)((int64_t)&uStackX_20 + iVar29 + -0x20);
            if (((undefined *)0xfff < *param_2 + 1) &&
               (iVar35 = *(int64_t *)(iVar16 + -8), puVar44 = (undefined *)((int64_t)&uStackX_20 + iVar29 + -0x20),
               0x1f < (iVar16 - iVar35) - 8U)) {
                pcVar4 = (code *)swi(0x29);
                iVar35 = (*pcVar4)(5);
                puVar44 = (undefined *)((int64_t)apauStackX_8 + iVar29);
            }
            *(undefined8 *)(puVar44 + -8) = 0x1800090c5;
            func_0x000180459c3c(iVar35);
        }
        *(undefined8 *)(puVar44 + -8) = 0x1800090ca;
        puVar17 = (undefined8 *)func_0x0001800137d0();
        *(undefined8 **)(puVar44 + 0x68) = puVar17;
        uVar18 = *puVar17;
        uVar28 = *(undefined8 *)(*(int64_t *)*unaff_R14 + 0x70);
        *(undefined8 *)(puVar44 + -8) = 0x1800090de;
        uVar21 = func_0x00018045838c();
        *(undefined8 *)(puVar44 + -8) = 0x1800090eb;
        pauVar20 = (undefined (*) [16])func_0x000180459890(0x50);
        *(undefined (**) [16])(puVar44 + 0x38) = pauVar20;
        *pauVar20 = ZEXT816(0);
        *(undefined4 *)(*pauVar20 + 8) = 1;
        *(undefined4 *)(*pauVar20 + 0xc) = 1;
        *(undefined8 *)*pauVar20 = 0x1805ab1a0;
        *(undefined (*) [16])(puVar44 + 0x308) = ZEXT816(0);
        *(undefined (***) [16])(puVar44 + 0x318) = unaff_R12;
        *(undefined (***) [16])(puVar44 + 800) = unaff_R12;
        *(undefined8 *)(puVar44 + -8) = 0x180009147;
        func_0x000180004830(puVar44 + 0x308, 0x1805aaf80, 0x195);
        *(undefined8 *)pauVar20[1] = 0x1805ab1c8;
        uVar53 = *(undefined4 *)(puVar44 + 0x30c);
        uVar54 = *(undefined4 *)(puVar44 + 0x310);
        uVar55 = *(undefined4 *)(puVar44 + 0x314);
        *(undefined4 *)pauVar20[2] = *(undefined4 *)(puVar44 + 0x308);
        *(undefined4 *)(pauVar20[2] + 4) = uVar53;
        *(undefined4 *)(pauVar20[2] + 8) = uVar54;
        *(undefined4 *)(pauVar20[2] + 0xc) = uVar55;
        uVar53 = *(undefined4 *)(puVar44 + 0x31c);
        uVar54 = *(undefined4 *)(puVar44 + 800);
        uVar55 = *(undefined4 *)(puVar44 + 0x324);
        *(undefined4 *)pauVar20[3] = *(undefined4 *)(puVar44 + 0x318);
        *(undefined4 *)(pauVar20[3] + 4) = uVar53;
        *(undefined4 *)(pauVar20[3] + 8) = uVar54;
        *(undefined4 *)(pauVar20[3] + 0xc) = uVar55;
        *(undefined8 *)pauVar20[4] = uVar28;
        *(undefined8 *)(pauVar20[4] + 8) = uVar21;
        *(int32_t *)(pauVar20[1] + 8) = iVar14;
        uVar12 = 0x8000;
        *(undefined (**) [16])(puVar44 + 0x98) = pauVar20 + 1;
        *(undefined (**) [16])(puVar44 + 0xa0) = pauVar20;
        *(undefined8 *)(puVar44 + -8) = 0x18000919d;
        func_0x0001800082d0(puVar44 + 0x58, puVar44 + 0x98);
        *(undefined8 *)(puVar44 + -8) = 0x1800091ab;
        func_0x00018000a9d0(uVar18, puVar44 + 0x58);
        *(undefined8 *)(puVar44 + -8) = 0x1800091b6;
        func_0x000180008300(puVar44 + 0x58);
        *(undefined8 *)(puVar44 + -8) = 0x1800091c4;
        func_0x000180008300(puVar44 + 0x98);
        *(undefined8 *)(puVar44 + -8) = 0x1800091c9;
        piVar22 = (int64_t *)func_0x0001800814c0();
        iVar29 = *piVar22;
        *(undefined8 *)(puVar44 + -8) = 0x1800091dd;
        func_0x000180007340(puVar44 + 0x370, iVar29 + 0x20);
        *(undefined (*) [16])(puVar44 + 0x40) = ZEXT816(0);
        *(undefined (***) [16])(puVar44 + 0x50) = unaff_R12;
        *(int32_t *)(puVar44 + 0xb8) = iVar14;
        *(undefined8 *)(puVar44 + 0xc0) = 0x1806a45e0;
        *(undefined8 *)(puVar44 + -8) = 0x18000921d;
        func_0x000180007fb0(puVar44 + 0x58, puVar44 + 0x370, puVar44 + 0xb8);
        *(undefined8 *)(puVar44 + -8) = 0x180009230;
        uVar18 = func_0x00018000a260(puVar44 + 0x350, puVar44 + 0x58);
        *(undefined8 *)(puVar44 + -8) = 0x180009240;
        func_0x0001800082d0(puVar44 + 200, uVar18);
        *(undefined8 *)(puVar44 + -8) = 0x180009250;
        uVar18 = func_0x00018000a260(puVar44 + 0x70, puVar44 + 0x58);
        *(undefined8 *)(puVar44 + -8) = 0x180009260;
        func_0x000180008350(puVar44 + 0x350, uVar18);
        while (iVar29 = *(int64_t *)(puVar44 + 200), iVar29 != *(int64_t *)(puVar44 + 0x350)) {
            if (*(int32_t *)(puVar44 + 0xb8) == 0) {
                *(undefined8 *)(puVar44 + -8) = 0x1800092aa;
                func_0x000180007ac0(iVar29, puVar44 + 0x98, 3);
                if ((*(int32_t *)(puVar44 + 0xa0) != 0) &&
                   (uVar15 = (int32_t)*(undefined8 *)(puVar44 + 0x98) - 1, (uVar15 & 0xfffffff7) != 0)) {
                    *(undefined8 *)(puVar44 + -8) = 0x18000a1da;
                    func_0x000180007a50(uVar15, *(int32_t *)(puVar44 + 0xa0), iVar29 + 0x20);
                    goto code_r0x00018000a1db;
                }
                if ((int32_t)*(undefined8 *)(puVar44 + 0x98) != 2) goto code_r0x00018000986d;
                puVar17 = (undefined8 *)(iVar29 + 0x20);
                *(undefined8 **)(puVar44 + 0xa8) = puVar17;
                if (7 < *(uint64_t *)(iVar29 + 0x38)) {
                    puVar17 = (undefined8 *)*puVar17;
                }
                piVar40 = (int16_t *)((int64_t)puVar17 + *(int64_t *)(iVar29 + 0x30) * 2);
                *(undefined8 *)(puVar44 + -8) = 0x180009300;
                piVar24 = piVar40;
                piVar23 = (int16_t *)func_0x000180006c10();
                if (piVar23 != piVar24) {
                    do {
                        piVar8 = piVar40;
                        if ((*piVar23 != 0x5c) && (*piVar23 != 0x2f)) break;
                        piVar23 = piVar23 + 1;
                    } while (piVar23 != piVar24);
                    do {
                        piVar40 = piVar8;
                        if (piVar23 == piVar24) break;
                        piVar24 = piVar40 + -1;
                        if ((*piVar24 == 0x5c) || (piVar8 = piVar24, *piVar24 == 0x2f)) break;
                    } while( true );
                }
                *(undefined8 *)(puVar44 + -8) = 0x18000934c;
                piVar24 = (int16_t *)func_0x000180458100(piVar40);
                if ((piVar40 == piVar24) || (piVar23 = piVar24 + -1, piVar40 == piVar23)) {
code_r0x00018000938f:
                    piVar23 = piVar24;
                } else {
                    if (*piVar23 != 0x2e) {
                        for (piVar23 = piVar24 + -2; piVar40 != piVar23; piVar23 = piVar23 + -1) {
                            if (*piVar23 == 0x2e) goto code_r0x000180009392;
                        }
                        goto code_r0x00018000938f;
                    }
                    if ((piVar40 == piVar24 + -2) && (piVar24[-2] == 0x2e)) goto code_r0x00018000938f;
                }
code_r0x000180009392:
                *(undefined (*) [16])(puVar44 + 0x308) = ZEXT816(0);
                *(undefined (***) [16])(puVar44 + 0x318) = unaff_R12;
                *(undefined (***) [16])(puVar44 + 800) = unaff_R12;
                *(undefined8 *)(puVar44 + -8) = 0x1800093c3;
                func_0x00018000d380(puVar44 + 0x308, piVar23, (int64_t)piVar24 - (int64_t)piVar23 >> 1);
                puVar30 = puVar44 + 0x308;
                if (7 < *(uint64_t *)(puVar44 + 800)) {
                    puVar30 = *(undefined **)(puVar44 + 0x308);
                }
                uVar37 = *(uint64_t *)(puVar44 + 0x318);
                *(undefined8 *)(puVar44 + -8) = 0x1800093f1;
                uVar53 = func_0x000180454ce0();
                *(undefined (*) [16])(puVar44 + 0x330) = ZEXT816(0);
                *(undefined (***) [16])(puVar44 + 0x340) = unaff_R12;
                uVar51 = 0xf;
                *(undefined8 *)(puVar44 + 0x348) = 0xf;
                puVar44[0x330] = 0;
                *(uint32_t *)(puVar44 + 0x30) = uVar12 | 0x7800;
                if (uVar37 != 0) {
                    if (0x7fffffff < uVar37) {
                        *(undefined8 *)(puVar44 + -8) = 0x18000a1f4;
                        func_0x000180006180();
                        goto code_r0x00018000a1f5;
                    }
                    *(int32_t *)(puVar44 + 0x20) = iVar14;
                    *(undefined8 *)(puVar44 + -8) = 0x180009452;
                    uVar18 = func_0x000180454d50(uVar53, puVar30, uVar37 & 0xffffffff, 0);
                    *(undefined8 *)(puVar44 + 0x38) = uVar18;
                    if ((int32_t)((uint64_t)uVar18 >> 0x20) != 0) {
                        *(undefined8 *)(puVar44 + -8) = 0x18000a1ee;
                        func_0x000180006560(*(undefined4 *)(puVar44 + 0x3c));
                        pcVar4 = (code *)swi(3);
                        pauVar20 = (undefined (*) [16])(*pcVar4)();
                        return pauVar20;
                    }
                    *(undefined8 *)(puVar44 + -8) = 0x180009479;
                    func_0x00018000b3b0(puVar44 + 0x330, (int64_t)(int32_t)uVar18, 0);
                    puVar45 = puVar44 + 0x330;
                    if (0xf < *(uint64_t *)(puVar44 + 0x348)) {
                        puVar45 = *(undefined **)(puVar44 + 0x330);
                    }
                    *(int32_t *)(puVar44 + 0x20) = (int32_t)uVar18;
                    *(undefined8 *)(puVar44 + -8) = 0x1800094a4;
                    uVar18 = func_0x000180454d50(uVar53, puVar30, uVar37 & 0xffffffff, puVar45);
                    *(undefined8 *)(puVar44 + 0x38) = uVar18;
                    if ((int32_t)((uint64_t)uVar18 >> 0x20) != 0) {
code_r0x00018000a1db:
                        *(undefined8 *)(puVar44 + -8) = 0x18000a1e4;
                        func_0x000180006560(*(undefined4 *)(puVar44 + 0x3c));
                        pcVar4 = (code *)swi(3);
                        pauVar20 = (undefined (*) [16])(*pcVar4)();
                        return pauVar20;
                    }
                    uVar51 = *(uint64_t *)(puVar44 + 0x348);
                }
                *(uint32_t *)(puVar44 + 0x30) = uVar12 | 0x7000;
                uVar12 = uVar12 | 0x7700;
                if (7 < *(uint64_t *)(puVar44 + 800)) {
                    *(undefined8 *)(puVar44 + -8) = 0x1800094f1;
                    func_0x00018000f950(puVar44 + 0x308, *(undefined8 *)(puVar44 + 0x308));
                    uVar51 = *(uint64_t *)(puVar44 + 0x348);
                }
                *(undefined (***) [16])(puVar44 + 0x318) = unaff_R12;
                *(undefined8 *)(puVar44 + 800) = 7;
                uVar48 = SUB82(unaff_R12, 0);
                *(undefined2 *)(puVar44 + 0x308) = uVar48;
                puVar45 = *(undefined **)(puVar44 + 0x330);
                puVar30 = puVar44 + 0x330;
                if (0xf < uVar51) {
                    puVar30 = puVar45;
                }
                puVar33 = puVar44 + 0x330;
                if (0xf < uVar51) {
                    puVar33 = puVar45;
                }
                iVar29 = *(int64_t *)(puVar44 + 0x340);
                puVar46 = puVar44 + 0x330;
                if (0xf < uVar51) {
                    puVar46 = puVar45;
                }
                if (puVar46 != puVar33 + iVar29) {
                    do {
                        uVar10 = *puVar46;
                        *(undefined8 *)(puVar44 + -8) = 0x18000955f;
                        uVar10 = func_0x000180460320(uVar10);
                        *puVar30 = uVar10;
                        puVar30 = puVar30 + 1;
                        puVar46 = puVar46 + 1;
                    } while (puVar46 != puVar33 + iVar29);
                    uVar51 = *(uint64_t *)(puVar44 + 0x348);
                    puVar45 = *(undefined **)(puVar44 + 0x330);
                }
                puVar30 = puVar44 + 0x330;
                if (0xf < uVar51) {
                    puVar30 = puVar45;
                }
                if (*(int64_t *)(puVar44 + 0x340) == 4) {
                    uVar9 = 0x18;
                    *(undefined8 *)(puVar44 + -8) = 0x1800095a8;
                    iVar13 = func_0x000180497f30(puVar30);
                    if (iVar13 != 0) goto code_r0x0001800095ac;
code_r0x0001800095e0:
                    puVar47 = *(undefined4 **)(puVar44 + 0x48);
                    if (puVar47 == *(undefined4 **)(puVar44 + 0x50)) {
                        iVar29 = (int64_t)puVar47 - *(int64_t *)(puVar44 + 0x40) >> 5;
                        if (iVar29 == 0x7ffffffffffffff) {
                            *(undefined8 *)(puVar44 + -8) = 0x18000a200;
                            uVar15 = func_0x000180010010();
                            goto code_r0x00018000a201;
                        }
                        uVar37 = iVar29 + 1;
                        uVar51 = (int64_t)*(undefined4 **)(puVar44 + 0x50) - *(int64_t *)(puVar44 + 0x40) >> 5;
                        if (0x7ffffffffffffff - (uVar51 >> 1) < uVar51) {
                            uVar49 = 0x7ffffffffffffff;
                        } else {
                            uVar51 = (uVar51 >> 1) + uVar51;
                            uVar49 = uVar37;
                            if (uVar37 <= uVar51) {
                                uVar49 = uVar51;
                            }
                            if (0x7ffffffffffffff < uVar49) {
code_r0x00018000a1f5:
                                *(undefined8 *)(puVar44 + -8) = 0x18000a1fa;
                                func_0x000180004720();
                                pcVar4 = (code *)swi(3);
                                pauVar20 = (undefined (*) [16])(*pcVar4)();
                                return pauVar20;
                            }
                        }
                        *(uint64_t *)(puVar44 + 0x38) = uVar49 << 5;
                        *(undefined8 *)(puVar44 + -8) = 0x180009678;
                        iVar16 = func_0x000180004de0(uVar49 << 5);
                        *(int64_t *)(puVar44 + 0x30) = iVar16;
                        iVar29 = iVar29 * 0x20 + iVar16;
                        pauVar20 = (undefined (*) [16])(iVar29 + 0x20);
                        *(undefined **)(puVar44 + 0x308) = puVar44 + 0x40;
                        *(int64_t *)(puVar44 + 0x310) = iVar16;
                        *(uint64_t *)(puVar44 + 0x318) = uVar49;
                        *(undefined (**) [16])(puVar44 + 800) = pauVar20;
                        *(undefined (**) [16])(puVar44 + 0x328) = pauVar20;
                        *(undefined8 *)(puVar44 + -8) = 0x1800096c3;
                        uVar53 = func_0x000180007340(iVar29, *(undefined8 *)(puVar44 + 0xa8));
                        puVar50 = *(undefined4 **)(puVar44 + 0x48);
                        puVar41 = *(undefined4 **)(puVar44 + 0x40);
                        if (puVar47 == puVar50) {
                            pauVar20 = *(undefined (**) [16])(puVar44 + 0x30);
                            pauVar25 = pauVar20;
                            if (puVar41 != puVar50) {
                                do {
                                    *pauVar25 = ZEXT816(0);
                                    *(undefined (***) [16])pauVar25[1] = unaff_R12;
                                    *(undefined (***) [16])(pauVar25[1] + 8) = unaff_R12;
                                    uVar53 = *puVar41;
                                    uVar54 = puVar41[1];
                                    uVar55 = puVar41[2];
                                    uVar56 = puVar41[3];
                                    *(undefined4 *)*pauVar25 = uVar53;
                                    *(undefined4 *)(*pauVar25 + 4) = uVar54;
                                    *(undefined4 *)(*pauVar25 + 8) = uVar55;
                                    *(undefined4 *)(*pauVar25 + 0xc) = uVar56;
                                    uVar54 = puVar41[5];
                                    uVar55 = puVar41[6];
                                    uVar56 = puVar41[7];
                                    *(undefined4 *)pauVar25[1] = puVar41[4];
                                    *(undefined4 *)(pauVar25[1] + 4) = uVar54;
                                    *(undefined4 *)(pauVar25[1] + 8) = uVar55;
                                    *(undefined4 *)(pauVar25[1] + 0xc) = uVar56;
                                    *(undefined (***) [16])(puVar41 + 4) = unaff_R12;
                                    *(undefined8 *)(puVar41 + 6) = 7;
                                    *(undefined2 *)puVar41 = uVar48;
                                    puVar41 = puVar41 + 8;
                                    pauVar25 = pauVar25 + 2;
                                } while (puVar41 != puVar50);
                                puVar50 = *(undefined4 **)(puVar44 + 0x48);
                                puVar41 = *(undefined4 **)(puVar44 + 0x40);
                            }
                        } else {
                            pauVar25 = *(undefined (**) [16])(puVar44 + 0x30);
                            if (puVar41 != puVar47) {
                                do {
                                    *pauVar25 = ZEXT816(0);
                                    *(undefined (***) [16])pauVar25[1] = unaff_R12;
                                    *(undefined (***) [16])(pauVar25[1] + 8) = unaff_R12;
                                    uVar53 = *puVar41;
                                    uVar54 = puVar41[1];
                                    uVar55 = puVar41[2];
                                    uVar56 = puVar41[3];
                                    *(undefined4 *)*pauVar25 = uVar53;
                                    *(undefined4 *)(*pauVar25 + 4) = uVar54;
                                    *(undefined4 *)(*pauVar25 + 8) = uVar55;
                                    *(undefined4 *)(*pauVar25 + 0xc) = uVar56;
                                    uVar54 = puVar41[5];
                                    uVar55 = puVar41[6];
                                    uVar56 = puVar41[7];
                                    *(undefined4 *)pauVar25[1] = puVar41[4];
                                    *(undefined4 *)(pauVar25[1] + 4) = uVar54;
                                    *(undefined4 *)(pauVar25[1] + 8) = uVar55;
                                    *(undefined4 *)(pauVar25[1] + 0xc) = uVar56;
                                    *(undefined (***) [16])(puVar41 + 4) = unaff_R12;
                                    *(undefined8 *)(puVar41 + 6) = 7;
                                    *(undefined2 *)puVar41 = uVar48;
                                    pauVar25 = pauVar25 + 2;
                                    puVar41 = puVar41 + 8;
                                } while (puVar41 != puVar47);
                                puVar50 = *(undefined4 **)(puVar44 + 0x48);
                                puVar41 = *(undefined4 **)(puVar44 + 0x40);
                            }
                            if (puVar47 != puVar50) {
                                do {
                                    *pauVar20 = ZEXT816(0);
                                    *(undefined (***) [16])pauVar20[1] = unaff_R12;
                                    *(undefined (***) [16])(pauVar20[1] + 8) = unaff_R12;
                                    uVar53 = *puVar47;
                                    uVar54 = puVar47[1];
                                    uVar55 = puVar47[2];
                                    uVar56 = puVar47[3];
                                    *(undefined4 *)*pauVar20 = uVar53;
                                    *(undefined4 *)(*pauVar20 + 4) = uVar54;
                                    *(undefined4 *)(*pauVar20 + 8) = uVar55;
                                    *(undefined4 *)(*pauVar20 + 0xc) = uVar56;
                                    uVar54 = puVar47[5];
                                    uVar55 = puVar47[6];
                                    uVar56 = puVar47[7];
                                    *(undefined4 *)pauVar20[1] = puVar47[4];
                                    *(undefined4 *)(pauVar20[1] + 4) = uVar54;
                                    *(undefined4 *)(pauVar20[1] + 8) = uVar55;
                                    *(undefined4 *)(pauVar20[1] + 0xc) = uVar56;
                                    *(undefined (***) [16])(puVar47 + 4) = unaff_R12;
                                    *(undefined8 *)(puVar47 + 6) = 7;
                                    *(undefined2 *)puVar47 = uVar48;
                                    pauVar20 = pauVar20 + 2;
                                    puVar47 = puVar47 + 8;
                                } while (puVar47 != puVar50);
                                puVar50 = *(undefined4 **)(puVar44 + 0x48);
                                puVar41 = *(undefined4 **)(puVar44 + 0x40);
                            }
                            pauVar20 = *(undefined (**) [16])(puVar44 + 0x30);
                        }
                        if (puVar41 != (undefined4 *)0x0) {
                            if (puVar41 != puVar50) {
                                do {
                                    *(undefined8 *)(puVar44 + -8) = 0x1800097ea;
                                    uVar53 = func_0x00018000dc80(puVar41);
                                    puVar41 = puVar41 + 8;
                                } while (puVar41 != puVar50);
                                puVar41 = *(undefined4 **)(puVar44 + 0x40);
                            }
                            *(undefined8 *)(puVar44 + -8) = 0x18000980c;
                            func_0x00018000f770(uVar53, puVar41, *(int64_t *)(puVar44 + 0x50) - (int64_t)puVar41 >> 5);
                        }
                        *(undefined (**) [16])(puVar44 + 0x40) = pauVar20;
                        *(undefined (**) [16])(puVar44 + 0x48) = pauVar20 + uVar37 * 2;
                        *(undefined **)(puVar44 + 0x50) = *pauVar20 + *(int64_t *)(puVar44 + 0x38);
                    } else {
                        *(undefined8 *)(puVar44 + -8) = 0x1800095ff;
                        func_0x000180007340(puVar47, *(undefined8 *)(puVar44 + 0xa8));
                        *(int64_t *)(puVar44 + 0x48) = *(int64_t *)(puVar44 + 0x48) + 0x20;
                    }
                    puVar45 = *(undefined **)(puVar44 + 0x330);
                    uVar51 = *(uint64_t *)(puVar44 + 0x348);
                } else {
code_r0x0001800095ac:
                    uVar9 = 0x20;
                    *(undefined8 *)(puVar44 + -8) = 0x1800095c0;
                    cVar11 = func_0x00018000a630(puVar44 + 0x330);
                    if (cVar11 != '\0') goto code_r0x0001800095e0;
                    uVar9 = 0x28;
                    *(undefined8 *)(puVar44 + -8) = 0x1800095d8;
                    cVar11 = func_0x00018000a630(puVar44 + 0x330);
                    if (cVar11 != '\0') goto code_r0x0001800095e0;
                }
                if (0xf < uVar51) {
                    uVar37 = uVar51 + 1;
                    puVar30 = puVar45;
                    if (0xfff < uVar37) {
                        puVar30 = *(undefined **)(puVar45 + -8);
                        if ((undefined *)0x1f < puVar45 + (-8 - (int64_t)puVar30)) {
                            pcVar4 = (code *)swi(0x29);
                            (*pcVar4)(5);
                            puVar44 = puVar44 + 8;
                            break;
                        }
                        uVar37 = uVar51 + 0x28;
                    }
                    *(undefined8 *)(puVar44 + -8) = 0x18000986d;
                    func_0x000180459c3c(puVar30, uVar37);
                }
            }
code_r0x00018000986d:
            *(undefined8 *)(puVar44 + -8) = 0x18000987a;
            iVar13 = func_0x000180007c30(puVar44 + 200);
            if (iVar13 != 0) {
                *(undefined8 *)(puVar44 + -8) = 0x18000a1d0;
                func_0x000180007960(extraout_XMM0_Da_07, iVar13);
                pcVar4 = (code *)swi(3);
                pauVar20 = (undefined (*) [16])(*pcVar4)();
                return pauVar20;
            }
        }
        piVar22 = *(int64_t **)(puVar44 + 0x358);
        if (piVar22 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar22 + 1;
            iVar13 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar13 == 1) {
                pcVar4 = *(code **)*piVar22;
                *(undefined8 *)(puVar44 + -8) = 0x1800098b2;
                (*pcVar4)(piVar22);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar22 + 0xc);
                iVar13 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar13 == 1) {
                    pcVar4 = *(code **)(*piVar22 + 8);
                    *(undefined8 *)(puVar44 + -8) = 0x1800098ca;
                    (*pcVar4)(piVar22);
                }
            }
        }
        piVar22 = *(int64_t **)(puVar44 + 0xd0);
        if (piVar22 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar22 + 1;
            iVar13 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar13 == 1) {
                pcVar4 = *(code **)*piVar22;
                *(undefined8 *)(puVar44 + -8) = 0x1800098ef;
                (*pcVar4)(piVar22);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar22 + 0xc);
                iVar13 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar13 == 1) {
                    pcVar4 = *(code **)(*piVar22 + 8);
                    *(undefined8 *)(puVar44 + -8) = 0x180009907;
                    (*pcVar4)(piVar22);
                }
            }
        }
        piVar22 = *(int64_t **)(puVar44 + 0x60);
        if (piVar22 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar22 + 1;
            iVar13 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar13 == 1) {
                pcVar4 = *(code **)*piVar22;
                *(undefined8 *)(puVar44 + -8) = 0x180009929;
                (*pcVar4)(piVar22);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar22 + 0xc);
                iVar13 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar13 == 1) {
                    pcVar4 = *(code **)(*piVar22 + 8);
                    *(undefined8 *)(puVar44 + -8) = 0x180009941;
                    (*pcVar4)(piVar22);
                }
            }
        }
        *(undefined8 *)(puVar44 + -8) = 0x18000995d;
        func_0x00018000e3a0(*(int64_t *)(puVar44 + 0x40), *(int64_t *)(puVar44 + 0x48), 
                            *(int64_t *)(puVar44 + 0x48) - *(int64_t *)(puVar44 + 0x40) >> 5, 0);
        puVar17 = *(undefined8 **)(puVar44 + 0x40);
        puVar32 = *(undefined8 **)(puVar44 + 0x48);
        if (puVar17 != puVar32) {
            do {
                puVar42 = puVar17;
                if (7 < (uint64_t)puVar17[3]) {
                    puVar42 = (undefined8 *)*puVar17;
                }
                *(undefined8 *)(puVar44 + 0xe0) = 0x1805ab198;
                *(undefined (***) [16])(puVar44 + 0x198) = unaff_R12;
                *(undefined8 *)(puVar44 + 0x1a0) = 0;
                *(int32_t *)(puVar44 + 0x1a8) = iVar14;
                *(undefined (*) [16])(puVar44 + 0x1b0) = ZEXT816(0);
                *(undefined (*) [16])(puVar44 + 0x1c0) = ZEXT816(0);
                *(undefined (*) [16])(puVar44 + 0x1d0) = ZEXT816(0);
                *(undefined (***) [16])(puVar44 + 0x1e0) = unaff_R12;
                puVar44[0x1e8] = 0;
                *(uint32_t *)(puVar44 + 0x30) = uVar12 | 2;
                *(undefined8 *)(puVar44 + 400) = 0x1804a5600;
                *(undefined4 *)(puVar44 + 0x18c) = 0x98;
                *(undefined (***) [16])(puVar44 + 0xe8) = unaff_R12;
                *(undefined8 *)(puVar44 + -8) = 0x180009a2c;
                func_0x00018000fe50(puVar44 + 400, puVar44 + 0xf0, 0);
                *(undefined8 *)(puVar44 + (int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4) + 0xe0) = 0x1805ab280;
                *(int32_t *)(puVar44 + (int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4) + 0xdc) =
                     *(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4) + -0xb0;
                *(undefined8 *)(puVar44 + -8) = 0x180009a69;
                func_0x00018000fa40(puVar44 + 0xf0);
                *(undefined8 *)(puVar44 + -8) = 0x180009a80;
                iVar29 = func_0x00018000f990(puVar44 + 0xf0, puVar42);
                if (iVar29 == 0) {
                    iVar29 = (int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4);
                    uVar9 = 2;
                    uVar15 = 6;
                    if (*(int64_t *)(puVar44 + iVar29 + 0x128) != 0) {
                        uVar15 = 2;
                    }
                    uVar3 = *(uint32_t *)(puVar44 + iVar29 + 0xf0);
                    *(uint32_t *)(puVar44 + iVar29 + 0xf0) = uVar15 | uVar3 & 0x17;
                    uVar15 = (uVar15 | uVar3 & 0x17) & *(uint32_t *)(puVar44 + iVar29 + 0xf4);
                    if (uVar15 != 0) {
code_r0x00018000a201:
                        if ((uVar15 & 4) == 0) {
                            uVar18 = 0x1805aae00;
                            if ((uVar9 & (uint8_t)uVar15) == 0) {
                                uVar18 = 0x1805aae18;
                            }
                        } else {
                            uVar18 = 0x1805aade8;
                        }
                        *(undefined8 *)(puVar44 + -8) = 0x18000a231;
                        uVar28 = func_0x000180005e50(puVar44 + 0x70, 1);
                        *(undefined8 *)(puVar44 + -8) = 0x18000a244;
                        func_0x0001800069f0(puVar44 + 0x2e0, uVar18, uVar28);
                        *(undefined8 *)(puVar44 + -8) = 0x18000a258;
                        func_0x00018045bae0(puVar44 + 0x2e0, 0x180698c38);
                        pcVar4 = (code *)swi(3);
                        pauVar20 = (undefined (*) [16])(*pcVar4)();
                        return pauVar20;
                    }
                }
                *(undefined8 *)(puVar44 + (int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4) + 0xe0) = 0x1805ab280;
                *(int32_t *)(puVar44 + (int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4) + 0xdc) =
                     *(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4) + -0xb0;
                if ((puVar44[(int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4) + 0xf0] & 6) == 0) {
                    *(undefined8 *)(puVar44 + 0x1f0) = 0x1805ab1e0;
                    *(undefined (***) [16])(puVar44 + 0x280) = unaff_R12;
                    *(undefined8 *)(puVar44 + 0x288) = 0;
                    *(int32_t *)(puVar44 + 0x290) = iVar14;
                    *(undefined (***) [16])(puVar44 + 0x298) = unaff_R12;
                    *(undefined (*) [16])(puVar44 + 0x2a0) = ZEXT816(0);
                    *(undefined (*) [16])(puVar44 + 0x2b0) = ZEXT816(0);
                    *(undefined (*) [16])(puVar44 + 0x2c0) = ZEXT816(0);
                    puVar44[0x2d0] = 0;
                    *(uint32_t *)(puVar44 + 0x30) = uVar12 | 0x12;
                    *(undefined8 *)(puVar44 + 0x278) = 0x1804a54f0;
                    *(undefined4 *)(puVar44 + 0x274) = 0x78;
                    *(undefined8 *)(puVar44 + -8) = 0x180009c20;
                    func_0x00018000fe50(puVar44 + 0x278, puVar44 + 0x1f8, 0);
                    *(undefined8 *)(puVar44 + (int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0x1f0) + 4) + 0x1f0) =
                         0x1804a6448;
                    *(int32_t *)(puVar44 + (int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0x1f0) + 4) + 0x1ec) =
                         *(int32_t *)(*(int64_t *)(puVar44 + 0x1f0) + 4) + -0x88;
                    *(undefined8 *)(puVar44 + -8) = 0x180009c62;
                    func_0x00018000fd90(puVar44 + 0x1f8);
                    *(undefined8 *)(puVar44 + 0x1f8) = 0x1804a5580;
                    *(undefined (***) [16])(puVar44 + 0x260) = unaff_R12;
                    *(undefined4 *)(puVar44 + 0x268) = 4;
                    *(undefined8 *)(puVar44 + -8) = 0x180009c99;
                    func_0x00018000ca80(puVar44 + 0x1f0, puVar44 + 0xf0);
                    uVar18 = **(undefined8 **)(puVar44 + 0x68);
                    *(undefined (*) [16])(puVar44 + 0x308) = ZEXT816(0);
                    *(undefined (***) [16])(puVar44 + 0x318) = unaff_R12;
                    *(undefined8 *)(puVar44 + 800) = 0xf;
                    puVar44[0x308] = 0;
                    *(uint32_t *)(puVar44 + 0x30) = uVar12 | 0x92;
                    *(undefined (*) [16])(puVar44 + 0x70) = ZEXT816(0);
                    *(undefined8 *)(puVar44 + 0x80) = 0;
                    if ((((uint8_t)*(uint32_t *)(puVar44 + 0x268) & 0x22) == 2) ||
                       (**(int64_t **)(puVar44 + 0x238) == 0)) {
                        if ((*(uint32_t *)(puVar44 + 0x268) & 4) == 0) {
                            if (**(int64_t **)(puVar44 + 0x230) == 0) {
                                ppauVar31 = unaff_R12;
                                ppauVar26 = *(undefined (***) [16])(puVar44 + 0x70);
                            } else {
                                ppauVar31 = (undefined (**) [16])**(uint64_t ***)(puVar44 + 0x210);
                                ppauVar26 = (undefined (**) [16])**(uint64_t ***)(puVar44 + 0x210);
                            }
                            goto code_r0x000180009d67;
                        }
                    } else {
                        ppauVar31 = (undefined (**) [16])**(uint64_t ***)(puVar44 + 0x218);
                        ppauVar26 = ppauVar31;
code_r0x000180009d67:
                        if (ppauVar31 != (undefined (**) [16])0x0) {
                            *(undefined8 *)(puVar44 + -8) = 0x180009d79;
                            func_0x00018000f180(puVar44 + 0x308, ppauVar26);
                        }
                    }
                    *(uint32_t *)(puVar44 + 0x30) = uVar12 | 0x52;
                    uVar28 = *(undefined8 *)(**(int64_t **)(puVar44 + 0x3d8) + 0x70);
                    *(undefined8 *)(puVar44 + -8) = 0x180009d9b;
                    uVar21 = func_0x00018045838c();
                    *(undefined8 *)(puVar44 + -8) = 0x180009da8;
                    pauVar20 = (undefined (*) [16])func_0x000180459890(0x50);
                    *(undefined (**) [16])(puVar44 + 0x38) = pauVar20;
                    *pauVar20 = ZEXT816(0);
                    *(undefined4 *)(*pauVar20 + 8) = 1;
                    *(undefined4 *)(*pauVar20 + 0xc) = 1;
                    *(undefined8 *)*pauVar20 = 0x1805ab1a0;
                    *(undefined8 *)pauVar20[1] = 0x1805ab1c8;
                    uVar53 = *(undefined4 *)(puVar44 + 0x30c);
                    uVar54 = *(undefined4 *)(puVar44 + 0x310);
                    uVar55 = *(undefined4 *)(puVar44 + 0x314);
                    *(undefined4 *)pauVar20[2] = *(undefined4 *)(puVar44 + 0x308);
                    *(undefined4 *)(pauVar20[2] + 4) = uVar53;
                    *(undefined4 *)(pauVar20[2] + 8) = uVar54;
                    *(undefined4 *)(pauVar20[2] + 0xc) = uVar55;
                    uVar53 = *(undefined4 *)(puVar44 + 0x31c);
                    uVar54 = *(undefined4 *)(puVar44 + 800);
                    uVar55 = *(undefined4 *)(puVar44 + 0x324);
                    *(undefined4 *)pauVar20[3] = *(undefined4 *)(puVar44 + 0x318);
                    *(undefined4 *)(pauVar20[3] + 4) = uVar53;
                    *(undefined4 *)(pauVar20[3] + 8) = uVar54;
                    *(undefined4 *)(pauVar20[3] + 0xc) = uVar55;
                    *(undefined (***) [16])(puVar44 + 0x318) = unaff_R12;
                    *(undefined8 *)(puVar44 + 800) = 0xf;
                    puVar44[0x308] = 0;
                    *(undefined8 *)pauVar20[4] = uVar28;
                    *(undefined8 *)(pauVar20[4] + 8) = uVar21;
                    *(int32_t *)(pauVar20[1] + 8) = iVar14;
                    uVar12 = uVar12 | 0x5a;
                    *(undefined (**) [16])(puVar44 + 0x58) = pauVar20 + 1;
                    *(undefined (**) [16])(puVar44 + 0x60) = pauVar20;
                    *(undefined (*) [16])(puVar44 + 0x70) = ZEXT816(0);
                    *(undefined8 *)(puVar44 + -8) = 0x180009e3d;
                    func_0x00018000a9d0(uVar18, puVar44 + 0x58);
                    piVar22 = *(int64_t **)(puVar44 + 0x60);
                    if (piVar22 != (int64_t *)0x0) {
                        LOCK();
                        piVar1 = piVar22 + 1;
                        iVar13 = *(int32_t *)piVar1;
                        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                        UNLOCK();
                        if (iVar13 == 1) {
                            pcVar4 = *(code **)*piVar22;
                            *(undefined8 *)(puVar44 + -8) = 0x180009e5f;
                            (*pcVar4)(piVar22);
                            LOCK();
                            piVar2 = (int32_t *)((int64_t)piVar22 + 0xc);
                            iVar13 = *piVar2;
                            *piVar2 = *piVar2 + -1;
                            UNLOCK();
                            if (iVar13 == 1) {
                                pcVar4 = *(code **)(*piVar22 + 8);
                                *(undefined8 *)(puVar44 + -8) = 0x180009e77;
                                (*pcVar4)(piVar22);
                            }
                        }
                    }
                    *(undefined8 *)(puVar44 + (int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0x1f0) + 4) + 0x1f0) =
                         0x1804a6448;
                    *(int32_t *)(puVar44 + (int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0x1f0) + 4) + 0x1ec) =
                         *(int32_t *)(*(int64_t *)(puVar44 + 0x1f0) + 4) + -0x88;
                    *(undefined8 *)(puVar44 + -8) = 0x180009eb9;
                    func_0x00018000c970(puVar44 + 0x1f8);
                    *(undefined8 *)(puVar44 + (int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0x1f0) + 4) + 0x1f0) =
                         0x1804a54f0;
                    *(int32_t *)(puVar44 + (int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0x1f0) + 4) + 0x1ec) =
                         *(int32_t *)(*(int64_t *)(puVar44 + 0x1f0) + 4) + -0x10;
                    *(undefined8 *)(puVar44 + 0x278) = 0x1804a54d0;
                    *(undefined8 *)(puVar44 + -8) = 0x180009f06;
                    func_0x000180455c14(puVar44 + 0x278);
                    *(undefined8 *)(puVar44 + (int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4) + 0xe0) =
                         0x1805ab280;
                    *(int32_t *)(puVar44 + (int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4) + 0xdc) =
                         *(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4) + -0xb0;
                    *(undefined8 *)(puVar44 + -8) = 0x180009f48;
                    func_0x00018000c170(puVar44 + 0xf0);
                    *(undefined8 *)(puVar44 + (int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4) + 0xe0) =
                         0x1804a5600;
                    *(int32_t *)(puVar44 + (int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4) + 0xdc) =
                         *(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4) + -0x18;
                    *(undefined8 *)(puVar44 + 400) = 0x1804a54d0;
                    *(undefined8 *)(puVar44 + -8) = 0x180009f8e;
                    func_0x000180455c14(puVar44 + 400);
                } else {
                    *(undefined8 *)(puVar44 + (int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4) + 0xe0) =
                         0x1805ab280;
                    *(int32_t *)(puVar44 + (int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4) + 0xdc) =
                         *(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4) + -0xb0;
                    *(undefined8 *)(puVar44 + -8) = 0x180009b36;
                    func_0x00018000c170(puVar44 + 0xf0);
                    *(undefined8 *)(puVar44 + (int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4) + 0xe0) =
                         0x1804a5600;
                    *(int32_t *)(puVar44 + (int64_t)*(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4) + 0xdc) =
                         *(int32_t *)(*(int64_t *)(puVar44 + 0xe0) + 4) + -0x18;
                    *(undefined8 *)(puVar44 + 400) = 0x1804a54d0;
                    *(undefined8 *)(puVar44 + -8) = 0x180009b7c;
                    func_0x000180455c14(puVar44 + 400);
                    uVar12 = uVar12 | 2;
                }
                puVar17 = puVar17 + 4;
            } while (puVar17 != puVar32);
            puVar17 = *(undefined8 **)(puVar44 + 0x40);
        }
        unaff_R15 = *(undefined (***) [16])(puVar44 + 0x68);
        unaff_R14 = *unaff_R15;
        if (*(int64_t *)unaff_R14[0xe] != 0) {
            do {
                unaff_RSI = *(undefined (**) [16])
                             (*(int64_t *)(unaff_R14[0xc] + 8) +
                             (*(int64_t *)unaff_R14[0xd] - 1U & *(uint64_t *)(unaff_R14[0xd] + 8)) * 8);
                unaff_RDI = *(uint64_t *)(**(int64_t **)(puVar44 + 0x3d8) + 0x70);
                *(undefined8 *)(puVar44 + -8) = 0x180009ff0;
                unaff_RBX = (undefined (*) [16])func_0x00018045838c();
                *(undefined8 *)(puVar44 + -8) = 0x180009ffd;
                pauVar20 = (undefined (*) [16])func_0x000180459890(0x50);
                *(undefined (**) [16])(puVar44 + 0x38) = pauVar20;
                uVar53 = 0;
                uVar54 = 0;
                uVar55 = 0;
                uVar56 = 0;
                *pauVar20 = ZEXT816(0);
                *(undefined4 *)(*pauVar20 + 8) = 1;
                *(undefined4 *)(*pauVar20 + 0xc) = 1;
                *(undefined8 *)*pauVar20 = 0x1805ab1a0;
                param_2 = pauVar20 + 1;
                puVar45 = puVar44;
code_r0x00018000a024:
                puVar44 = puVar45;
    // WARNING: This code block may not be properly labeled as switch case
                *(undefined4 *)(*param_2 + 8) = 2;
                *(undefined8 *)*param_2 = 0x1805ab1c8;
                auVar6._4_4_ = uVar54;
                auVar6._0_4_ = uVar53;
                auVar6._8_4_ = uVar55;
                auVar6._12_4_ = uVar56;
                param_2[1] = auVar6;
                *(undefined (***) [16])param_2[2] = unaff_R12;
                *(undefined (***) [16])(param_2[2] + 8) = unaff_R12;
                uVar53 = *(undefined4 *)(*unaff_RSI + 4);
                uVar54 = *(undefined4 *)(*unaff_RSI + 8);
                uVar55 = *(undefined4 *)(*unaff_RSI + 0xc);
                *(undefined4 *)param_2[1] = *(undefined4 *)*unaff_RSI;
                *(undefined4 *)(param_2[1] + 4) = uVar53;
                *(undefined4 *)(param_2[1] + 8) = uVar54;
                *(undefined4 *)(param_2[1] + 0xc) = uVar55;
                uVar53 = *(undefined4 *)(unaff_RSI[1] + 4);
                uVar54 = *(undefined4 *)(unaff_RSI[1] + 8);
                uVar55 = *(undefined4 *)(unaff_RSI[1] + 0xc);
                *(undefined4 *)param_2[2] = *(undefined4 *)unaff_RSI[1];
                *(undefined4 *)(param_2[2] + 4) = uVar53;
                *(undefined4 *)(param_2[2] + 8) = uVar54;
                *(undefined4 *)(param_2[2] + 0xc) = uVar55;
                *(undefined (***) [16])unaff_RSI[1] = unaff_R12;
                *(undefined8 *)(unaff_RSI[1] + 8) = 0xf;
                (*unaff_RSI)[0] = 0;
                *(uint64_t *)param_2[3] = unaff_RDI;
                *(undefined (**) [16])(param_2[3] + 8) = unaff_RBX;
                *(int32_t *)(*param_2 + 8) = iVar14;
                *(undefined (**) [16])(puVar44 + 0x58) = param_2;
                *(undefined (**) [16])(puVar44 + 0x60) = pauVar20;
                *(undefined (*) [16])(puVar44 + 0x70) = ZEXT816(0);
                *(undefined8 *)(puVar44 + -8) = 0x18000a08f;
                func_0x00018000a9d0(unaff_R14, puVar44 + 0x58);
                piVar22 = *(int64_t **)(puVar44 + 0x60);
                if (piVar22 != (int64_t *)0x0) {
                    LOCK();
                    piVar1 = piVar22 + 1;
                    iVar13 = *(int32_t *)piVar1;
                    *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                    UNLOCK();
                    if (iVar13 == 1) {
                        pcVar4 = *(code **)*piVar22;
                        *(undefined8 *)(puVar44 + -8) = 0x18000a0b1;
                        (*pcVar4)(piVar22);
                        LOCK();
                        piVar2 = (int32_t *)((int64_t)piVar22 + 0xc);
                        iVar13 = *piVar2;
                        *piVar2 = *piVar2 + -1;
                        UNLOCK();
                        if (iVar13 == 1) {
                            pcVar4 = *(code **)(*piVar22 + 8);
                            *(undefined8 *)(puVar44 + -8) = 0x18000a0c9;
                            (*pcVar4)(piVar22);
                        }
                    }
                }
                pauVar25 = *unaff_R15;
                uVar18 = *(undefined8 *)
                          (*(int64_t *)(pauVar25[0xc] + 8) +
                          (*(int64_t *)pauVar25[0xd] - 1U & *(uint64_t *)(pauVar25[0xd] + 8)) * 8);
                *(undefined8 *)(puVar44 + -8) = 0x18000a0ee;
                func_0x000180004e40(uVar18);
                pauVar20 = pauVar25 + 0xe;
                *(int64_t *)*pauVar20 = *(int64_t *)*pauVar20 + -1;
                if (*(int64_t *)*pauVar20 == 0) {
                    *(undefined (***) [16])(pauVar25[0xd] + 8) = unaff_R12;
                } else {
                    *(int64_t *)(pauVar25[0xd] + 8) = *(int64_t *)(pauVar25[0xd] + 8) + 1;
                }
                unaff_R14 = *unaff_R15;
            } while (*(int64_t *)unaff_R14[0xe] != 0);
            puVar17 = *(undefined8 **)(puVar44 + 0x40);
        }
        if (puVar17 != (undefined8 *)0x0) {
            puVar32 = *(undefined8 **)(puVar44 + 0x48);
            if (puVar17 != puVar32) {
                do {
                    *(undefined8 *)(puVar44 + -8) = 0x18000a138;
                    func_0x00018000dc80(puVar17);
                    puVar17 = puVar17 + 4;
                } while (puVar17 != puVar32);
                puVar17 = *(undefined8 **)(puVar44 + 0x40);
            }
            puVar32 = puVar17;
            if (0xfff < (*(int64_t *)(puVar44 + 0x50) - (int64_t)puVar17 & 0xffffffffffffffe0U)) {
                puVar32 = (undefined8 *)puVar17[-1];
                puVar17 = (undefined8 *)((int64_t)puVar17 + (-8 - (int64_t)puVar32));
                if ((undefined8 *)0x1f < puVar17) {
                    pcVar4 = (code *)swi(0x29);
                    (*pcVar4)(5);
                    puVar44 = puVar44 + 8;
                    puVar32 = puVar17;
                }
            }
            *(undefined8 *)(puVar44 + -8) = 0x18000a181;
            func_0x000180459c3c(puVar32);
            *(undefined (*) [16])(puVar44 + 0x40) = ZEXT816(0);
            *(undefined (***) [16])(puVar44 + 0x50) = unaff_R12;
        }
        *(undefined8 *)(puVar44 + -8) = 0x18000a19c;
        func_0x00018000dc80(puVar44 + 0x370);
        *(undefined8 *)(puVar44 + -8) = 0x18000a1ac;
        pauVar20 = (undefined (*) [16])func_0x000180459870(*(uint64_t *)(puVar44 + 0x398) ^ (uint64_t)puVar44);
        return pauVar20;
    case (undefined (*) [16])0xa2:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xa3:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xa4:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xa5:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xa6:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xa7:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xa8:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xa9:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xaa:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xac:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xad:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xaf:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xb0:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xb1:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xb2:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xb3:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xb4:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xb5:
    case (undefined (*) [16])0xea:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xb6:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xb7:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xb8:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xb9:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xba:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xbb:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xbc:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xbd:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xbe:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xbf:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xc0:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xc1:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xc2:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xc3:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xc4:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xc5:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xc7:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xc8:
    // WARNING: This code block may not be properly labeled as switch case
        if (puVar33 == (undefined *)0x0) {
            pcVar4 = (code *)swi(3);
            pauVar20 = (undefined (*) [16])(*pcVar4)();
            return pauVar20;
        }
        *(uint64_t *)*unaff_RBX = (uint64_t)*(uint32_t *)(&stack0x00000050 + iVar29);
        *(undefined8 *)(*unaff_RBX + 8) = 0;
        *(undefined **)unaff_RBX[1] = puVar33;
        return unaff_RBX;
    case (undefined (*) [16])0xc9:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xca:
    // WARNING: This code block may not be properly labeled as switch case
    // WARNING: Bad instruction - Truncating control flow here
        halt_baddata();
    case (undefined (*) [16])0xcb:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xcc:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xd0:
    case (undefined (*) [16])0xd8:
    case (undefined (*) [16])0xe0:
    // WARNING: This code block may not be properly labeled as switch case
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x1800028cc;
        func_0x00018003e070(0x180781f78, (int64_t)&uStackX_20 + iVar29);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x1800028e9;
        func_0x000180459d94(&stack0x00000030 + iVar29, 0x28, 5, 0x1800131a0);
        uVar18 = 0x1804a2560;
        puVar43 = (undefined *)((int64_t)&uStack_8 + iVar29);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x1800028f5;
        goto code_r0x000180459c24;
    case (undefined (*) [16])0xd1:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xd2:
    case (undefined (*) [16])0xda:
    case (undefined (*) [16])0xe2:
    case (undefined (*) [16])0xf6:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xd3:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xd4:
    case (undefined (*) [16])0xeb:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xd5:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xd6:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xd9:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xdb:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xdc:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xdd:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xde:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xdf:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xe1:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xe3:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xe5:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xe6:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xe7:
    // WARNING: This code block may not be properly labeled as switch case
        (*pauVar20)[0] = (*pauVar20)[0] ^ (uint8_t)unaff_RBX;
        if (((uint32_t)puVar33 & 0x1c0) == 0x40) goto code_r0x0001800104fe;
        break;
    case (undefined (*) [16])0xe8:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xe9:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xec:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xed:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xee:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xf1:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xf2:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xf3:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xf4:
    // WARNING: This code block may not be properly labeled as switch case
        iVar16 = *(int64_t *)(*pauVar20 + (int64_t)*unaff_RSI);
        if (iVar16 == 0) {
            if (*(char *)(uVar51 + 0x180000024) == (char)unaff_R14) {
code_r0x0001800020df:
                if (iVar16 != 0) goto code_r0x00018000212b;
            } else {
                *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x1800020d1;
                iVar16 = func_0x0001804558e0();
                if (unaff_RDI < *(uint64_t *)(iVar16 + 0x18)) {
                    iVar16 = *(int64_t *)(*unaff_RSI + *(int64_t *)(iVar16 + 0x10));
                    goto code_r0x0001800020df;
                }
            }
            iVar16 = *(int64_t *)((int64_t)unaff_RBP + 0x77);
            if (iVar16 == 0) {
                iVar35 = 0x180781f48;
                *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x1800020fd;
                iVar16 = func_0x00018002e5c0((undefined *)((int64_t)unaff_RBP + 0x77));
                if (iVar16 == -1) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180002472;
                    puVar19 = (uint64_t *)func_0x000180005b10();
                    uVar37 = *puVar19;
                    *(undefined *)(iVar35 + -0x5cffffdd) = *(undefined *)(iVar35 + -0x5cffffdd);
                    uVar12 = (uint32_t)(uint32_t *)((uint64_t)puVar19 & uVar37) &
                             *(uint32_t *)((uint64_t)puVar19 & uVar37);
                    cVar11 = (char)(uVar12 >> 8);
                    Var38 = (unkbyte7)((uint64_t)iVar35 >> 8);
                    cVar34 = (char)iVar35 + cVar11 * '\x02';
                    Var7 = (unkbyte3)(uVar12 >> 8);
                    uVar9 = (uint8_t)uVar12 & *(uint8_t *)(uint64_t)uVar12;
                    uVar12 = CONCAT31(Var7, uVar9 & *(uint8_t *)(uint64_t)CONCAT31(Var7, uVar9));
                    *(char *)0xffffffff9a000023 = *(char *)0xffffffff9a000023 + cVar11;
                    uVar12 = uVar12 & *(uint32_t *)(uint64_t)uVar12;
                    uVar9 = (uint8_t)(uVar12 >> 8);
                    *(char *)0xffffffffa3000023 = *(char *)0xffffffffa3000023 + uVar9;
                    pcVar36 = (char *)(CONCAT71(Var38, cVar34) + -0x5cffffde);
                    *pcVar36 = *pcVar36 + (uVar9 & (uint8_t)((uint32_t)*(undefined4 *)(uint64_t)uVar12 >> 8));
                    pcVar36 = (char *)CONCAT71(Var38, cVar34);
                    *pcVar36 = *pcVar36 + (char)((uint64_t)iVar35 >> 8);
                    pcVar4 = (code *)swi(3);
                    pauVar20 = (undefined (*) [16])(*pcVar4)();
                    return pauVar20;
                }
                piVar22 = *(int64_t **)((int64_t)unaff_RBP + 0x77);
                *(int64_t **)((int64_t)unaff_RBP + 0x67) = piVar22;
                *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180002117;
                func_0x0001804558a4(piVar22);
                pcVar4 = *(code **)(*piVar22 + 8);
                *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180002120;
                (*pcVar4)(piVar22);
                iVar16 = *(int64_t *)((int64_t)unaff_RBP + 0x77);
                *(int64_t *)0x180782480 = iVar16;
            }
        }
code_r0x00018000212b:
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180002134;
        func_0x00018045578c((undefined *)((int64_t)unaff_RBP + 0x6f));
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180002147;
        *(int64_t *)0x180781f38 = iVar16;
        *(undefined8 *)0x180781f40 = func_0x00018000a390(0x180781f48);
        *(undefined8 *)((int64_t)unaff_RBP + -0x59) = 0x180621ab8;
        *(undefined8 *)((int64_t)unaff_RBP + -0x51) = 0x180621ad7;
        *(undefined (**) [16])((int64_t)unaff_RBP + -0x49) = unaff_R14;
        *(undefined (**) [16])((int64_t)unaff_RBP + -0x41) = unaff_R14;
        *(undefined (*) [16])((int64_t)unaff_RBP + -0x39) = ZEXT816(0);
        *(undefined (**) [16])((int64_t)unaff_RBP + -0x29) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180002182;
        puVar17 = (undefined8 *)func_0x000180459890(0x30);
        puVar17[1] = 0x14;
        puVar17[2] = unaff_R14;
        puVar17[3] = unaff_R14;
        *puVar17 = 0x1806221d0;
        puVar17[4] = unaff_R14;
        puVar17[5] = unaff_R14;
        *(undefined8 **)((int64_t)unaff_RBP + -0x21) = puVar17;
        *(undefined8 **)((int64_t)unaff_RBP + -0x19) = puVar17;
        *(undefined4 *)((int64_t)unaff_RBP + -0x11) = 0x401;
        *(undefined (***) [16])((int64_t)unaff_RBP + -9) = unaff_R15;
        *(undefined (***) [16])((int64_t)unaff_RBP + -1) = unaff_R15;
        *(undefined4 *)((int64_t)unaff_RBP + 0xf) = 0x401;
        *(undefined *)((int64_t)unaff_RBP + 0x1b) = 0;
        *(undefined8 *)((int64_t)unaff_RBP + 7) = 0x43baefb;
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x1800021d7;
        func_0x00018002b970((undefined *)((int64_t)unaff_RBP + -0x59));
        *(undefined **)((int64_t)unaff_RBP + 0x67) = (undefined *)((int64_t)unaff_RBP + -0x21);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x1800021ea;
        puVar17 = (undefined8 *)func_0x000180459890(0x28);
        puVar17[1] = 0xd;
        puVar17[2] = unaff_R14;
        puVar17[3] = unaff_R14;
        *puVar17 = 0x1806220a8;
        uVar53 = SUB84(unaff_R14, 0);
        *(undefined4 *)(puVar17 + 4) = uVar53;
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180002214;
        uVar18 = func_0x00018002e210((undefined *)((int64_t)unaff_RBP + -0x21), puVar17);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180002220;
        func_0x00018002bb90((undefined *)((int64_t)unaff_RBP + -0x59));
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x18000222c;
        func_0x00018002bf70((undefined *)((int64_t)unaff_RBP + -0x21), uVar18);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180002236;
        puVar17 = (undefined8 *)func_0x000180459890(0x20);
        *puVar17 = 0x1806220a0;
        puVar17[1] = 0x15;
        puVar17[2] = unaff_R14;
        puVar17[3] = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x18000225c;
        func_0x00018002e210((undefined *)((int64_t)unaff_RBP + -0x21), puVar17);
        pauVar20 = *(undefined (**) [16])((int64_t)unaff_RBP + -0x21);
        *(undefined4 *)pauVar20[2] = *(undefined4 *)((int64_t)unaff_RBP + 0xf);
        *(int32_t *)(pauVar20[2] + 8) = *(int32_t *)((int64_t)unaff_RBP + -0x49) + 1;
        pauVar27 = unaff_R14;
        for (pauVar25 = pauVar20; pauVar25 != (undefined (*) [16])0x0; pauVar25 = *(undefined (**) [16])pauVar25[1]) {
            pauVar39 = pauVar27;
            switch(*(undefined4 *)(*pauVar25 + 8)) {
            case 7:
                if (pauVar27 != (undefined (*) [16])0x0) {
                    if (((*(int64_t *)pauVar25[2] == 0) ||
                        ((((*(int64_t *)(pauVar25[2] + 8) == 0 && (*(int64_t *)pauVar25[3] == 0)) &&
                          (*(int64_t *)(pauVar25[3] + 8) == 0)) &&
                         ((*(int16_t *)pauVar25[4] == 0 && (*(int64_t *)(*(int64_t *)pauVar25[2] + 0x18) == 0)))))) &&
                       (*(int64_t *)(pauVar25[4] + 8) == 0)) {
                        if ((*(uint32_t *)((int64_t)unaff_RBP + 0xf) & 0x800) == 0) break;
                        if (*(int64_t *)(pauVar25[3] + 8) == 0) {
                            bVar52 = ((*pauVar25)[0xc] & 1) == 0;
                            goto code_r0x00018000239d;
                        }
                    }
code_r0x00018000239f:
                    *(undefined4 *)(pauVar27[3] + 4) = uVar53;
                }
                break;
            case 8:
            case 0xd:
                bVar52 = pauVar27 == (undefined (*) [16])0x0;
code_r0x00018000239d:
                if (!bVar52) goto code_r0x00018000239f;
                break;
            case 10:
            case 0xb:
                uVar18 = *(undefined8 *)pauVar25[2];
                *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x1800022f5;
                func_0x00018002bdb0((undefined *)((int64_t)unaff_RBP + -0x59), uVar18, 0, 0);
                break;
            case 0x10:
                if (pauVar27 != (undefined (*) [16])0x0) {
                    *(undefined4 *)(pauVar27[3] + 4) = uVar53;
                }
                for (iVar16 = *(int64_t *)(pauVar25[2] + 8); iVar16 != 0; iVar16 = *(int64_t *)(iVar16 + 0x28)) {
                    uVar18 = *(undefined8 *)(iVar16 + 0x20);
                    uVar28 = *(undefined8 *)(iVar16 + 0x10);
                    *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x1800022d4;
                    func_0x00018002bdb0((undefined *)((int64_t)unaff_RBP + -0x59), uVar28, uVar18, pauVar27);
                }
                break;
            case 0x12:
                pauVar39 = pauVar25;
                if (pauVar27 != (undefined (*) [16])0x0) {
                    *(undefined4 *)(pauVar27[3] + 4) = uVar53;
                    if (*(uint32_t *)(pauVar27[2] + 4) < 2) {
                        uVar18 = *(undefined8 *)(*(int64_t *)(pauVar25[2] + 8) + 0x10);
                        uVar28 = *(undefined8 *)pauVar25[1];
                        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180002321;
                        func_0x00018002bdb0((undefined *)((int64_t)unaff_RBP + -0x59), uVar28, uVar18, pauVar25);
                        pauVar25 = *(undefined (**) [16])(pauVar25[2] + 8);
                        pauVar39 = pauVar27;
                    } else {
                        *(undefined4 *)(pauVar25[3] + 4) = uVar53;
                        pauVar39 = pauVar27;
                    }
                }
                break;
            case 0x13:
                if ((pauVar27 == *(undefined (**) [16])pauVar25[2]) &&
                   (pauVar39 = unaff_R14, *(int32_t *)(pauVar27[3] + 4) == -1)) {
                    *(undefined4 *)(pauVar27[3] + 4) = 1;
                }
            }
            pauVar27 = pauVar39;
        }
        LOCK();
        *(int32_t *)(pauVar20[2] + 0xc) = *(int32_t *)(pauVar20[2] + 0xc) + 1;
        UNLOCK();
        if (*(undefined (**) [16])0x180781f30 != (undefined (*) [16])0x0) {
            LOCK();
            piVar2 = (int32_t *)((*(undefined (**) [16])0x180781f30)[2] + 0xc);
            iVar14 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            pauVar25 = *(undefined (**) [16])0x180781f30;
            if (iVar14 == 1) {
                while (pauVar25 != (undefined (*) [16])0x0) {
                    pauVar27 = *(undefined (**) [16])pauVar25[1];
                    *(undefined (**) [16])pauVar25[1] = unaff_R14;
                    pcVar4 = **(code ***)*pauVar25;
                    *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x1800023f7;
                    (*pcVar4)(pauVar25, 1);
                    pauVar25 = pauVar27;
                }
            }
        }
        iVar16 = *(int64_t *)((int64_t)unaff_RBP + -0x41);
        *(undefined (**) [16])0x180781f30 = pauVar20;
        if (iVar16 != 0) {
            iVar35 = iVar16;
            puVar30 = (undefined *)((int64_t)&uStackX_20 + iVar29 + -0x20);
            if ((0xfff < (uint64_t)((*(int64_t *)((int64_t)unaff_RBP + -0x31) - iVar16 >> 2) * 4)) &&
               (iVar35 = *(int64_t *)(iVar16 + -8), puVar30 = (undefined *)((int64_t)&uStackX_20 + iVar29 + -0x20),
               0x1f < (iVar16 - iVar35) - 8U)) {
                iVar35 = 5;
                pcVar4 = (code *)swi(0x29);
                (*pcVar4)(5);
                puVar30 = (undefined *)((int64_t)apauStackX_8 + iVar29);
            }
            *(undefined8 *)(puVar30 + -8) = 0x180002451;
            func_0x000180459c3c(iVar35);
        }
        uVar18 = 0x1804a2350;
        puVar43 = puVar30 + 0xd8;
code_r0x000180459c24:
        *(undefined8 *)(puVar43 + -0x30) = 0x180459c2d;
        iVar29 = func_0x000180459be8(uVar18);
        return (undefined (*) [16])(uint64_t)((iVar29 != 0) - 1);
    case (undefined (*) [16])0xf5:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xf7:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xf8:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xf9:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xfa:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xfb:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xfc:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xfd:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xfe:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    case (undefined (*) [16])0xff:
    // WARNING: Bad instruction - Truncating control flow here
    // WARNING: This code block may not be properly labeled as switch case
        halt_baddata();
    }
    for (; 0 < (int64_t)unaff_RBX; unaff_RBX = (undefined (*) [16])(unaff_RBX[-1] + 0xf)) {
        iVar16 = (int64_t)*(int32_t *)(*(int64_t *)*unaff_RSI + 4);
        piVar22 = *(int64_t **)(unaff_RSI[4] + iVar16 + 8);
        uVar9 = unaff_RSI[5][iVar16 + 8];
        if (*(int64_t *)piVar22[8] == 0) {
code_r0x0001800104d5:
            pcVar4 = *(code **)(*piVar22 + 0x18);
            *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x1800104e1;
            uVar12 = (*pcVar4)(piVar22, uVar9);
        } else {
            iVar14 = *(int32_t *)piVar22[0xb];
            if (iVar14 < 1) goto code_r0x0001800104d5;
            *(int32_t *)piVar22[0xb] = iVar14 + -1;
            puVar5 = *(uint8_t **)piVar22[8];
            *(uint8_t **)piVar22[8] = puVar5 + 1;
            *puVar5 = uVar9;
            uVar12 = (uint32_t)uVar9;
        }
        if (uVar12 == 0xffffffff) {
            unaff_RDI = 4;
            *(undefined4 *)(&stack0x000000b0 + iVar29) = 4;
            goto code_r0x0001800105a0;
        }
    }
code_r0x0001800104fe:
    pcVar4 = *(code **)(**(int64_t **)(unaff_RSI[4] + (int64_t)*(int32_t *)(*(int64_t *)*unaff_RSI + 4) + 8) + 0x48);
    *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180010516;
    pauVar20 = (undefined (*) [16])(*pcVar4)();
    if (pauVar20 == unaff_R14) {
        for (; 0 < (int64_t)unaff_RBX; unaff_RBX = (undefined (*) [16])(unaff_RBX[-1] + 0xf)) {
            iVar16 = (int64_t)*(int32_t *)(*(int64_t *)*unaff_RSI + 4);
            piVar22 = *(int64_t **)(unaff_RSI[4] + iVar16 + 8);
            uVar9 = unaff_RSI[5][iVar16 + 8];
            if (*(int64_t *)piVar22[8] == 0) {
code_r0x000180010575:
                pcVar4 = *(code **)(*piVar22 + 0x18);
                *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180010581;
                uVar12 = (*pcVar4)(piVar22, uVar9);
            } else {
                iVar14 = *(int32_t *)piVar22[0xb];
                if (iVar14 < 1) goto code_r0x000180010575;
                *(int32_t *)piVar22[0xb] = iVar14 + -1;
                puVar5 = *(uint8_t **)piVar22[8];
                *(uint8_t **)piVar22[8] = puVar5 + 1;
                *puVar5 = uVar9;
                uVar12 = (uint32_t)uVar9;
            }
            if (uVar12 == 0xffffffff) {
                unaff_RDI = 4;
                *(undefined4 *)(&stack0x000000b0 + iVar29) = 4;
                break;
            }
        }
    } else {
        unaff_RDI = 4;
        *(undefined4 *)(&stack0x000000b0 + iVar29) = 4;
    }
code_r0x0001800105a0:
    *(undefined8 *)(unaff_RSI[2] + (int64_t)*(int32_t *)(*(int64_t *)*unaff_RSI + 4) + 8) = unaff_R13;
    iVar16 = (int64_t)*(int32_t *)(*(int64_t *)*unaff_RSI + 4);
    uVar12 = 4;
    if (*(int64_t *)(unaff_RSI[4] + iVar16 + 8) != 0) {
        uVar12 = (uint32_t)unaff_R13;
    }
    uVar12 = (uVar12 | *(uint32_t *)(unaff_RSI[1] + iVar16) | (uint32_t)unaff_RDI) & 0x17;
    *(uint32_t *)(unaff_RSI[1] + iVar16) = uVar12;
    uVar12 = uVar12 & *(uint32_t *)(unaff_RSI[1] + iVar16 + 4);
    if (uVar12 != 0) {
        if ((uVar12 & 4) == 0) {
            uVar18 = 0x1805aae00;
            if ((uVar12 & 2) == 0) {
                uVar18 = 0x1805aae18;
            }
        } else {
            uVar18 = 0x1805aade8;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180010667;
        uVar28 = func_0x000180005e50(&stack0x00000030 + iVar29, 1);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180010677;
        func_0x0001800069f0(&stack0x00000040 + iVar29, uVar18, uVar28);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180010688;
        func_0x00018045bae0(&stack0x00000040 + iVar29, 0x180698c38);
        pcVar4 = (code *)swi(3);
        pauVar20 = (undefined (*) [16])(*pcVar4)();
        return pauVar20;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x1800105f3;
    iVar14 = func_0x0001804557c0();
    if (iVar14 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x1800105ff;
        func_0x00018000fc20();
    }
    piVar22 = *(int64_t **)((int64_t)*(int32_t *)(**unaff_R15 + 4) + 0x48 + (int64_t)unaff_R15);
    if (piVar22 != (int64_t *)0x0) {
        pcVar4 = *(code **)(*piVar22 + 0x10);
        *(undefined8 *)((int64_t)&uStack_8 + iVar29) = 0x180010617;
        (*pcVar4)();
    }
    return unaff_RSI;
}

// ============================================================
// Function: FUN_1801e7fb0
// Address: 0x1801e7fb0
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1801e7fb0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h,
                  int64_t arg_a0h)
{
    int64_t **ppiVar1;
    char cVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    code *pcVar5;
    uint32_t uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t in_RCX;
    int64_t *piVar14;
    int64_t *in_RDX;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    bool bVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e7fc3;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar8 = *(uint32_t *)(in_RDX + 0x20);
    uVar3 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_98h + iVar9) = unaff_R14;
    bVar15 = true;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e7fe9;
    uVar6 = func_0x0001801e3b40(uVar3);
    if ((uVar8 & 1) == uVar6) {
        uVar8 = *(uint32_t *)(in_RDX + 0x20);
        uVar4 = in_RDX[7];
        pcVar5 = *(code **)(in_RCX + 0x70);
        if (pcVar5 != (code *)0x0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x78);
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e801c;
            uVar10 = (*pcVar5)((uVar8 & 2) != 0, uVar3);
            bVar15 = uVar4 >> 2 < uVar10;
        }
    }
    cVar2 = *(char *)((int64_t)in_RDX + 0x101);
    *(undefined8 *)((int64_t)&arg_90h + iVar9) = unaff_RDI;
    if (cVar2 == '\x03') {
        iVar11 = in_RDX[0xe];
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e8040;
        iVar7 = func_0x0001801e6440(iVar11);
        if (iVar7 == 0) goto code_r0x0001801e8094;
        if ((*(char *)((int64_t)in_RDX + 0x101) != '\0') && (*(char *)((int64_t)in_RDX + 0x101) == '\x03')) {
            iVar11 = in_RDX[0xe];
            *(undefined *)((int64_t)in_RDX + 0x101) = 4;
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e8063;
            func_0x0001801e6180(iVar11);
            in_RDX[0xe] = 0;
            if ((char)*(uint32_t *)((int64_t)in_RDX + 0x104) < '\0') {
                *(uint32_t *)((int64_t)in_RDX + 0x104) = *(uint32_t *)((int64_t)in_RDX + 0x104) & 0xffffff7f;
                piVar14 = (int64_t *)(in_RCX + 0x60);
                *piVar14 = *piVar14 + -1;
                if (*piVar14 == 0) {
                    uVar3 = *(undefined8 *)(in_RCX + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e808b;
                    func_0x0001801e3de0(uVar3);
                }
            }
        }
    } else {
code_r0x0001801e8094:
        if (((*(uint8_t *)((int64_t)in_RDX + 0x104) & 0x80) != 0) && (*(char *)((int64_t)in_RDX + 0x101) == '\x02')) {
            iVar11 = in_RDX[0xe];
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e80b2;
            iVar7 = func_0x0001801e6440(iVar11);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e80c1;
                func_0x0001801e8310(in_RCX, in_RDX);
            }
        }
    }
    uVar8 = *(uint32_t *)((int64_t)in_RDX + 0x104);
    if ((uVar8 & 0x40) == 0) {
        if ((((uVar8 & 0x20) == 0) || ((*(char *)((int64_t)in_RDX + 0x102) != '\0' && ((uVar8 & 0x10) == 0)))) ||
           ((cVar2 = *(char *)((int64_t)in_RDX + 0x101), cVar2 != '\0' && ((cVar2 != '\x04' && (cVar2 != '\x06')))))) {
            *(uint32_t *)((int64_t)in_RDX + 0x104) = uVar8 & 0xffffffbf;
        } else {
            piVar14 = in_RDX + 4;
            *(uint32_t *)((int64_t)in_RDX + 0x104) = uVar8 | 0x40;
            ppiVar1 = (int64_t **)(in_RCX + 0x30);
            piVar13 = *ppiVar1;
            *piVar14 = (int64_t)piVar13;
            piVar13[1] = (int64_t)piVar14;
            *ppiVar1 = piVar14;
            in_RDX[5] = (int64_t)ppiVar1;
        }
    }
    if ((bVar15) && ((*(uint32_t *)((int64_t)in_RDX + 0x104) & 0x40) == 0)) {
        if ((*(char *)((int64_t)in_RDX + 0x102) == '\0') || (*(char *)((int64_t)in_RDX + 0x102) != '\x01')) {
code_r0x0001801e816c:
            if ((*(uint8_t *)((int64_t)in_RDX + 0x104) & 0xc) == 0) {
                if (((*(uint32_t *)(in_RDX + 0x20) >> 0x1b & 1) == 0) &&
                   (((uVar8 = *(uint32_t *)(in_RDX + 0x20) >> 8 & 0xff, uVar8 == 1 || (uVar8 == 2)) || (uVar8 == 3)))) {
                    iVar11 = in_RDX[0xe];
                    *(int64_t *)((int64_t)&var_8h + iVar9) = (int64_t)&arg_88h + iVar9;
                    *(undefined8 *)((int64_t)&arg_88h + iVar9) = 2;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e81d0;
                    iVar7 = func_0x0001801e6230(iVar11, 0, (int64_t)&arg_38h + iVar9, (int64_t)&var_18h + iVar9);
                    if (iVar7 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e81e2;
                        iVar11 = func_0x0001801e5c20(in_RDX + 0x10, 0);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e81f1;
                        iVar12 = func_0x0001801bc820(in_RDX + 0x10);
                        if ((((*(uint8_t *)((int64_t)&arg_58h + iVar9) & 2) != 0) &&
                            (*(int64_t *)((int64_t)&arg_48h + iVar9) == 0)) ||
                           (*(uint64_t *)((int64_t)&arg_40h + iVar9) < (uint64_t)(iVar12 + iVar11)))
                        goto code_r0x0001801e8209;
                    }
                }
                goto code_r0x0001801e8245;
            }
        } else if ((*(uint32_t *)((int64_t)in_RDX + 0x104) & 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e8164;
            iVar7 = func_0x0001801e59a0(in_RDX + 0x14, 0);
            if (iVar7 == 0) goto code_r0x0001801e816c;
        }
code_r0x0001801e8209:
        if ((*(uint32_t *)(in_RDX + 0x20) & 0x1000000) == 0) {
            iVar9 = *(int64_t *)(in_RCX + 0x10);
            *in_RDX = iVar9;
            *(int64_t **)(iVar9 + 8) = in_RDX;
            *(int64_t **)(in_RCX + 0x10) = in_RDX;
            in_RDX[1] = (int64_t)(int64_t **)(in_RCX + 0x10);
            if (*(int64_t *)(in_RCX + 0x68) == 0) {
                *(int64_t **)(in_RCX + 0x68) = in_RDX;
            }
            *(uint32_t *)(in_RDX + 0x20) = *(uint32_t *)(in_RDX + 0x20) | 0x1000000;
        }
    } else {
code_r0x0001801e8245:
        if ((*(uint32_t *)(in_RDX + 0x20) & 0x1000000) != 0) {
            if (*(int64_t **)(in_RCX + 0x68) == in_RDX) {
                piVar14 = (int64_t *)in_RDX[1];
                if (piVar14 == (int64_t *)(in_RCX + 0x10)) {
                    piVar14 = (int64_t *)piVar14[1];
                }
                piVar13 = (int64_t *)0x0;
                if (piVar14 != (int64_t *)(in_RCX + 0x10)) {
                    piVar13 = piVar14;
                }
                *(int64_t **)(in_RCX + 0x68) = piVar13;
                if (piVar13 == in_RDX) {
                    *(undefined8 *)(in_RCX + 0x68) = 0;
                }
            }
            *(int64_t *)(*in_RDX + 8) = in_RDX[1];
            *(int64_t *)in_RDX[1] = *in_RDX;
            *(uint32_t *)(in_RDX + 0x20) = *(uint32_t *)(in_RDX + 0x20) & 0xfeffffff;
            *in_RDX = 0;
            in_RDX[1] = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e7fd6
// Address: 0x1801e7fd6
// Size: 349 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1801e7fb0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h,
                  int64_t arg_a0h)
{
    int64_t **ppiVar1;
    char cVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    code *pcVar5;
    uint32_t uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t in_RCX;
    int64_t *piVar14;
    int64_t *in_RDX;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    bool bVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e7fc3;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar8 = *(uint32_t *)(in_RDX + 0x20);
    uVar3 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_98h + iVar9) = unaff_R14;
    bVar15 = true;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e7fe9;
    uVar6 = func_0x0001801e3b40(uVar3);
    if ((uVar8 & 1) == uVar6) {
        uVar8 = *(uint32_t *)(in_RDX + 0x20);
        uVar4 = in_RDX[7];
        pcVar5 = *(code **)(in_RCX + 0x70);
        if (pcVar5 != (code *)0x0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x78);
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e801c;
            uVar10 = (*pcVar5)((uVar8 & 2) != 0, uVar3);
            bVar15 = uVar4 >> 2 < uVar10;
        }
    }
    cVar2 = *(char *)((int64_t)in_RDX + 0x101);
    *(undefined8 *)((int64_t)&arg_90h + iVar9) = unaff_RDI;
    if (cVar2 == '\x03') {
        iVar11 = in_RDX[0xe];
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e8040;
        iVar7 = func_0x0001801e6440(iVar11);
        if (iVar7 == 0) goto code_r0x0001801e8094;
        if ((*(char *)((int64_t)in_RDX + 0x101) != '\0') && (*(char *)((int64_t)in_RDX + 0x101) == '\x03')) {
            iVar11 = in_RDX[0xe];
            *(undefined *)((int64_t)in_RDX + 0x101) = 4;
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e8063;
            func_0x0001801e6180(iVar11);
            in_RDX[0xe] = 0;
            if ((char)*(uint32_t *)((int64_t)in_RDX + 0x104) < '\0') {
                *(uint32_t *)((int64_t)in_RDX + 0x104) = *(uint32_t *)((int64_t)in_RDX + 0x104) & 0xffffff7f;
                piVar14 = (int64_t *)(in_RCX + 0x60);
                *piVar14 = *piVar14 + -1;
                if (*piVar14 == 0) {
                    uVar3 = *(undefined8 *)(in_RCX + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e808b;
                    func_0x0001801e3de0(uVar3);
                }
            }
        }
    } else {
code_r0x0001801e8094:
        if (((*(uint8_t *)((int64_t)in_RDX + 0x104) & 0x80) != 0) && (*(char *)((int64_t)in_RDX + 0x101) == '\x02')) {
            iVar11 = in_RDX[0xe];
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e80b2;
            iVar7 = func_0x0001801e6440(iVar11);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e80c1;
                func_0x0001801e8310(in_RCX, in_RDX);
            }
        }
    }
    uVar8 = *(uint32_t *)((int64_t)in_RDX + 0x104);
    if ((uVar8 & 0x40) == 0) {
        if ((((uVar8 & 0x20) == 0) || ((*(char *)((int64_t)in_RDX + 0x102) != '\0' && ((uVar8 & 0x10) == 0)))) ||
           ((cVar2 = *(char *)((int64_t)in_RDX + 0x101), cVar2 != '\0' && ((cVar2 != '\x04' && (cVar2 != '\x06')))))) {
            *(uint32_t *)((int64_t)in_RDX + 0x104) = uVar8 & 0xffffffbf;
        } else {
            piVar14 = in_RDX + 4;
            *(uint32_t *)((int64_t)in_RDX + 0x104) = uVar8 | 0x40;
            ppiVar1 = (int64_t **)(in_RCX + 0x30);
            piVar13 = *ppiVar1;
            *piVar14 = (int64_t)piVar13;
            piVar13[1] = (int64_t)piVar14;
            *ppiVar1 = piVar14;
            in_RDX[5] = (int64_t)ppiVar1;
        }
    }
    if ((bVar15) && ((*(uint32_t *)((int64_t)in_RDX + 0x104) & 0x40) == 0)) {
        if ((*(char *)((int64_t)in_RDX + 0x102) == '\0') || (*(char *)((int64_t)in_RDX + 0x102) != '\x01')) {
code_r0x0001801e816c:
            if ((*(uint8_t *)((int64_t)in_RDX + 0x104) & 0xc) == 0) {
                if (((*(uint32_t *)(in_RDX + 0x20) >> 0x1b & 1) == 0) &&
                   (((uVar8 = *(uint32_t *)(in_RDX + 0x20) >> 8 & 0xff, uVar8 == 1 || (uVar8 == 2)) || (uVar8 == 3)))) {
                    iVar11 = in_RDX[0xe];
                    *(int64_t *)((int64_t)&var_8h + iVar9) = (int64_t)&arg_88h + iVar9;
                    *(undefined8 *)((int64_t)&arg_88h + iVar9) = 2;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e81d0;
                    iVar7 = func_0x0001801e6230(iVar11, 0, (int64_t)&arg_38h + iVar9, (int64_t)&var_18h + iVar9);
                    if (iVar7 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e81e2;
                        iVar11 = func_0x0001801e5c20(in_RDX + 0x10, 0);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e81f1;
                        iVar12 = func_0x0001801bc820(in_RDX + 0x10);
                        if ((((*(uint8_t *)((int64_t)&arg_58h + iVar9) & 2) != 0) &&
                            (*(int64_t *)((int64_t)&arg_48h + iVar9) == 0)) ||
                           (*(uint64_t *)((int64_t)&arg_40h + iVar9) < (uint64_t)(iVar12 + iVar11)))
                        goto code_r0x0001801e8209;
                    }
                }
                goto code_r0x0001801e8245;
            }
        } else if ((*(uint32_t *)((int64_t)in_RDX + 0x104) & 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e8164;
            iVar7 = func_0x0001801e59a0(in_RDX + 0x14, 0);
            if (iVar7 == 0) goto code_r0x0001801e816c;
        }
code_r0x0001801e8209:
        if ((*(uint32_t *)(in_RDX + 0x20) & 0x1000000) == 0) {
            iVar9 = *(int64_t *)(in_RCX + 0x10);
            *in_RDX = iVar9;
            *(int64_t **)(iVar9 + 8) = in_RDX;
            *(int64_t **)(in_RCX + 0x10) = in_RDX;
            in_RDX[1] = (int64_t)(int64_t **)(in_RCX + 0x10);
            if (*(int64_t *)(in_RCX + 0x68) == 0) {
                *(int64_t **)(in_RCX + 0x68) = in_RDX;
            }
            *(uint32_t *)(in_RDX + 0x20) = *(uint32_t *)(in_RDX + 0x20) | 0x1000000;
        }
    } else {
code_r0x0001801e8245:
        if ((*(uint32_t *)(in_RDX + 0x20) & 0x1000000) != 0) {
            if (*(int64_t **)(in_RCX + 0x68) == in_RDX) {
                piVar14 = (int64_t *)in_RDX[1];
                if (piVar14 == (int64_t *)(in_RCX + 0x10)) {
                    piVar14 = (int64_t *)piVar14[1];
                }
                piVar13 = (int64_t *)0x0;
                if (piVar14 != (int64_t *)(in_RCX + 0x10)) {
                    piVar13 = piVar14;
                }
                *(int64_t **)(in_RCX + 0x68) = piVar13;
                if (piVar13 == in_RDX) {
                    *(undefined8 *)(in_RCX + 0x68) = 0;
                }
            }
            *(int64_t *)(*in_RDX + 8) = in_RDX[1];
            *(int64_t *)in_RDX[1] = *in_RDX;
            *(uint32_t *)(in_RDX + 0x20) = *(uint32_t *)(in_RDX + 0x20) & 0xfeffffff;
            *in_RDX = 0;
            in_RDX[1] = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e8133
// Address: 0x1801e8133
// Size: 398 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1801e7fb0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h,
                  int64_t arg_a0h)
{
    int64_t **ppiVar1;
    char cVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    code *pcVar5;
    uint32_t uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t in_RCX;
    int64_t *piVar14;
    int64_t *in_RDX;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    bool bVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e7fc3;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar8 = *(uint32_t *)(in_RDX + 0x20);
    uVar3 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_98h + iVar9) = unaff_R14;
    bVar15 = true;
    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e7fe9;
    uVar6 = func_0x0001801e3b40(uVar3);
    if ((uVar8 & 1) == uVar6) {
        uVar8 = *(uint32_t *)(in_RDX + 0x20);
        uVar4 = in_RDX[7];
        pcVar5 = *(code **)(in_RCX + 0x70);
        if (pcVar5 != (code *)0x0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x78);
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e801c;
            uVar10 = (*pcVar5)((uVar8 & 2) != 0, uVar3);
            bVar15 = uVar4 >> 2 < uVar10;
        }
    }
    cVar2 = *(char *)((int64_t)in_RDX + 0x101);
    *(undefined8 *)((int64_t)&arg_90h + iVar9) = unaff_RDI;
    if (cVar2 == '\x03') {
        iVar11 = in_RDX[0xe];
        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e8040;
        iVar7 = func_0x0001801e6440(iVar11);
        if (iVar7 == 0) goto code_r0x0001801e8094;
        if ((*(char *)((int64_t)in_RDX + 0x101) != '\0') && (*(char *)((int64_t)in_RDX + 0x101) == '\x03')) {
            iVar11 = in_RDX[0xe];
            *(undefined *)((int64_t)in_RDX + 0x101) = 4;
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e8063;
            func_0x0001801e6180(iVar11);
            in_RDX[0xe] = 0;
            if ((char)*(uint32_t *)((int64_t)in_RDX + 0x104) < '\0') {
                *(uint32_t *)((int64_t)in_RDX + 0x104) = *(uint32_t *)((int64_t)in_RDX + 0x104) & 0xffffff7f;
                piVar14 = (int64_t *)(in_RCX + 0x60);
                *piVar14 = *piVar14 + -1;
                if (*piVar14 == 0) {
                    uVar3 = *(undefined8 *)(in_RCX + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e808b;
                    func_0x0001801e3de0(uVar3);
                }
            }
        }
    } else {
code_r0x0001801e8094:
        if (((*(uint8_t *)((int64_t)in_RDX + 0x104) & 0x80) != 0) && (*(char *)((int64_t)in_RDX + 0x101) == '\x02')) {
            iVar11 = in_RDX[0xe];
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e80b2;
            iVar7 = func_0x0001801e6440(iVar11);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e80c1;
                func_0x0001801e8310(in_RCX, in_RDX);
            }
        }
    }
    uVar8 = *(uint32_t *)((int64_t)in_RDX + 0x104);
    if ((uVar8 & 0x40) == 0) {
        if ((((uVar8 & 0x20) == 0) || ((*(char *)((int64_t)in_RDX + 0x102) != '\0' && ((uVar8 & 0x10) == 0)))) ||
           ((cVar2 = *(char *)((int64_t)in_RDX + 0x101), cVar2 != '\0' && ((cVar2 != '\x04' && (cVar2 != '\x06')))))) {
            *(uint32_t *)((int64_t)in_RDX + 0x104) = uVar8 & 0xffffffbf;
        } else {
            piVar14 = in_RDX + 4;
            *(uint32_t *)((int64_t)in_RDX + 0x104) = uVar8 | 0x40;
            ppiVar1 = (int64_t **)(in_RCX + 0x30);
            piVar13 = *ppiVar1;
            *piVar14 = (int64_t)piVar13;
            piVar13[1] = (int64_t)piVar14;
            *ppiVar1 = piVar14;
            in_RDX[5] = (int64_t)ppiVar1;
        }
    }
    if ((bVar15) && ((*(uint32_t *)((int64_t)in_RDX + 0x104) & 0x40) == 0)) {
        if ((*(char *)((int64_t)in_RDX + 0x102) == '\0') || (*(char *)((int64_t)in_RDX + 0x102) != '\x01')) {
code_r0x0001801e816c:
            if ((*(uint8_t *)((int64_t)in_RDX + 0x104) & 0xc) == 0) {
                if (((*(uint32_t *)(in_RDX + 0x20) >> 0x1b & 1) == 0) &&
                   (((uVar8 = *(uint32_t *)(in_RDX + 0x20) >> 8 & 0xff, uVar8 == 1 || (uVar8 == 2)) || (uVar8 == 3)))) {
                    iVar11 = in_RDX[0xe];
                    *(int64_t *)((int64_t)&var_8h + iVar9) = (int64_t)&arg_88h + iVar9;
                    *(undefined8 *)((int64_t)&arg_88h + iVar9) = 2;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e81d0;
                    iVar7 = func_0x0001801e6230(iVar11, 0, (int64_t)&arg_38h + iVar9, (int64_t)&var_18h + iVar9);
                    if (iVar7 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e81e2;
                        iVar11 = func_0x0001801e5c20(in_RDX + 0x10, 0);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e81f1;
                        iVar12 = func_0x0001801bc820(in_RDX + 0x10);
                        if ((((*(uint8_t *)((int64_t)&arg_58h + iVar9) & 2) != 0) &&
                            (*(int64_t *)((int64_t)&arg_48h + iVar9) == 0)) ||
                           (*(uint64_t *)((int64_t)&arg_40h + iVar9) < (uint64_t)(iVar12 + iVar11)))
                        goto code_r0x0001801e8209;
                    }
                }
                goto code_r0x0001801e8245;
            }
        } else if ((*(uint32_t *)((int64_t)in_RDX + 0x104) & 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar9) = 0x1801e8164;
            iVar7 = func_0x0001801e59a0(in_RDX + 0x14, 0);
            if (iVar7 == 0) goto code_r0x0001801e816c;
        }
code_r0x0001801e8209:
        if ((*(uint32_t *)(in_RDX + 0x20) & 0x1000000) == 0) {
            iVar9 = *(int64_t *)(in_RCX + 0x10);
            *in_RDX = iVar9;
            *(int64_t **)(iVar9 + 8) = in_RDX;
            *(int64_t **)(in_RCX + 0x10) = in_RDX;
            in_RDX[1] = (int64_t)(int64_t **)(in_RCX + 0x10);
            if (*(int64_t *)(in_RCX + 0x68) == 0) {
                *(int64_t **)(in_RCX + 0x68) = in_RDX;
            }
            *(uint32_t *)(in_RDX + 0x20) = *(uint32_t *)(in_RDX + 0x20) | 0x1000000;
        }
    } else {
code_r0x0001801e8245:
        if ((*(uint32_t *)(in_RDX + 0x20) & 0x1000000) != 0) {
            if (*(int64_t **)(in_RCX + 0x68) == in_RDX) {
                piVar14 = (int64_t *)in_RDX[1];
                if (piVar14 == (int64_t *)(in_RCX + 0x10)) {
                    piVar14 = (int64_t *)piVar14[1];
                }
                piVar13 = (int64_t *)0x0;
                if (piVar14 != (int64_t *)(in_RCX + 0x10)) {
                    piVar13 = piVar14;
                }
                *(int64_t **)(in_RCX + 0x68) = piVar13;
                if (piVar13 == in_RDX) {
                    *(undefined8 *)(in_RCX + 0x68) = 0;
                }
            }
            *(int64_t *)(*in_RDX + 8) = in_RDX[1];
            *(int64_t *)in_RDX[1] = *in_RDX;
            *(uint32_t *)(in_RDX + 0x20) = *(uint32_t *)(in_RDX + 0x20) & 0xfeffffff;
            *in_RDX = 0;
            in_RDX[1] = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e82d0
// Address: 0x1801e82d0
// Size: 25 bytes
// ============================================================
void fcn.1801e82d0(int64_t **param_1, undefined8 param_2, undefined8 param_3)
{
    int32_t iVar1;
    code *pcVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    piVar8 = *param_1;
    if (piVar8 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + 0x18) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + 0x10) = unaff_R14;
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + 8) = unaff_R15;
        *(undefined8 *)((int64_t)auStackX_8 + iVar6) = 0x180228cf8;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        iVar1 = *(int32_t *)(piVar8 + 7);
        *(undefined8 *)(&stack0x00000058 + iVar7 + iVar6) = unaff_RSI;
        pcVar2 = (code *)piVar8[6];
        *(undefined8 *)(&stack0x00000060 + iVar7 + iVar6) = unaff_RDI;
        iVar9 = (int64_t)(iVar1 + -1);
        if (-1 < iVar1 + -1) {
            *(undefined8 *)(&stack0x00000050 + iVar7 + iVar6) = unaff_RBX;
            do {
                puVar5 = *(undefined8 **)(*piVar8 + iVar9 * 8);
                while (puVar5 != (undefined8 *)0x0) {
                    puVar3 = (undefined8 *)puVar5[1];
                    uVar4 = *puVar5;
                    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6) = 0x180228d3f;
                    (*pcVar2)(uVar4, param_3, param_2);
                    puVar5 = puVar3;
                }
                iVar9 = iVar9 + -1;
            } while (-1 < iVar9);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e82f0
// Address: 0x1801e82f0
// Size: 31 bytes
// ============================================================
void fcn.1801e82f0(int64_t *param_1, undefined8 *param_2)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (param_1 != (int64_t *)0x0) {
        *(undefined8 *)(&stack0x00000038 + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x1801e7c69;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)(&stack0x00000050 + iVar3 + iVar4) = unaff_RSI;
        if (param_1[1] != 0) {
            *(int64_t *)(*param_1 + 8) = param_1[1];
            *(int64_t *)param_1[1] = *param_1;
            *param_1 = 0;
            param_1[1] = 0;
        }
        if (param_1[3] != 0) {
            *(int64_t *)(param_1[2] + 8) = param_1[3];
            *(int64_t *)param_1[3] = param_1[2];
            param_1[2] = 0;
            param_1[3] = 0;
        }
        if (param_1[5] != 0) {
            *(int64_t *)(param_1[4] + 8) = param_1[5];
            *(int64_t *)param_1[5] = param_1[4];
            param_1[4] = 0;
            param_1[5] = 0;
        }
        iVar1 = param_1[0xe];
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x1801e7ced;
        func_0x0001801e6180(iVar1);
        param_1[0xe] = 0;
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x1801e7cfa;
        fcn.1801e6b30(*(int64_t *)(&stack0x00000040 + iVar3 + iVar4));
        param_1[0xf] = 0;
        uVar2 = *param_2;
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x1801e7d09;
        func_0x000180228b10(uVar2, param_1);
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar4) = 0x1801e7d1e;
        fcn.180224990(param_1, 0x1804b74d8, 0xc3);
    }
    return;
}

// ============================================================
// Function: FUN_1801e8310
// Address: 0x1801e8310
// Size: 58 bytes
// ============================================================
void fcn.1801e8310(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_60h, int64_t arg_80h, int64_t arg_88h)
{
    int64_t *piVar1;
    uint32_t uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 *puVar9;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t iVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if ((char)*(uint32_t *)(in_RDX + 0x104) < '\0') {
        *(uint32_t *)(in_RDX + 0x104) = *(uint32_t *)(in_RDX + 0x104) & 0xffffff7f;
        piVar1 = (int64_t *)(in_RCX + 0x60);
        *piVar1 = *piVar1 + -1;
        if (*piVar1 == 0) {
            puVar9 = *(undefined8 **)(in_RCX + 8);
            *(undefined8 *)((int64_t)&arg_30h + iVar8) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_RSI;
            *(undefined8 *)((int64_t)auStackX_18 + iVar8 + 8) = unaff_RDI;
            *(undefined8 *)((int64_t)auStackX_18 + iVar8) = 0x1801e3df5;
            iVar5 = fcn.18045a350();
            iVar5 = -iVar5;
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x1801e3e0e;
            func_0x0001801e1a70();
            uVar3 = puVar9[0x79];
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x1801e3e1a;
            uVar6 = func_0x000180202870(uVar3);
            iVar10 = -1;
            uVar11 = 0xffffffffffffffff;
            if (uVar6 < 0x5555555555555556) {
                uVar11 = uVar6 * 3;
            }
            uVar3 = *puVar9;
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x1801e3e3f;
            iVar7 = func_0x0001801e8e50(uVar3);
            if (uVar11 <= -iVar7 - 1U) {
                iVar10 = iVar7 + uVar11;
            }
            uVar2 = *(uint32_t *)(puVar9 + 0xb2);
            puVar9[0xb3] = iVar10;
            if ((uVar2 & 2) == 0) {
                *(undefined8 *)((int64_t)&arg_48h + iVar5 + iVar8) = puVar9[0xae];
                uVar3 = puVar9[0xaf];
                *(undefined8 *)((int64_t)&arg_40h + iVar5 + iVar8) = 0;
                *(undefined8 *)((int64_t)&arg_50h + iVar5 + iVar8) = uVar3;
                uVar3 = puVar9[0x11];
                *(undefined8 *)((int64_t)&arg_58h + iVar5 + iVar8) = puVar9[0xb0];
                uVar4 = puVar9[0xb1];
                *(uint32_t *)((int64_t)&arg_40h + iVar5 + iVar8) = uVar2 & 1;
                *(undefined8 *)((int64_t)&arg_60h + iVar5 + iVar8) = uVar4;
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar8) = 0x1801e3eb4;
                func_0x000180207f00(uVar3, (int64_t)&arg_40h + iVar5 + iVar8);
                *(uint32_t *)(puVar9 + 0xba) = *(uint32_t *)(puVar9 + 0xba) | 0x1000000;
            }
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e8350
// Address: 0x1801e8350
// Size: 173 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801e8350(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    undefined8 *in_RCX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e836a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar5 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e8378;
    uVar3 = func_0x0001801e39a0(uVar5);
    uVar5 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e8383;
    uVar4 = func_0x0001801e3970(uVar5);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e838e;
    func_0x00018026d890(uVar3);
    uVar5 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e8396;
    uVar5 = func_0x0001801e39d0(uVar5);
    iVar1 = *(int32_t *)(in_RCX + 3);
    while (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e83a8;
        uVar6 = func_0x0001801dd170(uVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e83b3;
        uVar7 = func_0x0001801dd710(uVar4, uVar6);
        uVar6 = in_RCX[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e83c2;
        func_0x00018026d630(uVar6, uVar3, uVar7);
        if (*(int32_t *)(in_RCX + 3) != 0) break;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e83d5;
        func_0x0001801dd2b0(uVar5, 1);
        iVar1 = *(int32_t *)(in_RCX + 3);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e83e3;
    func_0x00018026d900(uVar3);
    return 1;
}

// ============================================================
// Function: FUN_1801e8400
// Address: 0x1801e8400
// Size: 70 bytes
// ============================================================
undefined8 fcn.1801e8400(undefined8 *param_1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e840c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(int32_t *)((int64_t)param_1 + 0x1c) == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801e8429;
    fcn.18026d400(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801e8432;
    fcn.180272c20(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    *param_1 = 0;
    param_1[2] = 0;
    return 1;
}

// ============================================================
// Function: FUN_1801e8450
// Address: 0x1801e8450
// Size: 129 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801e8450(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 *in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e8460;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801e8471;
    iVar2 = fcn.1801e39a0(in_RDX);
    if (iVar2 != 0) {
        *in_RCX = in_RDX;
        in_RCX[3] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801e8484;
        iVar2 = fcn.18026d4a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        in_RCX[1] = iVar2;
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801e84a2;
            iVar2 = fcn.180272e00(*(int64_t *)((int64_t)aiStackX_18 + iVar1), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1));
            in_RCX[2] = iVar2;
            if (iVar2 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801e84b4;
            fcn.18026d400(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e84e0
// Address: 0x1801e84e0
// Size: 136 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801e84e0(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 *in_RCX;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e84f0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar4 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e84fe;
    uVar4 = fcn.1801e39a0(uVar4);
    if (*(int32_t *)((int64_t)in_RCX + 0x1c) == 0) {
        if (*(int32_t *)(in_RCX + 3) == 0) {
            uVar1 = in_RCX[1];
            *(undefined4 *)(in_RCX + 3) = 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e851d;
            func_0x00018026d5b0(uVar1);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e8525;
        fcn.18026d900(uVar4);
        uVar1 = in_RCX[2];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e8533;
        iVar2 = func_0x000180272cd0(uVar1, (int64_t)&arg_28h + iVar3);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e853f;
            fcn.18026d890(uVar4);
            return 0;
        }
        *(undefined4 *)((int64_t)in_RCX + 0x1c) = 1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e8558;
        fcn.18026d890(uVar4);
    }
    return 1;
}

// ============================================================
// Function: FUN_1801e8570
// Address: 0x1801e8570
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801e8570(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    bool bVar6;
    uint64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    bool bVar8;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    bool bVar7;
    
    uStack_30 = 0x1801e8586;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    bVar7 = false;
    bVar6 = false;
    uVar1 = *(undefined8 *)(in_RCX + 0xa0);
    *(undefined4 *)((int64_t)&arg_38h + iVar5) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e85a7;
    iVar2 = func_0x00018020ecc0(uVar1);
    bVar8 = bVar7;
    if (0 < iVar2) {
        uVar1 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e85c3;
        iVar3 = func_0x00018020e980(uVar1);
        if (((0 < iVar3) && (bVar8 = bVar6, (uint64_t)(int64_t)(iVar3 + iVar2) <= in_R8)) && (in_R8 < 0xc6)) {
            *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R13;
            **(int64_t **)((int64_t)&arg_58h + iVar5) = (in_R8 - (int64_t)iVar3) - (int64_t)iVar2;
            if (in_R9 == 0) {
                bVar8 = true;
            } else {
                uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                *(int64_t *)((int64_t)&var_8h + iVar5) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e862c;
                iVar4 = func_0x000180212170(uVar1, 0, 0, 0);
                bVar8 = bVar7;
                if (iVar4 != 0) {
                    uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                    *(int32_t *)((int64_t)&var_8h + iVar5) = ((int32_t)in_R8 - iVar3) - iVar2;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e8654;
                    iVar3 = func_0x0001802121a0(uVar1, in_R9, (int64_t)&arg_38h + iVar5, iVar3 + in_RDX);
                    bVar8 = bVar6;
                    if (iVar3 != 0) {
                        uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e8673;
                        iVar2 = func_0x000180210b80(uVar1, 0x11, iVar2, in_R8 + (in_RDX - iVar2));
                        if (iVar2 != 0) {
                            uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e8690;
                            iVar2 = func_0x000180211e00(uVar1, *(int32_t *)((int64_t)&arg_38h + iVar5) + in_R9, 
                                                        (int64_t)&arg_38h + iVar5);
                            bVar8 = iVar2 != 0;
                        }
                    }
                }
            }
        }
    }
    return bVar8;
}

// ============================================================
// Function: FUN_1801e85b9
// Address: 0x1801e85b9
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801e8570(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    bool bVar6;
    uint64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    bool bVar8;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    bool bVar7;
    
    uStack_30 = 0x1801e8586;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    bVar7 = false;
    bVar6 = false;
    uVar1 = *(undefined8 *)(in_RCX + 0xa0);
    *(undefined4 *)((int64_t)&arg_38h + iVar5) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e85a7;
    iVar2 = func_0x00018020ecc0(uVar1);
    bVar8 = bVar7;
    if (0 < iVar2) {
        uVar1 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e85c3;
        iVar3 = func_0x00018020e980(uVar1);
        if (((0 < iVar3) && (bVar8 = bVar6, (uint64_t)(int64_t)(iVar3 + iVar2) <= in_R8)) && (in_R8 < 0xc6)) {
            *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R13;
            **(int64_t **)((int64_t)&arg_58h + iVar5) = (in_R8 - (int64_t)iVar3) - (int64_t)iVar2;
            if (in_R9 == 0) {
                bVar8 = true;
            } else {
                uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                *(int64_t *)((int64_t)&var_8h + iVar5) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e862c;
                iVar4 = func_0x000180212170(uVar1, 0, 0, 0);
                bVar8 = bVar7;
                if (iVar4 != 0) {
                    uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                    *(int32_t *)((int64_t)&var_8h + iVar5) = ((int32_t)in_R8 - iVar3) - iVar2;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e8654;
                    iVar3 = func_0x0001802121a0(uVar1, in_R9, (int64_t)&arg_38h + iVar5, iVar3 + in_RDX);
                    bVar8 = bVar6;
                    if (iVar3 != 0) {
                        uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e8673;
                        iVar2 = func_0x000180210b80(uVar1, 0x11, iVar2, in_R8 + (in_RDX - iVar2));
                        if (iVar2 != 0) {
                            uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e8690;
                            iVar2 = func_0x000180211e00(uVar1, *(int32_t *)((int64_t)&arg_38h + iVar5) + in_R9, 
                                                        (int64_t)&arg_38h + iVar5);
                            bVar8 = iVar2 != 0;
                        }
                    }
                }
            }
        }
    }
    return bVar8;
}

// ============================================================
// Function: FUN_1801e85f9
// Address: 0x1801e85f9
// Size: 170 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801e8570(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    bool bVar6;
    uint64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    bool bVar8;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    bool bVar7;
    
    uStack_30 = 0x1801e8586;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    bVar7 = false;
    bVar6 = false;
    uVar1 = *(undefined8 *)(in_RCX + 0xa0);
    *(undefined4 *)((int64_t)&arg_38h + iVar5) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e85a7;
    iVar2 = func_0x00018020ecc0(uVar1);
    bVar8 = bVar7;
    if (0 < iVar2) {
        uVar1 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e85c3;
        iVar3 = func_0x00018020e980(uVar1);
        if (((0 < iVar3) && (bVar8 = bVar6, (uint64_t)(int64_t)(iVar3 + iVar2) <= in_R8)) && (in_R8 < 0xc6)) {
            *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R13;
            **(int64_t **)((int64_t)&arg_58h + iVar5) = (in_R8 - (int64_t)iVar3) - (int64_t)iVar2;
            if (in_R9 == 0) {
                bVar8 = true;
            } else {
                uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                *(int64_t *)((int64_t)&var_8h + iVar5) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e862c;
                iVar4 = func_0x000180212170(uVar1, 0, 0, 0);
                bVar8 = bVar7;
                if (iVar4 != 0) {
                    uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                    *(int32_t *)((int64_t)&var_8h + iVar5) = ((int32_t)in_R8 - iVar3) - iVar2;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e8654;
                    iVar3 = func_0x0001802121a0(uVar1, in_R9, (int64_t)&arg_38h + iVar5, iVar3 + in_RDX);
                    bVar8 = bVar6;
                    if (iVar3 != 0) {
                        uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e8673;
                        iVar2 = func_0x000180210b80(uVar1, 0x11, iVar2, in_R8 + (in_RDX - iVar2));
                        if (iVar2 != 0) {
                            uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e8690;
                            iVar2 = func_0x000180211e00(uVar1, *(int32_t *)((int64_t)&arg_38h + iVar5) + in_R9, 
                                                        (int64_t)&arg_38h + iVar5);
                            bVar8 = iVar2 != 0;
                        }
                    }
                }
            }
        }
    }
    return bVar8;
}

// ============================================================
// Function: FUN_1801e86a3
// Address: 0x1801e86a3
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801e8570(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    bool bVar6;
    uint64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    bool bVar8;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    bool bVar7;
    
    uStack_30 = 0x1801e8586;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    bVar7 = false;
    bVar6 = false;
    uVar1 = *(undefined8 *)(in_RCX + 0xa0);
    *(undefined4 *)((int64_t)&arg_38h + iVar5) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e85a7;
    iVar2 = func_0x00018020ecc0(uVar1);
    bVar8 = bVar7;
    if (0 < iVar2) {
        uVar1 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e85c3;
        iVar3 = func_0x00018020e980(uVar1);
        if (((0 < iVar3) && (bVar8 = bVar6, (uint64_t)(int64_t)(iVar3 + iVar2) <= in_R8)) && (in_R8 < 0xc6)) {
            *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R13;
            **(int64_t **)((int64_t)&arg_58h + iVar5) = (in_R8 - (int64_t)iVar3) - (int64_t)iVar2;
            if (in_R9 == 0) {
                bVar8 = true;
            } else {
                uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                *(int64_t *)((int64_t)&var_8h + iVar5) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e862c;
                iVar4 = func_0x000180212170(uVar1, 0, 0, 0);
                bVar8 = bVar7;
                if (iVar4 != 0) {
                    uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                    *(int32_t *)((int64_t)&var_8h + iVar5) = ((int32_t)in_R8 - iVar3) - iVar2;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e8654;
                    iVar3 = func_0x0001802121a0(uVar1, in_R9, (int64_t)&arg_38h + iVar5, iVar3 + in_RDX);
                    bVar8 = bVar6;
                    if (iVar3 != 0) {
                        uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e8673;
                        iVar2 = func_0x000180210b80(uVar1, 0x11, iVar2, in_R8 + (in_RDX - iVar2));
                        if (iVar2 != 0) {
                            uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e8690;
                            iVar2 = func_0x000180211e00(uVar1, *(int32_t *)((int64_t)&arg_38h + iVar5) + in_R9, 
                                                        (int64_t)&arg_38h + iVar5);
                            bVar8 = iVar2 != 0;
                        }
                    }
                }
            }
        }
    }
    return bVar8;
}

// ============================================================
// Function: FUN_1801e86a8
// Address: 0x1801e86a8
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801e8570(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    bool bVar6;
    uint64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    bool bVar8;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    bool bVar7;
    
    uStack_30 = 0x1801e8586;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    bVar7 = false;
    bVar6 = false;
    uVar1 = *(undefined8 *)(in_RCX + 0xa0);
    *(undefined4 *)((int64_t)&arg_38h + iVar5) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e85a7;
    iVar2 = func_0x00018020ecc0(uVar1);
    bVar8 = bVar7;
    if (0 < iVar2) {
        uVar1 = *(undefined8 *)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e85c3;
        iVar3 = func_0x00018020e980(uVar1);
        if (((0 < iVar3) && (bVar8 = bVar6, (uint64_t)(int64_t)(iVar3 + iVar2) <= in_R8)) && (in_R8 < 0xc6)) {
            *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R13;
            **(int64_t **)((int64_t)&arg_58h + iVar5) = (in_R8 - (int64_t)iVar3) - (int64_t)iVar2;
            if (in_R9 == 0) {
                bVar8 = true;
            } else {
                uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                *(int64_t *)((int64_t)&var_8h + iVar5) = in_RDX;
                *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e862c;
                iVar4 = func_0x000180212170(uVar1, 0, 0, 0);
                bVar8 = bVar7;
                if (iVar4 != 0) {
                    uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                    *(int32_t *)((int64_t)&var_8h + iVar5) = ((int32_t)in_R8 - iVar3) - iVar2;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e8654;
                    iVar3 = func_0x0001802121a0(uVar1, in_R9, (int64_t)&arg_38h + iVar5, iVar3 + in_RDX);
                    bVar8 = bVar6;
                    if (iVar3 != 0) {
                        uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e8673;
                        iVar2 = func_0x000180210b80(uVar1, 0x11, iVar2, in_R8 + (in_RDX - iVar2));
                        if (iVar2 != 0) {
                            uVar1 = *(undefined8 *)(in_RCX + 0xa0);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801e8690;
                            iVar2 = func_0x000180211e00(uVar1, *(int32_t *)((int64_t)&arg_38h + iVar5) + in_R9, 
                                                        (int64_t)&arg_38h + iVar5);
                            bVar8 = iVar2 != 0;
                        }
                    }
                }
            }
        }
    }
    return bVar8;
}

// ============================================================
// Function: FUN_1801e86c0
// Address: 0x1801e86c0
// Size: 139 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 fcn.1801e86c0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801e86d6;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar4 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e86f3;
    iVar1 = fcn.18020ecc0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                          *(int64_t *)(&stack0x00000078 + iVar3), *(int64_t *)(&stack0x00000080 + iVar3));
    if (0 < iVar1) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e870a;
        iVar2 = fcn.18020e980(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                              *(int64_t *)((int64_t)&arg_40h + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000078 + iVar3), 
                              *(int64_t *)(&stack0x00000080 + iVar3), *(int64_t *)(&stack0x000000c8 + iVar3), 
                              *(int64_t *)(&stack0x00000128 + iVar3), *(int64_t *)(&stack0x00000130 + iVar3));
        if (0 < iVar2) {
            **(int64_t **)((int64_t)&arg_58h + iVar3) = (int64_t)iVar1 + 0x10 + (int64_t)iVar2 + in_R8;
            if (in_R9 == 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e875f;
            iVar1 = fcn.18021b9c0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3));
            uVar5 = 0;
            if (iVar1 != 0) {
                *(int64_t *)((int64_t)&var_8h + iVar3) = in_R9;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e877c;
                iVar1 = fcn.1802128b0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3)
                                     );
                uVar5 = uVar4;
                if (iVar1 != 0) {
                    *(int32_t *)((int64_t)&var_8h + iVar3) = (int32_t)in_R8;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e879b;
                    iVar1 = fcn.180212930(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                          *(int64_t *)(&stack0x00000028 + iVar3));
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e87b7;
                        iVar1 = fcn.180212650(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar3));
                        if (iVar1 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e87d2;
                            iVar1 = fcn.180210b80(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                                                  *(int64_t *)(&stack0x00000028 + iVar3));
                            uVar5 = 0;
                            if (iVar1 != 0) {
                                uVar5 = 1;
                            }
                        }
                    }
                }
            }
            return uVar5;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e874b
// Address: 0x1801e874b
// Size: 152 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 fcn.1801e86c0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801e86d6;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar4 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e86f3;
    iVar1 = fcn.18020ecc0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                          *(int64_t *)(&stack0x00000078 + iVar3), *(int64_t *)(&stack0x00000080 + iVar3));
    if (0 < iVar1) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e870a;
        iVar2 = fcn.18020e980(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                              *(int64_t *)((int64_t)&arg_40h + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000078 + iVar3), 
                              *(int64_t *)(&stack0x00000080 + iVar3), *(int64_t *)(&stack0x000000c8 + iVar3), 
                              *(int64_t *)(&stack0x00000128 + iVar3), *(int64_t *)(&stack0x00000130 + iVar3));
        if (0 < iVar2) {
            **(int64_t **)((int64_t)&arg_58h + iVar3) = (int64_t)iVar1 + 0x10 + (int64_t)iVar2 + in_R8;
            if (in_R9 == 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e875f;
            iVar1 = fcn.18021b9c0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3));
            uVar5 = 0;
            if (iVar1 != 0) {
                *(int64_t *)((int64_t)&var_8h + iVar3) = in_R9;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e877c;
                iVar1 = fcn.1802128b0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3)
                                     );
                uVar5 = uVar4;
                if (iVar1 != 0) {
                    *(int32_t *)((int64_t)&var_8h + iVar3) = (int32_t)in_R8;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e879b;
                    iVar1 = fcn.180212930(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                          *(int64_t *)(&stack0x00000028 + iVar3));
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e87b7;
                        iVar1 = fcn.180212650(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar3));
                        if (iVar1 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e87d2;
                            iVar1 = fcn.180210b80(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                                                  *(int64_t *)(&stack0x00000028 + iVar3));
                            uVar5 = 0;
                            if (iVar1 != 0) {
                                uVar5 = 1;
                            }
                        }
                    }
                }
            }
            return uVar5;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e87e3
// Address: 0x1801e87e3
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 fcn.1801e86c0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801e86d6;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar4 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e86f3;
    iVar1 = fcn.18020ecc0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3), *(int64_t *)(&stack0x00000050 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                          *(int64_t *)(&stack0x00000078 + iVar3), *(int64_t *)(&stack0x00000080 + iVar3));
    if (0 < iVar1) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e870a;
        iVar2 = fcn.18020e980(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                              *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)((int64_t)&arg_38h + iVar3), 
                              *(int64_t *)((int64_t)&arg_40h + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000078 + iVar3), 
                              *(int64_t *)(&stack0x00000080 + iVar3), *(int64_t *)(&stack0x000000c8 + iVar3), 
                              *(int64_t *)(&stack0x00000128 + iVar3), *(int64_t *)(&stack0x00000130 + iVar3));
        if (0 < iVar2) {
            **(int64_t **)((int64_t)&arg_58h + iVar3) = (int64_t)iVar1 + 0x10 + (int64_t)iVar2 + in_R8;
            if (in_R9 == 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e875f;
            iVar1 = fcn.18021b9c0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3));
            uVar5 = 0;
            if (iVar1 != 0) {
                *(int64_t *)((int64_t)&var_8h + iVar3) = in_R9;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e877c;
                iVar1 = fcn.1802128b0(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3)
                                     );
                uVar5 = uVar4;
                if (iVar1 != 0) {
                    *(int32_t *)((int64_t)&var_8h + iVar3) = (int32_t)in_R8;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e879b;
                    iVar1 = fcn.180212930(*(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                          *(int64_t *)(&stack0x00000028 + iVar3));
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e87b7;
                        iVar1 = fcn.180212650(*(int64_t *)((int64_t)&var_8h + iVar3), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -0x20), 
                                              *(int64_t *)((int64_t)aiStackX_8 + iVar3), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar3));
                        if (iVar1 != 0) {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1801e87d2;
                            iVar1 = fcn.180210b80(*(int64_t *)((int64_t)aiStackX_8 + iVar3 + 8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                                                  *(int64_t *)(&stack0x00000028 + iVar3));
                            uVar5 = 0;
                            if (iVar1 != 0) {
                                uVar5 = 1;
                            }
                        }
                    }
                }
            }
            return uVar5;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e8810
// Address: 0x1801e8810
// Size: 95 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_51h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_41h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_13ah
// WARNING: [rz-ghidra] Detected overlap for variable var_12bh
// WARNING: [rz-ghidra] Detected overlap for variable var_129h
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_138h
// WARNING: [rz-ghidra] Detected overlap for variable arg_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ah
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_15ah
// WARNING: [rz-ghidra] Detected overlap for variable var_128h

void fcn.1801e8810(int64_t arg_30h, int64_t arg_190h, int64_t arg_1a0h, int64_t arg_1b0h, int64_t arg_1f0h,
                  int64_t arg_1f8h)
{
    undefined uVar1;
    undefined uVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined uVar8;
    undefined uVar9;
    undefined uVar10;
    undefined uVar11;
    undefined uVar12;
    undefined uVar13;
    undefined uVar14;
    undefined uVar15;
    undefined uVar16;
    undefined uVar17;
    undefined uVar18;
    undefined uVar19;
    undefined uVar20;
    undefined uVar21;
    undefined uVar22;
    undefined uVar23;
    undefined4 uVar24;
    undefined4 uVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    int32_t iVar28;
    int32_t iVar29;
    int64_t iVar30;
    int64_t iVar31;
    int64_t in_RCX;
    uint64_t uVar32;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_178h;
    int64_t var_170h;
    undefined4 uStack_168;
    undefined4 uStack_164;
    undefined4 var_160h;
    undefined var_15ch;
    int64_t var_15bh;
    undefined4 uStack_152;
    undefined4 uStack_14e;
    undefined4 var_14ah;
    int64_t var_146h;
    int64_t var_13eh;
    undefined var_130h;
    int64_t var_12fh;
    int64_t var_58h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801e8829;
    iVar30 = fcn.18045a350();
    iVar30 = -iVar30;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar30);
    uVar4 = *(uint32_t *)(in_RCX + 0x5d0);
    *(undefined4 *)((int64_t)&arg_50h + iVar30 + 1) = 0;
    *(undefined (*) [16])((int64_t)&arg_40h + iVar30 + 1) = ZEXT816(0);
    *(undefined8 *)((int64_t)&var_10h + iVar30) = 0;
    if ((uVar4 & 0x2000000) == 0) goto code_r0x0001801e8acb;
    *(undefined8 *)((int64_t)&arg_1b0h + iVar30) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8888;
    iVar31 = fcn.180224d60(*(int64_t *)(&stack0x00000000 + iVar30));
    if (iVar31 == 0) goto code_r0x0001801e8acb;
    *(undefined *)((int64_t)&arg_40h + iVar30) = 8;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e88b5;
    iVar28 = fcn.18021b9c0(*(int64_t *)(&stack0x00000000 + iVar30), *(int64_t *)((int64_t)&var_20h + iVar30), 
                           *(int64_t *)(&stack0x00000028 + iVar30), *(int64_t *)((int64_t)&arg_30h + iVar30), 
                           *(int64_t *)(&stack0x00000038 + iVar30));
    if (iVar28 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e88ce;
        fcn.180224990(iVar31, 0x1804b74f8, 0x5aa);
        goto code_r0x0001801e8acb;
    }
    *(undefined8 *)((int64_t)&arg_1f0h + iVar30) = unaff_RBX;
    uVar3 = *(undefined4 *)(in_RCX + 0x438);
    *(undefined8 *)((int64_t)&arg_1f8h + iVar30) = unaff_RDI;
    uVar1 = *(undefined *)(in_RCX + 0x43c);
    auVar6._4_4_ = unaff_XMM6_Db;
    auVar6._0_4_ = unaff_XMM6_Da;
    auVar6._8_4_ = unaff_XMM6_Dc;
    auVar6._12_4_ = unaff_XMM6_Dd;
    *(undefined (*) [16])((int64_t)&arg_1a0h + iVar30) = auVar6;
    uVar24 = *(undefined4 *)(in_RCX + 0x428);
    uVar25 = *(undefined4 *)(in_RCX + 0x42c);
    uVar26 = *(undefined4 *)(in_RCX + 0x430);
    uVar27 = *(undefined4 *)(in_RCX + 0x434);
    *(undefined4 *)((int64_t)&arg_30h + iVar30) = *(undefined4 *)((int64_t)&arg_50h + iVar30);
    uVar2 = *(undefined *)((int64_t)&arg_50h + iVar30 + 4);
    auVar7._4_4_ = unaff_XMM7_Db;
    auVar7._0_4_ = unaff_XMM7_Da;
    auVar7._8_4_ = unaff_XMM7_Dc;
    auVar7._12_4_ = unaff_XMM7_Dd;
    *(undefined (*) [16])((int64_t)&arg_190h + iVar30) = auVar7;
    uVar8 = *(undefined *)((int64_t)&arg_40h + iVar30);
    uVar9 = *(undefined *)((int64_t)&arg_40h + iVar30 + 1);
    uVar10 = *(undefined *)((int64_t)&arg_40h + iVar30 + 2);
    uVar11 = *(undefined *)((int64_t)&arg_40h + iVar30 + 3);
    uVar12 = *(undefined *)((int64_t)&arg_40h + iVar30 + 4);
    uVar13 = *(undefined *)((int64_t)&arg_40h + iVar30 + 5);
    uVar14 = *(undefined *)((int64_t)&arg_40h + iVar30 + 6);
    uVar15 = *(undefined *)((int64_t)&arg_40h + iVar30 + 7);
    uVar16 = (&stack0x00000048)[iVar30];
    uVar17 = (&stack0x00000049)[iVar30];
    uVar18 = (&stack0x0000004a)[iVar30];
    uVar19 = (&stack0x0000004b)[iVar30];
    uVar20 = (&stack0x0000004c)[iVar30];
    uVar21 = (&stack0x0000004d)[iVar30];
    uVar22 = (&stack0x0000004e)[iVar30];
    uVar23 = (&stack0x0000004f)[iVar30];
    var_146h._0_6_ = 0;
    var_146h._6_2_ = 0;
    var_13eh._0_4_ = 0;
    *(undefined *)((int64_t)&var_20h + iVar30) = uVar8;
    *(undefined *)((int64_t)&var_20h + iVar30 + 1) = uVar9;
    *(undefined *)((int64_t)&var_20h + iVar30 + 2) = uVar10;
    *(undefined *)((int64_t)&var_20h + iVar30 + 3) = uVar11;
    *(undefined *)((int64_t)&var_20h + iVar30 + 4) = uVar12;
    *(undefined *)((int64_t)&var_20h + iVar30 + 5) = uVar13;
    *(undefined *)((int64_t)&var_20h + iVar30 + 6) = uVar14;
    *(undefined *)((int64_t)&var_20h + iVar30 + 7) = uVar15;
    (&stack0x00000028)[iVar30] = uVar16;
    (&stack0x00000029)[iVar30] = uVar17;
    (&stack0x0000002a)[iVar30] = uVar18;
    (&stack0x0000002b)[iVar30] = uVar19;
    (&stack0x0000002c)[iVar30] = uVar20;
    (&stack0x0000002d)[iVar30] = uVar21;
    (&stack0x0000002e)[iVar30] = uVar22;
    (&stack0x0000002f)[iVar30] = uVar23;
    var_13eh._4_2_ = 0;
    var_12fh._0_4_ = 0;
    var_12fh._4_2_ = 0;
    var_12fh._6_1_ = 0;
    *(undefined *)((int64_t)&arg_30h + iVar30 + 4) = uVar2;
    var_130h = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8945;
    var_178h = func_0x0001802450c0();
    var_15bh._1_4_ = *(undefined4 *)((int64_t)&var_20h + iVar30 + 1);
    unique0x100007fa = *(undefined4 *)((int64_t)&var_20h + iVar30 + 5);
    uStack_152 = *(undefined4 *)(&stack0x00000029 + iVar30);
    uStack_14e = *(undefined4 *)(&stack0x0000002d + iVar30);
    stack0xfffffffffffffec8 = 0;
    var_170h._0_4_ = uVar24;
    var_170h._4_4_ = uVar25;
    uStack_168 = uVar26;
    uStack_164 = uVar27;
    var_15bh._0_1_ = uVar8;
    var_14ah = *(undefined4 *)((int64_t)&arg_30h + iVar30 + 1);
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e897d;
    var_160h = uVar3;
    var_15ch = uVar1;
    iVar28 = func_0x00018026bf70(in_RDX, 0, (int64_t)&var_146h + 6);
    if ((iVar28 == 0) || (CONCAT26(var_13eh._4_2_, CONCAT42((undefined4)var_13eh, var_146h._6_2_)) == 0)) {
code_r0x0001801e8a73:
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a88;
        fcn.180224990(stack0xfffffffffffffec8, 0x1804b74f8, 0x34c);
code_r0x0001801e8a88:
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a9d;
        fcn.180224990(iVar31, 0x1804b74f8, 0x5b8);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89b4;
        *(int64_t *)0x0 =
             fcn.1802248d0(*(int64_t *)(&stack0x00000000 + iVar30), *(int64_t *)((int64_t)&iStackX_8 + iVar30));
        if (*(int64_t *)0x0 == 0) goto code_r0x0001801e8a73;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89d0;
        iVar28 = func_0x00018026bf70(in_RDX, *(int64_t *)0x0, (int64_t)&var_146h + 6);
        if (iVar28 == 0) goto code_r0x0001801e8a73;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89ea;
        iVar28 = func_0x0001801e8b10(&var_178h, (int64_t)&var_12fh + 7, (int64_t)&var_10h + iVar30);
        if (iVar28 == 0) goto code_r0x0001801e8a88;
        iVar5 = *(int64_t *)((int64_t)&var_10h + iVar30);
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a06;
        iVar28 = fcn.18020ecc0(*(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)(&stack0x00000028 + iVar30), 
                               *(int64_t *)((int64_t)&arg_30h + iVar30), *(int64_t *)(&stack0x00000038 + iVar30), 
                               *(int64_t *)((int64_t)&arg_40h + iVar30), *(int64_t *)(&stack0x00000048 + iVar30), 
                               *(int64_t *)((int64_t)&arg_50h + iVar30), *(int64_t *)(&stack0x00000058 + iVar30), 
                               *(int64_t *)(&stack0x00000060 + iVar30), *(int64_t *)(&stack0x00000068 + iVar30), 
                               *(int64_t *)(&stack0x00000080 + iVar30), *(int64_t *)(&stack0x00000088 + iVar30));
        if (iVar28 < 1) goto code_r0x0001801e8a88;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a19;
        iVar29 = fcn.18020e980(*(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)(&stack0x00000028 + iVar30), 
                               *(int64_t *)((int64_t)&arg_30h + iVar30), *(int64_t *)(&stack0x00000038 + iVar30), 
                               *(int64_t *)((int64_t)&arg_40h + iVar30), *(int64_t *)(&stack0x00000048 + iVar30), 
                               *(int64_t *)((int64_t)&arg_50h + iVar30), *(int64_t *)(&stack0x00000058 + iVar30), 
                               *(int64_t *)(&stack0x00000060 + iVar30), *(int64_t *)(&stack0x00000068 + iVar30), 
                               *(int64_t *)(&stack0x00000080 + iVar30), *(int64_t *)(&stack0x00000088 + iVar30), 
                               *(int64_t *)(&stack0x000000d0 + iVar30), *(int64_t *)(&stack0x00000130 + iVar30), 
                               *(int64_t *)(&stack0x00000138 + iVar30));
        if ((iVar29 < 1) ||
           (uVar32 = (int64_t)iVar29 + 0x10 + iVar5 + (int64_t)iVar28,
           *(uint64_t *)((int64_t)&var_18h + iVar30) = uVar32, 0xc5 < uVar32)) goto code_r0x0001801e8a88;
        *(int64_t *)(&stack0x00000000 + iVar30) = (int64_t)&var_18h + iVar30;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a56;
        iVar28 = fcn.1801e86c0(*(int64_t *)((int64_t)&var_10h + iVar30), *(int64_t *)((int64_t)&var_18h + iVar30), 
                               *(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)((int64_t)&arg_30h + iVar30));
        if ((iVar28 == 0) || (uVar32 = *(uint64_t *)((int64_t)&var_18h + iVar30), uVar32 < 0x10))
        goto code_r0x0001801e8a88;
        *(int64_t *)(in_RCX + 0x58) = iVar31;
        *(uint64_t *)(in_RCX + 0x60) = uVar32;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8ab3;
    fcn.180224990(stack0xfffffffffffffec8, 0x1804b74f8, 0x34c);
code_r0x0001801e8acb:
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8ada;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar30));
    return;
}

// ============================================================
// Function: FUN_1801e886f
// Address: 0x1801e886f
// Size: 104 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_51h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_41h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_13ah
// WARNING: [rz-ghidra] Detected overlap for variable var_12bh
// WARNING: [rz-ghidra] Detected overlap for variable var_129h
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_138h
// WARNING: [rz-ghidra] Detected overlap for variable arg_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ah
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_15ah
// WARNING: [rz-ghidra] Detected overlap for variable var_128h

void fcn.1801e8810(int64_t arg_30h, int64_t arg_190h, int64_t arg_1a0h, int64_t arg_1b0h, int64_t arg_1f0h,
                  int64_t arg_1f8h)
{
    undefined uVar1;
    undefined uVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined uVar8;
    undefined uVar9;
    undefined uVar10;
    undefined uVar11;
    undefined uVar12;
    undefined uVar13;
    undefined uVar14;
    undefined uVar15;
    undefined uVar16;
    undefined uVar17;
    undefined uVar18;
    undefined uVar19;
    undefined uVar20;
    undefined uVar21;
    undefined uVar22;
    undefined uVar23;
    undefined4 uVar24;
    undefined4 uVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    int32_t iVar28;
    int32_t iVar29;
    int64_t iVar30;
    int64_t iVar31;
    int64_t in_RCX;
    uint64_t uVar32;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_178h;
    int64_t var_170h;
    undefined4 uStack_168;
    undefined4 uStack_164;
    undefined4 var_160h;
    undefined var_15ch;
    int64_t var_15bh;
    undefined4 uStack_152;
    undefined4 uStack_14e;
    undefined4 var_14ah;
    int64_t var_146h;
    int64_t var_13eh;
    undefined var_130h;
    int64_t var_12fh;
    int64_t var_58h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801e8829;
    iVar30 = fcn.18045a350();
    iVar30 = -iVar30;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar30);
    uVar4 = *(uint32_t *)(in_RCX + 0x5d0);
    *(undefined4 *)((int64_t)&arg_50h + iVar30 + 1) = 0;
    *(undefined (*) [16])((int64_t)&arg_40h + iVar30 + 1) = ZEXT816(0);
    *(undefined8 *)((int64_t)&var_10h + iVar30) = 0;
    if ((uVar4 & 0x2000000) == 0) goto code_r0x0001801e8acb;
    *(undefined8 *)((int64_t)&arg_1b0h + iVar30) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8888;
    iVar31 = fcn.180224d60(*(int64_t *)(&stack0x00000000 + iVar30));
    if (iVar31 == 0) goto code_r0x0001801e8acb;
    *(undefined *)((int64_t)&arg_40h + iVar30) = 8;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e88b5;
    iVar28 = fcn.18021b9c0(*(int64_t *)(&stack0x00000000 + iVar30), *(int64_t *)((int64_t)&var_20h + iVar30), 
                           *(int64_t *)(&stack0x00000028 + iVar30), *(int64_t *)((int64_t)&arg_30h + iVar30), 
                           *(int64_t *)(&stack0x00000038 + iVar30));
    if (iVar28 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e88ce;
        fcn.180224990(iVar31, 0x1804b74f8, 0x5aa);
        goto code_r0x0001801e8acb;
    }
    *(undefined8 *)((int64_t)&arg_1f0h + iVar30) = unaff_RBX;
    uVar3 = *(undefined4 *)(in_RCX + 0x438);
    *(undefined8 *)((int64_t)&arg_1f8h + iVar30) = unaff_RDI;
    uVar1 = *(undefined *)(in_RCX + 0x43c);
    auVar6._4_4_ = unaff_XMM6_Db;
    auVar6._0_4_ = unaff_XMM6_Da;
    auVar6._8_4_ = unaff_XMM6_Dc;
    auVar6._12_4_ = unaff_XMM6_Dd;
    *(undefined (*) [16])((int64_t)&arg_1a0h + iVar30) = auVar6;
    uVar24 = *(undefined4 *)(in_RCX + 0x428);
    uVar25 = *(undefined4 *)(in_RCX + 0x42c);
    uVar26 = *(undefined4 *)(in_RCX + 0x430);
    uVar27 = *(undefined4 *)(in_RCX + 0x434);
    *(undefined4 *)((int64_t)&arg_30h + iVar30) = *(undefined4 *)((int64_t)&arg_50h + iVar30);
    uVar2 = *(undefined *)((int64_t)&arg_50h + iVar30 + 4);
    auVar7._4_4_ = unaff_XMM7_Db;
    auVar7._0_4_ = unaff_XMM7_Da;
    auVar7._8_4_ = unaff_XMM7_Dc;
    auVar7._12_4_ = unaff_XMM7_Dd;
    *(undefined (*) [16])((int64_t)&arg_190h + iVar30) = auVar7;
    uVar8 = *(undefined *)((int64_t)&arg_40h + iVar30);
    uVar9 = *(undefined *)((int64_t)&arg_40h + iVar30 + 1);
    uVar10 = *(undefined *)((int64_t)&arg_40h + iVar30 + 2);
    uVar11 = *(undefined *)((int64_t)&arg_40h + iVar30 + 3);
    uVar12 = *(undefined *)((int64_t)&arg_40h + iVar30 + 4);
    uVar13 = *(undefined *)((int64_t)&arg_40h + iVar30 + 5);
    uVar14 = *(undefined *)((int64_t)&arg_40h + iVar30 + 6);
    uVar15 = *(undefined *)((int64_t)&arg_40h + iVar30 + 7);
    uVar16 = (&stack0x00000048)[iVar30];
    uVar17 = (&stack0x00000049)[iVar30];
    uVar18 = (&stack0x0000004a)[iVar30];
    uVar19 = (&stack0x0000004b)[iVar30];
    uVar20 = (&stack0x0000004c)[iVar30];
    uVar21 = (&stack0x0000004d)[iVar30];
    uVar22 = (&stack0x0000004e)[iVar30];
    uVar23 = (&stack0x0000004f)[iVar30];
    var_146h._0_6_ = 0;
    var_146h._6_2_ = 0;
    var_13eh._0_4_ = 0;
    *(undefined *)((int64_t)&var_20h + iVar30) = uVar8;
    *(undefined *)((int64_t)&var_20h + iVar30 + 1) = uVar9;
    *(undefined *)((int64_t)&var_20h + iVar30 + 2) = uVar10;
    *(undefined *)((int64_t)&var_20h + iVar30 + 3) = uVar11;
    *(undefined *)((int64_t)&var_20h + iVar30 + 4) = uVar12;
    *(undefined *)((int64_t)&var_20h + iVar30 + 5) = uVar13;
    *(undefined *)((int64_t)&var_20h + iVar30 + 6) = uVar14;
    *(undefined *)((int64_t)&var_20h + iVar30 + 7) = uVar15;
    (&stack0x00000028)[iVar30] = uVar16;
    (&stack0x00000029)[iVar30] = uVar17;
    (&stack0x0000002a)[iVar30] = uVar18;
    (&stack0x0000002b)[iVar30] = uVar19;
    (&stack0x0000002c)[iVar30] = uVar20;
    (&stack0x0000002d)[iVar30] = uVar21;
    (&stack0x0000002e)[iVar30] = uVar22;
    (&stack0x0000002f)[iVar30] = uVar23;
    var_13eh._4_2_ = 0;
    var_12fh._0_4_ = 0;
    var_12fh._4_2_ = 0;
    var_12fh._6_1_ = 0;
    *(undefined *)((int64_t)&arg_30h + iVar30 + 4) = uVar2;
    var_130h = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8945;
    var_178h = func_0x0001802450c0();
    var_15bh._1_4_ = *(undefined4 *)((int64_t)&var_20h + iVar30 + 1);
    unique0x100007fa = *(undefined4 *)((int64_t)&var_20h + iVar30 + 5);
    uStack_152 = *(undefined4 *)(&stack0x00000029 + iVar30);
    uStack_14e = *(undefined4 *)(&stack0x0000002d + iVar30);
    stack0xfffffffffffffec8 = 0;
    var_170h._0_4_ = uVar24;
    var_170h._4_4_ = uVar25;
    uStack_168 = uVar26;
    uStack_164 = uVar27;
    var_15bh._0_1_ = uVar8;
    var_14ah = *(undefined4 *)((int64_t)&arg_30h + iVar30 + 1);
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e897d;
    var_160h = uVar3;
    var_15ch = uVar1;
    iVar28 = func_0x00018026bf70(in_RDX, 0, (int64_t)&var_146h + 6);
    if ((iVar28 == 0) || (CONCAT26(var_13eh._4_2_, CONCAT42((undefined4)var_13eh, var_146h._6_2_)) == 0)) {
code_r0x0001801e8a73:
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a88;
        fcn.180224990(stack0xfffffffffffffec8, 0x1804b74f8, 0x34c);
code_r0x0001801e8a88:
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a9d;
        fcn.180224990(iVar31, 0x1804b74f8, 0x5b8);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89b4;
        *(int64_t *)0x0 =
             fcn.1802248d0(*(int64_t *)(&stack0x00000000 + iVar30), *(int64_t *)((int64_t)&iStackX_8 + iVar30));
        if (*(int64_t *)0x0 == 0) goto code_r0x0001801e8a73;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89d0;
        iVar28 = func_0x00018026bf70(in_RDX, *(int64_t *)0x0, (int64_t)&var_146h + 6);
        if (iVar28 == 0) goto code_r0x0001801e8a73;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89ea;
        iVar28 = func_0x0001801e8b10(&var_178h, (int64_t)&var_12fh + 7, (int64_t)&var_10h + iVar30);
        if (iVar28 == 0) goto code_r0x0001801e8a88;
        iVar5 = *(int64_t *)((int64_t)&var_10h + iVar30);
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a06;
        iVar28 = fcn.18020ecc0(*(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)(&stack0x00000028 + iVar30), 
                               *(int64_t *)((int64_t)&arg_30h + iVar30), *(int64_t *)(&stack0x00000038 + iVar30), 
                               *(int64_t *)((int64_t)&arg_40h + iVar30), *(int64_t *)(&stack0x00000048 + iVar30), 
                               *(int64_t *)((int64_t)&arg_50h + iVar30), *(int64_t *)(&stack0x00000058 + iVar30), 
                               *(int64_t *)(&stack0x00000060 + iVar30), *(int64_t *)(&stack0x00000068 + iVar30), 
                               *(int64_t *)(&stack0x00000080 + iVar30), *(int64_t *)(&stack0x00000088 + iVar30));
        if (iVar28 < 1) goto code_r0x0001801e8a88;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a19;
        iVar29 = fcn.18020e980(*(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)(&stack0x00000028 + iVar30), 
                               *(int64_t *)((int64_t)&arg_30h + iVar30), *(int64_t *)(&stack0x00000038 + iVar30), 
                               *(int64_t *)((int64_t)&arg_40h + iVar30), *(int64_t *)(&stack0x00000048 + iVar30), 
                               *(int64_t *)((int64_t)&arg_50h + iVar30), *(int64_t *)(&stack0x00000058 + iVar30), 
                               *(int64_t *)(&stack0x00000060 + iVar30), *(int64_t *)(&stack0x00000068 + iVar30), 
                               *(int64_t *)(&stack0x00000080 + iVar30), *(int64_t *)(&stack0x00000088 + iVar30), 
                               *(int64_t *)(&stack0x000000d0 + iVar30), *(int64_t *)(&stack0x00000130 + iVar30), 
                               *(int64_t *)(&stack0x00000138 + iVar30));
        if ((iVar29 < 1) ||
           (uVar32 = (int64_t)iVar29 + 0x10 + iVar5 + (int64_t)iVar28,
           *(uint64_t *)((int64_t)&var_18h + iVar30) = uVar32, 0xc5 < uVar32)) goto code_r0x0001801e8a88;
        *(int64_t *)(&stack0x00000000 + iVar30) = (int64_t)&var_18h + iVar30;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a56;
        iVar28 = fcn.1801e86c0(*(int64_t *)((int64_t)&var_10h + iVar30), *(int64_t *)((int64_t)&var_18h + iVar30), 
                               *(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)((int64_t)&arg_30h + iVar30));
        if ((iVar28 == 0) || (uVar32 = *(uint64_t *)((int64_t)&var_18h + iVar30), uVar32 < 0x10))
        goto code_r0x0001801e8a88;
        *(int64_t *)(in_RCX + 0x58) = iVar31;
        *(uint64_t *)(in_RCX + 0x60) = uVar32;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8ab3;
    fcn.180224990(stack0xfffffffffffffec8, 0x1804b74f8, 0x34c);
code_r0x0001801e8acb:
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8ada;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar30));
    return;
}

// ============================================================
// Function: FUN_1801e88d7
// Address: 0x1801e88d7
// Size: 29 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_51h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_41h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_13ah
// WARNING: [rz-ghidra] Detected overlap for variable var_12bh
// WARNING: [rz-ghidra] Detected overlap for variable var_129h
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_138h
// WARNING: [rz-ghidra] Detected overlap for variable arg_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ah
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_15ah
// WARNING: [rz-ghidra] Detected overlap for variable var_128h

void fcn.1801e8810(int64_t arg_30h, int64_t arg_190h, int64_t arg_1a0h, int64_t arg_1b0h, int64_t arg_1f0h,
                  int64_t arg_1f8h)
{
    undefined uVar1;
    undefined uVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined uVar8;
    undefined uVar9;
    undefined uVar10;
    undefined uVar11;
    undefined uVar12;
    undefined uVar13;
    undefined uVar14;
    undefined uVar15;
    undefined uVar16;
    undefined uVar17;
    undefined uVar18;
    undefined uVar19;
    undefined uVar20;
    undefined uVar21;
    undefined uVar22;
    undefined uVar23;
    undefined4 uVar24;
    undefined4 uVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    int32_t iVar28;
    int32_t iVar29;
    int64_t iVar30;
    int64_t iVar31;
    int64_t in_RCX;
    uint64_t uVar32;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_178h;
    int64_t var_170h;
    undefined4 uStack_168;
    undefined4 uStack_164;
    undefined4 var_160h;
    undefined var_15ch;
    int64_t var_15bh;
    undefined4 uStack_152;
    undefined4 uStack_14e;
    undefined4 var_14ah;
    int64_t var_146h;
    int64_t var_13eh;
    undefined var_130h;
    int64_t var_12fh;
    int64_t var_58h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801e8829;
    iVar30 = fcn.18045a350();
    iVar30 = -iVar30;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar30);
    uVar4 = *(uint32_t *)(in_RCX + 0x5d0);
    *(undefined4 *)((int64_t)&arg_50h + iVar30 + 1) = 0;
    *(undefined (*) [16])((int64_t)&arg_40h + iVar30 + 1) = ZEXT816(0);
    *(undefined8 *)((int64_t)&var_10h + iVar30) = 0;
    if ((uVar4 & 0x2000000) == 0) goto code_r0x0001801e8acb;
    *(undefined8 *)((int64_t)&arg_1b0h + iVar30) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8888;
    iVar31 = fcn.180224d60(*(int64_t *)(&stack0x00000000 + iVar30));
    if (iVar31 == 0) goto code_r0x0001801e8acb;
    *(undefined *)((int64_t)&arg_40h + iVar30) = 8;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e88b5;
    iVar28 = fcn.18021b9c0(*(int64_t *)(&stack0x00000000 + iVar30), *(int64_t *)((int64_t)&var_20h + iVar30), 
                           *(int64_t *)(&stack0x00000028 + iVar30), *(int64_t *)((int64_t)&arg_30h + iVar30), 
                           *(int64_t *)(&stack0x00000038 + iVar30));
    if (iVar28 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e88ce;
        fcn.180224990(iVar31, 0x1804b74f8, 0x5aa);
        goto code_r0x0001801e8acb;
    }
    *(undefined8 *)((int64_t)&arg_1f0h + iVar30) = unaff_RBX;
    uVar3 = *(undefined4 *)(in_RCX + 0x438);
    *(undefined8 *)((int64_t)&arg_1f8h + iVar30) = unaff_RDI;
    uVar1 = *(undefined *)(in_RCX + 0x43c);
    auVar6._4_4_ = unaff_XMM6_Db;
    auVar6._0_4_ = unaff_XMM6_Da;
    auVar6._8_4_ = unaff_XMM6_Dc;
    auVar6._12_4_ = unaff_XMM6_Dd;
    *(undefined (*) [16])((int64_t)&arg_1a0h + iVar30) = auVar6;
    uVar24 = *(undefined4 *)(in_RCX + 0x428);
    uVar25 = *(undefined4 *)(in_RCX + 0x42c);
    uVar26 = *(undefined4 *)(in_RCX + 0x430);
    uVar27 = *(undefined4 *)(in_RCX + 0x434);
    *(undefined4 *)((int64_t)&arg_30h + iVar30) = *(undefined4 *)((int64_t)&arg_50h + iVar30);
    uVar2 = *(undefined *)((int64_t)&arg_50h + iVar30 + 4);
    auVar7._4_4_ = unaff_XMM7_Db;
    auVar7._0_4_ = unaff_XMM7_Da;
    auVar7._8_4_ = unaff_XMM7_Dc;
    auVar7._12_4_ = unaff_XMM7_Dd;
    *(undefined (*) [16])((int64_t)&arg_190h + iVar30) = auVar7;
    uVar8 = *(undefined *)((int64_t)&arg_40h + iVar30);
    uVar9 = *(undefined *)((int64_t)&arg_40h + iVar30 + 1);
    uVar10 = *(undefined *)((int64_t)&arg_40h + iVar30 + 2);
    uVar11 = *(undefined *)((int64_t)&arg_40h + iVar30 + 3);
    uVar12 = *(undefined *)((int64_t)&arg_40h + iVar30 + 4);
    uVar13 = *(undefined *)((int64_t)&arg_40h + iVar30 + 5);
    uVar14 = *(undefined *)((int64_t)&arg_40h + iVar30 + 6);
    uVar15 = *(undefined *)((int64_t)&arg_40h + iVar30 + 7);
    uVar16 = (&stack0x00000048)[iVar30];
    uVar17 = (&stack0x00000049)[iVar30];
    uVar18 = (&stack0x0000004a)[iVar30];
    uVar19 = (&stack0x0000004b)[iVar30];
    uVar20 = (&stack0x0000004c)[iVar30];
    uVar21 = (&stack0x0000004d)[iVar30];
    uVar22 = (&stack0x0000004e)[iVar30];
    uVar23 = (&stack0x0000004f)[iVar30];
    var_146h._0_6_ = 0;
    var_146h._6_2_ = 0;
    var_13eh._0_4_ = 0;
    *(undefined *)((int64_t)&var_20h + iVar30) = uVar8;
    *(undefined *)((int64_t)&var_20h + iVar30 + 1) = uVar9;
    *(undefined *)((int64_t)&var_20h + iVar30 + 2) = uVar10;
    *(undefined *)((int64_t)&var_20h + iVar30 + 3) = uVar11;
    *(undefined *)((int64_t)&var_20h + iVar30 + 4) = uVar12;
    *(undefined *)((int64_t)&var_20h + iVar30 + 5) = uVar13;
    *(undefined *)((int64_t)&var_20h + iVar30 + 6) = uVar14;
    *(undefined *)((int64_t)&var_20h + iVar30 + 7) = uVar15;
    (&stack0x00000028)[iVar30] = uVar16;
    (&stack0x00000029)[iVar30] = uVar17;
    (&stack0x0000002a)[iVar30] = uVar18;
    (&stack0x0000002b)[iVar30] = uVar19;
    (&stack0x0000002c)[iVar30] = uVar20;
    (&stack0x0000002d)[iVar30] = uVar21;
    (&stack0x0000002e)[iVar30] = uVar22;
    (&stack0x0000002f)[iVar30] = uVar23;
    var_13eh._4_2_ = 0;
    var_12fh._0_4_ = 0;
    var_12fh._4_2_ = 0;
    var_12fh._6_1_ = 0;
    *(undefined *)((int64_t)&arg_30h + iVar30 + 4) = uVar2;
    var_130h = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8945;
    var_178h = func_0x0001802450c0();
    var_15bh._1_4_ = *(undefined4 *)((int64_t)&var_20h + iVar30 + 1);
    unique0x100007fa = *(undefined4 *)((int64_t)&var_20h + iVar30 + 5);
    uStack_152 = *(undefined4 *)(&stack0x00000029 + iVar30);
    uStack_14e = *(undefined4 *)(&stack0x0000002d + iVar30);
    stack0xfffffffffffffec8 = 0;
    var_170h._0_4_ = uVar24;
    var_170h._4_4_ = uVar25;
    uStack_168 = uVar26;
    uStack_164 = uVar27;
    var_15bh._0_1_ = uVar8;
    var_14ah = *(undefined4 *)((int64_t)&arg_30h + iVar30 + 1);
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e897d;
    var_160h = uVar3;
    var_15ch = uVar1;
    iVar28 = func_0x00018026bf70(in_RDX, 0, (int64_t)&var_146h + 6);
    if ((iVar28 == 0) || (CONCAT26(var_13eh._4_2_, CONCAT42((undefined4)var_13eh, var_146h._6_2_)) == 0)) {
code_r0x0001801e8a73:
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a88;
        fcn.180224990(stack0xfffffffffffffec8, 0x1804b74f8, 0x34c);
code_r0x0001801e8a88:
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a9d;
        fcn.180224990(iVar31, 0x1804b74f8, 0x5b8);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89b4;
        *(int64_t *)0x0 =
             fcn.1802248d0(*(int64_t *)(&stack0x00000000 + iVar30), *(int64_t *)((int64_t)&iStackX_8 + iVar30));
        if (*(int64_t *)0x0 == 0) goto code_r0x0001801e8a73;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89d0;
        iVar28 = func_0x00018026bf70(in_RDX, *(int64_t *)0x0, (int64_t)&var_146h + 6);
        if (iVar28 == 0) goto code_r0x0001801e8a73;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89ea;
        iVar28 = func_0x0001801e8b10(&var_178h, (int64_t)&var_12fh + 7, (int64_t)&var_10h + iVar30);
        if (iVar28 == 0) goto code_r0x0001801e8a88;
        iVar5 = *(int64_t *)((int64_t)&var_10h + iVar30);
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a06;
        iVar28 = fcn.18020ecc0(*(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)(&stack0x00000028 + iVar30), 
                               *(int64_t *)((int64_t)&arg_30h + iVar30), *(int64_t *)(&stack0x00000038 + iVar30), 
                               *(int64_t *)((int64_t)&arg_40h + iVar30), *(int64_t *)(&stack0x00000048 + iVar30), 
                               *(int64_t *)((int64_t)&arg_50h + iVar30), *(int64_t *)(&stack0x00000058 + iVar30), 
                               *(int64_t *)(&stack0x00000060 + iVar30), *(int64_t *)(&stack0x00000068 + iVar30), 
                               *(int64_t *)(&stack0x00000080 + iVar30), *(int64_t *)(&stack0x00000088 + iVar30));
        if (iVar28 < 1) goto code_r0x0001801e8a88;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a19;
        iVar29 = fcn.18020e980(*(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)(&stack0x00000028 + iVar30), 
                               *(int64_t *)((int64_t)&arg_30h + iVar30), *(int64_t *)(&stack0x00000038 + iVar30), 
                               *(int64_t *)((int64_t)&arg_40h + iVar30), *(int64_t *)(&stack0x00000048 + iVar30), 
                               *(int64_t *)((int64_t)&arg_50h + iVar30), *(int64_t *)(&stack0x00000058 + iVar30), 
                               *(int64_t *)(&stack0x00000060 + iVar30), *(int64_t *)(&stack0x00000068 + iVar30), 
                               *(int64_t *)(&stack0x00000080 + iVar30), *(int64_t *)(&stack0x00000088 + iVar30), 
                               *(int64_t *)(&stack0x000000d0 + iVar30), *(int64_t *)(&stack0x00000130 + iVar30), 
                               *(int64_t *)(&stack0x00000138 + iVar30));
        if ((iVar29 < 1) ||
           (uVar32 = (int64_t)iVar29 + 0x10 + iVar5 + (int64_t)iVar28,
           *(uint64_t *)((int64_t)&var_18h + iVar30) = uVar32, 0xc5 < uVar32)) goto code_r0x0001801e8a88;
        *(int64_t *)(&stack0x00000000 + iVar30) = (int64_t)&var_18h + iVar30;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a56;
        iVar28 = fcn.1801e86c0(*(int64_t *)((int64_t)&var_10h + iVar30), *(int64_t *)((int64_t)&var_18h + iVar30), 
                               *(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)((int64_t)&arg_30h + iVar30));
        if ((iVar28 == 0) || (uVar32 = *(uint64_t *)((int64_t)&var_18h + iVar30), uVar32 < 0x10))
        goto code_r0x0001801e8a88;
        *(int64_t *)(in_RCX + 0x58) = iVar31;
        *(uint64_t *)(in_RCX + 0x60) = uVar32;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8ab3;
    fcn.180224990(stack0xfffffffffffffec8, 0x1804b74f8, 0x34c);
code_r0x0001801e8acb:
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8ada;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar30));
    return;
}

// ============================================================
// Function: FUN_1801e88f4
// Address: 0x1801e88f4
// Size: 161 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_51h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_41h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_13ah
// WARNING: [rz-ghidra] Detected overlap for variable var_12bh
// WARNING: [rz-ghidra] Detected overlap for variable var_129h
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_138h
// WARNING: [rz-ghidra] Detected overlap for variable arg_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ah
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_15ah
// WARNING: [rz-ghidra] Detected overlap for variable var_128h

void fcn.1801e8810(int64_t arg_30h, int64_t arg_190h, int64_t arg_1a0h, int64_t arg_1b0h, int64_t arg_1f0h,
                  int64_t arg_1f8h)
{
    undefined uVar1;
    undefined uVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined uVar8;
    undefined uVar9;
    undefined uVar10;
    undefined uVar11;
    undefined uVar12;
    undefined uVar13;
    undefined uVar14;
    undefined uVar15;
    undefined uVar16;
    undefined uVar17;
    undefined uVar18;
    undefined uVar19;
    undefined uVar20;
    undefined uVar21;
    undefined uVar22;
    undefined uVar23;
    undefined4 uVar24;
    undefined4 uVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    int32_t iVar28;
    int32_t iVar29;
    int64_t iVar30;
    int64_t iVar31;
    int64_t in_RCX;
    uint64_t uVar32;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_178h;
    int64_t var_170h;
    undefined4 uStack_168;
    undefined4 uStack_164;
    undefined4 var_160h;
    undefined var_15ch;
    int64_t var_15bh;
    undefined4 uStack_152;
    undefined4 uStack_14e;
    undefined4 var_14ah;
    int64_t var_146h;
    int64_t var_13eh;
    undefined var_130h;
    int64_t var_12fh;
    int64_t var_58h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801e8829;
    iVar30 = fcn.18045a350();
    iVar30 = -iVar30;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar30);
    uVar4 = *(uint32_t *)(in_RCX + 0x5d0);
    *(undefined4 *)((int64_t)&arg_50h + iVar30 + 1) = 0;
    *(undefined (*) [16])((int64_t)&arg_40h + iVar30 + 1) = ZEXT816(0);
    *(undefined8 *)((int64_t)&var_10h + iVar30) = 0;
    if ((uVar4 & 0x2000000) == 0) goto code_r0x0001801e8acb;
    *(undefined8 *)((int64_t)&arg_1b0h + iVar30) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8888;
    iVar31 = fcn.180224d60(*(int64_t *)(&stack0x00000000 + iVar30));
    if (iVar31 == 0) goto code_r0x0001801e8acb;
    *(undefined *)((int64_t)&arg_40h + iVar30) = 8;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e88b5;
    iVar28 = fcn.18021b9c0(*(int64_t *)(&stack0x00000000 + iVar30), *(int64_t *)((int64_t)&var_20h + iVar30), 
                           *(int64_t *)(&stack0x00000028 + iVar30), *(int64_t *)((int64_t)&arg_30h + iVar30), 
                           *(int64_t *)(&stack0x00000038 + iVar30));
    if (iVar28 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e88ce;
        fcn.180224990(iVar31, 0x1804b74f8, 0x5aa);
        goto code_r0x0001801e8acb;
    }
    *(undefined8 *)((int64_t)&arg_1f0h + iVar30) = unaff_RBX;
    uVar3 = *(undefined4 *)(in_RCX + 0x438);
    *(undefined8 *)((int64_t)&arg_1f8h + iVar30) = unaff_RDI;
    uVar1 = *(undefined *)(in_RCX + 0x43c);
    auVar6._4_4_ = unaff_XMM6_Db;
    auVar6._0_4_ = unaff_XMM6_Da;
    auVar6._8_4_ = unaff_XMM6_Dc;
    auVar6._12_4_ = unaff_XMM6_Dd;
    *(undefined (*) [16])((int64_t)&arg_1a0h + iVar30) = auVar6;
    uVar24 = *(undefined4 *)(in_RCX + 0x428);
    uVar25 = *(undefined4 *)(in_RCX + 0x42c);
    uVar26 = *(undefined4 *)(in_RCX + 0x430);
    uVar27 = *(undefined4 *)(in_RCX + 0x434);
    *(undefined4 *)((int64_t)&arg_30h + iVar30) = *(undefined4 *)((int64_t)&arg_50h + iVar30);
    uVar2 = *(undefined *)((int64_t)&arg_50h + iVar30 + 4);
    auVar7._4_4_ = unaff_XMM7_Db;
    auVar7._0_4_ = unaff_XMM7_Da;
    auVar7._8_4_ = unaff_XMM7_Dc;
    auVar7._12_4_ = unaff_XMM7_Dd;
    *(undefined (*) [16])((int64_t)&arg_190h + iVar30) = auVar7;
    uVar8 = *(undefined *)((int64_t)&arg_40h + iVar30);
    uVar9 = *(undefined *)((int64_t)&arg_40h + iVar30 + 1);
    uVar10 = *(undefined *)((int64_t)&arg_40h + iVar30 + 2);
    uVar11 = *(undefined *)((int64_t)&arg_40h + iVar30 + 3);
    uVar12 = *(undefined *)((int64_t)&arg_40h + iVar30 + 4);
    uVar13 = *(undefined *)((int64_t)&arg_40h + iVar30 + 5);
    uVar14 = *(undefined *)((int64_t)&arg_40h + iVar30 + 6);
    uVar15 = *(undefined *)((int64_t)&arg_40h + iVar30 + 7);
    uVar16 = (&stack0x00000048)[iVar30];
    uVar17 = (&stack0x00000049)[iVar30];
    uVar18 = (&stack0x0000004a)[iVar30];
    uVar19 = (&stack0x0000004b)[iVar30];
    uVar20 = (&stack0x0000004c)[iVar30];
    uVar21 = (&stack0x0000004d)[iVar30];
    uVar22 = (&stack0x0000004e)[iVar30];
    uVar23 = (&stack0x0000004f)[iVar30];
    var_146h._0_6_ = 0;
    var_146h._6_2_ = 0;
    var_13eh._0_4_ = 0;
    *(undefined *)((int64_t)&var_20h + iVar30) = uVar8;
    *(undefined *)((int64_t)&var_20h + iVar30 + 1) = uVar9;
    *(undefined *)((int64_t)&var_20h + iVar30 + 2) = uVar10;
    *(undefined *)((int64_t)&var_20h + iVar30 + 3) = uVar11;
    *(undefined *)((int64_t)&var_20h + iVar30 + 4) = uVar12;
    *(undefined *)((int64_t)&var_20h + iVar30 + 5) = uVar13;
    *(undefined *)((int64_t)&var_20h + iVar30 + 6) = uVar14;
    *(undefined *)((int64_t)&var_20h + iVar30 + 7) = uVar15;
    (&stack0x00000028)[iVar30] = uVar16;
    (&stack0x00000029)[iVar30] = uVar17;
    (&stack0x0000002a)[iVar30] = uVar18;
    (&stack0x0000002b)[iVar30] = uVar19;
    (&stack0x0000002c)[iVar30] = uVar20;
    (&stack0x0000002d)[iVar30] = uVar21;
    (&stack0x0000002e)[iVar30] = uVar22;
    (&stack0x0000002f)[iVar30] = uVar23;
    var_13eh._4_2_ = 0;
    var_12fh._0_4_ = 0;
    var_12fh._4_2_ = 0;
    var_12fh._6_1_ = 0;
    *(undefined *)((int64_t)&arg_30h + iVar30 + 4) = uVar2;
    var_130h = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8945;
    var_178h = func_0x0001802450c0();
    var_15bh._1_4_ = *(undefined4 *)((int64_t)&var_20h + iVar30 + 1);
    unique0x100007fa = *(undefined4 *)((int64_t)&var_20h + iVar30 + 5);
    uStack_152 = *(undefined4 *)(&stack0x00000029 + iVar30);
    uStack_14e = *(undefined4 *)(&stack0x0000002d + iVar30);
    stack0xfffffffffffffec8 = 0;
    var_170h._0_4_ = uVar24;
    var_170h._4_4_ = uVar25;
    uStack_168 = uVar26;
    uStack_164 = uVar27;
    var_15bh._0_1_ = uVar8;
    var_14ah = *(undefined4 *)((int64_t)&arg_30h + iVar30 + 1);
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e897d;
    var_160h = uVar3;
    var_15ch = uVar1;
    iVar28 = func_0x00018026bf70(in_RDX, 0, (int64_t)&var_146h + 6);
    if ((iVar28 == 0) || (CONCAT26(var_13eh._4_2_, CONCAT42((undefined4)var_13eh, var_146h._6_2_)) == 0)) {
code_r0x0001801e8a73:
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a88;
        fcn.180224990(stack0xfffffffffffffec8, 0x1804b74f8, 0x34c);
code_r0x0001801e8a88:
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a9d;
        fcn.180224990(iVar31, 0x1804b74f8, 0x5b8);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89b4;
        *(int64_t *)0x0 =
             fcn.1802248d0(*(int64_t *)(&stack0x00000000 + iVar30), *(int64_t *)((int64_t)&iStackX_8 + iVar30));
        if (*(int64_t *)0x0 == 0) goto code_r0x0001801e8a73;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89d0;
        iVar28 = func_0x00018026bf70(in_RDX, *(int64_t *)0x0, (int64_t)&var_146h + 6);
        if (iVar28 == 0) goto code_r0x0001801e8a73;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89ea;
        iVar28 = func_0x0001801e8b10(&var_178h, (int64_t)&var_12fh + 7, (int64_t)&var_10h + iVar30);
        if (iVar28 == 0) goto code_r0x0001801e8a88;
        iVar5 = *(int64_t *)((int64_t)&var_10h + iVar30);
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a06;
        iVar28 = fcn.18020ecc0(*(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)(&stack0x00000028 + iVar30), 
                               *(int64_t *)((int64_t)&arg_30h + iVar30), *(int64_t *)(&stack0x00000038 + iVar30), 
                               *(int64_t *)((int64_t)&arg_40h + iVar30), *(int64_t *)(&stack0x00000048 + iVar30), 
                               *(int64_t *)((int64_t)&arg_50h + iVar30), *(int64_t *)(&stack0x00000058 + iVar30), 
                               *(int64_t *)(&stack0x00000060 + iVar30), *(int64_t *)(&stack0x00000068 + iVar30), 
                               *(int64_t *)(&stack0x00000080 + iVar30), *(int64_t *)(&stack0x00000088 + iVar30));
        if (iVar28 < 1) goto code_r0x0001801e8a88;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a19;
        iVar29 = fcn.18020e980(*(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)(&stack0x00000028 + iVar30), 
                               *(int64_t *)((int64_t)&arg_30h + iVar30), *(int64_t *)(&stack0x00000038 + iVar30), 
                               *(int64_t *)((int64_t)&arg_40h + iVar30), *(int64_t *)(&stack0x00000048 + iVar30), 
                               *(int64_t *)((int64_t)&arg_50h + iVar30), *(int64_t *)(&stack0x00000058 + iVar30), 
                               *(int64_t *)(&stack0x00000060 + iVar30), *(int64_t *)(&stack0x00000068 + iVar30), 
                               *(int64_t *)(&stack0x00000080 + iVar30), *(int64_t *)(&stack0x00000088 + iVar30), 
                               *(int64_t *)(&stack0x000000d0 + iVar30), *(int64_t *)(&stack0x00000130 + iVar30), 
                               *(int64_t *)(&stack0x00000138 + iVar30));
        if ((iVar29 < 1) ||
           (uVar32 = (int64_t)iVar29 + 0x10 + iVar5 + (int64_t)iVar28,
           *(uint64_t *)((int64_t)&var_18h + iVar30) = uVar32, 0xc5 < uVar32)) goto code_r0x0001801e8a88;
        *(int64_t *)(&stack0x00000000 + iVar30) = (int64_t)&var_18h + iVar30;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a56;
        iVar28 = fcn.1801e86c0(*(int64_t *)((int64_t)&var_10h + iVar30), *(int64_t *)((int64_t)&var_18h + iVar30), 
                               *(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)((int64_t)&arg_30h + iVar30));
        if ((iVar28 == 0) || (uVar32 = *(uint64_t *)((int64_t)&var_18h + iVar30), uVar32 < 0x10))
        goto code_r0x0001801e8a88;
        *(int64_t *)(in_RCX + 0x58) = iVar31;
        *(uint64_t *)(in_RCX + 0x60) = uVar32;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8ab3;
    fcn.180224990(stack0xfffffffffffffec8, 0x1804b74f8, 0x34c);
code_r0x0001801e8acb:
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8ada;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar30));
    return;
}

// ============================================================
// Function: FUN_1801e8995
// Address: 0x1801e8995
// Size: 302 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_51h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_41h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_13ah
// WARNING: [rz-ghidra] Detected overlap for variable var_12bh
// WARNING: [rz-ghidra] Detected overlap for variable var_129h
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_138h
// WARNING: [rz-ghidra] Detected overlap for variable arg_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ah
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_15ah
// WARNING: [rz-ghidra] Detected overlap for variable var_128h

void fcn.1801e8810(int64_t arg_30h, int64_t arg_190h, int64_t arg_1a0h, int64_t arg_1b0h, int64_t arg_1f0h,
                  int64_t arg_1f8h)
{
    undefined uVar1;
    undefined uVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined uVar8;
    undefined uVar9;
    undefined uVar10;
    undefined uVar11;
    undefined uVar12;
    undefined uVar13;
    undefined uVar14;
    undefined uVar15;
    undefined uVar16;
    undefined uVar17;
    undefined uVar18;
    undefined uVar19;
    undefined uVar20;
    undefined uVar21;
    undefined uVar22;
    undefined uVar23;
    undefined4 uVar24;
    undefined4 uVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    int32_t iVar28;
    int32_t iVar29;
    int64_t iVar30;
    int64_t iVar31;
    int64_t in_RCX;
    uint64_t uVar32;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_178h;
    int64_t var_170h;
    undefined4 uStack_168;
    undefined4 uStack_164;
    undefined4 var_160h;
    undefined var_15ch;
    int64_t var_15bh;
    undefined4 uStack_152;
    undefined4 uStack_14e;
    undefined4 var_14ah;
    int64_t var_146h;
    int64_t var_13eh;
    undefined var_130h;
    int64_t var_12fh;
    int64_t var_58h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801e8829;
    iVar30 = fcn.18045a350();
    iVar30 = -iVar30;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar30);
    uVar4 = *(uint32_t *)(in_RCX + 0x5d0);
    *(undefined4 *)((int64_t)&arg_50h + iVar30 + 1) = 0;
    *(undefined (*) [16])((int64_t)&arg_40h + iVar30 + 1) = ZEXT816(0);
    *(undefined8 *)((int64_t)&var_10h + iVar30) = 0;
    if ((uVar4 & 0x2000000) == 0) goto code_r0x0001801e8acb;
    *(undefined8 *)((int64_t)&arg_1b0h + iVar30) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8888;
    iVar31 = fcn.180224d60(*(int64_t *)(&stack0x00000000 + iVar30));
    if (iVar31 == 0) goto code_r0x0001801e8acb;
    *(undefined *)((int64_t)&arg_40h + iVar30) = 8;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e88b5;
    iVar28 = fcn.18021b9c0(*(int64_t *)(&stack0x00000000 + iVar30), *(int64_t *)((int64_t)&var_20h + iVar30), 
                           *(int64_t *)(&stack0x00000028 + iVar30), *(int64_t *)((int64_t)&arg_30h + iVar30), 
                           *(int64_t *)(&stack0x00000038 + iVar30));
    if (iVar28 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e88ce;
        fcn.180224990(iVar31, 0x1804b74f8, 0x5aa);
        goto code_r0x0001801e8acb;
    }
    *(undefined8 *)((int64_t)&arg_1f0h + iVar30) = unaff_RBX;
    uVar3 = *(undefined4 *)(in_RCX + 0x438);
    *(undefined8 *)((int64_t)&arg_1f8h + iVar30) = unaff_RDI;
    uVar1 = *(undefined *)(in_RCX + 0x43c);
    auVar6._4_4_ = unaff_XMM6_Db;
    auVar6._0_4_ = unaff_XMM6_Da;
    auVar6._8_4_ = unaff_XMM6_Dc;
    auVar6._12_4_ = unaff_XMM6_Dd;
    *(undefined (*) [16])((int64_t)&arg_1a0h + iVar30) = auVar6;
    uVar24 = *(undefined4 *)(in_RCX + 0x428);
    uVar25 = *(undefined4 *)(in_RCX + 0x42c);
    uVar26 = *(undefined4 *)(in_RCX + 0x430);
    uVar27 = *(undefined4 *)(in_RCX + 0x434);
    *(undefined4 *)((int64_t)&arg_30h + iVar30) = *(undefined4 *)((int64_t)&arg_50h + iVar30);
    uVar2 = *(undefined *)((int64_t)&arg_50h + iVar30 + 4);
    auVar7._4_4_ = unaff_XMM7_Db;
    auVar7._0_4_ = unaff_XMM7_Da;
    auVar7._8_4_ = unaff_XMM7_Dc;
    auVar7._12_4_ = unaff_XMM7_Dd;
    *(undefined (*) [16])((int64_t)&arg_190h + iVar30) = auVar7;
    uVar8 = *(undefined *)((int64_t)&arg_40h + iVar30);
    uVar9 = *(undefined *)((int64_t)&arg_40h + iVar30 + 1);
    uVar10 = *(undefined *)((int64_t)&arg_40h + iVar30 + 2);
    uVar11 = *(undefined *)((int64_t)&arg_40h + iVar30 + 3);
    uVar12 = *(undefined *)((int64_t)&arg_40h + iVar30 + 4);
    uVar13 = *(undefined *)((int64_t)&arg_40h + iVar30 + 5);
    uVar14 = *(undefined *)((int64_t)&arg_40h + iVar30 + 6);
    uVar15 = *(undefined *)((int64_t)&arg_40h + iVar30 + 7);
    uVar16 = (&stack0x00000048)[iVar30];
    uVar17 = (&stack0x00000049)[iVar30];
    uVar18 = (&stack0x0000004a)[iVar30];
    uVar19 = (&stack0x0000004b)[iVar30];
    uVar20 = (&stack0x0000004c)[iVar30];
    uVar21 = (&stack0x0000004d)[iVar30];
    uVar22 = (&stack0x0000004e)[iVar30];
    uVar23 = (&stack0x0000004f)[iVar30];
    var_146h._0_6_ = 0;
    var_146h._6_2_ = 0;
    var_13eh._0_4_ = 0;
    *(undefined *)((int64_t)&var_20h + iVar30) = uVar8;
    *(undefined *)((int64_t)&var_20h + iVar30 + 1) = uVar9;
    *(undefined *)((int64_t)&var_20h + iVar30 + 2) = uVar10;
    *(undefined *)((int64_t)&var_20h + iVar30 + 3) = uVar11;
    *(undefined *)((int64_t)&var_20h + iVar30 + 4) = uVar12;
    *(undefined *)((int64_t)&var_20h + iVar30 + 5) = uVar13;
    *(undefined *)((int64_t)&var_20h + iVar30 + 6) = uVar14;
    *(undefined *)((int64_t)&var_20h + iVar30 + 7) = uVar15;
    (&stack0x00000028)[iVar30] = uVar16;
    (&stack0x00000029)[iVar30] = uVar17;
    (&stack0x0000002a)[iVar30] = uVar18;
    (&stack0x0000002b)[iVar30] = uVar19;
    (&stack0x0000002c)[iVar30] = uVar20;
    (&stack0x0000002d)[iVar30] = uVar21;
    (&stack0x0000002e)[iVar30] = uVar22;
    (&stack0x0000002f)[iVar30] = uVar23;
    var_13eh._4_2_ = 0;
    var_12fh._0_4_ = 0;
    var_12fh._4_2_ = 0;
    var_12fh._6_1_ = 0;
    *(undefined *)((int64_t)&arg_30h + iVar30 + 4) = uVar2;
    var_130h = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8945;
    var_178h = func_0x0001802450c0();
    var_15bh._1_4_ = *(undefined4 *)((int64_t)&var_20h + iVar30 + 1);
    unique0x100007fa = *(undefined4 *)((int64_t)&var_20h + iVar30 + 5);
    uStack_152 = *(undefined4 *)(&stack0x00000029 + iVar30);
    uStack_14e = *(undefined4 *)(&stack0x0000002d + iVar30);
    stack0xfffffffffffffec8 = 0;
    var_170h._0_4_ = uVar24;
    var_170h._4_4_ = uVar25;
    uStack_168 = uVar26;
    uStack_164 = uVar27;
    var_15bh._0_1_ = uVar8;
    var_14ah = *(undefined4 *)((int64_t)&arg_30h + iVar30 + 1);
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e897d;
    var_160h = uVar3;
    var_15ch = uVar1;
    iVar28 = func_0x00018026bf70(in_RDX, 0, (int64_t)&var_146h + 6);
    if ((iVar28 == 0) || (CONCAT26(var_13eh._4_2_, CONCAT42((undefined4)var_13eh, var_146h._6_2_)) == 0)) {
code_r0x0001801e8a73:
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a88;
        fcn.180224990(stack0xfffffffffffffec8, 0x1804b74f8, 0x34c);
code_r0x0001801e8a88:
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a9d;
        fcn.180224990(iVar31, 0x1804b74f8, 0x5b8);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89b4;
        *(int64_t *)0x0 =
             fcn.1802248d0(*(int64_t *)(&stack0x00000000 + iVar30), *(int64_t *)((int64_t)&iStackX_8 + iVar30));
        if (*(int64_t *)0x0 == 0) goto code_r0x0001801e8a73;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89d0;
        iVar28 = func_0x00018026bf70(in_RDX, *(int64_t *)0x0, (int64_t)&var_146h + 6);
        if (iVar28 == 0) goto code_r0x0001801e8a73;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89ea;
        iVar28 = func_0x0001801e8b10(&var_178h, (int64_t)&var_12fh + 7, (int64_t)&var_10h + iVar30);
        if (iVar28 == 0) goto code_r0x0001801e8a88;
        iVar5 = *(int64_t *)((int64_t)&var_10h + iVar30);
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a06;
        iVar28 = fcn.18020ecc0(*(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)(&stack0x00000028 + iVar30), 
                               *(int64_t *)((int64_t)&arg_30h + iVar30), *(int64_t *)(&stack0x00000038 + iVar30), 
                               *(int64_t *)((int64_t)&arg_40h + iVar30), *(int64_t *)(&stack0x00000048 + iVar30), 
                               *(int64_t *)((int64_t)&arg_50h + iVar30), *(int64_t *)(&stack0x00000058 + iVar30), 
                               *(int64_t *)(&stack0x00000060 + iVar30), *(int64_t *)(&stack0x00000068 + iVar30), 
                               *(int64_t *)(&stack0x00000080 + iVar30), *(int64_t *)(&stack0x00000088 + iVar30));
        if (iVar28 < 1) goto code_r0x0001801e8a88;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a19;
        iVar29 = fcn.18020e980(*(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)(&stack0x00000028 + iVar30), 
                               *(int64_t *)((int64_t)&arg_30h + iVar30), *(int64_t *)(&stack0x00000038 + iVar30), 
                               *(int64_t *)((int64_t)&arg_40h + iVar30), *(int64_t *)(&stack0x00000048 + iVar30), 
                               *(int64_t *)((int64_t)&arg_50h + iVar30), *(int64_t *)(&stack0x00000058 + iVar30), 
                               *(int64_t *)(&stack0x00000060 + iVar30), *(int64_t *)(&stack0x00000068 + iVar30), 
                               *(int64_t *)(&stack0x00000080 + iVar30), *(int64_t *)(&stack0x00000088 + iVar30), 
                               *(int64_t *)(&stack0x000000d0 + iVar30), *(int64_t *)(&stack0x00000130 + iVar30), 
                               *(int64_t *)(&stack0x00000138 + iVar30));
        if ((iVar29 < 1) ||
           (uVar32 = (int64_t)iVar29 + 0x10 + iVar5 + (int64_t)iVar28,
           *(uint64_t *)((int64_t)&var_18h + iVar30) = uVar32, 0xc5 < uVar32)) goto code_r0x0001801e8a88;
        *(int64_t *)(&stack0x00000000 + iVar30) = (int64_t)&var_18h + iVar30;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a56;
        iVar28 = fcn.1801e86c0(*(int64_t *)((int64_t)&var_10h + iVar30), *(int64_t *)((int64_t)&var_18h + iVar30), 
                               *(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)((int64_t)&arg_30h + iVar30));
        if ((iVar28 == 0) || (uVar32 = *(uint64_t *)((int64_t)&var_18h + iVar30), uVar32 < 0x10))
        goto code_r0x0001801e8a88;
        *(int64_t *)(in_RCX + 0x58) = iVar31;
        *(uint64_t *)(in_RCX + 0x60) = uVar32;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8ab3;
    fcn.180224990(stack0xfffffffffffffec8, 0x1804b74f8, 0x34c);
code_r0x0001801e8acb:
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8ada;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar30));
    return;
}

// ============================================================
// Function: FUN_1801e8ac3
// Address: 0x1801e8ac3
// Size: 8 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_51h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_41h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_13ah
// WARNING: [rz-ghidra] Detected overlap for variable var_12bh
// WARNING: [rz-ghidra] Detected overlap for variable var_129h
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_138h
// WARNING: [rz-ghidra] Detected overlap for variable arg_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ah
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_15ah
// WARNING: [rz-ghidra] Detected overlap for variable var_128h

void fcn.1801e8810(int64_t arg_30h, int64_t arg_190h, int64_t arg_1a0h, int64_t arg_1b0h, int64_t arg_1f0h,
                  int64_t arg_1f8h)
{
    undefined uVar1;
    undefined uVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined uVar8;
    undefined uVar9;
    undefined uVar10;
    undefined uVar11;
    undefined uVar12;
    undefined uVar13;
    undefined uVar14;
    undefined uVar15;
    undefined uVar16;
    undefined uVar17;
    undefined uVar18;
    undefined uVar19;
    undefined uVar20;
    undefined uVar21;
    undefined uVar22;
    undefined uVar23;
    undefined4 uVar24;
    undefined4 uVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    int32_t iVar28;
    int32_t iVar29;
    int64_t iVar30;
    int64_t iVar31;
    int64_t in_RCX;
    uint64_t uVar32;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_178h;
    int64_t var_170h;
    undefined4 uStack_168;
    undefined4 uStack_164;
    undefined4 var_160h;
    undefined var_15ch;
    int64_t var_15bh;
    undefined4 uStack_152;
    undefined4 uStack_14e;
    undefined4 var_14ah;
    int64_t var_146h;
    int64_t var_13eh;
    undefined var_130h;
    int64_t var_12fh;
    int64_t var_58h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801e8829;
    iVar30 = fcn.18045a350();
    iVar30 = -iVar30;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar30);
    uVar4 = *(uint32_t *)(in_RCX + 0x5d0);
    *(undefined4 *)((int64_t)&arg_50h + iVar30 + 1) = 0;
    *(undefined (*) [16])((int64_t)&arg_40h + iVar30 + 1) = ZEXT816(0);
    *(undefined8 *)((int64_t)&var_10h + iVar30) = 0;
    if ((uVar4 & 0x2000000) == 0) goto code_r0x0001801e8acb;
    *(undefined8 *)((int64_t)&arg_1b0h + iVar30) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8888;
    iVar31 = fcn.180224d60(*(int64_t *)(&stack0x00000000 + iVar30));
    if (iVar31 == 0) goto code_r0x0001801e8acb;
    *(undefined *)((int64_t)&arg_40h + iVar30) = 8;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e88b5;
    iVar28 = fcn.18021b9c0(*(int64_t *)(&stack0x00000000 + iVar30), *(int64_t *)((int64_t)&var_20h + iVar30), 
                           *(int64_t *)(&stack0x00000028 + iVar30), *(int64_t *)((int64_t)&arg_30h + iVar30), 
                           *(int64_t *)(&stack0x00000038 + iVar30));
    if (iVar28 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e88ce;
        fcn.180224990(iVar31, 0x1804b74f8, 0x5aa);
        goto code_r0x0001801e8acb;
    }
    *(undefined8 *)((int64_t)&arg_1f0h + iVar30) = unaff_RBX;
    uVar3 = *(undefined4 *)(in_RCX + 0x438);
    *(undefined8 *)((int64_t)&arg_1f8h + iVar30) = unaff_RDI;
    uVar1 = *(undefined *)(in_RCX + 0x43c);
    auVar6._4_4_ = unaff_XMM6_Db;
    auVar6._0_4_ = unaff_XMM6_Da;
    auVar6._8_4_ = unaff_XMM6_Dc;
    auVar6._12_4_ = unaff_XMM6_Dd;
    *(undefined (*) [16])((int64_t)&arg_1a0h + iVar30) = auVar6;
    uVar24 = *(undefined4 *)(in_RCX + 0x428);
    uVar25 = *(undefined4 *)(in_RCX + 0x42c);
    uVar26 = *(undefined4 *)(in_RCX + 0x430);
    uVar27 = *(undefined4 *)(in_RCX + 0x434);
    *(undefined4 *)((int64_t)&arg_30h + iVar30) = *(undefined4 *)((int64_t)&arg_50h + iVar30);
    uVar2 = *(undefined *)((int64_t)&arg_50h + iVar30 + 4);
    auVar7._4_4_ = unaff_XMM7_Db;
    auVar7._0_4_ = unaff_XMM7_Da;
    auVar7._8_4_ = unaff_XMM7_Dc;
    auVar7._12_4_ = unaff_XMM7_Dd;
    *(undefined (*) [16])((int64_t)&arg_190h + iVar30) = auVar7;
    uVar8 = *(undefined *)((int64_t)&arg_40h + iVar30);
    uVar9 = *(undefined *)((int64_t)&arg_40h + iVar30 + 1);
    uVar10 = *(undefined *)((int64_t)&arg_40h + iVar30 + 2);
    uVar11 = *(undefined *)((int64_t)&arg_40h + iVar30 + 3);
    uVar12 = *(undefined *)((int64_t)&arg_40h + iVar30 + 4);
    uVar13 = *(undefined *)((int64_t)&arg_40h + iVar30 + 5);
    uVar14 = *(undefined *)((int64_t)&arg_40h + iVar30 + 6);
    uVar15 = *(undefined *)((int64_t)&arg_40h + iVar30 + 7);
    uVar16 = (&stack0x00000048)[iVar30];
    uVar17 = (&stack0x00000049)[iVar30];
    uVar18 = (&stack0x0000004a)[iVar30];
    uVar19 = (&stack0x0000004b)[iVar30];
    uVar20 = (&stack0x0000004c)[iVar30];
    uVar21 = (&stack0x0000004d)[iVar30];
    uVar22 = (&stack0x0000004e)[iVar30];
    uVar23 = (&stack0x0000004f)[iVar30];
    var_146h._0_6_ = 0;
    var_146h._6_2_ = 0;
    var_13eh._0_4_ = 0;
    *(undefined *)((int64_t)&var_20h + iVar30) = uVar8;
    *(undefined *)((int64_t)&var_20h + iVar30 + 1) = uVar9;
    *(undefined *)((int64_t)&var_20h + iVar30 + 2) = uVar10;
    *(undefined *)((int64_t)&var_20h + iVar30 + 3) = uVar11;
    *(undefined *)((int64_t)&var_20h + iVar30 + 4) = uVar12;
    *(undefined *)((int64_t)&var_20h + iVar30 + 5) = uVar13;
    *(undefined *)((int64_t)&var_20h + iVar30 + 6) = uVar14;
    *(undefined *)((int64_t)&var_20h + iVar30 + 7) = uVar15;
    (&stack0x00000028)[iVar30] = uVar16;
    (&stack0x00000029)[iVar30] = uVar17;
    (&stack0x0000002a)[iVar30] = uVar18;
    (&stack0x0000002b)[iVar30] = uVar19;
    (&stack0x0000002c)[iVar30] = uVar20;
    (&stack0x0000002d)[iVar30] = uVar21;
    (&stack0x0000002e)[iVar30] = uVar22;
    (&stack0x0000002f)[iVar30] = uVar23;
    var_13eh._4_2_ = 0;
    var_12fh._0_4_ = 0;
    var_12fh._4_2_ = 0;
    var_12fh._6_1_ = 0;
    *(undefined *)((int64_t)&arg_30h + iVar30 + 4) = uVar2;
    var_130h = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8945;
    var_178h = func_0x0001802450c0();
    var_15bh._1_4_ = *(undefined4 *)((int64_t)&var_20h + iVar30 + 1);
    unique0x100007fa = *(undefined4 *)((int64_t)&var_20h + iVar30 + 5);
    uStack_152 = *(undefined4 *)(&stack0x00000029 + iVar30);
    uStack_14e = *(undefined4 *)(&stack0x0000002d + iVar30);
    stack0xfffffffffffffec8 = 0;
    var_170h._0_4_ = uVar24;
    var_170h._4_4_ = uVar25;
    uStack_168 = uVar26;
    uStack_164 = uVar27;
    var_15bh._0_1_ = uVar8;
    var_14ah = *(undefined4 *)((int64_t)&arg_30h + iVar30 + 1);
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e897d;
    var_160h = uVar3;
    var_15ch = uVar1;
    iVar28 = func_0x00018026bf70(in_RDX, 0, (int64_t)&var_146h + 6);
    if ((iVar28 == 0) || (CONCAT26(var_13eh._4_2_, CONCAT42((undefined4)var_13eh, var_146h._6_2_)) == 0)) {
code_r0x0001801e8a73:
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a88;
        fcn.180224990(stack0xfffffffffffffec8, 0x1804b74f8, 0x34c);
code_r0x0001801e8a88:
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a9d;
        fcn.180224990(iVar31, 0x1804b74f8, 0x5b8);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89b4;
        *(int64_t *)0x0 =
             fcn.1802248d0(*(int64_t *)(&stack0x00000000 + iVar30), *(int64_t *)((int64_t)&iStackX_8 + iVar30));
        if (*(int64_t *)0x0 == 0) goto code_r0x0001801e8a73;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89d0;
        iVar28 = func_0x00018026bf70(in_RDX, *(int64_t *)0x0, (int64_t)&var_146h + 6);
        if (iVar28 == 0) goto code_r0x0001801e8a73;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89ea;
        iVar28 = func_0x0001801e8b10(&var_178h, (int64_t)&var_12fh + 7, (int64_t)&var_10h + iVar30);
        if (iVar28 == 0) goto code_r0x0001801e8a88;
        iVar5 = *(int64_t *)((int64_t)&var_10h + iVar30);
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a06;
        iVar28 = fcn.18020ecc0(*(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)(&stack0x00000028 + iVar30), 
                               *(int64_t *)((int64_t)&arg_30h + iVar30), *(int64_t *)(&stack0x00000038 + iVar30), 
                               *(int64_t *)((int64_t)&arg_40h + iVar30), *(int64_t *)(&stack0x00000048 + iVar30), 
                               *(int64_t *)((int64_t)&arg_50h + iVar30), *(int64_t *)(&stack0x00000058 + iVar30), 
                               *(int64_t *)(&stack0x00000060 + iVar30), *(int64_t *)(&stack0x00000068 + iVar30), 
                               *(int64_t *)(&stack0x00000080 + iVar30), *(int64_t *)(&stack0x00000088 + iVar30));
        if (iVar28 < 1) goto code_r0x0001801e8a88;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a19;
        iVar29 = fcn.18020e980(*(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)(&stack0x00000028 + iVar30), 
                               *(int64_t *)((int64_t)&arg_30h + iVar30), *(int64_t *)(&stack0x00000038 + iVar30), 
                               *(int64_t *)((int64_t)&arg_40h + iVar30), *(int64_t *)(&stack0x00000048 + iVar30), 
                               *(int64_t *)((int64_t)&arg_50h + iVar30), *(int64_t *)(&stack0x00000058 + iVar30), 
                               *(int64_t *)(&stack0x00000060 + iVar30), *(int64_t *)(&stack0x00000068 + iVar30), 
                               *(int64_t *)(&stack0x00000080 + iVar30), *(int64_t *)(&stack0x00000088 + iVar30), 
                               *(int64_t *)(&stack0x000000d0 + iVar30), *(int64_t *)(&stack0x00000130 + iVar30), 
                               *(int64_t *)(&stack0x00000138 + iVar30));
        if ((iVar29 < 1) ||
           (uVar32 = (int64_t)iVar29 + 0x10 + iVar5 + (int64_t)iVar28,
           *(uint64_t *)((int64_t)&var_18h + iVar30) = uVar32, 0xc5 < uVar32)) goto code_r0x0001801e8a88;
        *(int64_t *)(&stack0x00000000 + iVar30) = (int64_t)&var_18h + iVar30;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a56;
        iVar28 = fcn.1801e86c0(*(int64_t *)((int64_t)&var_10h + iVar30), *(int64_t *)((int64_t)&var_18h + iVar30), 
                               *(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)((int64_t)&arg_30h + iVar30));
        if ((iVar28 == 0) || (uVar32 = *(uint64_t *)((int64_t)&var_18h + iVar30), uVar32 < 0x10))
        goto code_r0x0001801e8a88;
        *(int64_t *)(in_RCX + 0x58) = iVar31;
        *(uint64_t *)(in_RCX + 0x60) = uVar32;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8ab3;
    fcn.180224990(stack0xfffffffffffffec8, 0x1804b74f8, 0x34c);
code_r0x0001801e8acb:
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8ada;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar30));
    return;
}

// ============================================================
// Function: FUN_1801e8acb
// Address: 0x1801e8acb
// Size: 29 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_51h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_41h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_13ah
// WARNING: [rz-ghidra] Detected overlap for variable var_12bh
// WARNING: [rz-ghidra] Detected overlap for variable var_129h
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_140h
// WARNING: [rz-ghidra] Detected overlap for variable var_138h
// WARNING: [rz-ghidra] Detected overlap for variable arg_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ah
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_15ah
// WARNING: [rz-ghidra] Detected overlap for variable var_128h

void fcn.1801e8810(int64_t arg_30h, int64_t arg_190h, int64_t arg_1a0h, int64_t arg_1b0h, int64_t arg_1f0h,
                  int64_t arg_1f8h)
{
    undefined uVar1;
    undefined uVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined uVar8;
    undefined uVar9;
    undefined uVar10;
    undefined uVar11;
    undefined uVar12;
    undefined uVar13;
    undefined uVar14;
    undefined uVar15;
    undefined uVar16;
    undefined uVar17;
    undefined uVar18;
    undefined uVar19;
    undefined uVar20;
    undefined uVar21;
    undefined uVar22;
    undefined uVar23;
    undefined4 uVar24;
    undefined4 uVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    int32_t iVar28;
    int32_t iVar29;
    int64_t iVar30;
    int64_t iVar31;
    int64_t in_RCX;
    uint64_t uVar32;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_178h;
    int64_t var_170h;
    undefined4 uStack_168;
    undefined4 uStack_164;
    undefined4 var_160h;
    undefined var_15ch;
    int64_t var_15bh;
    undefined4 uStack_152;
    undefined4 uStack_14e;
    undefined4 var_14ah;
    int64_t var_146h;
    int64_t var_13eh;
    undefined var_130h;
    int64_t var_12fh;
    int64_t var_58h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801e8829;
    iVar30 = fcn.18045a350();
    iVar30 = -iVar30;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar30);
    uVar4 = *(uint32_t *)(in_RCX + 0x5d0);
    *(undefined4 *)((int64_t)&arg_50h + iVar30 + 1) = 0;
    *(undefined (*) [16])((int64_t)&arg_40h + iVar30 + 1) = ZEXT816(0);
    *(undefined8 *)((int64_t)&var_10h + iVar30) = 0;
    if ((uVar4 & 0x2000000) == 0) goto code_r0x0001801e8acb;
    *(undefined8 *)((int64_t)&arg_1b0h + iVar30) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8888;
    iVar31 = fcn.180224d60(*(int64_t *)(&stack0x00000000 + iVar30));
    if (iVar31 == 0) goto code_r0x0001801e8acb;
    *(undefined *)((int64_t)&arg_40h + iVar30) = 8;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e88b5;
    iVar28 = fcn.18021b9c0(*(int64_t *)(&stack0x00000000 + iVar30), *(int64_t *)((int64_t)&var_20h + iVar30), 
                           *(int64_t *)(&stack0x00000028 + iVar30), *(int64_t *)((int64_t)&arg_30h + iVar30), 
                           *(int64_t *)(&stack0x00000038 + iVar30));
    if (iVar28 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e88ce;
        fcn.180224990(iVar31, 0x1804b74f8, 0x5aa);
        goto code_r0x0001801e8acb;
    }
    *(undefined8 *)((int64_t)&arg_1f0h + iVar30) = unaff_RBX;
    uVar3 = *(undefined4 *)(in_RCX + 0x438);
    *(undefined8 *)((int64_t)&arg_1f8h + iVar30) = unaff_RDI;
    uVar1 = *(undefined *)(in_RCX + 0x43c);
    auVar6._4_4_ = unaff_XMM6_Db;
    auVar6._0_4_ = unaff_XMM6_Da;
    auVar6._8_4_ = unaff_XMM6_Dc;
    auVar6._12_4_ = unaff_XMM6_Dd;
    *(undefined (*) [16])((int64_t)&arg_1a0h + iVar30) = auVar6;
    uVar24 = *(undefined4 *)(in_RCX + 0x428);
    uVar25 = *(undefined4 *)(in_RCX + 0x42c);
    uVar26 = *(undefined4 *)(in_RCX + 0x430);
    uVar27 = *(undefined4 *)(in_RCX + 0x434);
    *(undefined4 *)((int64_t)&arg_30h + iVar30) = *(undefined4 *)((int64_t)&arg_50h + iVar30);
    uVar2 = *(undefined *)((int64_t)&arg_50h + iVar30 + 4);
    auVar7._4_4_ = unaff_XMM7_Db;
    auVar7._0_4_ = unaff_XMM7_Da;
    auVar7._8_4_ = unaff_XMM7_Dc;
    auVar7._12_4_ = unaff_XMM7_Dd;
    *(undefined (*) [16])((int64_t)&arg_190h + iVar30) = auVar7;
    uVar8 = *(undefined *)((int64_t)&arg_40h + iVar30);
    uVar9 = *(undefined *)((int64_t)&arg_40h + iVar30 + 1);
    uVar10 = *(undefined *)((int64_t)&arg_40h + iVar30 + 2);
    uVar11 = *(undefined *)((int64_t)&arg_40h + iVar30 + 3);
    uVar12 = *(undefined *)((int64_t)&arg_40h + iVar30 + 4);
    uVar13 = *(undefined *)((int64_t)&arg_40h + iVar30 + 5);
    uVar14 = *(undefined *)((int64_t)&arg_40h + iVar30 + 6);
    uVar15 = *(undefined *)((int64_t)&arg_40h + iVar30 + 7);
    uVar16 = (&stack0x00000048)[iVar30];
    uVar17 = (&stack0x00000049)[iVar30];
    uVar18 = (&stack0x0000004a)[iVar30];
    uVar19 = (&stack0x0000004b)[iVar30];
    uVar20 = (&stack0x0000004c)[iVar30];
    uVar21 = (&stack0x0000004d)[iVar30];
    uVar22 = (&stack0x0000004e)[iVar30];
    uVar23 = (&stack0x0000004f)[iVar30];
    var_146h._0_6_ = 0;
    var_146h._6_2_ = 0;
    var_13eh._0_4_ = 0;
    *(undefined *)((int64_t)&var_20h + iVar30) = uVar8;
    *(undefined *)((int64_t)&var_20h + iVar30 + 1) = uVar9;
    *(undefined *)((int64_t)&var_20h + iVar30 + 2) = uVar10;
    *(undefined *)((int64_t)&var_20h + iVar30 + 3) = uVar11;
    *(undefined *)((int64_t)&var_20h + iVar30 + 4) = uVar12;
    *(undefined *)((int64_t)&var_20h + iVar30 + 5) = uVar13;
    *(undefined *)((int64_t)&var_20h + iVar30 + 6) = uVar14;
    *(undefined *)((int64_t)&var_20h + iVar30 + 7) = uVar15;
    (&stack0x00000028)[iVar30] = uVar16;
    (&stack0x00000029)[iVar30] = uVar17;
    (&stack0x0000002a)[iVar30] = uVar18;
    (&stack0x0000002b)[iVar30] = uVar19;
    (&stack0x0000002c)[iVar30] = uVar20;
    (&stack0x0000002d)[iVar30] = uVar21;
    (&stack0x0000002e)[iVar30] = uVar22;
    (&stack0x0000002f)[iVar30] = uVar23;
    var_13eh._4_2_ = 0;
    var_12fh._0_4_ = 0;
    var_12fh._4_2_ = 0;
    var_12fh._6_1_ = 0;
    *(undefined *)((int64_t)&arg_30h + iVar30 + 4) = uVar2;
    var_130h = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8945;
    var_178h = func_0x0001802450c0();
    var_15bh._1_4_ = *(undefined4 *)((int64_t)&var_20h + iVar30 + 1);
    unique0x100007fa = *(undefined4 *)((int64_t)&var_20h + iVar30 + 5);
    uStack_152 = *(undefined4 *)(&stack0x00000029 + iVar30);
    uStack_14e = *(undefined4 *)(&stack0x0000002d + iVar30);
    stack0xfffffffffffffec8 = 0;
    var_170h._0_4_ = uVar24;
    var_170h._4_4_ = uVar25;
    uStack_168 = uVar26;
    uStack_164 = uVar27;
    var_15bh._0_1_ = uVar8;
    var_14ah = *(undefined4 *)((int64_t)&arg_30h + iVar30 + 1);
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e897d;
    var_160h = uVar3;
    var_15ch = uVar1;
    iVar28 = func_0x00018026bf70(in_RDX, 0, (int64_t)&var_146h + 6);
    if ((iVar28 == 0) || (CONCAT26(var_13eh._4_2_, CONCAT42((undefined4)var_13eh, var_146h._6_2_)) == 0)) {
code_r0x0001801e8a73:
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a88;
        fcn.180224990(stack0xfffffffffffffec8, 0x1804b74f8, 0x34c);
code_r0x0001801e8a88:
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a9d;
        fcn.180224990(iVar31, 0x1804b74f8, 0x5b8);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89b4;
        *(int64_t *)0x0 =
             fcn.1802248d0(*(int64_t *)(&stack0x00000000 + iVar30), *(int64_t *)((int64_t)&iStackX_8 + iVar30));
        if (*(int64_t *)0x0 == 0) goto code_r0x0001801e8a73;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89d0;
        iVar28 = func_0x00018026bf70(in_RDX, *(int64_t *)0x0, (int64_t)&var_146h + 6);
        if (iVar28 == 0) goto code_r0x0001801e8a73;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e89ea;
        iVar28 = func_0x0001801e8b10(&var_178h, (int64_t)&var_12fh + 7, (int64_t)&var_10h + iVar30);
        if (iVar28 == 0) goto code_r0x0001801e8a88;
        iVar5 = *(int64_t *)((int64_t)&var_10h + iVar30);
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a06;
        iVar28 = fcn.18020ecc0(*(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)(&stack0x00000028 + iVar30), 
                               *(int64_t *)((int64_t)&arg_30h + iVar30), *(int64_t *)(&stack0x00000038 + iVar30), 
                               *(int64_t *)((int64_t)&arg_40h + iVar30), *(int64_t *)(&stack0x00000048 + iVar30), 
                               *(int64_t *)((int64_t)&arg_50h + iVar30), *(int64_t *)(&stack0x00000058 + iVar30), 
                               *(int64_t *)(&stack0x00000060 + iVar30), *(int64_t *)(&stack0x00000068 + iVar30), 
                               *(int64_t *)(&stack0x00000080 + iVar30), *(int64_t *)(&stack0x00000088 + iVar30));
        if (iVar28 < 1) goto code_r0x0001801e8a88;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a19;
        iVar29 = fcn.18020e980(*(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)(&stack0x00000028 + iVar30), 
                               *(int64_t *)((int64_t)&arg_30h + iVar30), *(int64_t *)(&stack0x00000038 + iVar30), 
                               *(int64_t *)((int64_t)&arg_40h + iVar30), *(int64_t *)(&stack0x00000048 + iVar30), 
                               *(int64_t *)((int64_t)&arg_50h + iVar30), *(int64_t *)(&stack0x00000058 + iVar30), 
                               *(int64_t *)(&stack0x00000060 + iVar30), *(int64_t *)(&stack0x00000068 + iVar30), 
                               *(int64_t *)(&stack0x00000080 + iVar30), *(int64_t *)(&stack0x00000088 + iVar30), 
                               *(int64_t *)(&stack0x000000d0 + iVar30), *(int64_t *)(&stack0x00000130 + iVar30), 
                               *(int64_t *)(&stack0x00000138 + iVar30));
        if ((iVar29 < 1) ||
           (uVar32 = (int64_t)iVar29 + 0x10 + iVar5 + (int64_t)iVar28,
           *(uint64_t *)((int64_t)&var_18h + iVar30) = uVar32, 0xc5 < uVar32)) goto code_r0x0001801e8a88;
        *(int64_t *)(&stack0x00000000 + iVar30) = (int64_t)&var_18h + iVar30;
        *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8a56;
        iVar28 = fcn.1801e86c0(*(int64_t *)((int64_t)&var_10h + iVar30), *(int64_t *)((int64_t)&var_18h + iVar30), 
                               *(int64_t *)((int64_t)&var_20h + iVar30), *(int64_t *)((int64_t)&arg_30h + iVar30));
        if ((iVar28 == 0) || (uVar32 = *(uint64_t *)((int64_t)&var_18h + iVar30), uVar32 < 0x10))
        goto code_r0x0001801e8a88;
        *(int64_t *)(in_RCX + 0x58) = iVar31;
        *(uint64_t *)(in_RCX + 0x60) = uVar32;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8ab3;
    fcn.180224990(stack0xfffffffffffffec8, 0x1804b74f8, 0x34c);
code_r0x0001801e8acb:
    *(undefined8 *)((int64_t)&uStack_28 + iVar30) = 0x1801e8ada;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar30));
    return;
}

// ============================================================
// Function: FUN_1801e8af0
// Address: 0x1801e8af0
// Size: 25 bytes
// ============================================================
void fcn.1801e8af0(int64_t arg_70h, int64_t arg_78h, int64_t arg_88h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = *in_RCX;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x1801dd6ea;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(code **)(iVar4 + 0x18) == (code *)0x0) {
        *(undefined8 *)(&stack0x00000048 + iVar2 + iVar3) = 0x1802450ca;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(uint64_t *)((int64_t)&arg_88h + iVar4 + iVar2 + iVar3) =
             *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0x00000050 + iVar4 + iVar2 + iVar3);
        *(undefined8 *)(&stack0x00000048 + iVar4 + iVar2 + iVar3) = 0x1802450e7;
        (*(code *)0x69a176)((int64_t)&arg_78h + iVar4 + iVar2 + iVar3);
        *(undefined8 *)(&stack0x00000048 + iVar4 + iVar2 + iVar3) = 0x1802450f7;
        (*(code *)0x69a186)((int64_t)&arg_78h + iVar4 + iVar2 + iVar3, (int64_t)&arg_70h + iVar4 + iVar2 + iVar3);
        uVar1 = *(uint64_t *)((int64_t)&arg_88h + iVar4 + iVar2 + iVar3);
        *(undefined8 *)(&stack0x00000048 + iVar4 + iVar2 + iVar3) = 0x180245117;
        fcn.180459870(uVar1 ^ (uint64_t)(&stack0x00000050 + iVar4 + iVar2 + iVar3));
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001801dd707. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(iVar4 + 0x18))(*(undefined8 *)(iVar4 + 0x20));
    return;
}

// ============================================================
// Function: FUN_1801e8b10
// Address: 0x1801e8b10
// Size: 387 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.1801e8b10(int64_t arg_28h, int64_t arg_38h, int64_t arg_48h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    undefined uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    uint64_t *in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e8b2a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined (*) [16])((int64_t)&var_18h + iVar6) = ZEXT816(0);
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = 0;
    *(undefined (*) [16])((int64_t)&arg_28h + iVar6) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_38h + iVar6) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801e8b54;
    iVar7 = func_0x000180226610();
    if (((in_RDX == 0) || (iVar7 == 0)) || ((*(char *)(in_RCX + 0x48) != '\0' && (*(char *)(in_RCX + 0x48) != '\x01'))))
    goto code_r0x0001801e8c71;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801e8b86;
    iVar5 = func_0x000180244300((int64_t)&var_18h + iVar6, iVar7);
    if (iVar5 != 0) {
        uVar1 = *(undefined *)(in_RCX + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801e8ba2;
        iVar5 = func_0x000180244670((int64_t)&var_18h + iVar6, uVar1, 1);
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801e8bbd;
            iVar5 = func_0x0001802445f0((int64_t)&var_18h + iVar6, in_RCX, 8);
            if (iVar5 != 0) {
                if (*(char *)(in_RCX + 0x48) == '\0') {
code_r0x0001801e8c05:
                    uVar2 = *(undefined8 *)(in_RCX + 0x38);
                    uVar3 = *(undefined8 *)(in_RCX + 0x40);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801e8c1d;
                    iVar5 = func_0x000180244bf0((int64_t)&var_18h + iVar6, uVar3, uVar2, 1);
                    if (iVar5 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801e8c2e;
                        iVar5 = func_0x0001802442e0((int64_t)&var_18h + iVar6, in_R8);
                        if ((iVar5 != 0) && (*in_R8 < 0xaa)) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801e8c45;
                            iVar5 = func_0x000180244200((int64_t)&var_18h + iVar6);
                            if (iVar5 != 0) {
                                uVar4 = *in_R8;
                                uVar2 = *(undefined8 *)(iVar7 + 8);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801e8c58;
                                func_0x000180498030(in_RDX, uVar2, uVar4);
                                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801e8c60;
                                func_0x000180226310(iVar7);
                                return 1;
                            }
                        }
                    }
                } else {
                    uVar1 = *(undefined *)(in_RCX + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801e8be4;
                    iVar5 = func_0x000180244bf0((int64_t)&var_18h + iVar6, in_RCX + 9, uVar1, 1);
                    if (iVar5 != 0) {
                        uVar1 = *(undefined *)(in_RCX + 0x1d);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801e8c01;
                        iVar5 = func_0x000180244bf0((int64_t)&var_18h + iVar6, in_RCX + 0x1e, uVar1, 1);
                        if (iVar5 != 0) goto code_r0x0001801e8c05;
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801e8c71;
    func_0x000180243fb0((int64_t)&var_18h + iVar6);
code_r0x0001801e8c71:
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801e8c79;
    func_0x000180226310(iVar7);
    return 0;
}

// ============================================================
// Function: FUN_1801e8ca0
// Address: 0x1801e8ca0
// Size: 37 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel

void fcn.1801e8ca0(void)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801e8caa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801e8cc0;
    fcn.1801ea030(*(int64_t *)(&stack0x00000058 + iVar1), *(int64_t *)(&stack0x00000060 + iVar1), 
                  *(int64_t *)(&stack0x00000068 + iVar1), *(int64_t *)(&stack0x00000070 + iVar1), 
                  *(int64_t *)(&stack0x00000078 + iVar1), *(int64_t *)(&stack0x00000080 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1801e8cd0
// Address: 0x1801e8cd0
// Size: 215 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801e8cd0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int32_t *piVar4;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e8ce0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
    do {
        iVar1 = *(int64_t *)(in_RCX + 0x60);
        if (iVar1 == 0) {
            return;
        }
        *(undefined8 *)(in_RCX + 0x60) = *(undefined8 *)(iVar1 + 0x18);
        if (*(int64_t *)(in_RCX + 0x68) == iVar1) {
            *(undefined8 *)(in_RCX + 0x68) = *(undefined8 *)(iVar1 + 0x20);
        }
        if (*(int64_t *)(iVar1 + 0x20) != 0) {
            *(undefined8 *)(*(int64_t *)(iVar1 + 0x20) + 0x18) = *(undefined8 *)(iVar1 + 0x18);
        }
        if (*(int64_t *)(iVar1 + 0x18) != 0) {
            *(undefined8 *)(*(int64_t *)(iVar1 + 0x18) + 0x20) = *(undefined8 *)(iVar1 + 0x20);
        }
        *(int64_t *)(in_RCX + 0x70) = *(int64_t *)(in_RCX + 0x70) + -1;
        *(undefined (*) [16])(iVar1 + 0x18) = ZEXT816(0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e8d48;
        piVar3 = (int32_t *)func_0x0001801e3990(iVar1);
        if (piVar3 == (int32_t *)0x0) {
            return;
        }
        piVar4 = piVar3;
        if (*piVar3 != 0) {
            if (-1 < (char)*piVar3) {
                return;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e8d67;
            piVar4 = (int32_t *)func_0x0001801bda50(piVar3);
            if (piVar4 == (int32_t *)0x0) {
                return;
            }
        }
        if (*(int32_t **)(piVar4 + 0x10) == piVar3) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e8d7d;
            func_0x0001801e3930(iVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e8d85;
            func_0x000180193500(piVar3);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e8d92;
            func_0x000180193500();
        }
    } while( true );
}

