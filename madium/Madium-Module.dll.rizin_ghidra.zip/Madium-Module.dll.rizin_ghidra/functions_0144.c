// Chunk 144 - 50 functions

// ============================================================
// Function: FUN_1801e8db0
// Address: 0x1801e8db0
// Size: 54 bytes
// ============================================================
void fcn.1801e8db0(int64_t arg1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801e8dc0;
        iVar1 = fcn.18045a350();
        iVar1 = -iVar1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801e8dcb;
        fcn.1801e9680(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801e8de0;
        fcn.180224990(arg1, 0x1804b74f8, 0x80);
    }
    return;
}

// ============================================================
// Function: FUN_1801e8df0
// Address: 0x1801e8df0
// Size: 25 bytes
// ============================================================
undefined8 fcn.1801e8df0(int64_t *param_1)
{
    fcn.18045a350();
    return *(undefined8 *)(*param_1 + 0x10);
}

// ============================================================
// Function: FUN_1801e8e10
// Address: 0x1801e8e10
// Size: 25 bytes
// ============================================================
int64_t fcn.1801e8e10(int64_t *param_1)
{
    fcn.18045a350();
    return *param_1 + 0x28;
}

// ============================================================
// Function: FUN_1801e8e50
// Address: 0x1801e8e50
// Size: 25 bytes
// ============================================================
void fcn.1801e8e50(int64_t arg_70h, int64_t arg_78h, int64_t arg_88h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = *in_RCX;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x1801dd6ea;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(code **)(iVar4 + 0x18) == (code *)0x0) {
        *(undefined8 *)(&stack0x00000048 + iVar2 + iVar3) = 0x1802450ca;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(uint64_t *)((int64_t)&arg_88h + iVar4 + iVar2 + iVar3) =
             *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0x00000050 + iVar4 + iVar2 + iVar3);
        *(undefined8 *)(&stack0x00000048 + iVar4 + iVar2 + iVar3) = 0x1802450e7;
        (*(code *)0x69a176)((int64_t)&arg_78h + iVar4 + iVar2 + iVar3);
        *(undefined8 *)(&stack0x00000048 + iVar4 + iVar2 + iVar3) = 0x1802450f7;
        (*(code *)0x69a186)((int64_t)&arg_78h + iVar4 + iVar2 + iVar3, (int64_t)&arg_70h + iVar4 + iVar2 + iVar3);
        uVar1 = *(uint64_t *)((int64_t)&arg_88h + iVar4 + iVar2 + iVar3);
        *(undefined8 *)(&stack0x00000048 + iVar4 + iVar2 + iVar3) = 0x180245117;
        fcn.180459870(uVar1 ^ (uint64_t)(&stack0x00000050 + iVar4 + iVar2 + iVar3));
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001801dd707. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(iVar4 + 0x18))(*(undefined8 *)(iVar4 + 0x20));
    return;
}

// ============================================================
// Function: FUN_1801e8ea0
// Address: 0x1801e8ea0
// Size: 186 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.1801e8ea0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    uint32_t uVar4;
    undefined8 *in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e8eb0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e8ecd;
    puVar3 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    if (puVar3 != (undefined8 *)0x0) {
        *puVar3 = *in_RCX;
        puVar3[5] = in_RCX[3];
        uVar4 = (*(int32_t *)(in_RCX + 4) * 2 ^ *(uint32_t *)((int64_t)puVar3 + 0x9c)) & 2 ^
                *(uint32_t *)((int64_t)puVar3 + 0x9c);
        *(uint32_t *)((int64_t)puVar3 + 0x9c) = uVar4;
        *(uint32_t *)((int64_t)puVar3 + 0x9c) = (*(int32_t *)((int64_t)in_RCX + 0x24) << 2 ^ uVar4) & 4 ^ uVar4;
        puVar3[3] = in_RCX[1];
        puVar3[4] = in_RCX[2];
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e8f26;
        iVar1 = fcn.1801e9dd0(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000038 + iVar2));
        if (iVar1 != 0) {
            return puVar3;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e8f3f;
        fcn.180224990(puVar3, 0x1804b74f8, 0x73);
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_1801e8f60
// Address: 0x1801e8f60
// Size: 177 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801e8f60(int64_t arg_28h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e8f70;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((*(uint8_t *)(in_RCX + 0x9c) & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e8f8b;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e8fa3;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e8fb9;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
        uVar1 = *(undefined8 *)(in_RCX + 0x90);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e8fc5;
        func_0x000180254600(uVar1);
        if ((*(uint32_t *)(in_RCX + 0x9c) & 1) == 0) {
            *(uint32_t *)(in_RCX + 0x9c) = *(uint32_t *)(in_RCX + 0x9c) | 1;
        }
        if (in_RDX != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e8fe5;
            func_0x0001801e4930(in_RDX);
        }
        for (iVar2 = *(int64_t *)(in_RCX + 0x48); iVar2 != 0; iVar2 = *(int64_t *)(iVar2 + 8)) {
            if (iVar2 != in_RDX) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e8ffd;
                func_0x0001801e4930(iVar2);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e9020
// Address: 0x1801e9020
// Size: 40 bytes
// ============================================================
void fcn.1801e9020(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_68h, int64_t arg_70h,
                  int64_t arg_78h, int64_t arg_88h, int64_t arg_a0h, int64_t arg_b8h)
{
    undefined4 uVar1;
    char *pcVar2;
    char *pcVar3;
    undefined *puVar4;
    uint32_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    int64_t in_RCX;
    int64_t iVar12;
    uint32_t uVar13;
    undefined8 uVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar15;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar16;
    undefined8 uStackX_10;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e902c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801e9037;
    func_0x0001802203d0();
    iVar12 = *(int64_t *)(in_RCX + 0x90);
    uVar14 = *(undefined8 *)((int64_t)&var_18h + iVar6);
    if (iVar12 != 0) {
        *(undefined8 *)((int64_t)&var_18h + iVar6) = unaff_R14;
        *(undefined8 *)((int64_t)&uStackX_10 + iVar6) = 0x180254325;
        iVar7 = fcn.18045a350();
        iVar7 = -iVar7;
        if (*(int32_t *)(iVar12 + 0x344) != *(int32_t *)(iVar12 + 0x340)) {
            *(undefined8 *)((int64_t)&arg_50h + iVar7 + iVar6) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar6) = 0x180254347;
            iVar8 = func_0x000180221280();
            if (iVar8 != 0) {
                *(undefined8 *)((int64_t)&arg_68h + iVar7 + iVar6) = uVar14;
                uVar13 = *(uint32_t *)(iVar12 + 0x344);
                if (uVar13 != *(uint32_t *)(iVar12 + 0x340)) {
                    *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar6) = unaff_R15;
                    *(undefined8 *)((int64_t)&arg_70h + iVar7 + iVar6) = unaff_RBP;
                    *(undefined8 *)((int64_t)&arg_78h + iVar7 + iVar6) = unaff_RSI;
                    *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar6) = unaff_R12;
                    *(undefined8 *)((int64_t)&arg_40h + iVar7 + iVar6) = unaff_R13;
                    do {
                        uVar13 = uVar13 + 1 & 0x8000000f;
                        if ((int32_t)uVar13 < 0) {
                            uVar13 = (uVar13 - 1 | 0xfffffff0) + 1;
                        }
                        iVar16 = (int64_t)(int32_t)uVar13;
                        if ((*(uint8_t *)(iVar12 + iVar16 * 4) & 2) == 0) {
                            uVar5 = *(int32_t *)(iVar8 + 0x340) + 1U & 0x8000000f;
                            if ((int32_t)uVar5 < 0) {
                                uVar5 = (uVar5 - 1 | 0xfffffff0) + 1;
                            }
                            *(uint32_t *)(iVar8 + 0x340) = uVar5;
                            if (uVar5 == *(uint32_t *)(iVar8 + 0x344)) {
                                uVar11 = *(uint32_t *)(iVar8 + 0x344) + 1 & 0x8000000f;
                                if ((int32_t)uVar11 < 0) {
                                    uVar11 = (uVar11 - 1 | 0xfffffff0) + 1;
                                }
                                *(uint32_t *)(iVar8 + 0x344) = uVar11;
                            }
                            iVar15 = (int64_t)(int32_t)uVar5;
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar6) = 0x1802543f2;
                            func_0x000180220e60(iVar8, iVar15, 0);
                            *(undefined4 *)(iVar8 + iVar15 * 4) = *(undefined4 *)(iVar12 + iVar16 * 4);
                            *(undefined4 *)(iVar8 + 0x80 + iVar15 * 4) = *(undefined4 *)(iVar12 + 0x80 + iVar16 * 4);
                            uVar14 = *(undefined8 *)(iVar8 + 0x200 + iVar15 * 8);
                            pcVar2 = *(char **)(iVar12 + 0x2c0 + iVar16 * 8);
                            uVar1 = *(undefined4 *)(iVar12 + 0x280 + iVar16 * 4);
                            pcVar3 = *(char **)(iVar12 + 0x200 + iVar16 * 8);
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar6) = 0x18025443a;
                            fcn.180224990(uVar14, 0x1804bf6a0, 0x39);
                            if ((pcVar3 == (char *)0x0) || (*pcVar3 == '\0')) {
                                *(undefined8 *)(iVar8 + 0x200 + iVar15 * 8) = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar6) = 0x180254456;
                                func_0x000180498cd0(pcVar3);
                                *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar6) = 0x180254464;
                                iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar6));
                                *(int64_t *)(iVar8 + 0x200 + iVar15 * 8) = iVar9;
                                if (iVar9 != 0) {
                                    *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar6) = 0x18025447c;
                                    func_0x0001804990c0(iVar9, pcVar3);
                                }
                            }
                            *(undefined4 *)(iVar8 + 0x280 + iVar15 * 4) = uVar1;
                            uVar14 = *(undefined8 *)(iVar8 + 0x2c0 + iVar15 * 8);
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar6) = 0x1802544a1;
                            fcn.180224990(uVar14, 0x1804bf6a0);
                            if ((pcVar2 == (char *)0x0) || (*pcVar2 == '\0')) {
                                *(undefined8 *)(iVar8 + 0x2c0 + iVar15 * 8) = 0;
                            } else {
                                *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar6) = 0x1802544b4;
                                func_0x000180498cd0(pcVar2);
                                *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar6) = 0x1802544c2;
                                iVar9 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                                                      *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar6));
                                *(int64_t *)(iVar8 + 0x2c0 + iVar15 * 8) = iVar9;
                                if (iVar9 != 0) {
                                    *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar6) = 0x1802544da;
                                    func_0x0001804990c0(iVar9, pcVar2);
                                }
                            }
                            if ((*(int64_t *)(iVar12 + 0xc0 + iVar16 * 8) == 0) ||
                               (iVar9 = *(int64_t *)(iVar12 + 0x140 + iVar16 * 8), iVar9 == 0)) {
                                iVar16 = iVar8 + iVar15 * 4;
                                iVar9 = iVar8 + iVar15 * 8;
                                if ((*(uint8_t *)(iVar16 + 0x1c0) & 1) == 0) {
                                    *(undefined8 *)(iVar9 + 0xc0) = 0;
                                    *(undefined8 *)(iVar8 + 0x140 + iVar15 * 8) = 0;
                                    *(undefined4 *)(iVar16 + 0x1c0) = 0;
                                } else {
                                    puVar4 = *(undefined **)(iVar9 + 0xc0);
                                    if (puVar4 != (undefined *)0x0) {
                                        *puVar4 = 0;
                                        *(undefined4 *)(iVar16 + 0x1c0) = 1;
                                    }
                                }
                            } else {
                                *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar6) = 0x18025451a;
                                iVar10 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                                                       *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar6));
                                if (iVar10 != 0) {
                                    uVar14 = *(undefined8 *)(iVar12 + 0xc0 + iVar16 * 8);
                                    *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar6) = 0x180254539;
                                    func_0x000180498030(iVar10, uVar14);
                                    uVar5 = *(uint32_t *)(iVar12 + 0x1c0 + iVar16 * 4);
                                    if ((*(uint8_t *)(iVar8 + 0x1c0 + iVar15 * 4) & 1) != 0) {
                                        uVar14 = *(undefined8 *)(iVar8 + 0xc0 + iVar15 * 8);
                                        *(undefined8 *)((int64_t)&uStackX_10 + iVar7 + iVar6) = 0x180254569;
                                        fcn.180224990(uVar14, 0x1804bf6a0);
                                    }
                                    *(int64_t *)(iVar8 + 0xc0 + iVar15 * 8) = iVar10;
                                    *(int64_t *)(iVar8 + 0x140 + iVar15 * 8) = iVar9;
                                    *(uint32_t *)(iVar8 + 0x1c0 + iVar15 * 4) = uVar5 | 1;
                                }
                            }
                        }
                    } while (uVar13 != *(uint32_t *)(iVar12 + 0x340));
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e9050
// Address: 0x1801e9050
// Size: 204 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801e9050(int64_t arg_38h, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t *in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e9060;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX[6] == in_RDX) {
        return 1;
    }
    *(undefined (*) [16])((int64_t)&var_18h + iVar3) = ZEXT816(0);
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e908d;
        iVar2 = fcn.18021a190(in_RDX, (int64_t)&var_18h + iVar3);
        if (iVar2 != 0) {
            if ((*(int32_t *)((int64_t)&var_18h + iVar3) == 1) && (*(int32_t *)((int64_t)&var_20h + iVar3) < 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e90a4;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e90bc;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e90ce;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
                return 0;
            }
            goto code_r0x0001801e90e3;
        }
    }
    *(undefined4 *)((int64_t)&var_18h + iVar3) = 0;
code_r0x0001801e90e3:
    iVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e90f4;
    fcn.1801dd230(iVar1 + 0x28, (int64_t)&var_18h + iVar3);
    iVar1 = in_RCX[8];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e9100;
    fcn.1801de1c0(iVar1, in_RDX);
    in_RCX[6] = in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e910c;
    fcn.1801ea650(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
    return 1;
}

// ============================================================
// Function: FUN_1801e9120
// Address: 0x1801e9120
// Size: 159 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801e9120(int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e9130;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX[7] == in_RDX) {
        return 1;
    }
    *(undefined (*) [16])((int64_t)&var_18h + iVar4) = ZEXT816(0);
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e915d;
        iVar3 = fcn.18021a1d0(in_RDX, (int64_t)&var_18h + iVar4);
        if (iVar3 != 0) {
            if ((*(int32_t *)((int64_t)&var_18h + iVar4) == 1) && (*(int32_t *)((int64_t)&var_20h + iVar4) < 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e9174;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e918c;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e919e;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                return 0;
            }
            goto code_r0x0001801e91b3;
        }
    }
    *(undefined4 *)((int64_t)&var_18h + iVar4) = 0;
code_r0x0001801e91b3:
    iVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e91c9;
    fcn.1801dd270(iVar1 + 0x28, (int64_t)&var_18h + iVar4);
    for (iVar1 = in_RCX[9]; iVar1 != 0; iVar1 = *(int64_t *)(iVar1 + 8)) {
        uVar2 = *(undefined8 *)(iVar1 + 0x3d0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e91ef;
        fcn.1801fb900(uVar2, in_RDX);
    }
    in_RCX[7] = in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e9204;
    fcn.1801ea650(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    return 1;
}

// ============================================================
// Function: FUN_1801e91bf
// Address: 0x1801e91bf
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801e9120(int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e9130;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX[7] == in_RDX) {
        return 1;
    }
    *(undefined (*) [16])((int64_t)&var_18h + iVar4) = ZEXT816(0);
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e915d;
        iVar3 = fcn.18021a1d0(in_RDX, (int64_t)&var_18h + iVar4);
        if (iVar3 != 0) {
            if ((*(int32_t *)((int64_t)&var_18h + iVar4) == 1) && (*(int32_t *)((int64_t)&var_20h + iVar4) < 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e9174;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e918c;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e919e;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                return 0;
            }
            goto code_r0x0001801e91b3;
        }
    }
    *(undefined4 *)((int64_t)&var_18h + iVar4) = 0;
code_r0x0001801e91b3:
    iVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e91c9;
    fcn.1801dd270(iVar1 + 0x28, (int64_t)&var_18h + iVar4);
    for (iVar1 = in_RCX[9]; iVar1 != 0; iVar1 = *(int64_t *)(iVar1 + 8)) {
        uVar2 = *(undefined8 *)(iVar1 + 0x3d0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e91ef;
        fcn.1801fb900(uVar2, in_RDX);
    }
    in_RCX[7] = in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e9204;
    fcn.1801ea650(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    return 1;
}

// ============================================================
// Function: FUN_1801e9209
// Address: 0x1801e9209
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801e9120(int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e9130;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX[7] == in_RDX) {
        return 1;
    }
    *(undefined (*) [16])((int64_t)&var_18h + iVar4) = ZEXT816(0);
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e915d;
        iVar3 = fcn.18021a1d0(in_RDX, (int64_t)&var_18h + iVar4);
        if (iVar3 != 0) {
            if ((*(int32_t *)((int64_t)&var_18h + iVar4) == 1) && (*(int32_t *)((int64_t)&var_20h + iVar4) < 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e9174;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e918c;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e919e;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                return 0;
            }
            goto code_r0x0001801e91b3;
        }
    }
    *(undefined4 *)((int64_t)&var_18h + iVar4) = 0;
code_r0x0001801e91b3:
    iVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e91c9;
    fcn.1801dd270(iVar1 + 0x28, (int64_t)&var_18h + iVar4);
    for (iVar1 = in_RCX[9]; iVar1 != 0; iVar1 = *(int64_t *)(iVar1 + 8)) {
        uVar2 = *(undefined8 *)(iVar1 + 0x3d0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e91ef;
        fcn.1801fb900(uVar2, in_RDX);
    }
    in_RCX[7] = in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e9204;
    fcn.1801ea650(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    return 1;
}

// ============================================================
// Function: FUN_1801e9220
// Address: 0x1801e9220
// Size: 90 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_12h
// WARNING: [rz-ghidra] Detected overlap for variable var_11h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.1801e9220(int64_t arg_60h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    uint64_t uVar8;
    uint64_t *in_RDX;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    int64_t var_8h;
    undefined8 var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e922e;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&iStackX_20 + iVar7 + -8) =
         *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar7);
    uVar1 = *(uint8_t *)((int64_t)in_RCX + 0x9c);
    *(undefined2 *)((int64_t)in_RDX + 9) = 0;
    *in_RDX = 0xffffffffffffffff;
    *(uint8_t *)(in_RDX + 1) = ~uVar1 & 1;
    if ((*(uint8_t *)(*in_RCX + 0xa0) & 1) == 0) {
        uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x9c);
        *(undefined8 *)((int64_t)&arg_60h + iVar7) = unaff_RDI;
        if (((uVar2 & 1) == 0) && ((uVar2 & 0x18) != 0)) {
            iVar3 = in_RCX[8];
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e9298;
            iVar6 = func_0x0001801de120(iVar3);
            if ((iVar6 == -2) && ((*(uint8_t *)((int64_t)in_RCX + 0x9c) & 1) == 0)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e92ab;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7 + -8), *(int64_t *)((int64_t)&var_10h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e92c3;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7 + -8), *(int64_t *)((int64_t)&var_10h + iVar7), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)(&stack0x00000038 + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e92d9;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                iVar3 = in_RCX[0x12];
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e92e5;
                func_0x000180254600(iVar3);
                if ((*(uint32_t *)((int64_t)in_RCX + 0x9c) & 1) == 0) {
                    *(uint32_t *)((int64_t)in_RCX + 0x9c) = *(uint32_t *)((int64_t)in_RCX + 0x9c) | 1;
                }
                for (iVar3 = in_RCX[9]; iVar3 != 0; iVar3 = *(int64_t *)(iVar3 + 8)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e9309;
                    func_0x0001801e4930(iVar3);
                }
            }
        }
        for (iVar3 = in_RCX[9]; iVar3 != 0; iVar3 = *(int64_t *)(iVar3 + 8)) {
            *(undefined (*) [16])((int64_t)&var_10h + iVar7 + -8) = ZEXT816(0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e9338;
            func_0x0001801e5050(iVar3, (int64_t)&var_10h + iVar7 + -8, in_R8 & 0xffffffff);
            if ((*(char *)(in_RDX + 1) == '\0') && (*(char *)((int64_t)&var_10h + iVar7) == '\0')) {
                uVar5 = 0;
            } else {
                uVar5 = 1;
            }
            *(undefined *)(in_RDX + 1) = uVar5;
            if ((*(char *)((int64_t)in_RDX + 9) == '\0') && (*(char *)((int64_t)&var_10h + iVar7 + 1) == '\0')) {
                uVar5 = 0;
            } else {
                uVar5 = 1;
            }
            *(undefined *)((int64_t)in_RDX + 9) = uVar5;
            if ((*(char *)((int64_t)in_RDX + 10) == '\0') && (*(char *)((int64_t)&var_10h + iVar7 + 2) == '\0')) {
                uVar5 = 0;
            } else {
                uVar5 = 1;
            }
            uVar8 = *in_RDX;
            uVar4 = *(uint64_t *)((int64_t)&var_10h + iVar7 + -8);
            *(undefined *)((int64_t)in_RDX + 10) = uVar5;
            if (uVar4 <= uVar8) {
                uVar8 = *(uint64_t *)((int64_t)&var_10h + iVar7 + -8);
            }
            *in_RDX = uVar8;
        }
    }
    uVar8 = *(uint64_t *)((int64_t)&iStackX_20 + iVar7 + -8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e93a6;
    fcn.180459870(uVar8 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar7));
    return;
}

// ============================================================
// Function: FUN_1801e927a
// Address: 0x1801e927a
// Size: 287 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_12h
// WARNING: [rz-ghidra] Detected overlap for variable var_11h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.1801e9220(int64_t arg_60h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    uint64_t uVar8;
    uint64_t *in_RDX;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    int64_t var_8h;
    undefined8 var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e922e;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&iStackX_20 + iVar7 + -8) =
         *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar7);
    uVar1 = *(uint8_t *)((int64_t)in_RCX + 0x9c);
    *(undefined2 *)((int64_t)in_RDX + 9) = 0;
    *in_RDX = 0xffffffffffffffff;
    *(uint8_t *)(in_RDX + 1) = ~uVar1 & 1;
    if ((*(uint8_t *)(*in_RCX + 0xa0) & 1) == 0) {
        uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x9c);
        *(undefined8 *)((int64_t)&arg_60h + iVar7) = unaff_RDI;
        if (((uVar2 & 1) == 0) && ((uVar2 & 0x18) != 0)) {
            iVar3 = in_RCX[8];
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e9298;
            iVar6 = func_0x0001801de120(iVar3);
            if ((iVar6 == -2) && ((*(uint8_t *)((int64_t)in_RCX + 0x9c) & 1) == 0)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e92ab;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7 + -8), *(int64_t *)((int64_t)&var_10h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e92c3;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7 + -8), *(int64_t *)((int64_t)&var_10h + iVar7), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)(&stack0x00000038 + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e92d9;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                iVar3 = in_RCX[0x12];
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e92e5;
                func_0x000180254600(iVar3);
                if ((*(uint32_t *)((int64_t)in_RCX + 0x9c) & 1) == 0) {
                    *(uint32_t *)((int64_t)in_RCX + 0x9c) = *(uint32_t *)((int64_t)in_RCX + 0x9c) | 1;
                }
                for (iVar3 = in_RCX[9]; iVar3 != 0; iVar3 = *(int64_t *)(iVar3 + 8)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e9309;
                    func_0x0001801e4930(iVar3);
                }
            }
        }
        for (iVar3 = in_RCX[9]; iVar3 != 0; iVar3 = *(int64_t *)(iVar3 + 8)) {
            *(undefined (*) [16])((int64_t)&var_10h + iVar7 + -8) = ZEXT816(0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e9338;
            func_0x0001801e5050(iVar3, (int64_t)&var_10h + iVar7 + -8, in_R8 & 0xffffffff);
            if ((*(char *)(in_RDX + 1) == '\0') && (*(char *)((int64_t)&var_10h + iVar7) == '\0')) {
                uVar5 = 0;
            } else {
                uVar5 = 1;
            }
            *(undefined *)(in_RDX + 1) = uVar5;
            if ((*(char *)((int64_t)in_RDX + 9) == '\0') && (*(char *)((int64_t)&var_10h + iVar7 + 1) == '\0')) {
                uVar5 = 0;
            } else {
                uVar5 = 1;
            }
            *(undefined *)((int64_t)in_RDX + 9) = uVar5;
            if ((*(char *)((int64_t)in_RDX + 10) == '\0') && (*(char *)((int64_t)&var_10h + iVar7 + 2) == '\0')) {
                uVar5 = 0;
            } else {
                uVar5 = 1;
            }
            uVar8 = *in_RDX;
            uVar4 = *(uint64_t *)((int64_t)&var_10h + iVar7 + -8);
            *(undefined *)((int64_t)in_RDX + 10) = uVar5;
            if (uVar4 <= uVar8) {
                uVar8 = *(uint64_t *)((int64_t)&var_10h + iVar7 + -8);
            }
            *in_RDX = uVar8;
        }
    }
    uVar8 = *(uint64_t *)((int64_t)&iStackX_20 + iVar7 + -8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e93a6;
    fcn.180459870(uVar8 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar7));
    return;
}

// ============================================================
// Function: FUN_1801e9399
// Address: 0x1801e9399
// Size: 21 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_12h
// WARNING: [rz-ghidra] Detected overlap for variable var_11h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.1801e9220(int64_t arg_60h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    uint64_t uVar8;
    uint64_t *in_RDX;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    int64_t var_8h;
    undefined8 var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e922e;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&iStackX_20 + iVar7 + -8) =
         *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar7);
    uVar1 = *(uint8_t *)((int64_t)in_RCX + 0x9c);
    *(undefined2 *)((int64_t)in_RDX + 9) = 0;
    *in_RDX = 0xffffffffffffffff;
    *(uint8_t *)(in_RDX + 1) = ~uVar1 & 1;
    if ((*(uint8_t *)(*in_RCX + 0xa0) & 1) == 0) {
        uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x9c);
        *(undefined8 *)((int64_t)&arg_60h + iVar7) = unaff_RDI;
        if (((uVar2 & 1) == 0) && ((uVar2 & 0x18) != 0)) {
            iVar3 = in_RCX[8];
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e9298;
            iVar6 = func_0x0001801de120(iVar3);
            if ((iVar6 == -2) && ((*(uint8_t *)((int64_t)in_RCX + 0x9c) & 1) == 0)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e92ab;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar7 + -8), *(int64_t *)((int64_t)&var_10h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e92c3;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar7 + -8), *(int64_t *)((int64_t)&var_10h + iVar7), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)(&stack0x00000038 + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e92d9;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                iVar3 = in_RCX[0x12];
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e92e5;
                func_0x000180254600(iVar3);
                if ((*(uint32_t *)((int64_t)in_RCX + 0x9c) & 1) == 0) {
                    *(uint32_t *)((int64_t)in_RCX + 0x9c) = *(uint32_t *)((int64_t)in_RCX + 0x9c) | 1;
                }
                for (iVar3 = in_RCX[9]; iVar3 != 0; iVar3 = *(int64_t *)(iVar3 + 8)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e9309;
                    func_0x0001801e4930(iVar3);
                }
            }
        }
        for (iVar3 = in_RCX[9]; iVar3 != 0; iVar3 = *(int64_t *)(iVar3 + 8)) {
            *(undefined (*) [16])((int64_t)&var_10h + iVar7 + -8) = ZEXT816(0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e9338;
            func_0x0001801e5050(iVar3, (int64_t)&var_10h + iVar7 + -8, in_R8 & 0xffffffff);
            if ((*(char *)(in_RDX + 1) == '\0') && (*(char *)((int64_t)&var_10h + iVar7) == '\0')) {
                uVar5 = 0;
            } else {
                uVar5 = 1;
            }
            *(undefined *)(in_RDX + 1) = uVar5;
            if ((*(char *)((int64_t)in_RDX + 9) == '\0') && (*(char *)((int64_t)&var_10h + iVar7 + 1) == '\0')) {
                uVar5 = 0;
            } else {
                uVar5 = 1;
            }
            *(undefined *)((int64_t)in_RDX + 9) = uVar5;
            if ((*(char *)((int64_t)in_RDX + 10) == '\0') && (*(char *)((int64_t)&var_10h + iVar7 + 2) == '\0')) {
                uVar5 = 0;
            } else {
                uVar5 = 1;
            }
            uVar8 = *in_RDX;
            uVar4 = *(uint64_t *)((int64_t)&var_10h + iVar7 + -8);
            *(undefined *)((int64_t)in_RDX + 10) = uVar5;
            if (uVar4 <= uVar8) {
                uVar8 = *(uint64_t *)((int64_t)&var_10h + iVar7 + -8);
            }
            *in_RDX = uVar8;
        }
    }
    uVar8 = *(uint64_t *)((int64_t)&iStackX_20 + iVar7 + -8);
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1801e93a6;
    fcn.180459870(uVar8 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar7));
    return;
}

// ============================================================
// Function: FUN_1801e93b0
// Address: 0x1801e93b0
// Size: 319 bytes
// ============================================================
undefined4 fcn.1801e93b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RSI;
    undefined4 uVar4;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e93bc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_EDX == 0) && ((*(uint32_t *)((int64_t)in_RCX + 0x9c) & 0x100) == 0)) {
        return 0;
    }
    iVar1 = in_RCX[6];
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RDI;
    *(undefined (*) [16])((int64_t)&var_18h + iVar3) = ZEXT816(0);
    if (iVar1 == 0) {
code_r0x0001801e9445:
        *(undefined4 *)((int64_t)&var_18h + iVar3) = 0;
code_r0x0001801e9449:
        iVar1 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e945a;
        fcn.1801dd230(iVar1 + 0x28, (int64_t)&var_18h + iVar3);
        uVar4 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e9401;
        iVar2 = fcn.18021a190(iVar1, (int64_t)&var_18h + iVar3);
        if (iVar2 == 0) goto code_r0x0001801e9445;
        if ((*(int32_t *)((int64_t)&var_18h + iVar3) != 1) || (-1 < *(int32_t *)((int64_t)&var_20h + iVar3)))
        goto code_r0x0001801e9449;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e9417;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e942f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e9441;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        uVar4 = 0;
    }
    iVar1 = in_RCX[7];
    *(undefined (*) [16])((int64_t)&var_18h + iVar3) = ZEXT816(0);
    if (iVar1 == 0) {
code_r0x0001801e94bc:
        *(undefined4 *)((int64_t)&var_18h + iVar3) = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e947a;
        iVar2 = fcn.18021a1d0(iVar1, (int64_t)&var_18h + iVar3);
        if (iVar2 == 0) goto code_r0x0001801e94bc;
        if ((*(int32_t *)((int64_t)&var_18h + iVar3) == 1) && (*(int32_t *)((int64_t)&var_20h + iVar3) < 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e9490;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e94a8;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e94ba;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            uVar4 = 0;
            goto code_r0x0001801e94d3;
        }
    }
    iVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e94d1;
    fcn.1801dd270(iVar1 + 0x28, (int64_t)&var_18h + iVar3);
code_r0x0001801e94d3:
    *(uint32_t *)((int64_t)in_RCX + 0x9c) = *(uint32_t *)((int64_t)in_RCX + 0x9c) & 0xfffffeff;
    return uVar4;
}

// ============================================================
// Function: FUN_1801e94f0
// Address: 0x1801e94f0
// Size: 36 bytes
// ============================================================
undefined8 fcn.1801e94f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    undefined8 *in_RCX;
    uint8_t *in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint8_t *puVar6;
    uint8_t *puVar7;
    undefined8 unaff_RDI;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t in_R8;
    undefined8 unaff_R14;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e94fc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RDX == (uint8_t *)0x0) || (in_RCX == (undefined8 *)0x0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    in_RCX[8] = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_R14;
    if (in_R8 - 1U < 0x7fffffffffffffff) {
        uVar1 = *in_RDX;
        *(uint8_t *)(in_RCX + 9) = uVar1;
        if ((uVar1 < 2) && (7 < in_R8 - 1U)) {
            iVar8 = in_R8 + -9;
            puVar6 = in_RDX + 9;
            *in_RCX = *(undefined8 *)(in_RDX + 1);
            if (uVar1 != 0) {
                if (iVar8 == 0) goto code_r0x0001801e965e;
                uVar1 = *puVar6;
                uVar4 = (uint64_t)uVar1;
                in_RDX = in_RDX + 10;
                if (in_R8 - 10U < uVar4) goto code_r0x0001801e965e;
                *(uint8_t *)(in_RCX + 1) = uVar1;
                puVar7 = in_RDX + uVar4;
                iVar8 = (in_R8 - 10U) - uVar4;
                if (0x14 < uVar1) goto code_r0x0001801e965e;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e95b5;
                func_0x000180498030((int64_t)in_RCX + 9, in_RDX, uVar1);
                if (iVar8 == 0) goto code_r0x0001801e965e;
                uVar1 = *puVar7;
                uVar4 = (uint64_t)uVar1;
                uVar9 = iVar8 - 1;
                if (uVar9 < uVar4) goto code_r0x0001801e965e;
                iVar8 = uVar9 - uVar4;
                *(uint8_t *)((int64_t)in_RCX + 0x1d) = uVar1;
                puVar6 = puVar7 + 1 + uVar4;
                if (0x14 < uVar1) goto code_r0x0001801e965e;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e95eb;
                func_0x000180498030((int64_t)in_RCX + 0x1e, puVar7 + 1, uVar1);
            }
            if (iVar8 != 0) {
                uVar4 = (uint64_t)*puVar6;
                if ((uVar4 <= iVar8 - 1U) && (in_RCX[7] = uVar4, uVar4 != 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e961c;
                    iVar5 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    in_RCX[8] = iVar5;
                    if ((iVar5 != 0) && ((uint64_t)in_RCX[7] <= uVar4)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e963a;
                        func_0x000180498030(iVar5, puVar6 + 1);
                        if (iVar8 - 1U == uVar4) {
                            return 1;
                        }
                    }
                }
            }
        }
    }
code_r0x0001801e965e:
    uVar2 = in_RCX[8];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e9674;
    fcn.180224990(uVar2, 0x1804b74f8, 0x34c);
    return 0;
}

// ============================================================
// Function: FUN_1801e9514
// Address: 0x1801e9514
// Size: 330 bytes
// ============================================================
undefined8 fcn.1801e94f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    undefined8 *in_RCX;
    uint8_t *in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint8_t *puVar6;
    uint8_t *puVar7;
    undefined8 unaff_RDI;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t in_R8;
    undefined8 unaff_R14;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e94fc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RDX == (uint8_t *)0x0) || (in_RCX == (undefined8 *)0x0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    in_RCX[8] = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_R14;
    if (in_R8 - 1U < 0x7fffffffffffffff) {
        uVar1 = *in_RDX;
        *(uint8_t *)(in_RCX + 9) = uVar1;
        if ((uVar1 < 2) && (7 < in_R8 - 1U)) {
            iVar8 = in_R8 + -9;
            puVar6 = in_RDX + 9;
            *in_RCX = *(undefined8 *)(in_RDX + 1);
            if (uVar1 != 0) {
                if (iVar8 == 0) goto code_r0x0001801e965e;
                uVar1 = *puVar6;
                uVar4 = (uint64_t)uVar1;
                in_RDX = in_RDX + 10;
                if (in_R8 - 10U < uVar4) goto code_r0x0001801e965e;
                *(uint8_t *)(in_RCX + 1) = uVar1;
                puVar7 = in_RDX + uVar4;
                iVar8 = (in_R8 - 10U) - uVar4;
                if (0x14 < uVar1) goto code_r0x0001801e965e;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e95b5;
                func_0x000180498030((int64_t)in_RCX + 9, in_RDX, uVar1);
                if (iVar8 == 0) goto code_r0x0001801e965e;
                uVar1 = *puVar7;
                uVar4 = (uint64_t)uVar1;
                uVar9 = iVar8 - 1;
                if (uVar9 < uVar4) goto code_r0x0001801e965e;
                iVar8 = uVar9 - uVar4;
                *(uint8_t *)((int64_t)in_RCX + 0x1d) = uVar1;
                puVar6 = puVar7 + 1 + uVar4;
                if (0x14 < uVar1) goto code_r0x0001801e965e;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e95eb;
                func_0x000180498030((int64_t)in_RCX + 0x1e, puVar7 + 1, uVar1);
            }
            if (iVar8 != 0) {
                uVar4 = (uint64_t)*puVar6;
                if ((uVar4 <= iVar8 - 1U) && (in_RCX[7] = uVar4, uVar4 != 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e961c;
                    iVar5 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    in_RCX[8] = iVar5;
                    if ((iVar5 != 0) && ((uint64_t)in_RCX[7] <= uVar4)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e963a;
                        func_0x000180498030(iVar5, puVar6 + 1);
                        if (iVar8 - 1U == uVar4) {
                            return 1;
                        }
                    }
                }
            }
        }
    }
code_r0x0001801e965e:
    uVar2 = in_RCX[8];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e9674;
    fcn.180224990(uVar2, 0x1804b74f8, 0x34c);
    return 0;
}

// ============================================================
// Function: FUN_1801e965e
// Address: 0x1801e965e
// Size: 26 bytes
// ============================================================
undefined8 fcn.1801e94f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    undefined8 *in_RCX;
    uint8_t *in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint8_t *puVar6;
    uint8_t *puVar7;
    undefined8 unaff_RDI;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t in_R8;
    undefined8 unaff_R14;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e94fc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RDX == (uint8_t *)0x0) || (in_RCX == (undefined8 *)0x0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    in_RCX[8] = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_R14;
    if (in_R8 - 1U < 0x7fffffffffffffff) {
        uVar1 = *in_RDX;
        *(uint8_t *)(in_RCX + 9) = uVar1;
        if ((uVar1 < 2) && (7 < in_R8 - 1U)) {
            iVar8 = in_R8 + -9;
            puVar6 = in_RDX + 9;
            *in_RCX = *(undefined8 *)(in_RDX + 1);
            if (uVar1 != 0) {
                if (iVar8 == 0) goto code_r0x0001801e965e;
                uVar1 = *puVar6;
                uVar4 = (uint64_t)uVar1;
                in_RDX = in_RDX + 10;
                if (in_R8 - 10U < uVar4) goto code_r0x0001801e965e;
                *(uint8_t *)(in_RCX + 1) = uVar1;
                puVar7 = in_RDX + uVar4;
                iVar8 = (in_R8 - 10U) - uVar4;
                if (0x14 < uVar1) goto code_r0x0001801e965e;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e95b5;
                func_0x000180498030((int64_t)in_RCX + 9, in_RDX, uVar1);
                if (iVar8 == 0) goto code_r0x0001801e965e;
                uVar1 = *puVar7;
                uVar4 = (uint64_t)uVar1;
                uVar9 = iVar8 - 1;
                if (uVar9 < uVar4) goto code_r0x0001801e965e;
                iVar8 = uVar9 - uVar4;
                *(uint8_t *)((int64_t)in_RCX + 0x1d) = uVar1;
                puVar6 = puVar7 + 1 + uVar4;
                if (0x14 < uVar1) goto code_r0x0001801e965e;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e95eb;
                func_0x000180498030((int64_t)in_RCX + 0x1e, puVar7 + 1, uVar1);
            }
            if (iVar8 != 0) {
                uVar4 = (uint64_t)*puVar6;
                if ((uVar4 <= iVar8 - 1U) && (in_RCX[7] = uVar4, uVar4 != 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e961c;
                    iVar5 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    in_RCX[8] = iVar5;
                    if ((iVar5 != 0) && ((uint64_t)in_RCX[7] <= uVar4)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e963a;
                        func_0x000180498030(iVar5, puVar6 + 1);
                        if (iVar8 - 1U == uVar4) {
                            return 1;
                        }
                    }
                }
            }
        }
    }
code_r0x0001801e965e:
    uVar2 = in_RCX[8];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e9674;
    fcn.180224990(uVar2, 0x1804b74f8, 0x34c);
    return 0;
}

// ============================================================
// Function: FUN_1801e9678
// Address: 0x1801e9678
// Size: 8 bytes
// ============================================================
undefined8 fcn.1801e94f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    undefined8 *in_RCX;
    uint8_t *in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint8_t *puVar6;
    uint8_t *puVar7;
    undefined8 unaff_RDI;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t in_R8;
    undefined8 unaff_R14;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e94fc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RDX == (uint8_t *)0x0) || (in_RCX == (undefined8 *)0x0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RSI;
    in_RCX[8] = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_R14;
    if (in_R8 - 1U < 0x7fffffffffffffff) {
        uVar1 = *in_RDX;
        *(uint8_t *)(in_RCX + 9) = uVar1;
        if ((uVar1 < 2) && (7 < in_R8 - 1U)) {
            iVar8 = in_R8 + -9;
            puVar6 = in_RDX + 9;
            *in_RCX = *(undefined8 *)(in_RDX + 1);
            if (uVar1 != 0) {
                if (iVar8 == 0) goto code_r0x0001801e965e;
                uVar1 = *puVar6;
                uVar4 = (uint64_t)uVar1;
                in_RDX = in_RDX + 10;
                if (in_R8 - 10U < uVar4) goto code_r0x0001801e965e;
                *(uint8_t *)(in_RCX + 1) = uVar1;
                puVar7 = in_RDX + uVar4;
                iVar8 = (in_R8 - 10U) - uVar4;
                if (0x14 < uVar1) goto code_r0x0001801e965e;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e95b5;
                func_0x000180498030((int64_t)in_RCX + 9, in_RDX, uVar1);
                if (iVar8 == 0) goto code_r0x0001801e965e;
                uVar1 = *puVar7;
                uVar4 = (uint64_t)uVar1;
                uVar9 = iVar8 - 1;
                if (uVar9 < uVar4) goto code_r0x0001801e965e;
                iVar8 = uVar9 - uVar4;
                *(uint8_t *)((int64_t)in_RCX + 0x1d) = uVar1;
                puVar6 = puVar7 + 1 + uVar4;
                if (0x14 < uVar1) goto code_r0x0001801e965e;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e95eb;
                func_0x000180498030((int64_t)in_RCX + 0x1e, puVar7 + 1, uVar1);
            }
            if (iVar8 != 0) {
                uVar4 = (uint64_t)*puVar6;
                if ((uVar4 <= iVar8 - 1U) && (in_RCX[7] = uVar4, uVar4 != 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e961c;
                    iVar5 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    in_RCX[8] = iVar5;
                    if ((iVar5 != 0) && ((uint64_t)in_RCX[7] <= uVar4)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e963a;
                        func_0x000180498030(iVar5, puVar6 + 1);
                        if (iVar8 - 1U == uVar4) {
                            return 1;
                        }
                    }
                }
            }
        }
    }
code_r0x0001801e965e:
    uVar2 = in_RCX[8];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e9674;
    fcn.180224990(uVar2, 0x1804b74f8, 0x34c);
    return 0;
}

// ============================================================
// Function: FUN_1801e9680
// Address: 0x1801e9680
// Size: 231 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801e9680(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t *in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e9690;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar1 = in_RCX[8];
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e969f;
    func_0x0001801de000(iVar1);
    iVar1 = in_RCX[0x11];
    in_RCX[8] = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e96b1;
    func_0x0001802014f0(iVar1);
    iVar1 = in_RCX[0x10];
    in_RCX[0x11] = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e96c4;
    func_0x000180200e40(iVar1);
    iVar1 = in_RCX[0x12];
    in_RCX[0x10] = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e96d7;
    func_0x000180220c50(iVar1);
    in_RCX[0x12] = 0;
    if ((*(uint8_t *)((int64_t)in_RCX + 0x9c) & 0x20) != 0) {
        iVar1 = *in_RCX;
        if (*(int64_t **)(iVar1 + 0x88) == in_RCX) {
            *(int64_t *)(iVar1 + 0x88) = in_RCX[1];
        }
        if (*(int64_t **)(iVar1 + 0x90) == in_RCX) {
            *(int64_t *)(iVar1 + 0x90) = in_RCX[2];
        }
        if (in_RCX[2] != 0) {
            *(int64_t *)(in_RCX[2] + 8) = in_RCX[1];
        }
        if (in_RCX[1] != 0) {
            *(int64_t *)(in_RCX[1] + 0x10) = in_RCX[2];
        }
        *(int64_t *)(iVar1 + 0x98) = *(int64_t *)(iVar1 + 0x98) + -1;
        *(undefined (*) [16])(in_RCX + 1) = ZEXT816(0);
        *(uint32_t *)((int64_t)in_RCX + 0x9c) = *(uint32_t *)((int64_t)in_RCX + 0x9c) & 0xffffffdf;
    }
    iVar1 = in_RCX[0x14];
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e9755;
    func_0x000180211410(iVar1);
    in_RCX[0x14] = 0;
    return;
}

// ============================================================
// Function: FUN_1801e9770
// Address: 0x1801e9770
// Size: 1623 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_650h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_584h
// WARNING: [rz-ghidra] Detected overlap for variable var_4f2h
// WARNING: [rz-ghidra] Detected overlap for variable var_557h
// WARNING: [rz-ghidra] Detected overlap for variable var_50ch
// WARNING: [rz-ghidra] Detected overlap for variable var_570h
// WARNING: [rz-ghidra] Detected overlap for variable var_4fbh
// WARNING: [rz-ghidra] Detected overlap for variable var_56ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4f7h
// WARNING: [rz-ghidra] Detected overlap for variable var_580h
// WARNING: [rz-ghidra] Detected overlap for variable var_50bh
// WARNING: [rz-ghidra] Detected overlap for variable var_524h
// WARNING: [rz-ghidra] Detected overlap for variable var_4f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_550h

void fcn.1801e9770(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    undefined4 uVar3;
    uint64_t uVar4;
    undefined8 *puVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int32_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    int64_t **ppiVar14;
    int64_t in_RCX;
    int64_t *in_RDX;
    int64_t iVar15;
    int64_t iVar16;
    int64_t iVar17;
    undefined *in_R8;
    int64_t iVar18;
    int64_t iVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_5e8h;
    int64_t var_5e0h;
    int64_t var_5d8h;
    int64_t var_5d0h;
    int64_t var_5c8h;
    int64_t var_5c0h;
    int64_t var_588h;
    undefined4 var_580h;
    undefined4 uStack_57c;
    undefined4 uStack_578;
    undefined4 uStack_574;
    undefined4 var_570h;
    undefined var_56ch;
    int64_t var_56bh;
    undefined4 uStack_563;
    undefined4 uStack_55f;
    int64_t var_55bh;
    int64_t var_550h;
    int64_t var_528h;
    int64_t var_520h;
    undefined4 uStack_518;
    undefined4 uStack_514;
    int64_t var_510h;
    undefined4 uStack_507;
    undefined4 uStack_503;
    undefined4 uStack_4ff;
    undefined4 var_4fbh;
    undefined var_4f7h;
    int64_t var_4f6h;
    int64_t var_4e8h;
    int64_t var_4e0h;
    int64_t var_4d8h;
    int64_t var_4c8h;
    undefined8 uStack_4c0;
    int64_t var_4b8h;
    int64_t var_4b0h;
    int64_t var_4a8h;
    undefined8 uStack_4a0;
    int64_t var_498h;
    int64_t var_488h;
    int64_t var_478h;
    int64_t var_460h;
    int64_t var_448h;
    int64_t var_48h;
    undefined8 uStack_40;
    
    uStack_40 = 0x1801e9792;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar12);
    iVar15 = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar12) = 0;
    uVar2 = *(uint8_t *)((int64_t)in_RDX + 0x9c);
    *(undefined *)((int64_t)&var_8h + iVar12) = 0;
    var_488h = 0;
    iVar17 = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar12) = 0;
    iVar18 = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar12) = 0;
    _var_4c8h = ZEXT816(0);
    _var_4b8h = ZEXT816(0);
    _var_4a8h = ZEXT816(0);
    _var_498h = ZEXT816(0);
    iVar13 = iVar15;
    iVar19 = iVar15;
    if ((uVar2 & 1) == 0) {
        uVar4 = *(uint64_t *)(in_RCX + 0x10);
        puVar1 = (uint8_t *)(in_RCX + 0x80);
        *(undefined8 *)((int64_t)&var_10h + iVar12) = 0;
        iVar16 = iVar15;
        iVar13 = iVar17;
        iVar19 = iVar18;
        if ((0x14 < uVar4) && ((*puVar1 & 0x40) != 0)) {
            iVar17 = in_RDX[0x11];
            *(undefined8 *)(&stack0xffffffffffffffe8 + iVar12) = 0;
            *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e983b;
            iVar11 = func_0x000180201550(iVar17, puVar1 + (uVar4 - 0x10), 0, (int64_t)&var_10h + iVar12);
            while (iVar11 != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e984a;
                func_0x0001801e48e0(*(undefined8 *)((int64_t)&var_10h + iVar12));
                iVar17 = *(int64_t *)(in_RCX + 0x10);
                iVar18 = in_RDX[0x11];
                iVar16 = iVar16 + 1;
                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar12) = 0;
                *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9871;
                iVar11 = func_0x000180201550(iVar18, puVar1 + iVar17 + -0x10, iVar16, (int64_t)&var_10h + iVar12);
            }
            if (iVar16 != 0) goto code_r0x0001801e9d81;
        }
        if (in_R8 != (undefined *)0x0) {
            iVar17 = in_RDX[0x10];
            *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e989a;
            iVar11 = func_0x000180200f90(iVar17, in_R8, 0, (int64_t)&var_20h + iVar12);
            if (iVar11 != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e98ab;
                func_0x0001801e3a70(*(undefined8 *)((int64_t)&var_20h + iVar12), in_RCX);
                goto code_r0x0001801e9d9d;
            }
        }
        if ((((*(uint8_t *)((int64_t)in_RDX + 0x9c) & 0x10) != 0) &&
            (uVar4 = *(uint64_t *)(in_RCX + 0x10), 0x4af < uVar4)) && (uVar4 < 0x8000000000000000)) {
            *(uint64_t *)((int64_t)&arg_38h + iVar12) = uVar4;
            *(uint8_t **)((int64_t)&arg_30h + iVar12) = puVar1;
            *(int64_t *)(&stack0xfffffffffffffff8 + iVar12) = (int64_t)&arg_28h + iVar12;
            *(int64_t *)(&stack0xfffffffffffffff0 + iVar12) = iVar16;
            *(int64_t **)(&stack0xffffffffffffffe8 + iVar12) = &var_588h;
            *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e991c;
            iVar11 = func_0x0001801f8d60((int64_t)&arg_30h + iVar12, 0xffffffffffffffff, 1, 0);
            if ((iVar11 != 0) || ((*(uint8_t *)((int64_t)&arg_28h + iVar12) & 2) != 0)) {
                if ((var_588h._4_4_ == 0) || (var_588h._4_4_ != 1)) {
                    if (0x4af < *(uint64_t *)(in_RCX + 0x10)) {
                        *(undefined4 *)((int64_t)&var_10h + iVar12) = 1;
                        var_4f6h._0_4_ = 0;
                        var_4f6h._4_2_ = 0;
                        var_510h._0_4_ = (undefined4)var_55bh;
                        var_510h._4_1_ = var_55bh._4_1_;
                        var_4fbh = var_570h;
                        var_4f7h = var_56ch;
                        var_4d8h = (int64_t)&var_10h + iVar12;
                        var_520h._0_4_ = (undefined4)var_56bh;
                        var_520h._4_4_ = var_56bh._4_4_;
                        uStack_518 = uStack_563;
                        uStack_514 = uStack_55f;
                        *(int64_t **)((int64_t)&arg_40h + iVar12) = &var_448h;
                        var_5e0h = in_RCX + 0x38;
                        var_528h._0_4_ = 6;
                        stack0xfffffffffffffaf5 = var_580h;
                        uStack_507 = uStack_57c;
                        uStack_503 = uStack_578;
                        uStack_4ff = uStack_574;
                        var_528h._4_4_ = (undefined4)iVar16;
                        var_4e0h = 4;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9cb4;
                        var_5d8h = iVar16;
                        var_5d0h = iVar16;
                        unique0x100018ae = iVar16;
                        var_4e8h = iVar16;
                        iVar11 = func_0x000180244550(&var_5c0h, &var_448h, 0x400, 0);
                        if (iVar11 != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9cd0;
                            iVar11 = func_0x0001801f93b0(&var_5c0h, (undefined)var_580h, &var_528h, 0);
                            if (iVar11 != 0) {
                                do {
                                    uVar3 = *(undefined4 *)((int64_t)&var_10h + iVar16 * 4 + iVar12);
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9cf3;
                                    iVar11 = func_0x0001802446f0(&var_5c0h, uVar3, 4);
                                    if (iVar11 == 0) goto code_r0x0001801e9d81;
                                    iVar16 = iVar16 + 1;
                                } while (iVar16 == 0);
                                *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9d11;
                                iVar11 = func_0x0001802442e0(&var_5c0h, &var_5e8h);
                                if (iVar11 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9d1e;
                                    iVar11 = func_0x000180244200(&var_5c0h);
                                    if (iVar11 != 0) {
                                        iVar15 = in_RDX[7];
                                        *(int64_t **)(&stack0xfffffffffffffff0 + iVar12) = &var_5c8h;
                                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar12) = 0;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9d4a;
                                        iVar11 = func_0x00018021af90(iVar15, (int64_t)&arg_40h + iVar12, 0x28, 1);
                                        if (iVar11 == 0) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9d53;
                                            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar12), 
                                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar12));
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9d6b;
                                            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar12), 
                                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar12), 
                                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar12), 
                                                          *(int64_t *)(&stack0x00000000 + iVar12), 
                                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9d81;
                                            fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar12));
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else if ((char)var_588h == '\x01') {
                    var_478h._0_1_ = '\0';
                    var_4c8h = *(undefined8 *)*in_RDX;
                    var_4b0h._0_1_ = *in_R8;
                    var_4b8h = in_RDX[8];
                    var_4b0h._1_7_ = 0;
                    var_4a8h = 0x20;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e998a;
                    iVar13 = func_0x000180205410(&var_4c8h);
                    if (iVar13 != 0) {
                        puVar5 = (undefined8 *)*in_RDX;
                        *(int64_t *)(&stack0xfffffffffffffff0 + iVar12) = iVar16;
                        *(int64_t *)(&stack0xffffffffffffffe8 + iVar12) = iVar13;
                        uVar6 = puVar5[1];
                        uVar7 = *puVar5;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e99b9;
                        iVar11 = func_0x0001801f9c30(uVar7, uVar6, &var_580h, 1);
                        if (iVar11 != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e99cf;
                            iVar11 = func_0x0001802057b0(iVar13, in_RCX, in_R8);
                            if (iVar11 != 0) {
                                if ((*(uint8_t *)((int64_t)in_RDX + 0x9c) & 4) == 0) {
                                    iVar17 = iVar16;
                                    iVar15 = iVar13;
                                    if (var_550h != 0) {
code_r0x0001801e99f2:
                                        *(int64_t *)(&stack0xfffffffffffffff0 + iVar12) = (int64_t)&var_8h + iVar12;
                                        *(int64_t **)(&stack0xffffffffffffffe8 + iVar12) = &var_460h;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9a22;
                                        iVar11 = func_0x0001801ea6e0(&var_588h, in_RDX, in_RCX + 0x38, &var_478h);
                                        iVar17 = iVar16;
                                        if (iVar11 == 0) {
                                            if ((*(uint8_t *)((int64_t)in_RDX + 0x9c) & 4) != 0) {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9a3f;
                                                func_0x0001801ea270(in_RDX, in_RCX + 0x38, &var_588h);
                                                iVar13 = iVar16;
                                                iVar19 = iVar15;
                                                goto code_r0x0001801e9d81;
                                            }
                                            iVar17 = 0;
                                            iVar15 = iVar16;
                                        }
                                    }
                                    ppiVar14 = (int64_t **)in_RDX[0xf];
                                    iVar13 = iVar17;
                                    iVar19 = iVar15;
                                    if (ppiVar14 == (int64_t **)0x0) {
                                        *(undefined4 *)(&stack0xffffffffffffffe8 + iVar12) = 0;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9ac6;
                                        ppiVar14 = (int64_t **)func_0x0001801ea030(in_RDX, 0, iVar17, 1);
                                        if (ppiVar14 == (int64_t **)0x0) goto code_r0x0001801e9d81;
                                    } else {
                                        in_RDX[0xf] = 0;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9a7f;
                                        func_0x0001801e38c0(ppiVar14, iVar17);
                                        piVar8 = ppiVar14[0x7e];
                                        piVar9 = ppiVar14[0x7c];
                                        piVar10 = ppiVar14[0x7b];
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9a99;
                                        func_0x000180205760(piVar10, piVar9, piVar8);
                                        piVar8 = ppiVar14[0x7d];
                                        piVar9 = ppiVar14[0x7b];
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9aac;
                                        func_0x000180205770(piVar9, piVar8);
                                    }
                                    if (iVar17 == 0) {
                                        piVar8 = *ppiVar14;
                                        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar12) = 0;
                                        puVar5 = (undefined8 *)*piVar8;
                                        *(int64_t **)(&stack0xffffffffffffffe8 + iVar12) = ppiVar14[0x7b];
                                        uVar6 = puVar5[1];
                                        uVar7 = *puVar5;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9b04;
                                        iVar11 = func_0x0001801f9c30(uVar7, uVar6, &var_580h, 1);
                                        if (iVar11 == 0) goto code_r0x0001801e9d81;
                                    }
                                    if ((char)var_478h == '\0') {
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9b6c;
                                        iVar11 = func_0x0001801e41b0(ppiVar14, in_RCX + 0x38, &var_460h, &var_580h);
                                    } else {
                                        piVar8 = ppiVar14[0x11];
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9b21;
                                        func_0x000180208210(piVar8);
                                        *(int64_t **)(&stack0xffffffffffffffe8 + iVar12) = &var_478h;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9b44;
                                        iVar11 = func_0x0001801e3700(ppiVar14, in_RCX + 0x38, &var_460h, &var_580h);
                                    }
                                    if (iVar11 == 0) {
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9b50;
                                        func_0x0001801e3930(ppiVar14);
                                    } else {
                                        if (in_RDX[0xd] != 0) {
                                            *(int64_t ***)(in_RDX[0xd] + 0x18) = ppiVar14;
                                        }
                                        ppiVar14[4] = (int64_t *)in_RDX[0xd];
                                        ppiVar14[3] = (int64_t *)0x0;
                                        in_RDX[0xd] = (int64_t)ppiVar14;
                                        if (in_RDX[0xc] == 0) {
                                            in_RDX[0xc] = (int64_t)ppiVar14;
                                        }
                                        in_RDX[0xe] = in_RDX[0xe] + 1;
                                        if (*(char *)((int64_t)&var_8h + iVar12) == '\x01') {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9bad;
                                            func_0x0001801e8810(ppiVar14, in_RCX + 0x38);
                                        }
                                        if (iVar17 == 0) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9bc7;
                                            iVar11 = func_0x0001802055c0(iVar15, (int64_t)&var_18h + iVar12);
                                            while (iVar11 == 1) {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9bdd;
                                                func_0x0001801e3a90(ppiVar14, 
                                                                    *(undefined8 *)((int64_t)&var_18h + iVar12));
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9bea;
                                                iVar11 = func_0x0001802055c0(iVar15, (int64_t)&var_18h + iVar12);
                                            }
                                            piVar8 = ppiVar14[0x7b];
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9bfe;
                                            func_0x000180205780(iVar15, piVar8);
                                        } else {
                                            iVar13 = 0;
                                        }
                                    }
                                } else {
                                    iVar16 = iVar13;
                                    if (var_550h != 0) goto code_r0x0001801e99f2;
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9a5c;
                                    func_0x0001801ea270(in_RDX, in_RCX + 0x38, &var_588h);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
code_r0x0001801e9d81:
    *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9d89;
    func_0x000180205160(iVar13);
    *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9d91;
    func_0x000180205160(iVar19);
    iVar13 = in_RDX[8];
    *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9d9d;
    func_0x0001801de180(iVar13, in_RCX);
code_r0x0001801e9d9d:
    *(undefined8 *)((int64_t)&uStack_40 + iVar12) = 0x1801e9dac;
    fcn.180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar12));
    return;
}

// ============================================================
// Function: FUN_1801e9dd0
// Address: 0x1801e9dd0
// Size: 596 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_650h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_584h
// WARNING: [rz-ghidra] Detected overlap for variable var_4f2h
// WARNING: [rz-ghidra] Detected overlap for variable var_557h
// WARNING: [rz-ghidra] Detected overlap for variable var_50ch
// WARNING: [rz-ghidra] Detected overlap for variable var_570h
// WARNING: [rz-ghidra] Detected overlap for variable var_4fbh
// WARNING: [rz-ghidra] Detected overlap for variable var_56ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4f7h
// WARNING: [rz-ghidra] Detected overlap for variable var_580h
// WARNING: [rz-ghidra] Detected overlap for variable var_50bh
// WARNING: [rz-ghidra] Detected overlap for variable var_524h
// WARNING: [rz-ghidra] Detected overlap for variable var_4f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_550h

int64_t fcn.1801e9dd0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e9dee;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar10 = 0;
    iVar9 = 0;
    iVar8 = (uint64_t)(*(uint32_t *)((int64_t)in_RCX + 0x9c) & 2) << 2;
    iVar4 = -1;
    iVar12 = 0;
    iVar11 = 0;
    iVar7 = iVar10;
    iVar6 = iVar10;
    if ((*in_RCX != 0) && (iVar7 = iVar11, iVar6 = iVar12, in_RCX[5] != 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801e9e26;
        iVar11 = func_0x0001802542f0();
        in_RCX[0x12] = iVar11;
        if (iVar11 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801e9e4a;
            iVar11 = func_0x0001801de060(0, iVar8, 0x1801e8af0, in_RCX);
            in_RCX[8] = iVar11;
            iVar10 = iVar9;
            if (iVar11 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801e9e69;
                func_0x0001801de210(iVar11, fcn.1801e9770, in_RCX);
                uVar1 = ((undefined8 *)*in_RCX)[1];
                uVar2 = *(undefined8 *)*in_RCX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801e9e78;
                iVar9 = func_0x000180201630(uVar2, uVar1);
                in_RCX[0x11] = iVar9;
                if (iVar9 != 0) {
                    uVar1 = *(undefined8 *)*in_RCX;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801e9e96;
                    iVar9 = func_0x000180201000(uVar1, iVar8);
                    in_RCX[0x10] = iVar9;
                    if (iVar9 != 0) {
                        *(uint32_t *)((int64_t)in_RCX + 0x9c) = *(uint32_t *)((int64_t)in_RCX + 0x9c) & 0xfffffffe;
                        iVar9 = *in_RCX;
                        *(char *)(in_RCX + 0x13) = (char)iVar8;
                        *(undefined *)((int64_t)in_RCX + 0x99) = 8;
                        if (*(int64_t *)(iVar9 + 0x90) != 0) {
                            *(int64_t **)(*(int64_t *)(iVar9 + 0x90) + 8) = in_RCX;
                        }
                        in_RCX[2] = *(int64_t *)(iVar9 + 0x90);
                        in_RCX[1] = 0;
                        *(int64_t **)(iVar9 + 0x90) = in_RCX;
                        if (*(int64_t *)(iVar9 + 0x88) == 0) {
                            *(int64_t **)(iVar9 + 0x88) = in_RCX;
                        }
                        *(int64_t *)(iVar9 + 0x98) = *(int64_t *)(iVar9 + 0x98) + 1;
                        *(uint32_t *)((int64_t)in_RCX + 0x9c) = *(uint32_t *)((int64_t)in_RCX + 0x9c) | 0x120;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801e9f0a;
                        iVar8 = func_0x000180211490();
                        in_RCX[0x14] = iVar8;
                        if (iVar8 != 0) {
                            uVar1 = *(undefined8 *)*in_RCX;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801e9f2f;
                            iVar6 = func_0x0001802119f0(uVar1, 0x1804adad8, 0);
                            if (iVar6 != 0) {
                                iVar8 = in_RCX[0x14];
                                *(undefined8 *)((int64_t)&var_8h + iVar5) = 0;
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801e9f55;
                                iVar3 = func_0x0001802128b0(iVar8, iVar6, 0, 0);
                                if (iVar3 != 0) {
                                    iVar8 = in_RCX[0x14];
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801e9f65;
                                    iVar4 = func_0x00018020eae0(iVar8);
                                    if (0 < iVar4) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801e9f81;
                                        iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                                              *(int64_t *)((int64_t)&var_10h + iVar5));
                                        if (iVar7 != 0) {
                                            uVar1 = *(undefined8 *)*in_RCX;
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801e9f9d;
                                            iVar3 = func_0x00018021be60(uVar1, iVar7, (int64_t)iVar4, 0);
                                            if (iVar3 != 0) {
                                                iVar10 = in_RCX[0x14];
                                                *(undefined8 *)((int64_t)&var_8h + iVar5) = 0;
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801e9fba;
                                                iVar3 = func_0x0001802128b0(iVar10, 0, 0, iVar7);
                                                iVar10 = 0;
                                                if (iVar3 != 0) {
                                                    iVar10 = 1;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801e9fcc;
    func_0x000180211a40(iVar6);
    if (iVar4 < 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801e9ffd;
        fcn.180224990(iVar7, 0x1804b74f8, 0xbb);
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801e9fe9;
        func_0x000180224b90(iVar7, (int64_t)iVar4, 0x1804b74f8, 0xb9);
    }
    if ((int32_t)iVar10 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801ea009;
        fcn.1801e9680(*(int64_t *)((int64_t)&var_8h + iVar5));
    }
    return iVar10;
}

// ============================================================
// Function: FUN_1801ea030
// Address: 0x1801ea030
// Size: 221 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel

int64_t fcn.1801ea030(int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                     int64_t arg_88h)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int32_t *piVar8;
    int64_t in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBP;
    int32_t *piVar9;
    undefined8 in_R8;
    undefined8 uVar10;
    undefined4 in_R9D;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ea043;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    piVar9 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&var_10h + iVar4) = *(undefined8 *)(in_RCX + 0x80);
    *(undefined8 *)((int64_t)&var_18h + iVar4) = *(undefined8 *)(in_RCX + 0x88);
    *(int64_t *)((int64_t)&var_8h + iVar4) = in_RCX;
    *(undefined4 *)(&stack0x0000003c + iVar4) = *(undefined4 *)((int64_t)&arg_88h + iVar4);
    *(undefined8 *)((int64_t)&arg_28h + iVar4 + 4) = 0;
    *(undefined8 *)(&stack0x00000034 + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = 0;
    *(undefined4 *)((int64_t)&arg_28h + iVar4) = in_R9D;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = in_R8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea099;
    iVar5 = func_0x0001801e37b0((int64_t)&var_8h + iVar4);
    if (iVar5 == 0) {
        return 0;
    }
    if (in_RDX == (int32_t *)0x0) {
        pcVar1 = *(code **)(in_RCX + 0x18);
        in_RDX = piVar9;
        if (pcVar1 != (code *)0x0) {
            uVar10 = *(undefined8 *)(in_RCX + 0x20);
            *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea117;
            iVar6 = (*pcVar1)(iVar5, uVar10);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_R13;
                iVar2 = *(int64_t *)(in_RCX + 0x20);
                if (*(int64_t *)(iVar6 + 0x78) == 0) {
                    uVar10 = *(undefined8 *)(in_RCX + 0x28);
                    *(undefined8 *)((int64_t)&arg_78h + iVar4) = unaff_R14;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea153;
                    uVar7 = func_0x00018019a2d0();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea161;
                    in_RDX = (int32_t *)func_0x000180196080(uVar10, iVar6, uVar7);
                    *(int32_t **)(iVar6 + 0x78) = in_RDX;
                    if (in_RDX != (int32_t *)0x0) {
                        piVar8 = in_RDX;
                        if (*in_RDX == 0) {
code_r0x0001801ea18c:
                            if (iVar2 != 0) {
                                iVar2 = *(int64_t *)(iVar2 + 8);
                                pcVar1 = *(code **)(iVar2 + 0x220);
                                if (pcVar1 != (code *)0x0) {
                                    uVar10 = *(undefined8 *)(iVar2 + 0x228);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea1ad;
                                    iVar3 = (*pcVar1)(iVar2, iVar6, uVar10);
                                    if (iVar3 == 0) goto code_r0x0001801ea1d7;
                                }
                            }
                            piVar8[0x58] = piVar8[0x58] | 0x6000;
                            *(uint64_t *)(piVar8 + 0x26a) = *(uint64_t *)(piVar8 + 0x26a) & 0x3df6ffb85;
                            piVar8[0x2eb] = 0;
                            goto code_r0x0001801ea1f7;
                        }
                        if ((char)*in_RDX < '\0') {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea184;
                            piVar8 = (int32_t *)func_0x0001801bda50(in_RDX);
                            if (piVar8 != (int32_t *)0x0) goto code_r0x0001801ea18c;
                        }
                    }
code_r0x0001801ea1d7:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea1df;
                    func_0x000180193500(iVar6);
                    in_RDX = piVar9;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea13d;
                    func_0x000180193500(iVar6);
                }
            }
        }
code_r0x0001801ea1f7:
        *(int32_t **)(iVar5 + 0x30) = in_RDX;
        if (in_RDX == (int32_t *)0x0) {
            uVar10 = 0x21e;
            goto code_r0x0001801ea20d;
        }
    } else {
        *(int32_t **)(iVar5 + 0x30) = in_RDX;
    }
    *(uint32_t *)(iVar5 + 0x5d4) = *(uint32_t *)(iVar5 + 0x5d4) | 0x200;
    iVar6 = *(int64_t *)(*(int64_t *)(in_RDX + 2) + 0x6d0);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea0de;
        iVar6 = func_0x0001802231e0(iVar6, 0x1804b74f8, 0x228);
        *(int64_t *)(iVar5 + 0x5f0) = iVar6;
        if (iVar6 == 0) {
            uVar10 = 0x229;
            goto code_r0x0001801ea20d;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea237;
    iVar3 = func_0x0001801e3a50(iVar5);
    if (iVar3 != 0) {
        uVar10 = *(undefined8 *)(in_RCX + 0x38);
        uVar7 = *(undefined8 *)(iVar5 + 0x3d0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea253;
        fcn.1801fb900(uVar7, uVar10);
        return iVar5;
    }
    uVar10 = 0x233;
code_r0x0001801ea20d:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea21c;
    fcn.180224990(iVar5, 0x1804b74f8, uVar10);
    return 0;
}

// ============================================================
// Function: FUN_1801ea10d
// Address: 0x1801ea10d
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel

int64_t fcn.1801ea030(int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                     int64_t arg_88h)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int32_t *piVar8;
    int64_t in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBP;
    int32_t *piVar9;
    undefined8 in_R8;
    undefined8 uVar10;
    undefined4 in_R9D;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ea043;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    piVar9 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&var_10h + iVar4) = *(undefined8 *)(in_RCX + 0x80);
    *(undefined8 *)((int64_t)&var_18h + iVar4) = *(undefined8 *)(in_RCX + 0x88);
    *(int64_t *)((int64_t)&var_8h + iVar4) = in_RCX;
    *(undefined4 *)(&stack0x0000003c + iVar4) = *(undefined4 *)((int64_t)&arg_88h + iVar4);
    *(undefined8 *)((int64_t)&arg_28h + iVar4 + 4) = 0;
    *(undefined8 *)(&stack0x00000034 + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = 0;
    *(undefined4 *)((int64_t)&arg_28h + iVar4) = in_R9D;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = in_R8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea099;
    iVar5 = func_0x0001801e37b0((int64_t)&var_8h + iVar4);
    if (iVar5 == 0) {
        return 0;
    }
    if (in_RDX == (int32_t *)0x0) {
        pcVar1 = *(code **)(in_RCX + 0x18);
        in_RDX = piVar9;
        if (pcVar1 != (code *)0x0) {
            uVar10 = *(undefined8 *)(in_RCX + 0x20);
            *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea117;
            iVar6 = (*pcVar1)(iVar5, uVar10);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_R13;
                iVar2 = *(int64_t *)(in_RCX + 0x20);
                if (*(int64_t *)(iVar6 + 0x78) == 0) {
                    uVar10 = *(undefined8 *)(in_RCX + 0x28);
                    *(undefined8 *)((int64_t)&arg_78h + iVar4) = unaff_R14;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea153;
                    uVar7 = func_0x00018019a2d0();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea161;
                    in_RDX = (int32_t *)func_0x000180196080(uVar10, iVar6, uVar7);
                    *(int32_t **)(iVar6 + 0x78) = in_RDX;
                    if (in_RDX != (int32_t *)0x0) {
                        piVar8 = in_RDX;
                        if (*in_RDX == 0) {
code_r0x0001801ea18c:
                            if (iVar2 != 0) {
                                iVar2 = *(int64_t *)(iVar2 + 8);
                                pcVar1 = *(code **)(iVar2 + 0x220);
                                if (pcVar1 != (code *)0x0) {
                                    uVar10 = *(undefined8 *)(iVar2 + 0x228);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea1ad;
                                    iVar3 = (*pcVar1)(iVar2, iVar6, uVar10);
                                    if (iVar3 == 0) goto code_r0x0001801ea1d7;
                                }
                            }
                            piVar8[0x58] = piVar8[0x58] | 0x6000;
                            *(uint64_t *)(piVar8 + 0x26a) = *(uint64_t *)(piVar8 + 0x26a) & 0x3df6ffb85;
                            piVar8[0x2eb] = 0;
                            goto code_r0x0001801ea1f7;
                        }
                        if ((char)*in_RDX < '\0') {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea184;
                            piVar8 = (int32_t *)func_0x0001801bda50(in_RDX);
                            if (piVar8 != (int32_t *)0x0) goto code_r0x0001801ea18c;
                        }
                    }
code_r0x0001801ea1d7:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea1df;
                    func_0x000180193500(iVar6);
                    in_RDX = piVar9;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea13d;
                    func_0x000180193500(iVar6);
                }
            }
        }
code_r0x0001801ea1f7:
        *(int32_t **)(iVar5 + 0x30) = in_RDX;
        if (in_RDX == (int32_t *)0x0) {
            uVar10 = 0x21e;
            goto code_r0x0001801ea20d;
        }
    } else {
        *(int32_t **)(iVar5 + 0x30) = in_RDX;
    }
    *(uint32_t *)(iVar5 + 0x5d4) = *(uint32_t *)(iVar5 + 0x5d4) | 0x200;
    iVar6 = *(int64_t *)(*(int64_t *)(in_RDX + 2) + 0x6d0);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea0de;
        iVar6 = func_0x0001802231e0(iVar6, 0x1804b74f8, 0x228);
        *(int64_t *)(iVar5 + 0x5f0) = iVar6;
        if (iVar6 == 0) {
            uVar10 = 0x229;
            goto code_r0x0001801ea20d;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea237;
    iVar3 = func_0x0001801e3a50(iVar5);
    if (iVar3 != 0) {
        uVar10 = *(undefined8 *)(in_RCX + 0x38);
        uVar7 = *(undefined8 *)(iVar5 + 0x3d0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea253;
        fcn.1801fb900(uVar7, uVar10);
        return iVar5;
    }
    uVar10 = 0x233;
code_r0x0001801ea20d:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea21c;
    fcn.180224990(iVar5, 0x1804b74f8, uVar10);
    return 0;
}

// ============================================================
// Function: FUN_1801ea123
// Address: 0x1801ea123
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel

int64_t fcn.1801ea030(int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                     int64_t arg_88h)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int32_t *piVar8;
    int64_t in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBP;
    int32_t *piVar9;
    undefined8 in_R8;
    undefined8 uVar10;
    undefined4 in_R9D;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ea043;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    piVar9 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&var_10h + iVar4) = *(undefined8 *)(in_RCX + 0x80);
    *(undefined8 *)((int64_t)&var_18h + iVar4) = *(undefined8 *)(in_RCX + 0x88);
    *(int64_t *)((int64_t)&var_8h + iVar4) = in_RCX;
    *(undefined4 *)(&stack0x0000003c + iVar4) = *(undefined4 *)((int64_t)&arg_88h + iVar4);
    *(undefined8 *)((int64_t)&arg_28h + iVar4 + 4) = 0;
    *(undefined8 *)(&stack0x00000034 + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = 0;
    *(undefined4 *)((int64_t)&arg_28h + iVar4) = in_R9D;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = in_R8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea099;
    iVar5 = func_0x0001801e37b0((int64_t)&var_8h + iVar4);
    if (iVar5 == 0) {
        return 0;
    }
    if (in_RDX == (int32_t *)0x0) {
        pcVar1 = *(code **)(in_RCX + 0x18);
        in_RDX = piVar9;
        if (pcVar1 != (code *)0x0) {
            uVar10 = *(undefined8 *)(in_RCX + 0x20);
            *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea117;
            iVar6 = (*pcVar1)(iVar5, uVar10);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_R13;
                iVar2 = *(int64_t *)(in_RCX + 0x20);
                if (*(int64_t *)(iVar6 + 0x78) == 0) {
                    uVar10 = *(undefined8 *)(in_RCX + 0x28);
                    *(undefined8 *)((int64_t)&arg_78h + iVar4) = unaff_R14;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea153;
                    uVar7 = func_0x00018019a2d0();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea161;
                    in_RDX = (int32_t *)func_0x000180196080(uVar10, iVar6, uVar7);
                    *(int32_t **)(iVar6 + 0x78) = in_RDX;
                    if (in_RDX != (int32_t *)0x0) {
                        piVar8 = in_RDX;
                        if (*in_RDX == 0) {
code_r0x0001801ea18c:
                            if (iVar2 != 0) {
                                iVar2 = *(int64_t *)(iVar2 + 8);
                                pcVar1 = *(code **)(iVar2 + 0x220);
                                if (pcVar1 != (code *)0x0) {
                                    uVar10 = *(undefined8 *)(iVar2 + 0x228);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea1ad;
                                    iVar3 = (*pcVar1)(iVar2, iVar6, uVar10);
                                    if (iVar3 == 0) goto code_r0x0001801ea1d7;
                                }
                            }
                            piVar8[0x58] = piVar8[0x58] | 0x6000;
                            *(uint64_t *)(piVar8 + 0x26a) = *(uint64_t *)(piVar8 + 0x26a) & 0x3df6ffb85;
                            piVar8[0x2eb] = 0;
                            goto code_r0x0001801ea1f7;
                        }
                        if ((char)*in_RDX < '\0') {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea184;
                            piVar8 = (int32_t *)func_0x0001801bda50(in_RDX);
                            if (piVar8 != (int32_t *)0x0) goto code_r0x0001801ea18c;
                        }
                    }
code_r0x0001801ea1d7:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea1df;
                    func_0x000180193500(iVar6);
                    in_RDX = piVar9;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea13d;
                    func_0x000180193500(iVar6);
                }
            }
        }
code_r0x0001801ea1f7:
        *(int32_t **)(iVar5 + 0x30) = in_RDX;
        if (in_RDX == (int32_t *)0x0) {
            uVar10 = 0x21e;
            goto code_r0x0001801ea20d;
        }
    } else {
        *(int32_t **)(iVar5 + 0x30) = in_RDX;
    }
    *(uint32_t *)(iVar5 + 0x5d4) = *(uint32_t *)(iVar5 + 0x5d4) | 0x200;
    iVar6 = *(int64_t *)(*(int64_t *)(in_RDX + 2) + 0x6d0);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea0de;
        iVar6 = func_0x0001802231e0(iVar6, 0x1804b74f8, 0x228);
        *(int64_t *)(iVar5 + 0x5f0) = iVar6;
        if (iVar6 == 0) {
            uVar10 = 0x229;
            goto code_r0x0001801ea20d;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea237;
    iVar3 = func_0x0001801e3a50(iVar5);
    if (iVar3 != 0) {
        uVar10 = *(undefined8 *)(in_RCX + 0x38);
        uVar7 = *(undefined8 *)(iVar5 + 0x3d0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea253;
        fcn.1801fb900(uVar7, uVar10);
        return iVar5;
    }
    uVar10 = 0x233;
code_r0x0001801ea20d:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea21c;
    fcn.180224990(iVar5, 0x1804b74f8, uVar10);
    return 0;
}

// ============================================================
// Function: FUN_1801ea146
// Address: 0x1801ea146
// Size: 161 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel

int64_t fcn.1801ea030(int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                     int64_t arg_88h)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int32_t *piVar8;
    int64_t in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBP;
    int32_t *piVar9;
    undefined8 in_R8;
    undefined8 uVar10;
    undefined4 in_R9D;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ea043;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    piVar9 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&var_10h + iVar4) = *(undefined8 *)(in_RCX + 0x80);
    *(undefined8 *)((int64_t)&var_18h + iVar4) = *(undefined8 *)(in_RCX + 0x88);
    *(int64_t *)((int64_t)&var_8h + iVar4) = in_RCX;
    *(undefined4 *)(&stack0x0000003c + iVar4) = *(undefined4 *)((int64_t)&arg_88h + iVar4);
    *(undefined8 *)((int64_t)&arg_28h + iVar4 + 4) = 0;
    *(undefined8 *)(&stack0x00000034 + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = 0;
    *(undefined4 *)((int64_t)&arg_28h + iVar4) = in_R9D;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = in_R8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea099;
    iVar5 = func_0x0001801e37b0((int64_t)&var_8h + iVar4);
    if (iVar5 == 0) {
        return 0;
    }
    if (in_RDX == (int32_t *)0x0) {
        pcVar1 = *(code **)(in_RCX + 0x18);
        in_RDX = piVar9;
        if (pcVar1 != (code *)0x0) {
            uVar10 = *(undefined8 *)(in_RCX + 0x20);
            *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea117;
            iVar6 = (*pcVar1)(iVar5, uVar10);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_R13;
                iVar2 = *(int64_t *)(in_RCX + 0x20);
                if (*(int64_t *)(iVar6 + 0x78) == 0) {
                    uVar10 = *(undefined8 *)(in_RCX + 0x28);
                    *(undefined8 *)((int64_t)&arg_78h + iVar4) = unaff_R14;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea153;
                    uVar7 = func_0x00018019a2d0();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea161;
                    in_RDX = (int32_t *)func_0x000180196080(uVar10, iVar6, uVar7);
                    *(int32_t **)(iVar6 + 0x78) = in_RDX;
                    if (in_RDX != (int32_t *)0x0) {
                        piVar8 = in_RDX;
                        if (*in_RDX == 0) {
code_r0x0001801ea18c:
                            if (iVar2 != 0) {
                                iVar2 = *(int64_t *)(iVar2 + 8);
                                pcVar1 = *(code **)(iVar2 + 0x220);
                                if (pcVar1 != (code *)0x0) {
                                    uVar10 = *(undefined8 *)(iVar2 + 0x228);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea1ad;
                                    iVar3 = (*pcVar1)(iVar2, iVar6, uVar10);
                                    if (iVar3 == 0) goto code_r0x0001801ea1d7;
                                }
                            }
                            piVar8[0x58] = piVar8[0x58] | 0x6000;
                            *(uint64_t *)(piVar8 + 0x26a) = *(uint64_t *)(piVar8 + 0x26a) & 0x3df6ffb85;
                            piVar8[0x2eb] = 0;
                            goto code_r0x0001801ea1f7;
                        }
                        if ((char)*in_RDX < '\0') {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea184;
                            piVar8 = (int32_t *)func_0x0001801bda50(in_RDX);
                            if (piVar8 != (int32_t *)0x0) goto code_r0x0001801ea18c;
                        }
                    }
code_r0x0001801ea1d7:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea1df;
                    func_0x000180193500(iVar6);
                    in_RDX = piVar9;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea13d;
                    func_0x000180193500(iVar6);
                }
            }
        }
code_r0x0001801ea1f7:
        *(int32_t **)(iVar5 + 0x30) = in_RDX;
        if (in_RDX == (int32_t *)0x0) {
            uVar10 = 0x21e;
            goto code_r0x0001801ea20d;
        }
    } else {
        *(int32_t **)(iVar5 + 0x30) = in_RDX;
    }
    *(uint32_t *)(iVar5 + 0x5d4) = *(uint32_t *)(iVar5 + 0x5d4) | 0x200;
    iVar6 = *(int64_t *)(*(int64_t *)(in_RDX + 2) + 0x6d0);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea0de;
        iVar6 = func_0x0001802231e0(iVar6, 0x1804b74f8, 0x228);
        *(int64_t *)(iVar5 + 0x5f0) = iVar6;
        if (iVar6 == 0) {
            uVar10 = 0x229;
            goto code_r0x0001801ea20d;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea237;
    iVar3 = func_0x0001801e3a50(iVar5);
    if (iVar3 != 0) {
        uVar10 = *(undefined8 *)(in_RCX + 0x38);
        uVar7 = *(undefined8 *)(iVar5 + 0x3d0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea253;
        fcn.1801fb900(uVar7, uVar10);
        return iVar5;
    }
    uVar10 = 0x233;
code_r0x0001801ea20d:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea21c;
    fcn.180224990(iVar5, 0x1804b74f8, uVar10);
    return 0;
}

// ============================================================
// Function: FUN_1801ea1e7
// Address: 0x1801ea1e7
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel

int64_t fcn.1801ea030(int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                     int64_t arg_88h)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int32_t *piVar8;
    int64_t in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBP;
    int32_t *piVar9;
    undefined8 in_R8;
    undefined8 uVar10;
    undefined4 in_R9D;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ea043;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    piVar9 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&var_10h + iVar4) = *(undefined8 *)(in_RCX + 0x80);
    *(undefined8 *)((int64_t)&var_18h + iVar4) = *(undefined8 *)(in_RCX + 0x88);
    *(int64_t *)((int64_t)&var_8h + iVar4) = in_RCX;
    *(undefined4 *)(&stack0x0000003c + iVar4) = *(undefined4 *)((int64_t)&arg_88h + iVar4);
    *(undefined8 *)((int64_t)&arg_28h + iVar4 + 4) = 0;
    *(undefined8 *)(&stack0x00000034 + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = 0;
    *(undefined4 *)((int64_t)&arg_28h + iVar4) = in_R9D;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = in_R8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea099;
    iVar5 = func_0x0001801e37b0((int64_t)&var_8h + iVar4);
    if (iVar5 == 0) {
        return 0;
    }
    if (in_RDX == (int32_t *)0x0) {
        pcVar1 = *(code **)(in_RCX + 0x18);
        in_RDX = piVar9;
        if (pcVar1 != (code *)0x0) {
            uVar10 = *(undefined8 *)(in_RCX + 0x20);
            *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea117;
            iVar6 = (*pcVar1)(iVar5, uVar10);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_R13;
                iVar2 = *(int64_t *)(in_RCX + 0x20);
                if (*(int64_t *)(iVar6 + 0x78) == 0) {
                    uVar10 = *(undefined8 *)(in_RCX + 0x28);
                    *(undefined8 *)((int64_t)&arg_78h + iVar4) = unaff_R14;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea153;
                    uVar7 = func_0x00018019a2d0();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea161;
                    in_RDX = (int32_t *)func_0x000180196080(uVar10, iVar6, uVar7);
                    *(int32_t **)(iVar6 + 0x78) = in_RDX;
                    if (in_RDX != (int32_t *)0x0) {
                        piVar8 = in_RDX;
                        if (*in_RDX == 0) {
code_r0x0001801ea18c:
                            if (iVar2 != 0) {
                                iVar2 = *(int64_t *)(iVar2 + 8);
                                pcVar1 = *(code **)(iVar2 + 0x220);
                                if (pcVar1 != (code *)0x0) {
                                    uVar10 = *(undefined8 *)(iVar2 + 0x228);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea1ad;
                                    iVar3 = (*pcVar1)(iVar2, iVar6, uVar10);
                                    if (iVar3 == 0) goto code_r0x0001801ea1d7;
                                }
                            }
                            piVar8[0x58] = piVar8[0x58] | 0x6000;
                            *(uint64_t *)(piVar8 + 0x26a) = *(uint64_t *)(piVar8 + 0x26a) & 0x3df6ffb85;
                            piVar8[0x2eb] = 0;
                            goto code_r0x0001801ea1f7;
                        }
                        if ((char)*in_RDX < '\0') {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea184;
                            piVar8 = (int32_t *)func_0x0001801bda50(in_RDX);
                            if (piVar8 != (int32_t *)0x0) goto code_r0x0001801ea18c;
                        }
                    }
code_r0x0001801ea1d7:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea1df;
                    func_0x000180193500(iVar6);
                    in_RDX = piVar9;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea13d;
                    func_0x000180193500(iVar6);
                }
            }
        }
code_r0x0001801ea1f7:
        *(int32_t **)(iVar5 + 0x30) = in_RDX;
        if (in_RDX == (int32_t *)0x0) {
            uVar10 = 0x21e;
            goto code_r0x0001801ea20d;
        }
    } else {
        *(int32_t **)(iVar5 + 0x30) = in_RDX;
    }
    *(uint32_t *)(iVar5 + 0x5d4) = *(uint32_t *)(iVar5 + 0x5d4) | 0x200;
    iVar6 = *(int64_t *)(*(int64_t *)(in_RDX + 2) + 0x6d0);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea0de;
        iVar6 = func_0x0001802231e0(iVar6, 0x1804b74f8, 0x228);
        *(int64_t *)(iVar5 + 0x5f0) = iVar6;
        if (iVar6 == 0) {
            uVar10 = 0x229;
            goto code_r0x0001801ea20d;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea237;
    iVar3 = func_0x0001801e3a50(iVar5);
    if (iVar3 != 0) {
        uVar10 = *(undefined8 *)(in_RCX + 0x38);
        uVar7 = *(undefined8 *)(iVar5 + 0x3d0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea253;
        fcn.1801fb900(uVar7, uVar10);
        return iVar5;
    }
    uVar10 = 0x233;
code_r0x0001801ea20d:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea21c;
    fcn.180224990(iVar5, 0x1804b74f8, uVar10);
    return 0;
}

// ============================================================
// Function: FUN_1801ea1ef
// Address: 0x1801ea1ef
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel

int64_t fcn.1801ea030(int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                     int64_t arg_88h)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int32_t *piVar8;
    int64_t in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBP;
    int32_t *piVar9;
    undefined8 in_R8;
    undefined8 uVar10;
    undefined4 in_R9D;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ea043;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    piVar9 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&var_10h + iVar4) = *(undefined8 *)(in_RCX + 0x80);
    *(undefined8 *)((int64_t)&var_18h + iVar4) = *(undefined8 *)(in_RCX + 0x88);
    *(int64_t *)((int64_t)&var_8h + iVar4) = in_RCX;
    *(undefined4 *)(&stack0x0000003c + iVar4) = *(undefined4 *)((int64_t)&arg_88h + iVar4);
    *(undefined8 *)((int64_t)&arg_28h + iVar4 + 4) = 0;
    *(undefined8 *)(&stack0x00000034 + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = 0;
    *(undefined4 *)((int64_t)&arg_28h + iVar4) = in_R9D;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = in_R8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea099;
    iVar5 = func_0x0001801e37b0((int64_t)&var_8h + iVar4);
    if (iVar5 == 0) {
        return 0;
    }
    if (in_RDX == (int32_t *)0x0) {
        pcVar1 = *(code **)(in_RCX + 0x18);
        in_RDX = piVar9;
        if (pcVar1 != (code *)0x0) {
            uVar10 = *(undefined8 *)(in_RCX + 0x20);
            *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea117;
            iVar6 = (*pcVar1)(iVar5, uVar10);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_R13;
                iVar2 = *(int64_t *)(in_RCX + 0x20);
                if (*(int64_t *)(iVar6 + 0x78) == 0) {
                    uVar10 = *(undefined8 *)(in_RCX + 0x28);
                    *(undefined8 *)((int64_t)&arg_78h + iVar4) = unaff_R14;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea153;
                    uVar7 = func_0x00018019a2d0();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea161;
                    in_RDX = (int32_t *)func_0x000180196080(uVar10, iVar6, uVar7);
                    *(int32_t **)(iVar6 + 0x78) = in_RDX;
                    if (in_RDX != (int32_t *)0x0) {
                        piVar8 = in_RDX;
                        if (*in_RDX == 0) {
code_r0x0001801ea18c:
                            if (iVar2 != 0) {
                                iVar2 = *(int64_t *)(iVar2 + 8);
                                pcVar1 = *(code **)(iVar2 + 0x220);
                                if (pcVar1 != (code *)0x0) {
                                    uVar10 = *(undefined8 *)(iVar2 + 0x228);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea1ad;
                                    iVar3 = (*pcVar1)(iVar2, iVar6, uVar10);
                                    if (iVar3 == 0) goto code_r0x0001801ea1d7;
                                }
                            }
                            piVar8[0x58] = piVar8[0x58] | 0x6000;
                            *(uint64_t *)(piVar8 + 0x26a) = *(uint64_t *)(piVar8 + 0x26a) & 0x3df6ffb85;
                            piVar8[0x2eb] = 0;
                            goto code_r0x0001801ea1f7;
                        }
                        if ((char)*in_RDX < '\0') {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea184;
                            piVar8 = (int32_t *)func_0x0001801bda50(in_RDX);
                            if (piVar8 != (int32_t *)0x0) goto code_r0x0001801ea18c;
                        }
                    }
code_r0x0001801ea1d7:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea1df;
                    func_0x000180193500(iVar6);
                    in_RDX = piVar9;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea13d;
                    func_0x000180193500(iVar6);
                }
            }
        }
code_r0x0001801ea1f7:
        *(int32_t **)(iVar5 + 0x30) = in_RDX;
        if (in_RDX == (int32_t *)0x0) {
            uVar10 = 0x21e;
            goto code_r0x0001801ea20d;
        }
    } else {
        *(int32_t **)(iVar5 + 0x30) = in_RDX;
    }
    *(uint32_t *)(iVar5 + 0x5d4) = *(uint32_t *)(iVar5 + 0x5d4) | 0x200;
    iVar6 = *(int64_t *)(*(int64_t *)(in_RDX + 2) + 0x6d0);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea0de;
        iVar6 = func_0x0001802231e0(iVar6, 0x1804b74f8, 0x228);
        *(int64_t *)(iVar5 + 0x5f0) = iVar6;
        if (iVar6 == 0) {
            uVar10 = 0x229;
            goto code_r0x0001801ea20d;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea237;
    iVar3 = func_0x0001801e3a50(iVar5);
    if (iVar3 != 0) {
        uVar10 = *(undefined8 *)(in_RCX + 0x38);
        uVar7 = *(undefined8 *)(iVar5 + 0x3d0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea253;
        fcn.1801fb900(uVar7, uVar10);
        return iVar5;
    }
    uVar10 = 0x233;
code_r0x0001801ea20d:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea21c;
    fcn.180224990(iVar5, 0x1804b74f8, uVar10);
    return 0;
}

// ============================================================
// Function: FUN_1801ea1f7
// Address: 0x1801ea1f7
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel

int64_t fcn.1801ea030(int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                     int64_t arg_88h)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int32_t *piVar8;
    int64_t in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBP;
    int32_t *piVar9;
    undefined8 in_R8;
    undefined8 uVar10;
    undefined4 in_R9D;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801ea043;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    piVar9 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&var_10h + iVar4) = *(undefined8 *)(in_RCX + 0x80);
    *(undefined8 *)((int64_t)&var_18h + iVar4) = *(undefined8 *)(in_RCX + 0x88);
    *(int64_t *)((int64_t)&var_8h + iVar4) = in_RCX;
    *(undefined4 *)(&stack0x0000003c + iVar4) = *(undefined4 *)((int64_t)&arg_88h + iVar4);
    *(undefined8 *)((int64_t)&arg_28h + iVar4 + 4) = 0;
    *(undefined8 *)(&stack0x00000034 + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = 0;
    *(undefined4 *)((int64_t)&arg_28h + iVar4) = in_R9D;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = in_R8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea099;
    iVar5 = func_0x0001801e37b0((int64_t)&var_8h + iVar4);
    if (iVar5 == 0) {
        return 0;
    }
    if (in_RDX == (int32_t *)0x0) {
        pcVar1 = *(code **)(in_RCX + 0x18);
        in_RDX = piVar9;
        if (pcVar1 != (code *)0x0) {
            uVar10 = *(undefined8 *)(in_RCX + 0x20);
            *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea117;
            iVar6 = (*pcVar1)(iVar5, uVar10);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_R13;
                iVar2 = *(int64_t *)(in_RCX + 0x20);
                if (*(int64_t *)(iVar6 + 0x78) == 0) {
                    uVar10 = *(undefined8 *)(in_RCX + 0x28);
                    *(undefined8 *)((int64_t)&arg_78h + iVar4) = unaff_R14;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea153;
                    uVar7 = func_0x00018019a2d0();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea161;
                    in_RDX = (int32_t *)func_0x000180196080(uVar10, iVar6, uVar7);
                    *(int32_t **)(iVar6 + 0x78) = in_RDX;
                    if (in_RDX != (int32_t *)0x0) {
                        piVar8 = in_RDX;
                        if (*in_RDX == 0) {
code_r0x0001801ea18c:
                            if (iVar2 != 0) {
                                iVar2 = *(int64_t *)(iVar2 + 8);
                                pcVar1 = *(code **)(iVar2 + 0x220);
                                if (pcVar1 != (code *)0x0) {
                                    uVar10 = *(undefined8 *)(iVar2 + 0x228);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea1ad;
                                    iVar3 = (*pcVar1)(iVar2, iVar6, uVar10);
                                    if (iVar3 == 0) goto code_r0x0001801ea1d7;
                                }
                            }
                            piVar8[0x58] = piVar8[0x58] | 0x6000;
                            *(uint64_t *)(piVar8 + 0x26a) = *(uint64_t *)(piVar8 + 0x26a) & 0x3df6ffb85;
                            piVar8[0x2eb] = 0;
                            goto code_r0x0001801ea1f7;
                        }
                        if ((char)*in_RDX < '\0') {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea184;
                            piVar8 = (int32_t *)func_0x0001801bda50(in_RDX);
                            if (piVar8 != (int32_t *)0x0) goto code_r0x0001801ea18c;
                        }
                    }
code_r0x0001801ea1d7:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea1df;
                    func_0x000180193500(iVar6);
                    in_RDX = piVar9;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea13d;
                    func_0x000180193500(iVar6);
                }
            }
        }
code_r0x0001801ea1f7:
        *(int32_t **)(iVar5 + 0x30) = in_RDX;
        if (in_RDX == (int32_t *)0x0) {
            uVar10 = 0x21e;
            goto code_r0x0001801ea20d;
        }
    } else {
        *(int32_t **)(iVar5 + 0x30) = in_RDX;
    }
    *(uint32_t *)(iVar5 + 0x5d4) = *(uint32_t *)(iVar5 + 0x5d4) | 0x200;
    iVar6 = *(int64_t *)(*(int64_t *)(in_RDX + 2) + 0x6d0);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea0de;
        iVar6 = func_0x0001802231e0(iVar6, 0x1804b74f8, 0x228);
        *(int64_t *)(iVar5 + 0x5f0) = iVar6;
        if (iVar6 == 0) {
            uVar10 = 0x229;
            goto code_r0x0001801ea20d;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea237;
    iVar3 = func_0x0001801e3a50(iVar5);
    if (iVar3 != 0) {
        uVar10 = *(undefined8 *)(in_RCX + 0x38);
        uVar7 = *(undefined8 *)(iVar5 + 0x3d0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea253;
        fcn.1801fb900(uVar7, uVar10);
        return iVar5;
    }
    uVar10 = 0x233;
code_r0x0001801ea20d:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801ea21c;
    fcn.180224990(iVar5, 0x1804b74f8, uVar10);
    return 0;
}

// ============================================================
// Function: FUN_1801ea270
// Address: 0x1801ea270
// Size: 159 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_3b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ach
// WARNING: [rz-ghidra] Detected overlap for variable var_3a8h
// WARNING: [rz-ghidra] Removing arg arg_498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_448h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_440h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_397h
// WARNING: [rz-ghidra] Detected overlap for variable var_34bh
// WARNING: [rz-ghidra] Detected overlap for variable var_350h
// WARNING: [rz-ghidra] Detected overlap for variable var_34ch
// WARNING: [rz-ghidra] Detected overlap for variable var_33bh
// WARNING: [rz-ghidra] Detected overlap for variable var_337h
// WARNING: [rz-ghidra] Detected overlap for variable var_3c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_390h

void fcn.1801ea270(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined uVar1;
    undefined uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined auVar10 [16];
    undefined auVar11 [16];
    unkbyte3 Var12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined uVar17;
    int32_t iVar18;
    int32_t iVar19;
    uint32_t uVar20;
    int64_t iVar21;
    undefined8 uVar22;
    int64_t iVar23;
    int64_t *in_RCX;
    uint64_t uVar24;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_418h;
    int64_t var_408h;
    int64_t var_3c8h;
    int64_t var_3c0h;
    int64_t var_3b8h;
    undefined4 var_3b0h;
    undefined var_3ach;
    int64_t var_3abh;
    undefined4 uStack_3a3;
    undefined4 uStack_39f;
    int64_t var_39bh;
    int64_t var_390h;
    int64_t var_388h;
    int64_t var_380h;
    int64_t var_378h;
    int64_t var_368h;
    int64_t var_360h;
    int64_t var_358h;
    undefined4 var_350h;
    undefined4 var_34ch;
    int64_t var_348h;
    undefined4 uStack_33f;
    undefined var_33bh [3];
    int64_t var_338h;
    int64_t var_330h;
    int64_t var_328h;
    int64_t var_320h;
    int64_t var_318h;
    int64_t var_248h;
    int64_t var_48h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801ea28a;
    iVar21 = fcn.18045a350();
    iVar21 = -iVar21;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar21);
    var_378h = 0;
    var_3b0h = *(undefined4 *)(in_R8 + 0x2d);
    iVar23 = in_RCX[0x10];
    _var_368h = ZEXT816(0);
    var_3ach = *(undefined *)(in_R8 + 0x31);
    var_358h._0_4_ = 0;
    var_358h._4_4_ = 0;
    var_350h = 0;
    var_34ch = 0;
    var_3abh._0_3_ = 0;
    var_348h._0_1_ = 0;
    var_348h._1_4_ = 0;
    stack0xfffffffffffffcbd = SUB164(ZEXT816(0), 5);
    uStack_33f = 0;
    _var_33bh = 0;
    var_338h._1_1_ = 0;
    var_338h._2_6_ = 0;
    var_330h = 0;
    _var_328h = ZEXT816(0);
    var_3b8h._0_4_ = *(undefined4 *)(in_R8 + 0x25);
    var_3b8h._4_4_ = *(undefined4 *)(in_R8 + 0x29);
    auVar11._8_8_ = 0;
    auVar11._0_8_ = *(uint64_t *)(in_R8 + 0x1d);
    _var_3c8h = auVar11 << 0x40;
    var_3abh._3_1_ = 0;
    var_3abh._4_4_ = 0;
    uStack_3a3 = SUB164(ZEXT816(0), 5);
    uStack_39f = 0;
    var_39bh._0_4_ = 0;
    var_39bh._4_1_ = 0;
    unique0x100008d2 = 0;
    var_390h = 0;
    var_388h = 0;
    var_380h = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea303;
    iVar18 = func_0x000180200ee0(iVar23, &var_3abh);
    uVar17 = var_39bh._4_1_;
    uVar16 = (undefined4)var_39bh;
    uVar15 = uStack_39f;
    uVar14 = uStack_3a3;
    uVar13 = var_3abh._4_4_;
    uVar2 = var_3abh._3_1_;
    Var12 = (unkbyte3)var_3abh;
    if (iVar18 == 0) goto code_r0x0001801ea613;
    *(undefined8 *)(&stack0x00000498 + iVar21) = unaff_RBX;
    uVar3 = *(undefined4 *)(in_R8 + 0x18);
    *(undefined8 *)(&stack0x00000450 + iVar21) = unaff_RSI;
    uVar6 = *(undefined4 *)(in_R8 + 8);
    uVar7 = *(undefined4 *)(in_R8 + 0xc);
    uVar8 = *(undefined4 *)(in_R8 + 0x10);
    uVar9 = *(undefined4 *)(in_R8 + 0x14);
    *(undefined8 *)(&stack0x00000448 + iVar21) = unaff_RDI;
    uVar1 = *(undefined *)(in_R8 + 0x1c);
    *(undefined8 *)(&stack0x00000440 + iVar21) = unaff_R14;
    *(undefined4 *)((int64_t)&var_20h + iVar21) = uVar6;
    *(undefined4 *)((int64_t)&var_20h + iVar21 + 4) = uVar7;
    *(undefined4 *)(&stack0x00000028 + iVar21) = uVar8;
    *(undefined4 *)(&stack0x0000002c + iVar21) = uVar9;
    var_320h._0_1_ = 1;
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea357;
    uVar22 = func_0x0001802450c0();
    var_358h._0_4_ = *(undefined4 *)(&stack0x00000028 + iVar21);
    var_358h._4_4_ = *(undefined4 *)(&stack0x0000002c + iVar21);
    var_360h._0_4_ = *(undefined4 *)((int64_t)&var_20h + iVar21);
    var_360h._4_4_ = *(undefined4 *)((int64_t)&var_20h + iVar21 + 4);
    var_348h._0_1_ = uVar2;
    var_348h._1_4_ = uVar13;
    stack0xfffffffffffffcbd = uVar14;
    uStack_33f = uVar15;
    var_368h = uVar22;
    auVar10._8_8_ = 0;
    auVar10._0_8_ = var_320h;
    _var_328h = auVar10 << 0x40;
    var_34ch = CONCAT31(Var12, uVar1);
    _var_33bh = uVar16;
    var_338h._1_1_ = uVar17;
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea390;
    var_350h = uVar3;
    iVar18 = func_0x00018026bf70(in_RDX, 0, &var_330h);
    if ((iVar18 == 0) || (var_330h == 0)) {
code_r0x0001801ea5ea:
        iVar23 = var_328h;
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea3c7;
        iVar23 = fcn.1802248d0(*(int64_t *)(&stack0x00000000 + iVar21), *(int64_t *)((int64_t)&var_8h + iVar21));
        var_328h = iVar23;
        if (iVar23 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea3e3;
            iVar18 = func_0x00018026bf70(in_RDX, iVar23, &var_330h);
            if (iVar18 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea400;
                iVar18 = func_0x0001801e8b10(&var_368h, &var_248h, (int64_t)&iStackX_18 + iVar21 + -8);
                if (iVar18 != 0) {
                    iVar23 = in_RCX[0x14];
                    iVar4 = *(int64_t *)((int64_t)&iStackX_18 + iVar21 + -8);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea419;
                    iVar18 = func_0x00018020ecc0(iVar23);
                    if (0 < iVar18) {
                        iVar23 = in_RCX[0x14];
                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea430;
                        iVar19 = func_0x00018020e980(iVar23);
                        if ((0 < iVar19) &&
                           (uVar24 = (int64_t)iVar19 + 0x10 + iVar4 + (int64_t)iVar18,
                           *(uint64_t *)((int64_t)&var_20h + iVar21) = uVar24, uVar24 < 0xc6)) {
                            uVar22 = *(undefined8 *)((int64_t)&iStackX_18 + iVar21 + -8);
                            *(int64_t *)(&stack0x00000000 + iVar21) = (int64_t)&var_20h + iVar21;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea47c;
                            iVar18 = func_0x0001801e86c0(in_RCX, &var_248h, uVar22, &var_318h);
                            if ((iVar18 != 0) && (uVar24 = *(uint64_t *)((int64_t)&var_20h + iVar21), 0xf < uVar24)) {
                                var_3b0h = *(undefined4 *)(in_R8 + 0x2d);
                                var_3b8h._0_4_ = *(undefined4 *)(in_R8 + 0x25);
                                var_3b8h._4_4_ = *(undefined4 *)(in_R8 + 0x29);
                                var_3ach = *(undefined *)(in_R8 + 0x31);
                                uVar20 = (uint32_t)var_3c8h & 0xffffff04;
                                var_3c8h = 0x100000000;
                                var_3c8h._0_4_ = uVar20 | 0x8004;
                                var_378h = (int64_t)&var_318h;
                                var_3c0h._0_4_ = *(undefined4 *)(in_R8 + 0x1d);
                                var_3c0h._4_4_ = *(undefined4 *)(in_R8 + 0x21);
                                uVar22 = ((undefined8 *)*in_RCX)[1];
                                uVar5 = *(undefined8 *)*in_RCX;
                                var_380h = uVar24;
                                *(uint64_t *)(&stack0x00000000 + iVar21) = (int64_t)&var_328h + uVar24;
                                *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea4f2;
                                iVar18 = func_0x0001801f84b0(uVar5, uVar22, &var_3c8h, in_R8 + 8);
                                if (iVar18 != 0) {
                                    var_390h = var_378h;
                                    var_388h = var_380h;
                                    *(undefined8 *)((int64_t)&arg_40h + iVar21) = in_RDX;
                                    *(int64_t **)((int64_t)&arg_30h + iVar21) = &var_248h;
                                    *(undefined8 *)((int64_t)&arg_48h + iVar21) = 0;
                                    *(undefined8 *)((int64_t)&arg_50h + iVar21) = 0;
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea540;
                                    iVar18 = func_0x000180244550(&var_408h, &var_248h, 0x200, 0);
                                    if (iVar18 != 0) {
                                        uVar2 = *(undefined *)(in_R8 + 8);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea55d;
                                        iVar18 = func_0x0001801f93b0(&var_408h, uVar2, &var_3c8h, 0);
                                        if (iVar18 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea573;
                                            iVar18 = func_0x0001802442e0(&var_408h, (int64_t)&arg_38h + iVar21);
                                            if (iVar18 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea584;
                                                iVar18 = func_0x000180244200(&var_408h);
                                                if (iVar18 != 0) {
                                                    iVar23 = in_RCX[7];
                                                    *(int64_t *)((int64_t)&var_8h + iVar21) = (int64_t)&arg_58h + iVar21
                                                    ;
                                                    *(undefined8 *)(&stack0x00000000 + iVar21) = 0;
                                                    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5b1;
                                                    iVar18 = func_0x00018021af90(iVar23, (int64_t)&arg_30h + iVar21, 
                                                                                 0x28, 1);
                                                    if (iVar18 == 0) {
                                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5ba;
                                                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar21), 
                                                                      *(int64_t *)((int64_t)&var_8h + iVar21));
                                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5d2;
                                                        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar21), 
                                                                      *(int64_t *)((int64_t)&var_8h + iVar21), 
                                                                      *(int64_t *)((int64_t)&iStackX_18 + iVar21 + -8), 
                                                                      *(int64_t *)((int64_t)&iStackX_18 + iVar21), 
                                                                      *(int64_t *)((int64_t)&arg_30h + iVar21));
                                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5e8;
                                                        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar21));
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                goto code_r0x0001801ea613;
            }
            goto code_r0x0001801ea5ea;
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea603;
    fcn.180224990(iVar23, 0x1804b74f8, 0x34c);
code_r0x0001801ea613:
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea629;
    fcn.180224990(var_328h, 0x1804b74f8, 0x34c);
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea638;
    fcn.180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar21));
    return;
}

// ============================================================
// Function: FUN_1801ea30f
// Address: 0x1801ea30f
// Size: 12 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_3b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ach
// WARNING: [rz-ghidra] Detected overlap for variable var_3a8h
// WARNING: [rz-ghidra] Removing arg arg_498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_448h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_440h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_397h
// WARNING: [rz-ghidra] Detected overlap for variable var_34bh
// WARNING: [rz-ghidra] Detected overlap for variable var_350h
// WARNING: [rz-ghidra] Detected overlap for variable var_34ch
// WARNING: [rz-ghidra] Detected overlap for variable var_33bh
// WARNING: [rz-ghidra] Detected overlap for variable var_337h
// WARNING: [rz-ghidra] Detected overlap for variable var_3c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_390h

void fcn.1801ea270(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined uVar1;
    undefined uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined auVar10 [16];
    undefined auVar11 [16];
    unkbyte3 Var12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined uVar17;
    int32_t iVar18;
    int32_t iVar19;
    uint32_t uVar20;
    int64_t iVar21;
    undefined8 uVar22;
    int64_t iVar23;
    int64_t *in_RCX;
    uint64_t uVar24;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_418h;
    int64_t var_408h;
    int64_t var_3c8h;
    int64_t var_3c0h;
    int64_t var_3b8h;
    undefined4 var_3b0h;
    undefined var_3ach;
    int64_t var_3abh;
    undefined4 uStack_3a3;
    undefined4 uStack_39f;
    int64_t var_39bh;
    int64_t var_390h;
    int64_t var_388h;
    int64_t var_380h;
    int64_t var_378h;
    int64_t var_368h;
    int64_t var_360h;
    int64_t var_358h;
    undefined4 var_350h;
    undefined4 var_34ch;
    int64_t var_348h;
    undefined4 uStack_33f;
    undefined var_33bh [3];
    int64_t var_338h;
    int64_t var_330h;
    int64_t var_328h;
    int64_t var_320h;
    int64_t var_318h;
    int64_t var_248h;
    int64_t var_48h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801ea28a;
    iVar21 = fcn.18045a350();
    iVar21 = -iVar21;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar21);
    var_378h = 0;
    var_3b0h = *(undefined4 *)(in_R8 + 0x2d);
    iVar23 = in_RCX[0x10];
    _var_368h = ZEXT816(0);
    var_3ach = *(undefined *)(in_R8 + 0x31);
    var_358h._0_4_ = 0;
    var_358h._4_4_ = 0;
    var_350h = 0;
    var_34ch = 0;
    var_3abh._0_3_ = 0;
    var_348h._0_1_ = 0;
    var_348h._1_4_ = 0;
    stack0xfffffffffffffcbd = SUB164(ZEXT816(0), 5);
    uStack_33f = 0;
    _var_33bh = 0;
    var_338h._1_1_ = 0;
    var_338h._2_6_ = 0;
    var_330h = 0;
    _var_328h = ZEXT816(0);
    var_3b8h._0_4_ = *(undefined4 *)(in_R8 + 0x25);
    var_3b8h._4_4_ = *(undefined4 *)(in_R8 + 0x29);
    auVar11._8_8_ = 0;
    auVar11._0_8_ = *(uint64_t *)(in_R8 + 0x1d);
    _var_3c8h = auVar11 << 0x40;
    var_3abh._3_1_ = 0;
    var_3abh._4_4_ = 0;
    uStack_3a3 = SUB164(ZEXT816(0), 5);
    uStack_39f = 0;
    var_39bh._0_4_ = 0;
    var_39bh._4_1_ = 0;
    unique0x100008d2 = 0;
    var_390h = 0;
    var_388h = 0;
    var_380h = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea303;
    iVar18 = func_0x000180200ee0(iVar23, &var_3abh);
    uVar17 = var_39bh._4_1_;
    uVar16 = (undefined4)var_39bh;
    uVar15 = uStack_39f;
    uVar14 = uStack_3a3;
    uVar13 = var_3abh._4_4_;
    uVar2 = var_3abh._3_1_;
    Var12 = (unkbyte3)var_3abh;
    if (iVar18 == 0) goto code_r0x0001801ea613;
    *(undefined8 *)(&stack0x00000498 + iVar21) = unaff_RBX;
    uVar3 = *(undefined4 *)(in_R8 + 0x18);
    *(undefined8 *)(&stack0x00000450 + iVar21) = unaff_RSI;
    uVar6 = *(undefined4 *)(in_R8 + 8);
    uVar7 = *(undefined4 *)(in_R8 + 0xc);
    uVar8 = *(undefined4 *)(in_R8 + 0x10);
    uVar9 = *(undefined4 *)(in_R8 + 0x14);
    *(undefined8 *)(&stack0x00000448 + iVar21) = unaff_RDI;
    uVar1 = *(undefined *)(in_R8 + 0x1c);
    *(undefined8 *)(&stack0x00000440 + iVar21) = unaff_R14;
    *(undefined4 *)((int64_t)&var_20h + iVar21) = uVar6;
    *(undefined4 *)((int64_t)&var_20h + iVar21 + 4) = uVar7;
    *(undefined4 *)(&stack0x00000028 + iVar21) = uVar8;
    *(undefined4 *)(&stack0x0000002c + iVar21) = uVar9;
    var_320h._0_1_ = 1;
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea357;
    uVar22 = func_0x0001802450c0();
    var_358h._0_4_ = *(undefined4 *)(&stack0x00000028 + iVar21);
    var_358h._4_4_ = *(undefined4 *)(&stack0x0000002c + iVar21);
    var_360h._0_4_ = *(undefined4 *)((int64_t)&var_20h + iVar21);
    var_360h._4_4_ = *(undefined4 *)((int64_t)&var_20h + iVar21 + 4);
    var_348h._0_1_ = uVar2;
    var_348h._1_4_ = uVar13;
    stack0xfffffffffffffcbd = uVar14;
    uStack_33f = uVar15;
    var_368h = uVar22;
    auVar10._8_8_ = 0;
    auVar10._0_8_ = var_320h;
    _var_328h = auVar10 << 0x40;
    var_34ch = CONCAT31(Var12, uVar1);
    _var_33bh = uVar16;
    var_338h._1_1_ = uVar17;
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea390;
    var_350h = uVar3;
    iVar18 = func_0x00018026bf70(in_RDX, 0, &var_330h);
    if ((iVar18 == 0) || (var_330h == 0)) {
code_r0x0001801ea5ea:
        iVar23 = var_328h;
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea3c7;
        iVar23 = fcn.1802248d0(*(int64_t *)(&stack0x00000000 + iVar21), *(int64_t *)((int64_t)&var_8h + iVar21));
        var_328h = iVar23;
        if (iVar23 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea3e3;
            iVar18 = func_0x00018026bf70(in_RDX, iVar23, &var_330h);
            if (iVar18 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea400;
                iVar18 = func_0x0001801e8b10(&var_368h, &var_248h, (int64_t)&iStackX_18 + iVar21 + -8);
                if (iVar18 != 0) {
                    iVar23 = in_RCX[0x14];
                    iVar4 = *(int64_t *)((int64_t)&iStackX_18 + iVar21 + -8);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea419;
                    iVar18 = func_0x00018020ecc0(iVar23);
                    if (0 < iVar18) {
                        iVar23 = in_RCX[0x14];
                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea430;
                        iVar19 = func_0x00018020e980(iVar23);
                        if ((0 < iVar19) &&
                           (uVar24 = (int64_t)iVar19 + 0x10 + iVar4 + (int64_t)iVar18,
                           *(uint64_t *)((int64_t)&var_20h + iVar21) = uVar24, uVar24 < 0xc6)) {
                            uVar22 = *(undefined8 *)((int64_t)&iStackX_18 + iVar21 + -8);
                            *(int64_t *)(&stack0x00000000 + iVar21) = (int64_t)&var_20h + iVar21;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea47c;
                            iVar18 = func_0x0001801e86c0(in_RCX, &var_248h, uVar22, &var_318h);
                            if ((iVar18 != 0) && (uVar24 = *(uint64_t *)((int64_t)&var_20h + iVar21), 0xf < uVar24)) {
                                var_3b0h = *(undefined4 *)(in_R8 + 0x2d);
                                var_3b8h._0_4_ = *(undefined4 *)(in_R8 + 0x25);
                                var_3b8h._4_4_ = *(undefined4 *)(in_R8 + 0x29);
                                var_3ach = *(undefined *)(in_R8 + 0x31);
                                uVar20 = (uint32_t)var_3c8h & 0xffffff04;
                                var_3c8h = 0x100000000;
                                var_3c8h._0_4_ = uVar20 | 0x8004;
                                var_378h = (int64_t)&var_318h;
                                var_3c0h._0_4_ = *(undefined4 *)(in_R8 + 0x1d);
                                var_3c0h._4_4_ = *(undefined4 *)(in_R8 + 0x21);
                                uVar22 = ((undefined8 *)*in_RCX)[1];
                                uVar5 = *(undefined8 *)*in_RCX;
                                var_380h = uVar24;
                                *(uint64_t *)(&stack0x00000000 + iVar21) = (int64_t)&var_328h + uVar24;
                                *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea4f2;
                                iVar18 = func_0x0001801f84b0(uVar5, uVar22, &var_3c8h, in_R8 + 8);
                                if (iVar18 != 0) {
                                    var_390h = var_378h;
                                    var_388h = var_380h;
                                    *(undefined8 *)((int64_t)&arg_40h + iVar21) = in_RDX;
                                    *(int64_t **)((int64_t)&arg_30h + iVar21) = &var_248h;
                                    *(undefined8 *)((int64_t)&arg_48h + iVar21) = 0;
                                    *(undefined8 *)((int64_t)&arg_50h + iVar21) = 0;
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea540;
                                    iVar18 = func_0x000180244550(&var_408h, &var_248h, 0x200, 0);
                                    if (iVar18 != 0) {
                                        uVar2 = *(undefined *)(in_R8 + 8);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea55d;
                                        iVar18 = func_0x0001801f93b0(&var_408h, uVar2, &var_3c8h, 0);
                                        if (iVar18 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea573;
                                            iVar18 = func_0x0001802442e0(&var_408h, (int64_t)&arg_38h + iVar21);
                                            if (iVar18 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea584;
                                                iVar18 = func_0x000180244200(&var_408h);
                                                if (iVar18 != 0) {
                                                    iVar23 = in_RCX[7];
                                                    *(int64_t *)((int64_t)&var_8h + iVar21) = (int64_t)&arg_58h + iVar21
                                                    ;
                                                    *(undefined8 *)(&stack0x00000000 + iVar21) = 0;
                                                    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5b1;
                                                    iVar18 = func_0x00018021af90(iVar23, (int64_t)&arg_30h + iVar21, 
                                                                                 0x28, 1);
                                                    if (iVar18 == 0) {
                                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5ba;
                                                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar21), 
                                                                      *(int64_t *)((int64_t)&var_8h + iVar21));
                                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5d2;
                                                        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar21), 
                                                                      *(int64_t *)((int64_t)&var_8h + iVar21), 
                                                                      *(int64_t *)((int64_t)&iStackX_18 + iVar21 + -8), 
                                                                      *(int64_t *)((int64_t)&iStackX_18 + iVar21), 
                                                                      *(int64_t *)((int64_t)&arg_30h + iVar21));
                                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5e8;
                                                        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar21));
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                goto code_r0x0001801ea613;
            }
            goto code_r0x0001801ea5ea;
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea603;
    fcn.180224990(iVar23, 0x1804b74f8, 0x34c);
code_r0x0001801ea613:
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea629;
    fcn.180224990(var_328h, 0x1804b74f8, 0x34c);
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea638;
    fcn.180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar21));
    return;
}

// ============================================================
// Function: FUN_1801ea31b
// Address: 0x1801ea31b
// Size: 141 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_3b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ach
// WARNING: [rz-ghidra] Detected overlap for variable var_3a8h
// WARNING: [rz-ghidra] Removing arg arg_498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_448h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_440h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_397h
// WARNING: [rz-ghidra] Detected overlap for variable var_34bh
// WARNING: [rz-ghidra] Detected overlap for variable var_350h
// WARNING: [rz-ghidra] Detected overlap for variable var_34ch
// WARNING: [rz-ghidra] Detected overlap for variable var_33bh
// WARNING: [rz-ghidra] Detected overlap for variable var_337h
// WARNING: [rz-ghidra] Detected overlap for variable var_3c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_390h

void fcn.1801ea270(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined uVar1;
    undefined uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined auVar10 [16];
    undefined auVar11 [16];
    unkbyte3 Var12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined uVar17;
    int32_t iVar18;
    int32_t iVar19;
    uint32_t uVar20;
    int64_t iVar21;
    undefined8 uVar22;
    int64_t iVar23;
    int64_t *in_RCX;
    uint64_t uVar24;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_418h;
    int64_t var_408h;
    int64_t var_3c8h;
    int64_t var_3c0h;
    int64_t var_3b8h;
    undefined4 var_3b0h;
    undefined var_3ach;
    int64_t var_3abh;
    undefined4 uStack_3a3;
    undefined4 uStack_39f;
    int64_t var_39bh;
    int64_t var_390h;
    int64_t var_388h;
    int64_t var_380h;
    int64_t var_378h;
    int64_t var_368h;
    int64_t var_360h;
    int64_t var_358h;
    undefined4 var_350h;
    undefined4 var_34ch;
    int64_t var_348h;
    undefined4 uStack_33f;
    undefined var_33bh [3];
    int64_t var_338h;
    int64_t var_330h;
    int64_t var_328h;
    int64_t var_320h;
    int64_t var_318h;
    int64_t var_248h;
    int64_t var_48h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801ea28a;
    iVar21 = fcn.18045a350();
    iVar21 = -iVar21;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar21);
    var_378h = 0;
    var_3b0h = *(undefined4 *)(in_R8 + 0x2d);
    iVar23 = in_RCX[0x10];
    _var_368h = ZEXT816(0);
    var_3ach = *(undefined *)(in_R8 + 0x31);
    var_358h._0_4_ = 0;
    var_358h._4_4_ = 0;
    var_350h = 0;
    var_34ch = 0;
    var_3abh._0_3_ = 0;
    var_348h._0_1_ = 0;
    var_348h._1_4_ = 0;
    stack0xfffffffffffffcbd = SUB164(ZEXT816(0), 5);
    uStack_33f = 0;
    _var_33bh = 0;
    var_338h._1_1_ = 0;
    var_338h._2_6_ = 0;
    var_330h = 0;
    _var_328h = ZEXT816(0);
    var_3b8h._0_4_ = *(undefined4 *)(in_R8 + 0x25);
    var_3b8h._4_4_ = *(undefined4 *)(in_R8 + 0x29);
    auVar11._8_8_ = 0;
    auVar11._0_8_ = *(uint64_t *)(in_R8 + 0x1d);
    _var_3c8h = auVar11 << 0x40;
    var_3abh._3_1_ = 0;
    var_3abh._4_4_ = 0;
    uStack_3a3 = SUB164(ZEXT816(0), 5);
    uStack_39f = 0;
    var_39bh._0_4_ = 0;
    var_39bh._4_1_ = 0;
    unique0x100008d2 = 0;
    var_390h = 0;
    var_388h = 0;
    var_380h = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea303;
    iVar18 = func_0x000180200ee0(iVar23, &var_3abh);
    uVar17 = var_39bh._4_1_;
    uVar16 = (undefined4)var_39bh;
    uVar15 = uStack_39f;
    uVar14 = uStack_3a3;
    uVar13 = var_3abh._4_4_;
    uVar2 = var_3abh._3_1_;
    Var12 = (unkbyte3)var_3abh;
    if (iVar18 == 0) goto code_r0x0001801ea613;
    *(undefined8 *)(&stack0x00000498 + iVar21) = unaff_RBX;
    uVar3 = *(undefined4 *)(in_R8 + 0x18);
    *(undefined8 *)(&stack0x00000450 + iVar21) = unaff_RSI;
    uVar6 = *(undefined4 *)(in_R8 + 8);
    uVar7 = *(undefined4 *)(in_R8 + 0xc);
    uVar8 = *(undefined4 *)(in_R8 + 0x10);
    uVar9 = *(undefined4 *)(in_R8 + 0x14);
    *(undefined8 *)(&stack0x00000448 + iVar21) = unaff_RDI;
    uVar1 = *(undefined *)(in_R8 + 0x1c);
    *(undefined8 *)(&stack0x00000440 + iVar21) = unaff_R14;
    *(undefined4 *)((int64_t)&var_20h + iVar21) = uVar6;
    *(undefined4 *)((int64_t)&var_20h + iVar21 + 4) = uVar7;
    *(undefined4 *)(&stack0x00000028 + iVar21) = uVar8;
    *(undefined4 *)(&stack0x0000002c + iVar21) = uVar9;
    var_320h._0_1_ = 1;
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea357;
    uVar22 = func_0x0001802450c0();
    var_358h._0_4_ = *(undefined4 *)(&stack0x00000028 + iVar21);
    var_358h._4_4_ = *(undefined4 *)(&stack0x0000002c + iVar21);
    var_360h._0_4_ = *(undefined4 *)((int64_t)&var_20h + iVar21);
    var_360h._4_4_ = *(undefined4 *)((int64_t)&var_20h + iVar21 + 4);
    var_348h._0_1_ = uVar2;
    var_348h._1_4_ = uVar13;
    stack0xfffffffffffffcbd = uVar14;
    uStack_33f = uVar15;
    var_368h = uVar22;
    auVar10._8_8_ = 0;
    auVar10._0_8_ = var_320h;
    _var_328h = auVar10 << 0x40;
    var_34ch = CONCAT31(Var12, uVar1);
    _var_33bh = uVar16;
    var_338h._1_1_ = uVar17;
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea390;
    var_350h = uVar3;
    iVar18 = func_0x00018026bf70(in_RDX, 0, &var_330h);
    if ((iVar18 == 0) || (var_330h == 0)) {
code_r0x0001801ea5ea:
        iVar23 = var_328h;
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea3c7;
        iVar23 = fcn.1802248d0(*(int64_t *)(&stack0x00000000 + iVar21), *(int64_t *)((int64_t)&var_8h + iVar21));
        var_328h = iVar23;
        if (iVar23 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea3e3;
            iVar18 = func_0x00018026bf70(in_RDX, iVar23, &var_330h);
            if (iVar18 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea400;
                iVar18 = func_0x0001801e8b10(&var_368h, &var_248h, (int64_t)&iStackX_18 + iVar21 + -8);
                if (iVar18 != 0) {
                    iVar23 = in_RCX[0x14];
                    iVar4 = *(int64_t *)((int64_t)&iStackX_18 + iVar21 + -8);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea419;
                    iVar18 = func_0x00018020ecc0(iVar23);
                    if (0 < iVar18) {
                        iVar23 = in_RCX[0x14];
                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea430;
                        iVar19 = func_0x00018020e980(iVar23);
                        if ((0 < iVar19) &&
                           (uVar24 = (int64_t)iVar19 + 0x10 + iVar4 + (int64_t)iVar18,
                           *(uint64_t *)((int64_t)&var_20h + iVar21) = uVar24, uVar24 < 0xc6)) {
                            uVar22 = *(undefined8 *)((int64_t)&iStackX_18 + iVar21 + -8);
                            *(int64_t *)(&stack0x00000000 + iVar21) = (int64_t)&var_20h + iVar21;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea47c;
                            iVar18 = func_0x0001801e86c0(in_RCX, &var_248h, uVar22, &var_318h);
                            if ((iVar18 != 0) && (uVar24 = *(uint64_t *)((int64_t)&var_20h + iVar21), 0xf < uVar24)) {
                                var_3b0h = *(undefined4 *)(in_R8 + 0x2d);
                                var_3b8h._0_4_ = *(undefined4 *)(in_R8 + 0x25);
                                var_3b8h._4_4_ = *(undefined4 *)(in_R8 + 0x29);
                                var_3ach = *(undefined *)(in_R8 + 0x31);
                                uVar20 = (uint32_t)var_3c8h & 0xffffff04;
                                var_3c8h = 0x100000000;
                                var_3c8h._0_4_ = uVar20 | 0x8004;
                                var_378h = (int64_t)&var_318h;
                                var_3c0h._0_4_ = *(undefined4 *)(in_R8 + 0x1d);
                                var_3c0h._4_4_ = *(undefined4 *)(in_R8 + 0x21);
                                uVar22 = ((undefined8 *)*in_RCX)[1];
                                uVar5 = *(undefined8 *)*in_RCX;
                                var_380h = uVar24;
                                *(uint64_t *)(&stack0x00000000 + iVar21) = (int64_t)&var_328h + uVar24;
                                *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea4f2;
                                iVar18 = func_0x0001801f84b0(uVar5, uVar22, &var_3c8h, in_R8 + 8);
                                if (iVar18 != 0) {
                                    var_390h = var_378h;
                                    var_388h = var_380h;
                                    *(undefined8 *)((int64_t)&arg_40h + iVar21) = in_RDX;
                                    *(int64_t **)((int64_t)&arg_30h + iVar21) = &var_248h;
                                    *(undefined8 *)((int64_t)&arg_48h + iVar21) = 0;
                                    *(undefined8 *)((int64_t)&arg_50h + iVar21) = 0;
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea540;
                                    iVar18 = func_0x000180244550(&var_408h, &var_248h, 0x200, 0);
                                    if (iVar18 != 0) {
                                        uVar2 = *(undefined *)(in_R8 + 8);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea55d;
                                        iVar18 = func_0x0001801f93b0(&var_408h, uVar2, &var_3c8h, 0);
                                        if (iVar18 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea573;
                                            iVar18 = func_0x0001802442e0(&var_408h, (int64_t)&arg_38h + iVar21);
                                            if (iVar18 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea584;
                                                iVar18 = func_0x000180244200(&var_408h);
                                                if (iVar18 != 0) {
                                                    iVar23 = in_RCX[7];
                                                    *(int64_t *)((int64_t)&var_8h + iVar21) = (int64_t)&arg_58h + iVar21
                                                    ;
                                                    *(undefined8 *)(&stack0x00000000 + iVar21) = 0;
                                                    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5b1;
                                                    iVar18 = func_0x00018021af90(iVar23, (int64_t)&arg_30h + iVar21, 
                                                                                 0x28, 1);
                                                    if (iVar18 == 0) {
                                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5ba;
                                                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar21), 
                                                                      *(int64_t *)((int64_t)&var_8h + iVar21));
                                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5d2;
                                                        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar21), 
                                                                      *(int64_t *)((int64_t)&var_8h + iVar21), 
                                                                      *(int64_t *)((int64_t)&iStackX_18 + iVar21 + -8), 
                                                                      *(int64_t *)((int64_t)&iStackX_18 + iVar21), 
                                                                      *(int64_t *)((int64_t)&arg_30h + iVar21));
                                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5e8;
                                                        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar21));
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                goto code_r0x0001801ea613;
            }
            goto code_r0x0001801ea5ea;
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea603;
    fcn.180224990(iVar23, 0x1804b74f8, 0x34c);
code_r0x0001801ea613:
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea629;
    fcn.180224990(var_328h, 0x1804b74f8, 0x34c);
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea638;
    fcn.180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar21));
    return;
}

// ============================================================
// Function: FUN_1801ea3a8
// Address: 0x1801ea3a8
// Size: 619 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_3b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ach
// WARNING: [rz-ghidra] Detected overlap for variable var_3a8h
// WARNING: [rz-ghidra] Removing arg arg_498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_448h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_440h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_397h
// WARNING: [rz-ghidra] Detected overlap for variable var_34bh
// WARNING: [rz-ghidra] Detected overlap for variable var_350h
// WARNING: [rz-ghidra] Detected overlap for variable var_34ch
// WARNING: [rz-ghidra] Detected overlap for variable var_33bh
// WARNING: [rz-ghidra] Detected overlap for variable var_337h
// WARNING: [rz-ghidra] Detected overlap for variable var_3c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_390h

void fcn.1801ea270(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined uVar1;
    undefined uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined auVar10 [16];
    undefined auVar11 [16];
    unkbyte3 Var12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined uVar17;
    int32_t iVar18;
    int32_t iVar19;
    uint32_t uVar20;
    int64_t iVar21;
    undefined8 uVar22;
    int64_t iVar23;
    int64_t *in_RCX;
    uint64_t uVar24;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_418h;
    int64_t var_408h;
    int64_t var_3c8h;
    int64_t var_3c0h;
    int64_t var_3b8h;
    undefined4 var_3b0h;
    undefined var_3ach;
    int64_t var_3abh;
    undefined4 uStack_3a3;
    undefined4 uStack_39f;
    int64_t var_39bh;
    int64_t var_390h;
    int64_t var_388h;
    int64_t var_380h;
    int64_t var_378h;
    int64_t var_368h;
    int64_t var_360h;
    int64_t var_358h;
    undefined4 var_350h;
    undefined4 var_34ch;
    int64_t var_348h;
    undefined4 uStack_33f;
    undefined var_33bh [3];
    int64_t var_338h;
    int64_t var_330h;
    int64_t var_328h;
    int64_t var_320h;
    int64_t var_318h;
    int64_t var_248h;
    int64_t var_48h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801ea28a;
    iVar21 = fcn.18045a350();
    iVar21 = -iVar21;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar21);
    var_378h = 0;
    var_3b0h = *(undefined4 *)(in_R8 + 0x2d);
    iVar23 = in_RCX[0x10];
    _var_368h = ZEXT816(0);
    var_3ach = *(undefined *)(in_R8 + 0x31);
    var_358h._0_4_ = 0;
    var_358h._4_4_ = 0;
    var_350h = 0;
    var_34ch = 0;
    var_3abh._0_3_ = 0;
    var_348h._0_1_ = 0;
    var_348h._1_4_ = 0;
    stack0xfffffffffffffcbd = SUB164(ZEXT816(0), 5);
    uStack_33f = 0;
    _var_33bh = 0;
    var_338h._1_1_ = 0;
    var_338h._2_6_ = 0;
    var_330h = 0;
    _var_328h = ZEXT816(0);
    var_3b8h._0_4_ = *(undefined4 *)(in_R8 + 0x25);
    var_3b8h._4_4_ = *(undefined4 *)(in_R8 + 0x29);
    auVar11._8_8_ = 0;
    auVar11._0_8_ = *(uint64_t *)(in_R8 + 0x1d);
    _var_3c8h = auVar11 << 0x40;
    var_3abh._3_1_ = 0;
    var_3abh._4_4_ = 0;
    uStack_3a3 = SUB164(ZEXT816(0), 5);
    uStack_39f = 0;
    var_39bh._0_4_ = 0;
    var_39bh._4_1_ = 0;
    unique0x100008d2 = 0;
    var_390h = 0;
    var_388h = 0;
    var_380h = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea303;
    iVar18 = func_0x000180200ee0(iVar23, &var_3abh);
    uVar17 = var_39bh._4_1_;
    uVar16 = (undefined4)var_39bh;
    uVar15 = uStack_39f;
    uVar14 = uStack_3a3;
    uVar13 = var_3abh._4_4_;
    uVar2 = var_3abh._3_1_;
    Var12 = (unkbyte3)var_3abh;
    if (iVar18 == 0) goto code_r0x0001801ea613;
    *(undefined8 *)(&stack0x00000498 + iVar21) = unaff_RBX;
    uVar3 = *(undefined4 *)(in_R8 + 0x18);
    *(undefined8 *)(&stack0x00000450 + iVar21) = unaff_RSI;
    uVar6 = *(undefined4 *)(in_R8 + 8);
    uVar7 = *(undefined4 *)(in_R8 + 0xc);
    uVar8 = *(undefined4 *)(in_R8 + 0x10);
    uVar9 = *(undefined4 *)(in_R8 + 0x14);
    *(undefined8 *)(&stack0x00000448 + iVar21) = unaff_RDI;
    uVar1 = *(undefined *)(in_R8 + 0x1c);
    *(undefined8 *)(&stack0x00000440 + iVar21) = unaff_R14;
    *(undefined4 *)((int64_t)&var_20h + iVar21) = uVar6;
    *(undefined4 *)((int64_t)&var_20h + iVar21 + 4) = uVar7;
    *(undefined4 *)(&stack0x00000028 + iVar21) = uVar8;
    *(undefined4 *)(&stack0x0000002c + iVar21) = uVar9;
    var_320h._0_1_ = 1;
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea357;
    uVar22 = func_0x0001802450c0();
    var_358h._0_4_ = *(undefined4 *)(&stack0x00000028 + iVar21);
    var_358h._4_4_ = *(undefined4 *)(&stack0x0000002c + iVar21);
    var_360h._0_4_ = *(undefined4 *)((int64_t)&var_20h + iVar21);
    var_360h._4_4_ = *(undefined4 *)((int64_t)&var_20h + iVar21 + 4);
    var_348h._0_1_ = uVar2;
    var_348h._1_4_ = uVar13;
    stack0xfffffffffffffcbd = uVar14;
    uStack_33f = uVar15;
    var_368h = uVar22;
    auVar10._8_8_ = 0;
    auVar10._0_8_ = var_320h;
    _var_328h = auVar10 << 0x40;
    var_34ch = CONCAT31(Var12, uVar1);
    _var_33bh = uVar16;
    var_338h._1_1_ = uVar17;
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea390;
    var_350h = uVar3;
    iVar18 = func_0x00018026bf70(in_RDX, 0, &var_330h);
    if ((iVar18 == 0) || (var_330h == 0)) {
code_r0x0001801ea5ea:
        iVar23 = var_328h;
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea3c7;
        iVar23 = fcn.1802248d0(*(int64_t *)(&stack0x00000000 + iVar21), *(int64_t *)((int64_t)&var_8h + iVar21));
        var_328h = iVar23;
        if (iVar23 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea3e3;
            iVar18 = func_0x00018026bf70(in_RDX, iVar23, &var_330h);
            if (iVar18 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea400;
                iVar18 = func_0x0001801e8b10(&var_368h, &var_248h, (int64_t)&iStackX_18 + iVar21 + -8);
                if (iVar18 != 0) {
                    iVar23 = in_RCX[0x14];
                    iVar4 = *(int64_t *)((int64_t)&iStackX_18 + iVar21 + -8);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea419;
                    iVar18 = func_0x00018020ecc0(iVar23);
                    if (0 < iVar18) {
                        iVar23 = in_RCX[0x14];
                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea430;
                        iVar19 = func_0x00018020e980(iVar23);
                        if ((0 < iVar19) &&
                           (uVar24 = (int64_t)iVar19 + 0x10 + iVar4 + (int64_t)iVar18,
                           *(uint64_t *)((int64_t)&var_20h + iVar21) = uVar24, uVar24 < 0xc6)) {
                            uVar22 = *(undefined8 *)((int64_t)&iStackX_18 + iVar21 + -8);
                            *(int64_t *)(&stack0x00000000 + iVar21) = (int64_t)&var_20h + iVar21;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea47c;
                            iVar18 = func_0x0001801e86c0(in_RCX, &var_248h, uVar22, &var_318h);
                            if ((iVar18 != 0) && (uVar24 = *(uint64_t *)((int64_t)&var_20h + iVar21), 0xf < uVar24)) {
                                var_3b0h = *(undefined4 *)(in_R8 + 0x2d);
                                var_3b8h._0_4_ = *(undefined4 *)(in_R8 + 0x25);
                                var_3b8h._4_4_ = *(undefined4 *)(in_R8 + 0x29);
                                var_3ach = *(undefined *)(in_R8 + 0x31);
                                uVar20 = (uint32_t)var_3c8h & 0xffffff04;
                                var_3c8h = 0x100000000;
                                var_3c8h._0_4_ = uVar20 | 0x8004;
                                var_378h = (int64_t)&var_318h;
                                var_3c0h._0_4_ = *(undefined4 *)(in_R8 + 0x1d);
                                var_3c0h._4_4_ = *(undefined4 *)(in_R8 + 0x21);
                                uVar22 = ((undefined8 *)*in_RCX)[1];
                                uVar5 = *(undefined8 *)*in_RCX;
                                var_380h = uVar24;
                                *(uint64_t *)(&stack0x00000000 + iVar21) = (int64_t)&var_328h + uVar24;
                                *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea4f2;
                                iVar18 = func_0x0001801f84b0(uVar5, uVar22, &var_3c8h, in_R8 + 8);
                                if (iVar18 != 0) {
                                    var_390h = var_378h;
                                    var_388h = var_380h;
                                    *(undefined8 *)((int64_t)&arg_40h + iVar21) = in_RDX;
                                    *(int64_t **)((int64_t)&arg_30h + iVar21) = &var_248h;
                                    *(undefined8 *)((int64_t)&arg_48h + iVar21) = 0;
                                    *(undefined8 *)((int64_t)&arg_50h + iVar21) = 0;
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea540;
                                    iVar18 = func_0x000180244550(&var_408h, &var_248h, 0x200, 0);
                                    if (iVar18 != 0) {
                                        uVar2 = *(undefined *)(in_R8 + 8);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea55d;
                                        iVar18 = func_0x0001801f93b0(&var_408h, uVar2, &var_3c8h, 0);
                                        if (iVar18 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea573;
                                            iVar18 = func_0x0001802442e0(&var_408h, (int64_t)&arg_38h + iVar21);
                                            if (iVar18 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea584;
                                                iVar18 = func_0x000180244200(&var_408h);
                                                if (iVar18 != 0) {
                                                    iVar23 = in_RCX[7];
                                                    *(int64_t *)((int64_t)&var_8h + iVar21) = (int64_t)&arg_58h + iVar21
                                                    ;
                                                    *(undefined8 *)(&stack0x00000000 + iVar21) = 0;
                                                    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5b1;
                                                    iVar18 = func_0x00018021af90(iVar23, (int64_t)&arg_30h + iVar21, 
                                                                                 0x28, 1);
                                                    if (iVar18 == 0) {
                                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5ba;
                                                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar21), 
                                                                      *(int64_t *)((int64_t)&var_8h + iVar21));
                                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5d2;
                                                        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar21), 
                                                                      *(int64_t *)((int64_t)&var_8h + iVar21), 
                                                                      *(int64_t *)((int64_t)&iStackX_18 + iVar21 + -8), 
                                                                      *(int64_t *)((int64_t)&iStackX_18 + iVar21), 
                                                                      *(int64_t *)((int64_t)&arg_30h + iVar21));
                                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5e8;
                                                        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar21));
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                goto code_r0x0001801ea613;
            }
            goto code_r0x0001801ea5ea;
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea603;
    fcn.180224990(iVar23, 0x1804b74f8, 0x34c);
code_r0x0001801ea613:
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea629;
    fcn.180224990(var_328h, 0x1804b74f8, 0x34c);
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea638;
    fcn.180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar21));
    return;
}

// ============================================================
// Function: FUN_1801ea613
// Address: 0x1801ea613
// Size: 52 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_3b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ach
// WARNING: [rz-ghidra] Detected overlap for variable var_3a8h
// WARNING: [rz-ghidra] Removing arg arg_498h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_450h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_448h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_440h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_397h
// WARNING: [rz-ghidra] Detected overlap for variable var_34bh
// WARNING: [rz-ghidra] Detected overlap for variable var_350h
// WARNING: [rz-ghidra] Detected overlap for variable var_34ch
// WARNING: [rz-ghidra] Detected overlap for variable var_33bh
// WARNING: [rz-ghidra] Detected overlap for variable var_337h
// WARNING: [rz-ghidra] Detected overlap for variable var_3c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_390h

void fcn.1801ea270(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined uVar1;
    undefined uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined auVar10 [16];
    undefined auVar11 [16];
    unkbyte3 Var12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    undefined uVar17;
    int32_t iVar18;
    int32_t iVar19;
    uint32_t uVar20;
    int64_t iVar21;
    undefined8 uVar22;
    int64_t iVar23;
    int64_t *in_RCX;
    uint64_t uVar24;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t in_R8;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_418h;
    int64_t var_408h;
    int64_t var_3c8h;
    int64_t var_3c0h;
    int64_t var_3b8h;
    undefined4 var_3b0h;
    undefined var_3ach;
    int64_t var_3abh;
    undefined4 uStack_3a3;
    undefined4 uStack_39f;
    int64_t var_39bh;
    int64_t var_390h;
    int64_t var_388h;
    int64_t var_380h;
    int64_t var_378h;
    int64_t var_368h;
    int64_t var_360h;
    int64_t var_358h;
    undefined4 var_350h;
    undefined4 var_34ch;
    int64_t var_348h;
    undefined4 uStack_33f;
    undefined var_33bh [3];
    int64_t var_338h;
    int64_t var_330h;
    int64_t var_328h;
    int64_t var_320h;
    int64_t var_318h;
    int64_t var_248h;
    int64_t var_48h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801ea28a;
    iVar21 = fcn.18045a350();
    iVar21 = -iVar21;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar21);
    var_378h = 0;
    var_3b0h = *(undefined4 *)(in_R8 + 0x2d);
    iVar23 = in_RCX[0x10];
    _var_368h = ZEXT816(0);
    var_3ach = *(undefined *)(in_R8 + 0x31);
    var_358h._0_4_ = 0;
    var_358h._4_4_ = 0;
    var_350h = 0;
    var_34ch = 0;
    var_3abh._0_3_ = 0;
    var_348h._0_1_ = 0;
    var_348h._1_4_ = 0;
    stack0xfffffffffffffcbd = SUB164(ZEXT816(0), 5);
    uStack_33f = 0;
    _var_33bh = 0;
    var_338h._1_1_ = 0;
    var_338h._2_6_ = 0;
    var_330h = 0;
    _var_328h = ZEXT816(0);
    var_3b8h._0_4_ = *(undefined4 *)(in_R8 + 0x25);
    var_3b8h._4_4_ = *(undefined4 *)(in_R8 + 0x29);
    auVar11._8_8_ = 0;
    auVar11._0_8_ = *(uint64_t *)(in_R8 + 0x1d);
    _var_3c8h = auVar11 << 0x40;
    var_3abh._3_1_ = 0;
    var_3abh._4_4_ = 0;
    uStack_3a3 = SUB164(ZEXT816(0), 5);
    uStack_39f = 0;
    var_39bh._0_4_ = 0;
    var_39bh._4_1_ = 0;
    unique0x100008d2 = 0;
    var_390h = 0;
    var_388h = 0;
    var_380h = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea303;
    iVar18 = func_0x000180200ee0(iVar23, &var_3abh);
    uVar17 = var_39bh._4_1_;
    uVar16 = (undefined4)var_39bh;
    uVar15 = uStack_39f;
    uVar14 = uStack_3a3;
    uVar13 = var_3abh._4_4_;
    uVar2 = var_3abh._3_1_;
    Var12 = (unkbyte3)var_3abh;
    if (iVar18 == 0) goto code_r0x0001801ea613;
    *(undefined8 *)(&stack0x00000498 + iVar21) = unaff_RBX;
    uVar3 = *(undefined4 *)(in_R8 + 0x18);
    *(undefined8 *)(&stack0x00000450 + iVar21) = unaff_RSI;
    uVar6 = *(undefined4 *)(in_R8 + 8);
    uVar7 = *(undefined4 *)(in_R8 + 0xc);
    uVar8 = *(undefined4 *)(in_R8 + 0x10);
    uVar9 = *(undefined4 *)(in_R8 + 0x14);
    *(undefined8 *)(&stack0x00000448 + iVar21) = unaff_RDI;
    uVar1 = *(undefined *)(in_R8 + 0x1c);
    *(undefined8 *)(&stack0x00000440 + iVar21) = unaff_R14;
    *(undefined4 *)((int64_t)&var_20h + iVar21) = uVar6;
    *(undefined4 *)((int64_t)&var_20h + iVar21 + 4) = uVar7;
    *(undefined4 *)(&stack0x00000028 + iVar21) = uVar8;
    *(undefined4 *)(&stack0x0000002c + iVar21) = uVar9;
    var_320h._0_1_ = 1;
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea357;
    uVar22 = func_0x0001802450c0();
    var_358h._0_4_ = *(undefined4 *)(&stack0x00000028 + iVar21);
    var_358h._4_4_ = *(undefined4 *)(&stack0x0000002c + iVar21);
    var_360h._0_4_ = *(undefined4 *)((int64_t)&var_20h + iVar21);
    var_360h._4_4_ = *(undefined4 *)((int64_t)&var_20h + iVar21 + 4);
    var_348h._0_1_ = uVar2;
    var_348h._1_4_ = uVar13;
    stack0xfffffffffffffcbd = uVar14;
    uStack_33f = uVar15;
    var_368h = uVar22;
    auVar10._8_8_ = 0;
    auVar10._0_8_ = var_320h;
    _var_328h = auVar10 << 0x40;
    var_34ch = CONCAT31(Var12, uVar1);
    _var_33bh = uVar16;
    var_338h._1_1_ = uVar17;
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea390;
    var_350h = uVar3;
    iVar18 = func_0x00018026bf70(in_RDX, 0, &var_330h);
    if ((iVar18 == 0) || (var_330h == 0)) {
code_r0x0001801ea5ea:
        iVar23 = var_328h;
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea3c7;
        iVar23 = fcn.1802248d0(*(int64_t *)(&stack0x00000000 + iVar21), *(int64_t *)((int64_t)&var_8h + iVar21));
        var_328h = iVar23;
        if (iVar23 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea3e3;
            iVar18 = func_0x00018026bf70(in_RDX, iVar23, &var_330h);
            if (iVar18 != 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea400;
                iVar18 = func_0x0001801e8b10(&var_368h, &var_248h, (int64_t)&iStackX_18 + iVar21 + -8);
                if (iVar18 != 0) {
                    iVar23 = in_RCX[0x14];
                    iVar4 = *(int64_t *)((int64_t)&iStackX_18 + iVar21 + -8);
                    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea419;
                    iVar18 = func_0x00018020ecc0(iVar23);
                    if (0 < iVar18) {
                        iVar23 = in_RCX[0x14];
                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea430;
                        iVar19 = func_0x00018020e980(iVar23);
                        if ((0 < iVar19) &&
                           (uVar24 = (int64_t)iVar19 + 0x10 + iVar4 + (int64_t)iVar18,
                           *(uint64_t *)((int64_t)&var_20h + iVar21) = uVar24, uVar24 < 0xc6)) {
                            uVar22 = *(undefined8 *)((int64_t)&iStackX_18 + iVar21 + -8);
                            *(int64_t *)(&stack0x00000000 + iVar21) = (int64_t)&var_20h + iVar21;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea47c;
                            iVar18 = func_0x0001801e86c0(in_RCX, &var_248h, uVar22, &var_318h);
                            if ((iVar18 != 0) && (uVar24 = *(uint64_t *)((int64_t)&var_20h + iVar21), 0xf < uVar24)) {
                                var_3b0h = *(undefined4 *)(in_R8 + 0x2d);
                                var_3b8h._0_4_ = *(undefined4 *)(in_R8 + 0x25);
                                var_3b8h._4_4_ = *(undefined4 *)(in_R8 + 0x29);
                                var_3ach = *(undefined *)(in_R8 + 0x31);
                                uVar20 = (uint32_t)var_3c8h & 0xffffff04;
                                var_3c8h = 0x100000000;
                                var_3c8h._0_4_ = uVar20 | 0x8004;
                                var_378h = (int64_t)&var_318h;
                                var_3c0h._0_4_ = *(undefined4 *)(in_R8 + 0x1d);
                                var_3c0h._4_4_ = *(undefined4 *)(in_R8 + 0x21);
                                uVar22 = ((undefined8 *)*in_RCX)[1];
                                uVar5 = *(undefined8 *)*in_RCX;
                                var_380h = uVar24;
                                *(uint64_t *)(&stack0x00000000 + iVar21) = (int64_t)&var_328h + uVar24;
                                *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea4f2;
                                iVar18 = func_0x0001801f84b0(uVar5, uVar22, &var_3c8h, in_R8 + 8);
                                if (iVar18 != 0) {
                                    var_390h = var_378h;
                                    var_388h = var_380h;
                                    *(undefined8 *)((int64_t)&arg_40h + iVar21) = in_RDX;
                                    *(int64_t **)((int64_t)&arg_30h + iVar21) = &var_248h;
                                    *(undefined8 *)((int64_t)&arg_48h + iVar21) = 0;
                                    *(undefined8 *)((int64_t)&arg_50h + iVar21) = 0;
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea540;
                                    iVar18 = func_0x000180244550(&var_408h, &var_248h, 0x200, 0);
                                    if (iVar18 != 0) {
                                        uVar2 = *(undefined *)(in_R8 + 8);
                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea55d;
                                        iVar18 = func_0x0001801f93b0(&var_408h, uVar2, &var_3c8h, 0);
                                        if (iVar18 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea573;
                                            iVar18 = func_0x0001802442e0(&var_408h, (int64_t)&arg_38h + iVar21);
                                            if (iVar18 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea584;
                                                iVar18 = func_0x000180244200(&var_408h);
                                                if (iVar18 != 0) {
                                                    iVar23 = in_RCX[7];
                                                    *(int64_t *)((int64_t)&var_8h + iVar21) = (int64_t)&arg_58h + iVar21
                                                    ;
                                                    *(undefined8 *)(&stack0x00000000 + iVar21) = 0;
                                                    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5b1;
                                                    iVar18 = func_0x00018021af90(iVar23, (int64_t)&arg_30h + iVar21, 
                                                                                 0x28, 1);
                                                    if (iVar18 == 0) {
                                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5ba;
                                                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar21), 
                                                                      *(int64_t *)((int64_t)&var_8h + iVar21));
                                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5d2;
                                                        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar21), 
                                                                      *(int64_t *)((int64_t)&var_8h + iVar21), 
                                                                      *(int64_t *)((int64_t)&iStackX_18 + iVar21 + -8), 
                                                                      *(int64_t *)((int64_t)&iStackX_18 + iVar21), 
                                                                      *(int64_t *)((int64_t)&arg_30h + iVar21));
                                                        *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea5e8;
                                                        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar21));
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                goto code_r0x0001801ea613;
            }
            goto code_r0x0001801ea5ea;
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea603;
    fcn.180224990(iVar23, 0x1804b74f8, 0x34c);
code_r0x0001801ea613:
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea629;
    fcn.180224990(var_328h, 0x1804b74f8, 0x34c);
    *(undefined8 *)((int64_t)&uStack_28 + iVar21) = 0x1801ea638;
    fcn.180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar21));
    return;
}

// ============================================================
// Function: FUN_1801ea650
// Address: 0x1801ea650
// Size: 140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801ea650(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint32_t uVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ea665;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar1 = 0;
    iVar2 = 0;
    if (*(int64_t *)(in_RCX + 0x30) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ea688;
        iVar1 = fcn.180219d10(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3), 
                              *(int64_t *)(&stack0x00000070 + iVar3));
    }
    if (*(int64_t *)(in_RCX + 0x38) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801ea6a3;
        iVar2 = fcn.180219d10(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3), 
                              *(int64_t *)(&stack0x00000070 + iVar3));
    }
    uVar4 = (iVar1 << 5 ^ *(uint32_t *)(in_RCX + 0x9c)) & 0x80 ^ *(uint32_t *)(in_RCX + 0x9c);
    *(uint32_t *)(in_RCX + 0x9c) = (iVar2 << 5 ^ uVar4) & 0x40 ^ uVar4 | 0x100;
    return;
}

// ============================================================
// Function: FUN_1801ea6e0
// Address: 0x1801ea6e0
// Size: 765 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3dh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3eh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_12bh
// WARNING: [rz-ghidra] Detected overlap for variable var_127h

void fcn.1801ea6e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    char cVar1;
    undefined4 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t in_RCX;
    int64_t in_RDX;
    uint64_t uVar15;
    int64_t iVar16;
    undefined8 in_R8;
    undefined4 *in_R9;
    int64_t iVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_138h;
    undefined var_12bh [3];
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_58h;
    undefined8 uStack_48;
    
    uStack_48 = 0x1801ea6fc;
    iVar11 = fcn.18045a350();
    iVar16 = arg_30h;
    iVar8 = arg_28h;
    iVar11 = -iVar11;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar11);
    *(int64_t *)((int64_t)&var_18h + iVar11) = arg_30h;
    iVar17 = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar11) = 0;
    *(undefined (*) [16])((int64_t)&var_20h + iVar11) = ZEXT816(0);
    *(undefined8 *)((int64_t)&var_10h + iVar11) = in_R8;
    *(undefined (*) [16])((int64_t)&arg_30h + iVar11) = ZEXT816(0);
    *(int64_t *)(&stack0xfffffffffffffff8 + iVar11) = in_RDX;
    _var_12bh = 0;
    var_128h._1_1_ = 0;
    var_120h = 0;
    var_118h = 0;
    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1801ea75b;
    uVar12 = func_0x0001802450c0();
    *(undefined *)iVar16 = 0;
    uVar3 = *(undefined8 *)(in_RDX + 0xa0);
    uVar15 = *(uint64_t *)(in_RCX + 0x40);
    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1801ea772;
    iVar9 = func_0x00018020ecc0(uVar3);
    iVar16 = 0;
    iVar14 = 0;
    if (0 < iVar9) {
        uVar3 = *(undefined8 *)(*(int64_t *)(&stack0xfffffffffffffff8 + iVar11) + 0xa0);
        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1801ea78e;
        iVar10 = func_0x00018020e980(uVar3);
        iVar14 = iVar17;
        if (((0 < iVar10) && (iVar16 = var_118h, (uint64_t)(int64_t)(iVar10 + iVar9) <= uVar15)) && (uVar15 < 0xc6)) {
            uVar15 = (uVar15 - (int64_t)iVar10) - (int64_t)iVar9;
            _var_118h = SUB169(ZEXT816(0), 0);
            *(uint64_t *)(&stack0x00000000 + iVar11) = uVar15;
            iVar16 = var_118h;
            if (uVar15 < 0xaa) {
                uVar3 = *(undefined8 *)(in_RCX + 0x40);
                uVar4 = *(undefined8 *)(in_RCX + 0x38);
                *(int64_t *)(&stack0xffffffffffffffe0 + iVar11) = (int64_t)&stack0x00000000 + iVar11;
                *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1801ea7ed;
                iVar9 = func_0x0001801e8570(*(undefined8 *)(&stack0xfffffffffffffff8 + iVar11), uVar4, uVar3, &var_108h)
                ;
                if (iVar9 != 0) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1801ea808;
                    iVar9 = fcn.1801e94f0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar11), 
                                          *(int64_t *)(&stack0xffffffffffffffe8 + iVar11), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar11));
                    if (iVar9 != 0) {
                        uVar15 = *(uint64_t *)((int64_t)&var_20h + iVar11);
                        if ((uVar15 < uVar12) || (uVar15 <= uVar12)) {
                            uVar13 = 11000000000;
                            if ((char)var_110h == '\0') {
                                uVar13 = 0x3466c536a00;
                            }
                            if (uVar12 - uVar15 < uVar13) {
                                uVar3 = *(undefined8 *)((int64_t)&var_10h + iVar11);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1801ea861;
                                iVar9 = func_0x00018026bf70(uVar3, 0, &stack0xfffffffffffffff0 + iVar11);
                                if ((iVar9 != 0) && (*(int64_t *)(&stack0xfffffffffffffff0 + iVar11) == var_120h)) {
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1801ea88a;
                                    iVar14 = fcn.1802248d0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar11), 
                                                           *(int64_t *)(&stack0xffffffffffffffe8 + iVar11));
                                    if (iVar14 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1801ea8a6;
                                        iVar9 = func_0x00018026bf70(uVar3, iVar14, &stack0xfffffffffffffff0 + iVar11);
                                        if (iVar9 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1801ea8c2;
                                            iVar9 = func_0x000180497f30(iVar14, var_118h, 
                                                                        *(undefined8 *)
                                                                         (&stack0xfffffffffffffff0 + iVar11));
                                            if (iVar9 == 0) {
                                                if ((char)var_110h == '\0') {
                                                    uVar3 = *(undefined8 *)
                                                             (*(int64_t *)(&stack0xfffffffffffffff8 + iVar11) + 0x80);
                                                    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1801ea94f;
                                                    iVar9 = func_0x000180200ee0(uVar3, in_R9);
                                                    if (iVar9 != 0) {
                                                        uVar2 = *(undefined4 *)(in_RCX + 0x21);
                                                        uVar5 = *(undefined4 *)(in_RCX + 0x25);
                                                        uVar6 = *(undefined4 *)(in_RCX + 0x29);
                                                        *(undefined4 *)iVar8 = *(undefined4 *)(in_RCX + 0x1d);
                                                        *(undefined4 *)(iVar8 + 4) = uVar2;
                                                        *(undefined4 *)(iVar8 + 8) = uVar5;
                                                        *(undefined4 *)(iVar8 + 0xc) = uVar6;
                                                        *(undefined4 *)(iVar8 + 0x10) = *(undefined4 *)(in_RCX + 0x2d);
                                                        *(undefined *)(iVar8 + 0x14) = *(undefined *)(in_RCX + 0x31);
                                                        if (0x2f29aa759ff < uVar12 - uVar15) {
                                                            **(undefined **)((int64_t)&var_18h + iVar11) = 1;
                                                        }
                                                        *(undefined4 *)((int64_t)&var_8h + iVar11) = 1;
                                                    }
                                                } else {
                                                    cVar1 = *(char *)((int64_t)&arg_38h + iVar11 + 5);
                                                    if (cVar1 == *(char *)(in_RCX + 8)) {
                                                        *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1801ea8ee;
                                                        iVar9 = func_0x000180497f30((int64_t)&arg_38h + iVar11 + 6, 
                                                                                    in_RCX + 9, cVar1);
                                                        if (iVar9 == 0) {
                                                            uVar2 = *(undefined4 *)((int64_t)&arg_38h + iVar11);
                                                            uVar5 = *(undefined4 *)((int64_t)&arg_28h + iVar11 + 4);
                                                            uVar6 = *(undefined4 *)((int64_t)&arg_30h + iVar11);
                                                            uVar7 = *(undefined4 *)((int64_t)&arg_30h + iVar11 + 4);
                                                            *(undefined4 *)((int64_t)&var_8h + iVar11) = 1;
                                                            *in_R9 = *(undefined4 *)((int64_t)&arg_28h + iVar11);
                                                            in_R9[1] = uVar5;
                                                            in_R9[2] = uVar6;
                                                            in_R9[3] = uVar7;
                                                            in_R9[4] = uVar2;
                                                            uVar2 = *(undefined4 *)((int64_t)&arg_38h + iVar11 + 5);
                                                            uVar5 = *(undefined4 *)(&stack0x00000041 + iVar11);
                                                            uVar6 = *(undefined4 *)(&stack0x00000045 + iVar11);
                                                            uVar7 = *(undefined4 *)(&stack0x00000049 + iVar11);
                                                            *(undefined *)(in_R9 + 5) =
                                                                 *(undefined *)((int64_t)&arg_38h + iVar11 + 4);
                                                            *(undefined4 *)iVar8 = uVar2;
                                                            *(undefined4 *)(iVar8 + 4) = uVar5;
                                                            *(undefined4 *)(iVar8 + 8) = uVar6;
                                                            *(undefined4 *)(iVar8 + 0xc) = uVar7;
                                                            *(undefined4 *)(iVar8 + 0x10) = _var_12bh;
                                                            *(undefined *)(iVar8 + 0x14) = var_128h._1_1_;
                                                            **(undefined **)((int64_t)&var_18h + iVar11) = 1;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1801ea9a4;
    fcn.180224990(iVar16, 0x1804b74f8, 0x34c);
    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1801ea9b9;
    fcn.180224990(iVar14, 0x1804b74f8, 0x58d);
    *(undefined8 *)((int64_t)&uStack_48 + iVar11) = 0x1801ea9c9;
    fcn.180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar11));
    return;
}

// ============================================================
// Function: FUN_1801ea9e0
// Address: 0x1801ea9e0
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801ea9e0(undefined8 placeholder_0, int64_t placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_48h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                  int64_t arg_c8h)
{
    undefined2 uVar1;
    uint32_t *puVar2;
    undefined4 *puVar3;
    undefined2 *puVar4;
    uint64_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint16_t uVar9;
    undefined8 unaff_RSI;
    uint64_t uVar10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_40 = 0x1801ea9ff;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    puVar2 = *(uint32_t **)((int64_t)&arg_78h + iVar7);
    puVar3 = *(undefined4 **)((int64_t)&arg_70h + iVar7);
    uVar8 = 0;
    puVar4 = *(undefined2 **)((int64_t)&arg_80h + iVar7);
    uVar5 = *(uint64_t *)((int64_t)&arg_68h + iVar7);
    *puVar2 = 0;
    uVar9 = 0;
    *puVar3 = 0;
    *puVar4 = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar7) = 0;
    if (uVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
        uVar10 = arg3;
        do {
            uVar1 = *(undefined2 *)(arg4 + uVar8 * 2);
            puVar4 = (undefined2 *)(arg4 + uVar8 * 2);
            *(int64_t *)((int64_t)&var_10h + iVar7) = (int64_t)&var_8h + iVar7;
            *(undefined4 *)(&stack0xffffffffffffffe8 + iVar7) = 1;
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801eaa89;
            iVar6 = func_0x0001801ae070(placeholder_0, uVar1, placeholder_1, uVar10);
            if (iVar6 != 0) {
                uVar1 = *puVar4;
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801eaa9e;
                iVar6 = func_0x0001801ada30(placeholder_0, uVar1, 0x20004);
                if (iVar6 != 0) {
                    uVar1 = *puVar4;
                    *(undefined8 *)((int64_t)&var_10h + iVar7) = 0;
                    *(undefined4 *)(&stack0xffffffffffffffe8 + iVar7) = 0;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801eaac1;
                    iVar6 = func_0x0001801adc80(placeholder_0, uVar1, 0x304);
                    if ((iVar6 != 0) && (uVar8 = *(uint64_t *)((int64_t)&var_8h + iVar7), uVar8 < (uint64_t)arg3)) {
                        puVar4 = *(undefined2 **)((int64_t)&arg_80h + iVar7);
                        *puVar2 = (uint32_t)uVar9;
                        *puVar3 = (int32_t)uVar8;
                        *puVar4 = *(undefined2 *)(placeholder_1 + uVar8 * 2);
                        arg3 = uVar8;
                    }
                }
            }
            uVar10 = *(uint64_t *)((int64_t)&arg_58h + iVar7);
            uVar9 = uVar9 + 1;
            arg4 = *(int64_t *)((int64_t)&arg_60h + iVar7);
            uVar8 = (uint64_t)uVar9;
        } while (uVar8 < uVar5);
    }
    return;
}

// ============================================================
// Function: FUN_1801eaa49
// Address: 0x1801eaa49
// Size: 203 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801ea9e0(undefined8 placeholder_0, int64_t placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_48h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                  int64_t arg_c8h)
{
    undefined2 uVar1;
    uint32_t *puVar2;
    undefined4 *puVar3;
    undefined2 *puVar4;
    uint64_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint16_t uVar9;
    undefined8 unaff_RSI;
    uint64_t uVar10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_40 = 0x1801ea9ff;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    puVar2 = *(uint32_t **)((int64_t)&arg_78h + iVar7);
    puVar3 = *(undefined4 **)((int64_t)&arg_70h + iVar7);
    uVar8 = 0;
    puVar4 = *(undefined2 **)((int64_t)&arg_80h + iVar7);
    uVar5 = *(uint64_t *)((int64_t)&arg_68h + iVar7);
    *puVar2 = 0;
    uVar9 = 0;
    *puVar3 = 0;
    *puVar4 = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar7) = 0;
    if (uVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
        uVar10 = arg3;
        do {
            uVar1 = *(undefined2 *)(arg4 + uVar8 * 2);
            puVar4 = (undefined2 *)(arg4 + uVar8 * 2);
            *(int64_t *)((int64_t)&var_10h + iVar7) = (int64_t)&var_8h + iVar7;
            *(undefined4 *)(&stack0xffffffffffffffe8 + iVar7) = 1;
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801eaa89;
            iVar6 = func_0x0001801ae070(placeholder_0, uVar1, placeholder_1, uVar10);
            if (iVar6 != 0) {
                uVar1 = *puVar4;
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801eaa9e;
                iVar6 = func_0x0001801ada30(placeholder_0, uVar1, 0x20004);
                if (iVar6 != 0) {
                    uVar1 = *puVar4;
                    *(undefined8 *)((int64_t)&var_10h + iVar7) = 0;
                    *(undefined4 *)(&stack0xffffffffffffffe8 + iVar7) = 0;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801eaac1;
                    iVar6 = func_0x0001801adc80(placeholder_0, uVar1, 0x304);
                    if ((iVar6 != 0) && (uVar8 = *(uint64_t *)((int64_t)&var_8h + iVar7), uVar8 < (uint64_t)arg3)) {
                        puVar4 = *(undefined2 **)((int64_t)&arg_80h + iVar7);
                        *puVar2 = (uint32_t)uVar9;
                        *puVar3 = (int32_t)uVar8;
                        *puVar4 = *(undefined2 *)(placeholder_1 + uVar8 * 2);
                        arg3 = uVar8;
                    }
                }
            }
            uVar10 = *(uint64_t *)((int64_t)&arg_58h + iVar7);
            uVar9 = uVar9 + 1;
            arg4 = *(int64_t *)((int64_t)&arg_60h + iVar7);
            uVar8 = (uint64_t)uVar9;
        } while (uVar8 < uVar5);
    }
    return;
}

// ============================================================
// Function: FUN_1801eab14
// Address: 0x1801eab14
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801ea9e0(undefined8 placeholder_0, int64_t placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_48h,
                  int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h,
                  int64_t arg_c8h)
{
    undefined2 uVar1;
    uint32_t *puVar2;
    undefined4 *puVar3;
    undefined2 *puVar4;
    uint64_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint16_t uVar9;
    undefined8 unaff_RSI;
    uint64_t uVar10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_40 = 0x1801ea9ff;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    puVar2 = *(uint32_t **)((int64_t)&arg_78h + iVar7);
    puVar3 = *(undefined4 **)((int64_t)&arg_70h + iVar7);
    uVar8 = 0;
    puVar4 = *(undefined2 **)((int64_t)&arg_80h + iVar7);
    uVar5 = *(uint64_t *)((int64_t)&arg_68h + iVar7);
    *puVar2 = 0;
    uVar9 = 0;
    *puVar3 = 0;
    *puVar4 = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar7) = 0;
    if (uVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
        uVar10 = arg3;
        do {
            uVar1 = *(undefined2 *)(arg4 + uVar8 * 2);
            puVar4 = (undefined2 *)(arg4 + uVar8 * 2);
            *(int64_t *)((int64_t)&var_10h + iVar7) = (int64_t)&var_8h + iVar7;
            *(undefined4 *)(&stack0xffffffffffffffe8 + iVar7) = 1;
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801eaa89;
            iVar6 = func_0x0001801ae070(placeholder_0, uVar1, placeholder_1, uVar10);
            if (iVar6 != 0) {
                uVar1 = *puVar4;
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801eaa9e;
                iVar6 = func_0x0001801ada30(placeholder_0, uVar1, 0x20004);
                if (iVar6 != 0) {
                    uVar1 = *puVar4;
                    *(undefined8 *)((int64_t)&var_10h + iVar7) = 0;
                    *(undefined4 *)(&stack0xffffffffffffffe8 + iVar7) = 0;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1801eaac1;
                    iVar6 = func_0x0001801adc80(placeholder_0, uVar1, 0x304);
                    if ((iVar6 != 0) && (uVar8 = *(uint64_t *)((int64_t)&var_8h + iVar7), uVar8 < (uint64_t)arg3)) {
                        puVar4 = *(undefined2 **)((int64_t)&arg_80h + iVar7);
                        *puVar2 = (uint32_t)uVar9;
                        *puVar3 = (int32_t)uVar8;
                        *puVar4 = *(undefined2 *)(placeholder_1 + uVar8 * 2);
                        arg3 = uVar8;
                    }
                }
            }
            uVar10 = *(uint64_t *)((int64_t)&arg_58h + iVar7);
            uVar9 = uVar9 + 1;
            arg4 = *(int64_t *)((int64_t)&arg_60h + iVar7);
            uVar8 = (uint64_t)uVar9;
        } while (uVar8 < uVar5);
    }
    return;
}

// ============================================================
// Function: FUN_1801eab30
// Address: 0x1801eab30
// Size: 953 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_38h

undefined8
fcn.1801eab30(int64_t placeholder_0, int64_t *placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_68h,
             int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h,
             int64_t arg_b0h, int64_t arg_148h)
{
    undefined4 *puVar1;
    undefined uVar2;
    undefined uVar3;
    int16_t iVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    undefined *puVar9;
    int64_t iVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    int32_t iVar15;
    int64_t iVar16;
    int64_t iVar17;
    uint64_t uVar18;
    undefined8 uVar19;
    uint64_t uVar20;
    undefined8 uVar21;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_38h;
    
    uStack_40 = 0x1801eab54;
    var_18h = arg3;
    var_20h = arg4;
    iVar16 = fcn.18045a350();
    iVar16 = -iVar16;
    piVar5 = *(int64_t **)((int64_t)&arg_b0h + iVar16);
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar16) = 0;
    iVar17 = *piVar5;
    *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801eab88;
    iVar17 = func_0x000180224ed0(iVar17, 2, 0x1804b7630, 0x29c);
    piVar6 = *(int64_t **)((int64_t)&arg_98h + iVar16);
    piVar7 = *(int64_t **)((int64_t)&arg_a0h + iVar16);
    *piVar6 = iVar17;
    if (iVar17 == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801eaba6;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar16), *(int64_t *)(&stack0xfffffffffffffff0 + iVar16));
    } else {
        iVar17 = *piVar5;
        *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801eabe8;
        iVar17 = func_0x000180224ed0(iVar17, 0x10, 0x1804b7630, 0x2a2);
        *piVar7 = iVar17;
        if (iVar17 != 0) {
            uVar20 = placeholder_1[1];
            if (uVar20 != 0) {
                piVar8 = *(int64_t **)(&stack0x000000a8 + iVar16);
                uVar19 = *(undefined8 *)((int64_t)&arg_90h + iVar16);
                do {
                    if (uVar20 < 2) {
code_r0x0001801eae84:
                        *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801eae89;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar16));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801eaea1;
                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), 
                                      *(int64_t *)(&stack0x00000000 + iVar16), *(int64_t *)((int64_t)&var_18h + iVar16))
                        ;
                        uVar19 = 0x32;
                        uVar21 = 0x9f;
                        goto code_r0x0001801eaeac;
                    }
                    puVar9 = (undefined *)*placeholder_1;
                    uVar2 = *puVar9;
                    uVar3 = puVar9[1];
                    *placeholder_1 = (int64_t)(puVar9 + 2);
                    placeholder_1[1] = uVar20 - 2;
                    puVar9 = (undefined *)*placeholder_1;
                    iVar17 = placeholder_1[1];
                    *(undefined **)(&stack0x00000000 + iVar16) = puVar9;
                    *(int64_t *)((int64_t)(&stack0x00000000 + iVar16) + 8) = iVar17;
                    if (uVar20 - 2 < 2) goto code_r0x0001801eae84;
                    uVar18 = (uint64_t)CONCAT11(*puVar9, puVar9[1]);
                    if (uVar20 - 4 < uVar18) goto code_r0x0001801eae84;
                    *(undefined **)((int64_t)&var_10h + iVar16) = puVar9 + 2;
                    *(uint64_t *)((int64_t)&var_8h + iVar16) = (uVar20 - 4) - uVar18;
                    *(undefined **)(&stack0x00000000 + iVar16) = puVar9 + 2 + uVar18;
                    *(uint64_t *)((int64_t)&var_18h + iVar16) = uVar18;
                    puVar1 = (undefined4 *)(&stack0x00000000 + iVar16);
                    uVar11 = puVar1[1];
                    uVar12 = puVar1[2];
                    uVar13 = puVar1[3];
                    *(undefined4 *)placeholder_1 = *puVar1;
                    *(undefined4 *)((int64_t)placeholder_1 + 4) = uVar11;
                    *(undefined4 *)(placeholder_1 + 1) = uVar12;
                    *(undefined4 *)((int64_t)placeholder_1 + 0xc) = uVar13;
                    if (uVar18 == 0) goto code_r0x0001801eae84;
                    if ((*(int16_t *)(placeholder_0 + 0x4de) != 0) &&
                       ((CONCAT11(uVar2, uVar3) != *(int16_t *)(placeholder_0 + 0x4de) || (placeholder_1[1] != 0)))) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801eae3e;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar16));
code_r0x0001801eae43:
                        *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801eae56;
                        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), 
                                      *(int64_t *)(&stack0x00000000 + iVar16), *(int64_t *)((int64_t)&var_18h + iVar16))
                        ;
                        uVar19 = 0x2f;
                        uVar21 = 0x6c;
                        goto code_r0x0001801eaeac;
                    }
                    *(undefined **)(&stack0xfffffffffffffff0 + iVar16) = &stack0xfffffffffffffff8 + iVar16;
                    *(undefined4 *)(&stack0xffffffffffffffe8 + iVar16) = 0;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801eacf9;
                    iVar15 = func_0x0001801ae070(placeholder_0, CONCAT11(uVar2, uVar3), 
                                                 *(undefined8 *)((int64_t)&arg_78h + iVar16), 
                                                 *(undefined8 *)((int64_t)&arg_80h + iVar16));
                    if (iVar15 == 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801eae7d;
                        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar16), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar16));
                        goto code_r0x0001801eae43;
                    }
                    iVar4 = *(int16_t *)(placeholder_0 + 0x4de);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801eae6d;
                        iVar15 = func_0x0001801eaf80(placeholder_0, iVar4, (int64_t)&var_10h + iVar16);
                        if (iVar15 != 0) {
                            return 2;
                        }
                        goto code_r0x0001801eaeb7;
                    }
                    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar16) = 0;
                    *(undefined4 *)(&stack0xffffffffffffffe8 + iVar16) = 1;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801ead38;
                    iVar15 = func_0x0001801ae070(placeholder_0, CONCAT11(uVar2, uVar3), 
                                                 *(undefined8 *)((int64_t)&arg_88h + iVar16), uVar19);
                    if (iVar15 != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801ead51;
                        iVar15 = func_0x0001801ada30(placeholder_0, CONCAT11(uVar2, uVar3), 0x20004);
                        if (iVar15 != 0) {
                            *(undefined8 *)(&stack0xfffffffffffffff0 + iVar16) = 0;
                            *(undefined4 *)(&stack0xffffffffffffffe8 + iVar16) = 0;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801ead78;
                            iVar15 = func_0x0001801adc80(placeholder_0, CONCAT11(uVar2, uVar3), 0x304);
                            if (iVar15 != 0) {
                                uVar11 = *(undefined4 *)((int64_t)&var_10h + iVar16);
                                uVar12 = *(undefined4 *)((int64_t)&var_10h + iVar16 + 4);
                                uVar13 = *(undefined4 *)((int64_t)&var_18h + iVar16);
                                uVar14 = *(undefined4 *)((int64_t)&var_18h + iVar16 + 4);
                                *(int16_t *)(*piVar6 + *piVar8 * 2) = CONCAT11(uVar2, uVar3);
                                puVar1 = (undefined4 *)(*piVar7 + *piVar8 * 0x10);
                                *puVar1 = uVar11;
                                puVar1[1] = uVar12;
                                puVar1[2] = uVar13;
                                puVar1[3] = uVar14;
                                *piVar8 = *piVar8 + 1;
                                iVar17 = *piVar5;
                                if (*piVar8 == iVar17) {
                                    iVar10 = *piVar6;
                                    *(undefined4 *)(&stack0xffffffffffffffe8 + iVar16) = 0x2f5;
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801eadce;
                                    iVar17 = func_0x000180224f60(iVar10, iVar17 + 0x20, 2, 0x1804b7630);
                                    if (iVar17 == 0) goto code_r0x0001801eaeb7;
                                    *piVar6 = iVar17;
                                    iVar17 = *piVar5;
                                    iVar10 = *piVar7;
                                    *(undefined4 *)(&stack0xffffffffffffffe8 + iVar16) = 0x2fd;
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801eadff;
                                    iVar17 = func_0x000180224f60(iVar10, iVar17 + 0x20, 0x10, 0x1804b7630);
                                    if (iVar17 == 0) goto code_r0x0001801eaeb7;
                                    *piVar7 = iVar17;
                                    *piVar5 = *piVar5 + 0x20;
                                }
                            }
                        }
                    }
                    uVar20 = placeholder_1[1];
                } while (uVar20 != 0);
            }
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801eabf5;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar16), *(int64_t *)(&stack0xfffffffffffffff0 + iVar16));
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801eabbe;
    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar16), *(int64_t *)(&stack0xfffffffffffffff0 + iVar16), 
                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar16), *(int64_t *)(&stack0x00000000 + iVar16), 
                  *(int64_t *)((int64_t)&var_18h + iVar16));
    uVar19 = 0x50;
    uVar21 = 0xc0103;
code_r0x0001801eaeac:
    *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801eaeb7;
    func_0x00018019b5e0(placeholder_0, uVar19, uVar21, 0);
code_r0x0001801eaeb7:
    iVar17 = *piVar6;
    *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801eaecd;
    fcn.180224990(iVar17, 0x1804b7630, 0x30a);
    iVar17 = *piVar7;
    *(undefined8 *)((int64_t)&uStack_40 + iVar16) = 0x1801eaee2;
    fcn.180224990(iVar17, 0x1804b7630, 0x30b);
    return 0;
}

// ============================================================
// Function: FUN_1801eaef0
// Address: 0x1801eaef0
// Size: 140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801eaef0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h)
{
    undefined uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint64_t in_RDX;
    uint64_t uVar4;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801eaf0e;
    iVar2 = fcn.18045a350();
    uVar4 = 0;
    if (in_RDX != 0) {
        do {
            uVar1 = *(undefined *)(in_RCX + uVar4);
            *(undefined8 *)((int64_t)&uStack_20 + -iVar2) = 0x1801eaf42;
            iVar3 = func_0x000180498a80(in_R8, uVar1, in_R9);
            if (iVar3 != 0) {
                **(undefined **)((int64_t)&arg_48h + -iVar2) = uVar1;
                return 1;
            }
            uVar4 = uVar4 + 1;
        } while (uVar4 < in_RDX);
    }
    return 2;
}

// ============================================================
// Function: FUN_1801eaf80
// Address: 0x1801eaf80
// Size: 237 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801eaf80(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint32_t in_EDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801eaf90;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(int16_t *)(in_RCX + 0x4de) = (int16_t)in_EDX;
    *(int16_t *)(in_RCX + 0x4e8) = (int16_t)in_EDX;
    *(uint32_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x304) = in_EDX & 0xffff;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eafbe;
    iVar3 = fcn.1801c6590(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2));
    *(int64_t *)(in_RCX + 0x4e0) = iVar3;
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eafcf;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eafe7;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eaffd;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eb019;
    iVar1 = fcn.1801aa310(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                          *(int64_t *)(&stack0x00000068 + iVar2), *(int64_t *)(&stack0x00000078 + iVar2), 
                          *(int64_t *)(&stack0x00000080 + iVar2), *(int64_t *)(&stack0x00000090 + iVar2), 
                          *(int64_t *)(&stack0x000000a0 + iVar2));
    if (iVar1 < 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eb022;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eb03a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eb050;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801eb070
// Address: 0x1801eb070
// Size: 244 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801eb070(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801eb080;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int64_t *)(in_RCX + 0x4b8) == 0) {
        return 2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eb0b6;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eb0c7;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eb0d8;
            iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eb0f8;
                iVar1 = fcn.180244bf0(*(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                                      *(int64_t *)(&stack0x00000048 + iVar2));
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eb104;
                    iVar1 = fcn.180244000(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                          *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2)
                                          , *(int64_t *)(&stack0x00000040 + iVar2), 
                                          *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2)
                                          , *(int64_t *)(&stack0x00000058 + iVar2));
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eb110;
                        iVar1 = fcn.180244000(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                              *(int64_t *)(&stack0x00000030 + iVar2), 
                                              *(int64_t *)(&stack0x00000038 + iVar2), 
                                              *(int64_t *)(&stack0x00000040 + iVar2), 
                                              *(int64_t *)(&stack0x00000048 + iVar2), 
                                              *(int64_t *)(&stack0x00000050 + iVar2), 
                                              *(int64_t *)(&stack0x00000058 + iVar2));
                        if (iVar1 != 0) {
                            return 1;
                        }
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eb129;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eb141;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801eb157;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801eb170
// Address: 0x1801eb170
// Size: 175 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801eb170(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801eb183;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(char *)(in_RCX + 0xb51) == '\x02') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb19a;
        iVar1 = func_0x0001801b6f10();
        if ((iVar1 != 0) || (*(int32_t *)(in_RCX + 0xba8) == 2)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb1b5;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb1cd;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)((int64_t)&arg_38h + iVar2));
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb1e3;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar2));
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
    if (*(char *)(in_RCX + 0xb50) == '\0') {
        *(undefined *)(in_RCX + 0xb51) = 0;
        uVar3 = 2;
    } else {
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_R15;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb229;
        iVar1 = func_0x0001801b6f10(in_RCX);
        if ((((iVar1 == 0) && (*(int32_t *)(in_RCX + 0xba8) != 2)) || (*(char *)(in_RCX + 0xb51) != '\x01')) ||
           (*(int64_t *)(in_RCX + 0x1590) == 0)) {
            *(undefined *)(in_RCX + 0xb51) = 0;
            uVar3 = 2;
            *(undefined *)(in_RCX + 0xb50) = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb26f;
            iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                  *(int64_t *)(&stack0x00000048 + iVar2));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb280;
                iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_8 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8));
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb295;
                    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_8 + iVar2), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                          *(int64_t *)(&stack0x00000048 + iVar2));
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb2a1;
                        iVar1 = fcn.180244000(*(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar2), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar2), 
                                              *(int64_t *)(&stack0x00000040 + iVar2), 
                                              *(int64_t *)(&stack0x00000048 + iVar2));
                        if (iVar1 != 0) {
                            return 1;
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb2b1;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb2c9;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)((int64_t)&arg_38h + iVar2));
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb2df;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar2));
            uVar3 = 0;
        }
    }
    return uVar3;
}

// ============================================================
// Function: FUN_1801eb21f
// Address: 0x1801eb21f
// Size: 213 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801eb170(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801eb183;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(char *)(in_RCX + 0xb51) == '\x02') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb19a;
        iVar1 = func_0x0001801b6f10();
        if ((iVar1 != 0) || (*(int32_t *)(in_RCX + 0xba8) == 2)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb1b5;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb1cd;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)((int64_t)&arg_38h + iVar2));
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb1e3;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar2));
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
    if (*(char *)(in_RCX + 0xb50) == '\0') {
        *(undefined *)(in_RCX + 0xb51) = 0;
        uVar3 = 2;
    } else {
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_R15;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb229;
        iVar1 = func_0x0001801b6f10(in_RCX);
        if ((((iVar1 == 0) && (*(int32_t *)(in_RCX + 0xba8) != 2)) || (*(char *)(in_RCX + 0xb51) != '\x01')) ||
           (*(int64_t *)(in_RCX + 0x1590) == 0)) {
            *(undefined *)(in_RCX + 0xb51) = 0;
            uVar3 = 2;
            *(undefined *)(in_RCX + 0xb50) = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb26f;
            iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                  *(int64_t *)(&stack0x00000048 + iVar2));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb280;
                iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_8 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8));
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb295;
                    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_8 + iVar2), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                          *(int64_t *)(&stack0x00000048 + iVar2));
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb2a1;
                        iVar1 = fcn.180244000(*(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar2), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar2), 
                                              *(int64_t *)(&stack0x00000040 + iVar2), 
                                              *(int64_t *)(&stack0x00000048 + iVar2));
                        if (iVar1 != 0) {
                            return 1;
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb2b1;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb2c9;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)((int64_t)&arg_38h + iVar2));
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb2df;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar2));
            uVar3 = 0;
        }
    }
    return uVar3;
}

// ============================================================
// Function: FUN_1801eb2f4
// Address: 0x1801eb2f4
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801eb170(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801eb183;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(char *)(in_RCX + 0xb51) == '\x02') {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb19a;
        iVar1 = func_0x0001801b6f10();
        if ((iVar1 != 0) || (*(int32_t *)(in_RCX + 0xba8) == 2)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb1b5;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb1cd;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)((int64_t)&arg_38h + iVar2));
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb1e3;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar2));
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
    if (*(char *)(in_RCX + 0xb50) == '\0') {
        *(undefined *)(in_RCX + 0xb51) = 0;
        uVar3 = 2;
    } else {
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_R15;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb229;
        iVar1 = func_0x0001801b6f10(in_RCX);
        if ((((iVar1 == 0) && (*(int32_t *)(in_RCX + 0xba8) != 2)) || (*(char *)(in_RCX + 0xb51) != '\x01')) ||
           (*(int64_t *)(in_RCX + 0x1590) == 0)) {
            *(undefined *)(in_RCX + 0xb51) = 0;
            uVar3 = 2;
            *(undefined *)(in_RCX + 0xb50) = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb26f;
            iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                  *(int64_t *)(&stack0x00000048 + iVar2));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb280;
                iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_8 + iVar2), 
                                      *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8));
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb295;
                    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_8 + iVar2), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                          *(int64_t *)(&stack0x00000048 + iVar2));
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb2a1;
                        iVar1 = fcn.180244000(*(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar2), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar2), 
                                              *(int64_t *)(&stack0x00000040 + iVar2), 
                                              *(int64_t *)(&stack0x00000048 + iVar2));
                        if (iVar1 != 0) {
                            return 1;
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb2b1;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb2c9;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)((int64_t)&arg_38h + iVar2));
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801eb2df;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_28h + iVar2));
            uVar3 = 0;
        }
    }
    return uVar3;
}

// ============================================================
// Function: FUN_1801eb310
// Address: 0x1801eb310
// Size: 818 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801eb310(int64_t arg_b0h, int64_t arg_b8h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 uVar9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    var_30h = 0x1801eb32b;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    puVar1 = *(undefined8 **)(in_RCX + 8);
    uVar9 = 0;
    uVar2 = *(undefined8 *)(in_RCX + 0x40);
    if ((*(uint32_t *)(in_RCX + 0x160) & 0x800) == 0) {
        return 2;
    }
    if (puVar1[0x1c] == 0) {
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb363;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20)
                     );
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb37b;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20)
                      , *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6));
        goto code_r0x0001801eb80b;
    }
    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb399;
    iVar5 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                          *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)(&stack0x00000038 + iVar6));
    if (iVar5 == 0) {
code_r0x0001801eb7e8:
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb7ed;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20)
                     );
    } else {
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb3ae;
        iVar5 = fcn.180244a90(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb3c3;
        iVar5 = fcn.180244a90(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb3d7;
        iVar5 = func_0x0001802442e0(in_RDX, &var_40h);
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb3f0;
        iVar5 = func_0x000180244860(in_RDX, 0x1076, &var_68h);
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb40b;
        iVar5 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)(&stack0x00000038 + iVar6));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb426;
        iVar5 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)(&stack0x00000038 + iVar6));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb443;
        iVar5 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)(&stack0x00000038 + iVar6));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        uVar3 = *(undefined8 *)(in_RCX + 0x300);
        pcVar4 = *(code **)(*(int64_t *)(in_RCX + 0x18) + 0xb0);
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb467;
        iVar5 = (*pcVar4)(uVar3, in_RDX, &var_30h);
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb48a;
        iVar5 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)(&stack0x00000038 + iVar6));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb499;
        func_0x000180467bd4(0);
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb4aa;
        iVar5 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)(&stack0x00000038 + iVar6));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb4bf;
        iVar5 = fcn.180244a90(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb4d8;
        iVar5 = func_0x000180244860(in_RDX, 0x40, &var_88h);
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb4ea;
        iVar5 = func_0x0001801da790(in_RCX, 0);
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb508;
        iVar5 = func_0x000180197770(in_RCX, var_88h, 0x40, &var_60h);
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb520;
        iVar5 = func_0x000180243f60(in_RDX, var_60h, &var_58h);
        if ((iVar5 == 0) || (var_88h != var_58h)) {
code_r0x0001801eb7dc:
            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb7e1;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
        } else {
            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb53e;
            iVar5 = fcn.180244000(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6));
            if (iVar5 == 0) goto code_r0x0001801eb7dc;
            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb553;
            iVar5 = fcn.180244a90(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
            if (iVar5 == 0) goto code_r0x0001801eb7dc;
            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb56c;
            iVar5 = func_0x000180244860(in_RDX, 0x1000, &var_80h);
            if (iVar5 == 0) goto code_r0x0001801eb7dc;
            pcVar4 = (code *)puVar1[0x1c];
            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb588;
            iVar5 = (*pcVar4)(uVar2, var_80h, &var_50h);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb591;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb5a9;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6));
                goto code_r0x0001801eb80b;
            }
            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb5c4;
            iVar5 = func_0x000180243f60(in_RDX, var_50h, &var_48h);
            if ((iVar5 == 0) || (var_80h != var_48h)) {
code_r0x0001801eb7d0:
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb7d5;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
            } else {
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb5e2;
                iVar5 = fcn.180244000(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                      , *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6));
                if (iVar5 == 0) goto code_r0x0001801eb7d0;
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb5f6;
                iVar5 = func_0x0001802442e0(in_RDX, &var_8h);
                if (iVar5 == 0) goto code_r0x0001801eb7d0;
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb60f;
                iVar5 = func_0x000180244860(in_RDX, 0x20, &var_70h);
                if (iVar5 == 0) goto code_r0x0001801eb7d0;
                var_8h = var_8h - var_40h;
                var_78h = 0x20;
                if ((uint64_t)var_8h < 0x1057) {
                    *(undefined8 *)((int64_t)&arg_b0h + iVar6) = unaff_R14;
                    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb64f;
                    iVar7 = func_0x000180215470();
                    iVar8 = *(int64_t *)(in_RCX + 0xb88);
                    uVar2 = puVar1[0x8c];
                    uVar3 = *puVar1;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = 0x20;
                    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb67f;
                    iVar8 = func_0x00018022fea0(uVar3, 0x1804af24c, uVar2, iVar8 + 0x300);
                    if ((iVar7 == 0) || (iVar8 == 0)) {
                        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb785;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
                        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb79d;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                     );
                    } else {
                        uVar2 = *puVar1;
                        *(undefined8 *)((int64_t)&iStackX_10 + iVar6 + -8) = 0;
                        *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20) = iVar8;
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = puVar1[0x8c];
                        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb6be;
                        iVar5 = func_0x00018025c2e0(iVar7, 0, 0x1804b30b0, uVar2);
                        if (iVar5 < 1) {
code_r0x0001801eb774:
                            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb779;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
                        } else {
                            *(int64_t *)(&stack0xfffffffffffffff8 + iVar6) = var_8h;
                            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb6e3;
                            iVar5 = func_0x00018025bc60(iVar7, var_70h, &var_78h, var_68h);
                            if (iVar5 < 1) goto code_r0x0001801eb774;
                            if ((uint64_t)(var_8h + var_78h) < 0x1077) {
                                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb730;
                                iVar5 = func_0x000180243f60(in_RDX, var_78h, &var_38h);
                                if (((iVar5 != 0) && (var_70h == var_38h)) && (var_68h == var_70h - var_8h)) {
                                    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb750;
                                    iVar5 = fcn.180244000(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                                          *(int64_t *)(&stack0x00000028 + iVar6), 
                                                          *(int64_t *)(&stack0x00000030 + iVar6), 
                                                          *(int64_t *)(&stack0x00000038 + iVar6));
                                    if (iVar5 != 0) {
                                        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb75c;
                                        iVar5 = fcn.180244000(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                                              *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                                              *(int64_t *)(&stack0x00000028 + iVar6), 
                                                              *(int64_t *)(&stack0x00000030 + iVar6), 
                                                              *(int64_t *)(&stack0x00000038 + iVar6));
                                        if (iVar5 != 0) {
                                            uVar9 = 1;
                                            goto code_r0x0001801eb7b3;
                                        }
                                    }
                                }
                                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb76d;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
                            } else {
                                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb704;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
                            }
                        }
                        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb71c;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                     );
                    }
                    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb7b3;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
code_r0x0001801eb7b3:
                    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb7bb;
                    func_0x000180215310(iVar7);
                    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb7c3;
                    func_0x00018022ecc0(iVar8);
                    return uVar9;
                }
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb638;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
            }
        }
    }
    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb805;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                  *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                  *(int64_t *)(&stack0x00000028 + iVar6));
code_r0x0001801eb80b:
    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb81b;
    fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
    return 0;
}

// ============================================================
// Function: FUN_1801eb642
// Address: 0x1801eb642
// Size: 398 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801eb310(int64_t arg_b0h, int64_t arg_b8h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 uVar9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    var_30h = 0x1801eb32b;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    puVar1 = *(undefined8 **)(in_RCX + 8);
    uVar9 = 0;
    uVar2 = *(undefined8 *)(in_RCX + 0x40);
    if ((*(uint32_t *)(in_RCX + 0x160) & 0x800) == 0) {
        return 2;
    }
    if (puVar1[0x1c] == 0) {
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb363;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20)
                     );
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb37b;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20)
                      , *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6));
        goto code_r0x0001801eb80b;
    }
    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb399;
    iVar5 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                          *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)(&stack0x00000038 + iVar6));
    if (iVar5 == 0) {
code_r0x0001801eb7e8:
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb7ed;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20)
                     );
    } else {
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb3ae;
        iVar5 = fcn.180244a90(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb3c3;
        iVar5 = fcn.180244a90(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb3d7;
        iVar5 = func_0x0001802442e0(in_RDX, &var_40h);
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb3f0;
        iVar5 = func_0x000180244860(in_RDX, 0x1076, &var_68h);
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb40b;
        iVar5 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)(&stack0x00000038 + iVar6));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb426;
        iVar5 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)(&stack0x00000038 + iVar6));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb443;
        iVar5 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)(&stack0x00000038 + iVar6));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        uVar3 = *(undefined8 *)(in_RCX + 0x300);
        pcVar4 = *(code **)(*(int64_t *)(in_RCX + 0x18) + 0xb0);
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb467;
        iVar5 = (*pcVar4)(uVar3, in_RDX, &var_30h);
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb48a;
        iVar5 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)(&stack0x00000038 + iVar6));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb499;
        func_0x000180467bd4(0);
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb4aa;
        iVar5 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)(&stack0x00000038 + iVar6));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb4bf;
        iVar5 = fcn.180244a90(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb4d8;
        iVar5 = func_0x000180244860(in_RDX, 0x40, &var_88h);
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb4ea;
        iVar5 = func_0x0001801da790(in_RCX, 0);
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb508;
        iVar5 = func_0x000180197770(in_RCX, var_88h, 0x40, &var_60h);
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb520;
        iVar5 = func_0x000180243f60(in_RDX, var_60h, &var_58h);
        if ((iVar5 == 0) || (var_88h != var_58h)) {
code_r0x0001801eb7dc:
            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb7e1;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
        } else {
            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb53e;
            iVar5 = fcn.180244000(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6));
            if (iVar5 == 0) goto code_r0x0001801eb7dc;
            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb553;
            iVar5 = fcn.180244a90(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
            if (iVar5 == 0) goto code_r0x0001801eb7dc;
            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb56c;
            iVar5 = func_0x000180244860(in_RDX, 0x1000, &var_80h);
            if (iVar5 == 0) goto code_r0x0001801eb7dc;
            pcVar4 = (code *)puVar1[0x1c];
            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb588;
            iVar5 = (*pcVar4)(uVar2, var_80h, &var_50h);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb591;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb5a9;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6));
                goto code_r0x0001801eb80b;
            }
            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb5c4;
            iVar5 = func_0x000180243f60(in_RDX, var_50h, &var_48h);
            if ((iVar5 == 0) || (var_80h != var_48h)) {
code_r0x0001801eb7d0:
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb7d5;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
            } else {
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb5e2;
                iVar5 = fcn.180244000(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                      , *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6));
                if (iVar5 == 0) goto code_r0x0001801eb7d0;
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb5f6;
                iVar5 = func_0x0001802442e0(in_RDX, &var_8h);
                if (iVar5 == 0) goto code_r0x0001801eb7d0;
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb60f;
                iVar5 = func_0x000180244860(in_RDX, 0x20, &var_70h);
                if (iVar5 == 0) goto code_r0x0001801eb7d0;
                var_8h = var_8h - var_40h;
                var_78h = 0x20;
                if ((uint64_t)var_8h < 0x1057) {
                    *(undefined8 *)((int64_t)&arg_b0h + iVar6) = unaff_R14;
                    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb64f;
                    iVar7 = func_0x000180215470();
                    iVar8 = *(int64_t *)(in_RCX + 0xb88);
                    uVar2 = puVar1[0x8c];
                    uVar3 = *puVar1;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = 0x20;
                    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb67f;
                    iVar8 = func_0x00018022fea0(uVar3, 0x1804af24c, uVar2, iVar8 + 0x300);
                    if ((iVar7 == 0) || (iVar8 == 0)) {
                        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb785;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
                        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb79d;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                     );
                    } else {
                        uVar2 = *puVar1;
                        *(undefined8 *)((int64_t)&iStackX_10 + iVar6 + -8) = 0;
                        *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20) = iVar8;
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = puVar1[0x8c];
                        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb6be;
                        iVar5 = func_0x00018025c2e0(iVar7, 0, 0x1804b30b0, uVar2);
                        if (iVar5 < 1) {
code_r0x0001801eb774:
                            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb779;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
                        } else {
                            *(int64_t *)(&stack0xfffffffffffffff8 + iVar6) = var_8h;
                            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb6e3;
                            iVar5 = func_0x00018025bc60(iVar7, var_70h, &var_78h, var_68h);
                            if (iVar5 < 1) goto code_r0x0001801eb774;
                            if ((uint64_t)(var_8h + var_78h) < 0x1077) {
                                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb730;
                                iVar5 = func_0x000180243f60(in_RDX, var_78h, &var_38h);
                                if (((iVar5 != 0) && (var_70h == var_38h)) && (var_68h == var_70h - var_8h)) {
                                    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb750;
                                    iVar5 = fcn.180244000(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                                          *(int64_t *)(&stack0x00000028 + iVar6), 
                                                          *(int64_t *)(&stack0x00000030 + iVar6), 
                                                          *(int64_t *)(&stack0x00000038 + iVar6));
                                    if (iVar5 != 0) {
                                        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb75c;
                                        iVar5 = fcn.180244000(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                                              *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                                              *(int64_t *)(&stack0x00000028 + iVar6), 
                                                              *(int64_t *)(&stack0x00000030 + iVar6), 
                                                              *(int64_t *)(&stack0x00000038 + iVar6));
                                        if (iVar5 != 0) {
                                            uVar9 = 1;
                                            goto code_r0x0001801eb7b3;
                                        }
                                    }
                                }
                                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb76d;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
                            } else {
                                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb704;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
                            }
                        }
                        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb71c;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                     );
                    }
                    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb7b3;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
code_r0x0001801eb7b3:
                    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb7bb;
                    func_0x000180215310(iVar7);
                    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb7c3;
                    func_0x00018022ecc0(iVar8);
                    return uVar9;
                }
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb638;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
            }
        }
    }
    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb805;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                  *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                  *(int64_t *)(&stack0x00000028 + iVar6));
code_r0x0001801eb80b:
    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb81b;
    fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
    return 0;
}

// ============================================================
// Function: FUN_1801eb7d0
// Address: 0x1801eb7d0
// Size: 100 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801eb310(int64_t arg_b0h, int64_t arg_b8h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    code *pcVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 uVar9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    var_30h = 0x1801eb32b;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    puVar1 = *(undefined8 **)(in_RCX + 8);
    uVar9 = 0;
    uVar2 = *(undefined8 *)(in_RCX + 0x40);
    if ((*(uint32_t *)(in_RCX + 0x160) & 0x800) == 0) {
        return 2;
    }
    if (puVar1[0x1c] == 0) {
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb363;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20)
                     );
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb37b;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20)
                      , *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6));
        goto code_r0x0001801eb80b;
    }
    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb399;
    iVar5 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                          *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)(&stack0x00000038 + iVar6));
    if (iVar5 == 0) {
code_r0x0001801eb7e8:
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb7ed;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20)
                     );
    } else {
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb3ae;
        iVar5 = fcn.180244a90(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb3c3;
        iVar5 = fcn.180244a90(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb3d7;
        iVar5 = func_0x0001802442e0(in_RDX, &var_40h);
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb3f0;
        iVar5 = func_0x000180244860(in_RDX, 0x1076, &var_68h);
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb40b;
        iVar5 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)(&stack0x00000038 + iVar6));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb426;
        iVar5 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)(&stack0x00000038 + iVar6));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb443;
        iVar5 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)(&stack0x00000038 + iVar6));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        uVar3 = *(undefined8 *)(in_RCX + 0x300);
        pcVar4 = *(code **)(*(int64_t *)(in_RCX + 0x18) + 0xb0);
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb467;
        iVar5 = (*pcVar4)(uVar3, in_RDX, &var_30h);
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb48a;
        iVar5 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)(&stack0x00000038 + iVar6));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb499;
        func_0x000180467bd4(0);
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb4aa;
        iVar5 = fcn.1802446f0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)(&stack0x00000038 + iVar6));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb4bf;
        iVar5 = fcn.180244a90(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb4d8;
        iVar5 = func_0x000180244860(in_RDX, 0x40, &var_88h);
        if (iVar5 == 0) goto code_r0x0001801eb7e8;
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb4ea;
        iVar5 = func_0x0001801da790(in_RCX, 0);
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb508;
        iVar5 = func_0x000180197770(in_RCX, var_88h, 0x40, &var_60h);
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb520;
        iVar5 = func_0x000180243f60(in_RDX, var_60h, &var_58h);
        if ((iVar5 == 0) || (var_88h != var_58h)) {
code_r0x0001801eb7dc:
            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb7e1;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
        } else {
            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb53e;
            iVar5 = fcn.180244000(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                                  *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6));
            if (iVar5 == 0) goto code_r0x0001801eb7dc;
            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb553;
            iVar5 = fcn.180244a90(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
            if (iVar5 == 0) goto code_r0x0001801eb7dc;
            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb56c;
            iVar5 = func_0x000180244860(in_RDX, 0x1000, &var_80h);
            if (iVar5 == 0) goto code_r0x0001801eb7dc;
            pcVar4 = (code *)puVar1[0x1c];
            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb588;
            iVar5 = (*pcVar4)(uVar2, var_80h, &var_50h);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb591;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb5a9;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6));
                goto code_r0x0001801eb80b;
            }
            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb5c4;
            iVar5 = func_0x000180243f60(in_RDX, var_50h, &var_48h);
            if ((iVar5 == 0) || (var_80h != var_48h)) {
code_r0x0001801eb7d0:
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb7d5;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
            } else {
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb5e2;
                iVar5 = fcn.180244000(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                      , *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000038 + iVar6));
                if (iVar5 == 0) goto code_r0x0001801eb7d0;
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb5f6;
                iVar5 = func_0x0001802442e0(in_RDX, &var_8h);
                if (iVar5 == 0) goto code_r0x0001801eb7d0;
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb60f;
                iVar5 = func_0x000180244860(in_RDX, 0x20, &var_70h);
                if (iVar5 == 0) goto code_r0x0001801eb7d0;
                var_8h = var_8h - var_40h;
                var_78h = 0x20;
                if ((uint64_t)var_8h < 0x1057) {
                    *(undefined8 *)((int64_t)&arg_b0h + iVar6) = unaff_R14;
                    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb64f;
                    iVar7 = func_0x000180215470();
                    iVar8 = *(int64_t *)(in_RCX + 0xb88);
                    uVar2 = puVar1[0x8c];
                    uVar3 = *puVar1;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = 0x20;
                    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb67f;
                    iVar8 = func_0x00018022fea0(uVar3, 0x1804af24c, uVar2, iVar8 + 0x300);
                    if ((iVar7 == 0) || (iVar8 == 0)) {
                        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb785;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
                        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb79d;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                     );
                    } else {
                        uVar2 = *puVar1;
                        *(undefined8 *)((int64_t)&iStackX_10 + iVar6 + -8) = 0;
                        *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20) = iVar8;
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = puVar1[0x8c];
                        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb6be;
                        iVar5 = func_0x00018025c2e0(iVar7, 0, 0x1804b30b0, uVar2);
                        if (iVar5 < 1) {
code_r0x0001801eb774:
                            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb779;
                            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
                        } else {
                            *(int64_t *)(&stack0xfffffffffffffff8 + iVar6) = var_8h;
                            *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb6e3;
                            iVar5 = func_0x00018025bc60(iVar7, var_70h, &var_78h, var_68h);
                            if (iVar5 < 1) goto code_r0x0001801eb774;
                            if ((uint64_t)(var_8h + var_78h) < 0x1077) {
                                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb730;
                                iVar5 = func_0x000180243f60(in_RDX, var_78h, &var_38h);
                                if (((iVar5 != 0) && (var_70h == var_38h)) && (var_68h == var_70h - var_8h)) {
                                    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb750;
                                    iVar5 = fcn.180244000(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                                          *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                                          *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                                          *(int64_t *)(&stack0x00000028 + iVar6), 
                                                          *(int64_t *)(&stack0x00000030 + iVar6), 
                                                          *(int64_t *)(&stack0x00000038 + iVar6));
                                    if (iVar5 != 0) {
                                        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb75c;
                                        iVar5 = fcn.180244000(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                                              *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                                              *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                                                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                                                              *(int64_t *)(&stack0x00000028 + iVar6), 
                                                              *(int64_t *)(&stack0x00000030 + iVar6), 
                                                              *(int64_t *)(&stack0x00000038 + iVar6));
                                        if (iVar5 != 0) {
                                            uVar9 = 1;
                                            goto code_r0x0001801eb7b3;
                                        }
                                    }
                                }
                                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb76d;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
                            } else {
                                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb704;
                                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
                            }
                        }
                        *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb71c;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar6), *(int64_t *)(&stack0x00000028 + iVar6)
                                     );
                    }
                    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb7b3;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
code_r0x0001801eb7b3:
                    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb7bb;
                    func_0x000180215310(iVar7);
                    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb7c3;
                    func_0x00018022ecc0(iVar8);
                    return uVar9;
                }
                *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb638;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20));
            }
        }
    }
    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb805;
    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -0x20), 
                  *(int64_t *)((int64_t)&iStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar6), 
                  *(int64_t *)(&stack0x00000028 + iVar6));
code_r0x0001801eb80b:
    *(undefined8 *)((int64_t)&var_30h + iVar6) = 0x1801eb81b;
    fcn.18019b5e0(*(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8));
    return 0;
}

// ============================================================
// Function: FUN_1801eb840
// Address: 0x1801eb840
// Size: 271 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.1801eb840(int64_t arg_68h, int64_t arg_70h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint32_t uVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    undefined4 var_30h;
    undefined4 var_2ch;
    undefined4 var_28h;
    undefined4 var_24h;
    undefined4 uStack_20;
    int64_t var_1ch;
    int64_t var_10h;
    
    var_10h = 0x1801eb858;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2);
    var_38h._0_4_ = 0x2000e8fd;
    var_38h._4_4_ = 0x8301e30;
    var_30h = 0x852a0606;
    var_2ch = 0x9020203;
    var_28h = 0x6060830;
    var_24h = 0x203852a;
    uStack_20 = 0x8301602;
    var_1ch._0_4_ = 0x852a0606;
    var_1ch._4_4_ = 0x17020203;
    uVar4 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x18) & 0xffff;
    if ((uVar4 == 0x80) || (uVar4 == 0x81)) {
        *(undefined8 *)((int64_t)&var_10h + iVar2) = 0x1801eb8d3;
        uVar3 = func_0x000180193b40(in_RCX);
        if ((uVar3 >> 0x1f & 1) != 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar2) = 0x1801eb8f3;
            iVar1 = func_0x0001802445f0(in_RDX, &var_38h, 0x24);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&var_10h + iVar2) = 0x1801eb8fc;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
                *(undefined8 *)((int64_t)&var_10h + iVar2) = 0x1801eb914;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2));
                *(undefined8 *)((int64_t)&var_10h + iVar2) = 0x1801eb92a;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
            }
        }
    }
    uVar3 = var_10h ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2);
    *(undefined8 *)((int64_t)&var_10h + iVar2) = 0x1801eb93f;
    fcn.180459870(uVar3);
    return;
}

