// Chunk 28 - 50 functions

// ============================================================
// Function: FUN_180058920
// Address: 0x180058920
// Size: 100 bytes
// ============================================================
void fcn.180058920(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if (iVar3 != 0) {
        func_0x00018000ace0(iVar3 + 0x40);
        func_0x00018001c440(iVar3 + 0x30);
        piVar4 = *(int64_t **)(iVar3 + 0x18);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)(*piVar4 + 8))();
            }
        }
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        func_0x000180459c3c(*(int64_t *)(arg1 + 8), 0x68);
    }
    return;
}

// ============================================================
// Function: FUN_1800589b0
// Address: 0x1800589b0
// Size: 298 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800589b0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    undefined auVar4 [16];
    code *pcVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    undefined8 in_R9;
    bool bVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    undefined auStack_18 [16];
    
    _var_38h = ZEXT816(0);
    piVar7 = *(int64_t **)(*(int64_t *)(arg1 + 0x50) + 0x58);
    if (piVar7 == (int64_t *)0x0) {
        piVar7 = (int64_t *)0x0;
    } else {
        var_30h = (int64_t)piVar7;
        var_38h = *(undefined8 *)(*(int64_t *)(arg1 + 0x50) + 0x50);
        LOCK();
        *(int32_t *)((int64_t)piVar7 + 0xc) = *(int32_t *)((int64_t)piVar7 + 0xc) + 1;
        UNLOCK();
    }
    uVar10 = 0;
    uVar11 = 0;
    uVar12 = 0;
    uVar13 = 0;
    auStack_18 = ZEXT816(0);
    if (piVar7 != (int64_t *)0x0) {
        iVar3 = *(int32_t *)(piVar7 + 1);
        do {
            if (iVar3 == 0) goto code_r0x000180058a2d;
            LOCK();
            iVar6 = *(int32_t *)(piVar7 + 1);
            bVar9 = iVar3 == iVar6;
            if (bVar9) {
                *(int32_t *)(piVar7 + 1) = iVar3 + 1;
                iVar6 = iVar3;
            }
            UNLOCK();
            iVar3 = iVar6;
        } while (!bVar9);
        uVar10 = SUB164(_var_38h, 0);
        uVar11 = SUB164(_var_38h, 4);
        uVar12 = SUB164(_var_38h, 8);
        uVar13 = SUB164(_var_38h, 0xc);
        auStack_18 = _var_38h;
    }
code_r0x000180058a2d:
    pcVar5 = *(code **)0x180782630;
    auVar4._4_4_ = uVar11;
    auVar4._0_4_ = uVar10;
    auVar4._8_4_ = uVar12;
    auVar4._12_4_ = uVar13;
    piVar8 = auVar4._8_8_;
    if (CONCAT44(uVar11, uVar10) == 0) {
        func_0x000180086510(arg1);
    } else {
        if (piVar8 != (int64_t *)0x0) {
            LOCK();
            *(int32_t *)(piVar8 + 1) = *(int32_t *)(piVar8 + 1) + 1;
            UNLOCK();
        }
        var_28h._4_4_ = uVar11;
        var_28h._0_4_ = uVar10;
        unique0x100000a1 = uVar12;
        unique0x100000a5 = uVar13;
        (*pcVar5)(arg1, &var_28h, arg1, in_R9, _var_38h);
    }
    if (piVar8 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar8 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar8)(piVar8);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar8 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar8 + 8))(piVar8);
            }
        }
    }
    if (piVar7 != (int64_t *)0x0) {
        LOCK();
        piVar2 = (int32_t *)((int64_t)piVar7 + 0xc);
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)(*piVar7 + 8))(piVar7);
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180058ae0
// Address: 0x180058ae0
// Size: 382 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180058ae0(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t *piVar3;
    code *pcVar4;
    undefined auVar5 [16];
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    bool bVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    undefined auStack_18 [16];
    
    piVar9 = *(int64_t **)(arg1 + 0x28);
    piVar3 = *(int64_t **)(arg1 + 0x40);
    piVar10 = piVar9;
    if (piVar3 <= piVar9) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 10)) {
        func_0x000180088470(arg1, 1, 10);
        pcVar4 = (code *)swi(3);
        uVar8 = (*pcVar4)();
        return uVar8;
    }
    if (piVar3 <= piVar9) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar9 + 0xc) == 10) {
        iVar7 = *piVar9;
    } else {
        iVar7 = 0;
    }
    _var_38h = ZEXT816(0);
    piVar9 = *(int64_t **)(*(int64_t *)(iVar7 + 0x50) + 0x58);
    if (piVar9 == (int64_t *)0x0) {
        piVar9 = (int64_t *)0x0;
    } else {
        var_30h = (int64_t)piVar9;
        var_38h = *(undefined8 *)(*(int64_t *)(iVar7 + 0x50) + 0x50);
        LOCK();
        *(int32_t *)((int64_t)piVar9 + 0xc) = *(int32_t *)((int64_t)piVar9 + 0xc) + 1;
        UNLOCK();
    }
    uVar12 = 0;
    uVar13 = 0;
    uVar14 = 0;
    uVar15 = 0;
    auStack_18 = ZEXT816(0);
    if (piVar9 != (int64_t *)0x0) {
        iVar2 = *(int32_t *)(piVar9 + 1);
        do {
            if (iVar2 == 0) goto code_r0x000180058b9d;
            LOCK();
            iVar6 = *(int32_t *)(piVar9 + 1);
            bVar11 = iVar2 == iVar6;
            if (bVar11) {
                *(int32_t *)(piVar9 + 1) = iVar2 + 1;
                iVar6 = iVar2;
            }
            UNLOCK();
            iVar2 = iVar6;
        } while (!bVar11);
        uVar12 = SUB164(_var_38h, 0);
        uVar13 = SUB164(_var_38h, 4);
        uVar14 = SUB164(_var_38h, 8);
        uVar15 = SUB164(_var_38h, 0xc);
        auStack_18 = _var_38h;
    }
code_r0x000180058b9d:
    pcVar4 = *(code **)0x180782630;
    auVar5._4_4_ = uVar13;
    auVar5._0_4_ = uVar12;
    auVar5._8_4_ = uVar14;
    auVar5._12_4_ = uVar15;
    piVar10 = auVar5._8_8_;
    if (CONCAT44(uVar13, uVar12) == 0) {
        func_0x000180086510(arg1);
    } else {
        if (piVar10 != (int64_t *)0x0) {
            LOCK();
            *(int32_t *)(piVar10 + 1) = *(int32_t *)(piVar10 + 1) + 1;
            UNLOCK();
        }
        var_28h._4_4_ = uVar13;
        var_28h._0_4_ = uVar12;
        unique0x100000b3 = uVar14;
        unique0x100000b7 = uVar15;
        (*pcVar4)(arg1, &var_28h, piVar3, arg1, _var_38h);
    }
    if (piVar10 != (int64_t *)0x0) {
        LOCK();
        piVar3 = piVar10 + 1;
        iVar2 = *(int32_t *)piVar3;
        *(int32_t *)piVar3 = *(int32_t *)piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
            (**(code **)*piVar10)(piVar10);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar10 + 0xc);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)(*piVar10 + 8))(piVar10);
            }
        }
    }
    if (piVar9 != (int64_t *)0x0) {
        LOCK();
        piVar1 = (int32_t *)((int64_t)piVar9 + 0xc);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
            (**(code **)(*piVar9 + 8))(piVar9);
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180058c60
// Address: 0x180058c60
// Size: 1649 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h

void fcn.180058c60(int64_t arg1)
{
    char cVar1;
    int32_t *piVar2;
    undefined8 *puVar3;
    int64_t **ppiVar4;
    int64_t iVar5;
    int64_t *piVar6;
    code *pcVar7;
    undefined auVar8 [16];
    int64_t **ppiVar9;
    int32_t iVar10;
    int32_t iVar11;
    int32_t *piVar12;
    int64_t *piVar13;
    int64_t *piVar14;
    int64_t iVar15;
    undefined (*pauVar16) [16];
    int32_t *piVar17;
    uint64_t uVar18;
    uint64_t uVar19;
    int64_t **ppiVar20;
    undefined *puVar21;
    undefined *puVar22;
    int64_t iVar23;
    bool bVar24;
    bool bVar25;
    undefined auStack_d8 [8];
    undefined auStack_d0 [24];
    int64_t var_b8h;
    int64_t var_b0h;
    int32_t var_a8h;
    int32_t var_a4h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    
    puVar22 = auStack_d8;
    var_68h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_d8;
    bVar24 = false;
    var_a4h = 0;
    piVar12 = *(int32_t **)(arg1 + 0x28);
    piVar2 = *(int32_t **)(arg1 + 0x40);
    piVar17 = piVar12;
    if (piVar2 <= piVar12) {
        piVar17 = *(int32_t **)0x180782430;
    }
    var_a0h = arg1;
    if ((piVar17 != *(int32_t **)0x180782430) && (0 < piVar17[3])) {
        piVar17 = piVar12;
        if (piVar2 <= piVar12) {
            piVar17 = *(int32_t **)0x180782430;
        }
        puVar21 = auStack_d8;
        if ((piVar17 == *(int32_t **)0x180782430) || (puVar21 = auStack_d8, piVar17[3] != 1)) {
code_r0x0001800592ba:
            *(undefined8 *)(puVar21 + -8) = 0x1800592ca;
            func_0x000180088470(arg1, 1, 1);
            puVar22 = puVar21;
code_r0x0001800592cb:
            *(undefined8 *)(puVar22 + -8) = 0x1800592d0;
            func_0x000180092f10();
            pcVar7 = (code *)swi(3);
            (*pcVar7)();
            return;
        }
        if (piVar2 <= piVar12) {
            piVar12 = *(int32_t **)0x180782430;
        }
        if ((piVar12[3] == 0) || ((piVar12[3] == 1 && (*piVar12 == 0)))) {
            var_a8h = 0;
            goto code_r0x000180058d06;
        }
    }
    var_a8h = 1;
code_r0x000180058d06:
    var_a4h = 1;
    func_0x000180086fd0(arg1, 0, 0);
    iVar23 = *(int64_t *)(*(int64_t *)(arg1 + 0x50) + 0x98);
    var_b8h = 0;
    var_b0h = 0;
    var_90h = (int64_t)&var_b8h;
    var_98h = (int64_t)&var_b8h;
    piVar13 = (int64_t *)func_0x000180459890(0x30);
    *piVar13 = (int64_t)piVar13;
    piVar13[1] = (int64_t)piVar13;
    piVar13[2] = (int64_t)piVar13;
    *(undefined2 *)(piVar13 + 3) = 0x101;
    puVar3 = *(undefined8 **)(*(int64_t *)(iVar23 + 0x9e8) + 8);
    var_b8h = (int64_t)piVar13;
    if (*(char *)((int64_t)puVar3 + 0x19) == '\0') {
        var_80h = 0;
        var_88h = (int64_t)&var_b8h;
        piVar14 = (int64_t *)func_0x000180459890(0x30);
        piVar14[4] = 0;
        piVar14[5] = 0;
        if (puVar3[5] != 0) {
            piVar14[4] = puVar3[4];
            iVar15 = puVar3[5];
            piVar14[5] = iVar15;
            LOCK();
            piVar12 = (int32_t *)(iVar15 + 0xc);
            *piVar12 = *piVar12 + 1;
            UNLOCK();
        }
        *piVar14 = (int64_t)piVar13;
        piVar14[2] = (int64_t)piVar13;
        *(undefined2 *)(piVar14 + 3) = 0;
        piVar14[1] = (int64_t)piVar13;
        *(undefined *)(piVar14 + 3) = *(undefined *)(puVar3 + 3);
        var_80h = (int64_t)&var_b8h;
        var_88h = (int64_t)&var_b8h;
        var_78h = (int64_t)piVar14;
        iVar15 = func_0x00018005d270(&var_b8h, *puVar3, piVar14);
        *piVar14 = iVar15;
        iVar15 = func_0x00018005d270(&var_b8h, puVar3[2], piVar14);
        piVar14[2] = iVar15;
        piVar13 = piVar14;
    }
    *(int64_t **)(var_b8h + 8) = piVar13;
    var_b0h = *(int64_t *)(iVar23 + 0x9f0);
    ppiVar20 = *(int64_t ***)(var_b8h + 8);
    if (*(char *)((int64_t)ppiVar20 + 0x19) == '\0') {
        cVar1 = *(char *)((int64_t)*ppiVar20 + 0x19);
        ppiVar4 = (int64_t **)*ppiVar20;
        while (cVar1 == '\0') {
            cVar1 = *(char *)((int64_t)*ppiVar4 + 0x19);
            ppiVar20 = ppiVar4;
            ppiVar4 = (int64_t **)*ppiVar4;
        }
        *(int64_t ***)var_b8h = ppiVar20;
        iVar23 = *(int64_t *)(var_b8h + 8);
        cVar1 = *(char *)(*(int64_t *)(iVar23 + 0x10) + 0x19);
        while (cVar1 == '\0') {
            iVar23 = *(int64_t *)(iVar23 + 0x10);
            cVar1 = *(char *)(*(int64_t *)(iVar23 + 0x10) + 0x19);
        }
        *(int64_t *)(var_b8h + 0x10) = iVar23;
    } else {
        *(int64_t *)var_b8h = var_b8h;
        *(int64_t *)(var_b8h + 0x10) = var_b8h;
    }
    ppiVar20 = *(int64_t ***)var_b8h;
    cVar1 = *(char *)((int64_t)ppiVar20 + 0x19);
    iVar23 = arg1;
    do {
        if (cVar1 != '\0') {
            cVar1 = *(char *)((int64_t)*(int64_t **)(var_b8h + 8) + 0x19);
            piVar13 = *(int64_t **)(var_b8h + 8);
            while (cVar1 == '\0') {
                func_0x00018005c6d0(&var_b8h, &var_b8h, piVar13[2]);
                piVar14 = (int64_t *)piVar13[5];
                piVar6 = (int64_t *)*piVar13;
                if (piVar14 != (int64_t *)0x0) {
                    LOCK();
                    piVar12 = (int32_t *)((int64_t)piVar14 + 0xc);
                    iVar11 = *piVar12;
                    *piVar12 = *piVar12 + -1;
                    UNLOCK();
                    if (iVar11 == 1) {
                        (**(code **)(*piVar14 + 8))();
                    }
                }
                func_0x000180459c3c(piVar13, 0x30);
                piVar13 = piVar6;
                cVar1 = *(char *)((int64_t)piVar6 + 0x19);
            }
            func_0x000180459c3c(var_b8h, 0x30);
            func_0x000180459870(var_68h ^ (uint64_t)auStack_d8);
            return;
        }
        piVar13 = ppiVar20[5];
        if ((piVar13 != (int64_t *)0x0) && (*(int32_t *)(piVar13 + 1) != 0)) {
            iVar15 = 0;
            _var_98h = ZEXT816(0);
            iVar11 = *(int32_t *)(piVar13 + 1);
            do {
                if (iVar11 == 0) {
                    piVar13 = (int64_t *)0x0;
                    goto code_r0x000180058ef3;
                }
                LOCK();
                iVar10 = *(int32_t *)(piVar13 + 1);
                bVar25 = iVar11 == iVar10;
                if (bVar25) {
                    *(int32_t *)(piVar13 + 1) = iVar11 + 1;
                    iVar10 = iVar11;
                }
                UNLOCK();
                iVar11 = iVar10;
            } while (!bVar25);
            iVar15 = *(int64_t *)*(undefined (*) [16])(ppiVar20 + 4);
            piVar13 = ppiVar20[5];
            _var_98h = *(undefined (*) [16])(ppiVar20 + 4);
code_r0x000180058ef3:
            auVar8 = _var_98h;
            if (iVar15 != 0) {
                if (var_a8h != 0) {
                    arg1 = *(int64_t *)(iVar15 + 0x70);
code_r0x000180058f10:
                    if (arg1 == 0) {
                        uVar19 = var_70h;
                        iVar23 = var_88h;
code_r0x000180058f65:
                        bVar25 = false;
                    } else {
                        func_0x00018000b4d0(&var_88h, *(undefined8 *)(*(int64_t *)(arg1 + 0x18) + 8));
                        uVar19 = var_70h;
                        bVar24 = true;
                        iVar23 = var_88h;
                        piVar14 = &var_88h;
                        if (0xf < (uint64_t)var_70h) {
                            piVar14 = (int64_t *)var_88h;
                        }
                        if ((var_78h == 9) && (iVar11 = func_0x000180497f30(piVar14, 0x1806206c0), iVar11 == 0))
                        goto code_r0x000180058f65;
                        bVar25 = true;
                    }
                    if ((bVar24) && (bVar24 = false, 0xf < uVar19)) {
                        uVar18 = uVar19 + 1;
                        iVar15 = iVar23;
                        if (0xfff < uVar18) {
                            iVar15 = *(int64_t *)(iVar23 + -8);
                            if (0x1f < (iVar23 - iVar15) - 8U) goto code_r0x0001800592b3;
                            uVar18 = uVar19 + 0x28;
                        }
                        func_0x000180459c3c(iVar15, uVar18);
                    }
                    iVar23 = var_a0h;
                    if (!bVar25) goto code_r0x00018005910f;
                    func_0x00018000b4d0(&var_88h, *(undefined8 *)(*(int64_t *)(arg1 + 0x18) + 8));
                    iVar5 = var_70h;
                    iVar15 = var_78h;
                    iVar23 = var_88h;
                    piVar14 = &var_88h;
                    if (0xf < (uint64_t)var_70h) {
                        piVar14 = (int64_t *)var_88h;
                    }
                    if ((var_78h != 0xc) || (iVar11 = func_0x000180497f30(piVar14, 0x180625008, 0xc), iVar11 != 0)) {
                        piVar14 = &var_88h;
                        if (0xf < (uint64_t)iVar5) {
                            piVar14 = (int64_t *)iVar23;
                        }
                        if ((iVar15 == 7) && (iVar11 = func_0x000180497f30(piVar14, 0x180620c60, 7), iVar11 == 0))
                        goto code_r0x000180059061;
                        arg1 = *(int64_t *)(arg1 + 0x70);
                        if (0xf < (uint64_t)iVar5) {
                            uVar19 = iVar5 + 1;
                            iVar15 = iVar23;
                            if (0xfff < uVar19) {
                                iVar15 = *(int64_t *)(iVar23 + -8);
                                if (0x1f < (iVar23 - iVar15) - 8U) goto code_r0x0001800592b3;
                                uVar19 = iVar5 + 0x28;
                            }
                            func_0x000180459c3c(iVar15, uVar19);
                        }
                        goto code_r0x000180058f10;
                    }
code_r0x000180059061:
                    if (0xf < (uint64_t)iVar5) {
                        uVar19 = iVar5 + 1;
                        iVar15 = iVar23;
                        if (0xfff < uVar19) {
                            iVar15 = *(int64_t *)(iVar23 + -8);
                            if (0x1f < (iVar23 - iVar15) - 8U) {
code_r0x0001800592b3:
                                pcVar7 = (code *)swi(0x29);
                                (*pcVar7)(5);
                                puVar21 = auStack_d0;
                                goto code_r0x0001800592ba;
                            }
                            uVar19 = iVar5 + 0x28;
                        }
                        func_0x000180459c3c(iVar15, uVar19);
                    }
                    iVar23 = var_a0h;
                    if (piVar13 != (int64_t *)0x0) {
                        LOCK();
                        piVar14 = piVar13 + 1;
                        iVar11 = *(int32_t *)piVar14;
                        *(int32_t *)piVar14 = *(int32_t *)piVar14 + -1;
                        UNLOCK();
                        if (iVar11 == 1) {
                            (**(code **)*piVar13)(piVar13);
                            LOCK();
                            piVar12 = (int32_t *)((int64_t)piVar13 + 0xc);
                            iVar11 = *piVar12;
                            *piVar12 = *piVar12 + -1;
                            UNLOCK();
                            iVar23 = var_a0h;
                            if (iVar11 == 1) {
                                (**(code **)(*piVar13 + 8))(piVar13);
                                iVar23 = var_a0h;
                            }
                        }
                    }
                    goto code_r0x0001800590d3;
                }
code_r0x00018005910f:
                pcVar7 = *(code **)0x180782630;
                if (piVar13 != (int64_t *)0x0) {
                    LOCK();
                    *(int32_t *)(piVar13 + 1) = *(int32_t *)(piVar13 + 1) + 1;
                    UNLOCK();
                }
                _var_88h = auVar8;
                (*pcVar7)(iVar23, &var_88h);
                iVar11 = var_a4h;
                iVar15 = *(int64_t *)(iVar23 + 0x40);
                if (*(char *)(*(int64_t *)(iVar15 + -0x20) + 4) != '\0') goto code_r0x0001800592cb;
                var_a4h = var_a4h + 1;
                pauVar16 = (undefined (*) [16])func_0x0001800a1010(iVar23, *(int64_t *)(iVar15 + -0x20), iVar11);
                *pauVar16 = *(undefined (*) [16])(iVar15 + -0x10);
                if (5 < *(int32_t *)(*(int64_t *)(iVar23 + 0x40) + -4)) {
                    iVar15 = *(int64_t *)(iVar15 + -0x20);
                    if (((*(uint8_t *)(iVar15 + 1) & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(iVar23 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar5 = *(int64_t *)(iVar23 + 0x20);
                        if (*(char *)(iVar5 + 0x59) == '\x02') {
                            func_0x000180094420();
                        } else {
                            *(uint8_t *)(iVar15 + 1) = *(uint8_t *)(iVar15 + 1) & 0xfb;
                            *(undefined8 *)(iVar15 + 0x18) = *(undefined8 *)(iVar5 + 0x18);
                            *(int64_t *)(iVar5 + 0x18) = iVar15;
                        }
                    }
                }
                *(int64_t *)(iVar23 + 0x40) = *(int64_t *)(iVar23 + 0x40) + -0x10;
            }
            if (piVar13 != (int64_t *)0x0) {
                LOCK();
                piVar14 = piVar13 + 1;
                iVar11 = *(int32_t *)piVar14;
                *(int32_t *)piVar14 = *(int32_t *)piVar14 + -1;
                UNLOCK();
                if (iVar11 == 1) {
                    (**(code **)*piVar13)(piVar13);
                    LOCK();
                    piVar12 = (int32_t *)((int64_t)piVar13 + 0xc);
                    iVar11 = *piVar12;
                    *piVar12 = *piVar12 + -1;
                    UNLOCK();
                    if (iVar11 == 1) {
                        (**(code **)(*piVar13 + 8))(piVar13);
                    }
                }
            }
        }
code_r0x0001800590d3:
        ppiVar4 = (int64_t **)ppiVar20[2];
        if (*(char *)((int64_t)ppiVar4 + 0x19) == '\0') {
            cVar1 = *(char *)((int64_t)*ppiVar4 + 0x19);
            ppiVar20 = ppiVar4;
            ppiVar4 = (int64_t **)*ppiVar4;
            while (cVar1 == '\0') {
                cVar1 = *(char *)((int64_t)*ppiVar4 + 0x19);
                ppiVar20 = ppiVar4;
                ppiVar4 = (int64_t **)*ppiVar4;
            }
        } else {
            cVar1 = *(char *)((int64_t)ppiVar20[1] + 0x19);
            ppiVar9 = (int64_t **)ppiVar20[1];
            ppiVar4 = ppiVar20;
            while ((ppiVar20 = ppiVar9, cVar1 == '\0' && (ppiVar4 == (int64_t **)ppiVar20[2]))) {
                cVar1 = *(char *)((int64_t)ppiVar20[1] + 0x19);
                ppiVar9 = (int64_t **)ppiVar20[1];
                ppiVar4 = ppiVar20;
            }
        }
        cVar1 = *(char *)((int64_t)ppiVar20 + 0x19);
    } while( true );
}

// ============================================================
// Function: FUN_1800592e0
// Address: 0x1800592e0
// Size: 42 bytes
// ============================================================
void fcn.1800592e0(int64_t arg1)
{
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t in_stack_00000008;
    
    fcn.18005c6d0(in_stack_00000008);
    if ((*(int64_t *)arg1 != 0) &&
       (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)arg1, in_R9, unaff_RBX), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar1 = (undefined4 *)fcn.18046b77c();
        *puVar1 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_180059310
// Address: 0x180059310
// Size: 628 bytes
// ============================================================
void fcn.180059310(int64_t arg1)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    undefined8 *puVar10;
    undefined4 *puVar11;
    uint32_t uVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    undefined *puVar15;
    int64_t iVar16;
    int64_t *piVar17;
    int32_t iVar18;
    bool bVar19;
    undefined uStack_98;
    int64_t var_97h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    puVar15 = &uStack_98;
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)&uStack_98;
    func_0x000180086fd0(arg1, 0, 0);
    func_0x000180086ba0(arg1, *(undefined8 *)0x180782630, 0);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar10 = (undefined8 *)func_0x000180085370(arg1, 0xffffd8f0);
    iVar2 = *(int64_t *)(arg1 + 0x40);
    puVar11 = (undefined4 *)func_0x0001800a0ea0(*puVar10, iVar2 + -0x10);
    uVar5 = puVar11[1];
    uVar6 = puVar11[2];
    uVar7 = puVar11[3];
    *(undefined4 *)(iVar2 + -0x10) = *puVar11;
    *(undefined4 *)(iVar2 + -0xc) = uVar5;
    *(undefined4 *)(iVar2 + -8) = uVar6;
    *(undefined4 *)(iVar2 + -4) = uVar7;
    func_0x000180086510(arg1);
    iVar9 = func_0x000180087970(arg1, 0xfffffffe);
    iVar8 = 1;
    do {
        if (iVar9 == 0) {
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            func_0x000180459870(var_40h ^ (uint64_t)&uStack_98);
            return;
        }
        iVar2 = *(int64_t *)(arg1 + 0x40);
        if (*(int32_t *)(iVar2 + -4) == 9) {
            uVar12 = (uint32_t)*(uint8_t *)(*(int64_t *)(iVar2 + -0x10) + 3);
        } else {
            uVar12 = 0xffffffff;
        }
        iVar18 = iVar8;
        if (uVar12 == *(uint32_t *)0x1807823dc) {
            if (*(int32_t *)(iVar2 + -4) == 9) {
                piVar17 = (int64_t *)(*(int64_t *)(iVar2 + -0x10) + 0x10);
            } else if (*(int32_t *)(iVar2 + -4) == 2) {
                piVar17 = *(int64_t **)(iVar2 + -0x10);
            } else {
                piVar17 = (int64_t *)0x0;
            }
            if (piVar17[1] != 0) {
                LOCK();
                piVar1 = (int32_t *)(piVar17[1] + 8);
                *piVar1 = *piVar1 + 1;
                UNLOCK();
            }
            var_70h = *piVar17;
            piVar17 = (int64_t *)piVar17[1];
            var_68h = (int64_t)piVar17;
            func_0x00018000b4d0(&var_60h, *(undefined8 *)(*(int64_t *)(var_70h + 0x18) + 8));
            iVar3 = var_48h;
            iVar2 = var_60h;
            piVar13 = &var_60h;
            if (0xf < (uint64_t)var_48h) {
                piVar13 = (int64_t *)var_60h;
            }
            if (var_50h == 0xc) {
                iVar9 = func_0x000180497f30(piVar13, 0x1806244b0);
                bVar19 = iVar9 == 0;
            } else {
                bVar19 = false;
            }
            if (0xf < (uint64_t)iVar3) {
                uVar14 = iVar3 + 1;
                iVar16 = iVar2;
                if (0xfff < uVar14) {
                    iVar16 = *(int64_t *)(iVar2 + -8);
                    if (0x1f < (iVar2 - iVar16) - 8U) {
                        pcVar4 = (code *)swi(0x29);
                        (*pcVar4)(5);
                        puVar15 = (undefined *)((int64_t)&var_97h + 7);
                        goto code_r0x00018005957e;
                    }
                    uVar14 = iVar3 + 0x28;
                }
                func_0x000180459c3c(iVar16, uVar14);
            }
            if (piVar17 != (int64_t *)0x0) {
                LOCK();
                piVar13 = piVar17 + 1;
                iVar9 = *(int32_t *)piVar13;
                *(int32_t *)piVar13 = *(int32_t *)piVar13 + -1;
                UNLOCK();
                if (iVar9 == 1) {
                    (**(code **)*piVar17)(piVar17);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar17 + 0xc);
                    iVar9 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar9 == 1) {
                        (**(code **)(*piVar17 + 8))(piVar17);
                    }
                }
            }
            if (bVar19) {
                iVar2 = *(int64_t *)(arg1 + 0x40);
                if (*(char *)(*(int64_t *)(iVar2 + -0x40) + 4) != '\0') {
code_r0x00018005957e:
                    *(undefined8 *)(puVar15 + -8) = 0x180059583;
                    func_0x000180092f10();
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                iVar18 = iVar8 + 1;
                puVar11 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar2 + -0x40), iVar8);
                uVar5 = *(undefined4 *)(iVar2 + -0xc);
                uVar6 = *(undefined4 *)(iVar2 + -8);
                uVar7 = *(undefined4 *)(iVar2 + -4);
                *puVar11 = *(undefined4 *)(iVar2 + -0x10);
                puVar11[1] = uVar5;
                puVar11[2] = uVar6;
                puVar11[3] = uVar7;
                if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                    iVar2 = *(int64_t *)(iVar2 + -0x40);
                    if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar3 = *(int64_t *)(arg1 + 0x20);
                        if (*(char *)(iVar3 + 0x59) == '\x02') {
                            func_0x000180094420();
                        } else {
                            *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                            *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                            *(int64_t *)(iVar3 + 0x18) = iVar2;
                        }
                    }
                }
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        iVar9 = func_0x000180087970(arg1, 0xfffffffe);
        iVar8 = iVar18;
    } while( true );
}

// ============================================================
// Function: FUN_180059590
// Address: 0x180059590
// Size: 1945 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_19h
// WARNING: Variable defined which should be unmapped: var_21h
// WARNING: Variable defined which should be unmapped: var_29h
// WARNING: Variable defined which should be unmapped: var_39h
// WARNING: Variable defined which should be unmapped: var_41h
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_59h
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_67h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_51h

undefined8 fcn.180059590(int64_t arg1)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    code *pcVar12;
    undefined auVar13 [16];
    undefined4 uVar14;
    int32_t iVar15;
    undefined8 *puVar16;
    uint64_t uVar17;
    undefined4 *puVar18;
    int64_t iVar19;
    undefined8 *puVar20;
    int64_t *piVar21;
    uint64_t uVar22;
    uint64_t uVar23;
    int64_t *piVar24;
    uint64_t uVar25;
    int32_t iVar26;
    int32_t iVar27;
    bool bVar28;
    float fVar29;
    undefined auVar30 [16];
    undefined auVar31 [16];
    float fVar32;
    uint32_t uVar33;
    int32_t iVar34;
    undefined4 uVar35;
    undefined4 uVar36;
    int32_t iStackX_10;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    undefined auStack_d8 [16];
    uint64_t uStack_c8;
    uint64_t uStack_c0;
    undefined auStack_b8 [16];
    int64_t *piStack_a8;
    undefined8 *puStack_a0;
    undefined auStack_98 [16];
    int64_t iStack_88;
    undefined auStack_80 [7];
    int64_t var_79h;
    int64_t var_69h;
    int64_t var_61h;
    int64_t var_58h;
    int64_t var_49h;
    int64_t var_41h;
    int64_t var_39h;
    int64_t var_29h;
    int64_t var_21h;
    int64_t var_19h;
    undefined8 extraout_XMM0_Qb;
    
    iVar27 = 1;
    iStackX_10 = 1;
    func_0x000180086fd0(arg1, 0, 0);
    iVar3 = *(int64_t *)(arg1 + 0x50);
    if (*(int64_t *)(iVar3 + 0x20) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(iVar3 + 0x20) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    iVar19 = *(int64_t *)(iVar3 + 0x18);
    piVar21 = *(int64_t **)(iVar3 + 0x20);
    var_f0h = 0;
    var_e8h = 0;
    iStack_88 = iVar19;
    _auStack_80 = piVar21;
    var_f0h = func_0x000180459890(0x18);
    *(int64_t *)var_f0h = var_f0h;
    *(int64_t *)(var_f0h + 8) = var_f0h;
    var_e0h = 0;
    auStack_d8 = ZEXT816(0);
    uStack_c8 = 7;
    uStack_c0 = 8;
    func_0x00018000f7e0(&var_e0h, 0x10, var_f0h);
    puVar4 = *(undefined8 **)(iVar19 + 0x28);
    do {
        if (puVar4 == (undefined8 *)0x0) {
            func_0x00018000ace0(&var_e0h);
            func_0x00018001b580(&var_f0h);
            if (piVar21 != (int64_t *)0x0) {
                LOCK();
                piVar24 = piVar21 + 1;
                iVar27 = *(int32_t *)piVar24;
                *(int32_t *)piVar24 = *(int32_t *)piVar24 + -1;
                UNLOCK();
                if (iVar27 == 1) {
                    (**(code **)*piVar21)(piVar21);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar21 + 0xc);
                    iVar27 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar27 == 1) {
                        (**(code **)(*piVar21 + 8))(piVar21);
                    }
                }
            }
            return 1;
        }
        auStack_b8 = ZEXT816(0);
        piVar21 = (int64_t *)puVar4[0xb];
        if (piVar21 == (int64_t *)0x0) {
            piVar21 = (int64_t *)0x0;
        } else {
            auStack_b8._8_8_ = piVar21;
            auStack_b8._0_8_ = puVar4[10];
            LOCK();
            *(int32_t *)((int64_t)piVar21 + 0xc) = *(int32_t *)((int64_t)piVar21 + 0xc) + 1;
            UNLOCK();
        }
        uVar33 = 0;
        iVar34 = 0;
        uVar35 = 0;
        uVar36 = 0;
        unique0x100000e1 = ZEXT816(0);
        if (piVar21 != (int64_t *)0x0) {
            iVar26 = *(int32_t *)(piVar21 + 1);
            do {
                if (iVar26 == 0) goto code_r0x0001800596f8;
                LOCK();
                iVar15 = *(int32_t *)(piVar21 + 1);
                bVar28 = iVar26 == iVar15;
                if (bVar28) {
                    *(int32_t *)(piVar21 + 1) = iVar26 + 1;
                    iVar15 = iVar26;
                }
                UNLOCK();
                iVar26 = iVar15;
            } while (!bVar28);
            uVar33 = auStack_b8._0_4_;
            iVar34 = auStack_b8._4_4_;
            uVar35 = auStack_b8._8_4_;
            uVar36 = auStack_b8._12_4_;
            unique0x1000086c = auStack_b8;
        }
code_r0x0001800596f8:
        auVar13._4_4_ = iVar34;
        auVar13._0_4_ = uVar33;
        auVar13._8_4_ = uVar35;
        auVar13._12_4_ = uVar36;
        piVar24 = auVar13._8_8_;
        iVar3 = CONCAT44(iVar34, uVar33);
        if (iVar3 != 0) {
            uVar25 = (((((((((uint64_t)uVar33 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3 ^ iVar3 >> 8 & 0xffU) *
                           0x100000001b3 ^ iVar3 >> 0x10 & 0xffU) * 0x100000001b3 ^ iVar3 >> 0x18 & 0xffU) *
                         0x100000001b3 ^ (int64_t)iVar34 & 0xffU) * 0x100000001b3 ^ (int64_t)iVar34 >> 8 & 0xffU) *
                       0x100000001b3 ^ (int64_t)iVar34 >> 0x10 & 0xffU) * 0x100000001b3 ^
                     (int64_t)iVar34 >> 0x18 & 0xffU) * 0x100000001b3;
            uVar22 = uVar25 & uStack_c8;
            puVar16 = *(undefined8 **)(var_e0h + 8 + uVar22 * 0x10);
            if (puVar16 == (undefined8 *)var_f0h) {
                puVar20 = (undefined8 *)0x0;
            } else {
                iVar19 = puVar16[2];
                puVar20 = puVar16;
                while (iVar3 != iVar19) {
                    if (puVar20 == *(undefined8 **)(var_e0h + uVar22 * 0x10)) {
                        puVar20 = (undefined8 *)0x0;
                        break;
                    }
                    puVar20 = (undefined8 *)puVar20[1];
                    iVar19 = puVar20[2];
                }
            }
            if (puVar20 == (undefined8 *)0x0) {
                puVar20 = (undefined8 *)var_f0h;
                if (puVar16 == (undefined8 *)var_f0h) {
code_r0x000180059837:
                    if (var_e8h == 0xaaaaaaaaaaaaaaa) {
                        func_0x0001804546d4(0x180620428);
                        pcVar12 = (code *)swi(3);
                        auVar30._0_8_ = (*pcVar12)();
                        return auVar30._0_8_;
                    }
                    piStack_a8 = &var_f0h;
                    puStack_a0 = (undefined8 *)0x0;
                    puVar16 = (undefined8 *)func_0x000180459890(0x18);
                    uVar23 = uStack_c0;
                    puVar16[2] = iVar3;
                    uVar22 = var_e8h + 1;
                    if ((int64_t)uVar22 < 0) {
                        fVar29 = (float)(uVar22 >> 1 | (uint64_t)((uint32_t)uVar22 & 1));
                        fVar29 = fVar29 + fVar29;
                    } else {
                        fVar29 = (float)uVar22;
                    }
                    if ((int64_t)uStack_c0 < 0) {
                        fVar32 = (float)(uStack_c0 >> 1 | (uint64_t)((uint32_t)uStack_c0 & 1));
                        fVar32 = fVar32 + fVar32;
                    } else {
                        fVar32 = (float)uStack_c0;
                    }
                    if (1.0 < fVar29 / fVar32) {
                        puStack_a0 = puVar16;
                        auVar30._0_8_ = func_0x000180471c90(fVar29 / 1.0);
                        iVar3 = var_f0h;
                        auVar30._8_8_ = extraout_XMM0_Qb;
                        iVar19 = 0;
                        if ((9.223372e+18 <= (float)auVar30._0_8_) &&
                           (auVar31._4_12_ = auVar30._4_12_, auVar31._0_4_ = (float)auVar30._0_8_ - 9.223372e+18,
                           auVar30._0_8_ = auVar31._0_8_, auVar31._0_4_ < 9.223372e+18)) {
                            iVar19 = -0x8000000000000000;
                        }
                        uVar17 = (int64_t)(float)auVar30._0_8_ + iVar19;
                        uVar22 = 8;
                        if (8 < uVar17) {
                            uVar22 = uVar17;
                        }
                        uVar17 = uVar23;
                        if ((uVar23 < uVar22) && ((0x1ff < uVar23 || (uVar17 = uVar23 * 8, uVar23 * 8 < uVar22)))) {
                            uVar17 = uVar22;
                        }
                        for (iVar19 = 0x3f; 0xfffffffffffffffU >> iVar19 == 0; iVar19 = iVar19 + -1) {
                        }
                        if ((uint64_t)(1LL << ((uint8_t)iVar19 & 0x3f)) < uVar17) goto code_r0x000180059d1c;
                        uVar22 = uVar17 - 1 | 1;
                        iVar19 = 0x3f;
                        if (uVar22 != 0) {
                            for (; uVar22 >> iVar19 == 0; iVar19 = iVar19 + -1) {
                            }
                        }
                        uVar22 = 1LL << ((char)iVar19 + 1U & 0x3f);
                        func_0x00018000f7e0(&var_e0h, uVar22 * 2, var_f0h);
                        uStack_c8 = uVar22 - 1;
                        piVar2 = *(int64_t **)var_f0h;
joined_r0x000180059993:
                        if (piVar2 != (int64_t *)iVar3) {
                            piVar5 = (int64_t *)*piVar2;
                            uVar23 = (((((((((uint64_t)*(uint8_t *)(piVar2 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                           (uint64_t)*(uint8_t *)((int64_t)piVar2 + 0x11)) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)piVar2 + 0x12)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)piVar2 + 0x13)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)piVar2 + 0x14)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)piVar2 + 0x15)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)piVar2 + 0x16)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)piVar2 + 0x17)) * 0x100000001b3 & uStack_c8;
                            ppiVar6 = *(int64_t ***)(var_e0h + uVar23 * 0x10);
                            if (ppiVar6 == (int64_t **)iVar3) {
                                *(int64_t **)(var_e0h + uVar23 * 0x10) = piVar2;
                                *(int64_t **)(var_e0h + 8 + uVar23 * 0x10) = piVar2;
                                piVar2 = piVar5;
                            } else {
                                ppiVar7 = *(int64_t ***)(var_e0h + 8 + uVar23 * 0x10);
                                if ((int64_t *)piVar2[2] == ppiVar7[2]) {
                                    piVar8 = *ppiVar7;
                                    if (piVar8 != piVar2) {
                                        piVar9 = (int64_t *)piVar2[1];
                                        *piVar9 = (int64_t)piVar5;
                                        ppiVar6 = (int64_t **)piVar5[1];
                                        *ppiVar6 = piVar8;
                                        ppiVar7 = (int64_t **)piVar8[1];
                                        *ppiVar7 = piVar2;
                                        piVar8[1] = (int64_t)ppiVar6;
                                        piVar5[1] = (int64_t)piVar9;
                                        piVar2[1] = (int64_t)ppiVar7;
                                    }
                                    *(int64_t **)(var_e0h + 8 + uVar23 * 0x10) = piVar2;
                                    piVar2 = piVar5;
                                } else {
                                    do {
                                        if (ppiVar6 == ppiVar7) {
                                            piVar8 = (int64_t *)piVar2[1];
                                            *piVar8 = (int64_t)piVar5;
                                            piVar9 = (int64_t *)piVar5[1];
                                            *piVar9 = (int64_t)ppiVar7;
                                            ppiVar6 = (int64_t **)ppiVar7[1];
                                            *ppiVar6 = piVar2;
                                            ppiVar7[1] = piVar9;
                                            piVar5[1] = (int64_t)piVar8;
                                            piVar2[1] = (int64_t)ppiVar6;
                                            *(int64_t **)(var_e0h + uVar23 * 0x10) = piVar2;
                                            piVar2 = piVar5;
                                            goto joined_r0x000180059993;
                                        }
                                        ppiVar7 = (int64_t **)ppiVar7[1];
                                    } while ((int64_t *)piVar2[2] != ppiVar7[2]);
                                    piVar8 = *ppiVar7;
                                    piVar9 = (int64_t *)piVar2[1];
                                    *piVar9 = (int64_t)piVar5;
                                    ppiVar6 = (int64_t **)piVar5[1];
                                    *ppiVar6 = piVar8;
                                    ppiVar7 = (int64_t **)piVar8[1];
                                    *ppiVar7 = piVar2;
                                    piVar8[1] = (int64_t)ppiVar6;
                                    piVar5[1] = (int64_t)piVar9;
                                    piVar2[1] = (int64_t)ppiVar7;
                                    piVar2 = piVar5;
                                }
                            }
                            goto joined_r0x000180059993;
                        }
                        puVar10 = *(undefined8 **)(var_e0h + 8 + (uVar25 & uStack_c8) * 0x10);
                        puVar20 = (undefined8 *)var_f0h;
                        uStack_c0 = uVar22;
                        if (puVar10 != (undefined8 *)var_f0h) {
                            iVar3 = puVar10[2];
                            puVar20 = puVar10;
                            while (puVar16[2] != iVar3) {
                                if (puVar20 == *(undefined8 **)(var_e0h + (uVar25 & uStack_c8) * 0x10))
                                goto code_r0x000180059b08;
                                puVar20 = (undefined8 *)puVar20[1];
                                iVar3 = puVar20[2];
                            }
                            puVar20 = (undefined8 *)*puVar20;
                        }
                    }
code_r0x000180059b08:
                    puStack_a0 = (undefined8 *)0x0;
                    puVar10 = (undefined8 *)puVar20[1];
                    var_e8h = var_e8h + 1;
                    *puVar16 = puVar20;
                    puVar16[1] = puVar10;
                    *puVar10 = puVar16;
                    puVar20[1] = puVar16;
                    uVar25 = uVar25 & uStack_c8;
                    puVar11 = *(undefined8 **)(var_e0h + uVar25 * 0x10);
                    iVar26 = iStackX_10;
                    if (puVar11 == (undefined8 *)var_f0h) {
                        *(undefined8 **)(var_e0h + uVar25 * 0x10) = puVar16;
code_r0x000180059b87:
                        *(undefined8 **)(var_e0h + 8 + uVar25 * 0x10) = puVar16;
                    } else if (puVar11 == puVar20) {
                        *(undefined8 **)(var_e0h + uVar25 * 0x10) = puVar16;
                    } else if (*(undefined8 **)(var_e0h + 8 + uVar25 * 0x10) == puVar10) goto code_r0x000180059b87;
                } else {
                    iVar19 = puVar16[2];
                    puVar20 = puVar16;
                    while (iVar26 = iVar27, iVar3 != iVar19) {
                        if (puVar20 == *(undefined8 **)(uVar22 * 0x10 + var_e0h)) goto code_r0x000180059837;
                        puVar20 = (undefined8 *)puVar20[1];
                        iVar19 = puVar20[2];
                    }
                }
                pcVar12 = *(code **)0x180782630;
                if (piVar24 != (int64_t *)0x0) {
                    LOCK();
                    *(int32_t *)(piVar24 + 1) = *(int32_t *)(piVar24 + 1) + 1;
                    UNLOCK();
                }
                auStack_98._4_4_ = iVar34;
                auStack_98._0_4_ = uVar33;
                auStack_98._8_4_ = uVar35;
                auStack_98._12_4_ = uVar36;
                (*pcVar12)(arg1, auStack_98);
                iVar3 = *(int64_t *)(arg1 + 0x40);
                if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                    func_0x000180092f10(arg1);
code_r0x000180059d1c:
                    func_0x0001804546d4(0x180620448);
                    pcVar12 = (code *)swi(3);
                    auVar30._0_8_ = (*pcVar12)();
                    return auVar30._0_8_;
                }
                iVar27 = iVar26 + 1;
                puVar18 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar3 + -0x20), iVar26);
                uVar35 = *(undefined4 *)(iVar3 + -0xc);
                uVar36 = *(undefined4 *)(iVar3 + -8);
                uVar14 = *(undefined4 *)(iVar3 + -4);
                *puVar18 = *(undefined4 *)(iVar3 + -0x10);
                puVar18[1] = uVar35;
                puVar18[2] = uVar36;
                puVar18[3] = uVar14;
                if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                    iVar3 = *(int64_t *)(iVar3 + -0x20);
                    if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar19 = *(int64_t *)(arg1 + 0x20);
                        if (*(char *)(iVar19 + 0x59) == '\x02') {
                            func_0x000180094420();
                        } else {
                            *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                            *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar19 + 0x18);
                            *(int64_t *)(iVar19 + 0x18) = iVar3;
                        }
                    }
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                iStackX_10 = iVar27;
            }
        }
        if (piVar24 != (int64_t *)0x0) {
            LOCK();
            piVar2 = piVar24 + 1;
            iVar34 = *(int32_t *)piVar2;
            *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
            UNLOCK();
            if (iVar34 == 1) {
                (**(code **)*piVar24)(piVar24);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar24 + 0xc);
                iVar34 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar34 == 1) {
                    (**(code **)(*piVar24 + 8))(piVar24);
                }
            }
        }
        if (piVar21 != (int64_t *)0x0) {
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar21 + 0xc);
            iVar34 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar34 == 1) {
                (**(code **)(*piVar21 + 8))(piVar21);
            }
        }
        puVar4 = (undefined8 *)*puVar4;
        piVar21 = _auStack_80;
    } while( true );
}

// ============================================================
// Function: FUN_180059d30
// Address: 0x180059d30
// Size: 32 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018001b5b8: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018001b5bd)
// WARNING: Removing unreachable block (ram,0x00018001b5c5)

void fcn.180059d30(int64_t arg1, int64_t arg_30h)
{
    int32_t iVar1;
    undefined4 uVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    undefined8 unaff_RBX;
    int64_t var_8h;
    undefined8 auStack_30 [5];
    
    auStack_30[0] = 0x180059d42;
    func_0x00018000ace0(arg1 + 0x18);
    piVar4 = *(int64_t **)(arg1 + 8);
    *(undefined8 *)piVar4[1] = 0;
    piVar4 = (int64_t *)*piVar4;
    if (piVar4 == (int64_t *)0x0) {
        piVar4 = *(int64_t **)(arg1 + 8);
    } else {
        unaff_RBX = *piVar4;
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
        auStack_30[0] = 0x18001b5bd;
    }
    if (piVar4 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, piVar4);
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar2 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar2 = fcn.18046b63c(uVar2);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar3 = (undefined4 *)fcn.18046b77c();
            *puVar3 = uVar2;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180059d50
// Address: 0x180059d50
// Size: 1762 bytes
// ============================================================
void fcn.180059d50(int64_t arg1)
{
    int32_t *piVar1;
    int64_t *piVar2;
    uint64_t uVar3;
    undefined8 *puVar4;
    int64_t iVar5;
    int64_t iVar6;
    code *pcVar7;
    undefined auVar8 [16];
    int32_t iVar9;
    int64_t **ppiVar10;
    int64_t *piVar11;
    int32_t iVar12;
    int64_t **ppiVar13;
    int32_t iVar14;
    int64_t iVar15;
    int64_t *piVar16;
    undefined *puVar17;
    undefined *puVar18;
    uint64_t uVar19;
    bool bVar20;
    int64_t *piVar21;
    undefined4 uVar22;
    undefined4 uVar23;
    undefined4 uVar24;
    undefined4 uVar25;
    int64_t var_e0h;
    undefined auStack_d8 [8];
    undefined auStack_d0 [40];
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar17 = auStack_d8;
    puVar18 = auStack_d8;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_d8;
    ppiVar13 = *(int64_t ***)(arg1 + 0x28);
    ppiVar10 = ppiVar13;
    if (*(int64_t ***)(arg1 + 0x40) <= ppiVar13) {
        ppiVar10 = *(int64_t ***)0x180782430;
    }
    if (((*(int32_t *)((int64_t)ppiVar10 + 0xc) != 9) ||
        (*(uint8_t *)((int64_t)*ppiVar10 + 3) != *(uint32_t *)0x1807823dc)) ||
       (*ppiVar10 == (int64_t *)0xfffffffffffffff0)) {
code_r0x00018005a3f0:
        func_0x000180088380(arg1, 1, 0x1806217c8);
code_r0x00018005a405:
        func_0x000180088380(arg1, 1, 0x180624510);
        pcVar7 = (code *)swi(3);
        (*pcVar7)();
        return;
    }
    if (*(int64_t ***)(arg1 + 0x40) <= ppiVar13) {
        ppiVar13 = *(int64_t ***)0x180782430;
    }
    if (*(int32_t *)((int64_t)ppiVar13 + 0xc) == 9) {
        piVar16 = *ppiVar13 + 2;
    } else if (*(int32_t *)((int64_t)ppiVar13 + 0xc) == 2) {
        piVar16 = *ppiVar13;
    } else {
        piVar16 = (int64_t *)0x0;
    }
    if (piVar16[1] != 0) {
        LOCK();
        piVar1 = (int32_t *)(piVar16[1] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    iVar15 = *piVar16;
    piVar16 = (int64_t *)piVar16[1];
    var_98h = iVar15;
    var_90h = (int64_t)piVar16;
    func_0x00018000b4d0(&var_78h, *(undefined8 *)(*(int64_t *)(iVar15 + 0x18) + 8));
    piVar11 = &var_78h;
    if (0xf < (uint64_t)var_60h) {
        piVar11 = (int64_t *)var_78h;
    }
    if ((var_68h != 0xb) || (iVar9 = func_0x000180497f30(piVar11, 0x1806217e0, 0xb), iVar9 != 0)) {
        piVar11 = &var_78h;
        if (0xf < (uint64_t)var_60h) {
            piVar11 = (int64_t *)var_78h;
        }
        if ((var_68h != 6) || (iVar9 = func_0x000180497f30(piVar11, 0x1806244a4, 6), iVar9 != 0)) {
            piVar11 = &var_78h;
            if (0xf < (uint64_t)var_60h) {
                piVar11 = (int64_t *)var_78h;
            }
            if ((var_68h != 0xc) || (iVar9 = func_0x000180497f30(piVar11, 0x1806244b0, 0xc), iVar9 != 0)) {
                func_0x000180088380(arg1, 1, 0x1806244c0);
                goto code_r0x00018005a3f0;
            }
        }
    }
    piVar11 = &var_78h;
    if (0xf < (uint64_t)var_60h) {
        piVar11 = (int64_t *)var_78h;
    }
    if (((var_68h == 6) && (iVar9 = func_0x000180497f30(piVar11, 0x1806244a4, 6), iVar9 == 0)) &&
       (*(int32_t *)(iVar15 + 0x148) != 2)) goto code_r0x00018005a405;
    piVar11 = &var_78h;
    if (0xf < (uint64_t)var_60h) {
        piVar11 = (int64_t *)var_78h;
    }
    if ((var_68h == 0xb) && (iVar9 = func_0x000180497f30(piVar11, 0x1806217e0, 0xb), iVar9 == 0)) {
code_r0x000180059f27:
        if (*(int64_t *)(iVar15 + 0x180) == 0) {
            func_0x000180086510();
            puVar17 = auStack_d8;
            if ((uint64_t)var_60h < 0x10) goto joined_r0x00018005a36d;
            puVar18 = auStack_d8;
            if (0xfff < var_60h + 1U) {
                uVar3 = *(uint64_t *)(var_78h + -8);
joined_r0x000180059ff9:
                uVar19 = (var_78h - uVar3) - 8;
                var_78h = uVar3;
                puVar18 = auStack_d8;
                if (0x1f < uVar19) goto code_r0x00018005a371;
            }
        } else {
            piVar11 = *(int64_t **)(*(int64_t *)(iVar15 + 0x180) + 0x10);
            if (piVar11 == (int64_t *)0x0) {
                func_0x000180086510();
                puVar17 = auStack_d8;
                if ((uint64_t)var_60h < 0x10) goto joined_r0x00018005a36d;
                puVar18 = auStack_d8;
                if (0xfff < var_60h + 1U) {
                    uVar3 = *(uint64_t *)(var_78h + -8);
                    goto joined_r0x000180059ff9;
                }
            } else {
                iVar15 = *piVar11;
                if (iVar15 != 0) {
                    iVar9 = func_0x000180086ed0(arg1, 0xffffd8f0, *(undefined4 *)(iVar15 + 0x30));
                    if (iVar9 == 10) {
                        piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
                        if (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 10) {
                            iVar15 = *piVar11;
                        } else {
                            iVar15 = 0;
                        }
                        *(int64_t **)(arg1 + 0x40) = piVar11;
                        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                        }
                        puVar4 = *(undefined8 **)(arg1 + 0x40);
                        *puVar4 = *(undefined8 *)(iVar15 + 0x58);
                        *(undefined4 *)((int64_t)puVar4 + 0xc) = 7;
                        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                            iVar9 = *(int32_t *)(arg1 + 0x60);
                            iVar12 = (int32_t)(int32_t *)(arg1 + 0x60);
                            iVar14 = iVar9 - iVar12;
                            if (iVar9 - iVar12 < 1) {
                                iVar14 = iVar14 + 1;
                            } else {
                                iVar14 = iVar14 * 2;
                            }
                            func_0x000180093240(arg1, iVar14, 0);
                        }
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                        goto code_r0x000180059fcf;
                    }
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                }
                func_0x000180086510(arg1);
code_r0x000180059fcf:
                if ((uint64_t)var_60h < 0x10) goto joined_r0x00018005a36d;
                if (0xfff < var_60h + 1U) {
                    uVar3 = *(uint64_t *)(var_78h + -8);
                    goto joined_r0x000180059ff9;
                }
            }
        }
    } else {
        piVar11 = &var_78h;
        if (0xf < (uint64_t)var_60h) {
            piVar11 = (int64_t *)var_78h;
        }
        if ((var_68h == 6) && (iVar9 = func_0x000180497f30(piVar11, 0x1806244a4, 6), iVar9 == 0))
        goto code_r0x000180059f27;
        piVar11 = &var_78h;
        if (0xf < (uint64_t)var_60h) {
            piVar11 = (int64_t *)var_78h;
        }
        if ((var_68h != 0xc) || (iVar9 = func_0x000180497f30(piVar11, 0x1806244b0, 0xc), iVar9 != 0))
        goto code_r0x000180059fcf;
        func_0x000180085bf0(arg1, 0xffffd8f0);
        func_0x000180086510(arg1);
        iVar9 = func_0x000180087970(arg1, 0xfffffffe);
        while (iVar9 != 0) {
            iVar5 = *(int64_t *)(arg1 + 0x40);
            if (((int64_t **)(iVar5 - 0x10U) != *(int64_t ***)0x180782430) && (*(int32_t *)(iVar5 + -4) == 10)) {
                iVar5 = *(int64_t *)(iVar5 + -0x10);
                iVar6 = *(int64_t *)(iVar5 + 0x50);
                _var_a8h = ZEXT816(0);
                piVar11 = *(int64_t **)(iVar6 + 0x58);
                if (piVar11 == (int64_t *)0x0) {
                    piVar11 = (int64_t *)0x0;
                } else {
                    var_a0h = (int64_t)piVar11;
                    var_a8h = *(undefined8 *)(iVar6 + 0x50);
                    LOCK();
                    *(int32_t *)((int64_t)piVar11 + 0xc) = *(int32_t *)((int64_t)piVar11 + 0xc) + 1;
                    UNLOCK();
                }
                uVar22 = 0;
                uVar23 = 0;
                uVar24 = 0;
                uVar25 = 0;
                _var_88h = ZEXT816(0);
                if (piVar11 != (int64_t *)0x0) {
                    iVar9 = *(int32_t *)(piVar11 + 1);
                    do {
                        if (iVar9 == 0) goto code_r0x00018005a1aa;
                        LOCK();
                        iVar14 = *(int32_t *)(piVar11 + 1);
                        bVar20 = iVar9 == iVar14;
                        if (bVar20) {
                            *(int32_t *)(piVar11 + 1) = iVar9 + 1;
                            iVar14 = iVar9;
                        }
                        UNLOCK();
                        iVar9 = iVar14;
                    } while (!bVar20);
                    uVar22 = SUB164(_var_a8h, 0);
                    uVar23 = SUB164(_var_a8h, 4);
                    uVar24 = SUB164(_var_a8h, 8);
                    uVar25 = SUB164(_var_a8h, 0xc);
                    _var_88h = _var_a8h;
                }
code_r0x00018005a1aa:
                auVar8._4_4_ = uVar23;
                auVar8._0_4_ = uVar22;
                auVar8._8_4_ = uVar24;
                auVar8._12_4_ = uVar25;
                piVar21 = auVar8._8_8_;
                if ((((CONCAT44(uVar23, uVar22) != 0) && (piVar21 != (int64_t *)0x0)) && (0 < *(int32_t *)(piVar21 + 1))
                    ) && (CONCAT44(uVar23, uVar22) == iVar15)) {
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x30;
                    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                    }
                    puVar4 = *(undefined8 **)(arg1 + 0x40);
                    *puVar4 = *(undefined8 *)(iVar5 + 0x58);
                    *(undefined4 *)((int64_t)puVar4 + 0xc) = 7;
                    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                        iVar9 = *(int32_t *)(arg1 + 0x60);
                        iVar12 = (int32_t)(int32_t *)(arg1 + 0x60);
                        iVar14 = iVar9 - iVar12;
                        if (iVar9 - iVar12 < 1) {
                            iVar14 = iVar14 + 1;
                        } else {
                            iVar14 = iVar14 * 2;
                        }
                        func_0x000180093240(arg1, iVar14, 0);
                    }
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                    LOCK();
                    piVar2 = piVar21 + 1;
                    iVar9 = *(int32_t *)piVar2;
                    *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
                    UNLOCK();
                    if (iVar9 == 1) {
                        (**(code **)*piVar21)(piVar21);
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar21 + 0xc);
                        iVar9 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar9 == 1) {
                            (**(code **)(*piVar21 + 8))(piVar21);
                        }
                    }
                    if (piVar11 != (int64_t *)0x0) {
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar11 + 0xc);
                        iVar9 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar9 == 1) {
                            (**(code **)(*piVar11 + 8))(piVar11);
                        }
                    }
                    goto code_r0x00018005a337;
                }
                if (piVar21 != (int64_t *)0x0) {
                    LOCK();
                    piVar2 = piVar21 + 1;
                    iVar9 = *(int32_t *)piVar2;
                    *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
                    UNLOCK();
                    if (iVar9 == 1) {
                        (**(code **)*piVar21)(piVar21);
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar21 + 0xc);
                        iVar9 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar9 == 1) {
                            (**(code **)(*piVar21 + 8))(piVar21);
                        }
                    }
                }
                if (piVar11 != (int64_t *)0x0) {
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar11 + 0xc);
                    iVar9 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar9 == 1) {
                        (**(code **)(*piVar11 + 8))(piVar11);
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            iVar9 = func_0x000180087970(arg1, 0xfffffffe);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar9 = func_0x000180085510(arg1, 1), iVar9 == 0)) {
            func_0x000180099450(arg1, 0x18063d8d0);
            func_0x000180087960(arg1);
            pcVar7 = (code *)swi(3);
            (*pcVar7)();
            return;
        }
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
code_r0x00018005a337:
        puVar17 = auStack_d8;
        if ((uint64_t)var_60h < 0x10) goto joined_r0x00018005a36d;
        uVar19 = var_60h + 1;
        if (uVar19 < 0x1000) {
code_r0x00018005a364:
            func_0x000180459c3c(var_78h, uVar19);
            goto joined_r0x00018005a36d;
        }
        uVar19 = (var_78h - *(int64_t *)(var_78h + -8)) - 8;
        if (uVar19 < 0x20) {
            uVar19 = var_60h + 0x28;
            var_78h = *(int64_t *)(var_78h + -8);
            goto code_r0x00018005a364;
        }
code_r0x00018005a371:
        pcVar7 = (code *)swi(0x29);
        (*pcVar7)(5);
        var_78h = uVar19;
        puVar18 = auStack_d0;
    }
    *(undefined8 *)(puVar18 + -8) = 0x18005a380;
    func_0x000180459c3c(var_78h);
    puVar17 = puVar18;
joined_r0x00018005a36d:
    if (piVar16 != (int64_t *)0x0) {
        LOCK();
        piVar11 = piVar16 + 1;
        iVar9 = *(int32_t *)piVar11;
        *(int32_t *)piVar11 = *(int32_t *)piVar11 + -1;
        UNLOCK();
        if (iVar9 == 1) {
            pcVar7 = *(code **)*piVar16;
            *(undefined8 *)(puVar17 + -8) = 0x18005a39f;
            (*pcVar7)(piVar16);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar16 + 0xc);
            iVar9 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar9 == 1) {
                pcVar7 = *(code **)(*piVar16 + 8);
                *(undefined8 *)(puVar17 + -8) = 0x18005a3b2;
                (*pcVar7)(piVar16);
            }
        }
    }
    *(undefined8 *)(puVar17 + -8) = 0x18005a3c7;
    func_0x000180459870(*(uint64_t *)(puVar17 + 0x80) ^ (uint64_t)puVar17);
    return;
}

// ============================================================
// Function: FUN_18005a440
// Address: 0x18005a440
// Size: 430 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18005a440(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined *puVar7;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_78 [8];
    undefined auStack_70 [32];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar7 = auStack_78;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    var_50h = arg1;
    func_0x00018000b4d0(&var_48h, *(undefined8 *)(*(int64_t *)(arg2 + 0x18) + 8));
    piVar4 = &var_48h;
    if (0xf < (uint64_t)var_30h) {
        piVar4 = (int64_t *)var_48h;
    }
    uVar5 = var_48h;
    if ((var_38h == 0xb) && (iVar3 = func_0x000180497f30(piVar4, 0x1806217e0, 0xb), iVar3 == 0)) {
code_r0x00018005a4da:
        iVar1 = *(int64_t *)(arg2 + 0x1a8);
        if ((iVar1 == 0) || (*(int64_t *)(iVar1 + 0x20) == 0)) {
code_r0x00018005a58c:
            *(undefined *)(arg1 + 0x20) = 0;
            goto code_r0x00018005a590;
        }
        func_0x00018000b4d0(arg1, iVar1 + 0x10);
        *(undefined *)(arg1 + 0x20) = 1;
        puVar7 = auStack_78;
        if ((uint64_t)var_30h < 0x10) goto code_r0x00018005a5c9;
        puVar7 = auStack_78;
        if (0xfff < var_30h + 1U) {
            uVar5 = *(uint64_t *)(var_48h + -8);
            uVar6 = (var_48h - uVar5) - 8;
            puVar7 = auStack_78;
            if (uVar6 < 0x20) goto code_r0x00018005a5c4;
code_r0x00018005a5ba:
            pcVar2 = (code *)swi(0x29);
            (*pcVar2)(5);
            uVar5 = uVar6;
            puVar7 = auStack_70;
        }
    } else {
        piVar4 = &var_48h;
        if (0xf < (uint64_t)var_30h) {
            piVar4 = (int64_t *)var_48h;
        }
        if ((var_38h == 6) && (iVar3 = func_0x000180497f30(piVar4, 0x1806244a4, 6), iVar3 == 0))
        goto code_r0x00018005a4da;
        piVar4 = &var_48h;
        if (0xf < (uint64_t)var_30h) {
            piVar4 = (int64_t *)var_48h;
        }
        if ((((var_38h != 0xc) || (iVar3 = func_0x000180497f30(piVar4, 0x1806244b0, 0xc), iVar3 != 0)) ||
            (iVar1 = *(int64_t *)(arg2 + 0x150), iVar1 == 0)) || (*(int64_t *)(iVar1 + 0x20) == 0))
        goto code_r0x00018005a58c;
        func_0x00018000b4d0(arg1, iVar1 + 0x10);
        *(undefined *)(arg1 + 0x20) = 1;
code_r0x00018005a590:
        if ((uint64_t)var_30h < 0x10) goto code_r0x00018005a5c9;
        puVar7 = auStack_78;
        if (0xfff < var_30h + 1U) {
            uVar6 = (var_48h - *(uint64_t *)(var_48h + -8)) - 8;
            uVar5 = *(uint64_t *)(var_48h + -8);
            puVar7 = auStack_78;
            if (0x1f < uVar6) goto code_r0x00018005a5ba;
        }
    }
code_r0x00018005a5c4:
    *(undefined8 *)(puVar7 + -8) = 0x18005a5c9;
    func_0x000180459c3c(uVar5);
code_r0x00018005a5c9:
    *(undefined8 *)(puVar7 + -8) = 0x18005a5d9;
    func_0x000180459870(*(uint64_t *)(puVar7 + 0x50) ^ (uint64_t)puVar7);
    return;
}

// ============================================================
// Function: FUN_18005a5f0
// Address: 0x18005a5f0
// Size: 881 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_a7h
// WARNING: [rz-ghidra] Detected overlap for variable var_a6h
// WARNING: [rz-ghidra] Detected overlap for variable var_a5h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h

void fcn.18005a5f0(int64_t arg1)
{
    undefined4 uVar1;
    code *pcVar2;
    undefined auVar3 [16];
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t *piVar7;
    uint64_t uVar8;
    undefined *puVar9;
    undefined *puVar10;
    undefined *puVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    int64_t *piVar14;
    uint64_t uVar15;
    int64_t var_18h;
    undefined8 uStack_d0;
    undefined auStack_c8 [32];
    int64_t var_a8h;
    undefined var_a0h [8];
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    undefined8 uStack_58;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    puVar10 = auStack_c8;
    puVar9 = auStack_c8;
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_c8;
    piVar7 = (int64_t *)0x0;
    var_a8h = arg1;
    func_0x00018000b4d0(&var_80h);
    piVar14 = &var_80h;
    if (0xf < (uint64_t)var_68h) {
        piVar14 = (int64_t *)var_80h;
    }
    uVar1 = *(undefined4 *)piVar14;
    var_a8h._1_1_ = (uint8_t)((uint32_t)uVar1 >> 8);
    var_a8h._2_1_ = (uint8_t)((uint32_t)uVar1 >> 0x10);
    var_a8h._3_1_ = (uint8_t)((uint32_t)uVar1 >> 0x18);
    var_a8h = CONCAT44(var_a8h._4_4_, 
                       CONCAT13((var_a8h._3_1_ ^ 0x31) + 0x85, 
                                CONCAT12((var_a8h._2_1_ ^ 0x42) + 0xae, 
                                         CONCAT11((var_a8h._1_1_ ^ 0x53) - 0x29, (char)uVar1)))) ^ 0x52;
    piVar14 = piVar7;
    if (var_70h != 0) {
        do {
            piVar12 = &var_80h;
            if (0xf < (uint64_t)var_68h) {
                piVar12 = (int64_t *)var_80h;
            }
            *(uint8_t *)((int64_t)piVar12 + (int64_t)piVar14) =
                 *(uint8_t *)((int64_t)piVar12 + (int64_t)piVar14) ^
                 var_a0h[(uint64_t)((uint32_t)piVar14 & 3) - 8] + (char)piVar14 * ')';
            piVar14 = (int64_t *)((int64_t)piVar14 + 1);
        } while (piVar14 < (uint64_t)var_70h);
    }
    piVar14 = &var_80h;
    if (0xf < (uint64_t)var_68h) {
        piVar14 = (int64_t *)var_80h;
    }
    iVar4 = func_0x00018016b0d0(piVar14, var_70h, 0x2a);
    if (iVar4 == (int32_t)var_a8h) {
        piVar14 = &var_80h;
        if (0xf < (uint64_t)var_68h) {
            piVar14 = (int64_t *)var_80h;
        }
        uVar8 = (uint64_t)*(int32_t *)((int64_t)piVar14 + 4);
        _var_a0h = ZEXT816(0);
        var_90h = 0;
        if (uVar8 == 0) {
            var_a0h = (undefined  [8])0x0;
            piVar12 = (int64_t *)var_a0h;
            piVar14 = piVar7;
code_r0x00018005a78b:
            puVar9 = auStack_c8;
            puVar10 = auStack_c8;
            puVar11 = auStack_c8;
            piVar13 = &var_80h;
            if (0xf < (uint64_t)var_68h) {
                piVar13 = (int64_t *)var_80h;
            }
            func_0x0001803f6690(piVar12, uVar8, piVar13 + 1, var_70h + -8);
            _var_60h = ZEXT816(0);
            var_48h = 0xf;
            if (piVar12 == piVar14) {
                var_50h = 0;
                auVar3[15] = 0;
                auVar3._0_15_ = stack0xffffffffffffffa1;
                _var_60h = auVar3 << 8;
            } else {
                uVar8 = (int64_t)piVar14 - (int64_t)piVar12;
                if (0x7fffffffffffffff < uVar8) goto code_r0x00018005a949;
                puVar10 = auStack_c8;
                if (0xf < uVar8) {
                    uVar15 = uVar8 | 0xf;
                    if (uVar15 < 0x8000000000000000) goto code_r0x00018005a81f;
                    uVar15 = 0x7fffffffffffffff;
                    uVar6 = 0x8000000000000027;
                    puVar9 = auStack_c8;
                    do {
                        *(undefined8 *)(puVar9 + -8) = 0x18005a810;
                        iVar5 = func_0x000180459890(uVar6);
                        if (iVar5 != 0) {
                            piVar7 = (int64_t *)(iVar5 + 0x27U & 0xffffffffffffffe0);
                            piVar7[-1] = iVar5;
code_r0x00018005a864:
                            var_60h = (int64_t)piVar7;
                            puVar10 = puVar9;
                            var_48h = uVar15;
                            goto code_r0x00018005a86c;
                        }
                        pcVar2 = (code *)swi(0x29);
                        (*pcVar2)(5);
                        puVar9 = puVar9 + 8;
code_r0x00018005a81f:
                        if (uVar15 < 0x16) {
                            uVar15 = 0x16;
                        }
                        if (uVar15 == 0xffffffffffffffff) goto code_r0x00018005a864;
                        if (uVar15 + 1 < 0x1000) {
                            *(undefined8 *)(puVar9 + -8) = 0x18005a864;
                            piVar7 = (int64_t *)func_0x000180459890();
                            goto code_r0x00018005a864;
                        }
                        uVar6 = uVar15 + 0x28;
                    } while (uVar15 + 1 < uVar6);
                    *(undefined8 *)(puVar9 + -8) = 0x18005a954;
                    func_0x000180004720();
code_r0x00018005a955:
                    *(undefined8 *)(puVar9 + -8) = 0x18005a95a;
                    func_0x000180010010();
                    pcVar2 = (code *)swi(3);
                    (*pcVar2)();
                    return;
                }
code_r0x00018005a86c:
                piVar13 = &var_60h;
                if (0xf < (uint64_t)var_48h) {
                    piVar13 = piVar7;
                }
                *(undefined8 *)(puVar10 + -8) = 0x18005a886;
                func_0x000180498030(piVar13, piVar12, uVar8);
                var_50h = uVar8;
                *(undefined *)(uVar8 + (int64_t)piVar13) = 0;
            }
            *(undefined4 *)arg1 = (undefined4)var_60h;
            *(undefined4 *)(arg1 + 4) = var_60h._4_4_;
            *(undefined4 *)(arg1 + 8) = (undefined4)uStack_58;
            *(undefined4 *)(arg1 + 0xc) = uStack_58._4_4_;
            *(undefined4 *)(arg1 + 0x10) = (undefined4)var_50h;
            *(undefined4 *)(arg1 + 0x14) = var_50h._4_4_;
            *(undefined4 *)(arg1 + 0x18) = (undefined4)var_48h;
            *(undefined4 *)(arg1 + 0x1c) = var_48h._4_4_;
            *(undefined *)(arg1 + 0x20) = 1;
            if (piVar12 != (int64_t *)0x0) {
                uVar8 = (int64_t)piVar14 - (int64_t)piVar12;
                piVar14 = piVar12;
                if (0xfff < uVar8) {
                    piVar14 = (int64_t *)piVar12[-1];
                    if (0x1f < (uint64_t)((int64_t)piVar12 + (-8 - (int64_t)piVar14))) goto code_r0x00018005a93b;
                    uVar8 = uVar8 + 0x27;
                }
                *(undefined8 *)(puVar10 + -8) = 0x18005a8d9;
                func_0x000180459c3c(piVar14, uVar8);
            }
            goto code_r0x00018005a8da;
        }
        if (0x7fffffffffffffff < uVar8) goto code_r0x00018005a955;
        if (uVar8 < 0x1000) {
            piVar12 = (int64_t *)func_0x000180459890(uVar8);
code_r0x00018005a759:
            var_a0h = (undefined  [8])piVar12;
            piVar14 = (int64_t *)(uVar8 + (int64_t)piVar12);
            var_90h = (int64_t)piVar14;
            func_0x0001804986e0(piVar12, 0, uVar8);
            var_98h = (int64_t)piVar14;
            goto code_r0x00018005a78b;
        }
        if (uVar8 + 0x27 <= uVar8) {
            func_0x000180004720();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        iVar5 = func_0x000180459890();
        puVar10 = auStack_c8;
        if (iVar5 != 0) {
            piVar12 = (int64_t *)(iVar5 + 0x27U & 0xffffffffffffffe0);
            piVar12[-1] = iVar5;
            goto code_r0x00018005a759;
        }
code_r0x00018005a93b:
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        puVar10 = puVar10 + 8;
code_r0x00018005a942:
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        puVar11 = puVar10 + 8;
code_r0x00018005a949:
        *(undefined8 *)(puVar11 + -8) = 0x18005a94e;
        func_0x0001800047c0();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    *(undefined *)(arg1 + 0x20) = 0;
code_r0x00018005a8da:
    if ((uint64_t)var_68h < 0x10) goto code_r0x00018005a911;
    uVar8 = var_68h + 1;
    iVar5 = var_80h;
    if (0xfff < uVar8) {
        iVar5 = *(int64_t *)(var_80h + -8);
        if (0x1f < (var_80h - iVar5) - 8U) goto code_r0x00018005a942;
        uVar8 = var_68h + 0x28;
    }
    *(undefined8 *)(puVar10 + -8) = 0x18005a911;
    func_0x000180459c3c(iVar5, uVar8);
code_r0x00018005a911:
    uVar8 = var_40h ^ (uint64_t)puVar10;
    *(undefined8 *)(puVar10 + -8) = 0x18005a920;
    func_0x000180459870(uVar8);
    return;
}

// ============================================================
// Function: FUN_18005a970
// Address: 0x18005a970
// Size: 885 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_a7h
// WARNING: [rz-ghidra] Detected overlap for variable var_a6h
// WARNING: [rz-ghidra] Detected overlap for variable var_a5h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h

void fcn.18005a970(int64_t arg1)
{
    int32_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t **ppiVar4;
    int64_t iVar5;
    int64_t **ppiVar6;
    int64_t *piVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    undefined *puVar10;
    undefined *puVar11;
    uint64_t uVar12;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_120;
    undefined auStack_118 [8];
    undefined auStack_110 [32];
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar10 = auStack_118;
    puVar11 = auStack_118;
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_118;
    ppiVar6 = *(int64_t ***)(arg1 + 0x28);
    ppiVar4 = ppiVar6;
    if (*(int64_t ***)(arg1 + 0x40) <= ppiVar6) {
        ppiVar4 = *(int64_t ***)0x180782430;
    }
    if (((*(int32_t *)((int64_t)ppiVar4 + 0xc) != 9) ||
        (*(uint8_t *)((int64_t)*ppiVar4 + 3) != *(uint32_t *)0x1807823dc)) ||
       (*ppiVar4 == (int64_t *)0xfffffffffffffff0)) {
code_r0x00018005acbb:
        func_0x000180088380(arg1, 1, 0x1806217c8);
code_r0x00018005acd0:
        func_0x000180088380(arg1, 1, 0x180624510);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    if (*(int64_t ***)(arg1 + 0x40) <= ppiVar6) {
        ppiVar6 = *(int64_t ***)0x180782430;
    }
    if (*(int32_t *)((int64_t)ppiVar6 + 0xc) == 9) {
        piVar9 = *ppiVar6 + 2;
    } else if (*(int32_t *)((int64_t)ppiVar6 + 0xc) == 2) {
        piVar9 = *ppiVar6;
    } else {
        piVar9 = (int64_t *)0x0;
    }
    if (piVar9[1] != 0) {
        LOCK();
        piVar1 = (int32_t *)(piVar9[1] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    iVar5 = *piVar9;
    piVar9 = (int64_t *)piVar9[1];
    var_f0h = iVar5;
    var_e8h = (int64_t)piVar9;
    func_0x00018000b4d0(&var_90h, *(undefined8 *)(*(int64_t *)(iVar5 + 0x18) + 8));
    piVar7 = &var_90h;
    if (0xf < (uint64_t)var_78h) {
        piVar7 = (int64_t *)var_90h;
    }
    if ((var_80h != 0xb) || (iVar3 = func_0x000180497f30(piVar7, 0x1806217e0, 0xb), iVar3 != 0)) {
        piVar7 = &var_90h;
        if (0xf < (uint64_t)var_78h) {
            piVar7 = (int64_t *)var_90h;
        }
        if ((var_80h != 6) || (iVar3 = func_0x000180497f30(piVar7, 0x1806244a4, 6), iVar3 != 0)) {
            piVar7 = &var_90h;
            if (0xf < (uint64_t)var_78h) {
                piVar7 = (int64_t *)var_90h;
            }
            if ((var_80h != 0xc) || (iVar3 = func_0x000180497f30(piVar7, 0x1806244b0, 0xc), iVar3 != 0)) {
                func_0x000180088380(arg1, 1, 0x1806244c0);
                goto code_r0x00018005acbb;
            }
        }
    }
    piVar7 = &var_90h;
    if (0xf < (uint64_t)var_78h) {
        piVar7 = (int64_t *)var_90h;
    }
    if (((var_80h == 6) && (iVar3 = func_0x000180497f30(piVar7, 0x1806244a4, 6), iVar3 == 0)) &&
       (*(int32_t *)(iVar5 + 0x148) != 2)) goto code_r0x00018005acd0;
    fcn.18005a440((int64_t)&var_b8h, iVar5);
    if ((char)var_98h == '\0') {
        func_0x000180086510(arg1);
        puVar11 = auStack_118;
        goto code_r0x00018005abfe;
    }
    func_0x00018000b4d0(&var_50h, &var_b8h);
    fcn.18005a5f0((int64_t)&var_e0h);
    if ((char)var_c0h == '\0') {
        func_0x000180086510(arg1);
    } else {
        func_0x00018000b4d0(&var_70h, &var_e0h);
        piVar7 = &var_70h;
        if (0xf < (uint64_t)var_58h) {
            piVar7 = (int64_t *)var_70h;
        }
        func_0x0001800867f0(arg1, piVar7, var_60h);
        puVar11 = auStack_118;
        if (0xf < (uint64_t)var_58h) {
            if (0xfff < var_58h + 1U) {
                if ((var_70h - *(int64_t *)(var_70h + -8)) - 8U < 0x20) {
                    func_0x000180459c3c(*(int64_t *)(var_70h + -8), var_58h + 0x28);
                    puVar11 = auStack_118;
                    goto code_r0x00018005abac;
                }
                pcVar2 = (code *)swi(0x29);
                var_70h = (*pcVar2)(5);
                puVar10 = auStack_110;
            }
            *(undefined8 *)(puVar10 + -8) = 0x18005aba1;
            func_0x000180459c3c(var_70h);
            puVar11 = puVar10;
        }
    }
code_r0x00018005abac:
    if ((char)var_c0h != '\0') {
        *(undefined8 *)(puVar11 + -8) = 0x18005abbc;
        func_0x000180004e40(puVar11 + 0x38);
    }
    if (0xf < (uint64_t)var_38h) {
        iVar5 = var_50h;
        if ((0xfff < var_38h + 1U) && (iVar5 = *(int64_t *)(var_50h + -8), 0x1f < (var_50h - iVar5) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar5 = (*pcVar2)(5);
            puVar11 = puVar11 + 8;
        }
        *(undefined8 *)(puVar11 + -8) = 0x18005abfd;
        func_0x000180459c3c(iVar5);
    }
code_r0x00018005abfe:
    if ((char)var_98h != '\0') {
        *(undefined8 *)(puVar11 + -8) = 0x18005ac0d;
        func_0x000180004e40(&var_b8h);
    }
    if (0xf < (uint64_t)var_78h) {
        uVar8 = var_90h;
        if (0xfff < var_78h + 1U) {
            uVar8 = *(uint64_t *)(var_90h + -8);
            uVar12 = (var_90h - uVar8) - 8;
            if (0x1f < uVar12) {
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar11 = puVar11 + 8;
                uVar8 = uVar12;
            }
        }
        *(undefined8 *)(puVar11 + -8) = 0x18005ac47;
        func_0x000180459c3c(uVar8);
    }
    if (piVar9 != (int64_t *)0x0) {
        LOCK();
        piVar7 = piVar9 + 1;
        iVar3 = *(int32_t *)piVar7;
        *(int32_t *)piVar7 = *(int32_t *)piVar7 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            pcVar2 = *(code **)*piVar9;
            *(undefined8 *)(puVar11 + -8) = 0x18005ac66;
            (*pcVar2)(piVar9);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar9 + 0xc);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                pcVar2 = *(code **)(*piVar9 + 8);
                *(undefined8 *)(puVar11 + -8) = 0x18005ac79;
                (*pcVar2)(piVar9);
            }
        }
    }
    *(undefined8 *)(puVar11 + -8) = 0x18005ac8a;
    func_0x000180459870(var_30h ^ (uint64_t)puVar11);
    return;
}

// ============================================================
// Function: FUN_18005acf0
// Address: 0x18005acf0
// Size: 2341 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_a7h
// WARNING: [rz-ghidra] Detected overlap for variable var_a6h
// WARNING: [rz-ghidra] Detected overlap for variable var_a5h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h

void fcn.18005acf0(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t **ppiVar5;
    int64_t **ppiVar6;
    undefined4 *puVar7;
    undefined8 *puVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t *piVar11;
    undefined4 *puVar12;
    int64_t *piVar13;
    undefined *puVar14;
    undefined *puVar15;
    undefined *puVar16;
    uint64_t uVar17;
    int64_t iVar18;
    undefined4 uVar19;
    undefined8 uStack_1d0;
    undefined auStack_1c8 [8];
    undefined auStack_1c0 [24];
    int64_t var_1a8h;
    int64_t var_198h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t iStack_c8;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar14 = auStack_1c8;
    puVar15 = auStack_1c8;
    puVar16 = auStack_1c8;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    piVar13 = (int64_t *)0x0;
    ppiVar6 = *(int64_t ***)(arg1 + 0x28);
    ppiVar5 = ppiVar6;
    if (*(int64_t ***)(arg1 + 0x40) <= ppiVar6) {
        ppiVar5 = *(int64_t ***)0x180782430;
    }
    if (((*(int32_t *)((int64_t)ppiVar5 + 0xc) == 9) &&
        (*(uint8_t *)((int64_t)*ppiVar5 + 3) == *(uint32_t *)0x1807823dc)) &&
       (*ppiVar5 != (int64_t *)0xfffffffffffffff0)) {
        if (*(int64_t ***)(arg1 + 0x40) <= ppiVar6) {
            ppiVar6 = *(int64_t ***)0x180782430;
        }
        if (*(int32_t *)((int64_t)ppiVar6 + 0xc) == 9) {
            piVar13 = *ppiVar6 + 2;
        } else if (*(int32_t *)((int64_t)ppiVar6 + 0xc) == 2) {
            piVar13 = *ppiVar6;
        }
        if (piVar13[1] != 0) {
            LOCK();
            piVar1 = (int32_t *)(piVar13[1] + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        iVar18 = *piVar13;
        piVar13 = (int64_t *)piVar13[1];
        var_d8h = iVar18;
        var_d0h = (int64_t)piVar13;
        func_0x00018000b4d0(&var_98h, *(undefined8 *)(*(int64_t *)(iVar18 + 0x18) + 8));
        piVar11 = &var_98h;
        if (0xf < (uint64_t)var_80h) {
            piVar11 = (int64_t *)var_98h;
        }
        if ((var_88h != 0xb) || (iVar4 = func_0x000180497f30(piVar11, 0x1806217e0, 0xb), iVar4 != 0)) {
            piVar11 = &var_98h;
            if (0xf < (uint64_t)var_80h) {
                piVar11 = (int64_t *)var_98h;
            }
            if ((var_88h != 6) || (iVar4 = func_0x000180497f30(piVar11, 0x1806244a4, 6), iVar4 != 0)) {
                piVar11 = &var_98h;
                if (0xf < (uint64_t)var_80h) {
                    piVar11 = (int64_t *)var_98h;
                }
                if ((var_88h != 0xc) || (iVar4 = func_0x000180497f30(piVar11, 0x1806244b0, 0xc), iVar4 != 0)) {
                    func_0x000180088380(arg1, 1, 0x1806244c0);
                    goto code_r0x00018005b5d3;
                }
            }
        }
        piVar11 = &var_98h;
        if (0xf < (uint64_t)var_80h) {
            piVar11 = (int64_t *)var_98h;
        }
        if (((var_88h != 6) || (iVar4 = func_0x000180497f30(piVar11, 0x1806244a4, 6), iVar4 != 0)) ||
           (*(int32_t *)(iVar18 + 0x148) == 2)) {
            fcn.18005a440((int64_t)&var_138h, iVar18);
            iVar18 = var_88h;
            if ((char)var_118h == '\0') {
                func_0x000180086510(arg1);
code_r0x00018005ae8b:
                if ((char)var_118h != '\0') {
                    func_0x000180004e40(&var_138h);
                }
                if (0xf < (uint64_t)var_80h) {
                    uVar17 = var_80h + 1;
                    if (0xfff < uVar17) {
                        uVar17 = (var_98h - *(int64_t *)(var_98h + -8)) - 8;
                        puVar15 = auStack_1c8;
                        if (0x1f < uVar17) {
code_r0x00018005b55a:
                            iVar4 = (int32_t)iVar18;
                            pcVar3 = (code *)swi(0x29);
                            (*pcVar3)(5);
                            puVar15 = puVar15 + 8;
                            var_98h = uVar17;
                            goto code_r0x00018005b564;
                        }
                        uVar17 = var_80h + 0x28;
                        var_98h = *(int64_t *)(var_98h + -8);
                    }
                    func_0x000180459c3c(var_98h, uVar17);
                }
                if (piVar13 == (int64_t *)0x0) goto code_r0x00018005b599;
                iVar4 = -1;
                puVar16 = auStack_1c8;
            } else {
                func_0x00018000b4d0(&var_78h, &var_138h);
                fcn.18005a5f0((int64_t)&var_100h);
                if ((char)var_e0h == '\0') {
                    func_0x000180086510(arg1);
                    if ((char)var_e0h != '\0') {
                        func_0x000180004e40(&var_100h);
                    }
                    if (0xf < (uint64_t)var_60h) {
                        if (var_60h + 1U < 0x1000) {
                            func_0x000180459c3c(var_78h);
                        } else {
                            if (0x1f < (var_78h - *(int64_t *)(var_78h + -8)) - 8U) goto code_r0x00018005b510;
                            func_0x000180459c3c(*(int64_t *)(var_78h + -8), var_60h + 0x28);
                        }
                    }
                    goto code_r0x00018005ae8b;
                }
                func_0x00018000b4d0(&var_b8h, &var_100h);
                iVar10 = func_0x000180085760(arg1);
                uVar19 = func_0x000180013530();
                func_0x000180013740(uVar19, iVar10, 8);
                var_1a8h = 0;
                func_0x0001800869f0(iVar10, fcn.180059d50, 0, 0);
                func_0x000180085bf0(arg1, 1);
                func_0x000180085680(arg1, iVar10, 1);
                func_0x000180087810(iVar10, 1);
                ppiVar6 = (int64_t **)(*(int64_t *)(iVar10 + 0x40) - 0x10);
                if ((ppiVar6 != *(int64_t ***)0x180782430) && (*(int32_t *)(*(int64_t *)(iVar10 + 0x40) + -4) == 0)) {
                    *(int64_t ***)(iVar10 + 0x40) = ppiVar6;
                    func_0x000180085bf0(arg1, 1);
                    func_0x000180085680(arg1, iVar10, 1);
                    func_0x000180087370(iVar10, 0xffffd8ee, 0x180624534);
                    func_0x000180086cc0(arg1, 0xffffd8ee, 0x180623d58);
                    func_0x000180085680(arg1, iVar10, 1);
                    func_0x000180087370(iVar10, 0xffffd8ee, 0x180623d58);
                }
                var_198h = var_a8h;
                piVar11 = &var_b8h;
                if (0xf < (uint64_t)var_a0h) {
                    piVar11 = (int64_t *)CONCAT71(var_b8h._1_7_, (undefined)var_b8h);
                }
                if (*(uint64_t *)(*(int64_t *)(iVar10 + 0x20) + 0x28) <=
                    *(uint64_t *)(*(int64_t *)(iVar10 + 0x20) + 0x30)) {
                    (**(code **)0x180782658)(iVar10, 1);
                }
                var_110h = *(int64_t *)(iVar10 + 0x20);
                var_108h = *(int64_t *)(var_110h + 0x28);
                iVar18 = -1;
                *(undefined8 *)(var_110h + 0x28) = 0xffffffffffffffff;
                _var_188h = ZEXT816(0);
                var_178h = 0;
                var_170h = 0;
                var_168h = 0;
                var_160h = 0;
                var_158h = 0x1805aae98;
                var_148h = var_198h;
                var_140h = 0;
                var_150h = (int64_t)piVar11;
                iStack_c8 = var_110h;
                var_c0h = var_108h;
                iVar4 = func_0x000180093190(iVar10, 0x1800a80b0, &var_188h);
                if (iVar4 == 4) {
                    func_0x0001800867f0(iVar10, 0x18063ddf8, 0x11);
                    if (var_168h != 0) {
                        var_198h = var_160h * 8;
                        iVar9 = *(int64_t *)(var_170h + 0x20);
                        if ((var_198h - 1U < 0x400) && (-1 < *(char *)(var_198h + 0x180777990))) {
                            func_0x0001800985c0(var_170h, (int32_t)*(char *)(var_198h + 0x180777990), var_168h);
                        } else {
                            (**(code **)(iVar9 + 0x48))(*(undefined8 *)(iVar9 + 0x50), var_168h, var_198h, 0);
                        }
                        *(int64_t *)(iVar9 + 0x30) = *(int64_t *)(iVar9 + 0x30) - var_198h;
                        *(int64_t *)(iVar9 + 0x2c30) = *(int64_t *)(iVar9 + 0x2c30) - var_198h;
                    }
                    if (var_180h != 0) {
                        var_198h = var_178h * 8;
                        iVar9 = *(int64_t *)(var_188h + 0x20);
                        if ((var_198h - 1U < 0x400) && (-1 < *(char *)(var_198h + 0x180777990))) {
                            func_0x0001800985c0(var_188h, (int32_t)*(char *)(var_198h + 0x180777990), var_180h);
                        } else {
                            (**(code **)(iVar9 + 0x48))(*(undefined8 *)(iVar9 + 0x50), var_180h, var_198h, 0);
                        }
code_r0x00018005b2f9:
                        *(int64_t *)(iVar9 + 0x30) = *(int64_t *)(iVar9 + 0x30) - var_198h;
                        *(int64_t *)(iVar9 + 0x2c30) = *(int64_t *)(iVar9 + 0x2c30) - var_198h;
                    }
                } else {
                    if (var_168h != 0) {
                        var_198h = var_160h * 8;
                        iVar9 = *(int64_t *)(var_170h + 0x20);
                        if ((var_198h - 1U < 0x400) && (-1 < *(char *)(var_198h + 0x180777990))) {
                            func_0x0001800985c0(var_170h, (int32_t)*(char *)(var_198h + 0x180777990), var_168h);
                        } else {
                            (**(code **)(iVar9 + 0x48))(*(undefined8 *)(iVar9 + 0x50), var_168h, var_198h, 0);
                        }
                        *(int64_t *)(iVar9 + 0x30) = *(int64_t *)(iVar9 + 0x30) - var_198h;
                        *(int64_t *)(iVar9 + 0x2c30) = *(int64_t *)(iVar9 + 0x2c30) - var_198h;
                    }
                    if (var_180h != 0) {
                        var_198h = var_178h * 8;
                        iVar9 = *(int64_t *)(var_188h + 0x20);
                        if ((var_198h - 1U < 0x400) && (-1 < *(char *)(var_198h + 0x180777990))) {
                            func_0x0001800985c0(var_188h, (int32_t)*(char *)(var_198h + 0x180777990), var_180h);
                        } else {
                            (**(code **)(iVar9 + 0x48))(*(undefined8 *)(iVar9 + 0x50), var_180h, var_198h, 0);
                        }
                        goto code_r0x00018005b2f9;
                    }
                }
                *(int64_t *)(var_110h + 0x28) = var_108h;
                if (((int64_t **)(*(int64_t *)(arg1 + 0x40) - 0x10U) == *(int64_t ***)0x180782430) ||
                   (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
                    iVar9 = *(int64_t *)(iVar10 + 0x40);
                    ppiVar6 = (int64_t **)(iVar9 - 0x10U);
                    if ((int64_t **)(iVar9 - 0x10U) == *(int64_t ***)0x180782430) {
                        ppiVar6 = (int64_t **)0x0;
                    }
                    piVar11 = *ppiVar6;
                    ppiVar6 = (int64_t **)(iVar9 - 0x20);
                    if ((ppiVar6 != *(int64_t ***)0x180782430) && (*(int32_t *)(iVar9 + -0x14) == 7)) {
                        if (ppiVar6 == *(int64_t ***)0x180782430) {
                            ppiVar6 = (int64_t **)0x0;
                        }
                        piVar11[2] = (int64_t)*ppiVar6;
                        puVar12 = *(undefined4 **)(iVar10 + 0x40);
                        puVar7 = puVar12 + -4;
                        if (puVar7 < puVar12) {
                            do {
                                puVar7[-4] = *puVar7;
                                puVar7[-3] = puVar7[1];
                                puVar7[-2] = puVar7[2];
                                puVar7[-1] = puVar7[3];
                                puVar7 = puVar7 + 4;
                                puVar12 = *(undefined4 **)(iVar10 + 0x40);
                            } while (puVar7 < puVar12);
                        }
                        *(undefined4 **)(iVar10 + 0x40) = puVar12 + -4;
                    }
                    puVar8 = (undefined8 *)func_0x000180013530();
                    func_0x0001800136b0(*puVar8, piVar11[4]);
                    func_0x000180085680(iVar10, arg1, 1);
                    puVar12 = *(undefined4 **)(arg1 + 0x40);
                    puVar7 = puVar12 + -4;
                    if (puVar7 < puVar12) {
                        do {
                            puVar7[-4] = *puVar7;
                            puVar7[-3] = puVar7[1];
                            puVar7[-2] = puVar7[2];
                            puVar7[-1] = puVar7[3];
                            puVar7 = puVar7 + 4;
                            puVar12 = *(undefined4 **)(arg1 + 0x40);
                        } while (puVar7 < puVar12);
                    }
                    *(undefined4 **)(arg1 + 0x40) = puVar12 + -4;
                    puVar15 = auStack_1c8;
                    if (0xf < (uint64_t)var_a0h) {
                        iVar10 = CONCAT71(var_b8h._1_7_, (undefined)var_b8h);
                        if ((0xfff < var_a0h + 1U) &&
                           (iVar9 = iVar10 - *(int64_t *)(iVar10 + -8), iVar10 = *(int64_t *)(iVar10 + -8),
                           puVar14 = auStack_1c8, 0x1f < iVar9 - 8U)) {
code_r0x00018005b4ad:
                            pcVar3 = (code *)swi(0x29);
                            iVar10 = (*pcVar3)(5);
                            puVar14 = auStack_1c0;
                        }
                        *(undefined8 *)(puVar14 + -8) = 0x18005b4bc;
                        func_0x000180459c3c(iVar10);
                        puVar15 = puVar14;
                    }
                } else {
                    func_0x0001800858c0(arg1, 0);
                    if ((*(char *)0x180777010 != '\0') &&
                       ((**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U &&
                        (iVar4 = func_0x000180085510(arg1, 1), iVar4 == 0)))) goto code_r0x00018005b5fd;
                    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                    puVar15 = auStack_1c8;
                    if (0xf < (uint64_t)var_a0h) {
                        iVar10 = CONCAT71(var_b8h._1_7_, (undefined)var_b8h);
                        if (var_a0h + 1U < 0x1000) {
                            func_0x000180459c3c(iVar10);
                            puVar15 = auStack_1c8;
                        } else {
                            if (0x1f < (iVar10 - *(int64_t *)(iVar10 + -8)) - 8U) goto code_r0x00018005b4ad;
                            func_0x000180459c3c(*(int64_t *)(iVar10 + -8), var_a0h + 0x28);
                            puVar15 = auStack_1c8;
                        }
                    }
                }
                var_b8h._0_1_ = 0;
                var_a0h = 0xf;
                var_a8h = 0;
                if ((char)var_e0h != '\0') {
                    *(undefined8 *)(puVar15 + -8) = 0x18005b4de;
                    func_0x000180004e40(&var_100h);
                }
                if (0xf < (uint64_t)var_60h) {
                    iVar10 = var_78h;
                    if ((0xfff < var_60h + 1U) && (iVar10 = *(int64_t *)(var_78h + -8), 0x1f < (var_78h - iVar10) - 8U))
                    {
code_r0x00018005b510:
                        pcVar3 = (code *)swi(0x29);
                        iVar10 = (*pcVar3)(5);
                        puVar15 = puVar15 + 8;
                    }
                    *(undefined8 *)(puVar15 + -8) = 0x18005b51f;
                    func_0x000180459c3c(iVar10);
                }
                iVar4 = (int32_t)iVar18;
                if ((char)var_118h != '\0') {
                    *(undefined8 *)(puVar15 + -8) = 0x18005b52f;
                    func_0x000180004e40(&var_138h);
                }
                puVar16 = puVar15;
                if (0xf < (uint64_t)var_80h) {
                    if (0xfff < var_80h + 1U) {
                        uVar17 = (var_98h - *(uint64_t *)(var_98h + -8)) - 8;
                        var_98h = *(uint64_t *)(var_98h + -8);
                        if (uVar17 < 0x20) goto code_r0x00018005b564;
                        goto code_r0x00018005b55a;
                    }
code_r0x00018005b564:
                    *(undefined8 *)(puVar15 + -8) = 0x18005b569;
                    func_0x000180459c3c(var_98h);
                    puVar16 = puVar15;
                }
                if (piVar13 == (int64_t *)0x0) goto code_r0x00018005b599;
            }
            LOCK();
            piVar11 = piVar13 + 1;
            iVar2 = *(int32_t *)piVar11;
            *(int32_t *)piVar11 = *(int32_t *)piVar11 + iVar4;
            UNLOCK();
            if (iVar2 == 1) {
                pcVar3 = *(code **)*piVar13;
                *(undefined8 *)(puVar16 + -8) = 0x18005b584;
                (*pcVar3)(piVar13);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar13 + 0xc);
                iVar2 = *piVar1;
                *piVar1 = *piVar1 + iVar4;
                UNLOCK();
                if (iVar2 == 1) {
                    pcVar3 = *(code **)(*piVar13 + 8);
                    *(undefined8 *)(puVar16 + -8) = 0x18005b599;
                    (*pcVar3)(piVar13);
                }
            }
code_r0x00018005b599:
            *(undefined8 *)(puVar16 + -8) = 0x18005b5aa;
            func_0x000180459870(var_58h ^ (uint64_t)puVar16);
            return;
        }
    } else {
code_r0x00018005b5d3:
        func_0x000180088380(arg1, 1, 0x1806217c8);
    }
    func_0x000180088380(arg1, 1, 0x180624510);
code_r0x00018005b5fd:
    func_0x000180099450(arg1, 0x18063d8d0);
    func_0x000180087960(arg1);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_18005b620
// Address: 0x18005b620
// Size: 880 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18005b620(int64_t arg1)
{
    int32_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t **ppiVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t **ppiVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    int64_t *piVar10;
    undefined *puVar11;
    uint64_t uVar12;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_110;
    undefined auStack_108 [8];
    undefined auStack_100 [40];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar11 = auStack_108;
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_108;
    ppiVar7 = *(int64_t ***)(arg1 + 0x28);
    ppiVar4 = ppiVar7;
    if (*(int64_t ***)(arg1 + 0x40) <= ppiVar7) {
        ppiVar4 = *(int64_t ***)0x180782430;
    }
    if (((*(int32_t *)((int64_t)ppiVar4 + 0xc) == 9) &&
        (*(uint8_t *)((int64_t)*ppiVar4 + 3) == *(uint32_t *)0x1807823dc)) &&
       (*ppiVar4 != (int64_t *)0xfffffffffffffff0)) {
        if (*(int64_t ***)(arg1 + 0x40) <= ppiVar7) {
            ppiVar7 = *(int64_t ***)0x180782430;
        }
        if (*(int32_t *)((int64_t)ppiVar7 + 0xc) == 9) {
            piVar10 = *ppiVar7 + 2;
        } else if (*(int32_t *)((int64_t)ppiVar7 + 0xc) == 2) {
            piVar10 = *ppiVar7;
        } else {
            piVar10 = (int64_t *)0x0;
        }
        if (piVar10[1] != 0) {
            LOCK();
            piVar1 = (int32_t *)(piVar10[1] + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        iVar6 = *piVar10;
        piVar10 = (int64_t *)piVar10[1];
        var_c8h = iVar6;
        var_c0h = (int64_t)piVar10;
        func_0x00018000b4d0(&var_90h, *(undefined8 *)(*(int64_t *)(iVar6 + 0x18) + 8));
        piVar8 = &var_90h;
        if (0xf < (uint64_t)var_78h) {
            piVar8 = (int64_t *)var_90h;
        }
        if ((var_80h != 0xb) || (iVar3 = func_0x000180497f30(piVar8, 0x1806217e0, 0xb), iVar3 != 0)) {
            piVar8 = &var_90h;
            if (0xf < (uint64_t)var_78h) {
                piVar8 = (int64_t *)var_90h;
            }
            if ((var_80h != 6) || (iVar3 = func_0x000180497f30(piVar8, 0x1806244a4, 6), iVar3 != 0)) {
                piVar8 = &var_90h;
                if (0xf < (uint64_t)var_78h) {
                    piVar8 = (int64_t *)var_90h;
                }
                if ((var_80h != 0xc) || (iVar3 = func_0x000180497f30(piVar8, 0x1806244b0, 0xc), iVar3 != 0)) {
                    func_0x000180088380(arg1, 1, 0x1806244c0);
                    goto code_r0x00018005b966;
                }
            }
        }
        piVar8 = &var_90h;
        if (0xf < (uint64_t)var_78h) {
            piVar8 = (int64_t *)var_90h;
        }
        if (((var_80h != 6) || (iVar3 = func_0x000180497f30(piVar8, 0x1806244a4, 6), iVar3 != 0)) ||
           (*(int32_t *)(iVar6 + 0x148) == 2)) {
            fcn.18005a440((int64_t)&var_b8h, iVar6);
            if ((char)var_98h == '\0') {
                func_0x000180086510(arg1);
            } else {
                func_0x00018000b4d0(&var_50h, &var_b8h);
                func_0x00018007ff90();
                uVar5 = func_0x00018020e890();
                var_d8h = (int64_t)&var_50h;
                if (0xf < (uint64_t)var_38h) {
                    var_d8h = var_50h;
                }
                var_d0h = var_40h;
                func_0x000180081030(var_40h, &var_70h, &var_d8h, uVar5);
                if (var_60h == 0) {
                    func_0x000180086510(arg1);
                } else {
                    piVar8 = &var_70h;
                    if (0xf < (uint64_t)var_58h) {
                        piVar8 = (int64_t *)var_70h;
                    }
                    func_0x0001800867f0(arg1, piVar8);
                }
                puVar11 = auStack_108;
                if (0xf < (uint64_t)var_58h) {
                    iVar6 = var_70h;
                    puVar11 = auStack_108;
                    if ((0xfff < var_58h + 1U) &&
                       (iVar6 = *(int64_t *)(var_70h + -8), puVar11 = auStack_108, 0x1f < (var_70h - iVar6) - 8U)) {
                        pcVar2 = (code *)swi(0x29);
                        iVar6 = (*pcVar2)(5);
                        puVar11 = auStack_100;
                    }
                    *(undefined8 *)(puVar11 + -8) = 0x18005b867;
                    func_0x000180459c3c(iVar6);
                }
                if (0xf < (uint64_t)var_38h) {
                    iVar6 = var_50h;
                    if ((0xfff < var_38h + 1U) && (iVar6 = *(int64_t *)(var_50h + -8), 0x1f < (var_50h - iVar6) - 8U)) {
                        pcVar2 = (code *)swi(0x29);
                        iVar6 = (*pcVar2)(5);
                        puVar11 = puVar11 + 8;
                    }
                    *(undefined8 *)(puVar11 + -8) = 0x18005b8a8;
                    func_0x000180459c3c(iVar6);
                }
            }
            if ((char)var_98h != '\0') {
                *(undefined8 *)(puVar11 + -8) = 0x18005b8b8;
                func_0x000180004e40(&var_b8h);
            }
            if (0xf < (uint64_t)var_78h) {
                uVar9 = var_90h;
                if (0xfff < var_78h + 1U) {
                    uVar9 = *(uint64_t *)(var_90h + -8);
                    uVar12 = (var_90h - uVar9) - 8;
                    if (0x1f < uVar12) {
                        pcVar2 = (code *)swi(0x29);
                        (*pcVar2)(5);
                        puVar11 = puVar11 + 8;
                        uVar9 = uVar12;
                    }
                }
                *(undefined8 *)(puVar11 + -8) = 0x18005b8f2;
                func_0x000180459c3c(uVar9);
            }
            if (piVar10 != (int64_t *)0x0) {
                LOCK();
                piVar8 = piVar10 + 1;
                iVar3 = *(int32_t *)piVar8;
                *(int32_t *)piVar8 = *(int32_t *)piVar8 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    pcVar2 = *(code **)*piVar10;
                    *(undefined8 *)(puVar11 + -8) = 0x18005b911;
                    (*pcVar2)(piVar10);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar10 + 0xc);
                    iVar3 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar3 == 1) {
                        pcVar2 = *(code **)(*piVar10 + 8);
                        *(undefined8 *)(puVar11 + -8) = 0x18005b924;
                        (*pcVar2)(piVar10);
                    }
                }
            }
            *(undefined8 *)(puVar11 + -8) = 0x18005b935;
            func_0x000180459870(var_30h ^ (uint64_t)puVar11);
            return;
        }
    } else {
code_r0x00018005b966:
        func_0x000180088380(arg1, 1, 0x1806217c8);
    }
    func_0x000180088380(arg1, 1, 0x180624510);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_18005b990
// Address: 0x18005b990
// Size: 1157 bytes
// ============================================================
void fcn.18005b990(int64_t arg1, int64_t arg_40h, int64_t arg_48h)
{
    int32_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    undefined8 *puVar8;
    undefined4 *puVar9;
    uint32_t uVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t iVar15;
    int64_t *piVar16;
    undefined *puVar17;
    int64_t *piVar18;
    bool bVar19;
    int32_t iVar20;
    bool bVar21;
    int64_t var_1h;
    int64_t var_20h;
    undefined auStack_a8 [8];
    undefined auStack_a0 [24];
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    puVar17 = auStack_a8;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    bVar19 = false;
    var_88h._0_4_ = 0;
    iVar20 = 1;
    func_0x000180086fd0(arg1, 0, 0);
    func_0x000180086ba0(arg1, *(undefined8 *)0x180782630, 0);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar8 = (undefined8 *)func_0x000180085370(arg1, 0xffffd8f0);
    iVar2 = *(int64_t *)(arg1 + 0x40);
    puVar9 = (undefined4 *)func_0x0001800a0ea0(*puVar8, iVar2 + -0x10);
    uVar4 = puVar9[1];
    uVar5 = puVar9[2];
    uVar6 = puVar9[3];
    *(undefined4 *)(iVar2 + -0x10) = *puVar9;
    *(undefined4 *)(iVar2 + -0xc) = uVar4;
    *(undefined4 *)(iVar2 + -8) = uVar5;
    *(undefined4 *)(iVar2 + -4) = uVar6;
    func_0x000180086510(arg1);
    iVar7 = func_0x000180087970(arg1, 0xfffffffe);
    do {
        if (iVar7 == 0) {
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            func_0x000180459870(var_50h ^ (uint64_t)auStack_a8);
            return;
        }
        iVar2 = *(int64_t *)(arg1 + 0x40);
        if (*(int32_t *)(iVar2 + -4) == 9) {
            uVar10 = (uint32_t)*(uint8_t *)(*(int64_t *)(iVar2 + -0x10) + 3);
        } else {
            uVar10 = 0xffffffff;
        }
        if (uVar10 == *(uint32_t *)0x1807823dc) {
            if (*(int32_t *)(iVar2 + -4) == 9) {
                piVar18 = (int64_t *)(*(int64_t *)(iVar2 + -0x10) + 0x10);
            } else if (*(int32_t *)(iVar2 + -4) == 2) {
                piVar18 = *(int64_t **)(iVar2 + -0x10);
            } else {
                piVar18 = (int64_t *)0x0;
            }
            if (piVar18[1] != 0) {
                LOCK();
                piVar1 = (int32_t *)(piVar18[1] + 8);
                *piVar1 = *piVar1 + 1;
                UNLOCK();
            }
            iVar2 = *piVar18;
            piVar18 = (int64_t *)piVar18[1];
            iVar14 = *(int64_t *)(iVar2 + 0x18);
            var_80h = iVar2;
            var_78h = (int64_t)piVar18;
            for (iVar15 = iVar14; iVar15 != 0; iVar15 = *(int64_t *)(iVar15 + 0x230)) {
                piVar11 = *(int64_t **)(iVar15 + 8);
                piVar16 = piVar11 + 2;
                if (0xf < (uint64_t)piVar11[3]) {
                    piVar11 = (int64_t *)*piVar11;
                }
                if ((*piVar16 == 10) && (iVar7 = func_0x000180497f30(piVar11, 0x1806244f0), iVar7 == 0)) {
                    bVar21 = true;
                    iVar14 = var_70h;
                    uVar13 = var_58h;
                    goto code_r0x00018005bb3f;
                }
            }
            func_0x00018000b4d0(&var_70h, *(undefined8 *)(iVar14 + 8));
            uVar13 = var_58h;
            iVar14 = var_70h;
            bVar19 = true;
            piVar16 = &var_70h;
            if (0xf < (uint64_t)var_58h) {
                piVar16 = (int64_t *)var_70h;
            }
            if ((var_60h == 0xc) && (iVar7 = func_0x000180497f30(piVar16, 0x1806244b0), iVar7 == 0)) {
                bVar21 = true;
            } else {
                bVar21 = false;
            }
code_r0x00018005bb3f:
            if ((bVar19) && (bVar19 = false, 0xf < uVar13)) {
                uVar12 = uVar13 + 1;
                iVar15 = iVar14;
                if (uVar12 < 0x1000) {
code_r0x00018005bb78:
                    func_0x000180459c3c(iVar15, uVar12);
                    goto code_r0x00018005bb80;
                }
                iVar15 = *(int64_t *)(iVar14 + -8);
                if ((iVar14 - iVar15) - 8U < 0x20) {
                    uVar12 = uVar13 + 0x28;
                    goto code_r0x00018005bb78;
                }
code_r0x00018005be08:
                pcVar3 = (code *)swi(0x29);
                (*pcVar3)(5);
                puVar17 = auStack_a0;
                goto code_r0x00018005be0f;
            }
code_r0x00018005bb80:
            if (!bVar21) {
                if (piVar18 != (int64_t *)0x0) {
                    LOCK();
                    piVar16 = piVar18 + 1;
                    iVar7 = *(int32_t *)piVar16;
                    *(int32_t *)piVar16 = *(int32_t *)piVar16 + -1;
                    UNLOCK();
                    if (iVar7 == 1) {
                        (**(code **)*piVar18)(piVar18);
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar18 + 0xc);
                        iVar7 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar7 == 1) {
                            (**(code **)(*piVar18 + 8))(piVar18);
                        }
                    }
                }
                goto code_r0x00018005bdc6;
            }
            func_0x00018000b4d0(&var_70h, *(undefined8 *)(*(int64_t *)(iVar2 + 0x18) + 8));
            iVar14 = var_58h;
            iVar2 = var_70h;
            piVar16 = &var_70h;
            if (0xf < (uint64_t)var_58h) {
                piVar16 = (int64_t *)var_70h;
            }
            if (var_60h == 6) {
                iVar7 = func_0x000180497f30(piVar16, 0x1806244a4);
                bVar21 = iVar7 == 0;
            } else {
                bVar21 = false;
            }
            if (0xf < (uint64_t)iVar14) {
                uVar13 = iVar14 + 1;
                iVar15 = iVar2;
                if (0xfff < uVar13) {
                    iVar15 = *(int64_t *)(iVar2 + -8);
                    if (0x1f < (iVar2 - iVar15) - 8U) goto code_r0x00018005be08;
                    uVar13 = iVar14 + 0x28;
                }
                func_0x000180459c3c(iVar15, uVar13);
            }
            if (bVar21) {
                iVar2 = *(int64_t *)(arg1 + 0x40);
                if (*(int32_t *)(iVar2 + -4) == 9) {
                    piVar16 = (int64_t *)(*(int64_t *)(iVar2 + -0x10) + 0x10);
                } else if (*(int32_t *)(iVar2 + -4) == 2) {
                    piVar16 = *(int64_t **)(iVar2 + -0x10);
                } else {
                    piVar16 = (int64_t *)0x0;
                }
                if (piVar16[1] != 0) {
                    LOCK();
                    piVar1 = (int32_t *)(piVar16[1] + 8);
                    *piVar1 = *piVar1 + 1;
                    UNLOCK();
                }
                var_70h = *piVar16;
                piVar16 = (int64_t *)piVar16[1];
                var_68h = (int64_t)piVar16;
                if (*(int32_t *)(var_70h + 0x148) == 2) {
                    if (piVar16 != (int64_t *)0x0) {
                        LOCK();
                        piVar11 = piVar16 + 1;
                        iVar7 = *(int32_t *)piVar11;
                        *(int32_t *)piVar11 = *(int32_t *)piVar11 + -1;
                        UNLOCK();
                        if (iVar7 == 1) {
                            (**(code **)*piVar16)(piVar16);
                            LOCK();
                            piVar1 = (int32_t *)((int64_t)piVar16 + 0xc);
                            iVar7 = *piVar1;
                            *piVar1 = *piVar1 + -1;
                            UNLOCK();
                            if (iVar7 == 1) {
                                (**(code **)(*piVar16 + 8))(piVar16);
                            }
                        }
                    }
                    goto code_r0x00018005bd15;
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                iVar7 = iVar20;
                if (piVar16 != (int64_t *)0x0) {
                    LOCK();
                    piVar11 = piVar16 + 1;
                    iVar20 = *(int32_t *)piVar11;
                    *(int32_t *)piVar11 = *(int32_t *)piVar11 + -1;
                    UNLOCK();
                    if (iVar20 == 1) {
                        (**(code **)*piVar16)(piVar16);
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar16 + 0xc);
                        iVar20 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar20 == 1) {
                            (**(code **)(*piVar16 + 8))(piVar16);
                        }
                    }
                }
            } else {
code_r0x00018005bd15:
                iVar2 = *(int64_t *)(arg1 + 0x40);
                if (*(char *)(*(int64_t *)(iVar2 + -0x40) + 4) != '\0') {
code_r0x00018005be0f:
                    *(undefined8 *)(puVar17 + -8) = 0x18005be14;
                    func_0x000180092f10();
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                iVar7 = iVar20 + 1;
                puVar9 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar2 + -0x40), iVar20);
                uVar4 = *(undefined4 *)(iVar2 + -0xc);
                uVar5 = *(undefined4 *)(iVar2 + -8);
                uVar6 = *(undefined4 *)(iVar2 + -4);
                *puVar9 = *(undefined4 *)(iVar2 + -0x10);
                puVar9[1] = uVar4;
                puVar9[2] = uVar5;
                puVar9[3] = uVar6;
                if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                    iVar2 = *(int64_t *)(iVar2 + -0x40);
                    if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar14 = *(int64_t *)(arg1 + 0x20);
                        if (*(char *)(iVar14 + 0x59) == '\x02') {
                            func_0x000180094420();
                            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                            goto code_r0x00018005bc9c;
                        }
                        *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                        *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar14 + 0x18);
                        *(int64_t *)(iVar14 + 0x18) = iVar2;
                    }
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            }
code_r0x00018005bc9c:
            iVar20 = iVar7;
            if (piVar18 != (int64_t *)0x0) {
                LOCK();
                piVar16 = piVar18 + 1;
                iVar7 = *(int32_t *)piVar16;
                *(int32_t *)piVar16 = *(int32_t *)piVar16 + -1;
                UNLOCK();
                if (iVar7 == 1) {
                    (**(code **)*piVar18)(piVar18);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar18 + 0xc);
                    iVar7 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar7 == 1) {
                        (**(code **)(*piVar18 + 8))(piVar18);
                    }
                }
            }
        } else {
code_r0x00018005bdc6:
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        }
        iVar7 = func_0x000180087970(arg1, 0xfffffffe);
    } while( true );
}

// ============================================================
// Function: FUN_18005be20
// Address: 0x18005be20
// Size: 1355 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_16ch
// WARNING: [rz-ghidra] Detected overlap for variable var_17ch
// WARNING: [rz-ghidra] Detected overlap for variable var_a7h
// WARNING: [rz-ghidra] Detected overlap for variable var_a6h
// WARNING: [rz-ghidra] Detected overlap for variable var_a5h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h

void fcn.18005be20(int64_t arg1)
{
    int32_t *piVar1;
    uint32_t *puVar2;
    uint32_t uVar3;
    int64_t **ppiVar4;
    code *pcVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    int32_t iVar8;
    int64_t **ppiVar9;
    int64_t *piVar10;
    int64_t iVar11;
    int64_t **ppiVar12;
    uint64_t uVar13;
    undefined *puVar14;
    undefined *puVar15;
    int64_t *piVar16;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_1c0;
    undefined auStack_1b8 [8];
    undefined auStack_1b0 [24];
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t *piStack_b8;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar15 = auStack_1b8;
    puVar14 = auStack_1b8;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1b8;
    piVar16 = (int64_t *)0x0;
    ppiVar12 = *(int64_t ***)(arg1 + 0x28);
    ppiVar4 = *(int64_t ***)(arg1 + 0x40);
    ppiVar9 = ppiVar12;
    if (ppiVar4 <= ppiVar12) {
        ppiVar9 = *(int64_t ***)0x180782430;
    }
    if ((*(int32_t *)((int64_t)ppiVar9 + 0xc) != 9) && (*(int32_t *)((int64_t)ppiVar9 + 0xc) != 2)) {
        if (ppiVar4 <= ppiVar12) {
            ppiVar12 = *(int64_t ***)0x180782430;
        }
        puVar15 = auStack_1b8;
        if ((ppiVar12 == *(int64_t ***)0x180782430) ||
           (puVar15 = auStack_1b8, *(int32_t *)((int64_t)ppiVar12 + 0xc) != 8)) goto code_r0x00018005c303;
code_r0x00018005c33a:
        func_0x000180088560(arg1, 0x180624558);
code_r0x00018005c34a:
        func_0x00018045f7d4();
code_r0x00018005c350:
        func_0x000180093000(arg1, 0x18063e070);
        auVar7 = _var_178h;
code_r0x00018005c360:
        _var_178h = auVar7;
        func_0x0001804542e8(1);
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    if (ppiVar4 <= ppiVar12) {
        ppiVar12 = *(int64_t ***)0x180782430;
    }
    if (*(int32_t *)((int64_t)ppiVar12 + 0xc) == 9) {
        piVar16 = *ppiVar12 + 2;
    } else if (*(int32_t *)((int64_t)ppiVar12 + 0xc) == 2) {
        piVar16 = *ppiVar12;
    }
    if (piVar16[1] != 0) {
        LOCK();
        piVar1 = (int32_t *)(piVar16[1] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    var_c0h = *piVar16;
    piVar16 = (int64_t *)piVar16[1];
    piStack_b8 = piVar16;
    fcn.18005a440((int64_t)&var_110h, var_c0h);
    if ((char)var_f0h == '\0') {
        func_0x0001800867f0(arg1, 0x180624540, 0x11);
        puVar14 = auStack_1b8;
    } else {
        func_0x00018000b4d0(&var_68h, &var_110h);
        fcn.18005a5f0((int64_t)&var_e8h);
        if ((char)var_c8h != '\0') {
            func_0x00018000b4d0(&var_48h, &var_e8h);
            func_0x0001800205e0(&var_158h, arg1);
            piVar10 = (int64_t *)func_0x000180008740();
            iVar11 = *(int64_t *)(*piVar10 + 0x18);
            func_0x0001800137d0();
            var_148h = iVar11;
            func_0x00018000b4d0(&var_140h, &var_48h);
            if (var_150h != 0) {
                LOCK();
                *(int32_t *)(var_150h + 8) = *(int32_t *)(var_150h + 8) + 1;
                UNLOCK();
            }
            var_120h = var_158h;
            var_118h = var_150h;
            var_160h = (int64_t)&var_148h;
            iVar11 = func_0x00018045838c();
            var_a8h = var_148h;
            func_0x00018000b4d0(&var_a0h, &var_140h);
            if (var_118h != 0) {
                LOCK();
                *(int32_t *)(var_118h + 8) = *(int32_t *)(var_118h + 8) + 1;
                UNLOCK();
            }
            var_80h = var_120h;
            var_78h = var_118h;
            _var_178h = ZEXT816(0);
            var_70h = iVar11;
            var_168h = func_0x000180459890();
            *(undefined4 *)var_168h = 1;
            *(undefined4 *)(var_168h + 4) = 2;
            *(undefined8 *)(var_168h + 8) = 0;
            *(undefined8 *)(var_168h + 0x10) = 0;
            *(undefined4 *)(var_168h + 0x18) = 0;
            piVar10 = (int64_t *)func_0x000180459890(0x40);
            *piVar10 = var_a8h;
            var_188h = (int64_t)piVar10;
            func_0x00018000b4d0(piVar10 + 1, &var_a0h);
            piVar10[5] = var_80h;
            piVar10[6] = var_78h;
            var_80h = 0;
            var_78h = 0;
            piVar10[7] = var_70h;
            var_188h = (int64_t)piVar10;
            var_190h = (int64_t)&var_170h;
            var_198h._0_4_ = 0;
            iVar11 = func_0x00018045f6e8(0, 0, 0x18005c810, piVar10);
            auVar6 = _var_178h;
            var_178h = iVar11;
            auVar7 = _var_178h;
            var_170h._4_4_ = auVar6._12_4_;
            if (iVar11 == 0) {
                _var_178h = ZEXT812(0);
                func_0x0001804542e8(6);
                goto code_r0x00018005c33a;
            }
            var_170h._0_4_ = auVar6._8_4_;
            if ((int32_t)var_170h == 0) goto code_r0x00018005c360;
            var_180h._0_4_ = (int32_t)var_170h;
            var_188h = iVar11;
            var_180h._4_4_ = var_170h._4_4_;
            _var_178h = auVar7;
            iVar8 = func_0x000180454a0c(&var_188h);
            auVar7 = _var_178h;
            if (iVar8 != 0) goto code_r0x00018005c360;
            _var_188h = ZEXT816(0);
            _var_178h = ZEXT812(0);
            var_170h._4_4_ = 0;
            if (var_168h != 0) {
                LOCK();
                puVar2 = (uint32_t *)(var_168h + 4);
                uVar3 = *puVar2;
                *puVar2 = *puVar2 - 2;
                UNLOCK();
                if ((uVar3 & 0xfffffffe) == 2) {
                    LOCK();
                    iVar8 = *(int32_t *)var_168h;
                    *(int32_t *)var_168h = *(int32_t *)var_168h + -1;
                    UNLOCK();
                    if (iVar8 == 1) {
                        func_0x000180459c3c(var_168h, 0x20);
                    }
                }
            }
            if ((int32_t)var_170h != 0) goto code_r0x00018005c34a;
            func_0x000180004e40(&var_a0h);
            func_0x000180048130(&var_148h);
            if (*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) {
                *(undefined8 *)(arg1 + 0x28) = *(undefined8 *)(arg1 + 0x40);
                *(undefined *)(arg1 + 3) = 1;
                if (var_150h != 0) {
                    LOCK();
                    piVar1 = (int32_t *)(var_150h + 8);
                    iVar8 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar8 == 1) {
                        (***(code ***)var_150h)(var_150h);
                        LOCK();
                        piVar1 = (int32_t *)(var_150h + 0xc);
                        iVar8 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar8 == 1) {
                            (**(code **)(*(int64_t *)var_150h + 8))(var_150h);
                        }
                    }
                }
                puVar15 = auStack_1b8;
                if (0xf < (uint64_t)var_30h) {
                    iVar11 = var_48h;
                    puVar15 = auStack_1b8;
                    if ((0xfff < var_30h + 1U) &&
                       (iVar11 = *(int64_t *)(var_48h + -8), puVar15 = auStack_1b8, 0x1f < (var_48h - iVar11) - 8U)) {
                        pcVar5 = (code *)swi(0x29);
                        iVar11 = (*pcVar5)(5);
                        puVar15 = auStack_1b0;
                    }
                    *(undefined8 *)(puVar15 + -8) = 0x18005c1c2;
                    func_0x000180459c3c(iVar11);
                }
                if ((char)var_c8h != '\0') {
                    *(undefined8 *)(puVar15 + -8) = 0x18005c1d2;
                    func_0x000180004e40(&var_e8h);
                }
                if (0xf < (uint64_t)var_50h) {
                    uVar13 = var_50h + 1;
                    if (0xfff < uVar13) {
                        if (0x1f < (var_68h - *(int64_t *)(var_68h + -8)) - 8U) goto code_r0x00018005c2ad;
                        uVar13 = var_50h + 0x28;
                        var_68h = *(int64_t *)(var_68h + -8);
                    }
                    *(undefined8 *)(puVar15 + -8) = 0x18005c210;
                    func_0x000180459c3c(var_68h, uVar13);
                }
                if ((char)var_f0h != '\0') {
                    *(undefined8 *)(puVar15 + -8) = 0x18005c220;
                    func_0x000180004e40(&var_110h);
                }
                if (piVar16 != (int64_t *)0x0) {
                    LOCK();
                    piVar10 = piVar16 + 1;
                    iVar8 = *(int32_t *)piVar10;
                    *(int32_t *)piVar10 = *(int32_t *)piVar10 + -1;
                    UNLOCK();
                    if (iVar8 == 1) {
                        pcVar5 = *(code **)*piVar16;
                        *(undefined8 *)(puVar15 + -8) = 0x18005c23a;
                        (*pcVar5)(piVar16);
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar16 + 0xc);
                        iVar8 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar8 == 1) {
                            pcVar5 = *(code **)(*piVar16 + 8);
                            *(undefined8 *)(puVar15 + -8) = 0x18005c24f;
                            (*pcVar5)(piVar16);
                        }
                    }
                }
                goto code_r0x00018005c303;
            }
            goto code_r0x00018005c350;
        }
        func_0x0001800867f0(arg1, 0x180624540, 0x11);
        if ((char)var_c8h != '\0') {
            func_0x000180004e40(&var_e8h);
        }
        if (0xf < (uint64_t)var_50h) {
            iVar11 = var_68h;
            puVar14 = auStack_1b8;
            if ((0xfff < var_50h + 1U) &&
               (iVar11 = *(int64_t *)(var_68h + -8), puVar14 = auStack_1b8, 0x1f < (var_68h - iVar11) - 8U)) {
code_r0x00018005c2ad:
                pcVar5 = (code *)swi(0x29);
                iVar11 = (*pcVar5)(5);
                puVar14 = puVar15 + 8;
            }
            *(undefined8 *)(puVar14 + -8) = 0x18005c2bc;
            func_0x000180459c3c(iVar11);
        }
    }
    if ((char)var_f0h != '\0') {
        *(undefined8 *)(puVar14 + -8) = 0x18005c2cc;
        func_0x000180004e40(&var_110h);
    }
    puVar15 = puVar14;
    if (piVar16 != (int64_t *)0x0) {
        LOCK();
        piVar10 = piVar16 + 1;
        iVar8 = *(int32_t *)piVar10;
        *(int32_t *)piVar10 = *(int32_t *)piVar10 + -1;
        UNLOCK();
        if (iVar8 == 1) {
            pcVar5 = *(code **)*piVar16;
            *(undefined8 *)(puVar14 + -8) = 0x18005c2eb;
            (*pcVar5)(piVar16);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar16 + 0xc);
            iVar8 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar8 == 1) {
                pcVar5 = *(code **)(*piVar16 + 8);
                *(undefined8 *)(puVar14 + -8) = 0x18005c2fe;
                (*pcVar5)(piVar16);
            }
        }
    }
code_r0x00018005c303:
    *(undefined8 *)(puVar15 + -8) = 0x18005c312;
    func_0x000180459870(var_28h ^ (uint64_t)puVar15);
    return;
}

// ============================================================
// Function: FUN_18005c370
// Address: 0x18005c370
// Size: 854 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018005c3b9: Changing call to branch
// WARNING: Possible PIC construction at 0x00018005c3f4: Changing call to branch
// WARNING: Possible PIC construction at 0x00018005c42f: Changing call to branch
// WARNING: Possible PIC construction at 0x00018005c46a: Changing call to branch
// WARNING: Possible PIC construction at 0x00018005c4a5: Changing call to branch
// WARNING: Possible PIC construction at 0x00018005c4e0: Changing call to branch
// WARNING: Possible PIC construction at 0x00018005c527: Changing call to branch
// WARNING: Possible PIC construction at 0x00018005c5af: Changing call to branch
// WARNING: Possible PIC construction at 0x00018005c5f6: Changing call to branch
// WARNING: Possible PIC construction at 0x00018005c67e: Changing call to branch
// WARNING: Possible PIC construction at 0x00018005c635: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018005c5fb)
// WARNING: Removing unreachable block (ram,0x00018005c600)
// WARNING: Removing unreachable block (ram,0x00018005c622)
// WARNING: Removing unreachable block (ram,0x00018005c62d)
// WARNING: Removing unreachable block (ram,0x00018005c627)
// WARNING: Removing unreachable block (ram,0x00018005c63a)
// WARNING: Removing unreachable block (ram,0x00018005c648)
// WARNING: Removing unreachable block (ram,0x00018005c5b4)
// WARNING: Removing unreachable block (ram,0x00018005c52c)
// WARNING: Removing unreachable block (ram,0x00018005c531)
// WARNING: Removing unreachable block (ram,0x00018005c553)
// WARNING: Removing unreachable block (ram,0x00018005c55e)
// WARNING: Removing unreachable block (ram,0x00018005c558)
// WARNING: Removing unreachable block (ram,0x00018005c56b)
// WARNING: Removing unreachable block (ram,0x00018005c579)
// WARNING: Removing unreachable block (ram,0x00018005c4e5)
// WARNING: Removing unreachable block (ram,0x00018005c4aa)
// WARNING: Removing unreachable block (ram,0x00018005c46f)
// WARNING: Removing unreachable block (ram,0x00018005c434)
// WARNING: Removing unreachable block (ram,0x00018005c3f9)
// WARNING: Removing unreachable block (ram,0x00018005c3be)
// WARNING: Removing unreachable block (ram,0x00018005c683)
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.18005c370(undefined8 placeholder_0, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t var_20h;
    undefined auStack_c8 [32];
    undefined8 uStack_a8;
    undefined4 uStack_9c;
    uint64_t uStack_98;
    int64_t iStack_88;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    func_0x000180018f70();
    iVar4 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    func_0x0001800869f0(arg2, fcn.1800589b0, 0x1806245f0, 0);
    uStack_98 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_c8;
    iVar2 = (int32_t)iVar4;
    iStack_88 = iVar4;
    if (iVar2 < 1) {
        if (iVar2 < -9999) {
            uVar3 = func_0x000180085370();
        } else {
            uVar3 = (int64_t)iVar2 * 0x10 + *(int64_t *)(arg2 + 0x40);
        }
    } else {
        uVar3 = *(int64_t *)(arg2 + 0x28) + -0x10 + (int64_t)iVar2 * 0x10;
        if (*(uint64_t *)(arg2 + 0x40) <= uVar3) {
            uVar3 = *(uint64_t *)0x180782430;
        }
    }
    piVar5 = (int64_t *)(arg2 + 0x40);
    uVar1 = func_0x000180498cd0(0x1806245f0);
    uStack_a8 = func_0x00018009a8e0(arg2, 0x1806245f0, uVar1);
    uStack_9c = 6;
    func_0x0001800a8680(arg2, uVar3, &uStack_a8, *piVar5 + -0x10);
    *piVar5 = *piVar5 + -0x10;
    func_0x000180459870(uStack_98 ^ (uint64_t)auStack_c8);
    return;
}

// ============================================================
// Function: FUN_18005c6d0
// Address: 0x18005c6d0
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18005c6d0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    int32_t *piVar1;
    int32_t iVar2;
    char cVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar3 = *(char *)(arg3 + 0x19);
    while (cVar3 == '\0') {
        fcn.18005c6d0(arg1, arg2, *(int64_t *)(arg3 + 0x10), unaff_RDI);
        piVar4 = *(int64_t **)(arg3 + 0x28);
        piVar5 = *(int64_t **)arg3;
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)(*piVar4 + 8))();
            }
        }
        func_0x000180459c3c(arg3, 0x30);
        arg3 = (int64_t)piVar5;
        cVar3 = *(char *)((int64_t)piVar5 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_18005c6ef
// Address: 0x18005c6ef
// Size: 92 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18005c6d0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    int32_t *piVar1;
    int32_t iVar2;
    char cVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar3 = *(char *)(arg3 + 0x19);
    while (cVar3 == '\0') {
        fcn.18005c6d0(arg1, arg2, *(int64_t *)(arg3 + 0x10), unaff_RDI);
        piVar4 = *(int64_t **)(arg3 + 0x28);
        piVar5 = *(int64_t **)arg3;
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)(*piVar4 + 8))();
            }
        }
        func_0x000180459c3c(arg3, 0x30);
        arg3 = (int64_t)piVar5;
        cVar3 = *(char *)((int64_t)piVar5 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_18005c74b
// Address: 0x18005c74b
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18005c6d0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    int32_t *piVar1;
    int32_t iVar2;
    char cVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar3 = *(char *)(arg3 + 0x19);
    while (cVar3 == '\0') {
        fcn.18005c6d0(arg1, arg2, *(int64_t *)(arg3 + 0x10), unaff_RDI);
        piVar4 = *(int64_t **)(arg3 + 0x28);
        piVar5 = *(int64_t **)arg3;
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)(*piVar4 + 8))();
            }
        }
        func_0x000180459c3c(arg3, 0x30);
        arg3 = (int64_t)piVar5;
        cVar3 = *(char *)((int64_t)piVar5 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_18005c760
// Address: 0x18005c760
// Size: 57 bytes
// ============================================================
void fcn.18005c760(int64_t arg1)
{
    int64_t *arg1_00;
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t in_stack_00000008;
    
    arg1_00 = *(int64_t **)(arg1 + 8);
    if (arg1_00 == (int64_t *)0x0) {
        return;
    }
    fcn.18005c6d0((int64_t)arg1_00, *(int64_t *)arg1, *(int64_t *)(*arg1_00 + 8), in_stack_00000008);
    if ((*arg1_00 != 0) &&
       (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *arg1_00, in_R9, unaff_RBX), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar1 = (undefined4 *)fcn.18046b77c();
        *puVar1 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_18005c7a0
// Address: 0x18005c7a0
// Size: 98 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18005c7a0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    *(undefined8 *)(arg1 + 0x38) = 0;
    puVar1 = (undefined8 *)fcn.180459890(0x140);
    *puVar1 = 0x1806246c8;
    fcn.18003c320(puVar1 + 1, arg2);
    *(undefined8 **)(arg1 + 0x38) = puVar1;
    return arg1;
}

// ============================================================
// Function: FUN_18005c810
// Address: 0x18005c810
// Size: 2656 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_3b0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Removing arg arg_230h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_238h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_258h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.18005c810(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                  int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d0h,
                  int64_t arg_e0h, int64_t arg_e8h, int64_t arg_f0h, int64_t arg_f8h, int64_t arg_100h, int64_t arg_108h
                  , int64_t arg_110h, int64_t arg_118h, int64_t arg_120h, int64_t arg_1d0h, int64_t arg_1f0h,
                  int64_t arg_210h)
{
    undefined8 uVar1;
    code *pcVar2;
    bool bVar3;
    undefined auVar4 [16];
    undefined auVar5 [16];
    undefined auVar6 [16];
    int64_t **ppiVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int64_t **ppiVar11;
    char cVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t iVar15;
    int64_t *piVar16;
    undefined4 *puVar17;
    int64_t **ppiVar18;
    undefined8 uVar19;
    undefined8 uVar20;
    undefined8 ****ppppuVar21;
    int64_t iVar22;
    undefined8 *puVar23;
    int64_t **ppiVar24;
    undefined8 *puVar25;
    undefined *puVar26;
    undefined *puVar27;
    uint32_t uVar28;
    uint64_t uVar29;
    undefined8 ****ppppuVar30;
    undefined8 *puVar31;
    undefined4 uVar32;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_528 [8];
    undefined auStack_520 [24];
    int64_t var_508h;
    int64_t var_500h;
    int64_t var_4f8h;
    int64_t var_4f0h;
    int64_t var_4e8h;
    int64_t var_4e0h;
    int64_t var_4d8h;
    int64_t var_4d0h;
    int64_t var_4c8h;
    int64_t var_4c0h;
    int64_t var_4b0h;
    undefined8 uStack_4a8;
    int64_t aiStack_498 [7];
    int64_t *piStack_460;
    undefined auStack_458 [32];
    undefined4 uStack_438;
    undefined4 uStack_434;
    uint32_t uStack_430;
    undefined4 uStack_42c;
    uint64_t uStack_428;
    uint64_t uStack_420;
    undefined auStack_418 [12];
    undefined4 uStack_40c;
    undefined8 uStack_408;
    undefined8 uStack_400;
    undefined auStack_3f8 [16];
    undefined8 uStack_3e8;
    undefined8 uStack_3e0;
    undefined8 ****appppuStack_3d8 [2];
    int64_t iStack_3c8;
    uint64_t uStack_3c0;
    undefined8 ****ppppuStack_3b8;
    int64_t iStack_3b0;
    int64_t iStack_3a8;
    uint64_t uStack_3a0;
    undefined auStack_398 [16];
    undefined auStack_388 [16];
    undefined auStack_378 [16];
    undefined auStack_368 [16];
    undefined auStack_358 [16];
    undefined auStack_348 [16];
    undefined uStack_338;
    unkbyte7 Stack_337;
    undefined uStack_330;
    unkbyte7 Stack_32f;
    undefined8 uStack_328;
    undefined8 uStack_320;
    undefined auStack_318 [16];
    undefined8 uStack_308;
    undefined auStack_258 [32];
    undefined auStack_238 [32];
    undefined auStack_218 [32];
    undefined uStack_1f8;
    undefined auStack_1f0 [32];
    undefined uStack_1d0;
    undefined8 uStack_1c8;
    undefined auStack_1c0 [8];
    undefined auStack_1b8 [312];
    int64_t var_80h;
    uint64_t uStack_78;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_10h;
    
    puVar27 = auStack_528;
    uStack_78 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_528;
    uVar1 = *(undefined8 *)(arg1 + 0x38);
    var_4d8h = arg1;
    var_4c8h = arg1;
    uVar32 = func_0x00018007ff90();
    if (*(uint64_t *)(arg1 + 0x20) < 0x10) {
        var_4e8h = arg1 + 8;
    } else {
        var_4e8h = *(int64_t *)(arg1 + 8);
    }
    var_4e0h = *(int64_t *)(arg1 + 0x18);
    func_0x000180080600(uVar32, appppuStack_3d8, &var_4e8h);
    if (0x7fffffffffffffffU - iStack_3c8 < 0xb) {
        func_0x0001800047c0();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    ppppuVar21 = appppuStack_3d8;
    if (0xf < uStack_3c0) {
        ppppuVar21 = appppuStack_3d8[0];
    }
    uStack_438 = 0;
    uStack_434 = 0;
    uStack_430 = 0;
    uStack_42c = 0;
    puVar23 = (undefined8 *)0x0;
    uStack_428 = 0;
    uStack_420 = 0;
    uVar29 = iStack_3c8 + 0xb;
    if (uVar29 < 0x10) {
        uVar13 = 0xf;
        puVar23 = (undefined8 *)&uStack_438;
code_r0x00018005c95e:
        uStack_428 = uVar29;
        uStack_420 = uVar13;
        *puVar23 = 0x747069726373227b;
        *(undefined4 *)((int64_t)puVar23 + 7) = 0x223a2274;
        func_0x000180498030((int64_t)puVar23 + 0xb, ppppuVar21, iStack_3c8);
        *(undefined *)(uVar29 + (int64_t)puVar23) = 0;
        piVar16 = (int64_t *)func_0x00018000d970(&uStack_438, 0x18061fec8, 2);
        ppppuVar21 = (undefined8 ****)*piVar16;
        iStack_3b0 = piVar16[1];
        iStack_3a8 = piVar16[2];
        uVar29 = piVar16[3];
        piVar16[2] = 0;
        piVar16[3] = 0xf;
        *(undefined *)piVar16 = 0;
        ppppuStack_3b8 = ppppuVar21;
        uStack_3a0 = uVar29;
        if (0xf < uStack_420) {
            iVar15 = CONCAT44(uStack_434, uStack_438);
            uVar13 = uStack_420 + 1;
            if (0xfff < uVar13) {
                if (0x1f < (iVar15 - *(int64_t *)(iVar15 + -8)) - 8U) goto code_r0x00018005d202;
                uVar13 = uStack_420 + 0x28;
                iVar15 = *(int64_t *)(iVar15 + -8);
            }
            func_0x000180459c3c(iVar15, uVar13);
        }
        uStack_408 = 0xc;
        uStack_400 = 0xf;
        auStack_418._8_4_ = 0x65707954;
        auStack_418._0_8_ = 0x2d746e65746e6f43;
        uStack_40c = 0;
        auStack_3f8 = ZEXT816(0);
        uStack_3e8 = 0;
        uStack_3e0 = 0;
        puVar17 = (undefined4 *)fcn.180459890(0x20);
        auStack_3f8._0_8_ = puVar17;
        uStack_3e8 = 0x10;
        uStack_3e0 = 0x1f;
        *puVar17 = 0x6c707061;
        puVar17[1] = 0x74616369;
        puVar17[2] = 0x2f6e6f69;
        puVar17[3] = 0x6e6f736a;
        *(undefined *)(puVar17 + 4) = 0;
        var_4f8h = 0;
        var_4f0h = 0;
        ppiVar18 = (int64_t **)fcn.180459890(0x60);
        *ppiVar18 = (int64_t *)ppiVar18;
        ppiVar18[1] = (int64_t *)ppiVar18;
        ppiVar18[2] = (int64_t *)ppiVar18;
        *(undefined2 *)(ppiVar18 + 3) = 0x101;
        ppppuVar30 = (undefined8 ****)auStack_418;
        var_4f8h = (int64_t)ppiVar18;
        do {
            uVar9 = uStack_434;
            uVar32 = uStack_438;
            if (*(char *)((int64_t)ppiVar18 + 0x19) == '\0') {
                uStack_438 = SUB84(ppiVar18, 0);
                uVar8 = uStack_438;
                uStack_434 = (undefined4)((uint64_t)ppiVar18 >> 0x20);
                uVar10 = uStack_434;
                uStack_438 = uVar32;
                uStack_434 = uVar9;
                if (ppiVar18 == *(int64_t ***)var_4f8h) {
                    cVar12 = func_0x00018016b240(&var_4f8h, ppppuVar30, ppiVar18 + 4);
                    if (cVar12 == '\0') goto code_r0x00018005cc0a;
code_r0x00018005cb0b:
                    uStack_430 = 1;
                    bVar3 = false;
                    uStack_438 = uVar8;
                    uStack_434 = uVar10;
                } else {
                    cVar12 = func_0x00018016b240(&var_4f8h, ppppuVar30, ppiVar18 + 4);
                    if (cVar12 == '\0') {
                        cVar12 = func_0x00018016b240(&var_4f8h, ppiVar18 + 4, ppppuVar30);
                        if (cVar12 == '\0') {
                            bVar3 = true;
                            uStack_438 = uVar8;
                            uStack_434 = uVar10;
                        } else {
                            var_4e8h = (int64_t)ppiVar18;
                            piVar16 = (int64_t *)func_0x00018004a350(&var_4e8h);
                            iVar15 = *piVar16;
                            if ((*(char *)(iVar15 + 0x19) == '\0') &&
                               (cVar12 = func_0x00018016b240(&var_4f8h, ppppuVar30, iVar15 + 0x20), cVar12 == '\0'))
                            goto code_r0x00018005cc0a;
                            if (*(char *)((int64_t)ppiVar18[2] + 0x19) == '\0') {
                                uStack_438 = (undefined4)iVar15;
                                uStack_434 = (undefined4)((uint64_t)iVar15 >> 0x20);
                                uStack_430 = 1;
                                bVar3 = false;
                                goto code_r0x00018005ccd2;
                            }
                            bVar3 = false;
                            uStack_438 = uVar8;
                            uStack_434 = uVar10;
                        }
                    } else {
                        if (*(char *)((int64_t)ppiVar18 + 0x19) == '\0') {
                            ppiVar24 = (int64_t **)*ppiVar18;
                            if (*(char *)((int64_t)ppiVar24 + 0x19) == '\0') {
                                cVar12 = *(char *)((int64_t)ppiVar24[2] + 0x19);
                                while (cVar12 == '\0') {
                                    ppiVar24 = (int64_t **)ppiVar24[2];
                                    cVar12 = *(char *)((int64_t)ppiVar24[2] + 0x19);
                                }
                            } else {
                                cVar12 = *(char *)((int64_t)ppiVar18[1] + 0x19);
                                ppiVar11 = (int64_t **)ppiVar18[1];
                                ppiVar24 = ppiVar18;
                                while ((ppiVar7 = ppiVar11, cVar12 == '\0' && (ppiVar24 == (int64_t **)*ppiVar7))) {
                                    cVar12 = *(char *)((int64_t)ppiVar7[1] + 0x19);
                                    ppiVar11 = (int64_t **)ppiVar7[1];
                                    ppiVar24 = ppiVar7;
                                }
                                if (*(char *)((int64_t)ppiVar24 + 0x19) == '\0') {
                                    ppiVar24 = ppiVar7;
                                }
                            }
                        } else {
                            ppiVar24 = (int64_t **)ppiVar18[2];
                        }
                        cVar12 = func_0x00018016b240(&var_4f8h, ppiVar24 + 4, ppppuVar30);
                        if (cVar12 == '\0') goto code_r0x00018005cc0a;
                        if (*(char *)((int64_t)ppiVar24[2] + 0x19) == '\0') goto code_r0x00018005cb0b;
                        uStack_438 = SUB84(ppiVar24, 0);
                        uStack_434 = (undefined4)((uint64_t)ppiVar24 >> 0x20);
                        bVar3 = false;
                    }
code_r0x00018005cccb:
                    uStack_430 = 0;
                }
            } else {
                piVar16 = (int64_t *)(var_4f8h + 0x10);
                if ((*(char *)(*(int64_t *)(var_4f8h + 8) + 0x19) != '\0') ||
                   (cVar12 = func_0x00018016b240(&var_4f8h, *piVar16 + 0x20, ppppuVar30), cVar12 != '\0')) {
                    iVar15 = *piVar16;
                    uStack_438 = (undefined4)iVar15;
                    uStack_434 = (undefined4)((uint64_t)iVar15 >> 0x20);
                    bVar3 = false;
                    goto code_r0x00018005cccb;
                }
code_r0x00018005cc0a:
                puVar23 = *(undefined8 **)(var_4f8h + 8);
                puVar25 = puVar23;
                puVar31 = (undefined8 *)var_4f8h;
                if (*(char *)((int64_t)puVar23 + 0x19) == '\0') {
                    do {
                        puVar23 = puVar25;
                        cVar12 = func_0x00018016b240(&var_4f8h, puVar23 + 4, ppppuVar30);
                        if (cVar12 == '\0') {
                            puVar25 = (undefined8 *)*puVar23;
                            puVar31 = puVar23;
                        } else {
                            puVar25 = (undefined8 *)puVar23[2];
                        }
                        uVar28 = (uint32_t)(cVar12 == '\0');
                    } while (*(char *)((int64_t)puVar25 + 0x19) == '\0');
                } else {
                    uVar28 = 0;
                }
                if ((*(char *)((int64_t)puVar31 + 0x19) == '\0') &&
                   (cVar12 = func_0x00018016b240(&var_4f8h, ppppuVar30, puVar31 + 4), cVar12 == '\0')) {
                    uStack_438 = SUB84(puVar31, 0);
                    uStack_434 = (undefined4)((uint64_t)puVar31 >> 0x20);
                    uStack_430 = 2;
                    bVar3 = true;
                } else {
                    uStack_438 = SUB84(puVar23, 0);
                    uStack_434 = (undefined4)((uint64_t)puVar23 >> 0x20);
                    bVar3 = false;
                    uStack_430 = uVar28;
                }
            }
code_r0x00018005ccd2:
            iVar15 = var_4f8h;
            if (!bVar3) {
                if (var_4f0h == 0x2aaaaaaaaaaaaaa) {
                    func_0x000180013c00();
                    pcVar2 = (code *)swi(3);
                    (*pcVar2)();
                    return;
                }
                piVar16 = (int64_t *)fcn.180459890(0x60);
                fcn.18000b4d0(piVar16 + 4, ppppuVar30);
                fcn.18000b4d0(piVar16 + 8, ppppuVar30 + 4);
                *piVar16 = iVar15;
                piVar16[1] = iVar15;
                piVar16[2] = iVar15;
                *(undefined2 *)(piVar16 + 3) = 0;
                var_4e8h = CONCAT44(uStack_434, uStack_438);
                var_4e0h = CONCAT44(uStack_42c, uStack_430);
                func_0x0001800156d0(&var_4f8h, &var_4e8h, piVar16);
            }
            ppppuVar30 = ppppuVar30 + 8;
        } while ((undefined8 *****)ppppuVar30 != appppuStack_3d8);
        func_0x000180459d94(auStack_418, 0x40, 1, 0x180016a30);
        Stack_337 = 0;
        auStack_388 = ZEXT816(0xf) << 0x40;
        auStack_398._1_15_ = SUB1615(ZEXT816(0), 1);
        auVar4[15] = 0;
        auVar4._0_15_ = auStack_398._1_15_;
        auStack_398 = auVar4 << 8;
        auStack_368 = ZEXT816(0xf) << 0x40;
        auStack_378._1_15_ = SUB1615(ZEXT816(0), 1);
        auVar5[15] = 0;
        auVar5._0_15_ = auStack_378._1_15_;
        auStack_378 = auVar5 << 8;
        auStack_348 = ZEXT816(0xf) << 0x40;
        auStack_358._1_15_ = SUB1615(ZEXT816(0), 1);
        auVar6[15] = 0;
        auVar6._0_15_ = auStack_358._1_15_;
        auStack_358 = auVar6 << 8;
        uStack_338 = 0;
        Stack_32f = 0;
        uStack_328 = 0;
        uStack_320 = 0;
        uStack_330 = 0;
        auStack_318._0_9_ = ZEXT89(0xf);
        auStack_318._9_7_ = 0;
        uStack_308 = 0;
        ppppuVar30 = &ppppuStack_3b8;
        if (0xf < uVar29) {
            ppppuVar30 = ppppuVar21;
        }
        uVar19 = fcn.180459890(0x80);
        iVar15 = fcn.18003e190(&var_4e8h, &var_4f8h);
        uStack_438 = CONCAT31(uStack_438._1_3_, 1);
        fcn.18000b4d0(auStack_258, auStack_398);
        fcn.18000b4d0(auStack_238, auStack_378);
        fcn.18000b4d0(auStack_218, auStack_358);
        uStack_1f8 = uStack_338;
        fcn.18000b4d0(auStack_1f0, &uStack_330);
        uStack_1d0 = auStack_318[8];
        uStack_1c8 = uStack_308;
        uStack_430 = 0;
        uStack_42c = 0;
        uStack_428 = 0;
        uStack_420 = 0;
        func_0x00018003e9b0(&uStack_430, 1);
        uVar29 = CONCAT44(uStack_42c, uStack_430);
        puVar26 = auStack_258;
        do {
            func_0x0001800385d0(uVar29, puVar26);
            uVar29 = uVar29 + 0x98;
            puVar26 = puVar26 + 0x98;
        } while (puVar26 != auStack_1c0);
        uStack_428 = uVar29;
        func_0x000180459d94(auStack_258, 0x98, 1, 0x180038650);
        uVar20 = func_0x0001800047e0(auStack_458, ppppuVar30);
        _var_4c0h = ZEXT816(0);
        var_4b0h = 0;
        uStack_4a8 = 0;
        func_0x000180004830(&var_4c0h, 0x1806245a0, 0x20);
        var_500h._0_4_ = 1;
        var_508h = iVar15;
        iVar15 = func_0x000180083dc0(uVar19, &var_4c0h, uVar20, &uStack_438);
        var_4e8h = iVar15;
        if (0xf < (uint64_t)auStack_318._0_8_) {
            iVar22 = CONCAT71(Stack_32f, uStack_330);
            uVar29 = auStack_318._0_8_ + 1;
            if (0xfff < uVar29) {
                if (0x1f < (iVar22 - *(int64_t *)(iVar22 + -8)) - 8U) goto code_r0x00018005d202;
                uVar29 = auStack_318._0_8_ + 0x28;
                iVar22 = *(int64_t *)(iVar22 + -8);
            }
            func_0x000180459c3c(iVar22, uVar29);
        }
        if (0xf < (uint64_t)auStack_348._8_8_) {
            uVar29 = auStack_348._8_8_ + 1;
            iVar22 = auStack_358._0_8_;
            if (0xfff < uVar29) {
                if (0x1f < (auStack_358._0_8_ - *(int64_t *)(auStack_358._0_8_ + -8)) - 8U) goto code_r0x00018005d202;
                uVar29 = auStack_348._8_8_ + 0x28;
                iVar22 = *(int64_t *)(auStack_358._0_8_ + -8);
            }
            func_0x000180459c3c(iVar22, uVar29);
        }
        if (0xf < (uint64_t)auStack_368._8_8_) {
            uVar29 = auStack_368._8_8_ + 1;
            iVar22 = auStack_378._0_8_;
            if (0xfff < uVar29) {
                if (0x1f < (auStack_378._0_8_ - *(int64_t *)(auStack_378._0_8_ + -8)) - 8U) goto code_r0x00018005d202;
                uVar29 = auStack_368._8_8_ + 0x28;
                iVar22 = *(int64_t *)(auStack_378._0_8_ + -8);
            }
            func_0x000180459c3c(iVar22, uVar29);
        }
        if (0xf < (uint64_t)auStack_388._8_8_) {
            uVar29 = auStack_388._8_8_ + 1;
            iVar22 = auStack_398._0_8_;
            if (0xfff < uVar29) {
                if (0x1f < (auStack_398._0_8_ - *(int64_t *)(auStack_398._0_8_ + -8)) - 8U) goto code_r0x00018005d202;
                uVar29 = auStack_388._8_8_ + 0x28;
                iVar22 = *(int64_t *)(auStack_398._0_8_ + -8);
            }
            func_0x000180459c3c(iVar22, uVar29);
        }
        func_0x000180084280(iVar15, auStack_1b8, 2);
        puVar23 = (undefined8 *)func_0x0001800137d0();
        uVar19 = *puVar23;
        fcn.18003c320(auStack_398, auStack_1b8);
        puVar23 = (undefined8 *)fcn.180459890(0x88);
        iVar22 = var_4d8h;
        *(undefined4 *)(puVar23 + 1) = 1;
        *(undefined4 *)((int64_t)puVar23 + 0xc) = 1;
        *puVar23 = 0x180623990;
        iVar15 = *(int64_t *)var_4d8h;
        fcn.18005c7a0((int64_t)aiStack_498, (int64_t)auStack_398);
        var_500h._0_4_ = (uint32_t)var_500h & 0xffffff00;
        var_508h = iVar15;
        func_0x000180047960(puVar23 + 2, aiStack_498, uVar1, iVar22 + 0x28);
        if (piStack_460 != (int64_t *)0x0) {
            (**(code **)(*piStack_460 + 0x20))
                      (piStack_460, CONCAT71((unkint7)((uint64_t)aiStack_498 >> 8), piStack_460 != aiStack_498));
        }
        var_4d8h = (int64_t)(puVar23 + 2);
        var_4d0h = (int64_t)puVar23;
        func_0x00018000a9d0(uVar19, &var_4d8h);
        if (var_4d0h != 0) {
            func_0x000180005cf0();
        }
        func_0x00018003c510(auStack_398);
        func_0x00018003c510(auStack_1b8);
        func_0x00018003ded0(&var_4e8h);
        func_0x000180015170(&var_4f8h, &var_4f8h, *(undefined8 *)(var_4f8h + 8));
        func_0x000180459c3c(var_4f8h, 0x60);
        if (uStack_3a0 < 0x10) goto code_r0x00018005d211;
        ppppuVar21 = ppppuStack_3b8;
        puVar27 = auStack_528;
        if ((0xfff < uStack_3a0 + 1) &&
           (ppppuVar21 = (undefined8 ****)ppppuStack_3b8[-1], puVar27 = auStack_528,
           0x1f < (uint64_t)((int64_t)ppppuStack_3b8 + (-8 - (int64_t)ppppuStack_3b8[-1])))) goto code_r0x00018005d202;
    } else {
        uVar13 = uVar29 | 0xf;
        if (uVar13 < 0x8000000000000000) {
            if (uVar13 < 0x16) {
                uVar13 = 0x16;
            }
            if (uVar13 == 0xffffffffffffffff) {
                uStack_438 = 0;
                uStack_434 = 0;
            } else {
                if (0xfff < uVar13 + 1) {
                    uVar14 = uVar13 + 0x28;
                    if (uVar14 <= uVar13 + 1) {
                        fcn.180004720();
                        pcVar2 = (code *)swi(3);
                        (*pcVar2)();
                        return;
                    }
                    goto code_r0x00018005c8eb;
                }
                puVar23 = (undefined8 *)fcn.180459890();
                uStack_438 = SUB84(puVar23, 0);
                uStack_434 = (undefined4)((uint64_t)puVar23 >> 0x20);
            }
            goto code_r0x00018005c95e;
        }
        uVar14 = 0x8000000000000027;
        uVar13 = 0x7fffffffffffffff;
code_r0x00018005c8eb:
        iVar15 = fcn.180459890(uVar14);
        if (iVar15 != 0) {
            puVar23 = (undefined8 *)(iVar15 + 0x27U & 0xffffffffffffffe0);
            puVar23[-1] = iVar15;
            uStack_438 = SUB84(puVar23, 0);
            uStack_434 = (undefined4)((uint64_t)puVar23 >> 0x20);
            goto code_r0x00018005c95e;
        }
code_r0x00018005d202:
        pcVar2 = (code *)swi(0x29);
        ppppuVar21 = (undefined8 ****)(*pcVar2)(5);
        puVar27 = auStack_520;
    }
    *(undefined8 *)(puVar27 + -8) = 0x18005d211;
    func_0x000180459c3c(ppppuVar21);
code_r0x00018005d211:
    *(undefined8 *)(puVar27 + -8) = 0x18005d21a;
    func_0x000180004e40(appppuStack_3d8);
    *(undefined8 *)(puVar27 + -8) = 0x18005d21f;
    func_0x00018045476c();
    *(undefined8 *)(puVar27 + -8) = 0x18005d229;
    func_0x00018004b0d0(puVar27 + 0x60);
    *(undefined8 *)(puVar27 + -8) = 0x18005d23a;
    func_0x000180459870(uStack_78 ^ (uint64_t)puVar27);
    return;
}

// ============================================================
// Function: FUN_18005d270
// Address: 0x18005d270
// Size: 206 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h

undefined8 * fcn.18005d270(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int32_t *piVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined8 *arg3_00;
    undefined8 uVar4;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    puVar2 = *(undefined8 **)arg1;
    if (*(char *)(arg2 + 0x19) == '\0') {
        arg3_00 = (undefined8 *)fcn.180459890(0x30);
        arg3_00[4] = 0;
        arg3_00[5] = 0;
        if (*(int64_t *)(arg2 + 0x28) != 0) {
            arg3_00[4] = *(undefined8 *)(arg2 + 0x20);
            iVar3 = *(int64_t *)(arg2 + 0x28);
            arg3_00[5] = iVar3;
            LOCK();
            piVar1 = (int32_t *)(iVar3 + 0xc);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        *arg3_00 = puVar2;
        arg3_00[2] = puVar2;
        *(undefined2 *)(arg3_00 + 3) = 0;
        arg3_00[1] = arg3;
        *(undefined *)(arg3_00 + 3) = *(undefined *)(arg2 + 0x18);
        uVar4 = fcn.18005d270(arg1, *(int64_t *)arg2, (int64_t)arg3_00, placeholder_3, arg1);
        *arg3_00 = uVar4;
        uVar4 = fcn.18005d270(arg1, *(int64_t *)(arg2 + 0x10), (int64_t)arg3_00, placeholder_3, arg1);
        arg3_00[2] = uVar4;
        return arg3_00;
    }
    return puVar2;
}

// ============================================================
// Function: FUN_18005d380
// Address: 0x18005d380
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.18005d380(int64_t arg1)
{
    undefined8 *puVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar1 = (undefined8 *)fcn.180459890(0x140);
    *puVar1 = 0x1806246c8;
    fcn.18003c320(puVar1 + 1, arg1 + 8);
    return puVar1;
}

// ============================================================
// Function: FUN_18005d440
// Address: 0x18005d440
// Size: 158 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18005d440(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t *piVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    code *pcVar13;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar9 = piVar1;
    if (piVar2 <= piVar1) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) && (iVar3 = *piVar9, *(char *)(iVar3 + 3) == 'z')) &&
       (iVar3 != -0x10)) {
        if (((*(int64_t *)(iVar3 + 0x20) != 0) &&
            (*(int64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x20) == *(int64_t *)(arg1 + 0x20))) &&
           (*(int32_t *)(iVar3 + 0x30) != 0)) {
            func_0x000180086ed0(arg1, 0xffffd8f0);
            piVar9 = *(int64_t **)0x180782430;
            if (((int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10U) != *(int64_t **)0x180782430) &&
               (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 8)) {
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar4 = *(int64_t **)(arg1 + 0x40);
                uVar6 = *(undefined4 *)((int64_t)piVar4 + -0xc);
                uVar7 = *(undefined4 *)(piVar4 + -1);
                uVar8 = *(undefined4 *)((int64_t)piVar4 + -4);
                piVar12 = *(int64_t **)(arg1 + 0x28);
                if (piVar4 <= *(int64_t **)(arg1 + 0x28)) {
                    piVar12 = piVar9;
                }
                *(undefined4 *)piVar12 = *(undefined4 *)(piVar4 + -2);
                *(undefined4 *)((int64_t)piVar12 + 4) = uVar6;
                *(undefined4 *)(piVar12 + 1) = uVar7;
                *(undefined4 *)((int64_t)piVar12 + 0xc) = uVar8;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                iVar10 = func_0x000180085760(*(undefined8 *)(iVar3 + 0x20));
                if (iVar10 != 0) {
                    piVar9 = (int64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x40);
                    *piVar9 = *piVar9 + -0x10;
                    func_0x000180085680(arg1, iVar10, (int64_t)piVar2 - (int64_t)piVar1 >> 4 & 0xffffffff);
                    pcVar13 = *(code **)0x1807824c8;
                    if (*(code **)0x1807824c8 == (code *)0x0) {
                        func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaf04);
                        func_0x000180086cc0(arg1, 0xffffffff, 0x1805aaf0c);
                        iVar5 = *(int64_t *)(arg1 + 0x40);
                        if ((*(int32_t *)(iVar5 + -4) == 8) && (*(char *)(*(int64_t *)(iVar5 + -0x10) + 3) != '\0')) {
                            pcVar13 = *(code **)(*(int64_t *)(iVar5 + -0x10) + 0x20);
                        } else {
                            pcVar13 = (code *)0x0;
                        }
                        *(code **)0x1807824c8 = pcVar13;
                        *(int64_t *)(arg1 + 0x40) = iVar5 + -0x20;
                    }
                    (*pcVar13)(iVar10);
                }
                if (*(char *)(iVar3 + 0x29) != '\0') {
                    (**(code **)0x180782568)(iVar3 + 0x18);
                    *(undefined *)(iVar3 + 0x28) = 1;
                }
            }
        }
        return 0;
    }
    func_0x0001800883d0(arg1, 1, 0x180624778);
    pcVar13 = (code *)swi(3);
    uVar11 = (*pcVar13)();
    return uVar11;
}

// ============================================================
// Function: FUN_18005d4de
// Address: 0x18005d4de
// Size: 219 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18005d440(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t *piVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    code *pcVar13;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar9 = piVar1;
    if (piVar2 <= piVar1) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) && (iVar3 = *piVar9, *(char *)(iVar3 + 3) == 'z')) &&
       (iVar3 != -0x10)) {
        if (((*(int64_t *)(iVar3 + 0x20) != 0) &&
            (*(int64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x20) == *(int64_t *)(arg1 + 0x20))) &&
           (*(int32_t *)(iVar3 + 0x30) != 0)) {
            func_0x000180086ed0(arg1, 0xffffd8f0);
            piVar9 = *(int64_t **)0x180782430;
            if (((int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10U) != *(int64_t **)0x180782430) &&
               (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 8)) {
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar4 = *(int64_t **)(arg1 + 0x40);
                uVar6 = *(undefined4 *)((int64_t)piVar4 + -0xc);
                uVar7 = *(undefined4 *)(piVar4 + -1);
                uVar8 = *(undefined4 *)((int64_t)piVar4 + -4);
                piVar12 = *(int64_t **)(arg1 + 0x28);
                if (piVar4 <= *(int64_t **)(arg1 + 0x28)) {
                    piVar12 = piVar9;
                }
                *(undefined4 *)piVar12 = *(undefined4 *)(piVar4 + -2);
                *(undefined4 *)((int64_t)piVar12 + 4) = uVar6;
                *(undefined4 *)(piVar12 + 1) = uVar7;
                *(undefined4 *)((int64_t)piVar12 + 0xc) = uVar8;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                iVar10 = func_0x000180085760(*(undefined8 *)(iVar3 + 0x20));
                if (iVar10 != 0) {
                    piVar9 = (int64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x40);
                    *piVar9 = *piVar9 + -0x10;
                    func_0x000180085680(arg1, iVar10, (int64_t)piVar2 - (int64_t)piVar1 >> 4 & 0xffffffff);
                    pcVar13 = *(code **)0x1807824c8;
                    if (*(code **)0x1807824c8 == (code *)0x0) {
                        func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaf04);
                        func_0x000180086cc0(arg1, 0xffffffff, 0x1805aaf0c);
                        iVar5 = *(int64_t *)(arg1 + 0x40);
                        if ((*(int32_t *)(iVar5 + -4) == 8) && (*(char *)(*(int64_t *)(iVar5 + -0x10) + 3) != '\0')) {
                            pcVar13 = *(code **)(*(int64_t *)(iVar5 + -0x10) + 0x20);
                        } else {
                            pcVar13 = (code *)0x0;
                        }
                        *(code **)0x1807824c8 = pcVar13;
                        *(int64_t *)(arg1 + 0x40) = iVar5 + -0x20;
                    }
                    (*pcVar13)(iVar10);
                }
                if (*(char *)(iVar3 + 0x29) != '\0') {
                    (**(code **)0x180782568)(iVar3 + 0x18);
                    *(undefined *)(iVar3 + 0x28) = 1;
                }
            }
        }
        return 0;
    }
    func_0x0001800883d0(arg1, 1, 0x180624778);
    pcVar13 = (code *)swi(3);
    uVar11 = (*pcVar13)();
    return uVar11;
}

// ============================================================
// Function: FUN_18005d5b9
// Address: 0x18005d5b9
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18005d440(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t *piVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    code *pcVar13;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar9 = piVar1;
    if (piVar2 <= piVar1) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) && (iVar3 = *piVar9, *(char *)(iVar3 + 3) == 'z')) &&
       (iVar3 != -0x10)) {
        if (((*(int64_t *)(iVar3 + 0x20) != 0) &&
            (*(int64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x20) == *(int64_t *)(arg1 + 0x20))) &&
           (*(int32_t *)(iVar3 + 0x30) != 0)) {
            func_0x000180086ed0(arg1, 0xffffd8f0);
            piVar9 = *(int64_t **)0x180782430;
            if (((int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10U) != *(int64_t **)0x180782430) &&
               (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 8)) {
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar4 = *(int64_t **)(arg1 + 0x40);
                uVar6 = *(undefined4 *)((int64_t)piVar4 + -0xc);
                uVar7 = *(undefined4 *)(piVar4 + -1);
                uVar8 = *(undefined4 *)((int64_t)piVar4 + -4);
                piVar12 = *(int64_t **)(arg1 + 0x28);
                if (piVar4 <= *(int64_t **)(arg1 + 0x28)) {
                    piVar12 = piVar9;
                }
                *(undefined4 *)piVar12 = *(undefined4 *)(piVar4 + -2);
                *(undefined4 *)((int64_t)piVar12 + 4) = uVar6;
                *(undefined4 *)(piVar12 + 1) = uVar7;
                *(undefined4 *)((int64_t)piVar12 + 0xc) = uVar8;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                iVar10 = func_0x000180085760(*(undefined8 *)(iVar3 + 0x20));
                if (iVar10 != 0) {
                    piVar9 = (int64_t *)(*(int64_t *)(iVar3 + 0x20) + 0x40);
                    *piVar9 = *piVar9 + -0x10;
                    func_0x000180085680(arg1, iVar10, (int64_t)piVar2 - (int64_t)piVar1 >> 4 & 0xffffffff);
                    pcVar13 = *(code **)0x1807824c8;
                    if (*(code **)0x1807824c8 == (code *)0x0) {
                        func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaf04);
                        func_0x000180086cc0(arg1, 0xffffffff, 0x1805aaf0c);
                        iVar5 = *(int64_t *)(arg1 + 0x40);
                        if ((*(int32_t *)(iVar5 + -4) == 8) && (*(char *)(*(int64_t *)(iVar5 + -0x10) + 3) != '\0')) {
                            pcVar13 = *(code **)(*(int64_t *)(iVar5 + -0x10) + 0x20);
                        } else {
                            pcVar13 = (code *)0x0;
                        }
                        *(code **)0x1807824c8 = pcVar13;
                        *(int64_t *)(arg1 + 0x40) = iVar5 + -0x20;
                    }
                    (*pcVar13)(iVar10);
                }
                if (*(char *)(iVar3 + 0x29) != '\0') {
                    (**(code **)0x180782568)(iVar3 + 0x18);
                    *(undefined *)(iVar3 + 0x28) = 1;
                }
            }
        }
        return 0;
    }
    func_0x0001800883d0(arg1, 1, 0x180624778);
    pcVar13 = (code *)swi(3);
    uVar11 = (*pcVar13)();
    return uVar11;
}

// ============================================================
// Function: FUN_18005d5f0
// Address: 0x18005d5f0
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18005d5f0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    undefined8 uVar13;
    int64_t *piVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t *piVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    undefined4 uStack_20;
    
    piVar17 = *(int64_t **)0x180782430;
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar10 = piVar1;
    if (piVar2 <= piVar1) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar10 + 0xc) != 9) || (iVar3 = *piVar10, *(char *)(iVar3 + 3) != 'z')) ||
       (iVar3 == -0x10)) {
        func_0x0001800883d0(arg1, 1, 0x180624778);
        pcVar5 = (code *)swi(3);
        uVar13 = (*pcVar5)();
        return uVar13;
    }
    iVar15 = *(int32_t *)(iVar3 + 0x30);
    if (iVar15 != 0) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar9 = func_0x000180085510(arg1, 1), piVar17 = *(int64_t **)0x180782430, iVar9 == 0)) {
            func_0x000180099450(arg1, 0x18063d8d0);
            func_0x000180087960(arg1);
            pcVar5 = (code *)swi(3);
            uVar13 = (*pcVar5)();
            return uVar13;
        }
        puVar11 = (undefined8 *)func_0x000180085370(arg1, 0xffffd8f0);
        puVar12 = (undefined4 *)func_0x0001800a0d50(*puVar11, iVar15);
        puVar4 = *(undefined4 **)(arg1 + 0x40);
        uVar6 = puVar12[1];
        uVar7 = puVar12[2];
        uVar8 = puVar12[3];
        *puVar4 = *puVar12;
        puVar4[1] = uVar6;
        puVar4[2] = uVar7;
        puVar4[3] = uVar8;
        piVar10 = *(int64_t **)(arg1 + 0x40);
        *(int64_t **)(arg1 + 0x40) = piVar10 + 2;
        if ((piVar10 == piVar17) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
            *(int64_t **)(arg1 + 0x40) = piVar10;
        } else {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            piVar10 = *(int64_t **)(arg1 + 0x40);
            uVar6 = *(undefined4 *)((int64_t)piVar10 + -0xc);
            uVar7 = *(undefined4 *)(piVar10 + -1);
            uVar8 = *(undefined4 *)((int64_t)piVar10 + -4);
            piVar14 = *(int64_t **)(arg1 + 0x28);
            if (piVar10 <= *(int64_t **)(arg1 + 0x28)) {
                piVar14 = piVar17;
            }
            *(undefined4 *)piVar14 = *(undefined4 *)(piVar10 + -2);
            *(undefined4 *)((int64_t)piVar14 + 4) = uVar6;
            *(undefined4 *)(piVar14 + 1) = uVar7;
            *(undefined4 *)((int64_t)piVar14 + 0xc) = uVar8;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaf04);
            func_0x000180086cc0(arg1, 0xffffffff, 0x1806217b8);
            func_0x0001800859a0(arg1, 1);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            uVar16 = (uint32_t)((int64_t)piVar2 - (int64_t)piVar1 >> 4);
            iVar15 = uVar16 + 1;
            if ((((iVar15 < 0) && (*(char *)0x180777010 != '\0')) &&
                (uVar16 = ~uVar16,
                **(uint64_t **)(arg1 + 0x18) < (uint64_t)((int64_t)(int32_t)uVar16 * 0x10 + *(int64_t *)(arg1 + 0x40))))
               && (iVar9 = func_0x000180085510(arg1, uVar16), iVar9 == 0)) {
                func_0x000180099450(arg1, 0x18063d8d0);
                func_0x000180087960(arg1);
                pcVar5 = (code *)swi(3);
                uVar13 = (*pcVar5)();
                return uVar13;
            }
            var_28h = *(int64_t *)(arg1 + 0x40) + (int64_t)iVar15 * -0x10;
            uStack_20 = 0;
            func_0x000180094080(arg1, 0x180087890, &var_28h, var_28h - *(int64_t *)(arg1 + 0x38), 0);
            if (*(char *)(iVar3 + 0x29) != '\0') {
                (**(code **)0x180782568)(iVar3 + 0x18);
                *(undefined *)(iVar3 + 0x28) = 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18005d639
// Address: 0x18005d639
// Size: 474 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18005d5f0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    undefined8 uVar13;
    int64_t *piVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t *piVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    undefined4 uStack_20;
    
    piVar17 = *(int64_t **)0x180782430;
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar10 = piVar1;
    if (piVar2 <= piVar1) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar10 + 0xc) != 9) || (iVar3 = *piVar10, *(char *)(iVar3 + 3) != 'z')) ||
       (iVar3 == -0x10)) {
        func_0x0001800883d0(arg1, 1, 0x180624778);
        pcVar5 = (code *)swi(3);
        uVar13 = (*pcVar5)();
        return uVar13;
    }
    iVar15 = *(int32_t *)(iVar3 + 0x30);
    if (iVar15 != 0) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar9 = func_0x000180085510(arg1, 1), piVar17 = *(int64_t **)0x180782430, iVar9 == 0)) {
            func_0x000180099450(arg1, 0x18063d8d0);
            func_0x000180087960(arg1);
            pcVar5 = (code *)swi(3);
            uVar13 = (*pcVar5)();
            return uVar13;
        }
        puVar11 = (undefined8 *)func_0x000180085370(arg1, 0xffffd8f0);
        puVar12 = (undefined4 *)func_0x0001800a0d50(*puVar11, iVar15);
        puVar4 = *(undefined4 **)(arg1 + 0x40);
        uVar6 = puVar12[1];
        uVar7 = puVar12[2];
        uVar8 = puVar12[3];
        *puVar4 = *puVar12;
        puVar4[1] = uVar6;
        puVar4[2] = uVar7;
        puVar4[3] = uVar8;
        piVar10 = *(int64_t **)(arg1 + 0x40);
        *(int64_t **)(arg1 + 0x40) = piVar10 + 2;
        if ((piVar10 == piVar17) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
            *(int64_t **)(arg1 + 0x40) = piVar10;
        } else {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            piVar10 = *(int64_t **)(arg1 + 0x40);
            uVar6 = *(undefined4 *)((int64_t)piVar10 + -0xc);
            uVar7 = *(undefined4 *)(piVar10 + -1);
            uVar8 = *(undefined4 *)((int64_t)piVar10 + -4);
            piVar14 = *(int64_t **)(arg1 + 0x28);
            if (piVar10 <= *(int64_t **)(arg1 + 0x28)) {
                piVar14 = piVar17;
            }
            *(undefined4 *)piVar14 = *(undefined4 *)(piVar10 + -2);
            *(undefined4 *)((int64_t)piVar14 + 4) = uVar6;
            *(undefined4 *)(piVar14 + 1) = uVar7;
            *(undefined4 *)((int64_t)piVar14 + 0xc) = uVar8;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaf04);
            func_0x000180086cc0(arg1, 0xffffffff, 0x1806217b8);
            func_0x0001800859a0(arg1, 1);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            uVar16 = (uint32_t)((int64_t)piVar2 - (int64_t)piVar1 >> 4);
            iVar15 = uVar16 + 1;
            if ((((iVar15 < 0) && (*(char *)0x180777010 != '\0')) &&
                (uVar16 = ~uVar16,
                **(uint64_t **)(arg1 + 0x18) < (uint64_t)((int64_t)(int32_t)uVar16 * 0x10 + *(int64_t *)(arg1 + 0x40))))
               && (iVar9 = func_0x000180085510(arg1, uVar16), iVar9 == 0)) {
                func_0x000180099450(arg1, 0x18063d8d0);
                func_0x000180087960(arg1);
                pcVar5 = (code *)swi(3);
                uVar13 = (*pcVar5)();
                return uVar13;
            }
            var_28h = *(int64_t *)(arg1 + 0x40) + (int64_t)iVar15 * -0x10;
            uStack_20 = 0;
            func_0x000180094080(arg1, 0x180087890, &var_28h, var_28h - *(int64_t *)(arg1 + 0x38), 0);
            if (*(char *)(iVar3 + 0x29) != '\0') {
                (**(code **)0x180782568)(iVar3 + 0x18);
                *(undefined *)(iVar3 + 0x28) = 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18005d813
// Address: 0x18005d813
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18005d5f0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    undefined8 uVar13;
    int64_t *piVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t *piVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    undefined4 uStack_20;
    
    piVar17 = *(int64_t **)0x180782430;
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar10 = piVar1;
    if (piVar2 <= piVar1) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar10 + 0xc) != 9) || (iVar3 = *piVar10, *(char *)(iVar3 + 3) != 'z')) ||
       (iVar3 == -0x10)) {
        func_0x0001800883d0(arg1, 1, 0x180624778);
        pcVar5 = (code *)swi(3);
        uVar13 = (*pcVar5)();
        return uVar13;
    }
    iVar15 = *(int32_t *)(iVar3 + 0x30);
    if (iVar15 != 0) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar9 = func_0x000180085510(arg1, 1), piVar17 = *(int64_t **)0x180782430, iVar9 == 0)) {
            func_0x000180099450(arg1, 0x18063d8d0);
            func_0x000180087960(arg1);
            pcVar5 = (code *)swi(3);
            uVar13 = (*pcVar5)();
            return uVar13;
        }
        puVar11 = (undefined8 *)func_0x000180085370(arg1, 0xffffd8f0);
        puVar12 = (undefined4 *)func_0x0001800a0d50(*puVar11, iVar15);
        puVar4 = *(undefined4 **)(arg1 + 0x40);
        uVar6 = puVar12[1];
        uVar7 = puVar12[2];
        uVar8 = puVar12[3];
        *puVar4 = *puVar12;
        puVar4[1] = uVar6;
        puVar4[2] = uVar7;
        puVar4[3] = uVar8;
        piVar10 = *(int64_t **)(arg1 + 0x40);
        *(int64_t **)(arg1 + 0x40) = piVar10 + 2;
        if ((piVar10 == piVar17) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
            *(int64_t **)(arg1 + 0x40) = piVar10;
        } else {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            piVar10 = *(int64_t **)(arg1 + 0x40);
            uVar6 = *(undefined4 *)((int64_t)piVar10 + -0xc);
            uVar7 = *(undefined4 *)(piVar10 + -1);
            uVar8 = *(undefined4 *)((int64_t)piVar10 + -4);
            piVar14 = *(int64_t **)(arg1 + 0x28);
            if (piVar10 <= *(int64_t **)(arg1 + 0x28)) {
                piVar14 = piVar17;
            }
            *(undefined4 *)piVar14 = *(undefined4 *)(piVar10 + -2);
            *(undefined4 *)((int64_t)piVar14 + 4) = uVar6;
            *(undefined4 *)(piVar14 + 1) = uVar7;
            *(undefined4 *)((int64_t)piVar14 + 0xc) = uVar8;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaf04);
            func_0x000180086cc0(arg1, 0xffffffff, 0x1806217b8);
            func_0x0001800859a0(arg1, 1);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            uVar16 = (uint32_t)((int64_t)piVar2 - (int64_t)piVar1 >> 4);
            iVar15 = uVar16 + 1;
            if ((((iVar15 < 0) && (*(char *)0x180777010 != '\0')) &&
                (uVar16 = ~uVar16,
                **(uint64_t **)(arg1 + 0x18) < (uint64_t)((int64_t)(int32_t)uVar16 * 0x10 + *(int64_t *)(arg1 + 0x40))))
               && (iVar9 = func_0x000180085510(arg1, uVar16), iVar9 == 0)) {
                func_0x000180099450(arg1, 0x18063d8d0);
                func_0x000180087960(arg1);
                pcVar5 = (code *)swi(3);
                uVar13 = (*pcVar5)();
                return uVar13;
            }
            var_28h = *(int64_t *)(arg1 + 0x40) + (int64_t)iVar15 * -0x10;
            uStack_20 = 0;
            func_0x000180094080(arg1, 0x180087890, &var_28h, var_28h - *(int64_t *)(arg1 + 0x38), 0);
            if (*(char *)(iVar3 + 0x29) != '\0') {
                (**(code **)0x180782568)(iVar3 + 0x18);
                *(undefined *)(iVar3 + 0x28) = 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18005d825
// Address: 0x18005d825
// Size: 48 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18005d5f0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    undefined8 uVar13;
    int64_t *piVar14;
    int32_t iVar15;
    uint32_t uVar16;
    int64_t *piVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    undefined4 uStack_20;
    
    piVar17 = *(int64_t **)0x180782430;
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar10 = piVar1;
    if (piVar2 <= piVar1) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar10 + 0xc) != 9) || (iVar3 = *piVar10, *(char *)(iVar3 + 3) != 'z')) ||
       (iVar3 == -0x10)) {
        func_0x0001800883d0(arg1, 1, 0x180624778);
        pcVar5 = (code *)swi(3);
        uVar13 = (*pcVar5)();
        return uVar13;
    }
    iVar15 = *(int32_t *)(iVar3 + 0x30);
    if (iVar15 != 0) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar9 = func_0x000180085510(arg1, 1), piVar17 = *(int64_t **)0x180782430, iVar9 == 0)) {
            func_0x000180099450(arg1, 0x18063d8d0);
            func_0x000180087960(arg1);
            pcVar5 = (code *)swi(3);
            uVar13 = (*pcVar5)();
            return uVar13;
        }
        puVar11 = (undefined8 *)func_0x000180085370(arg1, 0xffffd8f0);
        puVar12 = (undefined4 *)func_0x0001800a0d50(*puVar11, iVar15);
        puVar4 = *(undefined4 **)(arg1 + 0x40);
        uVar6 = puVar12[1];
        uVar7 = puVar12[2];
        uVar8 = puVar12[3];
        *puVar4 = *puVar12;
        puVar4[1] = uVar6;
        puVar4[2] = uVar7;
        puVar4[3] = uVar8;
        piVar10 = *(int64_t **)(arg1 + 0x40);
        *(int64_t **)(arg1 + 0x40) = piVar10 + 2;
        if ((piVar10 == piVar17) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 8)) {
            *(int64_t **)(arg1 + 0x40) = piVar10;
        } else {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            piVar10 = *(int64_t **)(arg1 + 0x40);
            uVar6 = *(undefined4 *)((int64_t)piVar10 + -0xc);
            uVar7 = *(undefined4 *)(piVar10 + -1);
            uVar8 = *(undefined4 *)((int64_t)piVar10 + -4);
            piVar14 = *(int64_t **)(arg1 + 0x28);
            if (piVar10 <= *(int64_t **)(arg1 + 0x28)) {
                piVar14 = piVar17;
            }
            *(undefined4 *)piVar14 = *(undefined4 *)(piVar10 + -2);
            *(undefined4 *)((int64_t)piVar14 + 4) = uVar6;
            *(undefined4 *)(piVar14 + 1) = uVar7;
            *(undefined4 *)((int64_t)piVar14 + 0xc) = uVar8;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaf04);
            func_0x000180086cc0(arg1, 0xffffffff, 0x1806217b8);
            func_0x0001800859a0(arg1, 1);
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            uVar16 = (uint32_t)((int64_t)piVar2 - (int64_t)piVar1 >> 4);
            iVar15 = uVar16 + 1;
            if ((((iVar15 < 0) && (*(char *)0x180777010 != '\0')) &&
                (uVar16 = ~uVar16,
                **(uint64_t **)(arg1 + 0x18) < (uint64_t)((int64_t)(int32_t)uVar16 * 0x10 + *(int64_t *)(arg1 + 0x40))))
               && (iVar9 = func_0x000180085510(arg1, uVar16), iVar9 == 0)) {
                func_0x000180099450(arg1, 0x18063d8d0);
                func_0x000180087960(arg1);
                pcVar5 = (code *)swi(3);
                uVar13 = (*pcVar5)();
                return uVar13;
            }
            var_28h = *(int64_t *)(arg1 + 0x40) + (int64_t)iVar15 * -0x10;
            uStack_20 = 0;
            func_0x000180094080(arg1, 0x180087890, &var_28h, var_28h - *(int64_t *)(arg1 + 0x38), 0);
            if (*(char *)(iVar3 + 0x29) != '\0') {
                (**(code **)0x180782568)(iVar3 + 0x18);
                *(undefined *)(iVar3 + 0x28) = 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18005d860
// Address: 0x18005d860
// Size: 82 bytes
// ============================================================
undefined8 fcn.18005d860(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    
    piVar3 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar3 + 0xc) == 9) && (iVar1 = *piVar3, *(char *)(iVar1 + 3) == 'z')) &&
       (iVar1 != -0x10)) {
        (**(code **)0x180782568)(iVar1 + 0x18);
        return 0;
    }
    fcn.1800883d0(arg1, 1, 0x180624778);
    pcVar2 = (code *)swi(3);
    uVar4 = (*pcVar2)();
    return uVar4;
}

// ============================================================
// Function: FUN_18005d8c0
// Address: 0x18005d8c0
// Size: 138 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18005d8c0(int64_t arg1, int64_t arg_58h)
{
    char cVar1;
    undefined uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t **ppiVar5;
    code *pcVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    undefined8 uVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    int64_t **ppiVar13;
    int64_t **ppiVar14;
    int64_t **ppiVar15;
    int64_t **ppiVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar7 + 0xc) != 9) || (iVar3 = *piVar7, *(char *)(iVar3 + 3) != 'z')) ||
       ((int64_t *)(iVar3 + 0x10) == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624778);
        pcVar6 = (code *)swi(3);
        uVar10 = (*pcVar6)();
        return uVar10;
    }
    piVar7 = *(int64_t **)(*(int64_t *)(iVar3 + 0x10) + 8);
    if (piVar7 != (int64_t *)0x0) {
        piVar4 = *(int64_t **)(iVar3 + 0x18);
        while (piVar7 != piVar4) {
            piVar7 = (int64_t *)piVar7[2];
            if (piVar7 == (int64_t *)0x0) {
                return 0;
            }
        }
        if ((piVar4[4] == 0) &&
           (var_8h = (int64_t)piVar4, piVar7 = (int64_t *)fcn.18005fff0(piVar7, &var_8h), *piVar7 != 0)) {
            var_8h = (int64_t)piVar4;
            piVar7 = (int64_t *)fcn.18005fff0();
            piVar4[4] = *piVar7;
            ppiVar11 = (int64_t **)(*(int64_t ***)0x1807826e0)[1];
            cVar1 = *(char *)((int64_t)ppiVar11 + 0x19);
            ppiVar8 = ppiVar11;
            ppiVar14 = *(int64_t ***)0x1807826e0;
            ppiVar16 = *(int64_t ***)0x1807826e0;
            while (ppiVar12 = ppiVar8, cVar1 == '\0') {
                if (ppiVar12[4] < piVar4) {
                    ppiVar8 = (int64_t **)ppiVar12[2];
                    ppiVar12 = ppiVar14;
                } else {
                    if ((*(char *)((int64_t)ppiVar16 + 0x19) != '\0') && (piVar4 < ppiVar12[4])) {
                        ppiVar16 = ppiVar12;
                    }
                    ppiVar8 = (int64_t **)*ppiVar12;
                }
                cVar1 = *(char *)((int64_t)ppiVar8 + 0x19);
                ppiVar14 = ppiVar12;
            }
            if (*(char *)((int64_t)ppiVar16 + 0x19) == '\0') {
                ppiVar11 = (int64_t **)*ppiVar16;
            }
            cVar1 = *(char *)((int64_t)ppiVar11 + 0x19);
            while (cVar1 == '\0') {
                if (piVar4 < ppiVar11[4]) {
                    ppiVar8 = (int64_t **)*ppiVar11;
                    ppiVar16 = ppiVar11;
                } else {
                    ppiVar8 = (int64_t **)ppiVar11[2];
                }
                ppiVar11 = ppiVar8;
                cVar1 = *(char *)((int64_t)ppiVar8 + 0x19);
            }
            if ((ppiVar14 == (int64_t **)**(int64_t ***)0x1807826e0) && (*(char *)((int64_t)ppiVar16 + 0x19) != '\0')) {
                fcn.18005ff80();
            } else {
                while (ppiVar14 != ppiVar16) {
                    ppiVar8 = (int64_t **)ppiVar14[2];
                    ppiVar11 = ppiVar14 + 2;
                    if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                        ppiVar12 = ppiVar8;
                        ppiVar9 = (int64_t **)*ppiVar8;
                        while (cVar1 == '\0') {
                            cVar1 = *(char *)((int64_t)*ppiVar9 + 0x19);
                            ppiVar12 = ppiVar9;
                            ppiVar9 = (int64_t **)*ppiVar9;
                        }
                        piVar7 = *ppiVar8;
                        ppiVar9 = ppiVar8;
                        if (*(char *)((int64_t)piVar7 + 0x19) == '\0') {
                            do {
                                piVar7 = (int64_t *)*piVar7;
                            } while (*(char *)((int64_t)piVar7 + 0x19) == '\0');
                            ppiVar5 = (int64_t **)*ppiVar8;
                            do {
                                ppiVar9 = ppiVar5;
                                ppiVar5 = (int64_t **)*ppiVar9;
                            } while (*(char *)((int64_t)*ppiVar9 + 0x19) == '\0');
                        }
                    } else {
                        cVar1 = *(char *)((int64_t)ppiVar14[1] + 0x19);
                        ppiVar5 = (int64_t **)ppiVar14[1];
                        ppiVar9 = ppiVar14;
                        while ((ppiVar12 = ppiVar5, cVar1 == '\0' && (ppiVar9 == (int64_t **)ppiVar12[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar12[1] + 0x19);
                            ppiVar5 = (int64_t **)ppiVar12[1];
                            ppiVar9 = ppiVar12;
                        }
                        ppiVar9 = (int64_t **)ppiVar14[1];
                        cVar1 = *(char *)((int64_t)ppiVar9 + 0x19);
                        ppiVar5 = ppiVar14;
                        while ((ppiVar15 = ppiVar9, cVar1 == '\0' && (ppiVar5 == (int64_t **)ppiVar15[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar15[1] + 0x19);
                            ppiVar9 = (int64_t **)ppiVar15[1];
                            ppiVar5 = ppiVar15;
                        }
                        ppiVar5 = (int64_t **)ppiVar14[1];
                        cVar1 = *(char *)((int64_t)ppiVar5 + 0x19);
                        ppiVar15 = ppiVar14;
                        while ((ppiVar9 = ppiVar5, cVar1 == '\0' && (ppiVar15 == (int64_t **)ppiVar9[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar9[1] + 0x19);
                            ppiVar5 = (int64_t **)ppiVar9[1];
                            ppiVar15 = ppiVar9;
                        }
                    }
                    ppiVar13 = ppiVar14 + 1;
                    ppiVar5 = (int64_t **)*ppiVar14;
                    ppiVar15 = ppiVar8;
                    if (((*(char *)((int64_t)ppiVar5 + 0x19) == '\0') &&
                        (ppiVar15 = ppiVar5, *(char *)((int64_t)ppiVar8 + 0x19) == '\0')) &&
                       (ppiVar15 = (int64_t **)ppiVar9[2], ppiVar9 != ppiVar14)) {
                        ppiVar5[1] = (int64_t *)ppiVar9;
                        *ppiVar9 = *ppiVar14;
                        ppiVar8 = ppiVar9;
                        if (ppiVar9 != (int64_t **)*ppiVar11) {
                            ppiVar8 = (int64_t **)ppiVar9[1];
                            if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                                ppiVar15[1] = (int64_t *)ppiVar8;
                            }
                            *ppiVar8 = (int64_t *)ppiVar15;
                            ppiVar9[2] = *ppiVar11;
                            (*ppiVar11)[1] = (int64_t)ppiVar9;
                        }
                        if ((int64_t **)(*(int64_t ***)0x1807826e0)[1] == ppiVar14) {
                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar9;
                        } else {
                            ppiVar11 = (int64_t **)*ppiVar13;
                            if ((int64_t **)*ppiVar11 == ppiVar14) {
                                *ppiVar11 = (int64_t *)ppiVar9;
                            } else {
                                ppiVar11[2] = (int64_t *)ppiVar9;
                            }
                        }
                        uVar2 = *(undefined *)(ppiVar9 + 3);
                        ppiVar9[1] = *ppiVar13;
                        *(undefined *)(ppiVar9 + 3) = *(undefined *)(ppiVar14 + 3);
                        *(undefined *)(ppiVar14 + 3) = uVar2;
                    } else {
                        ppiVar8 = (int64_t **)*ppiVar13;
                        if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                            ppiVar15[1] = (int64_t *)ppiVar8;
                        }
                        if ((int64_t **)(*(int64_t ***)0x1807826e0)[1] == ppiVar14) {
                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar15;
                        } else if ((int64_t **)*ppiVar8 == ppiVar14) {
                            *ppiVar8 = (int64_t *)ppiVar15;
                        } else {
                            ppiVar8[2] = (int64_t *)ppiVar15;
                        }
                        if ((int64_t **)**(int64_t ***)0x1807826e0 == ppiVar14) {
                            ppiVar11 = ppiVar8;
                            if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                                cVar1 = *(char *)((int64_t)*ppiVar15 + 0x19);
                                ppiVar9 = (int64_t **)*ppiVar15;
                                ppiVar11 = ppiVar15;
                                while (ppiVar5 = ppiVar9, cVar1 == '\0') {
                                    ppiVar9 = (int64_t **)*ppiVar5;
                                    cVar1 = *(char *)((int64_t)ppiVar9 + 0x19);
                                    ppiVar11 = ppiVar5;
                                }
                            }
                            **(int64_t ***)0x1807826e0 = (int64_t *)ppiVar11;
                        }
                        if ((int64_t **)(*(int64_t ***)0x1807826e0)[2] == ppiVar14) {
                            if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                                cVar1 = *(char *)((int64_t)ppiVar15[2] + 0x19);
                                ppiVar11 = ppiVar15;
                                while (cVar1 == '\0') {
                                    ppiVar11 = (int64_t **)ppiVar11[2];
                                    cVar1 = *(char *)((int64_t)ppiVar11[2] + 0x19);
                                }
                                (*(int64_t ***)0x1807826e0)[2] = (int64_t *)ppiVar11;
                            } else {
                                (*(int64_t ***)0x1807826e0)[2] = (int64_t *)ppiVar8;
                            }
                        }
                    }
                    if (*(char *)(ppiVar14 + 3) == '\x01') {
                        if (ppiVar15 != (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                            do {
                                ppiVar11 = ppiVar8;
                                if (*(char *)(ppiVar15 + 3) != '\x01') break;
                                ppiVar8 = (int64_t **)*ppiVar11;
                                if (ppiVar15 == ppiVar8) {
                                    ppiVar8 = (int64_t **)ppiVar11[2];
                                    ppiVar9 = ppiVar11 + 3;
                                    if (*(char *)(ppiVar8 + 3) == '\0') {
                                        *(undefined *)(ppiVar8 + 3) = 1;
                                        ppiVar5 = (int64_t **)ppiVar11[2];
                                        *(undefined *)ppiVar9 = 0;
                                        ppiVar11[2] = *ppiVar5;
                                        if (*(char *)((int64_t)*ppiVar5 + 0x19) == '\0') {
                                            (*ppiVar5)[1] = (int64_t)ppiVar11;
                                        }
                                        ppiVar5[1] = ppiVar11[1];
                                        if (ppiVar11 == (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar5;
                                        } else {
                                            ppiVar8 = (int64_t **)ppiVar11[1];
                                            if (ppiVar11 == (int64_t **)*ppiVar8) {
                                                *ppiVar8 = (int64_t *)ppiVar5;
                                            } else {
                                                ppiVar8[2] = (int64_t *)ppiVar5;
                                            }
                                        }
                                        *ppiVar5 = (int64_t *)ppiVar11;
                                        ppiVar8 = (int64_t **)ppiVar11[2];
                                        ppiVar11[1] = (int64_t *)ppiVar5;
                                    }
                                    if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                                        if ((*(char *)(*ppiVar8 + 3) != '\x01') || (*(char *)(ppiVar8[2] + 3) != '\x01')
                                           ) {
                                            if (*(char *)(ppiVar8[2] + 3) == '\x01') {
                                                *(undefined *)(*ppiVar8 + 3) = 1;
                                                *(undefined *)(ppiVar8 + 3) = 0;
                                                fcn.180060390(0x1807826e0);
                                                ppiVar8 = (int64_t **)ppiVar11[2];
                                            }
                                            *(undefined *)(ppiVar8 + 3) = *(undefined *)ppiVar9;
                                            *(undefined *)ppiVar9 = 1;
                                            *(undefined *)(ppiVar8[2] + 3) = 1;
                                            fcn.1800603f0(0x1807826e0, ppiVar11);
                                            break;
                                        }
code_r0x00018005ddb6:
                                        *(undefined *)(ppiVar8 + 3) = 0;
                                    }
                                } else {
                                    ppiVar9 = ppiVar11 + 3;
                                    if (*(char *)(ppiVar8 + 3) == '\0') {
                                        *(undefined *)(ppiVar8 + 3) = 1;
                                        piVar7 = *ppiVar11;
                                        *(undefined *)ppiVar9 = 0;
                                        *ppiVar11 = (int64_t *)piVar7[2];
                                        if (*(char *)(piVar7[2] + 0x19) == '\0') {
                                            *(int64_t ***)(piVar7[2] + 8) = ppiVar11;
                                        }
                                        piVar7[1] = (int64_t)ppiVar11[1];
                                        if (ppiVar11 == (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                                            (*(int64_t ***)0x1807826e0)[1] = piVar7;
                                        } else {
                                            ppiVar8 = (int64_t **)ppiVar11[1];
                                            if (ppiVar11 == (int64_t **)ppiVar8[2]) {
                                                ppiVar8[2] = piVar7;
                                            } else {
                                                *ppiVar8 = piVar7;
                                            }
                                        }
                                        piVar7[2] = (int64_t)ppiVar11;
                                        ppiVar8 = (int64_t **)*ppiVar11;
                                        ppiVar11[1] = piVar7;
                                    }
                                    if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                                        if ((*(char *)(ppiVar8[2] + 3) == '\x01') && (*(char *)(*ppiVar8 + 3) == '\x01')
                                           ) goto code_r0x00018005ddb6;
                                        if (*(char *)(*ppiVar8 + 3) == '\x01') {
                                            *(undefined *)(ppiVar8[2] + 3) = 1;
                                            *(undefined *)(ppiVar8 + 3) = 0;
                                            fcn.1800603f0(0x1807826e0);
                                            ppiVar8 = (int64_t **)*ppiVar11;
                                        }
                                        *(undefined *)(ppiVar8 + 3) = *(undefined *)ppiVar9;
                                        *(undefined *)ppiVar9 = 1;
                                        *(undefined *)(*ppiVar8 + 3) = 1;
                                        fcn.180060390(0x1807826e0, ppiVar11);
                                        break;
                                    }
                                }
                                ppiVar8 = (int64_t **)ppiVar11[1];
                                ppiVar15 = ppiVar11;
                            } while (ppiVar11 != (int64_t **)(*(int64_t ***)0x1807826e0)[1]);
                        }
                        *(undefined *)(ppiVar15 + 3) = 1;
                    }
                    if (*(int64_t *)0x1807826e8 != 0) {
                        *(int64_t *)0x1807826e8 = *(int64_t *)0x1807826e8 + -1;
                    }
                    fcn.180459c3c(ppiVar14, 0x30);
                    ppiVar14 = ppiVar12;
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18005d94a
// Address: 0x18005d94a
// Size: 189 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18005d8c0(int64_t arg1, int64_t arg_58h)
{
    char cVar1;
    undefined uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t **ppiVar5;
    code *pcVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    undefined8 uVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    int64_t **ppiVar13;
    int64_t **ppiVar14;
    int64_t **ppiVar15;
    int64_t **ppiVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar7 + 0xc) != 9) || (iVar3 = *piVar7, *(char *)(iVar3 + 3) != 'z')) ||
       ((int64_t *)(iVar3 + 0x10) == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624778);
        pcVar6 = (code *)swi(3);
        uVar10 = (*pcVar6)();
        return uVar10;
    }
    piVar7 = *(int64_t **)(*(int64_t *)(iVar3 + 0x10) + 8);
    if (piVar7 != (int64_t *)0x0) {
        piVar4 = *(int64_t **)(iVar3 + 0x18);
        while (piVar7 != piVar4) {
            piVar7 = (int64_t *)piVar7[2];
            if (piVar7 == (int64_t *)0x0) {
                return 0;
            }
        }
        if ((piVar4[4] == 0) &&
           (var_8h = (int64_t)piVar4, piVar7 = (int64_t *)fcn.18005fff0(piVar7, &var_8h), *piVar7 != 0)) {
            var_8h = (int64_t)piVar4;
            piVar7 = (int64_t *)fcn.18005fff0();
            piVar4[4] = *piVar7;
            ppiVar11 = (int64_t **)(*(int64_t ***)0x1807826e0)[1];
            cVar1 = *(char *)((int64_t)ppiVar11 + 0x19);
            ppiVar8 = ppiVar11;
            ppiVar14 = *(int64_t ***)0x1807826e0;
            ppiVar16 = *(int64_t ***)0x1807826e0;
            while (ppiVar12 = ppiVar8, cVar1 == '\0') {
                if (ppiVar12[4] < piVar4) {
                    ppiVar8 = (int64_t **)ppiVar12[2];
                    ppiVar12 = ppiVar14;
                } else {
                    if ((*(char *)((int64_t)ppiVar16 + 0x19) != '\0') && (piVar4 < ppiVar12[4])) {
                        ppiVar16 = ppiVar12;
                    }
                    ppiVar8 = (int64_t **)*ppiVar12;
                }
                cVar1 = *(char *)((int64_t)ppiVar8 + 0x19);
                ppiVar14 = ppiVar12;
            }
            if (*(char *)((int64_t)ppiVar16 + 0x19) == '\0') {
                ppiVar11 = (int64_t **)*ppiVar16;
            }
            cVar1 = *(char *)((int64_t)ppiVar11 + 0x19);
            while (cVar1 == '\0') {
                if (piVar4 < ppiVar11[4]) {
                    ppiVar8 = (int64_t **)*ppiVar11;
                    ppiVar16 = ppiVar11;
                } else {
                    ppiVar8 = (int64_t **)ppiVar11[2];
                }
                ppiVar11 = ppiVar8;
                cVar1 = *(char *)((int64_t)ppiVar8 + 0x19);
            }
            if ((ppiVar14 == (int64_t **)**(int64_t ***)0x1807826e0) && (*(char *)((int64_t)ppiVar16 + 0x19) != '\0')) {
                fcn.18005ff80();
            } else {
                while (ppiVar14 != ppiVar16) {
                    ppiVar8 = (int64_t **)ppiVar14[2];
                    ppiVar11 = ppiVar14 + 2;
                    if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                        ppiVar12 = ppiVar8;
                        ppiVar9 = (int64_t **)*ppiVar8;
                        while (cVar1 == '\0') {
                            cVar1 = *(char *)((int64_t)*ppiVar9 + 0x19);
                            ppiVar12 = ppiVar9;
                            ppiVar9 = (int64_t **)*ppiVar9;
                        }
                        piVar7 = *ppiVar8;
                        ppiVar9 = ppiVar8;
                        if (*(char *)((int64_t)piVar7 + 0x19) == '\0') {
                            do {
                                piVar7 = (int64_t *)*piVar7;
                            } while (*(char *)((int64_t)piVar7 + 0x19) == '\0');
                            ppiVar5 = (int64_t **)*ppiVar8;
                            do {
                                ppiVar9 = ppiVar5;
                                ppiVar5 = (int64_t **)*ppiVar9;
                            } while (*(char *)((int64_t)*ppiVar9 + 0x19) == '\0');
                        }
                    } else {
                        cVar1 = *(char *)((int64_t)ppiVar14[1] + 0x19);
                        ppiVar5 = (int64_t **)ppiVar14[1];
                        ppiVar9 = ppiVar14;
                        while ((ppiVar12 = ppiVar5, cVar1 == '\0' && (ppiVar9 == (int64_t **)ppiVar12[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar12[1] + 0x19);
                            ppiVar5 = (int64_t **)ppiVar12[1];
                            ppiVar9 = ppiVar12;
                        }
                        ppiVar9 = (int64_t **)ppiVar14[1];
                        cVar1 = *(char *)((int64_t)ppiVar9 + 0x19);
                        ppiVar5 = ppiVar14;
                        while ((ppiVar15 = ppiVar9, cVar1 == '\0' && (ppiVar5 == (int64_t **)ppiVar15[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar15[1] + 0x19);
                            ppiVar9 = (int64_t **)ppiVar15[1];
                            ppiVar5 = ppiVar15;
                        }
                        ppiVar5 = (int64_t **)ppiVar14[1];
                        cVar1 = *(char *)((int64_t)ppiVar5 + 0x19);
                        ppiVar15 = ppiVar14;
                        while ((ppiVar9 = ppiVar5, cVar1 == '\0' && (ppiVar15 == (int64_t **)ppiVar9[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar9[1] + 0x19);
                            ppiVar5 = (int64_t **)ppiVar9[1];
                            ppiVar15 = ppiVar9;
                        }
                    }
                    ppiVar13 = ppiVar14 + 1;
                    ppiVar5 = (int64_t **)*ppiVar14;
                    ppiVar15 = ppiVar8;
                    if (((*(char *)((int64_t)ppiVar5 + 0x19) == '\0') &&
                        (ppiVar15 = ppiVar5, *(char *)((int64_t)ppiVar8 + 0x19) == '\0')) &&
                       (ppiVar15 = (int64_t **)ppiVar9[2], ppiVar9 != ppiVar14)) {
                        ppiVar5[1] = (int64_t *)ppiVar9;
                        *ppiVar9 = *ppiVar14;
                        ppiVar8 = ppiVar9;
                        if (ppiVar9 != (int64_t **)*ppiVar11) {
                            ppiVar8 = (int64_t **)ppiVar9[1];
                            if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                                ppiVar15[1] = (int64_t *)ppiVar8;
                            }
                            *ppiVar8 = (int64_t *)ppiVar15;
                            ppiVar9[2] = *ppiVar11;
                            (*ppiVar11)[1] = (int64_t)ppiVar9;
                        }
                        if ((int64_t **)(*(int64_t ***)0x1807826e0)[1] == ppiVar14) {
                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar9;
                        } else {
                            ppiVar11 = (int64_t **)*ppiVar13;
                            if ((int64_t **)*ppiVar11 == ppiVar14) {
                                *ppiVar11 = (int64_t *)ppiVar9;
                            } else {
                                ppiVar11[2] = (int64_t *)ppiVar9;
                            }
                        }
                        uVar2 = *(undefined *)(ppiVar9 + 3);
                        ppiVar9[1] = *ppiVar13;
                        *(undefined *)(ppiVar9 + 3) = *(undefined *)(ppiVar14 + 3);
                        *(undefined *)(ppiVar14 + 3) = uVar2;
                    } else {
                        ppiVar8 = (int64_t **)*ppiVar13;
                        if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                            ppiVar15[1] = (int64_t *)ppiVar8;
                        }
                        if ((int64_t **)(*(int64_t ***)0x1807826e0)[1] == ppiVar14) {
                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar15;
                        } else if ((int64_t **)*ppiVar8 == ppiVar14) {
                            *ppiVar8 = (int64_t *)ppiVar15;
                        } else {
                            ppiVar8[2] = (int64_t *)ppiVar15;
                        }
                        if ((int64_t **)**(int64_t ***)0x1807826e0 == ppiVar14) {
                            ppiVar11 = ppiVar8;
                            if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                                cVar1 = *(char *)((int64_t)*ppiVar15 + 0x19);
                                ppiVar9 = (int64_t **)*ppiVar15;
                                ppiVar11 = ppiVar15;
                                while (ppiVar5 = ppiVar9, cVar1 == '\0') {
                                    ppiVar9 = (int64_t **)*ppiVar5;
                                    cVar1 = *(char *)((int64_t)ppiVar9 + 0x19);
                                    ppiVar11 = ppiVar5;
                                }
                            }
                            **(int64_t ***)0x1807826e0 = (int64_t *)ppiVar11;
                        }
                        if ((int64_t **)(*(int64_t ***)0x1807826e0)[2] == ppiVar14) {
                            if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                                cVar1 = *(char *)((int64_t)ppiVar15[2] + 0x19);
                                ppiVar11 = ppiVar15;
                                while (cVar1 == '\0') {
                                    ppiVar11 = (int64_t **)ppiVar11[2];
                                    cVar1 = *(char *)((int64_t)ppiVar11[2] + 0x19);
                                }
                                (*(int64_t ***)0x1807826e0)[2] = (int64_t *)ppiVar11;
                            } else {
                                (*(int64_t ***)0x1807826e0)[2] = (int64_t *)ppiVar8;
                            }
                        }
                    }
                    if (*(char *)(ppiVar14 + 3) == '\x01') {
                        if (ppiVar15 != (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                            do {
                                ppiVar11 = ppiVar8;
                                if (*(char *)(ppiVar15 + 3) != '\x01') break;
                                ppiVar8 = (int64_t **)*ppiVar11;
                                if (ppiVar15 == ppiVar8) {
                                    ppiVar8 = (int64_t **)ppiVar11[2];
                                    ppiVar9 = ppiVar11 + 3;
                                    if (*(char *)(ppiVar8 + 3) == '\0') {
                                        *(undefined *)(ppiVar8 + 3) = 1;
                                        ppiVar5 = (int64_t **)ppiVar11[2];
                                        *(undefined *)ppiVar9 = 0;
                                        ppiVar11[2] = *ppiVar5;
                                        if (*(char *)((int64_t)*ppiVar5 + 0x19) == '\0') {
                                            (*ppiVar5)[1] = (int64_t)ppiVar11;
                                        }
                                        ppiVar5[1] = ppiVar11[1];
                                        if (ppiVar11 == (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar5;
                                        } else {
                                            ppiVar8 = (int64_t **)ppiVar11[1];
                                            if (ppiVar11 == (int64_t **)*ppiVar8) {
                                                *ppiVar8 = (int64_t *)ppiVar5;
                                            } else {
                                                ppiVar8[2] = (int64_t *)ppiVar5;
                                            }
                                        }
                                        *ppiVar5 = (int64_t *)ppiVar11;
                                        ppiVar8 = (int64_t **)ppiVar11[2];
                                        ppiVar11[1] = (int64_t *)ppiVar5;
                                    }
                                    if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                                        if ((*(char *)(*ppiVar8 + 3) != '\x01') || (*(char *)(ppiVar8[2] + 3) != '\x01')
                                           ) {
                                            if (*(char *)(ppiVar8[2] + 3) == '\x01') {
                                                *(undefined *)(*ppiVar8 + 3) = 1;
                                                *(undefined *)(ppiVar8 + 3) = 0;
                                                fcn.180060390(0x1807826e0);
                                                ppiVar8 = (int64_t **)ppiVar11[2];
                                            }
                                            *(undefined *)(ppiVar8 + 3) = *(undefined *)ppiVar9;
                                            *(undefined *)ppiVar9 = 1;
                                            *(undefined *)(ppiVar8[2] + 3) = 1;
                                            fcn.1800603f0(0x1807826e0, ppiVar11);
                                            break;
                                        }
code_r0x00018005ddb6:
                                        *(undefined *)(ppiVar8 + 3) = 0;
                                    }
                                } else {
                                    ppiVar9 = ppiVar11 + 3;
                                    if (*(char *)(ppiVar8 + 3) == '\0') {
                                        *(undefined *)(ppiVar8 + 3) = 1;
                                        piVar7 = *ppiVar11;
                                        *(undefined *)ppiVar9 = 0;
                                        *ppiVar11 = (int64_t *)piVar7[2];
                                        if (*(char *)(piVar7[2] + 0x19) == '\0') {
                                            *(int64_t ***)(piVar7[2] + 8) = ppiVar11;
                                        }
                                        piVar7[1] = (int64_t)ppiVar11[1];
                                        if (ppiVar11 == (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                                            (*(int64_t ***)0x1807826e0)[1] = piVar7;
                                        } else {
                                            ppiVar8 = (int64_t **)ppiVar11[1];
                                            if (ppiVar11 == (int64_t **)ppiVar8[2]) {
                                                ppiVar8[2] = piVar7;
                                            } else {
                                                *ppiVar8 = piVar7;
                                            }
                                        }
                                        piVar7[2] = (int64_t)ppiVar11;
                                        ppiVar8 = (int64_t **)*ppiVar11;
                                        ppiVar11[1] = piVar7;
                                    }
                                    if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                                        if ((*(char *)(ppiVar8[2] + 3) == '\x01') && (*(char *)(*ppiVar8 + 3) == '\x01')
                                           ) goto code_r0x00018005ddb6;
                                        if (*(char *)(*ppiVar8 + 3) == '\x01') {
                                            *(undefined *)(ppiVar8[2] + 3) = 1;
                                            *(undefined *)(ppiVar8 + 3) = 0;
                                            fcn.1800603f0(0x1807826e0);
                                            ppiVar8 = (int64_t **)*ppiVar11;
                                        }
                                        *(undefined *)(ppiVar8 + 3) = *(undefined *)ppiVar9;
                                        *(undefined *)ppiVar9 = 1;
                                        *(undefined *)(*ppiVar8 + 3) = 1;
                                        fcn.180060390(0x1807826e0, ppiVar11);
                                        break;
                                    }
                                }
                                ppiVar8 = (int64_t **)ppiVar11[1];
                                ppiVar15 = ppiVar11;
                            } while (ppiVar11 != (int64_t **)(*(int64_t ***)0x1807826e0)[1]);
                        }
                        *(undefined *)(ppiVar15 + 3) = 1;
                    }
                    if (*(int64_t *)0x1807826e8 != 0) {
                        *(int64_t *)0x1807826e8 = *(int64_t *)0x1807826e8 + -1;
                    }
                    fcn.180459c3c(ppiVar14, 0x30);
                    ppiVar14 = ppiVar12;
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18005da07
// Address: 0x18005da07
// Size: 1098 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18005d8c0(int64_t arg1, int64_t arg_58h)
{
    char cVar1;
    undefined uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t **ppiVar5;
    code *pcVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    undefined8 uVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    int64_t **ppiVar13;
    int64_t **ppiVar14;
    int64_t **ppiVar15;
    int64_t **ppiVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar7 + 0xc) != 9) || (iVar3 = *piVar7, *(char *)(iVar3 + 3) != 'z')) ||
       ((int64_t *)(iVar3 + 0x10) == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624778);
        pcVar6 = (code *)swi(3);
        uVar10 = (*pcVar6)();
        return uVar10;
    }
    piVar7 = *(int64_t **)(*(int64_t *)(iVar3 + 0x10) + 8);
    if (piVar7 != (int64_t *)0x0) {
        piVar4 = *(int64_t **)(iVar3 + 0x18);
        while (piVar7 != piVar4) {
            piVar7 = (int64_t *)piVar7[2];
            if (piVar7 == (int64_t *)0x0) {
                return 0;
            }
        }
        if ((piVar4[4] == 0) &&
           (var_8h = (int64_t)piVar4, piVar7 = (int64_t *)fcn.18005fff0(piVar7, &var_8h), *piVar7 != 0)) {
            var_8h = (int64_t)piVar4;
            piVar7 = (int64_t *)fcn.18005fff0();
            piVar4[4] = *piVar7;
            ppiVar11 = (int64_t **)(*(int64_t ***)0x1807826e0)[1];
            cVar1 = *(char *)((int64_t)ppiVar11 + 0x19);
            ppiVar8 = ppiVar11;
            ppiVar14 = *(int64_t ***)0x1807826e0;
            ppiVar16 = *(int64_t ***)0x1807826e0;
            while (ppiVar12 = ppiVar8, cVar1 == '\0') {
                if (ppiVar12[4] < piVar4) {
                    ppiVar8 = (int64_t **)ppiVar12[2];
                    ppiVar12 = ppiVar14;
                } else {
                    if ((*(char *)((int64_t)ppiVar16 + 0x19) != '\0') && (piVar4 < ppiVar12[4])) {
                        ppiVar16 = ppiVar12;
                    }
                    ppiVar8 = (int64_t **)*ppiVar12;
                }
                cVar1 = *(char *)((int64_t)ppiVar8 + 0x19);
                ppiVar14 = ppiVar12;
            }
            if (*(char *)((int64_t)ppiVar16 + 0x19) == '\0') {
                ppiVar11 = (int64_t **)*ppiVar16;
            }
            cVar1 = *(char *)((int64_t)ppiVar11 + 0x19);
            while (cVar1 == '\0') {
                if (piVar4 < ppiVar11[4]) {
                    ppiVar8 = (int64_t **)*ppiVar11;
                    ppiVar16 = ppiVar11;
                } else {
                    ppiVar8 = (int64_t **)ppiVar11[2];
                }
                ppiVar11 = ppiVar8;
                cVar1 = *(char *)((int64_t)ppiVar8 + 0x19);
            }
            if ((ppiVar14 == (int64_t **)**(int64_t ***)0x1807826e0) && (*(char *)((int64_t)ppiVar16 + 0x19) != '\0')) {
                fcn.18005ff80();
            } else {
                while (ppiVar14 != ppiVar16) {
                    ppiVar8 = (int64_t **)ppiVar14[2];
                    ppiVar11 = ppiVar14 + 2;
                    if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                        ppiVar12 = ppiVar8;
                        ppiVar9 = (int64_t **)*ppiVar8;
                        while (cVar1 == '\0') {
                            cVar1 = *(char *)((int64_t)*ppiVar9 + 0x19);
                            ppiVar12 = ppiVar9;
                            ppiVar9 = (int64_t **)*ppiVar9;
                        }
                        piVar7 = *ppiVar8;
                        ppiVar9 = ppiVar8;
                        if (*(char *)((int64_t)piVar7 + 0x19) == '\0') {
                            do {
                                piVar7 = (int64_t *)*piVar7;
                            } while (*(char *)((int64_t)piVar7 + 0x19) == '\0');
                            ppiVar5 = (int64_t **)*ppiVar8;
                            do {
                                ppiVar9 = ppiVar5;
                                ppiVar5 = (int64_t **)*ppiVar9;
                            } while (*(char *)((int64_t)*ppiVar9 + 0x19) == '\0');
                        }
                    } else {
                        cVar1 = *(char *)((int64_t)ppiVar14[1] + 0x19);
                        ppiVar5 = (int64_t **)ppiVar14[1];
                        ppiVar9 = ppiVar14;
                        while ((ppiVar12 = ppiVar5, cVar1 == '\0' && (ppiVar9 == (int64_t **)ppiVar12[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar12[1] + 0x19);
                            ppiVar5 = (int64_t **)ppiVar12[1];
                            ppiVar9 = ppiVar12;
                        }
                        ppiVar9 = (int64_t **)ppiVar14[1];
                        cVar1 = *(char *)((int64_t)ppiVar9 + 0x19);
                        ppiVar5 = ppiVar14;
                        while ((ppiVar15 = ppiVar9, cVar1 == '\0' && (ppiVar5 == (int64_t **)ppiVar15[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar15[1] + 0x19);
                            ppiVar9 = (int64_t **)ppiVar15[1];
                            ppiVar5 = ppiVar15;
                        }
                        ppiVar5 = (int64_t **)ppiVar14[1];
                        cVar1 = *(char *)((int64_t)ppiVar5 + 0x19);
                        ppiVar15 = ppiVar14;
                        while ((ppiVar9 = ppiVar5, cVar1 == '\0' && (ppiVar15 == (int64_t **)ppiVar9[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar9[1] + 0x19);
                            ppiVar5 = (int64_t **)ppiVar9[1];
                            ppiVar15 = ppiVar9;
                        }
                    }
                    ppiVar13 = ppiVar14 + 1;
                    ppiVar5 = (int64_t **)*ppiVar14;
                    ppiVar15 = ppiVar8;
                    if (((*(char *)((int64_t)ppiVar5 + 0x19) == '\0') &&
                        (ppiVar15 = ppiVar5, *(char *)((int64_t)ppiVar8 + 0x19) == '\0')) &&
                       (ppiVar15 = (int64_t **)ppiVar9[2], ppiVar9 != ppiVar14)) {
                        ppiVar5[1] = (int64_t *)ppiVar9;
                        *ppiVar9 = *ppiVar14;
                        ppiVar8 = ppiVar9;
                        if (ppiVar9 != (int64_t **)*ppiVar11) {
                            ppiVar8 = (int64_t **)ppiVar9[1];
                            if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                                ppiVar15[1] = (int64_t *)ppiVar8;
                            }
                            *ppiVar8 = (int64_t *)ppiVar15;
                            ppiVar9[2] = *ppiVar11;
                            (*ppiVar11)[1] = (int64_t)ppiVar9;
                        }
                        if ((int64_t **)(*(int64_t ***)0x1807826e0)[1] == ppiVar14) {
                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar9;
                        } else {
                            ppiVar11 = (int64_t **)*ppiVar13;
                            if ((int64_t **)*ppiVar11 == ppiVar14) {
                                *ppiVar11 = (int64_t *)ppiVar9;
                            } else {
                                ppiVar11[2] = (int64_t *)ppiVar9;
                            }
                        }
                        uVar2 = *(undefined *)(ppiVar9 + 3);
                        ppiVar9[1] = *ppiVar13;
                        *(undefined *)(ppiVar9 + 3) = *(undefined *)(ppiVar14 + 3);
                        *(undefined *)(ppiVar14 + 3) = uVar2;
                    } else {
                        ppiVar8 = (int64_t **)*ppiVar13;
                        if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                            ppiVar15[1] = (int64_t *)ppiVar8;
                        }
                        if ((int64_t **)(*(int64_t ***)0x1807826e0)[1] == ppiVar14) {
                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar15;
                        } else if ((int64_t **)*ppiVar8 == ppiVar14) {
                            *ppiVar8 = (int64_t *)ppiVar15;
                        } else {
                            ppiVar8[2] = (int64_t *)ppiVar15;
                        }
                        if ((int64_t **)**(int64_t ***)0x1807826e0 == ppiVar14) {
                            ppiVar11 = ppiVar8;
                            if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                                cVar1 = *(char *)((int64_t)*ppiVar15 + 0x19);
                                ppiVar9 = (int64_t **)*ppiVar15;
                                ppiVar11 = ppiVar15;
                                while (ppiVar5 = ppiVar9, cVar1 == '\0') {
                                    ppiVar9 = (int64_t **)*ppiVar5;
                                    cVar1 = *(char *)((int64_t)ppiVar9 + 0x19);
                                    ppiVar11 = ppiVar5;
                                }
                            }
                            **(int64_t ***)0x1807826e0 = (int64_t *)ppiVar11;
                        }
                        if ((int64_t **)(*(int64_t ***)0x1807826e0)[2] == ppiVar14) {
                            if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                                cVar1 = *(char *)((int64_t)ppiVar15[2] + 0x19);
                                ppiVar11 = ppiVar15;
                                while (cVar1 == '\0') {
                                    ppiVar11 = (int64_t **)ppiVar11[2];
                                    cVar1 = *(char *)((int64_t)ppiVar11[2] + 0x19);
                                }
                                (*(int64_t ***)0x1807826e0)[2] = (int64_t *)ppiVar11;
                            } else {
                                (*(int64_t ***)0x1807826e0)[2] = (int64_t *)ppiVar8;
                            }
                        }
                    }
                    if (*(char *)(ppiVar14 + 3) == '\x01') {
                        if (ppiVar15 != (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                            do {
                                ppiVar11 = ppiVar8;
                                if (*(char *)(ppiVar15 + 3) != '\x01') break;
                                ppiVar8 = (int64_t **)*ppiVar11;
                                if (ppiVar15 == ppiVar8) {
                                    ppiVar8 = (int64_t **)ppiVar11[2];
                                    ppiVar9 = ppiVar11 + 3;
                                    if (*(char *)(ppiVar8 + 3) == '\0') {
                                        *(undefined *)(ppiVar8 + 3) = 1;
                                        ppiVar5 = (int64_t **)ppiVar11[2];
                                        *(undefined *)ppiVar9 = 0;
                                        ppiVar11[2] = *ppiVar5;
                                        if (*(char *)((int64_t)*ppiVar5 + 0x19) == '\0') {
                                            (*ppiVar5)[1] = (int64_t)ppiVar11;
                                        }
                                        ppiVar5[1] = ppiVar11[1];
                                        if (ppiVar11 == (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar5;
                                        } else {
                                            ppiVar8 = (int64_t **)ppiVar11[1];
                                            if (ppiVar11 == (int64_t **)*ppiVar8) {
                                                *ppiVar8 = (int64_t *)ppiVar5;
                                            } else {
                                                ppiVar8[2] = (int64_t *)ppiVar5;
                                            }
                                        }
                                        *ppiVar5 = (int64_t *)ppiVar11;
                                        ppiVar8 = (int64_t **)ppiVar11[2];
                                        ppiVar11[1] = (int64_t *)ppiVar5;
                                    }
                                    if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                                        if ((*(char *)(*ppiVar8 + 3) != '\x01') || (*(char *)(ppiVar8[2] + 3) != '\x01')
                                           ) {
                                            if (*(char *)(ppiVar8[2] + 3) == '\x01') {
                                                *(undefined *)(*ppiVar8 + 3) = 1;
                                                *(undefined *)(ppiVar8 + 3) = 0;
                                                fcn.180060390(0x1807826e0);
                                                ppiVar8 = (int64_t **)ppiVar11[2];
                                            }
                                            *(undefined *)(ppiVar8 + 3) = *(undefined *)ppiVar9;
                                            *(undefined *)ppiVar9 = 1;
                                            *(undefined *)(ppiVar8[2] + 3) = 1;
                                            fcn.1800603f0(0x1807826e0, ppiVar11);
                                            break;
                                        }
code_r0x00018005ddb6:
                                        *(undefined *)(ppiVar8 + 3) = 0;
                                    }
                                } else {
                                    ppiVar9 = ppiVar11 + 3;
                                    if (*(char *)(ppiVar8 + 3) == '\0') {
                                        *(undefined *)(ppiVar8 + 3) = 1;
                                        piVar7 = *ppiVar11;
                                        *(undefined *)ppiVar9 = 0;
                                        *ppiVar11 = (int64_t *)piVar7[2];
                                        if (*(char *)(piVar7[2] + 0x19) == '\0') {
                                            *(int64_t ***)(piVar7[2] + 8) = ppiVar11;
                                        }
                                        piVar7[1] = (int64_t)ppiVar11[1];
                                        if (ppiVar11 == (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                                            (*(int64_t ***)0x1807826e0)[1] = piVar7;
                                        } else {
                                            ppiVar8 = (int64_t **)ppiVar11[1];
                                            if (ppiVar11 == (int64_t **)ppiVar8[2]) {
                                                ppiVar8[2] = piVar7;
                                            } else {
                                                *ppiVar8 = piVar7;
                                            }
                                        }
                                        piVar7[2] = (int64_t)ppiVar11;
                                        ppiVar8 = (int64_t **)*ppiVar11;
                                        ppiVar11[1] = piVar7;
                                    }
                                    if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                                        if ((*(char *)(ppiVar8[2] + 3) == '\x01') && (*(char *)(*ppiVar8 + 3) == '\x01')
                                           ) goto code_r0x00018005ddb6;
                                        if (*(char *)(*ppiVar8 + 3) == '\x01') {
                                            *(undefined *)(ppiVar8[2] + 3) = 1;
                                            *(undefined *)(ppiVar8 + 3) = 0;
                                            fcn.1800603f0(0x1807826e0);
                                            ppiVar8 = (int64_t **)*ppiVar11;
                                        }
                                        *(undefined *)(ppiVar8 + 3) = *(undefined *)ppiVar9;
                                        *(undefined *)ppiVar9 = 1;
                                        *(undefined *)(*ppiVar8 + 3) = 1;
                                        fcn.180060390(0x1807826e0, ppiVar11);
                                        break;
                                    }
                                }
                                ppiVar8 = (int64_t **)ppiVar11[1];
                                ppiVar15 = ppiVar11;
                            } while (ppiVar11 != (int64_t **)(*(int64_t ***)0x1807826e0)[1]);
                        }
                        *(undefined *)(ppiVar15 + 3) = 1;
                    }
                    if (*(int64_t *)0x1807826e8 != 0) {
                        *(int64_t *)0x1807826e8 = *(int64_t *)0x1807826e8 + -1;
                    }
                    fcn.180459c3c(ppiVar14, 0x30);
                    ppiVar14 = ppiVar12;
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18005de51
// Address: 0x18005de51
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18005d8c0(int64_t arg1, int64_t arg_58h)
{
    char cVar1;
    undefined uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t **ppiVar5;
    code *pcVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    undefined8 uVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    int64_t **ppiVar13;
    int64_t **ppiVar14;
    int64_t **ppiVar15;
    int64_t **ppiVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar7 + 0xc) != 9) || (iVar3 = *piVar7, *(char *)(iVar3 + 3) != 'z')) ||
       ((int64_t *)(iVar3 + 0x10) == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624778);
        pcVar6 = (code *)swi(3);
        uVar10 = (*pcVar6)();
        return uVar10;
    }
    piVar7 = *(int64_t **)(*(int64_t *)(iVar3 + 0x10) + 8);
    if (piVar7 != (int64_t *)0x0) {
        piVar4 = *(int64_t **)(iVar3 + 0x18);
        while (piVar7 != piVar4) {
            piVar7 = (int64_t *)piVar7[2];
            if (piVar7 == (int64_t *)0x0) {
                return 0;
            }
        }
        if ((piVar4[4] == 0) &&
           (var_8h = (int64_t)piVar4, piVar7 = (int64_t *)fcn.18005fff0(piVar7, &var_8h), *piVar7 != 0)) {
            var_8h = (int64_t)piVar4;
            piVar7 = (int64_t *)fcn.18005fff0();
            piVar4[4] = *piVar7;
            ppiVar11 = (int64_t **)(*(int64_t ***)0x1807826e0)[1];
            cVar1 = *(char *)((int64_t)ppiVar11 + 0x19);
            ppiVar8 = ppiVar11;
            ppiVar14 = *(int64_t ***)0x1807826e0;
            ppiVar16 = *(int64_t ***)0x1807826e0;
            while (ppiVar12 = ppiVar8, cVar1 == '\0') {
                if (ppiVar12[4] < piVar4) {
                    ppiVar8 = (int64_t **)ppiVar12[2];
                    ppiVar12 = ppiVar14;
                } else {
                    if ((*(char *)((int64_t)ppiVar16 + 0x19) != '\0') && (piVar4 < ppiVar12[4])) {
                        ppiVar16 = ppiVar12;
                    }
                    ppiVar8 = (int64_t **)*ppiVar12;
                }
                cVar1 = *(char *)((int64_t)ppiVar8 + 0x19);
                ppiVar14 = ppiVar12;
            }
            if (*(char *)((int64_t)ppiVar16 + 0x19) == '\0') {
                ppiVar11 = (int64_t **)*ppiVar16;
            }
            cVar1 = *(char *)((int64_t)ppiVar11 + 0x19);
            while (cVar1 == '\0') {
                if (piVar4 < ppiVar11[4]) {
                    ppiVar8 = (int64_t **)*ppiVar11;
                    ppiVar16 = ppiVar11;
                } else {
                    ppiVar8 = (int64_t **)ppiVar11[2];
                }
                ppiVar11 = ppiVar8;
                cVar1 = *(char *)((int64_t)ppiVar8 + 0x19);
            }
            if ((ppiVar14 == (int64_t **)**(int64_t ***)0x1807826e0) && (*(char *)((int64_t)ppiVar16 + 0x19) != '\0')) {
                fcn.18005ff80();
            } else {
                while (ppiVar14 != ppiVar16) {
                    ppiVar8 = (int64_t **)ppiVar14[2];
                    ppiVar11 = ppiVar14 + 2;
                    if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                        ppiVar12 = ppiVar8;
                        ppiVar9 = (int64_t **)*ppiVar8;
                        while (cVar1 == '\0') {
                            cVar1 = *(char *)((int64_t)*ppiVar9 + 0x19);
                            ppiVar12 = ppiVar9;
                            ppiVar9 = (int64_t **)*ppiVar9;
                        }
                        piVar7 = *ppiVar8;
                        ppiVar9 = ppiVar8;
                        if (*(char *)((int64_t)piVar7 + 0x19) == '\0') {
                            do {
                                piVar7 = (int64_t *)*piVar7;
                            } while (*(char *)((int64_t)piVar7 + 0x19) == '\0');
                            ppiVar5 = (int64_t **)*ppiVar8;
                            do {
                                ppiVar9 = ppiVar5;
                                ppiVar5 = (int64_t **)*ppiVar9;
                            } while (*(char *)((int64_t)*ppiVar9 + 0x19) == '\0');
                        }
                    } else {
                        cVar1 = *(char *)((int64_t)ppiVar14[1] + 0x19);
                        ppiVar5 = (int64_t **)ppiVar14[1];
                        ppiVar9 = ppiVar14;
                        while ((ppiVar12 = ppiVar5, cVar1 == '\0' && (ppiVar9 == (int64_t **)ppiVar12[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar12[1] + 0x19);
                            ppiVar5 = (int64_t **)ppiVar12[1];
                            ppiVar9 = ppiVar12;
                        }
                        ppiVar9 = (int64_t **)ppiVar14[1];
                        cVar1 = *(char *)((int64_t)ppiVar9 + 0x19);
                        ppiVar5 = ppiVar14;
                        while ((ppiVar15 = ppiVar9, cVar1 == '\0' && (ppiVar5 == (int64_t **)ppiVar15[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar15[1] + 0x19);
                            ppiVar9 = (int64_t **)ppiVar15[1];
                            ppiVar5 = ppiVar15;
                        }
                        ppiVar5 = (int64_t **)ppiVar14[1];
                        cVar1 = *(char *)((int64_t)ppiVar5 + 0x19);
                        ppiVar15 = ppiVar14;
                        while ((ppiVar9 = ppiVar5, cVar1 == '\0' && (ppiVar15 == (int64_t **)ppiVar9[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar9[1] + 0x19);
                            ppiVar5 = (int64_t **)ppiVar9[1];
                            ppiVar15 = ppiVar9;
                        }
                    }
                    ppiVar13 = ppiVar14 + 1;
                    ppiVar5 = (int64_t **)*ppiVar14;
                    ppiVar15 = ppiVar8;
                    if (((*(char *)((int64_t)ppiVar5 + 0x19) == '\0') &&
                        (ppiVar15 = ppiVar5, *(char *)((int64_t)ppiVar8 + 0x19) == '\0')) &&
                       (ppiVar15 = (int64_t **)ppiVar9[2], ppiVar9 != ppiVar14)) {
                        ppiVar5[1] = (int64_t *)ppiVar9;
                        *ppiVar9 = *ppiVar14;
                        ppiVar8 = ppiVar9;
                        if (ppiVar9 != (int64_t **)*ppiVar11) {
                            ppiVar8 = (int64_t **)ppiVar9[1];
                            if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                                ppiVar15[1] = (int64_t *)ppiVar8;
                            }
                            *ppiVar8 = (int64_t *)ppiVar15;
                            ppiVar9[2] = *ppiVar11;
                            (*ppiVar11)[1] = (int64_t)ppiVar9;
                        }
                        if ((int64_t **)(*(int64_t ***)0x1807826e0)[1] == ppiVar14) {
                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar9;
                        } else {
                            ppiVar11 = (int64_t **)*ppiVar13;
                            if ((int64_t **)*ppiVar11 == ppiVar14) {
                                *ppiVar11 = (int64_t *)ppiVar9;
                            } else {
                                ppiVar11[2] = (int64_t *)ppiVar9;
                            }
                        }
                        uVar2 = *(undefined *)(ppiVar9 + 3);
                        ppiVar9[1] = *ppiVar13;
                        *(undefined *)(ppiVar9 + 3) = *(undefined *)(ppiVar14 + 3);
                        *(undefined *)(ppiVar14 + 3) = uVar2;
                    } else {
                        ppiVar8 = (int64_t **)*ppiVar13;
                        if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                            ppiVar15[1] = (int64_t *)ppiVar8;
                        }
                        if ((int64_t **)(*(int64_t ***)0x1807826e0)[1] == ppiVar14) {
                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar15;
                        } else if ((int64_t **)*ppiVar8 == ppiVar14) {
                            *ppiVar8 = (int64_t *)ppiVar15;
                        } else {
                            ppiVar8[2] = (int64_t *)ppiVar15;
                        }
                        if ((int64_t **)**(int64_t ***)0x1807826e0 == ppiVar14) {
                            ppiVar11 = ppiVar8;
                            if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                                cVar1 = *(char *)((int64_t)*ppiVar15 + 0x19);
                                ppiVar9 = (int64_t **)*ppiVar15;
                                ppiVar11 = ppiVar15;
                                while (ppiVar5 = ppiVar9, cVar1 == '\0') {
                                    ppiVar9 = (int64_t **)*ppiVar5;
                                    cVar1 = *(char *)((int64_t)ppiVar9 + 0x19);
                                    ppiVar11 = ppiVar5;
                                }
                            }
                            **(int64_t ***)0x1807826e0 = (int64_t *)ppiVar11;
                        }
                        if ((int64_t **)(*(int64_t ***)0x1807826e0)[2] == ppiVar14) {
                            if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                                cVar1 = *(char *)((int64_t)ppiVar15[2] + 0x19);
                                ppiVar11 = ppiVar15;
                                while (cVar1 == '\0') {
                                    ppiVar11 = (int64_t **)ppiVar11[2];
                                    cVar1 = *(char *)((int64_t)ppiVar11[2] + 0x19);
                                }
                                (*(int64_t ***)0x1807826e0)[2] = (int64_t *)ppiVar11;
                            } else {
                                (*(int64_t ***)0x1807826e0)[2] = (int64_t *)ppiVar8;
                            }
                        }
                    }
                    if (*(char *)(ppiVar14 + 3) == '\x01') {
                        if (ppiVar15 != (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                            do {
                                ppiVar11 = ppiVar8;
                                if (*(char *)(ppiVar15 + 3) != '\x01') break;
                                ppiVar8 = (int64_t **)*ppiVar11;
                                if (ppiVar15 == ppiVar8) {
                                    ppiVar8 = (int64_t **)ppiVar11[2];
                                    ppiVar9 = ppiVar11 + 3;
                                    if (*(char *)(ppiVar8 + 3) == '\0') {
                                        *(undefined *)(ppiVar8 + 3) = 1;
                                        ppiVar5 = (int64_t **)ppiVar11[2];
                                        *(undefined *)ppiVar9 = 0;
                                        ppiVar11[2] = *ppiVar5;
                                        if (*(char *)((int64_t)*ppiVar5 + 0x19) == '\0') {
                                            (*ppiVar5)[1] = (int64_t)ppiVar11;
                                        }
                                        ppiVar5[1] = ppiVar11[1];
                                        if (ppiVar11 == (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar5;
                                        } else {
                                            ppiVar8 = (int64_t **)ppiVar11[1];
                                            if (ppiVar11 == (int64_t **)*ppiVar8) {
                                                *ppiVar8 = (int64_t *)ppiVar5;
                                            } else {
                                                ppiVar8[2] = (int64_t *)ppiVar5;
                                            }
                                        }
                                        *ppiVar5 = (int64_t *)ppiVar11;
                                        ppiVar8 = (int64_t **)ppiVar11[2];
                                        ppiVar11[1] = (int64_t *)ppiVar5;
                                    }
                                    if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                                        if ((*(char *)(*ppiVar8 + 3) != '\x01') || (*(char *)(ppiVar8[2] + 3) != '\x01')
                                           ) {
                                            if (*(char *)(ppiVar8[2] + 3) == '\x01') {
                                                *(undefined *)(*ppiVar8 + 3) = 1;
                                                *(undefined *)(ppiVar8 + 3) = 0;
                                                fcn.180060390(0x1807826e0);
                                                ppiVar8 = (int64_t **)ppiVar11[2];
                                            }
                                            *(undefined *)(ppiVar8 + 3) = *(undefined *)ppiVar9;
                                            *(undefined *)ppiVar9 = 1;
                                            *(undefined *)(ppiVar8[2] + 3) = 1;
                                            fcn.1800603f0(0x1807826e0, ppiVar11);
                                            break;
                                        }
code_r0x00018005ddb6:
                                        *(undefined *)(ppiVar8 + 3) = 0;
                                    }
                                } else {
                                    ppiVar9 = ppiVar11 + 3;
                                    if (*(char *)(ppiVar8 + 3) == '\0') {
                                        *(undefined *)(ppiVar8 + 3) = 1;
                                        piVar7 = *ppiVar11;
                                        *(undefined *)ppiVar9 = 0;
                                        *ppiVar11 = (int64_t *)piVar7[2];
                                        if (*(char *)(piVar7[2] + 0x19) == '\0') {
                                            *(int64_t ***)(piVar7[2] + 8) = ppiVar11;
                                        }
                                        piVar7[1] = (int64_t)ppiVar11[1];
                                        if (ppiVar11 == (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                                            (*(int64_t ***)0x1807826e0)[1] = piVar7;
                                        } else {
                                            ppiVar8 = (int64_t **)ppiVar11[1];
                                            if (ppiVar11 == (int64_t **)ppiVar8[2]) {
                                                ppiVar8[2] = piVar7;
                                            } else {
                                                *ppiVar8 = piVar7;
                                            }
                                        }
                                        piVar7[2] = (int64_t)ppiVar11;
                                        ppiVar8 = (int64_t **)*ppiVar11;
                                        ppiVar11[1] = piVar7;
                                    }
                                    if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                                        if ((*(char *)(ppiVar8[2] + 3) == '\x01') && (*(char *)(*ppiVar8 + 3) == '\x01')
                                           ) goto code_r0x00018005ddb6;
                                        if (*(char *)(*ppiVar8 + 3) == '\x01') {
                                            *(undefined *)(ppiVar8[2] + 3) = 1;
                                            *(undefined *)(ppiVar8 + 3) = 0;
                                            fcn.1800603f0(0x1807826e0);
                                            ppiVar8 = (int64_t **)*ppiVar11;
                                        }
                                        *(undefined *)(ppiVar8 + 3) = *(undefined *)ppiVar9;
                                        *(undefined *)ppiVar9 = 1;
                                        *(undefined *)(*ppiVar8 + 3) = 1;
                                        fcn.180060390(0x1807826e0, ppiVar11);
                                        break;
                                    }
                                }
                                ppiVar8 = (int64_t **)ppiVar11[1];
                                ppiVar15 = ppiVar11;
                            } while (ppiVar11 != (int64_t **)(*(int64_t ***)0x1807826e0)[1]);
                        }
                        *(undefined *)(ppiVar15 + 3) = 1;
                    }
                    if (*(int64_t *)0x1807826e8 != 0) {
                        *(int64_t *)0x1807826e8 = *(int64_t *)0x1807826e8 + -1;
                    }
                    fcn.180459c3c(ppiVar14, 0x30);
                    ppiVar14 = ppiVar12;
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18005de60
// Address: 0x18005de60
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18005d8c0(int64_t arg1, int64_t arg_58h)
{
    char cVar1;
    undefined uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t **ppiVar5;
    code *pcVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    undefined8 uVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    int64_t **ppiVar13;
    int64_t **ppiVar14;
    int64_t **ppiVar15;
    int64_t **ppiVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar7 + 0xc) != 9) || (iVar3 = *piVar7, *(char *)(iVar3 + 3) != 'z')) ||
       ((int64_t *)(iVar3 + 0x10) == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624778);
        pcVar6 = (code *)swi(3);
        uVar10 = (*pcVar6)();
        return uVar10;
    }
    piVar7 = *(int64_t **)(*(int64_t *)(iVar3 + 0x10) + 8);
    if (piVar7 != (int64_t *)0x0) {
        piVar4 = *(int64_t **)(iVar3 + 0x18);
        while (piVar7 != piVar4) {
            piVar7 = (int64_t *)piVar7[2];
            if (piVar7 == (int64_t *)0x0) {
                return 0;
            }
        }
        if ((piVar4[4] == 0) &&
           (var_8h = (int64_t)piVar4, piVar7 = (int64_t *)fcn.18005fff0(piVar7, &var_8h), *piVar7 != 0)) {
            var_8h = (int64_t)piVar4;
            piVar7 = (int64_t *)fcn.18005fff0();
            piVar4[4] = *piVar7;
            ppiVar11 = (int64_t **)(*(int64_t ***)0x1807826e0)[1];
            cVar1 = *(char *)((int64_t)ppiVar11 + 0x19);
            ppiVar8 = ppiVar11;
            ppiVar14 = *(int64_t ***)0x1807826e0;
            ppiVar16 = *(int64_t ***)0x1807826e0;
            while (ppiVar12 = ppiVar8, cVar1 == '\0') {
                if (ppiVar12[4] < piVar4) {
                    ppiVar8 = (int64_t **)ppiVar12[2];
                    ppiVar12 = ppiVar14;
                } else {
                    if ((*(char *)((int64_t)ppiVar16 + 0x19) != '\0') && (piVar4 < ppiVar12[4])) {
                        ppiVar16 = ppiVar12;
                    }
                    ppiVar8 = (int64_t **)*ppiVar12;
                }
                cVar1 = *(char *)((int64_t)ppiVar8 + 0x19);
                ppiVar14 = ppiVar12;
            }
            if (*(char *)((int64_t)ppiVar16 + 0x19) == '\0') {
                ppiVar11 = (int64_t **)*ppiVar16;
            }
            cVar1 = *(char *)((int64_t)ppiVar11 + 0x19);
            while (cVar1 == '\0') {
                if (piVar4 < ppiVar11[4]) {
                    ppiVar8 = (int64_t **)*ppiVar11;
                    ppiVar16 = ppiVar11;
                } else {
                    ppiVar8 = (int64_t **)ppiVar11[2];
                }
                ppiVar11 = ppiVar8;
                cVar1 = *(char *)((int64_t)ppiVar8 + 0x19);
            }
            if ((ppiVar14 == (int64_t **)**(int64_t ***)0x1807826e0) && (*(char *)((int64_t)ppiVar16 + 0x19) != '\0')) {
                fcn.18005ff80();
            } else {
                while (ppiVar14 != ppiVar16) {
                    ppiVar8 = (int64_t **)ppiVar14[2];
                    ppiVar11 = ppiVar14 + 2;
                    if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar8 + 0x19);
                        ppiVar12 = ppiVar8;
                        ppiVar9 = (int64_t **)*ppiVar8;
                        while (cVar1 == '\0') {
                            cVar1 = *(char *)((int64_t)*ppiVar9 + 0x19);
                            ppiVar12 = ppiVar9;
                            ppiVar9 = (int64_t **)*ppiVar9;
                        }
                        piVar7 = *ppiVar8;
                        ppiVar9 = ppiVar8;
                        if (*(char *)((int64_t)piVar7 + 0x19) == '\0') {
                            do {
                                piVar7 = (int64_t *)*piVar7;
                            } while (*(char *)((int64_t)piVar7 + 0x19) == '\0');
                            ppiVar5 = (int64_t **)*ppiVar8;
                            do {
                                ppiVar9 = ppiVar5;
                                ppiVar5 = (int64_t **)*ppiVar9;
                            } while (*(char *)((int64_t)*ppiVar9 + 0x19) == '\0');
                        }
                    } else {
                        cVar1 = *(char *)((int64_t)ppiVar14[1] + 0x19);
                        ppiVar5 = (int64_t **)ppiVar14[1];
                        ppiVar9 = ppiVar14;
                        while ((ppiVar12 = ppiVar5, cVar1 == '\0' && (ppiVar9 == (int64_t **)ppiVar12[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar12[1] + 0x19);
                            ppiVar5 = (int64_t **)ppiVar12[1];
                            ppiVar9 = ppiVar12;
                        }
                        ppiVar9 = (int64_t **)ppiVar14[1];
                        cVar1 = *(char *)((int64_t)ppiVar9 + 0x19);
                        ppiVar5 = ppiVar14;
                        while ((ppiVar15 = ppiVar9, cVar1 == '\0' && (ppiVar5 == (int64_t **)ppiVar15[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar15[1] + 0x19);
                            ppiVar9 = (int64_t **)ppiVar15[1];
                            ppiVar5 = ppiVar15;
                        }
                        ppiVar5 = (int64_t **)ppiVar14[1];
                        cVar1 = *(char *)((int64_t)ppiVar5 + 0x19);
                        ppiVar15 = ppiVar14;
                        while ((ppiVar9 = ppiVar5, cVar1 == '\0' && (ppiVar15 == (int64_t **)ppiVar9[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar9[1] + 0x19);
                            ppiVar5 = (int64_t **)ppiVar9[1];
                            ppiVar15 = ppiVar9;
                        }
                    }
                    ppiVar13 = ppiVar14 + 1;
                    ppiVar5 = (int64_t **)*ppiVar14;
                    ppiVar15 = ppiVar8;
                    if (((*(char *)((int64_t)ppiVar5 + 0x19) == '\0') &&
                        (ppiVar15 = ppiVar5, *(char *)((int64_t)ppiVar8 + 0x19) == '\0')) &&
                       (ppiVar15 = (int64_t **)ppiVar9[2], ppiVar9 != ppiVar14)) {
                        ppiVar5[1] = (int64_t *)ppiVar9;
                        *ppiVar9 = *ppiVar14;
                        ppiVar8 = ppiVar9;
                        if (ppiVar9 != (int64_t **)*ppiVar11) {
                            ppiVar8 = (int64_t **)ppiVar9[1];
                            if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                                ppiVar15[1] = (int64_t *)ppiVar8;
                            }
                            *ppiVar8 = (int64_t *)ppiVar15;
                            ppiVar9[2] = *ppiVar11;
                            (*ppiVar11)[1] = (int64_t)ppiVar9;
                        }
                        if ((int64_t **)(*(int64_t ***)0x1807826e0)[1] == ppiVar14) {
                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar9;
                        } else {
                            ppiVar11 = (int64_t **)*ppiVar13;
                            if ((int64_t **)*ppiVar11 == ppiVar14) {
                                *ppiVar11 = (int64_t *)ppiVar9;
                            } else {
                                ppiVar11[2] = (int64_t *)ppiVar9;
                            }
                        }
                        uVar2 = *(undefined *)(ppiVar9 + 3);
                        ppiVar9[1] = *ppiVar13;
                        *(undefined *)(ppiVar9 + 3) = *(undefined *)(ppiVar14 + 3);
                        *(undefined *)(ppiVar14 + 3) = uVar2;
                    } else {
                        ppiVar8 = (int64_t **)*ppiVar13;
                        if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                            ppiVar15[1] = (int64_t *)ppiVar8;
                        }
                        if ((int64_t **)(*(int64_t ***)0x1807826e0)[1] == ppiVar14) {
                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar15;
                        } else if ((int64_t **)*ppiVar8 == ppiVar14) {
                            *ppiVar8 = (int64_t *)ppiVar15;
                        } else {
                            ppiVar8[2] = (int64_t *)ppiVar15;
                        }
                        if ((int64_t **)**(int64_t ***)0x1807826e0 == ppiVar14) {
                            ppiVar11 = ppiVar8;
                            if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                                cVar1 = *(char *)((int64_t)*ppiVar15 + 0x19);
                                ppiVar9 = (int64_t **)*ppiVar15;
                                ppiVar11 = ppiVar15;
                                while (ppiVar5 = ppiVar9, cVar1 == '\0') {
                                    ppiVar9 = (int64_t **)*ppiVar5;
                                    cVar1 = *(char *)((int64_t)ppiVar9 + 0x19);
                                    ppiVar11 = ppiVar5;
                                }
                            }
                            **(int64_t ***)0x1807826e0 = (int64_t *)ppiVar11;
                        }
                        if ((int64_t **)(*(int64_t ***)0x1807826e0)[2] == ppiVar14) {
                            if (*(char *)((int64_t)ppiVar15 + 0x19) == '\0') {
                                cVar1 = *(char *)((int64_t)ppiVar15[2] + 0x19);
                                ppiVar11 = ppiVar15;
                                while (cVar1 == '\0') {
                                    ppiVar11 = (int64_t **)ppiVar11[2];
                                    cVar1 = *(char *)((int64_t)ppiVar11[2] + 0x19);
                                }
                                (*(int64_t ***)0x1807826e0)[2] = (int64_t *)ppiVar11;
                            } else {
                                (*(int64_t ***)0x1807826e0)[2] = (int64_t *)ppiVar8;
                            }
                        }
                    }
                    if (*(char *)(ppiVar14 + 3) == '\x01') {
                        if (ppiVar15 != (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                            do {
                                ppiVar11 = ppiVar8;
                                if (*(char *)(ppiVar15 + 3) != '\x01') break;
                                ppiVar8 = (int64_t **)*ppiVar11;
                                if (ppiVar15 == ppiVar8) {
                                    ppiVar8 = (int64_t **)ppiVar11[2];
                                    ppiVar9 = ppiVar11 + 3;
                                    if (*(char *)(ppiVar8 + 3) == '\0') {
                                        *(undefined *)(ppiVar8 + 3) = 1;
                                        ppiVar5 = (int64_t **)ppiVar11[2];
                                        *(undefined *)ppiVar9 = 0;
                                        ppiVar11[2] = *ppiVar5;
                                        if (*(char *)((int64_t)*ppiVar5 + 0x19) == '\0') {
                                            (*ppiVar5)[1] = (int64_t)ppiVar11;
                                        }
                                        ppiVar5[1] = ppiVar11[1];
                                        if (ppiVar11 == (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar5;
                                        } else {
                                            ppiVar8 = (int64_t **)ppiVar11[1];
                                            if (ppiVar11 == (int64_t **)*ppiVar8) {
                                                *ppiVar8 = (int64_t *)ppiVar5;
                                            } else {
                                                ppiVar8[2] = (int64_t *)ppiVar5;
                                            }
                                        }
                                        *ppiVar5 = (int64_t *)ppiVar11;
                                        ppiVar8 = (int64_t **)ppiVar11[2];
                                        ppiVar11[1] = (int64_t *)ppiVar5;
                                    }
                                    if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                                        if ((*(char *)(*ppiVar8 + 3) != '\x01') || (*(char *)(ppiVar8[2] + 3) != '\x01')
                                           ) {
                                            if (*(char *)(ppiVar8[2] + 3) == '\x01') {
                                                *(undefined *)(*ppiVar8 + 3) = 1;
                                                *(undefined *)(ppiVar8 + 3) = 0;
                                                fcn.180060390(0x1807826e0);
                                                ppiVar8 = (int64_t **)ppiVar11[2];
                                            }
                                            *(undefined *)(ppiVar8 + 3) = *(undefined *)ppiVar9;
                                            *(undefined *)ppiVar9 = 1;
                                            *(undefined *)(ppiVar8[2] + 3) = 1;
                                            fcn.1800603f0(0x1807826e0, ppiVar11);
                                            break;
                                        }
code_r0x00018005ddb6:
                                        *(undefined *)(ppiVar8 + 3) = 0;
                                    }
                                } else {
                                    ppiVar9 = ppiVar11 + 3;
                                    if (*(char *)(ppiVar8 + 3) == '\0') {
                                        *(undefined *)(ppiVar8 + 3) = 1;
                                        piVar7 = *ppiVar11;
                                        *(undefined *)ppiVar9 = 0;
                                        *ppiVar11 = (int64_t *)piVar7[2];
                                        if (*(char *)(piVar7[2] + 0x19) == '\0') {
                                            *(int64_t ***)(piVar7[2] + 8) = ppiVar11;
                                        }
                                        piVar7[1] = (int64_t)ppiVar11[1];
                                        if (ppiVar11 == (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                                            (*(int64_t ***)0x1807826e0)[1] = piVar7;
                                        } else {
                                            ppiVar8 = (int64_t **)ppiVar11[1];
                                            if (ppiVar11 == (int64_t **)ppiVar8[2]) {
                                                ppiVar8[2] = piVar7;
                                            } else {
                                                *ppiVar8 = piVar7;
                                            }
                                        }
                                        piVar7[2] = (int64_t)ppiVar11;
                                        ppiVar8 = (int64_t **)*ppiVar11;
                                        ppiVar11[1] = piVar7;
                                    }
                                    if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
                                        if ((*(char *)(ppiVar8[2] + 3) == '\x01') && (*(char *)(*ppiVar8 + 3) == '\x01')
                                           ) goto code_r0x00018005ddb6;
                                        if (*(char *)(*ppiVar8 + 3) == '\x01') {
                                            *(undefined *)(ppiVar8[2] + 3) = 1;
                                            *(undefined *)(ppiVar8 + 3) = 0;
                                            fcn.1800603f0(0x1807826e0);
                                            ppiVar8 = (int64_t **)*ppiVar11;
                                        }
                                        *(undefined *)(ppiVar8 + 3) = *(undefined *)ppiVar9;
                                        *(undefined *)ppiVar9 = 1;
                                        *(undefined *)(*ppiVar8 + 3) = 1;
                                        fcn.180060390(0x1807826e0, ppiVar11);
                                        break;
                                    }
                                }
                                ppiVar8 = (int64_t **)ppiVar11[1];
                                ppiVar15 = ppiVar11;
                            } while (ppiVar11 != (int64_t **)(*(int64_t ***)0x1807826e0)[1]);
                        }
                        *(undefined *)(ppiVar15 + 3) = 1;
                    }
                    if (*(int64_t *)0x1807826e8 != 0) {
                        *(int64_t *)0x1807826e8 = *(int64_t *)0x1807826e8 + -1;
                    }
                    fcn.180459c3c(ppiVar14, 0x30);
                    ppiVar14 = ppiVar12;
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18005de80
// Address: 0x18005de80
// Size: 107 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18005de80(int64_t arg1, int64_t arg_40h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t *piVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar3 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar3 + 0xc) == 9) && (iVar1 = *piVar3, *(char *)(iVar1 + 3) == 'z')) &&
       ((int64_t *)(iVar1 + 0x10) != (int64_t *)0x0)) {
        iVar6 = *(int64_t *)(*(int64_t *)(iVar1 + 0x10) + 8);
        if (iVar6 != 0) {
            iVar1 = *(int64_t *)(iVar1 + 0x18);
            while (iVar6 != iVar1) {
                iVar6 = *(int64_t *)(iVar6 + 0x10);
                if (iVar6 == 0) {
                    return 0;
                }
            }
            var_8h = iVar1;
            piVar3 = (int64_t *)fcn.18005fff0(iVar6, &var_8h);
            if (*piVar3 == 0) {
                uVar5 = *(undefined8 *)(iVar1 + 0x20);
                var_8h = iVar1;
                puVar4 = (undefined8 *)fcn.18005fff0();
                *puVar4 = uVar5;
            }
            *(undefined8 *)(iVar1 + 0x20) = 0;
        }
        return 0;
    }
    fcn.1800883d0(arg1, 1, 0x180624778);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_18005deeb
// Address: 0x18005deeb
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18005de80(int64_t arg1, int64_t arg_40h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t *piVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar3 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar3 + 0xc) == 9) && (iVar1 = *piVar3, *(char *)(iVar1 + 3) == 'z')) &&
       ((int64_t *)(iVar1 + 0x10) != (int64_t *)0x0)) {
        iVar6 = *(int64_t *)(*(int64_t *)(iVar1 + 0x10) + 8);
        if (iVar6 != 0) {
            iVar1 = *(int64_t *)(iVar1 + 0x18);
            while (iVar6 != iVar1) {
                iVar6 = *(int64_t *)(iVar6 + 0x10);
                if (iVar6 == 0) {
                    return 0;
                }
            }
            var_8h = iVar1;
            piVar3 = (int64_t *)fcn.18005fff0(iVar6, &var_8h);
            if (*piVar3 == 0) {
                uVar5 = *(undefined8 *)(iVar1 + 0x20);
                var_8h = iVar1;
                puVar4 = (undefined8 *)fcn.18005fff0();
                *puVar4 = uVar5;
            }
            *(undefined8 *)(iVar1 + 0x20) = 0;
        }
        return 0;
    }
    fcn.1800883d0(arg1, 1, 0x180624778);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_18005df0b
// Address: 0x18005df0b
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18005de80(int64_t arg1, int64_t arg_40h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t *piVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar3 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar3 + 0xc) == 9) && (iVar1 = *piVar3, *(char *)(iVar1 + 3) == 'z')) &&
       ((int64_t *)(iVar1 + 0x10) != (int64_t *)0x0)) {
        iVar6 = *(int64_t *)(*(int64_t *)(iVar1 + 0x10) + 8);
        if (iVar6 != 0) {
            iVar1 = *(int64_t *)(iVar1 + 0x18);
            while (iVar6 != iVar1) {
                iVar6 = *(int64_t *)(iVar6 + 0x10);
                if (iVar6 == 0) {
                    return 0;
                }
            }
            var_8h = iVar1;
            piVar3 = (int64_t *)fcn.18005fff0(iVar6, &var_8h);
            if (*piVar3 == 0) {
                uVar5 = *(undefined8 *)(iVar1 + 0x20);
                var_8h = iVar1;
                puVar4 = (undefined8 *)fcn.18005fff0();
                *puVar4 = uVar5;
            }
            *(undefined8 *)(iVar1 + 0x20) = 0;
        }
        return 0;
    }
    fcn.1800883d0(arg1, 1, 0x180624778);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_18005df30
// Address: 0x18005df30
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_3h
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

undefined8 fcn.18005df30(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined4 *puVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    int64_t iVar14;
    code *pcVar15;
    int64_t *piVar16;
    bool bVar17;
    undefined4 uVar18;
    int64_t var_3h;
    int64_t var_ch;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar16 = *(int64_t **)(arg1 + 0x28);
    piVar13 = piVar16;
    if (*(int64_t **)(arg1 + 0x40) <= piVar16) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar13 + 0xc) != 9) || (iVar1 = *piVar13, *(char *)(iVar1 + 3) != 'z')) ||
       ((int64_t *)(iVar1 + 0x10) == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624778);
        pcVar15 = (code *)swi(3);
        uVar11 = (*pcVar15)();
        return uVar11;
    }
    piVar13 = piVar16 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar16 + 2) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar13 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar7 = func_0x0001800a8360(arg1);
        if (iVar7 == 0) goto code_r0x00018005e359;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
            piVar13 = *(int64_t **)0x180782430;
        }
    }
    piVar16 = *(int64_t **)0x180782430;
    iVar14 = *piVar13 + 0x18;
    if (iVar14 == 0) {
code_r0x00018005e359:
        func_0x000180088470(arg1, 2, 6);
        pcVar15 = (code *)swi(3);
        uVar11 = (*pcVar15)();
        return uVar11;
    }
    piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    piVar12 = piVar13;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) ||
       ((*(int32_t *)((int64_t)piVar12 + 0xc) != 6 && (*(int32_t *)((int64_t)piVar12 + 0xc) != 3)))) {
code_r0x00018005e050:
        iVar7 = 0;
    } else {
        if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
            piVar13 = *(int64_t **)0x180782430;
        }
        if (piVar13 == *(int64_t **)0x180782430) {
            piVar13 = (int64_t *)0x0;
        }
        iVar2 = *piVar13;
        if (iVar2 == 0) goto code_r0x00018005e050;
        iVar7 = (int32_t)iVar2 + *(int32_t *)(iVar2 + 0x10) + 0x10;
    }
    bVar17 = false;
    if (*(char *)(iVar1 + 0x28) != '\0') {
        return 0;
    }
    if (iVar7 == -0x24d4b210) {
        iVar14 = *(int64_t *)(*(int64_t *)(iVar1 + 0x10) + 8);
        if (iVar14 != 0) {
            do {
                if (iVar14 == *(int64_t *)(iVar1 + 0x18)) {
                    func_0x000180086b20(arg1, *(int64_t *)(*(int64_t *)(iVar1 + 0x18) + 0x20) != 0);
                    return 1;
                }
                iVar14 = *(int64_t *)(iVar14 + 0x10);
            } while (iVar14 != 0);
            func_0x000180086b20(arg1, 0);
            return 1;
        }
code_r0x00018005e10a:
        func_0x000180086b20(arg1, bVar17);
        return 1;
    }
    if (iVar7 == 0xdff80c0) {
        if (*(int64_t *)(iVar1 + 0x20) != 0) {
            func_0x000180086b20(arg1, *(int64_t *)(arg1 + 0x20) != *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x20));
            return 1;
        }
        func_0x000180086b20(arg1, 1);
        return 1;
    }
    if (iVar7 == -0x629bd323) {
        bVar17 = *(int64_t *)(iVar1 + 0x20) != 0;
        goto code_r0x00018005e10a;
    }
    if (iVar7 == 0x7c9f9488) {
        if (*(int32_t *)(iVar1 + 0x30) == 0) {
code_r0x00018005e26f:
            func_0x000180086510(arg1);
            return 1;
        }
        func_0x000180086ed0(arg1, 0xffffd8f0);
        uVar3 = *(uint64_t *)(arg1 + 0x40);
        if (((int64_t *)(uVar3 - 0x10) != *(int64_t **)0x180782430) && (*(int32_t *)(uVar3 - 4) == 8)) {
            return 1;
        }
        *(int64_t **)(arg1 + 0x40) = (int64_t *)(uVar3 - 0x10);
        if ((*(char *)0x180777010 == '\0') || (uVar3 <= **(uint64_t **)(arg1 + 0x18))) goto code_r0x00018005e181;
        iVar7 = func_0x000180085510(arg1, 1);
    } else {
        if (iVar7 != 0x70d04107) {
            if (iVar7 == 0x70e5dd) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d440;
            } else if (iVar7 == 0x12319c08) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d5f0;
            } else if (iVar7 == -0x36f161e6) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d860;
            } else if (iVar7 == -0x5fba3fa1) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005de80;
            } else {
                if (iVar7 != 0x4dfafac4) {
                    fcn.180088560(arg1, 0x180624788, iVar14);
                    pcVar15 = (code *)swi(3);
                    uVar11 = (*pcVar15)();
                    return uVar11;
                }
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d8c0;
            }
            func_0x00018001afc0(uVar18, arg1, pcVar15, iVar14);
            return 1;
        }
        iVar7 = *(int32_t *)(iVar1 + 0x2c);
        if (iVar7 == 0) goto code_r0x00018005e26f;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar8 = func_0x000180085510(arg1, 1), piVar16 = *(int64_t **)0x180782430, iVar8 == 0))
        goto code_r0x00018005e32f;
        puVar9 = (undefined8 *)fcn.180085370(arg1, 0xffffd8f0);
        puVar10 = (undefined4 *)func_0x0001800a0d50(*puVar9, iVar7);
        puVar4 = *(undefined4 **)(arg1 + 0x40);
        uVar18 = puVar10[1];
        uVar5 = puVar10[2];
        uVar6 = puVar10[3];
        *puVar4 = *puVar10;
        puVar4[1] = uVar18;
        puVar4[2] = uVar5;
        puVar4[3] = uVar6;
        piVar13 = *(int64_t **)(arg1 + 0x40);
        *(int64_t **)(arg1 + 0x40) = piVar13 + 2;
        if ((piVar13 != piVar16) && (*(int32_t *)((int64_t)piVar13 + 0xc) == 10)) {
            return 1;
        }
        *(int64_t **)(arg1 + 0x40) = piVar13;
        if ((*(char *)0x180777010 == '\0') || (piVar13 + 2 <= **(int64_t ***)(arg1 + 0x18))) goto code_r0x00018005e181;
        iVar7 = func_0x000180085510(arg1, 1);
    }
    if (iVar7 == 0) {
code_r0x00018005e32f:
        func_0x000180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar15 = (code *)swi(3);
        uVar11 = (*pcVar15)();
        return uVar11;
    }
code_r0x00018005e181:
    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_18005df85
// Address: 0x18005df85
// Size: 816 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_3h
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

undefined8 fcn.18005df30(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined4 *puVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    int64_t iVar14;
    code *pcVar15;
    int64_t *piVar16;
    bool bVar17;
    undefined4 uVar18;
    int64_t var_3h;
    int64_t var_ch;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar16 = *(int64_t **)(arg1 + 0x28);
    piVar13 = piVar16;
    if (*(int64_t **)(arg1 + 0x40) <= piVar16) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar13 + 0xc) != 9) || (iVar1 = *piVar13, *(char *)(iVar1 + 3) != 'z')) ||
       ((int64_t *)(iVar1 + 0x10) == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624778);
        pcVar15 = (code *)swi(3);
        uVar11 = (*pcVar15)();
        return uVar11;
    }
    piVar13 = piVar16 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar16 + 2) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar13 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar7 = func_0x0001800a8360(arg1);
        if (iVar7 == 0) goto code_r0x00018005e359;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
            piVar13 = *(int64_t **)0x180782430;
        }
    }
    piVar16 = *(int64_t **)0x180782430;
    iVar14 = *piVar13 + 0x18;
    if (iVar14 == 0) {
code_r0x00018005e359:
        func_0x000180088470(arg1, 2, 6);
        pcVar15 = (code *)swi(3);
        uVar11 = (*pcVar15)();
        return uVar11;
    }
    piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    piVar12 = piVar13;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) ||
       ((*(int32_t *)((int64_t)piVar12 + 0xc) != 6 && (*(int32_t *)((int64_t)piVar12 + 0xc) != 3)))) {
code_r0x00018005e050:
        iVar7 = 0;
    } else {
        if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
            piVar13 = *(int64_t **)0x180782430;
        }
        if (piVar13 == *(int64_t **)0x180782430) {
            piVar13 = (int64_t *)0x0;
        }
        iVar2 = *piVar13;
        if (iVar2 == 0) goto code_r0x00018005e050;
        iVar7 = (int32_t)iVar2 + *(int32_t *)(iVar2 + 0x10) + 0x10;
    }
    bVar17 = false;
    if (*(char *)(iVar1 + 0x28) != '\0') {
        return 0;
    }
    if (iVar7 == -0x24d4b210) {
        iVar14 = *(int64_t *)(*(int64_t *)(iVar1 + 0x10) + 8);
        if (iVar14 != 0) {
            do {
                if (iVar14 == *(int64_t *)(iVar1 + 0x18)) {
                    func_0x000180086b20(arg1, *(int64_t *)(*(int64_t *)(iVar1 + 0x18) + 0x20) != 0);
                    return 1;
                }
                iVar14 = *(int64_t *)(iVar14 + 0x10);
            } while (iVar14 != 0);
            func_0x000180086b20(arg1, 0);
            return 1;
        }
code_r0x00018005e10a:
        func_0x000180086b20(arg1, bVar17);
        return 1;
    }
    if (iVar7 == 0xdff80c0) {
        if (*(int64_t *)(iVar1 + 0x20) != 0) {
            func_0x000180086b20(arg1, *(int64_t *)(arg1 + 0x20) != *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x20));
            return 1;
        }
        func_0x000180086b20(arg1, 1);
        return 1;
    }
    if (iVar7 == -0x629bd323) {
        bVar17 = *(int64_t *)(iVar1 + 0x20) != 0;
        goto code_r0x00018005e10a;
    }
    if (iVar7 == 0x7c9f9488) {
        if (*(int32_t *)(iVar1 + 0x30) == 0) {
code_r0x00018005e26f:
            func_0x000180086510(arg1);
            return 1;
        }
        func_0x000180086ed0(arg1, 0xffffd8f0);
        uVar3 = *(uint64_t *)(arg1 + 0x40);
        if (((int64_t *)(uVar3 - 0x10) != *(int64_t **)0x180782430) && (*(int32_t *)(uVar3 - 4) == 8)) {
            return 1;
        }
        *(int64_t **)(arg1 + 0x40) = (int64_t *)(uVar3 - 0x10);
        if ((*(char *)0x180777010 == '\0') || (uVar3 <= **(uint64_t **)(arg1 + 0x18))) goto code_r0x00018005e181;
        iVar7 = func_0x000180085510(arg1, 1);
    } else {
        if (iVar7 != 0x70d04107) {
            if (iVar7 == 0x70e5dd) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d440;
            } else if (iVar7 == 0x12319c08) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d5f0;
            } else if (iVar7 == -0x36f161e6) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d860;
            } else if (iVar7 == -0x5fba3fa1) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005de80;
            } else {
                if (iVar7 != 0x4dfafac4) {
                    fcn.180088560(arg1, 0x180624788, iVar14);
                    pcVar15 = (code *)swi(3);
                    uVar11 = (*pcVar15)();
                    return uVar11;
                }
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d8c0;
            }
            func_0x00018001afc0(uVar18, arg1, pcVar15, iVar14);
            return 1;
        }
        iVar7 = *(int32_t *)(iVar1 + 0x2c);
        if (iVar7 == 0) goto code_r0x00018005e26f;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar8 = func_0x000180085510(arg1, 1), piVar16 = *(int64_t **)0x180782430, iVar8 == 0))
        goto code_r0x00018005e32f;
        puVar9 = (undefined8 *)fcn.180085370(arg1, 0xffffd8f0);
        puVar10 = (undefined4 *)func_0x0001800a0d50(*puVar9, iVar7);
        puVar4 = *(undefined4 **)(arg1 + 0x40);
        uVar18 = puVar10[1];
        uVar5 = puVar10[2];
        uVar6 = puVar10[3];
        *puVar4 = *puVar10;
        puVar4[1] = uVar18;
        puVar4[2] = uVar5;
        puVar4[3] = uVar6;
        piVar13 = *(int64_t **)(arg1 + 0x40);
        *(int64_t **)(arg1 + 0x40) = piVar13 + 2;
        if ((piVar13 != piVar16) && (*(int32_t *)((int64_t)piVar13 + 0xc) == 10)) {
            return 1;
        }
        *(int64_t **)(arg1 + 0x40) = piVar13;
        if ((*(char *)0x180777010 == '\0') || (piVar13 + 2 <= **(int64_t ***)(arg1 + 0x18))) goto code_r0x00018005e181;
        iVar7 = func_0x000180085510(arg1, 1);
    }
    if (iVar7 == 0) {
code_r0x00018005e32f:
        func_0x000180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar15 = (code *)swi(3);
        uVar11 = (*pcVar15)();
        return uVar11;
    }
code_r0x00018005e181:
    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_18005e2b5
// Address: 0x18005e2b5
// Size: 146 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_3h
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

undefined8 fcn.18005df30(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined4 *puVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    int64_t iVar14;
    code *pcVar15;
    int64_t *piVar16;
    bool bVar17;
    undefined4 uVar18;
    int64_t var_3h;
    int64_t var_ch;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar16 = *(int64_t **)(arg1 + 0x28);
    piVar13 = piVar16;
    if (*(int64_t **)(arg1 + 0x40) <= piVar16) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar13 + 0xc) != 9) || (iVar1 = *piVar13, *(char *)(iVar1 + 3) != 'z')) ||
       ((int64_t *)(iVar1 + 0x10) == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624778);
        pcVar15 = (code *)swi(3);
        uVar11 = (*pcVar15)();
        return uVar11;
    }
    piVar13 = piVar16 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar16 + 2) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar13 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar7 = func_0x0001800a8360(arg1);
        if (iVar7 == 0) goto code_r0x00018005e359;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
            piVar13 = *(int64_t **)0x180782430;
        }
    }
    piVar16 = *(int64_t **)0x180782430;
    iVar14 = *piVar13 + 0x18;
    if (iVar14 == 0) {
code_r0x00018005e359:
        func_0x000180088470(arg1, 2, 6);
        pcVar15 = (code *)swi(3);
        uVar11 = (*pcVar15)();
        return uVar11;
    }
    piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    piVar12 = piVar13;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) ||
       ((*(int32_t *)((int64_t)piVar12 + 0xc) != 6 && (*(int32_t *)((int64_t)piVar12 + 0xc) != 3)))) {
code_r0x00018005e050:
        iVar7 = 0;
    } else {
        if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
            piVar13 = *(int64_t **)0x180782430;
        }
        if (piVar13 == *(int64_t **)0x180782430) {
            piVar13 = (int64_t *)0x0;
        }
        iVar2 = *piVar13;
        if (iVar2 == 0) goto code_r0x00018005e050;
        iVar7 = (int32_t)iVar2 + *(int32_t *)(iVar2 + 0x10) + 0x10;
    }
    bVar17 = false;
    if (*(char *)(iVar1 + 0x28) != '\0') {
        return 0;
    }
    if (iVar7 == -0x24d4b210) {
        iVar14 = *(int64_t *)(*(int64_t *)(iVar1 + 0x10) + 8);
        if (iVar14 != 0) {
            do {
                if (iVar14 == *(int64_t *)(iVar1 + 0x18)) {
                    func_0x000180086b20(arg1, *(int64_t *)(*(int64_t *)(iVar1 + 0x18) + 0x20) != 0);
                    return 1;
                }
                iVar14 = *(int64_t *)(iVar14 + 0x10);
            } while (iVar14 != 0);
            func_0x000180086b20(arg1, 0);
            return 1;
        }
code_r0x00018005e10a:
        func_0x000180086b20(arg1, bVar17);
        return 1;
    }
    if (iVar7 == 0xdff80c0) {
        if (*(int64_t *)(iVar1 + 0x20) != 0) {
            func_0x000180086b20(arg1, *(int64_t *)(arg1 + 0x20) != *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x20));
            return 1;
        }
        func_0x000180086b20(arg1, 1);
        return 1;
    }
    if (iVar7 == -0x629bd323) {
        bVar17 = *(int64_t *)(iVar1 + 0x20) != 0;
        goto code_r0x00018005e10a;
    }
    if (iVar7 == 0x7c9f9488) {
        if (*(int32_t *)(iVar1 + 0x30) == 0) {
code_r0x00018005e26f:
            func_0x000180086510(arg1);
            return 1;
        }
        func_0x000180086ed0(arg1, 0xffffd8f0);
        uVar3 = *(uint64_t *)(arg1 + 0x40);
        if (((int64_t *)(uVar3 - 0x10) != *(int64_t **)0x180782430) && (*(int32_t *)(uVar3 - 4) == 8)) {
            return 1;
        }
        *(int64_t **)(arg1 + 0x40) = (int64_t *)(uVar3 - 0x10);
        if ((*(char *)0x180777010 == '\0') || (uVar3 <= **(uint64_t **)(arg1 + 0x18))) goto code_r0x00018005e181;
        iVar7 = func_0x000180085510(arg1, 1);
    } else {
        if (iVar7 != 0x70d04107) {
            if (iVar7 == 0x70e5dd) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d440;
            } else if (iVar7 == 0x12319c08) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d5f0;
            } else if (iVar7 == -0x36f161e6) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d860;
            } else if (iVar7 == -0x5fba3fa1) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005de80;
            } else {
                if (iVar7 != 0x4dfafac4) {
                    fcn.180088560(arg1, 0x180624788, iVar14);
                    pcVar15 = (code *)swi(3);
                    uVar11 = (*pcVar15)();
                    return uVar11;
                }
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d8c0;
            }
            func_0x00018001afc0(uVar18, arg1, pcVar15, iVar14);
            return 1;
        }
        iVar7 = *(int32_t *)(iVar1 + 0x2c);
        if (iVar7 == 0) goto code_r0x00018005e26f;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar8 = func_0x000180085510(arg1, 1), piVar16 = *(int64_t **)0x180782430, iVar8 == 0))
        goto code_r0x00018005e32f;
        puVar9 = (undefined8 *)fcn.180085370(arg1, 0xffffd8f0);
        puVar10 = (undefined4 *)func_0x0001800a0d50(*puVar9, iVar7);
        puVar4 = *(undefined4 **)(arg1 + 0x40);
        uVar18 = puVar10[1];
        uVar5 = puVar10[2];
        uVar6 = puVar10[3];
        *puVar4 = *puVar10;
        puVar4[1] = uVar18;
        puVar4[2] = uVar5;
        puVar4[3] = uVar6;
        piVar13 = *(int64_t **)(arg1 + 0x40);
        *(int64_t **)(arg1 + 0x40) = piVar13 + 2;
        if ((piVar13 != piVar16) && (*(int32_t *)((int64_t)piVar13 + 0xc) == 10)) {
            return 1;
        }
        *(int64_t **)(arg1 + 0x40) = piVar13;
        if ((*(char *)0x180777010 == '\0') || (piVar13 + 2 <= **(int64_t ***)(arg1 + 0x18))) goto code_r0x00018005e181;
        iVar7 = func_0x000180085510(arg1, 1);
    }
    if (iVar7 == 0) {
code_r0x00018005e32f:
        func_0x000180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar15 = (code *)swi(3);
        uVar11 = (*pcVar15)();
        return uVar11;
    }
code_r0x00018005e181:
    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_18005e347
// Address: 0x18005e347
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_3h
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

undefined8 fcn.18005df30(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined4 *puVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    int64_t iVar14;
    code *pcVar15;
    int64_t *piVar16;
    bool bVar17;
    undefined4 uVar18;
    int64_t var_3h;
    int64_t var_ch;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar16 = *(int64_t **)(arg1 + 0x28);
    piVar13 = piVar16;
    if (*(int64_t **)(arg1 + 0x40) <= piVar16) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar13 + 0xc) != 9) || (iVar1 = *piVar13, *(char *)(iVar1 + 3) != 'z')) ||
       ((int64_t *)(iVar1 + 0x10) == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624778);
        pcVar15 = (code *)swi(3);
        uVar11 = (*pcVar15)();
        return uVar11;
    }
    piVar13 = piVar16 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar16 + 2) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar13 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar7 = func_0x0001800a8360(arg1);
        if (iVar7 == 0) goto code_r0x00018005e359;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
            piVar13 = *(int64_t **)0x180782430;
        }
    }
    piVar16 = *(int64_t **)0x180782430;
    iVar14 = *piVar13 + 0x18;
    if (iVar14 == 0) {
code_r0x00018005e359:
        func_0x000180088470(arg1, 2, 6);
        pcVar15 = (code *)swi(3);
        uVar11 = (*pcVar15)();
        return uVar11;
    }
    piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    piVar12 = piVar13;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) ||
       ((*(int32_t *)((int64_t)piVar12 + 0xc) != 6 && (*(int32_t *)((int64_t)piVar12 + 0xc) != 3)))) {
code_r0x00018005e050:
        iVar7 = 0;
    } else {
        if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
            piVar13 = *(int64_t **)0x180782430;
        }
        if (piVar13 == *(int64_t **)0x180782430) {
            piVar13 = (int64_t *)0x0;
        }
        iVar2 = *piVar13;
        if (iVar2 == 0) goto code_r0x00018005e050;
        iVar7 = (int32_t)iVar2 + *(int32_t *)(iVar2 + 0x10) + 0x10;
    }
    bVar17 = false;
    if (*(char *)(iVar1 + 0x28) != '\0') {
        return 0;
    }
    if (iVar7 == -0x24d4b210) {
        iVar14 = *(int64_t *)(*(int64_t *)(iVar1 + 0x10) + 8);
        if (iVar14 != 0) {
            do {
                if (iVar14 == *(int64_t *)(iVar1 + 0x18)) {
                    func_0x000180086b20(arg1, *(int64_t *)(*(int64_t *)(iVar1 + 0x18) + 0x20) != 0);
                    return 1;
                }
                iVar14 = *(int64_t *)(iVar14 + 0x10);
            } while (iVar14 != 0);
            func_0x000180086b20(arg1, 0);
            return 1;
        }
code_r0x00018005e10a:
        func_0x000180086b20(arg1, bVar17);
        return 1;
    }
    if (iVar7 == 0xdff80c0) {
        if (*(int64_t *)(iVar1 + 0x20) != 0) {
            func_0x000180086b20(arg1, *(int64_t *)(arg1 + 0x20) != *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x20));
            return 1;
        }
        func_0x000180086b20(arg1, 1);
        return 1;
    }
    if (iVar7 == -0x629bd323) {
        bVar17 = *(int64_t *)(iVar1 + 0x20) != 0;
        goto code_r0x00018005e10a;
    }
    if (iVar7 == 0x7c9f9488) {
        if (*(int32_t *)(iVar1 + 0x30) == 0) {
code_r0x00018005e26f:
            func_0x000180086510(arg1);
            return 1;
        }
        func_0x000180086ed0(arg1, 0xffffd8f0);
        uVar3 = *(uint64_t *)(arg1 + 0x40);
        if (((int64_t *)(uVar3 - 0x10) != *(int64_t **)0x180782430) && (*(int32_t *)(uVar3 - 4) == 8)) {
            return 1;
        }
        *(int64_t **)(arg1 + 0x40) = (int64_t *)(uVar3 - 0x10);
        if ((*(char *)0x180777010 == '\0') || (uVar3 <= **(uint64_t **)(arg1 + 0x18))) goto code_r0x00018005e181;
        iVar7 = func_0x000180085510(arg1, 1);
    } else {
        if (iVar7 != 0x70d04107) {
            if (iVar7 == 0x70e5dd) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d440;
            } else if (iVar7 == 0x12319c08) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d5f0;
            } else if (iVar7 == -0x36f161e6) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d860;
            } else if (iVar7 == -0x5fba3fa1) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005de80;
            } else {
                if (iVar7 != 0x4dfafac4) {
                    fcn.180088560(arg1, 0x180624788, iVar14);
                    pcVar15 = (code *)swi(3);
                    uVar11 = (*pcVar15)();
                    return uVar11;
                }
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d8c0;
            }
            func_0x00018001afc0(uVar18, arg1, pcVar15, iVar14);
            return 1;
        }
        iVar7 = *(int32_t *)(iVar1 + 0x2c);
        if (iVar7 == 0) goto code_r0x00018005e26f;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar8 = func_0x000180085510(arg1, 1), piVar16 = *(int64_t **)0x180782430, iVar8 == 0))
        goto code_r0x00018005e32f;
        puVar9 = (undefined8 *)fcn.180085370(arg1, 0xffffd8f0);
        puVar10 = (undefined4 *)func_0x0001800a0d50(*puVar9, iVar7);
        puVar4 = *(undefined4 **)(arg1 + 0x40);
        uVar18 = puVar10[1];
        uVar5 = puVar10[2];
        uVar6 = puVar10[3];
        *puVar4 = *puVar10;
        puVar4[1] = uVar18;
        puVar4[2] = uVar5;
        puVar4[3] = uVar6;
        piVar13 = *(int64_t **)(arg1 + 0x40);
        *(int64_t **)(arg1 + 0x40) = piVar13 + 2;
        if ((piVar13 != piVar16) && (*(int32_t *)((int64_t)piVar13 + 0xc) == 10)) {
            return 1;
        }
        *(int64_t **)(arg1 + 0x40) = piVar13;
        if ((*(char *)0x180777010 == '\0') || (piVar13 + 2 <= **(int64_t ***)(arg1 + 0x18))) goto code_r0x00018005e181;
        iVar7 = func_0x000180085510(arg1, 1);
    }
    if (iVar7 == 0) {
code_r0x00018005e32f:
        func_0x000180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar15 = (code *)swi(3);
        uVar11 = (*pcVar15)();
        return uVar11;
    }
code_r0x00018005e181:
    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_18005e359
// Address: 0x18005e359
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_3h
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

undefined8 fcn.18005df30(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined4 *puVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    int64_t iVar14;
    code *pcVar15;
    int64_t *piVar16;
    bool bVar17;
    undefined4 uVar18;
    int64_t var_3h;
    int64_t var_ch;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar16 = *(int64_t **)(arg1 + 0x28);
    piVar13 = piVar16;
    if (*(int64_t **)(arg1 + 0x40) <= piVar16) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar13 + 0xc) != 9) || (iVar1 = *piVar13, *(char *)(iVar1 + 3) != 'z')) ||
       ((int64_t *)(iVar1 + 0x10) == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624778);
        pcVar15 = (code *)swi(3);
        uVar11 = (*pcVar15)();
        return uVar11;
    }
    piVar13 = piVar16 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar16 + 2) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar13 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar7 = func_0x0001800a8360(arg1);
        if (iVar7 == 0) goto code_r0x00018005e359;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
            piVar13 = *(int64_t **)0x180782430;
        }
    }
    piVar16 = *(int64_t **)0x180782430;
    iVar14 = *piVar13 + 0x18;
    if (iVar14 == 0) {
code_r0x00018005e359:
        func_0x000180088470(arg1, 2, 6);
        pcVar15 = (code *)swi(3);
        uVar11 = (*pcVar15)();
        return uVar11;
    }
    piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    piVar12 = piVar13;
    if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) ||
       ((*(int32_t *)((int64_t)piVar12 + 0xc) != 6 && (*(int32_t *)((int64_t)piVar12 + 0xc) != 3)))) {
code_r0x00018005e050:
        iVar7 = 0;
    } else {
        if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
            piVar13 = *(int64_t **)0x180782430;
        }
        if (piVar13 == *(int64_t **)0x180782430) {
            piVar13 = (int64_t *)0x0;
        }
        iVar2 = *piVar13;
        if (iVar2 == 0) goto code_r0x00018005e050;
        iVar7 = (int32_t)iVar2 + *(int32_t *)(iVar2 + 0x10) + 0x10;
    }
    bVar17 = false;
    if (*(char *)(iVar1 + 0x28) != '\0') {
        return 0;
    }
    if (iVar7 == -0x24d4b210) {
        iVar14 = *(int64_t *)(*(int64_t *)(iVar1 + 0x10) + 8);
        if (iVar14 != 0) {
            do {
                if (iVar14 == *(int64_t *)(iVar1 + 0x18)) {
                    func_0x000180086b20(arg1, *(int64_t *)(*(int64_t *)(iVar1 + 0x18) + 0x20) != 0);
                    return 1;
                }
                iVar14 = *(int64_t *)(iVar14 + 0x10);
            } while (iVar14 != 0);
            func_0x000180086b20(arg1, 0);
            return 1;
        }
code_r0x00018005e10a:
        func_0x000180086b20(arg1, bVar17);
        return 1;
    }
    if (iVar7 == 0xdff80c0) {
        if (*(int64_t *)(iVar1 + 0x20) != 0) {
            func_0x000180086b20(arg1, *(int64_t *)(arg1 + 0x20) != *(int64_t *)(*(int64_t *)(iVar1 + 0x20) + 0x20));
            return 1;
        }
        func_0x000180086b20(arg1, 1);
        return 1;
    }
    if (iVar7 == -0x629bd323) {
        bVar17 = *(int64_t *)(iVar1 + 0x20) != 0;
        goto code_r0x00018005e10a;
    }
    if (iVar7 == 0x7c9f9488) {
        if (*(int32_t *)(iVar1 + 0x30) == 0) {
code_r0x00018005e26f:
            func_0x000180086510(arg1);
            return 1;
        }
        func_0x000180086ed0(arg1, 0xffffd8f0);
        uVar3 = *(uint64_t *)(arg1 + 0x40);
        if (((int64_t *)(uVar3 - 0x10) != *(int64_t **)0x180782430) && (*(int32_t *)(uVar3 - 4) == 8)) {
            return 1;
        }
        *(int64_t **)(arg1 + 0x40) = (int64_t *)(uVar3 - 0x10);
        if ((*(char *)0x180777010 == '\0') || (uVar3 <= **(uint64_t **)(arg1 + 0x18))) goto code_r0x00018005e181;
        iVar7 = func_0x000180085510(arg1, 1);
    } else {
        if (iVar7 != 0x70d04107) {
            if (iVar7 == 0x70e5dd) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d440;
            } else if (iVar7 == 0x12319c08) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d5f0;
            } else if (iVar7 == -0x36f161e6) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d860;
            } else if (iVar7 == -0x5fba3fa1) {
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005de80;
            } else {
                if (iVar7 != 0x4dfafac4) {
                    fcn.180088560(arg1, 0x180624788, iVar14);
                    pcVar15 = (code *)swi(3);
                    uVar11 = (*pcVar15)();
                    return uVar11;
                }
                uVar18 = func_0x000180018f70();
                pcVar15 = fcn.18005d8c0;
            }
            func_0x00018001afc0(uVar18, arg1, pcVar15, iVar14);
            return 1;
        }
        iVar7 = *(int32_t *)(iVar1 + 0x2c);
        if (iVar7 == 0) goto code_r0x00018005e26f;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar8 = func_0x000180085510(arg1, 1), piVar16 = *(int64_t **)0x180782430, iVar8 == 0))
        goto code_r0x00018005e32f;
        puVar9 = (undefined8 *)fcn.180085370(arg1, 0xffffd8f0);
        puVar10 = (undefined4 *)func_0x0001800a0d50(*puVar9, iVar7);
        puVar4 = *(undefined4 **)(arg1 + 0x40);
        uVar18 = puVar10[1];
        uVar5 = puVar10[2];
        uVar6 = puVar10[3];
        *puVar4 = *puVar10;
        puVar4[1] = uVar18;
        puVar4[2] = uVar5;
        puVar4[3] = uVar6;
        piVar13 = *(int64_t **)(arg1 + 0x40);
        *(int64_t **)(arg1 + 0x40) = piVar13 + 2;
        if ((piVar13 != piVar16) && (*(int32_t *)((int64_t)piVar13 + 0xc) == 10)) {
            return 1;
        }
        *(int64_t **)(arg1 + 0x40) = piVar13;
        if ((*(char *)0x180777010 == '\0') || (piVar13 + 2 <= **(int64_t ***)(arg1 + 0x18))) goto code_r0x00018005e181;
        iVar7 = func_0x000180085510(arg1, 1);
    }
    if (iVar7 == 0) {
code_r0x00018005e32f:
        func_0x000180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar15 = (code *)swi(3);
        uVar11 = (*pcVar15)();
        return uVar11;
    }
code_r0x00018005e181:
    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_18005e370
// Address: 0x18005e370
// Size: 210 bytes
// ============================================================
undefined8 fcn.18005e370(int64_t arg1)
{
    char cVar1;
    undefined uVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    undefined8 uVar13;
    int64_t *piVar14;
    undefined8 *puVar15;
    undefined4 *puVar16;
    int64_t **ppiVar17;
    int64_t **ppiVar18;
    int64_t *piVar19;
    int64_t *piVar20;
    int64_t *piVar21;
    int64_t **ppiVar22;
    int32_t iVar23;
    code *pcVar24;
    int64_t **ppiVar25;
    uint32_t uVar26;
    int64_t **ppiVar27;
    int64_t **ppiVar28;
    int64_t **ppiVar29;
    int64_t **ppiVar30;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    int64_t iStack_28;
    
    piVar19 = *(int64_t **)0x180782430;
    piVar20 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar20 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar20 + 0xc) != 9) || (iVar6 = *piVar20, *(char *)(iVar6 + 3) != 'z')) ||
       (iVar6 == -0x10)) {
        fcn.1800883d0(arg1, 1, 0x180624778);
        pcVar24 = (code *)swi(3);
        uVar13 = (*pcVar24)();
        return uVar13;
    }
    iVar12 = *(int64_t *)(arg1 + 8);
    if (iVar12 == 0) {
        fcn.180088560(arg1, 0x180624700);
        pcVar24 = (code *)swi(3);
        uVar13 = (*pcVar24)();
        return uVar13;
    }
    if (*(char *)(iVar6 + 0x28) != '\0') {
        return 0;
    }
    iVar23 = *(int32_t *)(iVar12 + 0x10) + 0x10 + (int32_t)iVar12;
    if (iVar23 == 0x70e5dd) {
        piVar19 = *(int64_t **)(arg1 + 0x28);
        piVar20 = *(int64_t **)(arg1 + 0x40);
        piVar11 = piVar19;
        if (piVar20 <= piVar19) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (((*(int32_t *)((int64_t)piVar11 + 0xc) == 9) && (iVar6 = *piVar11, *(char *)(iVar6 + 3) == 'z')) &&
           (iVar6 != -0x10)) {
            if (((*(int64_t *)(iVar6 + 0x20) != 0) &&
                (*(int64_t *)(*(int64_t *)(iVar6 + 0x20) + 0x20) == *(int64_t *)(arg1 + 0x20))) &&
               (*(int32_t *)(iVar6 + 0x30) != 0)) {
                func_0x000180086ed0(arg1, 0xffffd8f0);
                piVar11 = *(int64_t **)0x180782430;
                if (((int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10U) != *(int64_t **)0x180782430) &&
                   (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 8)) {
                    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                    }
                    piVar14 = *(int64_t **)(arg1 + 0x40);
                    uVar7 = *(undefined4 *)((int64_t)piVar14 + -0xc);
                    uVar8 = *(undefined4 *)(piVar14 + -1);
                    uVar9 = *(undefined4 *)((int64_t)piVar14 + -4);
                    piVar21 = *(int64_t **)(arg1 + 0x28);
                    if (piVar14 <= *(int64_t **)(arg1 + 0x28)) {
                        piVar21 = piVar11;
                    }
                    *(undefined4 *)piVar21 = *(undefined4 *)(piVar14 + -2);
                    *(undefined4 *)((int64_t)piVar21 + 4) = uVar7;
                    *(undefined4 *)(piVar21 + 1) = uVar8;
                    *(undefined4 *)((int64_t)piVar21 + 0xc) = uVar9;
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                    iVar12 = func_0x000180085760(*(undefined8 *)(iVar6 + 0x20));
                    if (iVar12 != 0) {
                        piVar11 = (int64_t *)(*(int64_t *)(iVar6 + 0x20) + 0x40);
                        *piVar11 = *piVar11 + -0x10;
                        func_0x000180085680(arg1, iVar12, (int64_t)piVar20 - (int64_t)piVar19 >> 4 & 0xffffffff);
                        pcVar24 = *(code **)0x1807824c8;
                        if (*(code **)0x1807824c8 == (code *)0x0) {
                            func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaf04);
                            func_0x000180086cc0(arg1, 0xffffffff, 0x1805aaf0c);
                            iVar3 = *(int64_t *)(arg1 + 0x40);
                            if ((*(int32_t *)(iVar3 + -4) == 8) && (*(char *)(*(int64_t *)(iVar3 + -0x10) + 3) != '\0'))
                            {
                                pcVar24 = *(code **)(*(int64_t *)(iVar3 + -0x10) + 0x20);
                            } else {
                                pcVar24 = (code *)0x0;
                            }
                            *(code **)0x1807824c8 = pcVar24;
                            *(int64_t *)(arg1 + 0x40) = iVar3 + -0x20;
                        }
                        (*pcVar24)(iVar12);
                    }
                    if (*(char *)(iVar6 + 0x29) != '\0') {
                        (**(code **)0x180782568)(iVar6 + 0x18);
                        *(undefined *)(iVar6 + 0x28) = 1;
                    }
                }
            }
            return 0;
        }
        fcn.1800883d0(arg1, 1, 0x180624778);
        pcVar24 = (code *)swi(3);
        uVar13 = (*pcVar24)();
        return uVar13;
    }
    if (iVar23 == 0x12319c08) {
        piVar20 = *(int64_t **)(arg1 + 0x28);
        piVar11 = *(int64_t **)(arg1 + 0x40);
        piVar14 = piVar20;
        if (piVar11 <= piVar20) {
            piVar14 = *(int64_t **)0x180782430;
        }
        if (((*(int32_t *)((int64_t)piVar14 + 0xc) != 9) || (iVar6 = *piVar14, *(char *)(iVar6 + 3) != 'z')) ||
           (iVar6 == -0x10)) {
            fcn.1800883d0(arg1, 1, 0x180624778);
            pcVar24 = (code *)swi(3);
            uVar13 = (*pcVar24)();
            return uVar13;
        }
        iVar23 = *(int32_t *)(iVar6 + 0x30);
        if (iVar23 != 0) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar10 = func_0x000180085510(arg1, 1), piVar19 = *(int64_t **)0x180782430, iVar10 == 0)) {
                func_0x000180099450(arg1, 0x18063d8d0);
                fcn.180087960(arg1);
                pcVar24 = (code *)swi(3);
                uVar13 = (*pcVar24)();
                return uVar13;
            }
            puVar15 = (undefined8 *)fcn.180085370(arg1, 0xffffd8f0);
            puVar16 = (undefined4 *)func_0x0001800a0d50(*puVar15, iVar23);
            puVar4 = *(undefined4 **)(arg1 + 0x40);
            uVar7 = puVar16[1];
            uVar8 = puVar16[2];
            uVar9 = puVar16[3];
            *puVar4 = *puVar16;
            puVar4[1] = uVar7;
            puVar4[2] = uVar8;
            puVar4[3] = uVar9;
            piVar14 = *(int64_t **)(arg1 + 0x40);
            *(int64_t **)(arg1 + 0x40) = piVar14 + 2;
            if ((piVar14 == piVar19) || (*(int32_t *)((int64_t)piVar14 + 0xc) != 8)) {
                *(int64_t **)(arg1 + 0x40) = piVar14;
            } else {
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                piVar14 = *(int64_t **)(arg1 + 0x40);
                uVar7 = *(undefined4 *)((int64_t)piVar14 + -0xc);
                uVar8 = *(undefined4 *)(piVar14 + -1);
                uVar9 = *(undefined4 *)((int64_t)piVar14 + -4);
                piVar21 = *(int64_t **)(arg1 + 0x28);
                if (piVar14 <= *(int64_t **)(arg1 + 0x28)) {
                    piVar21 = piVar19;
                }
                *(undefined4 *)piVar21 = *(undefined4 *)(piVar14 + -2);
                *(undefined4 *)((int64_t)piVar21 + 4) = uVar7;
                *(undefined4 *)(piVar21 + 1) = uVar8;
                *(undefined4 *)((int64_t)piVar21 + 0xc) = uVar9;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaf04);
                func_0x000180086cc0(arg1, 0xffffffff, 0x1806217b8);
                func_0x0001800859a0(arg1, 1);
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                uVar26 = (uint32_t)((int64_t)piVar11 - (int64_t)piVar20 >> 4);
                iVar23 = uVar26 + 1;
                if ((((iVar23 < 0) && (*(char *)0x180777010 != '\0')) &&
                    (uVar26 = ~uVar26,
                    **(uint64_t **)(arg1 + 0x18) <
                    (uint64_t)((int64_t)(int32_t)uVar26 * 0x10 + *(int64_t *)(arg1 + 0x40)))) &&
                   (iVar10 = func_0x000180085510(arg1, uVar26), iVar10 == 0)) {
                    func_0x000180099450(arg1, 0x18063d8d0);
                    fcn.180087960(arg1);
                    pcVar24 = (code *)swi(3);
                    uVar13 = (*pcVar24)();
                    return uVar13;
                }
                iStack_28 = *(int64_t *)(arg1 + 0x40) + (int64_t)iVar23 * -0x10;
                func_0x000180094080(arg1, 0x180087890, &iStack_28, iStack_28 - *(int64_t *)(arg1 + 0x38), 0);
                if (*(char *)(iVar6 + 0x29) != '\0') {
                    (**(code **)0x180782568)(iVar6 + 0x18);
                    *(undefined *)(iVar6 + 0x28) = 1;
                }
            }
        }
        return 0;
    }
    if (iVar23 == -0x36f161e6) {
        piVar19 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar19 = *(int64_t **)0x180782430;
        }
        if (((*(int32_t *)((int64_t)piVar19 + 0xc) == 9) && (iVar6 = *piVar19, *(char *)(iVar6 + 3) == 'z')) &&
           (iVar6 != -0x10)) {
            (**(code **)0x180782568)(iVar6 + 0x18);
            return 0;
        }
        fcn.1800883d0(arg1, 1, 0x180624778);
        pcVar24 = (code *)swi(3);
        uVar13 = (*pcVar24)();
        return uVar13;
    }
    if (iVar23 == -0x5fba3fa1) {
        piVar19 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar19 = *(int64_t **)0x180782430;
        }
        if (((*(int32_t *)((int64_t)piVar19 + 0xc) == 9) && (iVar6 = *piVar19, *(char *)(iVar6 + 3) == 'z')) &&
           ((int64_t *)(iVar6 + 0x10) != (int64_t *)0x0)) {
            iVar12 = *(int64_t *)(*(int64_t *)(iVar6 + 0x10) + 8);
            if (iVar12 != 0) {
                iVar6 = *(int64_t *)(iVar6 + 0x18);
                while (iVar12 != iVar6) {
                    iVar12 = *(int64_t *)(iVar12 + 0x10);
                    if (iVar12 == 0) {
                        return 0;
                    }
                }
                piVar19 = (int64_t *)fcn.18005fff0(iVar12, &stack0x00000008);
                if (*piVar19 == 0) {
                    uVar13 = *(undefined8 *)(iVar6 + 0x20);
                    puVar15 = (undefined8 *)fcn.18005fff0(extraout_XMM0_Da_00, &stack0x00000008);
                    *puVar15 = uVar13;
                }
                *(undefined8 *)(iVar6 + 0x20) = 0;
            }
            return 0;
        }
        fcn.1800883d0(arg1, 1, 0x180624778);
        pcVar24 = (code *)swi(3);
        uVar13 = (*pcVar24)();
        return uVar13;
    }
    if (iVar23 != 0x4dfafac4) {
        fcn.180088560(arg1, 0x180624788, iVar12 + 0x18);
        pcVar24 = (code *)swi(3);
        uVar13 = (*pcVar24)();
        return uVar13;
    }
    piVar19 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar19 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar19 + 0xc) != 9) || (iVar6 = *piVar19, *(char *)(iVar6 + 3) != 'z')) ||
       ((int64_t *)(iVar6 + 0x10) == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624778);
        pcVar24 = (code *)swi(3);
        uVar13 = (*pcVar24)();
        return uVar13;
    }
    piVar19 = *(int64_t **)(*(int64_t *)(iVar6 + 0x10) + 8);
    if (piVar19 != (int64_t *)0x0) {
        piVar20 = *(int64_t **)(iVar6 + 0x18);
        while (piVar19 != piVar20) {
            piVar19 = (int64_t *)piVar19[2];
            if (piVar19 == (int64_t *)0x0) {
                return 0;
            }
        }
        if ((piVar20[4] == 0) && (piVar19 = (int64_t *)fcn.18005fff0(piVar19, &stack0x00000008), *piVar19 != 0)) {
            piVar19 = (int64_t *)fcn.18005fff0(extraout_XMM0_Da, &stack0x00000008);
            piVar20[4] = *piVar19;
            ppiVar22 = (int64_t **)(*(int64_t ***)0x1807826e0)[1];
            cVar1 = *(char *)((int64_t)ppiVar22 + 0x19);
            ppiVar17 = ppiVar22;
            ppiVar28 = *(int64_t ***)0x1807826e0;
            ppiVar30 = *(int64_t ***)0x1807826e0;
            while (ppiVar25 = ppiVar17, cVar1 == '\0') {
                if (ppiVar25[4] < piVar20) {
                    ppiVar17 = (int64_t **)ppiVar25[2];
                    ppiVar25 = ppiVar28;
                } else {
                    if ((*(char *)((int64_t)ppiVar30 + 0x19) != '\0') && (piVar20 < ppiVar25[4])) {
                        ppiVar30 = ppiVar25;
                    }
                    ppiVar17 = (int64_t **)*ppiVar25;
                }
                cVar1 = *(char *)((int64_t)ppiVar17 + 0x19);
                ppiVar28 = ppiVar25;
            }
            if (*(char *)((int64_t)ppiVar30 + 0x19) == '\0') {
                ppiVar22 = (int64_t **)*ppiVar30;
            }
            cVar1 = *(char *)((int64_t)ppiVar22 + 0x19);
            while (cVar1 == '\0') {
                if (piVar20 < ppiVar22[4]) {
                    ppiVar17 = (int64_t **)*ppiVar22;
                    ppiVar30 = ppiVar22;
                } else {
                    ppiVar17 = (int64_t **)ppiVar22[2];
                }
                ppiVar22 = ppiVar17;
                cVar1 = *(char *)((int64_t)ppiVar17 + 0x19);
            }
            if ((ppiVar28 == (int64_t **)**(int64_t ***)0x1807826e0) && (*(char *)((int64_t)ppiVar30 + 0x19) != '\0')) {
                fcn.18005ff80();
            } else {
                while (ppiVar28 != ppiVar30) {
                    ppiVar17 = (int64_t **)ppiVar28[2];
                    ppiVar22 = ppiVar28 + 2;
                    if (*(char *)((int64_t)ppiVar17 + 0x19) == '\0') {
                        cVar1 = *(char *)((int64_t)*ppiVar17 + 0x19);
                        ppiVar25 = ppiVar17;
                        ppiVar18 = (int64_t **)*ppiVar17;
                        while (cVar1 == '\0') {
                            cVar1 = *(char *)((int64_t)*ppiVar18 + 0x19);
                            ppiVar25 = ppiVar18;
                            ppiVar18 = (int64_t **)*ppiVar18;
                        }
                        piVar19 = *ppiVar17;
                        ppiVar18 = ppiVar17;
                        if (*(char *)((int64_t)piVar19 + 0x19) == '\0') {
                            do {
                                piVar19 = (int64_t *)*piVar19;
                            } while (*(char *)((int64_t)piVar19 + 0x19) == '\0');
                            ppiVar5 = (int64_t **)*ppiVar17;
                            do {
                                ppiVar18 = ppiVar5;
                                ppiVar5 = (int64_t **)*ppiVar18;
                            } while (*(char *)((int64_t)*ppiVar18 + 0x19) == '\0');
                        }
                    } else {
                        cVar1 = *(char *)((int64_t)ppiVar28[1] + 0x19);
                        ppiVar5 = (int64_t **)ppiVar28[1];
                        ppiVar18 = ppiVar28;
                        while ((ppiVar25 = ppiVar5, cVar1 == '\0' && (ppiVar18 == (int64_t **)ppiVar25[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar25[1] + 0x19);
                            ppiVar5 = (int64_t **)ppiVar25[1];
                            ppiVar18 = ppiVar25;
                        }
                        ppiVar18 = (int64_t **)ppiVar28[1];
                        cVar1 = *(char *)((int64_t)ppiVar18 + 0x19);
                        ppiVar5 = ppiVar28;
                        while ((ppiVar29 = ppiVar18, cVar1 == '\0' && (ppiVar5 == (int64_t **)ppiVar29[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar29[1] + 0x19);
                            ppiVar18 = (int64_t **)ppiVar29[1];
                            ppiVar5 = ppiVar29;
                        }
                        ppiVar5 = (int64_t **)ppiVar28[1];
                        cVar1 = *(char *)((int64_t)ppiVar5 + 0x19);
                        ppiVar29 = ppiVar28;
                        while ((ppiVar18 = ppiVar5, cVar1 == '\0' && (ppiVar29 == (int64_t **)ppiVar18[2]))) {
                            cVar1 = *(char *)((int64_t)ppiVar18[1] + 0x19);
                            ppiVar5 = (int64_t **)ppiVar18[1];
                            ppiVar29 = ppiVar18;
                        }
                    }
                    ppiVar27 = ppiVar28 + 1;
                    ppiVar5 = (int64_t **)*ppiVar28;
                    ppiVar29 = ppiVar17;
                    if (((*(char *)((int64_t)ppiVar5 + 0x19) == '\0') &&
                        (ppiVar29 = ppiVar5, *(char *)((int64_t)ppiVar17 + 0x19) == '\0')) &&
                       (ppiVar29 = (int64_t **)ppiVar18[2], ppiVar18 != ppiVar28)) {
                        ppiVar5[1] = (int64_t *)ppiVar18;
                        *ppiVar18 = *ppiVar28;
                        ppiVar17 = ppiVar18;
                        if (ppiVar18 != (int64_t **)*ppiVar22) {
                            ppiVar17 = (int64_t **)ppiVar18[1];
                            if (*(char *)((int64_t)ppiVar29 + 0x19) == '\0') {
                                ppiVar29[1] = (int64_t *)ppiVar17;
                            }
                            *ppiVar17 = (int64_t *)ppiVar29;
                            ppiVar18[2] = *ppiVar22;
                            (*ppiVar22)[1] = (int64_t)ppiVar18;
                        }
                        if ((int64_t **)(*(int64_t ***)0x1807826e0)[1] == ppiVar28) {
                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar18;
                        } else {
                            ppiVar22 = (int64_t **)*ppiVar27;
                            if ((int64_t **)*ppiVar22 == ppiVar28) {
                                *ppiVar22 = (int64_t *)ppiVar18;
                            } else {
                                ppiVar22[2] = (int64_t *)ppiVar18;
                            }
                        }
                        uVar2 = *(undefined *)(ppiVar18 + 3);
                        ppiVar18[1] = *ppiVar27;
                        *(undefined *)(ppiVar18 + 3) = *(undefined *)(ppiVar28 + 3);
                        *(undefined *)(ppiVar28 + 3) = uVar2;
                    } else {
                        ppiVar17 = (int64_t **)*ppiVar27;
                        if (*(char *)((int64_t)ppiVar29 + 0x19) == '\0') {
                            ppiVar29[1] = (int64_t *)ppiVar17;
                        }
                        if ((int64_t **)(*(int64_t ***)0x1807826e0)[1] == ppiVar28) {
                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar29;
                        } else if ((int64_t **)*ppiVar17 == ppiVar28) {
                            *ppiVar17 = (int64_t *)ppiVar29;
                        } else {
                            ppiVar17[2] = (int64_t *)ppiVar29;
                        }
                        if ((int64_t **)**(int64_t ***)0x1807826e0 == ppiVar28) {
                            ppiVar22 = ppiVar17;
                            if (*(char *)((int64_t)ppiVar29 + 0x19) == '\0') {
                                cVar1 = *(char *)((int64_t)*ppiVar29 + 0x19);
                                ppiVar18 = (int64_t **)*ppiVar29;
                                ppiVar22 = ppiVar29;
                                while (ppiVar5 = ppiVar18, cVar1 == '\0') {
                                    ppiVar18 = (int64_t **)*ppiVar5;
                                    cVar1 = *(char *)((int64_t)ppiVar18 + 0x19);
                                    ppiVar22 = ppiVar5;
                                }
                            }
                            **(int64_t ***)0x1807826e0 = (int64_t *)ppiVar22;
                        }
                        if ((int64_t **)(*(int64_t ***)0x1807826e0)[2] == ppiVar28) {
                            if (*(char *)((int64_t)ppiVar29 + 0x19) == '\0') {
                                cVar1 = *(char *)((int64_t)ppiVar29[2] + 0x19);
                                ppiVar22 = ppiVar29;
                                while (cVar1 == '\0') {
                                    ppiVar22 = (int64_t **)ppiVar22[2];
                                    cVar1 = *(char *)((int64_t)ppiVar22[2] + 0x19);
                                }
                                (*(int64_t ***)0x1807826e0)[2] = (int64_t *)ppiVar22;
                            } else {
                                (*(int64_t ***)0x1807826e0)[2] = (int64_t *)ppiVar17;
                            }
                        }
                    }
                    if (*(char *)(ppiVar28 + 3) == '\x01') {
                        if (ppiVar29 != (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                            do {
                                ppiVar22 = ppiVar17;
                                if (*(char *)(ppiVar29 + 3) != '\x01') break;
                                ppiVar17 = (int64_t **)*ppiVar22;
                                if (ppiVar29 == ppiVar17) {
                                    ppiVar17 = (int64_t **)ppiVar22[2];
                                    ppiVar18 = ppiVar22 + 3;
                                    if (*(char *)(ppiVar17 + 3) == '\0') {
                                        *(undefined *)(ppiVar17 + 3) = 1;
                                        ppiVar5 = (int64_t **)ppiVar22[2];
                                        *(undefined *)ppiVar18 = 0;
                                        ppiVar22[2] = *ppiVar5;
                                        if (*(char *)((int64_t)*ppiVar5 + 0x19) == '\0') {
                                            (*ppiVar5)[1] = (int64_t)ppiVar22;
                                        }
                                        ppiVar5[1] = ppiVar22[1];
                                        if (ppiVar22 == (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar5;
                                        } else {
                                            ppiVar17 = (int64_t **)ppiVar22[1];
                                            if (ppiVar22 == (int64_t **)*ppiVar17) {
                                                *ppiVar17 = (int64_t *)ppiVar5;
                                            } else {
                                                ppiVar17[2] = (int64_t *)ppiVar5;
                                            }
                                        }
                                        *ppiVar5 = (int64_t *)ppiVar22;
                                        ppiVar17 = (int64_t **)ppiVar22[2];
                                        ppiVar22[1] = (int64_t *)ppiVar5;
                                    }
                                    if (*(char *)((int64_t)ppiVar17 + 0x19) == '\0') {
                                        if ((*(char *)(*ppiVar17 + 3) != '\x01') ||
                                           (*(char *)(ppiVar17[2] + 3) != '\x01')) {
                                            if (*(char *)(ppiVar17[2] + 3) == '\x01') {
                                                *(undefined *)(*ppiVar17 + 3) = 1;
                                                *(undefined *)(ppiVar17 + 3) = 0;
                                                fcn.180060390(0x1807826e0);
                                                ppiVar17 = (int64_t **)ppiVar22[2];
                                            }
                                            *(undefined *)(ppiVar17 + 3) = *(undefined *)ppiVar18;
                                            *(undefined *)ppiVar18 = 1;
                                            *(undefined *)(ppiVar17[2] + 3) = 1;
                                            fcn.1800603f0(0x1807826e0, ppiVar22);
                                            break;
                                        }
code_r0x00018005ddb6:
                                        *(undefined *)(ppiVar17 + 3) = 0;
                                    }
                                } else {
                                    ppiVar18 = ppiVar22 + 3;
                                    if (*(char *)(ppiVar17 + 3) == '\0') {
                                        *(undefined *)(ppiVar17 + 3) = 1;
                                        piVar19 = *ppiVar22;
                                        *(undefined *)ppiVar18 = 0;
                                        *ppiVar22 = (int64_t *)piVar19[2];
                                        if (*(char *)(piVar19[2] + 0x19) == '\0') {
                                            *(int64_t ***)(piVar19[2] + 8) = ppiVar22;
                                        }
                                        piVar19[1] = (int64_t)ppiVar22[1];
                                        if (ppiVar22 == (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                                            (*(int64_t ***)0x1807826e0)[1] = piVar19;
                                        } else {
                                            ppiVar17 = (int64_t **)ppiVar22[1];
                                            if (ppiVar22 == (int64_t **)ppiVar17[2]) {
                                                ppiVar17[2] = piVar19;
                                            } else {
                                                *ppiVar17 = piVar19;
                                            }
                                        }
                                        piVar19[2] = (int64_t)ppiVar22;
                                        ppiVar17 = (int64_t **)*ppiVar22;
                                        ppiVar22[1] = piVar19;
                                    }
                                    if (*(char *)((int64_t)ppiVar17 + 0x19) == '\0') {
                                        if ((*(char *)(ppiVar17[2] + 3) == '\x01') &&
                                           (*(char *)(*ppiVar17 + 3) == '\x01')) goto code_r0x00018005ddb6;
                                        if (*(char *)(*ppiVar17 + 3) == '\x01') {
                                            *(undefined *)(ppiVar17[2] + 3) = 1;
                                            *(undefined *)(ppiVar17 + 3) = 0;
                                            fcn.1800603f0(0x1807826e0);
                                            ppiVar17 = (int64_t **)*ppiVar22;
                                        }
                                        *(undefined *)(ppiVar17 + 3) = *(undefined *)ppiVar18;
                                        *(undefined *)ppiVar18 = 1;
                                        *(undefined *)(*ppiVar17 + 3) = 1;
                                        fcn.180060390(0x1807826e0, ppiVar22);
                                        break;
                                    }
                                }
                                ppiVar17 = (int64_t **)ppiVar22[1];
                                ppiVar29 = ppiVar22;
                            } while (ppiVar22 != (int64_t **)(*(int64_t ***)0x1807826e0)[1]);
                        }
                        *(undefined *)(ppiVar29 + 3) = 1;
                    }
                    if (*(int64_t *)0x1807826e8 != 0) {
                        *(int64_t *)0x1807826e8 = *(int64_t *)0x1807826e8 + -1;
                    }
                    fcn.180459c3c(ppiVar28, 0x30);
                    ppiVar28 = ppiVar25;
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18005e450
// Address: 0x18005e450
// Size: 32 bytes
// ============================================================
undefined8 fcn.18005e450(undefined8 param_1)
{
    fcn.1800867f0(param_1, 0x180624778, 0xf);
    return 1;
}

// ============================================================
// Function: FUN_18005e470
// Address: 0x18005e470
// Size: 107 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

undefined8 fcn.18005e470(int64_t arg1)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t *piVar8;
    undefined8 *puVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    uint32_t uVar12;
    int64_t *piVar13;
    int64_t iVar14;
    undefined uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    bool bVar18;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    piVar13 = piVar8;
    if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if ((piVar13 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar13 + 0xc) != 9)) {
        func_0x000180088470(arg1, 1, 9);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) == 9) {
        uVar12 = (uint32_t)*(uint8_t *)(*piVar8 + 3);
    } else {
        uVar12 = 0xffffffff;
    }
    if (uVar12 != *(uint32_t *)0x1807823d4) {
        func_0x000180088380(arg1, 1, 0x180624758);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    func_0x000180086cc0(arg1, 1, 0x1805aaf48);
    func_0x000180085bf0(arg1, 1);
    func_0x0001800869f0(arg1, 0x180005d40, 0, 0, 0);
    iVar6 = func_0x0001800878a0(arg1, 2, 1);
    if (iVar6 != 0) {
        fcn.180087960(arg1);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    iVar1 = *(int64_t *)(arg1 + 0x40);
    if (*(int32_t *)(iVar1 + -4) == 9) {
        piVar8 = (int64_t *)(*(int64_t *)(iVar1 + -0x10) + 0x10);
    } else {
        piVar8 = (int64_t *)0x0;
        if (*(int32_t *)(iVar1 + -4) == 2) {
            piVar8 = *(int64_t **)(iVar1 + -0x10);
        }
    }
    iVar1 = *piVar8;
    if (iVar1 == 0) {
        func_0x000180086fd0(arg1, 0, 0);
        return 1;
    }
    uVar11 = *(undefined8 *)(iVar1 + 0x20);
    iVar1 = *(int64_t *)(iVar1 + 0x10);
    func_0x000180086cc0(arg1, 0xffffffff, 0x1806247f0);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar2 = *(undefined4 **)(arg1 + 0x40);
    for (puVar10 = puVar2; puVar2 + -8 < puVar10; puVar10 = puVar10 + -4) {
        *puVar10 = puVar10[-4];
        puVar10[1] = puVar10[-3];
        puVar10[2] = puVar10[-2];
        puVar10[3] = puVar10[-1];
    }
    puVar10 = *(undefined4 **)(arg1 + 0x40);
    uVar17 = puVar10[1];
    uVar16 = puVar10[2];
    uVar5 = puVar10[3];
    puVar2[-8] = *puVar10;
    puVar2[-7] = uVar17;
    puVar2[-6] = uVar16;
    puVar2[-5] = uVar5;
    func_0x0001800878a0(arg1, 1, 0);
    func_0x000180086fd0(arg1, 0, 0);
    iVar6 = 1;
    do {
        if (iVar1 == 0) {
            return 1;
        }
        puVar9 = (undefined8 *)func_0x000180087f70(arg1, 0x28, 0x7a);
        uVar17 = 0;
        if ((*(int64_t *)(iVar1 + 0x30) == *(int64_t *)(iVar1 + 0x38) + 0x18) ||
           (*(int64_t *)(iVar1 + 0x38) == *(int64_t *)(iVar1 + 0x40) + 0x18)) {
            iVar7 = func_0x00018005d3d0(iVar1);
            if (iVar7 != 0) {
                if (iVar7 == 1) {
                    if ((((*(int64_t **)(iVar1 + 0x38) != (int64_t *)0x0) && (*(int64_t *)(iVar1 + 0x40) != 0)) &&
                        (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + 8) != 0)) &&
                       ((iVar14 = **(int64_t **)(iVar1 + 0x38), iVar14 == *(int64_t *)0x180782520 ||
                        (iVar14 == *(int64_t *)0x180782528)))) goto code_r0x00018005e896;
                } else if (((iVar7 == 2) &&
                           ((*(int64_t **)(iVar1 + 0x30) != (int64_t *)0x0 && (*(int64_t *)(iVar1 + 0x38) != 0)))) &&
                          (*(int32_t *)(*(int64_t *)(iVar1 + 0x38) + 8) != 0)) {
                    bVar18 = **(int64_t **)(iVar1 + 0x30) == *(int64_t *)0x180782620;
                    goto code_r0x00018005e890;
                }
                goto code_r0x00018005e6c8;
            }
            if (((*(int64_t **)(iVar1 + 0x30) == (int64_t *)0x0) || (*(int64_t *)(iVar1 + 0x38) == 0)) ||
               (*(int32_t *)(*(int64_t *)(iVar1 + 0x38) + 8) == 0)) goto code_r0x00018005e6c8;
            iVar14 = **(int64_t **)(iVar1 + 0x30);
            if (iVar14 != *(int64_t *)0x180782520) {
                bVar18 = iVar14 == *(int64_t *)0x180782528;
code_r0x00018005e890:
                if (!bVar18) goto code_r0x00018005e6c8;
            }
code_r0x00018005e896:
            iVar7 = func_0x00018005d3d0(iVar1);
            if (iVar7 == 0) {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar1 + 0x30) + 0x60);
                uVar15 = *(undefined *)(*(int64_t *)(iVar1 + 0x30) + 0x95);
            } else if (iVar7 == 1) {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar1 + 0x38) + 0x60);
                uVar15 = *(undefined *)(*(int64_t *)(iVar1 + 0x38) + 0x95);
            } else {
                if (iVar7 != 2) goto code_r0x00018005e6c8;
                uVar15 = 1;
                iVar14 = *(int64_t *)(*(int64_t *)(iVar1 + 0x30) + 0x38);
            }
            if (iVar14 == 0) goto code_r0x00018005e6c8;
            uVar17 = *(undefined4 *)(iVar14 + 0x34);
            uVar16 = *(undefined4 *)(iVar14 + 0x30);
            piVar8 = *(int64_t **)(iVar14 + 0x28);
        } else {
code_r0x00018005e6c8:
            uVar15 = 0;
            uVar16 = 0;
            piVar8 = (int64_t *)0x0;
        }
        *puVar9 = uVar11;
        puVar9[1] = iVar1;
        puVar9[2] = piVar8;
        *(undefined *)(puVar9 + 3) = 0;
        *(undefined *)((int64_t)puVar9 + 0x19) = uVar15;
        *(undefined4 *)((int64_t)puVar9 + 0x1c) = uVar16;
        *(undefined4 *)(puVar9 + 4) = uVar17;
        iVar7 = func_0x0001800885b0(arg1, 0x180624778);
        if (iVar7 != 0) {
            func_0x0001800869f0(arg1, fcn.18005df30, 0, 0, 0);
            func_0x000180087370(arg1, 0xfffffffe, 0x1805aae90);
            func_0x0001800869f0(arg1, fcn.18005e370, 0, 0, 0);
            func_0x000180087370(arg1, 0xfffffffe, 0x1806203d0);
            func_0x0001800869f0(arg1, fcn.18005e450, 0, 0, 0);
            func_0x000180087370(arg1, 0xfffffffe, 0x180622440);
            fcn.1800867f0(arg1, 0x180624778, 0xf);
            func_0x000180087370(arg1, 0xfffffffe, 0x180622470);
            fcn.1800867f0(arg1, 0x180622458, 0x17);
            func_0x000180087370(arg1, 0xfffffffe, 0x1806224a0);
        }
        func_0x000180087650(arg1, 0xfffffffe);
        iVar14 = *(int64_t *)(arg1 + 0x40);
        if (*(char *)(*(int64_t *)(iVar14 + -0x20) + 4) != '\0') {
            func_0x000180092f10(arg1);
            pcVar4 = (code *)swi(3);
            uVar11 = (*pcVar4)();
            return uVar11;
        }
        puVar10 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar14 + -0x20), iVar6);
        uVar17 = *(undefined4 *)(iVar14 + -0xc);
        uVar16 = *(undefined4 *)(iVar14 + -8);
        uVar5 = *(undefined4 *)(iVar14 + -4);
        *puVar10 = *(undefined4 *)(iVar14 + -0x10);
        puVar10[1] = uVar17;
        puVar10[2] = uVar16;
        puVar10[3] = uVar5;
        if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
            iVar14 = *(int64_t *)(iVar14 + -0x20);
            if (((*(uint8_t *)(iVar14 + 1) & 4) != 0) &&
               ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                iVar3 = *(int64_t *)(arg1 + 0x20);
                if (*(char *)(iVar3 + 0x59) == '\x02') {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(iVar14 + 1) = *(uint8_t *)(iVar14 + 1) & 0xfb;
                    *(undefined8 *)(iVar14 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                    *(int64_t *)(iVar3 + 0x18) = iVar14;
                }
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        iVar1 = *(int64_t *)(iVar1 + 0x10);
        iVar6 = iVar6 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_18005e4db
// Address: 0x18005e4db
// Size: 162 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

undefined8 fcn.18005e470(int64_t arg1)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t *piVar8;
    undefined8 *puVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    uint32_t uVar12;
    int64_t *piVar13;
    int64_t iVar14;
    undefined uVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    bool bVar18;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    piVar13 = piVar8;
    if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if ((piVar13 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar13 + 0xc) != 9)) {
        func_0x000180088470(arg1, 1, 9);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) == 9) {
        uVar12 = (uint32_t)*(uint8_t *)(*piVar8 + 3);
    } else {
        uVar12 = 0xffffffff;
    }
    if (uVar12 != *(uint32_t *)0x1807823d4) {
        func_0x000180088380(arg1, 1, 0x180624758);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    func_0x000180086cc0(arg1, 1, 0x1805aaf48);
    func_0x000180085bf0(arg1, 1);
    func_0x0001800869f0(arg1, 0x180005d40, 0, 0, 0);
    iVar6 = func_0x0001800878a0(arg1, 2, 1);
    if (iVar6 != 0) {
        fcn.180087960(arg1);
        pcVar4 = (code *)swi(3);
        uVar11 = (*pcVar4)();
        return uVar11;
    }
    iVar1 = *(int64_t *)(arg1 + 0x40);
    if (*(int32_t *)(iVar1 + -4) == 9) {
        piVar8 = (int64_t *)(*(int64_t *)(iVar1 + -0x10) + 0x10);
    } else {
        piVar8 = (int64_t *)0x0;
        if (*(int32_t *)(iVar1 + -4) == 2) {
            piVar8 = *(int64_t **)(iVar1 + -0x10);
        }
    }
    iVar1 = *piVar8;
    if (iVar1 == 0) {
        func_0x000180086fd0(arg1, 0, 0);
        return 1;
    }
    uVar11 = *(undefined8 *)(iVar1 + 0x20);
    iVar1 = *(int64_t *)(iVar1 + 0x10);
    func_0x000180086cc0(arg1, 0xffffffff, 0x1806247f0);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar2 = *(undefined4 **)(arg1 + 0x40);
    for (puVar10 = puVar2; puVar2 + -8 < puVar10; puVar10 = puVar10 + -4) {
        *puVar10 = puVar10[-4];
        puVar10[1] = puVar10[-3];
        puVar10[2] = puVar10[-2];
        puVar10[3] = puVar10[-1];
    }
    puVar10 = *(undefined4 **)(arg1 + 0x40);
    uVar17 = puVar10[1];
    uVar16 = puVar10[2];
    uVar5 = puVar10[3];
    puVar2[-8] = *puVar10;
    puVar2[-7] = uVar17;
    puVar2[-6] = uVar16;
    puVar2[-5] = uVar5;
    func_0x0001800878a0(arg1, 1, 0);
    func_0x000180086fd0(arg1, 0, 0);
    iVar6 = 1;
    do {
        if (iVar1 == 0) {
            return 1;
        }
        puVar9 = (undefined8 *)func_0x000180087f70(arg1, 0x28, 0x7a);
        uVar17 = 0;
        if ((*(int64_t *)(iVar1 + 0x30) == *(int64_t *)(iVar1 + 0x38) + 0x18) ||
           (*(int64_t *)(iVar1 + 0x38) == *(int64_t *)(iVar1 + 0x40) + 0x18)) {
            iVar7 = func_0x00018005d3d0(iVar1);
            if (iVar7 != 0) {
                if (iVar7 == 1) {
                    if ((((*(int64_t **)(iVar1 + 0x38) != (int64_t *)0x0) && (*(int64_t *)(iVar1 + 0x40) != 0)) &&
                        (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + 8) != 0)) &&
                       ((iVar14 = **(int64_t **)(iVar1 + 0x38), iVar14 == *(int64_t *)0x180782520 ||
                        (iVar14 == *(int64_t *)0x180782528)))) goto code_r0x00018005e896;
                } else if (((iVar7 == 2) &&
                           ((*(int64_t **)(iVar1 + 0x30) != (int64_t *)0x0 && (*(int64_t *)(iVar1 + 0x38) != 0)))) &&
                          (*(int32_t *)(*(int64_t *)(iVar1 + 0x38) + 8) != 0)) {
                    bVar18 = **(int64_t **)(iVar1 + 0x30) == *(int64_t *)0x180782620;
                    goto code_r0x00018005e890;
                }
                goto code_r0x00018005e6c8;
            }
            if (((*(int64_t **)(iVar1 + 0x30) == (int64_t *)0x0) || (*(int64_t *)(iVar1 + 0x38) == 0)) ||
               (*(int32_t *)(*(int64_t *)(iVar1 + 0x38) + 8) == 0)) goto code_r0x00018005e6c8;
            iVar14 = **(int64_t **)(iVar1 + 0x30);
            if (iVar14 != *(int64_t *)0x180782520) {
                bVar18 = iVar14 == *(int64_t *)0x180782528;
code_r0x00018005e890:
                if (!bVar18) goto code_r0x00018005e6c8;
            }
code_r0x00018005e896:
            iVar7 = func_0x00018005d3d0(iVar1);
            if (iVar7 == 0) {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar1 + 0x30) + 0x60);
                uVar15 = *(undefined *)(*(int64_t *)(iVar1 + 0x30) + 0x95);
            } else if (iVar7 == 1) {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar1 + 0x38) + 0x60);
                uVar15 = *(undefined *)(*(int64_t *)(iVar1 + 0x38) + 0x95);
            } else {
                if (iVar7 != 2) goto code_r0x00018005e6c8;
                uVar15 = 1;
                iVar14 = *(int64_t *)(*(int64_t *)(iVar1 + 0x30) + 0x38);
            }
            if (iVar14 == 0) goto code_r0x00018005e6c8;
            uVar17 = *(undefined4 *)(iVar14 + 0x34);
            uVar16 = *(undefined4 *)(iVar14 + 0x30);
            piVar8 = *(int64_t **)(iVar14 + 0x28);
        } else {
code_r0x00018005e6c8:
            uVar15 = 0;
            uVar16 = 0;
            piVar8 = (int64_t *)0x0;
        }
        *puVar9 = uVar11;
        puVar9[1] = iVar1;
        puVar9[2] = piVar8;
        *(undefined *)(puVar9 + 3) = 0;
        *(undefined *)((int64_t)puVar9 + 0x19) = uVar15;
        *(undefined4 *)((int64_t)puVar9 + 0x1c) = uVar16;
        *(undefined4 *)(puVar9 + 4) = uVar17;
        iVar7 = func_0x0001800885b0(arg1, 0x180624778);
        if (iVar7 != 0) {
            func_0x0001800869f0(arg1, fcn.18005df30, 0, 0, 0);
            func_0x000180087370(arg1, 0xfffffffe, 0x1805aae90);
            func_0x0001800869f0(arg1, fcn.18005e370, 0, 0, 0);
            func_0x000180087370(arg1, 0xfffffffe, 0x1806203d0);
            func_0x0001800869f0(arg1, fcn.18005e450, 0, 0, 0);
            func_0x000180087370(arg1, 0xfffffffe, 0x180622440);
            fcn.1800867f0(arg1, 0x180624778, 0xf);
            func_0x000180087370(arg1, 0xfffffffe, 0x180622470);
            fcn.1800867f0(arg1, 0x180622458, 0x17);
            func_0x000180087370(arg1, 0xfffffffe, 0x1806224a0);
        }
        func_0x000180087650(arg1, 0xfffffffe);
        iVar14 = *(int64_t *)(arg1 + 0x40);
        if (*(char *)(*(int64_t *)(iVar14 + -0x20) + 4) != '\0') {
            func_0x000180092f10(arg1);
            pcVar4 = (code *)swi(3);
            uVar11 = (*pcVar4)();
            return uVar11;
        }
        puVar10 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar14 + -0x20), iVar6);
        uVar17 = *(undefined4 *)(iVar14 + -0xc);
        uVar16 = *(undefined4 *)(iVar14 + -8);
        uVar5 = *(undefined4 *)(iVar14 + -4);
        *puVar10 = *(undefined4 *)(iVar14 + -0x10);
        puVar10[1] = uVar17;
        puVar10[2] = uVar16;
        puVar10[3] = uVar5;
        if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
            iVar14 = *(int64_t *)(iVar14 + -0x20);
            if (((*(uint8_t *)(iVar14 + 1) & 4) != 0) &&
               ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                iVar3 = *(int64_t *)(arg1 + 0x20);
                if (*(char *)(iVar3 + 0x59) == '\x02') {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(iVar14 + 1) = *(uint8_t *)(iVar14 + 1) & 0xfb;
                    *(undefined8 *)(iVar14 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                    *(int64_t *)(iVar3 + 0x18) = iVar14;
                }
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        iVar1 = *(int64_t *)(iVar1 + 0x10);
        iVar6 = iVar6 + 1;
    } while( true );
}

