// Chunk 15 - 50 functions

// ============================================================
// Function: FUN_180028940
// Address: 0x180028940
// Size: 122 bytes
// ============================================================
void fcn.180028940(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = auStack_28;
    uVar4 = *(uint64_t *)arg1;
    if (uVar4 != 0) {
        uVar3 = ((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 3) * 8;
        if (0xfff < uVar3) {
            puVar1 = (uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - *puVar1) - 8;
            if (uVar4 < 0x20) {
                uVar3 = uVar3 + 0x27;
                uVar4 = *puVar1;
                puVar5 = auStack_28;
            } else {
                pcVar2 = (code *)swi(0x29);
                uVar3 = (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x1800289a7;
        func_0x000180459c3c(uVar4, uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180028a80
// Address: 0x180028a80
// Size: 1152 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h

int64_t ** fcn.180028a80(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    code *pcVar8;
    uint64_t uVar9;
    int64_t **ppiVar10;
    uint64_t uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t **ppiVar15;
    undefined8 in_R8;
    undefined8 in_R9;
    float fVar16;
    float fVar17;
    int64_t var_48h;
    int64_t var_40h;
    
    uVar14 = (((((((((uint64_t)*(uint8_t *)arg2 ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 1)
                   ) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 2)) * 0x100000001b3 ^
                 (uint64_t)*(uint8_t *)(arg2 + 3)) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 4)) * 0x100000001b3 ^
               (uint64_t)*(uint8_t *)(arg2 + 5)) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 6)) * 0x100000001b3 ^
             (uint64_t)*(uint8_t *)(arg2 + 7)) * 0x100000001b3;
    ppiVar10 = *(int64_t ***)(*(int64_t *)0x1807820d8 + 8 + (uVar14 & *(uint64_t *)0x1807820f0) * 0x10);
    ppiVar15 = *(int64_t ***)0x1807820c8;
    if (ppiVar10 != *(int64_t ***)0x1807820c8) {
        piVar1 = ppiVar10[2];
        ppiVar15 = ppiVar10;
        while (ppiVar10 = ppiVar15, *(int64_t **)arg2 != piVar1) {
            if (ppiVar15 == *(int64_t ***)(*(int64_t *)0x1807820d8 + (uVar14 & *(uint64_t *)0x1807820f0) * 0x10))
            goto code_r0x000180028b4e;
            ppiVar15 = (int64_t **)ppiVar15[1];
            piVar1 = ppiVar15[2];
        }
        goto code_r0x000180028ed5;
    }
code_r0x000180028b4e:
    if (*(int64_t *)0x1807820d0 == 0x7ffffffffffffff) {
code_r0x000180028ef3:
        func_0x0001804546d4(0x180620428);
        pcVar8 = (code *)swi(3);
        ppiVar10 = (int64_t **)(*pcVar8)();
        return ppiVar10;
    }
    ppiVar10 = (int64_t **)func_0x000180459890(0x20, *(int64_t *)0x1807820d8, in_R8, in_R9, 0x1807820c8, 0);
    ppiVar10[2] = *(int64_t **)arg2;
    *(undefined4 *)(ppiVar10 + 3) = 0;
    uVar9 = *(uint64_t *)0x1807820f8;
    uVar11 = *(int64_t *)0x1807820d0 + 1;
    if ((int64_t)uVar11 < 0) {
        fVar16 = (float)(uVar11 >> 1 | (uint64_t)((uint32_t)uVar11 & 1));
        fVar16 = fVar16 + fVar16;
    } else {
        fVar16 = (float)uVar11;
    }
    if ((int64_t)*(uint64_t *)0x1807820f8 < 0) {
        fVar17 = (float)(*(uint64_t *)0x1807820f8 >> 1 | (uint64_t)((uint32_t)*(uint64_t *)0x1807820f8 & 1));
        fVar17 = fVar17 + fVar17;
    } else {
        fVar17 = (float)*(uint64_t *)0x1807820f8;
    }
    if (*(float *)0x1807820c0 < fVar16 / fVar17) {
        fVar16 = (float)func_0x000180471c90(fVar16 / *(float *)0x1807820c0);
        ppiVar15 = *(int64_t ***)0x1807820c8;
        iVar12 = 0;
        if ((9.223372e+18 <= fVar16) && (fVar16 = fVar16 - 9.223372e+18, fVar16 < 9.223372e+18)) {
            iVar12 = -0x8000000000000000;
        }
        uVar11 = 8;
        if (8 < (uint64_t)((int64_t)fVar16 + iVar12)) {
            uVar11 = (int64_t)fVar16 + iVar12;
        }
        uVar13 = uVar9;
        if ((uVar9 < uVar11) && ((0x1ff < uVar9 || (uVar13 = uVar9 * 8, uVar9 * 8 < uVar11)))) {
            uVar13 = uVar11;
        }
        for (iVar12 = 0x3f; 0xfffffffffffffffU >> iVar12 == 0; iVar12 = iVar12 + -1) {
        }
        if ((uint64_t)(1LL << ((uint8_t)iVar12 & 0x3f)) < uVar13) {
            func_0x0001804546d4(0x180620448);
            goto code_r0x000180028ef3;
        }
        uVar11 = uVar13 - 1 | 1;
        iVar12 = 0x3f;
        if (uVar11 != 0) {
            for (; uVar11 >> iVar12 == 0; iVar12 = iVar12 + -1) {
            }
        }
        uVar11 = 1LL << ((char)iVar12 + 1U & 0x3f);
        func_0x00018000f7e0(0x1807820d8, uVar11 * 2, *(int64_t ***)0x1807820c8);
        *(uint64_t *)0x1807820f0 = uVar11 - 1;
        *(uint64_t *)0x1807820f8 = uVar11;
        ppiVar7 = (int64_t **)**(int64_t ***)0x1807820c8;
        iVar12 = *(int64_t *)0x1807820d8;
joined_r0x000180028cdc:
        *(int64_t *)0x1807820d8 = iVar12;
        if (ppiVar7 != ppiVar15) {
            ppiVar2 = (int64_t **)*ppiVar7;
            uVar11 = (((((((((uint64_t)*(uint8_t *)(ppiVar7 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar7 + 0x11)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar7 + 0x12)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar7 + 0x13)) * 0x100000001b3 ^
                        (uint64_t)*(uint8_t *)((int64_t)ppiVar7 + 0x14)) * 0x100000001b3 ^
                       (uint64_t)*(uint8_t *)((int64_t)ppiVar7 + 0x15)) * 0x100000001b3 ^
                      (uint64_t)*(uint8_t *)((int64_t)ppiVar7 + 0x16)) * 0x100000001b3 ^
                     (uint64_t)*(uint8_t *)((int64_t)ppiVar7 + 0x17)) * 0x100000001b3 & *(uint64_t *)0x1807820f0;
            ppiVar3 = *(int64_t ***)(iVar12 + uVar11 * 0x10);
            if (ppiVar3 == ppiVar15) {
                *(int64_t ***)(iVar12 + uVar11 * 0x10) = ppiVar7;
                *(int64_t ***)(iVar12 + 8 + uVar11 * 0x10) = ppiVar7;
                ppiVar7 = ppiVar2;
                iVar12 = *(int64_t *)0x1807820d8;
            } else {
                ppiVar4 = *(int64_t ***)(iVar12 + 8 + uVar11 * 0x10);
                if (ppiVar7[2] == ppiVar4[2]) {
                    ppiVar4 = (int64_t **)*ppiVar4;
                    if (ppiVar4 != ppiVar7) {
                        ppiVar3 = (int64_t **)ppiVar7[1];
                        *ppiVar3 = (int64_t *)ppiVar2;
                        ppiVar5 = (int64_t **)ppiVar2[1];
                        *ppiVar5 = (int64_t *)ppiVar4;
                        ppiVar6 = (int64_t **)ppiVar4[1];
                        *ppiVar6 = (int64_t *)ppiVar7;
                        ppiVar4[1] = (int64_t *)ppiVar5;
                        ppiVar2[1] = (int64_t *)ppiVar3;
                        ppiVar7[1] = (int64_t *)ppiVar6;
                    }
                    *(int64_t ***)(iVar12 + 8 + uVar11 * 0x10) = ppiVar7;
                    ppiVar7 = ppiVar2;
                    iVar12 = *(int64_t *)0x1807820d8;
                } else {
                    do {
                        if (ppiVar3 == ppiVar4) {
                            ppiVar3 = (int64_t **)ppiVar7[1];
                            *ppiVar3 = (int64_t *)ppiVar2;
                            piVar1 = ppiVar2[1];
                            *piVar1 = (int64_t)ppiVar4;
                            ppiVar5 = (int64_t **)ppiVar4[1];
                            *ppiVar5 = (int64_t *)ppiVar7;
                            ppiVar4[1] = piVar1;
                            ppiVar2[1] = (int64_t *)ppiVar3;
                            ppiVar7[1] = (int64_t *)ppiVar5;
                            *(int64_t ***)(iVar12 + uVar11 * 0x10) = ppiVar7;
                            ppiVar7 = ppiVar2;
                            iVar12 = *(int64_t *)0x1807820d8;
                            goto joined_r0x000180028cdc;
                        }
                        ppiVar4 = (int64_t **)ppiVar4[1];
                    } while (ppiVar7[2] != ppiVar4[2]);
                    iVar12 = (int64_t)*ppiVar4;
                    ppiVar3 = (int64_t **)ppiVar7[1];
                    *ppiVar3 = (int64_t *)ppiVar2;
                    piVar1 = ppiVar2[1];
                    *piVar1 = iVar12;
                    ppiVar4 = *(int64_t ***)(iVar12 + 8);
                    *ppiVar4 = (int64_t *)ppiVar7;
                    *(int64_t **)(iVar12 + 8) = piVar1;
                    ppiVar2[1] = (int64_t *)ppiVar3;
                    ppiVar7[1] = (int64_t *)ppiVar4;
                    ppiVar7 = ppiVar2;
                    iVar12 = *(int64_t *)0x1807820d8;
                }
            }
            goto joined_r0x000180028cdc;
        }
        ppiVar7 = *(int64_t ***)(iVar12 + 8 + (*(uint64_t *)0x1807820f0 & uVar14) * 0x10);
        ppiVar15 = *(int64_t ***)0x1807820c8;
        if (ppiVar7 != *(int64_t ***)0x1807820c8) {
            piVar1 = ppiVar7[2];
            ppiVar15 = ppiVar7;
            while (ppiVar10[2] != piVar1) {
                if (ppiVar15 == *(int64_t ***)(iVar12 + (*(uint64_t *)0x1807820f0 & uVar14) * 0x10))
                goto code_r0x000180028e4d;
                ppiVar15 = (int64_t **)ppiVar15[1];
                piVar1 = ppiVar15[2];
            }
            ppiVar15 = (int64_t **)*ppiVar15;
        }
    }
code_r0x000180028e4d:
    piVar1 = ppiVar15[1];
    *(int64_t *)0x1807820d0 = *(int64_t *)0x1807820d0 + 1;
    *ppiVar10 = (int64_t *)ppiVar15;
    ppiVar10[1] = piVar1;
    *piVar1 = (int64_t)ppiVar10;
    ppiVar15[1] = (int64_t *)ppiVar10;
    iVar12 = *(int64_t *)0x1807820d8;
    uVar14 = *(uint64_t *)0x1807820f0 & uVar14;
    ppiVar7 = *(int64_t ***)(*(int64_t *)0x1807820d8 + uVar14 * 0x10);
    if (ppiVar7 == *(int64_t ***)0x1807820c8) {
        *(int64_t ***)(*(int64_t *)0x1807820d8 + uVar14 * 0x10) = ppiVar10;
    } else {
        if (ppiVar7 == ppiVar15) {
            *(int64_t ***)(*(int64_t *)0x1807820d8 + uVar14 * 0x10) = ppiVar10;
            goto code_r0x000180028ed5;
        }
        if (*(int64_t **)(*(int64_t *)0x1807820d8 + 8 + uVar14 * 0x10) != piVar1) goto code_r0x000180028ed5;
    }
    *(int64_t ***)(iVar12 + 8 + uVar14 * 0x10) = ppiVar10;
code_r0x000180028ed5:
    return ppiVar10 + 3;
}

// ============================================================
// Function: FUN_180028fc0
// Address: 0x180028fc0
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h

void fcn.180028fc0(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t **ppiStackX_10;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar2 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar3 = (int64_t **)*ppiVar2;
            if (ppiVar3 != ppiVar2) {
                iStackX_18 = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar3[1];
                iVar6 = ((((((((((uint64_t)*(uint8_t *)(ppiVar3 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30))
                        * 0x10;
                var_8h = *(int64_t *)(iVar6 + iStackX_18);
                ppiVar1 = (int64_t **)(iVar6 + iStackX_18);
                ppiStackX_10 = (int64_t **)(iVar6 + 8 + iStackX_18);
                ppiVar5 = (int64_t **)*ppiStackX_10;
                ppiVar8 = ppiVar3;
                do {
                    ppiVar9 = (int64_t **)*ppiVar8;
                    fcn.180459c3c(ppiVar8, 0x18);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar5) {
                        ppiVar5 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar3) {
                            *ppiVar1 = (int64_t *)ppiVar2;
                            ppiVar5 = ppiVar2;
                        }
                        *ppiStackX_10 = (int64_t *)ppiVar5;
                        while (ppiVar9 != ppiVar2) {
                            uVar7 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                                    (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 &
                                    *(uint64_t *)(arg1 + 0x30);
                            ppiVar1 = *(int64_t ***)(iStackX_18 + 8 + uVar7 * 0x10);
                            iVar6 = iStackX_18 + uVar7 * 0x10;
                            ppiVar3 = (int64_t **)(iStackX_18 + uVar7 * 0x10);
                            ppiVar5 = ppiVar9;
                            while( true ) {
                                ppiVar9 = (int64_t **)*ppiVar5;
                                fcn.180459c3c(ppiVar5, 0x18);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar5 == ppiVar1) break;
                                ppiVar5 = ppiVar9;
                                if (ppiVar9 == ppiVar2) {
                                    *ppiVar3 = (int64_t *)ppiVar9;
                                    goto code_r0x0001800290ec;
                                }
                            }
                            *ppiVar3 = (int64_t *)ppiVar2;
                            *(int64_t ***)(iVar6 + 8) = ppiVar2;
                        }
                        goto code_r0x0001800290ec;
                    }
                    ppiVar8 = ppiVar9;
                } while (ppiVar9 != ppiVar2);
                if ((int64_t **)var_8h == ppiVar3) {
                    *ppiVar1 = (int64_t *)ppiVar9;
                }
code_r0x0001800290ec:
                *ppiVar4 = (int64_t *)ppiVar9;
                ppiVar9[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar2[1] = 0;
            ppiVar2 = (int64_t **)*ppiVar2;
            while (ppiVar2 != (int64_t **)0x0) {
                ppiVar3 = (int64_t **)*ppiVar2;
                fcn.180459c3c(ppiVar2, 0x18);
                ppiVar2 = ppiVar3;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180028fdc
// Address: 0x180028fdc
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h

void fcn.180028fc0(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t **ppiStackX_10;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar2 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar3 = (int64_t **)*ppiVar2;
            if (ppiVar3 != ppiVar2) {
                iStackX_18 = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar3[1];
                iVar6 = ((((((((((uint64_t)*(uint8_t *)(ppiVar3 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30))
                        * 0x10;
                var_8h = *(int64_t *)(iVar6 + iStackX_18);
                ppiVar1 = (int64_t **)(iVar6 + iStackX_18);
                ppiStackX_10 = (int64_t **)(iVar6 + 8 + iStackX_18);
                ppiVar5 = (int64_t **)*ppiStackX_10;
                ppiVar8 = ppiVar3;
                do {
                    ppiVar9 = (int64_t **)*ppiVar8;
                    fcn.180459c3c(ppiVar8, 0x18);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar5) {
                        ppiVar5 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar3) {
                            *ppiVar1 = (int64_t *)ppiVar2;
                            ppiVar5 = ppiVar2;
                        }
                        *ppiStackX_10 = (int64_t *)ppiVar5;
                        while (ppiVar9 != ppiVar2) {
                            uVar7 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                                    (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 &
                                    *(uint64_t *)(arg1 + 0x30);
                            ppiVar1 = *(int64_t ***)(iStackX_18 + 8 + uVar7 * 0x10);
                            iVar6 = iStackX_18 + uVar7 * 0x10;
                            ppiVar3 = (int64_t **)(iStackX_18 + uVar7 * 0x10);
                            ppiVar5 = ppiVar9;
                            while( true ) {
                                ppiVar9 = (int64_t **)*ppiVar5;
                                fcn.180459c3c(ppiVar5, 0x18);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar5 == ppiVar1) break;
                                ppiVar5 = ppiVar9;
                                if (ppiVar9 == ppiVar2) {
                                    *ppiVar3 = (int64_t *)ppiVar9;
                                    goto code_r0x0001800290ec;
                                }
                            }
                            *ppiVar3 = (int64_t *)ppiVar2;
                            *(int64_t ***)(iVar6 + 8) = ppiVar2;
                        }
                        goto code_r0x0001800290ec;
                    }
                    ppiVar8 = ppiVar9;
                } while (ppiVar9 != ppiVar2);
                if ((int64_t **)var_8h == ppiVar3) {
                    *ppiVar1 = (int64_t *)ppiVar9;
                }
code_r0x0001800290ec:
                *ppiVar4 = (int64_t *)ppiVar9;
                ppiVar9[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar2[1] = 0;
            ppiVar2 = (int64_t **)*ppiVar2;
            while (ppiVar2 != (int64_t **)0x0) {
                ppiVar3 = (int64_t **)*ppiVar2;
                fcn.180459c3c(ppiVar2, 0x18);
                ppiVar2 = ppiVar3;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180028ff9
// Address: 0x180028ff9
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h

void fcn.180028fc0(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t **ppiStackX_10;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar2 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar3 = (int64_t **)*ppiVar2;
            if (ppiVar3 != ppiVar2) {
                iStackX_18 = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar3[1];
                iVar6 = ((((((((((uint64_t)*(uint8_t *)(ppiVar3 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30))
                        * 0x10;
                var_8h = *(int64_t *)(iVar6 + iStackX_18);
                ppiVar1 = (int64_t **)(iVar6 + iStackX_18);
                ppiStackX_10 = (int64_t **)(iVar6 + 8 + iStackX_18);
                ppiVar5 = (int64_t **)*ppiStackX_10;
                ppiVar8 = ppiVar3;
                do {
                    ppiVar9 = (int64_t **)*ppiVar8;
                    fcn.180459c3c(ppiVar8, 0x18);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar5) {
                        ppiVar5 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar3) {
                            *ppiVar1 = (int64_t *)ppiVar2;
                            ppiVar5 = ppiVar2;
                        }
                        *ppiStackX_10 = (int64_t *)ppiVar5;
                        while (ppiVar9 != ppiVar2) {
                            uVar7 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                                    (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 &
                                    *(uint64_t *)(arg1 + 0x30);
                            ppiVar1 = *(int64_t ***)(iStackX_18 + 8 + uVar7 * 0x10);
                            iVar6 = iStackX_18 + uVar7 * 0x10;
                            ppiVar3 = (int64_t **)(iStackX_18 + uVar7 * 0x10);
                            ppiVar5 = ppiVar9;
                            while( true ) {
                                ppiVar9 = (int64_t **)*ppiVar5;
                                fcn.180459c3c(ppiVar5, 0x18);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar5 == ppiVar1) break;
                                ppiVar5 = ppiVar9;
                                if (ppiVar9 == ppiVar2) {
                                    *ppiVar3 = (int64_t *)ppiVar9;
                                    goto code_r0x0001800290ec;
                                }
                            }
                            *ppiVar3 = (int64_t *)ppiVar2;
                            *(int64_t ***)(iVar6 + 8) = ppiVar2;
                        }
                        goto code_r0x0001800290ec;
                    }
                    ppiVar8 = ppiVar9;
                } while (ppiVar9 != ppiVar2);
                if ((int64_t **)var_8h == ppiVar3) {
                    *ppiVar1 = (int64_t *)ppiVar9;
                }
code_r0x0001800290ec:
                *ppiVar4 = (int64_t *)ppiVar9;
                ppiVar9[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar2[1] = 0;
            ppiVar2 = (int64_t **)*ppiVar2;
            while (ppiVar2 != (int64_t **)0x0) {
                ppiVar3 = (int64_t **)*ppiVar2;
                fcn.180459c3c(ppiVar2, 0x18);
                ppiVar2 = ppiVar3;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180029028
// Address: 0x180029028
// Size: 218 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h

void fcn.180028fc0(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t **ppiStackX_10;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar2 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar3 = (int64_t **)*ppiVar2;
            if (ppiVar3 != ppiVar2) {
                iStackX_18 = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar3[1];
                iVar6 = ((((((((((uint64_t)*(uint8_t *)(ppiVar3 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30))
                        * 0x10;
                var_8h = *(int64_t *)(iVar6 + iStackX_18);
                ppiVar1 = (int64_t **)(iVar6 + iStackX_18);
                ppiStackX_10 = (int64_t **)(iVar6 + 8 + iStackX_18);
                ppiVar5 = (int64_t **)*ppiStackX_10;
                ppiVar8 = ppiVar3;
                do {
                    ppiVar9 = (int64_t **)*ppiVar8;
                    fcn.180459c3c(ppiVar8, 0x18);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar5) {
                        ppiVar5 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar3) {
                            *ppiVar1 = (int64_t *)ppiVar2;
                            ppiVar5 = ppiVar2;
                        }
                        *ppiStackX_10 = (int64_t *)ppiVar5;
                        while (ppiVar9 != ppiVar2) {
                            uVar7 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                                    (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 &
                                    *(uint64_t *)(arg1 + 0x30);
                            ppiVar1 = *(int64_t ***)(iStackX_18 + 8 + uVar7 * 0x10);
                            iVar6 = iStackX_18 + uVar7 * 0x10;
                            ppiVar3 = (int64_t **)(iStackX_18 + uVar7 * 0x10);
                            ppiVar5 = ppiVar9;
                            while( true ) {
                                ppiVar9 = (int64_t **)*ppiVar5;
                                fcn.180459c3c(ppiVar5, 0x18);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar5 == ppiVar1) break;
                                ppiVar5 = ppiVar9;
                                if (ppiVar9 == ppiVar2) {
                                    *ppiVar3 = (int64_t *)ppiVar9;
                                    goto code_r0x0001800290ec;
                                }
                            }
                            *ppiVar3 = (int64_t *)ppiVar2;
                            *(int64_t ***)(iVar6 + 8) = ppiVar2;
                        }
                        goto code_r0x0001800290ec;
                    }
                    ppiVar8 = ppiVar9;
                } while (ppiVar9 != ppiVar2);
                if ((int64_t **)var_8h == ppiVar3) {
                    *ppiVar1 = (int64_t *)ppiVar9;
                }
code_r0x0001800290ec:
                *ppiVar4 = (int64_t *)ppiVar9;
                ppiVar9[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar2[1] = 0;
            ppiVar2 = (int64_t **)*ppiVar2;
            while (ppiVar2 != (int64_t **)0x0) {
                ppiVar3 = (int64_t **)*ppiVar2;
                fcn.180459c3c(ppiVar2, 0x18);
                ppiVar2 = ppiVar3;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180029102
// Address: 0x180029102
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h

void fcn.180028fc0(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t **ppiStackX_10;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar2 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar3 = (int64_t **)*ppiVar2;
            if (ppiVar3 != ppiVar2) {
                iStackX_18 = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar3[1];
                iVar6 = ((((((((((uint64_t)*(uint8_t *)(ppiVar3 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30))
                        * 0x10;
                var_8h = *(int64_t *)(iVar6 + iStackX_18);
                ppiVar1 = (int64_t **)(iVar6 + iStackX_18);
                ppiStackX_10 = (int64_t **)(iVar6 + 8 + iStackX_18);
                ppiVar5 = (int64_t **)*ppiStackX_10;
                ppiVar8 = ppiVar3;
                do {
                    ppiVar9 = (int64_t **)*ppiVar8;
                    fcn.180459c3c(ppiVar8, 0x18);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar5) {
                        ppiVar5 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar3) {
                            *ppiVar1 = (int64_t *)ppiVar2;
                            ppiVar5 = ppiVar2;
                        }
                        *ppiStackX_10 = (int64_t *)ppiVar5;
                        while (ppiVar9 != ppiVar2) {
                            uVar7 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                                    (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 &
                                    *(uint64_t *)(arg1 + 0x30);
                            ppiVar1 = *(int64_t ***)(iStackX_18 + 8 + uVar7 * 0x10);
                            iVar6 = iStackX_18 + uVar7 * 0x10;
                            ppiVar3 = (int64_t **)(iStackX_18 + uVar7 * 0x10);
                            ppiVar5 = ppiVar9;
                            while( true ) {
                                ppiVar9 = (int64_t **)*ppiVar5;
                                fcn.180459c3c(ppiVar5, 0x18);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar5 == ppiVar1) break;
                                ppiVar5 = ppiVar9;
                                if (ppiVar9 == ppiVar2) {
                                    *ppiVar3 = (int64_t *)ppiVar9;
                                    goto code_r0x0001800290ec;
                                }
                            }
                            *ppiVar3 = (int64_t *)ppiVar2;
                            *(int64_t ***)(iVar6 + 8) = ppiVar2;
                        }
                        goto code_r0x0001800290ec;
                    }
                    ppiVar8 = ppiVar9;
                } while (ppiVar9 != ppiVar2);
                if ((int64_t **)var_8h == ppiVar3) {
                    *ppiVar1 = (int64_t *)ppiVar9;
                }
code_r0x0001800290ec:
                *ppiVar4 = (int64_t *)ppiVar9;
                ppiVar9[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar2[1] = 0;
            ppiVar2 = (int64_t **)*ppiVar2;
            while (ppiVar2 != (int64_t **)0x0) {
                ppiVar3 = (int64_t **)*ppiVar2;
                fcn.180459c3c(ppiVar2, 0x18);
                ppiVar2 = ppiVar3;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180029107
// Address: 0x180029107
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h

void fcn.180028fc0(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t **ppiStackX_10;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar2 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar3 = (int64_t **)*ppiVar2;
            if (ppiVar3 != ppiVar2) {
                iStackX_18 = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar3[1];
                iVar6 = ((((((((((uint64_t)*(uint8_t *)(ppiVar3 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30))
                        * 0x10;
                var_8h = *(int64_t *)(iVar6 + iStackX_18);
                ppiVar1 = (int64_t **)(iVar6 + iStackX_18);
                ppiStackX_10 = (int64_t **)(iVar6 + 8 + iStackX_18);
                ppiVar5 = (int64_t **)*ppiStackX_10;
                ppiVar8 = ppiVar3;
                do {
                    ppiVar9 = (int64_t **)*ppiVar8;
                    fcn.180459c3c(ppiVar8, 0x18);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar5) {
                        ppiVar5 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar3) {
                            *ppiVar1 = (int64_t *)ppiVar2;
                            ppiVar5 = ppiVar2;
                        }
                        *ppiStackX_10 = (int64_t *)ppiVar5;
                        while (ppiVar9 != ppiVar2) {
                            uVar7 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                                    (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 &
                                    *(uint64_t *)(arg1 + 0x30);
                            ppiVar1 = *(int64_t ***)(iStackX_18 + 8 + uVar7 * 0x10);
                            iVar6 = iStackX_18 + uVar7 * 0x10;
                            ppiVar3 = (int64_t **)(iStackX_18 + uVar7 * 0x10);
                            ppiVar5 = ppiVar9;
                            while( true ) {
                                ppiVar9 = (int64_t **)*ppiVar5;
                                fcn.180459c3c(ppiVar5, 0x18);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar5 == ppiVar1) break;
                                ppiVar5 = ppiVar9;
                                if (ppiVar9 == ppiVar2) {
                                    *ppiVar3 = (int64_t *)ppiVar9;
                                    goto code_r0x0001800290ec;
                                }
                            }
                            *ppiVar3 = (int64_t *)ppiVar2;
                            *(int64_t ***)(iVar6 + 8) = ppiVar2;
                        }
                        goto code_r0x0001800290ec;
                    }
                    ppiVar8 = ppiVar9;
                } while (ppiVar9 != ppiVar2);
                if ((int64_t **)var_8h == ppiVar3) {
                    *ppiVar1 = (int64_t *)ppiVar9;
                }
code_r0x0001800290ec:
                *ppiVar4 = (int64_t *)ppiVar9;
                ppiVar9[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar2[1] = 0;
            ppiVar2 = (int64_t **)*ppiVar2;
            while (ppiVar2 != (int64_t **)0x0) {
                ppiVar3 = (int64_t **)*ppiVar2;
                fcn.180459c3c(ppiVar2, 0x18);
                ppiVar2 = ppiVar3;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180029116
// Address: 0x180029116
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h

void fcn.180028fc0(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t **ppiStackX_10;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar2 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar3 = (int64_t **)*ppiVar2;
            if (ppiVar3 != ppiVar2) {
                iStackX_18 = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar3[1];
                iVar6 = ((((((((((uint64_t)*(uint8_t *)(ppiVar3 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30))
                        * 0x10;
                var_8h = *(int64_t *)(iVar6 + iStackX_18);
                ppiVar1 = (int64_t **)(iVar6 + iStackX_18);
                ppiStackX_10 = (int64_t **)(iVar6 + 8 + iStackX_18);
                ppiVar5 = (int64_t **)*ppiStackX_10;
                ppiVar8 = ppiVar3;
                do {
                    ppiVar9 = (int64_t **)*ppiVar8;
                    fcn.180459c3c(ppiVar8, 0x18);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar5) {
                        ppiVar5 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar3) {
                            *ppiVar1 = (int64_t *)ppiVar2;
                            ppiVar5 = ppiVar2;
                        }
                        *ppiStackX_10 = (int64_t *)ppiVar5;
                        while (ppiVar9 != ppiVar2) {
                            uVar7 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                                    (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 &
                                    *(uint64_t *)(arg1 + 0x30);
                            ppiVar1 = *(int64_t ***)(iStackX_18 + 8 + uVar7 * 0x10);
                            iVar6 = iStackX_18 + uVar7 * 0x10;
                            ppiVar3 = (int64_t **)(iStackX_18 + uVar7 * 0x10);
                            ppiVar5 = ppiVar9;
                            while( true ) {
                                ppiVar9 = (int64_t **)*ppiVar5;
                                fcn.180459c3c(ppiVar5, 0x18);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar5 == ppiVar1) break;
                                ppiVar5 = ppiVar9;
                                if (ppiVar9 == ppiVar2) {
                                    *ppiVar3 = (int64_t *)ppiVar9;
                                    goto code_r0x0001800290ec;
                                }
                            }
                            *ppiVar3 = (int64_t *)ppiVar2;
                            *(int64_t ***)(iVar6 + 8) = ppiVar2;
                        }
                        goto code_r0x0001800290ec;
                    }
                    ppiVar8 = ppiVar9;
                } while (ppiVar9 != ppiVar2);
                if ((int64_t **)var_8h == ppiVar3) {
                    *ppiVar1 = (int64_t *)ppiVar9;
                }
code_r0x0001800290ec:
                *ppiVar4 = (int64_t *)ppiVar9;
                ppiVar9[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar2[1] = 0;
            ppiVar2 = (int64_t **)*ppiVar2;
            while (ppiVar2 != (int64_t **)0x0) {
                ppiVar3 = (int64_t **)*ppiVar2;
                fcn.180459c3c(ppiVar2, 0x18);
                ppiVar2 = ppiVar3;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18002911c
// Address: 0x18002911c
// Size: 244 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h

void fcn.180028fc0(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t **ppiStackX_10;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar2 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar3 = (int64_t **)*ppiVar2;
            if (ppiVar3 != ppiVar2) {
                iStackX_18 = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar3[1];
                iVar6 = ((((((((((uint64_t)*(uint8_t *)(ppiVar3 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30))
                        * 0x10;
                var_8h = *(int64_t *)(iVar6 + iStackX_18);
                ppiVar1 = (int64_t **)(iVar6 + iStackX_18);
                ppiStackX_10 = (int64_t **)(iVar6 + 8 + iStackX_18);
                ppiVar5 = (int64_t **)*ppiStackX_10;
                ppiVar8 = ppiVar3;
                do {
                    ppiVar9 = (int64_t **)*ppiVar8;
                    fcn.180459c3c(ppiVar8, 0x18);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar5) {
                        ppiVar5 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar3) {
                            *ppiVar1 = (int64_t *)ppiVar2;
                            ppiVar5 = ppiVar2;
                        }
                        *ppiStackX_10 = (int64_t *)ppiVar5;
                        while (ppiVar9 != ppiVar2) {
                            uVar7 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                                    (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 &
                                    *(uint64_t *)(arg1 + 0x30);
                            ppiVar1 = *(int64_t ***)(iStackX_18 + 8 + uVar7 * 0x10);
                            iVar6 = iStackX_18 + uVar7 * 0x10;
                            ppiVar3 = (int64_t **)(iStackX_18 + uVar7 * 0x10);
                            ppiVar5 = ppiVar9;
                            while( true ) {
                                ppiVar9 = (int64_t **)*ppiVar5;
                                fcn.180459c3c(ppiVar5, 0x18);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar5 == ppiVar1) break;
                                ppiVar5 = ppiVar9;
                                if (ppiVar9 == ppiVar2) {
                                    *ppiVar3 = (int64_t *)ppiVar9;
                                    goto code_r0x0001800290ec;
                                }
                            }
                            *ppiVar3 = (int64_t *)ppiVar2;
                            *(int64_t ***)(iVar6 + 8) = ppiVar2;
                        }
                        goto code_r0x0001800290ec;
                    }
                    ppiVar8 = ppiVar9;
                } while (ppiVar9 != ppiVar2);
                if ((int64_t **)var_8h == ppiVar3) {
                    *ppiVar1 = (int64_t *)ppiVar9;
                }
code_r0x0001800290ec:
                *ppiVar4 = (int64_t *)ppiVar9;
                ppiVar9[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar2[1] = 0;
            ppiVar2 = (int64_t **)*ppiVar2;
            while (ppiVar2 != (int64_t **)0x0) {
                ppiVar3 = (int64_t **)*ppiVar2;
                fcn.180459c3c(ppiVar2, 0x18);
                ppiVar2 = ppiVar3;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180029210
// Address: 0x180029210
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_47h
// WARNING: [rz-ghidra] Detected overlap for variable var_46h
// WARNING: [rz-ghidra] Detected overlap for variable var_45h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_42h
// WARNING: [rz-ghidra] Detected overlap for variable var_41h

void fcn.180028fc0(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t var_8h;
    int64_t **ppiStackX_10;
    int64_t iStackX_18;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    if (*(uint64_t *)(arg1 + 0x10) != 0) {
        ppiVar2 = *(int64_t ***)(arg1 + 8);
        if (*(uint64_t *)(arg1 + 0x10) < *(uint64_t *)(arg1 + 0x38) >> 3) {
            ppiVar3 = (int64_t **)*ppiVar2;
            if (ppiVar3 != ppiVar2) {
                iStackX_18 = *(int64_t *)(arg1 + 0x18);
                ppiVar4 = (int64_t **)ppiVar3[1];
                iVar6 = ((((((((((uint64_t)*(uint8_t *)(ppiVar3 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar3 + 0x17)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30))
                        * 0x10;
                var_8h = *(int64_t *)(iVar6 + iStackX_18);
                ppiVar1 = (int64_t **)(iVar6 + iStackX_18);
                ppiStackX_10 = (int64_t **)(iVar6 + 8 + iStackX_18);
                ppiVar5 = (int64_t **)*ppiStackX_10;
                ppiVar8 = ppiVar3;
                do {
                    ppiVar9 = (int64_t **)*ppiVar8;
                    fcn.180459c3c(ppiVar8, 0x18);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar8 == ppiVar5) {
                        ppiVar5 = ppiVar4;
                        if ((int64_t **)var_8h == ppiVar3) {
                            *ppiVar1 = (int64_t *)ppiVar2;
                            ppiVar5 = ppiVar2;
                        }
                        *ppiStackX_10 = (int64_t *)ppiVar5;
                        while (ppiVar9 != ppiVar2) {
                            uVar7 = (((((((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                                          (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                                         (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                                        (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 ^
                                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x14)) * 0x100000001b3 ^
                                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x15)) * 0x100000001b3 ^
                                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x16)) * 0x100000001b3 ^
                                    (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x17)) * 0x100000001b3 &
                                    *(uint64_t *)(arg1 + 0x30);
                            ppiVar1 = *(int64_t ***)(iStackX_18 + 8 + uVar7 * 0x10);
                            iVar6 = iStackX_18 + uVar7 * 0x10;
                            ppiVar3 = (int64_t **)(iStackX_18 + uVar7 * 0x10);
                            ppiVar5 = ppiVar9;
                            while( true ) {
                                ppiVar9 = (int64_t **)*ppiVar5;
                                fcn.180459c3c(ppiVar5, 0x18);
                                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                                if (ppiVar5 == ppiVar1) break;
                                ppiVar5 = ppiVar9;
                                if (ppiVar9 == ppiVar2) {
                                    *ppiVar3 = (int64_t *)ppiVar9;
                                    goto code_r0x0001800290ec;
                                }
                            }
                            *ppiVar3 = (int64_t *)ppiVar2;
                            *(int64_t ***)(iVar6 + 8) = ppiVar2;
                        }
                        goto code_r0x0001800290ec;
                    }
                    ppiVar8 = ppiVar9;
                } while (ppiVar9 != ppiVar2);
                if ((int64_t **)var_8h == ppiVar3) {
                    *ppiVar1 = (int64_t *)ppiVar9;
                }
code_r0x0001800290ec:
                *ppiVar4 = (int64_t *)ppiVar9;
                ppiVar9[1] = (int64_t *)ppiVar4;
                return;
            }
        } else {
            *ppiVar2[1] = 0;
            ppiVar2 = (int64_t **)*ppiVar2;
            while (ppiVar2 != (int64_t **)0x0) {
                ppiVar3 = (int64_t **)*ppiVar2;
                fcn.180459c3c(ppiVar2, 0x18);
                ppiVar2 = ppiVar3;
            }
            *(undefined8 *)*(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg1 + 8);
            *(int64_t *)(*(int64_t *)(arg1 + 8) + 8) = *(int64_t *)(arg1 + 8);
            *(undefined8 *)(arg1 + 0x10) = 0;
            var_8h = *(int64_t *)(arg1 + 8);
            fcn.18000d540(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20), &var_8h);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180029270
// Address: 0x180029270
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180029270(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined *puVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined *puVar7;
    uint64_t uVar8;
    undefined *puVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    int64_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    undefined auStack_38 [32];
    
    puVar9 = auStack_38;
    puVar7 = *(undefined **)(arg1 + 8);
    if (puVar7 != *(undefined **)(arg1 + 0x10)) {
        *puVar7 = *(undefined *)arg2;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 1;
        return;
    }
    uVar8 = 0x7fffffffffffffff;
    iVar12 = (int64_t)puVar7 - *(int64_t *)arg1;
    if (iVar12 == 0x7fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (int64_t)*(undefined **)(arg1 + 0x10) - *(int64_t *)arg1;
    uVar6 = uVar5 >> 1;
    uVar1 = iVar12 + 1;
    if (uVar5 <= 0x7fffffffffffffff - uVar6) goto code_r0x000180029302;
    uVar5 = 0x8000000000000026;
    puVar9 = auStack_38;
    do {
        *(undefined8 *)(puVar9 + -8) = 0x1800292f6;
        iVar4 = fcn.180459890(uVar5);
        if (iVar4 != 0) {
            uVar5 = iVar4 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar5 - 8) = iVar4;
code_r0x00018002934a:
            *(undefined *)(iVar12 + uVar5) = *(undefined *)arg2;
            puVar2 = *(undefined **)arg1;
            if (puVar7 == *(undefined **)(arg1 + 8)) {
                iVar4 = (int64_t)*(undefined **)(arg1 + 8) - (int64_t)puVar2;
                uVar6 = uVar5;
                puVar7 = puVar2;
            } else {
                *(undefined8 *)(puVar9 + -8) = 0x180029371;
                fcn.180498030(uVar5, puVar2, (int64_t)puVar7 - (int64_t)puVar2);
                iVar4 = *(int64_t *)(arg1 + 8) - (int64_t)puVar7;
                uVar6 = iVar12 + 1 + uVar5;
            }
            *(undefined8 *)(puVar9 + -8) = 0x180029387;
            fcn.180498030(uVar6, puVar7, iVar4);
            uVar11 = *(undefined8 *)(puVar9 + 0x28);
            uVar10 = *(undefined8 *)(puVar9 + 0x30);
            *(undefined8 *)(puVar9 + 0x30) = *(undefined8 *)(puVar9 + 0x40);
            *(undefined8 *)(puVar9 + 0x28) = uVar10;
            *(undefined8 *)(puVar9 + 0x20) = *(undefined8 *)(puVar9 + 0x48);
            *(undefined8 *)(puVar9 + 0x18) = uVar11;
            iVar12 = *(int64_t *)arg1;
            if (iVar12 != 0) {
                iVar4 = iVar12;
                puVar7 = puVar9 + -0x10;
                if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar12)) &&
                   (iVar4 = *(int64_t *)(iVar12 + -8), puVar7 = puVar9 + -0x10, 0x1f < (iVar12 - iVar4) - 8U)) {
                    pcVar3 = (code *)swi(0x29);
                    iVar4 = (*pcVar3)(5);
                    puVar7 = puVar9 + -8;
                }
                *(undefined8 *)(puVar7 + -8) = 0x18002a243;
                fcn.180459c3c(iVar4);
            }
            *(uint64_t *)arg1 = uVar5;
            *(uint64_t *)(arg1 + 8) = uVar5 + uVar1;
            *(uint64_t *)(arg1 + 0x10) = uVar5 + uVar8;
            return;
        }
        uVar5 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)();
        puVar9 = puVar9 + 8;
code_r0x000180029302:
        uVar8 = uVar1;
        if (uVar1 <= uVar5 + uVar6) {
            uVar8 = uVar5 + uVar6;
        }
        if (uVar8 == 0) {
            uVar5 = 0;
            goto code_r0x00018002934a;
        }
        if (uVar8 < 0x1000) {
            *(undefined8 *)(puVar9 + -8) = 0x180029347;
            uVar5 = fcn.180459890(uVar8);
            goto code_r0x00018002934a;
        }
        uVar5 = uVar8 + 0x27;
        if (uVar5 <= uVar8) {
            *(undefined8 *)(puVar9 + -8) = 0x1800293bf;
            fcn.180004720();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800292a2
// Address: 0x1800292a2
// Size: 274 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180029270(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined *puVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined *puVar7;
    uint64_t uVar8;
    undefined *puVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    int64_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    undefined auStack_38 [32];
    
    puVar9 = auStack_38;
    puVar7 = *(undefined **)(arg1 + 8);
    if (puVar7 != *(undefined **)(arg1 + 0x10)) {
        *puVar7 = *(undefined *)arg2;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 1;
        return;
    }
    uVar8 = 0x7fffffffffffffff;
    iVar12 = (int64_t)puVar7 - *(int64_t *)arg1;
    if (iVar12 == 0x7fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (int64_t)*(undefined **)(arg1 + 0x10) - *(int64_t *)arg1;
    uVar6 = uVar5 >> 1;
    uVar1 = iVar12 + 1;
    if (uVar5 <= 0x7fffffffffffffff - uVar6) goto code_r0x000180029302;
    uVar5 = 0x8000000000000026;
    puVar9 = auStack_38;
    do {
        *(undefined8 *)(puVar9 + -8) = 0x1800292f6;
        iVar4 = fcn.180459890(uVar5);
        if (iVar4 != 0) {
            uVar5 = iVar4 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar5 - 8) = iVar4;
code_r0x00018002934a:
            *(undefined *)(iVar12 + uVar5) = *(undefined *)arg2;
            puVar2 = *(undefined **)arg1;
            if (puVar7 == *(undefined **)(arg1 + 8)) {
                iVar4 = (int64_t)*(undefined **)(arg1 + 8) - (int64_t)puVar2;
                uVar6 = uVar5;
                puVar7 = puVar2;
            } else {
                *(undefined8 *)(puVar9 + -8) = 0x180029371;
                fcn.180498030(uVar5, puVar2, (int64_t)puVar7 - (int64_t)puVar2);
                iVar4 = *(int64_t *)(arg1 + 8) - (int64_t)puVar7;
                uVar6 = iVar12 + 1 + uVar5;
            }
            *(undefined8 *)(puVar9 + -8) = 0x180029387;
            fcn.180498030(uVar6, puVar7, iVar4);
            uVar11 = *(undefined8 *)(puVar9 + 0x28);
            uVar10 = *(undefined8 *)(puVar9 + 0x30);
            *(undefined8 *)(puVar9 + 0x30) = *(undefined8 *)(puVar9 + 0x40);
            *(undefined8 *)(puVar9 + 0x28) = uVar10;
            *(undefined8 *)(puVar9 + 0x20) = *(undefined8 *)(puVar9 + 0x48);
            *(undefined8 *)(puVar9 + 0x18) = uVar11;
            iVar12 = *(int64_t *)arg1;
            if (iVar12 != 0) {
                iVar4 = iVar12;
                puVar7 = puVar9 + -0x10;
                if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar12)) &&
                   (iVar4 = *(int64_t *)(iVar12 + -8), puVar7 = puVar9 + -0x10, 0x1f < (iVar12 - iVar4) - 8U)) {
                    pcVar3 = (code *)swi(0x29);
                    iVar4 = (*pcVar3)(5);
                    puVar7 = puVar9 + -8;
                }
                *(undefined8 *)(puVar7 + -8) = 0x18002a243;
                fcn.180459c3c(iVar4);
            }
            *(uint64_t *)arg1 = uVar5;
            *(uint64_t *)(arg1 + 8) = uVar5 + uVar1;
            *(uint64_t *)(arg1 + 0x10) = uVar5 + uVar8;
            return;
        }
        uVar5 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)();
        puVar9 = puVar9 + 8;
code_r0x000180029302:
        uVar8 = uVar1;
        if (uVar1 <= uVar5 + uVar6) {
            uVar8 = uVar5 + uVar6;
        }
        if (uVar8 == 0) {
            uVar5 = 0;
            goto code_r0x00018002934a;
        }
        if (uVar8 < 0x1000) {
            *(undefined8 *)(puVar9 + -8) = 0x180029347;
            uVar5 = fcn.180459890(uVar8);
            goto code_r0x00018002934a;
        }
        uVar5 = uVar8 + 0x27;
        if (uVar5 <= uVar8) {
            *(undefined8 *)(puVar9 + -8) = 0x1800293bf;
            fcn.180004720();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800293b4
// Address: 0x1800293b4
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180029270(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined *puVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined *puVar7;
    uint64_t uVar8;
    undefined *puVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    int64_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    undefined auStack_38 [32];
    
    puVar9 = auStack_38;
    puVar7 = *(undefined **)(arg1 + 8);
    if (puVar7 != *(undefined **)(arg1 + 0x10)) {
        *puVar7 = *(undefined *)arg2;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 1;
        return;
    }
    uVar8 = 0x7fffffffffffffff;
    iVar12 = (int64_t)puVar7 - *(int64_t *)arg1;
    if (iVar12 == 0x7fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (int64_t)*(undefined **)(arg1 + 0x10) - *(int64_t *)arg1;
    uVar6 = uVar5 >> 1;
    uVar1 = iVar12 + 1;
    if (uVar5 <= 0x7fffffffffffffff - uVar6) goto code_r0x000180029302;
    uVar5 = 0x8000000000000026;
    puVar9 = auStack_38;
    do {
        *(undefined8 *)(puVar9 + -8) = 0x1800292f6;
        iVar4 = fcn.180459890(uVar5);
        if (iVar4 != 0) {
            uVar5 = iVar4 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar5 - 8) = iVar4;
code_r0x00018002934a:
            *(undefined *)(iVar12 + uVar5) = *(undefined *)arg2;
            puVar2 = *(undefined **)arg1;
            if (puVar7 == *(undefined **)(arg1 + 8)) {
                iVar4 = (int64_t)*(undefined **)(arg1 + 8) - (int64_t)puVar2;
                uVar6 = uVar5;
                puVar7 = puVar2;
            } else {
                *(undefined8 *)(puVar9 + -8) = 0x180029371;
                fcn.180498030(uVar5, puVar2, (int64_t)puVar7 - (int64_t)puVar2);
                iVar4 = *(int64_t *)(arg1 + 8) - (int64_t)puVar7;
                uVar6 = iVar12 + 1 + uVar5;
            }
            *(undefined8 *)(puVar9 + -8) = 0x180029387;
            fcn.180498030(uVar6, puVar7, iVar4);
            uVar11 = *(undefined8 *)(puVar9 + 0x28);
            uVar10 = *(undefined8 *)(puVar9 + 0x30);
            *(undefined8 *)(puVar9 + 0x30) = *(undefined8 *)(puVar9 + 0x40);
            *(undefined8 *)(puVar9 + 0x28) = uVar10;
            *(undefined8 *)(puVar9 + 0x20) = *(undefined8 *)(puVar9 + 0x48);
            *(undefined8 *)(puVar9 + 0x18) = uVar11;
            iVar12 = *(int64_t *)arg1;
            if (iVar12 != 0) {
                iVar4 = iVar12;
                puVar7 = puVar9 + -0x10;
                if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar12)) &&
                   (iVar4 = *(int64_t *)(iVar12 + -8), puVar7 = puVar9 + -0x10, 0x1f < (iVar12 - iVar4) - 8U)) {
                    pcVar3 = (code *)swi(0x29);
                    iVar4 = (*pcVar3)(5);
                    puVar7 = puVar9 + -8;
                }
                *(undefined8 *)(puVar7 + -8) = 0x18002a243;
                fcn.180459c3c(iVar4);
            }
            *(uint64_t *)arg1 = uVar5;
            *(uint64_t *)(arg1 + 8) = uVar5 + uVar1;
            *(uint64_t *)(arg1 + 0x10) = uVar5 + uVar8;
            return;
        }
        uVar5 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)();
        puVar9 = puVar9 + 8;
code_r0x000180029302:
        uVar8 = uVar1;
        if (uVar1 <= uVar5 + uVar6) {
            uVar8 = uVar5 + uVar6;
        }
        if (uVar8 == 0) {
            uVar5 = 0;
            goto code_r0x00018002934a;
        }
        if (uVar8 < 0x1000) {
            *(undefined8 *)(puVar9 + -8) = 0x180029347;
            uVar5 = fcn.180459890(uVar8);
            goto code_r0x00018002934a;
        }
        uVar5 = uVar8 + 0x27;
        if (uVar5 <= uVar8) {
            *(undefined8 *)(puVar9 + -8) = 0x1800293bf;
            fcn.180004720();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800293ba
// Address: 0x1800293ba
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180029270(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined *puVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined *puVar7;
    uint64_t uVar8;
    undefined *puVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    int64_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    undefined auStack_38 [32];
    
    puVar9 = auStack_38;
    puVar7 = *(undefined **)(arg1 + 8);
    if (puVar7 != *(undefined **)(arg1 + 0x10)) {
        *puVar7 = *(undefined *)arg2;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 1;
        return;
    }
    uVar8 = 0x7fffffffffffffff;
    iVar12 = (int64_t)puVar7 - *(int64_t *)arg1;
    if (iVar12 == 0x7fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (int64_t)*(undefined **)(arg1 + 0x10) - *(int64_t *)arg1;
    uVar6 = uVar5 >> 1;
    uVar1 = iVar12 + 1;
    if (uVar5 <= 0x7fffffffffffffff - uVar6) goto code_r0x000180029302;
    uVar5 = 0x8000000000000026;
    puVar9 = auStack_38;
    do {
        *(undefined8 *)(puVar9 + -8) = 0x1800292f6;
        iVar4 = fcn.180459890(uVar5);
        if (iVar4 != 0) {
            uVar5 = iVar4 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar5 - 8) = iVar4;
code_r0x00018002934a:
            *(undefined *)(iVar12 + uVar5) = *(undefined *)arg2;
            puVar2 = *(undefined **)arg1;
            if (puVar7 == *(undefined **)(arg1 + 8)) {
                iVar4 = (int64_t)*(undefined **)(arg1 + 8) - (int64_t)puVar2;
                uVar6 = uVar5;
                puVar7 = puVar2;
            } else {
                *(undefined8 *)(puVar9 + -8) = 0x180029371;
                fcn.180498030(uVar5, puVar2, (int64_t)puVar7 - (int64_t)puVar2);
                iVar4 = *(int64_t *)(arg1 + 8) - (int64_t)puVar7;
                uVar6 = iVar12 + 1 + uVar5;
            }
            *(undefined8 *)(puVar9 + -8) = 0x180029387;
            fcn.180498030(uVar6, puVar7, iVar4);
            uVar11 = *(undefined8 *)(puVar9 + 0x28);
            uVar10 = *(undefined8 *)(puVar9 + 0x30);
            *(undefined8 *)(puVar9 + 0x30) = *(undefined8 *)(puVar9 + 0x40);
            *(undefined8 *)(puVar9 + 0x28) = uVar10;
            *(undefined8 *)(puVar9 + 0x20) = *(undefined8 *)(puVar9 + 0x48);
            *(undefined8 *)(puVar9 + 0x18) = uVar11;
            iVar12 = *(int64_t *)arg1;
            if (iVar12 != 0) {
                iVar4 = iVar12;
                puVar7 = puVar9 + -0x10;
                if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar12)) &&
                   (iVar4 = *(int64_t *)(iVar12 + -8), puVar7 = puVar9 + -0x10, 0x1f < (iVar12 - iVar4) - 8U)) {
                    pcVar3 = (code *)swi(0x29);
                    iVar4 = (*pcVar3)(5);
                    puVar7 = puVar9 + -8;
                }
                *(undefined8 *)(puVar7 + -8) = 0x18002a243;
                fcn.180459c3c(iVar4);
            }
            *(uint64_t *)arg1 = uVar5;
            *(uint64_t *)(arg1 + 8) = uVar5 + uVar1;
            *(uint64_t *)(arg1 + 0x10) = uVar5 + uVar8;
            return;
        }
        uVar5 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)();
        puVar9 = puVar9 + 8;
code_r0x000180029302:
        uVar8 = uVar1;
        if (uVar1 <= uVar5 + uVar6) {
            uVar8 = uVar5 + uVar6;
        }
        if (uVar8 == 0) {
            uVar5 = 0;
            goto code_r0x00018002934a;
        }
        if (uVar8 < 0x1000) {
            *(undefined8 *)(puVar9 + -8) = 0x180029347;
            uVar5 = fcn.180459890(uVar8);
            goto code_r0x00018002934a;
        }
        uVar5 = uVar8 + 0x27;
        if (uVar5 <= uVar8) {
            *(undefined8 *)(puVar9 + -8) = 0x1800293bf;
            fcn.180004720();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800293c0
// Address: 0x1800293c0
// Size: 90 bytes
// ============================================================
void fcn.1800293c0(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar1 = *(int64_t *)arg1;
    if (iVar1 != 0) {
        iVar3 = iVar1;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar1)) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_28, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180029407;
        fcn.180459c3c(iVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180029420
// Address: 0x180029420
// Size: 47 bytes
// ============================================================
void fcn.180029420(int64_t arg1)
{
    undefined8 *puVar1;
    
    if (*(int64_t **)(arg1 + 0x18) != (int64_t *)0x0) {
        puVar1 = (undefined8 *)(**(code **)(**(int64_t **)(arg1 + 0x18) + 0x10))();
        if (puVar1 != (undefined8 *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180029447. Too many branches
    // WARNING: Treating indirect jump as call
            (**(code **)*puVar1)(puVar1, 1);
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180029450
// Address: 0x180029450
// Size: 582 bytes
// ============================================================
void fcn.180029450(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined *puVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_90;
    undefined auStack_88 [32];
    int64_t var_68h;
    
    if (arg4 != 0) {
        puVar8 = auStack_88;
        piVar1 = (int64_t *)(arg1 + 8);
        iVar2 = *piVar1;
        if ((uint64_t)arg4 <= (uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar2)) {
            uVar9 = iVar2 - arg2;
            var_68h = (int64_t)piVar1;
            if ((uint64_t)arg4 < uVar9) {
                fcn.180498030(iVar2, iVar2 - arg4, arg4);
                *piVar1 = iVar2 + arg4;
                iVar10 = (iVar2 - arg4) - arg2;
                fcn.180498030(iVar2 - iVar10, arg2, iVar10);
                fcn.180498030(arg2, arg3, arg4);
            } else {
                fcn.180498030(arg2 + arg4, arg2, uVar9);
                *piVar1 = arg2 + arg4 + uVar9;
                fcn.180498030(arg2, arg3, arg4);
            }
            return;
        }
        iVar10 = iVar2 - *(int64_t *)arg1;
        uVar9 = 0x7fffffffffffffff;
        if (0x7fffffffffffffffU - iVar10 < (uint64_t)arg4) {
            fcn.180010010();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        uVar5 = iVar10 + arg4;
        var_68h = uVar5;
        uVar7 = *(int64_t *)(arg1 + 0x10) - *(int64_t *)arg1;
        uVar6 = uVar7 >> 1;
        if (uVar7 <= 0x7fffffffffffffff - uVar6) goto code_r0x0001800294fd;
        uVar6 = 0x8000000000000026;
        puVar8 = auStack_88;
        while( true ) {
            *(undefined8 *)(puVar8 + -8) = 0x1800294f1;
            iVar4 = fcn.180459890(uVar6);
            if (iVar4 != 0) break;
            uVar6 = 5;
            pcVar3 = (code *)swi(0x29);
            (*pcVar3)();
            puVar8 = puVar8 + 8;
code_r0x0001800294fd:
            uVar9 = uVar5;
            if (uVar5 <= uVar7 + uVar6) {
                uVar9 = uVar7 + uVar6;
            }
            if (uVar9 == 0) {
                uVar5 = 0;
                goto code_r0x000180029546;
            }
            if (uVar9 < 0x1000) {
                *(undefined8 *)(puVar8 + -8) = 0x180029543;
                uVar5 = fcn.180459890(uVar9);
                goto code_r0x000180029546;
            }
            uVar6 = uVar9 + 0x27;
            if (uVar6 <= uVar9) {
                *(undefined8 *)(puVar8 + -8) = 0x180029695;
                fcn.180004720();
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
        }
        uVar5 = iVar4 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar5 - 8) = iVar4;
code_r0x000180029546:
        *(int64_t *)(puVar8 + 0xa8) = arg2 - *(int64_t *)(puVar8 + 0x98);
        iVar4 = (arg2 - *(int64_t *)(puVar8 + 0x98)) + uVar5;
        *(int64_t *)(puVar8 + 0x90) = iVar4;
        *(undefined8 *)(puVar8 + -8) = 0x180029577;
        fcn.180498030(iVar4, *(undefined8 *)(puVar8 + 0xa0), arg4);
        if ((arg4 == 1) && (arg2 == iVar2)) {
            arg2 = *(int64_t *)(puVar8 + 0x98);
            uVar6 = uVar5;
        } else {
            *(undefined8 *)(puVar8 + -8) = 0x1800295aa;
            fcn.180498030(uVar5, *(undefined8 *)(puVar8 + 0x98), *(undefined8 *)(puVar8 + 0xa8));
            iVar10 = iVar2 - arg2;
            uVar6 = *(int64_t *)(puVar8 + 0x90) + arg4;
        }
        *(undefined8 *)(puVar8 + -8) = 0x1800295c3;
        fcn.180498030(uVar6, arg2, iVar10);
        *(undefined8 *)(puVar8 + -8) = 0x1800295d6;
        func_0x00018002a1f0(arg1, uVar5, *(undefined8 *)(puVar8 + 0x20), uVar9);
    }
    return;
}

// ============================================================
// Function: FUN_1800296c0
// Address: 0x1800296c0
// Size: 198 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800296c0(int64_t arg_38h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t *piVar6;
    code *pcVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar10 = *(uint64_t *)0x18077afb8;
    uVar11 = *(int64_t *)0x18077af90 + 1;
    if ((int64_t)uVar11 < 0) {
        fVar14 = (float)(uVar11 >> 1 | (uint64_t)((uint32_t)uVar11 & 1));
        fVar14 = fVar14 + fVar14;
    } else {
        fVar14 = (float)uVar11;
    }
    fVar14 = (float)func_0x000180471c90(fVar14 / *(float *)0x18077af80);
    ppiVar9 = *(int64_t ***)0x18077af88;
    iVar12 = 0;
    if ((9.223372e+18 <= fVar14) && (fVar14 = fVar14 - 9.223372e+18, fVar14 < 9.223372e+18)) {
        iVar12 = -0x8000000000000000;
    }
    uVar11 = 8;
    if (8 < (uint64_t)((int64_t)fVar14 + iVar12)) {
        uVar11 = (int64_t)fVar14 + iVar12;
    }
    uVar13 = uVar10;
    if ((uVar10 < uVar11) && ((0x1ff < uVar10 || (uVar13 = uVar10 * 8, uVar10 * 8 < uVar11)))) {
        uVar13 = uVar11;
    }
    for (iVar12 = 0x3f; 0xfffffffffffffffU >> iVar12 == 0; iVar12 = iVar12 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar12 & 0x3f)) < uVar13) {
        fcn.1804546d4(0x180620448);
        pcVar7 = (code *)swi(3);
        (*pcVar7)();
        return;
    }
    uVar10 = uVar13 - 1 | 1;
    iVar12 = 0x3f;
    if (uVar10 != 0) {
        for (; uVar10 >> iVar12 == 0; iVar12 = iVar12 + -1) {
        }
    }
    iVar12 = 1LL << ((char)iVar12 + 1U & 0x3f);
    func_0x00018000f7e0(0x18077af98, iVar12 * 2, *(int64_t ***)0x18077af88);
    *(uint64_t *)0x18077afb0 = iVar12 - 1;
    *(int64_t *)0x18077afb8 = iVar12;
    ppiVar8 = (int64_t **)**(int64_t ***)0x18077af88;
    iVar12 = *(int64_t *)0x18077af98;
joined_r0x0001800297d3:
    do {
        while( true ) {
            while( true ) {
                if (ppiVar8 == ppiVar9) {
                    *(int64_t *)0x18077af98 = iVar12;
                    return;
                }
                ppiVar1 = (int64_t **)*ppiVar8;
                uVar10 = (((((((((uint64_t)*(uint8_t *)(ppiVar8 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x17)) * 0x100000001b3 & *(uint64_t *)0x18077afb0;
                ppiVar2 = *(int64_t ***)(iVar12 + uVar10 * 0x10);
                *(int64_t *)0x18077af98 = iVar12;
                if (ppiVar2 != ppiVar9) break;
                *(int64_t ***)(iVar12 + uVar10 * 0x10) = ppiVar8;
                *(int64_t ***)(iVar12 + 8 + uVar10 * 0x10) = ppiVar8;
                ppiVar8 = ppiVar1;
                iVar12 = *(int64_t *)0x18077af98;
            }
            ppiVar3 = *(int64_t ***)(iVar12 + 8 + uVar10 * 0x10);
            if (ppiVar8[2] != ppiVar3[2]) break;
            ppiVar3 = (int64_t **)*ppiVar3;
            if (ppiVar3 != ppiVar8) {
                ppiVar2 = (int64_t **)ppiVar8[1];
                *ppiVar2 = (int64_t *)ppiVar1;
                ppiVar4 = (int64_t **)ppiVar1[1];
                *ppiVar4 = (int64_t *)ppiVar3;
                ppiVar5 = (int64_t **)ppiVar3[1];
                *ppiVar5 = (int64_t *)ppiVar8;
                ppiVar3[1] = (int64_t *)ppiVar4;
                ppiVar1[1] = (int64_t *)ppiVar2;
                ppiVar8[1] = (int64_t *)ppiVar5;
            }
            *(int64_t ***)(iVar12 + 8 + uVar10 * 0x10) = ppiVar8;
            ppiVar8 = ppiVar1;
            iVar12 = *(int64_t *)0x18077af98;
        }
        do {
            if (ppiVar2 == ppiVar3) {
                ppiVar2 = (int64_t **)ppiVar8[1];
                *ppiVar2 = (int64_t *)ppiVar1;
                piVar6 = ppiVar1[1];
                *piVar6 = (int64_t)ppiVar3;
                ppiVar4 = (int64_t **)ppiVar3[1];
                *ppiVar4 = (int64_t *)ppiVar8;
                ppiVar3[1] = piVar6;
                ppiVar1[1] = (int64_t *)ppiVar2;
                ppiVar8[1] = (int64_t *)ppiVar4;
                *(int64_t ***)(iVar12 + uVar10 * 0x10) = ppiVar8;
                ppiVar8 = ppiVar1;
                iVar12 = *(int64_t *)0x18077af98;
                goto joined_r0x0001800297d3;
            }
            ppiVar3 = (int64_t **)ppiVar3[1];
        } while (ppiVar8[2] != ppiVar3[2]);
        iVar12 = (int64_t)*ppiVar3;
        ppiVar2 = (int64_t **)ppiVar8[1];
        *ppiVar2 = (int64_t *)ppiVar1;
        piVar6 = ppiVar1[1];
        *piVar6 = iVar12;
        ppiVar3 = *(int64_t ***)(iVar12 + 8);
        *ppiVar3 = (int64_t *)ppiVar8;
        *(int64_t **)(iVar12 + 8) = piVar6;
        ppiVar1[1] = (int64_t *)ppiVar2;
        ppiVar8[1] = (int64_t *)ppiVar3;
        ppiVar8 = ppiVar1;
        iVar12 = *(int64_t *)0x18077af98;
    } while( true );
}

// ============================================================
// Function: FUN_180029786
// Address: 0x180029786
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800296c0(int64_t arg_38h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t *piVar6;
    code *pcVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar10 = *(uint64_t *)0x18077afb8;
    uVar11 = *(int64_t *)0x18077af90 + 1;
    if ((int64_t)uVar11 < 0) {
        fVar14 = (float)(uVar11 >> 1 | (uint64_t)((uint32_t)uVar11 & 1));
        fVar14 = fVar14 + fVar14;
    } else {
        fVar14 = (float)uVar11;
    }
    fVar14 = (float)func_0x000180471c90(fVar14 / *(float *)0x18077af80);
    ppiVar9 = *(int64_t ***)0x18077af88;
    iVar12 = 0;
    if ((9.223372e+18 <= fVar14) && (fVar14 = fVar14 - 9.223372e+18, fVar14 < 9.223372e+18)) {
        iVar12 = -0x8000000000000000;
    }
    uVar11 = 8;
    if (8 < (uint64_t)((int64_t)fVar14 + iVar12)) {
        uVar11 = (int64_t)fVar14 + iVar12;
    }
    uVar13 = uVar10;
    if ((uVar10 < uVar11) && ((0x1ff < uVar10 || (uVar13 = uVar10 * 8, uVar10 * 8 < uVar11)))) {
        uVar13 = uVar11;
    }
    for (iVar12 = 0x3f; 0xfffffffffffffffU >> iVar12 == 0; iVar12 = iVar12 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar12 & 0x3f)) < uVar13) {
        fcn.1804546d4(0x180620448);
        pcVar7 = (code *)swi(3);
        (*pcVar7)();
        return;
    }
    uVar10 = uVar13 - 1 | 1;
    iVar12 = 0x3f;
    if (uVar10 != 0) {
        for (; uVar10 >> iVar12 == 0; iVar12 = iVar12 + -1) {
        }
    }
    iVar12 = 1LL << ((char)iVar12 + 1U & 0x3f);
    func_0x00018000f7e0(0x18077af98, iVar12 * 2, *(int64_t ***)0x18077af88);
    *(uint64_t *)0x18077afb0 = iVar12 - 1;
    *(int64_t *)0x18077afb8 = iVar12;
    ppiVar8 = (int64_t **)**(int64_t ***)0x18077af88;
    iVar12 = *(int64_t *)0x18077af98;
joined_r0x0001800297d3:
    do {
        while( true ) {
            while( true ) {
                if (ppiVar8 == ppiVar9) {
                    *(int64_t *)0x18077af98 = iVar12;
                    return;
                }
                ppiVar1 = (int64_t **)*ppiVar8;
                uVar10 = (((((((((uint64_t)*(uint8_t *)(ppiVar8 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x17)) * 0x100000001b3 & *(uint64_t *)0x18077afb0;
                ppiVar2 = *(int64_t ***)(iVar12 + uVar10 * 0x10);
                *(int64_t *)0x18077af98 = iVar12;
                if (ppiVar2 != ppiVar9) break;
                *(int64_t ***)(iVar12 + uVar10 * 0x10) = ppiVar8;
                *(int64_t ***)(iVar12 + 8 + uVar10 * 0x10) = ppiVar8;
                ppiVar8 = ppiVar1;
                iVar12 = *(int64_t *)0x18077af98;
            }
            ppiVar3 = *(int64_t ***)(iVar12 + 8 + uVar10 * 0x10);
            if (ppiVar8[2] != ppiVar3[2]) break;
            ppiVar3 = (int64_t **)*ppiVar3;
            if (ppiVar3 != ppiVar8) {
                ppiVar2 = (int64_t **)ppiVar8[1];
                *ppiVar2 = (int64_t *)ppiVar1;
                ppiVar4 = (int64_t **)ppiVar1[1];
                *ppiVar4 = (int64_t *)ppiVar3;
                ppiVar5 = (int64_t **)ppiVar3[1];
                *ppiVar5 = (int64_t *)ppiVar8;
                ppiVar3[1] = (int64_t *)ppiVar4;
                ppiVar1[1] = (int64_t *)ppiVar2;
                ppiVar8[1] = (int64_t *)ppiVar5;
            }
            *(int64_t ***)(iVar12 + 8 + uVar10 * 0x10) = ppiVar8;
            ppiVar8 = ppiVar1;
            iVar12 = *(int64_t *)0x18077af98;
        }
        do {
            if (ppiVar2 == ppiVar3) {
                ppiVar2 = (int64_t **)ppiVar8[1];
                *ppiVar2 = (int64_t *)ppiVar1;
                piVar6 = ppiVar1[1];
                *piVar6 = (int64_t)ppiVar3;
                ppiVar4 = (int64_t **)ppiVar3[1];
                *ppiVar4 = (int64_t *)ppiVar8;
                ppiVar3[1] = piVar6;
                ppiVar1[1] = (int64_t *)ppiVar2;
                ppiVar8[1] = (int64_t *)ppiVar4;
                *(int64_t ***)(iVar12 + uVar10 * 0x10) = ppiVar8;
                ppiVar8 = ppiVar1;
                iVar12 = *(int64_t *)0x18077af98;
                goto joined_r0x0001800297d3;
            }
            ppiVar3 = (int64_t **)ppiVar3[1];
        } while (ppiVar8[2] != ppiVar3[2]);
        iVar12 = (int64_t)*ppiVar3;
        ppiVar2 = (int64_t **)ppiVar8[1];
        *ppiVar2 = (int64_t *)ppiVar1;
        piVar6 = ppiVar1[1];
        *piVar6 = iVar12;
        ppiVar3 = *(int64_t ***)(iVar12 + 8);
        *ppiVar3 = (int64_t *)ppiVar8;
        *(int64_t **)(iVar12 + 8) = piVar6;
        ppiVar1[1] = (int64_t *)ppiVar2;
        ppiVar8[1] = (int64_t *)ppiVar3;
        ppiVar8 = ppiVar1;
        iVar12 = *(int64_t *)0x18077af98;
    } while( true );
}

// ============================================================
// Function: FUN_1800297d9
// Address: 0x1800297d9
// Size: 350 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800296c0(int64_t arg_38h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t *piVar6;
    code *pcVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar10 = *(uint64_t *)0x18077afb8;
    uVar11 = *(int64_t *)0x18077af90 + 1;
    if ((int64_t)uVar11 < 0) {
        fVar14 = (float)(uVar11 >> 1 | (uint64_t)((uint32_t)uVar11 & 1));
        fVar14 = fVar14 + fVar14;
    } else {
        fVar14 = (float)uVar11;
    }
    fVar14 = (float)func_0x000180471c90(fVar14 / *(float *)0x18077af80);
    ppiVar9 = *(int64_t ***)0x18077af88;
    iVar12 = 0;
    if ((9.223372e+18 <= fVar14) && (fVar14 = fVar14 - 9.223372e+18, fVar14 < 9.223372e+18)) {
        iVar12 = -0x8000000000000000;
    }
    uVar11 = 8;
    if (8 < (uint64_t)((int64_t)fVar14 + iVar12)) {
        uVar11 = (int64_t)fVar14 + iVar12;
    }
    uVar13 = uVar10;
    if ((uVar10 < uVar11) && ((0x1ff < uVar10 || (uVar13 = uVar10 * 8, uVar10 * 8 < uVar11)))) {
        uVar13 = uVar11;
    }
    for (iVar12 = 0x3f; 0xfffffffffffffffU >> iVar12 == 0; iVar12 = iVar12 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar12 & 0x3f)) < uVar13) {
        fcn.1804546d4(0x180620448);
        pcVar7 = (code *)swi(3);
        (*pcVar7)();
        return;
    }
    uVar10 = uVar13 - 1 | 1;
    iVar12 = 0x3f;
    if (uVar10 != 0) {
        for (; uVar10 >> iVar12 == 0; iVar12 = iVar12 + -1) {
        }
    }
    iVar12 = 1LL << ((char)iVar12 + 1U & 0x3f);
    func_0x00018000f7e0(0x18077af98, iVar12 * 2, *(int64_t ***)0x18077af88);
    *(uint64_t *)0x18077afb0 = iVar12 - 1;
    *(int64_t *)0x18077afb8 = iVar12;
    ppiVar8 = (int64_t **)**(int64_t ***)0x18077af88;
    iVar12 = *(int64_t *)0x18077af98;
joined_r0x0001800297d3:
    do {
        while( true ) {
            while( true ) {
                if (ppiVar8 == ppiVar9) {
                    *(int64_t *)0x18077af98 = iVar12;
                    return;
                }
                ppiVar1 = (int64_t **)*ppiVar8;
                uVar10 = (((((((((uint64_t)*(uint8_t *)(ppiVar8 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x17)) * 0x100000001b3 & *(uint64_t *)0x18077afb0;
                ppiVar2 = *(int64_t ***)(iVar12 + uVar10 * 0x10);
                *(int64_t *)0x18077af98 = iVar12;
                if (ppiVar2 != ppiVar9) break;
                *(int64_t ***)(iVar12 + uVar10 * 0x10) = ppiVar8;
                *(int64_t ***)(iVar12 + 8 + uVar10 * 0x10) = ppiVar8;
                ppiVar8 = ppiVar1;
                iVar12 = *(int64_t *)0x18077af98;
            }
            ppiVar3 = *(int64_t ***)(iVar12 + 8 + uVar10 * 0x10);
            if (ppiVar8[2] != ppiVar3[2]) break;
            ppiVar3 = (int64_t **)*ppiVar3;
            if (ppiVar3 != ppiVar8) {
                ppiVar2 = (int64_t **)ppiVar8[1];
                *ppiVar2 = (int64_t *)ppiVar1;
                ppiVar4 = (int64_t **)ppiVar1[1];
                *ppiVar4 = (int64_t *)ppiVar3;
                ppiVar5 = (int64_t **)ppiVar3[1];
                *ppiVar5 = (int64_t *)ppiVar8;
                ppiVar3[1] = (int64_t *)ppiVar4;
                ppiVar1[1] = (int64_t *)ppiVar2;
                ppiVar8[1] = (int64_t *)ppiVar5;
            }
            *(int64_t ***)(iVar12 + 8 + uVar10 * 0x10) = ppiVar8;
            ppiVar8 = ppiVar1;
            iVar12 = *(int64_t *)0x18077af98;
        }
        do {
            if (ppiVar2 == ppiVar3) {
                ppiVar2 = (int64_t **)ppiVar8[1];
                *ppiVar2 = (int64_t *)ppiVar1;
                piVar6 = ppiVar1[1];
                *piVar6 = (int64_t)ppiVar3;
                ppiVar4 = (int64_t **)ppiVar3[1];
                *ppiVar4 = (int64_t *)ppiVar8;
                ppiVar3[1] = piVar6;
                ppiVar1[1] = (int64_t *)ppiVar2;
                ppiVar8[1] = (int64_t *)ppiVar4;
                *(int64_t ***)(iVar12 + uVar10 * 0x10) = ppiVar8;
                ppiVar8 = ppiVar1;
                iVar12 = *(int64_t *)0x18077af98;
                goto joined_r0x0001800297d3;
            }
            ppiVar3 = (int64_t **)ppiVar3[1];
        } while (ppiVar8[2] != ppiVar3[2]);
        iVar12 = (int64_t)*ppiVar3;
        ppiVar2 = (int64_t **)ppiVar8[1];
        *ppiVar2 = (int64_t *)ppiVar1;
        piVar6 = ppiVar1[1];
        *piVar6 = iVar12;
        ppiVar3 = *(int64_t ***)(iVar12 + 8);
        *ppiVar3 = (int64_t *)ppiVar8;
        *(int64_t **)(iVar12 + 8) = piVar6;
        ppiVar1[1] = (int64_t *)ppiVar2;
        ppiVar8[1] = (int64_t *)ppiVar3;
        ppiVar8 = ppiVar1;
        iVar12 = *(int64_t *)0x18077af98;
    } while( true );
}

// ============================================================
// Function: FUN_180029937
// Address: 0x180029937
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800296c0(int64_t arg_38h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t *piVar6;
    code *pcVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar10 = *(uint64_t *)0x18077afb8;
    uVar11 = *(int64_t *)0x18077af90 + 1;
    if ((int64_t)uVar11 < 0) {
        fVar14 = (float)(uVar11 >> 1 | (uint64_t)((uint32_t)uVar11 & 1));
        fVar14 = fVar14 + fVar14;
    } else {
        fVar14 = (float)uVar11;
    }
    fVar14 = (float)func_0x000180471c90(fVar14 / *(float *)0x18077af80);
    ppiVar9 = *(int64_t ***)0x18077af88;
    iVar12 = 0;
    if ((9.223372e+18 <= fVar14) && (fVar14 = fVar14 - 9.223372e+18, fVar14 < 9.223372e+18)) {
        iVar12 = -0x8000000000000000;
    }
    uVar11 = 8;
    if (8 < (uint64_t)((int64_t)fVar14 + iVar12)) {
        uVar11 = (int64_t)fVar14 + iVar12;
    }
    uVar13 = uVar10;
    if ((uVar10 < uVar11) && ((0x1ff < uVar10 || (uVar13 = uVar10 * 8, uVar10 * 8 < uVar11)))) {
        uVar13 = uVar11;
    }
    for (iVar12 = 0x3f; 0xfffffffffffffffU >> iVar12 == 0; iVar12 = iVar12 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar12 & 0x3f)) < uVar13) {
        fcn.1804546d4(0x180620448);
        pcVar7 = (code *)swi(3);
        (*pcVar7)();
        return;
    }
    uVar10 = uVar13 - 1 | 1;
    iVar12 = 0x3f;
    if (uVar10 != 0) {
        for (; uVar10 >> iVar12 == 0; iVar12 = iVar12 + -1) {
        }
    }
    iVar12 = 1LL << ((char)iVar12 + 1U & 0x3f);
    func_0x00018000f7e0(0x18077af98, iVar12 * 2, *(int64_t ***)0x18077af88);
    *(uint64_t *)0x18077afb0 = iVar12 - 1;
    *(int64_t *)0x18077afb8 = iVar12;
    ppiVar8 = (int64_t **)**(int64_t ***)0x18077af88;
    iVar12 = *(int64_t *)0x18077af98;
joined_r0x0001800297d3:
    do {
        while( true ) {
            while( true ) {
                if (ppiVar8 == ppiVar9) {
                    *(int64_t *)0x18077af98 = iVar12;
                    return;
                }
                ppiVar1 = (int64_t **)*ppiVar8;
                uVar10 = (((((((((uint64_t)*(uint8_t *)(ppiVar8 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x17)) * 0x100000001b3 & *(uint64_t *)0x18077afb0;
                ppiVar2 = *(int64_t ***)(iVar12 + uVar10 * 0x10);
                *(int64_t *)0x18077af98 = iVar12;
                if (ppiVar2 != ppiVar9) break;
                *(int64_t ***)(iVar12 + uVar10 * 0x10) = ppiVar8;
                *(int64_t ***)(iVar12 + 8 + uVar10 * 0x10) = ppiVar8;
                ppiVar8 = ppiVar1;
                iVar12 = *(int64_t *)0x18077af98;
            }
            ppiVar3 = *(int64_t ***)(iVar12 + 8 + uVar10 * 0x10);
            if (ppiVar8[2] != ppiVar3[2]) break;
            ppiVar3 = (int64_t **)*ppiVar3;
            if (ppiVar3 != ppiVar8) {
                ppiVar2 = (int64_t **)ppiVar8[1];
                *ppiVar2 = (int64_t *)ppiVar1;
                ppiVar4 = (int64_t **)ppiVar1[1];
                *ppiVar4 = (int64_t *)ppiVar3;
                ppiVar5 = (int64_t **)ppiVar3[1];
                *ppiVar5 = (int64_t *)ppiVar8;
                ppiVar3[1] = (int64_t *)ppiVar4;
                ppiVar1[1] = (int64_t *)ppiVar2;
                ppiVar8[1] = (int64_t *)ppiVar5;
            }
            *(int64_t ***)(iVar12 + 8 + uVar10 * 0x10) = ppiVar8;
            ppiVar8 = ppiVar1;
            iVar12 = *(int64_t *)0x18077af98;
        }
        do {
            if (ppiVar2 == ppiVar3) {
                ppiVar2 = (int64_t **)ppiVar8[1];
                *ppiVar2 = (int64_t *)ppiVar1;
                piVar6 = ppiVar1[1];
                *piVar6 = (int64_t)ppiVar3;
                ppiVar4 = (int64_t **)ppiVar3[1];
                *ppiVar4 = (int64_t *)ppiVar8;
                ppiVar3[1] = piVar6;
                ppiVar1[1] = (int64_t *)ppiVar2;
                ppiVar8[1] = (int64_t *)ppiVar4;
                *(int64_t ***)(iVar12 + uVar10 * 0x10) = ppiVar8;
                ppiVar8 = ppiVar1;
                iVar12 = *(int64_t *)0x18077af98;
                goto joined_r0x0001800297d3;
            }
            ppiVar3 = (int64_t **)ppiVar3[1];
        } while (ppiVar8[2] != ppiVar3[2]);
        iVar12 = (int64_t)*ppiVar3;
        ppiVar2 = (int64_t **)ppiVar8[1];
        *ppiVar2 = (int64_t *)ppiVar1;
        piVar6 = ppiVar1[1];
        *piVar6 = iVar12;
        ppiVar3 = *(int64_t ***)(iVar12 + 8);
        *ppiVar3 = (int64_t *)ppiVar8;
        *(int64_t **)(iVar12 + 8) = piVar6;
        ppiVar1[1] = (int64_t *)ppiVar2;
        ppiVar8[1] = (int64_t *)ppiVar3;
        ppiVar8 = ppiVar1;
        iVar12 = *(int64_t *)0x18077af98;
    } while( true );
}

// ============================================================
// Function: FUN_180029947
// Address: 0x180029947
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800296c0(int64_t arg_38h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t *piVar6;
    code *pcVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    float fVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar10 = *(uint64_t *)0x18077afb8;
    uVar11 = *(int64_t *)0x18077af90 + 1;
    if ((int64_t)uVar11 < 0) {
        fVar14 = (float)(uVar11 >> 1 | (uint64_t)((uint32_t)uVar11 & 1));
        fVar14 = fVar14 + fVar14;
    } else {
        fVar14 = (float)uVar11;
    }
    fVar14 = (float)func_0x000180471c90(fVar14 / *(float *)0x18077af80);
    ppiVar9 = *(int64_t ***)0x18077af88;
    iVar12 = 0;
    if ((9.223372e+18 <= fVar14) && (fVar14 = fVar14 - 9.223372e+18, fVar14 < 9.223372e+18)) {
        iVar12 = -0x8000000000000000;
    }
    uVar11 = 8;
    if (8 < (uint64_t)((int64_t)fVar14 + iVar12)) {
        uVar11 = (int64_t)fVar14 + iVar12;
    }
    uVar13 = uVar10;
    if ((uVar10 < uVar11) && ((0x1ff < uVar10 || (uVar13 = uVar10 * 8, uVar10 * 8 < uVar11)))) {
        uVar13 = uVar11;
    }
    for (iVar12 = 0x3f; 0xfffffffffffffffU >> iVar12 == 0; iVar12 = iVar12 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar12 & 0x3f)) < uVar13) {
        fcn.1804546d4(0x180620448);
        pcVar7 = (code *)swi(3);
        (*pcVar7)();
        return;
    }
    uVar10 = uVar13 - 1 | 1;
    iVar12 = 0x3f;
    if (uVar10 != 0) {
        for (; uVar10 >> iVar12 == 0; iVar12 = iVar12 + -1) {
        }
    }
    iVar12 = 1LL << ((char)iVar12 + 1U & 0x3f);
    func_0x00018000f7e0(0x18077af98, iVar12 * 2, *(int64_t ***)0x18077af88);
    *(uint64_t *)0x18077afb0 = iVar12 - 1;
    *(int64_t *)0x18077afb8 = iVar12;
    ppiVar8 = (int64_t **)**(int64_t ***)0x18077af88;
    iVar12 = *(int64_t *)0x18077af98;
joined_r0x0001800297d3:
    do {
        while( true ) {
            while( true ) {
                if (ppiVar8 == ppiVar9) {
                    *(int64_t *)0x18077af98 = iVar12;
                    return;
                }
                ppiVar1 = (int64_t **)*ppiVar8;
                uVar10 = (((((((((uint64_t)*(uint8_t *)(ppiVar8 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                               (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x11)) * 0x100000001b3 ^
                              (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x12)) * 0x100000001b3 ^
                             (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x13)) * 0x100000001b3 ^
                            (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x14)) * 0x100000001b3 ^
                           (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x15)) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x16)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar8 + 0x17)) * 0x100000001b3 & *(uint64_t *)0x18077afb0;
                ppiVar2 = *(int64_t ***)(iVar12 + uVar10 * 0x10);
                *(int64_t *)0x18077af98 = iVar12;
                if (ppiVar2 != ppiVar9) break;
                *(int64_t ***)(iVar12 + uVar10 * 0x10) = ppiVar8;
                *(int64_t ***)(iVar12 + 8 + uVar10 * 0x10) = ppiVar8;
                ppiVar8 = ppiVar1;
                iVar12 = *(int64_t *)0x18077af98;
            }
            ppiVar3 = *(int64_t ***)(iVar12 + 8 + uVar10 * 0x10);
            if (ppiVar8[2] != ppiVar3[2]) break;
            ppiVar3 = (int64_t **)*ppiVar3;
            if (ppiVar3 != ppiVar8) {
                ppiVar2 = (int64_t **)ppiVar8[1];
                *ppiVar2 = (int64_t *)ppiVar1;
                ppiVar4 = (int64_t **)ppiVar1[1];
                *ppiVar4 = (int64_t *)ppiVar3;
                ppiVar5 = (int64_t **)ppiVar3[1];
                *ppiVar5 = (int64_t *)ppiVar8;
                ppiVar3[1] = (int64_t *)ppiVar4;
                ppiVar1[1] = (int64_t *)ppiVar2;
                ppiVar8[1] = (int64_t *)ppiVar5;
            }
            *(int64_t ***)(iVar12 + 8 + uVar10 * 0x10) = ppiVar8;
            ppiVar8 = ppiVar1;
            iVar12 = *(int64_t *)0x18077af98;
        }
        do {
            if (ppiVar2 == ppiVar3) {
                ppiVar2 = (int64_t **)ppiVar8[1];
                *ppiVar2 = (int64_t *)ppiVar1;
                piVar6 = ppiVar1[1];
                *piVar6 = (int64_t)ppiVar3;
                ppiVar4 = (int64_t **)ppiVar3[1];
                *ppiVar4 = (int64_t *)ppiVar8;
                ppiVar3[1] = piVar6;
                ppiVar1[1] = (int64_t *)ppiVar2;
                ppiVar8[1] = (int64_t *)ppiVar4;
                *(int64_t ***)(iVar12 + uVar10 * 0x10) = ppiVar8;
                ppiVar8 = ppiVar1;
                iVar12 = *(int64_t *)0x18077af98;
                goto joined_r0x0001800297d3;
            }
            ppiVar3 = (int64_t **)ppiVar3[1];
        } while (ppiVar8[2] != ppiVar3[2]);
        iVar12 = (int64_t)*ppiVar3;
        ppiVar2 = (int64_t **)ppiVar8[1];
        *ppiVar2 = (int64_t *)ppiVar1;
        piVar6 = ppiVar1[1];
        *piVar6 = iVar12;
        ppiVar3 = *(int64_t ***)(iVar12 + 8);
        *ppiVar3 = (int64_t *)ppiVar8;
        *(int64_t **)(iVar12 + 8) = piVar6;
        ppiVar1[1] = (int64_t *)ppiVar2;
        ppiVar8[1] = (int64_t *)ppiVar3;
        ppiVar8 = ppiVar1;
        iVar12 = *(int64_t *)0x18077af98;
    } while( true );
}

// ============================================================
// Function: FUN_180029960
// Address: 0x180029960
// Size: 74 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018002998e: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180029993)

void fcn.180029960(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t iStack_38;
    undefined8 uStack_30;
    
    uStack_30 = 0x180029975;
    func_0x00018002a130(arg1 + 0x98);
    uStack_30 = 0x180029981;
    func_0x00018002a260(arg1 + 0x80);
    uStack_30 = 0x18002998a;
    func_0x00018002a260(arg1 + 0x68);
    uStack_30 = 0x180029993;
    puVar5 = auStack_58;
    uVar4 = *(uint64_t *)(arg1 + 0x48);
    if (uVar4 != 0) {
        uVar3 = ((int64_t)(*(int64_t *)(arg1 + 0x58) - uVar4) >> 2) * 4;
        iStack_38 = arg1;
        if (0xfff < uVar3) {
            puVar1 = (uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - *puVar1) - 8;
            if (uVar4 < 0x20) {
                uVar3 = uVar3 + 0x27;
                uVar4 = *puVar1;
                puVar5 = auStack_58;
            } else {
                pcVar2 = (code *)swi(0x29);
                uVar3 = (*pcVar2)(5);
                puVar5 = auStack_50;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x18002eea5;
        fcn.180459c3c(uVar4, uVar3);
        *(uint64_t *)(arg1 + 0x48) = 0;
        *(undefined8 *)(arg1 + 0x50) = 0;
        *(undefined8 *)(arg1 + 0x58) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800299b0
// Address: 0x1800299b0
// Size: 32 bytes
// ============================================================
void fcn.1800299b0(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    func_0x00018002a260(arg1 + 0x28);
    puVar5 = auStack_28;
    uVar4 = *(uint64_t *)(arg1 + 8);
    if (uVar4 != 0) {
        uVar3 = ((int64_t)(*(int64_t *)(arg1 + 0x18) - uVar4) >> 2) * 4;
        if (0xfff < uVar3) {
            puVar1 = (uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - *puVar1) - 8;
            if (uVar4 < 0x20) {
                uVar3 = uVar3 + 0x27;
                uVar4 = *puVar1;
                puVar5 = auStack_28;
            } else {
                pcVar2 = (code *)swi(0x29);
                uVar3 = (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x18002eea5;
        fcn.180459c3c(uVar4, uVar3);
        *(uint64_t *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
        *(undefined8 *)(arg1 + 0x18) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800299f0
// Address: 0x1800299f0
// Size: 903 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

char fcn.1800299f0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    code *pcVar2;
    char cVar3;
    int64_t iVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    undefined8 *puVar7;
    int64_t iVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    uint64_t unaff_RBP;
    uint64_t uVar11;
    uint32_t uVar12;
    uint64_t uVar13;
    undefined8 *puVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_40h;
    int64_t var_38h;
    undefined auStack_30 [24];
    
    piVar9 = &var_38h;
    if (arg2 != 0) {
        *(undefined *)(arg2 + 8) = 1;
        func_0x00018002c050(arg2, 0);
    }
    uVar13 = 0;
    *(undefined8 *)arg1 = *(undefined8 *)(arg1 + 0xb8);
    piVar10 = &var_38h;
    if (*(uint32_t *)(arg1 + 0xdc) < 2) goto code_r0x000180029bd5;
    func_0x00018002c250(arg1 + 8, *(uint32_t *)(arg1 + 0xdc));
    puVar7 = *(undefined8 **)(arg1 + 0x30);
    iVar8 = *(int64_t *)(arg1 + 0x28);
    uVar11 = (uint64_t)*(uint32_t *)(arg1 + 0xdc);
    uVar16 = (int64_t)puVar7 - iVar8 >> 4;
    if (uVar11 < uVar16) {
        *(uint64_t *)(arg1 + 0x30) = uVar11 * 0x10 + iVar8;
        piVar10 = &var_38h;
        goto code_r0x000180029bd5;
    }
    piVar10 = &var_38h;
    if (uVar11 <= uVar16) goto code_r0x000180029bd5;
    uVar6 = *(int64_t *)(arg1 + 0x38) - iVar8 >> 4;
    if (uVar11 <= uVar6) {
        for (iVar8 = uVar11 - uVar16; iVar8 != 0; iVar8 = iVar8 + -1) {
            *puVar7 = 0;
            puVar7[1] = 0;
            puVar7 = puVar7 + 2;
        }
        *(undefined8 **)(arg1 + 0x30) = puVar7;
        piVar10 = &var_38h;
        goto code_r0x000180029bd5;
    }
    if ((0xfffffffffffffff - (uVar6 >> 1) < uVar6) ||
       ((uVar6 = uVar6 + (uVar6 >> 1), uVar15 = uVar11, uVar11 <= uVar6 && (uVar15 = uVar6, 0xfffffffffffffff < uVar6)))
       ) {
code_r0x000180029d71:
        fcn.180004720();
        pcVar2 = (code *)swi(3);
        cVar3 = (*pcVar2)();
        return cVar3;
    }
    uVar15 = uVar15 * 0x10;
    if (uVar15 == 0) {
code_r0x000180029b15:
        puVar7 = (undefined8 *)(uVar16 * 0x10 + uVar13);
        for (iVar8 = uVar11 - uVar16; iVar8 != 0; iVar8 = iVar8 + -1) {
            *puVar7 = 0;
            puVar7[1] = 0;
            puVar7 = puVar7 + 2;
        }
        fcn.180498030(uVar13, *(int64_t *)(arg1 + 0x28), *(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x28));
        iVar8 = *(int64_t *)(arg1 + 0x28);
        if (iVar8 != 0) {
            iVar4 = iVar8;
            piVar9 = &var_38h;
            if ((0xfff < (*(int64_t *)(arg1 + 0x38) - iVar8 & 0xfffffffffffffff0U)) &&
               (iVar4 = *(int64_t *)(iVar8 + -8), piVar9 = &var_38h, unaff_RBP = uVar13, 0x1f < (iVar8 - iVar4) - 8U))
            goto code_r0x000180029b88;
            goto code_r0x000180029b92;
        }
    } else {
        if (uVar15 < 0x1000) {
            uVar13 = fcn.180459890(uVar15);
            goto code_r0x000180029b15;
        }
        if (uVar15 + 0x27 <= uVar15) goto code_r0x000180029d71;
        iVar8 = fcn.180459890();
        if (iVar8 != 0) {
            uVar13 = iVar8 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar13 - 8) = iVar8;
            goto code_r0x000180029b15;
        }
code_r0x000180029b88:
        pcVar2 = (code *)swi(0x29);
        iVar4 = (*pcVar2)(5);
        piVar9 = (int64_t *)auStack_30;
        uVar13 = unaff_RBP;
code_r0x000180029b92:
        *(undefined8 *)((int64_t)piVar9 + -8) = 0x180029b97;
        fcn.180459c3c(iVar4);
    }
    *(uint64_t *)(arg1 + 0x28) = uVar13;
    *(uint64_t *)(arg1 + 0x30) = uVar11 * 0x10 + uVar13;
    *(uint64_t *)(arg1 + 0x38) = uVar15 + uVar13;
    piVar10 = piVar9;
code_r0x000180029bd5:
    uVar5 = *(undefined8 *)(arg1 + 200);
    *(undefined *)(arg1 + 0xf0) = 0;
    *(undefined4 *)(arg1 + 0xf4) = 10000000;
    *(undefined4 *)(arg1 + 0xf8) = 600;
    *(undefined8 *)(arg1 + 0xb0) = 0;
    *(undefined *)(arg1 + 0xd8) = 0;
    *(undefined8 *)((int64_t)piVar10 + -8) = 0x180029c0d;
    cVar3 = func_0x00018002aab0(arg1, uVar5);
    if (cVar3 != '\0') {
        if (arg2 != 0) {
            uVar1 = *(undefined4 *)(arg1 + 0xdc);
            *(undefined8 *)((int64_t)piVar10 + -8) = 0x180029c2c;
            func_0x00018002c050(arg2, uVar1);
            puVar7 = *(undefined8 **)(arg2 + 0x10);
            uVar13 = 1;
            puVar14 = (undefined8 *)(arg1 + 0x40);
            if (*(char *)(arg1 + 0xe0) == '\0') {
                puVar14 = (undefined8 *)arg1;
            }
            *(undefined *)(puVar7 + 2) = 1;
            *puVar7 = *(undefined8 *)(arg1 + 0xb8);
            puVar7[1] = *puVar14;
            if (1 < *(uint32_t *)(arg1 + 0xdc)) {
                do {
                    iVar8 = uVar13 * 0x18;
                    if ((*(uint32_t *)(puVar14[1] + (uVar13 >> 5) * 4) >> ((uint8_t)uVar13 & 0x1f) & 1) == 0) {
                        *(undefined *)(*(int64_t *)(arg2 + 0x10) + 0x10 + iVar8) = 0;
                        *(undefined8 *)(iVar8 + *(int64_t *)(arg2 + 0x10)) = *(undefined8 *)(arg1 + 0xc0);
                        uVar5 = *(undefined8 *)(arg1 + 0xc0);
                    } else {
                        *(undefined *)(*(int64_t *)(arg2 + 0x10) + 0x10 + iVar8) = 1;
                        *(undefined8 *)(iVar8 + *(int64_t *)(arg2 + 0x10)) = *(undefined8 *)(puVar14[5] + uVar13 * 0x10)
                        ;
                        uVar5 = *(undefined8 *)(puVar14[5] + 8 + uVar13 * 0x10);
                    }
                    uVar12 = (int32_t)uVar13 + 1;
                    uVar13 = (uint64_t)uVar12;
                    *(undefined8 *)(*(int64_t *)(arg2 + 0x10) + 8 + iVar8) = uVar5;
                } while (uVar12 < *(uint32_t *)(arg1 + 0xdc));
            }
            *(undefined8 *)arg2 = *(undefined8 *)(arg1 + 0xb8);
            iVar8 = *(int64_t *)(arg1 + 0xb8);
            *(int64_t *)(arg2 + 0x28) = iVar8;
            iVar4 = **(int64_t **)(arg2 + 0x10);
            *(int64_t *)(arg2 + 0x30) = iVar4;
            *(bool *)(arg2 + 0x38) = iVar8 != iVar4;
            iVar8 = (*(int64_t **)(arg2 + 0x10))[1];
            *(int64_t *)(arg2 + 0x40) = iVar8;
            iVar4 = *(int64_t *)(arg1 + 0xc0);
            *(int64_t *)(arg2 + 0x48) = iVar4;
            *(bool *)(arg2 + 0x50) = iVar8 != iVar4;
            *(undefined8 *)(arg2 + 0x58) = *(undefined8 *)(arg1 + 0xc0);
            *(undefined8 *)(arg2 + 0x60) = *(undefined8 *)(arg1 + 0xc0);
        }
        cVar3 = '\x01';
    }
    return cVar3;
}

// ============================================================
// Function: FUN_180029d80
// Address: 0x180029d80
// Size: 48 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180029d80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t var_8h;
    
    fcn.180498030(arg3, arg1, arg2 - arg1);
    return (arg2 - arg1) + arg3;
}

// ============================================================
// Function: FUN_180029db0
// Address: 0x180029db0
// Size: 313 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch

int64_t fcn.180029db0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    char *pcVar1;
    uint8_t uVar2;
    int64_t *piVar3;
    char cVar4;
    undefined8 uVar5;
    uint8_t **ppuVar6;
    char cVar7;
    undefined *puVar8;
    int64_t iVar9;
    uint8_t *arg3_00;
    undefined *puVar10;
    uint64_t uVar11;
    int32_t iVar12;
    char *pcVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar9 = arg_28h;
    if (arg_28h == 0) {
        iVar9 = *(int64_t *)(arg1 + 200);
    }
    if (arg3 == arg4) {
code_r0x000180029e18:
        *(int64_t *)arg2 = arg3;
        return arg2;
    }
code_r0x000180029df2:
    for (; iVar9 != 0; iVar9 = *(int64_t *)(iVar9 + 0x10)) {
    // switch table (22 cases) at 0x18002a0d0
        switch(*(undefined4 *)(iVar9 + 8)) {
        default:
            goto code_r0x000180029e18;
        case 1:
        case 8:
        case 9:
        case 0xb:
        case 0xd:
        case 0xe:
        case 0x11:
        case 0x14:
            break;
        case 2:
            if ((*(uint32_t *)(arg1 + 0xd0) & 0x1000) == 0) goto code_r0x000180029eb5;
            if ((*(char *)(arg3 + -1) != '\n') && (*(char *)(arg3 + -1) != '\r')) {
                ppuVar6 = (uint8_t **)func_0x00018002a2d0(&arg_28h, arg3, arg4, 0x180000000, 0x1806220c2);
                arg3 = (int64_t)*ppuVar6;
                if (arg3 != arg4) {
                    arg3 = arg3 + 1;
                }
            }
            goto code_r0x000180029e84;
        case 3:
            if ((*(uint32_t *)(arg1 + 0xd0) & 0x1000) != 0) {
                func_0x00018002a2d0(arg2, arg3, arg4, 0x180000000, 0x1806220c2);
                return arg2;
            }
            goto code_r0x000180029eb5;
        case 4:
            cVar7 = *(char *)((uint64_t)*(uint8_t *)(arg3 + -1) + 0x1806220d0);
            while (uVar2 = *(uint8_t *)arg3,
                  (*(uint32_t *)(iVar9 + 0xc) & 1) != (uint32_t)(*(char *)((uint64_t)uVar2 + 0x1806220d0) == cVar7)) {
                arg3 = arg3 + 1;
                cVar7 = *(char *)((uint64_t)uVar2 + 0x1806220d0);
                if (arg3 == arg4) {
                    *(int64_t *)arg2 = arg3;
                    return arg2;
                }
            }
            goto code_r0x000180029e84;
        case 6:
            var_18h = *(int64_t *)(iVar9 + 0x28);
            uVar11 = (uint64_t)*(uint32_t *)(iVar9 + 0x24);
            if ((*(uint32_t *)(arg1 + 0xd0) & 0x100) == 0) {
                if ((int64_t)uVar11 <= arg4 - arg3) {
                    uVar5 = func_0x0001804581c0(arg3, arg4, var_18h);
                    *(undefined8 *)arg2 = uVar5;
                    return arg2;
                }
code_r0x000180029eb5:
                *(int64_t *)arg2 = arg4;
                return arg2;
            }
            puVar8 = (undefined *)arg4;
            if (arg4 - arg3 < (int64_t)uVar11) goto code_r0x000180029f52;
            iVar9 = *(int64_t *)(arg1 + 0xe8);
            pcVar1 = (char *)(var_18h + uVar11);
            arg_28h = arg4 - uVar11;
            puVar8 = (undefined *)arg3;
            puVar10 = (undefined *)arg3;
            pcVar13 = (char *)var_18h;
            if ((char *)var_18h == pcVar1) goto code_r0x000180029f52;
            goto code_r0x000180029f10;
        case 7:
            goto code_r0x000180029f80;
        case 10:
            if ((uint32_t)arg_30h < 0x32) {
                iVar12 = (uint32_t)arg_30h + 1;
                ppuVar6 = (uint8_t **)
                          fcn.180029db0(arg1, (int64_t)&arg_28h, arg3, arg4, *(int64_t *)(iVar9 + 0x20), 
                                        CONCAT44(var_30h._4_4_, iVar12));
                arg3 = (int64_t)*ppuVar6;
                ppuVar6 = (uint8_t **)
                          fcn.180029db0(arg1, (int64_t)&arg_28h, arg3, arg4, *(int64_t *)(iVar9 + 0x10), 
                                        CONCAT44(var_30h._4_4_, iVar12));
                arg3_00 = *ppuVar6;
                if (arg3_00 != (uint8_t *)arg3) {
                    while( true ) {
                        ppuVar6 = (uint8_t **)
                                  fcn.180029db0(arg1, (int64_t)&var_18h, (int64_t)arg3_00, arg4, 
                                                *(int64_t *)(iVar9 + 0x20), CONCAT44(var_30h._4_4_, iVar12));
                        arg3 = (int64_t)*ppuVar6;
                        if (arg3_00 == (uint8_t *)arg3) break;
                        ppuVar6 = (uint8_t **)
                                  fcn.180029db0(arg1, (int64_t)&arg_28h, arg3, arg4, *(int64_t *)(iVar9 + 0x10), 
                                                CONCAT44(var_30h._4_4_, iVar12));
                        arg3_00 = *ppuVar6;
                        if (arg3_00 == (uint8_t *)arg3) {
                            *(int64_t *)arg2 = arg3;
                            return arg2;
                        }
                    }
                }
                goto code_r0x000180029e84;
            }
            goto code_r0x000180029e18;
        case 0xc:
            goto code_r0x000180029e0d;
        case 0x10:
            if (*(int64_t *)(iVar9 + 0x28) != 0) goto code_r0x000180029e18;
            break;
        case 0x12:
            if (*(int32_t *)(iVar9 + 0x20) == 0) goto code_r0x000180029e18;
        }
    }
    goto code_r0x000180029e18;
code_r0x000180029e0d:
    iVar9 = 0;
    goto code_r0x000180029df2;
code_r0x000180029f10:
    piVar3 = *(int64_t **)(iVar9 + 8);
    cVar7 = *pcVar13;
    cVar4 = (**(code **)(*piVar3 + 0x20))(piVar3, *puVar10);
    if (cVar4 != cVar7) {
        puVar8 = (undefined *)arg4;
        if (arg3 == arg_28h) {
code_r0x000180029f52:
            *(undefined **)arg2 = puVar8;
            return arg2;
        }
        arg3 = arg3 + 1;
        puVar10 = (undefined *)arg3;
        pcVar13 = (char *)var_18h;
        goto code_r0x000180029f10;
    }
    puVar8 = (undefined *)arg3;
    if (pcVar13 + 1 == pcVar1) goto code_r0x000180029f52;
    puVar10 = puVar10 + 1;
    pcVar13 = pcVar13 + 1;
    goto code_r0x000180029f10;
code_r0x000180029f80:
    while( true ) {
        ppuVar6 = (uint8_t **)func_0x00018002a380(arg1, &arg_28h, iVar9, arg3);
        if (*ppuVar6 != (uint8_t *)arg3) break;
        arg3 = arg3 + 1;
        if (arg3 == arg4) {
            *(int64_t *)arg2 = arg3;
            return arg2;
        }
    }
code_r0x000180029e84:
    *(int64_t *)arg2 = arg3;
    return arg2;
}

// ============================================================
// Function: FUN_180029ee9
// Address: 0x180029ee9
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch

int64_t fcn.180029db0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    char *pcVar1;
    uint8_t uVar2;
    int64_t *piVar3;
    char cVar4;
    undefined8 uVar5;
    uint8_t **ppuVar6;
    char cVar7;
    undefined *puVar8;
    int64_t iVar9;
    uint8_t *arg3_00;
    undefined *puVar10;
    uint64_t uVar11;
    int32_t iVar12;
    char *pcVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar9 = arg_28h;
    if (arg_28h == 0) {
        iVar9 = *(int64_t *)(arg1 + 200);
    }
    if (arg3 == arg4) {
code_r0x000180029e18:
        *(int64_t *)arg2 = arg3;
        return arg2;
    }
code_r0x000180029df2:
    for (; iVar9 != 0; iVar9 = *(int64_t *)(iVar9 + 0x10)) {
    // switch table (22 cases) at 0x18002a0d0
        switch(*(undefined4 *)(iVar9 + 8)) {
        default:
            goto code_r0x000180029e18;
        case 1:
        case 8:
        case 9:
        case 0xb:
        case 0xd:
        case 0xe:
        case 0x11:
        case 0x14:
            break;
        case 2:
            if ((*(uint32_t *)(arg1 + 0xd0) & 0x1000) == 0) goto code_r0x000180029eb5;
            if ((*(char *)(arg3 + -1) != '\n') && (*(char *)(arg3 + -1) != '\r')) {
                ppuVar6 = (uint8_t **)func_0x00018002a2d0(&arg_28h, arg3, arg4, 0x180000000, 0x1806220c2);
                arg3 = (int64_t)*ppuVar6;
                if (arg3 != arg4) {
                    arg3 = arg3 + 1;
                }
            }
            goto code_r0x000180029e84;
        case 3:
            if ((*(uint32_t *)(arg1 + 0xd0) & 0x1000) != 0) {
                func_0x00018002a2d0(arg2, arg3, arg4, 0x180000000, 0x1806220c2);
                return arg2;
            }
            goto code_r0x000180029eb5;
        case 4:
            cVar7 = *(char *)((uint64_t)*(uint8_t *)(arg3 + -1) + 0x1806220d0);
            while (uVar2 = *(uint8_t *)arg3,
                  (*(uint32_t *)(iVar9 + 0xc) & 1) != (uint32_t)(*(char *)((uint64_t)uVar2 + 0x1806220d0) == cVar7)) {
                arg3 = arg3 + 1;
                cVar7 = *(char *)((uint64_t)uVar2 + 0x1806220d0);
                if (arg3 == arg4) {
                    *(int64_t *)arg2 = arg3;
                    return arg2;
                }
            }
            goto code_r0x000180029e84;
        case 6:
            var_18h = *(int64_t *)(iVar9 + 0x28);
            uVar11 = (uint64_t)*(uint32_t *)(iVar9 + 0x24);
            if ((*(uint32_t *)(arg1 + 0xd0) & 0x100) == 0) {
                if ((int64_t)uVar11 <= arg4 - arg3) {
                    uVar5 = func_0x0001804581c0(arg3, arg4, var_18h);
                    *(undefined8 *)arg2 = uVar5;
                    return arg2;
                }
code_r0x000180029eb5:
                *(int64_t *)arg2 = arg4;
                return arg2;
            }
            puVar8 = (undefined *)arg4;
            if (arg4 - arg3 < (int64_t)uVar11) goto code_r0x000180029f52;
            iVar9 = *(int64_t *)(arg1 + 0xe8);
            pcVar1 = (char *)(var_18h + uVar11);
            arg_28h = arg4 - uVar11;
            puVar8 = (undefined *)arg3;
            puVar10 = (undefined *)arg3;
            pcVar13 = (char *)var_18h;
            if ((char *)var_18h == pcVar1) goto code_r0x000180029f52;
            goto code_r0x000180029f10;
        case 7:
            goto code_r0x000180029f80;
        case 10:
            if ((uint32_t)arg_30h < 0x32) {
                iVar12 = (uint32_t)arg_30h + 1;
                ppuVar6 = (uint8_t **)
                          fcn.180029db0(arg1, (int64_t)&arg_28h, arg3, arg4, *(int64_t *)(iVar9 + 0x20), 
                                        CONCAT44(var_30h._4_4_, iVar12));
                arg3 = (int64_t)*ppuVar6;
                ppuVar6 = (uint8_t **)
                          fcn.180029db0(arg1, (int64_t)&arg_28h, arg3, arg4, *(int64_t *)(iVar9 + 0x10), 
                                        CONCAT44(var_30h._4_4_, iVar12));
                arg3_00 = *ppuVar6;
                if (arg3_00 != (uint8_t *)arg3) {
                    while( true ) {
                        ppuVar6 = (uint8_t **)
                                  fcn.180029db0(arg1, (int64_t)&var_18h, (int64_t)arg3_00, arg4, 
                                                *(int64_t *)(iVar9 + 0x20), CONCAT44(var_30h._4_4_, iVar12));
                        arg3 = (int64_t)*ppuVar6;
                        if (arg3_00 == (uint8_t *)arg3) break;
                        ppuVar6 = (uint8_t **)
                                  fcn.180029db0(arg1, (int64_t)&arg_28h, arg3, arg4, *(int64_t *)(iVar9 + 0x10), 
                                                CONCAT44(var_30h._4_4_, iVar12));
                        arg3_00 = *ppuVar6;
                        if (arg3_00 == (uint8_t *)arg3) {
                            *(int64_t *)arg2 = arg3;
                            return arg2;
                        }
                    }
                }
                goto code_r0x000180029e84;
            }
            goto code_r0x000180029e18;
        case 0xc:
            goto code_r0x000180029e0d;
        case 0x10:
            if (*(int64_t *)(iVar9 + 0x28) != 0) goto code_r0x000180029e18;
            break;
        case 0x12:
            if (*(int32_t *)(iVar9 + 0x20) == 0) goto code_r0x000180029e18;
        }
    }
    goto code_r0x000180029e18;
code_r0x000180029e0d:
    iVar9 = 0;
    goto code_r0x000180029df2;
code_r0x000180029f10:
    piVar3 = *(int64_t **)(iVar9 + 8);
    cVar7 = *pcVar13;
    cVar4 = (**(code **)(*piVar3 + 0x20))(piVar3, *puVar10);
    if (cVar4 != cVar7) {
        puVar8 = (undefined *)arg4;
        if (arg3 == arg_28h) {
code_r0x000180029f52:
            *(undefined **)arg2 = puVar8;
            return arg2;
        }
        arg3 = arg3 + 1;
        puVar10 = (undefined *)arg3;
        pcVar13 = (char *)var_18h;
        goto code_r0x000180029f10;
    }
    puVar8 = (undefined *)arg3;
    if (pcVar13 + 1 == pcVar1) goto code_r0x000180029f52;
    puVar10 = puVar10 + 1;
    pcVar13 = pcVar13 + 1;
    goto code_r0x000180029f10;
code_r0x000180029f80:
    while( true ) {
        ppuVar6 = (uint8_t **)func_0x00018002a380(arg1, &arg_28h, iVar9, arg3);
        if (*ppuVar6 != (uint8_t *)arg3) break;
        arg3 = arg3 + 1;
        if (arg3 == arg4) {
            *(int64_t *)arg2 = arg3;
            return arg2;
        }
    }
code_r0x000180029e84:
    *(int64_t *)arg2 = arg3;
    return arg2;
}

// ============================================================
// Function: FUN_180029f52
// Address: 0x180029f52
// Size: 470 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch

int64_t fcn.180029db0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    char *pcVar1;
    uint8_t uVar2;
    int64_t *piVar3;
    char cVar4;
    undefined8 uVar5;
    uint8_t **ppuVar6;
    char cVar7;
    undefined *puVar8;
    int64_t iVar9;
    uint8_t *arg3_00;
    undefined *puVar10;
    uint64_t uVar11;
    int32_t iVar12;
    char *pcVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar9 = arg_28h;
    if (arg_28h == 0) {
        iVar9 = *(int64_t *)(arg1 + 200);
    }
    if (arg3 == arg4) {
code_r0x000180029e18:
        *(int64_t *)arg2 = arg3;
        return arg2;
    }
code_r0x000180029df2:
    for (; iVar9 != 0; iVar9 = *(int64_t *)(iVar9 + 0x10)) {
    // switch table (22 cases) at 0x18002a0d0
        switch(*(undefined4 *)(iVar9 + 8)) {
        default:
            goto code_r0x000180029e18;
        case 1:
        case 8:
        case 9:
        case 0xb:
        case 0xd:
        case 0xe:
        case 0x11:
        case 0x14:
            break;
        case 2:
            if ((*(uint32_t *)(arg1 + 0xd0) & 0x1000) == 0) goto code_r0x000180029eb5;
            if ((*(char *)(arg3 + -1) != '\n') && (*(char *)(arg3 + -1) != '\r')) {
                ppuVar6 = (uint8_t **)func_0x00018002a2d0(&arg_28h, arg3, arg4, 0x180000000, 0x1806220c2);
                arg3 = (int64_t)*ppuVar6;
                if (arg3 != arg4) {
                    arg3 = arg3 + 1;
                }
            }
            goto code_r0x000180029e84;
        case 3:
            if ((*(uint32_t *)(arg1 + 0xd0) & 0x1000) != 0) {
                func_0x00018002a2d0(arg2, arg3, arg4, 0x180000000, 0x1806220c2);
                return arg2;
            }
            goto code_r0x000180029eb5;
        case 4:
            cVar7 = *(char *)((uint64_t)*(uint8_t *)(arg3 + -1) + 0x1806220d0);
            while (uVar2 = *(uint8_t *)arg3,
                  (*(uint32_t *)(iVar9 + 0xc) & 1) != (uint32_t)(*(char *)((uint64_t)uVar2 + 0x1806220d0) == cVar7)) {
                arg3 = arg3 + 1;
                cVar7 = *(char *)((uint64_t)uVar2 + 0x1806220d0);
                if (arg3 == arg4) {
                    *(int64_t *)arg2 = arg3;
                    return arg2;
                }
            }
            goto code_r0x000180029e84;
        case 6:
            var_18h = *(int64_t *)(iVar9 + 0x28);
            uVar11 = (uint64_t)*(uint32_t *)(iVar9 + 0x24);
            if ((*(uint32_t *)(arg1 + 0xd0) & 0x100) == 0) {
                if ((int64_t)uVar11 <= arg4 - arg3) {
                    uVar5 = func_0x0001804581c0(arg3, arg4, var_18h);
                    *(undefined8 *)arg2 = uVar5;
                    return arg2;
                }
code_r0x000180029eb5:
                *(int64_t *)arg2 = arg4;
                return arg2;
            }
            puVar8 = (undefined *)arg4;
            if (arg4 - arg3 < (int64_t)uVar11) goto code_r0x000180029f52;
            iVar9 = *(int64_t *)(arg1 + 0xe8);
            pcVar1 = (char *)(var_18h + uVar11);
            arg_28h = arg4 - uVar11;
            puVar8 = (undefined *)arg3;
            puVar10 = (undefined *)arg3;
            pcVar13 = (char *)var_18h;
            if ((char *)var_18h == pcVar1) goto code_r0x000180029f52;
            goto code_r0x000180029f10;
        case 7:
            goto code_r0x000180029f80;
        case 10:
            if ((uint32_t)arg_30h < 0x32) {
                iVar12 = (uint32_t)arg_30h + 1;
                ppuVar6 = (uint8_t **)
                          fcn.180029db0(arg1, (int64_t)&arg_28h, arg3, arg4, *(int64_t *)(iVar9 + 0x20), 
                                        CONCAT44(var_30h._4_4_, iVar12));
                arg3 = (int64_t)*ppuVar6;
                ppuVar6 = (uint8_t **)
                          fcn.180029db0(arg1, (int64_t)&arg_28h, arg3, arg4, *(int64_t *)(iVar9 + 0x10), 
                                        CONCAT44(var_30h._4_4_, iVar12));
                arg3_00 = *ppuVar6;
                if (arg3_00 != (uint8_t *)arg3) {
                    while( true ) {
                        ppuVar6 = (uint8_t **)
                                  fcn.180029db0(arg1, (int64_t)&var_18h, (int64_t)arg3_00, arg4, 
                                                *(int64_t *)(iVar9 + 0x20), CONCAT44(var_30h._4_4_, iVar12));
                        arg3 = (int64_t)*ppuVar6;
                        if (arg3_00 == (uint8_t *)arg3) break;
                        ppuVar6 = (uint8_t **)
                                  fcn.180029db0(arg1, (int64_t)&arg_28h, arg3, arg4, *(int64_t *)(iVar9 + 0x10), 
                                                CONCAT44(var_30h._4_4_, iVar12));
                        arg3_00 = *ppuVar6;
                        if (arg3_00 == (uint8_t *)arg3) {
                            *(int64_t *)arg2 = arg3;
                            return arg2;
                        }
                    }
                }
                goto code_r0x000180029e84;
            }
            goto code_r0x000180029e18;
        case 0xc:
            goto code_r0x000180029e0d;
        case 0x10:
            if (*(int64_t *)(iVar9 + 0x28) != 0) goto code_r0x000180029e18;
            break;
        case 0x12:
            if (*(int32_t *)(iVar9 + 0x20) == 0) goto code_r0x000180029e18;
        }
    }
    goto code_r0x000180029e18;
code_r0x000180029e0d:
    iVar9 = 0;
    goto code_r0x000180029df2;
code_r0x000180029f10:
    piVar3 = *(int64_t **)(iVar9 + 8);
    cVar7 = *pcVar13;
    cVar4 = (**(code **)(*piVar3 + 0x20))(piVar3, *puVar10);
    if (cVar4 != cVar7) {
        puVar8 = (undefined *)arg4;
        if (arg3 == arg_28h) {
code_r0x000180029f52:
            *(undefined **)arg2 = puVar8;
            return arg2;
        }
        arg3 = arg3 + 1;
        puVar10 = (undefined *)arg3;
        pcVar13 = (char *)var_18h;
        goto code_r0x000180029f10;
    }
    puVar8 = (undefined *)arg3;
    if (pcVar13 + 1 == pcVar1) goto code_r0x000180029f52;
    puVar10 = puVar10 + 1;
    pcVar13 = pcVar13 + 1;
    goto code_r0x000180029f10;
code_r0x000180029f80:
    while( true ) {
        ppuVar6 = (uint8_t **)func_0x00018002a380(arg1, &arg_28h, iVar9, arg3);
        if (*ppuVar6 != (uint8_t *)arg3) break;
        arg3 = arg3 + 1;
        if (arg3 == arg4) {
            *(int64_t *)arg2 = arg3;
            return arg2;
        }
    }
code_r0x000180029e84:
    *(int64_t *)arg2 = arg3;
    return arg2;
}

// ============================================================
// Function: FUN_18002a130
// Address: 0x18002a130
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18002a130(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x40) {
            func_0x00018002a260(iVar3 + 0x28);
            func_0x00018002ee50(iVar3 + 8);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xffffffffffffffc0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18002a1b0;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18002a145
// Address: 0x18002a145
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18002a130(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x40) {
            func_0x00018002a260(iVar3 + 0x28);
            func_0x00018002ee50(iVar3 + 8);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xffffffffffffffc0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18002a1b0;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18002a18a
// Address: 0x18002a18a
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18002a130(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x40) {
            func_0x00018002a260(iVar3 + 0x28);
            func_0x00018002ee50(iVar3 + 8);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar3 & 0xffffffffffffffc0U)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18002a1b0;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18002a1f0
// Address: 0x18002a1f0
// Size: 111 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180029270(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined *puVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined *puVar7;
    uint64_t uVar8;
    undefined *puVar9;
    undefined8 uVar10;
    undefined8 uVar11;
    int64_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    undefined auStack_38 [32];
    
    puVar9 = auStack_38;
    puVar7 = *(undefined **)(arg1 + 8);
    if (puVar7 != *(undefined **)(arg1 + 0x10)) {
        *puVar7 = *(undefined *)arg2;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 1;
        return;
    }
    uVar8 = 0x7fffffffffffffff;
    iVar12 = (int64_t)puVar7 - *(int64_t *)arg1;
    if (iVar12 == 0x7fffffffffffffff) {
        fcn.180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar5 = (int64_t)*(undefined **)(arg1 + 0x10) - *(int64_t *)arg1;
    uVar6 = uVar5 >> 1;
    uVar1 = iVar12 + 1;
    if (uVar5 <= 0x7fffffffffffffff - uVar6) goto code_r0x000180029302;
    uVar5 = 0x8000000000000026;
    puVar9 = auStack_38;
    do {
        *(undefined8 *)(puVar9 + -8) = 0x1800292f6;
        iVar4 = fcn.180459890(uVar5);
        if (iVar4 != 0) {
            uVar5 = iVar4 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar5 - 8) = iVar4;
code_r0x00018002934a:
            *(undefined *)(iVar12 + uVar5) = *(undefined *)arg2;
            puVar2 = *(undefined **)arg1;
            if (puVar7 == *(undefined **)(arg1 + 8)) {
                iVar4 = (int64_t)*(undefined **)(arg1 + 8) - (int64_t)puVar2;
                uVar6 = uVar5;
                puVar7 = puVar2;
            } else {
                *(undefined8 *)(puVar9 + -8) = 0x180029371;
                fcn.180498030(uVar5, puVar2, (int64_t)puVar7 - (int64_t)puVar2);
                iVar4 = *(int64_t *)(arg1 + 8) - (int64_t)puVar7;
                uVar6 = iVar12 + 1 + uVar5;
            }
            *(undefined8 *)(puVar9 + -8) = 0x180029387;
            fcn.180498030(uVar6, puVar7, iVar4);
            uVar11 = *(undefined8 *)(puVar9 + 0x28);
            uVar10 = *(undefined8 *)(puVar9 + 0x30);
            *(undefined8 *)(puVar9 + 0x30) = *(undefined8 *)(puVar9 + 0x40);
            *(undefined8 *)(puVar9 + 0x28) = uVar10;
            *(undefined8 *)(puVar9 + 0x20) = *(undefined8 *)(puVar9 + 0x48);
            *(undefined8 *)(puVar9 + 0x18) = uVar11;
            iVar12 = *(int64_t *)arg1;
            if (iVar12 != 0) {
                iVar4 = iVar12;
                puVar7 = puVar9 + -0x10;
                if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar12)) &&
                   (iVar4 = *(int64_t *)(iVar12 + -8), puVar7 = puVar9 + -0x10, 0x1f < (iVar12 - iVar4) - 8U)) {
                    pcVar3 = (code *)swi(0x29);
                    iVar4 = (*pcVar3)(5);
                    puVar7 = puVar9 + -8;
                }
                *(undefined8 *)(puVar7 + -8) = 0x18002a243;
                fcn.180459c3c(iVar4);
            }
            *(uint64_t *)arg1 = uVar5;
            *(uint64_t *)(arg1 + 8) = uVar5 + uVar1;
            *(uint64_t *)(arg1 + 0x10) = uVar5 + uVar8;
            return;
        }
        uVar5 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)();
        puVar9 = puVar9 + 8;
code_r0x000180029302:
        uVar8 = uVar1;
        if (uVar1 <= uVar5 + uVar6) {
            uVar8 = uVar5 + uVar6;
        }
        if (uVar8 == 0) {
            uVar5 = 0;
            goto code_r0x00018002934a;
        }
        if (uVar8 < 0x1000) {
            *(undefined8 *)(puVar9 + -8) = 0x180029347;
            uVar5 = fcn.180459890(uVar8);
            goto code_r0x00018002934a;
        }
        uVar5 = uVar8 + 0x27;
        if (uVar5 <= uVar8) {
            *(undefined8 *)(puVar9 + -8) = 0x1800293bf;
            fcn.180004720();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
    } while( true );
}

// ============================================================
// Function: FUN_18002a260
// Address: 0x18002a260
// Size: 94 bytes
// ============================================================
void fcn.18002a260(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar1 = *(int64_t *)arg1;
    if (iVar1 != 0) {
        iVar3 = iVar1;
        puVar4 = auStack_28;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar1 & 0xfffffffffffffff0U)) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_28, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18002a2ab;
        fcn.180459c3c(iVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18002a2d0
// Address: 0x18002a2d0
// Size: 161 bytes
// ============================================================
int64_t fcn.18002a2d0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    undefined8 uVar1;
    char *pcVar2;
    
    if (arg_28h == 0x1806220c1) {
        uVar1 = fcn.1804580f0(arg2, arg3, 0xd);
        *(undefined8 *)arg1 = uVar1;
        return arg1;
    }
    if (0xf < arg3 - arg2) {
        uVar1 = fcn.180457ff0(arg2, arg3, 0x1806220c0, arg_28h);
        *(undefined8 *)arg1 = uVar1;
        return arg1;
    }
    if (arg2 != arg3) {
        do {
            if (arg_28h != 0x1806220c0) {
                pcVar2 = "\r\n";
                do {
                    if (*(char *)arg2 == *pcVar2) goto code_r0x00018002a365;
                    pcVar2 = pcVar2 + 1;
                } while (pcVar2 != (char *)arg_28h);
            }
            arg2 = arg2 + 1;
        } while (arg2 != arg3);
    }
code_r0x00018002a365:
    *(int64_t *)arg1 = arg2;
    return arg1;
}

// ============================================================
// Function: FUN_18002a380
// Address: 0x18002a380
// Size: 1832 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_10fh
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_107h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h

void fcn.18002a380(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined *puVar1;
    code *pcVar2;
    undefined auVar3 [16];
    bool bVar4;
    undefined uVar5;
    int64_t iVar6;
    undefined uVar7;
    char cVar8;
    uint8_t uVar9;
    int32_t iVar10;
    int64_t *piVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    uint32_t uVar15;
    undefined *puVar16;
    undefined *puVar17;
    undefined *puVar18;
    undefined *puVar19;
    undefined *puVar20;
    undefined *puVar21;
    int64_t iVar22;
    int64_t iVar23;
    uint32_t uVar24;
    uint32_t uVar25;
    uint64_t uVar26;
    int64_t **ppiVar27;
    int64_t var_20h;
    undefined8 uStack_140;
    undefined auStack_138 [8];
    undefined auStack_130 [24];
    int64_t var_118h;
    int64_t var_110h;
    undefined var_108h;
    undefined var_107h [3];
    uint32_t var_104h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    puVar21 = auStack_138;
    puVar18 = auStack_138;
    puVar20 = auStack_138;
    puVar19 = auStack_138;
    puVar17 = auStack_138;
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_138;
    uVar25 = 0;
    var_100h = var_100h & 0xffffffff00000000;
    var_118h._0_1_ = *(uint8_t *)arg4;
    piVar11 = (int64_t *)(arg1 + 0xe8);
    var_f0h = (int64_t)piVar11;
    var_e0h = arg1;
    var_d8h = arg3;
    var_c8h = arg2;
    if ((*(uint32_t *)(arg1 + 0xd0) & 0x100) != 0) {
        var_118h._0_1_ = (**(code **)(**(int64_t **)(*piVar11 + 8) + 0x20))();
    }
    uVar5 = var_108h;
    var_f8h = *(int64_t *)(arg3 + 0x20);
    if ((uint32_t *)var_f8h == (uint32_t *)0x0) {
code_r0x00018002a619:
        puVar16 = (undefined *)(arg4 + 1);
        iVar22 = *(int64_t *)(var_d8h + 0x38);
        puVar21 = auStack_138;
        var_d0h = iVar22;
        if (iVar22 != 0) {
            if ((*(uint32_t *)(arg1 + 0xd0) & 0x800) == 0) {
                if (*(uint32_t *)(iVar22 + 4) != 0) {
                    uVar14 = 0;
                    do {
                        if ((*(uint8_t *)(uVar14 + *(int64_t *)(iVar22 + 8)) <= (uint8_t)var_118h) &&
                           ((uint8_t)var_118h <=
                            *(uint8_t *)((uint64_t)((int32_t)uVar14 + 1) + *(int64_t *)(iVar22 + 8)))) {
                            bVar4 = true;
                            goto code_r0x00018002aa2e;
                        }
                        uVar25 = (int32_t)uVar14 + 2;
                        uVar14 = (uint64_t)uVar25;
                    } while (uVar25 < *(uint32_t *)(iVar22 + 4));
                }
                bVar4 = false;
                puVar17 = auStack_138;
            } else {
                ppiVar27 = (int64_t **)*piVar11;
                var_110h._0_1_ = (uint8_t)var_118h;
                var_e8h = (int64_t)ppiVar27;
                func_0x00018002e800(ppiVar27, &var_c0h, &var_110h);
                uVar14 = 0;
                var_104h = 0;
                if (*(int32_t *)(iVar22 + 4) != 0) {
                    do {
                        var_107h[0] = *(undefined *)(uVar14 + *(int64_t *)(iVar22 + 8));
                        var_108h = *(undefined *)((uint64_t)((int32_t)uVar14 + 1) + *(int64_t *)(iVar22 + 8));
                        _var_a0h = ZEXT816(0);
                        var_90h = 0;
                        var_88h = 0;
                        func_0x000180004830(&var_a0h, var_107h, 1);
                        piVar11 = &var_a0h;
                        if (0xf < (uint64_t)var_88h) {
                            piVar11 = (int64_t *)var_a0h;
                        }
                        (**(code **)(**ppiVar27 + 0x20))(*ppiVar27, &var_60h, piVar11);
                        if (0xf < (uint64_t)var_88h) {
                            uVar14 = var_88h + 1;
                            iVar22 = var_a0h;
                            if (uVar14 < 0x1000) {
code_r0x00018002a726:
                                fcn.180459c3c(iVar22, uVar14);
                                goto code_r0x00018002a72c;
                            }
                            iVar22 = *(int64_t *)(var_a0h + -8);
                            puVar17 = auStack_138;
                            if ((var_a0h - iVar22) - 8U < 0x20) {
                                uVar14 = var_88h + 0x28;
                                goto code_r0x00018002a726;
                            }
code_r0x00018002a954:
                            pcVar2 = (code *)swi(0x29);
                            (*pcVar2)(5);
                            puVar18 = puVar17 + 8;
code_r0x00018002a95b:
                            puVar17 = puVar18;
                            if (0xf < (uint64_t)var_a8h) {
                                if (0xfff < var_a8h + 1U) {
                                    iVar22 = *(int64_t *)(var_c0h + -8);
                                    puVar19 = puVar18;
                                    if (0x1f < (var_c0h - iVar22) - 8U) goto code_r0x00018002a9e9;
                                    *(undefined8 *)(puVar18 + -8) = 0x18002a98f;
                                    fcn.180459c3c(iVar22, var_a8h + 0x28);
                                    bVar4 = true;
                                    goto code_r0x00018002aa2e;
                                }
                                *(undefined8 *)(puVar18 + -8) = 0x18002a9a2;
                                fcn.180459c3c(var_c0h);
                            }
                            bVar4 = true;
                            goto code_r0x00018002aa2e;
                        }
code_r0x00018002a72c:
                        iVar6 = var_50h;
                        iVar22 = var_b0h;
                        uVar24 = uVar25 | 0xd;
                        var_100h = CONCAT44(var_100h._4_4_, uVar25) | 0xd;
                        piVar11 = &var_c0h;
                        if (0xf < (uint64_t)var_a8h) {
                            piVar11 = (int64_t *)var_c0h;
                        }
                        piVar12 = &var_60h;
                        if (0xf < (uint64_t)var_48h) {
                            piVar12 = (int64_t *)var_60h;
                        }
                        iVar23 = var_50h;
                        if ((uint64_t)var_b0h < (uint64_t)var_50h) {
                            iVar23 = var_b0h;
                        }
                        iVar10 = func_0x000180497f30(piVar12, piVar11, iVar23);
                        if (iVar10 == 0) {
                            if ((uint64_t)iVar6 < (uint64_t)iVar22) {
                                cVar8 = -1;
                                goto code_r0x00018002a77f;
                            }
                            if ((uint64_t)iVar22 < (uint64_t)iVar6) goto code_r0x00018002a77d;
code_r0x00018002a793:
                            _var_a0h = ZEXT816(0);
                            var_90h = 0;
                            var_88h = 0;
                            func_0x000180004830(&var_a0h, &var_108h, 1);
                            piVar11 = &var_a0h;
                            if (0xf < (uint64_t)var_88h) {
                                piVar11 = (int64_t *)var_a0h;
                            }
                            (**(code **)(**ppiVar27 + 0x20))(*ppiVar27, &var_80h, piVar11);
                            var_100h = CONCAT44(var_100h._4_4_, uVar25) | 0x3d;
                            if ((uint64_t)var_88h < 0x10) {
code_r0x00018002a827:
                                uVar14 = var_68h;
                                iVar6 = var_70h;
                                iVar22 = var_b0h;
                                uVar24 = 0x3f;
                                piVar11 = (int64_t *)CONCAT71(var_80h._1_7_, (undefined)var_80h);
                                piVar12 = &var_80h;
                                if (0xf < (uint64_t)var_68h) {
                                    piVar12 = piVar11;
                                }
                                piVar13 = &var_c0h;
                                if (0xf < (uint64_t)var_a8h) {
                                    piVar13 = (int64_t *)var_c0h;
                                }
                                iVar23 = var_b0h;
                                if ((uint64_t)var_70h < (uint64_t)var_b0h) {
                                    iVar23 = var_70h;
                                }
                                iVar10 = func_0x000180497f30(piVar13, piVar12, iVar23);
                                if (iVar10 == 0) {
                                    if ((uint64_t)iVar22 < (uint64_t)iVar6) {
                                        cVar8 = -1;
                                        goto code_r0x00018002a87b;
                                    }
                                    if ((uint64_t)iVar6 < (uint64_t)iVar22) goto code_r0x00018002a879;
                                } else {
                                    if (iVar10 < 0) {
                                        cVar8 = -1;
                                    } else {
code_r0x00018002a879:
                                        cVar8 = '\x01';
                                    }
code_r0x00018002a87b:
                                    if ('\0' < cVar8) {
                                        bVar4 = false;
                                        goto code_r0x00018002a887;
                                    }
                                }
                                bVar4 = true;
                                goto code_r0x00018002a887;
                            }
                            uVar14 = var_88h + 1;
                            iVar22 = var_a0h;
                            if (uVar14 < 0x1000) {
code_r0x00018002a822:
                                fcn.180459c3c(iVar22, uVar14);
                                goto code_r0x00018002a827;
                            }
                            iVar22 = *(int64_t *)(var_a0h + -8);
                            if ((var_a0h - iVar22) - 8U < 0x20) {
                                uVar14 = var_88h + 0x28;
                                goto code_r0x00018002a822;
                            }
code_r0x00018002a94d:
                            pcVar2 = (code *)swi(0x29);
                            (*pcVar2)(5);
                            puVar17 = auStack_130;
                            goto code_r0x00018002a954;
                        }
                        if (iVar10 < 0) {
                            cVar8 = -1;
                        } else {
code_r0x00018002a77d:
                            cVar8 = '\x01';
                        }
code_r0x00018002a77f:
                        if (cVar8 < '\x01') goto code_r0x00018002a793;
                        piVar11 = (int64_t *)CONCAT71(var_80h._1_7_, (undefined)var_80h);
                        bVar4 = false;
                        uVar14 = var_68h;
code_r0x00018002a887:
                        if ((uVar24 & 2) != 0) {
                            uVar24 = uVar24 & 0xfffffffd;
                            if (0xf < uVar14) {
                                uVar26 = uVar14 + 1;
                                piVar12 = piVar11;
                                if (0xfff < uVar26) {
                                    piVar12 = (int64_t *)piVar11[-1];
                                    if (0x1f < (uint64_t)((int64_t)piVar11 + (-8 - (int64_t)piVar12)))
                                    goto code_r0x00018002a94d;
                                    uVar26 = uVar14 + 0x28;
                                }
                                fcn.180459c3c(piVar12, uVar26);
                            }
                            var_70h = 0;
                            var_68h = 0xf;
                            var_80h._0_1_ = 0;
                        }
                        uVar25 = uVar24 & 0xfffffffe;
                        if (0xf < (uint64_t)var_48h) {
                            uVar14 = var_48h + 1;
                            iVar22 = var_60h;
                            if (0xfff < uVar14) {
                                iVar22 = *(int64_t *)(var_60h + -8);
                                puVar17 = auStack_138;
                                if (0x1f < (var_60h - iVar22) - 8U) goto code_r0x00018002a954;
                                uVar14 = var_48h + 0x28;
                            }
                            fcn.180459c3c(iVar22, uVar14);
                        }
                        if (bVar4) goto code_r0x00018002a95b;
                        var_104h = var_104h + 2;
                        uVar14 = (uint64_t)var_104h;
                        iVar22 = var_d0h;
                        ppiVar27 = (int64_t **)var_e8h;
                    } while (var_104h < *(uint32_t *)(var_d0h + 4));
                }
                if ((uint64_t)var_a8h < 0x10) goto code_r0x00018002a9f8;
                iVar22 = var_c0h;
                puVar20 = auStack_138;
                if (var_a8h + 1U < 0x1000) goto code_r0x00018002a9f0;
                puVar19 = auStack_138;
                if (0x1f < (var_c0h - *(int64_t *)(var_c0h + -8)) - 8U) goto code_r0x00018002a9e9;
                fcn.180459c3c(*(int64_t *)(var_c0h + -8), var_a8h + 0x28);
                bVar4 = false;
                puVar17 = auStack_138;
            }
            goto code_r0x00018002aa2e;
        }
    } else {
        var_104h = *(uint32_t *)(arg1 + 0xd0);
        var_d0h = *piVar11;
        puVar1 = *(undefined **)(arg1 + 0xc0);
        var_a8h = 0xf;
        stack0xffffffffffffff42 = SUB1614(ZEXT816(0), 2);
        auVar3._14_2_ = 0;
        auVar3._0_14_ = stack0xffffffffffffff42;
        _var_c0h = auVar3 << 0x10;
        var_100h = 1;
        var_b0h = 1;
        var_c0h._0_1_ = (uint8_t)var_118h;
        uVar26 = 1;
        puVar16 = (undefined *)(arg4 + 1);
        uVar14 = (uint64_t)*(uint32_t *)var_f8h;
        var_e8h = uVar14;
        if (1 < uVar14) {
            do {
                iVar22 = var_b0h;
                if (puVar16 == puVar1) break;
                uVar7 = *puVar16;
                var_100h = var_b0h;
                if ((var_104h >> 8 & 1) != 0) {
                    uVar7 = (**(code **)(**(int64_t **)(var_d0h + 8) + 0x20))(*(int64_t **)(var_d0h + 8), uVar7);
                    uVar14 = var_e8h;
                }
                if ((uint64_t)iVar22 < (uint64_t)var_a8h) {
                    var_b0h = iVar22 + 1;
                    piVar11 = &var_c0h;
                    if (0xf < (uint64_t)var_a8h) {
                        piVar11 = (int64_t *)var_c0h;
                    }
                    *(undefined *)((int64_t)piVar11 + iVar22) = uVar7;
                    *(undefined *)((int64_t)piVar11 + iVar22 + 1) = 0;
                } else {
                    func_0x00018000f010(&var_c0h, 1, uVar5);
                    uVar14 = var_e8h;
                }
                uVar26 = uVar26 + 1;
                puVar16 = puVar16 + 1;
                var_100h = var_b0h;
            } while (uVar26 < uVar14);
        }
        piVar12 = (int64_t *)var_c0h;
        uVar14 = var_b0h;
        var_100h = var_b0h;
        do {
            uVar24 = *(uint32_t *)var_f8h;
            uVar26 = (uint64_t)uVar24;
            if (uVar26 <= uVar14) {
                piVar11 = &var_c0h;
                if (0xf < (uint64_t)var_a8h) {
                    piVar11 = piVar12;
                }
                iVar22 = *(int64_t *)(var_f8h + 0x10);
                uVar14 = var_100h;
                for (uVar15 = *(uint32_t *)(var_f8h + 0xc); puVar16 = (undefined *)(uint64_t)uVar15, var_100h = uVar14,
                    uVar24 <= uVar15; uVar15 = uVar15 - uVar24) {
                    iVar10 = func_0x000180497f30(piVar11, iVar22, uVar26);
                    if (iVar10 == 0) {
                        if (0xf < (uint64_t)var_a8h) {
                            iVar22 = var_c0h;
                            if ((0xfff < var_a8h + 1U) &&
                               (iVar22 = *(int64_t *)(var_c0h + -8), 0x1f < (var_c0h - iVar22) - 8U))
                            goto code_r0x00018002a9e9;
                            fcn.180459c3c(iVar22);
                        }
                        puVar16 = (undefined *)(uVar26 + arg4);
                        piVar11 = (int64_t *)var_f0h;
                        arg1 = var_e0h;
                        if (puVar16 == (undefined *)arg4) goto code_r0x00018002a619;
                        uVar9 = 1;
                        goto code_r0x00018002aa66;
                    }
                    iVar22 = iVar22 + uVar26;
                    piVar12 = (int64_t *)var_c0h;
                    uVar14 = var_100h;
                }
            }
            var_f8h = *(int64_t *)(var_f8h + 0x18);
        } while (var_f8h != 0);
        piVar11 = (int64_t *)var_f0h;
        arg1 = var_e0h;
        if ((uint64_t)var_a8h < 0x10) goto code_r0x00018002a619;
        piVar11 = piVar12;
        if ((var_a8h + 1U < 0x1000) ||
           (piVar11 = (int64_t *)piVar12[-1], puVar19 = auStack_138,
           (uint64_t)((int64_t)piVar12 + (-8 - (int64_t)piVar11)) < 0x20)) {
            fcn.180459c3c(piVar11);
            piVar11 = (int64_t *)var_f0h;
            arg1 = var_e0h;
            goto code_r0x00018002a619;
        }
code_r0x00018002a9e9:
        pcVar2 = (code *)swi(0x29);
        iVar22 = (*pcVar2)(5);
        puVar20 = puVar19 + 8;
code_r0x00018002a9f0:
        *(undefined8 *)(puVar20 + -8) = 0x18002a9f8;
        fcn.180459c3c(iVar22);
code_r0x00018002a9f8:
        bVar4 = false;
        puVar17 = puVar20;
code_r0x00018002aa2e:
        puVar21 = puVar17;
        if (bVar4) {
            uVar9 = 1;
            goto code_r0x00018002aa66;
        }
    }
    if ((*(int64_t *)(var_d8h + 0x28) == 0) ||
       ((*(uint8_t *)((uint64_t)((uint8_t)puVar21[0x20] >> 3) + *(int64_t *)(var_d8h + 0x28)) &
        (uint8_t)(1 << (puVar21[0x20] & 7))) == 0)) {
        uVar9 = 0;
    } else {
        uVar9 = 1;
    }
code_r0x00018002aa66:
    if (uVar9 == (*(uint8_t *)(var_d8h + 0xc) & 1)) {
        *(int64_t *)var_c8h = arg4;
    } else {
        *(undefined **)var_c8h = puVar16;
    }
    *(undefined8 *)(puVar21 + -8) = 0x18002aa8d;
    func_0x000180459870(var_40h ^ (uint64_t)puVar21);
    return;
}

// ============================================================
// Function: FUN_18002aab0
// Address: 0x18002aab0
// Size: 3764 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_10fh
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_107h
// WARNING: [rz-ghidra] Detected overlap for variable var_108h

uint64_t fcn.18002aab0(int64_t arg1, int64_t arg2)
{
    uint32_t *puVar1;
    uint8_t *puVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    uint8_t uVar6;
    char cVar7;
    char cVar8;
    int32_t iVar9;
    uint64_t uVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int64_t iVar13;
    uint32_t uVar14;
    char *pcVar15;
    char *pcVar16;
    uint64_t uVar17;
    int64_t iVar18;
    char *pcVar19;
    uint64_t uVar20;
    int64_t iVar21;
    uint32_t uVar22;
    char *pcVar23;
    char *pcVar24;
    int64_t *piVar25;
    int64_t iVar26;
    bool bVar27;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    if ((0 < *(int32_t *)(arg1 + 0xf8)) &&
       (iVar9 = *(int32_t *)(arg1 + 0xf8) + -1, *(int32_t *)(arg1 + 0xf8) = iVar9, iVar9 < 1)) {
code_r0x00018002b8f6:
        func_0x00018045471c(0xc);
        pcVar5 = (code *)swi(3);
        uVar10 = (*pcVar5)();
        return uVar10;
    }
    if ((0 < *(int32_t *)(arg1 + 0xf4)) &&
       (iVar9 = *(int32_t *)(arg1 + 0xf4) + -1, *(int32_t *)(arg1 + 0xf4) = iVar9, iVar9 < 1)) {
        func_0x00018045471c(0xb);
        pcVar5 = (code *)swi(3);
        uVar10 = (*pcVar5)();
        return uVar10;
    }
    uVar14 = 0;
    cVar8 = '\0';
    var_20h._0_4_ = 0;
    var_10h = arg2;
    if (arg2 == 0) {
code_r0x00018002afaa:
        iVar9 = *(int32_t *)(arg1 + 0xf8);
        if (0 < iVar9) {
            iVar9 = iVar9 + 1;
            *(int32_t *)(arg1 + 0xf8) = iVar9;
        }
        return (uint64_t)CONCAT31((unkint3)((uint32_t)iVar9 >> 8), cVar8 == '\0');
    }
code_r0x00018002ab30:
    cVar8 = (char)uVar14;
    piVar25 = (int64_t *)(arg1 + 0x28);
    piVar11 = (int64_t *)(arg1 + 8);
    uVar10 = (uint64_t)*(int32_t *)(var_10h + 8);
    // switch table (22 cases) at 0x18002b90c
    switch(*(int32_t *)(var_10h + 8)) {
    default:
        goto code_r0x00018002b8e9;
    case 1:
    case 8:
    case 9:
    case 0x11:
    case 0x14:
        break;
    case 2:
        if (((*(uint32_t *)(arg1 + 0xd4) >> 8 & 1) == 0) && (*(int64_t *)arg1 == *(int64_t *)(arg1 + 0xb8))) {
            var_20h._0_4_ = *(uint32_t *)(arg1 + 0xd4) & 0xffffff01;
            uVar14 = (uint32_t)var_20h;
            break;
        }
        if (((*(uint32_t *)(arg1 + 0xd0) & 0x1000) == 0) ||
           ((*(char *)(*(int64_t *)arg1 + -1) != '\n' && (*(char *)(*(int64_t *)arg1 + -1) != '\r'))))
        goto code_r0x00018002afa8;
code_r0x00018002ab96:
        uVar14 = 0;
        var_20h._0_4_ = 0;
        goto code_r0x00018002b850;
    case 3:
        if (*(char **)arg1 != *(char **)(arg1 + 0xc0)) {
            if ((*(uint32_t *)(arg1 + 0xd0) & 0x1000) != 0) {
                cVar8 = **(char **)arg1;
                if (cVar8 == '\n') goto code_r0x00018002ab96;
                if (cVar8 == '\r') {
                    uVar14 = 0;
                    var_20h._0_4_ = 0;
                    goto code_r0x00018002b850;
                }
            }
            goto code_r0x00018002afa8;
        }
        var_20h._0_4_ = *(uint32_t *)(arg1 + 0xd4) >> 1 & 1;
        uVar14 = (uint32_t)var_20h;
        break;
    case 4:
        uVar14 = *(uint32_t *)(arg1 + 0xd4);
        if (((uVar14 >> 8 & 1) == 0) && (puVar2 = *(uint8_t **)arg1, puVar2 == *(uint8_t **)(arg1 + 0xb8))) {
            if ((puVar2 != *(uint8_t **)(arg1 + 0xc0)) && ((uVar14 & 4) == 0)) {
                uVar6 = *puVar2;
code_r0x00018002ac2b:
                if (*(char *)((uint64_t)uVar6 + 0x1806220d0) != '\0') {
                    bVar27 = (*(uint32_t *)(var_10h + 0xc) & 1) == 1;
                    var_20h._0_4_ = (uint32_t)bVar27;
                    uVar14 = (uint32_t)bVar27;
                    break;
                }
            }
        } else {
            puVar2 = *(uint8_t **)arg1;
            if (puVar2 != *(uint8_t **)(arg1 + 0xc0)) {
                bVar27 = (uint32_t)
                         (*(char *)((uint64_t)puVar2[-1] + 0x1806220d0) != *(char *)((uint64_t)*puVar2 + 0x1806220d0))
                         == (*(uint32_t *)(var_10h + 0xc) & 1);
                var_20h._0_4_ = (uint32_t)bVar27;
                uVar14 = (uint32_t)bVar27;
                break;
            }
            if ((uVar14 & 8) == 0) {
                uVar6 = puVar2[-1];
                goto code_r0x00018002ac2b;
            }
        }
        bVar27 = (*(uint32_t *)(var_10h + 0xc) & 1) == 0;
        var_20h._0_4_ = (uint32_t)bVar27;
        uVar14 = (uint32_t)bVar27;
        break;
    case 5:
        pcVar23 = *(char **)arg1;
        if (pcVar23 == *(char **)(arg1 + 0xc0)) goto code_r0x00018002afa8;
        cVar7 = *pcVar23;
        if ((*(uint8_t *)(arg1 + 0xd0) & 0x3e) == 0) {
            if (cVar7 == '\n') goto code_r0x00018002afa8;
            bVar27 = cVar7 == '\r';
        } else {
            bVar27 = cVar7 == '\0';
        }
        if (!bVar27) {
            if (cVar8 == '\0') {
                *(char **)arg1 = pcVar23 + 1;
                goto code_r0x00018002b850;
            }
            goto code_r0x00018002afaa;
        }
        goto code_r0x00018002afa8;
    case 6:
        pcVar23 = *(char **)(var_10h + 0x28);
        pcVar19 = pcVar23 + *(uint32_t *)(var_10h + 0x24);
        pcVar16 = *(char **)(arg1 + 0xc0);
        pcVar24 = *(char **)arg1;
        pcVar15 = pcVar24;
        if ((*(uint32_t *)(arg1 + 0xd0) & 0x100) == 0) {
            for (; (pcVar15 != pcVar16 && (pcVar23 != pcVar19)); pcVar23 = pcVar23 + 1) {
                if (*pcVar15 != *pcVar23) goto code_r0x00018002ad73;
                pcVar15 = pcVar15 + 1;
            }
            if (pcVar23 == pcVar19) {
                pcVar24 = pcVar15;
            }
        } else {
            iVar12 = *(int64_t *)(arg1 + 0xe8);
            for (; (pcVar15 != pcVar16 && (pcVar23 != pcVar19)); pcVar23 = pcVar23 + 1) {
                cVar8 = *pcVar23;
                cVar7 = (**(code **)(**(int64_t **)(iVar12 + 8) + 0x20))();
                uVar14 = (uint32_t)var_20h;
                if (cVar7 != cVar8) goto code_r0x00018002ad73;
                pcVar15 = pcVar15 + 1;
            }
            uVar14 = (uint32_t)var_20h;
            if (pcVar23 == pcVar19) {
                pcVar24 = pcVar15;
            }
        }
code_r0x00018002ad73:
        if (pcVar24 == *(char **)arg1) goto code_r0x00018002afa8;
        *(char **)arg1 = pcVar24;
        break;
    case 7:
        if (*(int64_t *)arg1 != *(int64_t *)(arg1 + 0xc0)) {
            piVar11 = (int64_t *)fcn.18002a380(arg1, (int64_t)&var_50h, var_10h, *(int64_t *)arg1);
            if (*piVar11 != *(int64_t *)arg1) {
                *(int64_t *)arg1 = *piVar11;
                break;
            }
        }
code_r0x00018002afa8:
        cVar8 = '\x01';
        goto code_r0x00018002afaa;
    case 10:
        uVar3 = *(undefined8 *)arg1;
        cVar8 = fcn.18002aab0(arg1, *(int64_t *)(var_10h + 0x20));
        if (cVar8 == '\0') {
            var_20h._0_4_ = 1;
            uVar14 = 1;
        } else {
            *(undefined8 *)arg1 = uVar3;
            var_20h._0_4_ = 0;
            uVar14 = 0;
        }
        break;
    case 0xb:
        iVar12 = func_0x00018002e990(arg1);
        uVar6 = fcn.18002aab0(arg1, *(int64_t *)(var_10h + 0x20));
        if (uVar6 == 0) {
            *(undefined8 *)arg1 = *(undefined8 *)(iVar12 * 0x40 + *(int64_t *)(arg1 + 0x98));
            func_0x00018002e250(piVar11);
        }
        *(int64_t *)(arg1 + 0xb0) = iVar12;
        var_20h._0_4_ = (uint32_t)uVar6;
        uVar14 = (uint32_t)uVar6;
        break;
    case 0xc:
        goto code_r0x00018002b837;
    case 0xd:
        if (*(uint32_t *)(var_10h + 0x20) != 0) {
            *(undefined8 *)(*piVar25 + (uint64_t)*(uint32_t *)(var_10h + 0x20) * 0x10) = *(undefined8 *)arg1;
        }
        break;
    case 0xe:
        iVar12 = *(int64_t *)(var_10h + 0x20);
        uVar22 = *(uint32_t *)(iVar12 + 0x20);
        if (uVar22 != 0) {
            puVar1 = (uint32_t *)(*piVar11 + (uint64_t)(uVar22 >> 5) * 4);
            *puVar1 = *puVar1 | 1 << (uVar22 & 0x1f);
            *(undefined8 *)(*piVar25 + 8 + (uint64_t)*(uint32_t *)(iVar12 + 0x20) * 0x10) = *(undefined8 *)arg1;
        }
        break;
    case 0xf:
        uVar22 = *(uint32_t *)(var_10h + 0x20);
        if ((*(uint32_t *)(*piVar11 + (uint64_t)(uVar22 >> 5) * 4) >> ((uint8_t)uVar22 & 0x1f) & 1) == 0) {
            if ((*(uint8_t *)(arg1 + 0xd0) & 0x12) != 0) goto code_r0x00018002afa8;
        } else {
            pcVar23 = *(char **)arg1;
            pcVar16 = *(char **)(*piVar25 + (uint64_t)uVar22 * 0x10);
            pcVar24 = *(char **)(*piVar25 + 8 + (uint64_t)uVar22 * 0x10);
            if (pcVar16 != pcVar24) {
                pcVar15 = *(char **)(arg1 + 0xc0);
                pcVar19 = pcVar23;
                if ((*(uint32_t *)(arg1 + 0xd0) & 0x100) == 0) {
                    for (; (pcVar19 != pcVar15 && (pcVar16 != pcVar24)); pcVar16 = pcVar16 + 1) {
                        if (*pcVar19 != *pcVar16) goto code_r0x00018002af7e;
                        pcVar19 = pcVar19 + 1;
                    }
                    if (pcVar16 == pcVar24) {
                        pcVar23 = pcVar19;
                    }
                } else {
                    iVar12 = *(int64_t *)(arg1 + 0xe8);
                    for (; (pcVar19 != pcVar15 && (pcVar16 != pcVar24)); pcVar16 = pcVar16 + 1) {
                        piVar11 = *(int64_t **)(iVar12 + 8);
                        cVar8 = (**(code **)(*piVar11 + 0x20))(piVar11, *pcVar19);
                        cVar7 = (**(code **)(**(int64_t **)(iVar12 + 8) + 0x20))();
                        if (cVar8 != cVar7) goto code_r0x00018002af7e;
                        pcVar19 = pcVar19 + 1;
                    }
                    if (pcVar16 == pcVar24) {
                        pcVar23 = pcVar19;
                    }
                }
code_r0x00018002af7e:
                if (pcVar23 == *(char **)arg1) goto code_r0x00018002afa8;
            }
            *(char **)arg1 = pcVar23;
            uVar14 = (uint32_t)var_20h;
        }
        break;
    case 0x10:
        iVar12 = func_0x00018002e990(arg1);
code_r0x00018002aff0:
        func_0x00018002c580(arg1, *(int64_t *)(arg1 + 0x98) + iVar12 * 0x40);
        cVar8 = fcn.18002aab0(arg1, *(int64_t *)(var_10h + 0x10));
        if (cVar8 == '\0') goto code_r0x00018002b012;
        if (*(char *)(arg1 + 0xe0) != '\0') {
            for (iVar21 = *(int64_t *)(var_10h + 0x28); uVar14 = (uint32_t)var_20h, iVar21 != 0;
                iVar21 = *(int64_t *)(iVar21 + 0x28)) {
                func_0x00018002c580(arg1, *(int64_t *)(arg1 + 0x98) + iVar12 * 0x40);
                fcn.18002aab0(arg1, *(int64_t *)(iVar21 + 0x10));
            }
        }
        *(int64_t *)(arg1 + 0xb0) = iVar12;
        goto code_r0x00018002b837;
    case 0x12:
        uVar14 = *(uint32_t *)(var_10h + 0xc) >> 1;
        if (*(int32_t *)(var_10h + 0x34) == 1) {
            var_18h._0_4_ = 0;
            iVar12 = func_0x00018002e990(arg1);
            if (*(int32_t *)(var_10h + 0x20) < 1) {
code_r0x00018002b140:
                _var_a8h = ZEXT816(0);
                _var_98h = ZEXT816(0);
                var_88h = 0;
                var_80h = 0;
                _var_78h = ZEXT816(0);
                cVar8 = '\0';
                var_8h = 0;
                iVar21 = *(int64_t *)arg1;
                cVar7 = fcn.18002aab0(arg1, *(int64_t *)(*(int64_t *)(var_10h + 0x28) + 0x10));
                iVar26 = 0;
                if (cVar7 != '\0') {
                    if ((uVar14 & 1) == 0) {
                        *(int64_t *)(arg1 + 0xb0) = iVar12;
                        cVar8 = '\x01';
                        goto code_r0x00018002b6da;
                    }
                    func_0x00018002c580(&var_a8h);
                    cVar8 = '\x01';
                    var_8h = 1;
                    iVar26 = var_80h;
                }
                if (((int32_t)var_18h != 0) || (*(int32_t *)(var_10h + 0x24) == 0)) goto code_r0x00018002b310;
                *(int64_t *)arg1 = iVar21;
                func_0x00018002e250(piVar11, *(int64_t *)(arg1 + 0x98) + iVar12 * 0x40 + 8);
                cVar7 = fcn.18002aab0(arg1, *(int64_t *)(var_10h + 0x10));
                if (cVar7 != '\0') {
                    iVar13 = *(int64_t *)arg1;
                    if (iVar21 != iVar13) {
                        cVar7 = fcn.18002aab0(arg1, *(int64_t *)(*(int64_t *)(var_10h + 0x28) + 0x10));
                        if (cVar7 != '\0') {
                            if ((uVar14 & 1) == 0) goto code_r0x00018002b230;
                            func_0x00018002c580(&var_a8h);
                            cVar8 = '\x01';
                            var_8h = 1;
                            iVar26 = var_80h;
                        }
                        var_18h._0_4_ = 1;
                        iVar21 = iVar13;
code_r0x00018002b310:
                        piVar11 = (int64_t *)(arg1 + 8);
                        if (*(int32_t *)(var_10h + 0x24) != -1) {
                            if (*(int32_t *)(var_10h + 0x24) <= (int32_t)var_18h) goto code_r0x00018002b5e7;
                            var_18h._0_4_ = (int32_t)var_18h + 1;
                        }
                        *(int64_t *)arg1 = iVar21;
                        var_58h = *(int64_t *)(arg1 + 0x98) + 8 + iVar12 * 0x40;
                        if (piVar11 != (int64_t *)var_58h) {
                            var_68h = *(int64_t *)var_58h;
                            uVar10 = *(int64_t *)(var_58h + 8) - var_68h >> 2;
                            var_60h = *piVar11;
                            if ((uint64_t)(*(int64_t *)(arg1 + 0x18) - var_60h >> 2) < uVar10) {
                                func_0x000180030840(piVar11, uVar10);
                                iVar13 = *piVar11;
                                fcn.180498030(iVar13, var_68h, uVar10 * 4);
                                iVar13 = iVar13 + uVar10 * 4;
                            } else {
                                uVar17 = *(int64_t *)(arg1 + 0x10) - var_60h >> 2;
                                if (uVar17 < uVar10) {
                                    fcn.180498030(var_60h, var_68h, uVar17 * 4);
                                    iVar4 = *(int64_t *)(arg1 + 0x10);
                                    iVar13 = (uVar10 - uVar17) * 4;
                                    fcn.180498030(iVar4, var_68h + uVar17 * 4, iVar13);
                                    iVar13 = iVar13 + iVar4;
                                } else {
                                    fcn.180498030(var_60h, var_68h, uVar10 * 4);
                                    iVar13 = var_60h + uVar10 * 4;
                                }
                                cVar8 = (char)var_8h;
                            }
                            *(int64_t *)(arg1 + 0x10) = iVar13;
                            *(undefined8 *)(arg1 + 0x20) = *(undefined8 *)(var_58h + 0x18);
                        }
                        cVar7 = fcn.18002aab0(arg1, *(int64_t *)(var_10h + 0x10));
                        if ((cVar7 == '\0') || (iVar13 = *(int64_t *)arg1, iVar13 == iVar21)) goto code_r0x00018002b5e7;
                        cVar7 = fcn.18002aab0(arg1, *(int64_t *)(*(int64_t *)(var_10h + 0x28) + 0x10));
                        iVar21 = iVar13;
                        if (cVar7 != '\0') {
                            if ((uVar14 & 1) == 0) {
                                *(int64_t *)(arg1 + 0xb0) = iVar12;
                                goto code_r0x00018002b237;
                            }
                            var_a8h = *(undefined8 *)arg1;
                            func_0x00018002e250(&var_a0h);
                            iVar26 = var_80h;
                            if (&var_80h != (int64_t *)(arg1 + 0x28)) {
                                iVar13 = *(int64_t *)(arg1 + 0x28);
                                uVar17 = *(int64_t *)(arg1 + 0x30) - iVar13 >> 4;
                                uVar10 = var_70h - var_80h >> 4;
                                if (uVar10 < uVar17) {
                                    if (0xfffffffffffffff < uVar17) {
                                        fcn.180010010();
                                        goto code_r0x00018002b8f6;
                                    }
                                    if (0xfffffffffffffff - (uVar10 >> 1) < uVar10) {
                                        uVar20 = 0xfffffffffffffff;
                                    } else {
                                        uVar20 = (uVar10 >> 1) + uVar10;
                                        if (uVar20 < uVar17) {
                                            uVar20 = uVar17;
                                        }
                                    }
                                    if (var_80h != 0) {
                                        uVar10 = uVar10 * 0x10;
                                        if (0xfff < uVar10) {
                                            iVar26 = *(int64_t *)(var_80h + -8);
                                            if (0x1f < (var_80h - iVar26) - 8U) {
                                                pcVar5 = (code *)swi(0x29);
                                                (*pcVar5)(5);
                                                goto code_r0x00018002b8e2;
                                            }
                                            uVar10 = uVar10 + 0x27;
                                        }
                                        fcn.180459c3c(iVar26, uVar10);
                                        var_80h = 0;
                                        _var_78h = ZEXT816(0);
                                    }
                                    func_0x0001800307b0(&var_80h, uVar20);
                                    iVar26 = var_80h;
                                    fcn.180498030(var_80h, iVar13, uVar17 << 4);
code_r0x00018002b5b8:
                                    var_78h = uVar17 * 0x10 + iVar26;
                                } else {
                                    iVar4 = var_78h;
                                    uVar10 = var_78h - var_80h >> 4;
                                    if (uVar17 <= uVar10) {
                                        fcn.180498030(var_80h, iVar13, uVar17 << 4);
                                        goto code_r0x00018002b5b8;
                                    }
                                    fcn.180498030(var_80h, iVar13, uVar10 * 0x10);
                                    iVar18 = (uVar17 - uVar10) * 0x10;
                                    fcn.180498030(iVar4, iVar13 + uVar10 * 0x10, iVar18);
                                    var_78h = iVar18 + iVar4;
                                }
                            }
                            cVar8 = '\x01';
                            var_8h = 1;
                        }
                        goto code_r0x00018002b310;
                    }
                    if (((*(uint8_t *)(arg1 + 0xd0) & 0x3e) == 0) ||
                       (cVar7 = fcn.18002aab0(arg1, *(int64_t *)(*(int64_t *)(var_10h + 0x28) + 0x10)), cVar7 == '\0'))
                    goto code_r0x00018002b5e7;
code_r0x00018002b230:
                    *(int64_t *)(arg1 + 0xb0) = iVar12;
code_r0x00018002b237:
                    if (iVar26 != 0) {
                        iVar12 = iVar26;
                        if ((0xfff < (var_70h - iVar26 & 0xfffffffffffffff0U)) &&
                           (iVar12 = *(int64_t *)(iVar26 + -8), 0x1f < (iVar26 - iVar12) - 8U))
                        goto code_r0x00018002b8e2;
                        fcn.180459c3c(iVar12);
                    }
                    if (var_a0h != 0) {
                        iVar12 = var_a0h;
                        if ((0xfff < (uint64_t)((var_90h - var_a0h >> 2) * 4)) &&
                           (iVar12 = *(int64_t *)(var_a0h + -8), 0x1f < (var_a0h - iVar12) - 8U))
                        goto code_r0x00018002b8e2;
                        fcn.180459c3c(iVar12);
                    }
                    cVar8 = '\x01';
                    goto code_r0x00018002b6da;
                }
code_r0x00018002b5e7:
                if (cVar8 != '\0') {
                    func_0x00018002c580(arg1);
                    iVar26 = var_80h;
                }
                *(int64_t *)(arg1 + 0xb0) = iVar12;
                if (iVar26 != 0) {
                    iVar12 = iVar26;
                    if (((var_70h - iVar26 & 0xfffffffffffffff0U) < 0x1000) ||
                       (iVar12 = *(int64_t *)(iVar26 + -8), (iVar26 - iVar12) - 8U < 0x20)) {
                        fcn.180459c3c(iVar12);
                        goto code_r0x00018002b640;
                    }
code_r0x00018002b8e2:
                    pcVar5 = (code *)swi(0x29);
                    uVar10 = (*pcVar5)(5);
code_r0x00018002b8e9:
                    return uVar10 & 0xffffffffffffff00;
                }
code_r0x00018002b640:
                if (var_a0h != 0) {
                    iVar12 = var_a0h;
                    if ((0xfff < (uint64_t)((var_90h - var_a0h >> 2) * 4)) &&
                       (iVar12 = *(int64_t *)(var_a0h + -8), 0x1f < (var_a0h - iVar12) - 8U)) goto code_r0x00018002b8e2;
                    fcn.180459c3c(iVar12);
                }
            } else {
                cVar8 = fcn.18002aab0(arg1, *(int64_t *)(var_10h + 0x10));
                if (cVar8 == '\0') {
code_r0x00018002b0b9:
                    *(int64_t *)(arg1 + 0xb0) = iVar12;
                    cVar8 = '\0';
                } else {
                    if (*(int64_t *)arg1 != *(int64_t *)(iVar12 * 0x40 + *(int64_t *)(arg1 + 0x98))) {
                        var_18h._0_4_ = 1;
                        if (1 < *(int32_t *)(var_10h + 0x20)) {
                            do {
                                func_0x00018002e250(piVar11, *(int64_t *)(arg1 + 0x98) + 8 + iVar12 * 0x40);
                                cVar8 = fcn.18002aab0(arg1, *(int64_t *)(var_10h + 0x10));
                                if (cVar8 == '\0') goto code_r0x00018002b0b9;
                                var_18h._0_4_ = (int32_t)var_18h + 1;
                            } while ((int32_t)var_18h < *(int32_t *)(var_10h + 0x20));
                        }
                        goto code_r0x00018002b140;
                    }
                    *(int64_t *)(arg1 + 0xb0) = iVar12;
                    cVar8 = fcn.18002aab0(arg1, *(int64_t *)(*(int64_t *)(var_10h + 0x28) + 0x10));
                }
            }
        } else {
            iVar12 = (uint64_t)*(uint32_t *)(var_10h + 0x30) * 0x10 + *(int64_t *)(arg1 + 0x80);
            if ((*(int32_t *)(iVar12 + 0xc) == 0) &&
               (((*(uint8_t *)(arg1 + 0xd0) & 0x3e) != 0 ||
                (cVar8 = func_0x00018002ebb0(arg1, *(undefined8 *)(var_10h + 0x10), iVar12), cVar8 == '\0')))) {
                *(undefined4 *)(iVar12 + 0xc) = *(undefined4 *)(arg1 + 0x20);
            }
            cVar8 = func_0x00018002c930(arg1, var_10h, uVar14 & 1, 0);
        }
code_r0x00018002b6da:
        var_20h._0_4_ = (uint32_t)var_20h & 0xff;
        uVar14 = (uint32_t)var_20h;
        if (cVar8 == '\0') {
            var_20h._0_4_ = 1;
            uVar14 = (uint32_t)var_20h;
        }
        goto code_r0x00018002b837;
    case 0x13:
        iVar12 = *(int64_t *)(var_10h + 0x20);
        if (*(int32_t *)(iVar12 + 0x34) == 0) {
            cVar8 = func_0x00018002c930(arg1, iVar12, 
                                        CONCAT31((unkuint3)(*(uint32_t *)(iVar12 + 0xc) >> 9), 
                                                 (char)(*(uint32_t *)(iVar12 + 0xc) >> 1)) & 0xffffff01, 
                                        *(undefined4 *)
                                         (*(int64_t *)(arg1 + 0x80) + 8 + (uint64_t)*(uint32_t *)(iVar12 + 0x30) * 0x10)
                                       );
            var_20h._0_4_ = uVar14 & 0xff;
            uVar14 = (uint32_t)var_20h;
            if (cVar8 == '\0') {
                var_20h._0_4_ = 1;
                uVar14 = (uint32_t)var_20h;
            }
        }
        goto code_r0x00018002b837;
    case 0x15:
        if ((((*(uint32_t *)(arg1 + 0xd4) & 0x2020) == 0) || (*(int64_t *)(arg1 + 0xb8) != *(int64_t *)arg1)) &&
           ((*(char *)(arg1 + 0xf0) == '\0' || (*(int64_t *)arg1 == *(int64_t *)(arg1 + 0xc0))))) {
            if (*(char *)(arg1 + 0xe0) != '\0') {
                if (*(char *)(arg1 + 0xd8) == '\0') {
code_r0x00018002b8c2:
                    func_0x00018002c580(arg1 + 0x40);
                    *(undefined *)(arg1 + 0xd8) = 1;
                } else if (*(int64_t *)(arg1 + 0x40) == *(int64_t *)arg1) {
                    uVar14 = (uint32_t)var_20h;
                    if (1 < *(uint32_t *)(arg1 + 0xdc)) {
                        uVar10 = 1;
                        do {
                            iVar12 = (uVar10 >> 5) * 4;
                            uVar22 = 1 << ((uint8_t)uVar10 & 0x1f);
                            uVar14 = uVar22 & *(uint32_t *)(*(int64_t *)(arg1 + 0x48) + iVar12);
                            if ((uVar14 != 0) != ((*(uint32_t *)(iVar12 + *piVar11) & uVar22) != 0)) {
                                bVar27 = (*(uint32_t *)(iVar12 + *(int64_t *)(arg1 + 8)) & uVar22) != 0;
                                uVar14 = (uint32_t)var_20h;
                                goto code_r0x00018002b8ba;
                            }
                            if (uVar14 != 0) {
                                iVar21 = uVar10 * 0x10;
                                iVar12 = *piVar25;
                                if (*(int64_t *)(*(int64_t *)(arg1 + 0x68) + iVar21) != *(int64_t *)(iVar12 + iVar21)) {
                                    bVar27 = *(int64_t *)(iVar12 + iVar21) - *(int64_t *)(arg1 + 0xb8) <
                                             *(int64_t *)(*(int64_t *)(arg1 + 0x68) + iVar21) -
                                             *(int64_t *)(arg1 + 0xb8);
                                    uVar14 = (uint32_t)var_20h;
                                    goto code_r0x00018002b8ba;
                                }
                                iVar26 = *(int64_t *)(iVar12 + 8 + iVar21);
                                if (*(int64_t *)(*(int64_t *)(arg1 + 0x68) + 8 + iVar21) != iVar26) {
                                    bVar27 = *(int64_t *)(*(int64_t *)(arg1 + 0x68) + 8 + iVar21) -
                                             *(int64_t *)(*(int64_t *)(arg1 + 0x68) + iVar21) <
                                             iVar26 - *(int64_t *)(iVar12 + iVar21);
                                    uVar14 = (uint32_t)var_20h;
                                    goto code_r0x00018002b8ba;
                                }
                            }
                            uVar22 = (int32_t)uVar10 + 1;
                            uVar10 = (uint64_t)uVar22;
                            uVar14 = (uint32_t)var_20h;
                        } while (uVar22 < *(uint32_t *)(arg1 + 0xdc));
                    }
                } else {
                    bVar27 = *(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0xb8) <
                             *(int64_t *)arg1 - *(int64_t *)(arg1 + 0xb8);
code_r0x00018002b8ba:
                    if (bVar27) goto code_r0x00018002b8c2;
                }
            }
        } else {
            var_20h._0_4_ = 1;
            uVar14 = 1;
        }
        goto code_r0x00018002b837;
    }
code_r0x00018002b839:
    cVar8 = (char)uVar14;
    if (cVar8 != '\0') goto code_r0x00018002afaa;
code_r0x00018002b850:
    cVar8 = (char)uVar14;
    if ((var_10h == 0) || (var_10h = *(int64_t *)(var_10h + 0x10), var_10h == 0)) goto code_r0x00018002afaa;
    goto code_r0x00018002ab30;
code_r0x00018002b012:
    var_10h = *(int64_t *)(var_10h + 0x28);
    if (var_10h == 0) goto code_r0x00018002b01b;
    goto code_r0x00018002aff0;
code_r0x00018002b01b:
    var_20h._0_4_ = 1;
    *(int64_t *)(arg1 + 0xb0) = iVar12;
    uVar14 = 1;
code_r0x00018002b837:
    var_10h = 0;
    goto code_r0x00018002b839;
}

// ============================================================
// Function: FUN_18002b970
// Address: 0x18002b970
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18002b970(int64_t arg1)
{
    uint8_t uVar1;
    bool bVar2;
    char cVar3;
    char cVar4;
    int64_t iVar5;
    char *pcVar6;
    uint64_t uVar7;
    int64_t var_8h;
    
    if (*(uint8_t **)arg1 == *(uint8_t **)(arg1 + 8)) {
        *(undefined *)(arg1 + 0x75) = 0;
        *(undefined4 *)(arg1 + 0x70) = 0xffffffff;
        return;
    }
    uVar1 = **(uint8_t **)arg1;
    *(uint8_t *)(arg1 + 0x75) = uVar1;
    iVar5 = fcn.18045b928(0x1806221e0, (int32_t)(char)uVar1);
    if (iVar5 != 0) {
        *(uint32_t *)(arg1 + 0x70) = (uint32_t)uVar1;
    // switch table (116 cases) at 0x18002baf4
        switch((uint32_t)uVar1) {
        case 10:
            if ((*(uint8_t *)(arg1 + 0x60) & 4) == 0) {
                return;
            }
            if (*(int32_t *)(arg1 + 0x14) != 0) {
                return;
            }
            *(undefined4 *)(arg1 + 0x70) = 0x7c;
            return;
        default:
            goto code_r0x00018002bae8;
        case 0x24:
            uVar7 = *(uint64_t *)(arg1 + 0x60);
            if ((uVar7 >> 0x18 & 1) == 0) {
                return;
            }
            pcVar6 = (char *)(*(int64_t *)arg1 + 1);
            if (pcVar6 == *(char **)(arg1 + 8)) {
                return;
            }
            cVar3 = *pcVar6;
            if ((cVar3 == '\\') && (cVar4 = fcn.18002cd40(arg1, pcVar6), cVar4 != '\0')) {
                cVar3 = pcVar6[1];
                bVar2 = true;
            } else {
                bVar2 = false;
            }
            if ((((uVar7 & 4) != 0) && (cVar3 == '\n')) && (*(int32_t *)(arg1 + 0x14) == 0)) {
                return;
            }
            if (((bVar2) && (cVar3 == ')')) && (*(int32_t *)(arg1 + 0x14) != 0)) {
                return;
            }
            break;
        case 0x28:
        case 0x29:
            if ((*(uint8_t *)(arg1 + 0x60) & 8) != 0) {
                return;
            }
            break;
        case 0x2b:
        case 0x3f:
            if ((*(uint8_t *)(arg1 + 0x60) & 1) != 0) {
                return;
            }
            break;
        case 0x5c:
            iVar5 = *(int64_t *)arg1;
            cVar3 = fcn.18002cd40(arg1, iVar5);
            if (cVar3 == '\0') {
                return;
            }
            uVar1 = *(uint8_t *)(iVar5 + 1);
            *(uint8_t *)(arg1 + 0x75) = uVar1;
            *(uint32_t *)(arg1 + 0x70) = (uint32_t)uVar1;
            return;
        case 0x7b:
        case 0x7d:
            if ((*(uint8_t *)(arg1 + 0x60) & 0x10) != 0) {
                return;
            }
            break;
        case 0x7c:
            if ((*(uint8_t *)(arg1 + 0x60) & 2) != 0) {
                return;
            }
        }
    }
    *(undefined4 *)(arg1 + 0x70) = 0;
code_r0x00018002bae8:
    return;
}

// ============================================================
// Function: FUN_18002b993
// Address: 0x18002b993
// Size: 127 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18002b970(int64_t arg1)
{
    uint8_t uVar1;
    bool bVar2;
    char cVar3;
    char cVar4;
    int64_t iVar5;
    char *pcVar6;
    uint64_t uVar7;
    int64_t var_8h;
    
    if (*(uint8_t **)arg1 == *(uint8_t **)(arg1 + 8)) {
        *(undefined *)(arg1 + 0x75) = 0;
        *(undefined4 *)(arg1 + 0x70) = 0xffffffff;
        return;
    }
    uVar1 = **(uint8_t **)arg1;
    *(uint8_t *)(arg1 + 0x75) = uVar1;
    iVar5 = fcn.18045b928(0x1806221e0, (int32_t)(char)uVar1);
    if (iVar5 != 0) {
        *(uint32_t *)(arg1 + 0x70) = (uint32_t)uVar1;
    // switch table (116 cases) at 0x18002baf4
        switch((uint32_t)uVar1) {
        case 10:
            if ((*(uint8_t *)(arg1 + 0x60) & 4) == 0) {
                return;
            }
            if (*(int32_t *)(arg1 + 0x14) != 0) {
                return;
            }
            *(undefined4 *)(arg1 + 0x70) = 0x7c;
            return;
        default:
            goto code_r0x00018002bae8;
        case 0x24:
            uVar7 = *(uint64_t *)(arg1 + 0x60);
            if ((uVar7 >> 0x18 & 1) == 0) {
                return;
            }
            pcVar6 = (char *)(*(int64_t *)arg1 + 1);
            if (pcVar6 == *(char **)(arg1 + 8)) {
                return;
            }
            cVar3 = *pcVar6;
            if ((cVar3 == '\\') && (cVar4 = fcn.18002cd40(arg1, pcVar6), cVar4 != '\0')) {
                cVar3 = pcVar6[1];
                bVar2 = true;
            } else {
                bVar2 = false;
            }
            if ((((uVar7 & 4) != 0) && (cVar3 == '\n')) && (*(int32_t *)(arg1 + 0x14) == 0)) {
                return;
            }
            if (((bVar2) && (cVar3 == ')')) && (*(int32_t *)(arg1 + 0x14) != 0)) {
                return;
            }
            break;
        case 0x28:
        case 0x29:
            if ((*(uint8_t *)(arg1 + 0x60) & 8) != 0) {
                return;
            }
            break;
        case 0x2b:
        case 0x3f:
            if ((*(uint8_t *)(arg1 + 0x60) & 1) != 0) {
                return;
            }
            break;
        case 0x5c:
            iVar5 = *(int64_t *)arg1;
            cVar3 = fcn.18002cd40(arg1, iVar5);
            if (cVar3 == '\0') {
                return;
            }
            uVar1 = *(uint8_t *)(iVar5 + 1);
            *(uint8_t *)(arg1 + 0x75) = uVar1;
            *(uint32_t *)(arg1 + 0x70) = (uint32_t)uVar1;
            return;
        case 0x7b:
        case 0x7d:
            if ((*(uint8_t *)(arg1 + 0x60) & 0x10) != 0) {
                return;
            }
            break;
        case 0x7c:
            if ((*(uint8_t *)(arg1 + 0x60) & 2) != 0) {
                return;
            }
        }
    }
    *(undefined4 *)(arg1 + 0x70) = 0;
code_r0x00018002bae8:
    return;
}

// ============================================================
// Function: FUN_18002ba12
// Address: 0x18002ba12
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18002b970(int64_t arg1)
{
    uint8_t uVar1;
    bool bVar2;
    char cVar3;
    char cVar4;
    int64_t iVar5;
    char *pcVar6;
    uint64_t uVar7;
    int64_t var_8h;
    
    if (*(uint8_t **)arg1 == *(uint8_t **)(arg1 + 8)) {
        *(undefined *)(arg1 + 0x75) = 0;
        *(undefined4 *)(arg1 + 0x70) = 0xffffffff;
        return;
    }
    uVar1 = **(uint8_t **)arg1;
    *(uint8_t *)(arg1 + 0x75) = uVar1;
    iVar5 = fcn.18045b928(0x1806221e0, (int32_t)(char)uVar1);
    if (iVar5 != 0) {
        *(uint32_t *)(arg1 + 0x70) = (uint32_t)uVar1;
    // switch table (116 cases) at 0x18002baf4
        switch((uint32_t)uVar1) {
        case 10:
            if ((*(uint8_t *)(arg1 + 0x60) & 4) == 0) {
                return;
            }
            if (*(int32_t *)(arg1 + 0x14) != 0) {
                return;
            }
            *(undefined4 *)(arg1 + 0x70) = 0x7c;
            return;
        default:
            goto code_r0x00018002bae8;
        case 0x24:
            uVar7 = *(uint64_t *)(arg1 + 0x60);
            if ((uVar7 >> 0x18 & 1) == 0) {
                return;
            }
            pcVar6 = (char *)(*(int64_t *)arg1 + 1);
            if (pcVar6 == *(char **)(arg1 + 8)) {
                return;
            }
            cVar3 = *pcVar6;
            if ((cVar3 == '\\') && (cVar4 = fcn.18002cd40(arg1, pcVar6), cVar4 != '\0')) {
                cVar3 = pcVar6[1];
                bVar2 = true;
            } else {
                bVar2 = false;
            }
            if ((((uVar7 & 4) != 0) && (cVar3 == '\n')) && (*(int32_t *)(arg1 + 0x14) == 0)) {
                return;
            }
            if (((bVar2) && (cVar3 == ')')) && (*(int32_t *)(arg1 + 0x14) != 0)) {
                return;
            }
            break;
        case 0x28:
        case 0x29:
            if ((*(uint8_t *)(arg1 + 0x60) & 8) != 0) {
                return;
            }
            break;
        case 0x2b:
        case 0x3f:
            if ((*(uint8_t *)(arg1 + 0x60) & 1) != 0) {
                return;
            }
            break;
        case 0x5c:
            iVar5 = *(int64_t *)arg1;
            cVar3 = fcn.18002cd40(arg1, iVar5);
            if (cVar3 == '\0') {
                return;
            }
            uVar1 = *(uint8_t *)(iVar5 + 1);
            *(uint8_t *)(arg1 + 0x75) = uVar1;
            *(uint32_t *)(arg1 + 0x70) = (uint32_t)uVar1;
            return;
        case 0x7b:
        case 0x7d:
            if ((*(uint8_t *)(arg1 + 0x60) & 0x10) != 0) {
                return;
            }
            break;
        case 0x7c:
            if ((*(uint8_t *)(arg1 + 0x60) & 2) != 0) {
                return;
            }
        }
    }
    *(undefined4 *)(arg1 + 0x70) = 0;
code_r0x00018002bae8:
    return;
}

// ============================================================
// Function: FUN_18002ba38
// Address: 0x18002ba38
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18002b970(int64_t arg1)
{
    uint8_t uVar1;
    bool bVar2;
    char cVar3;
    char cVar4;
    int64_t iVar5;
    char *pcVar6;
    uint64_t uVar7;
    int64_t var_8h;
    
    if (*(uint8_t **)arg1 == *(uint8_t **)(arg1 + 8)) {
        *(undefined *)(arg1 + 0x75) = 0;
        *(undefined4 *)(arg1 + 0x70) = 0xffffffff;
        return;
    }
    uVar1 = **(uint8_t **)arg1;
    *(uint8_t *)(arg1 + 0x75) = uVar1;
    iVar5 = fcn.18045b928(0x1806221e0, (int32_t)(char)uVar1);
    if (iVar5 != 0) {
        *(uint32_t *)(arg1 + 0x70) = (uint32_t)uVar1;
    // switch table (116 cases) at 0x18002baf4
        switch((uint32_t)uVar1) {
        case 10:
            if ((*(uint8_t *)(arg1 + 0x60) & 4) == 0) {
                return;
            }
            if (*(int32_t *)(arg1 + 0x14) != 0) {
                return;
            }
            *(undefined4 *)(arg1 + 0x70) = 0x7c;
            return;
        default:
            goto code_r0x00018002bae8;
        case 0x24:
            uVar7 = *(uint64_t *)(arg1 + 0x60);
            if ((uVar7 >> 0x18 & 1) == 0) {
                return;
            }
            pcVar6 = (char *)(*(int64_t *)arg1 + 1);
            if (pcVar6 == *(char **)(arg1 + 8)) {
                return;
            }
            cVar3 = *pcVar6;
            if ((cVar3 == '\\') && (cVar4 = fcn.18002cd40(arg1, pcVar6), cVar4 != '\0')) {
                cVar3 = pcVar6[1];
                bVar2 = true;
            } else {
                bVar2 = false;
            }
            if ((((uVar7 & 4) != 0) && (cVar3 == '\n')) && (*(int32_t *)(arg1 + 0x14) == 0)) {
                return;
            }
            if (((bVar2) && (cVar3 == ')')) && (*(int32_t *)(arg1 + 0x14) != 0)) {
                return;
            }
            break;
        case 0x28:
        case 0x29:
            if ((*(uint8_t *)(arg1 + 0x60) & 8) != 0) {
                return;
            }
            break;
        case 0x2b:
        case 0x3f:
            if ((*(uint8_t *)(arg1 + 0x60) & 1) != 0) {
                return;
            }
            break;
        case 0x5c:
            iVar5 = *(int64_t *)arg1;
            cVar3 = fcn.18002cd40(arg1, iVar5);
            if (cVar3 == '\0') {
                return;
            }
            uVar1 = *(uint8_t *)(iVar5 + 1);
            *(uint8_t *)(arg1 + 0x75) = uVar1;
            *(uint32_t *)(arg1 + 0x70) = (uint32_t)uVar1;
            return;
        case 0x7b:
        case 0x7d:
            if ((*(uint8_t *)(arg1 + 0x60) & 0x10) != 0) {
                return;
            }
            break;
        case 0x7c:
            if ((*(uint8_t *)(arg1 + 0x60) & 2) != 0) {
                return;
            }
        }
    }
    *(undefined4 *)(arg1 + 0x70) = 0;
code_r0x00018002bae8:
    return;
}

// ============================================================
// Function: FUN_18002ba4d
// Address: 0x18002ba4d
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18002b970(int64_t arg1)
{
    uint8_t uVar1;
    bool bVar2;
    char cVar3;
    char cVar4;
    int64_t iVar5;
    char *pcVar6;
    uint64_t uVar7;
    int64_t var_8h;
    
    if (*(uint8_t **)arg1 == *(uint8_t **)(arg1 + 8)) {
        *(undefined *)(arg1 + 0x75) = 0;
        *(undefined4 *)(arg1 + 0x70) = 0xffffffff;
        return;
    }
    uVar1 = **(uint8_t **)arg1;
    *(uint8_t *)(arg1 + 0x75) = uVar1;
    iVar5 = fcn.18045b928(0x1806221e0, (int32_t)(char)uVar1);
    if (iVar5 != 0) {
        *(uint32_t *)(arg1 + 0x70) = (uint32_t)uVar1;
    // switch table (116 cases) at 0x18002baf4
        switch((uint32_t)uVar1) {
        case 10:
            if ((*(uint8_t *)(arg1 + 0x60) & 4) == 0) {
                return;
            }
            if (*(int32_t *)(arg1 + 0x14) != 0) {
                return;
            }
            *(undefined4 *)(arg1 + 0x70) = 0x7c;
            return;
        default:
            goto code_r0x00018002bae8;
        case 0x24:
            uVar7 = *(uint64_t *)(arg1 + 0x60);
            if ((uVar7 >> 0x18 & 1) == 0) {
                return;
            }
            pcVar6 = (char *)(*(int64_t *)arg1 + 1);
            if (pcVar6 == *(char **)(arg1 + 8)) {
                return;
            }
            cVar3 = *pcVar6;
            if ((cVar3 == '\\') && (cVar4 = fcn.18002cd40(arg1, pcVar6), cVar4 != '\0')) {
                cVar3 = pcVar6[1];
                bVar2 = true;
            } else {
                bVar2 = false;
            }
            if ((((uVar7 & 4) != 0) && (cVar3 == '\n')) && (*(int32_t *)(arg1 + 0x14) == 0)) {
                return;
            }
            if (((bVar2) && (cVar3 == ')')) && (*(int32_t *)(arg1 + 0x14) != 0)) {
                return;
            }
            break;
        case 0x28:
        case 0x29:
            if ((*(uint8_t *)(arg1 + 0x60) & 8) != 0) {
                return;
            }
            break;
        case 0x2b:
        case 0x3f:
            if ((*(uint8_t *)(arg1 + 0x60) & 1) != 0) {
                return;
            }
            break;
        case 0x5c:
            iVar5 = *(int64_t *)arg1;
            cVar3 = fcn.18002cd40(arg1, iVar5);
            if (cVar3 == '\0') {
                return;
            }
            uVar1 = *(uint8_t *)(iVar5 + 1);
            *(uint8_t *)(arg1 + 0x75) = uVar1;
            *(uint32_t *)(arg1 + 0x70) = (uint32_t)uVar1;
            return;
        case 0x7b:
        case 0x7d:
            if ((*(uint8_t *)(arg1 + 0x60) & 0x10) != 0) {
                return;
            }
            break;
        case 0x7c:
            if ((*(uint8_t *)(arg1 + 0x60) & 2) != 0) {
                return;
            }
        }
    }
    *(undefined4 *)(arg1 + 0x70) = 0;
code_r0x00018002bae8:
    return;
}

// ============================================================
// Function: FUN_18002ba62
// Address: 0x18002ba62
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18002b970(int64_t arg1)
{
    uint8_t uVar1;
    bool bVar2;
    char cVar3;
    char cVar4;
    int64_t iVar5;
    char *pcVar6;
    uint64_t uVar7;
    int64_t var_8h;
    
    if (*(uint8_t **)arg1 == *(uint8_t **)(arg1 + 8)) {
        *(undefined *)(arg1 + 0x75) = 0;
        *(undefined4 *)(arg1 + 0x70) = 0xffffffff;
        return;
    }
    uVar1 = **(uint8_t **)arg1;
    *(uint8_t *)(arg1 + 0x75) = uVar1;
    iVar5 = fcn.18045b928(0x1806221e0, (int32_t)(char)uVar1);
    if (iVar5 != 0) {
        *(uint32_t *)(arg1 + 0x70) = (uint32_t)uVar1;
    // switch table (116 cases) at 0x18002baf4
        switch((uint32_t)uVar1) {
        case 10:
            if ((*(uint8_t *)(arg1 + 0x60) & 4) == 0) {
                return;
            }
            if (*(int32_t *)(arg1 + 0x14) != 0) {
                return;
            }
            *(undefined4 *)(arg1 + 0x70) = 0x7c;
            return;
        default:
            goto code_r0x00018002bae8;
        case 0x24:
            uVar7 = *(uint64_t *)(arg1 + 0x60);
            if ((uVar7 >> 0x18 & 1) == 0) {
                return;
            }
            pcVar6 = (char *)(*(int64_t *)arg1 + 1);
            if (pcVar6 == *(char **)(arg1 + 8)) {
                return;
            }
            cVar3 = *pcVar6;
            if ((cVar3 == '\\') && (cVar4 = fcn.18002cd40(arg1, pcVar6), cVar4 != '\0')) {
                cVar3 = pcVar6[1];
                bVar2 = true;
            } else {
                bVar2 = false;
            }
            if ((((uVar7 & 4) != 0) && (cVar3 == '\n')) && (*(int32_t *)(arg1 + 0x14) == 0)) {
                return;
            }
            if (((bVar2) && (cVar3 == ')')) && (*(int32_t *)(arg1 + 0x14) != 0)) {
                return;
            }
            break;
        case 0x28:
        case 0x29:
            if ((*(uint8_t *)(arg1 + 0x60) & 8) != 0) {
                return;
            }
            break;
        case 0x2b:
        case 0x3f:
            if ((*(uint8_t *)(arg1 + 0x60) & 1) != 0) {
                return;
            }
            break;
        case 0x5c:
            iVar5 = *(int64_t *)arg1;
            cVar3 = fcn.18002cd40(arg1, iVar5);
            if (cVar3 == '\0') {
                return;
            }
            uVar1 = *(uint8_t *)(iVar5 + 1);
            *(uint8_t *)(arg1 + 0x75) = uVar1;
            *(uint32_t *)(arg1 + 0x70) = (uint32_t)uVar1;
            return;
        case 0x7b:
        case 0x7d:
            if ((*(uint8_t *)(arg1 + 0x60) & 0x10) != 0) {
                return;
            }
            break;
        case 0x7c:
            if ((*(uint8_t *)(arg1 + 0x60) & 2) != 0) {
                return;
            }
        }
    }
    *(undefined4 *)(arg1 + 0x70) = 0;
code_r0x00018002bae8:
    return;
}

// ============================================================
// Function: FUN_18002baca
// Address: 0x18002baca
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18002b970(int64_t arg1)
{
    uint8_t uVar1;
    bool bVar2;
    char cVar3;
    char cVar4;
    int64_t iVar5;
    char *pcVar6;
    uint64_t uVar7;
    int64_t var_8h;
    
    if (*(uint8_t **)arg1 == *(uint8_t **)(arg1 + 8)) {
        *(undefined *)(arg1 + 0x75) = 0;
        *(undefined4 *)(arg1 + 0x70) = 0xffffffff;
        return;
    }
    uVar1 = **(uint8_t **)arg1;
    *(uint8_t *)(arg1 + 0x75) = uVar1;
    iVar5 = fcn.18045b928(0x1806221e0, (int32_t)(char)uVar1);
    if (iVar5 != 0) {
        *(uint32_t *)(arg1 + 0x70) = (uint32_t)uVar1;
    // switch table (116 cases) at 0x18002baf4
        switch((uint32_t)uVar1) {
        case 10:
            if ((*(uint8_t *)(arg1 + 0x60) & 4) == 0) {
                return;
            }
            if (*(int32_t *)(arg1 + 0x14) != 0) {
                return;
            }
            *(undefined4 *)(arg1 + 0x70) = 0x7c;
            return;
        default:
            goto code_r0x00018002bae8;
        case 0x24:
            uVar7 = *(uint64_t *)(arg1 + 0x60);
            if ((uVar7 >> 0x18 & 1) == 0) {
                return;
            }
            pcVar6 = (char *)(*(int64_t *)arg1 + 1);
            if (pcVar6 == *(char **)(arg1 + 8)) {
                return;
            }
            cVar3 = *pcVar6;
            if ((cVar3 == '\\') && (cVar4 = fcn.18002cd40(arg1, pcVar6), cVar4 != '\0')) {
                cVar3 = pcVar6[1];
                bVar2 = true;
            } else {
                bVar2 = false;
            }
            if ((((uVar7 & 4) != 0) && (cVar3 == '\n')) && (*(int32_t *)(arg1 + 0x14) == 0)) {
                return;
            }
            if (((bVar2) && (cVar3 == ')')) && (*(int32_t *)(arg1 + 0x14) != 0)) {
                return;
            }
            break;
        case 0x28:
        case 0x29:
            if ((*(uint8_t *)(arg1 + 0x60) & 8) != 0) {
                return;
            }
            break;
        case 0x2b:
        case 0x3f:
            if ((*(uint8_t *)(arg1 + 0x60) & 1) != 0) {
                return;
            }
            break;
        case 0x5c:
            iVar5 = *(int64_t *)arg1;
            cVar3 = fcn.18002cd40(arg1, iVar5);
            if (cVar3 == '\0') {
                return;
            }
            uVar1 = *(uint8_t *)(iVar5 + 1);
            *(uint8_t *)(arg1 + 0x75) = uVar1;
            *(uint32_t *)(arg1 + 0x70) = (uint32_t)uVar1;
            return;
        case 0x7b:
        case 0x7d:
            if ((*(uint8_t *)(arg1 + 0x60) & 0x10) != 0) {
                return;
            }
            break;
        case 0x7c:
            if ((*(uint8_t *)(arg1 + 0x60) & 2) != 0) {
                return;
            }
        }
    }
    *(undefined4 *)(arg1 + 0x70) = 0;
code_r0x00018002bae8:
    return;
}

// ============================================================
// Function: FUN_18002badb
// Address: 0x18002badb
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18002b970(int64_t arg1)
{
    uint8_t uVar1;
    bool bVar2;
    char cVar3;
    char cVar4;
    int64_t iVar5;
    char *pcVar6;
    uint64_t uVar7;
    int64_t var_8h;
    
    if (*(uint8_t **)arg1 == *(uint8_t **)(arg1 + 8)) {
        *(undefined *)(arg1 + 0x75) = 0;
        *(undefined4 *)(arg1 + 0x70) = 0xffffffff;
        return;
    }
    uVar1 = **(uint8_t **)arg1;
    *(uint8_t *)(arg1 + 0x75) = uVar1;
    iVar5 = fcn.18045b928(0x1806221e0, (int32_t)(char)uVar1);
    if (iVar5 != 0) {
        *(uint32_t *)(arg1 + 0x70) = (uint32_t)uVar1;
    // switch table (116 cases) at 0x18002baf4
        switch((uint32_t)uVar1) {
        case 10:
            if ((*(uint8_t *)(arg1 + 0x60) & 4) == 0) {
                return;
            }
            if (*(int32_t *)(arg1 + 0x14) != 0) {
                return;
            }
            *(undefined4 *)(arg1 + 0x70) = 0x7c;
            return;
        default:
            goto code_r0x00018002bae8;
        case 0x24:
            uVar7 = *(uint64_t *)(arg1 + 0x60);
            if ((uVar7 >> 0x18 & 1) == 0) {
                return;
            }
            pcVar6 = (char *)(*(int64_t *)arg1 + 1);
            if (pcVar6 == *(char **)(arg1 + 8)) {
                return;
            }
            cVar3 = *pcVar6;
            if ((cVar3 == '\\') && (cVar4 = fcn.18002cd40(arg1, pcVar6), cVar4 != '\0')) {
                cVar3 = pcVar6[1];
                bVar2 = true;
            } else {
                bVar2 = false;
            }
            if ((((uVar7 & 4) != 0) && (cVar3 == '\n')) && (*(int32_t *)(arg1 + 0x14) == 0)) {
                return;
            }
            if (((bVar2) && (cVar3 == ')')) && (*(int32_t *)(arg1 + 0x14) != 0)) {
                return;
            }
            break;
        case 0x28:
        case 0x29:
            if ((*(uint8_t *)(arg1 + 0x60) & 8) != 0) {
                return;
            }
            break;
        case 0x2b:
        case 0x3f:
            if ((*(uint8_t *)(arg1 + 0x60) & 1) != 0) {
                return;
            }
            break;
        case 0x5c:
            iVar5 = *(int64_t *)arg1;
            cVar3 = fcn.18002cd40(arg1, iVar5);
            if (cVar3 == '\0') {
                return;
            }
            uVar1 = *(uint8_t *)(iVar5 + 1);
            *(uint8_t *)(arg1 + 0x75) = uVar1;
            *(uint32_t *)(arg1 + 0x70) = (uint32_t)uVar1;
            return;
        case 0x7b:
        case 0x7d:
            if ((*(uint8_t *)(arg1 + 0x60) & 0x10) != 0) {
                return;
            }
            break;
        case 0x7c:
            if ((*(uint8_t *)(arg1 + 0x60) & 2) != 0) {
                return;
            }
        }
    }
    *(undefined4 *)(arg1 + 0x70) = 0;
code_r0x00018002bae8:
    return;
}

// ============================================================
// Function: FUN_18002baf4
// Address: 0x18002baf4
// Size: 148 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_18002bb90
// Address: 0x18002bb90
// Size: 121 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18002bb90(int64_t arg1, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    char cVar5;
    undefined8 *puVar6;
    undefined8 *puVar7;
    char *pcVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 0x40);
    cVar5 = func_0x00018002cdd0();
    if (cVar5 == '\0') {
        if (*(int32_t *)(arg1 + 0x70) != 0x7c) {
            return;
        }
        puVar6 = (undefined8 *)fcn.180459890(0x20);
        *puVar6 = 0x1806220a0;
        puVar6[1] = 8;
        puVar6[2] = 0;
        puVar6[3] = 0;
        func_0x00018002e210(arg1 + 0x38, puVar6);
        func_0x00018002bf70();
    }
    if (*(int32_t *)(arg1 + 0x70) == 0x7c) {
        puVar6 = (undefined8 *)fcn.180459890(0x20);
        puVar6[1] = 0x11;
        puVar6[2] = 0;
        puVar6[3] = 0;
        *puVar6 = 0x1806220a0;
        func_0x00018002e210(arg1 + 0x38, puVar6);
        puVar7 = (undefined8 *)fcn.180459890(0x30);
        puVar7[1] = 0x10;
        puVar7[2] = 0;
        puVar7[3] = 0;
        *puVar7 = 0x1806220b8;
        puVar7[4] = puVar6;
        puVar7[5] = 0;
        iVar2 = *(int64_t *)(iVar1 + 0x10);
        *(undefined8 **)(*(int64_t *)(iVar2 + 0x18) + 0x10) = puVar7;
        puVar7[3] = *(undefined8 *)(iVar2 + 0x18);
        *(undefined8 **)(iVar2 + 0x18) = puVar7;
        puVar7[2] = iVar2;
        do {
            pcVar8 = *(char **)arg1;
            if (pcVar8 != *(char **)(arg1 + 8)) {
                if ((((*pcVar8 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                    (pcVar8 = pcVar8 + 1, pcVar8 != *(char **)(arg1 + 8))) &&
                   ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar8 - 0x28U) < 2)) ||
                    (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar8 + 0x85U & 0xfd) == 0)))))) {
                    *(char **)arg1 = pcVar8;
                }
                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
            }
            fcn.18002b970(arg1);
            cVar5 = func_0x00018002cdd0(arg1);
            if (cVar5 == '\0') {
                puVar7 = (undefined8 *)fcn.180459890(0x20);
                *puVar7 = 0x1806220a0;
                puVar7[1] = 8;
                puVar7[2] = 0;
                puVar7[3] = 0;
                func_0x00018002e210(arg1 + 0x38, puVar7);
                func_0x00018002bf70();
            }
            iVar2 = *(int64_t *)(iVar1 + 0x10);
            iVar3 = puVar6[2];
            puVar6[2] = 0;
            iVar4 = *(int64_t *)(arg1 + 0x40);
            *(undefined8 **)(arg1 + 0x40) = puVar6;
            puVar6[2] = 0;
            *(undefined8 **)(iVar4 + 0x10) = puVar6;
            iVar4 = *(int64_t *)(iVar2 + 0x28);
            while (iVar4 != 0) {
                iVar2 = *(int64_t *)(iVar2 + 0x28);
                iVar4 = *(int64_t *)(iVar2 + 0x28);
            }
            puVar7 = (undefined8 *)fcn.180459890(0x30);
            puVar7[1] = 0x10;
            puVar7[3] = 0;
            *puVar7 = 0x1806220b8;
            puVar7[4] = puVar6;
            puVar7[5] = 0;
            *(undefined8 **)(iVar2 + 0x28) = puVar7;
            puVar7[2] = iVar3;
            *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar2 + 0x28);
        } while (*(int32_t *)(arg1 + 0x70) == 0x7c);
    }
    return;
}

// ============================================================
// Function: FUN_18002bc09
// Address: 0x18002bc09
// Size: 404 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18002bb90(int64_t arg1, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    char cVar5;
    undefined8 *puVar6;
    undefined8 *puVar7;
    char *pcVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 0x40);
    cVar5 = func_0x00018002cdd0();
    if (cVar5 == '\0') {
        if (*(int32_t *)(arg1 + 0x70) != 0x7c) {
            return;
        }
        puVar6 = (undefined8 *)fcn.180459890(0x20);
        *puVar6 = 0x1806220a0;
        puVar6[1] = 8;
        puVar6[2] = 0;
        puVar6[3] = 0;
        func_0x00018002e210(arg1 + 0x38, puVar6);
        func_0x00018002bf70();
    }
    if (*(int32_t *)(arg1 + 0x70) == 0x7c) {
        puVar6 = (undefined8 *)fcn.180459890(0x20);
        puVar6[1] = 0x11;
        puVar6[2] = 0;
        puVar6[3] = 0;
        *puVar6 = 0x1806220a0;
        func_0x00018002e210(arg1 + 0x38, puVar6);
        puVar7 = (undefined8 *)fcn.180459890(0x30);
        puVar7[1] = 0x10;
        puVar7[2] = 0;
        puVar7[3] = 0;
        *puVar7 = 0x1806220b8;
        puVar7[4] = puVar6;
        puVar7[5] = 0;
        iVar2 = *(int64_t *)(iVar1 + 0x10);
        *(undefined8 **)(*(int64_t *)(iVar2 + 0x18) + 0x10) = puVar7;
        puVar7[3] = *(undefined8 *)(iVar2 + 0x18);
        *(undefined8 **)(iVar2 + 0x18) = puVar7;
        puVar7[2] = iVar2;
        do {
            pcVar8 = *(char **)arg1;
            if (pcVar8 != *(char **)(arg1 + 8)) {
                if ((((*pcVar8 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                    (pcVar8 = pcVar8 + 1, pcVar8 != *(char **)(arg1 + 8))) &&
                   ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar8 - 0x28U) < 2)) ||
                    (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar8 + 0x85U & 0xfd) == 0)))))) {
                    *(char **)arg1 = pcVar8;
                }
                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
            }
            fcn.18002b970(arg1);
            cVar5 = func_0x00018002cdd0(arg1);
            if (cVar5 == '\0') {
                puVar7 = (undefined8 *)fcn.180459890(0x20);
                *puVar7 = 0x1806220a0;
                puVar7[1] = 8;
                puVar7[2] = 0;
                puVar7[3] = 0;
                func_0x00018002e210(arg1 + 0x38, puVar7);
                func_0x00018002bf70();
            }
            iVar2 = *(int64_t *)(iVar1 + 0x10);
            iVar3 = puVar6[2];
            puVar6[2] = 0;
            iVar4 = *(int64_t *)(arg1 + 0x40);
            *(undefined8 **)(arg1 + 0x40) = puVar6;
            puVar6[2] = 0;
            *(undefined8 **)(iVar4 + 0x10) = puVar6;
            iVar4 = *(int64_t *)(iVar2 + 0x28);
            while (iVar4 != 0) {
                iVar2 = *(int64_t *)(iVar2 + 0x28);
                iVar4 = *(int64_t *)(iVar2 + 0x28);
            }
            puVar7 = (undefined8 *)fcn.180459890(0x30);
            puVar7[1] = 0x10;
            puVar7[3] = 0;
            *puVar7 = 0x1806220b8;
            puVar7[4] = puVar6;
            puVar7[5] = 0;
            *(undefined8 **)(iVar2 + 0x28) = puVar7;
            puVar7[2] = iVar3;
            *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar2 + 0x28);
        } while (*(int32_t *)(arg1 + 0x70) == 0x7c);
    }
    return;
}

// ============================================================
// Function: FUN_18002bd9d
// Address: 0x18002bd9d
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18002bb90(int64_t arg1, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    char cVar5;
    undefined8 *puVar6;
    undefined8 *puVar7;
    char *pcVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 0x40);
    cVar5 = func_0x00018002cdd0();
    if (cVar5 == '\0') {
        if (*(int32_t *)(arg1 + 0x70) != 0x7c) {
            return;
        }
        puVar6 = (undefined8 *)fcn.180459890(0x20);
        *puVar6 = 0x1806220a0;
        puVar6[1] = 8;
        puVar6[2] = 0;
        puVar6[3] = 0;
        func_0x00018002e210(arg1 + 0x38, puVar6);
        func_0x00018002bf70();
    }
    if (*(int32_t *)(arg1 + 0x70) == 0x7c) {
        puVar6 = (undefined8 *)fcn.180459890(0x20);
        puVar6[1] = 0x11;
        puVar6[2] = 0;
        puVar6[3] = 0;
        *puVar6 = 0x1806220a0;
        func_0x00018002e210(arg1 + 0x38, puVar6);
        puVar7 = (undefined8 *)fcn.180459890(0x30);
        puVar7[1] = 0x10;
        puVar7[2] = 0;
        puVar7[3] = 0;
        *puVar7 = 0x1806220b8;
        puVar7[4] = puVar6;
        puVar7[5] = 0;
        iVar2 = *(int64_t *)(iVar1 + 0x10);
        *(undefined8 **)(*(int64_t *)(iVar2 + 0x18) + 0x10) = puVar7;
        puVar7[3] = *(undefined8 *)(iVar2 + 0x18);
        *(undefined8 **)(iVar2 + 0x18) = puVar7;
        puVar7[2] = iVar2;
        do {
            pcVar8 = *(char **)arg1;
            if (pcVar8 != *(char **)(arg1 + 8)) {
                if ((((*pcVar8 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                    (pcVar8 = pcVar8 + 1, pcVar8 != *(char **)(arg1 + 8))) &&
                   ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar8 - 0x28U) < 2)) ||
                    (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar8 + 0x85U & 0xfd) == 0)))))) {
                    *(char **)arg1 = pcVar8;
                }
                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
            }
            fcn.18002b970(arg1);
            cVar5 = func_0x00018002cdd0(arg1);
            if (cVar5 == '\0') {
                puVar7 = (undefined8 *)fcn.180459890(0x20);
                *puVar7 = 0x1806220a0;
                puVar7[1] = 8;
                puVar7[2] = 0;
                puVar7[3] = 0;
                func_0x00018002e210(arg1 + 0x38, puVar7);
                func_0x00018002bf70();
            }
            iVar2 = *(int64_t *)(iVar1 + 0x10);
            iVar3 = puVar6[2];
            puVar6[2] = 0;
            iVar4 = *(int64_t *)(arg1 + 0x40);
            *(undefined8 **)(arg1 + 0x40) = puVar6;
            puVar6[2] = 0;
            *(undefined8 **)(iVar4 + 0x10) = puVar6;
            iVar4 = *(int64_t *)(iVar2 + 0x28);
            while (iVar4 != 0) {
                iVar2 = *(int64_t *)(iVar2 + 0x28);
                iVar4 = *(int64_t *)(iVar2 + 0x28);
            }
            puVar7 = (undefined8 *)fcn.180459890(0x30);
            puVar7[1] = 0x10;
            puVar7[3] = 0;
            *puVar7 = 0x1806220b8;
            puVar7[4] = puVar6;
            puVar7[5] = 0;
            *(undefined8 **)(iVar2 + 0x28) = puVar7;
            puVar7[2] = iVar3;
            *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar2 + 0x28);
        } while (*(int32_t *)(arg1 + 0x70) == 0x7c);
    }
    return;
}

