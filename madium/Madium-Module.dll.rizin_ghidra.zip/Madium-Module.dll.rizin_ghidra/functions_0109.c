// Chunk 109 - 50 functions

// ============================================================
// Function: FUN_18017cfc0
// Address: 0x18017cfc0
// Size: 113 bytes
// ============================================================
void fcn.18017cfc0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t *piVar3;
    char cVar4;
    int32_t iVar5;
    int32_t iVar6;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)arg1 = 0x1804a6aa8;
    piVar3 = *(int64_t **)(arg1 + 0x170);
    if (piVar3 != (int64_t *)0x0) {
        (**(code **)(*piVar3 + 0x20))(piVar3, piVar3 != (int64_t *)(arg1 + 0x138));
        *(undefined8 *)(arg1 + 0x170) = 0;
    }
    piVar3 = *(int64_t **)(arg1 + 0x130);
    if (piVar3 != (int64_t *)0x0) {
        (**(code **)(*piVar3 + 0x20))(piVar3, piVar3 != (int64_t *)(arg1 + 0xf8));
        *(undefined8 *)(arg1 + 0x130) = 0;
    }
    *(undefined8 *)arg1 = 0x1804a6a98;
    if ((*(int64_t *)(arg1 + 8) != 0) && (*(int32_t *)(arg1 + 0x20) < 3)) {
        iVar5 = func_0x000180173bc0(*(undefined8 *)(arg1 + 8));
        if (*(int32_t *)(arg1 + 0x14) == iVar5) {
            cVar4 = func_0x000180173be0(*(undefined8 *)(arg1 + 8));
            if (cVar4 != '\0') {
                func_0x00018017f680(arg1, 0);
                if (*(int64_t *)(arg1 + 8) != 0) {
                    iVar5 = *(int32_t *)(arg1 + 0x14);
                    iVar6 = func_0x000180173bc0();
                    if (iVar5 == iVar6) {
                        func_0x000180174090(*(undefined8 *)(arg1 + 8), 0);
                    }
                }
            }
        }
    }
    piVar3 = *(int64_t **)(arg1 + 0xf0);
    if (piVar3 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar3 + 1;
        iVar5 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
            (**(code **)*piVar3)(piVar3);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar3 + 0xc);
            iVar5 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar5 == 1) {
                (**(code **)(*piVar3 + 8))(piVar3);
            }
        }
    }
    piVar3 = *(int64_t **)(arg1 + 0xe0);
    if (piVar3 != (int64_t *)0x0) {
        (**(code **)(*piVar3 + 0x20))(piVar3, piVar3 != (int64_t *)(arg1 + 0xa8), in_R8, in_R9, unaff_RDI);
        *(undefined8 *)(arg1 + 0xe0) = 0;
    }
    piVar3 = *(int64_t **)(arg1 + 0xa0);
    if (piVar3 != (int64_t *)0x0) {
        (**(code **)(*piVar3 + 0x20))(piVar3, piVar3 != (int64_t *)(arg1 + 0x68));
        *(undefined8 *)(arg1 + 0xa0) = 0;
    }
    piVar3 = *(int64_t **)(arg1 + 0x60);
    if (piVar3 != (int64_t *)0x0) {
        (**(code **)(*piVar3 + 0x20))(piVar3, piVar3 != (int64_t *)(arg1 + 0x28));
        *(undefined8 *)(arg1 + 0x60) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18017d040
// Address: 0x18017d040
// Size: 418 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18017d040(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)arg1 = 0x1804a6ae8;
    func_0x000180180e40(arg1, 1);
    piVar4 = *(int64_t **)(arg1 + 0x298);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    piVar4 = *(int64_t **)(arg1 + 0x288);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    piVar4 = *(int64_t **)(arg1 + 0x278);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    piVar4 = *(int64_t **)(arg1 + 0x268);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    piVar4 = *(int64_t **)(arg1 + 0x250);
    if (piVar4 != (int64_t *)0x0) {
        (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x218));
        *(undefined8 *)(arg1 + 0x250) = 0;
    }
    piVar4 = *(int64_t **)(arg1 + 0x210);
    if (piVar4 != (int64_t *)0x0) {
        (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x1d8));
        *(undefined8 *)(arg1 + 0x210) = 0;
    }
    piVar4 = *(int64_t **)(arg1 + 0x1d0);
    if (piVar4 != (int64_t *)0x0) {
        (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)(arg1 + 0x198));
        *(undefined8 *)(arg1 + 0x1d0) = 0;
    }
    func_0x000180004e40(arg1 + 0x178);
    *(undefined8 *)arg1 = 0x1804a6ad8;
    func_0x000180180e40(arg1, 1);
    func_0x00018017ccd0(arg1);
    func_0x000180061a70(arg1 + 0x148);
    return;
}

// ============================================================
// Function: FUN_18017d210
// Address: 0x18017d210
// Size: 3158 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_148h

void fcn.18017d210(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    undefined4 uVar2;
    code *pcVar3;
    int64_t *piVar4;
    undefined auVar5 [16];
    undefined auVar6 [16];
    undefined (*pauVar7) [16];
    char cVar8;
    int32_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    undefined (*pauVar12) [16];
    int64_t iVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    int64_t *piVar16;
    undefined (*pauVar17) [16];
    undefined *puVar18;
    undefined *puVar19;
    undefined *puVar20;
    undefined *puVar21;
    undefined *puVar22;
    undefined8 *puVar23;
    undefined8 uVar24;
    int64_t *piVar25;
    undefined (*pauVar26) [16];
    int64_t var_20h;
    undefined8 uStack_250;
    undefined auStack_248 [8];
    undefined auStack_240 [24];
    int64_t var_228h;
    int64_t var_220h;
    int64_t var_218h;
    int64_t var_210h;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1d0h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    int64_t var_1b8h;
    int64_t var_1b0h;
    int64_t var_1a8h;
    undefined8 uStack_1a0;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_158h;
    int64_t var_150h;
    undefined var_148h [2];
    int64_t var_146h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    
    puVar18 = auStack_248;
    puVar19 = auStack_248;
    puVar20 = auStack_248;
    puVar22 = auStack_248;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_248;
    pauVar17 = (undefined (*) [16])0x0;
    pauVar26 = *(undefined (**) [16])(arg3 + 8);
    piVar25 = *(int64_t **)(arg3 + 0x10);
    puVar21 = auStack_248;
    if (*(int32_t *)(*(int64_t *)arg1 + 600) == 2) {
        piVar16 = *(int64_t **)(*(int64_t *)arg1 + 0x260);
        iVar9 = (**(code **)(*piVar16 + 0x10))(piVar16, pauVar26, piVar25);
        piVar16 = (int64_t *)(int64_t)iVar9;
        if ((piVar16 != piVar25) &&
           (iVar9 = (**(code **)(**(int64_t **)(*(int64_t *)arg1 + 0x260) + 0x60))(), iVar9 != 0)) {
            iVar10 = func_0x00018045b9a8(0x1804a6bd0, 0x5c);
            uVar11 = func_0x0001801723e0();
            var_220h = 0x1804a6c70;
            var_228h = CONCAT44(var_228h._4_4_, 0x68);
            uVar24 = 0x1804a6cc8;
            puVar22 = auStack_248;
            goto code_r0x00018017de10;
        }
        pauVar26 = (undefined (*) [16])(*pauVar26 + (int64_t)piVar16);
        piVar25 = (int64_t *)((int64_t)piVar25 - (int64_t)piVar16);
        cVar8 = (**(code **)(**(int64_t **)(*(int64_t *)arg1 + 0x260) + 0x30))();
        puVar21 = auStack_248;
        if (cVar8 == '\0') goto code_r0x00018017ddad;
        iVar10 = *(int64_t *)(*(int64_t *)arg1 + 0x280);
        iVar9 = *(int32_t *)(iVar10 + 0xe0);
        iVar13 = *(int64_t *)(*(int64_t *)arg1 + 0x270);
        if (iVar9 == 0x65) {
            func_0x000180178270(iVar13, &var_128h, 0x1804a6b08, 0x18069c1d0);
            _var_68h = ZEXT816(0);
            piVar16 = &var_128h;
            if (0xf < (uint64_t)var_110h) {
                piVar16 = (int64_t *)var_128h;
            }
            _var_58h = _var_68h;
            func_0x0001801898c0(piVar16, &var_68h);
            func_0x000180178270(*(undefined8 *)(*(int64_t *)arg1 + 0x280), &var_168h, 0x1804a6d58, 0x18069c1d0);
            piVar16 = &var_168h;
            if (0xf < (uint64_t)var_150h) {
                piVar16 = (int64_t *)CONCAT71(var_168h._1_7_, (undefined)var_168h);
            }
            iVar9 = func_0x000180498f10(&var_68h, piVar16);
            if (iVar9 != 0) {
                iVar10 = func_0x00018045b9a8(0x1804a6bd0, 0x5c);
                uVar11 = func_0x0001801723e0();
                var_220h = 0x1804a6c70;
                var_228h = CONCAT44(var_228h._4_4_, 0x88);
                func_0x000180172b00(uVar11, 4, 0x1804a6d70, iVar10 + 1);
                func_0x00018017f680(*(int64_t *)arg2, *(int32_t *)(*(int64_t *)arg2 + 0x178) == 1);
                if (0xf < (uint64_t)var_150h) {
                    iVar10 = CONCAT71(var_168h._1_7_, (undefined)var_168h);
                    uVar14 = var_150h + 1;
                    if (0xfff < uVar14) {
                        if (0x1f < (iVar10 - *(int64_t *)(iVar10 + -8)) - 8U) goto code_r0x00018017dd4e;
                        uVar14 = var_150h + 0x28;
                        iVar10 = *(int64_t *)(iVar10 + -8);
                    }
                    func_0x000180459c3c(iVar10, uVar14);
                }
                var_158h = 0;
                var_150h = 0xf;
                var_168h._0_1_ = 0;
                puVar18 = auStack_248;
                if ((uint64_t)var_110h < 0x10) goto code_r0x00018017de30;
                var_188h = var_128h;
                if (0xfff < var_110h + 1U) {
                    puVar20 = auStack_248;
                    if ((var_128h - *(int64_t *)(var_128h + -8)) - 8U < 0x20) {
                        func_0x000180459c3c(*(int64_t *)(var_128h + -8), var_110h + 0x28);
                        puVar18 = auStack_248;
                        goto code_r0x00018017de30;
                    }
                    goto code_r0x00018017dd9e;
                }
code_r0x00018017d82b:
                *(undefined8 *)(puVar19 + -8) = 0x18017d833;
                func_0x000180459c3c(var_188h);
                puVar18 = puVar19;
                goto code_r0x00018017de30;
            }
            pauVar12 = (undefined (*) [16])func_0x000180459890(0x80);
            _var_148h = (int64_t)pauVar12;
            if (pauVar12 != (undefined (*) [16])0x0) {
                *pauVar12 = ZEXT816(0);
                *(undefined4 *)((int64_t)*pauVar12 + 8) = 1;
                *(undefined4 *)((int64_t)*pauVar12 + 0xc) = 1;
                *(int64_t *)*pauVar12 = 0x1804a6f18;
                func_0x000180189f70(pauVar12 + 1);
                pauVar17 = pauVar12;
            }
            iVar10 = *(int64_t *)arg1;
            *(undefined (**) [16])(iVar10 + 0x290) = pauVar17 + 1;
            piVar16 = *(int64_t **)(iVar10 + 0x298);
            *(undefined (**) [16])(iVar10 + 0x298) = pauVar17;
            if (piVar16 != (int64_t *)0x0) {
                LOCK();
                piVar4 = piVar16 + 1;
                iVar9 = *(int32_t *)piVar4;
                *(int32_t *)piVar4 = *(int32_t *)piVar4 + -1;
                UNLOCK();
                if (iVar9 == 1) {
                    (**(code **)*piVar16)(piVar16);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar16 + 0xc);
                    iVar9 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar9 == 1) {
                        (**(code **)(*piVar16 + 8))(piVar16);
                    }
                }
            }
            var_100h = *(int64_t *)arg1;
            iVar10 = *(int64_t *)(var_100h + 0x290);
            piVar16 = (int64_t *)(iVar10 + 0x30);
            var_108h = 0x1804a7128;
            var_d0h = (int64_t)&var_108h;
            var_70h = 0;
            var_f8h = arg2;
            var_70h = func_0x00018017e8c0(&var_108h, &var_a8h);
            if (var_d0h != 0) {
                (**(code **)(*(int64_t *)var_d0h + 0x20))
                          (var_d0h, CONCAT71((unkint7)((uint64_t)&var_108h >> 8), (int64_t *)var_d0h != &var_108h));
                var_d0h = 0;
            }
            piVar4 = *(int64_t **)(iVar10 + 0x68);
            if (piVar4 != (int64_t *)0x0) {
                if (piVar4 == piVar16) {
                    var_d0h = (**(code **)(*piVar4 + 8))(piVar4, &var_108h);
                    piVar4 = *(int64_t **)(iVar10 + 0x68);
                    if (piVar4 == (int64_t *)0x0) goto code_r0x00018017db91;
                    (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != piVar16);
                } else {
                    var_d0h = (int64_t)piVar4;
                }
                *(undefined8 *)(iVar10 + 0x68) = 0;
            }
code_r0x00018017db91:
            if (var_70h != 0) {
                if ((int64_t *)var_70h == &var_a8h) {
                    uVar11 = (**(code **)(*(int64_t *)var_70h + 8))(var_70h, piVar16);
                    *(undefined8 *)(iVar10 + 0x68) = uVar11;
                    if (var_70h != 0) {
                        (**(code **)(*(int64_t *)var_70h + 0x20))
                                  (var_70h, CONCAT71((unkint7)((uint64_t)&var_a8h >> 8), (int64_t *)var_70h != &var_a8h)
                                  );
                    }
                } else {
                    *(int64_t *)(iVar10 + 0x68) = var_70h;
                }
            }
            if (var_d0h != 0) {
                (**(code **)(*(int64_t *)var_d0h + 0x20))
                          (var_d0h, CONCAT71((unkint7)((uint64_t)&var_108h >> 8), (int64_t *)var_d0h != &var_108h));
            }
            *(undefined4 *)(*(int64_t *)arg1 + 600) = 3;
            if (0 < *(int32_t *)(*(int64_t *)arg1 + 0x2a0)) {
                *(undefined4 *)(*(int64_t *)arg1 + 0x2a4) = 0;
                var_208h = 0x1804a6fa0;
                var_200h = *(int64_t *)arg1;
                var_1d0h = (int64_t)&var_208h;
                iVar10 = *(int64_t *)arg2;
                if (*(int64_t *)(iVar10 + 8) == 0) {
                    func_0x00018000f480(&var_208h, 0);
                } else {
                    uVar2 = *(undefined4 *)(*(int64_t *)arg1 + 0x2a0);
                    piVar16 = (int64_t *)(iVar10 + 0x138);
                    if (piVar16 != &var_208h) {
                        piVar4 = *(int64_t **)(iVar10 + 0x170);
                        if (piVar4 != (int64_t *)0x0) {
                            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != piVar16);
                            *(undefined8 *)(iVar10 + 0x170) = 0;
                        }
                        if (var_1d0h != 0) {
                            if ((int64_t *)var_1d0h == &var_208h) {
                                uVar11 = (**(code **)(*(int64_t *)var_1d0h + 8))(var_1d0h, piVar16);
                                *(undefined8 *)(iVar10 + 0x170) = uVar11;
                                if (var_1d0h == 0) goto code_r0x00018017dcd1;
                                (**(code **)(*(int64_t *)var_1d0h + 0x20))
                                          (var_1d0h, 
                                           CONCAT71((unkint7)((uint64_t)&var_208h >> 8), 
                                                    (int64_t *)var_1d0h != &var_208h));
                            } else {
                                *(int64_t *)(iVar10 + 0x170) = var_1d0h;
                            }
                            var_1d0h = 0;
                        }
                    }
code_r0x00018017dcd1:
                    func_0x0001801740a0(*(undefined8 *)(iVar10 + 8), uVar2, 0x180180590);
                    if (var_1d0h != 0) {
                        (**(code **)(*(int64_t *)var_1d0h + 0x20))
                                  (var_1d0h, 
                                   CONCAT71((unkint7)((uint64_t)&var_208h >> 8), (int64_t *)var_1d0h != &var_208h));
                    }
                }
            }
            if (*(int64_t *)(*(int64_t *)arg1 + 0x1d0) != 0) {
                (**(code **)(**(int64_t **)(*(int64_t *)arg1 + 0x1d0) + 0x10))();
            }
            if (0xf < (uint64_t)var_150h) {
                iVar13 = CONCAT71(var_168h._1_7_, (undefined)var_168h);
                iVar10 = iVar13;
                puVar20 = auStack_248;
                if ((0xfff < var_150h + 1U) &&
                   (iVar10 = *(int64_t *)(iVar13 + -8), puVar20 = auStack_248, 0x1f < (iVar13 - iVar10) - 8U)) {
code_r0x00018017dd4e:
                    pcVar3 = (code *)swi(0x29);
                    iVar10 = (*pcVar3)(5);
                    puVar20 = auStack_240;
                }
                *(undefined8 *)(puVar20 + -8) = 0x18017dd5d;
                func_0x000180459c3c(iVar10);
            }
            var_158h = 0;
            var_150h = 0xf;
            var_168h._0_1_ = 0;
            puVar21 = puVar20;
            if ((uint64_t)var_110h < 0x10) goto code_r0x00018017ddad;
            if ((0xfff < var_110h + 1U) &&
               (iVar10 = var_128h - *(int64_t *)(var_128h + -8), var_128h = *(int64_t *)(var_128h + -8),
               0x1f < iVar10 - 8U)) goto code_r0x00018017dd9e;
code_r0x00018017dda8:
            *(undefined8 *)(puVar20 + -8) = 0x18017ddad;
            func_0x000180459c3c(var_128h);
            puVar21 = puVar20;
            goto code_r0x00018017ddad;
        }
        if (((*(uint8_t *)(iVar13 + 0x1b4) & 1) != 0) && ((iVar9 - 0x12dU < 3 || (iVar9 - 0x133U < 2)))) {
            var_1b8h = 8;
            var_1b0h = 0xf;
            _var_1c8h = (unkuint9)0x6e6f697461636f4c;
            var_1c0h._1_7_ = 0;
            piVar16 = (int64_t *)func_0x000180014c60(iVar10 + 0x10, var_148h, &var_1c8h);
            func_0x00018000b4d0(&var_188h, *piVar16 + 0x40);
            if ((uint64_t)var_1b0h < 0x10) {
code_r0x00018017d3b5:
                var_1b8h = 0;
                var_1b0h = 0xf;
                auVar5[15] = 0;
                auVar5._0_15_ = stack0xfffffffffffffe39;
                _var_1c8h = auVar5 << 8;
                if (var_178h == 0) {
                    if (0xf < (uint64_t)var_170h) {
                        uVar14 = var_170h + 1;
                        if (0xfff < uVar14) {
                            puVar20 = auStack_248;
                            if (0x1f < (var_188h - *(int64_t *)(var_188h + -8)) - 8U) goto code_r0x00018017dd9e;
                            uVar14 = var_170h + 0x28;
                            var_188h = *(int64_t *)(var_188h + -8);
                        }
                        func_0x000180459c3c(var_188h, uVar14);
                    }
                    goto code_r0x00018017d875;
                }
                piVar25 = &var_188h;
                if (0xf < (uint64_t)var_170h) {
                    piVar25 = (int64_t *)var_188h;
                }
                puVar23 = (undefined8 *)(*(int64_t *)(*(int64_t *)arg1 + 0x270) + 0xe8);
                if (0xf < *(uint64_t *)(*(int64_t *)(*(int64_t *)arg1 + 0x270) + 0x100)) {
                    puVar23 = (undefined8 *)*puVar23;
                }
                iVar10 = func_0x00018045b9a8(0x1804a6bd0, 0x5c);
                uVar11 = func_0x0001801723e0();
                var_210h = 0x1804a6c70;
                var_218h = CONCAT44(var_218h._4_4_, 0x74);
                var_228h = (int64_t)piVar25;
                var_220h = iVar10 + 1;
                func_0x000180172b00(uVar11, 2, 0x1804a6ce8, puVar23);
                _var_1a8h = ZEXT816(0);
                auVar5 = _var_1a8h;
                uStack_1a0 = 0;
                var_198h = 0;
                var_190h = 0;
                pauVar26 = (undefined (*) [16])&var_188h;
                if (0xf < (uint64_t)var_170h) {
                    pauVar26 = (undefined (*) [16])var_188h;
                }
                _var_1a8h = auVar5;
                if (0x7fffffffffffffff < (uint64_t)var_178h) {
                    func_0x0001800047c0();
code_r0x00018017de60:
                    func_0x000180004720();
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                if ((uint64_t)var_178h < 0x10) {
                    var_198h = var_178h;
                    uVar14 = 0xf;
                    var_190h = 0xf;
                    pauVar17 = *(undefined (**) [16])*pauVar26;
                    _var_1a8h = *pauVar26;
                } else {
                    uVar14 = var_178h | 0xf;
                    if (uVar14 < 0x8000000000000000) {
                        if (uVar14 < 0x16) {
                            uVar14 = 0x16;
                        }
                        if (uVar14 != 0xffffffffffffffff) {
                            if (0xfff < uVar14 + 1) {
                                uVar15 = uVar14 + 0x28;
                                if (uVar15 <= uVar14 + 1) goto code_r0x00018017de60;
                                goto code_r0x00018017d4b7;
                            }
                            pauVar17 = (undefined (*) [16])func_0x000180459890();
                        }
                    } else {
                        uVar15 = 0x8000000000000027;
                        uVar14 = 0x7fffffffffffffff;
code_r0x00018017d4b7:
                        iVar10 = func_0x000180459890(uVar15);
                        puVar20 = auStack_248;
                        piVar25 = (int64_t *)var_178h;
                        if (iVar10 == 0) goto code_r0x00018017d7da;
                        pauVar17 = (undefined (*) [16])(iVar10 + 0x27U & 0xffffffffffffffe0);
                        *(int64_t *)((int64_t)pauVar17[-1] + 8) = iVar10;
                    }
                    var_1a8h = (int64_t)pauVar17;
                    var_198h = var_178h;
                    var_190h = uVar14;
                    func_0x000180498030(pauVar17, pauVar26, var_178h + 1);
                }
                var_1b8h = 4;
                var_1b0h = 0xf;
                stack0xfffffffffffffe3d = SUB1611(ZEXT816(0), 5);
                var_1c8h._0_5_ = 0x70747468;
                cVar8 = func_0x000180185ac0(&var_188h, &var_1c8h);
                if ((uint64_t)var_1b0h < 0x10) {
code_r0x00018017d5a4:
                    if (cVar8 != '\0') {
                        var_138h = 2;
                        var_130h = 0xf;
                        stack0xfffffffffffffebb = SUB1613(ZEXT816(0), 3);
                        _var_148h = 0x7377;
                        var_1b8h = 4;
                        var_1b0h = 0xf;
                        stack0xfffffffffffffe3d = SUB1611(ZEXT816(0), 5);
                        var_1c8h._0_5_ = 0x70747468;
                        pauVar12 = (undefined (*) [16])func_0x000180185a30(&var_c8h, &var_188h, &var_1c8h, var_148h);
                        if ((undefined (*) [16])&var_1a8h == pauVar12) {
code_r0x00018017d67a:
                            puVar18 = auStack_248;
                            if (0xf < (uint64_t)var_b0h) {
                                iVar10 = CONCAT71(var_c8h._1_7_, (undefined)var_c8h);
                                puVar18 = auStack_248;
                                if ((0xfff < var_b0h + 1U) &&
                                   (iVar13 = iVar10 - *(int64_t *)(iVar10 + -8), iVar10 = *(int64_t *)(iVar10 + -8),
                                   puVar18 = auStack_248, 0x1f < iVar13 - 8U)) goto code_r0x00018017d6b1;
                                goto code_r0x00018017d6bb;
                            }
                        } else {
                            if (uVar14 < 0x10) {
code_r0x00018017d64a:
                                pauVar17 = *(undefined (**) [16])*pauVar12;
                                _var_1a8h = *pauVar12;
                                var_198h = *(int64_t *)pauVar12[1];
                                uVar14 = *(uint64_t *)(pauVar12[1] + 8);
                                *(undefined8 *)pauVar12[1] = 0;
                                *(undefined8 *)(pauVar12[1] + 8) = 0xf;
                                (*pauVar12)[0] = 0;
                                var_190h = uVar14;
                                goto code_r0x00018017d67a;
                            }
                            uVar15 = uVar14 + 1;
                            if (uVar15 < 0x1000) {
code_r0x00018017d645:
                                func_0x000180459c3c(pauVar17, uVar15);
                                goto code_r0x00018017d64a;
                            }
                            pauVar7 = pauVar17 + -1;
                            pauVar17 = (undefined (*) [16])
                                       ((int64_t)pauVar17 +
                                       (-8 - (int64_t)*(undefined (**) [16])((int64_t)*pauVar7 + 8)));
                            if (pauVar17 < (undefined (*) [16])0x20) {
                                uVar15 = uVar14 + 0x28;
                                pauVar17 = *(undefined (**) [16])((int64_t)*pauVar7 + 8);
                                goto code_r0x00018017d645;
                            }
code_r0x00018017d6b1:
                            pcVar3 = (code *)swi(0x29);
                            iVar10 = (*pcVar3)(5);
                            puVar18 = auStack_240;
code_r0x00018017d6bb:
                            *(undefined8 *)(puVar18 + -8) = 0x18017d6c0;
                            func_0x000180459c3c(iVar10);
                        }
                        var_b8h = 0;
                        var_b0h = 0xf;
                        var_c8h._0_1_ = 0;
                        if (0xf < (uint64_t)var_1b0h) {
                            iVar10 = var_1c8h;
                            if ((0xfff < var_1b0h + 1U) &&
                               (iVar10 = *(int64_t *)(var_1c8h + -8), 0x1f < (var_1c8h - iVar10) - 8U)) {
                                pcVar3 = (code *)swi(0x29);
                                iVar10 = (*pcVar3)(5);
                                puVar18 = puVar18 + 8;
                            }
                            *(undefined8 *)(puVar18 + -8) = 0x18017d719;
                            func_0x000180459c3c(iVar10);
                        }
                        var_1b8h = 0;
                        var_1b0h = 0xf;
                        auVar6[15] = 0;
                        auVar6._0_15_ = stack0xfffffffffffffe39;
                        _var_1c8h = auVar6 << 8;
                        if (0xf < (uint64_t)var_130h) {
                            iVar10 = _var_148h;
                            if ((0xfff < var_130h + 1U) &&
                               (iVar10 = *(int64_t *)(_var_148h + -8), puVar20 = puVar18,
                               0x1f < (_var_148h - iVar10) - 8U)) goto code_r0x00018017d75a;
                            goto code_r0x00018017d764;
                        }
                    }
                } else {
                    uVar15 = var_1b0h + 1;
                    iVar10 = var_1c8h;
                    if (uVar15 < 0x1000) {
code_r0x00018017d59c:
                        func_0x000180459c3c(iVar10, uVar15);
                        goto code_r0x00018017d5a4;
                    }
                    puVar20 = auStack_248;
                    if ((var_1c8h - *(int64_t *)(var_1c8h + -8)) - 8U < 0x20) {
                        uVar15 = var_1b0h + 0x28;
                        iVar10 = *(int64_t *)(var_1c8h + -8);
                        goto code_r0x00018017d59c;
                    }
code_r0x00018017d75a:
                    pcVar3 = (code *)swi(0x29);
                    iVar10 = (*pcVar3)(5);
                    puVar18 = puVar20 + 8;
code_r0x00018017d764:
                    *(undefined8 *)(puVar18 + -8) = 0x18017d769;
                    func_0x000180459c3c(iVar10);
                }
                iVar10 = *(int64_t *)arg2;
                piVar25 = (int64_t *)(iVar10 + 0xa8);
                piVar16 = *(int64_t **)(iVar10 + 0xe0);
                if (piVar16 != (int64_t *)0x0) {
                    pcVar3 = *(code **)(*piVar16 + 0x20);
                    *(undefined8 *)(puVar18 + -8) = 0x18017d789;
                    (*pcVar3)(piVar16, piVar16 != piVar25);
                    *(undefined8 *)(iVar10 + 0xe0) = 0;
                }
                pauVar12 = (undefined (*) [16])&var_1a8h;
                if (0xf < uVar14) {
                    pauVar12 = pauVar17;
                }
                uVar11 = *(undefined8 *)arg1;
                *(undefined8 *)(puVar18 + -8) = 0x18017d7a8;
                func_0x00018017fc00(uVar11, pauVar12, 0x18077e0e0);
                if (0xf < (uint64_t)var_190h) {
                    iVar10 = var_1a8h;
                    if ((0xfff < var_190h + 1U) &&
                       (iVar10 = *(int64_t *)(var_1a8h + -8), puVar20 = puVar18,
                       0x1f < (var_1a8h - *(int64_t *)(var_1a8h + -8)) - 8U)) goto code_r0x00018017d7da;
                    goto code_r0x00018017d7e4;
                }
            } else {
                uVar14 = var_1b0h + 1;
                iVar10 = var_1c8h;
                if (uVar14 < 0x1000) {
code_r0x00018017d3b0:
                    func_0x000180459c3c(iVar10, uVar14);
                    goto code_r0x00018017d3b5;
                }
                puVar20 = auStack_248;
                if ((var_1c8h - *(int64_t *)(var_1c8h + -8)) - 8U < 0x20) {
                    uVar14 = var_1b0h + 0x28;
                    iVar10 = *(int64_t *)(var_1c8h + -8);
                    goto code_r0x00018017d3b0;
                }
code_r0x00018017d7da:
                pcVar3 = (code *)swi(0x29);
                iVar10 = (*pcVar3)(5);
                puVar18 = puVar20 + 8;
code_r0x00018017d7e4:
                *(undefined8 *)(puVar18 + -8) = 0x18017d7e9;
                func_0x000180459c3c(iVar10);
            }
            if ((uint64_t)var_170h < 0x10) goto code_r0x00018017de30;
            puVar19 = puVar18;
            if (var_170h + 1U < 0x1000) goto code_r0x00018017d82b;
            iVar10 = *(int64_t *)(var_188h + -8);
            puVar20 = puVar18;
            if ((var_188h - iVar10) - 8U < 0x20) {
                *(undefined8 *)(puVar18 + -8) = 0x18017d826;
                func_0x000180459c3c(iVar10, var_170h + 0x28);
                goto code_r0x00018017de30;
            }
code_r0x00018017dd9e:
            pcVar3 = (code *)swi(0x29);
            var_128h = (*pcVar3)(5);
            puVar20 = puVar20 + 8;
            goto code_r0x00018017dda8;
        }
code_r0x00018017d875:
        iVar10 = *(int64_t *)(*(int64_t *)arg1 + 0x280);
        iVar13 = func_0x00018045b9a8(0x1804a6bd0, 0x5c);
        uVar2 = *(undefined4 *)(iVar10 + 0xe0);
        uVar11 = func_0x0001801723e0();
        var_218h = 0x1804a6c70;
        var_220h = CONCAT44(var_220h._4_4_, 0x7f);
        var_228h = iVar13 + 1;
        func_0x000180172b00(uVar11, 4, 0x1804a6d10, uVar2);
    } else {
code_r0x00018017ddad:
        puVar18 = puVar21;
        if ((*(int32_t *)(*(int64_t *)arg1 + 600) != 3) || (piVar25 == (int64_t *)0x0)) goto code_r0x00018017de30;
        uVar11 = *(undefined8 *)(*(int64_t *)arg1 + 0x290);
        *(undefined8 *)(puVar21 + -8) = 0x18017ddd0;
        iVar9 = func_0x00018018a030(uVar11, pauVar26, piVar25);
        if ((int64_t *)(int64_t)iVar9 == piVar25) goto code_r0x00018017de30;
        *(undefined8 *)(puVar21 + -8) = 0x18017dde9;
        iVar10 = func_0x00018045b9a8(0x1804a6bd0, 0x5c);
        *(undefined8 *)(puVar21 + -8) = 0x18017ddf2;
        uVar11 = func_0x0001801723e0();
        *(undefined8 *)(puVar21 + 0x28) = 0x1804a6c70;
        *(undefined4 *)(puVar21 + 0x20) = 0xbe;
        uVar24 = 0x1804a6da0;
        puVar22 = puVar21;
code_r0x00018017de10:
        *(undefined8 *)(puVar22 + -8) = 0x18017de1d;
        func_0x000180172b00(uVar11, 4, uVar24, iVar10 + 1);
    }
    arg2 = *(int64_t *)arg2;
    iVar9 = *(int32_t *)(arg2 + 0x178);
    *(undefined8 *)(puVar22 + -8) = 0x18017de30;
    func_0x00018017f680(arg2, iVar9 == 1);
    puVar18 = puVar22;
code_r0x00018017de30:
    *(undefined8 *)(puVar18 + -8) = 0x18017de3f;
    func_0x000180459870(var_48h ^ (uint64_t)puVar18);
    return;
}

// ============================================================
// Function: FUN_18017de70
// Address: 0x18017de70
// Size: 1722 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_beh
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c2h
// WARNING: [rz-ghidra] Detected overlap for variable var_c1h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch

void fcn.18017de70(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    code *pcVar4;
    char cVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int64_t *piVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t iVar12;
    undefined (*pauVar13) [16];
    uint64_t uVar14;
    undefined (*pauVar15) [16];
    undefined *puVar16;
    undefined *puVar17;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_e8 [8];
    undefined auStack_e0 [24];
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    undefined8 uStack_a0;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    undefined8 var_40h;
    int64_t var_38h;
    int64_t var_28h;
    
    puVar16 = auStack_e8;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_e8;
    pauVar15 = (undefined (*) [16])0x0;
    iVar9 = *(int64_t *)arg2;
    if ((((*(int32_t *)(iVar9 + 0x20) != 2) || (*(int64_t *)(iVar9 + 8) == 0)) || (2 < *(int32_t *)(iVar9 + 0x20))) ||
       ((iVar3 = *(int32_t *)(iVar9 + 0x14), iVar6 = func_0x000180173bc0(*(undefined8 *)(iVar9 + 8)), iVar3 != iVar6 ||
        (cVar5 = func_0x000180173be0(*(undefined8 *)(iVar9 + 8)), cVar5 == '\0')))) {
        *(undefined4 *)(*(int64_t *)arg1 + 600) = 4;
        puVar17 = auStack_e8;
        if (*(int64_t *)(*(int64_t *)arg1 + 0x210) != 0) {
            (**(code **)(**(int64_t **)(*(int64_t *)arg1 + 0x210) + 0x10))();
            puVar17 = auStack_e8;
        }
        goto code_r0x00018017e502;
    }
    *(undefined4 *)(*(int64_t *)arg1 + 600) = 1;
    var_b8h = 10;
    var_b0h = 0xf;
    var_c0h._0_2_ = 0x6e6f;
    var_c8h = 0x697463656e6e6f43;
    var_c0h._2_6_ = 0;
    piVar8 = (int64_t *)func_0x000180014c60(*(int64_t *)(*(int64_t *)arg1 + 0x270) + 0x10, &var_48h, &var_c8h);
    func_0x00018000f180(*piVar8 + 0x40, 0x1804a6b00, 7);
    if ((uint64_t)var_b0h < 0x10) {
code_r0x00018017dfa3:
        var_b8h = 7;
        var_b0h = 0xf;
        _var_c8h = ZEXT716(0x65646172677055);
        piVar8 = (int64_t *)func_0x000180014c60(*(int64_t *)(*(int64_t *)arg1 + 0x270) + 0x10, &var_48h, &var_c8h);
        func_0x00018000f180(*piVar8 + 0x40, 0x180624fa0, 9);
        if (0xf < (uint64_t)var_b0h) {
            uVar14 = var_b0h + 1;
            iVar9 = var_c8h;
            if (0xfff < uVar14) {
                if (0x1f < (var_c8h - *(int64_t *)(var_c8h + -8)) - 8U) goto code_r0x00018017e4cb;
                uVar14 = var_b0h + 0x28;
                iVar9 = *(int64_t *)(var_c8h + -8);
            }
            func_0x000180459c3c(iVar9, uVar14);
        }
        iVar9 = func_0x000180178270(*(undefined8 *)(*(int64_t *)arg1 + 0x270), &var_88h, 0x1804a6b08, 0x18069c1d0);
        iVar9 = *(int64_t *)(iVar9 + 0x10);
        if (0xf < (uint64_t)var_70h) {
            uVar14 = var_70h + 1;
            iVar12 = var_88h;
            if (0xfff < uVar14) {
                if (0x1f < (var_88h - *(int64_t *)(var_88h + -8)) - 8U) goto code_r0x00018017e4cb;
                uVar14 = var_70h + 0x28;
                iVar12 = *(int64_t *)(var_88h + -8);
            }
            func_0x000180459c3c(iVar12, uVar14);
        }
        if (iVar9 == 0) {
            _var_48h = ZEXT816(0);
            uVar7 = func_0x000180472118();
            var_48h._0_4_ = uVar7;
            uVar7 = func_0x000180472118();
            var_48h = CONCAT44(uVar7, (undefined4)var_48h);
            uVar7 = func_0x000180472118();
            var_40h._0_4_ = uVar7;
            uVar7 = func_0x000180472118();
            var_40h._4_4_ = uVar7;
            _var_88h = ZEXT816(0);
            _var_78h = ZEXT816(0);
            func_0x000180189720(&var_48h, 0x10, &var_88h);
            _var_a8h = ZEXT816(0);
            var_98h = 0;
            var_90h = 0;
            puVar10 = (undefined4 *)func_0x000180459890(0x20);
            var_a8h = (int64_t)puVar10;
            var_98h = 0x11;
            var_90h = 0x1f;
            *puVar10 = 0x2d636553;
            puVar10[1] = 0x53626557;
            puVar10[2] = 0x656b636f;
            puVar10[3] = 0x654b2d74;
            *(undefined *)(puVar10 + 4) = 0x79;
            *(undefined *)((int64_t)puVar10 + 0x11) = 0;
            piVar8 = (int64_t *)func_0x000180014c60(*(int64_t *)(*(int64_t *)arg1 + 0x270) + 0x10, &var_c8h, &var_a8h);
            iVar9 = *piVar8;
            uVar11 = func_0x000180498cd0(&var_88h);
            func_0x00018000f180(iVar9 + 0x40, &var_88h, uVar11);
            if (0xf < (uint64_t)var_90h) {
                uVar14 = var_90h + 1;
                iVar9 = var_a8h;
                if (0xfff < uVar14) {
                    if (0x1f < (var_a8h - *(int64_t *)(var_a8h + -8)) - 8U) goto code_r0x00018017e4cb;
                    uVar14 = var_90h + 0x28;
                    iVar9 = *(int64_t *)(var_a8h + -8);
                }
                func_0x000180459c3c(iVar9, uVar14);
            }
        }
        iVar9 = func_0x000180178270(*(undefined8 *)(*(int64_t *)arg1 + 0x270), &var_88h, 0x1804a6b20, 0x18069c1d0);
        iVar9 = *(int64_t *)(iVar9 + 0x10);
        if (0xf < (uint64_t)var_70h) {
            uVar14 = var_70h + 1;
            iVar12 = var_88h;
            if (0xfff < uVar14) {
                if (0x1f < (var_88h - *(int64_t *)(var_88h + -8)) - 8U) goto code_r0x00018017e4cb;
                uVar14 = var_70h + 0x28;
                iVar12 = *(int64_t *)(var_88h + -8);
            }
            func_0x000180459c3c(iVar12, uVar14);
        }
        if (iVar9 == 0) {
            _var_a8h = ZEXT816(0);
            var_98h = 0;
            var_90h = 0;
            puVar10 = (undefined4 *)func_0x000180459890(0x20);
            var_a8h = (int64_t)puVar10;
            var_98h = 0x15;
            var_90h = 0x1f;
            *puVar10 = 0x2d636553;
            puVar10[1] = 0x53626557;
            puVar10[2] = 0x656b636f;
            puVar10[3] = 0x65562d74;
            *(undefined8 *)((int64_t)puVar10 + 0xd) = 0x6e6f69737265562d;
            *(undefined *)((int64_t)puVar10 + 0x15) = 0;
            piVar8 = (int64_t *)func_0x000180014c60(*(int64_t *)(*(int64_t *)arg1 + 0x270) + 0x10, &var_c8h, &var_a8h);
            func_0x00018000f180(*piVar8 + 0x40, 0x1804a6b38, 2);
            if (0xf < (uint64_t)var_90h) {
                uVar14 = var_90h + 1;
                iVar9 = var_a8h;
                if (0xfff < uVar14) {
                    if (0x1f < (var_a8h - *(int64_t *)(var_a8h + -8)) - 8U) goto code_r0x00018017e4cb;
                    uVar14 = var_90h + 0x28;
                    iVar9 = *(int64_t *)(var_a8h + -8);
                }
                func_0x000180459c3c(iVar9, uVar14);
            }
        }
        (**(code **)(**(int64_t **)(*(int64_t *)arg1 + 0x270) + 0x10))
                  (*(int64_t **)(*(int64_t *)arg1 + 0x270), &var_68h, 1);
        arg2 = *(int64_t *)arg2;
        piVar8 = &var_68h;
        if (0xf < (uint64_t)var_50h) {
            piVar8 = (int64_t *)var_68h;
        }
        if (((*(int64_t *)(arg2 + 8) != 0) && (*(int32_t *)(arg2 + 0x20) < 3)) &&
           ((iVar3 = *(int32_t *)(arg2 + 0x14), iVar6 = func_0x000180173bc0(*(undefined8 *)(arg2 + 8)), iVar3 == iVar6
            && (cVar5 = func_0x000180173be0(*(undefined8 *)(arg2 + 8)), cVar5 != '\0')))) {
            func_0x000180183bc0(*(undefined8 *)(arg2 + 8), piVar8, (int64_t)(int32_t)var_58h);
        }
        *(undefined4 *)(*(int64_t *)arg1 + 600) = 2;
        iVar12 = func_0x000180189d50(0, 1);
        iVar9 = *(int64_t *)arg1;
        var_48h = iVar12;
        var_48h = func_0x000180459890(0x18);
        pauVar13 = pauVar15;
        if ((undefined (*) [16])var_48h != (undefined (*) [16])0x0) {
            *(undefined (*) [16])var_48h = ZEXT816(0);
            *(undefined4 *)((undefined *)var_48h + 8) = 1;
            *(undefined4 *)((undefined *)var_48h + 0xc) = 1;
            *(undefined8 *)(undefined *)var_48h = 0x1804a6f78;
            *(int64_t *)*(undefined (*) [16])(var_48h + 0x10) = iVar12;
            pauVar13 = (undefined (*) [16])var_48h;
        }
        *(int64_t *)(iVar9 + 0x260) = iVar12;
        piVar8 = *(int64_t **)(iVar9 + 0x268);
        *(undefined (**) [16])(iVar9 + 0x268) = pauVar13;
        if (piVar8 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar8 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar8)(piVar8);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar8 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar8 + 8))(piVar8);
                }
            }
        }
        pauVar13 = (undefined (*) [16])func_0x000180459890(0xf8);
        var_48h = (int64_t)pauVar13;
        if (pauVar13 != (undefined (*) [16])0x0) {
            *pauVar13 = ZEXT816(0);
            *(undefined4 *)(*pauVar13 + 8) = 1;
            *(undefined4 *)(*pauVar13 + 0xc) = 1;
            *(undefined8 *)*pauVar13 = 0x1804a6ef0;
            func_0x000180175b80(pauVar13 + 1);
            pauVar15 = pauVar13;
        }
        iVar9 = *(int64_t *)arg1;
        *(undefined (**) [16])(iVar9 + 0x280) = pauVar15 + 1;
        piVar8 = *(int64_t **)(iVar9 + 0x288);
        *(undefined (**) [16])(iVar9 + 0x288) = pauVar15;
        if (piVar8 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar8 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar8)(piVar8);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar8 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar8 + 8))(piVar8);
                }
            }
        }
        piVar8 = *(int64_t **)(*(int64_t *)arg1 + 0x260);
        (**(code **)(*piVar8 + 0x48))(piVar8, *(undefined8 *)(*(int64_t *)arg1 + 0x280));
        puVar17 = auStack_e8;
        if ((uint64_t)var_50h < 0x10) goto code_r0x00018017e502;
        if (0xfff < var_50h + 1U) {
            if ((var_68h - *(int64_t *)(var_68h + -8)) - 8U < 0x20) {
                func_0x000180459c3c(*(int64_t *)(var_68h + -8), var_50h + 0x28);
                puVar17 = auStack_e8;
                goto code_r0x00018017e502;
            }
            goto code_r0x00018017e4cb;
        }
    } else {
        uVar14 = var_b0h + 1;
        iVar9 = var_c8h;
        if (uVar14 < 0x1000) {
code_r0x00018017df9e:
            func_0x000180459c3c(iVar9, uVar14);
            goto code_r0x00018017dfa3;
        }
        if ((var_c8h - *(int64_t *)(var_c8h + -8)) - 8U < 0x20) {
            uVar14 = var_b0h + 0x28;
            iVar9 = *(int64_t *)(var_c8h + -8);
            goto code_r0x00018017df9e;
        }
code_r0x00018017e4cb:
        pcVar4 = (code *)swi(0x29);
        var_68h = (*pcVar4)(5);
        puVar16 = auStack_e0;
    }
    *(undefined8 *)(puVar16 + -8) = 0x18017e4da;
    func_0x000180459c3c(var_68h);
    puVar17 = puVar16;
code_r0x00018017e502:
    *(undefined8 *)(puVar17 + -8) = 0x18017e50e;
    func_0x000180459870(var_38h ^ (uint64_t)puVar17);
    return;
}

// ============================================================
// Function: FUN_18017e530
// Address: 0x18017e530
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18017e530(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    fcn.18017ccd0();
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x148);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18017e570
// Address: 0x18017e570
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18017e570(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0x1804a6ad8;
    fcn.180180e40(arg1, 1);
    fcn.18017ccd0(arg1);
    fcn.180061a70(arg1 + 0x148);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x178);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18017e5d0
// Address: 0x18017e5d0
// Size: 43 bytes
// ============================================================
int64_t fcn.18017e5d0(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1804a6e28;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x60);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18017e600
// Address: 0x18017e600
// Size: 43 bytes
// ============================================================
int64_t fcn.18017e600(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1804a6ec8;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x1c8);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18017e630
// Address: 0x18017e630
// Size: 43 bytes
// ============================================================
int64_t fcn.18017e630(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1804a6ef0;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0xf8);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18017e660
// Address: 0x18017e660
// Size: 43 bytes
// ============================================================
int64_t fcn.18017e660(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1804a7208;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x200);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18017e690
// Address: 0x18017e690
// Size: 43 bytes
// ============================================================
int64_t fcn.18017e690(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1804a6f18;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x80);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18017e6c0
// Address: 0x18017e6c0
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18017e6c0(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    fcn.18017ce50();
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0xf8);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18017e700
// Address: 0x18017e700
// Size: 98 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18017e700(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0x1804a6a88;
    if (*(char *)(arg1 + 0x18) != '\0') {
        if (*(int64_t *)(arg1 + 8) != 0) {
            func_0x000180180fe0();
            *(undefined8 *)(arg1 + 8) = 0;
        }
        *(undefined8 *)(arg1 + 0x10) = 0;
        *(undefined *)(arg1 + 0x18) = 0;
    }
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x20);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18017e770
// Address: 0x18017e770
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18017e770(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    fcn.18017cfc0(arg1);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x178);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18017e7b0
// Address: 0x18017e7b0
// Size: 135 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18017e7b0(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0x1804a6ab8;
    *(undefined8 *)(arg1 + 0x180) = 0x1804a6a88;
    if (*(char *)(arg1 + 0x198) != '\0') {
        if (*(int64_t *)(arg1 + 0x188) != 0) {
            func_0x000180180fe0();
            *(undefined8 *)(arg1 + 0x188) = 0;
        }
        *(undefined8 *)(arg1 + 400) = 0;
        *(undefined *)(arg1 + 0x198) = 0;
    }
    fcn.18017cfc0(arg1);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x1f0);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18017e840
// Address: 0x18017e840
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18017e840(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    fcn.18017d040(arg1);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x2a8);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18017ea00
// Address: 0x18017ea00
// Size: 133 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.18017ea00(int64_t arg1, int64_t arg_38h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    puVar2 = (undefined8 *)fcn.180459890(0x70);
    *puVar2 = 0x1804a6f40;
    puVar2[1] = *(undefined8 *)(arg1 + 8);
    puVar2[2] = *(undefined8 *)(arg1 + 0x10);
    *(undefined4 *)(puVar2 + 3) = *(undefined4 *)(arg1 + 0x18);
    puVar2[0xb] = 0;
    puVar1 = *(undefined8 **)(arg1 + 0x58);
    if (puVar1 != (undefined8 *)0x0) {
        uVar3 = (**(code **)*puVar1)(puVar1, puVar2 + 4);
        puVar2[0xb] = uVar3;
    }
    *(undefined4 *)(puVar2 + 0xc) = *(undefined4 *)(arg1 + 0x60);
    puVar2[0xd] = *(undefined8 *)(arg1 + 0x68);
    return puVar2;
}

// ============================================================
// Function: FUN_18017eaa0
// Address: 0x18017eaa0
// Size: 88 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18017eaa0(int64_t arg1)
{
    int64_t *piVar1;
    char in_DL;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar1 = *(int64_t **)(arg1 + 0x58);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)(arg1 + 0x20));
        *(undefined8 *)(arg1 + 0x58) = 0;
    }
    if (in_DL != '\0') {
        fcn.180459c3c(arg1, 0x70);
    }
    return;
}

// ============================================================
// Function: FUN_18017eb40
// Address: 0x18017eb40
// Size: 94 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_70h
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18017eb40(int64_t arg1)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    uint32_t *puVar6;
    uint32_t uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    uint32_t uVar10;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    piVar4 = *(int64_t **)(iVar3 + 0xb0);
    iVar5 = *(int64_t *)(iVar3 + 0x68);
    if (piVar4 != (int64_t *)0x0) {
        (**(code **)(*piVar4 + 0x10))(piVar4, iVar3 + 8);
    }
    if (iVar5 != 0) {
        iVar3 = *(int64_t *)(arg1 + 8);
        iVar5 = *(int64_t *)(iVar3 + 0x68);
        if (iVar5 != 0) {
            *(int32_t *)(iVar5 + 0x14) = *(int32_t *)(iVar5 + 0x14) + 1;
            if ((*(uint32_t *)(iVar5 + 0x10) == 0xffffffff) ||
               (*(uint32_t *)(iVar5 + 0x14) <= *(uint32_t *)(iVar5 + 0x10))) {
                puVar6 = *(uint32_t **)(iVar3 + 0x68);
                uVar10 = puVar6[3];
                if (uVar10 == 0) {
                    uVar10 = *puVar6;
                } else if (uVar10 == 1) {
                    uVar10 = puVar6[2] + *puVar6;
                } else {
                    uVar10 = puVar6[2] * uVar10;
                }
                if (uVar10 <= *puVar6) {
                    uVar10 = *puVar6;
                }
                uVar7 = puVar6[1];
                if (uVar10 < puVar6[1]) {
                    uVar7 = uVar10;
                }
                puVar6[2] = uVar7;
                iVar5 = *(int64_t *)(iVar3 + 0x68);
                iVar8 = func_0x00018045b9a8(0x1804a7020, 0x5c);
                uVar1 = *(undefined4 *)(iVar5 + 8);
                uVar2 = *(undefined4 *)(iVar5 + 0x14);
                uVar9 = func_0x0001801723e0();
                func_0x000180172b00(uVar9, 2, 0x1804a7278, uVar2, uVar1, iVar8 + 1, 0xac, 0x1804a7230);
                var_58h = 0x1804a73c8;
                var_20h = (int64_t)&var_58h;
                var_50h = iVar3;
                func_0x0001801805c0(*(undefined8 *)(iVar3 + 0x138), uVar7, &var_58h);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18017eb9e
// Address: 0x18017eb9e
// Size: 224 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_70h
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18017eb40(int64_t arg1)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    uint32_t *puVar6;
    uint32_t uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    uint32_t uVar10;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    piVar4 = *(int64_t **)(iVar3 + 0xb0);
    iVar5 = *(int64_t *)(iVar3 + 0x68);
    if (piVar4 != (int64_t *)0x0) {
        (**(code **)(*piVar4 + 0x10))(piVar4, iVar3 + 8);
    }
    if (iVar5 != 0) {
        iVar3 = *(int64_t *)(arg1 + 8);
        iVar5 = *(int64_t *)(iVar3 + 0x68);
        if (iVar5 != 0) {
            *(int32_t *)(iVar5 + 0x14) = *(int32_t *)(iVar5 + 0x14) + 1;
            if ((*(uint32_t *)(iVar5 + 0x10) == 0xffffffff) ||
               (*(uint32_t *)(iVar5 + 0x14) <= *(uint32_t *)(iVar5 + 0x10))) {
                puVar6 = *(uint32_t **)(iVar3 + 0x68);
                uVar10 = puVar6[3];
                if (uVar10 == 0) {
                    uVar10 = *puVar6;
                } else if (uVar10 == 1) {
                    uVar10 = puVar6[2] + *puVar6;
                } else {
                    uVar10 = puVar6[2] * uVar10;
                }
                if (uVar10 <= *puVar6) {
                    uVar10 = *puVar6;
                }
                uVar7 = puVar6[1];
                if (uVar10 < puVar6[1]) {
                    uVar7 = uVar10;
                }
                puVar6[2] = uVar7;
                iVar5 = *(int64_t *)(iVar3 + 0x68);
                iVar8 = func_0x00018045b9a8(0x1804a7020, 0x5c);
                uVar1 = *(undefined4 *)(iVar5 + 8);
                uVar2 = *(undefined4 *)(iVar5 + 0x14);
                uVar9 = func_0x0001801723e0();
                func_0x000180172b00(uVar9, 2, 0x1804a7278, uVar2, uVar1, iVar8 + 1, 0xac, 0x1804a7230);
                var_58h = 0x1804a73c8;
                var_20h = (int64_t)&var_58h;
                var_50h = iVar3;
                func_0x0001801805c0(*(undefined8 *)(iVar3 + 0x138), uVar7, &var_58h);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18017ec7e
// Address: 0x18017ec7e
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_70h
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18017eb40(int64_t arg1)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    uint32_t *puVar6;
    uint32_t uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    uint32_t uVar10;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    piVar4 = *(int64_t **)(iVar3 + 0xb0);
    iVar5 = *(int64_t *)(iVar3 + 0x68);
    if (piVar4 != (int64_t *)0x0) {
        (**(code **)(*piVar4 + 0x10))(piVar4, iVar3 + 8);
    }
    if (iVar5 != 0) {
        iVar3 = *(int64_t *)(arg1 + 8);
        iVar5 = *(int64_t *)(iVar3 + 0x68);
        if (iVar5 != 0) {
            *(int32_t *)(iVar5 + 0x14) = *(int32_t *)(iVar5 + 0x14) + 1;
            if ((*(uint32_t *)(iVar5 + 0x10) == 0xffffffff) ||
               (*(uint32_t *)(iVar5 + 0x14) <= *(uint32_t *)(iVar5 + 0x10))) {
                puVar6 = *(uint32_t **)(iVar3 + 0x68);
                uVar10 = puVar6[3];
                if (uVar10 == 0) {
                    uVar10 = *puVar6;
                } else if (uVar10 == 1) {
                    uVar10 = puVar6[2] + *puVar6;
                } else {
                    uVar10 = puVar6[2] * uVar10;
                }
                if (uVar10 <= *puVar6) {
                    uVar10 = *puVar6;
                }
                uVar7 = puVar6[1];
                if (uVar10 < puVar6[1]) {
                    uVar7 = uVar10;
                }
                puVar6[2] = uVar7;
                iVar5 = *(int64_t *)(iVar3 + 0x68);
                iVar8 = func_0x00018045b9a8(0x1804a7020, 0x5c);
                uVar1 = *(undefined4 *)(iVar5 + 8);
                uVar2 = *(undefined4 *)(iVar5 + 0x14);
                uVar9 = func_0x0001801723e0();
                func_0x000180172b00(uVar9, 2, 0x1804a7278, uVar2, uVar1, iVar8 + 1, 0xac, 0x1804a7230);
                var_58h = 0x1804a73c8;
                var_20h = (int64_t)&var_58h;
                var_50h = iVar3;
                func_0x0001801805c0(*(undefined8 *)(iVar3 + 0x138), uVar7, &var_58h);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18017eca0
// Address: 0x18017eca0
// Size: 242 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int64_t * fcn.18017eca0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_40h)
{
    uint32_t uVar1;
    bool bVar2;
    char cVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t unaff_RBX;
    int32_t iVar10;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_48;
    undefined8 uStack_40;
    undefined8 uStack_38;
    undefined8 uStack_30;
    int64_t *piStack_28;
    uint64_t uStack_20;
    int64_t var_18h;
    undefined8 uStack_10;
    
    iVar10 = *(int32_t *)arg2;
    piVar6 = *(int64_t **)(arg1 + 0x10);
    *(int32_t *)(*piVar6 + 0x17c) = iVar10;
    if ((iVar10 == 1) || (iVar10 == 2)) {
        piVar6 = (int64_t *)(*(int64_t **)(arg1 + 8))[0x4a];
        if (piVar6 == (int64_t *)0x0) {
            return *(int64_t **)(arg1 + 8);
        }
    // WARNING: Could not recover jumptable at 0x00018017ed88. Too many branches
    // WARNING: Treating indirect jump as call
        piVar6 = (int64_t *)(**(code **)(*piVar6 + 0x10))(piVar6, arg3);
        return piVar6;
    }
    if (iVar10 != 8) {
        if (iVar10 == 9) {
            var_18h._0_1_ = 1;
            uStack_40 = 0x18017ed22;
            piVar6 = (int64_t *)fcn.1801899b0(var_18h);
            return piVar6;
        }
        if (iVar10 != 10) {
            return piVar6;
        }
        piVar6 = *(int64_t **)(arg1 + 8);
        *(undefined4 *)((int64_t)piVar6 + 0x2a4) = 0;
        return piVar6;
    }
    var_18h._0_1_ = 1;
    uStack_40 = 0x18017ed52;
    fcn.1801899b0(var_18h);
    iVar8 = **(int64_t **)(arg1 + 0x10);
    iVar10 = *(int32_t *)(iVar8 + 0x178);
    if ((*(int64_t *)(iVar8 + 8) == 0) || (2 < *(int32_t *)(iVar8 + 0x20))) {
code_r0x00018017f6d3:
        bVar2 = true;
    } else {
        iVar5 = *(int32_t *)(iVar8 + 0x14);
        uStack_30 = 0x18017f6b9;
        iVar4 = fcn.180173bc0(*(undefined8 *)(iVar8 + 8));
        if (iVar5 != iVar4) goto code_r0x00018017f6d3;
        uStack_30 = 0x18017f6cb;
        cVar3 = fcn.180173be0(*(undefined8 *)(iVar8 + 8));
        if (cVar3 == '\0') goto code_r0x00018017f6d3;
        bVar2 = false;
    }
    if (bVar2) {
        return (int64_t *)0xffffffff;
    }
    LOCK();
    *(int32_t *)(iVar8 + 0x20) = 4;
    UNLOCK();
    if (*(int64_t *)(iVar8 + 0xe0) == 0) {
        uStack_30 = 0x18017f70b;
        iVar7 = fcn.1801739f0(*(undefined8 *)(iVar8 + 8));
        if (iVar7 == 0x18017fa80) {
            uStack_30 = 0x18017f722;
            fcn.1801742f0(*(undefined8 *)(iVar8 + 8), 0);
        }
    }
    piVar6 = *(int64_t **)(iVar8 + 8);
    if (iVar10 != 1) {
        if ((*(uint32_t *)((int64_t)piVar6 + 0x3c) & 0x20) == 0) {
            if ((*(uint32_t *)((int64_t)piVar6 + 0x3c) & 1) == 0) {
                iVar10 = *(int32_t *)(*piVar6 + 0x34);
                uStack_40 = 0x180183738;
                iVar5 = (*(code *)0x699ddc)();
                if (iVar5 != iVar10) goto code_r0x000180181d00;
            }
            uStack_40 = 0x18018375b;
            (*(code *)0x699f1c)(piVar6 + 0x19);
            uVar1 = *(uint32_t *)((int64_t)piVar6 + 0x3c);
            if ((uVar1 & 0x20) != 0) {
                uStack_40 = 0x18018376f;
                (*(code *)0x699f34)(piVar6 + 0x19);
                return (int64_t *)0x0;
            }
            if (((piVar6[0x16] != 0) && (*(int32_t *)((int64_t)piVar6 + 0x4c) == 0)) && ((uVar1 & 0x2001) == 0)) {
                *(uint32_t *)((int64_t)piVar6 + 0x3c) = uVar1 | 0x2000;
                uStack_40 = 0x1801837b3;
                (*(code *)0x699f34)(piVar6 + 0x19);
                uStack_40 = 0x1801837c4;
                iVar8 = fcn.18045b9a8(0x1804a77e0, 0x5c);
                uStack_40 = 0x1801837cd;
                uVar9 = fcn.1801723e0(unaff_retaddr);
                uStack_10 = 0x1804a7af8;
                var_18h._0_4_ = 0x25f;
                uStack_40 = 0x1801837f8;
                fcn.180172b00(uVar9, 3, 0x1804a7b08, iVar8 + 1);
                iVar10 = 60000;
                if (*(int32_t *)((int64_t)piVar6 + 0x124) != 0) {
                    iVar10 = *(int32_t *)((int64_t)piVar6 + 0x124);
                }
                uStack_40 = 0x18018381f;
                iVar8 = fcn.180182c00(*piVar6, 0x1801833d0, iVar10, 1);
                piVar6[0x29] = iVar8;
                *(int64_t **)(iVar8 + 0x28) = piVar6;
                return (int64_t *)0x0;
            }
            *(uint32_t *)((int64_t)piVar6 + 0x3c) = uVar1 | 0x20;
            uStack_40 = 0x18018384a;
            (*(code *)0x699f34)(piVar6 + 0x19);
            uStack_40 = 0x180183852;
            fcn.180173810(unaff_RBX);
            uStack_40 = 0x18018385a;
            fcn.180173710(piVar6);
            uStack_40 = 0x180183862;
            fcn.1801736e0(piVar6);
            uStack_40 = 0x18018386a;
            fcn.1801737b0(piVar6);
            uStack_40 = 0x180183872;
            fcn.1801737e0(piVar6);
            uStack_40 = 0x18018387a;
            fcn.180173780(piVar6);
            uStack_40 = 0x180183882;
            fcn.180173740(piVar6);
            uStack_40 = 0x18018388a;
            fcn.180173690(piVar6);
            if (piVar6[0x30] != 0) {
                uStack_40 = 0x18018389d;
                fcn.180183340();
                piVar6[0x30] = 0;
            }
            if ((piVar6[0x31] != 0) && ((*(uint32_t *)((int64_t)piVar6 + 0x3c) & 0x8000) != 0)) {
                uStack_40 = 0x1801838be;
                fcn.180183170();
                piVar6[0x31] = 0;
            }
            if (piVar6[0x32] != 0) {
                uStack_40 = 0x1801838d6;
                fcn.180460d90();
                piVar6[0x32] = 0;
            }
            if ((*(uint32_t *)(piVar6 + 8) & 0xfffff00) != 0) {
                uStack_40 = 0x1801838f1;
                (*(code *)0x8000000000000003)((int64_t)*(int32_t *)(piVar6 + 9));
                return (int64_t *)0x0;
            }
            if (*(uint32_t *)(piVar6 + 8) == 0x20) {
                uStack_40 = 0x18018390b;
                fcn.180474154(*(undefined4 *)(piVar6 + 9));
            }
        }
        return (int64_t *)0x0;
    }
code_r0x000180181d00:
    uStack_48 = 0;
    uStack_40 = 0;
    uStack_38 = 0;
    _var_18h = ZEXT816(0);
    uStack_30 = 0x180181d50;
    uStack_20 = (uint64_t)*(uint32_t *)((int64_t)piVar6 + 0x44);
    piStack_28 = piVar6;
    fcn.1801823b0(*piVar6, &uStack_48);
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_18017edb0
// Address: 0x18017edb0
// Size: 20 bytes
// ============================================================
undefined8 fcn.18017edb0(int64_t arg1)
{
    fcn.180180a60(*(undefined8 *)(arg1 + 8));
    return 0;
}

// ============================================================
// Function: FUN_18017edd0
// Address: 0x18017edd0
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18017edd0(int64_t arg1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    char cVar4;
    int32_t iVar5;
    int64_t var_10h;
    int64_t var_8h;
    
    if ((*(int64_t *)(*(int64_t *)(arg1 + 8) + 0x70) != 0) &&
       (*(int64_t *)(*(int64_t *)(*(int64_t *)(arg1 + 8) + 8) + 8) != 0)) {
        func_0x0001801741e0();
    }
    iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 8) + 8);
    if ((*(int64_t *)(iVar2 + 8) != 0) && (*(int32_t *)(iVar2 + 0x20) < 3)) {
        iVar1 = *(int32_t *)(iVar2 + 0x14);
        iVar5 = fcn.180173bc0(*(undefined8 *)(iVar2 + 8));
        if (iVar1 == iVar5) {
            cVar4 = fcn.180173be0(*(undefined8 *)(iVar2 + 8));
            if (cVar4 != '\0') {
                func_0x000180183b00(*(undefined8 *)(iVar2 + 8));
            }
        }
    }
    piVar3 = *(int64_t **)(*(int64_t *)(arg1 + 8) + 0xb0);
    if (piVar3 != (int64_t *)0x0) {
        (**(code **)(*piVar3 + 0x10))(piVar3, *(int64_t *)(arg1 + 8) + 8);
    }
    iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 8) + 0x68);
    if (iVar2 != 0) {
        *(undefined4 *)(iVar2 + 8) = 0;
        *(undefined4 *)(iVar2 + 0x14) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18017edd8
// Address: 0x18017edd8
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18017edd0(int64_t arg1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    char cVar4;
    int32_t iVar5;
    int64_t var_10h;
    int64_t var_8h;
    
    if ((*(int64_t *)(*(int64_t *)(arg1 + 8) + 0x70) != 0) &&
       (*(int64_t *)(*(int64_t *)(*(int64_t *)(arg1 + 8) + 8) + 8) != 0)) {
        func_0x0001801741e0();
    }
    iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 8) + 8);
    if ((*(int64_t *)(iVar2 + 8) != 0) && (*(int32_t *)(iVar2 + 0x20) < 3)) {
        iVar1 = *(int32_t *)(iVar2 + 0x14);
        iVar5 = fcn.180173bc0(*(undefined8 *)(iVar2 + 8));
        if (iVar1 == iVar5) {
            cVar4 = fcn.180173be0(*(undefined8 *)(iVar2 + 8));
            if (cVar4 != '\0') {
                func_0x000180183b00(*(undefined8 *)(iVar2 + 8));
            }
        }
    }
    piVar3 = *(int64_t **)(*(int64_t *)(arg1 + 8) + 0xb0);
    if (piVar3 != (int64_t *)0x0) {
        (**(code **)(*piVar3 + 0x10))(piVar3, *(int64_t *)(arg1 + 8) + 8);
    }
    iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 8) + 0x68);
    if (iVar2 != 0) {
        *(undefined4 *)(iVar2 + 8) = 0;
        *(undefined4 *)(iVar2 + 0x14) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18017ede0
// Address: 0x18017ede0
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18017edd0(int64_t arg1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    char cVar4;
    int32_t iVar5;
    int64_t var_10h;
    int64_t var_8h;
    
    if ((*(int64_t *)(*(int64_t *)(arg1 + 8) + 0x70) != 0) &&
       (*(int64_t *)(*(int64_t *)(*(int64_t *)(arg1 + 8) + 8) + 8) != 0)) {
        func_0x0001801741e0();
    }
    iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 8) + 8);
    if ((*(int64_t *)(iVar2 + 8) != 0) && (*(int32_t *)(iVar2 + 0x20) < 3)) {
        iVar1 = *(int32_t *)(iVar2 + 0x14);
        iVar5 = fcn.180173bc0(*(undefined8 *)(iVar2 + 8));
        if (iVar1 == iVar5) {
            cVar4 = fcn.180173be0(*(undefined8 *)(iVar2 + 8));
            if (cVar4 != '\0') {
                func_0x000180183b00(*(undefined8 *)(iVar2 + 8));
            }
        }
    }
    piVar3 = *(int64_t **)(*(int64_t *)(arg1 + 8) + 0xb0);
    if (piVar3 != (int64_t *)0x0) {
        (**(code **)(*piVar3 + 0x10))(piVar3, *(int64_t *)(arg1 + 8) + 8);
    }
    iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 8) + 0x68);
    if (iVar2 != 0) {
        *(undefined4 *)(iVar2 + 8) = 0;
        *(undefined4 *)(iVar2 + 0x14) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18017ee1c
// Address: 0x18017ee1c
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18017edd0(int64_t arg1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    char cVar4;
    int32_t iVar5;
    int64_t var_10h;
    int64_t var_8h;
    
    if ((*(int64_t *)(*(int64_t *)(arg1 + 8) + 0x70) != 0) &&
       (*(int64_t *)(*(int64_t *)(*(int64_t *)(arg1 + 8) + 8) + 8) != 0)) {
        func_0x0001801741e0();
    }
    iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 8) + 8);
    if ((*(int64_t *)(iVar2 + 8) != 0) && (*(int32_t *)(iVar2 + 0x20) < 3)) {
        iVar1 = *(int32_t *)(iVar2 + 0x14);
        iVar5 = fcn.180173bc0(*(undefined8 *)(iVar2 + 8));
        if (iVar1 == iVar5) {
            cVar4 = fcn.180173be0(*(undefined8 *)(iVar2 + 8));
            if (cVar4 != '\0') {
                func_0x000180183b00(*(undefined8 *)(iVar2 + 8));
            }
        }
    }
    piVar3 = *(int64_t **)(*(int64_t *)(arg1 + 8) + 0xb0);
    if (piVar3 != (int64_t *)0x0) {
        (**(code **)(*piVar3 + 0x10))(piVar3, *(int64_t *)(arg1 + 8) + 8);
    }
    iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 8) + 0x68);
    if (iVar2 != 0) {
        *(undefined4 *)(iVar2 + 8) = 0;
        *(undefined4 *)(iVar2 + 0x14) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18017ee32
// Address: 0x18017ee32
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18017edd0(int64_t arg1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    char cVar4;
    int32_t iVar5;
    int64_t var_10h;
    int64_t var_8h;
    
    if ((*(int64_t *)(*(int64_t *)(arg1 + 8) + 0x70) != 0) &&
       (*(int64_t *)(*(int64_t *)(*(int64_t *)(arg1 + 8) + 8) + 8) != 0)) {
        func_0x0001801741e0();
    }
    iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 8) + 8);
    if ((*(int64_t *)(iVar2 + 8) != 0) && (*(int32_t *)(iVar2 + 0x20) < 3)) {
        iVar1 = *(int32_t *)(iVar2 + 0x14);
        iVar5 = fcn.180173bc0(*(undefined8 *)(iVar2 + 8));
        if (iVar1 == iVar5) {
            cVar4 = fcn.180173be0(*(undefined8 *)(iVar2 + 8));
            if (cVar4 != '\0') {
                func_0x000180183b00(*(undefined8 *)(iVar2 + 8));
            }
        }
    }
    piVar3 = *(int64_t **)(*(int64_t *)(arg1 + 8) + 0xb0);
    if (piVar3 != (int64_t *)0x0) {
        (**(code **)(*piVar3 + 0x10))(piVar3, *(int64_t *)(arg1 + 8) + 8);
    }
    iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 8) + 0x68);
    if (iVar2 != 0) {
        *(undefined4 *)(iVar2 + 8) = 0;
        *(undefined4 *)(iVar2 + 0x14) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18017ee5d
// Address: 0x18017ee5d
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18017edd0(int64_t arg1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    char cVar4;
    int32_t iVar5;
    int64_t var_10h;
    int64_t var_8h;
    
    if ((*(int64_t *)(*(int64_t *)(arg1 + 8) + 0x70) != 0) &&
       (*(int64_t *)(*(int64_t *)(*(int64_t *)(arg1 + 8) + 8) + 8) != 0)) {
        func_0x0001801741e0();
    }
    iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 8) + 8);
    if ((*(int64_t *)(iVar2 + 8) != 0) && (*(int32_t *)(iVar2 + 0x20) < 3)) {
        iVar1 = *(int32_t *)(iVar2 + 0x14);
        iVar5 = fcn.180173bc0(*(undefined8 *)(iVar2 + 8));
        if (iVar1 == iVar5) {
            cVar4 = fcn.180173be0(*(undefined8 *)(iVar2 + 8));
            if (cVar4 != '\0') {
                func_0x000180183b00(*(undefined8 *)(iVar2 + 8));
            }
        }
    }
    piVar3 = *(int64_t **)(*(int64_t *)(arg1 + 8) + 0xb0);
    if (piVar3 != (int64_t *)0x0) {
        (**(code **)(*piVar3 + 0x10))(piVar3, *(int64_t *)(arg1 + 8) + 8);
    }
    iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 8) + 0x68);
    if (iVar2 != 0) {
        *(undefined4 *)(iVar2 + 8) = 0;
        *(undefined4 *)(iVar2 + 0x14) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18017ee79
// Address: 0x18017ee79
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18017edd0(int64_t arg1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    char cVar4;
    int32_t iVar5;
    int64_t var_10h;
    int64_t var_8h;
    
    if ((*(int64_t *)(*(int64_t *)(arg1 + 8) + 0x70) != 0) &&
       (*(int64_t *)(*(int64_t *)(*(int64_t *)(arg1 + 8) + 8) + 8) != 0)) {
        func_0x0001801741e0();
    }
    iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 8) + 8);
    if ((*(int64_t *)(iVar2 + 8) != 0) && (*(int32_t *)(iVar2 + 0x20) < 3)) {
        iVar1 = *(int32_t *)(iVar2 + 0x14);
        iVar5 = fcn.180173bc0(*(undefined8 *)(iVar2 + 8));
        if (iVar1 == iVar5) {
            cVar4 = fcn.180173be0(*(undefined8 *)(iVar2 + 8));
            if (cVar4 != '\0') {
                func_0x000180183b00(*(undefined8 *)(iVar2 + 8));
            }
        }
    }
    piVar3 = *(int64_t **)(*(int64_t *)(arg1 + 8) + 0xb0);
    if (piVar3 != (int64_t *)0x0) {
        (**(code **)(*piVar3 + 0x10))(piVar3, *(int64_t *)(arg1 + 8) + 8);
    }
    iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 8) + 0x68);
    if (iVar2 != 0) {
        *(undefined4 *)(iVar2 + 8) = 0;
        *(undefined4 *)(iVar2 + 0x14) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18017ee90
// Address: 0x18017ee90
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18017ee90(int64_t arg1)
{
    int64_t iVar1;
    int64_t unaff_RBX;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t in_stack_00000038;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    if (*(int64_t *)(iVar1 + 8) != 0) {
        if (*(int64_t *)(iVar1 + 0x68) != 0) {
            fcn.180180fe0();
            *(undefined8 *)(iVar1 + 0x68) = 0;
        }
        fcn.18017f680(unaff_retaddr, unaff_RBX, in_stack_00000038);
    }
    return;
}

// ============================================================
// Function: FUN_18017eef0
// Address: 0x18017eef0
// Size: 51 bytes
// ============================================================
void fcn.18017eef0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(*(int64_t *)(arg1 + 8) + 0x130);
    if (piVar1 != (int64_t *)0x0) {
        var_8h = *(int64_t *)arg2;
        (**(code **)(*piVar1 + 0x10))(piVar1, *(int64_t *)(arg1 + 8) + 8, &var_8h);
    }
    return;
}

// ============================================================
// Function: FUN_18017ef30
// Address: 0x18017ef30
// Size: 51 bytes
// ============================================================
void fcn.18017ef30(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(*(int64_t *)(arg1 + 8) + 0xf0);
    if (piVar1 != (int64_t *)0x0) {
        var_8h = *(int64_t *)arg2;
        (**(code **)(*piVar1 + 0x10))(piVar1, *(int64_t *)(arg1 + 8) + 8, &var_8h);
    }
    return;
}

// ============================================================
// Function: FUN_18017ef70
// Address: 0x18017ef70
// Size: 48 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

uint64_t fcn.18017ef70(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    bool bVar3;
    char cVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint64_t in_RAX;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t unaff_RBX;
    uint64_t uVar12;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_48;
    undefined8 uStack_40;
    undefined8 uStack_38;
    undefined8 uStack_30;
    int64_t *piStack_28;
    uint64_t uStack_20;
    int64_t var_18h;
    undefined8 uStack_10;
    
    iVar11 = *(int64_t *)(arg1 + 8);
    iVar9 = *(int64_t *)(iVar11 + 8);
    if (iVar9 == 0) {
        return in_RAX;
    }
    iVar7 = *(int32_t *)(iVar11 + 0x2a4);
    *(int32_t *)(iVar11 + 0x2a4) = iVar7 + 1;
    if (iVar7 != 3) {
        uStack_30 = 0x180189c49;
        iVar7 = func_0x000180456008(iVar9 + 0x1a0);
        if (iVar7 != 0) {
            uStack_30 = 0x180189d43;
            func_0x0001804542e8(5);
            pcVar2 = (code *)swi(3);
            uVar12 = (*pcVar2)();
            return uVar12;
        }
        if (*(int32_t *)(iVar9 + 0x1ec) == 0x7fffffff) {
            *(undefined4 *)(iVar9 + 0x1ec) = 0x7ffffffe;
            uStack_30 = 0x180189d38;
            func_0x0001804542e8(6);
            pcVar2 = (code *)swi(3);
            uVar12 = (*pcVar2)();
            return uVar12;
        }
        if (*(int32_t *)(iVar9 + 0x178) == 0) {
            if ((*(int64_t *)(iVar9 + 8) != 0) && (*(int32_t *)(iVar9 + 0x20) < 3)) {
                iVar7 = *(int32_t *)(iVar9 + 0x14);
                uStack_30 = 0x180189c91;
                iVar6 = fcn.180173bc0(*(undefined8 *)(iVar9 + 8));
                if (iVar7 == iVar6) {
                    uStack_30 = 0x180189c9e;
                    cVar4 = fcn.180173be0(*(undefined8 *)(iVar9 + 8));
                    if (cVar4 != '\0') {
                        uStack_30 = 0x180189cb8;
                        uVar8 = func_0x000180183bc0(*(undefined8 *)(iVar9 + 8), 0x1804a8748, 6);
                        uVar12 = (uint64_t)uVar8;
                        goto code_r0x000180189d06;
                    }
                }
            }
        } else if ((*(int64_t *)(iVar9 + 8) != 0) && (*(int32_t *)(iVar9 + 0x20) < 3)) {
            iVar7 = *(int32_t *)(iVar9 + 0x14);
            uStack_30 = 0x180189cd6;
            iVar6 = fcn.180173bc0(*(undefined8 *)(iVar9 + 8));
            if (iVar7 == iVar6) {
                uStack_30 = 0x180189ce3;
                cVar4 = fcn.180173be0(*(undefined8 *)(iVar9 + 8));
                if (cVar4 != '\0') {
                    uStack_30 = 0x180189cfd;
                    uVar8 = func_0x000180183bc0(*(undefined8 *)(iVar9 + 8), 0x1804a8750, 2);
                    uVar12 = (uint64_t)uVar8;
                    goto code_r0x000180189d06;
                }
            }
        }
        uVar12 = 0xffffffff;
code_r0x000180189d06:
        uStack_30 = 0x180189d12;
        func_0x000180456010(iVar9 + 0x1a0);
        return uVar12;
    }
    uStack_40 = 0x18017efb1;
    iVar9 = fcn.18045b9a8(0x1804a6bd0, 0x5c);
    uStack_40 = 0x18017efba;
    uVar10 = fcn.1801723e0(unaff_retaddr);
    uStack_10 = 0x1804a6b40;
    var_18h._0_4_ = 0xb0;
    uStack_40 = 0x18017efe5;
    fcn.180172b00(uVar10, 4, 0x1804a6c48, iVar9 + 1);
    iVar11 = *(int64_t *)(iVar11 + 8);
    iVar7 = *(int32_t *)(iVar11 + 0x178);
    if ((*(int64_t *)(iVar11 + 8) == 0) || (2 < *(int32_t *)(iVar11 + 0x20))) {
code_r0x00018017f6d3:
        bVar3 = true;
    } else {
        iVar6 = *(int32_t *)(iVar11 + 0x14);
        uStack_30 = 0x18017f6b9;
        iVar5 = fcn.180173bc0(*(undefined8 *)(iVar11 + 8));
        if (iVar6 != iVar5) goto code_r0x00018017f6d3;
        uStack_30 = 0x18017f6cb;
        cVar4 = fcn.180173be0(*(undefined8 *)(iVar11 + 8));
        if (cVar4 == '\0') goto code_r0x00018017f6d3;
        bVar3 = false;
    }
    if (bVar3) {
        return 0xffffffff;
    }
    LOCK();
    *(int32_t *)(iVar11 + 0x20) = 4;
    UNLOCK();
    if (*(int64_t *)(iVar11 + 0xe0) == 0) {
        uStack_30 = 0x18017f70b;
        iVar9 = fcn.1801739f0(*(undefined8 *)(iVar11 + 8));
        if (iVar9 == 0x18017fa80) {
            uStack_30 = 0x18017f722;
            fcn.1801742f0(*(undefined8 *)(iVar11 + 8), 0);
        }
    }
    piVar1 = *(int64_t **)(iVar11 + 8);
    if (iVar7 != 1) {
        if ((*(uint32_t *)((int64_t)piVar1 + 0x3c) & 0x20) == 0) {
            if ((*(uint32_t *)((int64_t)piVar1 + 0x3c) & 1) == 0) {
                iVar7 = *(int32_t *)(*piVar1 + 0x34);
                uStack_40 = 0x180183738;
                iVar6 = (*(code *)0x699ddc)();
                if (iVar6 != iVar7) goto code_r0x000180181d00;
            }
            uStack_40 = 0x18018375b;
            (*(code *)0x699f1c)(piVar1 + 0x19);
            uVar8 = *(uint32_t *)((int64_t)piVar1 + 0x3c);
            if ((uVar8 & 0x20) != 0) {
                uStack_40 = 0x18018376f;
                (*(code *)0x699f34)(piVar1 + 0x19);
                return 0;
            }
            if (((piVar1[0x16] != 0) && (*(int32_t *)((int64_t)piVar1 + 0x4c) == 0)) && ((uVar8 & 0x2001) == 0)) {
                *(uint32_t *)((int64_t)piVar1 + 0x3c) = uVar8 | 0x2000;
                uStack_40 = 0x1801837b3;
                (*(code *)0x699f34)(piVar1 + 0x19);
                uStack_40 = 0x1801837c4;
                iVar11 = fcn.18045b9a8(0x1804a77e0, 0x5c);
                uStack_40 = 0x1801837cd;
                uVar10 = fcn.1801723e0(unaff_retaddr);
                uStack_10 = 0x1804a7af8;
                var_18h._0_4_ = 0x25f;
                uStack_40 = 0x1801837f8;
                fcn.180172b00(uVar10, 3, 0x1804a7b08, iVar11 + 1);
                iVar7 = 60000;
                if (*(int32_t *)((int64_t)piVar1 + 0x124) != 0) {
                    iVar7 = *(int32_t *)((int64_t)piVar1 + 0x124);
                }
                uStack_40 = 0x18018381f;
                iVar11 = fcn.180182c00(*piVar1, 0x1801833d0, iVar7, 1);
                piVar1[0x29] = iVar11;
                *(int64_t **)(iVar11 + 0x28) = piVar1;
                return 0;
            }
            *(uint32_t *)((int64_t)piVar1 + 0x3c) = uVar8 | 0x20;
            uStack_40 = 0x18018384a;
            (*(code *)0x699f34)(piVar1 + 0x19);
            uStack_40 = 0x180183852;
            fcn.180173810(unaff_RBX);
            uStack_40 = 0x18018385a;
            fcn.180173710(piVar1);
            uStack_40 = 0x180183862;
            fcn.1801736e0(piVar1);
            uStack_40 = 0x18018386a;
            fcn.1801737b0(piVar1);
            uStack_40 = 0x180183872;
            fcn.1801737e0(piVar1);
            uStack_40 = 0x18018387a;
            fcn.180173780(piVar1);
            uStack_40 = 0x180183882;
            fcn.180173740(piVar1);
            uStack_40 = 0x18018388a;
            fcn.180173690(piVar1);
            if (piVar1[0x30] != 0) {
                uStack_40 = 0x18018389d;
                fcn.180183340();
                piVar1[0x30] = 0;
            }
            if ((piVar1[0x31] != 0) && ((*(uint32_t *)((int64_t)piVar1 + 0x3c) & 0x8000) != 0)) {
                uStack_40 = 0x1801838be;
                fcn.180183170();
                piVar1[0x31] = 0;
            }
            if (piVar1[0x32] != 0) {
                uStack_40 = 0x1801838d6;
                fcn.180460d90();
                piVar1[0x32] = 0;
            }
            if ((*(uint32_t *)(piVar1 + 8) & 0xfffff00) != 0) {
                uStack_40 = 0x1801838f1;
                (*(code *)0x8000000000000003)((int64_t)*(int32_t *)(piVar1 + 9));
                return 0;
            }
            if (*(uint32_t *)(piVar1 + 8) == 0x20) {
                uStack_40 = 0x18018390b;
                fcn.180474154(*(undefined4 *)(piVar1 + 9));
            }
        }
        return 0;
    }
code_r0x000180181d00:
    uStack_48 = 0;
    uStack_40 = 0;
    uStack_38 = 0;
    _var_18h = ZEXT816(0);
    uStack_30 = 0x180181d50;
    uStack_20 = (uint64_t)*(uint32_t *)((int64_t)piVar1 + 0x44);
    piStack_28 = piVar1;
    fcn.1801823b0(*piVar1, &uStack_48);
    return 0;
}

// ============================================================
// Function: FUN_18017efa0
// Address: 0x18017efa0
// Size: 98 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

uint64_t fcn.18017ef70(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    bool bVar3;
    char cVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint64_t in_RAX;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t unaff_RBX;
    uint64_t uVar12;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_48;
    undefined8 uStack_40;
    undefined8 uStack_38;
    undefined8 uStack_30;
    int64_t *piStack_28;
    uint64_t uStack_20;
    int64_t var_18h;
    undefined8 uStack_10;
    
    iVar11 = *(int64_t *)(arg1 + 8);
    iVar9 = *(int64_t *)(iVar11 + 8);
    if (iVar9 == 0) {
        return in_RAX;
    }
    iVar7 = *(int32_t *)(iVar11 + 0x2a4);
    *(int32_t *)(iVar11 + 0x2a4) = iVar7 + 1;
    if (iVar7 != 3) {
        uStack_30 = 0x180189c49;
        iVar7 = func_0x000180456008(iVar9 + 0x1a0);
        if (iVar7 != 0) {
            uStack_30 = 0x180189d43;
            func_0x0001804542e8(5);
            pcVar2 = (code *)swi(3);
            uVar12 = (*pcVar2)();
            return uVar12;
        }
        if (*(int32_t *)(iVar9 + 0x1ec) == 0x7fffffff) {
            *(undefined4 *)(iVar9 + 0x1ec) = 0x7ffffffe;
            uStack_30 = 0x180189d38;
            func_0x0001804542e8(6);
            pcVar2 = (code *)swi(3);
            uVar12 = (*pcVar2)();
            return uVar12;
        }
        if (*(int32_t *)(iVar9 + 0x178) == 0) {
            if ((*(int64_t *)(iVar9 + 8) != 0) && (*(int32_t *)(iVar9 + 0x20) < 3)) {
                iVar7 = *(int32_t *)(iVar9 + 0x14);
                uStack_30 = 0x180189c91;
                iVar6 = fcn.180173bc0(*(undefined8 *)(iVar9 + 8));
                if (iVar7 == iVar6) {
                    uStack_30 = 0x180189c9e;
                    cVar4 = fcn.180173be0(*(undefined8 *)(iVar9 + 8));
                    if (cVar4 != '\0') {
                        uStack_30 = 0x180189cb8;
                        uVar8 = func_0x000180183bc0(*(undefined8 *)(iVar9 + 8), 0x1804a8748, 6);
                        uVar12 = (uint64_t)uVar8;
                        goto code_r0x000180189d06;
                    }
                }
            }
        } else if ((*(int64_t *)(iVar9 + 8) != 0) && (*(int32_t *)(iVar9 + 0x20) < 3)) {
            iVar7 = *(int32_t *)(iVar9 + 0x14);
            uStack_30 = 0x180189cd6;
            iVar6 = fcn.180173bc0(*(undefined8 *)(iVar9 + 8));
            if (iVar7 == iVar6) {
                uStack_30 = 0x180189ce3;
                cVar4 = fcn.180173be0(*(undefined8 *)(iVar9 + 8));
                if (cVar4 != '\0') {
                    uStack_30 = 0x180189cfd;
                    uVar8 = func_0x000180183bc0(*(undefined8 *)(iVar9 + 8), 0x1804a8750, 2);
                    uVar12 = (uint64_t)uVar8;
                    goto code_r0x000180189d06;
                }
            }
        }
        uVar12 = 0xffffffff;
code_r0x000180189d06:
        uStack_30 = 0x180189d12;
        func_0x000180456010(iVar9 + 0x1a0);
        return uVar12;
    }
    uStack_40 = 0x18017efb1;
    iVar9 = fcn.18045b9a8(0x1804a6bd0, 0x5c);
    uStack_40 = 0x18017efba;
    uVar10 = fcn.1801723e0(unaff_retaddr);
    uStack_10 = 0x1804a6b40;
    var_18h._0_4_ = 0xb0;
    uStack_40 = 0x18017efe5;
    fcn.180172b00(uVar10, 4, 0x1804a6c48, iVar9 + 1);
    iVar11 = *(int64_t *)(iVar11 + 8);
    iVar7 = *(int32_t *)(iVar11 + 0x178);
    if ((*(int64_t *)(iVar11 + 8) == 0) || (2 < *(int32_t *)(iVar11 + 0x20))) {
code_r0x00018017f6d3:
        bVar3 = true;
    } else {
        iVar6 = *(int32_t *)(iVar11 + 0x14);
        uStack_30 = 0x18017f6b9;
        iVar5 = fcn.180173bc0(*(undefined8 *)(iVar11 + 8));
        if (iVar6 != iVar5) goto code_r0x00018017f6d3;
        uStack_30 = 0x18017f6cb;
        cVar4 = fcn.180173be0(*(undefined8 *)(iVar11 + 8));
        if (cVar4 == '\0') goto code_r0x00018017f6d3;
        bVar3 = false;
    }
    if (bVar3) {
        return 0xffffffff;
    }
    LOCK();
    *(int32_t *)(iVar11 + 0x20) = 4;
    UNLOCK();
    if (*(int64_t *)(iVar11 + 0xe0) == 0) {
        uStack_30 = 0x18017f70b;
        iVar9 = fcn.1801739f0(*(undefined8 *)(iVar11 + 8));
        if (iVar9 == 0x18017fa80) {
            uStack_30 = 0x18017f722;
            fcn.1801742f0(*(undefined8 *)(iVar11 + 8), 0);
        }
    }
    piVar1 = *(int64_t **)(iVar11 + 8);
    if (iVar7 != 1) {
        if ((*(uint32_t *)((int64_t)piVar1 + 0x3c) & 0x20) == 0) {
            if ((*(uint32_t *)((int64_t)piVar1 + 0x3c) & 1) == 0) {
                iVar7 = *(int32_t *)(*piVar1 + 0x34);
                uStack_40 = 0x180183738;
                iVar6 = (*(code *)0x699ddc)();
                if (iVar6 != iVar7) goto code_r0x000180181d00;
            }
            uStack_40 = 0x18018375b;
            (*(code *)0x699f1c)(piVar1 + 0x19);
            uVar8 = *(uint32_t *)((int64_t)piVar1 + 0x3c);
            if ((uVar8 & 0x20) != 0) {
                uStack_40 = 0x18018376f;
                (*(code *)0x699f34)(piVar1 + 0x19);
                return 0;
            }
            if (((piVar1[0x16] != 0) && (*(int32_t *)((int64_t)piVar1 + 0x4c) == 0)) && ((uVar8 & 0x2001) == 0)) {
                *(uint32_t *)((int64_t)piVar1 + 0x3c) = uVar8 | 0x2000;
                uStack_40 = 0x1801837b3;
                (*(code *)0x699f34)(piVar1 + 0x19);
                uStack_40 = 0x1801837c4;
                iVar11 = fcn.18045b9a8(0x1804a77e0, 0x5c);
                uStack_40 = 0x1801837cd;
                uVar10 = fcn.1801723e0(unaff_retaddr);
                uStack_10 = 0x1804a7af8;
                var_18h._0_4_ = 0x25f;
                uStack_40 = 0x1801837f8;
                fcn.180172b00(uVar10, 3, 0x1804a7b08, iVar11 + 1);
                iVar7 = 60000;
                if (*(int32_t *)((int64_t)piVar1 + 0x124) != 0) {
                    iVar7 = *(int32_t *)((int64_t)piVar1 + 0x124);
                }
                uStack_40 = 0x18018381f;
                iVar11 = fcn.180182c00(*piVar1, 0x1801833d0, iVar7, 1);
                piVar1[0x29] = iVar11;
                *(int64_t **)(iVar11 + 0x28) = piVar1;
                return 0;
            }
            *(uint32_t *)((int64_t)piVar1 + 0x3c) = uVar8 | 0x20;
            uStack_40 = 0x18018384a;
            (*(code *)0x699f34)(piVar1 + 0x19);
            uStack_40 = 0x180183852;
            fcn.180173810(unaff_RBX);
            uStack_40 = 0x18018385a;
            fcn.180173710(piVar1);
            uStack_40 = 0x180183862;
            fcn.1801736e0(piVar1);
            uStack_40 = 0x18018386a;
            fcn.1801737b0(piVar1);
            uStack_40 = 0x180183872;
            fcn.1801737e0(piVar1);
            uStack_40 = 0x18018387a;
            fcn.180173780(piVar1);
            uStack_40 = 0x180183882;
            fcn.180173740(piVar1);
            uStack_40 = 0x18018388a;
            fcn.180173690(piVar1);
            if (piVar1[0x30] != 0) {
                uStack_40 = 0x18018389d;
                fcn.180183340();
                piVar1[0x30] = 0;
            }
            if ((piVar1[0x31] != 0) && ((*(uint32_t *)((int64_t)piVar1 + 0x3c) & 0x8000) != 0)) {
                uStack_40 = 0x1801838be;
                fcn.180183170();
                piVar1[0x31] = 0;
            }
            if (piVar1[0x32] != 0) {
                uStack_40 = 0x1801838d6;
                fcn.180460d90();
                piVar1[0x32] = 0;
            }
            if ((*(uint32_t *)(piVar1 + 8) & 0xfffff00) != 0) {
                uStack_40 = 0x1801838f1;
                (*(code *)0x8000000000000003)((int64_t)*(int32_t *)(piVar1 + 9));
                return 0;
            }
            if (*(uint32_t *)(piVar1 + 8) == 0x20) {
                uStack_40 = 0x18018390b;
                fcn.180474154(*(undefined4 *)(piVar1 + 9));
            }
        }
        return 0;
    }
code_r0x000180181d00:
    uStack_48 = 0;
    uStack_40 = 0;
    uStack_38 = 0;
    _var_18h = ZEXT816(0);
    uStack_30 = 0x180181d50;
    uStack_20 = (uint64_t)*(uint32_t *)((int64_t)piVar1 + 0x44);
    piStack_28 = piVar1;
    fcn.1801823b0(*piVar1, &uStack_48);
    return 0;
}

// ============================================================
// Function: FUN_18017f002
// Address: 0x18017f002
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

uint64_t fcn.18017ef70(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    bool bVar3;
    char cVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint64_t in_RAX;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t unaff_RBX;
    uint64_t uVar12;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_48;
    undefined8 uStack_40;
    undefined8 uStack_38;
    undefined8 uStack_30;
    int64_t *piStack_28;
    uint64_t uStack_20;
    int64_t var_18h;
    undefined8 uStack_10;
    
    iVar11 = *(int64_t *)(arg1 + 8);
    iVar9 = *(int64_t *)(iVar11 + 8);
    if (iVar9 == 0) {
        return in_RAX;
    }
    iVar7 = *(int32_t *)(iVar11 + 0x2a4);
    *(int32_t *)(iVar11 + 0x2a4) = iVar7 + 1;
    if (iVar7 != 3) {
        uStack_30 = 0x180189c49;
        iVar7 = func_0x000180456008(iVar9 + 0x1a0);
        if (iVar7 != 0) {
            uStack_30 = 0x180189d43;
            func_0x0001804542e8(5);
            pcVar2 = (code *)swi(3);
            uVar12 = (*pcVar2)();
            return uVar12;
        }
        if (*(int32_t *)(iVar9 + 0x1ec) == 0x7fffffff) {
            *(undefined4 *)(iVar9 + 0x1ec) = 0x7ffffffe;
            uStack_30 = 0x180189d38;
            func_0x0001804542e8(6);
            pcVar2 = (code *)swi(3);
            uVar12 = (*pcVar2)();
            return uVar12;
        }
        if (*(int32_t *)(iVar9 + 0x178) == 0) {
            if ((*(int64_t *)(iVar9 + 8) != 0) && (*(int32_t *)(iVar9 + 0x20) < 3)) {
                iVar7 = *(int32_t *)(iVar9 + 0x14);
                uStack_30 = 0x180189c91;
                iVar6 = fcn.180173bc0(*(undefined8 *)(iVar9 + 8));
                if (iVar7 == iVar6) {
                    uStack_30 = 0x180189c9e;
                    cVar4 = fcn.180173be0(*(undefined8 *)(iVar9 + 8));
                    if (cVar4 != '\0') {
                        uStack_30 = 0x180189cb8;
                        uVar8 = func_0x000180183bc0(*(undefined8 *)(iVar9 + 8), 0x1804a8748, 6);
                        uVar12 = (uint64_t)uVar8;
                        goto code_r0x000180189d06;
                    }
                }
            }
        } else if ((*(int64_t *)(iVar9 + 8) != 0) && (*(int32_t *)(iVar9 + 0x20) < 3)) {
            iVar7 = *(int32_t *)(iVar9 + 0x14);
            uStack_30 = 0x180189cd6;
            iVar6 = fcn.180173bc0(*(undefined8 *)(iVar9 + 8));
            if (iVar7 == iVar6) {
                uStack_30 = 0x180189ce3;
                cVar4 = fcn.180173be0(*(undefined8 *)(iVar9 + 8));
                if (cVar4 != '\0') {
                    uStack_30 = 0x180189cfd;
                    uVar8 = func_0x000180183bc0(*(undefined8 *)(iVar9 + 8), 0x1804a8750, 2);
                    uVar12 = (uint64_t)uVar8;
                    goto code_r0x000180189d06;
                }
            }
        }
        uVar12 = 0xffffffff;
code_r0x000180189d06:
        uStack_30 = 0x180189d12;
        func_0x000180456010(iVar9 + 0x1a0);
        return uVar12;
    }
    uStack_40 = 0x18017efb1;
    iVar9 = fcn.18045b9a8(0x1804a6bd0, 0x5c);
    uStack_40 = 0x18017efba;
    uVar10 = fcn.1801723e0(unaff_retaddr);
    uStack_10 = 0x1804a6b40;
    var_18h._0_4_ = 0xb0;
    uStack_40 = 0x18017efe5;
    fcn.180172b00(uVar10, 4, 0x1804a6c48, iVar9 + 1);
    iVar11 = *(int64_t *)(iVar11 + 8);
    iVar7 = *(int32_t *)(iVar11 + 0x178);
    if ((*(int64_t *)(iVar11 + 8) == 0) || (2 < *(int32_t *)(iVar11 + 0x20))) {
code_r0x00018017f6d3:
        bVar3 = true;
    } else {
        iVar6 = *(int32_t *)(iVar11 + 0x14);
        uStack_30 = 0x18017f6b9;
        iVar5 = fcn.180173bc0(*(undefined8 *)(iVar11 + 8));
        if (iVar6 != iVar5) goto code_r0x00018017f6d3;
        uStack_30 = 0x18017f6cb;
        cVar4 = fcn.180173be0(*(undefined8 *)(iVar11 + 8));
        if (cVar4 == '\0') goto code_r0x00018017f6d3;
        bVar3 = false;
    }
    if (bVar3) {
        return 0xffffffff;
    }
    LOCK();
    *(int32_t *)(iVar11 + 0x20) = 4;
    UNLOCK();
    if (*(int64_t *)(iVar11 + 0xe0) == 0) {
        uStack_30 = 0x18017f70b;
        iVar9 = fcn.1801739f0(*(undefined8 *)(iVar11 + 8));
        if (iVar9 == 0x18017fa80) {
            uStack_30 = 0x18017f722;
            fcn.1801742f0(*(undefined8 *)(iVar11 + 8), 0);
        }
    }
    piVar1 = *(int64_t **)(iVar11 + 8);
    if (iVar7 != 1) {
        if ((*(uint32_t *)((int64_t)piVar1 + 0x3c) & 0x20) == 0) {
            if ((*(uint32_t *)((int64_t)piVar1 + 0x3c) & 1) == 0) {
                iVar7 = *(int32_t *)(*piVar1 + 0x34);
                uStack_40 = 0x180183738;
                iVar6 = (*(code *)0x699ddc)();
                if (iVar6 != iVar7) goto code_r0x000180181d00;
            }
            uStack_40 = 0x18018375b;
            (*(code *)0x699f1c)(piVar1 + 0x19);
            uVar8 = *(uint32_t *)((int64_t)piVar1 + 0x3c);
            if ((uVar8 & 0x20) != 0) {
                uStack_40 = 0x18018376f;
                (*(code *)0x699f34)(piVar1 + 0x19);
                return 0;
            }
            if (((piVar1[0x16] != 0) && (*(int32_t *)((int64_t)piVar1 + 0x4c) == 0)) && ((uVar8 & 0x2001) == 0)) {
                *(uint32_t *)((int64_t)piVar1 + 0x3c) = uVar8 | 0x2000;
                uStack_40 = 0x1801837b3;
                (*(code *)0x699f34)(piVar1 + 0x19);
                uStack_40 = 0x1801837c4;
                iVar11 = fcn.18045b9a8(0x1804a77e0, 0x5c);
                uStack_40 = 0x1801837cd;
                uVar10 = fcn.1801723e0(unaff_retaddr);
                uStack_10 = 0x1804a7af8;
                var_18h._0_4_ = 0x25f;
                uStack_40 = 0x1801837f8;
                fcn.180172b00(uVar10, 3, 0x1804a7b08, iVar11 + 1);
                iVar7 = 60000;
                if (*(int32_t *)((int64_t)piVar1 + 0x124) != 0) {
                    iVar7 = *(int32_t *)((int64_t)piVar1 + 0x124);
                }
                uStack_40 = 0x18018381f;
                iVar11 = fcn.180182c00(*piVar1, 0x1801833d0, iVar7, 1);
                piVar1[0x29] = iVar11;
                *(int64_t **)(iVar11 + 0x28) = piVar1;
                return 0;
            }
            *(uint32_t *)((int64_t)piVar1 + 0x3c) = uVar8 | 0x20;
            uStack_40 = 0x18018384a;
            (*(code *)0x699f34)(piVar1 + 0x19);
            uStack_40 = 0x180183852;
            fcn.180173810(unaff_RBX);
            uStack_40 = 0x18018385a;
            fcn.180173710(piVar1);
            uStack_40 = 0x180183862;
            fcn.1801736e0(piVar1);
            uStack_40 = 0x18018386a;
            fcn.1801737b0(piVar1);
            uStack_40 = 0x180183872;
            fcn.1801737e0(piVar1);
            uStack_40 = 0x18018387a;
            fcn.180173780(piVar1);
            uStack_40 = 0x180183882;
            fcn.180173740(piVar1);
            uStack_40 = 0x18018388a;
            fcn.180173690(piVar1);
            if (piVar1[0x30] != 0) {
                uStack_40 = 0x18018389d;
                fcn.180183340();
                piVar1[0x30] = 0;
            }
            if ((piVar1[0x31] != 0) && ((*(uint32_t *)((int64_t)piVar1 + 0x3c) & 0x8000) != 0)) {
                uStack_40 = 0x1801838be;
                fcn.180183170();
                piVar1[0x31] = 0;
            }
            if (piVar1[0x32] != 0) {
                uStack_40 = 0x1801838d6;
                fcn.180460d90();
                piVar1[0x32] = 0;
            }
            if ((*(uint32_t *)(piVar1 + 8) & 0xfffff00) != 0) {
                uStack_40 = 0x1801838f1;
                (*(code *)0x8000000000000003)((int64_t)*(int32_t *)(piVar1 + 9));
                return 0;
            }
            if (*(uint32_t *)(piVar1 + 8) == 0x20) {
                uStack_40 = 0x18018390b;
                fcn.180474154(*(undefined4 *)(piVar1 + 9));
            }
        }
        return 0;
    }
code_r0x000180181d00:
    uStack_48 = 0;
    uStack_40 = 0;
    uStack_38 = 0;
    _var_18h = ZEXT816(0);
    uStack_30 = 0x180181d50;
    uStack_20 = (uint64_t)*(uint32_t *)((int64_t)piVar1 + 0x44);
    piStack_28 = piVar1;
    fcn.1801823b0(*piVar1, &uStack_48);
    return 0;
}

// ============================================================
// Function: FUN_18017f030
// Address: 0x18017f030
// Size: 84 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h

void fcn.18017f030(int64_t arg1)
{
    undefined8 *puVar1;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_10h;
    
    var_10h = 0;
    puVar1 = *(undefined8 **)(arg1 + 0x58);
    if (puVar1 != (undefined8 *)0x0) {
        var_10h = (**(code **)*puVar1)(puVar1, &var_48h);
    }
    (**(code **)(arg1 + 8))
              (*(undefined8 *)(arg1 + 0x68), *(undefined4 *)(arg1 + 0x60), &var_48h, *(undefined4 *)(arg1 + 0x18), 
               *(undefined8 *)(arg1 + 0x10));
    return;
}

// ============================================================
// Function: FUN_18017f090
// Address: 0x18017f090
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18017f090(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    char cVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t iVar9;
    int64_t **ppiVar10;
    int64_t unaff_RDI;
    int64_t var_8h;
    
    piVar5 = *(int64_t **)arg1;
    if ((arg2 == *piVar5) && (*(char *)(arg3 + 0x19) != '\0')) {
        fcn.1800646d0(unaff_RDI);
        piVar5[1] = (int64_t)piVar5;
        *piVar5 = (int64_t)piVar5;
        piVar5[2] = (int64_t)piVar5;
        *(undefined8 *)(arg1 + 8) = 0;
        return arg3;
    }
    if (arg2 != arg3) {
        do {
            ppiVar6 = *(int64_t ***)(arg2 + 0x10);
            if (*(char *)((int64_t)ppiVar6 + 0x19) == '\0') {
                cVar4 = *(char *)((int64_t)*ppiVar6 + 0x19);
                ppiVar10 = ppiVar6;
                ppiVar8 = (int64_t **)*ppiVar6;
                while (cVar4 == '\0') {
                    cVar4 = *(char *)((int64_t)*ppiVar8 + 0x19);
                    ppiVar10 = ppiVar8;
                    ppiVar8 = (int64_t **)*ppiVar8;
                }
                piVar5 = *ppiVar6;
                cVar4 = *(char *)((int64_t)piVar5 + 0x19);
                while (cVar4 == '\0') {
                    piVar5 = (int64_t *)*piVar5;
                    cVar4 = *(char *)((int64_t)piVar5 + 0x19);
                }
            } else {
                cVar4 = *(char *)((int64_t)*(int64_t ***)(arg2 + 8) + 0x19);
                ppiVar8 = *(int64_t ***)(arg2 + 8);
                ppiVar6 = (int64_t **)arg2;
                while ((ppiVar10 = ppiVar8, cVar4 == '\0' && (ppiVar6 == (int64_t **)ppiVar10[2]))) {
                    cVar4 = *(char *)((int64_t)ppiVar10[1] + 0x19);
                    ppiVar8 = (int64_t **)ppiVar10[1];
                    ppiVar6 = ppiVar10;
                }
                cVar4 = *(char *)((int64_t)*(int64_t ***)(arg2 + 8) + 0x19);
                ppiVar8 = *(int64_t ***)(arg2 + 8);
                ppiVar6 = (int64_t **)arg2;
                while ((ppiVar7 = ppiVar8, cVar4 == '\0' && (ppiVar6 == (int64_t **)ppiVar7[2]))) {
                    cVar4 = *(char *)((int64_t)ppiVar7[1] + 0x19);
                    ppiVar8 = (int64_t **)ppiVar7[1];
                    ppiVar6 = ppiVar7;
                }
            }
            iVar9 = fcn.18017f1f0(arg1, arg2);
            piVar5 = *(int64_t **)(iVar9 + 0x30);
            if (piVar5 != (int64_t *)0x0) {
                LOCK();
                piVar1 = piVar5 + 1;
                iVar3 = *(int32_t *)piVar1;
                *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)*piVar5)(piVar5);
                    LOCK();
                    piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
                    iVar3 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (iVar3 == 1) {
                        (**(code **)(*piVar5 + 8))(piVar5);
                    }
                }
            }
            fcn.180459c3c(iVar9, 0x38);
            arg2 = (int64_t)ppiVar10;
        } while (ppiVar10 != (int64_t **)arg3);
    }
    return arg3;
}

// ============================================================
// Function: FUN_18017f0e7
// Address: 0x18017f0e7
// Size: 243 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18017f090(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    char cVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t iVar9;
    int64_t **ppiVar10;
    int64_t unaff_RDI;
    int64_t var_8h;
    
    piVar5 = *(int64_t **)arg1;
    if ((arg2 == *piVar5) && (*(char *)(arg3 + 0x19) != '\0')) {
        fcn.1800646d0(unaff_RDI);
        piVar5[1] = (int64_t)piVar5;
        *piVar5 = (int64_t)piVar5;
        piVar5[2] = (int64_t)piVar5;
        *(undefined8 *)(arg1 + 8) = 0;
        return arg3;
    }
    if (arg2 != arg3) {
        do {
            ppiVar6 = *(int64_t ***)(arg2 + 0x10);
            if (*(char *)((int64_t)ppiVar6 + 0x19) == '\0') {
                cVar4 = *(char *)((int64_t)*ppiVar6 + 0x19);
                ppiVar10 = ppiVar6;
                ppiVar8 = (int64_t **)*ppiVar6;
                while (cVar4 == '\0') {
                    cVar4 = *(char *)((int64_t)*ppiVar8 + 0x19);
                    ppiVar10 = ppiVar8;
                    ppiVar8 = (int64_t **)*ppiVar8;
                }
                piVar5 = *ppiVar6;
                cVar4 = *(char *)((int64_t)piVar5 + 0x19);
                while (cVar4 == '\0') {
                    piVar5 = (int64_t *)*piVar5;
                    cVar4 = *(char *)((int64_t)piVar5 + 0x19);
                }
            } else {
                cVar4 = *(char *)((int64_t)*(int64_t ***)(arg2 + 8) + 0x19);
                ppiVar8 = *(int64_t ***)(arg2 + 8);
                ppiVar6 = (int64_t **)arg2;
                while ((ppiVar10 = ppiVar8, cVar4 == '\0' && (ppiVar6 == (int64_t **)ppiVar10[2]))) {
                    cVar4 = *(char *)((int64_t)ppiVar10[1] + 0x19);
                    ppiVar8 = (int64_t **)ppiVar10[1];
                    ppiVar6 = ppiVar10;
                }
                cVar4 = *(char *)((int64_t)*(int64_t ***)(arg2 + 8) + 0x19);
                ppiVar8 = *(int64_t ***)(arg2 + 8);
                ppiVar6 = (int64_t **)arg2;
                while ((ppiVar7 = ppiVar8, cVar4 == '\0' && (ppiVar6 == (int64_t **)ppiVar7[2]))) {
                    cVar4 = *(char *)((int64_t)ppiVar7[1] + 0x19);
                    ppiVar8 = (int64_t **)ppiVar7[1];
                    ppiVar6 = ppiVar7;
                }
            }
            iVar9 = fcn.18017f1f0(arg1, arg2);
            piVar5 = *(int64_t **)(iVar9 + 0x30);
            if (piVar5 != (int64_t *)0x0) {
                LOCK();
                piVar1 = piVar5 + 1;
                iVar3 = *(int32_t *)piVar1;
                *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)*piVar5)(piVar5);
                    LOCK();
                    piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
                    iVar3 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (iVar3 == 1) {
                        (**(code **)(*piVar5 + 8))(piVar5);
                    }
                }
            }
            fcn.180459c3c(iVar9, 0x38);
            arg2 = (int64_t)ppiVar10;
        } while (ppiVar10 != (int64_t **)arg3);
    }
    return arg3;
}

// ============================================================
// Function: FUN_18017f1da
// Address: 0x18017f1da
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18017f090(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_58h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    char cVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t iVar9;
    int64_t **ppiVar10;
    int64_t unaff_RDI;
    int64_t var_8h;
    
    piVar5 = *(int64_t **)arg1;
    if ((arg2 == *piVar5) && (*(char *)(arg3 + 0x19) != '\0')) {
        fcn.1800646d0(unaff_RDI);
        piVar5[1] = (int64_t)piVar5;
        *piVar5 = (int64_t)piVar5;
        piVar5[2] = (int64_t)piVar5;
        *(undefined8 *)(arg1 + 8) = 0;
        return arg3;
    }
    if (arg2 != arg3) {
        do {
            ppiVar6 = *(int64_t ***)(arg2 + 0x10);
            if (*(char *)((int64_t)ppiVar6 + 0x19) == '\0') {
                cVar4 = *(char *)((int64_t)*ppiVar6 + 0x19);
                ppiVar10 = ppiVar6;
                ppiVar8 = (int64_t **)*ppiVar6;
                while (cVar4 == '\0') {
                    cVar4 = *(char *)((int64_t)*ppiVar8 + 0x19);
                    ppiVar10 = ppiVar8;
                    ppiVar8 = (int64_t **)*ppiVar8;
                }
                piVar5 = *ppiVar6;
                cVar4 = *(char *)((int64_t)piVar5 + 0x19);
                while (cVar4 == '\0') {
                    piVar5 = (int64_t *)*piVar5;
                    cVar4 = *(char *)((int64_t)piVar5 + 0x19);
                }
            } else {
                cVar4 = *(char *)((int64_t)*(int64_t ***)(arg2 + 8) + 0x19);
                ppiVar8 = *(int64_t ***)(arg2 + 8);
                ppiVar6 = (int64_t **)arg2;
                while ((ppiVar10 = ppiVar8, cVar4 == '\0' && (ppiVar6 == (int64_t **)ppiVar10[2]))) {
                    cVar4 = *(char *)((int64_t)ppiVar10[1] + 0x19);
                    ppiVar8 = (int64_t **)ppiVar10[1];
                    ppiVar6 = ppiVar10;
                }
                cVar4 = *(char *)((int64_t)*(int64_t ***)(arg2 + 8) + 0x19);
                ppiVar8 = *(int64_t ***)(arg2 + 8);
                ppiVar6 = (int64_t **)arg2;
                while ((ppiVar7 = ppiVar8, cVar4 == '\0' && (ppiVar6 == (int64_t **)ppiVar7[2]))) {
                    cVar4 = *(char *)((int64_t)ppiVar7[1] + 0x19);
                    ppiVar8 = (int64_t **)ppiVar7[1];
                    ppiVar6 = ppiVar7;
                }
            }
            iVar9 = fcn.18017f1f0(arg1, arg2);
            piVar5 = *(int64_t **)(iVar9 + 0x30);
            if (piVar5 != (int64_t *)0x0) {
                LOCK();
                piVar1 = piVar5 + 1;
                iVar3 = *(int32_t *)piVar1;
                *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)*piVar5)(piVar5);
                    LOCK();
                    piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
                    iVar3 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (iVar3 == 1) {
                        (**(code **)(*piVar5 + 8))(piVar5);
                    }
                }
            }
            fcn.180459c3c(iVar9, 0x38);
            arg2 = (int64_t)ppiVar10;
        } while (ppiVar10 != (int64_t **)arg3);
    }
    return arg3;
}

// ============================================================
// Function: FUN_18017f1f0
// Address: 0x18017f1f0
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18017f1f0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    undefined uVar2;
    int64_t **ppiVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t **ppiVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    ppiVar8 = (int64_t **)(arg2 + 0x10);
    ppiVar7 = (int64_t **)*ppiVar8;
    if (*(char *)((int64_t)ppiVar7 + 0x19) == '\0') {
        cVar1 = *(char *)((int64_t)*ppiVar7 + 0x19);
        ppiVar6 = ppiVar7;
        ppiVar3 = (int64_t **)*ppiVar7;
        while (cVar1 == '\0') {
            cVar1 = *(char *)((int64_t)*ppiVar3 + 0x19);
            ppiVar6 = ppiVar3;
            ppiVar3 = (int64_t **)*ppiVar3;
        }
    } else {
        cVar1 = *(char *)((int64_t)*(int64_t ***)(arg2 + 8) + 0x19);
        ppiVar9 = *(int64_t ***)(arg2 + 8);
        ppiVar3 = (int64_t **)arg2;
        while ((ppiVar6 = ppiVar9, cVar1 == '\0' && (ppiVar3 == (int64_t **)ppiVar6[2]))) {
            cVar1 = *(char *)((int64_t)ppiVar6[1] + 0x19);
            ppiVar9 = (int64_t **)ppiVar6[1];
            ppiVar3 = ppiVar6;
        }
    }
    ppiVar10 = (int64_t **)(arg2 + 8);
    ppiVar3 = *(int64_t ***)arg2;
    ppiVar9 = ppiVar7;
    if (((*(char *)((int64_t)ppiVar3 + 0x19) == '\0') && (ppiVar9 = ppiVar3, *(char *)((int64_t)ppiVar7 + 0x19) == '\0')
        ) && (ppiVar9 = (int64_t **)ppiVar6[2], ppiVar6 != (int64_t **)arg2)) {
        ppiVar3[1] = (int64_t *)ppiVar6;
        *ppiVar6 = *(int64_t **)arg2;
        ppiVar7 = ppiVar6;
        if (ppiVar6 != (int64_t **)*ppiVar8) {
            ppiVar7 = (int64_t **)ppiVar6[1];
            if (*(char *)((int64_t)ppiVar9 + 0x19) == '\0') {
                ppiVar9[1] = (int64_t *)ppiVar7;
            }
            *ppiVar7 = (int64_t *)ppiVar9;
            ppiVar6[2] = *ppiVar8;
            (*ppiVar8)[1] = (int64_t)ppiVar6;
        }
        if (*(int64_t *)(*(int64_t *)arg1 + 8) == arg2) {
            *(int64_t ***)(*(int64_t *)arg1 + 8) = ppiVar6;
        } else {
            ppiVar8 = (int64_t **)*ppiVar10;
            if (*ppiVar8 == (int64_t *)arg2) {
                *ppiVar8 = (int64_t *)ppiVar6;
            } else {
                ppiVar8[2] = (int64_t *)ppiVar6;
            }
        }
        uVar2 = *(undefined *)(ppiVar6 + 3);
        ppiVar6[1] = *ppiVar10;
        *(undefined *)(ppiVar6 + 3) = *(undefined *)(arg2 + 0x18);
        *(undefined *)(arg2 + 0x18) = uVar2;
    } else {
        ppiVar7 = (int64_t **)*ppiVar10;
        if (*(char *)((int64_t)ppiVar9 + 0x19) == '\0') {
            ppiVar9[1] = (int64_t *)ppiVar7;
        }
        if (*(int64_t *)(*(int64_t *)arg1 + 8) == arg2) {
            *(int64_t ***)(*(int64_t *)arg1 + 8) = ppiVar9;
        } else if (*ppiVar7 == (int64_t *)arg2) {
            *ppiVar7 = (int64_t *)ppiVar9;
        } else {
            ppiVar7[2] = (int64_t *)ppiVar9;
        }
        if (**(int64_t ***)arg1 == (int64_t *)arg2) {
            ppiVar8 = ppiVar7;
            if (*(char *)((int64_t)ppiVar9 + 0x19) == '\0') {
                cVar1 = *(char *)((int64_t)*ppiVar9 + 0x19);
                ppiVar6 = (int64_t **)*ppiVar9;
                ppiVar8 = ppiVar9;
                while (ppiVar3 = ppiVar6, cVar1 == '\0') {
                    ppiVar6 = (int64_t **)*ppiVar3;
                    cVar1 = *(char *)((int64_t)ppiVar6 + 0x19);
                    ppiVar8 = ppiVar3;
                }
            }
            **(int64_t ***)arg1 = (int64_t *)ppiVar8;
        }
        iVar4 = *(int64_t *)arg1;
        if (*(int64_t *)(iVar4 + 0x10) == arg2) {
            if (*(char *)((int64_t)ppiVar9 + 0x19) == '\0') {
                cVar1 = *(char *)((int64_t)ppiVar9[2] + 0x19);
                ppiVar8 = ppiVar9;
                while (cVar1 == '\0') {
                    ppiVar8 = (int64_t **)ppiVar8[2];
                    cVar1 = *(char *)((int64_t)ppiVar8[2] + 0x19);
                }
                *(int64_t ***)(iVar4 + 0x10) = ppiVar8;
            } else {
                *(int64_t ***)(iVar4 + 0x10) = ppiVar7;
            }
        }
    }
    if (*(char *)(arg2 + 0x18) == '\x01') {
        if (ppiVar9 != *(int64_t ***)(*(int64_t *)arg1 + 8)) {
            do {
                ppiVar8 = ppiVar7;
                if (*(char *)(ppiVar9 + 3) != '\x01') break;
                ppiVar7 = (int64_t **)*ppiVar8;
                if (ppiVar9 == ppiVar7) {
                    ppiVar7 = (int64_t **)ppiVar8[2];
                    if (*(char *)(ppiVar7 + 3) == '\0') {
                        *(undefined *)(ppiVar7 + 3) = 1;
                        ppiVar7 = (int64_t **)ppiVar8[2];
                        *(undefined *)(ppiVar8 + 3) = 0;
                        ppiVar8[2] = *ppiVar7;
                        if (*(char *)((int64_t)*ppiVar7 + 0x19) == '\0') {
                            (*ppiVar7)[1] = (int64_t)ppiVar8;
                        }
                        ppiVar7[1] = ppiVar8[1];
                        if (ppiVar8 == *(int64_t ***)(*(int64_t *)arg1 + 8)) {
                            *(int64_t ***)(*(int64_t *)arg1 + 8) = ppiVar7;
                        } else {
                            ppiVar6 = (int64_t **)ppiVar8[1];
                            if (ppiVar8 == (int64_t **)*ppiVar6) {
                                *ppiVar6 = (int64_t *)ppiVar7;
                            } else {
                                ppiVar6[2] = (int64_t *)ppiVar7;
                            }
                        }
                        *ppiVar7 = (int64_t *)ppiVar8;
                        ppiVar8[1] = (int64_t *)ppiVar7;
                        ppiVar7 = (int64_t **)ppiVar8[2];
                    }
                    if (*(char *)((int64_t)ppiVar7 + 0x19) == '\0') {
                        if ((*(char *)(*ppiVar7 + 3) != '\x01') || (*(char *)(ppiVar7[2] + 3) != '\x01')) {
                            if (*(char *)(ppiVar7[2] + 3) == '\x01') {
                                *(undefined *)(*ppiVar7 + 3) = 1;
                                *(undefined *)(ppiVar7 + 3) = 0;
                                func_0x000180060390(arg1, ppiVar7);
                                ppiVar7 = (int64_t **)ppiVar8[2];
                            }
                            *(undefined *)(ppiVar7 + 3) = *(undefined *)(ppiVar8 + 3);
                            *(undefined *)(ppiVar8 + 3) = 1;
                            *(undefined *)(ppiVar7[2] + 3) = 1;
                            func_0x0001800603f0(arg1, ppiVar8);
                            break;
                        }
code_r0x00018017f51f:
                        *(undefined *)(ppiVar7 + 3) = 0;
                    }
                } else {
                    if (*(char *)(ppiVar7 + 3) == '\0') {
                        *(undefined *)(ppiVar7 + 3) = 1;
                        piVar5 = *ppiVar8;
                        *(undefined *)(ppiVar8 + 3) = 0;
                        *ppiVar8 = (int64_t *)piVar5[2];
                        if (*(char *)(piVar5[2] + 0x19) == '\0') {
                            *(int64_t ***)(piVar5[2] + 8) = ppiVar8;
                        }
                        piVar5[1] = (int64_t)ppiVar8[1];
                        if (ppiVar8 == *(int64_t ***)(*(int64_t *)arg1 + 8)) {
                            *(int64_t **)(*(int64_t *)arg1 + 8) = piVar5;
                        } else {
                            ppiVar7 = (int64_t **)ppiVar8[1];
                            if (ppiVar8 == (int64_t **)ppiVar7[2]) {
                                ppiVar7[2] = piVar5;
                            } else {
                                *ppiVar7 = piVar5;
                            }
                        }
                        piVar5[2] = (int64_t)ppiVar8;
                        ppiVar8[1] = piVar5;
                        ppiVar7 = (int64_t **)*ppiVar8;
                    }
                    if (*(char *)((int64_t)ppiVar7 + 0x19) == '\0') {
                        if ((*(char *)(ppiVar7[2] + 3) == '\x01') && (*(char *)(*ppiVar7 + 3) == '\x01'))
                        goto code_r0x00018017f51f;
                        if (*(char *)(*ppiVar7 + 3) == '\x01') {
                            *(undefined *)(ppiVar7[2] + 3) = 1;
                            *(undefined *)(ppiVar7 + 3) = 0;
                            func_0x0001800603f0(arg1, ppiVar7);
                            ppiVar7 = (int64_t **)*ppiVar8;
                        }
                        *(undefined *)(ppiVar7 + 3) = *(undefined *)(ppiVar8 + 3);
                        *(undefined *)(ppiVar8 + 3) = 1;
                        *(undefined *)(*ppiVar7 + 3) = 1;
                        func_0x000180060390(arg1, ppiVar8);
                        break;
                    }
                }
                ppiVar7 = (int64_t **)ppiVar8[1];
                ppiVar9 = ppiVar8;
            } while (ppiVar8 != *(int64_t ***)(*(int64_t *)arg1 + 8));
        }
        *(undefined *)(ppiVar9 + 3) = 1;
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + -1;
    }
    return arg2;
}

// ============================================================
// Function: FUN_18017f1fb
// Address: 0x18017f1fb
// Size: 456 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18017f1f0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    undefined uVar2;
    int64_t **ppiVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t **ppiVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    ppiVar8 = (int64_t **)(arg2 + 0x10);
    ppiVar7 = (int64_t **)*ppiVar8;
    if (*(char *)((int64_t)ppiVar7 + 0x19) == '\0') {
        cVar1 = *(char *)((int64_t)*ppiVar7 + 0x19);
        ppiVar6 = ppiVar7;
        ppiVar3 = (int64_t **)*ppiVar7;
        while (cVar1 == '\0') {
            cVar1 = *(char *)((int64_t)*ppiVar3 + 0x19);
            ppiVar6 = ppiVar3;
            ppiVar3 = (int64_t **)*ppiVar3;
        }
    } else {
        cVar1 = *(char *)((int64_t)*(int64_t ***)(arg2 + 8) + 0x19);
        ppiVar9 = *(int64_t ***)(arg2 + 8);
        ppiVar3 = (int64_t **)arg2;
        while ((ppiVar6 = ppiVar9, cVar1 == '\0' && (ppiVar3 == (int64_t **)ppiVar6[2]))) {
            cVar1 = *(char *)((int64_t)ppiVar6[1] + 0x19);
            ppiVar9 = (int64_t **)ppiVar6[1];
            ppiVar3 = ppiVar6;
        }
    }
    ppiVar10 = (int64_t **)(arg2 + 8);
    ppiVar3 = *(int64_t ***)arg2;
    ppiVar9 = ppiVar7;
    if (((*(char *)((int64_t)ppiVar3 + 0x19) == '\0') && (ppiVar9 = ppiVar3, *(char *)((int64_t)ppiVar7 + 0x19) == '\0')
        ) && (ppiVar9 = (int64_t **)ppiVar6[2], ppiVar6 != (int64_t **)arg2)) {
        ppiVar3[1] = (int64_t *)ppiVar6;
        *ppiVar6 = *(int64_t **)arg2;
        ppiVar7 = ppiVar6;
        if (ppiVar6 != (int64_t **)*ppiVar8) {
            ppiVar7 = (int64_t **)ppiVar6[1];
            if (*(char *)((int64_t)ppiVar9 + 0x19) == '\0') {
                ppiVar9[1] = (int64_t *)ppiVar7;
            }
            *ppiVar7 = (int64_t *)ppiVar9;
            ppiVar6[2] = *ppiVar8;
            (*ppiVar8)[1] = (int64_t)ppiVar6;
        }
        if (*(int64_t *)(*(int64_t *)arg1 + 8) == arg2) {
            *(int64_t ***)(*(int64_t *)arg1 + 8) = ppiVar6;
        } else {
            ppiVar8 = (int64_t **)*ppiVar10;
            if (*ppiVar8 == (int64_t *)arg2) {
                *ppiVar8 = (int64_t *)ppiVar6;
            } else {
                ppiVar8[2] = (int64_t *)ppiVar6;
            }
        }
        uVar2 = *(undefined *)(ppiVar6 + 3);
        ppiVar6[1] = *ppiVar10;
        *(undefined *)(ppiVar6 + 3) = *(undefined *)(arg2 + 0x18);
        *(undefined *)(arg2 + 0x18) = uVar2;
    } else {
        ppiVar7 = (int64_t **)*ppiVar10;
        if (*(char *)((int64_t)ppiVar9 + 0x19) == '\0') {
            ppiVar9[1] = (int64_t *)ppiVar7;
        }
        if (*(int64_t *)(*(int64_t *)arg1 + 8) == arg2) {
            *(int64_t ***)(*(int64_t *)arg1 + 8) = ppiVar9;
        } else if (*ppiVar7 == (int64_t *)arg2) {
            *ppiVar7 = (int64_t *)ppiVar9;
        } else {
            ppiVar7[2] = (int64_t *)ppiVar9;
        }
        if (**(int64_t ***)arg1 == (int64_t *)arg2) {
            ppiVar8 = ppiVar7;
            if (*(char *)((int64_t)ppiVar9 + 0x19) == '\0') {
                cVar1 = *(char *)((int64_t)*ppiVar9 + 0x19);
                ppiVar6 = (int64_t **)*ppiVar9;
                ppiVar8 = ppiVar9;
                while (ppiVar3 = ppiVar6, cVar1 == '\0') {
                    ppiVar6 = (int64_t **)*ppiVar3;
                    cVar1 = *(char *)((int64_t)ppiVar6 + 0x19);
                    ppiVar8 = ppiVar3;
                }
            }
            **(int64_t ***)arg1 = (int64_t *)ppiVar8;
        }
        iVar4 = *(int64_t *)arg1;
        if (*(int64_t *)(iVar4 + 0x10) == arg2) {
            if (*(char *)((int64_t)ppiVar9 + 0x19) == '\0') {
                cVar1 = *(char *)((int64_t)ppiVar9[2] + 0x19);
                ppiVar8 = ppiVar9;
                while (cVar1 == '\0') {
                    ppiVar8 = (int64_t **)ppiVar8[2];
                    cVar1 = *(char *)((int64_t)ppiVar8[2] + 0x19);
                }
                *(int64_t ***)(iVar4 + 0x10) = ppiVar8;
            } else {
                *(int64_t ***)(iVar4 + 0x10) = ppiVar7;
            }
        }
    }
    if (*(char *)(arg2 + 0x18) == '\x01') {
        if (ppiVar9 != *(int64_t ***)(*(int64_t *)arg1 + 8)) {
            do {
                ppiVar8 = ppiVar7;
                if (*(char *)(ppiVar9 + 3) != '\x01') break;
                ppiVar7 = (int64_t **)*ppiVar8;
                if (ppiVar9 == ppiVar7) {
                    ppiVar7 = (int64_t **)ppiVar8[2];
                    if (*(char *)(ppiVar7 + 3) == '\0') {
                        *(undefined *)(ppiVar7 + 3) = 1;
                        ppiVar7 = (int64_t **)ppiVar8[2];
                        *(undefined *)(ppiVar8 + 3) = 0;
                        ppiVar8[2] = *ppiVar7;
                        if (*(char *)((int64_t)*ppiVar7 + 0x19) == '\0') {
                            (*ppiVar7)[1] = (int64_t)ppiVar8;
                        }
                        ppiVar7[1] = ppiVar8[1];
                        if (ppiVar8 == *(int64_t ***)(*(int64_t *)arg1 + 8)) {
                            *(int64_t ***)(*(int64_t *)arg1 + 8) = ppiVar7;
                        } else {
                            ppiVar6 = (int64_t **)ppiVar8[1];
                            if (ppiVar8 == (int64_t **)*ppiVar6) {
                                *ppiVar6 = (int64_t *)ppiVar7;
                            } else {
                                ppiVar6[2] = (int64_t *)ppiVar7;
                            }
                        }
                        *ppiVar7 = (int64_t *)ppiVar8;
                        ppiVar8[1] = (int64_t *)ppiVar7;
                        ppiVar7 = (int64_t **)ppiVar8[2];
                    }
                    if (*(char *)((int64_t)ppiVar7 + 0x19) == '\0') {
                        if ((*(char *)(*ppiVar7 + 3) != '\x01') || (*(char *)(ppiVar7[2] + 3) != '\x01')) {
                            if (*(char *)(ppiVar7[2] + 3) == '\x01') {
                                *(undefined *)(*ppiVar7 + 3) = 1;
                                *(undefined *)(ppiVar7 + 3) = 0;
                                func_0x000180060390(arg1, ppiVar7);
                                ppiVar7 = (int64_t **)ppiVar8[2];
                            }
                            *(undefined *)(ppiVar7 + 3) = *(undefined *)(ppiVar8 + 3);
                            *(undefined *)(ppiVar8 + 3) = 1;
                            *(undefined *)(ppiVar7[2] + 3) = 1;
                            func_0x0001800603f0(arg1, ppiVar8);
                            break;
                        }
code_r0x00018017f51f:
                        *(undefined *)(ppiVar7 + 3) = 0;
                    }
                } else {
                    if (*(char *)(ppiVar7 + 3) == '\0') {
                        *(undefined *)(ppiVar7 + 3) = 1;
                        piVar5 = *ppiVar8;
                        *(undefined *)(ppiVar8 + 3) = 0;
                        *ppiVar8 = (int64_t *)piVar5[2];
                        if (*(char *)(piVar5[2] + 0x19) == '\0') {
                            *(int64_t ***)(piVar5[2] + 8) = ppiVar8;
                        }
                        piVar5[1] = (int64_t)ppiVar8[1];
                        if (ppiVar8 == *(int64_t ***)(*(int64_t *)arg1 + 8)) {
                            *(int64_t **)(*(int64_t *)arg1 + 8) = piVar5;
                        } else {
                            ppiVar7 = (int64_t **)ppiVar8[1];
                            if (ppiVar8 == (int64_t **)ppiVar7[2]) {
                                ppiVar7[2] = piVar5;
                            } else {
                                *ppiVar7 = piVar5;
                            }
                        }
                        piVar5[2] = (int64_t)ppiVar8;
                        ppiVar8[1] = piVar5;
                        ppiVar7 = (int64_t **)*ppiVar8;
                    }
                    if (*(char *)((int64_t)ppiVar7 + 0x19) == '\0') {
                        if ((*(char *)(ppiVar7[2] + 3) == '\x01') && (*(char *)(*ppiVar7 + 3) == '\x01'))
                        goto code_r0x00018017f51f;
                        if (*(char *)(*ppiVar7 + 3) == '\x01') {
                            *(undefined *)(ppiVar7[2] + 3) = 1;
                            *(undefined *)(ppiVar7 + 3) = 0;
                            func_0x0001800603f0(arg1, ppiVar7);
                            ppiVar7 = (int64_t **)*ppiVar8;
                        }
                        *(undefined *)(ppiVar7 + 3) = *(undefined *)(ppiVar8 + 3);
                        *(undefined *)(ppiVar8 + 3) = 1;
                        *(undefined *)(*ppiVar7 + 3) = 1;
                        func_0x000180060390(arg1, ppiVar8);
                        break;
                    }
                }
                ppiVar7 = (int64_t **)ppiVar8[1];
                ppiVar9 = ppiVar8;
            } while (ppiVar8 != *(int64_t ***)(*(int64_t *)arg1 + 8));
        }
        *(undefined *)(ppiVar9 + 3) = 1;
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + -1;
    }
    return arg2;
}

// ============================================================
// Function: FUN_18017f3c3
// Address: 0x18017f3c3
// Size: 460 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18017f1f0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    undefined uVar2;
    int64_t **ppiVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t **ppiVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    ppiVar8 = (int64_t **)(arg2 + 0x10);
    ppiVar7 = (int64_t **)*ppiVar8;
    if (*(char *)((int64_t)ppiVar7 + 0x19) == '\0') {
        cVar1 = *(char *)((int64_t)*ppiVar7 + 0x19);
        ppiVar6 = ppiVar7;
        ppiVar3 = (int64_t **)*ppiVar7;
        while (cVar1 == '\0') {
            cVar1 = *(char *)((int64_t)*ppiVar3 + 0x19);
            ppiVar6 = ppiVar3;
            ppiVar3 = (int64_t **)*ppiVar3;
        }
    } else {
        cVar1 = *(char *)((int64_t)*(int64_t ***)(arg2 + 8) + 0x19);
        ppiVar9 = *(int64_t ***)(arg2 + 8);
        ppiVar3 = (int64_t **)arg2;
        while ((ppiVar6 = ppiVar9, cVar1 == '\0' && (ppiVar3 == (int64_t **)ppiVar6[2]))) {
            cVar1 = *(char *)((int64_t)ppiVar6[1] + 0x19);
            ppiVar9 = (int64_t **)ppiVar6[1];
            ppiVar3 = ppiVar6;
        }
    }
    ppiVar10 = (int64_t **)(arg2 + 8);
    ppiVar3 = *(int64_t ***)arg2;
    ppiVar9 = ppiVar7;
    if (((*(char *)((int64_t)ppiVar3 + 0x19) == '\0') && (ppiVar9 = ppiVar3, *(char *)((int64_t)ppiVar7 + 0x19) == '\0')
        ) && (ppiVar9 = (int64_t **)ppiVar6[2], ppiVar6 != (int64_t **)arg2)) {
        ppiVar3[1] = (int64_t *)ppiVar6;
        *ppiVar6 = *(int64_t **)arg2;
        ppiVar7 = ppiVar6;
        if (ppiVar6 != (int64_t **)*ppiVar8) {
            ppiVar7 = (int64_t **)ppiVar6[1];
            if (*(char *)((int64_t)ppiVar9 + 0x19) == '\0') {
                ppiVar9[1] = (int64_t *)ppiVar7;
            }
            *ppiVar7 = (int64_t *)ppiVar9;
            ppiVar6[2] = *ppiVar8;
            (*ppiVar8)[1] = (int64_t)ppiVar6;
        }
        if (*(int64_t *)(*(int64_t *)arg1 + 8) == arg2) {
            *(int64_t ***)(*(int64_t *)arg1 + 8) = ppiVar6;
        } else {
            ppiVar8 = (int64_t **)*ppiVar10;
            if (*ppiVar8 == (int64_t *)arg2) {
                *ppiVar8 = (int64_t *)ppiVar6;
            } else {
                ppiVar8[2] = (int64_t *)ppiVar6;
            }
        }
        uVar2 = *(undefined *)(ppiVar6 + 3);
        ppiVar6[1] = *ppiVar10;
        *(undefined *)(ppiVar6 + 3) = *(undefined *)(arg2 + 0x18);
        *(undefined *)(arg2 + 0x18) = uVar2;
    } else {
        ppiVar7 = (int64_t **)*ppiVar10;
        if (*(char *)((int64_t)ppiVar9 + 0x19) == '\0') {
            ppiVar9[1] = (int64_t *)ppiVar7;
        }
        if (*(int64_t *)(*(int64_t *)arg1 + 8) == arg2) {
            *(int64_t ***)(*(int64_t *)arg1 + 8) = ppiVar9;
        } else if (*ppiVar7 == (int64_t *)arg2) {
            *ppiVar7 = (int64_t *)ppiVar9;
        } else {
            ppiVar7[2] = (int64_t *)ppiVar9;
        }
        if (**(int64_t ***)arg1 == (int64_t *)arg2) {
            ppiVar8 = ppiVar7;
            if (*(char *)((int64_t)ppiVar9 + 0x19) == '\0') {
                cVar1 = *(char *)((int64_t)*ppiVar9 + 0x19);
                ppiVar6 = (int64_t **)*ppiVar9;
                ppiVar8 = ppiVar9;
                while (ppiVar3 = ppiVar6, cVar1 == '\0') {
                    ppiVar6 = (int64_t **)*ppiVar3;
                    cVar1 = *(char *)((int64_t)ppiVar6 + 0x19);
                    ppiVar8 = ppiVar3;
                }
            }
            **(int64_t ***)arg1 = (int64_t *)ppiVar8;
        }
        iVar4 = *(int64_t *)arg1;
        if (*(int64_t *)(iVar4 + 0x10) == arg2) {
            if (*(char *)((int64_t)ppiVar9 + 0x19) == '\0') {
                cVar1 = *(char *)((int64_t)ppiVar9[2] + 0x19);
                ppiVar8 = ppiVar9;
                while (cVar1 == '\0') {
                    ppiVar8 = (int64_t **)ppiVar8[2];
                    cVar1 = *(char *)((int64_t)ppiVar8[2] + 0x19);
                }
                *(int64_t ***)(iVar4 + 0x10) = ppiVar8;
            } else {
                *(int64_t ***)(iVar4 + 0x10) = ppiVar7;
            }
        }
    }
    if (*(char *)(arg2 + 0x18) == '\x01') {
        if (ppiVar9 != *(int64_t ***)(*(int64_t *)arg1 + 8)) {
            do {
                ppiVar8 = ppiVar7;
                if (*(char *)(ppiVar9 + 3) != '\x01') break;
                ppiVar7 = (int64_t **)*ppiVar8;
                if (ppiVar9 == ppiVar7) {
                    ppiVar7 = (int64_t **)ppiVar8[2];
                    if (*(char *)(ppiVar7 + 3) == '\0') {
                        *(undefined *)(ppiVar7 + 3) = 1;
                        ppiVar7 = (int64_t **)ppiVar8[2];
                        *(undefined *)(ppiVar8 + 3) = 0;
                        ppiVar8[2] = *ppiVar7;
                        if (*(char *)((int64_t)*ppiVar7 + 0x19) == '\0') {
                            (*ppiVar7)[1] = (int64_t)ppiVar8;
                        }
                        ppiVar7[1] = ppiVar8[1];
                        if (ppiVar8 == *(int64_t ***)(*(int64_t *)arg1 + 8)) {
                            *(int64_t ***)(*(int64_t *)arg1 + 8) = ppiVar7;
                        } else {
                            ppiVar6 = (int64_t **)ppiVar8[1];
                            if (ppiVar8 == (int64_t **)*ppiVar6) {
                                *ppiVar6 = (int64_t *)ppiVar7;
                            } else {
                                ppiVar6[2] = (int64_t *)ppiVar7;
                            }
                        }
                        *ppiVar7 = (int64_t *)ppiVar8;
                        ppiVar8[1] = (int64_t *)ppiVar7;
                        ppiVar7 = (int64_t **)ppiVar8[2];
                    }
                    if (*(char *)((int64_t)ppiVar7 + 0x19) == '\0') {
                        if ((*(char *)(*ppiVar7 + 3) != '\x01') || (*(char *)(ppiVar7[2] + 3) != '\x01')) {
                            if (*(char *)(ppiVar7[2] + 3) == '\x01') {
                                *(undefined *)(*ppiVar7 + 3) = 1;
                                *(undefined *)(ppiVar7 + 3) = 0;
                                func_0x000180060390(arg1, ppiVar7);
                                ppiVar7 = (int64_t **)ppiVar8[2];
                            }
                            *(undefined *)(ppiVar7 + 3) = *(undefined *)(ppiVar8 + 3);
                            *(undefined *)(ppiVar8 + 3) = 1;
                            *(undefined *)(ppiVar7[2] + 3) = 1;
                            func_0x0001800603f0(arg1, ppiVar8);
                            break;
                        }
code_r0x00018017f51f:
                        *(undefined *)(ppiVar7 + 3) = 0;
                    }
                } else {
                    if (*(char *)(ppiVar7 + 3) == '\0') {
                        *(undefined *)(ppiVar7 + 3) = 1;
                        piVar5 = *ppiVar8;
                        *(undefined *)(ppiVar8 + 3) = 0;
                        *ppiVar8 = (int64_t *)piVar5[2];
                        if (*(char *)(piVar5[2] + 0x19) == '\0') {
                            *(int64_t ***)(piVar5[2] + 8) = ppiVar8;
                        }
                        piVar5[1] = (int64_t)ppiVar8[1];
                        if (ppiVar8 == *(int64_t ***)(*(int64_t *)arg1 + 8)) {
                            *(int64_t **)(*(int64_t *)arg1 + 8) = piVar5;
                        } else {
                            ppiVar7 = (int64_t **)ppiVar8[1];
                            if (ppiVar8 == (int64_t **)ppiVar7[2]) {
                                ppiVar7[2] = piVar5;
                            } else {
                                *ppiVar7 = piVar5;
                            }
                        }
                        piVar5[2] = (int64_t)ppiVar8;
                        ppiVar8[1] = piVar5;
                        ppiVar7 = (int64_t **)*ppiVar8;
                    }
                    if (*(char *)((int64_t)ppiVar7 + 0x19) == '\0') {
                        if ((*(char *)(ppiVar7[2] + 3) == '\x01') && (*(char *)(*ppiVar7 + 3) == '\x01'))
                        goto code_r0x00018017f51f;
                        if (*(char *)(*ppiVar7 + 3) == '\x01') {
                            *(undefined *)(ppiVar7[2] + 3) = 1;
                            *(undefined *)(ppiVar7 + 3) = 0;
                            func_0x0001800603f0(arg1, ppiVar7);
                            ppiVar7 = (int64_t **)*ppiVar8;
                        }
                        *(undefined *)(ppiVar7 + 3) = *(undefined *)(ppiVar8 + 3);
                        *(undefined *)(ppiVar8 + 3) = 1;
                        *(undefined *)(*ppiVar7 + 3) = 1;
                        func_0x000180060390(arg1, ppiVar8);
                        break;
                    }
                }
                ppiVar7 = (int64_t **)ppiVar8[1];
                ppiVar9 = ppiVar8;
            } while (ppiVar8 != *(int64_t ***)(*(int64_t *)arg1 + 8));
        }
        *(undefined *)(ppiVar9 + 3) = 1;
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + -1;
    }
    return arg2;
}

// ============================================================
// Function: FUN_18017f58f
// Address: 0x18017f58f
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18017f1f0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    undefined uVar2;
    int64_t **ppiVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t **ppiVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    ppiVar8 = (int64_t **)(arg2 + 0x10);
    ppiVar7 = (int64_t **)*ppiVar8;
    if (*(char *)((int64_t)ppiVar7 + 0x19) == '\0') {
        cVar1 = *(char *)((int64_t)*ppiVar7 + 0x19);
        ppiVar6 = ppiVar7;
        ppiVar3 = (int64_t **)*ppiVar7;
        while (cVar1 == '\0') {
            cVar1 = *(char *)((int64_t)*ppiVar3 + 0x19);
            ppiVar6 = ppiVar3;
            ppiVar3 = (int64_t **)*ppiVar3;
        }
    } else {
        cVar1 = *(char *)((int64_t)*(int64_t ***)(arg2 + 8) + 0x19);
        ppiVar9 = *(int64_t ***)(arg2 + 8);
        ppiVar3 = (int64_t **)arg2;
        while ((ppiVar6 = ppiVar9, cVar1 == '\0' && (ppiVar3 == (int64_t **)ppiVar6[2]))) {
            cVar1 = *(char *)((int64_t)ppiVar6[1] + 0x19);
            ppiVar9 = (int64_t **)ppiVar6[1];
            ppiVar3 = ppiVar6;
        }
    }
    ppiVar10 = (int64_t **)(arg2 + 8);
    ppiVar3 = *(int64_t ***)arg2;
    ppiVar9 = ppiVar7;
    if (((*(char *)((int64_t)ppiVar3 + 0x19) == '\0') && (ppiVar9 = ppiVar3, *(char *)((int64_t)ppiVar7 + 0x19) == '\0')
        ) && (ppiVar9 = (int64_t **)ppiVar6[2], ppiVar6 != (int64_t **)arg2)) {
        ppiVar3[1] = (int64_t *)ppiVar6;
        *ppiVar6 = *(int64_t **)arg2;
        ppiVar7 = ppiVar6;
        if (ppiVar6 != (int64_t **)*ppiVar8) {
            ppiVar7 = (int64_t **)ppiVar6[1];
            if (*(char *)((int64_t)ppiVar9 + 0x19) == '\0') {
                ppiVar9[1] = (int64_t *)ppiVar7;
            }
            *ppiVar7 = (int64_t *)ppiVar9;
            ppiVar6[2] = *ppiVar8;
            (*ppiVar8)[1] = (int64_t)ppiVar6;
        }
        if (*(int64_t *)(*(int64_t *)arg1 + 8) == arg2) {
            *(int64_t ***)(*(int64_t *)arg1 + 8) = ppiVar6;
        } else {
            ppiVar8 = (int64_t **)*ppiVar10;
            if (*ppiVar8 == (int64_t *)arg2) {
                *ppiVar8 = (int64_t *)ppiVar6;
            } else {
                ppiVar8[2] = (int64_t *)ppiVar6;
            }
        }
        uVar2 = *(undefined *)(ppiVar6 + 3);
        ppiVar6[1] = *ppiVar10;
        *(undefined *)(ppiVar6 + 3) = *(undefined *)(arg2 + 0x18);
        *(undefined *)(arg2 + 0x18) = uVar2;
    } else {
        ppiVar7 = (int64_t **)*ppiVar10;
        if (*(char *)((int64_t)ppiVar9 + 0x19) == '\0') {
            ppiVar9[1] = (int64_t *)ppiVar7;
        }
        if (*(int64_t *)(*(int64_t *)arg1 + 8) == arg2) {
            *(int64_t ***)(*(int64_t *)arg1 + 8) = ppiVar9;
        } else if (*ppiVar7 == (int64_t *)arg2) {
            *ppiVar7 = (int64_t *)ppiVar9;
        } else {
            ppiVar7[2] = (int64_t *)ppiVar9;
        }
        if (**(int64_t ***)arg1 == (int64_t *)arg2) {
            ppiVar8 = ppiVar7;
            if (*(char *)((int64_t)ppiVar9 + 0x19) == '\0') {
                cVar1 = *(char *)((int64_t)*ppiVar9 + 0x19);
                ppiVar6 = (int64_t **)*ppiVar9;
                ppiVar8 = ppiVar9;
                while (ppiVar3 = ppiVar6, cVar1 == '\0') {
                    ppiVar6 = (int64_t **)*ppiVar3;
                    cVar1 = *(char *)((int64_t)ppiVar6 + 0x19);
                    ppiVar8 = ppiVar3;
                }
            }
            **(int64_t ***)arg1 = (int64_t *)ppiVar8;
        }
        iVar4 = *(int64_t *)arg1;
        if (*(int64_t *)(iVar4 + 0x10) == arg2) {
            if (*(char *)((int64_t)ppiVar9 + 0x19) == '\0') {
                cVar1 = *(char *)((int64_t)ppiVar9[2] + 0x19);
                ppiVar8 = ppiVar9;
                while (cVar1 == '\0') {
                    ppiVar8 = (int64_t **)ppiVar8[2];
                    cVar1 = *(char *)((int64_t)ppiVar8[2] + 0x19);
                }
                *(int64_t ***)(iVar4 + 0x10) = ppiVar8;
            } else {
                *(int64_t ***)(iVar4 + 0x10) = ppiVar7;
            }
        }
    }
    if (*(char *)(arg2 + 0x18) == '\x01') {
        if (ppiVar9 != *(int64_t ***)(*(int64_t *)arg1 + 8)) {
            do {
                ppiVar8 = ppiVar7;
                if (*(char *)(ppiVar9 + 3) != '\x01') break;
                ppiVar7 = (int64_t **)*ppiVar8;
                if (ppiVar9 == ppiVar7) {
                    ppiVar7 = (int64_t **)ppiVar8[2];
                    if (*(char *)(ppiVar7 + 3) == '\0') {
                        *(undefined *)(ppiVar7 + 3) = 1;
                        ppiVar7 = (int64_t **)ppiVar8[2];
                        *(undefined *)(ppiVar8 + 3) = 0;
                        ppiVar8[2] = *ppiVar7;
                        if (*(char *)((int64_t)*ppiVar7 + 0x19) == '\0') {
                            (*ppiVar7)[1] = (int64_t)ppiVar8;
                        }
                        ppiVar7[1] = ppiVar8[1];
                        if (ppiVar8 == *(int64_t ***)(*(int64_t *)arg1 + 8)) {
                            *(int64_t ***)(*(int64_t *)arg1 + 8) = ppiVar7;
                        } else {
                            ppiVar6 = (int64_t **)ppiVar8[1];
                            if (ppiVar8 == (int64_t **)*ppiVar6) {
                                *ppiVar6 = (int64_t *)ppiVar7;
                            } else {
                                ppiVar6[2] = (int64_t *)ppiVar7;
                            }
                        }
                        *ppiVar7 = (int64_t *)ppiVar8;
                        ppiVar8[1] = (int64_t *)ppiVar7;
                        ppiVar7 = (int64_t **)ppiVar8[2];
                    }
                    if (*(char *)((int64_t)ppiVar7 + 0x19) == '\0') {
                        if ((*(char *)(*ppiVar7 + 3) != '\x01') || (*(char *)(ppiVar7[2] + 3) != '\x01')) {
                            if (*(char *)(ppiVar7[2] + 3) == '\x01') {
                                *(undefined *)(*ppiVar7 + 3) = 1;
                                *(undefined *)(ppiVar7 + 3) = 0;
                                func_0x000180060390(arg1, ppiVar7);
                                ppiVar7 = (int64_t **)ppiVar8[2];
                            }
                            *(undefined *)(ppiVar7 + 3) = *(undefined *)(ppiVar8 + 3);
                            *(undefined *)(ppiVar8 + 3) = 1;
                            *(undefined *)(ppiVar7[2] + 3) = 1;
                            func_0x0001800603f0(arg1, ppiVar8);
                            break;
                        }
code_r0x00018017f51f:
                        *(undefined *)(ppiVar7 + 3) = 0;
                    }
                } else {
                    if (*(char *)(ppiVar7 + 3) == '\0') {
                        *(undefined *)(ppiVar7 + 3) = 1;
                        piVar5 = *ppiVar8;
                        *(undefined *)(ppiVar8 + 3) = 0;
                        *ppiVar8 = (int64_t *)piVar5[2];
                        if (*(char *)(piVar5[2] + 0x19) == '\0') {
                            *(int64_t ***)(piVar5[2] + 8) = ppiVar8;
                        }
                        piVar5[1] = (int64_t)ppiVar8[1];
                        if (ppiVar8 == *(int64_t ***)(*(int64_t *)arg1 + 8)) {
                            *(int64_t **)(*(int64_t *)arg1 + 8) = piVar5;
                        } else {
                            ppiVar7 = (int64_t **)ppiVar8[1];
                            if (ppiVar8 == (int64_t **)ppiVar7[2]) {
                                ppiVar7[2] = piVar5;
                            } else {
                                *ppiVar7 = piVar5;
                            }
                        }
                        piVar5[2] = (int64_t)ppiVar8;
                        ppiVar8[1] = piVar5;
                        ppiVar7 = (int64_t **)*ppiVar8;
                    }
                    if (*(char *)((int64_t)ppiVar7 + 0x19) == '\0') {
                        if ((*(char *)(ppiVar7[2] + 3) == '\x01') && (*(char *)(*ppiVar7 + 3) == '\x01'))
                        goto code_r0x00018017f51f;
                        if (*(char *)(*ppiVar7 + 3) == '\x01') {
                            *(undefined *)(ppiVar7[2] + 3) = 1;
                            *(undefined *)(ppiVar7 + 3) = 0;
                            func_0x0001800603f0(arg1, ppiVar7);
                            ppiVar7 = (int64_t **)*ppiVar8;
                        }
                        *(undefined *)(ppiVar7 + 3) = *(undefined *)(ppiVar8 + 3);
                        *(undefined *)(ppiVar8 + 3) = 1;
                        *(undefined *)(*ppiVar7 + 3) = 1;
                        func_0x000180060390(arg1, ppiVar8);
                        break;
                    }
                }
                ppiVar7 = (int64_t **)ppiVar8[1];
                ppiVar9 = ppiVar8;
            } while (ppiVar8 != *(int64_t ***)(*(int64_t *)arg1 + 8));
        }
        *(undefined *)(ppiVar9 + 3) = 1;
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + -1;
    }
    return arg2;
}

// ============================================================
// Function: FUN_18017f680
// Address: 0x18017f680
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

undefined8 fcn.18017f680(int64_t arg1, int64_t var_8h, int64_t var_10h, int64_t arg_40h)
{
    uint32_t uVar1;
    int64_t *piVar2;
    bool bVar3;
    char cVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    char in_DL;
    int64_t unaff_RBX;
    int32_t iVar8;
    int64_t unaff_retaddr;
    int64_t var_18h;
    undefined8 uStack_48;
    undefined8 uStack_40;
    undefined8 uStack_38;
    undefined8 uStack_30;
    int64_t *piStack_28;
    uint64_t uStack_20;
    undefined auStack_18 [8];
    undefined8 uStack_10;
    
    if ((*(int64_t *)(arg1 + 8) == 0) || (2 < *(int32_t *)(arg1 + 0x20))) {
code_r0x00018017f6d3:
        bVar3 = true;
    } else {
        iVar8 = *(int32_t *)(arg1 + 0x14);
        uStack_30 = 0x18017f6b9;
        iVar5 = fcn.180173bc0(*(undefined8 *)(arg1 + 8));
        if (iVar8 != iVar5) goto code_r0x00018017f6d3;
        uStack_30 = 0x18017f6cb;
        cVar4 = fcn.180173be0(*(undefined8 *)(arg1 + 8));
        if (cVar4 == '\0') goto code_r0x00018017f6d3;
        bVar3 = false;
    }
    if (bVar3) {
        return 0xffffffff;
    }
    LOCK();
    *(int32_t *)(arg1 + 0x20) = 4;
    UNLOCK();
    if (*(int64_t *)(arg1 + 0xe0) == 0) {
        uStack_30 = 0x18017f70b;
        iVar6 = fcn.1801739f0(*(undefined8 *)(arg1 + 8));
        if (iVar6 == 0x18017fa80) {
            uStack_30 = 0x18017f722;
            fcn.1801742f0(*(undefined8 *)(arg1 + 8), 0);
        }
    }
    piVar2 = *(int64_t **)(arg1 + 8);
    if (in_DL == '\0') {
        if ((*(uint32_t *)((int64_t)piVar2 + 0x3c) & 0x20) == 0) {
            if ((*(uint32_t *)((int64_t)piVar2 + 0x3c) & 1) == 0) {
                iVar8 = *(int32_t *)(*piVar2 + 0x34);
                uStack_40 = 0x180183738;
                iVar5 = (*(code *)0x699ddc)();
                if (iVar5 != iVar8) goto code_r0x000180181d00;
            }
            uStack_40 = 0x18018375b;
            (*(code *)0x699f1c)(piVar2 + 0x19);
            uVar1 = *(uint32_t *)((int64_t)piVar2 + 0x3c);
            if ((uVar1 & 0x20) != 0) {
                uStack_40 = 0x18018376f;
                (*(code *)0x699f34)(piVar2 + 0x19);
                return 0;
            }
            if (((piVar2[0x16] != 0) && (*(int32_t *)((int64_t)piVar2 + 0x4c) == 0)) && ((uVar1 & 0x2001) == 0)) {
                *(uint32_t *)((int64_t)piVar2 + 0x3c) = uVar1 | 0x2000;
                uStack_40 = 0x1801837b3;
                (*(code *)0x699f34)(piVar2 + 0x19);
                uStack_40 = 0x1801837c4;
                iVar6 = fcn.18045b9a8(0x1804a77e0, 0x5c);
                uStack_40 = 0x1801837cd;
                uVar7 = fcn.1801723e0(unaff_retaddr);
                uStack_10 = 0x1804a7af8;
                auStack_18._0_4_ = 0x25f;
                uStack_40 = 0x1801837f8;
                fcn.180172b00(uVar7, 3, 0x1804a7b08, iVar6 + 1);
                iVar8 = 60000;
                if (*(int32_t *)((int64_t)piVar2 + 0x124) != 0) {
                    iVar8 = *(int32_t *)((int64_t)piVar2 + 0x124);
                }
                uStack_40 = 0x18018381f;
                iVar6 = fcn.180182c00(*piVar2, 0x1801833d0, iVar8, 1);
                piVar2[0x29] = iVar6;
                *(int64_t **)(iVar6 + 0x28) = piVar2;
                return 0;
            }
            *(uint32_t *)((int64_t)piVar2 + 0x3c) = uVar1 | 0x20;
            uStack_40 = 0x18018384a;
            (*(code *)0x699f34)(piVar2 + 0x19);
            uStack_40 = 0x180183852;
            fcn.180173810(unaff_RBX);
            uStack_40 = 0x18018385a;
            fcn.180173710(piVar2);
            uStack_40 = 0x180183862;
            fcn.1801736e0(piVar2);
            uStack_40 = 0x18018386a;
            fcn.1801737b0(piVar2);
            uStack_40 = 0x180183872;
            fcn.1801737e0(piVar2);
            uStack_40 = 0x18018387a;
            fcn.180173780(piVar2);
            uStack_40 = 0x180183882;
            fcn.180173740(piVar2);
            uStack_40 = 0x18018388a;
            fcn.180173690(piVar2);
            if (piVar2[0x30] != 0) {
                uStack_40 = 0x18018389d;
                fcn.180183340();
                piVar2[0x30] = 0;
            }
            if ((piVar2[0x31] != 0) && ((*(uint32_t *)((int64_t)piVar2 + 0x3c) & 0x8000) != 0)) {
                uStack_40 = 0x1801838be;
                fcn.180183170();
                piVar2[0x31] = 0;
            }
            if (piVar2[0x32] != 0) {
                uStack_40 = 0x1801838d6;
                fcn.180460d90();
                piVar2[0x32] = 0;
            }
            if ((*(uint32_t *)(piVar2 + 8) & 0xfffff00) != 0) {
                uStack_40 = 0x1801838f1;
                (*(code *)0x8000000000000003)((int64_t)*(int32_t *)(piVar2 + 9));
                return 0;
            }
            if (*(uint32_t *)(piVar2 + 8) == 0x20) {
                uStack_40 = 0x18018390b;
                fcn.180474154(*(undefined4 *)(piVar2 + 9));
            }
        }
        return 0;
    }
code_r0x000180181d00:
    uStack_48 = 0;
    uStack_40 = 0;
    uStack_38 = 0;
    _auStack_18 = ZEXT816(0);
    uStack_30 = 0x180181d50;
    uStack_20 = (uint64_t)*(uint32_t *)((int64_t)piVar2 + 0x44);
    piStack_28 = piVar2;
    fcn.1801823b0(*piVar2, &uStack_48);
    return 0;
}

// ============================================================
// Function: FUN_18017f6a8
// Address: 0x18017f6a8
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

undefined8 fcn.18017f680(int64_t arg1, int64_t var_8h, int64_t var_10h, int64_t arg_40h)
{
    uint32_t uVar1;
    int64_t *piVar2;
    bool bVar3;
    char cVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    char in_DL;
    int64_t unaff_RBX;
    int32_t iVar8;
    int64_t unaff_retaddr;
    int64_t var_18h;
    undefined8 uStack_48;
    undefined8 uStack_40;
    undefined8 uStack_38;
    undefined8 uStack_30;
    int64_t *piStack_28;
    uint64_t uStack_20;
    undefined auStack_18 [8];
    undefined8 uStack_10;
    
    if ((*(int64_t *)(arg1 + 8) == 0) || (2 < *(int32_t *)(arg1 + 0x20))) {
code_r0x00018017f6d3:
        bVar3 = true;
    } else {
        iVar8 = *(int32_t *)(arg1 + 0x14);
        uStack_30 = 0x18017f6b9;
        iVar5 = fcn.180173bc0(*(undefined8 *)(arg1 + 8));
        if (iVar8 != iVar5) goto code_r0x00018017f6d3;
        uStack_30 = 0x18017f6cb;
        cVar4 = fcn.180173be0(*(undefined8 *)(arg1 + 8));
        if (cVar4 == '\0') goto code_r0x00018017f6d3;
        bVar3 = false;
    }
    if (bVar3) {
        return 0xffffffff;
    }
    LOCK();
    *(int32_t *)(arg1 + 0x20) = 4;
    UNLOCK();
    if (*(int64_t *)(arg1 + 0xe0) == 0) {
        uStack_30 = 0x18017f70b;
        iVar6 = fcn.1801739f0(*(undefined8 *)(arg1 + 8));
        if (iVar6 == 0x18017fa80) {
            uStack_30 = 0x18017f722;
            fcn.1801742f0(*(undefined8 *)(arg1 + 8), 0);
        }
    }
    piVar2 = *(int64_t **)(arg1 + 8);
    if (in_DL == '\0') {
        if ((*(uint32_t *)((int64_t)piVar2 + 0x3c) & 0x20) == 0) {
            if ((*(uint32_t *)((int64_t)piVar2 + 0x3c) & 1) == 0) {
                iVar8 = *(int32_t *)(*piVar2 + 0x34);
                uStack_40 = 0x180183738;
                iVar5 = (*(code *)0x699ddc)();
                if (iVar5 != iVar8) goto code_r0x000180181d00;
            }
            uStack_40 = 0x18018375b;
            (*(code *)0x699f1c)(piVar2 + 0x19);
            uVar1 = *(uint32_t *)((int64_t)piVar2 + 0x3c);
            if ((uVar1 & 0x20) != 0) {
                uStack_40 = 0x18018376f;
                (*(code *)0x699f34)(piVar2 + 0x19);
                return 0;
            }
            if (((piVar2[0x16] != 0) && (*(int32_t *)((int64_t)piVar2 + 0x4c) == 0)) && ((uVar1 & 0x2001) == 0)) {
                *(uint32_t *)((int64_t)piVar2 + 0x3c) = uVar1 | 0x2000;
                uStack_40 = 0x1801837b3;
                (*(code *)0x699f34)(piVar2 + 0x19);
                uStack_40 = 0x1801837c4;
                iVar6 = fcn.18045b9a8(0x1804a77e0, 0x5c);
                uStack_40 = 0x1801837cd;
                uVar7 = fcn.1801723e0(unaff_retaddr);
                uStack_10 = 0x1804a7af8;
                auStack_18._0_4_ = 0x25f;
                uStack_40 = 0x1801837f8;
                fcn.180172b00(uVar7, 3, 0x1804a7b08, iVar6 + 1);
                iVar8 = 60000;
                if (*(int32_t *)((int64_t)piVar2 + 0x124) != 0) {
                    iVar8 = *(int32_t *)((int64_t)piVar2 + 0x124);
                }
                uStack_40 = 0x18018381f;
                iVar6 = fcn.180182c00(*piVar2, 0x1801833d0, iVar8, 1);
                piVar2[0x29] = iVar6;
                *(int64_t **)(iVar6 + 0x28) = piVar2;
                return 0;
            }
            *(uint32_t *)((int64_t)piVar2 + 0x3c) = uVar1 | 0x20;
            uStack_40 = 0x18018384a;
            (*(code *)0x699f34)(piVar2 + 0x19);
            uStack_40 = 0x180183852;
            fcn.180173810(unaff_RBX);
            uStack_40 = 0x18018385a;
            fcn.180173710(piVar2);
            uStack_40 = 0x180183862;
            fcn.1801736e0(piVar2);
            uStack_40 = 0x18018386a;
            fcn.1801737b0(piVar2);
            uStack_40 = 0x180183872;
            fcn.1801737e0(piVar2);
            uStack_40 = 0x18018387a;
            fcn.180173780(piVar2);
            uStack_40 = 0x180183882;
            fcn.180173740(piVar2);
            uStack_40 = 0x18018388a;
            fcn.180173690(piVar2);
            if (piVar2[0x30] != 0) {
                uStack_40 = 0x18018389d;
                fcn.180183340();
                piVar2[0x30] = 0;
            }
            if ((piVar2[0x31] != 0) && ((*(uint32_t *)((int64_t)piVar2 + 0x3c) & 0x8000) != 0)) {
                uStack_40 = 0x1801838be;
                fcn.180183170();
                piVar2[0x31] = 0;
            }
            if (piVar2[0x32] != 0) {
                uStack_40 = 0x1801838d6;
                fcn.180460d90();
                piVar2[0x32] = 0;
            }
            if ((*(uint32_t *)(piVar2 + 8) & 0xfffff00) != 0) {
                uStack_40 = 0x1801838f1;
                (*(code *)0x8000000000000003)((int64_t)*(int32_t *)(piVar2 + 9));
                return 0;
            }
            if (*(uint32_t *)(piVar2 + 8) == 0x20) {
                uStack_40 = 0x18018390b;
                fcn.180474154(*(undefined4 *)(piVar2 + 9));
            }
        }
        return 0;
    }
code_r0x000180181d00:
    uStack_48 = 0;
    uStack_40 = 0;
    uStack_38 = 0;
    _auStack_18 = ZEXT816(0);
    uStack_30 = 0x180181d50;
    uStack_20 = (uint64_t)*(uint32_t *)((int64_t)piVar2 + 0x44);
    piStack_28 = piVar2;
    fcn.1801823b0(*piVar2, &uStack_48);
    return 0;
}

// ============================================================
// Function: FUN_18017f6c2
// Address: 0x18017f6c2
// Size: 145 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

undefined8 fcn.18017f680(int64_t arg1, int64_t var_8h, int64_t var_10h, int64_t arg_40h)
{
    uint32_t uVar1;
    int64_t *piVar2;
    bool bVar3;
    char cVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    char in_DL;
    int64_t unaff_RBX;
    int32_t iVar8;
    int64_t unaff_retaddr;
    int64_t var_18h;
    undefined8 uStack_48;
    undefined8 uStack_40;
    undefined8 uStack_38;
    undefined8 uStack_30;
    int64_t *piStack_28;
    uint64_t uStack_20;
    undefined auStack_18 [8];
    undefined8 uStack_10;
    
    if ((*(int64_t *)(arg1 + 8) == 0) || (2 < *(int32_t *)(arg1 + 0x20))) {
code_r0x00018017f6d3:
        bVar3 = true;
    } else {
        iVar8 = *(int32_t *)(arg1 + 0x14);
        uStack_30 = 0x18017f6b9;
        iVar5 = fcn.180173bc0(*(undefined8 *)(arg1 + 8));
        if (iVar8 != iVar5) goto code_r0x00018017f6d3;
        uStack_30 = 0x18017f6cb;
        cVar4 = fcn.180173be0(*(undefined8 *)(arg1 + 8));
        if (cVar4 == '\0') goto code_r0x00018017f6d3;
        bVar3 = false;
    }
    if (bVar3) {
        return 0xffffffff;
    }
    LOCK();
    *(int32_t *)(arg1 + 0x20) = 4;
    UNLOCK();
    if (*(int64_t *)(arg1 + 0xe0) == 0) {
        uStack_30 = 0x18017f70b;
        iVar6 = fcn.1801739f0(*(undefined8 *)(arg1 + 8));
        if (iVar6 == 0x18017fa80) {
            uStack_30 = 0x18017f722;
            fcn.1801742f0(*(undefined8 *)(arg1 + 8), 0);
        }
    }
    piVar2 = *(int64_t **)(arg1 + 8);
    if (in_DL == '\0') {
        if ((*(uint32_t *)((int64_t)piVar2 + 0x3c) & 0x20) == 0) {
            if ((*(uint32_t *)((int64_t)piVar2 + 0x3c) & 1) == 0) {
                iVar8 = *(int32_t *)(*piVar2 + 0x34);
                uStack_40 = 0x180183738;
                iVar5 = (*(code *)0x699ddc)();
                if (iVar5 != iVar8) goto code_r0x000180181d00;
            }
            uStack_40 = 0x18018375b;
            (*(code *)0x699f1c)(piVar2 + 0x19);
            uVar1 = *(uint32_t *)((int64_t)piVar2 + 0x3c);
            if ((uVar1 & 0x20) != 0) {
                uStack_40 = 0x18018376f;
                (*(code *)0x699f34)(piVar2 + 0x19);
                return 0;
            }
            if (((piVar2[0x16] != 0) && (*(int32_t *)((int64_t)piVar2 + 0x4c) == 0)) && ((uVar1 & 0x2001) == 0)) {
                *(uint32_t *)((int64_t)piVar2 + 0x3c) = uVar1 | 0x2000;
                uStack_40 = 0x1801837b3;
                (*(code *)0x699f34)(piVar2 + 0x19);
                uStack_40 = 0x1801837c4;
                iVar6 = fcn.18045b9a8(0x1804a77e0, 0x5c);
                uStack_40 = 0x1801837cd;
                uVar7 = fcn.1801723e0(unaff_retaddr);
                uStack_10 = 0x1804a7af8;
                auStack_18._0_4_ = 0x25f;
                uStack_40 = 0x1801837f8;
                fcn.180172b00(uVar7, 3, 0x1804a7b08, iVar6 + 1);
                iVar8 = 60000;
                if (*(int32_t *)((int64_t)piVar2 + 0x124) != 0) {
                    iVar8 = *(int32_t *)((int64_t)piVar2 + 0x124);
                }
                uStack_40 = 0x18018381f;
                iVar6 = fcn.180182c00(*piVar2, 0x1801833d0, iVar8, 1);
                piVar2[0x29] = iVar6;
                *(int64_t **)(iVar6 + 0x28) = piVar2;
                return 0;
            }
            *(uint32_t *)((int64_t)piVar2 + 0x3c) = uVar1 | 0x20;
            uStack_40 = 0x18018384a;
            (*(code *)0x699f34)(piVar2 + 0x19);
            uStack_40 = 0x180183852;
            fcn.180173810(unaff_RBX);
            uStack_40 = 0x18018385a;
            fcn.180173710(piVar2);
            uStack_40 = 0x180183862;
            fcn.1801736e0(piVar2);
            uStack_40 = 0x18018386a;
            fcn.1801737b0(piVar2);
            uStack_40 = 0x180183872;
            fcn.1801737e0(piVar2);
            uStack_40 = 0x18018387a;
            fcn.180173780(piVar2);
            uStack_40 = 0x180183882;
            fcn.180173740(piVar2);
            uStack_40 = 0x18018388a;
            fcn.180173690(piVar2);
            if (piVar2[0x30] != 0) {
                uStack_40 = 0x18018389d;
                fcn.180183340();
                piVar2[0x30] = 0;
            }
            if ((piVar2[0x31] != 0) && ((*(uint32_t *)((int64_t)piVar2 + 0x3c) & 0x8000) != 0)) {
                uStack_40 = 0x1801838be;
                fcn.180183170();
                piVar2[0x31] = 0;
            }
            if (piVar2[0x32] != 0) {
                uStack_40 = 0x1801838d6;
                fcn.180460d90();
                piVar2[0x32] = 0;
            }
            if ((*(uint32_t *)(piVar2 + 8) & 0xfffff00) != 0) {
                uStack_40 = 0x1801838f1;
                (*(code *)0x8000000000000003)((int64_t)*(int32_t *)(piVar2 + 9));
                return 0;
            }
            if (*(uint32_t *)(piVar2 + 8) == 0x20) {
                uStack_40 = 0x18018390b;
                fcn.180474154(*(undefined4 *)(piVar2 + 9));
            }
        }
        return 0;
    }
code_r0x000180181d00:
    uStack_48 = 0;
    uStack_40 = 0;
    uStack_38 = 0;
    _auStack_18 = ZEXT816(0);
    uStack_30 = 0x180181d50;
    uStack_20 = (uint64_t)*(uint32_t *)((int64_t)piVar2 + 0x44);
    piStack_28 = piVar2;
    fcn.1801823b0(*piVar2, &uStack_48);
    return 0;
}

// ============================================================
// Function: FUN_18017f760
// Address: 0x18017f760
// Size: 107 bytes
// ============================================================
undefined8 fcn.18017f760(int64_t arg1)
{
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_10h;
    
    if ((*(int64_t *)(arg1 + 8) != 0) && (*(int32_t *)(*(int64_t *)(arg1 + 8) + 0x20) != 4)) {
        var_48h = 0x1804a7198;
        var_10h = (int64_t)&var_48h;
        var_40h = arg1;
        fcn.180180470(*(undefined8 *)(arg1 + 0x138), &var_48h);
        *(undefined4 *)(arg1 + 600) = 4;
        return 0;
    }
    *(undefined4 *)(arg1 + 600) = 4;
    return 0;
}

// ============================================================
// Function: FUN_18017f7d0
// Address: 0x18017f7d0
// Size: 298 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int32_t fcn.18017f7d0(int64_t arg1, int64_t arg2, int64_t arg_138h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined8 *puVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_18 [8];
    int64_t *piStack_10;
    
    iVar7 = (*(code *)0x8000000000000017)(*(undefined2 *)arg2, 1, 0);
    if (iVar7 < 0) {
        fcn.18047208c(0x1804a70dc);
        return -2;
    }
    iVar8 = fcn.180181e00(*(undefined8 *)(*(int64_t *)(arg1 + 0x138) + 8), iVar7);
    var_10h = iVar8;
    fcn.180184b50(arg2);
    fcn.180174190(iVar8, arg2);
    puVar9 = (undefined8 *)fcn.18017c710(auStack_18, &var_10h);
    uVar4 = *puVar9;
    uVar5 = puVar9[1];
    *puVar9 = 0;
    puVar9[1] = 0;
    piVar6 = *(int64_t **)(arg1 + 0x10);
    *(undefined8 *)(arg1 + 8) = uVar4;
    *(undefined8 *)(arg1 + 0x10) = uVar5;
    if (piVar6 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar6 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar6)(piVar6);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar6 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar6 + 8))(piVar6);
            }
        }
    }
    if (piStack_10 != (int64_t *)0x0) {
        LOCK();
        piVar6 = piStack_10 + 1;
        iVar3 = *(int32_t *)piVar6;
        *(int32_t *)piVar6 = *(int32_t *)piVar6 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piStack_10)(piStack_10);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piStack_10 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piStack_10 + 8))(piStack_10);
            }
        }
    }
    return iVar7;
}

// ============================================================
// Function: FUN_18017f900
// Address: 0x18017f900
// Size: 377 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h

void fcn.18017f900(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    char cVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t *piVar12;
    int64_t unaff_RBX;
    undefined8 in_R8;
    int64_t **arg3;
    undefined8 in_R9;
    int64_t **arg2;
    int64_t var_8h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar4 = *(int64_t *)(arg1 + 0x20);
    piVar5 = *(int64_t **)(arg1 + 0x10);
    piVar6 = *(int64_t **)(iVar4 + 0x90);
    piVar9 = (int64_t *)piVar6[1];
    cVar3 = *(char *)((int64_t)piVar9 + 0x19);
    piVar8 = piVar6;
    while (cVar3 == '\0') {
        piVar12 = piVar9;
        if ((int64_t *)piVar9[4] < piVar5) {
            piVar9 = piVar9 + 2;
            piVar12 = piVar8;
        }
        piVar9 = (int64_t *)*piVar9;
        piVar8 = piVar12;
        cVar3 = *(char *)((int64_t)piVar9 + 0x19);
    }
    var_30h = 0;
    if (((*(char *)((int64_t)piVar8 + 0x19) == '\0') && ((int64_t *)piVar8[4] <= piVar5)) && (piVar8 != piVar6)) {
        if (piVar8[6] != 0) {
            LOCK();
            piVar1 = (int32_t *)(piVar8[6] + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        iVar7 = piVar8[5];
        var_30h = piVar8[6];
        if (*(int32_t *)(iVar7 + 0x48) != -1) {
            *(int32_t *)(iVar7 + 0x48) = *(int32_t *)(iVar7 + 0x48) + -1;
        }
        piVar6 = *(int64_t **)(iVar7 + 0x40);
        if (piVar6 != (int64_t *)0x0) {
            var_8h = (int64_t)piVar5;
            (**(code **)(*piVar6 + 0x10))(piVar6, &var_8h, in_R8, in_R9, iVar7, var_30h);
        }
        if (*(int32_t *)(iVar7 + 0x48) == 0) {
            arg3 = *(int64_t ***)(iVar4 + 0x90);
            ppiVar10 = (int64_t **)arg3[1];
            cVar3 = *(char *)((int64_t)ppiVar10 + 0x19);
            arg2 = arg3;
            ppiVar11 = ppiVar10;
            while (cVar3 == '\0') {
                if (ppiVar11[4] < piVar5) {
                    ppiVar11 = ppiVar11 + 2;
                } else {
                    arg2 = ppiVar11;
                    if ((*(char *)((int64_t)arg3 + 0x19) != '\0') && (piVar5 < ppiVar11[4])) {
                        arg3 = ppiVar11;
                    }
                }
                ppiVar11 = (int64_t **)*ppiVar11;
                cVar3 = *(char *)((int64_t)ppiVar11 + 0x19);
            }
            if (*(char *)((int64_t)arg3 + 0x19) == '\0') {
                ppiVar10 = (int64_t **)*arg3;
            }
            cVar3 = *(char *)((int64_t)ppiVar10 + 0x19);
            while (cVar3 == '\0') {
                if (piVar5 < ppiVar10[4]) {
                    ppiVar11 = (int64_t **)*ppiVar10;
                    arg3 = ppiVar10;
                } else {
                    ppiVar11 = (int64_t **)ppiVar10[2];
                }
                ppiVar10 = ppiVar11;
                cVar3 = *(char *)((int64_t)ppiVar11 + 0x19);
            }
            fcn.18017f090(iVar4 + 0x90, (int64_t)arg2, (int64_t)arg3, unaff_RBX);
        }
    }
    if ((int64_t *)var_30h != (int64_t *)0x0) {
        LOCK();
        piVar5 = (int64_t *)(var_30h + 8);
        iVar2 = *(int32_t *)piVar5;
        *(int32_t *)piVar5 = *(int32_t *)piVar5 + -1;
        UNLOCK();
        if (iVar2 == 1) {
            (***(code ***)var_30h)(var_30h);
            LOCK();
            piVar1 = (int32_t *)(var_30h + 0xc);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)(*(int64_t *)var_30h + 8))(var_30h);
            }
        }
    }
    return;
}

