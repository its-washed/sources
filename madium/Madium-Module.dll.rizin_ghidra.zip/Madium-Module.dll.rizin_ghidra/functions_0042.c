// Chunk 42 - 50 functions

// ============================================================
// Function: FUN_18008d32f
// Address: 0x18008d32f
// Size: 37 bytes
// ============================================================
undefined8 fcn.18008d32f(int64_t arg1, int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    code *pcVar2;
    uint32_t uVar3;
    undefined8 uVar4;
    
    uVar1 = *(uint32_t *)(arg1 + 4);
    uVar3 = fcn.180088860();
    if ((uint64_t)uVar3 + 4 <= (uint64_t)uVar1) {
        fcn.180086570();
        return 1;
    }
    fcn.180088560();
    pcVar2 = (code *)swi(3);
    uVar4 = (*pcVar2)();
    return uVar4;
}

// ============================================================
// Function: FUN_18008d354
// Address: 0x18008d354
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_30h

undefined8 fcn.18008d32f(int64_t arg1, int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    code *pcVar2;
    uint32_t uVar3;
    undefined8 uVar4;
    
    uVar1 = *(uint32_t *)(arg1 + 4);
    uVar3 = fcn.180088860();
    if ((uint64_t)uVar3 + 4 <= (uint64_t)uVar1) {
        fcn.180086570();
        return 1;
    }
    fcn.180088560();
    pcVar2 = (code *)swi(3);
    uVar4 = (*pcVar2)();
    return uVar4;
}

// ============================================================
// Function: FUN_18008d3a0
// Address: 0x18008d3a0
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d3a0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 4 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, (double)*(float *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d3cf
// Address: 0x18008d3cf
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d3a0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 4 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, (double)*(float *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d3f4
// Address: 0x18008d3f4
// Size: 78 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d3a0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 4 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, (double)*(float *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d450
// Address: 0x18008d450
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d450(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 8 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, *(undefined8 *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d47f
// Address: 0x18008d47f
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d450(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 8 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, *(undefined8 *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d4a4
// Address: 0x18008d4a4
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d450(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 8 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, *(undefined8 *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d500
// Address: 0x18008d500
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d500(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    undefined uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar5 = fcn.180088860(arg1, 2);
            uVar4 = fcn.180088a70(arg1, 3);
            if ((uint64_t)uVar5 + 1 <= (uint64_t)uVar2) {
                *(undefined *)((int32_t)uVar5 + iVar1) = uVar4;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008d52f
// Address: 0x18008d52f
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d500(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    undefined uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar5 = fcn.180088860(arg1, 2);
            uVar4 = fcn.180088a70(arg1, 3);
            if ((uint64_t)uVar5 + 1 <= (uint64_t)uVar2) {
                *(undefined *)((int32_t)uVar5 + iVar1) = uVar4;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008d568
// Address: 0x18008d568
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d500(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    undefined uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar5 = fcn.180088860(arg1, 2);
            uVar4 = fcn.180088a70(arg1, 3);
            if ((uint64_t)uVar5 + 1 <= (uint64_t)uVar2) {
                *(undefined *)((int32_t)uVar5 + iVar1) = uVar4;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008d57e
// Address: 0x18008d57e
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d500(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    undefined uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar5 = fcn.180088860(arg1, 2);
            uVar4 = fcn.180088a70(arg1, 3);
            if ((uint64_t)uVar5 + 1 <= (uint64_t)uVar2) {
                *(undefined *)((int32_t)uVar5 + iVar1) = uVar4;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008d592
// Address: 0x18008d592
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d500(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    undefined uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar5 = fcn.180088860(arg1, 2);
            uVar4 = fcn.180088a70(arg1, 3);
            if ((uint64_t)uVar5 + 1 <= (uint64_t)uVar2) {
                *(undefined *)((int32_t)uVar5 + iVar1) = uVar4;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008d5b0
// Address: 0x18008d5b0
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d5b0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    undefined2 uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar5 = fcn.180088860(arg1, 2);
            uVar4 = fcn.180088a70(arg1, 3);
            if ((uint64_t)uVar5 + 2 <= (uint64_t)uVar2) {
                *(undefined2 *)((int32_t)uVar5 + iVar1) = uVar4;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008d5df
// Address: 0x18008d5df
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d5b0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    undefined2 uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar5 = fcn.180088860(arg1, 2);
            uVar4 = fcn.180088a70(arg1, 3);
            if ((uint64_t)uVar5 + 2 <= (uint64_t)uVar2) {
                *(undefined2 *)((int32_t)uVar5 + iVar1) = uVar4;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008d619
// Address: 0x18008d619
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d5b0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    undefined2 uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar5 = fcn.180088860(arg1, 2);
            uVar4 = fcn.180088a70(arg1, 3);
            if ((uint64_t)uVar5 + 2 <= (uint64_t)uVar2) {
                *(undefined2 *)((int32_t)uVar5 + iVar1) = uVar4;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008d630
// Address: 0x18008d630
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d5b0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    undefined2 uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar5 = fcn.180088860(arg1, 2);
            uVar4 = fcn.180088a70(arg1, 3);
            if ((uint64_t)uVar5 + 2 <= (uint64_t)uVar2) {
                *(undefined2 *)((int32_t)uVar5 + iVar1) = uVar4;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008d644
// Address: 0x18008d644
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d5b0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    undefined2 uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar5 = fcn.180088860(arg1, 2);
            uVar4 = fcn.180088a70(arg1, 3);
            if ((uint64_t)uVar5 + 2 <= (uint64_t)uVar2) {
                *(undefined2 *)((int32_t)uVar5 + iVar1) = uVar4;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008d660
// Address: 0x18008d660
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d660(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            uVar5 = fcn.180088a70(arg1, 3);
            if ((uint64_t)uVar4 + 4 <= (uint64_t)uVar2) {
                *(undefined4 *)((int32_t)uVar4 + iVar1) = uVar5;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008d68f
// Address: 0x18008d68f
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d660(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            uVar5 = fcn.180088a70(arg1, 3);
            if ((uint64_t)uVar4 + 4 <= (uint64_t)uVar2) {
                *(undefined4 *)((int32_t)uVar4 + iVar1) = uVar5;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008d6c9
// Address: 0x18008d6c9
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d660(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            uVar5 = fcn.180088a70(arg1, 3);
            if ((uint64_t)uVar4 + 4 <= (uint64_t)uVar2) {
                *(undefined4 *)((int32_t)uVar4 + iVar1) = uVar5;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008d6df
// Address: 0x18008d6df
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d660(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            uVar5 = fcn.180088a70(arg1, 3);
            if ((uint64_t)uVar4 + 4 <= (uint64_t)uVar2) {
                *(undefined4 *)((int32_t)uVar4 + iVar1) = uVar5;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008d6f3
// Address: 0x18008d6f3
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d660(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            uVar5 = fcn.180088a70(arg1, 3);
            if ((uint64_t)uVar4 + 4 <= (uint64_t)uVar2) {
                *(undefined4 *)((int32_t)uVar4 + iVar1) = uVar5;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008d710
// Address: 0x18008d710
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d710(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    double dVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar5 = fcn.180088860(arg1, 2);
            dVar4 = (double)fcn.180085ea0(arg1, 3, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, 3, 3);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            if ((uint64_t)uVar5 + 4 <= (uint64_t)uVar2) {
                *(float *)((int32_t)uVar5 + iVar1) = (float)dVar4;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008d73f
// Address: 0x18008d73f
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d710(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    double dVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar5 = fcn.180088860(arg1, 2);
            dVar4 = (double)fcn.180085ea0(arg1, 3, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, 3, 3);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            if ((uint64_t)uVar5 + 4 <= (uint64_t)uVar2) {
                *(float *)((int32_t)uVar5 + iVar1) = (float)dVar4;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008d7a8
// Address: 0x18008d7a8
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d710(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    double dVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar5 = fcn.180088860(arg1, 2);
            dVar4 = (double)fcn.180085ea0(arg1, 3, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, 3, 3);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            if ((uint64_t)uVar5 + 4 <= (uint64_t)uVar2) {
                *(float *)((int32_t)uVar5 + iVar1) = (float)dVar4;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008d7bc
// Address: 0x18008d7bc
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d710(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    double dVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar5 = fcn.180088860(arg1, 2);
            dVar4 = (double)fcn.180085ea0(arg1, 3, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, 3, 3);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            if ((uint64_t)uVar5 + 4 <= (uint64_t)uVar2) {
                *(float *)((int32_t)uVar5 + iVar1) = (float)dVar4;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008d7e0
// Address: 0x18008d7e0
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d7e0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            uVar6 = fcn.180085ea0(arg1, 3, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, 3, 3);
                pcVar3 = (code *)swi(3);
                uVar6 = (*pcVar3)();
                return uVar6;
            }
            if ((uint64_t)uVar4 + 8 <= (uint64_t)uVar2) {
                *(undefined8 *)((int32_t)uVar4 + iVar1) = uVar6;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d80f
// Address: 0x18008d80f
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d7e0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            uVar6 = fcn.180085ea0(arg1, 3, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, 3, 3);
                pcVar3 = (code *)swi(3);
                uVar6 = (*pcVar3)();
                return uVar6;
            }
            if ((uint64_t)uVar4 + 8 <= (uint64_t)uVar2) {
                *(undefined8 *)((int32_t)uVar4 + iVar1) = uVar6;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d876
// Address: 0x18008d876
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d7e0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            uVar6 = fcn.180085ea0(arg1, 3, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, 3, 3);
                pcVar3 = (code *)swi(3);
                uVar6 = (*pcVar3)();
                return uVar6;
            }
            if ((uint64_t)uVar4 + 8 <= (uint64_t)uVar2) {
                *(undefined8 *)((int32_t)uVar4 + iVar1) = uVar6;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d88a
// Address: 0x18008d88a
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008d7e0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            uVar6 = fcn.180085ea0(arg1, 3, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, 3, 3);
                pcVar3 = (code *)swi(3);
                uVar6 = (*pcVar3)();
                return uVar6;
            }
            if ((uint64_t)uVar4 + 8 <= (uint64_t)uVar2) {
                *(undefined8 *)((int32_t)uVar4 + iVar1) = uVar6;
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d920
// Address: 0x18008d920
// Size: 72 bytes
// ============================================================
undefined8
fcn.18008d920(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    undefined8 uVar1;
    int64_t in_stack_00000038;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        uVar1 = fcn.18048e730(in_stack_00000038);
        *(undefined8 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 3;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008d970
// Address: 0x18008d970
// Size: 72 bytes
// ============================================================
undefined8
fcn.18008d970(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t placeholder_4, int64_t arg_30h
             )
{
    undefined8 uVar1;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        uVar1 = fcn.18048ec30(placeholder_4);
        *(undefined8 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 3;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008d9c0
// Address: 0x18008d9c0
// Size: 87 bytes
// ============================================================
undefined8
fcn.18008d9c0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    
    if ((((1 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) &&
       (*(int32_t *)(arg_28h + 0xc) == 3)) {
        uVar1 = fcn.18048f110(*(undefined8 *)arg3, *(undefined8 *)arg_28h);
        *(undefined8 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 3;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008da20
// Address: 0x18008da20
// Size: 72 bytes
// ============================================================
undefined8
fcn.18008da20(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    int64_t unaff_RBX;
    undefined8 uVar1;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        uVar1 = fcn.18048eec0(unaff_RBX);
        *(undefined8 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 3;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008dae0
// Address: 0x18008dae0
// Size: 72 bytes
// ============================================================
undefined8
fcn.18008dae0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    undefined8 uVar1;
    int64_t in_stack_00000048;
    int64_t in_stack_00000058;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        uVar1 = fcn.1804901d0(in_stack_00000048, in_stack_00000058);
        *(undefined8 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 3;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008db30
// Address: 0x18008db30
// Size: 72 bytes
// ============================================================
undefined8
fcn.18008db30(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    undefined8 uVar1;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        uVar1 = fcn.18048f790(*(undefined8 *)arg3);
        *(undefined8 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 3;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008dbc0
// Address: 0x18008dbc0
// Size: 72 bytes
// ============================================================
undefined8
fcn.18008dbc0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    undefined8 uVar1;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        uVar1 = fcn.1804905c0(*(undefined8 *)arg3);
        *(undefined8 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 3;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008dc80
// Address: 0x18008dc80
// Size: 87 bytes
// ============================================================
undefined8
fcn.18008dc80(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    
    if ((((1 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) &&
       (*(int32_t *)(arg_28h + 0xc) == 3)) {
        uVar1 = fcn.180490b30(*(undefined8 *)arg3, *(undefined8 *)arg_28h);
        *(undefined8 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 3;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008dce0
// Address: 0x18008dce0
// Size: 99 bytes
// ============================================================
undefined8
fcn.18008dce0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    undefined8 uVar1;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 3)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        uVar1 = fcn.180467d50(*(undefined8 *)arg3, &arg_30h);
        *(undefined8 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 3;
        *(undefined4 *)(arg2 + 0x1c) = 3;
        *(double *)(arg2 + 0x10) = (double)(int32_t)arg_30h;
        return 2;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008dd50
// Address: 0x18008dd50
// Size: 87 bytes
// ============================================================
undefined8
fcn.18008dd50(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    int64_t in_stack_00000008;
    
    if ((((1 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) &&
       (*(int32_t *)(arg_28h + 0xc) == 3)) {
        uVar1 = fcn.18046d9a0(in_stack_00000008);
        *(undefined8 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 3;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008ddb0
// Address: 0x18008ddb0
// Size: 72 bytes
// ============================================================
undefined8
fcn.18008ddb0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    undefined8 uVar1;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        uVar1 = fcn.18048d7c0(*(undefined8 *)arg3);
        *(undefined8 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 3;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008de00
// Address: 0x18008de00
// Size: 91 bytes
// ============================================================
undefined8
fcn.18008de00(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t unaff_RBX;
    undefined8 uVar1;
    double dVar2;
    double dVar3;
    int64_t var_28h;
    int64_t var_18h;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        uVar1 = *(undefined8 *)arg3;
        if ((int32_t)arg_30h == 1) {
            uVar1 = fcn.180491150(uVar1);
            *(undefined8 *)arg2 = uVar1;
            *(undefined4 *)(arg2 + 0xc) = 3;
            return 1;
        }
        if (*(int32_t *)(arg_28h + 0xc) == 3) {
            dVar3 = *(double *)arg_28h;
            *(undefined4 *)(arg2 + 0xc) = 3;
            if (dVar3 == 2.0) {
                uVar1 = fcn.180491680(unaff_RBX);
            } else {
                if (dVar3 != 10.0) {
                    dVar2 = (double)fcn.180491150(uVar1);
                    dVar3 = (double)fcn.180491150(dVar3);
                    *(double *)arg2 = dVar2 / dVar3;
                    return 1;
                }
                uVar1 = fcn.18048d7c0();
            }
            *(undefined8 *)arg2 = uVar1;
            return 1;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008de5b
// Address: 0x18008de5b
// Size: 53 bytes
// ============================================================
undefined8
fcn.18008de00(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t unaff_RBX;
    undefined8 uVar1;
    double dVar2;
    double dVar3;
    int64_t var_28h;
    int64_t var_18h;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        uVar1 = *(undefined8 *)arg3;
        if ((int32_t)arg_30h == 1) {
            uVar1 = fcn.180491150(uVar1);
            *(undefined8 *)arg2 = uVar1;
            *(undefined4 *)(arg2 + 0xc) = 3;
            return 1;
        }
        if (*(int32_t *)(arg_28h + 0xc) == 3) {
            dVar3 = *(double *)arg_28h;
            *(undefined4 *)(arg2 + 0xc) = 3;
            if (dVar3 == 2.0) {
                uVar1 = fcn.180491680(unaff_RBX);
            } else {
                if (dVar3 != 10.0) {
                    dVar2 = (double)fcn.180491150(uVar1);
                    dVar3 = (double)fcn.180491150(dVar3);
                    *(double *)arg2 = dVar2 / dVar3;
                    return 1;
                }
                uVar1 = fcn.18048d7c0();
            }
            *(undefined8 *)arg2 = uVar1;
            return 1;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008de90
// Address: 0x18008de90
// Size: 69 bytes
// ============================================================
undefined8
fcn.18008de00(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t unaff_RBX;
    undefined8 uVar1;
    double dVar2;
    double dVar3;
    int64_t var_28h;
    int64_t var_18h;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        uVar1 = *(undefined8 *)arg3;
        if ((int32_t)arg_30h == 1) {
            uVar1 = fcn.180491150(uVar1);
            *(undefined8 *)arg2 = uVar1;
            *(undefined4 *)(arg2 + 0xc) = 3;
            return 1;
        }
        if (*(int32_t *)(arg_28h + 0xc) == 3) {
            dVar3 = *(double *)arg_28h;
            *(undefined4 *)(arg2 + 0xc) = 3;
            if (dVar3 == 2.0) {
                uVar1 = fcn.180491680(unaff_RBX);
            } else {
                if (dVar3 != 10.0) {
                    dVar2 = (double)fcn.180491150(uVar1);
                    dVar3 = (double)fcn.180491150(dVar3);
                    *(double *)arg2 = dVar2 / dVar3;
                    return 1;
                }
                uVar1 = fcn.18048d7c0();
            }
            *(undefined8 *)arg2 = uVar1;
            return 1;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008ded5
// Address: 0x18008ded5
// Size: 11 bytes
// ============================================================
undefined8
fcn.18008de00(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t unaff_RBX;
    undefined8 uVar1;
    double dVar2;
    double dVar3;
    int64_t var_28h;
    int64_t var_18h;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        uVar1 = *(undefined8 *)arg3;
        if ((int32_t)arg_30h == 1) {
            uVar1 = fcn.180491150(uVar1);
            *(undefined8 *)arg2 = uVar1;
            *(undefined4 *)(arg2 + 0xc) = 3;
            return 1;
        }
        if (*(int32_t *)(arg_28h + 0xc) == 3) {
            dVar3 = *(double *)arg_28h;
            *(undefined4 *)(arg2 + 0xc) = 3;
            if (dVar3 == 2.0) {
                uVar1 = fcn.180491680(unaff_RBX);
            } else {
                if (dVar3 != 10.0) {
                    dVar2 = (double)fcn.180491150(uVar1);
                    dVar3 = (double)fcn.180491150(dVar3);
                    *(double *)arg2 = dVar2 / dVar3;
                    return 1;
                }
                uVar1 = fcn.18048d7c0();
            }
            *(undefined8 *)arg2 = uVar1;
            return 1;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008e000
// Address: 0x18008e000
// Size: 95 bytes
// ============================================================
undefined8
fcn.18008e000(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    undefined8 uVar1;
    int64_t var_18h;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 3)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        uVar1 = fcn.18046df90(*(undefined8 *)arg3, &var_18h);
        *(int64_t *)arg2 = var_18h;
        *(undefined8 *)(arg2 + 0x10) = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 3;
        *(undefined4 *)(arg2 + 0x1c) = 3;
        return 2;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008e060
// Address: 0x18008e060
// Size: 87 bytes
// ============================================================
undefined8
fcn.18008e060(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    
    if ((((1 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) &&
       (*(int32_t *)(arg_28h + 0xc) == 3)) {
        uVar1 = fcn.180491d70(*(undefined8 *)arg3, *(undefined8 *)arg_28h);
        *(undefined8 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 3;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008e100
// Address: 0x18008e100
// Size: 72 bytes
// ============================================================
undefined8
fcn.18008e100(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    undefined8 uVar1;
    int64_t in_stack_00000048;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        uVar1 = fcn.180494070(in_stack_00000048);
        *(undefined8 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 3;
        return 1;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18008e150
// Address: 0x18008e150
// Size: 72 bytes
// ============================================================
undefined8
fcn.18008e150(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h)
{
    undefined8 uVar1;
    int64_t in_stack_00000008;
    
    if (((0 < (int32_t)arg_30h) && ((int32_t)arg4 < 2)) && (*(int32_t *)(arg3 + 0xc) == 3)) {
        uVar1 = fcn.180493440(in_stack_00000008);
        *(undefined8 *)arg2 = uVar1;
        *(undefined4 *)(arg2 + 0xc) = 3;
        return 1;
    }
    return 0xffffffff;
}

