// Chunk 41 - 50 functions

// ============================================================
// Function: FUN_18008c310
// Address: 0x18008c310
// Size: 51 bytes
// ============================================================
undefined8 fcn.18008c310(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = func_0x000180088860(arg1, 2);
            piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
            piVar5 = piVar7;
            if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
                piVar5 = *(int64_t **)0x180782430;
            }
            if ((piVar5 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar5 + 0xc) != 4)) {
                func_0x000180088470(arg1, 3, 4);
                pcVar3 = (code *)swi(3);
                uVar6 = (*pcVar3)();
                return uVar6;
            }
            if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
                piVar7 = *(int64_t **)0x180782430;
            }
            if (*(int32_t *)((int64_t)piVar7 + 0xc) == 4) {
                iVar8 = *piVar7;
            } else {
                iVar8 = 0;
            }
            if ((uint64_t)uVar4 + 8 <= (uint64_t)uVar2) {
                *(int64_t *)((int32_t)uVar4 + iVar1) = iVar8;
                return 0;
            }
            func_0x000180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    func_0x000180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008c343
// Address: 0x18008c343
// Size: 118 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18008c310(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = func_0x000180088860(arg1, 2);
            piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
            piVar5 = piVar7;
            if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
                piVar5 = *(int64_t **)0x180782430;
            }
            if ((piVar5 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar5 + 0xc) != 4)) {
                func_0x000180088470(arg1, 3, 4);
                pcVar3 = (code *)swi(3);
                uVar6 = (*pcVar3)();
                return uVar6;
            }
            if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
                piVar7 = *(int64_t **)0x180782430;
            }
            if (*(int32_t *)((int64_t)piVar7 + 0xc) == 4) {
                iVar8 = *piVar7;
            } else {
                iVar8 = 0;
            }
            if ((uint64_t)uVar4 + 8 <= (uint64_t)uVar2) {
                *(int64_t *)((int32_t)uVar4 + iVar1) = iVar8;
                return 0;
            }
            func_0x000180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    func_0x000180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008c3b9
// Address: 0x18008c3b9
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18008c310(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = func_0x000180088860(arg1, 2);
            piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
            piVar5 = piVar7;
            if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
                piVar5 = *(int64_t **)0x180782430;
            }
            if ((piVar5 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar5 + 0xc) != 4)) {
                func_0x000180088470(arg1, 3, 4);
                pcVar3 = (code *)swi(3);
                uVar6 = (*pcVar3)();
                return uVar6;
            }
            if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
                piVar7 = *(int64_t **)0x180782430;
            }
            if (*(int32_t *)((int64_t)piVar7 + 0xc) == 4) {
                iVar8 = *piVar7;
            } else {
                iVar8 = 0;
            }
            if ((uint64_t)uVar4 + 8 <= (uint64_t)uVar2) {
                *(int64_t *)((int32_t)uVar4 + iVar1) = iVar8;
                return 0;
            }
            func_0x000180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    func_0x000180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008c3cd
// Address: 0x18008c3cd
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18008c310(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = func_0x000180088860(arg1, 2);
            piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
            piVar5 = piVar7;
            if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
                piVar5 = *(int64_t **)0x180782430;
            }
            if ((piVar5 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar5 + 0xc) != 4)) {
                func_0x000180088470(arg1, 3, 4);
                pcVar3 = (code *)swi(3);
                uVar6 = (*pcVar3)();
                return uVar6;
            }
            if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
                piVar7 = *(int64_t **)0x180782430;
            }
            if (*(int32_t *)((int64_t)piVar7 + 0xc) == 4) {
                iVar8 = *piVar7;
            } else {
                iVar8 = 0;
            }
            if ((uint64_t)uVar4 + 8 <= (uint64_t)uVar2) {
                *(int64_t *)((int32_t)uVar4 + iVar1) = iVar8;
                return 0;
            }
            func_0x000180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    func_0x000180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008c400
// Address: 0x18008c400
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008c400(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            uVar5 = fcn.180088860(arg1, 3);
            if ((int32_t)uVar5 < 0) {
                fcn.180088380(arg1, 3, 0x18063dcac);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            if ((uint64_t)uVar4 + (uint64_t)uVar5 <= (uint64_t)uVar2) {
                fcn.1800867f0(arg1, iVar1 + (int32_t)uVar4, (int64_t)(int32_t)uVar5);
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008c42f
// Address: 0x18008c42f
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008c400(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            uVar5 = fcn.180088860(arg1, 3);
            if ((int32_t)uVar5 < 0) {
                fcn.180088380(arg1, 3, 0x18063dcac);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            if ((uint64_t)uVar4 + (uint64_t)uVar5 <= (uint64_t)uVar2) {
                fcn.1800867f0(arg1, iVar1 + (int32_t)uVar4, (int64_t)(int32_t)uVar5);
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008c492
// Address: 0x18008c492
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008c400(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            uVar5 = fcn.180088860(arg1, 3);
            if ((int32_t)uVar5 < 0) {
                fcn.180088380(arg1, 3, 0x18063dcac);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            if ((uint64_t)uVar4 + (uint64_t)uVar5 <= (uint64_t)uVar2) {
                fcn.1800867f0(arg1, iVar1 + (int32_t)uVar4, (int64_t)(int32_t)uVar5);
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008c4a6
// Address: 0x18008c4a6
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008c400(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            uVar5 = fcn.180088860(arg1, 3);
            if ((int32_t)uVar5 < 0) {
                fcn.180088380(arg1, 3, 0x18063dcac);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            if ((uint64_t)uVar4 + (uint64_t)uVar5 <= (uint64_t)uVar2) {
                fcn.1800867f0(arg1, iVar1 + (int32_t)uVar4, (int64_t)(int32_t)uVar5);
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008c4d0
// Address: 0x18008c4d0
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008c4d0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 0xb) {
code_r0x00018008c62e:
        fcn.180088470(arg1, 1, 0xb);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    iVar1 = *piVar8 + 8;
    if (iVar1 == 0) goto code_r0x00018008c62e;
    uVar3 = *(uint32_t *)(*piVar8 + 4);
    uVar5 = fcn.180088860(arg1, 2);
    iVar12 = *(int64_t *)(arg1 + 0x28);
    piVar8 = *(int64_t **)(arg1 + 0x40);
    piVar9 = (int64_t *)(iVar12 + 0x20U);
    if (piVar8 <= (int64_t *)(iVar12 + 0x20U)) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar6 = func_0x0001800a8360(arg1);
        if (iVar6 == 0) goto code_r0x00018008c642;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        iVar12 = *(int64_t *)(arg1 + 0x28);
        piVar8 = *(int64_t **)(arg1 + 0x40);
        piVar9 = (int64_t *)(iVar12 + 0x20U);
        if (piVar8 <= (int64_t *)(iVar12 + 0x20U)) {
            piVar9 = *(int64_t **)0x180782430;
        }
    }
    iVar2 = *piVar9 + 0x18;
    if (iVar2 != 0) {
        uVar7 = *(uint32_t *)(*piVar9 + 0x14);
        uVar11 = (uint64_t)uVar7;
        piVar9 = (int64_t *)(iVar12 + 0x30U);
        if (piVar8 <= (int64_t *)(iVar12 + 0x30U)) {
            piVar9 = *(int64_t **)0x180782430;
        }
        if ((piVar9 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar9 + 0xc))) {
            uVar7 = fcn.180088860(arg1, 4);
        }
        if ((int32_t)uVar7 < 0) {
            fcn.180088380(arg1, 4, 0x18063dd08);
            pcVar4 = (code *)swi(3);
            uVar10 = (*pcVar4)();
            return uVar10;
        }
        if (uVar11 < (uint64_t)(int64_t)(int32_t)uVar7) {
            fcn.180088560(arg1, 0x18063dcf0);
            pcVar4 = (code *)swi(3);
            uVar10 = (*pcVar4)();
            return uVar10;
        }
        if ((uint64_t)uVar3 < (uint64_t)uVar5 + (uint64_t)uVar7) {
            fcn.180088560(arg1, 0x18063dc90);
            pcVar4 = (code *)swi(3);
            uVar10 = (*pcVar4)();
            return uVar10;
        }
        func_0x000180498030((int32_t)uVar5 + iVar1, iVar2);
        return 0;
    }
code_r0x00018008c642:
    fcn.180088470(arg1, 3, 6);
    pcVar4 = (code *)swi(3);
    uVar10 = (*pcVar4)();
    return uVar10;
}

// ============================================================
// Function: FUN_18008c504
// Address: 0x18008c504
// Size: 298 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008c4d0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 0xb) {
code_r0x00018008c62e:
        fcn.180088470(arg1, 1, 0xb);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    iVar1 = *piVar8 + 8;
    if (iVar1 == 0) goto code_r0x00018008c62e;
    uVar3 = *(uint32_t *)(*piVar8 + 4);
    uVar5 = fcn.180088860(arg1, 2);
    iVar12 = *(int64_t *)(arg1 + 0x28);
    piVar8 = *(int64_t **)(arg1 + 0x40);
    piVar9 = (int64_t *)(iVar12 + 0x20U);
    if (piVar8 <= (int64_t *)(iVar12 + 0x20U)) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar6 = func_0x0001800a8360(arg1);
        if (iVar6 == 0) goto code_r0x00018008c642;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        iVar12 = *(int64_t *)(arg1 + 0x28);
        piVar8 = *(int64_t **)(arg1 + 0x40);
        piVar9 = (int64_t *)(iVar12 + 0x20U);
        if (piVar8 <= (int64_t *)(iVar12 + 0x20U)) {
            piVar9 = *(int64_t **)0x180782430;
        }
    }
    iVar2 = *piVar9 + 0x18;
    if (iVar2 != 0) {
        uVar7 = *(uint32_t *)(*piVar9 + 0x14);
        uVar11 = (uint64_t)uVar7;
        piVar9 = (int64_t *)(iVar12 + 0x30U);
        if (piVar8 <= (int64_t *)(iVar12 + 0x30U)) {
            piVar9 = *(int64_t **)0x180782430;
        }
        if ((piVar9 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar9 + 0xc))) {
            uVar7 = fcn.180088860(arg1, 4);
        }
        if ((int32_t)uVar7 < 0) {
            fcn.180088380(arg1, 4, 0x18063dd08);
            pcVar4 = (code *)swi(3);
            uVar10 = (*pcVar4)();
            return uVar10;
        }
        if (uVar11 < (uint64_t)(int64_t)(int32_t)uVar7) {
            fcn.180088560(arg1, 0x18063dcf0);
            pcVar4 = (code *)swi(3);
            uVar10 = (*pcVar4)();
            return uVar10;
        }
        if ((uint64_t)uVar3 < (uint64_t)uVar5 + (uint64_t)uVar7) {
            fcn.180088560(arg1, 0x18063dc90);
            pcVar4 = (code *)swi(3);
            uVar10 = (*pcVar4)();
            return uVar10;
        }
        func_0x000180498030((int32_t)uVar5 + iVar1, iVar2);
        return 0;
    }
code_r0x00018008c642:
    fcn.180088470(arg1, 3, 6);
    pcVar4 = (code *)swi(3);
    uVar10 = (*pcVar4)();
    return uVar10;
}

// ============================================================
// Function: FUN_18008c62e
// Address: 0x18008c62e
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008c4d0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 0xb) {
code_r0x00018008c62e:
        fcn.180088470(arg1, 1, 0xb);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    iVar1 = *piVar8 + 8;
    if (iVar1 == 0) goto code_r0x00018008c62e;
    uVar3 = *(uint32_t *)(*piVar8 + 4);
    uVar5 = fcn.180088860(arg1, 2);
    iVar12 = *(int64_t *)(arg1 + 0x28);
    piVar8 = *(int64_t **)(arg1 + 0x40);
    piVar9 = (int64_t *)(iVar12 + 0x20U);
    if (piVar8 <= (int64_t *)(iVar12 + 0x20U)) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar6 = func_0x0001800a8360(arg1);
        if (iVar6 == 0) goto code_r0x00018008c642;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        iVar12 = *(int64_t *)(arg1 + 0x28);
        piVar8 = *(int64_t **)(arg1 + 0x40);
        piVar9 = (int64_t *)(iVar12 + 0x20U);
        if (piVar8 <= (int64_t *)(iVar12 + 0x20U)) {
            piVar9 = *(int64_t **)0x180782430;
        }
    }
    iVar2 = *piVar9 + 0x18;
    if (iVar2 != 0) {
        uVar7 = *(uint32_t *)(*piVar9 + 0x14);
        uVar11 = (uint64_t)uVar7;
        piVar9 = (int64_t *)(iVar12 + 0x30U);
        if (piVar8 <= (int64_t *)(iVar12 + 0x30U)) {
            piVar9 = *(int64_t **)0x180782430;
        }
        if ((piVar9 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar9 + 0xc))) {
            uVar7 = fcn.180088860(arg1, 4);
        }
        if ((int32_t)uVar7 < 0) {
            fcn.180088380(arg1, 4, 0x18063dd08);
            pcVar4 = (code *)swi(3);
            uVar10 = (*pcVar4)();
            return uVar10;
        }
        if (uVar11 < (uint64_t)(int64_t)(int32_t)uVar7) {
            fcn.180088560(arg1, 0x18063dcf0);
            pcVar4 = (code *)swi(3);
            uVar10 = (*pcVar4)();
            return uVar10;
        }
        if ((uint64_t)uVar3 < (uint64_t)uVar5 + (uint64_t)uVar7) {
            fcn.180088560(arg1, 0x18063dc90);
            pcVar4 = (code *)swi(3);
            uVar10 = (*pcVar4)();
            return uVar10;
        }
        func_0x000180498030((int32_t)uVar5 + iVar1, iVar2);
        return 0;
    }
code_r0x00018008c642:
    fcn.180088470(arg1, 3, 6);
    pcVar4 = (code *)swi(3);
    uVar10 = (*pcVar4)();
    return uVar10;
}

// ============================================================
// Function: FUN_18008c642
// Address: 0x18008c642
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008c4d0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 0xb) {
code_r0x00018008c62e:
        fcn.180088470(arg1, 1, 0xb);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    iVar1 = *piVar8 + 8;
    if (iVar1 == 0) goto code_r0x00018008c62e;
    uVar3 = *(uint32_t *)(*piVar8 + 4);
    uVar5 = fcn.180088860(arg1, 2);
    iVar12 = *(int64_t *)(arg1 + 0x28);
    piVar8 = *(int64_t **)(arg1 + 0x40);
    piVar9 = (int64_t *)(iVar12 + 0x20U);
    if (piVar8 <= (int64_t *)(iVar12 + 0x20U)) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar6 = func_0x0001800a8360(arg1);
        if (iVar6 == 0) goto code_r0x00018008c642;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        iVar12 = *(int64_t *)(arg1 + 0x28);
        piVar8 = *(int64_t **)(arg1 + 0x40);
        piVar9 = (int64_t *)(iVar12 + 0x20U);
        if (piVar8 <= (int64_t *)(iVar12 + 0x20U)) {
            piVar9 = *(int64_t **)0x180782430;
        }
    }
    iVar2 = *piVar9 + 0x18;
    if (iVar2 != 0) {
        uVar7 = *(uint32_t *)(*piVar9 + 0x14);
        uVar11 = (uint64_t)uVar7;
        piVar9 = (int64_t *)(iVar12 + 0x30U);
        if (piVar8 <= (int64_t *)(iVar12 + 0x30U)) {
            piVar9 = *(int64_t **)0x180782430;
        }
        if ((piVar9 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar9 + 0xc))) {
            uVar7 = fcn.180088860(arg1, 4);
        }
        if ((int32_t)uVar7 < 0) {
            fcn.180088380(arg1, 4, 0x18063dd08);
            pcVar4 = (code *)swi(3);
            uVar10 = (*pcVar4)();
            return uVar10;
        }
        if (uVar11 < (uint64_t)(int64_t)(int32_t)uVar7) {
            fcn.180088560(arg1, 0x18063dcf0);
            pcVar4 = (code *)swi(3);
            uVar10 = (*pcVar4)();
            return uVar10;
        }
        if ((uint64_t)uVar3 < (uint64_t)uVar5 + (uint64_t)uVar7) {
            fcn.180088560(arg1, 0x18063dc90);
            pcVar4 = (code *)swi(3);
            uVar10 = (*pcVar4)();
            return uVar10;
        }
        func_0x000180498030((int32_t)uVar5 + iVar1, iVar2);
        return 0;
    }
code_r0x00018008c642:
    fcn.180088470(arg1, 3, 6);
    pcVar4 = (code *)swi(3);
    uVar10 = (*pcVar4)();
    return uVar10;
}

// ============================================================
// Function: FUN_18008c656
// Address: 0x18008c656
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008c4d0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    undefined8 uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 0xb) {
code_r0x00018008c62e:
        fcn.180088470(arg1, 1, 0xb);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    iVar1 = *piVar8 + 8;
    if (iVar1 == 0) goto code_r0x00018008c62e;
    uVar3 = *(uint32_t *)(*piVar8 + 4);
    uVar5 = fcn.180088860(arg1, 2);
    iVar12 = *(int64_t *)(arg1 + 0x28);
    piVar8 = *(int64_t **)(arg1 + 0x40);
    piVar9 = (int64_t *)(iVar12 + 0x20U);
    if (piVar8 <= (int64_t *)(iVar12 + 0x20U)) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar6 = func_0x0001800a8360(arg1);
        if (iVar6 == 0) goto code_r0x00018008c642;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        iVar12 = *(int64_t *)(arg1 + 0x28);
        piVar8 = *(int64_t **)(arg1 + 0x40);
        piVar9 = (int64_t *)(iVar12 + 0x20U);
        if (piVar8 <= (int64_t *)(iVar12 + 0x20U)) {
            piVar9 = *(int64_t **)0x180782430;
        }
    }
    iVar2 = *piVar9 + 0x18;
    if (iVar2 != 0) {
        uVar7 = *(uint32_t *)(*piVar9 + 0x14);
        uVar11 = (uint64_t)uVar7;
        piVar9 = (int64_t *)(iVar12 + 0x30U);
        if (piVar8 <= (int64_t *)(iVar12 + 0x30U)) {
            piVar9 = *(int64_t **)0x180782430;
        }
        if ((piVar9 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar9 + 0xc))) {
            uVar7 = fcn.180088860(arg1, 4);
        }
        if ((int32_t)uVar7 < 0) {
            fcn.180088380(arg1, 4, 0x18063dd08);
            pcVar4 = (code *)swi(3);
            uVar10 = (*pcVar4)();
            return uVar10;
        }
        if (uVar11 < (uint64_t)(int64_t)(int32_t)uVar7) {
            fcn.180088560(arg1, 0x18063dcf0);
            pcVar4 = (code *)swi(3);
            uVar10 = (*pcVar4)();
            return uVar10;
        }
        if ((uint64_t)uVar3 < (uint64_t)uVar5 + (uint64_t)uVar7) {
            fcn.180088560(arg1, 0x18063dc90);
            pcVar4 = (code *)swi(3);
            uVar10 = (*pcVar4)();
            return uVar10;
        }
        func_0x000180498030((int32_t)uVar5 + iVar1, iVar2);
        return 0;
    }
code_r0x00018008c642:
    fcn.180088470(arg1, 3, 6);
    pcVar4 = (code *)swi(3);
    uVar10 = (*pcVar4)();
    return uVar10;
}

// ============================================================
// Function: FUN_18008c690
// Address: 0x18008c690
// Size: 81 bytes
// ============================================================
undefined8 fcn.18008c690(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    
    piVar2 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar2 = *(int64_t **)0x180782430;
    }
    if ((*(int32_t *)((int64_t)piVar2 + 0xc) == 0xb) && (*piVar2 != -8)) {
        fcn.180086570(arg1, (double)(uint64_t)*(uint32_t *)(*piVar2 + 4));
        return 1;
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_18008c6f0
// Address: 0x18008c6f0
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008c6f0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    code *pcVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    undefined8 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar10 + 0xc) == 0xb) {
        iVar1 = *piVar10 + 8;
        if (iVar1 != 0) {
            uVar3 = *(uint32_t *)(*piVar10 + 4);
            uVar6 = fcn.180088860(arg1, 2);
            piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
            if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
                piVar10 = *(int64_t **)0x180782430;
            }
            if (*(int32_t *)((int64_t)piVar10 + 0xc) == 0xb) {
                iVar2 = *piVar10 + 8;
                if (iVar2 != 0) {
                    piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x30);
                    uVar4 = *(uint32_t *)(*piVar10 + 4);
                    if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
                        piVar9 = *(int64_t **)0x180782430;
                    }
                    if ((piVar9 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar9 + 0xc) < 1)) {
                        uVar7 = 0;
                    } else {
                        uVar7 = fcn.180088860(arg1, 4);
                    }
                    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x40);
                    if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) < 1)) {
                        uVar8 = uVar4 - uVar7;
                    } else {
                        uVar8 = fcn.180088860(arg1, 5);
                    }
                    if (((-1 < (int32_t)uVar8) && ((uint64_t)uVar7 + (uint64_t)uVar8 <= (uint64_t)uVar4)) &&
                       ((uint64_t)uVar6 + (uint64_t)uVar8 <= (uint64_t)uVar3)) {
                        func_0x000180498030(iVar1 + (int32_t)uVar6, (int32_t)uVar7 + iVar2, (int64_t)(int32_t)uVar8);
                        return 0;
                    }
                    fcn.180088560(arg1, 0x18063dc90);
                    pcVar5 = (code *)swi(3);
                    uVar11 = (*pcVar5)();
                    return uVar11;
                }
            }
            fcn.180088470(arg1, 3, 0xb);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar5 = (code *)swi(3);
    uVar11 = (*pcVar5)();
    return uVar11;
}

// ============================================================
// Function: FUN_18008c724
// Address: 0x18008c724
// Size: 278 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008c6f0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    code *pcVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    undefined8 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar10 + 0xc) == 0xb) {
        iVar1 = *piVar10 + 8;
        if (iVar1 != 0) {
            uVar3 = *(uint32_t *)(*piVar10 + 4);
            uVar6 = fcn.180088860(arg1, 2);
            piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
            if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
                piVar10 = *(int64_t **)0x180782430;
            }
            if (*(int32_t *)((int64_t)piVar10 + 0xc) == 0xb) {
                iVar2 = *piVar10 + 8;
                if (iVar2 != 0) {
                    piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x30);
                    uVar4 = *(uint32_t *)(*piVar10 + 4);
                    if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
                        piVar9 = *(int64_t **)0x180782430;
                    }
                    if ((piVar9 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar9 + 0xc) < 1)) {
                        uVar7 = 0;
                    } else {
                        uVar7 = fcn.180088860(arg1, 4);
                    }
                    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x40);
                    if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) < 1)) {
                        uVar8 = uVar4 - uVar7;
                    } else {
                        uVar8 = fcn.180088860(arg1, 5);
                    }
                    if (((-1 < (int32_t)uVar8) && ((uint64_t)uVar7 + (uint64_t)uVar8 <= (uint64_t)uVar4)) &&
                       ((uint64_t)uVar6 + (uint64_t)uVar8 <= (uint64_t)uVar3)) {
                        func_0x000180498030(iVar1 + (int32_t)uVar6, (int32_t)uVar7 + iVar2, (int64_t)(int32_t)uVar8);
                        return 0;
                    }
                    fcn.180088560(arg1, 0x18063dc90);
                    pcVar5 = (code *)swi(3);
                    uVar11 = (*pcVar5)();
                    return uVar11;
                }
            }
            fcn.180088470(arg1, 3, 0xb);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar5 = (code *)swi(3);
    uVar11 = (*pcVar5)();
    return uVar11;
}

// ============================================================
// Function: FUN_18008c83a
// Address: 0x18008c83a
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008c6f0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    code *pcVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    undefined8 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar10 + 0xc) == 0xb) {
        iVar1 = *piVar10 + 8;
        if (iVar1 != 0) {
            uVar3 = *(uint32_t *)(*piVar10 + 4);
            uVar6 = fcn.180088860(arg1, 2);
            piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
            if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
                piVar10 = *(int64_t **)0x180782430;
            }
            if (*(int32_t *)((int64_t)piVar10 + 0xc) == 0xb) {
                iVar2 = *piVar10 + 8;
                if (iVar2 != 0) {
                    piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x30);
                    uVar4 = *(uint32_t *)(*piVar10 + 4);
                    if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
                        piVar9 = *(int64_t **)0x180782430;
                    }
                    if ((piVar9 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar9 + 0xc) < 1)) {
                        uVar7 = 0;
                    } else {
                        uVar7 = fcn.180088860(arg1, 4);
                    }
                    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x40);
                    if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) < 1)) {
                        uVar8 = uVar4 - uVar7;
                    } else {
                        uVar8 = fcn.180088860(arg1, 5);
                    }
                    if (((-1 < (int32_t)uVar8) && ((uint64_t)uVar7 + (uint64_t)uVar8 <= (uint64_t)uVar4)) &&
                       ((uint64_t)uVar6 + (uint64_t)uVar8 <= (uint64_t)uVar3)) {
                        func_0x000180498030(iVar1 + (int32_t)uVar6, (int32_t)uVar7 + iVar2, (int64_t)(int32_t)uVar8);
                        return 0;
                    }
                    fcn.180088560(arg1, 0x18063dc90);
                    pcVar5 = (code *)swi(3);
                    uVar11 = (*pcVar5)();
                    return uVar11;
                }
            }
            fcn.180088470(arg1, 3, 0xb);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar5 = (code *)swi(3);
    uVar11 = (*pcVar5)();
    return uVar11;
}

// ============================================================
// Function: FUN_18008c84e
// Address: 0x18008c84e
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008c6f0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    code *pcVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    undefined8 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar10 + 0xc) == 0xb) {
        iVar1 = *piVar10 + 8;
        if (iVar1 != 0) {
            uVar3 = *(uint32_t *)(*piVar10 + 4);
            uVar6 = fcn.180088860(arg1, 2);
            piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
            if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
                piVar10 = *(int64_t **)0x180782430;
            }
            if (*(int32_t *)((int64_t)piVar10 + 0xc) == 0xb) {
                iVar2 = *piVar10 + 8;
                if (iVar2 != 0) {
                    piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x30);
                    uVar4 = *(uint32_t *)(*piVar10 + 4);
                    if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
                        piVar9 = *(int64_t **)0x180782430;
                    }
                    if ((piVar9 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar9 + 0xc) < 1)) {
                        uVar7 = 0;
                    } else {
                        uVar7 = fcn.180088860(arg1, 4);
                    }
                    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x40);
                    if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) < 1)) {
                        uVar8 = uVar4 - uVar7;
                    } else {
                        uVar8 = fcn.180088860(arg1, 5);
                    }
                    if (((-1 < (int32_t)uVar8) && ((uint64_t)uVar7 + (uint64_t)uVar8 <= (uint64_t)uVar4)) &&
                       ((uint64_t)uVar6 + (uint64_t)uVar8 <= (uint64_t)uVar3)) {
                        func_0x000180498030(iVar1 + (int32_t)uVar6, (int32_t)uVar7 + iVar2, (int64_t)(int32_t)uVar8);
                        return 0;
                    }
                    fcn.180088560(arg1, 0x18063dc90);
                    pcVar5 = (code *)swi(3);
                    uVar11 = (*pcVar5)();
                    return uVar11;
                }
            }
            fcn.180088470(arg1, 3, 0xb);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar5 = (code *)swi(3);
    uVar11 = (*pcVar5)();
    return uVar11;
}

// ============================================================
// Function: FUN_18008c85e
// Address: 0x18008c85e
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008c6f0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    code *pcVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    undefined8 uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar10 + 0xc) == 0xb) {
        iVar1 = *piVar10 + 8;
        if (iVar1 != 0) {
            uVar3 = *(uint32_t *)(*piVar10 + 4);
            uVar6 = fcn.180088860(arg1, 2);
            piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
            if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
                piVar10 = *(int64_t **)0x180782430;
            }
            if (*(int32_t *)((int64_t)piVar10 + 0xc) == 0xb) {
                iVar2 = *piVar10 + 8;
                if (iVar2 != 0) {
                    piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x30);
                    uVar4 = *(uint32_t *)(*piVar10 + 4);
                    if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
                        piVar9 = *(int64_t **)0x180782430;
                    }
                    if ((piVar9 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar9 + 0xc) < 1)) {
                        uVar7 = 0;
                    } else {
                        uVar7 = fcn.180088860(arg1, 4);
                    }
                    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x40);
                    if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
                        piVar10 = *(int64_t **)0x180782430;
                    }
                    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) < 1)) {
                        uVar8 = uVar4 - uVar7;
                    } else {
                        uVar8 = fcn.180088860(arg1, 5);
                    }
                    if (((-1 < (int32_t)uVar8) && ((uint64_t)uVar7 + (uint64_t)uVar8 <= (uint64_t)uVar4)) &&
                       ((uint64_t)uVar6 + (uint64_t)uVar8 <= (uint64_t)uVar3)) {
                        func_0x000180498030(iVar1 + (int32_t)uVar6, (int32_t)uVar7 + iVar2, (int64_t)(int32_t)uVar8);
                        return 0;
                    }
                    fcn.180088560(arg1, 0x18063dc90);
                    pcVar5 = (code *)swi(3);
                    uVar11 = (*pcVar5)();
                    return uVar11;
                }
            }
            fcn.180088470(arg1, 3, 0xb);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar5 = (code *)swi(3);
    uVar11 = (*pcVar5)();
    return uVar11;
}

// ============================================================
// Function: FUN_18008c880
// Address: 0x18008c880
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008c880(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    undefined uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) == 0xb) {
        uVar2 = *(uint32_t *)(*piVar8 + 4);
        iVar1 = *piVar8 + 8;
        if (iVar1 != 0) {
            uVar5 = fcn.180088860(arg1, 2);
            uVar4 = func_0x000180088a70(arg1, 3);
            piVar8 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x30);
            if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
                piVar8 = *(int64_t **)0x180782430;
            }
            if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) < 1)) {
                uVar6 = uVar2 - uVar5;
            } else {
                uVar6 = fcn.180088860(arg1, 4);
            }
            if ((-1 < (int32_t)uVar6) && ((uint64_t)uVar6 + (uint64_t)uVar5 <= (uint64_t)uVar2)) {
                func_0x0001804986e0((int32_t)uVar5 + iVar1, uVar4, (int64_t)(int32_t)uVar6);
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008c8bf
// Address: 0x18008c8bf
// Size: 155 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008c880(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    undefined uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) == 0xb) {
        uVar2 = *(uint32_t *)(*piVar8 + 4);
        iVar1 = *piVar8 + 8;
        if (iVar1 != 0) {
            uVar5 = fcn.180088860(arg1, 2);
            uVar4 = func_0x000180088a70(arg1, 3);
            piVar8 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x30);
            if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
                piVar8 = *(int64_t **)0x180782430;
            }
            if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) < 1)) {
                uVar6 = uVar2 - uVar5;
            } else {
                uVar6 = fcn.180088860(arg1, 4);
            }
            if ((-1 < (int32_t)uVar6) && ((uint64_t)uVar6 + (uint64_t)uVar5 <= (uint64_t)uVar2)) {
                func_0x0001804986e0((int32_t)uVar5 + iVar1, uVar4, (int64_t)(int32_t)uVar6);
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008c95a
// Address: 0x18008c95a
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008c880(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    undefined uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) == 0xb) {
        uVar2 = *(uint32_t *)(*piVar8 + 4);
        iVar1 = *piVar8 + 8;
        if (iVar1 != 0) {
            uVar5 = fcn.180088860(arg1, 2);
            uVar4 = func_0x000180088a70(arg1, 3);
            piVar8 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x30);
            if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
                piVar8 = *(int64_t **)0x180782430;
            }
            if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) < 1)) {
                uVar6 = uVar2 - uVar5;
            } else {
                uVar6 = fcn.180088860(arg1, 4);
            }
            if ((-1 < (int32_t)uVar6) && ((uint64_t)uVar6 + (uint64_t)uVar5 <= (uint64_t)uVar2)) {
                func_0x0001804986e0((int32_t)uVar5 + iVar1, uVar4, (int64_t)(int32_t)uVar6);
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008c96b
// Address: 0x18008c96b
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008c880(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    undefined uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) == 0xb) {
        uVar2 = *(uint32_t *)(*piVar8 + 4);
        iVar1 = *piVar8 + 8;
        if (iVar1 != 0) {
            uVar5 = fcn.180088860(arg1, 2);
            uVar4 = func_0x000180088a70(arg1, 3);
            piVar8 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x30);
            if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
                piVar8 = *(int64_t **)0x180782430;
            }
            if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) < 1)) {
                uVar6 = uVar2 - uVar5;
            } else {
                uVar6 = fcn.180088860(arg1, 4);
            }
            if ((-1 < (int32_t)uVar6) && ((uint64_t)uVar6 + (uint64_t)uVar5 <= (uint64_t)uVar2)) {
                func_0x0001804986e0((int32_t)uVar5 + iVar1, uVar4, (int64_t)(int32_t)uVar6);
                return 0;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008c980
// Address: 0x18008c980
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008c980(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    code *pcVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    double dVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar3 = *(uint32_t *)(*piVar6 + 4);
            dVar10 = (double)fcn.180085ea0(arg1, 2, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, 2, 3);
                pcVar4 = (code *)swi(3);
                uVar7 = (*pcVar4)();
                return uVar7;
            }
            iVar9 = (int64_t)dVar10;
            uVar5 = fcn.180088860(arg1, 3);
            if (-1 < iVar9) {
                if (0x20 < uVar5) {
                    fcn.180088560(arg1, 0x18063dcc8);
                    pcVar4 = (code *)swi(3);
                    uVar7 = (*pcVar4)();
                    return uVar7;
                }
                if ((uint64_t)(iVar9 + (int32_t)uVar5) <= (uint64_t)uVar3 << 3) {
                    var_8h = 0;
                    iVar2 = iVar9 + (int32_t)uVar5 + 7;
                    uVar8 = (int64_t)((uint64_t)((uint32_t)(iVar9 >> 0x3f) & 7) + iVar9) >> 3;
                    fcn.180498030(&var_8h, (uVar8 & 0xffffffff) + iVar1, 
                                  (int32_t)((int64_t)((uint64_t)((uint32_t)(iVar2 >> 0x3f) & 7) + iVar2) >> 3) -
                                  (int32_t)uVar8);
                    fcn.1800866d0(arg1, (uint32_t)((uint64_t)var_8h >> ((uint8_t)iVar9 & 7)) &
                                        (int32_t)(1LL << ((uint8_t)uVar5 & 0x3f)) - 1U);
                    return 1;
                }
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar4 = (code *)swi(3);
            uVar7 = (*pcVar4)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar4 = (code *)swi(3);
    uVar7 = (*pcVar4)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008c9b4
// Address: 0x18008c9b4
// Size: 231 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008c980(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    code *pcVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    double dVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar3 = *(uint32_t *)(*piVar6 + 4);
            dVar10 = (double)fcn.180085ea0(arg1, 2, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, 2, 3);
                pcVar4 = (code *)swi(3);
                uVar7 = (*pcVar4)();
                return uVar7;
            }
            iVar9 = (int64_t)dVar10;
            uVar5 = fcn.180088860(arg1, 3);
            if (-1 < iVar9) {
                if (0x20 < uVar5) {
                    fcn.180088560(arg1, 0x18063dcc8);
                    pcVar4 = (code *)swi(3);
                    uVar7 = (*pcVar4)();
                    return uVar7;
                }
                if ((uint64_t)(iVar9 + (int32_t)uVar5) <= (uint64_t)uVar3 << 3) {
                    var_8h = 0;
                    iVar2 = iVar9 + (int32_t)uVar5 + 7;
                    uVar8 = (int64_t)((uint64_t)((uint32_t)(iVar9 >> 0x3f) & 7) + iVar9) >> 3;
                    fcn.180498030(&var_8h, (uVar8 & 0xffffffff) + iVar1, 
                                  (int32_t)((int64_t)((uint64_t)((uint32_t)(iVar2 >> 0x3f) & 7) + iVar2) >> 3) -
                                  (int32_t)uVar8);
                    fcn.1800866d0(arg1, (uint32_t)((uint64_t)var_8h >> ((uint8_t)iVar9 & 7)) &
                                        (int32_t)(1LL << ((uint8_t)uVar5 & 0x3f)) - 1U);
                    return 1;
                }
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar4 = (code *)swi(3);
            uVar7 = (*pcVar4)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar4 = (code *)swi(3);
    uVar7 = (*pcVar4)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008ca9b
// Address: 0x18008ca9b
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008c980(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    code *pcVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    double dVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar3 = *(uint32_t *)(*piVar6 + 4);
            dVar10 = (double)fcn.180085ea0(arg1, 2, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, 2, 3);
                pcVar4 = (code *)swi(3);
                uVar7 = (*pcVar4)();
                return uVar7;
            }
            iVar9 = (int64_t)dVar10;
            uVar5 = fcn.180088860(arg1, 3);
            if (-1 < iVar9) {
                if (0x20 < uVar5) {
                    fcn.180088560(arg1, 0x18063dcc8);
                    pcVar4 = (code *)swi(3);
                    uVar7 = (*pcVar4)();
                    return uVar7;
                }
                if ((uint64_t)(iVar9 + (int32_t)uVar5) <= (uint64_t)uVar3 << 3) {
                    var_8h = 0;
                    iVar2 = iVar9 + (int32_t)uVar5 + 7;
                    uVar8 = (int64_t)((uint64_t)((uint32_t)(iVar9 >> 0x3f) & 7) + iVar9) >> 3;
                    fcn.180498030(&var_8h, (uVar8 & 0xffffffff) + iVar1, 
                                  (int32_t)((int64_t)((uint64_t)((uint32_t)(iVar2 >> 0x3f) & 7) + iVar2) >> 3) -
                                  (int32_t)uVar8);
                    fcn.1800866d0(arg1, (uint32_t)((uint64_t)var_8h >> ((uint8_t)iVar9 & 7)) &
                                        (int32_t)(1LL << ((uint8_t)uVar5 & 0x3f)) - 1U);
                    return 1;
                }
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar4 = (code *)swi(3);
            uVar7 = (*pcVar4)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar4 = (code *)swi(3);
    uVar7 = (*pcVar4)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008caaf
// Address: 0x18008caaf
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008c980(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    code *pcVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    double dVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar3 = *(uint32_t *)(*piVar6 + 4);
            dVar10 = (double)fcn.180085ea0(arg1, 2, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, 2, 3);
                pcVar4 = (code *)swi(3);
                uVar7 = (*pcVar4)();
                return uVar7;
            }
            iVar9 = (int64_t)dVar10;
            uVar5 = fcn.180088860(arg1, 3);
            if (-1 < iVar9) {
                if (0x20 < uVar5) {
                    fcn.180088560(arg1, 0x18063dcc8);
                    pcVar4 = (code *)swi(3);
                    uVar7 = (*pcVar4)();
                    return uVar7;
                }
                if ((uint64_t)(iVar9 + (int32_t)uVar5) <= (uint64_t)uVar3 << 3) {
                    var_8h = 0;
                    iVar2 = iVar9 + (int32_t)uVar5 + 7;
                    uVar8 = (int64_t)((uint64_t)((uint32_t)(iVar9 >> 0x3f) & 7) + iVar9) >> 3;
                    fcn.180498030(&var_8h, (uVar8 & 0xffffffff) + iVar1, 
                                  (int32_t)((int64_t)((uint64_t)((uint32_t)(iVar2 >> 0x3f) & 7) + iVar2) >> 3) -
                                  (int32_t)uVar8);
                    fcn.1800866d0(arg1, (uint32_t)((uint64_t)var_8h >> ((uint8_t)iVar9 & 7)) &
                                        (int32_t)(1LL << ((uint8_t)uVar5 & 0x3f)) - 1U);
                    return 1;
                }
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar4 = (code *)swi(3);
            uVar7 = (*pcVar4)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar4 = (code *)swi(3);
    uVar7 = (*pcVar4)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008cac0
// Address: 0x18008cac0
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18008c980(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    code *pcVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    double dVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar1 = *piVar6 + 8;
        if (iVar1 != 0) {
            uVar3 = *(uint32_t *)(*piVar6 + 4);
            dVar10 = (double)fcn.180085ea0(arg1, 2, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, 2, 3);
                pcVar4 = (code *)swi(3);
                uVar7 = (*pcVar4)();
                return uVar7;
            }
            iVar9 = (int64_t)dVar10;
            uVar5 = fcn.180088860(arg1, 3);
            if (-1 < iVar9) {
                if (0x20 < uVar5) {
                    fcn.180088560(arg1, 0x18063dcc8);
                    pcVar4 = (code *)swi(3);
                    uVar7 = (*pcVar4)();
                    return uVar7;
                }
                if ((uint64_t)(iVar9 + (int32_t)uVar5) <= (uint64_t)uVar3 << 3) {
                    var_8h = 0;
                    iVar2 = iVar9 + (int32_t)uVar5 + 7;
                    uVar8 = (int64_t)((uint64_t)((uint32_t)(iVar9 >> 0x3f) & 7) + iVar9) >> 3;
                    fcn.180498030(&var_8h, (uVar8 & 0xffffffff) + iVar1, 
                                  (int32_t)((int64_t)((uint64_t)((uint32_t)(iVar2 >> 0x3f) & 7) + iVar2) >> 3) -
                                  (int32_t)uVar8);
                    fcn.1800866d0(arg1, (uint32_t)((uint64_t)var_8h >> ((uint8_t)iVar9 & 7)) &
                                        (int32_t)(1LL << ((uint8_t)uVar5 & 0x3f)) - 1U);
                    return 1;
                }
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar4 = (code *)swi(3);
            uVar7 = (*pcVar4)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar4 = (code *)swi(3);
    uVar7 = (*pcVar4)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008cae0
// Address: 0x18008cae0
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18008cae0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint8_t uVar8;
    uint64_t uVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    double dVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar12 = *piVar6 + 8;
        if (iVar12 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            dVar13 = (double)fcn.180085ea0(arg1, 2, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, 2, 3);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            iVar11 = (int64_t)dVar13;
            uVar4 = fcn.180088860(arg1, 3);
            uVar5 = fcn.180088a70(arg1, 4);
            if (-1 < iVar11) {
                if (0x20 < uVar4) {
                    fcn.180088560(arg1, 0x18063dcc8);
                    pcVar3 = (code *)swi(3);
                    uVar7 = (*pcVar3)();
                    return uVar7;
                }
                if ((uint64_t)(iVar11 + (int32_t)uVar4) <= (uint64_t)uVar2 << 3) {
                    var_8h = 0;
                    uVar9 = (int64_t)((uint64_t)((uint32_t)(iVar11 >> 0x3f) & 7) + iVar11) >> 3;
                    iVar1 = iVar11 + (int32_t)uVar4 + 7;
                    iVar12 = iVar12 + (uVar9 & 0xffffffff);
                    iVar10 = (int32_t)((int64_t)((uint64_t)((uint32_t)(iVar1 >> 0x3f) & 7) + iVar1) >> 3) -
                             (int32_t)uVar9;
                    fcn.180498030(&var_8h, iVar12, iVar10);
                    uVar8 = (uint8_t)iVar11 & 7;
                    uVar9 = (1LL << ((uint8_t)uVar4 & 0x3f)) - 1;
                    var_8h = (uVar5 & uVar9) << uVar8 | ~(uVar9 << uVar8) & var_8h;
                    fcn.180498030(iVar12, &var_8h, iVar10);
                    return 0;
                }
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008cb14
// Address: 0x18008cb14
// Size: 281 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18008cae0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint8_t uVar8;
    uint64_t uVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    double dVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar12 = *piVar6 + 8;
        if (iVar12 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            dVar13 = (double)fcn.180085ea0(arg1, 2, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, 2, 3);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            iVar11 = (int64_t)dVar13;
            uVar4 = fcn.180088860(arg1, 3);
            uVar5 = fcn.180088a70(arg1, 4);
            if (-1 < iVar11) {
                if (0x20 < uVar4) {
                    fcn.180088560(arg1, 0x18063dcc8);
                    pcVar3 = (code *)swi(3);
                    uVar7 = (*pcVar3)();
                    return uVar7;
                }
                if ((uint64_t)(iVar11 + (int32_t)uVar4) <= (uint64_t)uVar2 << 3) {
                    var_8h = 0;
                    uVar9 = (int64_t)((uint64_t)((uint32_t)(iVar11 >> 0x3f) & 7) + iVar11) >> 3;
                    iVar1 = iVar11 + (int32_t)uVar4 + 7;
                    iVar12 = iVar12 + (uVar9 & 0xffffffff);
                    iVar10 = (int32_t)((int64_t)((uint64_t)((uint32_t)(iVar1 >> 0x3f) & 7) + iVar1) >> 3) -
                             (int32_t)uVar9;
                    fcn.180498030(&var_8h, iVar12, iVar10);
                    uVar8 = (uint8_t)iVar11 & 7;
                    uVar9 = (1LL << ((uint8_t)uVar4 & 0x3f)) - 1;
                    var_8h = (uVar5 & uVar9) << uVar8 | ~(uVar9 << uVar8) & var_8h;
                    fcn.180498030(iVar12, &var_8h, iVar10);
                    return 0;
                }
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008cc2d
// Address: 0x18008cc2d
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18008cae0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint8_t uVar8;
    uint64_t uVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    double dVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar12 = *piVar6 + 8;
        if (iVar12 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            dVar13 = (double)fcn.180085ea0(arg1, 2, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, 2, 3);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            iVar11 = (int64_t)dVar13;
            uVar4 = fcn.180088860(arg1, 3);
            uVar5 = fcn.180088a70(arg1, 4);
            if (-1 < iVar11) {
                if (0x20 < uVar4) {
                    fcn.180088560(arg1, 0x18063dcc8);
                    pcVar3 = (code *)swi(3);
                    uVar7 = (*pcVar3)();
                    return uVar7;
                }
                if ((uint64_t)(iVar11 + (int32_t)uVar4) <= (uint64_t)uVar2 << 3) {
                    var_8h = 0;
                    uVar9 = (int64_t)((uint64_t)((uint32_t)(iVar11 >> 0x3f) & 7) + iVar11) >> 3;
                    iVar1 = iVar11 + (int32_t)uVar4 + 7;
                    iVar12 = iVar12 + (uVar9 & 0xffffffff);
                    iVar10 = (int32_t)((int64_t)((uint64_t)((uint32_t)(iVar1 >> 0x3f) & 7) + iVar1) >> 3) -
                             (int32_t)uVar9;
                    fcn.180498030(&var_8h, iVar12, iVar10);
                    uVar8 = (uint8_t)iVar11 & 7;
                    uVar9 = (1LL << ((uint8_t)uVar4 & 0x3f)) - 1;
                    var_8h = (uVar5 & uVar9) << uVar8 | ~(uVar9 << uVar8) & var_8h;
                    fcn.180498030(iVar12, &var_8h, iVar10);
                    return 0;
                }
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008cc41
// Address: 0x18008cc41
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18008cae0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint8_t uVar8;
    uint64_t uVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    double dVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar12 = *piVar6 + 8;
        if (iVar12 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            dVar13 = (double)fcn.180085ea0(arg1, 2, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, 2, 3);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            iVar11 = (int64_t)dVar13;
            uVar4 = fcn.180088860(arg1, 3);
            uVar5 = fcn.180088a70(arg1, 4);
            if (-1 < iVar11) {
                if (0x20 < uVar4) {
                    fcn.180088560(arg1, 0x18063dcc8);
                    pcVar3 = (code *)swi(3);
                    uVar7 = (*pcVar3)();
                    return uVar7;
                }
                if ((uint64_t)(iVar11 + (int32_t)uVar4) <= (uint64_t)uVar2 << 3) {
                    var_8h = 0;
                    uVar9 = (int64_t)((uint64_t)((uint32_t)(iVar11 >> 0x3f) & 7) + iVar11) >> 3;
                    iVar1 = iVar11 + (int32_t)uVar4 + 7;
                    iVar12 = iVar12 + (uVar9 & 0xffffffff);
                    iVar10 = (int32_t)((int64_t)((uint64_t)((uint32_t)(iVar1 >> 0x3f) & 7) + iVar1) >> 3) -
                             (int32_t)uVar9;
                    fcn.180498030(&var_8h, iVar12, iVar10);
                    uVar8 = (uint8_t)iVar11 & 7;
                    uVar9 = (1LL << ((uint8_t)uVar4 & 0x3f)) - 1;
                    var_8h = (uVar5 & uVar9) << uVar8 | ~(uVar9 << uVar8) & var_8h;
                    fcn.180498030(iVar12, &var_8h, iVar10);
                    return 0;
                }
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008cc52
// Address: 0x18008cc52
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18008cae0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint8_t uVar8;
    uint64_t uVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    double dVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 0xb) {
        iVar12 = *piVar6 + 8;
        if (iVar12 != 0) {
            uVar2 = *(uint32_t *)(*piVar6 + 4);
            dVar13 = (double)fcn.180085ea0(arg1, 2, &var_8h);
            if ((int32_t)var_8h == 0) {
                fcn.180088470(arg1, 2, 3);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            iVar11 = (int64_t)dVar13;
            uVar4 = fcn.180088860(arg1, 3);
            uVar5 = fcn.180088a70(arg1, 4);
            if (-1 < iVar11) {
                if (0x20 < uVar4) {
                    fcn.180088560(arg1, 0x18063dcc8);
                    pcVar3 = (code *)swi(3);
                    uVar7 = (*pcVar3)();
                    return uVar7;
                }
                if ((uint64_t)(iVar11 + (int32_t)uVar4) <= (uint64_t)uVar2 << 3) {
                    var_8h = 0;
                    uVar9 = (int64_t)((uint64_t)((uint32_t)(iVar11 >> 0x3f) & 7) + iVar11) >> 3;
                    iVar1 = iVar11 + (int32_t)uVar4 + 7;
                    iVar12 = iVar12 + (uVar9 & 0xffffffff);
                    iVar10 = (int32_t)((int64_t)((uint64_t)((uint32_t)(iVar1 >> 0x3f) & 7) + iVar1) >> 3) -
                             (int32_t)uVar9;
                    fcn.180498030(&var_8h, iVar12, iVar10);
                    uVar8 = (uint8_t)iVar11 & 7;
                    uVar9 = (1LL << ((uint8_t)uVar4 & 0x3f)) - 1;
                    var_8h = (uVar5 & uVar9) << uVar8 | ~(uVar9 << uVar8) & var_8h;
                    fcn.180498030(iVar12, &var_8h, iVar10);
                    return 0;
                }
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar7 = (*pcVar3)();
            return uVar7;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_18008cc80
// Address: 0x18008cc80
// Size: 849 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

undefined8 fcn.18008cc80(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    undefined8 uVar5;
    undefined4 *puVar6;
    int32_t iVar7;
    int64_t unaff_RDI;
    undefined8 *puVar8;
    int64_t var_38h;
    
    iVar7 = 0;
    if (*(char *)0x1807778b0 == '\0') {
        puVar8 = (undefined8 *)0x180611a40;
        piVar2 = (int64_t *)0x180611a40;
        do {
            iVar7 = iVar7 + 1;
            piVar2 = piVar2 + 2;
        } while (*piVar2 != 0);
        func_0x000180088ce0(arg1, 0xffffd8f0, 0x18063da18, 1);
        func_0x000180086cc0(arg1, 0xffffffff, 0x18062598c);
        iVar3 = *(int64_t *)(arg1 + 0x40) + -0x10;
        if ((iVar3 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 7)) {
            *(int64_t *)(arg1 + 0x40) = iVar3;
            iVar3 = func_0x000180088ce0(arg1, 0xffffd8ee, 0x18062598c, iVar7);
            if (iVar3 != 0) goto code_r0x00018008cfa2;
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U))
               && (iVar7 = fcn.180085510(unaff_RDI), iVar7 == 0)) goto code_r0x00018008cfb9;
            puVar4 = *(undefined4 **)(arg1 + 0x40);
            *puVar4 = puVar4[-4];
            puVar4[1] = puVar4[-3];
            puVar4[2] = puVar4[-2];
            puVar4[3] = puVar4[-1];
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            func_0x000180087370(arg1, 0xfffffffd, 0x18062598c);
        }
        puVar6 = *(undefined4 **)(arg1 + 0x40);
        puVar4 = puVar6 + -4;
        if (puVar4 < puVar6) {
            do {
                puVar4[-4] = *puVar4;
                puVar4[-3] = puVar4[1];
                puVar4[-2] = puVar4[2];
                puVar4[-1] = puVar4[3];
                puVar6 = *(undefined4 **)(arg1 + 0x40);
                puVar4 = puVar4 + 4;
            } while (puVar4 < puVar6);
        }
        *(undefined4 **)(arg1 + 0x40) = puVar6 + -4;
        iVar3 = 0x18063c32c;
        do {
            func_0x0001800869f0(arg1, puVar8[1], iVar3, 0, 0);
            func_0x000180087370(arg1, 0xfffffffe, *puVar8);
            iVar3 = puVar8[2];
            puVar8 = puVar8 + 2;
        } while (iVar3 != 0);
        return 1;
    }
    puVar8 = (undefined8 *)0x180611870;
    piVar2 = (int64_t *)0x180611870;
    do {
        iVar7 = iVar7 + 1;
        piVar2 = piVar2 + 2;
    } while (*piVar2 != 0);
    func_0x000180088ce0(arg1, 0xffffd8f0, 0x18063da18, 1);
    func_0x000180086cc0(arg1, 0xffffffff, 0x18062598c);
    iVar3 = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((iVar3 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 7)) {
        *(int64_t *)(arg1 + 0x40) = iVar3;
        iVar3 = func_0x000180088ce0(arg1, 0xffffd8ee, 0x18062598c, iVar7);
        if (iVar3 != 0) {
code_r0x00018008cfa2:
            fcn.180088560(arg1, 0x18063da68, 0x18062598c);
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar7 = fcn.180085510(unaff_RDI), iVar7 == 0)) {
code_r0x00018008cfb9:
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        puVar4 = *(undefined4 **)(arg1 + 0x40);
        *puVar4 = puVar4[-4];
        puVar4[1] = puVar4[-3];
        puVar4[2] = puVar4[-2];
        puVar4[3] = puVar4[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087370(arg1, 0xfffffffd, 0x18062598c);
    }
    puVar6 = *(undefined4 **)(arg1 + 0x40);
    puVar4 = puVar6 + -4;
    if (puVar4 < puVar6) {
        do {
            puVar4[-4] = *puVar4;
            puVar4[-3] = puVar4[1];
            puVar4[-2] = puVar4[2];
            puVar4[-1] = puVar4[3];
            puVar6 = *(undefined4 **)(arg1 + 0x40);
            puVar4 = puVar4 + 4;
        } while (puVar4 < puVar6);
    }
    *(undefined4 **)(arg1 + 0x40) = puVar6 + -4;
    iVar3 = 0x18063c32c;
    do {
        func_0x0001800869f0(arg1, puVar8[1], iVar3, 0, 0);
        func_0x000180087370(arg1, 0xfffffffe, *puVar8);
        iVar3 = puVar8[2];
        puVar8 = puVar8 + 2;
    } while (iVar3 != 0);
    return 1;
}

// ============================================================
// Function: FUN_18008cfe0
// Address: 0x18008cfe0
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008cfe0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 1 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, (double)(int32_t)*(char *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d00f
// Address: 0x18008d00f
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008cfe0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 1 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, (double)(int32_t)*(char *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d033
// Address: 0x18008d033
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008cfe0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 1 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, (double)(int32_t)*(char *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d080
// Address: 0x18008d080
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008d080(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 1 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, (double)(uint32_t)*(uint8_t *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d0af
// Address: 0x18008d0af
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008d080(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 1 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, (double)(uint32_t)*(uint8_t *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d0d3
// Address: 0x18008d0d3
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008d080(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 1 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, (double)(uint32_t)*(uint8_t *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d120
// Address: 0x18008d120
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008d120(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 2 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, (double)(int32_t)*(int16_t *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d14f
// Address: 0x18008d14f
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008d120(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 2 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, (double)(int32_t)*(int16_t *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d174
// Address: 0x18008d174
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008d120(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 2 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, (double)(int32_t)*(int16_t *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d1c0
// Address: 0x18008d1c0
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008d1c0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 2 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, (double)(uint32_t)*(uint16_t *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d1ef
// Address: 0x18008d1ef
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008d1c0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 2 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, (double)(uint32_t)*(uint16_t *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d214
// Address: 0x18008d214
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008d1c0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 2 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, (double)(uint32_t)*(uint16_t *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d260
// Address: 0x18008d260
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008d260(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 4 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, (double)*(int32_t *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d28f
// Address: 0x18008d28f
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008d260(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 4 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, (double)*(int32_t *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d2b7
// Address: 0x18008d2b7
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008d260(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 4 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, (double)*(int32_t *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_18008d300
// Address: 0x18008d300
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18008d300(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 0xb) {
        iVar1 = *piVar5 + 8;
        if (iVar1 != 0) {
            uVar2 = *(uint32_t *)(*piVar5 + 4);
            uVar4 = fcn.180088860(arg1, 2);
            if ((uint64_t)uVar4 + 4 <= (uint64_t)uVar2) {
                fcn.180086570(arg1, (double)(uint64_t)*(uint32_t *)((int32_t)uVar4 + iVar1));
                return 1;
            }
            fcn.180088560(arg1, 0x18063dc90);
            pcVar3 = (code *)swi(3);
            uVar6 = (*pcVar3)();
            return uVar6;
        }
    }
    fcn.180088470(arg1, 1, 0xb);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

