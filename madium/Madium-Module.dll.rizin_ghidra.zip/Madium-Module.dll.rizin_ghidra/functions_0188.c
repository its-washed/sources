// Chunk 188 - 50 functions

// ============================================================
// Function: FUN_1802513b0
// Address: 0x1802513b0
// Size: 184 bytes
// ============================================================
void fcn.1802513b0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    code *pcStack_10;
    
    if (arg1 != 0) {
        pcStack_10 = (code *)0x1802513c4;
        iVar2 = func_0x00018045a350();
        iVar2 = -iVar2;
    // switch table (6 cases) at 0x180251450
        switch(*(undefined4 *)arg1) {
        case 1:
            uVar1 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&pcStack_10 + iVar2) = 0x1802513fe;
            func_0x000180224990(uVar1, 0x1804e59a0, 0x344);
            uVar1 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&pcStack_10 + iVar2) = 0x180251414;
            func_0x000180224990(uVar1, 0x1804e59a0, 0x345);
            break;
        case 2:
        case 3:
        case 4:
            uVar1 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&pcStack_10 + iVar2) = 0x18025141f;
            func_0x00018022ecc0(uVar1);
            break;
        case 5:
            uVar1 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&pcStack_10 + iVar2) = 0x18025142a;
            func_0x00018021fe80(uVar1);
            break;
        case 6:
            uVar1 = *(undefined8 *)(arg1 + 8);
            *(code **)((int64_t)&pcStack_10 + iVar2) = case.default.0x1802513e6;
            func_0x00018028eb90(uVar1);
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar2) = 0x18025144a;
        func_0x000180224990(arg1, 0x1804e59a0, 0x357);
    }
    return;
}

// ============================================================
// Function: FUN_1802514a0
// Address: 0x1802514a0
// Size: 117 bytes
// ============================================================
undefined4 * fcn.1802514a0(undefined8 param_1)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802514ac;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802514c9;
    puVar2 = (undefined4 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (puVar2 == (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802514d3;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802514eb;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802514fd;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
        return (undefined4 *)0x0;
    }
    *puVar2 = 5;
    *(undefined8 *)(puVar2 + 2) = param_1;
    return puVar2;
}

// ============================================================
// Function: FUN_180251520
// Address: 0x180251520
// Size: 117 bytes
// ============================================================
undefined4 * fcn.180251520(undefined8 param_1)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025152c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180251549;
    puVar2 = (undefined4 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (puVar2 == (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180251553;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025156b;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025157d;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
        return (undefined4 *)0x0;
    }
    *puVar2 = 6;
    *(undefined8 *)(puVar2 + 2) = param_1;
    return puVar2;
}

// ============================================================
// Function: FUN_1802515a0
// Address: 0x1802515a0
// Size: 125 bytes
// ============================================================
undefined4 * fcn.1802515a0(undefined8 param_1)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802515ac;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802515c9;
    puVar2 = (undefined4 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = 1;
        *(undefined8 *)(puVar2 + 2) = param_1;
        *(undefined8 *)(puVar2 + 4) = 0;
        return puVar2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802515eb;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180251603;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180251615;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
    return (undefined4 *)0x0;
}

// ============================================================
// Function: FUN_180251620
// Address: 0x180251620
// Size: 117 bytes
// ============================================================
undefined4 * fcn.180251620(undefined8 param_1)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025162c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180251649;
    puVar2 = (undefined4 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (puVar2 == (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180251653;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025166b;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025167d;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
        return (undefined4 *)0x0;
    }
    *puVar2 = 2;
    *(undefined8 *)(puVar2 + 2) = param_1;
    return puVar2;
}

// ============================================================
// Function: FUN_1802516a0
// Address: 0x1802516a0
// Size: 117 bytes
// ============================================================
undefined4 * fcn.1802516a0(undefined8 param_1)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802516ac;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802516c9;
    puVar2 = (undefined4 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (puVar2 == (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802516d3;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802516eb;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802516fd;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
        return (undefined4 *)0x0;
    }
    *puVar2 = 4;
    *(undefined8 *)(puVar2 + 2) = param_1;
    return puVar2;
}

// ============================================================
// Function: FUN_180251720
// Address: 0x180251720
// Size: 117 bytes
// ============================================================
undefined4 * fcn.180251720(undefined8 param_1)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025172c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180251749;
    puVar2 = (undefined4 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (puVar2 == (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180251753;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025176b;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025177d;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
        return (undefined4 *)0x0;
    }
    *puVar2 = 3;
    *(undefined8 *)(puVar2 + 2) = param_1;
    return puVar2;
}

// ============================================================
// Function: FUN_1802517a0
// Address: 0x1802517a0
// Size: 86 bytes
// ============================================================
undefined8 fcn.1802517a0(int32_t *param_1, undefined8 param_2)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802517aa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*param_1 != 1) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802517b7;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802517cf;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802517e1;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    *(undefined8 *)(param_1 + 4) = param_2;
    return 1;
}

// ============================================================
// Function: FUN_180251800
// Address: 0x180251800
// Size: 68 bytes
// ============================================================
void fcn.180251800(undefined8 param_1)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025180c;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180251829;
    puVar2 = (undefined4 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + -iVar1));
    if (puVar2 == (undefined4 *)0x0) {
        return;
    }
    *puVar2 = 1;
    *(undefined8 *)(puVar2 + 2) = param_1;
    return;
}

// ============================================================
// Function: FUN_180251850
// Address: 0x180251850
// Size: 35 bytes
// ============================================================
void fcn.180251850(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4) = 0x18022499a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(code **)0x1806a0030 == (code *)0x180224990) {
        if (param_1 != 0) {
            *(undefined8 *)(&stack0x00000048 + iVar3 + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_180251880
// Address: 0x180251880
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 fcn.180251880(int64_t arg_28h)
{
    undefined4 uVar1;
    int64_t iVar2;
    undefined8 in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180251890;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025189b;
    uVar1 = fcn.180252490(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802518b2;
    fcn.180224990(in_RCX, 0x1804e59a0, 599);
    return uVar1;
}

// ============================================================
// Function: FUN_1802518c0
// Address: 0x1802518c0
// Size: 142 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1802518c0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802518d5;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar4 = 0;
    if (in_RCX[8] != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802518ed;
        iVar3 = func_0x000180222010();
        if (iVar3 == 0) {
            iVar1 = in_RCX[8];
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802518fa;
            func_0x000180221d50(iVar1);
            in_RCX[8] = 0;
        }
    }
    if (in_RCX[8] == 0) {
        if (in_RCX[1] != 0) {
            iVar1 = in_RCX[2];
            pcVar2 = *(code **)(*in_RCX + 0xb0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025191f;
            iVar4 = (*pcVar2)(iVar1);
            if (in_RCX[1] != 0) goto code_r0x000180251936;
        }
        pcVar2 = *(code **)(*in_RCX + 0x40);
        iVar1 = in_RCX[2];
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180251934;
        iVar4 = (*pcVar2)(iVar1);
    }
code_r0x000180251936:
    return iVar4 != 0;
}

// ============================================================
// Function: FUN_180251950
// Address: 0x180251950
// Size: 46 bytes
// ============================================================
uint64_t fcn.180251950(int64_t *param_1)
{
    uint64_t uVar1;
    
    fcn.18045a350();
    if (param_1[1] != 0) {
        return (uint64_t)*(uint32_t *)((int64_t)param_1 + 0x3c);
    }
    // WARNING: Could not recover jumptable at 0x00018025197b. Too many branches
    // WARNING: Treating indirect jump as call
    uVar1 = (**(code **)(*param_1 + 0x48))(param_1[2], *(code **)(*param_1 + 0x48));
    return uVar1;
}

// ============================================================
// Function: FUN_180251980
// Address: 0x180251980
// Size: 315 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.180251980(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    code *pcVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBP;
    uint64_t uVar7;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    uint64_t uVar9;
    uint64_t uVar10;
    undefined8 unaff_R15;
    int64_t aiStackX_10 [3];
    undefined8 uStack_18;
    int64_t var_10h;
    uint64_t uVar8;
    
    uStack_18 = 0x18025198d;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)(in_RCX + 7) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802519a1;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802519b9;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802519cb;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    if (in_RDX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802519de;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802519f6;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a08;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    iVar5 = in_RCX[1];
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R14;
    if (iVar5 == 0) {
        pcVar1 = *(code **)(*in_RCX + 0x30);
        if (pcVar1 != (code *)0x0) {
            iVar5 = in_RCX[2];
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251c5d;
            uVar3 = (*pcVar1)(iVar5);
            return (uint64_t)uVar3;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251c28;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251c40;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251c52;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    uVar8 = 0;
    uVar7 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
    if (*(int64_t *)(iVar5 + 0xa0) == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a42;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a5a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a6c;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a78;
    iVar5 = fcn.18025b2a0();
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a85;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a9d;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251aaf;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    iVar2 = *in_RDX;
    uVar9 = 0;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar4) = unaff_R15;
    uVar10 = uVar9;
    if (iVar2 == 1) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b9f;
        iVar2 = fcn.180234b40(*(int64_t *)((int64_t)&arg_40h + iVar4), *(int64_t *)(&stack0x00000070 + iVar4), 
                              *(int64_t *)(&stack0x00000078 + iVar4), *(int64_t *)(&stack0x00000080 + iVar4), 
                              *(int64_t *)(&stack0x00000088 + iVar4));
        if (iVar2 < 1) goto code_r0x000180251be9;
code_r0x000180251bb2:
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251bba;
        iVar2 = fcn.18025b460(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4)
                              , *(int64_t *)((int64_t)&arg_30h + iVar4));
        uVar7 = uVar8;
    } else if (iVar2 == 2) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b40;
        iVar2 = fcn.180234b40(*(int64_t *)((int64_t)&arg_40h + iVar4), *(int64_t *)(&stack0x00000070 + iVar4), 
                              *(int64_t *)(&stack0x00000078 + iVar4), *(int64_t *)(&stack0x00000080 + iVar4), 
                              *(int64_t *)(&stack0x00000088 + iVar4));
        uVar7 = uVar8;
        if (iVar2 < 1) goto code_r0x000180251be9;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b56;
        uVar7 = fcn.18025ff60(*(int64_t *)((int64_t)&arg_38h + iVar4));
        if (uVar7 == 0) goto code_r0x000180251be9;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b79;
        iVar2 = fcn.18025b460(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4)
                              , *(int64_t *)((int64_t)&arg_30h + iVar4));
        if (iVar2 == 0) goto code_r0x000180251be9;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b8f;
        iVar2 = fcn.18025b310(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4))
        ;
    } else {
        if (iVar2 == 3) {
            uVar6 = *(undefined8 *)(in_RDX + 6);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b01;
            fcn.18020f750(uVar6);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b16;
            iVar2 = fcn.18025b510(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), 
                                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4));
            uVar7 = uVar8;
            if (iVar2 == 0) goto code_r0x000180251be9;
            goto code_r0x000180251bb2;
        }
        uVar7 = uVar8;
        uVar10 = uVar8;
        if (iVar2 != 4) goto code_r0x000180251be9;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251af3;
        iVar2 = fcn.18025b510(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4)
                              , *(int64_t *)((int64_t)&arg_30h + iVar4));
    }
    uVar10 = uVar9;
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251bc6;
        uVar6 = fcn.18025b5a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8)
                              , *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), 
                              *(int64_t *)(&stack0x00000028 + iVar4));
        pcVar1 = *(code **)(in_RCX[1] + 0xa0);
        iVar5 = in_RCX[2];
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251bde;
        uVar3 = (*pcVar1)(iVar5, uVar6);
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251be9;
        fcn.180256a40(uVar6);
        uVar10 = (uint64_t)uVar3;
    }
code_r0x000180251be9:
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251bf1;
    fcn.18025b220(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251c08;
    fcn.180224990(*(undefined8 *)((int64_t)&arg_30h + iVar4), 0x1804e59a0, 0x193);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251c10;
    fcn.180255290(uVar7);
    return uVar10;
}

// ============================================================
// Function: FUN_180251abb
// Address: 0x180251abb
// Size: 348 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.180251980(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    code *pcVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBP;
    uint64_t uVar7;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    uint64_t uVar9;
    uint64_t uVar10;
    undefined8 unaff_R15;
    int64_t aiStackX_10 [3];
    undefined8 uStack_18;
    int64_t var_10h;
    uint64_t uVar8;
    
    uStack_18 = 0x18025198d;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)(in_RCX + 7) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802519a1;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802519b9;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802519cb;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    if (in_RDX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802519de;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802519f6;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a08;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    iVar5 = in_RCX[1];
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R14;
    if (iVar5 == 0) {
        pcVar1 = *(code **)(*in_RCX + 0x30);
        if (pcVar1 != (code *)0x0) {
            iVar5 = in_RCX[2];
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251c5d;
            uVar3 = (*pcVar1)(iVar5);
            return (uint64_t)uVar3;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251c28;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251c40;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251c52;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    uVar8 = 0;
    uVar7 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
    if (*(int64_t *)(iVar5 + 0xa0) == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a42;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a5a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a6c;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a78;
    iVar5 = fcn.18025b2a0();
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a85;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a9d;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251aaf;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    iVar2 = *in_RDX;
    uVar9 = 0;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar4) = unaff_R15;
    uVar10 = uVar9;
    if (iVar2 == 1) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b9f;
        iVar2 = fcn.180234b40(*(int64_t *)((int64_t)&arg_40h + iVar4), *(int64_t *)(&stack0x00000070 + iVar4), 
                              *(int64_t *)(&stack0x00000078 + iVar4), *(int64_t *)(&stack0x00000080 + iVar4), 
                              *(int64_t *)(&stack0x00000088 + iVar4));
        if (iVar2 < 1) goto code_r0x000180251be9;
code_r0x000180251bb2:
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251bba;
        iVar2 = fcn.18025b460(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4)
                              , *(int64_t *)((int64_t)&arg_30h + iVar4));
        uVar7 = uVar8;
    } else if (iVar2 == 2) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b40;
        iVar2 = fcn.180234b40(*(int64_t *)((int64_t)&arg_40h + iVar4), *(int64_t *)(&stack0x00000070 + iVar4), 
                              *(int64_t *)(&stack0x00000078 + iVar4), *(int64_t *)(&stack0x00000080 + iVar4), 
                              *(int64_t *)(&stack0x00000088 + iVar4));
        uVar7 = uVar8;
        if (iVar2 < 1) goto code_r0x000180251be9;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b56;
        uVar7 = fcn.18025ff60(*(int64_t *)((int64_t)&arg_38h + iVar4));
        if (uVar7 == 0) goto code_r0x000180251be9;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b79;
        iVar2 = fcn.18025b460(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4)
                              , *(int64_t *)((int64_t)&arg_30h + iVar4));
        if (iVar2 == 0) goto code_r0x000180251be9;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b8f;
        iVar2 = fcn.18025b310(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4))
        ;
    } else {
        if (iVar2 == 3) {
            uVar6 = *(undefined8 *)(in_RDX + 6);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b01;
            fcn.18020f750(uVar6);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b16;
            iVar2 = fcn.18025b510(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), 
                                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4));
            uVar7 = uVar8;
            if (iVar2 == 0) goto code_r0x000180251be9;
            goto code_r0x000180251bb2;
        }
        uVar7 = uVar8;
        uVar10 = uVar8;
        if (iVar2 != 4) goto code_r0x000180251be9;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251af3;
        iVar2 = fcn.18025b510(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4)
                              , *(int64_t *)((int64_t)&arg_30h + iVar4));
    }
    uVar10 = uVar9;
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251bc6;
        uVar6 = fcn.18025b5a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8)
                              , *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), 
                              *(int64_t *)(&stack0x00000028 + iVar4));
        pcVar1 = *(code **)(in_RCX[1] + 0xa0);
        iVar5 = in_RCX[2];
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251bde;
        uVar3 = (*pcVar1)(iVar5, uVar6);
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251be9;
        fcn.180256a40(uVar6);
        uVar10 = (uint64_t)uVar3;
    }
code_r0x000180251be9:
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251bf1;
    fcn.18025b220(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251c08;
    fcn.180224990(*(undefined8 *)((int64_t)&arg_30h + iVar4), 0x1804e59a0, 0x193);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251c10;
    fcn.180255290(uVar7);
    return uVar10;
}

// ============================================================
// Function: FUN_180251c17
// Address: 0x180251c17
// Size: 98 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.180251980(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    code *pcVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBP;
    uint64_t uVar7;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    uint64_t uVar9;
    uint64_t uVar10;
    undefined8 unaff_R15;
    int64_t aiStackX_10 [3];
    undefined8 uStack_18;
    int64_t var_10h;
    uint64_t uVar8;
    
    uStack_18 = 0x18025198d;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)(in_RCX + 7) != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802519a1;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802519b9;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802519cb;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    if (in_RDX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802519de;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1802519f6;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a08;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    iVar5 = in_RCX[1];
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R14;
    if (iVar5 == 0) {
        pcVar1 = *(code **)(*in_RCX + 0x30);
        if (pcVar1 != (code *)0x0) {
            iVar5 = in_RCX[2];
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251c5d;
            uVar3 = (*pcVar1)(iVar5);
            return (uint64_t)uVar3;
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251c28;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251c40;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251c52;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    uVar8 = 0;
    uVar7 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
    if (*(int64_t *)(iVar5 + 0xa0) == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a42;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a5a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a6c;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a78;
    iVar5 = fcn.18025b2a0();
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a85;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251a9d;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_40h + iVar4));
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251aaf;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        return 0;
    }
    iVar2 = *in_RDX;
    uVar9 = 0;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar4) = unaff_R15;
    uVar10 = uVar9;
    if (iVar2 == 1) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b9f;
        iVar2 = fcn.180234b40(*(int64_t *)((int64_t)&arg_40h + iVar4), *(int64_t *)(&stack0x00000070 + iVar4), 
                              *(int64_t *)(&stack0x00000078 + iVar4), *(int64_t *)(&stack0x00000080 + iVar4), 
                              *(int64_t *)(&stack0x00000088 + iVar4));
        if (iVar2 < 1) goto code_r0x000180251be9;
code_r0x000180251bb2:
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251bba;
        iVar2 = fcn.18025b460(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4)
                              , *(int64_t *)((int64_t)&arg_30h + iVar4));
        uVar7 = uVar8;
    } else if (iVar2 == 2) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b40;
        iVar2 = fcn.180234b40(*(int64_t *)((int64_t)&arg_40h + iVar4), *(int64_t *)(&stack0x00000070 + iVar4), 
                              *(int64_t *)(&stack0x00000078 + iVar4), *(int64_t *)(&stack0x00000080 + iVar4), 
                              *(int64_t *)(&stack0x00000088 + iVar4));
        uVar7 = uVar8;
        if (iVar2 < 1) goto code_r0x000180251be9;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b56;
        uVar7 = fcn.18025ff60(*(int64_t *)((int64_t)&arg_38h + iVar4));
        if (uVar7 == 0) goto code_r0x000180251be9;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b79;
        iVar2 = fcn.18025b460(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4)
                              , *(int64_t *)((int64_t)&arg_30h + iVar4));
        if (iVar2 == 0) goto code_r0x000180251be9;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b8f;
        iVar2 = fcn.18025b310(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4))
        ;
    } else {
        if (iVar2 == 3) {
            uVar6 = *(undefined8 *)(in_RDX + 6);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b01;
            fcn.18020f750(uVar6);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251b16;
            iVar2 = fcn.18025b510(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), 
                                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4));
            uVar7 = uVar8;
            if (iVar2 == 0) goto code_r0x000180251be9;
            goto code_r0x000180251bb2;
        }
        uVar7 = uVar8;
        uVar10 = uVar8;
        if (iVar2 != 4) goto code_r0x000180251be9;
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251af3;
        iVar2 = fcn.18025b510(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), *(int64_t *)(&stack0x00000028 + iVar4)
                              , *(int64_t *)((int64_t)&arg_30h + iVar4));
    }
    uVar10 = uVar9;
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251bc6;
        uVar6 = fcn.18025b5a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8)
                              , *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 0x10), 
                              *(int64_t *)(&stack0x00000028 + iVar4));
        pcVar1 = *(code **)(in_RCX[1] + 0xa0);
        iVar5 = in_RCX[2];
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251bde;
        uVar3 = (*pcVar1)(iVar5, uVar6);
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251be9;
        fcn.180256a40(uVar6);
        uVar10 = (uint64_t)uVar3;
    }
code_r0x000180251be9:
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251bf1;
    fcn.18025b220(*(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251c08;
    fcn.180224990(*(undefined8 *)((int64_t)&arg_30h + iVar4), 0x1804e59a0, 0x193);
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x180251c10;
    fcn.180255290(uVar7);
    return uVar10;
}

// ============================================================
// Function: FUN_180251c80
// Address: 0x180251c80
// Size: 552 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t * fcn.180251c80(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t *in_RCX;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    code *pcStack_20;
    
    pcStack_20 = (code *)0x180251c93;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar8 = (int32_t *)0x0;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
    *(undefined4 *)(in_RCX + 7) = 1;
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = unaff_R14;
code_r0x000180251cb5:
    if (in_RCX[8] != 0) {
        *(undefined8 *)((int64_t)&pcStack_20 + iVar7) = 0x180251cc3;
        iVar6 = fcn.180222010();
        if (iVar6 == 0) {
            iVar1 = in_RCX[8];
            *(undefined8 *)((int64_t)&pcStack_20 + iVar7) = 0x180251cd0;
            fcn.180221d50(iVar1);
            in_RCX[8] = 0;
        }
    }
    if (in_RCX[8] == 0) {
        iVar6 = 1;
        if (in_RCX[1] != 0) {
            iVar1 = in_RCX[2];
            pcVar2 = *(code **)(*in_RCX + 0xb0);
            *(undefined8 *)((int64_t)&pcStack_20 + iVar7) = 0x180251cf5;
            iVar6 = (*pcVar2)(iVar1);
        }
        if (in_RCX[1] == 0) {
            iVar1 = in_RCX[2];
            pcVar2 = *(code **)(*in_RCX + 0x40);
            *(undefined8 *)((int64_t)&pcStack_20 + iVar7) = 0x180251d0c;
            iVar6 = (*pcVar2)(iVar1);
        }
        if (iVar6 != 0) {
            return (int32_t *)0x0;
        }
    }
    if (in_RCX[8] == 0) {
        iVar1 = in_RCX[1];
        if (iVar1 != 0) {
            iVar3 = in_RCX[2];
            *(undefined8 *)((int64_t)&var_18h + iVar7) = 0;
            *(int64_t **)((int64_t)&var_20h + iVar7) = in_RCX;
            *(undefined4 *)((int64_t)in_RCX + 0x3c) = 0;
            pcVar2 = *(code **)(iVar1 + 0xa8);
            *(int64_t **)((int64_t)&var_8h + iVar7) = in_RCX + 9;
            *(undefined8 *)((int64_t)&pcStack_20 + iVar7) = 0x180251d68;
            iVar6 = (*pcVar2)(iVar3, 0x1802cc3b0, (int64_t)&var_18h + iVar7, 0x1802b47d0);
            if (iVar6 == 0) {
                *(undefined4 *)((int64_t)in_RCX + 0x3c) = 1;
                return (int32_t *)0x0;
            }
            piVar8 = *(int32_t **)((int64_t)&var_18h + iVar7);
        }
        if (in_RCX[1] == 0) {
            iVar1 = in_RCX[0xb];
            iVar3 = in_RCX[10];
            iVar4 = in_RCX[2];
            pcVar2 = *(code **)(*in_RCX + 0x38);
            *(undefined8 *)((int64_t)&pcStack_20 + iVar7) = 0x180251d90;
            piVar8 = (int32_t *)(*pcVar2)(iVar4, iVar3, iVar1);
        }
    } else {
        *(undefined8 *)((int64_t)&pcStack_20 + iVar7) = 0x180251d2c;
        piVar8 = (int32_t *)func_0x0001802222a0();
    }
    pcVar2 = (code *)in_RCX[3];
    if ((pcVar2 != (code *)0x0) && (piVar8 != (int32_t *)0x0)) goto code_r0x000180251da1;
    goto code_r0x000180251db6;
code_r0x000180251da1:
    iVar1 = in_RCX[4];
    *(undefined8 *)((int64_t)&pcStack_20 + iVar7) = 0x180251daa;
    piVar8 = (int32_t *)(*pcVar2)(piVar8, iVar1);
    if (piVar8 != (int32_t *)0x0) {
code_r0x000180251db6:
        *(undefined8 *)((int64_t)&pcStack_20 + iVar7) = 0x180251dbe;
        func_0x0001802b4420(in_RCX + 9);
        if (piVar8 == (int32_t *)0x0) {
            return (int32_t *)0x0;
        }
        if (*(int32_t *)(in_RCX + 5) == 0) {
            return piVar8;
        }
        iVar6 = *piVar8;
        if (iVar6 == 1) {
            return piVar8;
        }
        if (iVar6 == 0) {
            return piVar8;
        }
        if (*(int32_t *)(in_RCX + 5) == iVar6) {
            return piVar8;
        }
    // switch table (6 cases) at 0x180251e90
        switch(iVar6) {
        case 1:
            uVar5 = *(undefined8 *)(piVar8 + 2);
            *(undefined8 *)((int64_t)&pcStack_20 + iVar7) = 0x180251e19;
            fcn.180224990(uVar5, 0x1804e59a0, 0x344);
            uVar5 = *(undefined8 *)(piVar8 + 4);
            *(undefined8 *)((int64_t)&pcStack_20 + iVar7) = 0x180251e2f;
            fcn.180224990(uVar5, 0x1804e59a0, 0x345);
            break;
        case 2:
        case 3:
        case 4:
            uVar5 = *(undefined8 *)(piVar8 + 2);
            *(undefined8 *)((int64_t)&pcStack_20 + iVar7) = 0x180251e3a;
            func_0x00018022ecc0(uVar5);
            break;
        case 5:
            uVar5 = *(undefined8 *)(piVar8 + 2);
            *(undefined8 *)((int64_t)&pcStack_20 + iVar7) = 0x180251e45;
            func_0x00018021fe80(uVar5);
            break;
        case 6:
            uVar5 = *(undefined8 *)(piVar8 + 2);
            *(code **)((int64_t)&pcStack_20 + iVar7) = case.default.0x180251e01;
            func_0x00018028eb90(uVar5);
        }
        *(undefined8 *)((int64_t)&pcStack_20 + iVar7) = 0x180251e65;
        fcn.180224990(piVar8, 0x1804e59a0, 0x357);
    }
    goto code_r0x000180251cb5;
}

// ============================================================
// Function: FUN_180251eb0
// Address: 0x180251eb0
// Size: 60 bytes
// ============================================================
void fcn.180251eb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_70h)
{
    int64_t iVar1;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180251eba;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_38h + iVar1) = *(undefined8 *)((int64_t)&arg_70h + iVar1);
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_R8;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180251ee7;
    fcn.180251ef0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1));
    return;
}

// ============================================================
// Function: FUN_180251ef0
// Address: 0x180251ef0
// Size: 1181 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180251ef0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined *puVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    undefined8 uVar13;
    int64_t **ppiVar14;
    int64_t **ppiVar15;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int64_t in_R8;
    undefined8 in_R9;
    int64_t **ppiVar16;
    int64_t *apiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_208h;
    int64_t var_1f8h;
    int64_t var_1e8h;
    int64_t var_1d8h;
    int64_t var_1d0h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    int64_t var_1b0h;
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_180h;
    int64_t var_170h;
    int64_t var_158h;
    int64_t var_58h;
    undefined8 uStack_48;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_48 = 0x180251f0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar8);
    *(int64_t *)((int64_t)&var_8h + iVar8) = arg_28h;
    ppiVar14 = (int64_t **)0x0;
    *(int64_t *)((int64_t)&arg_28h + iVar8) = arg_30h;
    *(int64_t *)((int64_t)&var_10h + iVar8) = in_R8;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = in_RDX;
    var_1e8h = 0x1804e5980;
    *(undefined8 *)((int64_t)apiStackX_8 + iVar8) = 1;
    *(undefined8 *)((int64_t)&var_18h + iVar8) = 1;
    *(undefined8 *)(&stack0x00000000 + iVar8) = in_R9;
    *(undefined (*) [16])((int64_t)&arg_30h + iVar8) = ZEXT816(0);
    *(undefined8 *)((int64_t)apiStackX_8 + iVar8 + 8) = 0;
    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180251f9d;
    func_0x000180223790(&var_158h, in_RCX, 0x100);
    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180251fab;
    puVar9 = (undefined *)func_0x00018045b928(&var_158h, 0x3a);
    if (puVar9 != (undefined *)0x0) {
        *puVar9 = 0;
        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180251fc5;
        iVar7 = func_0x000180223670(&var_158h, 0x1804e5980);
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180251fe0;
            iVar7 = func_0x000180498f90(puVar9 + 1, 0x180641964, 2);
            *(int64_t **)((int64_t)&var_1e8h + (uint64_t)(-(uint32_t)(iVar7 != 0) & 8)) = &var_158h;
            *(uint64_t *)((int64_t)&var_18h + iVar8) = (uint64_t)(iVar7 != 0) + 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180252008;
    func_0x000180229b10();
    ppiVar11 = ppiVar14;
    ppiVar10 = ppiVar14;
    ppiVar12 = ppiVar14;
    ppiVar16 = ppiVar14;
    ppiVar15 = ppiVar14;
    if (*(int64_t *)(&stack0x00000000 + iVar8) == 0) {
code_r0x000180252172:
        do {
            if (*(int64_t ***)((int64_t)&var_18h + iVar8) <= ppiVar16) break;
            iVar3 = (&var_1e8h)[(int64_t)ppiVar16];
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180252187;
            func_0x000180229b10();
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18025218f;
            ppiVar10 = (int64_t **)func_0x0001802cc1e0(iVar3);
            if (ppiVar10 == (int64_t **)0x0) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802521fb;
                func_0x0001802299d0();
                *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18025220d;
                ppiVar12 = (int64_t **)
                           func_0x0001802cb4a0(*(undefined8 *)((int64_t)&var_20h + iVar8), iVar3, 
                                               *(undefined8 *)((int64_t)&var_10h + iVar8));
                if (ppiVar12 == (int64_t **)0x0) goto code_r0x000180252279;
                *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18025221d;
                uVar13 = func_0x0001802cb550(ppiVar12);
                *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180252225;
                uVar13 = func_0x00018025b1a0(uVar13);
                piVar1 = ppiVar12[0x1a];
                *(undefined4 *)((int64_t)apiStackX_8 + iVar8) = 0;
                ppiVar10 = ppiVar12;
                if (piVar1 == (int64_t *)0x0) {
                    piVar1 = ppiVar12[0x11];
                    if (piVar1 == (int64_t *)0x0) goto code_r0x00018025225c;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802522dc;
                    ppiVar11 = (int64_t **)(*(code *)piVar1)(uVar13, in_RCX);
                    if (ppiVar11 == (int64_t **)0x0) goto code_r0x000180252261;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802522fd;
                    iVar7 = func_0x000180252390(ppiVar12, ppiVar11, *(undefined8 *)((int64_t)&arg_28h + iVar8), 
                                                *(undefined8 *)((int64_t)&var_10h + iVar8));
                    if (iVar7 == 0) {
                        piVar1 = ppiVar12[0x17];
                        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180252311;
                        (*(code *)piVar1)(ppiVar11);
                        ppiVar11 = ppiVar14;
                        goto code_r0x000180252261;
                    }
                } else {
                    *(int64_t *)(&stack0xffffffffffffffe0 + iVar8) = (int64_t)&arg_30h + iVar8;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180252259;
                    ppiVar11 = (int64_t **)
                               (*(code *)piVar1)(uVar13, in_RCX, *(undefined8 *)((int64_t)&arg_28h + iVar8), 0x1802b47d0
                                                );
code_r0x00018025225c:
                    if (ppiVar11 == (int64_t **)0x0) {
code_r0x000180252261:
                        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180252269;
                        fcn.1802cb4f0(ppiVar12);
                        ppiVar10 = ppiVar14;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180252279;
                func_0x0001802b4420((int64_t)&arg_30h + iVar8);
                ppiVar12 = ppiVar10;
code_r0x000180252279:
                in_R8 = *(int64_t *)((int64_t)&var_10h + iVar8);
            } else {
                *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18025219c;
                func_0x000180229900();
                piVar1 = ppiVar10[0xb];
                *(undefined4 *)((int64_t)apiStackX_8 + iVar8) = 0;
                if (piVar1 == (int64_t *)0x0) {
                    piVar1 = ppiVar10[2];
                    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802521ee;
                    ppiVar11 = (int64_t **)
                               (*(code *)piVar1)(ppiVar10, in_RCX, *(undefined8 *)(&stack0x00000000 + iVar8), 
                                                 *(undefined8 *)((int64_t)&var_8h + iVar8));
                    goto code_r0x000180252279;
                }
                in_R8 = *(int64_t *)((int64_t)&var_10h + iVar8);
                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = *(undefined8 *)((int64_t)&var_8h + iVar8);
                *(undefined8 *)(&stack0xffffffffffffffe0 + iVar8) = *(undefined8 *)(&stack0x00000000 + iVar8);
                *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802521d3;
                ppiVar11 = (int64_t **)
                           (*(code *)piVar1)(ppiVar10, in_RCX, *(undefined8 *)((int64_t)&var_20h + iVar8), in_R8);
            }
            ppiVar16 = (int64_t **)((int64_t)ppiVar16 + 1);
        } while (ppiVar11 == (int64_t **)0x0);
        if ((*(int32_t *)((int64_t)apiStackX_8 + iVar8) == 0) && (ppiVar11 != (int64_t **)0x0)) {
            if (in_R8 != 0) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802522b8;
                ppiVar14 = (int64_t **)func_0x0001802231e0(in_R8, 0x1804e59a0, 0xbd);
                *(int64_t ***)((int64_t)apiStackX_8 + iVar8 + 8) = ppiVar14;
                ppiVar15 = (int64_t **)0x0;
                if (ppiVar14 == (int64_t **)0x0) goto code_r0x00018025206d;
            }
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180252333;
            ppiVar15 = (int64_t **)fcn.180224d60(*(int64_t *)(&stack0xffffffffffffffe0 + iVar8));
            if (ppiVar15 != (int64_t **)0x0) {
                ppiVar15[6] = (int64_t *)ppiVar14;
                ppiVar15[1] = (int64_t *)ppiVar12;
                *ppiVar15 = (int64_t *)ppiVar10;
                ppiVar15[2] = (int64_t *)ppiVar11;
                ppiVar15[3] = (int64_t *)arg_38h;
                ppiVar15[4] = (int64_t *)arg_40h;
                uVar4 = *(undefined4 *)((int64_t)&arg_30h + iVar8 + 4);
                uVar5 = *(undefined4 *)((int64_t)&arg_38h + iVar8);
                uVar6 = *(undefined4 *)((int64_t)&arg_38h + iVar8 + 4);
                *(undefined4 *)(ppiVar15 + 9) = *(undefined4 *)((int64_t)&arg_30h + iVar8);
                *(undefined4 *)((int64_t)ppiVar15 + 0x4c) = uVar4;
                *(undefined4 *)(ppiVar15 + 10) = uVar5;
                *(undefined4 *)((int64_t)ppiVar15 + 0x54) = uVar6;
                *(undefined4 *)(ppiVar15 + 0xb) = 0;
                *(undefined4 *)((int64_t)ppiVar15 + 0x5c) = 0;
                *(undefined4 *)(ppiVar15 + 0xc) = 0;
                *(undefined4 *)((int64_t)ppiVar15 + 100) = 0;
                *(undefined4 *)(ppiVar15 + 0xd) = 0;
                *(undefined4 *)((int64_t)ppiVar15 + 0x6c) = 0;
                *(undefined4 *)(ppiVar15 + 0xe) = 0;
                *(undefined4 *)((int64_t)ppiVar15 + 0x74) = 0;
                *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180252385;
                func_0x0001802299d0();
                goto code_r0x00018025214c;
            }
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180252028;
        iVar7 = func_0x0001802b4a50((int64_t)&arg_30h + iVar8, *(int64_t *)(&stack0x00000000 + iVar8), 
                                    *(undefined8 *)((int64_t)&var_8h + iVar8));
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180252036;
            iVar7 = func_0x0001802b44d0((int64_t)&arg_30h + iVar8);
            if (iVar7 != 0) goto code_r0x000180252172;
        }
        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180252043;
        fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe0 + iVar8), *(int64_t *)(&stack0xffffffffffffffe8 + iVar8));
        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18025205b;
        fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe0 + iVar8), *(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                      *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_8h + iVar8), 
                      *(int64_t *)((int64_t)apiStackX_8 + iVar8 + 8));
        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18025206d;
        fcn.1802296d0(*(int64_t *)(&stack0x00000000 + iVar8));
    }
code_r0x00018025206d:
    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180252072;
    func_0x000180229900();
    if (ppiVar11 != (int64_t **)0x0) {
        var_1c8h = (int64_t)ppiVar11;
        var_1d0h = (int64_t)ppiVar12;
        _var_1c0h = ZEXT816(0);
        _var_1b0h = ZEXT816(0);
        _var_1a0h = ZEXT816(0);
        _var_190h = ZEXT816(0);
        _var_180h = ZEXT816(0);
        _var_170h = ZEXT816(0);
        var_1d8h = (int64_t)ppiVar10;
        if (ppiVar12 == (int64_t **)0x0) {
code_r0x0001802520c6:
            pcVar2 = *(code **)(var_1d8h + 0x50);
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802520cf;
            (*pcVar2)(ppiVar11);
        } else {
            piVar1 = ppiVar10[0x17];
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802520b7;
            (*(code *)piVar1)(ppiVar11);
            if (var_1d0h == 0) {
                ppiVar11 = (int64_t **)var_1c8h;
                goto code_r0x0001802520c6;
            }
        }
        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802520df;
        fcn.180222290(var_198h, 0x180196ec0);
        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802520ee;
        fcn.180222050(*(int64_t *)(&stack0xffffffffffffffe0 + iVar8), *(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                      *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&var_8h + iVar8), 
                      *(int64_t *)((int64_t)&var_18h + iVar8));
        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802520f7;
        fcn.1802cb4f0(var_1d0h);
        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18025210d;
        fcn.180224990(var_1a8h, 0x1804e59a0, 0x24e);
        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180252116;
        fcn.1802b4460(&var_190h);
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18025211e;
    fcn.1802cb4f0(ppiVar12);
    uVar13 = *(undefined8 *)((int64_t)apiStackX_8 + iVar8 + 8);
    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180252135;
    fcn.180224990(uVar13, 0x1804e59a0, 0xe9);
    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18025214a;
    fcn.180224990(ppiVar15, 0x1804e59a0, 0xea);
code_r0x00018025214c:
    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18025215b;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar8));
    return;
}

// ============================================================
// Function: FUN_180252390
// Address: 0x180252390
// Size: 247 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180252390(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h,
                      int64_t arg_90h, int64_t arg_98h)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802523aa;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_R8 != 0) {
        pcVar1 = *(code **)(in_RCX + 0xa0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802523cd;
        uVar7 = (*pcVar1)(in_RDX, in_R8);
        if ((int32_t)uVar7 == 0) {
            return uVar7;
        }
    }
    if (in_R9 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802523ed;
        iVar8 = func_0x00018022ae60(in_R8, 0x1804afa28);
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180252409;
            puVar9 = (undefined4 *)func_0x000180229e30((int64_t)&var_18h + iVar6, 0x1804afa28, in_R9, 0);
            uVar2 = puVar9[1];
            uVar3 = puVar9[2];
            uVar4 = puVar9[3];
            *(undefined4 *)((int64_t)&arg_48h + iVar6) = *puVar9;
            *(undefined4 *)((int64_t)&arg_48h + iVar6 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000050 + iVar6) = uVar3;
            *(undefined4 *)(&stack0x00000054 + iVar6) = uVar4;
            uVar2 = puVar9[5];
            uVar3 = puVar9[6];
            uVar4 = puVar9[7];
            *(undefined4 *)((int64_t)&arg_58h + iVar6) = puVar9[4];
            *(undefined4 *)((int64_t)&arg_58h + iVar6 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000060 + iVar6) = uVar3;
            *(undefined4 *)(&stack0x00000064 + iVar6) = uVar4;
            *(undefined8 *)((int64_t)&arg_68h + iVar6) = *(undefined8 *)(puVar9 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025242f;
            puVar9 = (undefined4 *)func_0x000180229ba0((int64_t)&var_18h + iVar6);
            uVar2 = puVar9[1];
            uVar3 = puVar9[2];
            uVar4 = puVar9[3];
            *(undefined4 *)((int64_t)&arg_70h + iVar6) = *puVar9;
            *(undefined4 *)((int64_t)&arg_70h + iVar6 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000078 + iVar6) = uVar3;
            *(undefined4 *)(&stack0x0000007c + iVar6) = uVar4;
            uVar2 = puVar9[5];
            uVar3 = puVar9[6];
            uVar4 = puVar9[7];
            *(undefined4 *)((int64_t)&arg_80h + iVar6) = puVar9[4];
            *(undefined4 *)((int64_t)&arg_80h + iVar6 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000088 + iVar6) = uVar3;
            *(undefined4 *)(&stack0x0000008c + iVar6) = uVar4;
            pcVar1 = *(code **)(in_RCX + 0xa0);
            *(undefined8 *)((int64_t)&arg_90h + iVar6) = *(undefined8 *)(puVar9 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025245e;
            iVar5 = (*pcVar1)(in_RDX, (int64_t)&arg_48h + iVar6);
            return (uint64_t)(iVar5 != 0);
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_180252490
// Address: 0x180252490
// Size: 185 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 fcn.180252490(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802524a0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar3 = 0;
    if (in_RCX == (int64_t *)0x0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
    if (in_RCX[1] != 0) {
        iVar1 = in_RCX[2];
        pcVar2 = *(code **)(*in_RCX + 0xb8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802524d8;
        uVar3 = (*pcVar2)(iVar1);
    }
    if (in_RCX[1] == 0) {
        iVar1 = in_RCX[2];
        pcVar2 = *(code **)(*in_RCX + 0x50);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802524ee;
        uVar3 = (*pcVar2)(iVar1);
    }
    iVar1 = in_RCX[8];
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180252500;
    fcn.180222290(iVar1, 0x180196ec0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025250f;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)(&stack0x00000050 + iVar4));
    iVar1 = in_RCX[1];
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180252518;
    fcn.1802cb4f0(iVar1);
    iVar1 = in_RCX[6];
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025252e;
    fcn.180224990(iVar1, 0x1804e59a0, 0x24e);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180252537;
    fcn.1802b4460(in_RCX + 9);
    return uVar3;
}

// ============================================================
// Function: FUN_180252550
// Address: 0x180252550
// Size: 290 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180252550(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025256a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = *(int64_t *)(in_RCX + 0x40);
    if (in_R8D < 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180252584;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025259c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802525ae;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar5 = 0xffffffff;
    } else {
        uVar2 = *(undefined8 *)(iVar1 + 0x50);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802525c1;
        iVar3 = func_0x000180222950(uVar2);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802525ca;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802525e2;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802525f4;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            uVar5 = 0xffffffff;
        } else {
            *(undefined4 *)((int64_t)&var_20h + iVar4) = 0;
            *(undefined8 *)((int64_t)&var_18h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180252617;
            uVar5 = func_0x000180253cd0(in_RCX, in_RDX, (int64_t)in_R8D, 0);
            if ((int64_t)uVar5 < 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180252624;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025263c;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025264d;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                uVar5 = 0xffffffff;
            }
            uVar2 = *(undefined8 *)(iVar1 + 0x50);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025265b;
            func_0x000180222910(uVar2);
            uVar5 = uVar5 & 0xffffffff;
        }
    }
    return uVar5;
}

// ============================================================
// Function: FUN_180252680
// Address: 0x180252680
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180252680(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    uint32_t uVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint32_t uVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int64_t *piVar10;
    undefined8 unaff_RSI;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025269a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar2 = *(int64_t **)(in_RCX + 0x40);
    if (in_R8D < 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526b4;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526cc;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526de;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
    } else {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RSI;
        if (*piVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526fa;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252712;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252724;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        } else {
            piVar3 = *(int64_t **)(*piVar2 + 0x40);
            uVar1 = *(uint32_t *)(piVar2 + 0xb);
            *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RBP;
            uVar9 = *(uint32_t *)(piVar3 + 0xb) >> 2 & 1;
            piVar10 = piVar3;
            piVar5 = piVar2;
            if (uVar9 != 0) {
                piVar10 = piVar2;
                piVar5 = piVar3;
            }
            if (((uVar9 != (uVar1 >> 2 & 1)) && (piVar3 != piVar2)) && (piVar5 != piVar10)) {
                iVar4 = piVar5[10];
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252770;
                iVar6 = func_0x000180222950(iVar4);
                if (iVar6 != 0) {
                    iVar4 = piVar10[10];
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025277d;
                    iVar6 = func_0x000180222950(iVar4);
                    if (iVar6 != 0) {
                        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0;
                        *(undefined8 *)((int64_t)&var_8h + iVar7) = 0;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802527f9;
                        uVar8 = func_0x000180253860(in_RCX, in_RDX, (int64_t)in_R8D, 0);
                        if ((int64_t)uVar8 < 0) {
                            if (uVar8 != 0xffffffffffffff90) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025280c;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                              *(int64_t *)((int64_t)&var_10h + iVar7));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252824;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                              *(int64_t *)((int64_t)&var_10h + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&var_20h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar7));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252835;
                                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                            }
                            uVar8 = 0xffffffff;
                        }
                        iVar4 = piVar3[10];
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252843;
                        func_0x000180222910(iVar4);
                        iVar4 = piVar2[10];
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025284c;
                        func_0x000180222910(iVar4);
                        return uVar8 & 0xffffffff;
                    }
                    iVar4 = piVar5[10];
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025278a;
                    func_0x000180222910(iVar4);
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025278f;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802527a7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802527b9;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1802526e8
// Address: 0x1802526e8
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180252680(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    uint32_t uVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint32_t uVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int64_t *piVar10;
    undefined8 unaff_RSI;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025269a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar2 = *(int64_t **)(in_RCX + 0x40);
    if (in_R8D < 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526b4;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526cc;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526de;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
    } else {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RSI;
        if (*piVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526fa;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252712;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252724;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        } else {
            piVar3 = *(int64_t **)(*piVar2 + 0x40);
            uVar1 = *(uint32_t *)(piVar2 + 0xb);
            *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RBP;
            uVar9 = *(uint32_t *)(piVar3 + 0xb) >> 2 & 1;
            piVar10 = piVar3;
            piVar5 = piVar2;
            if (uVar9 != 0) {
                piVar10 = piVar2;
                piVar5 = piVar3;
            }
            if (((uVar9 != (uVar1 >> 2 & 1)) && (piVar3 != piVar2)) && (piVar5 != piVar10)) {
                iVar4 = piVar5[10];
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252770;
                iVar6 = func_0x000180222950(iVar4);
                if (iVar6 != 0) {
                    iVar4 = piVar10[10];
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025277d;
                    iVar6 = func_0x000180222950(iVar4);
                    if (iVar6 != 0) {
                        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0;
                        *(undefined8 *)((int64_t)&var_8h + iVar7) = 0;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802527f9;
                        uVar8 = func_0x000180253860(in_RCX, in_RDX, (int64_t)in_R8D, 0);
                        if ((int64_t)uVar8 < 0) {
                            if (uVar8 != 0xffffffffffffff90) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025280c;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                              *(int64_t *)((int64_t)&var_10h + iVar7));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252824;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                              *(int64_t *)((int64_t)&var_10h + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&var_20h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar7));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252835;
                                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                            }
                            uVar8 = 0xffffffff;
                        }
                        iVar4 = piVar3[10];
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252843;
                        func_0x000180222910(iVar4);
                        iVar4 = piVar2[10];
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025284c;
                        func_0x000180222910(iVar4);
                        return uVar8 & 0xffffffff;
                    }
                    iVar4 = piVar5[10];
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025278a;
                    func_0x000180222910(iVar4);
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025278f;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802527a7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802527b9;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180252738
// Address: 0x180252738
// Size: 139 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180252680(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    uint32_t uVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint32_t uVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int64_t *piVar10;
    undefined8 unaff_RSI;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025269a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar2 = *(int64_t **)(in_RCX + 0x40);
    if (in_R8D < 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526b4;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526cc;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526de;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
    } else {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RSI;
        if (*piVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526fa;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252712;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252724;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        } else {
            piVar3 = *(int64_t **)(*piVar2 + 0x40);
            uVar1 = *(uint32_t *)(piVar2 + 0xb);
            *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RBP;
            uVar9 = *(uint32_t *)(piVar3 + 0xb) >> 2 & 1;
            piVar10 = piVar3;
            piVar5 = piVar2;
            if (uVar9 != 0) {
                piVar10 = piVar2;
                piVar5 = piVar3;
            }
            if (((uVar9 != (uVar1 >> 2 & 1)) && (piVar3 != piVar2)) && (piVar5 != piVar10)) {
                iVar4 = piVar5[10];
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252770;
                iVar6 = func_0x000180222950(iVar4);
                if (iVar6 != 0) {
                    iVar4 = piVar10[10];
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025277d;
                    iVar6 = func_0x000180222950(iVar4);
                    if (iVar6 != 0) {
                        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0;
                        *(undefined8 *)((int64_t)&var_8h + iVar7) = 0;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802527f9;
                        uVar8 = func_0x000180253860(in_RCX, in_RDX, (int64_t)in_R8D, 0);
                        if ((int64_t)uVar8 < 0) {
                            if (uVar8 != 0xffffffffffffff90) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025280c;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                              *(int64_t *)((int64_t)&var_10h + iVar7));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252824;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                              *(int64_t *)((int64_t)&var_10h + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&var_20h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar7));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252835;
                                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                            }
                            uVar8 = 0xffffffff;
                        }
                        iVar4 = piVar3[10];
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252843;
                        func_0x000180222910(iVar4);
                        iVar4 = piVar2[10];
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025284c;
                        func_0x000180222910(iVar4);
                        return uVar8 & 0xffffffff;
                    }
                    iVar4 = piVar5[10];
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025278a;
                    func_0x000180222910(iVar4);
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025278f;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802527a7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802527b9;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1802527c3
// Address: 0x1802527c3
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180252680(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    uint32_t uVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint32_t uVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int64_t *piVar10;
    undefined8 unaff_RSI;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025269a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar2 = *(int64_t **)(in_RCX + 0x40);
    if (in_R8D < 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526b4;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526cc;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526de;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
    } else {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RSI;
        if (*piVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526fa;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252712;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252724;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        } else {
            piVar3 = *(int64_t **)(*piVar2 + 0x40);
            uVar1 = *(uint32_t *)(piVar2 + 0xb);
            *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RBP;
            uVar9 = *(uint32_t *)(piVar3 + 0xb) >> 2 & 1;
            piVar10 = piVar3;
            piVar5 = piVar2;
            if (uVar9 != 0) {
                piVar10 = piVar2;
                piVar5 = piVar3;
            }
            if (((uVar9 != (uVar1 >> 2 & 1)) && (piVar3 != piVar2)) && (piVar5 != piVar10)) {
                iVar4 = piVar5[10];
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252770;
                iVar6 = func_0x000180222950(iVar4);
                if (iVar6 != 0) {
                    iVar4 = piVar10[10];
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025277d;
                    iVar6 = func_0x000180222950(iVar4);
                    if (iVar6 != 0) {
                        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0;
                        *(undefined8 *)((int64_t)&var_8h + iVar7) = 0;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802527f9;
                        uVar8 = func_0x000180253860(in_RCX, in_RDX, (int64_t)in_R8D, 0);
                        if ((int64_t)uVar8 < 0) {
                            if (uVar8 != 0xffffffffffffff90) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025280c;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                              *(int64_t *)((int64_t)&var_10h + iVar7));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252824;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                              *(int64_t *)((int64_t)&var_10h + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&var_20h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar7));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252835;
                                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                            }
                            uVar8 = 0xffffffff;
                        }
                        iVar4 = piVar3[10];
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252843;
                        func_0x000180222910(iVar4);
                        iVar4 = piVar2[10];
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025284c;
                        func_0x000180222910(iVar4);
                        return uVar8 & 0xffffffff;
                    }
                    iVar4 = piVar5[10];
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025278a;
                    func_0x000180222910(iVar4);
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025278f;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802527a7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802527b9;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1802527c8
// Address: 0x1802527c8
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180252680(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    uint32_t uVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint32_t uVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int64_t *piVar10;
    undefined8 unaff_RSI;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025269a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar2 = *(int64_t **)(in_RCX + 0x40);
    if (in_R8D < 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526b4;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526cc;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526de;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
    } else {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RSI;
        if (*piVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526fa;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252712;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252724;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        } else {
            piVar3 = *(int64_t **)(*piVar2 + 0x40);
            uVar1 = *(uint32_t *)(piVar2 + 0xb);
            *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RBP;
            uVar9 = *(uint32_t *)(piVar3 + 0xb) >> 2 & 1;
            piVar10 = piVar3;
            piVar5 = piVar2;
            if (uVar9 != 0) {
                piVar10 = piVar2;
                piVar5 = piVar3;
            }
            if (((uVar9 != (uVar1 >> 2 & 1)) && (piVar3 != piVar2)) && (piVar5 != piVar10)) {
                iVar4 = piVar5[10];
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252770;
                iVar6 = func_0x000180222950(iVar4);
                if (iVar6 != 0) {
                    iVar4 = piVar10[10];
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025277d;
                    iVar6 = func_0x000180222950(iVar4);
                    if (iVar6 != 0) {
                        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0;
                        *(undefined8 *)((int64_t)&var_8h + iVar7) = 0;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802527f9;
                        uVar8 = func_0x000180253860(in_RCX, in_RDX, (int64_t)in_R8D, 0);
                        if ((int64_t)uVar8 < 0) {
                            if (uVar8 != 0xffffffffffffff90) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025280c;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                              *(int64_t *)((int64_t)&var_10h + iVar7));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252824;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                              *(int64_t *)((int64_t)&var_10h + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&var_20h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar7));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252835;
                                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                            }
                            uVar8 = 0xffffffff;
                        }
                        iVar4 = piVar3[10];
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252843;
                        func_0x000180222910(iVar4);
                        iVar4 = piVar2[10];
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025284c;
                        func_0x000180222910(iVar4);
                        return uVar8 & 0xffffffff;
                    }
                    iVar4 = piVar5[10];
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025278a;
                    func_0x000180222910(iVar4);
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025278f;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802527a7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802527b9;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1802527dd
// Address: 0x1802527dd
// Size: 118 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180252680(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    uint32_t uVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint32_t uVar9;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int64_t *piVar10;
    undefined8 unaff_RSI;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025269a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar2 = *(int64_t **)(in_RCX + 0x40);
    if (in_R8D < 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526b4;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526cc;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526de;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
    } else {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RSI;
        if (*piVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802526fa;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252712;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252724;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        } else {
            piVar3 = *(int64_t **)(*piVar2 + 0x40);
            uVar1 = *(uint32_t *)(piVar2 + 0xb);
            *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RBP;
            uVar9 = *(uint32_t *)(piVar3 + 0xb) >> 2 & 1;
            piVar10 = piVar3;
            piVar5 = piVar2;
            if (uVar9 != 0) {
                piVar10 = piVar2;
                piVar5 = piVar3;
            }
            if (((uVar9 != (uVar1 >> 2 & 1)) && (piVar3 != piVar2)) && (piVar5 != piVar10)) {
                iVar4 = piVar5[10];
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252770;
                iVar6 = func_0x000180222950(iVar4);
                if (iVar6 != 0) {
                    iVar4 = piVar10[10];
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025277d;
                    iVar6 = func_0x000180222950(iVar4);
                    if (iVar6 != 0) {
                        *(undefined4 *)((int64_t)&var_10h + iVar7) = 0;
                        *(undefined8 *)((int64_t)&var_8h + iVar7) = 0;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802527f9;
                        uVar8 = func_0x000180253860(in_RCX, in_RDX, (int64_t)in_R8D, 0);
                        if ((int64_t)uVar8 < 0) {
                            if (uVar8 != 0xffffffffffffff90) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025280c;
                                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                              *(int64_t *)((int64_t)&var_10h + iVar7));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252824;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), 
                                              *(int64_t *)((int64_t)&var_10h + iVar7), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&var_20h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar7));
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252835;
                                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
                            }
                            uVar8 = 0xffffffff;
                        }
                        iVar4 = piVar3[10];
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180252843;
                        func_0x000180222910(iVar4);
                        iVar4 = piVar2[10];
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025284c;
                        func_0x000180222910(iVar4);
                        return uVar8 & 0xffffffff;
                    }
                    iVar4 = piVar5[10];
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025278a;
                    func_0x000180222910(iVar4);
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025278f;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802527a7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7));
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802527b9;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar7));
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180252860
// Address: 0x180252860
// Size: 296 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180252860(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025287a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = *(int64_t *)(in_RCX + 0x40);
    if (in_R8D < 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180252894;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802528ac;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802528be;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar5 = 0xffffffff;
    } else {
        uVar2 = *(undefined8 *)(iVar1 + 0x50);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802528d1;
        iVar3 = func_0x000180222950(uVar2);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802528da;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802528f2;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180252904;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            uVar5 = 0xffffffff;
        } else {
            *(undefined4 *)((int64_t)&var_20h + iVar4) = 0;
            *(undefined8 *)((int64_t)&var_18h + iVar4) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180252927;
            uVar5 = func_0x000180253860(in_RCX, in_RDX, (int64_t)in_R8D, 0);
            if ((int64_t)uVar5 < 0) {
                if (uVar5 != 0xffffffffffffff90) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025293a;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180252952;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180252963;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                }
                uVar5 = 0xffffffff;
            }
            uVar2 = *(undefined8 *)(iVar1 + 0x50);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180252971;
            func_0x000180222910(uVar2);
            uVar5 = uVar5 & 0xffffffff;
        }
    }
    return uVar5;
}

// ============================================================
// Function: FUN_180252990
// Address: 0x180252990
// Size: 99 bytes
// ============================================================
uint64_t fcn.180252990(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_60h, int64_t arg_70h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                      int64_t arg_98h, int64_t arg_c8h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t **ppuVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *piVar10;
    int64_t in_RCX;
    uint64_t uVar11;
    int64_t iVar12;
    int32_t in_EDX;
    uint64_t uVar13;
    undefined8 unaff_RBX;
    int64_t *piVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar15;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    uint32_t *in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 uStackX_18;
    int64_t var_20h;
    code *pcStack_8;
    
    pcStack_8 = (code *)0x18025299a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_EDX == 0x55) {
        uVar7 = **(uint64_t **)(in_RCX + 0x40);
        if (uVar7 == 0) {
            return uVar7;
        }
        return (uint64_t)*(uint32_t *)(*(int64_t *)(uVar7 + 0x40) + 0x40);
    }
    if (in_EDX != 0x8a) {
        if (in_EDX == 0x8b) {
            *(undefined8 *)((int64_t)&pcStack_8 + iVar5) = 0x1802529c0;
            func_0x000180253550();
            return 1;
        }
        *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5 + -8) = unaff_R14;
        *(undefined8 *)(&stack0x00000008 + iVar5) = 0x180252a0f;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(uint64_t *)((int64_t)&arg_70h + iVar6 + iVar5) =
             *(uint64_t *)0x1806a3940 ^ (int64_t)&uStackX_18 + iVar6 + iVar5 + -8;
        piVar14 = *(int64_t **)(in_RCX + 0x40);
        if (piVar14 != (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_c8h + iVar6 + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_98h + iVar6 + iVar5) = unaff_RSI;
            iVar4 = (int32_t)in_R8;
    // switch table (140 cases) at 0x180252d98
            switch(in_EDX) {
            case 1:
                piVar14[3] = 0;
                piVar14[5] = 0;
                piVar14[4] = 0;
                break;
            case 2:
                break;
            case 10:
                if (*(int32_t *)(in_RCX + 0x28) != 0) {
                    if (*piVar14 != 0) {
                        piVar14 = *(int64_t **)(*piVar14 + 0x40);
                    }
                    iVar1 = piVar14[10];
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b88;
                    iVar4 = func_0x000180222950(iVar1);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&arg_90h + iVar6 + iVar5) = unaff_R12;
                        iVar1 = piVar14[5];
                        uVar7 = 0x40;
                        *(undefined8 *)((int64_t)&arg_88h + iVar6 + iVar5) = unaff_R13;
                        iVar2 = piVar14[3];
                        *(undefined8 *)((int64_t)&arg_80h + iVar6 + iVar5) = unaff_R15;
                        iVar15 = (int64_t)&arg_30h + iVar6 + iVar5;
                        do {
                            uVar13 = piVar14[3];
                            iVar9 = piVar14[5];
                            uVar8 = piVar14[2] - iVar9;
                            uVar11 = uVar13;
                            if (uVar8 <= uVar13) {
                                uVar11 = uVar8;
                            }
                            if (uVar11 == 0) break;
                            uVar8 = uVar7;
                            if (uVar11 <= uVar7) {
                                uVar8 = uVar11;
                            }
                            if (iVar15 != 0) {
                                iVar12 = piVar14[1];
                                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252bff;
                                fcn.180498030(iVar15, iVar12 + iVar9, uVar8);
                                uVar13 = piVar14[3];
                            }
                            if ((uVar8 <= (uint64_t)(piVar14[2] - piVar14[5])) && (uVar8 <= uVar13)) {
                                iVar12 = piVar14[5] + uVar8;
                                iVar9 = 0;
                                if (iVar12 != piVar14[2]) {
                                    iVar9 = iVar12;
                                }
                                piVar14[5] = iVar9;
                                piVar14[3] = piVar14[3] - uVar8;
                            }
                            iVar9 = uVar8 + iVar15;
                            if (iVar15 == 0) {
                                iVar9 = iVar15;
                            }
                            uVar7 = uVar7 - uVar8;
                            iVar15 = iVar9;
                        } while (uVar7 != 0);
                        iVar15 = piVar14[10];
                        piVar14[5] = iVar1;
                        piVar14[3] = iVar2;
                        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252c5b;
                        func_0x000180222910(iVar15);
                    }
                }
                break;
            case 0x29:
                break;
            case 0x2a:
                piVar14[7] = in_R8 & 0xffffffff;
                if (*piVar14 != 0) {
                    *(uint64_t *)(*(int64_t *)(*piVar14 + 0x40) + 0x38) = in_R8 & 0xffffffff;
                }
                break;
            case 0x52:
                break;
            case 0x53:
                *in_R9 = *(uint32_t *)(piVar14 + 0xb) >> 1 & 1;
                break;
            case 0x54:
                if (*(int32_t *)(in_RCX + 0x28) != 0) {
                    piVar10 = piVar14;
                    if (*piVar14 != 0) {
                        piVar10 = *(int64_t **)(*piVar14 + 0x40);
                    }
                    if ((~*(uint32_t *)(piVar10 + 8) & 9) == 0) {
                        *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffffd;
                        *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | -(uint32_t)(iVar4 != 0) & 2;
                    }
                }
                break;
            case 0x55:
            case 0x56:
                break;
            case 0x57:
                *(int32_t *)(piVar14 + 8) = iVar4;
                break;
            case 0x58:
                break;
            case 0x59:
                *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffffe;
                *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | (uint32_t)(0 < iVar4);
                break;
            case 0x5e:
                iVar1 = piVar14[9];
                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252d63;
                func_0x00018026beb0(iVar1);
                piVar14[9] = (int64_t)in_R9;
                break;
            case 0x88:
                uVar7 = (uint64_t)iVar4;
                if (*piVar14 == 0) {
                    if (uVar7 < 0x400) {
                        uVar7 = 0x400;
                    }
                    if (piVar14[1] != 0) {
                        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252afb;
                        iVar4 = func_0x000180254140(piVar14 + 1, uVar7);
                        if (iVar4 == 0) break;
                    }
                    *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffff7;
                    piVar14[6] = uVar7;
                } else {
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252a82;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5));
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252a9a;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(code **)(&stack0x00000008 + iVar6 + iVar5) = case.0x180252a72.3;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5));
                }
                break;
            case 0x89:
                break;
            case 0x8c:
                iVar1 = piVar14[10];
                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b28;
                iVar4 = func_0x000180222850(iVar1);
                if (iVar4 != 0) {
                    iVar1 = piVar14[10];
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b57;
                    func_0x000180222910(iVar1);
                }
            }
        }
        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252ad1;
        uVar7 = func_0x000180459870(*(uint64_t *)((int64_t)&arg_70h + iVar6 + iVar5) ^
                                    (int64_t)&uStackX_18 + iVar6 + iVar5 + -8);
        return uVar7;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = 0x180253630;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if ((in_RCX == 0) || (in_R9 == (uint32_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253834;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025384c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
code_r0x000180253813:
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253822;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
        return 0;
    }
    if ((*(int64_t *)(in_RCX + 8) != 0x1804e5af0) || (*(int64_t *)(in_R9 + 2) != 0x1804e5af0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537f4;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025380c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
        goto code_r0x000180253813;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar5) = unaff_RBX;
    piVar14 = *(int64_t **)(in_R9 + 0x10);
    *(undefined8 *)((int64_t)&arg_58h + iVar6 + iVar5) = unaff_RDI;
    ppuVar3 = *(uint32_t ***)(in_RCX + 0x40);
    if ((ppuVar3 == (uint32_t **)0x0) || (piVar14 == (int64_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537e1;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
    } else {
        if ((*ppuVar3 != (uint32_t *)0x0) || (*piVar14 != 0)) {
            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537b6;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537ce;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
            goto code_r0x000180253790;
        }
        if (((uint32_t *)0x3ff < ppuVar3[6]) && (0x3ff < (uint64_t)piVar14[6])) {
            if (ppuVar3[2] != ppuVar3[6]) {
                *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536cc;
                iVar4 = func_0x0001802540d0(ppuVar3 + 1);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536d5;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536ed;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                    goto code_r0x000180253790;
                }
            }
            if (piVar14[2] != piVar14[6]) {
                *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025370a;
                iVar4 = func_0x0001802540d0(piVar14 + 1);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253713;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025372b;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025373d;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253746;
                    func_0x000180254090(ppuVar3 + 1);
                    return 0;
                }
            }
            *ppuVar3 = in_R9;
            *piVar14 = in_RCX;
            *(uint32_t *)(ppuVar3 + 0xb) = *(uint32_t *)(ppuVar3 + 0xb) & 0xfffffffb;
            *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | 4;
            *(undefined4 *)(in_RCX + 0x28) = 1;
            in_R9[10] = 1;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253770;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
    }
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253788;
    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
code_r0x000180253790:
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025379a;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_180252a00
// Address: 0x180252a00
// Size: 64 bytes
// ============================================================
uint64_t fcn.180252990(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_60h, int64_t arg_70h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                      int64_t arg_98h, int64_t arg_c8h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t **ppuVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *piVar10;
    int64_t in_RCX;
    uint64_t uVar11;
    int64_t iVar12;
    int32_t in_EDX;
    uint64_t uVar13;
    undefined8 unaff_RBX;
    int64_t *piVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar15;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    uint32_t *in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 uStackX_18;
    int64_t var_20h;
    code *pcStack_8;
    
    pcStack_8 = (code *)0x18025299a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_EDX == 0x55) {
        uVar7 = **(uint64_t **)(in_RCX + 0x40);
        if (uVar7 == 0) {
            return uVar7;
        }
        return (uint64_t)*(uint32_t *)(*(int64_t *)(uVar7 + 0x40) + 0x40);
    }
    if (in_EDX != 0x8a) {
        if (in_EDX == 0x8b) {
            *(undefined8 *)((int64_t)&pcStack_8 + iVar5) = 0x1802529c0;
            func_0x000180253550();
            return 1;
        }
        *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5 + -8) = unaff_R14;
        *(undefined8 *)(&stack0x00000008 + iVar5) = 0x180252a0f;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(uint64_t *)((int64_t)&arg_70h + iVar6 + iVar5) =
             *(uint64_t *)0x1806a3940 ^ (int64_t)&uStackX_18 + iVar6 + iVar5 + -8;
        piVar14 = *(int64_t **)(in_RCX + 0x40);
        if (piVar14 != (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_c8h + iVar6 + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_98h + iVar6 + iVar5) = unaff_RSI;
            iVar4 = (int32_t)in_R8;
    // switch table (140 cases) at 0x180252d98
            switch(in_EDX) {
            case 1:
                piVar14[3] = 0;
                piVar14[5] = 0;
                piVar14[4] = 0;
                break;
            case 2:
                break;
            case 10:
                if (*(int32_t *)(in_RCX + 0x28) != 0) {
                    if (*piVar14 != 0) {
                        piVar14 = *(int64_t **)(*piVar14 + 0x40);
                    }
                    iVar1 = piVar14[10];
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b88;
                    iVar4 = func_0x000180222950(iVar1);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&arg_90h + iVar6 + iVar5) = unaff_R12;
                        iVar1 = piVar14[5];
                        uVar7 = 0x40;
                        *(undefined8 *)((int64_t)&arg_88h + iVar6 + iVar5) = unaff_R13;
                        iVar2 = piVar14[3];
                        *(undefined8 *)((int64_t)&arg_80h + iVar6 + iVar5) = unaff_R15;
                        iVar15 = (int64_t)&arg_30h + iVar6 + iVar5;
                        do {
                            uVar13 = piVar14[3];
                            iVar9 = piVar14[5];
                            uVar8 = piVar14[2] - iVar9;
                            uVar11 = uVar13;
                            if (uVar8 <= uVar13) {
                                uVar11 = uVar8;
                            }
                            if (uVar11 == 0) break;
                            uVar8 = uVar7;
                            if (uVar11 <= uVar7) {
                                uVar8 = uVar11;
                            }
                            if (iVar15 != 0) {
                                iVar12 = piVar14[1];
                                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252bff;
                                fcn.180498030(iVar15, iVar12 + iVar9, uVar8);
                                uVar13 = piVar14[3];
                            }
                            if ((uVar8 <= (uint64_t)(piVar14[2] - piVar14[5])) && (uVar8 <= uVar13)) {
                                iVar12 = piVar14[5] + uVar8;
                                iVar9 = 0;
                                if (iVar12 != piVar14[2]) {
                                    iVar9 = iVar12;
                                }
                                piVar14[5] = iVar9;
                                piVar14[3] = piVar14[3] - uVar8;
                            }
                            iVar9 = uVar8 + iVar15;
                            if (iVar15 == 0) {
                                iVar9 = iVar15;
                            }
                            uVar7 = uVar7 - uVar8;
                            iVar15 = iVar9;
                        } while (uVar7 != 0);
                        iVar15 = piVar14[10];
                        piVar14[5] = iVar1;
                        piVar14[3] = iVar2;
                        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252c5b;
                        func_0x000180222910(iVar15);
                    }
                }
                break;
            case 0x29:
                break;
            case 0x2a:
                piVar14[7] = in_R8 & 0xffffffff;
                if (*piVar14 != 0) {
                    *(uint64_t *)(*(int64_t *)(*piVar14 + 0x40) + 0x38) = in_R8 & 0xffffffff;
                }
                break;
            case 0x52:
                break;
            case 0x53:
                *in_R9 = *(uint32_t *)(piVar14 + 0xb) >> 1 & 1;
                break;
            case 0x54:
                if (*(int32_t *)(in_RCX + 0x28) != 0) {
                    piVar10 = piVar14;
                    if (*piVar14 != 0) {
                        piVar10 = *(int64_t **)(*piVar14 + 0x40);
                    }
                    if ((~*(uint32_t *)(piVar10 + 8) & 9) == 0) {
                        *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffffd;
                        *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | -(uint32_t)(iVar4 != 0) & 2;
                    }
                }
                break;
            case 0x55:
            case 0x56:
                break;
            case 0x57:
                *(int32_t *)(piVar14 + 8) = iVar4;
                break;
            case 0x58:
                break;
            case 0x59:
                *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffffe;
                *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | (uint32_t)(0 < iVar4);
                break;
            case 0x5e:
                iVar1 = piVar14[9];
                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252d63;
                func_0x00018026beb0(iVar1);
                piVar14[9] = (int64_t)in_R9;
                break;
            case 0x88:
                uVar7 = (uint64_t)iVar4;
                if (*piVar14 == 0) {
                    if (uVar7 < 0x400) {
                        uVar7 = 0x400;
                    }
                    if (piVar14[1] != 0) {
                        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252afb;
                        iVar4 = func_0x000180254140(piVar14 + 1, uVar7);
                        if (iVar4 == 0) break;
                    }
                    *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffff7;
                    piVar14[6] = uVar7;
                } else {
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252a82;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5));
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252a9a;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(code **)(&stack0x00000008 + iVar6 + iVar5) = case.0x180252a72.3;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5));
                }
                break;
            case 0x89:
                break;
            case 0x8c:
                iVar1 = piVar14[10];
                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b28;
                iVar4 = func_0x000180222850(iVar1);
                if (iVar4 != 0) {
                    iVar1 = piVar14[10];
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b57;
                    func_0x000180222910(iVar1);
                }
            }
        }
        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252ad1;
        uVar7 = func_0x000180459870(*(uint64_t *)((int64_t)&arg_70h + iVar6 + iVar5) ^
                                    (int64_t)&uStackX_18 + iVar6 + iVar5 + -8);
        return uVar7;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = 0x180253630;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if ((in_RCX == 0) || (in_R9 == (uint32_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253834;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025384c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
code_r0x000180253813:
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253822;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
        return 0;
    }
    if ((*(int64_t *)(in_RCX + 8) != 0x1804e5af0) || (*(int64_t *)(in_R9 + 2) != 0x1804e5af0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537f4;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025380c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
        goto code_r0x000180253813;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar5) = unaff_RBX;
    piVar14 = *(int64_t **)(in_R9 + 0x10);
    *(undefined8 *)((int64_t)&arg_58h + iVar6 + iVar5) = unaff_RDI;
    ppuVar3 = *(uint32_t ***)(in_RCX + 0x40);
    if ((ppuVar3 == (uint32_t **)0x0) || (piVar14 == (int64_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537e1;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
    } else {
        if ((*ppuVar3 != (uint32_t *)0x0) || (*piVar14 != 0)) {
            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537b6;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537ce;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
            goto code_r0x000180253790;
        }
        if (((uint32_t *)0x3ff < ppuVar3[6]) && (0x3ff < (uint64_t)piVar14[6])) {
            if (ppuVar3[2] != ppuVar3[6]) {
                *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536cc;
                iVar4 = func_0x0001802540d0(ppuVar3 + 1);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536d5;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536ed;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                    goto code_r0x000180253790;
                }
            }
            if (piVar14[2] != piVar14[6]) {
                *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025370a;
                iVar4 = func_0x0001802540d0(piVar14 + 1);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253713;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025372b;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025373d;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253746;
                    func_0x000180254090(ppuVar3 + 1);
                    return 0;
                }
            }
            *ppuVar3 = in_R9;
            *piVar14 = in_RCX;
            *(uint32_t *)(ppuVar3 + 0xb) = *(uint32_t *)(ppuVar3 + 0xb) & 0xfffffffb;
            *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | 4;
            *(undefined4 *)(in_RCX + 0x28) = 1;
            in_R9[10] = 1;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253770;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
    }
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253788;
    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
code_r0x000180253790:
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025379a;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_180252a40
// Address: 0x180252a40
// Size: 132 bytes
// ============================================================
uint64_t fcn.180252990(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_60h, int64_t arg_70h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                      int64_t arg_98h, int64_t arg_c8h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t **ppuVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *piVar10;
    int64_t in_RCX;
    uint64_t uVar11;
    int64_t iVar12;
    int32_t in_EDX;
    uint64_t uVar13;
    undefined8 unaff_RBX;
    int64_t *piVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar15;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    uint32_t *in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 uStackX_18;
    int64_t var_20h;
    code *pcStack_8;
    
    pcStack_8 = (code *)0x18025299a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_EDX == 0x55) {
        uVar7 = **(uint64_t **)(in_RCX + 0x40);
        if (uVar7 == 0) {
            return uVar7;
        }
        return (uint64_t)*(uint32_t *)(*(int64_t *)(uVar7 + 0x40) + 0x40);
    }
    if (in_EDX != 0x8a) {
        if (in_EDX == 0x8b) {
            *(undefined8 *)((int64_t)&pcStack_8 + iVar5) = 0x1802529c0;
            func_0x000180253550();
            return 1;
        }
        *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5 + -8) = unaff_R14;
        *(undefined8 *)(&stack0x00000008 + iVar5) = 0x180252a0f;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(uint64_t *)((int64_t)&arg_70h + iVar6 + iVar5) =
             *(uint64_t *)0x1806a3940 ^ (int64_t)&uStackX_18 + iVar6 + iVar5 + -8;
        piVar14 = *(int64_t **)(in_RCX + 0x40);
        if (piVar14 != (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_c8h + iVar6 + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_98h + iVar6 + iVar5) = unaff_RSI;
            iVar4 = (int32_t)in_R8;
    // switch table (140 cases) at 0x180252d98
            switch(in_EDX) {
            case 1:
                piVar14[3] = 0;
                piVar14[5] = 0;
                piVar14[4] = 0;
                break;
            case 2:
                break;
            case 10:
                if (*(int32_t *)(in_RCX + 0x28) != 0) {
                    if (*piVar14 != 0) {
                        piVar14 = *(int64_t **)(*piVar14 + 0x40);
                    }
                    iVar1 = piVar14[10];
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b88;
                    iVar4 = func_0x000180222950(iVar1);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&arg_90h + iVar6 + iVar5) = unaff_R12;
                        iVar1 = piVar14[5];
                        uVar7 = 0x40;
                        *(undefined8 *)((int64_t)&arg_88h + iVar6 + iVar5) = unaff_R13;
                        iVar2 = piVar14[3];
                        *(undefined8 *)((int64_t)&arg_80h + iVar6 + iVar5) = unaff_R15;
                        iVar15 = (int64_t)&arg_30h + iVar6 + iVar5;
                        do {
                            uVar13 = piVar14[3];
                            iVar9 = piVar14[5];
                            uVar8 = piVar14[2] - iVar9;
                            uVar11 = uVar13;
                            if (uVar8 <= uVar13) {
                                uVar11 = uVar8;
                            }
                            if (uVar11 == 0) break;
                            uVar8 = uVar7;
                            if (uVar11 <= uVar7) {
                                uVar8 = uVar11;
                            }
                            if (iVar15 != 0) {
                                iVar12 = piVar14[1];
                                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252bff;
                                fcn.180498030(iVar15, iVar12 + iVar9, uVar8);
                                uVar13 = piVar14[3];
                            }
                            if ((uVar8 <= (uint64_t)(piVar14[2] - piVar14[5])) && (uVar8 <= uVar13)) {
                                iVar12 = piVar14[5] + uVar8;
                                iVar9 = 0;
                                if (iVar12 != piVar14[2]) {
                                    iVar9 = iVar12;
                                }
                                piVar14[5] = iVar9;
                                piVar14[3] = piVar14[3] - uVar8;
                            }
                            iVar9 = uVar8 + iVar15;
                            if (iVar15 == 0) {
                                iVar9 = iVar15;
                            }
                            uVar7 = uVar7 - uVar8;
                            iVar15 = iVar9;
                        } while (uVar7 != 0);
                        iVar15 = piVar14[10];
                        piVar14[5] = iVar1;
                        piVar14[3] = iVar2;
                        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252c5b;
                        func_0x000180222910(iVar15);
                    }
                }
                break;
            case 0x29:
                break;
            case 0x2a:
                piVar14[7] = in_R8 & 0xffffffff;
                if (*piVar14 != 0) {
                    *(uint64_t *)(*(int64_t *)(*piVar14 + 0x40) + 0x38) = in_R8 & 0xffffffff;
                }
                break;
            case 0x52:
                break;
            case 0x53:
                *in_R9 = *(uint32_t *)(piVar14 + 0xb) >> 1 & 1;
                break;
            case 0x54:
                if (*(int32_t *)(in_RCX + 0x28) != 0) {
                    piVar10 = piVar14;
                    if (*piVar14 != 0) {
                        piVar10 = *(int64_t **)(*piVar14 + 0x40);
                    }
                    if ((~*(uint32_t *)(piVar10 + 8) & 9) == 0) {
                        *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffffd;
                        *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | -(uint32_t)(iVar4 != 0) & 2;
                    }
                }
                break;
            case 0x55:
            case 0x56:
                break;
            case 0x57:
                *(int32_t *)(piVar14 + 8) = iVar4;
                break;
            case 0x58:
                break;
            case 0x59:
                *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffffe;
                *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | (uint32_t)(0 < iVar4);
                break;
            case 0x5e:
                iVar1 = piVar14[9];
                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252d63;
                func_0x00018026beb0(iVar1);
                piVar14[9] = (int64_t)in_R9;
                break;
            case 0x88:
                uVar7 = (uint64_t)iVar4;
                if (*piVar14 == 0) {
                    if (uVar7 < 0x400) {
                        uVar7 = 0x400;
                    }
                    if (piVar14[1] != 0) {
                        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252afb;
                        iVar4 = func_0x000180254140(piVar14 + 1, uVar7);
                        if (iVar4 == 0) break;
                    }
                    *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffff7;
                    piVar14[6] = uVar7;
                } else {
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252a82;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5));
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252a9a;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(code **)(&stack0x00000008 + iVar6 + iVar5) = case.0x180252a72.3;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5));
                }
                break;
            case 0x89:
                break;
            case 0x8c:
                iVar1 = piVar14[10];
                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b28;
                iVar4 = func_0x000180222850(iVar1);
                if (iVar4 != 0) {
                    iVar1 = piVar14[10];
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b57;
                    func_0x000180222910(iVar1);
                }
            }
        }
        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252ad1;
        uVar7 = func_0x000180459870(*(uint64_t *)((int64_t)&arg_70h + iVar6 + iVar5) ^
                                    (int64_t)&uStackX_18 + iVar6 + iVar5 + -8);
        return uVar7;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = 0x180253630;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if ((in_RCX == 0) || (in_R9 == (uint32_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253834;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025384c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
code_r0x000180253813:
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253822;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
        return 0;
    }
    if ((*(int64_t *)(in_RCX + 8) != 0x1804e5af0) || (*(int64_t *)(in_R9 + 2) != 0x1804e5af0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537f4;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025380c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
        goto code_r0x000180253813;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar5) = unaff_RBX;
    piVar14 = *(int64_t **)(in_R9 + 0x10);
    *(undefined8 *)((int64_t)&arg_58h + iVar6 + iVar5) = unaff_RDI;
    ppuVar3 = *(uint32_t ***)(in_RCX + 0x40);
    if ((ppuVar3 == (uint32_t **)0x0) || (piVar14 == (int64_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537e1;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
    } else {
        if ((*ppuVar3 != (uint32_t *)0x0) || (*piVar14 != 0)) {
            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537b6;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537ce;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
            goto code_r0x000180253790;
        }
        if (((uint32_t *)0x3ff < ppuVar3[6]) && (0x3ff < (uint64_t)piVar14[6])) {
            if (ppuVar3[2] != ppuVar3[6]) {
                *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536cc;
                iVar4 = func_0x0001802540d0(ppuVar3 + 1);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536d5;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536ed;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                    goto code_r0x000180253790;
                }
            }
            if (piVar14[2] != piVar14[6]) {
                *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025370a;
                iVar4 = func_0x0001802540d0(piVar14 + 1);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253713;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025372b;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025373d;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253746;
                    func_0x000180254090(ppuVar3 + 1);
                    return 0;
                }
            }
            *ppuVar3 = in_R9;
            *piVar14 = in_RCX;
            *(uint32_t *)(ppuVar3 + 0xb) = *(uint32_t *)(ppuVar3 + 0xb) & 0xfffffffb;
            *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | 4;
            *(undefined4 *)(in_RCX + 0x28) = 1;
            in_R9[10] = 1;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253770;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
    }
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253788;
    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
code_r0x000180253790:
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025379a;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_180252ac4
// Address: 0x180252ac4
// Size: 25 bytes
// ============================================================
uint64_t fcn.180252990(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_60h, int64_t arg_70h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                      int64_t arg_98h, int64_t arg_c8h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t **ppuVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *piVar10;
    int64_t in_RCX;
    uint64_t uVar11;
    int64_t iVar12;
    int32_t in_EDX;
    uint64_t uVar13;
    undefined8 unaff_RBX;
    int64_t *piVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar15;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    uint32_t *in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 uStackX_18;
    int64_t var_20h;
    code *pcStack_8;
    
    pcStack_8 = (code *)0x18025299a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_EDX == 0x55) {
        uVar7 = **(uint64_t **)(in_RCX + 0x40);
        if (uVar7 == 0) {
            return uVar7;
        }
        return (uint64_t)*(uint32_t *)(*(int64_t *)(uVar7 + 0x40) + 0x40);
    }
    if (in_EDX != 0x8a) {
        if (in_EDX == 0x8b) {
            *(undefined8 *)((int64_t)&pcStack_8 + iVar5) = 0x1802529c0;
            func_0x000180253550();
            return 1;
        }
        *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5 + -8) = unaff_R14;
        *(undefined8 *)(&stack0x00000008 + iVar5) = 0x180252a0f;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(uint64_t *)((int64_t)&arg_70h + iVar6 + iVar5) =
             *(uint64_t *)0x1806a3940 ^ (int64_t)&uStackX_18 + iVar6 + iVar5 + -8;
        piVar14 = *(int64_t **)(in_RCX + 0x40);
        if (piVar14 != (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_c8h + iVar6 + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_98h + iVar6 + iVar5) = unaff_RSI;
            iVar4 = (int32_t)in_R8;
    // switch table (140 cases) at 0x180252d98
            switch(in_EDX) {
            case 1:
                piVar14[3] = 0;
                piVar14[5] = 0;
                piVar14[4] = 0;
                break;
            case 2:
                break;
            case 10:
                if (*(int32_t *)(in_RCX + 0x28) != 0) {
                    if (*piVar14 != 0) {
                        piVar14 = *(int64_t **)(*piVar14 + 0x40);
                    }
                    iVar1 = piVar14[10];
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b88;
                    iVar4 = func_0x000180222950(iVar1);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&arg_90h + iVar6 + iVar5) = unaff_R12;
                        iVar1 = piVar14[5];
                        uVar7 = 0x40;
                        *(undefined8 *)((int64_t)&arg_88h + iVar6 + iVar5) = unaff_R13;
                        iVar2 = piVar14[3];
                        *(undefined8 *)((int64_t)&arg_80h + iVar6 + iVar5) = unaff_R15;
                        iVar15 = (int64_t)&arg_30h + iVar6 + iVar5;
                        do {
                            uVar13 = piVar14[3];
                            iVar9 = piVar14[5];
                            uVar8 = piVar14[2] - iVar9;
                            uVar11 = uVar13;
                            if (uVar8 <= uVar13) {
                                uVar11 = uVar8;
                            }
                            if (uVar11 == 0) break;
                            uVar8 = uVar7;
                            if (uVar11 <= uVar7) {
                                uVar8 = uVar11;
                            }
                            if (iVar15 != 0) {
                                iVar12 = piVar14[1];
                                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252bff;
                                fcn.180498030(iVar15, iVar12 + iVar9, uVar8);
                                uVar13 = piVar14[3];
                            }
                            if ((uVar8 <= (uint64_t)(piVar14[2] - piVar14[5])) && (uVar8 <= uVar13)) {
                                iVar12 = piVar14[5] + uVar8;
                                iVar9 = 0;
                                if (iVar12 != piVar14[2]) {
                                    iVar9 = iVar12;
                                }
                                piVar14[5] = iVar9;
                                piVar14[3] = piVar14[3] - uVar8;
                            }
                            iVar9 = uVar8 + iVar15;
                            if (iVar15 == 0) {
                                iVar9 = iVar15;
                            }
                            uVar7 = uVar7 - uVar8;
                            iVar15 = iVar9;
                        } while (uVar7 != 0);
                        iVar15 = piVar14[10];
                        piVar14[5] = iVar1;
                        piVar14[3] = iVar2;
                        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252c5b;
                        func_0x000180222910(iVar15);
                    }
                }
                break;
            case 0x29:
                break;
            case 0x2a:
                piVar14[7] = in_R8 & 0xffffffff;
                if (*piVar14 != 0) {
                    *(uint64_t *)(*(int64_t *)(*piVar14 + 0x40) + 0x38) = in_R8 & 0xffffffff;
                }
                break;
            case 0x52:
                break;
            case 0x53:
                *in_R9 = *(uint32_t *)(piVar14 + 0xb) >> 1 & 1;
                break;
            case 0x54:
                if (*(int32_t *)(in_RCX + 0x28) != 0) {
                    piVar10 = piVar14;
                    if (*piVar14 != 0) {
                        piVar10 = *(int64_t **)(*piVar14 + 0x40);
                    }
                    if ((~*(uint32_t *)(piVar10 + 8) & 9) == 0) {
                        *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffffd;
                        *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | -(uint32_t)(iVar4 != 0) & 2;
                    }
                }
                break;
            case 0x55:
            case 0x56:
                break;
            case 0x57:
                *(int32_t *)(piVar14 + 8) = iVar4;
                break;
            case 0x58:
                break;
            case 0x59:
                *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffffe;
                *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | (uint32_t)(0 < iVar4);
                break;
            case 0x5e:
                iVar1 = piVar14[9];
                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252d63;
                func_0x00018026beb0(iVar1);
                piVar14[9] = (int64_t)in_R9;
                break;
            case 0x88:
                uVar7 = (uint64_t)iVar4;
                if (*piVar14 == 0) {
                    if (uVar7 < 0x400) {
                        uVar7 = 0x400;
                    }
                    if (piVar14[1] != 0) {
                        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252afb;
                        iVar4 = func_0x000180254140(piVar14 + 1, uVar7);
                        if (iVar4 == 0) break;
                    }
                    *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffff7;
                    piVar14[6] = uVar7;
                } else {
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252a82;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5));
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252a9a;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(code **)(&stack0x00000008 + iVar6 + iVar5) = case.0x180252a72.3;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5));
                }
                break;
            case 0x89:
                break;
            case 0x8c:
                iVar1 = piVar14[10];
                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b28;
                iVar4 = func_0x000180222850(iVar1);
                if (iVar4 != 0) {
                    iVar1 = piVar14[10];
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b57;
                    func_0x000180222910(iVar1);
                }
            }
        }
        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252ad1;
        uVar7 = func_0x000180459870(*(uint64_t *)((int64_t)&arg_70h + iVar6 + iVar5) ^
                                    (int64_t)&uStackX_18 + iVar6 + iVar5 + -8);
        return uVar7;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = 0x180253630;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if ((in_RCX == 0) || (in_R9 == (uint32_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253834;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025384c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
code_r0x000180253813:
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253822;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
        return 0;
    }
    if ((*(int64_t *)(in_RCX + 8) != 0x1804e5af0) || (*(int64_t *)(in_R9 + 2) != 0x1804e5af0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537f4;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025380c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
        goto code_r0x000180253813;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar5) = unaff_RBX;
    piVar14 = *(int64_t **)(in_R9 + 0x10);
    *(undefined8 *)((int64_t)&arg_58h + iVar6 + iVar5) = unaff_RDI;
    ppuVar3 = *(uint32_t ***)(in_RCX + 0x40);
    if ((ppuVar3 == (uint32_t **)0x0) || (piVar14 == (int64_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537e1;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
    } else {
        if ((*ppuVar3 != (uint32_t *)0x0) || (*piVar14 != 0)) {
            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537b6;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537ce;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
            goto code_r0x000180253790;
        }
        if (((uint32_t *)0x3ff < ppuVar3[6]) && (0x3ff < (uint64_t)piVar14[6])) {
            if (ppuVar3[2] != ppuVar3[6]) {
                *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536cc;
                iVar4 = func_0x0001802540d0(ppuVar3 + 1);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536d5;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536ed;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                    goto code_r0x000180253790;
                }
            }
            if (piVar14[2] != piVar14[6]) {
                *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025370a;
                iVar4 = func_0x0001802540d0(piVar14 + 1);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253713;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025372b;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025373d;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253746;
                    func_0x000180254090(ppuVar3 + 1);
                    return 0;
                }
            }
            *ppuVar3 = in_R9;
            *piVar14 = in_RCX;
            *(uint32_t *)(ppuVar3 + 0xb) = *(uint32_t *)(ppuVar3 + 0xb) & 0xfffffffb;
            *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | 4;
            *(undefined4 *)(in_RCX + 0x28) = 1;
            in_R9[10] = 1;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253770;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
    }
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253788;
    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
code_r0x000180253790:
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025379a;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_180252add
// Address: 0x180252add
// Size: 181 bytes
// ============================================================
uint64_t fcn.180252990(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_60h, int64_t arg_70h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                      int64_t arg_98h, int64_t arg_c8h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t **ppuVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *piVar10;
    int64_t in_RCX;
    uint64_t uVar11;
    int64_t iVar12;
    int32_t in_EDX;
    uint64_t uVar13;
    undefined8 unaff_RBX;
    int64_t *piVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar15;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    uint32_t *in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 uStackX_18;
    int64_t var_20h;
    code *pcStack_8;
    
    pcStack_8 = (code *)0x18025299a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_EDX == 0x55) {
        uVar7 = **(uint64_t **)(in_RCX + 0x40);
        if (uVar7 == 0) {
            return uVar7;
        }
        return (uint64_t)*(uint32_t *)(*(int64_t *)(uVar7 + 0x40) + 0x40);
    }
    if (in_EDX != 0x8a) {
        if (in_EDX == 0x8b) {
            *(undefined8 *)((int64_t)&pcStack_8 + iVar5) = 0x1802529c0;
            func_0x000180253550();
            return 1;
        }
        *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5 + -8) = unaff_R14;
        *(undefined8 *)(&stack0x00000008 + iVar5) = 0x180252a0f;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(uint64_t *)((int64_t)&arg_70h + iVar6 + iVar5) =
             *(uint64_t *)0x1806a3940 ^ (int64_t)&uStackX_18 + iVar6 + iVar5 + -8;
        piVar14 = *(int64_t **)(in_RCX + 0x40);
        if (piVar14 != (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_c8h + iVar6 + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_98h + iVar6 + iVar5) = unaff_RSI;
            iVar4 = (int32_t)in_R8;
    // switch table (140 cases) at 0x180252d98
            switch(in_EDX) {
            case 1:
                piVar14[3] = 0;
                piVar14[5] = 0;
                piVar14[4] = 0;
                break;
            case 2:
                break;
            case 10:
                if (*(int32_t *)(in_RCX + 0x28) != 0) {
                    if (*piVar14 != 0) {
                        piVar14 = *(int64_t **)(*piVar14 + 0x40);
                    }
                    iVar1 = piVar14[10];
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b88;
                    iVar4 = func_0x000180222950(iVar1);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&arg_90h + iVar6 + iVar5) = unaff_R12;
                        iVar1 = piVar14[5];
                        uVar7 = 0x40;
                        *(undefined8 *)((int64_t)&arg_88h + iVar6 + iVar5) = unaff_R13;
                        iVar2 = piVar14[3];
                        *(undefined8 *)((int64_t)&arg_80h + iVar6 + iVar5) = unaff_R15;
                        iVar15 = (int64_t)&arg_30h + iVar6 + iVar5;
                        do {
                            uVar13 = piVar14[3];
                            iVar9 = piVar14[5];
                            uVar8 = piVar14[2] - iVar9;
                            uVar11 = uVar13;
                            if (uVar8 <= uVar13) {
                                uVar11 = uVar8;
                            }
                            if (uVar11 == 0) break;
                            uVar8 = uVar7;
                            if (uVar11 <= uVar7) {
                                uVar8 = uVar11;
                            }
                            if (iVar15 != 0) {
                                iVar12 = piVar14[1];
                                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252bff;
                                fcn.180498030(iVar15, iVar12 + iVar9, uVar8);
                                uVar13 = piVar14[3];
                            }
                            if ((uVar8 <= (uint64_t)(piVar14[2] - piVar14[5])) && (uVar8 <= uVar13)) {
                                iVar12 = piVar14[5] + uVar8;
                                iVar9 = 0;
                                if (iVar12 != piVar14[2]) {
                                    iVar9 = iVar12;
                                }
                                piVar14[5] = iVar9;
                                piVar14[3] = piVar14[3] - uVar8;
                            }
                            iVar9 = uVar8 + iVar15;
                            if (iVar15 == 0) {
                                iVar9 = iVar15;
                            }
                            uVar7 = uVar7 - uVar8;
                            iVar15 = iVar9;
                        } while (uVar7 != 0);
                        iVar15 = piVar14[10];
                        piVar14[5] = iVar1;
                        piVar14[3] = iVar2;
                        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252c5b;
                        func_0x000180222910(iVar15);
                    }
                }
                break;
            case 0x29:
                break;
            case 0x2a:
                piVar14[7] = in_R8 & 0xffffffff;
                if (*piVar14 != 0) {
                    *(uint64_t *)(*(int64_t *)(*piVar14 + 0x40) + 0x38) = in_R8 & 0xffffffff;
                }
                break;
            case 0x52:
                break;
            case 0x53:
                *in_R9 = *(uint32_t *)(piVar14 + 0xb) >> 1 & 1;
                break;
            case 0x54:
                if (*(int32_t *)(in_RCX + 0x28) != 0) {
                    piVar10 = piVar14;
                    if (*piVar14 != 0) {
                        piVar10 = *(int64_t **)(*piVar14 + 0x40);
                    }
                    if ((~*(uint32_t *)(piVar10 + 8) & 9) == 0) {
                        *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffffd;
                        *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | -(uint32_t)(iVar4 != 0) & 2;
                    }
                }
                break;
            case 0x55:
            case 0x56:
                break;
            case 0x57:
                *(int32_t *)(piVar14 + 8) = iVar4;
                break;
            case 0x58:
                break;
            case 0x59:
                *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffffe;
                *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | (uint32_t)(0 < iVar4);
                break;
            case 0x5e:
                iVar1 = piVar14[9];
                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252d63;
                func_0x00018026beb0(iVar1);
                piVar14[9] = (int64_t)in_R9;
                break;
            case 0x88:
                uVar7 = (uint64_t)iVar4;
                if (*piVar14 == 0) {
                    if (uVar7 < 0x400) {
                        uVar7 = 0x400;
                    }
                    if (piVar14[1] != 0) {
                        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252afb;
                        iVar4 = func_0x000180254140(piVar14 + 1, uVar7);
                        if (iVar4 == 0) break;
                    }
                    *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffff7;
                    piVar14[6] = uVar7;
                } else {
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252a82;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5));
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252a9a;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(code **)(&stack0x00000008 + iVar6 + iVar5) = case.0x180252a72.3;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5));
                }
                break;
            case 0x89:
                break;
            case 0x8c:
                iVar1 = piVar14[10];
                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b28;
                iVar4 = func_0x000180222850(iVar1);
                if (iVar4 != 0) {
                    iVar1 = piVar14[10];
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b57;
                    func_0x000180222910(iVar1);
                }
            }
        }
        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252ad1;
        uVar7 = func_0x000180459870(*(uint64_t *)((int64_t)&arg_70h + iVar6 + iVar5) ^
                                    (int64_t)&uStackX_18 + iVar6 + iVar5 + -8);
        return uVar7;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = 0x180253630;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if ((in_RCX == 0) || (in_R9 == (uint32_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253834;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025384c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
code_r0x000180253813:
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253822;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
        return 0;
    }
    if ((*(int64_t *)(in_RCX + 8) != 0x1804e5af0) || (*(int64_t *)(in_R9 + 2) != 0x1804e5af0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537f4;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025380c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
        goto code_r0x000180253813;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar5) = unaff_RBX;
    piVar14 = *(int64_t **)(in_R9 + 0x10);
    *(undefined8 *)((int64_t)&arg_58h + iVar6 + iVar5) = unaff_RDI;
    ppuVar3 = *(uint32_t ***)(in_RCX + 0x40);
    if ((ppuVar3 == (uint32_t **)0x0) || (piVar14 == (int64_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537e1;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
    } else {
        if ((*ppuVar3 != (uint32_t *)0x0) || (*piVar14 != 0)) {
            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537b6;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537ce;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
            goto code_r0x000180253790;
        }
        if (((uint32_t *)0x3ff < ppuVar3[6]) && (0x3ff < (uint64_t)piVar14[6])) {
            if (ppuVar3[2] != ppuVar3[6]) {
                *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536cc;
                iVar4 = func_0x0001802540d0(ppuVar3 + 1);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536d5;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536ed;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                    goto code_r0x000180253790;
                }
            }
            if (piVar14[2] != piVar14[6]) {
                *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025370a;
                iVar4 = func_0x0001802540d0(piVar14 + 1);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253713;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025372b;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025373d;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253746;
                    func_0x000180254090(ppuVar3 + 1);
                    return 0;
                }
            }
            *ppuVar3 = in_R9;
            *piVar14 = in_RCX;
            *(uint32_t *)(ppuVar3 + 0xb) = *(uint32_t *)(ppuVar3 + 0xb) & 0xfffffffb;
            *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | 4;
            *(undefined4 *)(in_RCX + 0x28) = 1;
            in_R9[10] = 1;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253770;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
    }
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253788;
    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
code_r0x000180253790:
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025379a;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_180252b92
// Address: 0x180252b92
// Size: 223 bytes
// ============================================================
uint64_t fcn.180252990(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_60h, int64_t arg_70h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                      int64_t arg_98h, int64_t arg_c8h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t **ppuVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *piVar10;
    int64_t in_RCX;
    uint64_t uVar11;
    int64_t iVar12;
    int32_t in_EDX;
    uint64_t uVar13;
    undefined8 unaff_RBX;
    int64_t *piVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar15;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    uint32_t *in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 uStackX_18;
    int64_t var_20h;
    code *pcStack_8;
    
    pcStack_8 = (code *)0x18025299a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_EDX == 0x55) {
        uVar7 = **(uint64_t **)(in_RCX + 0x40);
        if (uVar7 == 0) {
            return uVar7;
        }
        return (uint64_t)*(uint32_t *)(*(int64_t *)(uVar7 + 0x40) + 0x40);
    }
    if (in_EDX != 0x8a) {
        if (in_EDX == 0x8b) {
            *(undefined8 *)((int64_t)&pcStack_8 + iVar5) = 0x1802529c0;
            func_0x000180253550();
            return 1;
        }
        *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5 + -8) = unaff_R14;
        *(undefined8 *)(&stack0x00000008 + iVar5) = 0x180252a0f;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(uint64_t *)((int64_t)&arg_70h + iVar6 + iVar5) =
             *(uint64_t *)0x1806a3940 ^ (int64_t)&uStackX_18 + iVar6 + iVar5 + -8;
        piVar14 = *(int64_t **)(in_RCX + 0x40);
        if (piVar14 != (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_c8h + iVar6 + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_98h + iVar6 + iVar5) = unaff_RSI;
            iVar4 = (int32_t)in_R8;
    // switch table (140 cases) at 0x180252d98
            switch(in_EDX) {
            case 1:
                piVar14[3] = 0;
                piVar14[5] = 0;
                piVar14[4] = 0;
                break;
            case 2:
                break;
            case 10:
                if (*(int32_t *)(in_RCX + 0x28) != 0) {
                    if (*piVar14 != 0) {
                        piVar14 = *(int64_t **)(*piVar14 + 0x40);
                    }
                    iVar1 = piVar14[10];
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b88;
                    iVar4 = func_0x000180222950(iVar1);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&arg_90h + iVar6 + iVar5) = unaff_R12;
                        iVar1 = piVar14[5];
                        uVar7 = 0x40;
                        *(undefined8 *)((int64_t)&arg_88h + iVar6 + iVar5) = unaff_R13;
                        iVar2 = piVar14[3];
                        *(undefined8 *)((int64_t)&arg_80h + iVar6 + iVar5) = unaff_R15;
                        iVar15 = (int64_t)&arg_30h + iVar6 + iVar5;
                        do {
                            uVar13 = piVar14[3];
                            iVar9 = piVar14[5];
                            uVar8 = piVar14[2] - iVar9;
                            uVar11 = uVar13;
                            if (uVar8 <= uVar13) {
                                uVar11 = uVar8;
                            }
                            if (uVar11 == 0) break;
                            uVar8 = uVar7;
                            if (uVar11 <= uVar7) {
                                uVar8 = uVar11;
                            }
                            if (iVar15 != 0) {
                                iVar12 = piVar14[1];
                                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252bff;
                                fcn.180498030(iVar15, iVar12 + iVar9, uVar8);
                                uVar13 = piVar14[3];
                            }
                            if ((uVar8 <= (uint64_t)(piVar14[2] - piVar14[5])) && (uVar8 <= uVar13)) {
                                iVar12 = piVar14[5] + uVar8;
                                iVar9 = 0;
                                if (iVar12 != piVar14[2]) {
                                    iVar9 = iVar12;
                                }
                                piVar14[5] = iVar9;
                                piVar14[3] = piVar14[3] - uVar8;
                            }
                            iVar9 = uVar8 + iVar15;
                            if (iVar15 == 0) {
                                iVar9 = iVar15;
                            }
                            uVar7 = uVar7 - uVar8;
                            iVar15 = iVar9;
                        } while (uVar7 != 0);
                        iVar15 = piVar14[10];
                        piVar14[5] = iVar1;
                        piVar14[3] = iVar2;
                        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252c5b;
                        func_0x000180222910(iVar15);
                    }
                }
                break;
            case 0x29:
                break;
            case 0x2a:
                piVar14[7] = in_R8 & 0xffffffff;
                if (*piVar14 != 0) {
                    *(uint64_t *)(*(int64_t *)(*piVar14 + 0x40) + 0x38) = in_R8 & 0xffffffff;
                }
                break;
            case 0x52:
                break;
            case 0x53:
                *in_R9 = *(uint32_t *)(piVar14 + 0xb) >> 1 & 1;
                break;
            case 0x54:
                if (*(int32_t *)(in_RCX + 0x28) != 0) {
                    piVar10 = piVar14;
                    if (*piVar14 != 0) {
                        piVar10 = *(int64_t **)(*piVar14 + 0x40);
                    }
                    if ((~*(uint32_t *)(piVar10 + 8) & 9) == 0) {
                        *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffffd;
                        *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | -(uint32_t)(iVar4 != 0) & 2;
                    }
                }
                break;
            case 0x55:
            case 0x56:
                break;
            case 0x57:
                *(int32_t *)(piVar14 + 8) = iVar4;
                break;
            case 0x58:
                break;
            case 0x59:
                *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffffe;
                *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | (uint32_t)(0 < iVar4);
                break;
            case 0x5e:
                iVar1 = piVar14[9];
                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252d63;
                func_0x00018026beb0(iVar1);
                piVar14[9] = (int64_t)in_R9;
                break;
            case 0x88:
                uVar7 = (uint64_t)iVar4;
                if (*piVar14 == 0) {
                    if (uVar7 < 0x400) {
                        uVar7 = 0x400;
                    }
                    if (piVar14[1] != 0) {
                        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252afb;
                        iVar4 = func_0x000180254140(piVar14 + 1, uVar7);
                        if (iVar4 == 0) break;
                    }
                    *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffff7;
                    piVar14[6] = uVar7;
                } else {
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252a82;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5));
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252a9a;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(code **)(&stack0x00000008 + iVar6 + iVar5) = case.0x180252a72.3;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5));
                }
                break;
            case 0x89:
                break;
            case 0x8c:
                iVar1 = piVar14[10];
                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b28;
                iVar4 = func_0x000180222850(iVar1);
                if (iVar4 != 0) {
                    iVar1 = piVar14[10];
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b57;
                    func_0x000180222910(iVar1);
                }
            }
        }
        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252ad1;
        uVar7 = func_0x000180459870(*(uint64_t *)((int64_t)&arg_70h + iVar6 + iVar5) ^
                                    (int64_t)&uStackX_18 + iVar6 + iVar5 + -8);
        return uVar7;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = 0x180253630;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if ((in_RCX == 0) || (in_R9 == (uint32_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253834;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025384c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
code_r0x000180253813:
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253822;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
        return 0;
    }
    if ((*(int64_t *)(in_RCX + 8) != 0x1804e5af0) || (*(int64_t *)(in_R9 + 2) != 0x1804e5af0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537f4;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025380c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
        goto code_r0x000180253813;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar5) = unaff_RBX;
    piVar14 = *(int64_t **)(in_R9 + 0x10);
    *(undefined8 *)((int64_t)&arg_58h + iVar6 + iVar5) = unaff_RDI;
    ppuVar3 = *(uint32_t ***)(in_RCX + 0x40);
    if ((ppuVar3 == (uint32_t **)0x0) || (piVar14 == (int64_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537e1;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
    } else {
        if ((*ppuVar3 != (uint32_t *)0x0) || (*piVar14 != 0)) {
            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537b6;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537ce;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
            goto code_r0x000180253790;
        }
        if (((uint32_t *)0x3ff < ppuVar3[6]) && (0x3ff < (uint64_t)piVar14[6])) {
            if (ppuVar3[2] != ppuVar3[6]) {
                *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536cc;
                iVar4 = func_0x0001802540d0(ppuVar3 + 1);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536d5;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536ed;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                    goto code_r0x000180253790;
                }
            }
            if (piVar14[2] != piVar14[6]) {
                *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025370a;
                iVar4 = func_0x0001802540d0(piVar14 + 1);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253713;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025372b;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025373d;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253746;
                    func_0x000180254090(ppuVar3 + 1);
                    return 0;
                }
            }
            *ppuVar3 = in_R9;
            *piVar14 = in_RCX;
            *(uint32_t *)(ppuVar3 + 0xb) = *(uint32_t *)(ppuVar3 + 0xb) & 0xfffffffb;
            *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | 4;
            *(undefined4 *)(in_RCX + 0x28) = 1;
            in_R9[10] = 1;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253770;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
    }
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253788;
    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
code_r0x000180253790:
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025379a;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_180252c71
// Address: 0x180252c71
// Size: 19 bytes
// ============================================================
uint64_t fcn.180252990(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_60h, int64_t arg_70h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                      int64_t arg_98h, int64_t arg_c8h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t **ppuVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *piVar10;
    int64_t in_RCX;
    uint64_t uVar11;
    int64_t iVar12;
    int32_t in_EDX;
    uint64_t uVar13;
    undefined8 unaff_RBX;
    int64_t *piVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar15;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    uint32_t *in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 uStackX_18;
    int64_t var_20h;
    code *pcStack_8;
    
    pcStack_8 = (code *)0x18025299a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_EDX == 0x55) {
        uVar7 = **(uint64_t **)(in_RCX + 0x40);
        if (uVar7 == 0) {
            return uVar7;
        }
        return (uint64_t)*(uint32_t *)(*(int64_t *)(uVar7 + 0x40) + 0x40);
    }
    if (in_EDX != 0x8a) {
        if (in_EDX == 0x8b) {
            *(undefined8 *)((int64_t)&pcStack_8 + iVar5) = 0x1802529c0;
            func_0x000180253550();
            return 1;
        }
        *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5 + -8) = unaff_R14;
        *(undefined8 *)(&stack0x00000008 + iVar5) = 0x180252a0f;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(uint64_t *)((int64_t)&arg_70h + iVar6 + iVar5) =
             *(uint64_t *)0x1806a3940 ^ (int64_t)&uStackX_18 + iVar6 + iVar5 + -8;
        piVar14 = *(int64_t **)(in_RCX + 0x40);
        if (piVar14 != (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_c8h + iVar6 + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_98h + iVar6 + iVar5) = unaff_RSI;
            iVar4 = (int32_t)in_R8;
    // switch table (140 cases) at 0x180252d98
            switch(in_EDX) {
            case 1:
                piVar14[3] = 0;
                piVar14[5] = 0;
                piVar14[4] = 0;
                break;
            case 2:
                break;
            case 10:
                if (*(int32_t *)(in_RCX + 0x28) != 0) {
                    if (*piVar14 != 0) {
                        piVar14 = *(int64_t **)(*piVar14 + 0x40);
                    }
                    iVar1 = piVar14[10];
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b88;
                    iVar4 = func_0x000180222950(iVar1);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&arg_90h + iVar6 + iVar5) = unaff_R12;
                        iVar1 = piVar14[5];
                        uVar7 = 0x40;
                        *(undefined8 *)((int64_t)&arg_88h + iVar6 + iVar5) = unaff_R13;
                        iVar2 = piVar14[3];
                        *(undefined8 *)((int64_t)&arg_80h + iVar6 + iVar5) = unaff_R15;
                        iVar15 = (int64_t)&arg_30h + iVar6 + iVar5;
                        do {
                            uVar13 = piVar14[3];
                            iVar9 = piVar14[5];
                            uVar8 = piVar14[2] - iVar9;
                            uVar11 = uVar13;
                            if (uVar8 <= uVar13) {
                                uVar11 = uVar8;
                            }
                            if (uVar11 == 0) break;
                            uVar8 = uVar7;
                            if (uVar11 <= uVar7) {
                                uVar8 = uVar11;
                            }
                            if (iVar15 != 0) {
                                iVar12 = piVar14[1];
                                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252bff;
                                fcn.180498030(iVar15, iVar12 + iVar9, uVar8);
                                uVar13 = piVar14[3];
                            }
                            if ((uVar8 <= (uint64_t)(piVar14[2] - piVar14[5])) && (uVar8 <= uVar13)) {
                                iVar12 = piVar14[5] + uVar8;
                                iVar9 = 0;
                                if (iVar12 != piVar14[2]) {
                                    iVar9 = iVar12;
                                }
                                piVar14[5] = iVar9;
                                piVar14[3] = piVar14[3] - uVar8;
                            }
                            iVar9 = uVar8 + iVar15;
                            if (iVar15 == 0) {
                                iVar9 = iVar15;
                            }
                            uVar7 = uVar7 - uVar8;
                            iVar15 = iVar9;
                        } while (uVar7 != 0);
                        iVar15 = piVar14[10];
                        piVar14[5] = iVar1;
                        piVar14[3] = iVar2;
                        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252c5b;
                        func_0x000180222910(iVar15);
                    }
                }
                break;
            case 0x29:
                break;
            case 0x2a:
                piVar14[7] = in_R8 & 0xffffffff;
                if (*piVar14 != 0) {
                    *(uint64_t *)(*(int64_t *)(*piVar14 + 0x40) + 0x38) = in_R8 & 0xffffffff;
                }
                break;
            case 0x52:
                break;
            case 0x53:
                *in_R9 = *(uint32_t *)(piVar14 + 0xb) >> 1 & 1;
                break;
            case 0x54:
                if (*(int32_t *)(in_RCX + 0x28) != 0) {
                    piVar10 = piVar14;
                    if (*piVar14 != 0) {
                        piVar10 = *(int64_t **)(*piVar14 + 0x40);
                    }
                    if ((~*(uint32_t *)(piVar10 + 8) & 9) == 0) {
                        *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffffd;
                        *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | -(uint32_t)(iVar4 != 0) & 2;
                    }
                }
                break;
            case 0x55:
            case 0x56:
                break;
            case 0x57:
                *(int32_t *)(piVar14 + 8) = iVar4;
                break;
            case 0x58:
                break;
            case 0x59:
                *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffffe;
                *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | (uint32_t)(0 < iVar4);
                break;
            case 0x5e:
                iVar1 = piVar14[9];
                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252d63;
                func_0x00018026beb0(iVar1);
                piVar14[9] = (int64_t)in_R9;
                break;
            case 0x88:
                uVar7 = (uint64_t)iVar4;
                if (*piVar14 == 0) {
                    if (uVar7 < 0x400) {
                        uVar7 = 0x400;
                    }
                    if (piVar14[1] != 0) {
                        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252afb;
                        iVar4 = func_0x000180254140(piVar14 + 1, uVar7);
                        if (iVar4 == 0) break;
                    }
                    *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffff7;
                    piVar14[6] = uVar7;
                } else {
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252a82;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5));
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252a9a;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(code **)(&stack0x00000008 + iVar6 + iVar5) = case.0x180252a72.3;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5));
                }
                break;
            case 0x89:
                break;
            case 0x8c:
                iVar1 = piVar14[10];
                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b28;
                iVar4 = func_0x000180222850(iVar1);
                if (iVar4 != 0) {
                    iVar1 = piVar14[10];
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b57;
                    func_0x000180222910(iVar1);
                }
            }
        }
        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252ad1;
        uVar7 = func_0x000180459870(*(uint64_t *)((int64_t)&arg_70h + iVar6 + iVar5) ^
                                    (int64_t)&uStackX_18 + iVar6 + iVar5 + -8);
        return uVar7;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = 0x180253630;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if ((in_RCX == 0) || (in_R9 == (uint32_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253834;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025384c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
code_r0x000180253813:
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253822;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
        return 0;
    }
    if ((*(int64_t *)(in_RCX + 8) != 0x1804e5af0) || (*(int64_t *)(in_R9 + 2) != 0x1804e5af0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537f4;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025380c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
        goto code_r0x000180253813;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar5) = unaff_RBX;
    piVar14 = *(int64_t **)(in_R9 + 0x10);
    *(undefined8 *)((int64_t)&arg_58h + iVar6 + iVar5) = unaff_RDI;
    ppuVar3 = *(uint32_t ***)(in_RCX + 0x40);
    if ((ppuVar3 == (uint32_t **)0x0) || (piVar14 == (int64_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537e1;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
    } else {
        if ((*ppuVar3 != (uint32_t *)0x0) || (*piVar14 != 0)) {
            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537b6;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537ce;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
            goto code_r0x000180253790;
        }
        if (((uint32_t *)0x3ff < ppuVar3[6]) && (0x3ff < (uint64_t)piVar14[6])) {
            if (ppuVar3[2] != ppuVar3[6]) {
                *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536cc;
                iVar4 = func_0x0001802540d0(ppuVar3 + 1);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536d5;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536ed;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                    goto code_r0x000180253790;
                }
            }
            if (piVar14[2] != piVar14[6]) {
                *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025370a;
                iVar4 = func_0x0001802540d0(piVar14 + 1);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253713;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025372b;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025373d;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253746;
                    func_0x000180254090(ppuVar3 + 1);
                    return 0;
                }
            }
            *ppuVar3 = in_R9;
            *piVar14 = in_RCX;
            *(uint32_t *)(ppuVar3 + 0xb) = *(uint32_t *)(ppuVar3 + 0xb) & 0xfffffffb;
            *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | 4;
            *(undefined4 *)(in_RCX + 0x28) = 1;
            in_R9[10] = 1;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253770;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
    }
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253788;
    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
code_r0x000180253790:
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025379a;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_180252c84
// Address: 0x180252c84
// Size: 488 bytes
// ============================================================
uint64_t fcn.180252990(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_60h, int64_t arg_70h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                      int64_t arg_98h, int64_t arg_c8h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t **ppuVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *piVar10;
    int64_t in_RCX;
    uint64_t uVar11;
    int64_t iVar12;
    int32_t in_EDX;
    uint64_t uVar13;
    undefined8 unaff_RBX;
    int64_t *piVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar15;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    uint32_t *in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 uStackX_18;
    int64_t var_20h;
    code *pcStack_8;
    
    pcStack_8 = (code *)0x18025299a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_EDX == 0x55) {
        uVar7 = **(uint64_t **)(in_RCX + 0x40);
        if (uVar7 == 0) {
            return uVar7;
        }
        return (uint64_t)*(uint32_t *)(*(int64_t *)(uVar7 + 0x40) + 0x40);
    }
    if (in_EDX != 0x8a) {
        if (in_EDX == 0x8b) {
            *(undefined8 *)((int64_t)&pcStack_8 + iVar5) = 0x1802529c0;
            func_0x000180253550();
            return 1;
        }
        *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5 + -8) = unaff_R14;
        *(undefined8 *)(&stack0x00000008 + iVar5) = 0x180252a0f;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(uint64_t *)((int64_t)&arg_70h + iVar6 + iVar5) =
             *(uint64_t *)0x1806a3940 ^ (int64_t)&uStackX_18 + iVar6 + iVar5 + -8;
        piVar14 = *(int64_t **)(in_RCX + 0x40);
        if (piVar14 != (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_c8h + iVar6 + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_98h + iVar6 + iVar5) = unaff_RSI;
            iVar4 = (int32_t)in_R8;
    // switch table (140 cases) at 0x180252d98
            switch(in_EDX) {
            case 1:
                piVar14[3] = 0;
                piVar14[5] = 0;
                piVar14[4] = 0;
                break;
            case 2:
                break;
            case 10:
                if (*(int32_t *)(in_RCX + 0x28) != 0) {
                    if (*piVar14 != 0) {
                        piVar14 = *(int64_t **)(*piVar14 + 0x40);
                    }
                    iVar1 = piVar14[10];
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b88;
                    iVar4 = func_0x000180222950(iVar1);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&arg_90h + iVar6 + iVar5) = unaff_R12;
                        iVar1 = piVar14[5];
                        uVar7 = 0x40;
                        *(undefined8 *)((int64_t)&arg_88h + iVar6 + iVar5) = unaff_R13;
                        iVar2 = piVar14[3];
                        *(undefined8 *)((int64_t)&arg_80h + iVar6 + iVar5) = unaff_R15;
                        iVar15 = (int64_t)&arg_30h + iVar6 + iVar5;
                        do {
                            uVar13 = piVar14[3];
                            iVar9 = piVar14[5];
                            uVar8 = piVar14[2] - iVar9;
                            uVar11 = uVar13;
                            if (uVar8 <= uVar13) {
                                uVar11 = uVar8;
                            }
                            if (uVar11 == 0) break;
                            uVar8 = uVar7;
                            if (uVar11 <= uVar7) {
                                uVar8 = uVar11;
                            }
                            if (iVar15 != 0) {
                                iVar12 = piVar14[1];
                                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252bff;
                                fcn.180498030(iVar15, iVar12 + iVar9, uVar8);
                                uVar13 = piVar14[3];
                            }
                            if ((uVar8 <= (uint64_t)(piVar14[2] - piVar14[5])) && (uVar8 <= uVar13)) {
                                iVar12 = piVar14[5] + uVar8;
                                iVar9 = 0;
                                if (iVar12 != piVar14[2]) {
                                    iVar9 = iVar12;
                                }
                                piVar14[5] = iVar9;
                                piVar14[3] = piVar14[3] - uVar8;
                            }
                            iVar9 = uVar8 + iVar15;
                            if (iVar15 == 0) {
                                iVar9 = iVar15;
                            }
                            uVar7 = uVar7 - uVar8;
                            iVar15 = iVar9;
                        } while (uVar7 != 0);
                        iVar15 = piVar14[10];
                        piVar14[5] = iVar1;
                        piVar14[3] = iVar2;
                        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252c5b;
                        func_0x000180222910(iVar15);
                    }
                }
                break;
            case 0x29:
                break;
            case 0x2a:
                piVar14[7] = in_R8 & 0xffffffff;
                if (*piVar14 != 0) {
                    *(uint64_t *)(*(int64_t *)(*piVar14 + 0x40) + 0x38) = in_R8 & 0xffffffff;
                }
                break;
            case 0x52:
                break;
            case 0x53:
                *in_R9 = *(uint32_t *)(piVar14 + 0xb) >> 1 & 1;
                break;
            case 0x54:
                if (*(int32_t *)(in_RCX + 0x28) != 0) {
                    piVar10 = piVar14;
                    if (*piVar14 != 0) {
                        piVar10 = *(int64_t **)(*piVar14 + 0x40);
                    }
                    if ((~*(uint32_t *)(piVar10 + 8) & 9) == 0) {
                        *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffffd;
                        *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | -(uint32_t)(iVar4 != 0) & 2;
                    }
                }
                break;
            case 0x55:
            case 0x56:
                break;
            case 0x57:
                *(int32_t *)(piVar14 + 8) = iVar4;
                break;
            case 0x58:
                break;
            case 0x59:
                *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffffe;
                *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | (uint32_t)(0 < iVar4);
                break;
            case 0x5e:
                iVar1 = piVar14[9];
                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252d63;
                func_0x00018026beb0(iVar1);
                piVar14[9] = (int64_t)in_R9;
                break;
            case 0x88:
                uVar7 = (uint64_t)iVar4;
                if (*piVar14 == 0) {
                    if (uVar7 < 0x400) {
                        uVar7 = 0x400;
                    }
                    if (piVar14[1] != 0) {
                        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252afb;
                        iVar4 = func_0x000180254140(piVar14 + 1, uVar7);
                        if (iVar4 == 0) break;
                    }
                    *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffff7;
                    piVar14[6] = uVar7;
                } else {
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252a82;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5));
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252a9a;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(code **)(&stack0x00000008 + iVar6 + iVar5) = case.0x180252a72.3;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5));
                }
                break;
            case 0x89:
                break;
            case 0x8c:
                iVar1 = piVar14[10];
                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b28;
                iVar4 = func_0x000180222850(iVar1);
                if (iVar4 != 0) {
                    iVar1 = piVar14[10];
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b57;
                    func_0x000180222910(iVar1);
                }
            }
        }
        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252ad1;
        uVar7 = func_0x000180459870(*(uint64_t *)((int64_t)&arg_70h + iVar6 + iVar5) ^
                                    (int64_t)&uStackX_18 + iVar6 + iVar5 + -8);
        return uVar7;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = 0x180253630;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if ((in_RCX == 0) || (in_R9 == (uint32_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253834;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025384c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
code_r0x000180253813:
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253822;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
        return 0;
    }
    if ((*(int64_t *)(in_RCX + 8) != 0x1804e5af0) || (*(int64_t *)(in_R9 + 2) != 0x1804e5af0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537f4;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025380c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
        goto code_r0x000180253813;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar5) = unaff_RBX;
    piVar14 = *(int64_t **)(in_R9 + 0x10);
    *(undefined8 *)((int64_t)&arg_58h + iVar6 + iVar5) = unaff_RDI;
    ppuVar3 = *(uint32_t ***)(in_RCX + 0x40);
    if ((ppuVar3 == (uint32_t **)0x0) || (piVar14 == (int64_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537e1;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
    } else {
        if ((*ppuVar3 != (uint32_t *)0x0) || (*piVar14 != 0)) {
            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537b6;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537ce;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
            goto code_r0x000180253790;
        }
        if (((uint32_t *)0x3ff < ppuVar3[6]) && (0x3ff < (uint64_t)piVar14[6])) {
            if (ppuVar3[2] != ppuVar3[6]) {
                *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536cc;
                iVar4 = func_0x0001802540d0(ppuVar3 + 1);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536d5;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536ed;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                    goto code_r0x000180253790;
                }
            }
            if (piVar14[2] != piVar14[6]) {
                *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025370a;
                iVar4 = func_0x0001802540d0(piVar14 + 1);
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253713;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025372b;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025373d;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253746;
                    func_0x000180254090(ppuVar3 + 1);
                    return 0;
                }
            }
            *ppuVar3 = in_R9;
            *piVar14 = in_RCX;
            *(uint32_t *)(ppuVar3 + 0xb) = *(uint32_t *)(ppuVar3 + 0xb) & 0xfffffffb;
            *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | 4;
            *(undefined4 *)(in_RCX + 0x28) = 1;
            in_R9[10] = 1;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253770;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
    }
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253788;
    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
code_r0x000180253790:
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025379a;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_180252e70
// Address: 0x180252e70
// Size: 137 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180252e70(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180252e80;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180252e9d;
    iVar2 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)(iVar2 + 0x38) = 0x5c0;
        *(undefined8 *)(iVar2 + 0x30) = 0x3600;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180252eba;
        iVar3 = fcn.180222800();
        *(int64_t *)(iVar2 + 0x50) = iVar3;
        if (iVar3 != 0) {
            *(int64_t *)(in_RCX + 0x40) = iVar2;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180252ed8;
        fcn.180224990(iVar2, 0x1804e5c10, 0x122);
    }
    return 0;
}

// ============================================================
// Function: FUN_180252f00
// Address: 0x180252f00
// Size: 225 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180252f00(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180252f10;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180252f2d;
    iVar3 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    if (iVar3 != 0) {
        *(undefined8 *)(iVar3 + 0x38) = 0x5c0;
        *(undefined8 *)(iVar3 + 0x30) = 0x3600;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180252f4a;
        iVar4 = fcn.180222800();
        *(int64_t *)(iVar3 + 0x50) = iVar4;
        if (iVar4 != 0) {
            *(int64_t *)(in_RCX + 0x40) = iVar3;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180252f86;
            iVar1 = fcn.1802540d0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2));
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180252f8f;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180252fa7;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2));
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180252fb9;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
                return 0;
            }
            *(uint32_t *)(iVar3 + 0x58) = *(uint32_t *)(iVar3 + 0x58) | 8;
            *(undefined4 *)(in_RCX + 0x28) = 1;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180252f68;
        fcn.180224990(iVar3, 0x1804e5c10, 0x122);
    }
    return 0;
}

// ============================================================
// Function: FUN_180252ff0
// Address: 0x180252ff0
// Size: 83 bytes
// ============================================================
undefined8 fcn.180252ff0(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180252ffc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((param_1 != 0) && (iVar1 = *(int64_t *)(param_1 + 0x40), iVar1 != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180253012;
        fcn.180253550(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
        uVar2 = *(undefined8 *)(iVar1 + 0x50);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025301b;
        fcn.1802227d0(uVar2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180253030;
        fcn.180224990(iVar1, 0x1804e5c10, 0x14d);
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180253050
// Address: 0x180253050
// Size: 179 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h

void fcn.180253050(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_60h,
                  int64_t arg_70h, int64_t arg_c8h, int64_t arg_d8h, int64_t arg_f0h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t in_RCX;
    undefined4 *puVar15;
    int64_t in_RDX;
    int64_t *piVar16;
    undefined8 unaff_RBP;
    uint64_t uVar17;
    int64_t *piVar18;
    uint64_t *puVar19;
    undefined8 in_R8;
    int64_t in_R9;
    int64_t iVar20;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_38;
    int64_t var_30h;
    
    uStack_38 = 0x180253064;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    *(uint64_t *)((int64_t)&arg_60h + iVar11) = *(uint64_t *)0x1806a3940 ^ (int64_t)&var_30h + iVar11;
    puVar19 = *(uint64_t **)((int64_t)&arg_d8h + iVar11);
    uVar17 = 0;
    iVar20 = *(int64_t *)(in_RCX + 0x40);
    *(int64_t *)((int64_t)&var_8h + iVar11) = in_R9;
    *(undefined8 *)(&stack0x00000000 + iVar11) = in_R8;
    *(int64_t *)((int64_t)&var_10h + iVar11) = in_RCX;
    *(uint64_t **)(&stack0xfffffffffffffff8 + iVar11) = puVar19;
    *(int64_t *)(&stack0xfffffffffffffff0 + iVar11) = iVar20;
    if (in_R9 == 0) {
        *puVar19 = 0;
    } else {
        uVar2 = *(undefined8 *)(iVar20 + 0x50);
        *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802530c6;
        iVar10 = func_0x000180222950(uVar2);
        if (iVar10 == 0) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802530cf;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar11));
            *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802530e7;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), *(int64_t *)(&stack0x00000000 + iVar11), 
                          *(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_20h + iVar11));
            *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802530f9;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_10h + iVar11));
            *puVar19 = 0;
        } else {
            *(undefined8 *)((int64_t)&arg_c8h + iVar11) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_70h + iVar11) = unaff_R15;
            if (in_R9 == 0) {
code_r0x0001802532fa:
                *puVar19 = uVar17;
            } else {
                piVar18 = (int64_t *)(in_RDX + 0x18);
                while( true ) {
                    puVar3 = (undefined4 *)piVar18[-1];
                    puVar15 = (undefined4 *)*piVar18;
                    iVar20 = piVar18[-2];
                    iVar14 = piVar18[-3];
                    piVar4 = *(int64_t **)(in_RCX + 0x40);
                    *(undefined (*) [16])((int64_t)&arg_30h + iVar11) = ZEXT816(0);
                    *(undefined (*) [16])((int64_t)&arg_40h + iVar11) = ZEXT816(0);
                    *(undefined (*) [16])((int64_t)&arg_50h + iVar11) = ZEXT816(0);
                    *(undefined8 *)((int64_t)&arg_28h + iVar11) = 0;
                    if (((((*(int32_t *)(in_RCX + 0x28) == 0) || (piVar4 == (int64_t *)0x0)) || (piVar4[1] == 0)) ||
                        ((iVar20 != 0 && (iVar14 == 0)))) ||
                       ((puVar15 != (undefined4 *)0x0 && ((*(uint8_t *)(piVar4 + 0xb) & 2) == 0))))
                    goto code_r0x0001802532a7;
                    piVar16 = piVar4;
                    if (*piVar4 != 0) {
                        piVar16 = *(int64_t **)(*piVar4 + 0x40);
                    }
                    if ((puVar3 != (undefined4 *)0x0) && ((*(uint8_t *)(piVar16 + 8) & 2) == 0))
                    goto code_r0x0001802532a7;
                    *(int64_t *)((int64_t)&var_20h + iVar11) = iVar20;
                    puVar12 = (undefined4 *)0x1804e5bd0;
                    if (puVar3 != (undefined4 *)0x0) {
                        puVar12 = puVar3;
                    }
                    *(undefined8 *)((int64_t)&arg_50h + iVar11 + 4) = *(undefined8 *)(puVar12 + 4);
                    uVar1 = *puVar12;
                    uVar7 = puVar12[1];
                    uVar8 = puVar12[2];
                    uVar9 = puVar12[3];
                    *(undefined4 *)(&stack0x0000005c + iVar11) = puVar12[6];
                    *(undefined4 *)((int64_t)&arg_40h + iVar11 + 4) = uVar1;
                    *(undefined4 *)(&stack0x00000048 + iVar11) = uVar7;
                    *(undefined4 *)(&stack0x0000004c + iVar11) = uVar8;
                    *(undefined4 *)((int64_t)&arg_50h + iVar11) = uVar9;
                    if ((puVar15 == (undefined4 *)0x0) &&
                       (puVar15 = (undefined4 *)piVar4[9], puVar15 == (undefined4 *)0x0)) {
                        puVar15 = (undefined4 *)0x1804e5bd0;
                    }
                    uVar7 = puVar15[1];
                    uVar8 = puVar15[2];
                    uVar9 = puVar15[3];
                    uVar1 = puVar15[6];
                    uVar2 = *(undefined8 *)(puVar15 + 4);
                    iVar5 = piVar4[4];
                    iVar6 = piVar4[3];
                    *(undefined4 *)((int64_t)&arg_28h + iVar11) = *puVar15;
                    *(undefined4 *)((int64_t)&arg_28h + iVar11 + 4) = uVar7;
                    *(undefined4 *)((int64_t)&arg_30h + iVar11) = uVar8;
                    *(undefined4 *)((int64_t)&arg_30h + iVar11 + 4) = uVar9;
                    *(undefined4 *)((int64_t)&arg_40h + iVar11) = uVar1;
                    *(undefined8 *)((int64_t)&arg_38h + iVar11) = uVar2;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x18025322c;
                    iVar13 = func_0x000180253ea0(piVar4, (int64_t)&var_20h + iVar11, 0x40);
                    if (iVar13 != 0x40) break;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x180253240;
                    iVar14 = func_0x000180253ea0(piVar4, iVar14, iVar20);
                    if (iVar14 != iVar20) break;
                    if (iVar20 < 0) goto code_r0x0001802532a7;
                    piVar18[1] = 0;
                    uVar17 = uVar17 + 1;
                    piVar18 = (int64_t *)((int64_t)piVar18 + *(int64_t *)(&stack0x00000000 + iVar11));
                    if (*(uint64_t *)((int64_t)&var_8h + iVar11) <= uVar17) {
                        puVar19 = *(uint64_t **)(&stack0xfffffffffffffff8 + iVar11);
                        iVar20 = *(int64_t *)(&stack0xfffffffffffffff0 + iVar11);
                        goto code_r0x0001802532fa;
                    }
                    in_RCX = *(int64_t *)((int64_t)&var_10h + iVar11);
                }
                piVar4[4] = iVar5;
                piVar4[3] = iVar6;
code_r0x0001802532a7:
                **(uint64_t **)(&stack0xfffffffffffffff8 + iVar11) = uVar17;
                if (uVar17 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802532c0;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar11));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802532d8;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), 
                                  *(int64_t *)(&stack0x00000000 + iVar11), *(int64_t *)((int64_t)&var_8h + iVar11), 
                                  *(int64_t *)((int64_t)&var_20h + iVar11));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802532e9;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_10h + iVar11));
                    iVar20 = *(int64_t *)(&stack0xfffffffffffffff0 + iVar11);
                } else {
                    iVar20 = *(int64_t *)(&stack0xfffffffffffffff0 + iVar11);
                }
            }
            uVar2 = *(undefined8 *)(iVar20 + 0x50);
            *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x18025330d;
            func_0x000180222910(uVar2);
        }
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x180253330;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_60h + iVar11) ^ (int64_t)&var_30h + iVar11);
    return;
}

// ============================================================
// Function: FUN_180253103
// Address: 0x180253103
// Size: 541 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h

void fcn.180253050(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_60h,
                  int64_t arg_70h, int64_t arg_c8h, int64_t arg_d8h, int64_t arg_f0h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t in_RCX;
    undefined4 *puVar15;
    int64_t in_RDX;
    int64_t *piVar16;
    undefined8 unaff_RBP;
    uint64_t uVar17;
    int64_t *piVar18;
    uint64_t *puVar19;
    undefined8 in_R8;
    int64_t in_R9;
    int64_t iVar20;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_38;
    int64_t var_30h;
    
    uStack_38 = 0x180253064;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    *(uint64_t *)((int64_t)&arg_60h + iVar11) = *(uint64_t *)0x1806a3940 ^ (int64_t)&var_30h + iVar11;
    puVar19 = *(uint64_t **)((int64_t)&arg_d8h + iVar11);
    uVar17 = 0;
    iVar20 = *(int64_t *)(in_RCX + 0x40);
    *(int64_t *)((int64_t)&var_8h + iVar11) = in_R9;
    *(undefined8 *)(&stack0x00000000 + iVar11) = in_R8;
    *(int64_t *)((int64_t)&var_10h + iVar11) = in_RCX;
    *(uint64_t **)(&stack0xfffffffffffffff8 + iVar11) = puVar19;
    *(int64_t *)(&stack0xfffffffffffffff0 + iVar11) = iVar20;
    if (in_R9 == 0) {
        *puVar19 = 0;
    } else {
        uVar2 = *(undefined8 *)(iVar20 + 0x50);
        *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802530c6;
        iVar10 = func_0x000180222950(uVar2);
        if (iVar10 == 0) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802530cf;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar11));
            *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802530e7;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), *(int64_t *)(&stack0x00000000 + iVar11), 
                          *(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_20h + iVar11));
            *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802530f9;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_10h + iVar11));
            *puVar19 = 0;
        } else {
            *(undefined8 *)((int64_t)&arg_c8h + iVar11) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_70h + iVar11) = unaff_R15;
            if (in_R9 == 0) {
code_r0x0001802532fa:
                *puVar19 = uVar17;
            } else {
                piVar18 = (int64_t *)(in_RDX + 0x18);
                while( true ) {
                    puVar3 = (undefined4 *)piVar18[-1];
                    puVar15 = (undefined4 *)*piVar18;
                    iVar20 = piVar18[-2];
                    iVar14 = piVar18[-3];
                    piVar4 = *(int64_t **)(in_RCX + 0x40);
                    *(undefined (*) [16])((int64_t)&arg_30h + iVar11) = ZEXT816(0);
                    *(undefined (*) [16])((int64_t)&arg_40h + iVar11) = ZEXT816(0);
                    *(undefined (*) [16])((int64_t)&arg_50h + iVar11) = ZEXT816(0);
                    *(undefined8 *)((int64_t)&arg_28h + iVar11) = 0;
                    if (((((*(int32_t *)(in_RCX + 0x28) == 0) || (piVar4 == (int64_t *)0x0)) || (piVar4[1] == 0)) ||
                        ((iVar20 != 0 && (iVar14 == 0)))) ||
                       ((puVar15 != (undefined4 *)0x0 && ((*(uint8_t *)(piVar4 + 0xb) & 2) == 0))))
                    goto code_r0x0001802532a7;
                    piVar16 = piVar4;
                    if (*piVar4 != 0) {
                        piVar16 = *(int64_t **)(*piVar4 + 0x40);
                    }
                    if ((puVar3 != (undefined4 *)0x0) && ((*(uint8_t *)(piVar16 + 8) & 2) == 0))
                    goto code_r0x0001802532a7;
                    *(int64_t *)((int64_t)&var_20h + iVar11) = iVar20;
                    puVar12 = (undefined4 *)0x1804e5bd0;
                    if (puVar3 != (undefined4 *)0x0) {
                        puVar12 = puVar3;
                    }
                    *(undefined8 *)((int64_t)&arg_50h + iVar11 + 4) = *(undefined8 *)(puVar12 + 4);
                    uVar1 = *puVar12;
                    uVar7 = puVar12[1];
                    uVar8 = puVar12[2];
                    uVar9 = puVar12[3];
                    *(undefined4 *)(&stack0x0000005c + iVar11) = puVar12[6];
                    *(undefined4 *)((int64_t)&arg_40h + iVar11 + 4) = uVar1;
                    *(undefined4 *)(&stack0x00000048 + iVar11) = uVar7;
                    *(undefined4 *)(&stack0x0000004c + iVar11) = uVar8;
                    *(undefined4 *)((int64_t)&arg_50h + iVar11) = uVar9;
                    if ((puVar15 == (undefined4 *)0x0) &&
                       (puVar15 = (undefined4 *)piVar4[9], puVar15 == (undefined4 *)0x0)) {
                        puVar15 = (undefined4 *)0x1804e5bd0;
                    }
                    uVar7 = puVar15[1];
                    uVar8 = puVar15[2];
                    uVar9 = puVar15[3];
                    uVar1 = puVar15[6];
                    uVar2 = *(undefined8 *)(puVar15 + 4);
                    iVar5 = piVar4[4];
                    iVar6 = piVar4[3];
                    *(undefined4 *)((int64_t)&arg_28h + iVar11) = *puVar15;
                    *(undefined4 *)((int64_t)&arg_28h + iVar11 + 4) = uVar7;
                    *(undefined4 *)((int64_t)&arg_30h + iVar11) = uVar8;
                    *(undefined4 *)((int64_t)&arg_30h + iVar11 + 4) = uVar9;
                    *(undefined4 *)((int64_t)&arg_40h + iVar11) = uVar1;
                    *(undefined8 *)((int64_t)&arg_38h + iVar11) = uVar2;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x18025322c;
                    iVar13 = func_0x000180253ea0(piVar4, (int64_t)&var_20h + iVar11, 0x40);
                    if (iVar13 != 0x40) break;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x180253240;
                    iVar14 = func_0x000180253ea0(piVar4, iVar14, iVar20);
                    if (iVar14 != iVar20) break;
                    if (iVar20 < 0) goto code_r0x0001802532a7;
                    piVar18[1] = 0;
                    uVar17 = uVar17 + 1;
                    piVar18 = (int64_t *)((int64_t)piVar18 + *(int64_t *)(&stack0x00000000 + iVar11));
                    if (*(uint64_t *)((int64_t)&var_8h + iVar11) <= uVar17) {
                        puVar19 = *(uint64_t **)(&stack0xfffffffffffffff8 + iVar11);
                        iVar20 = *(int64_t *)(&stack0xfffffffffffffff0 + iVar11);
                        goto code_r0x0001802532fa;
                    }
                    in_RCX = *(int64_t *)((int64_t)&var_10h + iVar11);
                }
                piVar4[4] = iVar5;
                piVar4[3] = iVar6;
code_r0x0001802532a7:
                **(uint64_t **)(&stack0xfffffffffffffff8 + iVar11) = uVar17;
                if (uVar17 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802532c0;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar11));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802532d8;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), 
                                  *(int64_t *)(&stack0x00000000 + iVar11), *(int64_t *)((int64_t)&var_8h + iVar11), 
                                  *(int64_t *)((int64_t)&var_20h + iVar11));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802532e9;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_10h + iVar11));
                    iVar20 = *(int64_t *)(&stack0xfffffffffffffff0 + iVar11);
                } else {
                    iVar20 = *(int64_t *)(&stack0xfffffffffffffff0 + iVar11);
                }
            }
            uVar2 = *(undefined8 *)(iVar20 + 0x50);
            *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x18025330d;
            func_0x000180222910(uVar2);
        }
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x180253330;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_60h + iVar11) ^ (int64_t)&var_30h + iVar11);
    return;
}

// ============================================================
// Function: FUN_180253320
// Address: 0x180253320
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h

void fcn.180253050(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_60h,
                  int64_t arg_70h, int64_t arg_c8h, int64_t arg_d8h, int64_t arg_f0h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    undefined4 *puVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t in_RCX;
    undefined4 *puVar15;
    int64_t in_RDX;
    int64_t *piVar16;
    undefined8 unaff_RBP;
    uint64_t uVar17;
    int64_t *piVar18;
    uint64_t *puVar19;
    undefined8 in_R8;
    int64_t in_R9;
    int64_t iVar20;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_38;
    int64_t var_30h;
    
    uStack_38 = 0x180253064;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    *(uint64_t *)((int64_t)&arg_60h + iVar11) = *(uint64_t *)0x1806a3940 ^ (int64_t)&var_30h + iVar11;
    puVar19 = *(uint64_t **)((int64_t)&arg_d8h + iVar11);
    uVar17 = 0;
    iVar20 = *(int64_t *)(in_RCX + 0x40);
    *(int64_t *)((int64_t)&var_8h + iVar11) = in_R9;
    *(undefined8 *)(&stack0x00000000 + iVar11) = in_R8;
    *(int64_t *)((int64_t)&var_10h + iVar11) = in_RCX;
    *(uint64_t **)(&stack0xfffffffffffffff8 + iVar11) = puVar19;
    *(int64_t *)(&stack0xfffffffffffffff0 + iVar11) = iVar20;
    if (in_R9 == 0) {
        *puVar19 = 0;
    } else {
        uVar2 = *(undefined8 *)(iVar20 + 0x50);
        *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802530c6;
        iVar10 = func_0x000180222950(uVar2);
        if (iVar10 == 0) {
            *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802530cf;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar11));
            *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802530e7;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), *(int64_t *)(&stack0x00000000 + iVar11), 
                          *(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_20h + iVar11));
            *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802530f9;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_10h + iVar11));
            *puVar19 = 0;
        } else {
            *(undefined8 *)((int64_t)&arg_c8h + iVar11) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_70h + iVar11) = unaff_R15;
            if (in_R9 == 0) {
code_r0x0001802532fa:
                *puVar19 = uVar17;
            } else {
                piVar18 = (int64_t *)(in_RDX + 0x18);
                while( true ) {
                    puVar3 = (undefined4 *)piVar18[-1];
                    puVar15 = (undefined4 *)*piVar18;
                    iVar20 = piVar18[-2];
                    iVar14 = piVar18[-3];
                    piVar4 = *(int64_t **)(in_RCX + 0x40);
                    *(undefined (*) [16])((int64_t)&arg_30h + iVar11) = ZEXT816(0);
                    *(undefined (*) [16])((int64_t)&arg_40h + iVar11) = ZEXT816(0);
                    *(undefined (*) [16])((int64_t)&arg_50h + iVar11) = ZEXT816(0);
                    *(undefined8 *)((int64_t)&arg_28h + iVar11) = 0;
                    if (((((*(int32_t *)(in_RCX + 0x28) == 0) || (piVar4 == (int64_t *)0x0)) || (piVar4[1] == 0)) ||
                        ((iVar20 != 0 && (iVar14 == 0)))) ||
                       ((puVar15 != (undefined4 *)0x0 && ((*(uint8_t *)(piVar4 + 0xb) & 2) == 0))))
                    goto code_r0x0001802532a7;
                    piVar16 = piVar4;
                    if (*piVar4 != 0) {
                        piVar16 = *(int64_t **)(*piVar4 + 0x40);
                    }
                    if ((puVar3 != (undefined4 *)0x0) && ((*(uint8_t *)(piVar16 + 8) & 2) == 0))
                    goto code_r0x0001802532a7;
                    *(int64_t *)((int64_t)&var_20h + iVar11) = iVar20;
                    puVar12 = (undefined4 *)0x1804e5bd0;
                    if (puVar3 != (undefined4 *)0x0) {
                        puVar12 = puVar3;
                    }
                    *(undefined8 *)((int64_t)&arg_50h + iVar11 + 4) = *(undefined8 *)(puVar12 + 4);
                    uVar1 = *puVar12;
                    uVar7 = puVar12[1];
                    uVar8 = puVar12[2];
                    uVar9 = puVar12[3];
                    *(undefined4 *)(&stack0x0000005c + iVar11) = puVar12[6];
                    *(undefined4 *)((int64_t)&arg_40h + iVar11 + 4) = uVar1;
                    *(undefined4 *)(&stack0x00000048 + iVar11) = uVar7;
                    *(undefined4 *)(&stack0x0000004c + iVar11) = uVar8;
                    *(undefined4 *)((int64_t)&arg_50h + iVar11) = uVar9;
                    if ((puVar15 == (undefined4 *)0x0) &&
                       (puVar15 = (undefined4 *)piVar4[9], puVar15 == (undefined4 *)0x0)) {
                        puVar15 = (undefined4 *)0x1804e5bd0;
                    }
                    uVar7 = puVar15[1];
                    uVar8 = puVar15[2];
                    uVar9 = puVar15[3];
                    uVar1 = puVar15[6];
                    uVar2 = *(undefined8 *)(puVar15 + 4);
                    iVar5 = piVar4[4];
                    iVar6 = piVar4[3];
                    *(undefined4 *)((int64_t)&arg_28h + iVar11) = *puVar15;
                    *(undefined4 *)((int64_t)&arg_28h + iVar11 + 4) = uVar7;
                    *(undefined4 *)((int64_t)&arg_30h + iVar11) = uVar8;
                    *(undefined4 *)((int64_t)&arg_30h + iVar11 + 4) = uVar9;
                    *(undefined4 *)((int64_t)&arg_40h + iVar11) = uVar1;
                    *(undefined8 *)((int64_t)&arg_38h + iVar11) = uVar2;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x18025322c;
                    iVar13 = func_0x000180253ea0(piVar4, (int64_t)&var_20h + iVar11, 0x40);
                    if (iVar13 != 0x40) break;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x180253240;
                    iVar14 = func_0x000180253ea0(piVar4, iVar14, iVar20);
                    if (iVar14 != iVar20) break;
                    if (iVar20 < 0) goto code_r0x0001802532a7;
                    piVar18[1] = 0;
                    uVar17 = uVar17 + 1;
                    piVar18 = (int64_t *)((int64_t)piVar18 + *(int64_t *)(&stack0x00000000 + iVar11));
                    if (*(uint64_t *)((int64_t)&var_8h + iVar11) <= uVar17) {
                        puVar19 = *(uint64_t **)(&stack0xfffffffffffffff8 + iVar11);
                        iVar20 = *(int64_t *)(&stack0xfffffffffffffff0 + iVar11);
                        goto code_r0x0001802532fa;
                    }
                    in_RCX = *(int64_t *)((int64_t)&var_10h + iVar11);
                }
                piVar4[4] = iVar5;
                piVar4[3] = iVar6;
code_r0x0001802532a7:
                **(uint64_t **)(&stack0xfffffffffffffff8 + iVar11) = uVar17;
                if (uVar17 == 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802532c0;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar11));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802532d8;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar11), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar11), 
                                  *(int64_t *)(&stack0x00000000 + iVar11), *(int64_t *)((int64_t)&var_8h + iVar11), 
                                  *(int64_t *)((int64_t)&var_20h + iVar11));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x1802532e9;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_10h + iVar11));
                    iVar20 = *(int64_t *)(&stack0xfffffffffffffff0 + iVar11);
                } else {
                    iVar20 = *(int64_t *)(&stack0xfffffffffffffff0 + iVar11);
                }
            }
            uVar2 = *(undefined8 *)(iVar20 + 0x50);
            *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x18025330d;
            func_0x000180222910(uVar2);
        }
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar11) = 0x180253330;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_60h + iVar11) ^ (int64_t)&var_30h + iVar11);
    return;
}

// ============================================================
// Function: FUN_180253350
// Address: 0x180253350
// Size: 280 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Removing arg arg_64h because it doesn't fit into ProtoModel

uint64_t fcn.180253350(int64_t placeholder_0, int64_t placeholder_1, int64_t arg3, int64_t arg_38h, int64_t arg_40h,
                      int64_t arg_48h, int64_t arg_50h, int64_t arg_60h, int64_t arg_c0h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 unaff_RDI;
    uint64_t uVar7;
    uint64_t in_R9;
    int64_t *piVar8;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18025336c;
    var_18h = arg3;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    piVar8 = *(int64_t **)(placeholder_0 + 0x40);
    if (in_R9 == 0) {
        **(undefined8 **)((int64_t)&arg_60h + iVar2) = 0;
        return 1;
    }
    if (*(int32_t *)(placeholder_0 + 0x28) == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1802533b0;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2));
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1802533c8;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1802533da;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar2));
        **(undefined8 **)((int64_t)&arg_60h + iVar2) = 0;
        return 0;
    }
    if (*piVar8 != 0) {
        piVar8 = *(int64_t **)(*piVar8 + 0x40);
    }
    iVar3 = piVar8[10];
    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180253412;
    iVar1 = fcn.180222950(iVar3);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18025341b;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2));
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180253433;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180253445;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar2));
        **(undefined8 **)((int64_t)&arg_60h + iVar2) = 0;
        return 0;
    }
    uVar6 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_R14;
    uVar7 = uVar6;
    uVar5 = 1;
    if (in_R9 != 0) {
        piVar4 = (int64_t *)(placeholder_1 + 8);
        do {
            iVar3 = piVar4[1];
            *(undefined4 *)(&stack0x00000000 + iVar2) = 1;
            *(int64_t *)((int64_t)&var_8h + iVar2) = iVar3;
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1802534a2;
            iVar3 = fcn.180253860(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                                  *(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)((int64_t)&arg_60h + iVar2), 
                                  *(int64_t *)(&stack0x00000068 + iVar2), *(int64_t *)(&stack0x00000070 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_c0h + iVar2), *(int64_t *)(&stack0x000000c8 + iVar2));
            if (iVar3 < 0) {
                **(uint64_t **)((int64_t)&arg_60h + iVar2) = uVar7;
                if (uVar7 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180253506;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18025351e;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2))
                    ;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180253531;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar2));
                    uVar5 = uVar6;
                }
                goto code_r0x0001802534c9;
            }
            *piVar4 = iVar3;
            uVar7 = uVar7 + 1;
            piVar4[3] = 0;
            piVar4 = (int64_t *)((int64_t)piVar4 + *(int64_t *)((int64_t)&arg_48h + iVar2));
        } while (uVar7 < in_R9);
    }
    **(uint64_t **)((int64_t)&arg_60h + iVar2) = uVar7;
code_r0x0001802534c9:
    iVar3 = piVar8[10];
    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1802534d3;
    fcn.180222910(iVar3);
    return uVar5;
}

// ============================================================
// Function: FUN_180253468
// Address: 0x180253468
// Size: 137 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Removing arg arg_64h because it doesn't fit into ProtoModel

uint64_t fcn.180253350(int64_t placeholder_0, int64_t placeholder_1, int64_t arg3, int64_t arg_38h, int64_t arg_40h,
                      int64_t arg_48h, int64_t arg_50h, int64_t arg_60h, int64_t arg_c0h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 unaff_RDI;
    uint64_t uVar7;
    uint64_t in_R9;
    int64_t *piVar8;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18025336c;
    var_18h = arg3;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    piVar8 = *(int64_t **)(placeholder_0 + 0x40);
    if (in_R9 == 0) {
        **(undefined8 **)((int64_t)&arg_60h + iVar2) = 0;
        return 1;
    }
    if (*(int32_t *)(placeholder_0 + 0x28) == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1802533b0;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2));
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1802533c8;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1802533da;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar2));
        **(undefined8 **)((int64_t)&arg_60h + iVar2) = 0;
        return 0;
    }
    if (*piVar8 != 0) {
        piVar8 = *(int64_t **)(*piVar8 + 0x40);
    }
    iVar3 = piVar8[10];
    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180253412;
    iVar1 = fcn.180222950(iVar3);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18025341b;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2));
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180253433;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180253445;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar2));
        **(undefined8 **)((int64_t)&arg_60h + iVar2) = 0;
        return 0;
    }
    uVar6 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_R14;
    uVar7 = uVar6;
    uVar5 = 1;
    if (in_R9 != 0) {
        piVar4 = (int64_t *)(placeholder_1 + 8);
        do {
            iVar3 = piVar4[1];
            *(undefined4 *)(&stack0x00000000 + iVar2) = 1;
            *(int64_t *)((int64_t)&var_8h + iVar2) = iVar3;
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1802534a2;
            iVar3 = fcn.180253860(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                                  *(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)((int64_t)&arg_60h + iVar2), 
                                  *(int64_t *)(&stack0x00000068 + iVar2), *(int64_t *)(&stack0x00000070 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_c0h + iVar2), *(int64_t *)(&stack0x000000c8 + iVar2));
            if (iVar3 < 0) {
                **(uint64_t **)((int64_t)&arg_60h + iVar2) = uVar7;
                if (uVar7 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180253506;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18025351e;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2))
                    ;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180253531;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar2));
                    uVar5 = uVar6;
                }
                goto code_r0x0001802534c9;
            }
            *piVar4 = iVar3;
            uVar7 = uVar7 + 1;
            piVar4[3] = 0;
            piVar4 = (int64_t *)((int64_t)piVar4 + *(int64_t *)((int64_t)&arg_48h + iVar2));
        } while (uVar7 < in_R9);
    }
    **(uint64_t **)((int64_t)&arg_60h + iVar2) = uVar7;
code_r0x0001802534c9:
    iVar3 = piVar8[10];
    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1802534d3;
    fcn.180222910(iVar3);
    return uVar5;
}

// ============================================================
// Function: FUN_1802534f1
// Address: 0x1802534f1
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_6ch
// WARNING: [rz-ghidra] Removing arg arg_64h because it doesn't fit into ProtoModel

uint64_t fcn.180253350(int64_t placeholder_0, int64_t placeholder_1, int64_t arg3, int64_t arg_38h, int64_t arg_40h,
                      int64_t arg_48h, int64_t arg_50h, int64_t arg_60h, int64_t arg_c0h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 unaff_RDI;
    uint64_t uVar7;
    uint64_t in_R9;
    int64_t *piVar8;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18025336c;
    var_18h = arg3;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    piVar8 = *(int64_t **)(placeholder_0 + 0x40);
    if (in_R9 == 0) {
        **(undefined8 **)((int64_t)&arg_60h + iVar2) = 0;
        return 1;
    }
    if (*(int32_t *)(placeholder_0 + 0x28) == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1802533b0;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2));
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1802533c8;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1802533da;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar2));
        **(undefined8 **)((int64_t)&arg_60h + iVar2) = 0;
        return 0;
    }
    if (*piVar8 != 0) {
        piVar8 = *(int64_t **)(*piVar8 + 0x40);
    }
    iVar3 = piVar8[10];
    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180253412;
    iVar1 = fcn.180222950(iVar3);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18025341b;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2));
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180253433;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180253445;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar2));
        **(undefined8 **)((int64_t)&arg_60h + iVar2) = 0;
        return 0;
    }
    uVar6 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_R14;
    uVar7 = uVar6;
    uVar5 = 1;
    if (in_R9 != 0) {
        piVar4 = (int64_t *)(placeholder_1 + 8);
        do {
            iVar3 = piVar4[1];
            *(undefined4 *)(&stack0x00000000 + iVar2) = 1;
            *(int64_t *)((int64_t)&var_8h + iVar2) = iVar3;
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1802534a2;
            iVar3 = fcn.180253860(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                                  *(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)((int64_t)&arg_60h + iVar2), 
                                  *(int64_t *)(&stack0x00000068 + iVar2), *(int64_t *)(&stack0x00000070 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_c0h + iVar2), *(int64_t *)(&stack0x000000c8 + iVar2));
            if (iVar3 < 0) {
                **(uint64_t **)((int64_t)&arg_60h + iVar2) = uVar7;
                if (uVar7 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180253506;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18025351e;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar2 + 8), *(int64_t *)(&stack0x00000028 + iVar2))
                    ;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x180253531;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar2));
                    uVar5 = uVar6;
                }
                goto code_r0x0001802534c9;
            }
            *piVar4 = iVar3;
            uVar7 = uVar7 + 1;
            piVar4[3] = 0;
            piVar4 = (int64_t *)((int64_t)piVar4 + *(int64_t *)((int64_t)&arg_48h + iVar2));
        } while (uVar7 < in_R9);
    }
    **(uint64_t **)((int64_t)&arg_60h + iVar2) = uVar7;
code_r0x0001802534c9:
    iVar3 = piVar8[10];
    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1802534d3;
    fcn.180222910(iVar3);
    return uVar5;
}

// ============================================================
// Function: FUN_180253550
// Address: 0x180253550
// Size: 102 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.180253550(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    bool bVar6;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025356b;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    piVar1 = *(int64_t **)(in_RCX + 0x40);
    iVar2 = piVar1[1];
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025358b;
    fcn.180224990(iVar2, 0x1804e5c10, 0x30);
    piVar1[1] = 0;
    piVar1[2] = 0;
    piVar1[3] = 0;
    *(undefined4 *)(in_RCX + 0x28) = 0;
    iVar2 = piVar1[9];
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802535a7;
    func_0x00018026beb0(iVar2);
    iVar2 = *piVar1;
    if (iVar2 == 0) {
        bVar6 = true;
    } else {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        piVar3 = *(int64_t **)(iVar2 + 0x40);
        bVar6 = *piVar3 == in_RCX;
        if (bVar6) {
            iVar4 = piVar3[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802535de;
            fcn.180224990(iVar4, 0x1804e5c10, 0x30);
            piVar3[1] = 0;
            piVar3[2] = 0;
            piVar3[3] = 0;
            *(undefined4 *)(iVar2 + 0x28) = 0;
            *piVar1 = 0;
            *piVar3 = 0;
        }
    }
    return bVar6;
}

// ============================================================
// Function: FUN_1802535b6
// Address: 0x1802535b6
// Size: 72 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.180253550(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    bool bVar6;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025356b;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    piVar1 = *(int64_t **)(in_RCX + 0x40);
    iVar2 = piVar1[1];
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025358b;
    fcn.180224990(iVar2, 0x1804e5c10, 0x30);
    piVar1[1] = 0;
    piVar1[2] = 0;
    piVar1[3] = 0;
    *(undefined4 *)(in_RCX + 0x28) = 0;
    iVar2 = piVar1[9];
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802535a7;
    func_0x00018026beb0(iVar2);
    iVar2 = *piVar1;
    if (iVar2 == 0) {
        bVar6 = true;
    } else {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        piVar3 = *(int64_t **)(iVar2 + 0x40);
        bVar6 = *piVar3 == in_RCX;
        if (bVar6) {
            iVar4 = piVar3[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802535de;
            fcn.180224990(iVar4, 0x1804e5c10, 0x30);
            piVar3[1] = 0;
            piVar3[2] = 0;
            piVar3[3] = 0;
            *(undefined4 *)(iVar2 + 0x28) = 0;
            *piVar1 = 0;
            *piVar3 = 0;
        }
    }
    return bVar6;
}

// ============================================================
// Function: FUN_1802535fe
// Address: 0x1802535fe
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.180253550(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    bool bVar6;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025356b;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    piVar1 = *(int64_t **)(in_RCX + 0x40);
    iVar2 = piVar1[1];
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025358b;
    fcn.180224990(iVar2, 0x1804e5c10, 0x30);
    piVar1[1] = 0;
    piVar1[2] = 0;
    piVar1[3] = 0;
    *(undefined4 *)(in_RCX + 0x28) = 0;
    iVar2 = piVar1[9];
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802535a7;
    func_0x00018026beb0(iVar2);
    iVar2 = *piVar1;
    if (iVar2 == 0) {
        bVar6 = true;
    } else {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        piVar3 = *(int64_t **)(iVar2 + 0x40);
        bVar6 = *piVar3 == in_RCX;
        if (bVar6) {
            iVar4 = piVar3[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802535de;
            fcn.180224990(iVar4, 0x1804e5c10, 0x30);
            piVar3[1] = 0;
            piVar3[2] = 0;
            piVar3[3] = 0;
            *(undefined4 *)(iVar2 + 0x28) = 0;
            *piVar1 = 0;
            *piVar3 = 0;
        }
    }
    return bVar6;
}

// ============================================================
// Function: FUN_180253620
// Address: 0x180253620
// Size: 70 bytes
// ============================================================
uint64_t fcn.180252990(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_60h, int64_t arg_70h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                      int64_t arg_98h, int64_t arg_c8h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t **ppuVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *piVar10;
    int64_t in_RCX;
    uint64_t uVar11;
    int64_t iVar12;
    int32_t in_EDX;
    uint64_t uVar13;
    undefined8 unaff_RBX;
    int64_t *piVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar15;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    uint32_t *in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 uStackX_18;
    int64_t var_20h;
    code *pcStack_8;
    
    pcStack_8 = (code *)0x18025299a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_EDX == 0x55) {
        uVar7 = **(uint64_t **)(in_RCX + 0x40);
        if (uVar7 == 0) {
            return uVar7;
        }
        return (uint64_t)*(uint32_t *)(*(int64_t *)(uVar7 + 0x40) + 0x40);
    }
    if (in_EDX != 0x8a) {
        if (in_EDX == 0x8b) {
            *(undefined8 *)((int64_t)&pcStack_8 + iVar5) = 0x1802529c0;
            fcn.180253550(*(int64_t *)((int64_t)&var_20h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5), 
                          *(int64_t *)((int64_t)&arg_30h + iVar5), *(int64_t *)(&stack0x00000038 + iVar5));
            return 1;
        }
        *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5 + -8) = unaff_R14;
        *(undefined8 *)(&stack0x00000008 + iVar5) = 0x180252a0f;
        iVar6 = fcn.18045a350();
        iVar6 = -iVar6;
        *(uint64_t *)((int64_t)&arg_70h + iVar6 + iVar5) =
             *(uint64_t *)0x1806a3940 ^ (int64_t)&uStackX_18 + iVar6 + iVar5 + -8;
        piVar14 = *(int64_t **)(in_RCX + 0x40);
        if (piVar14 != (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_c8h + iVar6 + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_98h + iVar6 + iVar5) = unaff_RSI;
            iVar4 = (int32_t)in_R8;
    // switch table (140 cases) at 0x180252d98
            switch(in_EDX) {
            case 1:
                piVar14[3] = 0;
                piVar14[5] = 0;
                piVar14[4] = 0;
                break;
            case 2:
                break;
            case 10:
                if (*(int32_t *)(in_RCX + 0x28) != 0) {
                    if (*piVar14 != 0) {
                        piVar14 = *(int64_t **)(*piVar14 + 0x40);
                    }
                    iVar1 = piVar14[10];
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b88;
                    iVar4 = fcn.180222950(iVar1);
                    if (iVar4 != 0) {
                        *(undefined8 *)((int64_t)&arg_90h + iVar6 + iVar5) = unaff_R12;
                        iVar1 = piVar14[5];
                        uVar7 = 0x40;
                        *(undefined8 *)((int64_t)&arg_88h + iVar6 + iVar5) = unaff_R13;
                        iVar2 = piVar14[3];
                        *(undefined8 *)((int64_t)&arg_80h + iVar6 + iVar5) = unaff_R15;
                        iVar15 = (int64_t)&arg_30h + iVar6 + iVar5;
                        do {
                            uVar13 = piVar14[3];
                            iVar9 = piVar14[5];
                            uVar8 = piVar14[2] - iVar9;
                            uVar11 = uVar13;
                            if (uVar8 <= uVar13) {
                                uVar11 = uVar8;
                            }
                            if (uVar11 == 0) break;
                            uVar8 = uVar7;
                            if (uVar11 <= uVar7) {
                                uVar8 = uVar11;
                            }
                            if (iVar15 != 0) {
                                iVar12 = piVar14[1];
                                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252bff;
                                fcn.180498030(iVar15, iVar12 + iVar9, uVar8);
                                uVar13 = piVar14[3];
                            }
                            if ((uVar8 <= (uint64_t)(piVar14[2] - piVar14[5])) && (uVar8 <= uVar13)) {
                                iVar12 = piVar14[5] + uVar8;
                                iVar9 = 0;
                                if (iVar12 != piVar14[2]) {
                                    iVar9 = iVar12;
                                }
                                piVar14[5] = iVar9;
                                piVar14[3] = piVar14[3] - uVar8;
                            }
                            iVar9 = uVar8 + iVar15;
                            if (iVar15 == 0) {
                                iVar9 = iVar15;
                            }
                            uVar7 = uVar7 - uVar8;
                            iVar15 = iVar9;
                        } while (uVar7 != 0);
                        iVar15 = piVar14[10];
                        piVar14[5] = iVar1;
                        piVar14[3] = iVar2;
                        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252c5b;
                        fcn.180222910(iVar15);
                    }
                }
                break;
            case 0x29:
                break;
            case 0x2a:
                piVar14[7] = in_R8 & 0xffffffff;
                if (*piVar14 != 0) {
                    *(uint64_t *)(*(int64_t *)(*piVar14 + 0x40) + 0x38) = in_R8 & 0xffffffff;
                }
                break;
            case 0x52:
                break;
            case 0x53:
                *in_R9 = *(uint32_t *)(piVar14 + 0xb) >> 1 & 1;
                break;
            case 0x54:
                if (*(int32_t *)(in_RCX + 0x28) != 0) {
                    piVar10 = piVar14;
                    if (*piVar14 != 0) {
                        piVar10 = *(int64_t **)(*piVar14 + 0x40);
                    }
                    if ((~*(uint32_t *)(piVar10 + 8) & 9) == 0) {
                        *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffffd;
                        *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | -(uint32_t)(iVar4 != 0) & 2;
                    }
                }
                break;
            case 0x55:
            case 0x56:
                break;
            case 0x57:
                *(int32_t *)(piVar14 + 8) = iVar4;
                break;
            case 0x58:
                break;
            case 0x59:
                *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffffe;
                *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | (uint32_t)(0 < iVar4);
                break;
            case 0x5e:
                iVar1 = piVar14[9];
                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252d63;
                func_0x00018026beb0(iVar1);
                piVar14[9] = (int64_t)in_R9;
                break;
            case 0x88:
                uVar7 = (uint64_t)iVar4;
                if (*piVar14 == 0) {
                    if (uVar7 < 0x400) {
                        uVar7 = 0x400;
                    }
                    if (piVar14[1] != 0) {
                        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252afb;
                        iVar4 = func_0x000180254140(piVar14 + 1, uVar7);
                        if (iVar4 == 0) break;
                    }
                    *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) & 0xfffffff7;
                    piVar14[6] = uVar7;
                } else {
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252a82;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5));
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252a9a;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(code **)(&stack0x00000008 + iVar6 + iVar5) = case.0x180252a72.3;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5));
                }
                break;
            case 0x89:
                break;
            case 0x8c:
                iVar1 = piVar14[10];
                *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b28;
                iVar4 = func_0x000180222850(iVar1);
                if (iVar4 != 0) {
                    iVar1 = piVar14[10];
                    *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252b57;
                    fcn.180222910(iVar1);
                }
            }
        }
        *(undefined8 *)(&stack0x00000008 + iVar6 + iVar5) = 0x180252ad1;
        uVar7 = func_0x000180459870(*(uint64_t *)((int64_t)&arg_70h + iVar6 + iVar5) ^
                                    (int64_t)&uStackX_18 + iVar6 + iVar5 + -8);
        return uVar7;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar5) = 0x180253630;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if ((in_RCX == 0) || (in_R9 == (uint32_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253834;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025384c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
code_r0x000180253813:
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253822;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
        return 0;
    }
    if ((*(int64_t *)(in_RCX + 8) != 0x1804e5af0) || (*(int64_t *)(in_R9 + 2) != 0x1804e5af0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537f4;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025380c;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
        goto code_r0x000180253813;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar5) = unaff_RBX;
    piVar14 = *(int64_t **)(in_R9 + 0x10);
    *(undefined8 *)((int64_t)&arg_58h + iVar6 + iVar5) = unaff_RDI;
    ppuVar3 = *(uint32_t ***)(in_RCX + 0x40);
    if ((ppuVar3 == (uint32_t **)0x0) || (piVar14 == (int64_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537e1;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
    } else {
        if ((*ppuVar3 != (uint32_t *)0x0) || (*piVar14 != 0)) {
            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537b6;
            fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
            *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802537ce;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                          *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
            goto code_r0x000180253790;
        }
        if (((uint32_t *)0x3ff < ppuVar3[6]) && (0x3ff < (uint64_t)piVar14[6])) {
            if (ppuVar3[2] != ppuVar3[6]) {
                *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536cc;
                iVar4 = fcn.1802540d0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536d5;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x1802536ed;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                    goto code_r0x000180253790;
                }
            }
            if (piVar14[2] != piVar14[6]) {
                *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025370a;
                iVar4 = fcn.1802540d0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                      *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253713;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025372b;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025373d;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253746;
                    func_0x000180254090(ppuVar3 + 1);
                    return 0;
                }
            }
            *ppuVar3 = in_R9;
            *piVar14 = in_RCX;
            *(uint32_t *)(ppuVar3 + 0xb) = *(uint32_t *)(ppuVar3 + 0xb) & 0xfffffffb;
            *(uint32_t *)(piVar14 + 0xb) = *(uint32_t *)(piVar14 + 0xb) | 4;
            *(undefined4 *)(in_RCX + 0x28) = 1;
            in_R9[10] = 1;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253770;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5));
    }
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x180253788;
    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_48h + iVar6 + iVar5), 
                  *(int64_t *)((int64_t)&arg_50h + iVar6 + iVar5), *(int64_t *)((int64_t)&arg_58h + iVar6 + iVar5), 
                  *(int64_t *)((int64_t)&arg_70h + iVar6 + iVar5));
code_r0x000180253790:
    *(undefined8 *)((int64_t)&uStackX_18 + iVar6 + iVar5) = 0x18025379a;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar6 + iVar5));
    return 0;
}

