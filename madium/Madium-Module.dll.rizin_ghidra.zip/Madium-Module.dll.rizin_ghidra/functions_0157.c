// Chunk 157 - 50 functions

// ============================================================
// Function: FUN_18020d6b0
// Address: 0x18020d6b0
// Size: 269 bytes
// ============================================================
void fcn.18020d6b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_70h, int64_t arg_b0h, int64_t arg_c0h, int64_t arg_f0h, int64_t arg_f8h)
{
    char cVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t unaff_RBX;
    int64_t var_20h;
    
    uVar2 = func_0x0001801f9c00();
    iVar3 = func_0x0001801b4180(*(undefined8 *)(unaff_RBX + 0x40), *(undefined8 *)(unaff_RBX + 0x48), 
                                *(undefined8 *)(unaff_RBX + 0x28), unaff_RBX + 0x8a, 0x1804ba528);
    if (iVar3 != 0) {
        cVar1 = *(char *)(unaff_RBX + 0x68);
        if (((cVar1 == '\x01') || (cVar1 == '\x02')) ||
           ((cVar1 == '\x03' && ((~*(uint32_t *)(unaff_RBX + 0x50) & 1) != 0)))) {
            if (*(int64_t *)(unaff_RBX + 0x30) != 0) {
                func_0x000180211410();
                *(undefined8 *)(unaff_RBX + 0x30) = 0;
            }
            func_0x000180244fc0(unaff_RBX + 0x6a, 0x10);
        }
        iVar3 = func_0x00018020ce40();
        if (iVar3 != 0) {
            *(int64_t *)(unaff_RBX + 0x50) = *(int64_t *)(unaff_RBX + 0x50) + 1;
            *(undefined8 *)(unaff_RBX + 0x58) = 0;
            func_0x000180498030(unaff_RBX + 0x8a, &arg_70h, uVar2);
        }
    }
    func_0x000180459870(arg_b0h ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_18020d7bd
// Address: 0x18020d7bd
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_f0h
// WARNING: Variable defined which should be unmapped: arg_f8h
// WARNING: Variable defined which should be unmapped: arg_c0h

void fcn.18020d6b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_70h, int64_t arg_b0h, int64_t arg_c0h, int64_t arg_f0h, int64_t arg_f8h)
{
    char cVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t unaff_RBX;
    int64_t var_20h;
    
    uVar2 = func_0x0001801f9c00();
    iVar3 = func_0x0001801b4180(*(undefined8 *)(unaff_RBX + 0x40), *(undefined8 *)(unaff_RBX + 0x48), 
                                *(undefined8 *)(unaff_RBX + 0x28), unaff_RBX + 0x8a, 0x1804ba528);
    if (iVar3 != 0) {
        cVar1 = *(char *)(unaff_RBX + 0x68);
        if (((cVar1 == '\x01') || (cVar1 == '\x02')) ||
           ((cVar1 == '\x03' && ((~*(uint32_t *)(unaff_RBX + 0x50) & 1) != 0)))) {
            if (*(int64_t *)(unaff_RBX + 0x30) != 0) {
                func_0x000180211410();
                *(undefined8 *)(unaff_RBX + 0x30) = 0;
            }
            func_0x000180244fc0(unaff_RBX + 0x6a, 0x10);
        }
        iVar3 = func_0x00018020ce40();
        if (iVar3 != 0) {
            *(int64_t *)(unaff_RBX + 0x50) = *(int64_t *)(unaff_RBX + 0x50) + 1;
            *(undefined8 *)(unaff_RBX + 0x58) = 0;
            func_0x000180498030(unaff_RBX + 0x8a, &arg_70h, uVar2);
        }
    }
    func_0x000180459870(arg_b0h ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_18020d7d7
// Address: 0x18020d7d7
// Size: 4 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_f0h
// WARNING: Variable defined which should be unmapped: arg_f8h
// WARNING: Variable defined which should be unmapped: arg_c0h

void fcn.18020d6b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_70h, int64_t arg_b0h, int64_t arg_c0h, int64_t arg_f0h, int64_t arg_f8h)
{
    char cVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t unaff_RBX;
    int64_t var_20h;
    
    uVar2 = func_0x0001801f9c00();
    iVar3 = func_0x0001801b4180(*(undefined8 *)(unaff_RBX + 0x40), *(undefined8 *)(unaff_RBX + 0x48), 
                                *(undefined8 *)(unaff_RBX + 0x28), unaff_RBX + 0x8a, 0x1804ba528);
    if (iVar3 != 0) {
        cVar1 = *(char *)(unaff_RBX + 0x68);
        if (((cVar1 == '\x01') || (cVar1 == '\x02')) ||
           ((cVar1 == '\x03' && ((~*(uint32_t *)(unaff_RBX + 0x50) & 1) != 0)))) {
            if (*(int64_t *)(unaff_RBX + 0x30) != 0) {
                func_0x000180211410();
                *(undefined8 *)(unaff_RBX + 0x30) = 0;
            }
            func_0x000180244fc0(unaff_RBX + 0x6a, 0x10);
        }
        iVar3 = func_0x00018020ce40();
        if (iVar3 != 0) {
            *(int64_t *)(unaff_RBX + 0x50) = *(int64_t *)(unaff_RBX + 0x50) + 1;
            *(undefined8 *)(unaff_RBX + 0x58) = 0;
            func_0x000180498030(unaff_RBX + 0x8a, &arg_70h, uVar2);
        }
    }
    func_0x000180459870(arg_b0h ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_18020d7db
// Address: 0x18020d7db
// Size: 51 bytes
// ============================================================
void fcn.18020d7db(void)
{
    uint64_t in_stack_000000b0;
    
    func_0x000180229480();
    func_0x0001802295a0(0x1804ba548, 0x161, 0x1804ba590);
    func_0x0001802296d0(0x14, 0x80106, 0);
    func_0x000180459870(in_stack_000000b0 ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_18020d810
// Address: 0x18020d810
// Size: 125 bytes
// ============================================================
undefined8 fcn.18020d810(int64_t param_1, uint64_t param_2)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020d81c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((((uint32_t)param_2 < 4) && (param_1 = (param_2 & 0xffffffff) * 0xd0 + param_1, param_1 != 0)) &&
       ((uint32_t)param_2 == 3)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020d847;
        fcn.18020d1f0(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        *(undefined *)(param_1 + 0x68) = 3;
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020d85b;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020d873;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020d885;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
    return 0;
}

// ============================================================
// Function: FUN_18020d890
// Address: 0x18020d890
// Size: 249 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h

void fcn.18020d890(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_68h, int64_t arg_a8h, int64_t arg_e8h, int64_t arg_100h, int64_t arg_168h,
                  int64_t arg_170h, int64_t arg_178h, int64_t arg_180h, int64_t arg_188h, int64_t arg_190h)
{
    char cVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint8_t uVar11;
    undefined8 unaff_RBX;
    int64_t iVar12;
    undefined8 in_R8;
    uint32_t uVar13;
    uint64_t in_R9;
    uint8_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_40;
    
    uStack_40 = 0x18020d8a6;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_e8h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar8);
    uVar6 = *(undefined4 *)((int64_t)&arg_168h + iVar8);
    iVar10 = *(int64_t *)((int64_t)&arg_170h + iVar8);
    *(undefined8 *)((int64_t)&arg_50h + iVar8) = *(undefined8 *)((int64_t)&arg_178h + iVar8);
    uVar13 = (uint32_t)in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar8) = in_R8;
    *(undefined8 *)((int64_t)&arg_30h + iVar8) = in_RDX;
    *(undefined4 *)((int64_t)&arg_38h + iVar8) = uVar6;
    if (uVar13 < 4) {
        *(undefined4 *)((int64_t)&arg_38h + iVar8 + 4) = 0;
        *(undefined4 *)((int64_t)&arg_40h + iVar8) = 0;
        *(undefined4 *)((int64_t)&arg_40h + iVar8 + 4) = 0;
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d94e;
        iVar9 = func_0x0001801f9bc0(uVar6);
        *(int64_t *)((int64_t)&arg_58h + iVar8) = iVar9;
        iVar12 = (in_R9 & 0xffffffff) * 0xd0 + in_RCX;
        if ((((iVar12 != 0) && (iVar9 != 0)) && (uVar14 = *(uint8_t *)((int64_t)&arg_188h + iVar8), uVar14 < 2)) &&
           ((uVar5 = *(uint32_t *)((int64_t)&arg_190h + iVar8), uVar5 < 2 && ((uVar14 == 0 || (uVar13 == 3)))))) {
            *(undefined8 *)((int64_t)&arg_100h + iVar8) = unaff_RBX;
            if ((uVar13 == 0) && (*(char *)(iVar12 + 0x68) == '\x01')) {
                iVar9 = (in_R9 & 0xffffffff) * 0xd0 + in_RCX;
                cVar1 = *(char *)(iVar9 + 0x68);
                if ((cVar1 != '\0') && (((cVar1 == '\x01' || (cVar1 == '\x02')) || (cVar1 == '\x03')))) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d9d4;
                    func_0x0001801f8940(iVar9);
                    cVar1 = *(char *)(iVar9 + 0x68);
                    if (((cVar1 == '\x01') || (cVar1 == '\x02')) ||
                       ((cVar1 == '\x03' && ((~*(uint32_t *)(iVar9 + 0x50) & 1) != 0)))) {
                        if (*(int64_t *)(iVar9 + 0x30) != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d9fe;
                            func_0x000180211410();
                            *(undefined8 *)(iVar9 + 0x30) = 0;
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da10;
                        func_0x000180244fc0(iVar9 + 0x6a, 0x10);
                    }
                    cVar1 = *(char *)(iVar9 + 0x68);
                    if ((((cVar1 != '\x01') && (cVar1 != '\x02')) && (cVar1 == '\x03')) &&
                       ((*(uint32_t *)(iVar9 + 0x50) & 1) != 0)) {
                        if (*(int64_t *)(iVar9 + 0x38) != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da39;
                            func_0x000180211410();
                            *(undefined8 *)(iVar9 + 0x38) = 0;
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da4b;
                        func_0x000180244fc0(iVar9 + 0x7a, 0x10);
                    }
                    uVar14 = *(uint8_t *)((int64_t)&arg_188h + iVar8);
                }
                uVar2 = *(undefined8 *)(iVar9 + 0x28);
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da5d;
                func_0x000180215590(uVar2);
                uVar5 = *(uint32_t *)((int64_t)&arg_190h + iVar8);
                *(undefined8 *)(iVar9 + 0x28) = 0;
                *(undefined *)(iVar9 + 0x68) = 4;
                *(undefined *)(iVar12 + 0x68) = 0;
            }
            if (*(char *)(iVar12 + 0x68) == '\0') {
                uVar11 = 0;
                if (uVar5 == 0) {
                    uVar11 = uVar14;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dae5;
                uVar5 = func_0x0001801f9b10(uVar6);
                if (uVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020daf1;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
                    goto code_r0x00018020da87;
                }
                if (iVar10 != 0) {
code_r0x00018020db52:
                    *(undefined8 *)(iVar12 + 0x40) = *(undefined8 *)((int64_t)&arg_30h + iVar8);
                    *(undefined8 *)(iVar12 + 0x48) = *(undefined8 *)((int64_t)&arg_28h + iVar8);
                    uVar6 = *(undefined4 *)((int64_t)&arg_38h + iVar8);
                    *(int64_t *)(iVar12 + 0x28) = iVar10;
                    *(undefined4 *)(iVar12 + 0x60) = uVar6;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020db76;
                    uVar6 = func_0x0001801f9ab0(uVar6);
                    uVar2 = *(undefined8 *)((int64_t)&arg_50h + iVar8);
                    uVar3 = *(undefined8 *)((int64_t)&arg_28h + iVar8);
                    uVar4 = *(undefined8 *)((int64_t)&arg_30h + iVar8);
                    *(undefined4 *)((int64_t)&var_18h + iVar8) = 1;
                    *(undefined4 *)(iVar12 + 100) = uVar6;
                    *(uint64_t *)((int64_t)&var_10h + iVar8) = (uint64_t)uVar5;
                    *(uint64_t *)(iVar12 + 0x50) = (uint64_t)uVar14;
                    *(char *)(iVar12 + 0x69) = (char)*(undefined4 *)((int64_t)&arg_190h + iVar8);
                    *(int64_t *)((int64_t)&var_8h + iVar8) = (int64_t)&arg_a8h + iVar8;
                    *(undefined8 *)(&stack0x00000000 + iVar8) = 0;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8) = 0;
                    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = 7;
                    *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = 0x1804ba520;
                    *(undefined8 *)(iVar12 + 0x58) = 0;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dbe2;
                    iVar7 = func_0x0001801b4180(uVar4, uVar3, iVar10, uVar2);
                    if (iVar7 != 0) {
                        uVar2 = *(undefined8 *)((int64_t)&arg_180h + iVar8);
                        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = uVar2;
                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = *(undefined8 *)((int64_t)&arg_50h + iVar8);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dc14;
                        iVar7 = func_0x00018020ce40(in_RCX, in_R9 & 0xffffffff, 1, uVar11);
                        if (iVar7 != 0) {
                            *(undefined4 *)((int64_t)&arg_38h + iVar8 + 4) = 1;
                            if (uVar13 == 3) {
                                iVar9 = (int64_t)&arg_68h + iVar8;
                                if (*(int32_t *)((int64_t)&arg_190h + iVar8) != 0) {
                                    iVar9 = iVar12 + 0x8a;
                                }
                                *(undefined4 *)((int64_t)&var_18h + iVar8) = 1;
                                *(undefined8 *)((int64_t)&var_10h + iVar8) = uVar2;
                                *(int64_t *)((int64_t)&var_8h + iVar8) = iVar9;
                                *(undefined8 *)(&stack0x00000000 + iVar8) = 0;
                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8) = 0;
                                *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = 7;
                                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = 0x1804ba528;
                                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dc92;
                                iVar7 = func_0x0001801b4180(*(undefined8 *)((int64_t)&arg_30h + iVar8), 
                                                            *(undefined8 *)((int64_t)&arg_28h + iVar8), iVar10, 
                                                            *(undefined8 *)((int64_t)&arg_50h + iVar8));
                                if (iVar7 != 0) {
                                    if (*(int32_t *)((int64_t)&arg_190h + iVar8) != 0) goto code_r0x00018020dd36;
                                    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = uVar2;
                                    *(int64_t *)(&stack0xffffffffffffffe8 + iVar8) = (int64_t)&arg_68h + iVar8;
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dcd0;
                                    iVar7 = func_0x00018020ce40(in_RCX, in_R9 & 0xffffffff, 1, uVar11 == 0);
                                    if (iVar7 != 0) {
                                        *(undefined4 *)((int64_t)&var_18h + iVar8) = 1;
                                        *(undefined8 *)((int64_t)&var_10h + iVar8) = uVar2;
                                        *(int64_t *)((int64_t)&var_8h + iVar8) = iVar12 + 0x8a;
                                        *(undefined8 *)(&stack0x00000000 + iVar8) = 0;
                                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8) = 0;
                                        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = 7;
                                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = 0x1804ba528;
                                        *(undefined4 *)((int64_t)&arg_40h + iVar8) = 1;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd32;
                                        iVar7 = func_0x0001801b4180(*(undefined8 *)((int64_t)&arg_30h + iVar8), 
                                                                    *(undefined8 *)((int64_t)&arg_28h + iVar8), iVar10, 
                                                                    (int64_t)&arg_68h + iVar8);
                                        if (iVar7 != 0) goto code_r0x00018020dd36;
                                    }
                                }
                            } else {
code_r0x00018020dd36:
                                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd3f;
                                uVar6 = func_0x0001801f9ae0(*(undefined4 *)((int64_t)&arg_38h + iVar8));
                                *(uint64_t *)(&stack0xfffffffffffffff0 + iVar8) = (uint64_t)uVar5;
                                *(int64_t *)(&stack0xffffffffffffffe8 + iVar8) = (int64_t)&arg_a8h + iVar8;
                                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd66;
                                iVar7 = func_0x0001801f8ad0(iVar12, *(undefined8 *)((int64_t)&arg_30h + iVar8), 
                                                            *(undefined8 *)((int64_t)&arg_28h + iVar8), uVar6);
                                if (iVar7 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd7c;
                                    func_0x000180244fc0((int64_t)&arg_a8h + iVar8, 0x40);
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd8e;
                                    func_0x000180244fc0((int64_t)&arg_68h + iVar8, 0x40);
                                    *(undefined *)(iVar12 + 0x68) = 1;
                                    goto code_r0x00018020daaf;
                                }
                            }
                        }
                    }
                    *(undefined4 *)(iVar12 + 0x60) = 0;
                    *(undefined8 *)(iVar12 + 0x28) = 0;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020ddb5;
                    func_0x000180244fc0((int64_t)&arg_a8h + iVar8, 0x40);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020ddc7;
                    func_0x000180244fc0((int64_t)&arg_68h + iVar8, 0x40);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020ddd8;
                    func_0x000180244fc0(iVar12 + 0x8a, 0x40);
                    if (*(int32_t *)((int64_t)&arg_38h + iVar8 + 4) != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020ddeb;
                        fcn.18020d1f0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8));
                    }
                    if (*(int32_t *)((int64_t)&arg_40h + iVar8) != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020de05;
                        fcn.18020d1f0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8));
                    }
                    if (*(int32_t *)((int64_t)&arg_40h + iVar8 + 4) != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020de18;
                        func_0x000180215590(iVar10);
                    }
                    goto code_r0x00018020daaf;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020db1b;
                iVar10 = func_0x000180215540(*(undefined8 *)((int64_t)&arg_30h + iVar8), 
                                             *(undefined8 *)((int64_t)&arg_58h + iVar8), 
                                             *(undefined8 *)((int64_t)&arg_28h + iVar8));
                if (iVar10 != 0) {
                    *(undefined4 *)((int64_t)&arg_40h + iVar8 + 4) = 1;
                    goto code_r0x00018020db52;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020db28;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020db40;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                              *(int64_t *)((int64_t)&var_18h + iVar8));
            } else {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da7b;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
code_r0x00018020da87:
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da93;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                              *(int64_t *)((int64_t)&var_18h + iVar8));
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020daa5;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar8));
            goto code_r0x00018020daaf;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d8fe;
        func_0x0001801f9bc0(uVar6);
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d903;
    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d91b;
    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                  *(int64_t *)((int64_t)&var_18h + iVar8));
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d92d;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar8));
code_r0x00018020daaf:
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dabf;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_e8h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_18020d989
// Address: 0x18020d989
// Size: 294 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h

void fcn.18020d890(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_68h, int64_t arg_a8h, int64_t arg_e8h, int64_t arg_100h, int64_t arg_168h,
                  int64_t arg_170h, int64_t arg_178h, int64_t arg_180h, int64_t arg_188h, int64_t arg_190h)
{
    char cVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint8_t uVar11;
    undefined8 unaff_RBX;
    int64_t iVar12;
    undefined8 in_R8;
    uint32_t uVar13;
    uint64_t in_R9;
    uint8_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_40;
    
    uStack_40 = 0x18020d8a6;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_e8h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar8);
    uVar6 = *(undefined4 *)((int64_t)&arg_168h + iVar8);
    iVar10 = *(int64_t *)((int64_t)&arg_170h + iVar8);
    *(undefined8 *)((int64_t)&arg_50h + iVar8) = *(undefined8 *)((int64_t)&arg_178h + iVar8);
    uVar13 = (uint32_t)in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar8) = in_R8;
    *(undefined8 *)((int64_t)&arg_30h + iVar8) = in_RDX;
    *(undefined4 *)((int64_t)&arg_38h + iVar8) = uVar6;
    if (uVar13 < 4) {
        *(undefined4 *)((int64_t)&arg_38h + iVar8 + 4) = 0;
        *(undefined4 *)((int64_t)&arg_40h + iVar8) = 0;
        *(undefined4 *)((int64_t)&arg_40h + iVar8 + 4) = 0;
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d94e;
        iVar9 = func_0x0001801f9bc0(uVar6);
        *(int64_t *)((int64_t)&arg_58h + iVar8) = iVar9;
        iVar12 = (in_R9 & 0xffffffff) * 0xd0 + in_RCX;
        if ((((iVar12 != 0) && (iVar9 != 0)) && (uVar14 = *(uint8_t *)((int64_t)&arg_188h + iVar8), uVar14 < 2)) &&
           ((uVar5 = *(uint32_t *)((int64_t)&arg_190h + iVar8), uVar5 < 2 && ((uVar14 == 0 || (uVar13 == 3)))))) {
            *(undefined8 *)((int64_t)&arg_100h + iVar8) = unaff_RBX;
            if ((uVar13 == 0) && (*(char *)(iVar12 + 0x68) == '\x01')) {
                iVar9 = (in_R9 & 0xffffffff) * 0xd0 + in_RCX;
                cVar1 = *(char *)(iVar9 + 0x68);
                if ((cVar1 != '\0') && (((cVar1 == '\x01' || (cVar1 == '\x02')) || (cVar1 == '\x03')))) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d9d4;
                    func_0x0001801f8940(iVar9);
                    cVar1 = *(char *)(iVar9 + 0x68);
                    if (((cVar1 == '\x01') || (cVar1 == '\x02')) ||
                       ((cVar1 == '\x03' && ((~*(uint32_t *)(iVar9 + 0x50) & 1) != 0)))) {
                        if (*(int64_t *)(iVar9 + 0x30) != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d9fe;
                            func_0x000180211410();
                            *(undefined8 *)(iVar9 + 0x30) = 0;
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da10;
                        func_0x000180244fc0(iVar9 + 0x6a, 0x10);
                    }
                    cVar1 = *(char *)(iVar9 + 0x68);
                    if ((((cVar1 != '\x01') && (cVar1 != '\x02')) && (cVar1 == '\x03')) &&
                       ((*(uint32_t *)(iVar9 + 0x50) & 1) != 0)) {
                        if (*(int64_t *)(iVar9 + 0x38) != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da39;
                            func_0x000180211410();
                            *(undefined8 *)(iVar9 + 0x38) = 0;
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da4b;
                        func_0x000180244fc0(iVar9 + 0x7a, 0x10);
                    }
                    uVar14 = *(uint8_t *)((int64_t)&arg_188h + iVar8);
                }
                uVar2 = *(undefined8 *)(iVar9 + 0x28);
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da5d;
                func_0x000180215590(uVar2);
                uVar5 = *(uint32_t *)((int64_t)&arg_190h + iVar8);
                *(undefined8 *)(iVar9 + 0x28) = 0;
                *(undefined *)(iVar9 + 0x68) = 4;
                *(undefined *)(iVar12 + 0x68) = 0;
            }
            if (*(char *)(iVar12 + 0x68) == '\0') {
                uVar11 = 0;
                if (uVar5 == 0) {
                    uVar11 = uVar14;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dae5;
                uVar5 = func_0x0001801f9b10(uVar6);
                if (uVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020daf1;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
                    goto code_r0x00018020da87;
                }
                if (iVar10 != 0) {
code_r0x00018020db52:
                    *(undefined8 *)(iVar12 + 0x40) = *(undefined8 *)((int64_t)&arg_30h + iVar8);
                    *(undefined8 *)(iVar12 + 0x48) = *(undefined8 *)((int64_t)&arg_28h + iVar8);
                    uVar6 = *(undefined4 *)((int64_t)&arg_38h + iVar8);
                    *(int64_t *)(iVar12 + 0x28) = iVar10;
                    *(undefined4 *)(iVar12 + 0x60) = uVar6;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020db76;
                    uVar6 = func_0x0001801f9ab0(uVar6);
                    uVar2 = *(undefined8 *)((int64_t)&arg_50h + iVar8);
                    uVar3 = *(undefined8 *)((int64_t)&arg_28h + iVar8);
                    uVar4 = *(undefined8 *)((int64_t)&arg_30h + iVar8);
                    *(undefined4 *)((int64_t)&var_18h + iVar8) = 1;
                    *(undefined4 *)(iVar12 + 100) = uVar6;
                    *(uint64_t *)((int64_t)&var_10h + iVar8) = (uint64_t)uVar5;
                    *(uint64_t *)(iVar12 + 0x50) = (uint64_t)uVar14;
                    *(char *)(iVar12 + 0x69) = (char)*(undefined4 *)((int64_t)&arg_190h + iVar8);
                    *(int64_t *)((int64_t)&var_8h + iVar8) = (int64_t)&arg_a8h + iVar8;
                    *(undefined8 *)(&stack0x00000000 + iVar8) = 0;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8) = 0;
                    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = 7;
                    *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = 0x1804ba520;
                    *(undefined8 *)(iVar12 + 0x58) = 0;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dbe2;
                    iVar7 = func_0x0001801b4180(uVar4, uVar3, iVar10, uVar2);
                    if (iVar7 != 0) {
                        uVar2 = *(undefined8 *)((int64_t)&arg_180h + iVar8);
                        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = uVar2;
                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = *(undefined8 *)((int64_t)&arg_50h + iVar8);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dc14;
                        iVar7 = func_0x00018020ce40(in_RCX, in_R9 & 0xffffffff, 1, uVar11);
                        if (iVar7 != 0) {
                            *(undefined4 *)((int64_t)&arg_38h + iVar8 + 4) = 1;
                            if (uVar13 == 3) {
                                iVar9 = (int64_t)&arg_68h + iVar8;
                                if (*(int32_t *)((int64_t)&arg_190h + iVar8) != 0) {
                                    iVar9 = iVar12 + 0x8a;
                                }
                                *(undefined4 *)((int64_t)&var_18h + iVar8) = 1;
                                *(undefined8 *)((int64_t)&var_10h + iVar8) = uVar2;
                                *(int64_t *)((int64_t)&var_8h + iVar8) = iVar9;
                                *(undefined8 *)(&stack0x00000000 + iVar8) = 0;
                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8) = 0;
                                *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = 7;
                                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = 0x1804ba528;
                                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dc92;
                                iVar7 = func_0x0001801b4180(*(undefined8 *)((int64_t)&arg_30h + iVar8), 
                                                            *(undefined8 *)((int64_t)&arg_28h + iVar8), iVar10, 
                                                            *(undefined8 *)((int64_t)&arg_50h + iVar8));
                                if (iVar7 != 0) {
                                    if (*(int32_t *)((int64_t)&arg_190h + iVar8) != 0) goto code_r0x00018020dd36;
                                    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = uVar2;
                                    *(int64_t *)(&stack0xffffffffffffffe8 + iVar8) = (int64_t)&arg_68h + iVar8;
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dcd0;
                                    iVar7 = func_0x00018020ce40(in_RCX, in_R9 & 0xffffffff, 1, uVar11 == 0);
                                    if (iVar7 != 0) {
                                        *(undefined4 *)((int64_t)&var_18h + iVar8) = 1;
                                        *(undefined8 *)((int64_t)&var_10h + iVar8) = uVar2;
                                        *(int64_t *)((int64_t)&var_8h + iVar8) = iVar12 + 0x8a;
                                        *(undefined8 *)(&stack0x00000000 + iVar8) = 0;
                                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8) = 0;
                                        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = 7;
                                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = 0x1804ba528;
                                        *(undefined4 *)((int64_t)&arg_40h + iVar8) = 1;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd32;
                                        iVar7 = func_0x0001801b4180(*(undefined8 *)((int64_t)&arg_30h + iVar8), 
                                                                    *(undefined8 *)((int64_t)&arg_28h + iVar8), iVar10, 
                                                                    (int64_t)&arg_68h + iVar8);
                                        if (iVar7 != 0) goto code_r0x00018020dd36;
                                    }
                                }
                            } else {
code_r0x00018020dd36:
                                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd3f;
                                uVar6 = func_0x0001801f9ae0(*(undefined4 *)((int64_t)&arg_38h + iVar8));
                                *(uint64_t *)(&stack0xfffffffffffffff0 + iVar8) = (uint64_t)uVar5;
                                *(int64_t *)(&stack0xffffffffffffffe8 + iVar8) = (int64_t)&arg_a8h + iVar8;
                                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd66;
                                iVar7 = func_0x0001801f8ad0(iVar12, *(undefined8 *)((int64_t)&arg_30h + iVar8), 
                                                            *(undefined8 *)((int64_t)&arg_28h + iVar8), uVar6);
                                if (iVar7 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd7c;
                                    func_0x000180244fc0((int64_t)&arg_a8h + iVar8, 0x40);
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd8e;
                                    func_0x000180244fc0((int64_t)&arg_68h + iVar8, 0x40);
                                    *(undefined *)(iVar12 + 0x68) = 1;
                                    goto code_r0x00018020daaf;
                                }
                            }
                        }
                    }
                    *(undefined4 *)(iVar12 + 0x60) = 0;
                    *(undefined8 *)(iVar12 + 0x28) = 0;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020ddb5;
                    func_0x000180244fc0((int64_t)&arg_a8h + iVar8, 0x40);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020ddc7;
                    func_0x000180244fc0((int64_t)&arg_68h + iVar8, 0x40);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020ddd8;
                    func_0x000180244fc0(iVar12 + 0x8a, 0x40);
                    if (*(int32_t *)((int64_t)&arg_38h + iVar8 + 4) != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020ddeb;
                        fcn.18020d1f0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8));
                    }
                    if (*(int32_t *)((int64_t)&arg_40h + iVar8) != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020de05;
                        fcn.18020d1f0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8));
                    }
                    if (*(int32_t *)((int64_t)&arg_40h + iVar8 + 4) != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020de18;
                        func_0x000180215590(iVar10);
                    }
                    goto code_r0x00018020daaf;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020db1b;
                iVar10 = func_0x000180215540(*(undefined8 *)((int64_t)&arg_30h + iVar8), 
                                             *(undefined8 *)((int64_t)&arg_58h + iVar8), 
                                             *(undefined8 *)((int64_t)&arg_28h + iVar8));
                if (iVar10 != 0) {
                    *(undefined4 *)((int64_t)&arg_40h + iVar8 + 4) = 1;
                    goto code_r0x00018020db52;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020db28;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020db40;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                              *(int64_t *)((int64_t)&var_18h + iVar8));
            } else {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da7b;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
code_r0x00018020da87:
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da93;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                              *(int64_t *)((int64_t)&var_18h + iVar8));
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020daa5;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar8));
            goto code_r0x00018020daaf;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d8fe;
        func_0x0001801f9bc0(uVar6);
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d903;
    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d91b;
    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                  *(int64_t *)((int64_t)&var_18h + iVar8));
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d92d;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar8));
code_r0x00018020daaf:
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dabf;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_e8h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_18020daaf
// Address: 0x18020daaf
// Size: 35 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h

void fcn.18020d890(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_68h, int64_t arg_a8h, int64_t arg_e8h, int64_t arg_100h, int64_t arg_168h,
                  int64_t arg_170h, int64_t arg_178h, int64_t arg_180h, int64_t arg_188h, int64_t arg_190h)
{
    char cVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint8_t uVar11;
    undefined8 unaff_RBX;
    int64_t iVar12;
    undefined8 in_R8;
    uint32_t uVar13;
    uint64_t in_R9;
    uint8_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_40;
    
    uStack_40 = 0x18020d8a6;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_e8h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar8);
    uVar6 = *(undefined4 *)((int64_t)&arg_168h + iVar8);
    iVar10 = *(int64_t *)((int64_t)&arg_170h + iVar8);
    *(undefined8 *)((int64_t)&arg_50h + iVar8) = *(undefined8 *)((int64_t)&arg_178h + iVar8);
    uVar13 = (uint32_t)in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar8) = in_R8;
    *(undefined8 *)((int64_t)&arg_30h + iVar8) = in_RDX;
    *(undefined4 *)((int64_t)&arg_38h + iVar8) = uVar6;
    if (uVar13 < 4) {
        *(undefined4 *)((int64_t)&arg_38h + iVar8 + 4) = 0;
        *(undefined4 *)((int64_t)&arg_40h + iVar8) = 0;
        *(undefined4 *)((int64_t)&arg_40h + iVar8 + 4) = 0;
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d94e;
        iVar9 = func_0x0001801f9bc0(uVar6);
        *(int64_t *)((int64_t)&arg_58h + iVar8) = iVar9;
        iVar12 = (in_R9 & 0xffffffff) * 0xd0 + in_RCX;
        if ((((iVar12 != 0) && (iVar9 != 0)) && (uVar14 = *(uint8_t *)((int64_t)&arg_188h + iVar8), uVar14 < 2)) &&
           ((uVar5 = *(uint32_t *)((int64_t)&arg_190h + iVar8), uVar5 < 2 && ((uVar14 == 0 || (uVar13 == 3)))))) {
            *(undefined8 *)((int64_t)&arg_100h + iVar8) = unaff_RBX;
            if ((uVar13 == 0) && (*(char *)(iVar12 + 0x68) == '\x01')) {
                iVar9 = (in_R9 & 0xffffffff) * 0xd0 + in_RCX;
                cVar1 = *(char *)(iVar9 + 0x68);
                if ((cVar1 != '\0') && (((cVar1 == '\x01' || (cVar1 == '\x02')) || (cVar1 == '\x03')))) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d9d4;
                    func_0x0001801f8940(iVar9);
                    cVar1 = *(char *)(iVar9 + 0x68);
                    if (((cVar1 == '\x01') || (cVar1 == '\x02')) ||
                       ((cVar1 == '\x03' && ((~*(uint32_t *)(iVar9 + 0x50) & 1) != 0)))) {
                        if (*(int64_t *)(iVar9 + 0x30) != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d9fe;
                            func_0x000180211410();
                            *(undefined8 *)(iVar9 + 0x30) = 0;
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da10;
                        func_0x000180244fc0(iVar9 + 0x6a, 0x10);
                    }
                    cVar1 = *(char *)(iVar9 + 0x68);
                    if ((((cVar1 != '\x01') && (cVar1 != '\x02')) && (cVar1 == '\x03')) &&
                       ((*(uint32_t *)(iVar9 + 0x50) & 1) != 0)) {
                        if (*(int64_t *)(iVar9 + 0x38) != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da39;
                            func_0x000180211410();
                            *(undefined8 *)(iVar9 + 0x38) = 0;
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da4b;
                        func_0x000180244fc0(iVar9 + 0x7a, 0x10);
                    }
                    uVar14 = *(uint8_t *)((int64_t)&arg_188h + iVar8);
                }
                uVar2 = *(undefined8 *)(iVar9 + 0x28);
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da5d;
                func_0x000180215590(uVar2);
                uVar5 = *(uint32_t *)((int64_t)&arg_190h + iVar8);
                *(undefined8 *)(iVar9 + 0x28) = 0;
                *(undefined *)(iVar9 + 0x68) = 4;
                *(undefined *)(iVar12 + 0x68) = 0;
            }
            if (*(char *)(iVar12 + 0x68) == '\0') {
                uVar11 = 0;
                if (uVar5 == 0) {
                    uVar11 = uVar14;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dae5;
                uVar5 = func_0x0001801f9b10(uVar6);
                if (uVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020daf1;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
                    goto code_r0x00018020da87;
                }
                if (iVar10 != 0) {
code_r0x00018020db52:
                    *(undefined8 *)(iVar12 + 0x40) = *(undefined8 *)((int64_t)&arg_30h + iVar8);
                    *(undefined8 *)(iVar12 + 0x48) = *(undefined8 *)((int64_t)&arg_28h + iVar8);
                    uVar6 = *(undefined4 *)((int64_t)&arg_38h + iVar8);
                    *(int64_t *)(iVar12 + 0x28) = iVar10;
                    *(undefined4 *)(iVar12 + 0x60) = uVar6;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020db76;
                    uVar6 = func_0x0001801f9ab0(uVar6);
                    uVar2 = *(undefined8 *)((int64_t)&arg_50h + iVar8);
                    uVar3 = *(undefined8 *)((int64_t)&arg_28h + iVar8);
                    uVar4 = *(undefined8 *)((int64_t)&arg_30h + iVar8);
                    *(undefined4 *)((int64_t)&var_18h + iVar8) = 1;
                    *(undefined4 *)(iVar12 + 100) = uVar6;
                    *(uint64_t *)((int64_t)&var_10h + iVar8) = (uint64_t)uVar5;
                    *(uint64_t *)(iVar12 + 0x50) = (uint64_t)uVar14;
                    *(char *)(iVar12 + 0x69) = (char)*(undefined4 *)((int64_t)&arg_190h + iVar8);
                    *(int64_t *)((int64_t)&var_8h + iVar8) = (int64_t)&arg_a8h + iVar8;
                    *(undefined8 *)(&stack0x00000000 + iVar8) = 0;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8) = 0;
                    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = 7;
                    *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = 0x1804ba520;
                    *(undefined8 *)(iVar12 + 0x58) = 0;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dbe2;
                    iVar7 = func_0x0001801b4180(uVar4, uVar3, iVar10, uVar2);
                    if (iVar7 != 0) {
                        uVar2 = *(undefined8 *)((int64_t)&arg_180h + iVar8);
                        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = uVar2;
                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = *(undefined8 *)((int64_t)&arg_50h + iVar8);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dc14;
                        iVar7 = func_0x00018020ce40(in_RCX, in_R9 & 0xffffffff, 1, uVar11);
                        if (iVar7 != 0) {
                            *(undefined4 *)((int64_t)&arg_38h + iVar8 + 4) = 1;
                            if (uVar13 == 3) {
                                iVar9 = (int64_t)&arg_68h + iVar8;
                                if (*(int32_t *)((int64_t)&arg_190h + iVar8) != 0) {
                                    iVar9 = iVar12 + 0x8a;
                                }
                                *(undefined4 *)((int64_t)&var_18h + iVar8) = 1;
                                *(undefined8 *)((int64_t)&var_10h + iVar8) = uVar2;
                                *(int64_t *)((int64_t)&var_8h + iVar8) = iVar9;
                                *(undefined8 *)(&stack0x00000000 + iVar8) = 0;
                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8) = 0;
                                *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = 7;
                                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = 0x1804ba528;
                                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dc92;
                                iVar7 = func_0x0001801b4180(*(undefined8 *)((int64_t)&arg_30h + iVar8), 
                                                            *(undefined8 *)((int64_t)&arg_28h + iVar8), iVar10, 
                                                            *(undefined8 *)((int64_t)&arg_50h + iVar8));
                                if (iVar7 != 0) {
                                    if (*(int32_t *)((int64_t)&arg_190h + iVar8) != 0) goto code_r0x00018020dd36;
                                    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = uVar2;
                                    *(int64_t *)(&stack0xffffffffffffffe8 + iVar8) = (int64_t)&arg_68h + iVar8;
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dcd0;
                                    iVar7 = func_0x00018020ce40(in_RCX, in_R9 & 0xffffffff, 1, uVar11 == 0);
                                    if (iVar7 != 0) {
                                        *(undefined4 *)((int64_t)&var_18h + iVar8) = 1;
                                        *(undefined8 *)((int64_t)&var_10h + iVar8) = uVar2;
                                        *(int64_t *)((int64_t)&var_8h + iVar8) = iVar12 + 0x8a;
                                        *(undefined8 *)(&stack0x00000000 + iVar8) = 0;
                                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8) = 0;
                                        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = 7;
                                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = 0x1804ba528;
                                        *(undefined4 *)((int64_t)&arg_40h + iVar8) = 1;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd32;
                                        iVar7 = func_0x0001801b4180(*(undefined8 *)((int64_t)&arg_30h + iVar8), 
                                                                    *(undefined8 *)((int64_t)&arg_28h + iVar8), iVar10, 
                                                                    (int64_t)&arg_68h + iVar8);
                                        if (iVar7 != 0) goto code_r0x00018020dd36;
                                    }
                                }
                            } else {
code_r0x00018020dd36:
                                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd3f;
                                uVar6 = func_0x0001801f9ae0(*(undefined4 *)((int64_t)&arg_38h + iVar8));
                                *(uint64_t *)(&stack0xfffffffffffffff0 + iVar8) = (uint64_t)uVar5;
                                *(int64_t *)(&stack0xffffffffffffffe8 + iVar8) = (int64_t)&arg_a8h + iVar8;
                                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd66;
                                iVar7 = func_0x0001801f8ad0(iVar12, *(undefined8 *)((int64_t)&arg_30h + iVar8), 
                                                            *(undefined8 *)((int64_t)&arg_28h + iVar8), uVar6);
                                if (iVar7 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd7c;
                                    func_0x000180244fc0((int64_t)&arg_a8h + iVar8, 0x40);
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd8e;
                                    func_0x000180244fc0((int64_t)&arg_68h + iVar8, 0x40);
                                    *(undefined *)(iVar12 + 0x68) = 1;
                                    goto code_r0x00018020daaf;
                                }
                            }
                        }
                    }
                    *(undefined4 *)(iVar12 + 0x60) = 0;
                    *(undefined8 *)(iVar12 + 0x28) = 0;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020ddb5;
                    func_0x000180244fc0((int64_t)&arg_a8h + iVar8, 0x40);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020ddc7;
                    func_0x000180244fc0((int64_t)&arg_68h + iVar8, 0x40);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020ddd8;
                    func_0x000180244fc0(iVar12 + 0x8a, 0x40);
                    if (*(int32_t *)((int64_t)&arg_38h + iVar8 + 4) != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020ddeb;
                        fcn.18020d1f0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8));
                    }
                    if (*(int32_t *)((int64_t)&arg_40h + iVar8) != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020de05;
                        fcn.18020d1f0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8));
                    }
                    if (*(int32_t *)((int64_t)&arg_40h + iVar8 + 4) != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020de18;
                        func_0x000180215590(iVar10);
                    }
                    goto code_r0x00018020daaf;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020db1b;
                iVar10 = func_0x000180215540(*(undefined8 *)((int64_t)&arg_30h + iVar8), 
                                             *(undefined8 *)((int64_t)&arg_58h + iVar8), 
                                             *(undefined8 *)((int64_t)&arg_28h + iVar8));
                if (iVar10 != 0) {
                    *(undefined4 *)((int64_t)&arg_40h + iVar8 + 4) = 1;
                    goto code_r0x00018020db52;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020db28;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020db40;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                              *(int64_t *)((int64_t)&var_18h + iVar8));
            } else {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da7b;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
code_r0x00018020da87:
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da93;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                              *(int64_t *)((int64_t)&var_18h + iVar8));
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020daa5;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar8));
            goto code_r0x00018020daaf;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d8fe;
        func_0x0001801f9bc0(uVar6);
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d903;
    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d91b;
    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                  *(int64_t *)((int64_t)&var_18h + iVar8));
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d92d;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar8));
code_r0x00018020daaf:
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dabf;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_e8h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_18020dad2
// Address: 0x18020dad2
// Size: 843 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h

void fcn.18020d890(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_68h, int64_t arg_a8h, int64_t arg_e8h, int64_t arg_100h, int64_t arg_168h,
                  int64_t arg_170h, int64_t arg_178h, int64_t arg_180h, int64_t arg_188h, int64_t arg_190h)
{
    char cVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint8_t uVar11;
    undefined8 unaff_RBX;
    int64_t iVar12;
    undefined8 in_R8;
    uint32_t uVar13;
    uint64_t in_R9;
    uint8_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_40;
    
    uStack_40 = 0x18020d8a6;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&arg_e8h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar8);
    uVar6 = *(undefined4 *)((int64_t)&arg_168h + iVar8);
    iVar10 = *(int64_t *)((int64_t)&arg_170h + iVar8);
    *(undefined8 *)((int64_t)&arg_50h + iVar8) = *(undefined8 *)((int64_t)&arg_178h + iVar8);
    uVar13 = (uint32_t)in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar8) = in_R8;
    *(undefined8 *)((int64_t)&arg_30h + iVar8) = in_RDX;
    *(undefined4 *)((int64_t)&arg_38h + iVar8) = uVar6;
    if (uVar13 < 4) {
        *(undefined4 *)((int64_t)&arg_38h + iVar8 + 4) = 0;
        *(undefined4 *)((int64_t)&arg_40h + iVar8) = 0;
        *(undefined4 *)((int64_t)&arg_40h + iVar8 + 4) = 0;
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d94e;
        iVar9 = func_0x0001801f9bc0(uVar6);
        *(int64_t *)((int64_t)&arg_58h + iVar8) = iVar9;
        iVar12 = (in_R9 & 0xffffffff) * 0xd0 + in_RCX;
        if ((((iVar12 != 0) && (iVar9 != 0)) && (uVar14 = *(uint8_t *)((int64_t)&arg_188h + iVar8), uVar14 < 2)) &&
           ((uVar5 = *(uint32_t *)((int64_t)&arg_190h + iVar8), uVar5 < 2 && ((uVar14 == 0 || (uVar13 == 3)))))) {
            *(undefined8 *)((int64_t)&arg_100h + iVar8) = unaff_RBX;
            if ((uVar13 == 0) && (*(char *)(iVar12 + 0x68) == '\x01')) {
                iVar9 = (in_R9 & 0xffffffff) * 0xd0 + in_RCX;
                cVar1 = *(char *)(iVar9 + 0x68);
                if ((cVar1 != '\0') && (((cVar1 == '\x01' || (cVar1 == '\x02')) || (cVar1 == '\x03')))) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d9d4;
                    func_0x0001801f8940(iVar9);
                    cVar1 = *(char *)(iVar9 + 0x68);
                    if (((cVar1 == '\x01') || (cVar1 == '\x02')) ||
                       ((cVar1 == '\x03' && ((~*(uint32_t *)(iVar9 + 0x50) & 1) != 0)))) {
                        if (*(int64_t *)(iVar9 + 0x30) != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d9fe;
                            func_0x000180211410();
                            *(undefined8 *)(iVar9 + 0x30) = 0;
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da10;
                        func_0x000180244fc0(iVar9 + 0x6a, 0x10);
                    }
                    cVar1 = *(char *)(iVar9 + 0x68);
                    if ((((cVar1 != '\x01') && (cVar1 != '\x02')) && (cVar1 == '\x03')) &&
                       ((*(uint32_t *)(iVar9 + 0x50) & 1) != 0)) {
                        if (*(int64_t *)(iVar9 + 0x38) != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da39;
                            func_0x000180211410();
                            *(undefined8 *)(iVar9 + 0x38) = 0;
                        }
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da4b;
                        func_0x000180244fc0(iVar9 + 0x7a, 0x10);
                    }
                    uVar14 = *(uint8_t *)((int64_t)&arg_188h + iVar8);
                }
                uVar2 = *(undefined8 *)(iVar9 + 0x28);
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da5d;
                func_0x000180215590(uVar2);
                uVar5 = *(uint32_t *)((int64_t)&arg_190h + iVar8);
                *(undefined8 *)(iVar9 + 0x28) = 0;
                *(undefined *)(iVar9 + 0x68) = 4;
                *(undefined *)(iVar12 + 0x68) = 0;
            }
            if (*(char *)(iVar12 + 0x68) == '\0') {
                uVar11 = 0;
                if (uVar5 == 0) {
                    uVar11 = uVar14;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dae5;
                uVar5 = func_0x0001801f9b10(uVar6);
                if (uVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020daf1;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
                    goto code_r0x00018020da87;
                }
                if (iVar10 != 0) {
code_r0x00018020db52:
                    *(undefined8 *)(iVar12 + 0x40) = *(undefined8 *)((int64_t)&arg_30h + iVar8);
                    *(undefined8 *)(iVar12 + 0x48) = *(undefined8 *)((int64_t)&arg_28h + iVar8);
                    uVar6 = *(undefined4 *)((int64_t)&arg_38h + iVar8);
                    *(int64_t *)(iVar12 + 0x28) = iVar10;
                    *(undefined4 *)(iVar12 + 0x60) = uVar6;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020db76;
                    uVar6 = func_0x0001801f9ab0(uVar6);
                    uVar2 = *(undefined8 *)((int64_t)&arg_50h + iVar8);
                    uVar3 = *(undefined8 *)((int64_t)&arg_28h + iVar8);
                    uVar4 = *(undefined8 *)((int64_t)&arg_30h + iVar8);
                    *(undefined4 *)((int64_t)&var_18h + iVar8) = 1;
                    *(undefined4 *)(iVar12 + 100) = uVar6;
                    *(uint64_t *)((int64_t)&var_10h + iVar8) = (uint64_t)uVar5;
                    *(uint64_t *)(iVar12 + 0x50) = (uint64_t)uVar14;
                    *(char *)(iVar12 + 0x69) = (char)*(undefined4 *)((int64_t)&arg_190h + iVar8);
                    *(int64_t *)((int64_t)&var_8h + iVar8) = (int64_t)&arg_a8h + iVar8;
                    *(undefined8 *)(&stack0x00000000 + iVar8) = 0;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8) = 0;
                    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = 7;
                    *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = 0x1804ba520;
                    *(undefined8 *)(iVar12 + 0x58) = 0;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dbe2;
                    iVar7 = func_0x0001801b4180(uVar4, uVar3, iVar10, uVar2);
                    if (iVar7 != 0) {
                        uVar2 = *(undefined8 *)((int64_t)&arg_180h + iVar8);
                        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = uVar2;
                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = *(undefined8 *)((int64_t)&arg_50h + iVar8);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dc14;
                        iVar7 = func_0x00018020ce40(in_RCX, in_R9 & 0xffffffff, 1, uVar11);
                        if (iVar7 != 0) {
                            *(undefined4 *)((int64_t)&arg_38h + iVar8 + 4) = 1;
                            if (uVar13 == 3) {
                                iVar9 = (int64_t)&arg_68h + iVar8;
                                if (*(int32_t *)((int64_t)&arg_190h + iVar8) != 0) {
                                    iVar9 = iVar12 + 0x8a;
                                }
                                *(undefined4 *)((int64_t)&var_18h + iVar8) = 1;
                                *(undefined8 *)((int64_t)&var_10h + iVar8) = uVar2;
                                *(int64_t *)((int64_t)&var_8h + iVar8) = iVar9;
                                *(undefined8 *)(&stack0x00000000 + iVar8) = 0;
                                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8) = 0;
                                *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = 7;
                                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = 0x1804ba528;
                                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dc92;
                                iVar7 = func_0x0001801b4180(*(undefined8 *)((int64_t)&arg_30h + iVar8), 
                                                            *(undefined8 *)((int64_t)&arg_28h + iVar8), iVar10, 
                                                            *(undefined8 *)((int64_t)&arg_50h + iVar8));
                                if (iVar7 != 0) {
                                    if (*(int32_t *)((int64_t)&arg_190h + iVar8) != 0) goto code_r0x00018020dd36;
                                    *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = uVar2;
                                    *(int64_t *)(&stack0xffffffffffffffe8 + iVar8) = (int64_t)&arg_68h + iVar8;
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dcd0;
                                    iVar7 = func_0x00018020ce40(in_RCX, in_R9 & 0xffffffff, 1, uVar11 == 0);
                                    if (iVar7 != 0) {
                                        *(undefined4 *)((int64_t)&var_18h + iVar8) = 1;
                                        *(undefined8 *)((int64_t)&var_10h + iVar8) = uVar2;
                                        *(int64_t *)((int64_t)&var_8h + iVar8) = iVar12 + 0x8a;
                                        *(undefined8 *)(&stack0x00000000 + iVar8) = 0;
                                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar8) = 0;
                                        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar8) = 7;
                                        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = 0x1804ba528;
                                        *(undefined4 *)((int64_t)&arg_40h + iVar8) = 1;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd32;
                                        iVar7 = func_0x0001801b4180(*(undefined8 *)((int64_t)&arg_30h + iVar8), 
                                                                    *(undefined8 *)((int64_t)&arg_28h + iVar8), iVar10, 
                                                                    (int64_t)&arg_68h + iVar8);
                                        if (iVar7 != 0) goto code_r0x00018020dd36;
                                    }
                                }
                            } else {
code_r0x00018020dd36:
                                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd3f;
                                uVar6 = func_0x0001801f9ae0(*(undefined4 *)((int64_t)&arg_38h + iVar8));
                                *(uint64_t *)(&stack0xfffffffffffffff0 + iVar8) = (uint64_t)uVar5;
                                *(int64_t *)(&stack0xffffffffffffffe8 + iVar8) = (int64_t)&arg_a8h + iVar8;
                                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd66;
                                iVar7 = func_0x0001801f8ad0(iVar12, *(undefined8 *)((int64_t)&arg_30h + iVar8), 
                                                            *(undefined8 *)((int64_t)&arg_28h + iVar8), uVar6);
                                if (iVar7 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd7c;
                                    func_0x000180244fc0((int64_t)&arg_a8h + iVar8, 0x40);
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dd8e;
                                    func_0x000180244fc0((int64_t)&arg_68h + iVar8, 0x40);
                                    *(undefined *)(iVar12 + 0x68) = 1;
                                    goto code_r0x00018020daaf;
                                }
                            }
                        }
                    }
                    *(undefined4 *)(iVar12 + 0x60) = 0;
                    *(undefined8 *)(iVar12 + 0x28) = 0;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020ddb5;
                    func_0x000180244fc0((int64_t)&arg_a8h + iVar8, 0x40);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020ddc7;
                    func_0x000180244fc0((int64_t)&arg_68h + iVar8, 0x40);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020ddd8;
                    func_0x000180244fc0(iVar12 + 0x8a, 0x40);
                    if (*(int32_t *)((int64_t)&arg_38h + iVar8 + 4) != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020ddeb;
                        fcn.18020d1f0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8));
                    }
                    if (*(int32_t *)((int64_t)&arg_40h + iVar8) != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020de05;
                        fcn.18020d1f0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8));
                    }
                    if (*(int32_t *)((int64_t)&arg_40h + iVar8 + 4) != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020de18;
                        func_0x000180215590(iVar10);
                    }
                    goto code_r0x00018020daaf;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020db1b;
                iVar10 = func_0x000180215540(*(undefined8 *)((int64_t)&arg_30h + iVar8), 
                                             *(undefined8 *)((int64_t)&arg_58h + iVar8), 
                                             *(undefined8 *)((int64_t)&arg_28h + iVar8));
                if (iVar10 != 0) {
                    *(undefined4 *)((int64_t)&arg_40h + iVar8 + 4) = 1;
                    goto code_r0x00018020db52;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020db28;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020db40;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                              *(int64_t *)((int64_t)&var_18h + iVar8));
            } else {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da7b;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
code_r0x00018020da87:
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020da93;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                              *(int64_t *)((int64_t)&var_18h + iVar8));
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020daa5;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar8));
            goto code_r0x00018020daaf;
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d8fe;
        func_0x0001801f9bc0(uVar6);
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d903;
    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8));
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d91b;
    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar8), *(int64_t *)(&stack0xfffffffffffffff0 + iVar8), 
                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                  *(int64_t *)((int64_t)&var_18h + iVar8));
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020d92d;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar8));
code_r0x00018020daaf:
    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18020dabf;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_e8h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_18020de20
// Address: 0x18020de20
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18020de20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h, int64_t arg_68h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020de35;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    puVar2 = *(undefined8 **)(in_RCX + 0x70);
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020de49;
    piVar8 = (int64_t *)func_0x000180203d60();
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020de54;
    iVar9 = func_0x000180203dc0(in_RCX);
    if (iVar9 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RSI;
        do {
            uVar1 = *(uint32_t *)(in_RCX + 0x20);
            pcVar3 = (code *)puVar2[3];
            uVar4 = puVar2[4];
            iVar10 = *piVar8;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020de83;
            iVar10 = (*pcVar3)(iVar10, uVar1 & 3, uVar4);
            if (iVar10 != 0) {
                if ((uint64_t)piVar8[1] <= (uint64_t)piVar8[2]) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020dea4;
                    func_0x0001801e6480(iVar10);
                }
                if (((*(uint8_t *)(piVar8 + 3) & 1) != 0) && (*piVar8 != -1)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020deb8;
                    func_0x0001801e65a0(iVar10);
                }
                if (((*(uint8_t *)(piVar8 + 3) & 2) != 0) && (iVar5 = *piVar8, iVar5 != -1)) {
                    pcVar3 = (code *)puVar2[7];
                    uVar4 = puVar2[8];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020ded9;
                    (*pcVar3)(5, iVar5, in_RCX, uVar4);
                }
                if (((*(uint8_t *)(piVar8 + 3) & 4) != 0) && (iVar5 = *piVar8, iVar5 != -1)) {
                    pcVar3 = (code *)puVar2[7];
                    uVar4 = puVar2[8];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020defa;
                    (*pcVar3)(4, iVar5, in_RCX, uVar4);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020df02;
                iVar6 = func_0x0001801e6440(iVar10);
                if (iVar6 != 0) {
                    pcVar3 = (code *)puVar2[9];
                    uVar4 = puVar2[10];
                    iVar10 = *piVar8;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020df13;
                    (*pcVar3)(iVar10, uVar4);
                }
            }
            piVar8 = piVar8 + 4;
            iVar9 = iVar9 + -1;
        } while (iVar9 != 0);
    }
    iVar9 = *(int64_t *)(in_RCX + 0x68);
    while (iVar9 != 0) {
        uVar4 = *puVar2;
        iVar9 = *(int64_t *)(iVar9 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020df40;
        func_0x000180202080(uVar4);
    }
    piVar8 = (int64_t *)puVar2[2];
    piVar8[2] = piVar8[2] + -1;
    *(int64_t *)(in_RCX + 0x80) = piVar8[1];
    *(undefined8 *)(in_RCX + 0x88) = 0;
    piVar8[1] = in_RCX;
    if (*(int64_t *)(in_RCX + 0x80) != 0) {
        *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x88) = in_RCX;
    }
    if (*piVar8 == 0) {
        *piVar8 = in_RCX;
    }
    return;
}

// ============================================================
// Function: FUN_18020de3f
// Address: 0x18020de3f
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18020de20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h, int64_t arg_68h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020de35;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    puVar2 = *(undefined8 **)(in_RCX + 0x70);
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020de49;
    piVar8 = (int64_t *)func_0x000180203d60();
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020de54;
    iVar9 = func_0x000180203dc0(in_RCX);
    if (iVar9 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RSI;
        do {
            uVar1 = *(uint32_t *)(in_RCX + 0x20);
            pcVar3 = (code *)puVar2[3];
            uVar4 = puVar2[4];
            iVar10 = *piVar8;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020de83;
            iVar10 = (*pcVar3)(iVar10, uVar1 & 3, uVar4);
            if (iVar10 != 0) {
                if ((uint64_t)piVar8[1] <= (uint64_t)piVar8[2]) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020dea4;
                    func_0x0001801e6480(iVar10);
                }
                if (((*(uint8_t *)(piVar8 + 3) & 1) != 0) && (*piVar8 != -1)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020deb8;
                    func_0x0001801e65a0(iVar10);
                }
                if (((*(uint8_t *)(piVar8 + 3) & 2) != 0) && (iVar5 = *piVar8, iVar5 != -1)) {
                    pcVar3 = (code *)puVar2[7];
                    uVar4 = puVar2[8];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020ded9;
                    (*pcVar3)(5, iVar5, in_RCX, uVar4);
                }
                if (((*(uint8_t *)(piVar8 + 3) & 4) != 0) && (iVar5 = *piVar8, iVar5 != -1)) {
                    pcVar3 = (code *)puVar2[7];
                    uVar4 = puVar2[8];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020defa;
                    (*pcVar3)(4, iVar5, in_RCX, uVar4);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020df02;
                iVar6 = func_0x0001801e6440(iVar10);
                if (iVar6 != 0) {
                    pcVar3 = (code *)puVar2[9];
                    uVar4 = puVar2[10];
                    iVar10 = *piVar8;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020df13;
                    (*pcVar3)(iVar10, uVar4);
                }
            }
            piVar8 = piVar8 + 4;
            iVar9 = iVar9 + -1;
        } while (iVar9 != 0);
    }
    iVar9 = *(int64_t *)(in_RCX + 0x68);
    while (iVar9 != 0) {
        uVar4 = *puVar2;
        iVar9 = *(int64_t *)(iVar9 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020df40;
        func_0x000180202080(uVar4);
    }
    piVar8 = (int64_t *)puVar2[2];
    piVar8[2] = piVar8[2] + -1;
    *(int64_t *)(in_RCX + 0x80) = piVar8[1];
    *(undefined8 *)(in_RCX + 0x88) = 0;
    piVar8[1] = in_RCX;
    if (*(int64_t *)(in_RCX + 0x80) != 0) {
        *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x88) = in_RCX;
    }
    if (*piVar8 == 0) {
        *piVar8 = in_RCX;
    }
    return;
}

// ============================================================
// Function: FUN_18020de60
// Address: 0x18020de60
// Size: 198 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18020de20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h, int64_t arg_68h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020de35;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    puVar2 = *(undefined8 **)(in_RCX + 0x70);
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020de49;
    piVar8 = (int64_t *)func_0x000180203d60();
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020de54;
    iVar9 = func_0x000180203dc0(in_RCX);
    if (iVar9 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RSI;
        do {
            uVar1 = *(uint32_t *)(in_RCX + 0x20);
            pcVar3 = (code *)puVar2[3];
            uVar4 = puVar2[4];
            iVar10 = *piVar8;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020de83;
            iVar10 = (*pcVar3)(iVar10, uVar1 & 3, uVar4);
            if (iVar10 != 0) {
                if ((uint64_t)piVar8[1] <= (uint64_t)piVar8[2]) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020dea4;
                    func_0x0001801e6480(iVar10);
                }
                if (((*(uint8_t *)(piVar8 + 3) & 1) != 0) && (*piVar8 != -1)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020deb8;
                    func_0x0001801e65a0(iVar10);
                }
                if (((*(uint8_t *)(piVar8 + 3) & 2) != 0) && (iVar5 = *piVar8, iVar5 != -1)) {
                    pcVar3 = (code *)puVar2[7];
                    uVar4 = puVar2[8];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020ded9;
                    (*pcVar3)(5, iVar5, in_RCX, uVar4);
                }
                if (((*(uint8_t *)(piVar8 + 3) & 4) != 0) && (iVar5 = *piVar8, iVar5 != -1)) {
                    pcVar3 = (code *)puVar2[7];
                    uVar4 = puVar2[8];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020defa;
                    (*pcVar3)(4, iVar5, in_RCX, uVar4);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020df02;
                iVar6 = func_0x0001801e6440(iVar10);
                if (iVar6 != 0) {
                    pcVar3 = (code *)puVar2[9];
                    uVar4 = puVar2[10];
                    iVar10 = *piVar8;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020df13;
                    (*pcVar3)(iVar10, uVar4);
                }
            }
            piVar8 = piVar8 + 4;
            iVar9 = iVar9 + -1;
        } while (iVar9 != 0);
    }
    iVar9 = *(int64_t *)(in_RCX + 0x68);
    while (iVar9 != 0) {
        uVar4 = *puVar2;
        iVar9 = *(int64_t *)(iVar9 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020df40;
        func_0x000180202080(uVar4);
    }
    piVar8 = (int64_t *)puVar2[2];
    piVar8[2] = piVar8[2] + -1;
    *(int64_t *)(in_RCX + 0x80) = piVar8[1];
    *(undefined8 *)(in_RCX + 0x88) = 0;
    piVar8[1] = in_RCX;
    if (*(int64_t *)(in_RCX + 0x80) != 0) {
        *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x88) = in_RCX;
    }
    if (*piVar8 == 0) {
        *piVar8 = in_RCX;
    }
    return;
}

// ============================================================
// Function: FUN_18020df26
// Address: 0x18020df26
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18020de20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h, int64_t arg_68h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020de35;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    puVar2 = *(undefined8 **)(in_RCX + 0x70);
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020de49;
    piVar8 = (int64_t *)func_0x000180203d60();
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020de54;
    iVar9 = func_0x000180203dc0(in_RCX);
    if (iVar9 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RSI;
        do {
            uVar1 = *(uint32_t *)(in_RCX + 0x20);
            pcVar3 = (code *)puVar2[3];
            uVar4 = puVar2[4];
            iVar10 = *piVar8;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020de83;
            iVar10 = (*pcVar3)(iVar10, uVar1 & 3, uVar4);
            if (iVar10 != 0) {
                if ((uint64_t)piVar8[1] <= (uint64_t)piVar8[2]) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020dea4;
                    func_0x0001801e6480(iVar10);
                }
                if (((*(uint8_t *)(piVar8 + 3) & 1) != 0) && (*piVar8 != -1)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020deb8;
                    func_0x0001801e65a0(iVar10);
                }
                if (((*(uint8_t *)(piVar8 + 3) & 2) != 0) && (iVar5 = *piVar8, iVar5 != -1)) {
                    pcVar3 = (code *)puVar2[7];
                    uVar4 = puVar2[8];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020ded9;
                    (*pcVar3)(5, iVar5, in_RCX, uVar4);
                }
                if (((*(uint8_t *)(piVar8 + 3) & 4) != 0) && (iVar5 = *piVar8, iVar5 != -1)) {
                    pcVar3 = (code *)puVar2[7];
                    uVar4 = puVar2[8];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020defa;
                    (*pcVar3)(4, iVar5, in_RCX, uVar4);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020df02;
                iVar6 = func_0x0001801e6440(iVar10);
                if (iVar6 != 0) {
                    pcVar3 = (code *)puVar2[9];
                    uVar4 = puVar2[10];
                    iVar10 = *piVar8;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020df13;
                    (*pcVar3)(iVar10, uVar4);
                }
            }
            piVar8 = piVar8 + 4;
            iVar9 = iVar9 + -1;
        } while (iVar9 != 0);
    }
    iVar9 = *(int64_t *)(in_RCX + 0x68);
    while (iVar9 != 0) {
        uVar4 = *puVar2;
        iVar9 = *(int64_t *)(iVar9 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020df40;
        func_0x000180202080(uVar4);
    }
    piVar8 = (int64_t *)puVar2[2];
    piVar8[2] = piVar8[2] + -1;
    *(int64_t *)(in_RCX + 0x80) = piVar8[1];
    *(undefined8 *)(in_RCX + 0x88) = 0;
    piVar8[1] = in_RCX;
    if (*(int64_t *)(in_RCX + 0x80) != 0) {
        *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x88) = in_RCX;
    }
    if (*piVar8 == 0) {
        *piVar8 = in_RCX;
    }
    return;
}

// ============================================================
// Function: FUN_18020df34
// Address: 0x18020df34
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18020de20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h, int64_t arg_68h)
{
    uint32_t uVar1;
    undefined8 *puVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020de35;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    puVar2 = *(undefined8 **)(in_RCX + 0x70);
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020de49;
    piVar8 = (int64_t *)func_0x000180203d60();
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020de54;
    iVar9 = func_0x000180203dc0(in_RCX);
    if (iVar9 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RSI;
        do {
            uVar1 = *(uint32_t *)(in_RCX + 0x20);
            pcVar3 = (code *)puVar2[3];
            uVar4 = puVar2[4];
            iVar10 = *piVar8;
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020de83;
            iVar10 = (*pcVar3)(iVar10, uVar1 & 3, uVar4);
            if (iVar10 != 0) {
                if ((uint64_t)piVar8[1] <= (uint64_t)piVar8[2]) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020dea4;
                    func_0x0001801e6480(iVar10);
                }
                if (((*(uint8_t *)(piVar8 + 3) & 1) != 0) && (*piVar8 != -1)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020deb8;
                    func_0x0001801e65a0(iVar10);
                }
                if (((*(uint8_t *)(piVar8 + 3) & 2) != 0) && (iVar5 = *piVar8, iVar5 != -1)) {
                    pcVar3 = (code *)puVar2[7];
                    uVar4 = puVar2[8];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020ded9;
                    (*pcVar3)(5, iVar5, in_RCX, uVar4);
                }
                if (((*(uint8_t *)(piVar8 + 3) & 4) != 0) && (iVar5 = *piVar8, iVar5 != -1)) {
                    pcVar3 = (code *)puVar2[7];
                    uVar4 = puVar2[8];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020defa;
                    (*pcVar3)(4, iVar5, in_RCX, uVar4);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020df02;
                iVar6 = func_0x0001801e6440(iVar10);
                if (iVar6 != 0) {
                    pcVar3 = (code *)puVar2[9];
                    uVar4 = puVar2[10];
                    iVar10 = *piVar8;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020df13;
                    (*pcVar3)(iVar10, uVar4);
                }
            }
            piVar8 = piVar8 + 4;
            iVar9 = iVar9 + -1;
        } while (iVar9 != 0);
    }
    iVar9 = *(int64_t *)(in_RCX + 0x68);
    while (iVar9 != 0) {
        uVar4 = *puVar2;
        iVar9 = *(int64_t *)(iVar9 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020df40;
        func_0x000180202080(uVar4);
    }
    piVar8 = (int64_t *)puVar2[2];
    piVar8[2] = piVar8[2] + -1;
    *(int64_t *)(in_RCX + 0x80) = piVar8[1];
    *(undefined8 *)(in_RCX + 0x88) = 0;
    piVar8[1] = in_RCX;
    if (*(int64_t *)(in_RCX + 0x80) != 0) {
        *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x88) = in_RCX;
    }
    if (*piVar8 == 0) {
        *piVar8 = in_RCX;
    }
    return;
}

// ============================================================
// Function: FUN_18020df70
// Address: 0x18020df70
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18020df70(int64_t arg_28h, int64_t arg_30h, int64_t arg_50h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020df80;
    iVar4 = fcn.18045a350();
    iVar5 = *(int64_t *)(in_RCX + 0x68);
    puVar1 = *(undefined8 **)(in_RCX + 0x70);
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar4) = unaff_RBX;
        do {
            uVar2 = *puVar1;
            iVar5 = *(int64_t *)(iVar5 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar4) = 0x18020dfac;
            func_0x000180202080(uVar2);
        } while (iVar5 != 0);
    }
    piVar3 = (int64_t *)puVar1[2];
    piVar3[2] = piVar3[2] + -1;
    *(int64_t *)(in_RCX + 0x80) = piVar3[1];
    *(undefined8 *)(in_RCX + 0x88) = 0;
    piVar3[1] = in_RCX;
    if (*(int64_t *)(in_RCX + 0x80) != 0) {
        *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x88) = in_RCX;
    }
    if (*piVar3 == 0) {
        *piVar3 = in_RCX;
    }
    return;
}

// ============================================================
// Function: FUN_18020df93
// Address: 0x18020df93
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18020df70(int64_t arg_28h, int64_t arg_30h, int64_t arg_50h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020df80;
    iVar4 = fcn.18045a350();
    iVar5 = *(int64_t *)(in_RCX + 0x68);
    puVar1 = *(undefined8 **)(in_RCX + 0x70);
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar4) = unaff_RBX;
        do {
            uVar2 = *puVar1;
            iVar5 = *(int64_t *)(iVar5 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar4) = 0x18020dfac;
            func_0x000180202080(uVar2);
        } while (iVar5 != 0);
    }
    piVar3 = (int64_t *)puVar1[2];
    piVar3[2] = piVar3[2] + -1;
    *(int64_t *)(in_RCX + 0x80) = piVar3[1];
    *(undefined8 *)(in_RCX + 0x88) = 0;
    piVar3[1] = in_RCX;
    if (*(int64_t *)(in_RCX + 0x80) != 0) {
        *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x88) = in_RCX;
    }
    if (*piVar3 == 0) {
        *piVar3 = in_RCX;
    }
    return;
}

// ============================================================
// Function: FUN_18020dfb9
// Address: 0x18020dfb9
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18020df70(int64_t arg_28h, int64_t arg_30h, int64_t arg_50h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020df80;
    iVar4 = fcn.18045a350();
    iVar5 = *(int64_t *)(in_RCX + 0x68);
    puVar1 = *(undefined8 **)(in_RCX + 0x70);
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar4) = unaff_RBX;
        do {
            uVar2 = *puVar1;
            iVar5 = *(int64_t *)(iVar5 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar4) = 0x18020dfac;
            func_0x000180202080(uVar2);
        } while (iVar5 != 0);
    }
    piVar3 = (int64_t *)puVar1[2];
    piVar3[2] = piVar3[2] + -1;
    *(int64_t *)(in_RCX + 0x80) = piVar3[1];
    *(undefined8 *)(in_RCX + 0x88) = 0;
    piVar3[1] = in_RCX;
    if (*(int64_t *)(in_RCX + 0x80) != 0) {
        *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x88) = in_RCX;
    }
    if (*piVar3 == 0) {
        *piVar3 = in_RCX;
    }
    return;
}

// ============================================================
// Function: FUN_18020dfd0
// Address: 0x18020dfd0
// Size: 23 bytes
// ============================================================
void fcn.18020dfd0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t *puVar1;
    uint32_t uVar2;
    undefined8 *puVar3;
    code *pcVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar10;
    int64_t var_10h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020dfdd;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar3 = *(undefined8 **)(in_RCX + 0x70);
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_10h + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020dffb;
    piVar6 = (int64_t *)func_0x000180203d60();
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e006;
    iVar7 = func_0x000180203dc0(in_RCX);
    pcVar4 = (code *)puVar3[0xb];
    if (pcVar4 == (code *)0x0) {
        uVar8 = 0;
    } else {
        uVar8 = puVar3[0xc];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e01c;
        uVar8 = (*pcVar4)(uVar8);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e027;
    func_0x000180204e50(uVar8, in_RCX);
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R14;
        do {
            uVar2 = *(uint32_t *)(in_RCX + 0x20);
            pcVar4 = (code *)puVar3[3];
            uVar8 = puVar3[4];
            iVar9 = *piVar6;
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e053;
            iVar9 = (*pcVar4)(iVar9, uVar2 & 3, uVar8);
            if (iVar9 != 0) {
                bVar10 = (uint64_t)piVar6[1] <= (uint64_t)piVar6[2];
                if (bVar10) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e077;
                    func_0x0001801e65c0(iVar9);
                }
                if (((*(uint8_t *)(piVar6 + 3) & 1) != 0) && (*piVar6 != -1)) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e091;
                    func_0x0001801e6610(iVar9);
                    bVar10 = true;
                }
                if (((*(uint8_t *)(piVar6 + 3) & 2) != 0) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[5];
                    uVar8 = puVar3[6];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0b8;
                    (*pcVar4)(5, iVar9, in_RCX, uVar8);
                }
                if (((*(uint8_t *)(piVar6 + 3) & 4) != 0) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[5];
                    uVar8 = puVar3[6];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0d9;
                    (*pcVar4)(4, iVar9, in_RCX, uVar8);
                }
                pcVar4 = (code *)puVar3[5];
                uVar8 = puVar3[6];
                iVar9 = *piVar6;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0ee;
                (*pcVar4)(0x11, iVar9, in_RCX, uVar8);
                if ((bVar10) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[9];
                    uVar8 = puVar3[10];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e106;
                    (*pcVar4)(iVar9, uVar8);
                }
            }
            piVar6 = piVar6 + 4;
            iVar7 = iVar7 + -1;
        } while (iVar7 != 0);
    }
    iVar7 = *(int64_t *)(in_RCX + 0x68);
    while (iVar7 != 0) {
        uVar8 = *puVar3;
        iVar9 = *(int64_t *)(iVar7 + 8);
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e142;
        func_0x000180201ee0(uVar8, iVar7, 0xffffffff);
        iVar7 = iVar9;
    }
    if ((*(uint8_t *)(in_RCX + 0x7c) & 1) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e169;
        (*pcVar4)(0x1e, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*(uint8_t *)(in_RCX + 0x7c) & 2) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e18c;
        (*pcVar4)(0x10, 0xffffffffffffffff, in_RCX, uVar8);
    }
    puVar1 = (uint8_t *)(in_RCX + 0x7c);
    if ((*puVar1 & 4) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1b6;
        (*pcVar4)(0x12, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*puVar1 & 8) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1d5;
        (*pcVar4)(0x13, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*puVar1 & 0x10) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1f9;
        (*pcVar4)(3, 0xffffffffffffffff, in_RCX, uVar8);
    }
    piVar6 = (int64_t *)puVar3[2];
    piVar6[2] = piVar6[2] + -1;
    *(int64_t *)(in_RCX + 0x80) = piVar6[1];
    *(undefined8 *)(in_RCX + 0x88) = 0;
    piVar6[1] = in_RCX;
    if (*(int64_t *)(in_RCX + 0x80) != 0) {
        *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x88) = in_RCX;
    }
    if (*piVar6 == 0) {
        *piVar6 = in_RCX;
    }
    return;
}

// ============================================================
// Function: FUN_18020dfe7
// Address: 0x18020dfe7
// Size: 10 bytes
// ============================================================
void fcn.18020dfd0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t *puVar1;
    uint32_t uVar2;
    undefined8 *puVar3;
    code *pcVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar10;
    int64_t var_10h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020dfdd;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar3 = *(undefined8 **)(in_RCX + 0x70);
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_10h + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020dffb;
    piVar6 = (int64_t *)func_0x000180203d60();
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e006;
    iVar7 = func_0x000180203dc0(in_RCX);
    pcVar4 = (code *)puVar3[0xb];
    if (pcVar4 == (code *)0x0) {
        uVar8 = 0;
    } else {
        uVar8 = puVar3[0xc];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e01c;
        uVar8 = (*pcVar4)(uVar8);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e027;
    func_0x000180204e50(uVar8, in_RCX);
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R14;
        do {
            uVar2 = *(uint32_t *)(in_RCX + 0x20);
            pcVar4 = (code *)puVar3[3];
            uVar8 = puVar3[4];
            iVar9 = *piVar6;
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e053;
            iVar9 = (*pcVar4)(iVar9, uVar2 & 3, uVar8);
            if (iVar9 != 0) {
                bVar10 = (uint64_t)piVar6[1] <= (uint64_t)piVar6[2];
                if (bVar10) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e077;
                    func_0x0001801e65c0(iVar9);
                }
                if (((*(uint8_t *)(piVar6 + 3) & 1) != 0) && (*piVar6 != -1)) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e091;
                    func_0x0001801e6610(iVar9);
                    bVar10 = true;
                }
                if (((*(uint8_t *)(piVar6 + 3) & 2) != 0) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[5];
                    uVar8 = puVar3[6];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0b8;
                    (*pcVar4)(5, iVar9, in_RCX, uVar8);
                }
                if (((*(uint8_t *)(piVar6 + 3) & 4) != 0) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[5];
                    uVar8 = puVar3[6];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0d9;
                    (*pcVar4)(4, iVar9, in_RCX, uVar8);
                }
                pcVar4 = (code *)puVar3[5];
                uVar8 = puVar3[6];
                iVar9 = *piVar6;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0ee;
                (*pcVar4)(0x11, iVar9, in_RCX, uVar8);
                if ((bVar10) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[9];
                    uVar8 = puVar3[10];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e106;
                    (*pcVar4)(iVar9, uVar8);
                }
            }
            piVar6 = piVar6 + 4;
            iVar7 = iVar7 + -1;
        } while (iVar7 != 0);
    }
    iVar7 = *(int64_t *)(in_RCX + 0x68);
    while (iVar7 != 0) {
        uVar8 = *puVar3;
        iVar9 = *(int64_t *)(iVar7 + 8);
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e142;
        func_0x000180201ee0(uVar8, iVar7, 0xffffffff);
        iVar7 = iVar9;
    }
    if ((*(uint8_t *)(in_RCX + 0x7c) & 1) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e169;
        (*pcVar4)(0x1e, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*(uint8_t *)(in_RCX + 0x7c) & 2) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e18c;
        (*pcVar4)(0x10, 0xffffffffffffffff, in_RCX, uVar8);
    }
    puVar1 = (uint8_t *)(in_RCX + 0x7c);
    if ((*puVar1 & 4) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1b6;
        (*pcVar4)(0x12, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*puVar1 & 8) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1d5;
        (*pcVar4)(0x13, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*puVar1 & 0x10) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1f9;
        (*pcVar4)(3, 0xffffffffffffffff, in_RCX, uVar8);
    }
    piVar6 = (int64_t *)puVar3[2];
    piVar6[2] = piVar6[2] + -1;
    *(int64_t *)(in_RCX + 0x80) = piVar6[1];
    *(undefined8 *)(in_RCX + 0x88) = 0;
    piVar6[1] = in_RCX;
    if (*(int64_t *)(in_RCX + 0x80) != 0) {
        *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x88) = in_RCX;
    }
    if (*piVar6 == 0) {
        *piVar6 = in_RCX;
    }
    return;
}

// ============================================================
// Function: FUN_18020dff1
// Address: 0x18020dff1
// Size: 63 bytes
// ============================================================
void fcn.18020dfd0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t *puVar1;
    uint32_t uVar2;
    undefined8 *puVar3;
    code *pcVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar10;
    int64_t var_10h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020dfdd;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar3 = *(undefined8 **)(in_RCX + 0x70);
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_10h + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020dffb;
    piVar6 = (int64_t *)func_0x000180203d60();
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e006;
    iVar7 = func_0x000180203dc0(in_RCX);
    pcVar4 = (code *)puVar3[0xb];
    if (pcVar4 == (code *)0x0) {
        uVar8 = 0;
    } else {
        uVar8 = puVar3[0xc];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e01c;
        uVar8 = (*pcVar4)(uVar8);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e027;
    func_0x000180204e50(uVar8, in_RCX);
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R14;
        do {
            uVar2 = *(uint32_t *)(in_RCX + 0x20);
            pcVar4 = (code *)puVar3[3];
            uVar8 = puVar3[4];
            iVar9 = *piVar6;
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e053;
            iVar9 = (*pcVar4)(iVar9, uVar2 & 3, uVar8);
            if (iVar9 != 0) {
                bVar10 = (uint64_t)piVar6[1] <= (uint64_t)piVar6[2];
                if (bVar10) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e077;
                    func_0x0001801e65c0(iVar9);
                }
                if (((*(uint8_t *)(piVar6 + 3) & 1) != 0) && (*piVar6 != -1)) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e091;
                    func_0x0001801e6610(iVar9);
                    bVar10 = true;
                }
                if (((*(uint8_t *)(piVar6 + 3) & 2) != 0) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[5];
                    uVar8 = puVar3[6];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0b8;
                    (*pcVar4)(5, iVar9, in_RCX, uVar8);
                }
                if (((*(uint8_t *)(piVar6 + 3) & 4) != 0) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[5];
                    uVar8 = puVar3[6];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0d9;
                    (*pcVar4)(4, iVar9, in_RCX, uVar8);
                }
                pcVar4 = (code *)puVar3[5];
                uVar8 = puVar3[6];
                iVar9 = *piVar6;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0ee;
                (*pcVar4)(0x11, iVar9, in_RCX, uVar8);
                if ((bVar10) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[9];
                    uVar8 = puVar3[10];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e106;
                    (*pcVar4)(iVar9, uVar8);
                }
            }
            piVar6 = piVar6 + 4;
            iVar7 = iVar7 + -1;
        } while (iVar7 != 0);
    }
    iVar7 = *(int64_t *)(in_RCX + 0x68);
    while (iVar7 != 0) {
        uVar8 = *puVar3;
        iVar9 = *(int64_t *)(iVar7 + 8);
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e142;
        func_0x000180201ee0(uVar8, iVar7, 0xffffffff);
        iVar7 = iVar9;
    }
    if ((*(uint8_t *)(in_RCX + 0x7c) & 1) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e169;
        (*pcVar4)(0x1e, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*(uint8_t *)(in_RCX + 0x7c) & 2) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e18c;
        (*pcVar4)(0x10, 0xffffffffffffffff, in_RCX, uVar8);
    }
    puVar1 = (uint8_t *)(in_RCX + 0x7c);
    if ((*puVar1 & 4) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1b6;
        (*pcVar4)(0x12, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*puVar1 & 8) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1d5;
        (*pcVar4)(0x13, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*puVar1 & 0x10) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1f9;
        (*pcVar4)(3, 0xffffffffffffffff, in_RCX, uVar8);
    }
    piVar6 = (int64_t *)puVar3[2];
    piVar6[2] = piVar6[2] + -1;
    *(int64_t *)(in_RCX + 0x80) = piVar6[1];
    *(undefined8 *)(in_RCX + 0x88) = 0;
    piVar6[1] = in_RCX;
    if (*(int64_t *)(in_RCX + 0x80) != 0) {
        *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x88) = in_RCX;
    }
    if (*piVar6 == 0) {
        *piVar6 = in_RCX;
    }
    return;
}

// ============================================================
// Function: FUN_18020e030
// Address: 0x18020e030
// Size: 233 bytes
// ============================================================
void fcn.18020dfd0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t *puVar1;
    uint32_t uVar2;
    undefined8 *puVar3;
    code *pcVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar10;
    int64_t var_10h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020dfdd;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar3 = *(undefined8 **)(in_RCX + 0x70);
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_10h + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020dffb;
    piVar6 = (int64_t *)func_0x000180203d60();
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e006;
    iVar7 = func_0x000180203dc0(in_RCX);
    pcVar4 = (code *)puVar3[0xb];
    if (pcVar4 == (code *)0x0) {
        uVar8 = 0;
    } else {
        uVar8 = puVar3[0xc];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e01c;
        uVar8 = (*pcVar4)(uVar8);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e027;
    func_0x000180204e50(uVar8, in_RCX);
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R14;
        do {
            uVar2 = *(uint32_t *)(in_RCX + 0x20);
            pcVar4 = (code *)puVar3[3];
            uVar8 = puVar3[4];
            iVar9 = *piVar6;
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e053;
            iVar9 = (*pcVar4)(iVar9, uVar2 & 3, uVar8);
            if (iVar9 != 0) {
                bVar10 = (uint64_t)piVar6[1] <= (uint64_t)piVar6[2];
                if (bVar10) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e077;
                    func_0x0001801e65c0(iVar9);
                }
                if (((*(uint8_t *)(piVar6 + 3) & 1) != 0) && (*piVar6 != -1)) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e091;
                    func_0x0001801e6610(iVar9);
                    bVar10 = true;
                }
                if (((*(uint8_t *)(piVar6 + 3) & 2) != 0) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[5];
                    uVar8 = puVar3[6];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0b8;
                    (*pcVar4)(5, iVar9, in_RCX, uVar8);
                }
                if (((*(uint8_t *)(piVar6 + 3) & 4) != 0) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[5];
                    uVar8 = puVar3[6];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0d9;
                    (*pcVar4)(4, iVar9, in_RCX, uVar8);
                }
                pcVar4 = (code *)puVar3[5];
                uVar8 = puVar3[6];
                iVar9 = *piVar6;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0ee;
                (*pcVar4)(0x11, iVar9, in_RCX, uVar8);
                if ((bVar10) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[9];
                    uVar8 = puVar3[10];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e106;
                    (*pcVar4)(iVar9, uVar8);
                }
            }
            piVar6 = piVar6 + 4;
            iVar7 = iVar7 + -1;
        } while (iVar7 != 0);
    }
    iVar7 = *(int64_t *)(in_RCX + 0x68);
    while (iVar7 != 0) {
        uVar8 = *puVar3;
        iVar9 = *(int64_t *)(iVar7 + 8);
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e142;
        func_0x000180201ee0(uVar8, iVar7, 0xffffffff);
        iVar7 = iVar9;
    }
    if ((*(uint8_t *)(in_RCX + 0x7c) & 1) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e169;
        (*pcVar4)(0x1e, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*(uint8_t *)(in_RCX + 0x7c) & 2) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e18c;
        (*pcVar4)(0x10, 0xffffffffffffffff, in_RCX, uVar8);
    }
    puVar1 = (uint8_t *)(in_RCX + 0x7c);
    if ((*puVar1 & 4) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1b6;
        (*pcVar4)(0x12, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*puVar1 & 8) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1d5;
        (*pcVar4)(0x13, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*puVar1 & 0x10) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1f9;
        (*pcVar4)(3, 0xffffffffffffffff, in_RCX, uVar8);
    }
    piVar6 = (int64_t *)puVar3[2];
    piVar6[2] = piVar6[2] + -1;
    *(int64_t *)(in_RCX + 0x80) = piVar6[1];
    *(undefined8 *)(in_RCX + 0x88) = 0;
    piVar6[1] = in_RCX;
    if (*(int64_t *)(in_RCX + 0x80) != 0) {
        *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x88) = in_RCX;
    }
    if (*piVar6 == 0) {
        *piVar6 = in_RCX;
    }
    return;
}

// ============================================================
// Function: FUN_18020e119
// Address: 0x18020e119
// Size: 23 bytes
// ============================================================
void fcn.18020dfd0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t *puVar1;
    uint32_t uVar2;
    undefined8 *puVar3;
    code *pcVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar10;
    int64_t var_10h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020dfdd;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar3 = *(undefined8 **)(in_RCX + 0x70);
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_10h + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020dffb;
    piVar6 = (int64_t *)func_0x000180203d60();
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e006;
    iVar7 = func_0x000180203dc0(in_RCX);
    pcVar4 = (code *)puVar3[0xb];
    if (pcVar4 == (code *)0x0) {
        uVar8 = 0;
    } else {
        uVar8 = puVar3[0xc];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e01c;
        uVar8 = (*pcVar4)(uVar8);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e027;
    func_0x000180204e50(uVar8, in_RCX);
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R14;
        do {
            uVar2 = *(uint32_t *)(in_RCX + 0x20);
            pcVar4 = (code *)puVar3[3];
            uVar8 = puVar3[4];
            iVar9 = *piVar6;
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e053;
            iVar9 = (*pcVar4)(iVar9, uVar2 & 3, uVar8);
            if (iVar9 != 0) {
                bVar10 = (uint64_t)piVar6[1] <= (uint64_t)piVar6[2];
                if (bVar10) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e077;
                    func_0x0001801e65c0(iVar9);
                }
                if (((*(uint8_t *)(piVar6 + 3) & 1) != 0) && (*piVar6 != -1)) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e091;
                    func_0x0001801e6610(iVar9);
                    bVar10 = true;
                }
                if (((*(uint8_t *)(piVar6 + 3) & 2) != 0) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[5];
                    uVar8 = puVar3[6];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0b8;
                    (*pcVar4)(5, iVar9, in_RCX, uVar8);
                }
                if (((*(uint8_t *)(piVar6 + 3) & 4) != 0) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[5];
                    uVar8 = puVar3[6];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0d9;
                    (*pcVar4)(4, iVar9, in_RCX, uVar8);
                }
                pcVar4 = (code *)puVar3[5];
                uVar8 = puVar3[6];
                iVar9 = *piVar6;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0ee;
                (*pcVar4)(0x11, iVar9, in_RCX, uVar8);
                if ((bVar10) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[9];
                    uVar8 = puVar3[10];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e106;
                    (*pcVar4)(iVar9, uVar8);
                }
            }
            piVar6 = piVar6 + 4;
            iVar7 = iVar7 + -1;
        } while (iVar7 != 0);
    }
    iVar7 = *(int64_t *)(in_RCX + 0x68);
    while (iVar7 != 0) {
        uVar8 = *puVar3;
        iVar9 = *(int64_t *)(iVar7 + 8);
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e142;
        func_0x000180201ee0(uVar8, iVar7, 0xffffffff);
        iVar7 = iVar9;
    }
    if ((*(uint8_t *)(in_RCX + 0x7c) & 1) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e169;
        (*pcVar4)(0x1e, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*(uint8_t *)(in_RCX + 0x7c) & 2) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e18c;
        (*pcVar4)(0x10, 0xffffffffffffffff, in_RCX, uVar8);
    }
    puVar1 = (uint8_t *)(in_RCX + 0x7c);
    if ((*puVar1 & 4) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1b6;
        (*pcVar4)(0x12, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*puVar1 & 8) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1d5;
        (*pcVar4)(0x13, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*puVar1 & 0x10) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1f9;
        (*pcVar4)(3, 0xffffffffffffffff, in_RCX, uVar8);
    }
    piVar6 = (int64_t *)puVar3[2];
    piVar6[2] = piVar6[2] + -1;
    *(int64_t *)(in_RCX + 0x80) = piVar6[1];
    *(undefined8 *)(in_RCX + 0x88) = 0;
    piVar6[1] = in_RCX;
    if (*(int64_t *)(in_RCX + 0x80) != 0) {
        *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x88) = in_RCX;
    }
    if (*piVar6 == 0) {
        *piVar6 = in_RCX;
    }
    return;
}

// ============================================================
// Function: FUN_18020e130
// Address: 0x18020e130
// Size: 109 bytes
// ============================================================
void fcn.18020dfd0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t *puVar1;
    uint32_t uVar2;
    undefined8 *puVar3;
    code *pcVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar10;
    int64_t var_10h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020dfdd;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar3 = *(undefined8 **)(in_RCX + 0x70);
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_10h + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020dffb;
    piVar6 = (int64_t *)func_0x000180203d60();
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e006;
    iVar7 = func_0x000180203dc0(in_RCX);
    pcVar4 = (code *)puVar3[0xb];
    if (pcVar4 == (code *)0x0) {
        uVar8 = 0;
    } else {
        uVar8 = puVar3[0xc];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e01c;
        uVar8 = (*pcVar4)(uVar8);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e027;
    func_0x000180204e50(uVar8, in_RCX);
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R14;
        do {
            uVar2 = *(uint32_t *)(in_RCX + 0x20);
            pcVar4 = (code *)puVar3[3];
            uVar8 = puVar3[4];
            iVar9 = *piVar6;
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e053;
            iVar9 = (*pcVar4)(iVar9, uVar2 & 3, uVar8);
            if (iVar9 != 0) {
                bVar10 = (uint64_t)piVar6[1] <= (uint64_t)piVar6[2];
                if (bVar10) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e077;
                    func_0x0001801e65c0(iVar9);
                }
                if (((*(uint8_t *)(piVar6 + 3) & 1) != 0) && (*piVar6 != -1)) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e091;
                    func_0x0001801e6610(iVar9);
                    bVar10 = true;
                }
                if (((*(uint8_t *)(piVar6 + 3) & 2) != 0) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[5];
                    uVar8 = puVar3[6];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0b8;
                    (*pcVar4)(5, iVar9, in_RCX, uVar8);
                }
                if (((*(uint8_t *)(piVar6 + 3) & 4) != 0) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[5];
                    uVar8 = puVar3[6];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0d9;
                    (*pcVar4)(4, iVar9, in_RCX, uVar8);
                }
                pcVar4 = (code *)puVar3[5];
                uVar8 = puVar3[6];
                iVar9 = *piVar6;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0ee;
                (*pcVar4)(0x11, iVar9, in_RCX, uVar8);
                if ((bVar10) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[9];
                    uVar8 = puVar3[10];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e106;
                    (*pcVar4)(iVar9, uVar8);
                }
            }
            piVar6 = piVar6 + 4;
            iVar7 = iVar7 + -1;
        } while (iVar7 != 0);
    }
    iVar7 = *(int64_t *)(in_RCX + 0x68);
    while (iVar7 != 0) {
        uVar8 = *puVar3;
        iVar9 = *(int64_t *)(iVar7 + 8);
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e142;
        func_0x000180201ee0(uVar8, iVar7, 0xffffffff);
        iVar7 = iVar9;
    }
    if ((*(uint8_t *)(in_RCX + 0x7c) & 1) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e169;
        (*pcVar4)(0x1e, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*(uint8_t *)(in_RCX + 0x7c) & 2) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e18c;
        (*pcVar4)(0x10, 0xffffffffffffffff, in_RCX, uVar8);
    }
    puVar1 = (uint8_t *)(in_RCX + 0x7c);
    if ((*puVar1 & 4) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1b6;
        (*pcVar4)(0x12, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*puVar1 & 8) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1d5;
        (*pcVar4)(0x13, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*puVar1 & 0x10) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1f9;
        (*pcVar4)(3, 0xffffffffffffffff, in_RCX, uVar8);
    }
    piVar6 = (int64_t *)puVar3[2];
    piVar6[2] = piVar6[2] + -1;
    *(int64_t *)(in_RCX + 0x80) = piVar6[1];
    *(undefined8 *)(in_RCX + 0x88) = 0;
    piVar6[1] = in_RCX;
    if (*(int64_t *)(in_RCX + 0x80) != 0) {
        *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x88) = in_RCX;
    }
    if (*piVar6 == 0) {
        *piVar6 = in_RCX;
    }
    return;
}

// ============================================================
// Function: FUN_18020e19d
// Address: 0x18020e19d
// Size: 67 bytes
// ============================================================
void fcn.18020dfd0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t *puVar1;
    uint32_t uVar2;
    undefined8 *puVar3;
    code *pcVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar10;
    int64_t var_10h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020dfdd;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar3 = *(undefined8 **)(in_RCX + 0x70);
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_10h + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020dffb;
    piVar6 = (int64_t *)func_0x000180203d60();
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e006;
    iVar7 = func_0x000180203dc0(in_RCX);
    pcVar4 = (code *)puVar3[0xb];
    if (pcVar4 == (code *)0x0) {
        uVar8 = 0;
    } else {
        uVar8 = puVar3[0xc];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e01c;
        uVar8 = (*pcVar4)(uVar8);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e027;
    func_0x000180204e50(uVar8, in_RCX);
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R14;
        do {
            uVar2 = *(uint32_t *)(in_RCX + 0x20);
            pcVar4 = (code *)puVar3[3];
            uVar8 = puVar3[4];
            iVar9 = *piVar6;
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e053;
            iVar9 = (*pcVar4)(iVar9, uVar2 & 3, uVar8);
            if (iVar9 != 0) {
                bVar10 = (uint64_t)piVar6[1] <= (uint64_t)piVar6[2];
                if (bVar10) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e077;
                    func_0x0001801e65c0(iVar9);
                }
                if (((*(uint8_t *)(piVar6 + 3) & 1) != 0) && (*piVar6 != -1)) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e091;
                    func_0x0001801e6610(iVar9);
                    bVar10 = true;
                }
                if (((*(uint8_t *)(piVar6 + 3) & 2) != 0) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[5];
                    uVar8 = puVar3[6];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0b8;
                    (*pcVar4)(5, iVar9, in_RCX, uVar8);
                }
                if (((*(uint8_t *)(piVar6 + 3) & 4) != 0) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[5];
                    uVar8 = puVar3[6];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0d9;
                    (*pcVar4)(4, iVar9, in_RCX, uVar8);
                }
                pcVar4 = (code *)puVar3[5];
                uVar8 = puVar3[6];
                iVar9 = *piVar6;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0ee;
                (*pcVar4)(0x11, iVar9, in_RCX, uVar8);
                if ((bVar10) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[9];
                    uVar8 = puVar3[10];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e106;
                    (*pcVar4)(iVar9, uVar8);
                }
            }
            piVar6 = piVar6 + 4;
            iVar7 = iVar7 + -1;
        } while (iVar7 != 0);
    }
    iVar7 = *(int64_t *)(in_RCX + 0x68);
    while (iVar7 != 0) {
        uVar8 = *puVar3;
        iVar9 = *(int64_t *)(iVar7 + 8);
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e142;
        func_0x000180201ee0(uVar8, iVar7, 0xffffffff);
        iVar7 = iVar9;
    }
    if ((*(uint8_t *)(in_RCX + 0x7c) & 1) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e169;
        (*pcVar4)(0x1e, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*(uint8_t *)(in_RCX + 0x7c) & 2) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e18c;
        (*pcVar4)(0x10, 0xffffffffffffffff, in_RCX, uVar8);
    }
    puVar1 = (uint8_t *)(in_RCX + 0x7c);
    if ((*puVar1 & 4) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1b6;
        (*pcVar4)(0x12, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*puVar1 & 8) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1d5;
        (*pcVar4)(0x13, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*puVar1 & 0x10) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1f9;
        (*pcVar4)(3, 0xffffffffffffffff, in_RCX, uVar8);
    }
    piVar6 = (int64_t *)puVar3[2];
    piVar6[2] = piVar6[2] + -1;
    *(int64_t *)(in_RCX + 0x80) = piVar6[1];
    *(undefined8 *)(in_RCX + 0x88) = 0;
    piVar6[1] = in_RCX;
    if (*(int64_t *)(in_RCX + 0x80) != 0) {
        *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x88) = in_RCX;
    }
    if (*piVar6 == 0) {
        *piVar6 = in_RCX;
    }
    return;
}

// ============================================================
// Function: FUN_18020e1e0
// Address: 0x18020e1e0
// Size: 43 bytes
// ============================================================
void fcn.18020dfd0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t *puVar1;
    uint32_t uVar2;
    undefined8 *puVar3;
    code *pcVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar10;
    int64_t var_10h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18020dfdd;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar3 = *(undefined8 **)(in_RCX + 0x70);
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_10h + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020dffb;
    piVar6 = (int64_t *)func_0x000180203d60();
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e006;
    iVar7 = func_0x000180203dc0(in_RCX);
    pcVar4 = (code *)puVar3[0xb];
    if (pcVar4 == (code *)0x0) {
        uVar8 = 0;
    } else {
        uVar8 = puVar3[0xc];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e01c;
        uVar8 = (*pcVar4)(uVar8);
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e027;
    func_0x000180204e50(uVar8, in_RCX);
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_R14;
        do {
            uVar2 = *(uint32_t *)(in_RCX + 0x20);
            pcVar4 = (code *)puVar3[3];
            uVar8 = puVar3[4];
            iVar9 = *piVar6;
            *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e053;
            iVar9 = (*pcVar4)(iVar9, uVar2 & 3, uVar8);
            if (iVar9 != 0) {
                bVar10 = (uint64_t)piVar6[1] <= (uint64_t)piVar6[2];
                if (bVar10) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e077;
                    func_0x0001801e65c0(iVar9);
                }
                if (((*(uint8_t *)(piVar6 + 3) & 1) != 0) && (*piVar6 != -1)) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e091;
                    func_0x0001801e6610(iVar9);
                    bVar10 = true;
                }
                if (((*(uint8_t *)(piVar6 + 3) & 2) != 0) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[5];
                    uVar8 = puVar3[6];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0b8;
                    (*pcVar4)(5, iVar9, in_RCX, uVar8);
                }
                if (((*(uint8_t *)(piVar6 + 3) & 4) != 0) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[5];
                    uVar8 = puVar3[6];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0d9;
                    (*pcVar4)(4, iVar9, in_RCX, uVar8);
                }
                pcVar4 = (code *)puVar3[5];
                uVar8 = puVar3[6];
                iVar9 = *piVar6;
                *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e0ee;
                (*pcVar4)(0x11, iVar9, in_RCX, uVar8);
                if ((bVar10) && (iVar9 = *piVar6, iVar9 != -1)) {
                    pcVar4 = (code *)puVar3[9];
                    uVar8 = puVar3[10];
                    *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e106;
                    (*pcVar4)(iVar9, uVar8);
                }
            }
            piVar6 = piVar6 + 4;
            iVar7 = iVar7 + -1;
        } while (iVar7 != 0);
    }
    iVar7 = *(int64_t *)(in_RCX + 0x68);
    while (iVar7 != 0) {
        uVar8 = *puVar3;
        iVar9 = *(int64_t *)(iVar7 + 8);
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e142;
        func_0x000180201ee0(uVar8, iVar7, 0xffffffff);
        iVar7 = iVar9;
    }
    if ((*(uint8_t *)(in_RCX + 0x7c) & 1) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e169;
        (*pcVar4)(0x1e, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*(uint8_t *)(in_RCX + 0x7c) & 2) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e18c;
        (*pcVar4)(0x10, 0xffffffffffffffff, in_RCX, uVar8);
    }
    puVar1 = (uint8_t *)(in_RCX + 0x7c);
    if ((*puVar1 & 4) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1b6;
        (*pcVar4)(0x12, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*puVar1 & 8) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1d5;
        (*pcVar4)(0x13, 0xffffffffffffffff, in_RCX, uVar8);
    }
    if ((*puVar1 & 0x10) != 0) {
        pcVar4 = (code *)puVar3[5];
        uVar8 = puVar3[6];
        *(undefined8 *)((int64_t)&uStack_18 + iVar5) = 0x18020e1f9;
        (*pcVar4)(3, 0xffffffffffffffff, in_RCX, uVar8);
    }
    piVar6 = (int64_t *)puVar3[2];
    piVar6[2] = piVar6[2] + -1;
    *(int64_t *)(in_RCX + 0x80) = piVar6[1];
    *(undefined8 *)(in_RCX + 0x88) = 0;
    piVar6[1] = in_RCX;
    if (*(int64_t *)(in_RCX + 0x80) != 0) {
        *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x88) = in_RCX;
    }
    if (*piVar6 == 0) {
        *piVar6 = in_RCX;
    }
    return;
}

// ============================================================
// Function: FUN_18020e2a0
// Address: 0x18020e2a0
// Size: 290 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18020e2a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    code *pcVar2;
    uint64_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    undefined8 uVar8;
    undefined8 *in_RCX;
    int64_t in_RDX;
    uint64_t *puVar9;
    undefined8 unaff_RBP;
    uint64_t uVar10;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18020e2b9;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar10 = 0;
    *(undefined8 **)(in_RDX + 0x70) = in_RCX;
    *(int64_t *)(in_RDX + 0x40) = in_RDX;
    *(code **)(in_RDX + 0x28) = fcn.18020dfd0;
    *(code **)(in_RDX + 0x30) = fcn.18020de20;
    *(code **)(in_RDX + 0x38) = fcn.18020df70;
    *(undefined (*) [16])(in_RDX + 0x48) = ZEXT816(0);
    iVar6 = *(int64_t *)(in_RDX + 0x68);
    *(undefined8 *)(in_RDX + 0x60) = 0;
    *(undefined8 *)(in_RDX + 0x58) = 0;
    for (; iVar6 != 0; iVar6 = *(int64_t *)(iVar6 + 8)) {
        uVar8 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020e310;
        func_0x000180201fc0(uVar8, iVar6);
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020e326;
    iVar6 = func_0x000180203d60(in_RDX);
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020e331;
    uVar7 = func_0x000180203dc0(in_RDX);
    if (uVar7 != 0) {
        puVar9 = (uint64_t *)(iVar6 + 0x10);
        do {
            uVar1 = *(uint32_t *)(in_RDX + 0x20);
            pcVar2 = (code *)in_RCX[3];
            uVar8 = in_RCX[4];
            uVar3 = puVar9[-2];
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020e355;
            iVar6 = (*pcVar2)(uVar3, uVar1 & 3, uVar8);
            if (iVar6 != 0) {
                if (puVar9[-1] <= *puVar9) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020e371;
                    iVar4 = func_0x0001801e6630(iVar6);
                    if (iVar4 == 0) {
                        return 0;
                    }
                }
                if ((*(uint8_t *)(puVar9 + 1) & 1) != 0) {
                    uVar3 = *puVar9;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020e389;
                    iVar4 = func_0x0001801e6680(iVar6, uVar3 + 1);
                    if (iVar4 == 0) {
                        return 0;
                    }
                }
            }
            uVar10 = uVar10 + 1;
            puVar9 = puVar9 + 4;
        } while (uVar10 < uVar7);
    }
    uVar8 = in_RCX[1];
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18020e3a5;
    uVar8 = func_0x000180203720(uVar8, in_RDX);
    return uVar8;
}

// ============================================================
// Function: FUN_18020e3e0
// Address: 0x18020e3e0
// Size: 30 bytes
// ============================================================
undefined8 fcn.18020e3e0(void)
{
    int64_t iVar1;
    undefined4 *puVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020e3ea;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x18020e3f2;
    puVar2 = (undefined4 *)fcn.1801dd170();
    *(undefined (*) [16])(puVar2 + 5) = ZEXT816(0);
    *(undefined (*) [16])(puVar2 + 9) = ZEXT816(0);
    *(undefined (*) [16])(puVar2 + 0xd) = ZEXT816(0);
    *(undefined (*) [16])(puVar2 + 0x11) = ZEXT816(0);
    *(undefined8 *)(puVar2 + 0x15) = 0;
    puVar2[0x17] = 0;
    *puVar2 = 0x67452301;
    puVar2[1] = 0xefcdab89;
    puVar2[2] = 0x98badcfe;
    puVar2[3] = 0x10325476;
    puVar2[4] = 0xc3d2e1f0;
    return 1;
}

// ============================================================
// Function: FUN_18020e400
// Address: 0x18020e400
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable arg_64h

undefined8
fcn.18020e400(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h)
{
    uint32_t *puVar1;
    undefined (*pauVar2) [16];
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t in_RDX;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar9;
    uint64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020e410;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020e41e;
    iVar4 = fcn.1801dd170();
    uVar9 = *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = *(undefined8 *)((int64_t)&arg_28h + iVar3);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = uVar9;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8) = unaff_R12;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + -8) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + -0x10) = 0x180275d84;
    iVar5 = fcn.18045a350(iVar4, in_RDX);
    iVar5 = -iVar5;
    if (in_R8 != 0) {
        uVar6 = *(uint32_t *)(iVar4 + 0x14) + (int32_t)in_R8 * 8;
        if (uVar6 < *(uint32_t *)(iVar4 + 0x14)) {
            *(int32_t *)(iVar4 + 0x18) = *(int32_t *)(iVar4 + 0x18) + 1;
        }
        puVar1 = (uint32_t *)(iVar4 + 0x5c);
        *(uint32_t *)(iVar4 + 0x14) = uVar6;
        uVar7 = (uint64_t)*puVar1;
        pauVar2 = (undefined (*) [16])(iVar4 + 0x1c);
        *(int32_t *)(iVar4 + 0x18) = *(int32_t *)(iVar4 + 0x18) + (int32_t)(in_R8 >> 0x1d);
        if (uVar7 != 0) {
            if ((in_R8 < 0x40) && (uVar7 + in_R8 < 0x40)) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x180275de2;
                func_0x000180498030(*pauVar2 + uVar7, in_RDX);
                *puVar1 = *puVar1 + (int32_t)in_R8;
                return 1;
            }
            iVar8 = 0x40 - uVar7;
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x180275e04;
            func_0x000180498030(*pauVar2 + uVar7, in_RDX, iVar8);
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x180275e15;
            func_0x000180276020(iVar4, pauVar2, 1);
            *puVar1 = 0;
            *pauVar2 = ZEXT816(0);
            in_RDX = in_RDX + iVar8;
            *(undefined (*) [16])(iVar4 + 0x2c) = ZEXT816(0);
            in_R8 = in_R8 - iVar8;
            *(undefined (*) [16])(iVar4 + 0x3c) = ZEXT816(0);
            *(undefined (*) [16])(iVar4 + 0x4c) = ZEXT816(0);
        }
        if (in_R8 >> 6 != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x180275e51;
            func_0x000180276020(iVar4, in_RDX, in_R8 >> 6);
            in_RDX = in_RDX + (in_R8 & 0xffffffffffffffc0);
            in_R8 = in_R8 - (in_R8 & 0xffffffffffffffc0);
        }
        if (in_R8 != 0) {
            *(int32_t *)(iVar4 + 0x5c) = (int32_t)in_R8;
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x180275e73;
            func_0x000180498030(pauVar2, in_RDX, in_R8);
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18020e440
// Address: 0x18020e440
// Size: 39 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_39h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ah
// WARNING: [rz-ghidra] Detected overlap for variable arg_3bh
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_3dh
// WARNING: [rz-ghidra] Detected overlap for variable arg_3eh
// WARNING: [rz-ghidra] Detected overlap for variable arg_3fh
// WARNING: [rz-ghidra] Detected overlap for variable arg_51h
// WARNING: [rz-ghidra] Detected overlap for variable arg_52h
// WARNING: [rz-ghidra] Detected overlap for variable arg_53h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_55h
// WARNING: [rz-ghidra] Detected overlap for variable arg_56h
// WARNING: [rz-ghidra] Detected overlap for variable arg_57h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h

undefined8
fcn.18020e440(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined *in_RDX;
    uint64_t uVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020e44c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020e457;
    puVar4 = (undefined4 *)fcn.1801dd170();
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3) = 0x180275b8a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar1 = puVar4 + 7;
    uVar6 = (uint64_t)(uint32_t)puVar4[0x17] + 1;
    *(undefined *)((uint64_t)(uint32_t)puVar4[0x17] + (int64_t)puVar1) = 0x80;
    if (0x38 < uVar6) {
        *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3) = 0x180275bbc;
        fcn.1804986e0(uVar6 + (int64_t)puVar1, 0, 0x40 - uVar6);
        uVar6 = 0;
        *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3) = 0x180275bcf;
        fcn.180276020(*(int64_t *)(&stack0x00000080 + iVar5 + iVar3), *(int64_t *)(&stack0x00000088 + iVar5 + iVar3), 
                      *(int64_t *)(&stack0x00000090 + iVar5 + iVar3), *(int64_t *)(&stack0x00000098 + iVar5 + iVar3), 
                      *(int64_t *)(&stack0x00000138 + iVar5 + iVar3));
    }
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3) = 0x180275be3;
    fcn.1804986e0(uVar6 + (int64_t)puVar1, 0, 0x38 - uVar6);
    *(undefined *)(puVar4 + 0x15) = *(undefined *)((int64_t)puVar4 + 0x1b);
    *(undefined *)((int64_t)puVar4 + 0x55) = *(undefined *)((int64_t)puVar4 + 0x1a);
    *(undefined *)((int64_t)puVar4 + 0x56) = *(undefined *)((int64_t)puVar4 + 0x19);
    *(undefined *)((int64_t)puVar4 + 0x57) = *(undefined *)(puVar4 + 6);
    *(undefined *)(puVar4 + 0x16) = *(undefined *)((int64_t)puVar4 + 0x17);
    *(undefined *)((int64_t)puVar4 + 0x59) = *(undefined *)((int64_t)puVar4 + 0x16);
    *(undefined *)((int64_t)puVar4 + 0x5a) = *(undefined *)((int64_t)puVar4 + 0x15);
    *(undefined *)((int64_t)puVar4 + 0x5b) = *(undefined *)(puVar4 + 5);
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3) = 0x180275c2c;
    fcn.180276020(*(int64_t *)(&stack0x00000080 + iVar5 + iVar3), *(int64_t *)(&stack0x00000088 + iVar5 + iVar3), 
                  *(int64_t *)(&stack0x00000090 + iVar5 + iVar3), *(int64_t *)(&stack0x00000098 + iVar5 + iVar3), 
                  *(int64_t *)(&stack0x00000138 + iVar5 + iVar3));
    puVar4[0x17] = 0;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3) = 0x180275c40;
    fcn.180244fc0(puVar1, 0x40);
    uVar2 = *puVar4;
    *in_RDX = (char)((uint32_t)uVar2 >> 0x18);
    in_RDX[1] = (char)((uint32_t)uVar2 >> 0x10);
    in_RDX[2] = (char)((uint32_t)uVar2 >> 8);
    in_RDX[3] = (char)uVar2;
    uVar2 = puVar4[1];
    in_RDX[4] = (char)((uint32_t)uVar2 >> 0x18);
    in_RDX[5] = (char)((uint32_t)uVar2 >> 0x10);
    in_RDX[6] = (char)((uint32_t)uVar2 >> 8);
    in_RDX[7] = (char)uVar2;
    uVar2 = puVar4[2];
    in_RDX[8] = (char)((uint32_t)uVar2 >> 0x18);
    in_RDX[9] = (char)((uint32_t)uVar2 >> 0x10);
    in_RDX[10] = (char)((uint32_t)uVar2 >> 8);
    in_RDX[0xb] = (char)uVar2;
    uVar2 = puVar4[3];
    in_RDX[0xc] = (char)((uint32_t)uVar2 >> 0x18);
    in_RDX[0xd] = (char)((uint32_t)uVar2 >> 0x10);
    in_RDX[0xe] = (char)((uint32_t)uVar2 >> 8);
    in_RDX[0xf] = (char)uVar2;
    uVar2 = puVar4[4];
    in_RDX[0x10] = (char)((uint32_t)uVar2 >> 0x18);
    in_RDX[0x11] = (char)((uint32_t)uVar2 >> 0x10);
    in_RDX[0x12] = (char)((uint32_t)uVar2 >> 8);
    in_RDX[0x13] = (char)uVar2;
    return 1;
}

// ============================================================
// Function: FUN_18020e470
// Address: 0x18020e470
// Size: 30 bytes
// ============================================================
undefined8 fcn.18020e470(void)
{
    int64_t iVar1;
    undefined4 *puVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020e47a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x18020e482;
    puVar2 = (undefined4 *)fcn.1801dd170();
    *(undefined (*) [16])(puVar2 + 8) = ZEXT816(0);
    *(undefined (*) [16])(puVar2 + 0xc) = ZEXT816(0);
    *(undefined (*) [16])(puVar2 + 0x10) = ZEXT816(0);
    *(undefined (*) [16])(puVar2 + 0x14) = ZEXT816(0);
    *(undefined8 *)(puVar2 + 0x18) = 0;
    puVar2[0x1a] = 0;
    *puVar2 = 0xc1059ed8;
    puVar2[1] = 0x367cd507;
    puVar2[2] = 0x3070dd17;
    puVar2[3] = 0xf70e5939;
    puVar2[4] = 0xffc00b31;
    puVar2[5] = 0x68581511;
    puVar2[6] = 0x64f98fa7;
    puVar2[7] = 0xbefa4fa4;
    puVar2[0x1b] = 0x1c;
    return 1;
}

// ============================================================
// Function: FUN_18020e490
// Address: 0x18020e490
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.18020e490(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    uint32_t *puVar1;
    undefined (*pauVar2) [16];
    uint32_t uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint32_t uVar9;
    int64_t in_RDX;
    int64_t iVar10;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    uint64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020e4a0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020e4ae;
    iVar6 = fcn.1801dd170();
    uVar4 = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    uVar11 = *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8);
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5) = uVar11;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + -8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + -0x10) = 0x1802774bf;
    iVar7 = fcn.18045a350(iVar6, in_RDX);
    iVar7 = -iVar7;
    if (in_R8 != 0) {
        uVar3 = *(uint32_t *)(iVar6 + 0x20);
        *(undefined8 *)((int64_t)&arg_50h + iVar7 + iVar5) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_58h + iVar7 + iVar5) = unaff_R12;
        *(undefined8 *)((int64_t)&arg_60h + iVar7 + iVar5) = unaff_R15;
        uVar9 = uVar3 + (int32_t)in_R8 * 8;
        if (uVar9 < uVar3) {
            *(int32_t *)(iVar6 + 0x24) = *(int32_t *)(iVar6 + 0x24) + 1;
        }
        puVar1 = (uint32_t *)(iVar6 + 0x68);
        *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar5) = uVar4;
        *(uint32_t *)(iVar6 + 0x20) = uVar9;
        pauVar2 = (undefined (*) [16])(iVar6 + 0x28);
        *(int32_t *)(iVar6 + 0x24) = *(int32_t *)(iVar6 + 0x24) + (int32_t)(in_R8 >> 0x1d);
        uVar8 = (uint64_t)*puVar1;
        if (uVar8 != 0) {
            if ((in_R8 < 0x40) && (uVar8 + in_R8 < 0x40)) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5 + -0x10) = 0x180277531;
                func_0x000180498030(*pauVar2 + uVar8, in_RDX);
                *puVar1 = *puVar1 + (int32_t)in_R8;
                return 1;
            }
            iVar10 = 0x40 - uVar8;
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5 + -0x10) = 0x180277553;
            func_0x000180498030(*pauVar2 + uVar8, in_RDX, iVar10);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5 + -0x10) = 0x180277564;
            func_0x000180277bf0(iVar6, pauVar2, 1);
            *puVar1 = 0;
            *pauVar2 = ZEXT816(0);
            in_RDX = in_RDX + iVar10;
            *(undefined (*) [16])(iVar6 + 0x38) = ZEXT816(0);
            in_R8 = in_R8 - iVar10;
            *(undefined (*) [16])(iVar6 + 0x48) = ZEXT816(0);
            *(undefined (*) [16])(iVar6 + 0x58) = ZEXT816(0);
        }
        if (in_R8 >> 6 != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5 + -0x10) = 0x1802775a0;
            func_0x000180277bf0(iVar6, in_RDX, in_R8 >> 6);
            in_RDX = in_RDX + (in_R8 & 0xffffffffffffffc0);
            in_R8 = in_R8 - (in_R8 & 0xffffffffffffffc0);
        }
        if (in_R8 != 0) {
            *(int32_t *)(iVar6 + 0x68) = (int32_t)in_R8;
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5 + -0x10) = 0x1802775c2;
            func_0x000180498030(pauVar2, in_RDX, in_R8);
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18020e4d0
// Address: 0x18020e4d0
// Size: 39 bytes
// ============================================================
undefined8
fcn.18020e4d0(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h,
             int64_t arg_80h, int64_t arg_88h)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    undefined *in_RDX;
    undefined8 uVar7;
    uint32_t uVar8;
    undefined8 unaff_RBP;
    uint64_t uVar9;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar10;
    undefined8 unaff_R14;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020e4dc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020e4e7;
    puVar5 = (undefined4 *)fcn.1801dd170();
    uVar7 = *(undefined8 *)((int64_t)auStackX_18 + iVar4);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x18027743a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar3 = iVar6 + iVar4 + 0x18;
    *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar4) = uVar7;
    *(undefined8 *)((int64_t)&arg_58h + iVar6 + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_60h + iVar6 + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_68h + iVar6 + iVar4) = unaff_RDI;
    *(undefined8 *)(&stack0x00000040 + iVar6 + iVar4 + 0x18 + -0x18) = unaff_R14;
    *(undefined8 *)(&stack0x00000038 + iVar6 + iVar4) = 0x180277610;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    puVar1 = puVar5 + 10;
    uVar9 = 0;
    uVar10 = (uint64_t)(uint32_t)puVar5[0x1a] + 1;
    *(undefined *)((uint64_t)(uint32_t)puVar5[0x1a] + (int64_t)puVar1) = 0x80;
    if (0x38 < uVar10) {
        *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + -0x18) = 0x180277645;
        fcn.1804986e0(uVar10 + (int64_t)puVar1, 0, 0x40 - uVar10);
        *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + -0x18) = 0x180277658;
        func_0x000180277bf0(puVar5, puVar1, 1);
        uVar10 = uVar9;
    }
    *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + -0x18) = 0x18027766c;
    fcn.1804986e0(uVar10 + (int64_t)puVar1, 0, 0x38 - uVar10);
    *(undefined *)(puVar5 + 0x18) = *(undefined *)((int64_t)puVar5 + 0x27);
    *(undefined *)((int64_t)puVar5 + 0x61) = *(undefined *)((int64_t)puVar5 + 0x26);
    *(undefined *)((int64_t)puVar5 + 0x62) = *(undefined *)((int64_t)puVar5 + 0x25);
    *(undefined *)((int64_t)puVar5 + 99) = *(undefined *)(puVar5 + 9);
    *(undefined *)(puVar5 + 0x19) = *(undefined *)((int64_t)puVar5 + 0x23);
    *(undefined *)((int64_t)puVar5 + 0x65) = *(undefined *)((int64_t)puVar5 + 0x22);
    *(undefined *)((int64_t)puVar5 + 0x66) = *(undefined *)((int64_t)puVar5 + 0x21);
    *(undefined *)((int64_t)puVar5 + 0x67) = *(undefined *)(puVar5 + 8);
    *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + -0x18) = 0x1802776bd;
    func_0x000180277bf0(puVar5, puVar1, 1);
    puVar5[0x1a] = 0;
    *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + -0x18) = 0x1802776cd;
    fcn.180244fc0(puVar1, 0x40);
    uVar8 = puVar5[0x1b];
    if (uVar8 == 0x18) {
        uVar2 = *puVar5;
        *in_RDX = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[3] = (char)uVar2;
        in_RDX[1] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[2] = (char)((uint32_t)uVar2 >> 8);
        uVar2 = puVar5[1];
        in_RDX[4] = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[5] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[6] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[7] = (char)uVar2;
        uVar2 = puVar5[2];
        in_RDX[8] = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[9] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[10] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[0xb] = (char)uVar2;
        uVar2 = puVar5[3];
        in_RDX[0xc] = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[0xd] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[0xe] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[0xf] = (char)uVar2;
        uVar2 = puVar5[4];
        in_RDX[0x10] = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[0x11] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[0x12] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[0x13] = (char)uVar2;
        uVar2 = puVar5[5];
        in_RDX[0x14] = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[0x15] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[0x16] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[0x17] = (char)uVar2;
    } else if (uVar8 == 0x1c) {
        uVar2 = *puVar5;
        *in_RDX = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[1] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[2] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[3] = (char)uVar2;
        uVar2 = puVar5[1];
        in_RDX[4] = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[5] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[6] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[7] = (char)uVar2;
        uVar2 = puVar5[2];
        in_RDX[8] = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[9] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[10] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[0xb] = (char)uVar2;
        uVar2 = puVar5[3];
        in_RDX[0xc] = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[0xd] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[0xe] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[0xf] = (char)uVar2;
        uVar2 = puVar5[4];
        in_RDX[0x10] = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[0x11] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[0x12] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[0x13] = (char)uVar2;
        uVar2 = puVar5[5];
        in_RDX[0x14] = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[0x15] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[0x16] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[0x17] = (char)uVar2;
        uVar2 = puVar5[6];
        in_RDX[0x18] = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[0x19] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[0x1a] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[0x1b] = (char)uVar2;
    } else if (uVar8 == 0x20) {
        uVar2 = *puVar5;
        *in_RDX = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[1] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[2] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[3] = (char)uVar2;
        uVar2 = puVar5[1];
        in_RDX[4] = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[5] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[6] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[7] = (char)uVar2;
        uVar2 = puVar5[2];
        in_RDX[8] = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[9] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[10] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[0xb] = (char)uVar2;
        uVar2 = puVar5[3];
        in_RDX[0xc] = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[0xd] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[0xe] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[0xf] = (char)uVar2;
        uVar2 = puVar5[4];
        in_RDX[0x10] = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[0x11] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[0x12] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[0x13] = (char)uVar2;
        uVar2 = puVar5[5];
        in_RDX[0x14] = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[0x15] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[0x16] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[0x17] = (char)uVar2;
        uVar2 = puVar5[6];
        in_RDX[0x18] = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[0x19] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[0x1a] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[0x1b] = (char)uVar2;
        uVar2 = puVar5[7];
        in_RDX[0x1c] = (char)((uint32_t)uVar2 >> 0x18);
        in_RDX[0x1d] = (char)((uint32_t)uVar2 >> 0x10);
        in_RDX[0x1e] = (char)((uint32_t)uVar2 >> 8);
        in_RDX[0x1f] = (char)uVar2;
    } else {
        if (0x20 < uVar8) {
            return 0;
        }
        if ((uVar8 & 0xfffffffc) != 0) {
            do {
                uVar8 = (int32_t)uVar9 + 1;
                uVar2 = puVar5[uVar9];
                *in_RDX = (char)((uint32_t)uVar2 >> 0x18);
                in_RDX[1] = (char)((uint32_t)uVar2 >> 0x10);
                in_RDX[2] = (char)((uint32_t)uVar2 >> 8);
                in_RDX[3] = (char)uVar2;
                in_RDX = in_RDX + 4;
                uVar9 = (uint64_t)uVar8;
            } while (uVar8 < (uint32_t)puVar5[0x1b] >> 2);
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18020e500
// Address: 0x18020e500
// Size: 30 bytes
// ============================================================
undefined8 fcn.18020e500(void)
{
    int64_t iVar1;
    undefined4 *puVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020e50a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x18020e512;
    puVar2 = (undefined4 *)fcn.1801dd170();
    *(undefined (*) [16])(puVar2 + 8) = ZEXT816(0);
    *(undefined (*) [16])(puVar2 + 0xc) = ZEXT816(0);
    *(undefined (*) [16])(puVar2 + 0x10) = ZEXT816(0);
    *(undefined (*) [16])(puVar2 + 0x14) = ZEXT816(0);
    *(undefined8 *)(puVar2 + 0x18) = 0;
    puVar2[0x1a] = 0;
    *puVar2 = 0x6a09e667;
    puVar2[1] = 0xbb67ae85;
    puVar2[2] = 0x3c6ef372;
    puVar2[3] = 0xa54ff53a;
    puVar2[4] = 0x510e527f;
    puVar2[5] = 0x9b05688c;
    puVar2[6] = 0x1f83d9ab;
    puVar2[7] = 0x5be0cd19;
    puVar2[0x1b] = 0x20;
    return 1;
}

// ============================================================
// Function: FUN_18020e520
// Address: 0x18020e520
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.18020e520(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_70h)
{
    uint32_t *puVar1;
    undefined (*pauVar2) [16];
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t in_RDX;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar9;
    uint64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020e530;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020e53e;
    iVar4 = fcn.1801dd170();
    uVar9 = *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = *(undefined8 *)((int64_t)&arg_28h + iVar3);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = uVar9;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8) = unaff_R12;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + -8) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + -0x10) = 0x180277a74;
    iVar5 = fcn.18045a350(iVar4, in_RDX);
    iVar5 = -iVar5;
    if (in_R8 != 0) {
        uVar6 = *(uint32_t *)(iVar4 + 0x20) + (int32_t)in_R8 * 8;
        if (uVar6 < *(uint32_t *)(iVar4 + 0x20)) {
            *(int32_t *)(iVar4 + 0x24) = *(int32_t *)(iVar4 + 0x24) + 1;
        }
        puVar1 = (uint32_t *)(iVar4 + 0x68);
        *(uint32_t *)(iVar4 + 0x20) = uVar6;
        uVar7 = (uint64_t)*puVar1;
        pauVar2 = (undefined (*) [16])(iVar4 + 0x28);
        *(int32_t *)(iVar4 + 0x24) = *(int32_t *)(iVar4 + 0x24) + (int32_t)(in_R8 >> 0x1d);
        if (uVar7 != 0) {
            if ((in_R8 < 0x40) && (uVar7 + in_R8 < 0x40)) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x180277ad2;
                func_0x000180498030(*pauVar2 + uVar7, in_RDX);
                *puVar1 = *puVar1 + (int32_t)in_R8;
                return 1;
            }
            iVar8 = 0x40 - uVar7;
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x180277af4;
            func_0x000180498030(*pauVar2 + uVar7, in_RDX, iVar8);
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x180277b05;
            func_0x000180277bf0(iVar4, pauVar2, 1);
            *puVar1 = 0;
            *pauVar2 = ZEXT816(0);
            in_RDX = in_RDX + iVar8;
            *(undefined (*) [16])(iVar4 + 0x38) = ZEXT816(0);
            in_R8 = in_R8 - iVar8;
            *(undefined (*) [16])(iVar4 + 0x48) = ZEXT816(0);
            *(undefined (*) [16])(iVar4 + 0x58) = ZEXT816(0);
        }
        if (in_R8 >> 6 != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x180277b41;
            func_0x000180277bf0(iVar4, in_RDX, in_R8 >> 6);
            in_RDX = in_RDX + (in_R8 & 0xffffffffffffffc0);
            in_R8 = in_R8 - (in_R8 & 0xffffffffffffffc0);
        }
        if (in_R8 != 0) {
            *(int32_t *)(iVar4 + 0x68) = (int32_t)in_R8;
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3 + -0x10) = 0x180277b63;
            func_0x000180498030(pauVar2, in_RDX, in_R8);
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18020e560
// Address: 0x18020e560
// Size: 39 bytes
// ============================================================
undefined8 fcn.18020e560(undefined8 param_1, undefined *param_2)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    uint32_t uVar6;
    undefined8 unaff_RBP;
    uint64_t uVar7;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar8;
    undefined8 unaff_R14;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020e56c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020e577;
    puVar4 = (undefined4 *)fcn.1801dd170();
    *(undefined8 *)(&stack0x00000028 + iVar3) = *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8);
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_RSI;
    *(undefined8 *)(&stack0x00000040 + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_10 + iVar3) = 0x180277610;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar1 = puVar4 + 10;
    uVar7 = 0;
    uVar8 = (uint64_t)(uint32_t)puVar4[0x1a] + 1;
    *(undefined *)((uint64_t)(uint32_t)puVar4[0x1a] + (int64_t)puVar1) = 0x80;
    if (0x38 < uVar8) {
        *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3) = 0x180277645;
        fcn.1804986e0(uVar8 + (int64_t)puVar1, 0, 0x40 - uVar8);
        *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3) = 0x180277658;
        func_0x000180277bf0(puVar4, puVar1, 1);
        uVar8 = uVar7;
    }
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3) = 0x18027766c;
    fcn.1804986e0(uVar8 + (int64_t)puVar1, 0, 0x38 - uVar8);
    *(undefined *)(puVar4 + 0x18) = *(undefined *)((int64_t)puVar4 + 0x27);
    *(undefined *)((int64_t)puVar4 + 0x61) = *(undefined *)((int64_t)puVar4 + 0x26);
    *(undefined *)((int64_t)puVar4 + 0x62) = *(undefined *)((int64_t)puVar4 + 0x25);
    *(undefined *)((int64_t)puVar4 + 99) = *(undefined *)(puVar4 + 9);
    *(undefined *)(puVar4 + 0x19) = *(undefined *)((int64_t)puVar4 + 0x23);
    *(undefined *)((int64_t)puVar4 + 0x65) = *(undefined *)((int64_t)puVar4 + 0x22);
    *(undefined *)((int64_t)puVar4 + 0x66) = *(undefined *)((int64_t)puVar4 + 0x21);
    *(undefined *)((int64_t)puVar4 + 0x67) = *(undefined *)(puVar4 + 8);
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3) = 0x1802776bd;
    func_0x000180277bf0(puVar4, puVar1, 1);
    puVar4[0x1a] = 0;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar3) = 0x1802776cd;
    fcn.180244fc0(puVar1, 0x40);
    uVar6 = puVar4[0x1b];
    if (uVar6 == 0x18) {
        uVar2 = *puVar4;
        *param_2 = (char)((uint32_t)uVar2 >> 0x18);
        param_2[3] = (char)uVar2;
        param_2[1] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[2] = (char)((uint32_t)uVar2 >> 8);
        uVar2 = puVar4[1];
        param_2[4] = (char)((uint32_t)uVar2 >> 0x18);
        param_2[5] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[6] = (char)((uint32_t)uVar2 >> 8);
        param_2[7] = (char)uVar2;
        uVar2 = puVar4[2];
        param_2[8] = (char)((uint32_t)uVar2 >> 0x18);
        param_2[9] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[10] = (char)((uint32_t)uVar2 >> 8);
        param_2[0xb] = (char)uVar2;
        uVar2 = puVar4[3];
        param_2[0xc] = (char)((uint32_t)uVar2 >> 0x18);
        param_2[0xd] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[0xe] = (char)((uint32_t)uVar2 >> 8);
        param_2[0xf] = (char)uVar2;
        uVar2 = puVar4[4];
        param_2[0x10] = (char)((uint32_t)uVar2 >> 0x18);
        param_2[0x11] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[0x12] = (char)((uint32_t)uVar2 >> 8);
        param_2[0x13] = (char)uVar2;
        uVar2 = puVar4[5];
        param_2[0x14] = (char)((uint32_t)uVar2 >> 0x18);
        param_2[0x15] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[0x16] = (char)((uint32_t)uVar2 >> 8);
        param_2[0x17] = (char)uVar2;
    } else if (uVar6 == 0x1c) {
        uVar2 = *puVar4;
        *param_2 = (char)((uint32_t)uVar2 >> 0x18);
        param_2[1] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[2] = (char)((uint32_t)uVar2 >> 8);
        param_2[3] = (char)uVar2;
        uVar2 = puVar4[1];
        param_2[4] = (char)((uint32_t)uVar2 >> 0x18);
        param_2[5] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[6] = (char)((uint32_t)uVar2 >> 8);
        param_2[7] = (char)uVar2;
        uVar2 = puVar4[2];
        param_2[8] = (char)((uint32_t)uVar2 >> 0x18);
        param_2[9] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[10] = (char)((uint32_t)uVar2 >> 8);
        param_2[0xb] = (char)uVar2;
        uVar2 = puVar4[3];
        param_2[0xc] = (char)((uint32_t)uVar2 >> 0x18);
        param_2[0xd] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[0xe] = (char)((uint32_t)uVar2 >> 8);
        param_2[0xf] = (char)uVar2;
        uVar2 = puVar4[4];
        param_2[0x10] = (char)((uint32_t)uVar2 >> 0x18);
        param_2[0x11] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[0x12] = (char)((uint32_t)uVar2 >> 8);
        param_2[0x13] = (char)uVar2;
        uVar2 = puVar4[5];
        param_2[0x14] = (char)((uint32_t)uVar2 >> 0x18);
        param_2[0x15] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[0x16] = (char)((uint32_t)uVar2 >> 8);
        param_2[0x17] = (char)uVar2;
        uVar2 = puVar4[6];
        param_2[0x18] = (char)((uint32_t)uVar2 >> 0x18);
        param_2[0x19] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[0x1a] = (char)((uint32_t)uVar2 >> 8);
        param_2[0x1b] = (char)uVar2;
    } else if (uVar6 == 0x20) {
        uVar2 = *puVar4;
        *param_2 = (char)((uint32_t)uVar2 >> 0x18);
        param_2[1] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[2] = (char)((uint32_t)uVar2 >> 8);
        param_2[3] = (char)uVar2;
        uVar2 = puVar4[1];
        param_2[4] = (char)((uint32_t)uVar2 >> 0x18);
        param_2[5] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[6] = (char)((uint32_t)uVar2 >> 8);
        param_2[7] = (char)uVar2;
        uVar2 = puVar4[2];
        param_2[8] = (char)((uint32_t)uVar2 >> 0x18);
        param_2[9] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[10] = (char)((uint32_t)uVar2 >> 8);
        param_2[0xb] = (char)uVar2;
        uVar2 = puVar4[3];
        param_2[0xc] = (char)((uint32_t)uVar2 >> 0x18);
        param_2[0xd] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[0xe] = (char)((uint32_t)uVar2 >> 8);
        param_2[0xf] = (char)uVar2;
        uVar2 = puVar4[4];
        param_2[0x10] = (char)((uint32_t)uVar2 >> 0x18);
        param_2[0x11] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[0x12] = (char)((uint32_t)uVar2 >> 8);
        param_2[0x13] = (char)uVar2;
        uVar2 = puVar4[5];
        param_2[0x14] = (char)((uint32_t)uVar2 >> 0x18);
        param_2[0x15] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[0x16] = (char)((uint32_t)uVar2 >> 8);
        param_2[0x17] = (char)uVar2;
        uVar2 = puVar4[6];
        param_2[0x18] = (char)((uint32_t)uVar2 >> 0x18);
        param_2[0x19] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[0x1a] = (char)((uint32_t)uVar2 >> 8);
        param_2[0x1b] = (char)uVar2;
        uVar2 = puVar4[7];
        param_2[0x1c] = (char)((uint32_t)uVar2 >> 0x18);
        param_2[0x1d] = (char)((uint32_t)uVar2 >> 0x10);
        param_2[0x1e] = (char)((uint32_t)uVar2 >> 8);
        param_2[0x1f] = (char)uVar2;
    } else {
        if (0x20 < uVar6) {
            return 0;
        }
        if ((uVar6 & 0xfffffffc) != 0) {
            do {
                uVar6 = (int32_t)uVar7 + 1;
                uVar2 = puVar4[uVar7];
                *param_2 = (char)((uint32_t)uVar2 >> 0x18);
                param_2[1] = (char)((uint32_t)uVar2 >> 0x10);
                param_2[2] = (char)((uint32_t)uVar2 >> 8);
                param_2[3] = (char)uVar2;
                param_2 = param_2 + 4;
                uVar7 = (uint64_t)uVar6;
            } while (uVar6 < (uint32_t)puVar4[0x1b] >> 2);
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18020e590
// Address: 0x18020e590
// Size: 30 bytes
// ============================================================
undefined8 fcn.18020e590(void)
{
    int64_t iVar1;
    undefined8 *puVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020e59a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x18020e5a2;
    puVar2 = (undefined8 *)fcn.1801dd170();
    *(undefined4 *)((int64_t)puVar2 + 0xd4) = 0x30;
    *puVar2 = 0xcbbb9d5dc1059ed8;
    puVar2[1] = 0x629a292a367cd507;
    puVar2[2] = 0x9159015a3070dd17;
    puVar2[3] = 0x152fecd8f70e5939;
    puVar2[4] = 0x67332667ffc00b31;
    puVar2[5] = 0x8eb44a8768581511;
    puVar2[6] = 0xdb0c2e0d64f98fa7;
    puVar2[7] = 0x47b5481dbefa4fa4;
    puVar2[8] = 0;
    puVar2[9] = 0;
    *(undefined4 *)(puVar2 + 0x1a) = 0;
    return 1;
}

// ============================================================
// Function: FUN_18020e5b0
// Address: 0x18020e5b0
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.18020e5b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar7;
    uint64_t in_R8;
    undefined8 unaff_R14;
    uint64_t uVar8;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020e5c0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020e5ce;
    iVar5 = fcn.1801dd170();
    uVar7 = *(undefined8 *)((int64_t)auStackX_10 + iVar4 + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4 + 8) = uVar7;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4) = 0x180278dca;
    iVar6 = fcn.18045a350(iVar5, in_RDX);
    iVar6 = -iVar6;
    iVar1 = iVar5 + 0x50;
    if (in_R8 != 0) {
        uVar8 = *(uint64_t *)(iVar5 + 0x40) + in_R8 * 8;
        if (uVar8 < *(uint64_t *)(iVar5 + 0x40)) {
            *(int64_t *)(iVar5 + 0x48) = *(int64_t *)(iVar5 + 0x48) + 1;
        }
        *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar4) = unaff_R14;
        *(int64_t *)(iVar5 + 0x48) = *(int64_t *)(iVar5 + 0x48) + (in_R8 >> 0x3d);
        uVar3 = *(uint32_t *)(iVar5 + 0xd0);
        *(uint64_t *)(iVar5 + 0x40) = uVar8;
        if (uVar3 != 0) {
            iVar2 = (uint64_t)uVar3 + iVar1;
            uVar8 = 0x80 - (uint64_t)uVar3;
            if (in_R8 < uVar8) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x180278e2c;
                func_0x000180498030(iVar2, in_RDX);
                *(int32_t *)(iVar5 + 0xd0) = *(int32_t *)(iVar5 + 0xd0) + (int32_t)in_R8;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x180278e3c;
            func_0x000180498030(iVar2, in_RDX, uVar8);
            *(undefined4 *)(iVar5 + 0xd0) = 0;
            in_R8 = in_R8 - uVar8;
            in_RDX = in_RDX + uVar8;
            *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x180278e5d;
            func_0x0001802799a0(iVar5, iVar1, 1);
        }
        if (0x7f < in_R8) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x180278e78;
            func_0x0001802799a0(iVar5, in_RDX, in_R8 >> 7);
            in_RDX = in_RDX + in_R8;
            in_R8 = (uint64_t)((uint32_t)in_R8 & 0x7f);
            in_RDX = in_RDX - in_R8;
        }
        if (in_R8 != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x180278e94;
            func_0x000180498030(iVar1, in_RDX, in_R8);
            *(int32_t *)(iVar5 + 0xd0) = (int32_t)in_R8;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18020e5f0
// Address: 0x18020e5f0
// Size: 39 bytes
// ============================================================
undefined8
fcn.18020e5f0(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h)
{
    undefined8 *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined *in_RDX;
    undefined8 uVar7;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    uint64_t uVar8;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020e5fc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020e607;
    puVar5 = (undefined8 *)fcn.1801dd170();
    uVar7 = *(undefined8 *)((int64_t)auStackX_18 + iVar4);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x180278d0a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar3 = iVar6 + iVar4 + 0x18;
    *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar4) = uVar7;
    *(undefined8 *)((int64_t)&arg_58h + iVar6 + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_60h + iVar6 + iVar4) = unaff_RDI;
    *(undefined8 *)(&stack0x00000040 + iVar6 + iVar4 + 0x18 + -0x18) = unaff_R14;
    *(undefined8 *)(&stack0x00000038 + iVar6 + iVar4) = 0x180278edb;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    puVar1 = puVar5 + 10;
    uVar8 = (uint64_t)*(uint32_t *)(puVar5 + 0x1a) + 1;
    *(undefined *)((uint64_t)*(uint32_t *)(puVar5 + 0x1a) + (int64_t)puVar1) = 0x80;
    if (0x70 < uVar8) {
        *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + -0x18) = 0x180278f10;
        fcn.1804986e0(uVar8 + (int64_t)puVar1, 0, 0x80 - uVar8);
        uVar8 = 0;
        *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + -0x18) = 0x180278f24;
        func_0x0001802799a0(puVar5, puVar1, 1);
    }
    *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + -0x18) = 0x180278f38;
    fcn.1804986e0(uVar8 + (int64_t)puVar1, 0, 0x70 - uVar8);
    *(undefined *)((int64_t)puVar5 + 0xcf) = *(undefined *)(puVar5 + 8);
    *(char *)((int64_t)puVar5 + 0xce) = (char)((uint32_t)*(undefined4 *)(puVar5 + 8) >> 8);
    *(char *)((int64_t)puVar5 + 0xcd) = (char)((uint32_t)*(undefined4 *)(puVar5 + 8) >> 0x10);
    *(char *)((int64_t)puVar5 + 0xcc) = (char)((uint32_t)*(undefined4 *)(puVar5 + 8) >> 0x18);
    *(char *)((int64_t)puVar5 + 0xcb) = (char)((uint64_t)puVar5[8] >> 0x20);
    *(char *)((int64_t)puVar5 + 0xca) = (char)((uint64_t)puVar5[8] >> 0x28);
    *(undefined *)((int64_t)puVar5 + 0xc9) = *(undefined *)((int64_t)puVar5 + 0x46);
    *(undefined *)(puVar5 + 0x19) = *(undefined *)((int64_t)puVar5 + 0x47);
    *(undefined *)((int64_t)puVar5 + 199) = *(undefined *)(puVar5 + 9);
    *(char *)((int64_t)puVar5 + 0xc6) = (char)((uint32_t)*(undefined4 *)(puVar5 + 9) >> 8);
    *(char *)((int64_t)puVar5 + 0xc5) = (char)((uint32_t)*(undefined4 *)(puVar5 + 9) >> 0x10);
    *(char *)((int64_t)puVar5 + 0xc4) = (char)((uint32_t)*(undefined4 *)(puVar5 + 9) >> 0x18);
    *(char *)((int64_t)puVar5 + 0xc3) = (char)((uint64_t)puVar5[9] >> 0x20);
    *(char *)((int64_t)puVar5 + 0xc2) = (char)((uint64_t)puVar5[9] >> 0x28);
    *(undefined *)((int64_t)puVar5 + 0xc1) = *(undefined *)((int64_t)puVar5 + 0x4e);
    *(undefined *)(puVar5 + 0x18) = *(undefined *)((int64_t)puVar5 + 0x4f);
    *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + -0x18) = 0x180278fdb;
    func_0x0001802799a0(puVar5, puVar1, 1);
    if (in_RDX != (undefined *)0x0) {
        iVar2 = *(int32_t *)((int64_t)puVar5 + 0xd4);
        if (iVar2 == 0x1c) {
            uVar7 = *puVar5;
            *in_RDX = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[1] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[2] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[3] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[4] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[5] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[6] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[7] = (char)uVar7;
            uVar7 = puVar5[1];
            in_RDX[8] = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[9] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[10] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[0xb] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[0xc] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[0xd] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[0xe] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[0xf] = (char)uVar7;
            uVar7 = puVar5[2];
            in_RDX[0x10] = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[0x11] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[0x12] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[0x13] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[0x14] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[0x15] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[0x16] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[0x17] = (char)uVar7;
            uVar7 = puVar5[3];
            in_RDX[0x18] = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[0x19] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[0x1b] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[0x1a] = (char)((uint64_t)uVar7 >> 0x28);
            return 1;
        }
        if (iVar2 == 0x20) {
            uVar7 = *puVar5;
            *in_RDX = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[1] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[2] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[3] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[4] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[5] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[6] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[7] = (char)uVar7;
            uVar7 = puVar5[1];
            in_RDX[8] = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[9] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[10] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[0xb] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[0xc] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[0xd] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[0xe] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[0xf] = (char)uVar7;
            uVar7 = puVar5[2];
            in_RDX[0x10] = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[0x11] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[0x12] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[0x13] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[0x14] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[0x15] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[0x16] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[0x17] = (char)uVar7;
            uVar7 = puVar5[3];
            in_RDX[0x18] = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[0x19] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[0x1a] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[0x1b] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[0x1c] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[0x1d] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[0x1e] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[0x1f] = (char)uVar7;
            return 1;
        }
        if (iVar2 == 0x30) {
            uVar7 = *puVar5;
            *in_RDX = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[1] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[2] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[3] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[4] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[5] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[6] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[7] = (char)uVar7;
            uVar7 = puVar5[1];
            in_RDX[8] = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[9] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[10] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[0xb] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[0xc] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[0xd] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[0xe] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[0xf] = (char)uVar7;
            uVar7 = puVar5[2];
            in_RDX[0x10] = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[0x11] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[0x12] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[0x13] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[0x14] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[0x15] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[0x16] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[0x17] = (char)uVar7;
            uVar7 = puVar5[3];
            in_RDX[0x18] = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[0x19] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[0x1a] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[0x1b] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[0x1c] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[0x1d] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[0x1e] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[0x1f] = (char)uVar7;
            uVar7 = puVar5[4];
            in_RDX[0x20] = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[0x21] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[0x22] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[0x23] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[0x24] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[0x25] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[0x26] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[0x27] = (char)uVar7;
            uVar7 = puVar5[5];
            in_RDX[0x28] = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[0x29] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[0x2a] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[0x2b] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[0x2c] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[0x2d] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[0x2e] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[0x2f] = (char)uVar7;
            return 1;
        }
        if (iVar2 == 0x40) {
            uVar7 = *puVar5;
            *in_RDX = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[1] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[2] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[3] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[4] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[5] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[6] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[7] = (char)uVar7;
            uVar7 = puVar5[1];
            in_RDX[8] = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[9] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[10] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[0xb] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[0xc] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[0xd] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[0xe] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[0xf] = (char)uVar7;
            uVar7 = puVar5[2];
            in_RDX[0x10] = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[0x11] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[0x12] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[0x13] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[0x14] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[0x15] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[0x16] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[0x17] = (char)uVar7;
            uVar7 = puVar5[3];
            in_RDX[0x18] = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[0x19] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[0x1a] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[0x1b] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[0x1c] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[0x1d] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[0x1e] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[0x1f] = (char)uVar7;
            uVar7 = puVar5[4];
            in_RDX[0x20] = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[0x21] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[0x22] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[0x23] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[0x24] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[0x25] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[0x26] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[0x27] = (char)uVar7;
            uVar7 = puVar5[5];
            in_RDX[0x28] = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[0x29] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[0x2a] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[0x2b] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[0x2c] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[0x2d] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[0x2e] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[0x2f] = (char)uVar7;
            uVar7 = puVar5[6];
            in_RDX[0x30] = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[0x31] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[0x32] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[0x33] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[0x34] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[0x35] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[0x36] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[0x37] = (char)uVar7;
            uVar7 = puVar5[7];
            in_RDX[0x38] = (char)((uint64_t)uVar7 >> 0x38);
            in_RDX[0x39] = (char)((uint64_t)uVar7 >> 0x30);
            in_RDX[0x3a] = (char)((uint64_t)uVar7 >> 0x28);
            in_RDX[0x3b] = (char)((uint64_t)uVar7 >> 0x20);
            in_RDX[0x3c] = (char)((uint64_t)uVar7 >> 0x18);
            in_RDX[0x3d] = (char)((uint64_t)uVar7 >> 0x10);
            in_RDX[0x3e] = (char)((uint64_t)uVar7 >> 8);
            in_RDX[0x3f] = (char)uVar7;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18020e620
// Address: 0x18020e620
// Size: 30 bytes
// ============================================================
undefined8 fcn.18020e620(void)
{
    int64_t iVar1;
    undefined8 *puVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020e62a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x18020e632;
    puVar2 = (undefined8 *)fcn.1801dd170();
    *(undefined4 *)((int64_t)puVar2 + 0xd4) = 0x40;
    *puVar2 = 0x6a09e667f3bcc908;
    puVar2[1] = 0xbb67ae8584caa73b;
    puVar2[2] = 0x3c6ef372fe94f82b;
    puVar2[3] = 0xa54ff53a5f1d36f1;
    puVar2[4] = 0x510e527fade682d1;
    puVar2[5] = 0x9b05688c2b3e6c1f;
    puVar2[6] = 0x1f83d9abfb41bd6b;
    puVar2[7] = 0x5be0cd19137e2179;
    puVar2[8] = 0;
    puVar2[9] = 0;
    *(undefined4 *)(puVar2 + 0x1a) = 0;
    return 1;
}

// ============================================================
// Function: FUN_18020e640
// Address: 0x18020e640
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.18020e640(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar7;
    uint64_t in_R8;
    undefined8 unaff_R14;
    uint64_t uVar8;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020e650;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020e65e;
    iVar5 = fcn.1801dd170();
    uVar7 = *(undefined8 *)((int64_t)auStackX_10 + iVar4 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = uVar7;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4) = 0x180279790;
    iVar6 = fcn.18045a350(iVar5, in_RDX);
    iVar6 = -iVar6;
    iVar1 = iVar5 + 0x50;
    if (in_R8 != 0) {
        uVar8 = *(uint64_t *)(iVar5 + 0x40) + in_R8 * 8;
        if (uVar8 < *(uint64_t *)(iVar5 + 0x40)) {
            *(int64_t *)(iVar5 + 0x48) = *(int64_t *)(iVar5 + 0x48) + 1;
        }
        *(uint64_t *)(iVar5 + 0x40) = uVar8;
        *(int64_t *)(iVar5 + 0x48) = *(int64_t *)(iVar5 + 0x48) + (in_R8 >> 0x3d);
        uVar3 = *(uint32_t *)(iVar5 + 0xd0);
        if (uVar3 != 0) {
            iVar2 = (uint64_t)uVar3 + iVar1;
            uVar8 = 0x80 - (uint64_t)uVar3;
            if (in_R8 < uVar8) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x1802797ed;
                func_0x000180498030(iVar2, in_RDX);
                *(int32_t *)(iVar5 + 0xd0) = *(int32_t *)(iVar5 + 0xd0) + (int32_t)in_R8;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x1802797fd;
            func_0x000180498030(iVar2, in_RDX, uVar8);
            *(undefined4 *)(iVar5 + 0xd0) = 0;
            in_R8 = in_R8 - uVar8;
            in_RDX = in_RDX + uVar8;
            *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x18027981e;
            func_0x0001802799a0(iVar5, iVar1, 1);
        }
        if (0x7f < in_R8) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x180279839;
            func_0x0001802799a0(iVar5, in_RDX, in_R8 >> 7);
            in_RDX = in_RDX + in_R8;
            in_R8 = (uint64_t)((uint32_t)in_R8 & 0x7f);
            in_RDX = in_RDX - in_R8;
        }
        if (in_R8 != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x180279855;
            func_0x000180498030(iVar1, in_RDX, in_R8);
            *(int32_t *)(iVar5 + 0xd0) = (int32_t)in_R8;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18020e680
// Address: 0x18020e680
// Size: 39 bytes
// ============================================================
undefined8 fcn.18020e680(undefined8 param_1, undefined *param_2)
{
    undefined8 *puVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    uint64_t uVar7;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020e68c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18020e697;
    puVar5 = (undefined8 *)fcn.1801dd170();
    *(undefined8 *)(&stack0x00000028 + iVar4) = *(undefined8 *)((int64_t)auStackX_10 + iVar4 + 8);
    *(undefined8 *)(&stack0x00000030 + iVar4) = unaff_RSI;
    *(undefined8 *)(&stack0x00000038 + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4) = 0x180278edb;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    puVar1 = puVar5 + 10;
    uVar7 = (uint64_t)*(uint32_t *)(puVar5 + 0x1a) + 1;
    *(undefined *)((uint64_t)*(uint32_t *)(puVar5 + 0x1a) + (int64_t)puVar1) = 0x80;
    if (0x70 < uVar7) {
        *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x180278f10;
        fcn.1804986e0(uVar7 + (int64_t)puVar1, 0, 0x80 - uVar7);
        uVar7 = 0;
        *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x180278f24;
        func_0x0001802799a0(puVar5, puVar1, 1);
    }
    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x180278f38;
    fcn.1804986e0(uVar7 + (int64_t)puVar1, 0, 0x70 - uVar7);
    *(undefined *)((int64_t)puVar5 + 0xcf) = *(undefined *)(puVar5 + 8);
    *(char *)((int64_t)puVar5 + 0xce) = (char)((uint32_t)*(undefined4 *)(puVar5 + 8) >> 8);
    *(char *)((int64_t)puVar5 + 0xcd) = (char)((uint32_t)*(undefined4 *)(puVar5 + 8) >> 0x10);
    *(char *)((int64_t)puVar5 + 0xcc) = (char)((uint32_t)*(undefined4 *)(puVar5 + 8) >> 0x18);
    *(char *)((int64_t)puVar5 + 0xcb) = (char)((uint64_t)puVar5[8] >> 0x20);
    *(char *)((int64_t)puVar5 + 0xca) = (char)((uint64_t)puVar5[8] >> 0x28);
    *(undefined *)((int64_t)puVar5 + 0xc9) = *(undefined *)((int64_t)puVar5 + 0x46);
    *(undefined *)(puVar5 + 0x19) = *(undefined *)((int64_t)puVar5 + 0x47);
    *(undefined *)((int64_t)puVar5 + 199) = *(undefined *)(puVar5 + 9);
    *(char *)((int64_t)puVar5 + 0xc6) = (char)((uint32_t)*(undefined4 *)(puVar5 + 9) >> 8);
    *(char *)((int64_t)puVar5 + 0xc5) = (char)((uint32_t)*(undefined4 *)(puVar5 + 9) >> 0x10);
    *(char *)((int64_t)puVar5 + 0xc4) = (char)((uint32_t)*(undefined4 *)(puVar5 + 9) >> 0x18);
    *(char *)((int64_t)puVar5 + 0xc3) = (char)((uint64_t)puVar5[9] >> 0x20);
    *(char *)((int64_t)puVar5 + 0xc2) = (char)((uint64_t)puVar5[9] >> 0x28);
    *(undefined *)((int64_t)puVar5 + 0xc1) = *(undefined *)((int64_t)puVar5 + 0x4e);
    *(undefined *)(puVar5 + 0x18) = *(undefined *)((int64_t)puVar5 + 0x4f);
    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar4) = 0x180278fdb;
    func_0x0001802799a0(puVar5, puVar1, 1);
    if (param_2 != (undefined *)0x0) {
        iVar2 = *(int32_t *)((int64_t)puVar5 + 0xd4);
        if (iVar2 == 0x1c) {
            uVar3 = *puVar5;
            *param_2 = (char)((uint64_t)uVar3 >> 0x38);
            param_2[1] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[2] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[3] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[4] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[5] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[6] = (char)((uint64_t)uVar3 >> 8);
            param_2[7] = (char)uVar3;
            uVar3 = puVar5[1];
            param_2[8] = (char)((uint64_t)uVar3 >> 0x38);
            param_2[9] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[10] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[0xb] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[0xc] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[0xd] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[0xe] = (char)((uint64_t)uVar3 >> 8);
            param_2[0xf] = (char)uVar3;
            uVar3 = puVar5[2];
            param_2[0x10] = (char)((uint64_t)uVar3 >> 0x38);
            param_2[0x11] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[0x12] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[0x13] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[0x14] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[0x15] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[0x16] = (char)((uint64_t)uVar3 >> 8);
            param_2[0x17] = (char)uVar3;
            uVar3 = puVar5[3];
            param_2[0x18] = (char)((uint64_t)uVar3 >> 0x38);
            param_2[0x19] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[0x1b] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[0x1a] = (char)((uint64_t)uVar3 >> 0x28);
            return 1;
        }
        if (iVar2 == 0x20) {
            uVar3 = *puVar5;
            *param_2 = (char)((uint64_t)uVar3 >> 0x38);
            param_2[1] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[2] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[3] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[4] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[5] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[6] = (char)((uint64_t)uVar3 >> 8);
            param_2[7] = (char)uVar3;
            uVar3 = puVar5[1];
            param_2[8] = (char)((uint64_t)uVar3 >> 0x38);
            param_2[9] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[10] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[0xb] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[0xc] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[0xd] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[0xe] = (char)((uint64_t)uVar3 >> 8);
            param_2[0xf] = (char)uVar3;
            uVar3 = puVar5[2];
            param_2[0x10] = (char)((uint64_t)uVar3 >> 0x38);
            param_2[0x11] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[0x12] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[0x13] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[0x14] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[0x15] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[0x16] = (char)((uint64_t)uVar3 >> 8);
            param_2[0x17] = (char)uVar3;
            uVar3 = puVar5[3];
            param_2[0x18] = (char)((uint64_t)uVar3 >> 0x38);
            param_2[0x19] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[0x1a] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[0x1b] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[0x1c] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[0x1d] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[0x1e] = (char)((uint64_t)uVar3 >> 8);
            param_2[0x1f] = (char)uVar3;
            return 1;
        }
        if (iVar2 == 0x30) {
            uVar3 = *puVar5;
            *param_2 = (char)((uint64_t)uVar3 >> 0x38);
            param_2[1] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[2] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[3] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[4] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[5] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[6] = (char)((uint64_t)uVar3 >> 8);
            param_2[7] = (char)uVar3;
            uVar3 = puVar5[1];
            param_2[8] = (char)((uint64_t)uVar3 >> 0x38);
            param_2[9] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[10] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[0xb] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[0xc] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[0xd] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[0xe] = (char)((uint64_t)uVar3 >> 8);
            param_2[0xf] = (char)uVar3;
            uVar3 = puVar5[2];
            param_2[0x10] = (char)((uint64_t)uVar3 >> 0x38);
            param_2[0x11] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[0x12] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[0x13] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[0x14] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[0x15] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[0x16] = (char)((uint64_t)uVar3 >> 8);
            param_2[0x17] = (char)uVar3;
            uVar3 = puVar5[3];
            param_2[0x18] = (char)((uint64_t)uVar3 >> 0x38);
            param_2[0x19] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[0x1a] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[0x1b] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[0x1c] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[0x1d] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[0x1e] = (char)((uint64_t)uVar3 >> 8);
            param_2[0x1f] = (char)uVar3;
            uVar3 = puVar5[4];
            param_2[0x20] = (char)((uint64_t)uVar3 >> 0x38);
            param_2[0x21] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[0x22] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[0x23] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[0x24] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[0x25] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[0x26] = (char)((uint64_t)uVar3 >> 8);
            param_2[0x27] = (char)uVar3;
            uVar3 = puVar5[5];
            param_2[0x28] = (char)((uint64_t)uVar3 >> 0x38);
            param_2[0x29] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[0x2a] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[0x2b] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[0x2c] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[0x2d] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[0x2e] = (char)((uint64_t)uVar3 >> 8);
            param_2[0x2f] = (char)uVar3;
            return 1;
        }
        if (iVar2 == 0x40) {
            uVar3 = *puVar5;
            *param_2 = (char)((uint64_t)uVar3 >> 0x38);
            param_2[1] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[2] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[3] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[4] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[5] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[6] = (char)((uint64_t)uVar3 >> 8);
            param_2[7] = (char)uVar3;
            uVar3 = puVar5[1];
            param_2[8] = (char)((uint64_t)uVar3 >> 0x38);
            param_2[9] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[10] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[0xb] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[0xc] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[0xd] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[0xe] = (char)((uint64_t)uVar3 >> 8);
            param_2[0xf] = (char)uVar3;
            uVar3 = puVar5[2];
            param_2[0x10] = (char)((uint64_t)uVar3 >> 0x38);
            param_2[0x11] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[0x12] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[0x13] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[0x14] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[0x15] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[0x16] = (char)((uint64_t)uVar3 >> 8);
            param_2[0x17] = (char)uVar3;
            uVar3 = puVar5[3];
            param_2[0x18] = (char)((uint64_t)uVar3 >> 0x38);
            param_2[0x19] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[0x1a] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[0x1b] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[0x1c] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[0x1d] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[0x1e] = (char)((uint64_t)uVar3 >> 8);
            param_2[0x1f] = (char)uVar3;
            uVar3 = puVar5[4];
            param_2[0x20] = (char)((uint64_t)uVar3 >> 0x38);
            param_2[0x21] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[0x22] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[0x23] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[0x24] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[0x25] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[0x26] = (char)((uint64_t)uVar3 >> 8);
            param_2[0x27] = (char)uVar3;
            uVar3 = puVar5[5];
            param_2[0x28] = (char)((uint64_t)uVar3 >> 0x38);
            param_2[0x29] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[0x2a] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[0x2b] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[0x2c] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[0x2d] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[0x2e] = (char)((uint64_t)uVar3 >> 8);
            param_2[0x2f] = (char)uVar3;
            uVar3 = puVar5[6];
            param_2[0x30] = (char)((uint64_t)uVar3 >> 0x38);
            param_2[0x31] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[0x32] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[0x33] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[0x34] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[0x35] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[0x36] = (char)((uint64_t)uVar3 >> 8);
            param_2[0x37] = (char)uVar3;
            uVar3 = puVar5[7];
            param_2[0x38] = (char)((uint64_t)uVar3 >> 0x38);
            param_2[0x39] = (char)((uint64_t)uVar3 >> 0x30);
            param_2[0x3a] = (char)((uint64_t)uVar3 >> 0x28);
            param_2[0x3b] = (char)((uint64_t)uVar3 >> 0x20);
            param_2[0x3c] = (char)((uint64_t)uVar3 >> 0x18);
            param_2[0x3d] = (char)((uint64_t)uVar3 >> 0x10);
            param_2[0x3e] = (char)((uint64_t)uVar3 >> 8);
            param_2[0x3f] = (char)uVar3;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18020e6b0
// Address: 0x18020e6b0
// Size: 30 bytes
// ============================================================
undefined8 fcn.18020e6b0(void)
{
    int64_t iVar1;
    undefined8 *puVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020e6ba;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x18020e6c2;
    puVar2 = (undefined8 *)fcn.1801dd170();
    *(undefined4 *)((int64_t)puVar2 + 0xd4) = 0x1c;
    *puVar2 = 0x8c3d37c819544da2;
    puVar2[1] = 0x73e1996689dcd4d6;
    puVar2[2] = 0x1dfab7ae32ff9c82;
    puVar2[3] = 0x679dd514582f9fcf;
    puVar2[4] = 0xf6d2b697bd44da8;
    puVar2[5] = 0x77e36f7304c48942;
    puVar2[6] = 0x3f9d85a86a1d36c8;
    puVar2[7] = 0x1112e6ad91d692a1;
    puVar2[8] = 0;
    puVar2[9] = 0;
    *(undefined4 *)(puVar2 + 0x1a) = 0;
    return 1;
}

// ============================================================
// Function: FUN_18020e6d0
// Address: 0x18020e6d0
// Size: 30 bytes
// ============================================================
undefined8 fcn.18020e6d0(void)
{
    int64_t iVar1;
    undefined8 *puVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x18020e6da;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x18020e6e2;
    puVar2 = (undefined8 *)fcn.1801dd170();
    *(undefined4 *)((int64_t)puVar2 + 0xd4) = 0x20;
    *puVar2 = 0x22312194fc2bf72c;
    puVar2[1] = 0x9f555fa3c84c64c2;
    puVar2[2] = 0x2393b86b6f53b151;
    puVar2[3] = 0x963877195940eabd;
    puVar2[4] = 0x96283ee2a88effe3;
    puVar2[5] = 0xbe5e1e2553863992;
    puVar2[6] = 0x2b0199fc2c85b8aa;
    puVar2[7] = 0xeb72ddc81c52ca2;
    puVar2[8] = 0;
    puVar2[9] = 0;
    *(undefined4 *)(puVar2 + 0x1a) = 0;
    return 1;
}

// ============================================================
// Function: FUN_18020e6f0
// Address: 0x18020e6f0
// Size: 51 bytes
// ============================================================
bool fcn.18020e6f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined uVar4;
    uint64_t uVar5;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020e6fc;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar5 = (uint64_t)(*(int32_t *)(*(int64_t *)(in_RCX + 8) + 8) << 3);
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020e711;
    iVar2 = fcn.1801dd170();
    uVar4 = 6;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = *(undefined8 *)((int64_t)auStackX_10 + iVar1 + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar1) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar1 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar1) = 0x18027b7da;
    iVar3 = fcn.18045a350();
    uVar6 = 800 - uVar5 >> 2 & 0x1fffffffffffffff;
    if (uVar6 < 0xa9) {
        *(undefined8 *)((int64_t)auStackX_10 + (iVar1 - iVar3)) = 0x18027b815;
        fcn.1804986e0();
        *(uint64_t *)(iVar2 + 0x170) = uVar6;
        *(undefined8 *)(iVar2 + 0x180) = 0;
        *(undefined4 *)(iVar2 + 0x1a8) = 0;
        *(uint64_t *)(iVar2 + 0x178) = uVar5 >> 3;
        *(undefined *)(iVar2 + 0x188) = uVar4;
    }
    return uVar6 < 0xa9;
}

// ============================================================
// Function: FUN_18020e730
// Address: 0x18020e730
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.18020e730(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t in_R8;
    undefined8 unaff_R14;
    uint64_t uVar6;
    int64_t var_8h;
    undefined8 uStackX_10;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020e740;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020e74e;
    iVar3 = fcn.1801dd170();
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = *(undefined8 *)((int64_t)&arg_28h + iVar2);
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RSI;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = *(undefined8 *)((int64_t)&var_18h + iVar2);
    *(undefined8 *)((int64_t)&uStackX_10 + iVar2) = 0x18027ba4a;
    iVar4 = fcn.18045a350(iVar3, in_RDX);
    iVar4 = -iVar4;
    uVar1 = *(uint64_t *)(iVar3 + 0x170);
    if (in_R8 != 0) {
        if ((*(int32_t *)(iVar3 + 0x1a8) == 3) || (*(int32_t *)(iVar3 + 0x1a8) == 2)) {
            return 0;
        }
        iVar5 = *(int64_t *)(iVar3 + 0x180);
        *(undefined8 *)((int64_t)&arg_48h + iVar4 + iVar2) = unaff_R14;
        if (iVar5 != 0) {
            uVar6 = uVar1 - iVar5;
            iVar5 = iVar3 + 200 + iVar5;
            if (in_R8 < uVar6) {
                *(undefined8 *)((int64_t)&uStackX_10 + iVar4 + iVar2) = 0x18027baa5;
                fcn.180498030(iVar5);
                *(int64_t *)(iVar3 + 0x180) = *(int64_t *)(iVar3 + 0x180) + in_R8;
                return 1;
            }
            *(undefined8 *)((int64_t)&uStackX_10 + iVar4 + iVar2) = 0x18027bad3;
            fcn.180498030(iVar5);
            in_RDX = in_RDX + uVar6;
            in_R8 = in_R8 - uVar6;
            *(undefined8 *)((int64_t)&uStackX_10 + iVar4 + iVar2) = 0x18027baf1;
            fcn.1802e22c0(*(int64_t *)(&stack0x000000e8 + iVar4 + iVar2), *(int64_t *)(&stack0x00000108 + iVar4 + iVar2)
                          , *(int64_t *)(&stack0x00000128 + iVar4 + iVar2));
            *(undefined8 *)(iVar3 + 0x180) = 0;
        }
        uVar6 = in_R8;
        if (uVar1 <= in_R8) {
            *(undefined8 *)((int64_t)&uStackX_10 + iVar4 + iVar2) = 0x18027bb1b;
            uVar6 = fcn.1802e22c0(*(int64_t *)(&stack0x000000e8 + iVar4 + iVar2), 
                                  *(int64_t *)(&stack0x00000108 + iVar4 + iVar2), 
                                  *(int64_t *)(&stack0x00000128 + iVar4 + iVar2));
        }
        if (uVar6 != 0) {
            *(undefined8 *)((int64_t)&uStackX_10 + iVar4 + iVar2) = 0x18027bb3a;
            fcn.180498030(iVar3 + 200, in_R8 + (in_RDX - uVar6), uVar6);
            *(uint64_t *)(iVar3 + 0x180) = uVar6;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18020e770
// Address: 0x18020e770
// Size: 46 bytes
// ============================================================
undefined8
fcn.18020e770(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
             int64_t arg_70h)
{
    int64_t iVar1;
    uint8_t *puVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 in_RDX;
    undefined8 uVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar9;
    undefined8 unaff_R14;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020e77c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18020e787;
    iVar6 = fcn.1801dd170();
    iVar9 = *(int64_t *)(iVar6 + 0x178);
    uVar8 = *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5) = 0x18027b6eb;
    iVar7 = fcn.18045a350(iVar6, in_RDX);
    iVar7 = -iVar7;
    iVar3 = *(int64_t *)(iVar6 + 0x170);
    iVar4 = *(int64_t *)(iVar6 + 0x180);
    if (iVar9 == 0) {
        uVar8 = 1;
    } else if ((*(int32_t *)(iVar6 + 0x1a8) == 3) || (*(int32_t *)(iVar6 + 0x1a8) == 2)) {
        uVar8 = 0;
    } else {
        *(undefined8 *)((int64_t)&arg_58h + iVar7 + iVar5) = uVar8;
        iVar1 = iVar4 + iVar6;
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x18027b741;
        fcn.1804986e0(iVar1 + 200, 0, iVar3 - iVar4);
        *(undefined *)(iVar1 + 200) = *(undefined *)(iVar6 + 0x188);
        puVar2 = (uint8_t *)(iVar6 + 199 + iVar3);
        *puVar2 = *puVar2 | 0x80;
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x18027b76b;
        fcn.1802e22c0(*(int64_t *)(&stack0x000000e8 + iVar7 + iVar5), *(int64_t *)(&stack0x00000108 + iVar7 + iVar5), 
                      *(int64_t *)(&stack0x00000128 + iVar7 + iVar5));
        *(undefined4 *)(iVar6 + 0x1a8) = 2;
        *(undefined4 *)((int64_t)&arg_38h + iVar7 + iVar5) = 0;
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x18027b78e;
        func_0x0001802e2410(iVar6, in_RDX, iVar9, iVar3);
        uVar8 = 1;
    }
    return uVar8;
}

// ============================================================
// Function: FUN_18020e7a0
// Address: 0x18020e7a0
// Size: 51 bytes
// ============================================================
bool fcn.18020e7a0(int64_t param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined uVar4;
    uint64_t uVar5;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020e7ac;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar5 = (uint64_t)(*(int32_t *)(*(int64_t *)(param_1 + 8) + 8) << 3);
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020e7c1;
    iVar2 = fcn.1801dd170();
    uVar4 = 0x1f;
    *(undefined8 *)(&stack0x00000028 + iVar1) = *(undefined8 *)((int64_t)auStackX_10 + iVar1 + 8);
    *(undefined8 *)(&stack0x00000030 + iVar1) = unaff_RBP;
    *(undefined8 *)(&stack0x00000038 + iVar1) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar1 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar1) = 0x18027b7da;
    iVar3 = fcn.18045a350();
    uVar6 = 800 - uVar5 >> 2 & 0x1fffffffffffffff;
    if (uVar6 < 0xa9) {
        *(undefined8 *)((int64_t)auStackX_10 + (iVar1 - iVar3)) = 0x18027b815;
        fcn.1804986e0();
        *(uint64_t *)(iVar2 + 0x170) = uVar6;
        *(undefined8 *)(iVar2 + 0x180) = 0;
        *(undefined4 *)(iVar2 + 0x1a8) = 0;
        *(uint64_t *)(iVar2 + 0x178) = uVar5 >> 3;
        *(undefined *)(iVar2 + 0x188) = uVar4;
    }
    return uVar6 < 0xa9;
}

// ============================================================
// Function: FUN_18020e7e0
// Address: 0x18020e7e0
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18020e7e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_78h, int64_t arg_a0h)
{
    uint64_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint64_t in_RDX;
    int32_t iVar6;
    uint64_t in_R8;
    undefined8 in_R9;
    undefined8 extraout_XMM0_Qa;
    undefined auVar7 [16];
    int64_t var_8h;
    int64_t var_10h;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020e7f5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == 0) {
        puVar4 = (undefined4 *)0x0;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18020e80a;
        puVar4 = (undefined4 *)fcn.1801dd170();
    }
    iVar6 = (int32_t)in_R8;
    iVar2 = (int32_t)in_RDX;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = *(undefined8 *)((int64_t)&arg_28h + iVar3);
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = *(undefined8 *)((int64_t)auStackX_18 + iVar3);
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + -8) = 0x180275eb0;
    iVar5 = fcn.18045a350(puVar4, in_RDX & 0xffffffff, in_R8 & 0xffffffff, in_R9);
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_78h + iVar5 + iVar3) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_18 + iVar5 + iVar3;
    if (((iVar2 == 0x1d) && (puVar4 != (undefined4 *)0x0)) && (iVar6 == 0x30)) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar3 + -8) = 0x180275ef8;
        iVar2 = func_0x000180275d60(extraout_XMM0_Qa, in_R9, 0x30);
        if (0 < iVar2) {
            *(undefined8 *)((int64_t)&arg_58h + iVar5 + iVar3) = 0x3636363636363636;
            *(undefined8 *)((int64_t)&arg_38h + iVar5 + iVar3) = 0x3636363636363636;
            *(undefined8 *)(&stack0x00000040 + iVar5 + iVar3) = 0x3636363636363636;
            *(undefined8 *)((int64_t)&arg_48h + iVar5 + iVar3) = 0x3636363636363636;
            *(undefined8 *)(&stack0x00000050 + iVar5 + iVar3) = 0x3636363636363636;
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar3 + -8) = 0x180275f2b;
            iVar2 = func_0x000180275d60(puVar4, (int64_t)&arg_38h + iVar5 + iVar3, 0x28);
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar3 + -8) = 0x180275f40;
                iVar2 = func_0x000180275b70((int64_t)&arg_60h + iVar5 + iVar3, puVar4);
                if (iVar2 != 0) {
                    auVar7 = ZEXT816(0);
                    *(undefined (*) [16])(puVar4 + 5) = auVar7;
                    *(undefined (*) [16])(puVar4 + 9) = auVar7;
                    *(undefined (*) [16])(puVar4 + 0xd) = auVar7;
                    *(undefined (*) [16])(puVar4 + 0x11) = auVar7;
                    *(undefined8 *)(puVar4 + 0x15) = 0;
                    puVar4[0x17] = 0;
                    *puVar4 = 0x67452301;
                    puVar4[1] = 0xefcdab89;
                    puVar4[2] = 0x98badcfe;
                    puVar4[3] = 0x10325476;
                    puVar4[4] = 0xc3d2e1f0;
                    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar3 + -8) = 0x180275f97;
                    iVar2 = func_0x000180275d60(puVar4, in_R9, 0x30);
                    if (0 < iVar2) {
                        *(undefined8 *)((int64_t)&arg_58h + iVar5 + iVar3) = 0x5c5c5c5c5c5c5c5c;
                        *(undefined8 *)((int64_t)&arg_38h + iVar5 + iVar3) = 0x5c5c5c5c5c5c5c5c;
                        *(undefined8 *)(&stack0x00000040 + iVar5 + iVar3) = 0x5c5c5c5c5c5c5c5c;
                        *(undefined8 *)((int64_t)&arg_48h + iVar5 + iVar3) = 0x5c5c5c5c5c5c5c5c;
                        *(undefined8 *)(&stack0x00000050 + iVar5 + iVar3) = 0x5c5c5c5c5c5c5c5c;
                        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar3 + -8) = 0x180275fc6;
                        iVar2 = func_0x000180275d60(puVar4, (int64_t)&arg_38h + iVar5 + iVar3, 0x28);
                        if (iVar2 != 0) {
                            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar3 + -8) = 0x180275fdd;
                            iVar2 = func_0x000180275d60(puVar4, (int64_t)&arg_60h + iVar5 + iVar3, 0x14);
                            if (iVar2 != 0) {
                                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar3 + -8) = 0x180275ff0;
                                fcn.180244fc0((int64_t)&arg_60h + iVar5 + iVar3, 0x14);
                            }
                        }
                    }
                }
            }
        }
    }
    uVar1 = *(uint64_t *)((int64_t)&arg_78h + iVar5 + iVar3);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar3 + -8) = 0x180276006;
    func_0x000180459870(uVar1 ^ (int64_t)auStackX_18 + iVar5 + iVar3);
    return;
}

// ============================================================
// Function: FUN_18020e980
// Address: 0x18020e980
// Size: 349 bytes
// ============================================================
int32_t fcn.18020e980(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
                     int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                     int64_t arg_a8h, int64_t arg_b0h, int64_t arg_f8h, int64_t arg_158h, int64_t arg_160h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int64_t *in_RCX;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020e98c;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar1 = *in_RCX;
    if (iVar1 == 0) {
        return 0;
    }
    iVar6 = *(int32_t *)((int64_t)in_RCX + 0x6c);
    if (iVar6 < 0) {
        iVar6 = *(int32_t *)(iVar1 + 0xc);
        *(int32_t *)((int64_t)&arg_a8h + iVar7) = iVar6;
        *(int64_t *)((int64_t)&arg_b0h + iVar7) = (int64_t)iVar6;
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_50h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_58h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_60h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_68h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_70h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_78h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_80h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_88h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_90h + iVar7) = 0;
        if (*(int64_t *)(iVar1 + 0xe8) == 0) {
            if ((*(uint32_t *)(iVar1 + 0x10) & 0x800) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020eacb;
                iVar6 = fcn.180210b80(*(int64_t *)(&stack0x00000030 + iVar7), *(int64_t *)(&stack0x00000038 + iVar7), 
                                      *(int64_t *)(&stack0x00000040 + iVar7), *(int64_t *)((int64_t)&arg_48h + iVar7));
                if (iVar6 < 1) {
                    return -1;
                }
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020ea27;
            puVar8 = (undefined4 *)fcn.180229cc0((int64_t)&var_18h + iVar7, 0x1804bb2ec, (int64_t)&arg_b0h + iVar7);
            iVar1 = in_RCX[0x16];
            iVar2 = *in_RCX;
            uVar3 = puVar8[1];
            uVar4 = puVar8[2];
            uVar5 = puVar8[3];
            *(undefined4 *)((int64_t)&arg_48h + iVar7) = *puVar8;
            *(undefined4 *)((int64_t)&arg_48h + iVar7 + 4) = uVar3;
            *(undefined4 *)((int64_t)&arg_50h + iVar7) = uVar4;
            *(undefined4 *)((int64_t)&arg_50h + iVar7 + 4) = uVar5;
            uVar3 = puVar8[5];
            uVar4 = puVar8[6];
            uVar5 = puVar8[7];
            *(undefined4 *)((int64_t)&arg_58h + iVar7) = puVar8[4];
            *(undefined4 *)((int64_t)&arg_58h + iVar7 + 4) = uVar3;
            *(undefined4 *)((int64_t)&arg_60h + iVar7) = uVar4;
            *(undefined4 *)((int64_t)&arg_60h + iVar7 + 4) = uVar5;
            *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(puVar8 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020ea57;
            iVar6 = fcn.180280760(iVar2, iVar1, (int64_t)&arg_48h + iVar7);
            if (iVar6 < 1) {
                if (iVar6 != -1) {
                    return -1;
                }
                iVar6 = *(int32_t *)((int64_t)&arg_a8h + iVar7);
                *(int32_t *)((int64_t)in_RCX + 0x6c) = iVar6;
                return iVar6;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020ea65;
            iVar6 = fcn.18022aed0((int64_t)&arg_48h + iVar7);
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18020ea7b;
                iVar6 = fcn.180229fc0(*(int64_t *)((int64_t)&arg_60h + iVar7), *(int64_t *)((int64_t)&arg_68h + iVar7));
                if (iVar6 == 0) {
                    return -1;
                }
            }
        }
        iVar6 = *(int32_t *)((int64_t)&arg_a8h + iVar7);
        *(int32_t *)((int64_t)in_RCX + 0x6c) = iVar6;
    }
    return iVar6;
}

// ============================================================
// Function: FUN_18020eae0
// Address: 0x18020eae0
// Size: 40 bytes
// ============================================================
uint64_t fcn.18020eae0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
                      int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h,
                      int64_t arg_a8h, int64_t arg_b0h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    uint64_t uVar10;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020eaec;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar2 = *in_RCX;
    if (iVar2 == 0) {
        return 0;
    }
    uVar1 = *(uint32_t *)(in_RCX + 0xd);
    uVar10 = (uint64_t)uVar1;
    *(undefined8 *)((int64_t)&arg_b0h + iVar8) = unaff_RBX;
    if (((int32_t)uVar1 < 1) && (*(int64_t *)(iVar2 + 0x70) != 0)) {
        *(undefined8 *)((int64_t)&arg_48h + iVar8) = 0;
        *(undefined4 *)((int64_t)&arg_50h + iVar8) = 0;
        *(undefined8 *)((int64_t)&arg_58h + iVar8) = 0;
        *(undefined8 *)((int64_t)&arg_60h + iVar8) = 0;
        *(undefined8 *)((int64_t)&arg_68h + iVar8) = 0;
        *(undefined8 *)((int64_t)&arg_70h + iVar8) = 0;
        *(undefined4 *)((int64_t)&arg_78h + iVar8) = 0;
        *(undefined8 *)((int64_t)&arg_80h + iVar8) = 0;
        *(undefined8 *)((int64_t)&arg_88h + iVar8) = 0;
        *(undefined8 *)((int64_t)&arg_90h + iVar8) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x18020eb7a;
        puVar9 = (undefined4 *)fcn.180229cc0((int64_t)&var_18h + iVar8, 0x1804bb2f4, (int64_t)&arg_a8h + iVar8);
        iVar2 = in_RCX[0x16];
        iVar3 = *in_RCX;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        *(undefined4 *)((int64_t)&arg_48h + iVar8) = *puVar9;
        *(undefined4 *)((int64_t)&arg_48h + iVar8 + 4) = uVar4;
        *(undefined4 *)((int64_t)&arg_50h + iVar8) = uVar5;
        *(undefined4 *)((int64_t)&arg_50h + iVar8 + 4) = uVar6;
        uVar4 = puVar9[5];
        uVar5 = puVar9[6];
        uVar6 = puVar9[7];
        *(undefined4 *)((int64_t)&arg_58h + iVar8) = puVar9[4];
        *(undefined4 *)((int64_t)&arg_58h + iVar8 + 4) = uVar4;
        *(undefined4 *)((int64_t)&arg_60h + iVar8) = uVar5;
        *(undefined4 *)((int64_t)&arg_60h + iVar8 + 4) = uVar6;
        *(undefined8 *)((int64_t)&arg_68h + iVar8) = *(undefined8 *)(puVar9 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x18020ebaa;
        iVar7 = fcn.180280760(iVar3, iVar2, (int64_t)&arg_48h + iVar8);
        if (0 < iVar7) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x18020ebbc;
            iVar7 = fcn.180229fc0(*(int64_t *)((int64_t)&arg_60h + iVar8), *(int64_t *)((int64_t)&arg_68h + iVar8));
            if (iVar7 != 0) {
                uVar10 = *(uint64_t *)((int64_t)&arg_a8h + iVar8);
                *(int32_t *)(in_RCX + 0xd) = (int32_t)uVar10;
                return uVar10;
            }
        }
        uVar10 = 0xffffffff;
    }
    return uVar10;
}

