// Chunk 192 - 50 functions

// ============================================================
// Function: FUN_1802591a0
// Address: 0x1802591a0
// Size: 51 bytes
// ============================================================
void fcn.1802591a0(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802591aa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&arg_28h + iVar1) = 0xffffffff;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802591ce;
    fcn.18025a280(*(int64_t *)(&stack0x00000110 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1802591e0
// Address: 0x1802591e0
// Size: 44 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel

void fcn.1802591e0(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802591ea;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&arg_28h + iVar1) = 0xffffffff;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_R8;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180259207;
    fcn.18025a280(*(int64_t *)(&stack0x00000110 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180259210
// Address: 0x180259210
// Size: 42 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel

void fcn.180259210(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025921a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&arg_28h + iVar1) = 0xffffffff;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_R8;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180259235;
    fcn.18025a280(*(int64_t *)(&stack0x00000110 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180259240
// Address: 0x180259240
// Size: 46 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel

void fcn.180259240(int64_t arg_28h)
{
    int64_t iVar1;
    undefined4 in_ECX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025924a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&arg_28h + iVar1) = in_ECX;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180259269;
    fcn.18025a280(*(int64_t *)(&stack0x00000110 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180259270
// Address: 0x180259270
// Size: 47 bytes
// ============================================================
void fcn.180259270(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 in_RDX;
    undefined4 in_R8D;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025927a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = in_RDX;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = in_R8D;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18025929a;
    fcn.180258740(*(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1802592a0
// Address: 0x1802592a0
// Size: 65 bytes
// ============================================================
void fcn.1802592a0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    undefined8 in_RDX;
    undefined4 in_R8D;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802592aa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&arg_30h + iVar1) = in_R8D;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = in_RDX;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 6;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802592dc;
    fcn.180259b00(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000070 + iVar1), 
                  *(int64_t *)(&stack0x00000078 + iVar1), *(int64_t *)(&stack0x00000088 + iVar1), 
                  *(int64_t *)(&stack0x00000098 + iVar1), *(int64_t *)(&stack0x000000d0 + iVar1), 
                  *(int64_t *)(&stack0x000000d8 + iVar1), *(int64_t *)(&stack0x000000e0 + iVar1), 
                  *(int64_t *)(&stack0x00000198 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1802592f0
// Address: 0x1802592f0
// Size: 255 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h

code * fcn.1802592f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h,
                    int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h
                    , int64_t arg_188h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    code *UNRECOVERED_JUMPTABLE_00;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint32_t *in_RCX;
    undefined8 uVar9;
    int64_t *in_RDX;
    uint64_t uVar10;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int32_t var_74h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_30h;
    int64_t var_20h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180259300;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025930e;
    iVar3 = func_0x000180259e70();
    if (iVar3 != 1) {
        if (iVar3 != 2) {
            return (code *)0x0;
        }
        uVar4 = *in_RCX;
        if (((((uVar4 >> 0xb & 1) == 0) || (*(int64_t *)(in_RCX + 10) == 0)) ||
            (UNRECOVERED_JUMPTABLE_00 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x58),
            UNRECOVERED_JUMPTABLE_00 == (code *)0x0)) &&
           (((((uVar4 & 0xc1f0) == 0 || (*(int64_t *)(in_RCX + 10) == 0)) ||
             (UNRECOVERED_JUMPTABLE_00 = *(code **)(*(int64_t *)(in_RCX + 10) + 0xf0),
             UNRECOVERED_JUMPTABLE_00 == (code *)0x0)) &&
            ((((uVar4 & 0x600) == 0 || (*(int64_t *)(in_RCX + 10) == 0)) ||
             (UNRECOVERED_JUMPTABLE_00 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x70),
             UNRECOVERED_JUMPTABLE_00 == (code *)0x0)))))) {
            if ((((uVar4 & 6) != 0) && (iVar6 = *(int64_t *)(in_RCX + 8), iVar6 != 0)) &&
               (*(int64_t *)(iVar6 + 0x80) != 0)) {
                uVar9 = *(undefined8 *)(in_RCX + 10);
                *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8) = 0x180257e1a;
                fcn.18045a350(iVar6, uVar9, in_RDX);
                UNRECOVERED_JUMPTABLE_00 = *(code **)(iVar6 + 0x80);
                if (UNRECOVERED_JUMPTABLE_00 == (code *)0x0) {
                    return UNRECOVERED_JUMPTABLE_00;
                }
    // WARNING: Could not recover jumptable at 0x000180257e3b. Too many branches
    // WARNING: Treating indirect jump as call
                UNRECOVERED_JUMPTABLE_00 = (code *)(*UNRECOVERED_JUMPTABLE_00)(uVar9, in_RDX);
                return UNRECOVERED_JUMPTABLE_00;
            }
            if ((uVar4 & 0x3000) == 0) {
                return (code *)0x0;
            }
            if (*(int64_t *)(in_RCX + 10) == 0) {
                return (code *)0x0;
            }
            UNRECOVERED_JUMPTABLE_00 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x70);
            if (UNRECOVERED_JUMPTABLE_00 == (code *)0x0) {
                return (code *)0x0;
            }
        }
    // WARNING: Could not recover jumptable at 0x00018025934b. Too many branches
    // WARNING: Treating indirect jump as call
        UNRECOVERED_JUMPTABLE_00 = (code *)(*UNRECOVERED_JUMPTABLE_00)(*(undefined8 *)(in_RCX + 0xc), in_RDX);
        return UNRECOVERED_JUMPTABLE_00;
    }
    uVar9 = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    uVar11 = *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8);
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8) = 0x1802a2c9a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar2 = iVar6 + iVar5 + 0x18;
    if (*(int64_t *)(in_RCX + 8) != 0) {
        return (code *)0x0;
    }
    uVar10 = 2;
    *(undefined8 *)((int64_t)&arg_68h + iVar6 + iVar5) = uVar9;
    *(undefined8 *)((int64_t)&arg_40h + iVar6 + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_30h + iVar6 + iVar5) = uVar11;
    *(undefined8 *)((int64_t)&arg_28h + iVar6 + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar5 + 0x10) = unaff_R13;
    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar5 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar5 + 0x18 + -0x18) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar5 + -8) = 0x1802a2cdf;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)auStackX_10 + iVar6 + iVar5 + -0x10) =
         *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_10 + iVar7 + iVar2 + -0x18;
    uVar4 = *in_RCX;
    uVar1 = in_RCX[0x1d];
    *(int32_t *)((int64_t)&arg_40h + iVar7 + iVar2 + -0x18) = (int32_t)uVar10;
    if (uVar4 == 0) {
        uVar4 = 0xffffffff;
    }
    for (; (in_RDX != (int64_t *)0x0 && (iVar8 = *in_RDX, iVar8 != 0)); in_RDX = in_RDX + 5) {
        *(undefined8 *)((int64_t)&arg_70h + iVar7 + iVar2 + -0x18) = 0;
        *(undefined (*) [16])((int64_t)&arg_60h + iVar7 + iVar2 + -0x18) = ZEXT816(0);
        *(undefined (*) [16])((int64_t)&var_90h + iVar6 + iVar5) = ZEXT816(0);
        *(int32_t *)((int64_t)&var_88h + iVar6 + iVar5) = (int32_t)uVar10;
        *(undefined (*) [16])((int64_t)&var_80h + iVar6 + iVar5) = ZEXT816(0);
        UNRECOVERED_JUMPTABLE_00 = (code *)0x1802a2120;
        *(int32_t *)((int64_t)&arg_50h + iVar7 + iVar2 + -0x18) = (int32_t)uVar10;
        *(undefined (*) [16])((int64_t)&var_70h + iVar6 + iVar5) = ZEXT816(0);
        *(uint32_t *)((int64_t)&arg_58h + iVar7 + iVar2 + -0x18) = uVar1;
        *(undefined (*) [16])((int64_t)&var_60h + iVar6 + iVar5) = ZEXT816(0);
        *(uint32_t *)((int64_t)&arg_50h + iVar7 + iVar2 + -0x14) = uVar1;
        *(undefined (*) [16])((int64_t)&var_50h + iVar6 + iVar5) = ZEXT816(0);
        *(uint32_t *)((int64_t)&arg_58h + iVar7 + iVar2 + -0x14) = uVar4;
        *(undefined (*) [16])((int64_t)&var_40h + iVar6 + iVar5) = ZEXT816(0);
        *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar2 + -0x18) = iVar8;
        *(undefined (*) [16])((int64_t)&var_30h + iVar6 + iVar5) = ZEXT816(0);
        *(undefined (*) [16])((int64_t)&var_20h + iVar6 + iVar5) = ZEXT816(0);
        *(undefined (*) [16])((int64_t)&uStack_10 + iVar6 + iVar5) = ZEXT816(0);
        *(undefined (*) [16])((int64_t)&arg_80h + iVar7 + iVar2 + -0x18) = ZEXT816(0);
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar2 + -0x20) = 0x1802a2d97;
        iVar8 = func_0x0001802a33a0((int64_t)&arg_50h + iVar7 + iVar2 + -0x18);
        if (iVar8 != 0) {
            if (*(code **)(iVar8 + 0x38) != (code *)0x0) {
                UNRECOVERED_JUMPTABLE_00 = *(code **)(iVar8 + 0x38);
            }
            *(undefined4 *)((int64_t)&var_88h + iVar6 + iVar5 + 4) = *(undefined4 *)(iVar8 + 0x10);
        }
        *(uint32_t **)((int64_t)&var_90h + iVar6 + iVar5) = in_RCX;
        *(int64_t **)((int64_t)&var_60h + iVar6 + iVar5) = in_RDX;
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar2 + -0x20) = 0x1802a2dc6;
        iVar3 = (*UNRECOVERED_JUMPTABLE_00)(7, iVar8, (int64_t)&var_90h + iVar6 + iVar5);
        if (iVar3 < 1) {
code_r0x0001802a2df6:
            if (-1 < iVar3) goto code_r0x0001802a2dfa;
        } else {
            if (*(int32_t *)((int64_t)&var_88h + iVar6 + iVar5) != 0) {
                *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar2 + -0x18) =
                     *(undefined8 *)((int64_t)&var_70h + iVar6 + iVar5);
                *(undefined4 *)((int64_t)&arg_30h + iVar7 + iVar2 + -0x18) =
                     *(undefined4 *)((int64_t)&var_74h + iVar6 + iVar5);
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar2 + -0x20) = 0x1802a2df4;
                iVar3 = fcn.180258740(*(int64_t *)((int64_t)&arg_50h + iVar7 + iVar2 + -0x18), 
                                      *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar2 + -0x18), 
                                      *(int64_t *)((int64_t)&arg_60h + iVar7 + iVar2 + -0x18), 
                                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar2 + -0x18), 
                                      *(int64_t *)((int64_t)&arg_70h + iVar7 + iVar2 + -0x18), 
                                      *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar2 + -0x18));
                goto code_r0x0001802a2df6;
            }
code_r0x0001802a2dfa:
            *(int32_t *)((int64_t)&var_74h + iVar6 + iVar5) = iVar3;
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar2 + -0x20) = 0x1802a2e0b;
            (*UNRECOVERED_JUMPTABLE_00)(8, iVar8, (int64_t)&var_90h + iVar6 + iVar5);
            iVar3 = *(int32_t *)((int64_t)&var_74h + iVar6 + iVar5);
        }
        iVar8 = *(int64_t *)((int64_t)&var_18h + iVar6 + iVar5);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar2 + -0x20) = 0x1802a2e29;
            func_0x000180224990(iVar8, 0x1804f0ed0, 0x2cd);
        }
        if (iVar3 < 1) break;
        uVar10 = (uint64_t)*(uint32_t *)((int64_t)&arg_40h + iVar7 + iVar2 + -0x18);
    }
    uVar10 = *(uint64_t *)((int64_t)auStackX_10 + iVar6 + iVar5 + -0x10);
    *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar2 + -0x20) = 0x1802a2e4c;
    UNRECOVERED_JUMPTABLE_00 = (code *)func_0x000180459870(uVar10 ^ (int64_t)auStackX_10 + iVar7 + iVar2 + -0x18);
    return UNRECOVERED_JUMPTABLE_00;
}

// ============================================================
// Function: FUN_1802593f0
// Address: 0x1802593f0
// Size: 57 bytes
// ============================================================
void fcn.1802593f0(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802593fa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&arg_28h + iVar1) = 1;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 0xc1f0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180259424;
    fcn.180259c70(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000070 + iVar1), 
                  *(int64_t *)(&stack0x00000078 + iVar1), *(int64_t *)(&stack0x00000088 + iVar1), 
                  *(int64_t *)(&stack0x00000098 + iVar1), *(int64_t *)(&stack0x000000b0 + iVar1), 
                  *(int64_t *)(&stack0x000000d8 + iVar1), *(int64_t *)(&stack0x00000190 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180259430
// Address: 0x180259430
// Size: 302 bytes
// ============================================================
undefined8 fcn.180259430(uint32_t *param_1)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025943c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar1 = *param_1;
    if ((((uVar1 >> 0xb & 1) != 0) && (*(int64_t *)(param_1 + 10) != 0)) &&
       (*(int64_t *)(*(int64_t *)(param_1 + 10) + 0x60) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025945f;
        uVar3 = func_0x00018021eaf0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259467;
        uVar3 = func_0x00018027e810(uVar3);
    // WARNING: Could not recover jumptable at 0x00018025947b. Too many branches
    // WARNING: Treating indirect jump as call
        uVar3 = (**(code **)(*(int64_t *)(param_1 + 10) + 0x60))
                          (*(undefined8 *)(param_1 + 0xc), uVar3, *(code **)(*(int64_t *)(param_1 + 10) + 0x60));
        return uVar3;
    }
    if ((((uVar1 & 0xc1f0) != 0) && (*(int64_t *)(param_1 + 10) != 0)) &&
       (*(int64_t *)(*(int64_t *)(param_1 + 10) + 0xf8) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025949d;
        uVar3 = func_0x00018021eaf0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802594a5;
        uVar3 = func_0x00018027e810(uVar3);
    // WARNING: Could not recover jumptable at 0x0001802594bc. Too many branches
    // WARNING: Treating indirect jump as call
        uVar3 = (**(code **)(*(int64_t *)(param_1 + 10) + 0xf8))
                          (*(undefined8 *)(param_1 + 0xc), uVar3, *(code **)(*(int64_t *)(param_1 + 10) + 0xf8));
        return uVar3;
    }
    if ((((uVar1 & 0x600) == 0) || (*(int64_t *)(param_1 + 10) == 0)) ||
       (*(int64_t *)(*(int64_t *)(param_1 + 10) + 0x78) == 0)) {
        if ((((uVar1 & 6) != 0) && (*(int64_t *)(param_1 + 8) != 0)) &&
           (*(int64_t *)(*(int64_t *)(param_1 + 8) + 0x88) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259516;
            uVar3 = func_0x0001801dd170();
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025951e;
            uVar3 = func_0x00018027e810(uVar3);
    // WARNING: Could not recover jumptable at 0x000180259535. Too many branches
    // WARNING: Treating indirect jump as call
            uVar3 = (**(code **)(*(int64_t *)(param_1 + 8) + 0x88))
                              (*(undefined8 *)(param_1 + 10), uVar3, *(code **)(*(int64_t *)(param_1 + 8) + 0x88));
            return uVar3;
        }
        if ((((uVar1 & 0x3000) == 0) || (*(int64_t *)(param_1 + 10) == 0)) ||
           (*(int64_t *)(*(int64_t *)(param_1 + 10) + 0x78) == 0)) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259554;
        uVar3 = func_0x00018021eaf0();
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802594db;
        uVar3 = func_0x00018021eaf0();
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802594e3;
    uVar3 = func_0x00018027e810(uVar3);
    // WARNING: Could not recover jumptable at 0x0001802594f7. Too many branches
    // WARNING: Treating indirect jump as call
    uVar3 = (**(code **)(*(int64_t *)(param_1 + 10) + 0x78))
                      (*(undefined8 *)(param_1 + 0xc), uVar3, *(code **)(*(int64_t *)(param_1 + 10) + 0x78));
    return uVar3;
}

// ============================================================
// Function: FUN_180259560
// Address: 0x180259560
// Size: 47 bytes
// ============================================================
void fcn.180259560(int64_t arg1)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    if (arg1 != 0) {
        uStack_8 = 0x18025956f;
        iVar1 = fcn.18045a350();
        if ((*(uint8_t *)(arg1 + 4) & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x18025958a;
            fcn.180224990();
        }
    }
    return;
}

// ============================================================
// Function: FUN_180259590
// Address: 0x180259590
// Size: 61 bytes
// ============================================================
void fcn.180259590(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_88h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    code *pcVar7;
    int32_t iVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar9;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 auStackX_18 [2];
    undefined8 uStack_8;
    
    uStack_8 = 0x18025959a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (*(int64_t *)0x18077e748 == 0) {
        return;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar5) = 0x1802595b5;
    piVar6 = (int32_t *)func_0x000180222290(*(int64_t *)0x18077e748, 0x180196ec0);
    pcVar7 = fcn.180259560;
    if (piVar6 != (int32_t *)0x0) {
        *(undefined8 *)(&stack0x00000048 + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + 8) = unaff_RSI;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5) = 0x180222069;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_50h + iVar4 + iVar5) = unaff_RBX;
        iVar8 = 0;
        *(undefined8 *)((int64_t)&arg_60h + iVar4 + iVar5) = unaff_R14;
        if (0 < *piVar6) {
            *(undefined8 *)((int64_t)&arg_58h + iVar4 + iVar5) = unaff_RDI;
            iVar9 = 0;
            do {
                iVar1 = *(int64_t *)(iVar9 + *(int64_t *)(piVar6 + 2));
                if (iVar1 != 0) {
                    pcVar2 = *(code **)(piVar6 + 8);
                    if (pcVar2 == (code *)0x0) {
                        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1802220b2;
                        (*pcVar7)();
                    } else {
                        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1802220ae;
                        (*pcVar2)(pcVar7, iVar1);
                    }
                }
                iVar8 = iVar8 + 1;
                iVar9 = iVar9 + 8;
            } while (iVar8 < *piVar6);
        }
        uVar3 = *(undefined8 *)(piVar6 + 2);
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1802220d7;
        fcn.180224990(uVar3, 0x1804bf768, 0x1ce);
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1802220ec;
        fcn.180224990(piVar6, 0x1804bf768, 0x1cf);
    }
    return;
}

// ============================================================
// Function: FUN_1802595d0
// Address: 0x1802595d0
// Size: 446 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1802595d0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h)
{
    int32_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint32_t *in_RCX;
    uint64_t in_RDX;
    uint64_t in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802595ee;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    piVar1 = *(int32_t **)(in_RCX + 0x1e);
    if ((piVar1 == (int32_t *)0x0) || (*(int64_t *)(piVar1 + 0x3e) == 0)) {
        if (*in_RCX == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025961f;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180259637;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180259649;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
            return 0xffffffff;
        }
        if (((uint32_t)in_R8 != 0xffffffff) && (((uint32_t)in_R8 & *in_RCX) == 0)) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180259663;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025967b;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025968d;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
            return 0xffffffff;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025969c;
    iVar3 = func_0x000180259e70();
    if ((iVar3 != 0) && (iVar3 != 1)) {
        if (iVar3 == 2) {
            *(undefined8 *)((int64_t)&var_10h + iVar5) = *(undefined8 *)((int64_t)&arg_60h + iVar5);
            *(undefined4 *)((int64_t)&var_8h + iVar5) = *(undefined4 *)((int64_t)&arg_58h + iVar5);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802596d2;
            uVar6 = func_0x0001802a2a70(in_RCX, in_RDX & 0xffffffff, in_R8 & 0xffffffff, in_R9 & 0xffffffff);
            return uVar6;
        }
        return 0;
    }
    if ((piVar1 != (int32_t *)0x0) && (pcVar2 = *(code **)(piVar1 + 0x30), pcVar2 != (code *)0x0)) {
        if (((int32_t)in_RDX != -1) && (*piVar1 != (int32_t)in_RDX)) {
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180259707;
        uVar4 = (*pcVar2)(in_RCX, in_R9 & 0xffffffff, *(undefined4 *)((int64_t)&arg_58h + iVar5), 
                          *(undefined8 *)((int64_t)&arg_60h + iVar5));
        if (uVar4 == 0xfffffffe) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180259713;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025972b;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025973d;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
            return (uint64_t)uVar4;
        }
        return (uint64_t)uVar4;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180259746;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025975e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                  *(int64_t *)((int64_t)&arg_38h + iVar5));
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180259770;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_180259790
// Address: 0x180259790
// Size: 102 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180259790(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    code *pcVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t in_R8;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802597aa;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar5 = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802597c2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802597da;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802597ec;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar5 = 0xfffffffe;
    } else {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259800;
        iVar2 = func_0x000180259e70();
        if ((iVar2 == 0) || (iVar2 == 1)) {
            if ((*(int64_t *)(in_RCX + 0x78) == 0) ||
               (pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x78) + 200), pcVar1 == (code *)0x0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802598d9;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802598f1;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259903;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                uVar5 = 0xfffffffe;
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259853;
                iVar2 = func_0x000180498f10(in_RDX, 0x1804af254);
                if (iVar2 == 0) {
                    if (in_R8 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259864;
                        iVar6 = func_0x00018022e160(in_R8);
                        if (iVar6 != 0) {
                            *(int64_t *)((int64_t)&var_20h + iVar4) = iVar6;
                            *(undefined4 *)((int64_t)&var_18h + iVar4) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025988b;
                            uVar5 = fcn.180258740(*(int64_t *)((int64_t)&arg_38h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                                  *(int64_t *)(&stack0x00000058 + iVar4), 
                                                  *(int64_t *)(&stack0x00000060 + iVar4));
                            return uVar5;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259894;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802598ac;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802598be;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                    uVar5 = 0;
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802598ce;
                    uVar3 = (*pcVar1)(in_RCX, in_RDX, in_R8);
                    uVar5 = (uint64_t)uVar3;
                }
            }
        } else if (iVar2 == 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259822;
            uVar5 = func_0x0001802a28d0(in_RCX, in_RDX, in_R8);
        }
    }
    return uVar5;
}

// ============================================================
// Function: FUN_1802597f6
// Address: 0x1802597f6
// Size: 279 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180259790(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    code *pcVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t in_R8;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802597aa;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar5 = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802597c2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802597da;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802597ec;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar5 = 0xfffffffe;
    } else {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259800;
        iVar2 = func_0x000180259e70();
        if ((iVar2 == 0) || (iVar2 == 1)) {
            if ((*(int64_t *)(in_RCX + 0x78) == 0) ||
               (pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x78) + 200), pcVar1 == (code *)0x0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802598d9;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802598f1;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259903;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                uVar5 = 0xfffffffe;
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259853;
                iVar2 = func_0x000180498f10(in_RDX, 0x1804af254);
                if (iVar2 == 0) {
                    if (in_R8 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259864;
                        iVar6 = func_0x00018022e160(in_R8);
                        if (iVar6 != 0) {
                            *(int64_t *)((int64_t)&var_20h + iVar4) = iVar6;
                            *(undefined4 *)((int64_t)&var_18h + iVar4) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025988b;
                            uVar5 = fcn.180258740(*(int64_t *)((int64_t)&arg_38h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                                  *(int64_t *)(&stack0x00000058 + iVar4), 
                                                  *(int64_t *)(&stack0x00000060 + iVar4));
                            return uVar5;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259894;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802598ac;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802598be;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                    uVar5 = 0;
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802598ce;
                    uVar3 = (*pcVar1)(in_RCX, in_RDX, in_R8);
                    uVar5 = (uint64_t)uVar3;
                }
            }
        } else if (iVar2 == 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259822;
            uVar5 = func_0x0001802a28d0(in_RCX, in_RDX, in_R8);
        }
    }
    return uVar5;
}

// ============================================================
// Function: FUN_18025990d
// Address: 0x18025990d
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180259790(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    code *pcVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t in_R8;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802597aa;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar5 = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802597c2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802597da;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802597ec;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar5 = 0xfffffffe;
    } else {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R14;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259800;
        iVar2 = func_0x000180259e70();
        if ((iVar2 == 0) || (iVar2 == 1)) {
            if ((*(int64_t *)(in_RCX + 0x78) == 0) ||
               (pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x78) + 200), pcVar1 == (code *)0x0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802598d9;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802598f1;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259903;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                uVar5 = 0xfffffffe;
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259853;
                iVar2 = func_0x000180498f10(in_RDX, 0x1804af254);
                if (iVar2 == 0) {
                    if (in_R8 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259864;
                        iVar6 = func_0x00018022e160(in_R8);
                        if (iVar6 != 0) {
                            *(int64_t *)((int64_t)&var_20h + iVar4) = iVar6;
                            *(undefined4 *)((int64_t)&var_18h + iVar4) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025988b;
                            uVar5 = fcn.180258740(*(int64_t *)((int64_t)&arg_38h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                                  *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                                  *(int64_t *)(&stack0x00000058 + iVar4), 
                                                  *(int64_t *)(&stack0x00000060 + iVar4));
                            return uVar5;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259894;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802598ac;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802598be;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                    uVar5 = 0;
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802598ce;
                    uVar3 = (*pcVar1)(in_RCX, in_RDX, in_R8);
                    uVar5 = (uint64_t)uVar3;
                }
            }
        } else if (iVar2 == 2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259822;
            uVar5 = func_0x0001802a28d0(in_RCX, in_RDX, in_R8);
        }
    }
    return uVar5;
}

// ============================================================
// Function: FUN_180259930
// Address: 0x180259930
// Size: 284 bytes
// ============================================================
void fcn.180259930(uint32_t *param_1)
{
    uint32_t uVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025993c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *param_1;
    if ((uVar1 & 0xc1f0) != 0) {
        if ((*(int64_t *)(param_1 + 0xc) != 0) && (*(int64_t *)(param_1 + 10) != 0)) {
            pcVar2 = *(code **)(*(int64_t *)(param_1 + 10) + 0xd0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259966;
            (*pcVar2)();
        }
        uVar3 = *(undefined8 *)(param_1 + 10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025996f;
        fcn.1802481d0(uVar3);
        *(undefined8 *)(param_1 + 0xc) = 0;
        *(undefined8 *)(param_1 + 10) = 0;
        return;
    }
    if ((uVar1 >> 0xb & 1) != 0) {
        if ((*(int64_t *)(param_1 + 0xc) != 0) && (*(int64_t *)(param_1 + 10) != 0)) {
            pcVar2 = *(code **)(*(int64_t *)(param_1 + 10) + 0x48);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025999d;
            (*pcVar2)();
        }
        uVar3 = *(undefined8 *)(param_1 + 10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802599a6;
        fcn.180249610(uVar3);
        *(undefined8 *)(param_1 + 0xc) = 0;
        *(undefined8 *)(param_1 + 10) = 0;
        return;
    }
    if ((uVar1 & 0x3000) != 0) {
        if ((*(int64_t *)(param_1 + 0xc) != 0) && (*(int64_t *)(param_1 + 10) != 0)) {
            pcVar2 = *(code **)(*(int64_t *)(param_1 + 10) + 0x50);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802599d5;
            (*pcVar2)();
        }
        uVar3 = *(undefined8 *)(param_1 + 10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802599de;
        fcn.18026df60(uVar3);
        *(undefined8 *)(param_1 + 0xc) = 0;
        *(undefined8 *)(param_1 + 10) = 0;
        return;
    }
    if ((uVar1 & 0x600) != 0) {
        if ((*(int64_t *)(param_1 + 0xc) != 0) && (*(int64_t *)(param_1 + 10) != 0)) {
            pcVar2 = *(code **)(*(int64_t *)(param_1 + 10) + 0x50);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259a0d;
            (*pcVar2)();
        }
        uVar3 = *(undefined8 *)(param_1 + 10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259a16;
        fcn.180264d30(uVar3);
        *(undefined8 *)(param_1 + 0xc) = 0;
        *(undefined8 *)(param_1 + 10) = 0;
        return;
    }
    if ((((uVar1 & 6) != 0) && (iVar6 = *(int64_t *)(param_1 + 10), iVar6 != 0)) &&
       (iVar5 = *(int64_t *)(param_1 + 8), iVar5 != 0)) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x180257d5a;
        fcn.18045a350();
        if (*(code **)(iVar5 + 0x98) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180257d70. Too many branches
    // WARNING: Treating indirect jump as call
            (**(code **)(iVar5 + 0x98))(iVar6);
            return;
        }
        return;
    }
    return;
}

// ============================================================
// Function: FUN_180259a50
// Address: 0x180259a50
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180259a50(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    int64_t *piVar5;
    undefined8 unaff_RBP;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180259a60;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_RCX != 0) && (in_RDX != (int64_t *)0x0)) {
        iVar4 = *(int64_t *)(in_RCX + 0x20);
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBP;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259a89;
            uVar3 = func_0x000180258f80();
            iVar4 = *in_RDX;
            piVar5 = in_RDX;
            while (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259aab;
                iVar4 = func_0x00018022ae60(uVar3, iVar4);
                if (iVar4 == 0) {
                    return 0xfffffffe;
                }
                piVar1 = piVar5 + 5;
                piVar5 = piVar5 + 5;
                iVar4 = *piVar1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259ac8;
        uVar3 = func_0x000180258cd0(in_RCX, in_RDX);
        return uVar3;
    }
    return 0;
}

// ============================================================
// Function: FUN_180259a78
// Address: 0x180259a78
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180259a50(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    int64_t *piVar5;
    undefined8 unaff_RBP;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180259a60;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_RCX != 0) && (in_RDX != (int64_t *)0x0)) {
        iVar4 = *(int64_t *)(in_RCX + 0x20);
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBP;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259a89;
            uVar3 = func_0x000180258f80();
            iVar4 = *in_RDX;
            piVar5 = in_RDX;
            while (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259aab;
                iVar4 = func_0x00018022ae60(uVar3, iVar4);
                if (iVar4 == 0) {
                    return 0xfffffffe;
                }
                piVar1 = piVar5 + 5;
                piVar5 = piVar5 + 5;
                iVar4 = *piVar1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259ac8;
        uVar3 = func_0x000180258cd0(in_RCX, in_RDX);
        return uVar3;
    }
    return 0;
}

// ============================================================
// Function: FUN_180259add
// Address: 0x180259add
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180259a50(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    int64_t *piVar5;
    undefined8 unaff_RBP;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180259a60;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_RCX != 0) && (in_RDX != (int64_t *)0x0)) {
        iVar4 = *(int64_t *)(in_RCX + 0x20);
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBP;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259a89;
            uVar3 = func_0x000180258f80();
            iVar4 = *in_RDX;
            piVar5 = in_RDX;
            while (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259aab;
                iVar4 = func_0x00018022ae60(uVar3, iVar4);
                if (iVar4 == 0) {
                    return 0xfffffffe;
                }
                piVar1 = piVar5 + 5;
                piVar5 = piVar5 + 5;
                iVar4 = *piVar1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259ac8;
        uVar3 = func_0x000180258cd0(in_RCX, in_RDX);
        return uVar3;
    }
    return 0;
}

// ============================================================
// Function: FUN_180259ae4
// Address: 0x180259ae4
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180259a50(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    int64_t *piVar5;
    undefined8 unaff_RBP;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180259a60;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_RCX != 0) && (in_RDX != (int64_t *)0x0)) {
        iVar4 = *(int64_t *)(in_RCX + 0x20);
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBP;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259a89;
            uVar3 = func_0x000180258f80();
            iVar4 = *in_RDX;
            piVar5 = in_RDX;
            while (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259aab;
                iVar4 = func_0x00018022ae60(uVar3, iVar4);
                if (iVar4 == 0) {
                    return 0xfffffffe;
                }
                piVar1 = piVar5 + 5;
                piVar5 = piVar5 + 5;
                iVar4 = *piVar1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259ac8;
        uVar3 = func_0x000180258cd0(in_RCX, in_RDX);
        return uVar3;
    }
    return 0;
}

// ============================================================
// Function: FUN_180259b00
// Address: 0x180259b00
// Size: 355 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h

undefined8
fcn.180259b00(int64_t arg_28h, int64_t arg_58h, int64_t arg_68h, int64_t arg_78h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_a0h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_e8h, int64_t arg_1a0h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined4 *puVar6;
    uint32_t *in_RCX;
    int32_t in_EDX;
    undefined8 in_R8;
    uint32_t in_R9D;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180259b0c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((in_RCX == (uint32_t *)0x0) || ((*in_RCX & in_R9D) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259c2b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259c43;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259c55;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0xfffffffe;
    }
    if (in_EDX != 0) {
        *(undefined8 *)((int64_t)&var_20h + iVar4) = *(undefined8 *)((int64_t)&arg_e0h + iVar4);
        *(undefined4 *)((int64_t)&var_18h + iVar4) = *(undefined4 *)((int64_t)&arg_e8h + iVar4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259b5b;
        uVar5 = fcn.180258740(*(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar4), *(int64_t *)(&stack0x00000050 + iVar4), 
                              *(int64_t *)((int64_t)&arg_58h + iVar4), *(int64_t *)(&stack0x00000060 + iVar4));
        return uVar5;
    }
    if (*(int32_t *)((int64_t)&arg_e8h + iVar4) < 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259b75;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259b8d;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259b9f;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259bc2;
    puVar6 = (undefined4 *)
             fcn.180229c70((int64_t)&arg_28h + iVar4, in_R8, *(undefined8 *)((int64_t)&arg_e0h + iVar4), 
                           (int64_t)*(int32_t *)((int64_t)&arg_e8h + iVar4));
    uVar1 = puVar6[1];
    uVar2 = puVar6[2];
    uVar3 = puVar6[3];
    *(undefined4 *)((int64_t)&arg_58h + iVar4) = *puVar6;
    *(undefined4 *)((int64_t)&arg_58h + iVar4 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000060 + iVar4) = uVar2;
    *(undefined4 *)(&stack0x00000064 + iVar4) = uVar3;
    uVar1 = puVar6[5];
    uVar2 = puVar6[6];
    uVar3 = puVar6[7];
    *(undefined4 *)((int64_t)&arg_68h + iVar4) = puVar6[4];
    *(undefined4 *)((int64_t)&arg_68h + iVar4 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000070 + iVar4) = uVar2;
    *(undefined4 *)(&stack0x00000074 + iVar4) = uVar3;
    *(undefined8 *)((int64_t)&arg_78h + iVar4) = *(undefined8 *)(puVar6 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259beb;
    puVar6 = (undefined4 *)fcn.180229ba0((int64_t)&arg_28h + iVar4);
    uVar1 = puVar6[1];
    uVar2 = puVar6[2];
    uVar3 = puVar6[3];
    *(undefined4 *)((int64_t)&arg_80h + iVar4) = *puVar6;
    *(undefined4 *)((int64_t)&arg_80h + iVar4 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000088 + iVar4) = uVar2;
    *(undefined4 *)(&stack0x0000008c + iVar4) = uVar3;
    uVar1 = puVar6[5];
    uVar2 = puVar6[6];
    uVar3 = puVar6[7];
    *(undefined4 *)((int64_t)&arg_90h + iVar4) = puVar6[4];
    *(undefined4 *)((int64_t)&arg_90h + iVar4 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000098 + iVar4) = uVar2;
    *(undefined4 *)(&stack0x0000009c + iVar4) = uVar3;
    *(undefined8 *)((int64_t)&arg_a0h + iVar4) = *(undefined8 *)(puVar6 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259c1d;
    uVar5 = fcn.1802592f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                          *(int64_t *)(&stack0x00000050 + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4), 
                          *(int64_t *)(&stack0x00000060 + iVar4), *(int64_t *)((int64_t)&arg_68h + iVar4), 
                          *(int64_t *)(&stack0x00000070 + iVar4), *(int64_t *)(&stack0x00000178 + iVar4));
    return uVar5;
}

// ============================================================
// Function: FUN_180259c70
// Address: 0x180259c70
// Size: 324 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h

undefined8
fcn.180259c70(int64_t arg_28h, int64_t arg_58h, int64_t arg_68h, int64_t arg_78h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_a0h, int64_t arg_b8h, int64_t arg_e0h, int64_t arg_198h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined4 *puVar6;
    uint32_t *in_RCX;
    int64_t in_RDX;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180259c80;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((in_RCX != (uint32_t *)0x0) && ((*in_RCX & *(uint32_t *)(&stack0x000000d8 + iVar4)) != 0)) {
        if (in_R8D == 0) {
            if (in_RDX != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259cf0;
                fcn.18020f750(in_RDX);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259d03;
            puVar6 = (undefined4 *)
                     fcn.180229e30(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                   *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                                   *(int64_t *)(&stack0x00000050 + iVar4));
            uVar1 = puVar6[1];
            uVar2 = puVar6[2];
            uVar3 = puVar6[3];
            *(undefined4 *)((int64_t)&arg_58h + iVar4) = *puVar6;
            *(undefined4 *)((int64_t)&arg_58h + iVar4 + 4) = uVar1;
            *(undefined4 *)(&stack0x00000060 + iVar4) = uVar2;
            *(undefined4 *)(&stack0x00000064 + iVar4) = uVar3;
            uVar1 = puVar6[5];
            uVar2 = puVar6[6];
            uVar3 = puVar6[7];
            *(undefined4 *)((int64_t)&arg_68h + iVar4) = puVar6[4];
            *(undefined4 *)((int64_t)&arg_68h + iVar4 + 4) = uVar1;
            *(undefined4 *)(&stack0x00000070 + iVar4) = uVar2;
            *(undefined4 *)(&stack0x00000074 + iVar4) = uVar3;
            *(undefined8 *)((int64_t)&arg_78h + iVar4) = *(undefined8 *)(puVar6 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259d2c;
            puVar6 = (undefined4 *)fcn.180229ba0((int64_t)&arg_28h + iVar4);
            uVar1 = puVar6[1];
            uVar2 = puVar6[2];
            uVar3 = puVar6[3];
            *(undefined4 *)((int64_t)&arg_80h + iVar4) = *puVar6;
            *(undefined4 *)((int64_t)&arg_80h + iVar4 + 4) = uVar1;
            *(undefined4 *)(&stack0x00000088 + iVar4) = uVar2;
            *(undefined4 *)(&stack0x0000008c + iVar4) = uVar3;
            uVar1 = puVar6[5];
            uVar2 = puVar6[6];
            uVar3 = puVar6[7];
            *(undefined4 *)((int64_t)&arg_90h + iVar4) = puVar6[4];
            *(undefined4 *)((int64_t)&arg_90h + iVar4 + 4) = uVar1;
            *(undefined4 *)(&stack0x00000098 + iVar4) = uVar2;
            *(undefined4 *)(&stack0x0000009c + iVar4) = uVar3;
            *(undefined8 *)((int64_t)&arg_a0h + iVar4) = *(undefined8 *)(puVar6 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259d5e;
            uVar5 = fcn.1802592f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                  *(int64_t *)(&stack0x00000040 + iVar4), *(int64_t *)(&stack0x00000048 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar4), *(int64_t *)((int64_t)&arg_68h + iVar4), 
                                  *(int64_t *)(&stack0x00000070 + iVar4), *(int64_t *)(&stack0x00000178 + iVar4));
            return uVar5;
        }
        *(int64_t *)((int64_t)&var_20h + iVar4) = in_RDX;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259cc9;
        uVar5 = fcn.180258740(*(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar4), *(int64_t *)(&stack0x00000050 + iVar4), 
                              *(int64_t *)((int64_t)&arg_58h + iVar4), *(int64_t *)(&stack0x00000060 + iVar4));
        return uVar5;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259d74;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259d8c;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180259d9e;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_180259dc0
// Address: 0x180259dc0
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h

undefined8 fcn.180259dc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180259dd0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_RCX != 0) && (in_RDX != (int64_t *)0x0)) {
        iVar4 = *(int64_t *)(in_RCX + 0x20);
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBP;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259df9;
            uVar3 = fcn.180259430();
            iVar4 = *in_RDX;
            while (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259e1b;
                iVar4 = func_0x00018022ae60(uVar3, iVar4);
                if (iVar4 == 0) {
                    return 0xfffffffe;
                }
                piVar1 = in_RDX + 5;
                in_RDX = in_RDX + 5;
                iVar4 = *piVar1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259e38;
        uVar3 = fcn.1802592f0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                              *(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2), 
                              *(int64_t *)(&stack0x00000068 + iVar2), *(int64_t *)(&stack0x00000070 + iVar2), 
                              *(int64_t *)(&stack0x00000178 + iVar2));
        return uVar3;
    }
    return 0;
}

// ============================================================
// Function: FUN_180259de8
// Address: 0x180259de8
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h

undefined8 fcn.180259dc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180259dd0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_RCX != 0) && (in_RDX != (int64_t *)0x0)) {
        iVar4 = *(int64_t *)(in_RCX + 0x20);
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBP;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259df9;
            uVar3 = fcn.180259430();
            iVar4 = *in_RDX;
            while (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259e1b;
                iVar4 = func_0x00018022ae60(uVar3, iVar4);
                if (iVar4 == 0) {
                    return 0xfffffffe;
                }
                piVar1 = in_RDX + 5;
                in_RDX = in_RDX + 5;
                iVar4 = *piVar1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259e38;
        uVar3 = fcn.1802592f0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                              *(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2), 
                              *(int64_t *)(&stack0x00000068 + iVar2), *(int64_t *)(&stack0x00000070 + iVar2), 
                              *(int64_t *)(&stack0x00000178 + iVar2));
        return uVar3;
    }
    return 0;
}

// ============================================================
// Function: FUN_180259e4d
// Address: 0x180259e4d
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h

undefined8 fcn.180259dc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180259dd0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_RCX != 0) && (in_RDX != (int64_t *)0x0)) {
        iVar4 = *(int64_t *)(in_RCX + 0x20);
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBP;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259df9;
            uVar3 = fcn.180259430();
            iVar4 = *in_RDX;
            while (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259e1b;
                iVar4 = func_0x00018022ae60(uVar3, iVar4);
                if (iVar4 == 0) {
                    return 0xfffffffe;
                }
                piVar1 = in_RDX + 5;
                in_RDX = in_RDX + 5;
                iVar4 = *piVar1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259e38;
        uVar3 = fcn.1802592f0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                              *(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2), 
                              *(int64_t *)(&stack0x00000068 + iVar2), *(int64_t *)(&stack0x00000070 + iVar2), 
                              *(int64_t *)(&stack0x00000178 + iVar2));
        return uVar3;
    }
    return 0;
}

// ============================================================
// Function: FUN_180259e54
// Address: 0x180259e54
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h

undefined8 fcn.180259dc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180259dd0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((in_RCX != 0) && (in_RDX != (int64_t *)0x0)) {
        iVar4 = *(int64_t *)(in_RCX + 0x20);
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBP;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259df9;
            uVar3 = fcn.180259430();
            iVar4 = *in_RDX;
            while (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259e1b;
                iVar4 = func_0x00018022ae60(uVar3, iVar4);
                if (iVar4 == 0) {
                    return 0xfffffffe;
                }
                piVar1 = in_RDX + 5;
                in_RDX = in_RDX + 5;
                iVar4 = *piVar1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259e38;
        uVar3 = fcn.1802592f0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                              *(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                              *(int64_t *)(&stack0x00000048 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2), 
                              *(int64_t *)(&stack0x00000068 + iVar2), *(int64_t *)(&stack0x00000070 + iVar2), 
                              *(int64_t *)(&stack0x00000178 + iVar2));
        return uVar3;
    }
    return 0;
}

// ============================================================
// Function: FUN_180259ee0
// Address: 0x180259ee0
// Size: 100 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180259ee0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h,
             int64_t arg_80h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    uint32_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    uint32_t in_R8D;
    int32_t in_R9D;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180259efb;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar7 = *(int64_t *)((int64_t)&arg_48h + iVar5);
    if (in_R9D == -1) {
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f2d;
            iVar3 = func_0x000180498f10(iVar7, 0x1804e662c);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f40;
                iVar3 = func_0x000180498f10(iVar7, 0x1804e6638);
                if (iVar3 != 0) goto code_r0x000180259fba;
            }
code_r0x000180259f44:
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
            if ((int32_t)in_RDX != -1) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f5a;
                iVar3 = func_0x000180259e70(in_RCX);
                if ((iVar3 == 0) || (iVar3 == 1)) {
                    if (*(undefined4 **)(in_RCX + 0x1e) == (undefined4 *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a058;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a070;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a082;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xfffffffe;
                    }
                    uVar1 = **(undefined4 **)(in_RCX + 0x1e);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a093;
                    iVar3 = func_0x000180299e80(uVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a09c;
                    iVar4 = func_0x000180299e80(in_RDX & 0xffffffff);
                    if (iVar3 != iVar4) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0a5;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0bd;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0cf;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xffffffff;
                    }
                } else if (iVar3 == 2) {
                    if (*(int64_t *)(in_RCX + 8) == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f80;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f98;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259faa;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xfffffffe;
                    }
                    uVar2 = *(undefined8 *)(in_RCX + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259ffe;
                    uVar6 = func_0x000180231580(in_RDX & 0xffffffff);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a009;
                    iVar3 = func_0x000180257a60(uVar2, uVar6);
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a016;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a02e;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a040;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xffffffff;
                    }
                }
            }
            if ((in_R8D != 0xffffffff) && ((*in_RCX & in_R8D) == 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0e9;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a101;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                              *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                              *(int64_t *)((int64_t)&arg_48h + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a113;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                return 0xffffffff;
            }
            uVar2 = *(undefined8 *)(in_RCX + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a133;
            fcn.180224990(uVar2, 0x1804e6520, 0x5fd);
            uVar2 = *(undefined8 *)(in_RCX + 0xe);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a149;
            fcn.180224990(uVar2, 0x1804e6520, 0x5fe);
            *(undefined8 *)(in_RCX + 0x10) = 0;
            *(undefined8 *)(in_RCX + 0xe) = 0;
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a16d;
                iVar7 = func_0x0001802231e0(iVar7, 0x1804e6520, 0x5e7);
                *(int64_t *)(in_RCX + 0xe) = iVar7;
                if (iVar7 == 0) {
                    return 0;
                }
            }
            iVar7 = *(int64_t *)((int64_t)&arg_58h + iVar5);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a19a;
                iVar5 = func_0x000180223170(*(undefined8 *)(&stack0x00000050 + iVar5), iVar7, 0x1804e6520, 0x5ec);
                *(int64_t *)(in_RCX + 0x10) = iVar5;
                if (iVar5 == 0) {
                    return 0;
                }
            }
            in_RCX[0x14] = in_RCX[0x14] | 1;
            *(int64_t *)(in_RCX + 0x12) = iVar7;
            return 1;
        }
    } else if (in_R9D == 0xf) goto code_r0x000180259f44;
code_r0x000180259fba:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259fbf;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259fd7;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)((int64_t)&arg_48h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259fe9;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_180259f44
// Address: 0x180259f44
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180259ee0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h,
             int64_t arg_80h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    uint32_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    uint32_t in_R8D;
    int32_t in_R9D;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180259efb;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar7 = *(int64_t *)((int64_t)&arg_48h + iVar5);
    if (in_R9D == -1) {
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f2d;
            iVar3 = func_0x000180498f10(iVar7, 0x1804e662c);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f40;
                iVar3 = func_0x000180498f10(iVar7, 0x1804e6638);
                if (iVar3 != 0) goto code_r0x000180259fba;
            }
code_r0x000180259f44:
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
            if ((int32_t)in_RDX != -1) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f5a;
                iVar3 = func_0x000180259e70(in_RCX);
                if ((iVar3 == 0) || (iVar3 == 1)) {
                    if (*(undefined4 **)(in_RCX + 0x1e) == (undefined4 *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a058;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a070;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a082;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xfffffffe;
                    }
                    uVar1 = **(undefined4 **)(in_RCX + 0x1e);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a093;
                    iVar3 = func_0x000180299e80(uVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a09c;
                    iVar4 = func_0x000180299e80(in_RDX & 0xffffffff);
                    if (iVar3 != iVar4) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0a5;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0bd;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0cf;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xffffffff;
                    }
                } else if (iVar3 == 2) {
                    if (*(int64_t *)(in_RCX + 8) == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f80;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f98;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259faa;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xfffffffe;
                    }
                    uVar2 = *(undefined8 *)(in_RCX + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259ffe;
                    uVar6 = func_0x000180231580(in_RDX & 0xffffffff);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a009;
                    iVar3 = func_0x000180257a60(uVar2, uVar6);
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a016;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a02e;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a040;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xffffffff;
                    }
                }
            }
            if ((in_R8D != 0xffffffff) && ((*in_RCX & in_R8D) == 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0e9;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a101;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                              *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                              *(int64_t *)((int64_t)&arg_48h + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a113;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                return 0xffffffff;
            }
            uVar2 = *(undefined8 *)(in_RCX + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a133;
            fcn.180224990(uVar2, 0x1804e6520, 0x5fd);
            uVar2 = *(undefined8 *)(in_RCX + 0xe);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a149;
            fcn.180224990(uVar2, 0x1804e6520, 0x5fe);
            *(undefined8 *)(in_RCX + 0x10) = 0;
            *(undefined8 *)(in_RCX + 0xe) = 0;
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a16d;
                iVar7 = func_0x0001802231e0(iVar7, 0x1804e6520, 0x5e7);
                *(int64_t *)(in_RCX + 0xe) = iVar7;
                if (iVar7 == 0) {
                    return 0;
                }
            }
            iVar7 = *(int64_t *)((int64_t)&arg_58h + iVar5);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a19a;
                iVar5 = func_0x000180223170(*(undefined8 *)(&stack0x00000050 + iVar5), iVar7, 0x1804e6520, 0x5ec);
                *(int64_t *)(in_RCX + 0x10) = iVar5;
                if (iVar5 == 0) {
                    return 0;
                }
            }
            in_RCX[0x14] = in_RCX[0x14] | 1;
            *(int64_t *)(in_RCX + 0x12) = iVar7;
            return 1;
        }
    } else if (in_R9D == 0xf) goto code_r0x000180259f44;
code_r0x000180259fba:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259fbf;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259fd7;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)((int64_t)&arg_48h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259fe9;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_180259fb4
// Address: 0x180259fb4
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180259ee0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h,
             int64_t arg_80h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    uint32_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    uint32_t in_R8D;
    int32_t in_R9D;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180259efb;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar7 = *(int64_t *)((int64_t)&arg_48h + iVar5);
    if (in_R9D == -1) {
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f2d;
            iVar3 = func_0x000180498f10(iVar7, 0x1804e662c);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f40;
                iVar3 = func_0x000180498f10(iVar7, 0x1804e6638);
                if (iVar3 != 0) goto code_r0x000180259fba;
            }
code_r0x000180259f44:
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
            if ((int32_t)in_RDX != -1) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f5a;
                iVar3 = func_0x000180259e70(in_RCX);
                if ((iVar3 == 0) || (iVar3 == 1)) {
                    if (*(undefined4 **)(in_RCX + 0x1e) == (undefined4 *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a058;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a070;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a082;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xfffffffe;
                    }
                    uVar1 = **(undefined4 **)(in_RCX + 0x1e);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a093;
                    iVar3 = func_0x000180299e80(uVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a09c;
                    iVar4 = func_0x000180299e80(in_RDX & 0xffffffff);
                    if (iVar3 != iVar4) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0a5;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0bd;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0cf;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xffffffff;
                    }
                } else if (iVar3 == 2) {
                    if (*(int64_t *)(in_RCX + 8) == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f80;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f98;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259faa;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xfffffffe;
                    }
                    uVar2 = *(undefined8 *)(in_RCX + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259ffe;
                    uVar6 = func_0x000180231580(in_RDX & 0xffffffff);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a009;
                    iVar3 = func_0x000180257a60(uVar2, uVar6);
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a016;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a02e;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a040;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xffffffff;
                    }
                }
            }
            if ((in_R8D != 0xffffffff) && ((*in_RCX & in_R8D) == 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0e9;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a101;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                              *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                              *(int64_t *)((int64_t)&arg_48h + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a113;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                return 0xffffffff;
            }
            uVar2 = *(undefined8 *)(in_RCX + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a133;
            fcn.180224990(uVar2, 0x1804e6520, 0x5fd);
            uVar2 = *(undefined8 *)(in_RCX + 0xe);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a149;
            fcn.180224990(uVar2, 0x1804e6520, 0x5fe);
            *(undefined8 *)(in_RCX + 0x10) = 0;
            *(undefined8 *)(in_RCX + 0xe) = 0;
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a16d;
                iVar7 = func_0x0001802231e0(iVar7, 0x1804e6520, 0x5e7);
                *(int64_t *)(in_RCX + 0xe) = iVar7;
                if (iVar7 == 0) {
                    return 0;
                }
            }
            iVar7 = *(int64_t *)((int64_t)&arg_58h + iVar5);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a19a;
                iVar5 = func_0x000180223170(*(undefined8 *)(&stack0x00000050 + iVar5), iVar7, 0x1804e6520, 0x5ec);
                *(int64_t *)(in_RCX + 0x10) = iVar5;
                if (iVar5 == 0) {
                    return 0;
                }
            }
            in_RCX[0x14] = in_RCX[0x14] | 1;
            *(int64_t *)(in_RCX + 0x12) = iVar7;
            return 1;
        }
    } else if (in_R9D == 0xf) goto code_r0x000180259f44;
code_r0x000180259fba:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259fbf;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259fd7;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)((int64_t)&arg_48h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259fe9;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_180259ff3
// Address: 0x180259ff3
// Size: 454 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180259ee0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h,
             int64_t arg_80h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    uint32_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    uint32_t in_R8D;
    int32_t in_R9D;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180259efb;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar7 = *(int64_t *)((int64_t)&arg_48h + iVar5);
    if (in_R9D == -1) {
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f2d;
            iVar3 = func_0x000180498f10(iVar7, 0x1804e662c);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f40;
                iVar3 = func_0x000180498f10(iVar7, 0x1804e6638);
                if (iVar3 != 0) goto code_r0x000180259fba;
            }
code_r0x000180259f44:
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
            if ((int32_t)in_RDX != -1) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f5a;
                iVar3 = func_0x000180259e70(in_RCX);
                if ((iVar3 == 0) || (iVar3 == 1)) {
                    if (*(undefined4 **)(in_RCX + 0x1e) == (undefined4 *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a058;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a070;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a082;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xfffffffe;
                    }
                    uVar1 = **(undefined4 **)(in_RCX + 0x1e);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a093;
                    iVar3 = func_0x000180299e80(uVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a09c;
                    iVar4 = func_0x000180299e80(in_RDX & 0xffffffff);
                    if (iVar3 != iVar4) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0a5;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0bd;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0cf;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xffffffff;
                    }
                } else if (iVar3 == 2) {
                    if (*(int64_t *)(in_RCX + 8) == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f80;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f98;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259faa;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xfffffffe;
                    }
                    uVar2 = *(undefined8 *)(in_RCX + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259ffe;
                    uVar6 = func_0x000180231580(in_RDX & 0xffffffff);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a009;
                    iVar3 = func_0x000180257a60(uVar2, uVar6);
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a016;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a02e;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a040;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xffffffff;
                    }
                }
            }
            if ((in_R8D != 0xffffffff) && ((*in_RCX & in_R8D) == 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0e9;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a101;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                              *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                              *(int64_t *)((int64_t)&arg_48h + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a113;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                return 0xffffffff;
            }
            uVar2 = *(undefined8 *)(in_RCX + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a133;
            fcn.180224990(uVar2, 0x1804e6520, 0x5fd);
            uVar2 = *(undefined8 *)(in_RCX + 0xe);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a149;
            fcn.180224990(uVar2, 0x1804e6520, 0x5fe);
            *(undefined8 *)(in_RCX + 0x10) = 0;
            *(undefined8 *)(in_RCX + 0xe) = 0;
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a16d;
                iVar7 = func_0x0001802231e0(iVar7, 0x1804e6520, 0x5e7);
                *(int64_t *)(in_RCX + 0xe) = iVar7;
                if (iVar7 == 0) {
                    return 0;
                }
            }
            iVar7 = *(int64_t *)((int64_t)&arg_58h + iVar5);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a19a;
                iVar5 = func_0x000180223170(*(undefined8 *)(&stack0x00000050 + iVar5), iVar7, 0x1804e6520, 0x5ec);
                *(int64_t *)(in_RCX + 0x10) = iVar5;
                if (iVar5 == 0) {
                    return 0;
                }
            }
            in_RCX[0x14] = in_RCX[0x14] | 1;
            *(int64_t *)(in_RCX + 0x12) = iVar7;
            return 1;
        }
    } else if (in_R9D == 0xf) goto code_r0x000180259f44;
code_r0x000180259fba:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259fbf;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259fd7;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)((int64_t)&arg_48h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259fe9;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_18025a1b9
// Address: 0x18025a1b9
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180259ee0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h,
             int64_t arg_80h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    uint32_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    uint32_t in_R8D;
    int32_t in_R9D;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180259efb;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar7 = *(int64_t *)((int64_t)&arg_48h + iVar5);
    if (in_R9D == -1) {
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f2d;
            iVar3 = func_0x000180498f10(iVar7, 0x1804e662c);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f40;
                iVar3 = func_0x000180498f10(iVar7, 0x1804e6638);
                if (iVar3 != 0) goto code_r0x000180259fba;
            }
code_r0x000180259f44:
            *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
            if ((int32_t)in_RDX != -1) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f5a;
                iVar3 = func_0x000180259e70(in_RCX);
                if ((iVar3 == 0) || (iVar3 == 1)) {
                    if (*(undefined4 **)(in_RCX + 0x1e) == (undefined4 *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a058;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a070;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a082;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xfffffffe;
                    }
                    uVar1 = **(undefined4 **)(in_RCX + 0x1e);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a093;
                    iVar3 = func_0x000180299e80(uVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a09c;
                    iVar4 = func_0x000180299e80(in_RDX & 0xffffffff);
                    if (iVar3 != iVar4) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0a5;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0bd;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0cf;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xffffffff;
                    }
                } else if (iVar3 == 2) {
                    if (*(int64_t *)(in_RCX + 8) == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f80;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259f98;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259faa;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xfffffffe;
                    }
                    uVar2 = *(undefined8 *)(in_RCX + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259ffe;
                    uVar6 = func_0x000180231580(in_RDX & 0xffffffff);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a009;
                    iVar3 = func_0x000180257a60(uVar2, uVar6);
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a016;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a02e;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar5));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a040;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                        return 0xffffffff;
                    }
                }
            }
            if ((in_R8D != 0xffffffff) && ((*in_RCX & in_R8D) == 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a0e9;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a101;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                              *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                              *(int64_t *)((int64_t)&arg_48h + iVar5));
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a113;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
                return 0xffffffff;
            }
            uVar2 = *(undefined8 *)(in_RCX + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a133;
            fcn.180224990(uVar2, 0x1804e6520, 0x5fd);
            uVar2 = *(undefined8 *)(in_RCX + 0xe);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a149;
            fcn.180224990(uVar2, 0x1804e6520, 0x5fe);
            *(undefined8 *)(in_RCX + 0x10) = 0;
            *(undefined8 *)(in_RCX + 0xe) = 0;
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a16d;
                iVar7 = func_0x0001802231e0(iVar7, 0x1804e6520, 0x5e7);
                *(int64_t *)(in_RCX + 0xe) = iVar7;
                if (iVar7 == 0) {
                    return 0;
                }
            }
            iVar7 = *(int64_t *)((int64_t)&arg_58h + iVar5);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18025a19a;
                iVar5 = func_0x000180223170(*(undefined8 *)(&stack0x00000050 + iVar5), iVar7, 0x1804e6520, 0x5ec);
                *(int64_t *)(in_RCX + 0x10) = iVar5;
                if (iVar5 == 0) {
                    return 0;
                }
            }
            in_RCX[0x14] = in_RCX[0x14] | 1;
            *(int64_t *)(in_RCX + 0x12) = iVar7;
            return 1;
        }
    } else if (in_R9D == 0xf) goto code_r0x000180259f44;
code_r0x000180259fba:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259fbf;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259fd7;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)((int64_t)&arg_48h + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180259fe9;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_18025a1d0
// Address: 0x18025a1d0
// Size: 92 bytes
// ============================================================
uint64_t fcn.18025a1d0(int64_t arg_28h)
{
    code *pcVar1;
    undefined8 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar9;
    undefined8 unaff_R14;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025a1da;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if ((*(uint8_t *)(in_RCX + 0x50) & 1) == 0) {
        return 1;
    }
    iVar7 = *(int64_t *)(in_RCX + 0x38);
    iVar9 = *(int64_t *)(in_RCX + 0x40);
    uVar2 = *(undefined8 *)(in_RCX + 0x48);
    if (iVar7 != 0) {
        *(undefined8 *)(&stack0x00000048 + iVar8) = unaff_RBX;
        *(undefined8 *)(&stack0x00000050 + iVar8) = unaff_RBP;
        *(undefined8 *)(&stack0x00000058 + iVar8) = unaff_RSI;
        *(undefined8 *)(&stack0x00000030 + iVar8) = unaff_RDI;
        *(undefined8 *)((int64_t)&arg_28h + iVar8) = 0x1802597aa;
        iVar5 = fcn.18045a350();
        iVar5 = -iVar5;
        uVar6 = 0;
        if (in_RCX == 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar5 + iVar8) = 0x1802597c2;
            fcn.180229480(*(int64_t *)(&stack0x00000050 + iVar5 + iVar8), *(int64_t *)(&stack0x00000058 + iVar5 + iVar8)
                         );
            *(undefined8 *)((int64_t)&arg_28h + iVar5 + iVar8) = 0x1802597da;
            fcn.1802295a0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar8), *(int64_t *)(&stack0x00000058 + iVar5 + iVar8)
                          , *(int64_t *)(&stack0x00000060 + iVar5 + iVar8), 
                          *(int64_t *)(&stack0x00000068 + iVar5 + iVar8), *(int64_t *)(&stack0x00000080 + iVar5 + iVar8)
                         );
            *(undefined8 *)((int64_t)&arg_28h + iVar5 + iVar8) = 0x1802597ec;
            fcn.1802296d0(*(int64_t *)(&stack0x00000070 + iVar5 + iVar8));
            uVar6 = 0xfffffffe;
        } else {
            *(undefined8 *)(&stack0x00000070 + iVar5 + iVar8) = unaff_R14;
            *(undefined8 *)((int64_t)&arg_28h + iVar5 + iVar8) = 0x180259800;
            iVar3 = func_0x000180259e70();
            if ((iVar3 == 0) || (iVar3 == 1)) {
                if ((*(int64_t *)(in_RCX + 0x78) == 0) ||
                   (pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x78) + 200), pcVar1 == (code *)0x0)) {
                    *(undefined8 *)((int64_t)&arg_28h + iVar5 + iVar8) = 0x1802598d9;
                    fcn.180229480(*(int64_t *)(&stack0x00000050 + iVar5 + iVar8), 
                                  *(int64_t *)(&stack0x00000058 + iVar5 + iVar8));
                    *(undefined8 *)((int64_t)&arg_28h + iVar5 + iVar8) = 0x1802598f1;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar8), 
                                  *(int64_t *)(&stack0x00000058 + iVar5 + iVar8), 
                                  *(int64_t *)(&stack0x00000060 + iVar5 + iVar8), 
                                  *(int64_t *)(&stack0x00000068 + iVar5 + iVar8), 
                                  *(int64_t *)(&stack0x00000080 + iVar5 + iVar8));
                    *(undefined8 *)((int64_t)&arg_28h + iVar5 + iVar8) = 0x180259903;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000070 + iVar5 + iVar8));
                    uVar6 = 0xfffffffe;
                } else {
                    *(undefined8 *)((int64_t)&arg_28h + iVar5 + iVar8) = 0x180259853;
                    iVar3 = func_0x000180498f10(iVar7, 0x1804af254);
                    if (iVar3 == 0) {
                        if (iVar9 != 0) {
                            *(undefined8 *)((int64_t)&arg_28h + iVar5 + iVar8) = 0x180259864;
                            iVar7 = func_0x00018022e160(iVar9);
                            if (iVar7 != 0) {
                                *(int64_t *)(&stack0x00000058 + iVar5 + iVar8) = iVar7;
                                *(undefined4 *)(&stack0x00000050 + iVar5 + iVar8) = 0;
                                *(undefined8 *)((int64_t)&arg_28h + iVar5 + iVar8) = 0x18025988b;
                                uVar6 = fcn.180258740(*(int64_t *)(&stack0x00000070 + iVar5 + iVar8), 
                                                      *(int64_t *)(&stack0x00000078 + iVar5 + iVar8), 
                                                      *(int64_t *)(&stack0x00000080 + iVar5 + iVar8), 
                                                      *(int64_t *)(&stack0x00000088 + iVar5 + iVar8), 
                                                      *(int64_t *)(&stack0x00000090 + iVar5 + iVar8), 
                                                      *(int64_t *)(&stack0x00000098 + iVar5 + iVar8));
                                return uVar6;
                            }
                        }
                        *(undefined8 *)((int64_t)&arg_28h + iVar5 + iVar8) = 0x180259894;
                        fcn.180229480(*(int64_t *)(&stack0x00000050 + iVar5 + iVar8), 
                                      *(int64_t *)(&stack0x00000058 + iVar5 + iVar8));
                        *(undefined8 *)((int64_t)&arg_28h + iVar5 + iVar8) = 0x1802598ac;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar8), 
                                      *(int64_t *)(&stack0x00000058 + iVar5 + iVar8), 
                                      *(int64_t *)(&stack0x00000060 + iVar5 + iVar8), 
                                      *(int64_t *)(&stack0x00000068 + iVar5 + iVar8), 
                                      *(int64_t *)(&stack0x00000080 + iVar5 + iVar8));
                        *(undefined8 *)((int64_t)&arg_28h + iVar5 + iVar8) = 0x1802598be;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000070 + iVar5 + iVar8));
                        uVar6 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&arg_28h + iVar5 + iVar8) = 0x1802598ce;
                        uVar4 = (*pcVar1)(in_RCX, iVar7, iVar9);
                        uVar6 = (uint64_t)uVar4;
                    }
                }
            } else if (iVar3 == 2) {
                *(undefined8 *)((int64_t)&arg_28h + iVar5 + iVar8) = 0x180259822;
                uVar6 = func_0x0001802a28d0(in_RCX, iVar7, iVar9);
            }
        }
        return uVar6;
    }
    *(int64_t *)((int64_t)&arg_28h + iVar8) = iVar9;
    *(int32_t *)((int64_t)&var_20h + iVar8) = (int32_t)uVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x18025a21d;
    uVar6 = fcn.1802595d0(*(int64_t *)(&stack0x00000030 + iVar8), *(int64_t *)(&stack0x00000038 + iVar8), 
                          *(int64_t *)(&stack0x00000040 + iVar8), *(int64_t *)(&stack0x00000050 + iVar8), 
                          *(int64_t *)(&stack0x00000058 + iVar8));
    return uVar6;
}

// ============================================================
// Function: FUN_18025a230
// Address: 0x18025a230
// Size: 77 bytes
// ============================================================
undefined8 fcn.18025a230(int64_t arg_150h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined4 in_ECX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025a23a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int64_t *)0x18077e748 != 0) {
        *(undefined4 *)((int64_t)&var_20h + iVar2) = in_ECX;
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025a259;
        iVar1 = fcn.180221a50(*(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2));
        if (-1 < iVar1) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025a26b;
            uVar3 = fcn.180222340(*(int64_t *)0x18077e748, iVar1);
            return uVar3;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18025a280
// Address: 0x18025a280
// Size: 1070 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_270h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_218h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel

undefined4 * fcn.18025a280(int64_t arg1, int64_t arg_118h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    code **ppcVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    int64_t iVar11;
    int32_t *in_RDX;
    int64_t in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18025a2a1;
    var_8h = arg1;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar5 = *(int32_t *)(&stack0x00000270 + iVar6);
    puVar10 = (undefined4 *)0x0;
    iVar7 = 0;
    iVar9 = 0;
    if (iVar5 == -1) {
        if (in_RDX == (int32_t *)0x0) {
code_r0x00018025a31d:
            if (in_R9 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a32a;
                iVar5 = func_0x0001802314f0(in_R9);
                if (iVar5 != 0) goto code_r0x00018025a2d1;
                iVar5 = -1;
            }
        } else {
            if (*(int64_t *)(in_RDX + 0x18) != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a31a;
                in_R9 = func_0x0001801dd6c0();
                goto code_r0x00018025a31d;
            }
            iVar5 = *in_RDX;
code_r0x00018025a2d1:
            if (iVar5 != -1) goto code_r0x00018025a337;
        }
        if (in_R8 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a2e4;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a2fc;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)(&stack0x00000028 + iVar6));
            goto code_r0x00018025a301;
        }
        goto code_r0x00018025a4d2;
    }
code_r0x00018025a337:
    iVar7 = 0;
    if (in_R8 == 0) {
        if ((in_RDX == (int32_t *)0x0) || ((*(uint8_t *)(in_RDX + 0x13) & 1) == 0)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a35b;
            in_R9 = func_0x00018022ccf0(iVar5);
            if (in_RDX != (int32_t *)0x0) goto code_r0x00018025a363;
        } else {
code_r0x00018025a363:
            in_R8 = *(int64_t *)(in_RDX + 6);
            iVar7 = in_R9;
            if ((in_R8 != 0) || (in_R8 = *(int64_t *)(in_RDX + 4), in_R8 != 0)) goto code_r0x00018025a3db;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a37c;
        in_R8 = func_0x00018029b6c0(iVar5);
    } else {
code_r0x00018025a3db:
        in_R9 = iVar7;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a3e3;
        iVar3 = func_0x00018026b010(in_R8);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a3ec;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a404;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                          *(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)(&stack0x00000028 + iVar6));
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a416;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
            return (undefined4 *)0x0;
        }
    }
    if (in_R8 == 0) {
        if ((in_RDX != (int32_t *)0x0) && ((*(uint8_t *)(in_RDX + 0x13) & 1) != 0)) {
            if (*(int64_t *)0x18077e748 != 0) {
                *(int32_t *)((int64_t)&var_18h + iVar6) = iVar5;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a44a;
                iVar3 = fcn.180221a50(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                if (-1 < iVar3) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a45c;
                    iVar7 = fcn.180222340(*(int64_t *)0x18077e748, iVar3);
                    *(int64_t *)((int64_t)&var_8h + iVar6) = iVar7;
                    if (iVar7 != 0) goto code_r0x00018025a4d2;
                }
            }
            *(int32_t *)((int64_t)&arg_118h + iVar6) = iVar5;
            *(int64_t *)((int64_t)&var_8h + iVar6) = (int64_t)&arg_118h + iVar6;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = 0x18025a6b0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a4a6;
            ppcVar8 = (code **)func_0x00018022c840((int64_t)&var_8h + iVar6, 0x1806a03e0, 10, 8);
            if ((ppcVar8 == (code **)0x0) || (pcVar2 = *ppcVar8, pcVar2 == (code *)0x0)) {
                iVar7 = 0;
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a4b5;
                iVar7 = (*pcVar2)();
            }
code_r0x00018025a4d2:
            iVar3 = iVar5;
            if (in_R9 != 0) {
                if ((in_RDX == (int32_t *)0x0) || (*(int64_t *)(in_RDX + 0x18) == 0)) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a537;
                    iVar9 = func_0x0001802579b0(*(undefined8 *)(&stack0x00000248 + iVar6), in_R9, 
                                                *(undefined8 *)(&stack0x00000268 + iVar6));
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a4ee;
                    iVar4 = func_0x000180257ae0();
                    if (iVar4 == 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a4f7;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)(&stack0x00000000 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a50f;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                      *(int64_t *)(&stack0x00000000 + iVar6), *(int64_t *)((int64_t)&var_8h + iVar6), 
                                      *(int64_t *)((int64_t)&var_10h + iVar6), *(int64_t *)(&stack0x00000028 + iVar6));
code_r0x00018025a301:
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a30e;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
                        return (undefined4 *)0x0;
                    }
                    iVar9 = *(int64_t *)(in_RDX + 0x18);
                }
                if (iVar9 == 0) {
                    return (undefined4 *)0x0;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a54b;
                iVar4 = func_0x00018020efa0(iVar9);
                if (((iVar4 != 0) && (iVar3 = iVar4, iVar5 != -1)) && (iVar3 = iVar5, iVar5 != iVar4)) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a56c;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                 );
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a584;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6)
                                  , *(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                                  *(int64_t *)(&stack0x00000028 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a596;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
                    goto code_r0x00018025a596;
                }
            }
            goto code_r0x00018025a395;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a4c6;
        iVar7 = fcn.18025a230(*(int64_t *)(&stack0x00000120 + iVar6));
        if (iVar7 == 0) goto code_r0x00018025a4d2;
code_r0x00018025a5a5:
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a5bc;
        puVar10 = (undefined4 *)func_0x000180224d60(0xb0, 0x1804e6520, 0x129);
        if ((puVar10 == (undefined4 *)0x0) || (iVar7 == 0)) goto code_r0x00018025a5c9;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a392;
        iVar7 = func_0x00018029b650(in_R8, iVar5);
        iVar3 = iVar5;
code_r0x00018025a395:
        iVar5 = iVar3;
        if ((iVar7 != 0) || (iVar9 != 0)) goto code_r0x00018025a5a5;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a3ac;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a3c4;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                      *(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)(&stack0x00000028 + iVar6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a3d6;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar6));
code_r0x00018025a5c9:
        if (in_R8 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a5d6;
            func_0x00018026aee0(in_R8);
        }
        if (puVar10 == (undefined4 *)0x0) {
code_r0x00018025a596:
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a59e;
            func_0x000180257a00(iVar9);
            return (undefined4 *)0x0;
        }
    }
    if (*(int64_t *)(&stack0x00000268 + iVar6) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a600;
        iVar11 = func_0x0001802231e0(*(undefined8 *)(&stack0x00000268 + iVar6), 0x1804e6520, 0x136);
        *(int64_t *)(puVar10 + 4) = iVar11;
        if (iVar11 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a61e;
            fcn.180224990(puVar10, 0x1804e6520, 0x138);
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a626;
            func_0x000180257a00(iVar9);
            return (undefined4 *)0x0;
        }
    }
    uVar1 = *(undefined8 *)(&stack0x00000248 + iVar6);
    puVar10[0x1d] = iVar5;
    *(undefined8 *)(puVar10 + 2) = uVar1;
    *(int64_t *)(puVar10 + 6) = in_R9;
    *(int64_t *)(puVar10 + 8) = iVar9;
    *(int64_t *)(puVar10 + 0x20) = in_R8;
    *(int64_t *)(puVar10 + 0x1e) = iVar7;
    *puVar10 = 0;
    if (in_RDX != (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a65d;
        iVar5 = func_0x0001802308d0(in_RDX);
        if (iVar5 == 0) goto code_r0x00018025a683;
    }
    *(int32_t **)(puVar10 + 0x22) = in_RDX;
    if (iVar7 == 0) {
        return puVar10;
    }
    pcVar2 = *(code **)(iVar7 + 8);
    if (pcVar2 == (code *)0x0) {
        return puVar10;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a67b;
    iVar5 = (*pcVar2)(puVar10);
    if (0 < iVar5) {
        return puVar10;
    }
    *(undefined8 *)(puVar10 + 0x1e) = 0;
code_r0x00018025a683:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18025a68b;
    func_0x000180258be0(puVar10);
    return (undefined4 *)0x0;
}

// ============================================================
// Function: FUN_18025a6b0
// Address: 0x18025a6b0
// Size: 35 bytes
// ============================================================
int32_t fcn.18025a6b0(int32_t **param_1, code **param_2)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t *piVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025a6bc;
    iVar2 = fcn.18045a350();
    pcVar1 = *param_2;
    *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x18025a6c4;
    piVar3 = (int32_t *)(*pcVar1)();
    return **param_1 - *piVar3;
}

// ============================================================
// Function: FUN_18025a6e0
// Address: 0x18025a6e0
// Size: 146 bytes
// ============================================================
undefined8 fcn.18025a6e0(int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int32_t *in_RCX;
    int64_t in_R8;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025a6ea;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025a6f7;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025a70f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)((int64_t)&arg_38h + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025a721;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0;
    }
    if ((*in_RCX != 0) && (*(int64_t *)(in_RCX + 0x18) == 0)) {
        iVar4 = *(int64_t *)(in_RCX + 2);
        *(int64_t *)((int64_t)&arg_30h + iVar2) = in_R8;
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = in_R9;
        *(undefined8 *)((int64_t)&var_20h + iVar2) = 0;
        pcVar1 = *(code **)(iVar4 + 0x120);
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025a764;
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    *(undefined8 *)(&stack0x00000040 + iVar2) = 0x18029e98a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((in_RCX != (int32_t *)0x0) && (in_R8 != 0)) {
        *(undefined8 *)((int64_t)&arg_68h + iVar4 + iVar2) = in_R9;
        *(undefined8 *)(&stack0x00000040 + iVar4 + iVar2) = 0x18029e9af;
        uVar3 = fcn.180257b20(*(int64_t *)(&stack0x00000088 + iVar4 + iVar2));
        return uVar3;
    }
    return 0;
}

// ============================================================
// Function: FUN_18025a780
// Address: 0x18025a780
// Size: 279 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18025a780(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    uint8_t *in_RCX;
    int64_t *in_RDX;
    int64_t iVar4;
    uint64_t in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025a7a0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((in_RCX == (uint8_t *)0x0) || ((*in_RCX & 8) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025a84d;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025a865;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025a877;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar1));
        return 0xfffffffe;
    }
    if (in_RDX == (int64_t *)0x0) {
code_r0x00018025a812:
        uVar3 = 0xffffffff;
    } else {
        iVar2 = *in_RDX;
        iVar4 = 0;
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025a7d5;
            iVar2 = func_0x00018022fd80();
            *in_RDX = iVar2;
            iVar4 = iVar2;
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025a7e8;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025a800;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                              *(int64_t *)(&stack0x00000048 + iVar1));
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025a812;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar1));
                goto code_r0x00018025a812;
            }
        }
        uVar3 = *(undefined8 *)(in_RCX + 0x20);
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025a828;
        iVar2 = func_0x00018029ece0(iVar2, uVar3, in_R8 & 0xffffffff, in_R9);
        if (iVar2 == 0) {
            if (iVar4 != 0) {
                *in_RDX = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025a83d;
                func_0x00018022ecc0(iVar4);
            }
            uVar3 = 0;
        } else {
            uVar3 = 1;
        }
    }
    return uVar3;
}

// ============================================================
// Function: FUN_18025a8a0
// Address: 0x18025a8a0
// Size: 123 bytes
// ============================================================
undefined8 fcn.18025a8a0(undefined4 *param_1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025a8ac;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 != (undefined4 *)0x0) {
        if (*(int64_t *)(param_1 + 6) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025a8c3;
            fcn.180259930();
            if (*(int64_t *)(param_1 + 8) != 0) {
                *param_1 = 8;
                return 1;
            }
        }
        *param_1 = 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025a8e6;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025a8fe;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025a910;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_18025a920
// Address: 0x18025a920
// Size: 581 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.18025a920(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int32_t *in_RCX;
    int32_t **in_RDX;
    int32_t *piVar9;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_20;
    
    uStack_20 = 0x18025a932;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    piVar9 = (int32_t *)0x0;
    if (in_RDX == (int32_t **)0x0) {
        return -1;
    }
    if (in_RCX == (int32_t *)0x0) {
code_r0x00018025ab0e:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025ab13;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025ab2b;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 0x10)
                      , *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025ab3d;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
        iVar4 = -2;
    } else {
        if ((*(uint8_t *)in_RCX & 6) == 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025a959;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025a971;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar5), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 0x10), *(int64_t *)((int64_t)&arg_38h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025a983;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
            iVar4 = -1;
            goto code_r0x00018025ab4e;
        }
        piVar6 = *in_RDX;
        if (piVar6 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025a99a;
            piVar6 = (int32_t *)func_0x00018022fd80();
            *in_RDX = piVar6;
            piVar9 = piVar6;
            if (piVar6 == (int32_t *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025a9ad;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5));
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025a9c5;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8)
                              , *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 0x10), 
                              *(int64_t *)((int64_t)&arg_38h + iVar5));
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025a9d7;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
                return -1;
            }
        }
        iVar8 = *(int64_t *)(in_RCX + 0x22);
        if (*(int64_t *)(in_RCX + 10) == 0) {
            if ((iVar8 != 0) && (*(int64_t *)(iVar8 + 0x60) != 0)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025aa08;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5));
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025aa20;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar5 + -8), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar5), *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 8)
                              , *(int64_t *)((int64_t)aiStackX_10 + iVar5 + 0x10), 
                              *(int64_t *)((int64_t)&arg_38h + iVar5));
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025aa32;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar5));
                iVar4 = -1;
                goto code_r0x00018025ab42;
            }
            if (*in_RCX == 2) {
                pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x1e) + 0x28);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025aa6f;
                iVar4 = (*pcVar1)(in_RCX, piVar6);
            } else {
                if (*in_RCX != 4) goto code_r0x00018025ab0e;
                pcVar1 = *(code **)(*(int64_t *)(in_RCX + 0x1e) + 0x38);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025aa5a;
                iVar4 = (*pcVar1)(in_RCX);
            }
        } else {
            in_RCX[0x1c] = 2;
            *(int64_t *)(in_RCX + 0x1a) = (int64_t)&arg_48h + iVar5;
            if (iVar8 == 0) {
code_r0x00018025aac2:
                uVar7 = *(undefined8 *)(in_RCX + 10);
                uVar2 = *(undefined8 *)(in_RCX + 8);
                piVar6 = *in_RDX;
                *(int32_t **)((int64_t)aiStackX_10 + iVar5 + -8) = in_RCX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025aade;
                iVar8 = func_0x00018029edc0(piVar6, uVar2, uVar7, 0x18025b010);
                if (iVar8 == 0) goto code_r0x00018025aafa;
                *(undefined8 *)(in_RCX + 0x1a) = 0;
                iVar4 = 1;
                piVar6 = *in_RDX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025aaf8;
                func_0x000180231260(piVar6);
            } else {
                uVar7 = *(undefined8 *)(in_RCX + 4);
                uVar2 = *(undefined8 *)(in_RCX + 2);
                *(undefined8 *)((int64_t)&arg_40h + iVar5) = *(undefined8 *)(in_RCX + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025aaa6;
                uVar7 = func_0x000180230ea0(iVar8, uVar2, (int64_t)&arg_40h + iVar5, uVar7);
                if (*(int64_t *)((int64_t)&arg_40h + iVar5) == 0) goto code_r0x00018025ab0e;
                uVar2 = *(undefined8 *)(in_RCX + 10);
                uVar3 = *(undefined8 *)(in_RCX + 8);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025aabe;
                iVar4 = func_0x000180257e40(uVar3, uVar2, uVar7);
                if (iVar4 != 0) goto code_r0x00018025aac2;
code_r0x00018025aafa:
                iVar4 = 0;
                *(undefined8 *)(in_RCX + 0x1a) = 0;
            }
            **in_RDX = in_RCX[0x1d];
        }
        if (0 < iVar4) {
            return iVar4;
        }
    }
code_r0x00018025ab42:
    if (piVar9 != (int32_t *)0x0) {
        *in_RDX = (int32_t *)0x0;
    }
code_r0x00018025ab4e:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18025ab56;
    func_0x00018022ecc0(piVar9);
    return iVar4;
}

// ============================================================
// Function: FUN_18025ab70
// Address: 0x18025ab70
// Size: 84 bytes
// ============================================================
int32_t fcn.18025ab70(int32_t *param_1, int32_t **param_2)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 unaff_RBX;
    int32_t *piVar10;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iStack_8;
    
    iStack_8 = 0x18025ab7a;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    if (*param_1 != 4) {
        *(undefined8 *)((int64_t)&iStack_8 + iVar9) = 0x18025ab87;
        fcn.180229480(*(int64_t *)(&stack0x00000020 + iVar9), *(int64_t *)(&stack0x00000028 + iVar9));
        *(undefined8 *)((int64_t)&iStack_8 + iVar9) = 0x18025ab9f;
        fcn.1802295a0(*(int64_t *)(&stack0x00000020 + iVar9), *(int64_t *)(&stack0x00000028 + iVar9), 
                      *(int64_t *)(&stack0x00000030 + iVar9), *(int64_t *)(&stack0x00000038 + iVar9), 
                      *(int64_t *)(&stack0x00000050 + iVar9));
        *(undefined8 *)((int64_t)&iStack_8 + iVar9) = 0x18025abb1;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar9));
        return -1;
    }
    *(undefined8 *)(&stack0x00000030 + iVar9) = unaff_RBX;
    *(undefined8 *)(&stack0x00000020 + iVar9) = unaff_RBP;
    *(undefined8 *)(&stack0x00000018 + iVar9) = unaff_RSI;
    *(undefined8 *)(&stack0x00000010 + iVar9) = unaff_RDI;
    *(undefined8 *)(&stack0x00000008 + iVar9) = 0x18025a932;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    piVar10 = (int32_t *)0x0;
    if (param_2 == (int32_t **)0x0) {
        return -1;
    }
    if (param_1 == (int32_t *)0x0) {
code_r0x00018025ab0e:
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025ab13;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar5 + iVar9), *(int64_t *)(&stack0x00000038 + iVar5 + iVar9));
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025ab2b;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar5 + iVar9), *(int64_t *)(&stack0x00000038 + iVar5 + iVar9), 
                      *(int64_t *)(&stack0x00000040 + iVar5 + iVar9), *(int64_t *)(&stack0x00000048 + iVar5 + iVar9), 
                      *(int64_t *)(&stack0x00000060 + iVar5 + iVar9));
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025ab3d;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar9));
        iVar4 = -2;
    } else {
        if ((*(uint8_t *)param_1 & 6) == 0) {
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025a959;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar5 + iVar9), *(int64_t *)(&stack0x00000038 + iVar5 + iVar9)
                         );
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025a971;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar5 + iVar9), *(int64_t *)(&stack0x00000038 + iVar5 + iVar9)
                          , *(int64_t *)(&stack0x00000040 + iVar5 + iVar9), 
                          *(int64_t *)(&stack0x00000048 + iVar5 + iVar9), *(int64_t *)(&stack0x00000060 + iVar5 + iVar9)
                         );
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025a983;
            fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar9));
            iVar4 = -1;
            goto code_r0x00018025ab4e;
        }
        piVar6 = *param_2;
        if (piVar6 == (int32_t *)0x0) {
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025a99a;
            piVar6 = (int32_t *)func_0x00018022fd80();
            *param_2 = piVar6;
            piVar10 = piVar6;
            if (piVar6 == (int32_t *)0x0) {
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025a9ad;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000038 + iVar5 + iVar9));
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025a9c5;
                fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000038 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000040 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000060 + iVar5 + iVar9));
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025a9d7;
                fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar9));
                return -1;
            }
        }
        iVar8 = *(int64_t *)(param_1 + 0x22);
        if (*(int64_t *)(param_1 + 10) == 0) {
            if ((iVar8 != 0) && (*(int64_t *)(iVar8 + 0x60) != 0)) {
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025aa08;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000038 + iVar5 + iVar9));
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025aa20;
                fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000038 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000040 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000060 + iVar5 + iVar9));
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025aa32;
                fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar9));
                iVar4 = -1;
                goto code_r0x00018025ab42;
            }
            if (*param_1 == 2) {
                pcVar1 = *(code **)(*(int64_t *)(param_1 + 0x1e) + 0x28);
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025aa6f;
                iVar4 = (*pcVar1)(param_1, piVar6);
            } else {
                if (*param_1 != 4) goto code_r0x00018025ab0e;
                pcVar1 = *(code **)(*(int64_t *)(param_1 + 0x1e) + 0x38);
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025aa5a;
                iVar4 = (*pcVar1)(param_1);
            }
        } else {
            param_1[0x1c] = 2;
            *(undefined **)(param_1 + 0x1a) = &stack0x00000070 + iVar5 + iVar9;
            if (iVar8 == 0) {
code_r0x00018025aac2:
                uVar7 = *(undefined8 *)(param_1 + 10);
                uVar2 = *(undefined8 *)(param_1 + 8);
                piVar6 = *param_2;
                *(int32_t **)(&stack0x00000030 + iVar5 + iVar9) = param_1;
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025aade;
                iVar8 = func_0x00018029edc0(piVar6, uVar2, uVar7, 0x18025b010);
                if (iVar8 == 0) goto code_r0x00018025aafa;
                *(undefined8 *)(param_1 + 0x1a) = 0;
                iVar4 = 1;
                piVar6 = *param_2;
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025aaf8;
                func_0x000180231260(piVar6);
            } else {
                uVar7 = *(undefined8 *)(param_1 + 4);
                uVar2 = *(undefined8 *)(param_1 + 2);
                *(undefined8 *)(&stack0x00000068 + iVar5 + iVar9) = *(undefined8 *)(param_1 + 8);
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025aaa6;
                uVar7 = func_0x000180230ea0(iVar8, uVar2, &stack0x00000068 + iVar5 + iVar9, uVar7);
                if (*(int64_t *)(&stack0x00000068 + iVar5 + iVar9) == 0) goto code_r0x00018025ab0e;
                uVar2 = *(undefined8 *)(param_1 + 10);
                uVar3 = *(undefined8 *)(param_1 + 8);
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025aabe;
                iVar4 = func_0x000180257e40(uVar3, uVar2, uVar7);
                if (iVar4 != 0) goto code_r0x00018025aac2;
code_r0x00018025aafa:
                iVar4 = 0;
                *(undefined8 *)(param_1 + 0x1a) = 0;
            }
            **param_2 = param_1[0x1d];
        }
        if (0 < iVar4) {
            return iVar4;
        }
    }
code_r0x00018025ab42:
    if (piVar10 != (int32_t *)0x0) {
        *param_2 = (int32_t *)0x0;
    }
code_r0x00018025ab4e:
    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025ab56;
    func_0x00018022ecc0(piVar10);
    return iVar4;
}

// ============================================================
// Function: FUN_18025abd0
// Address: 0x18025abd0
// Size: 276 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18025abd0(int64_t arg_28h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined4 *in_RCX;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025abe0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar5 = 0;
    if (in_RCX == (undefined4 *)0x0) {
code_r0x00018025ac90:
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025ac95;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025acad;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025acbf;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        uVar5 = 0xfffffffe;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025abf6;
        fcn.180259930();
        iVar3 = *(int64_t *)(in_RCX + 8);
        *in_RCX = 4;
        if ((iVar3 != 0) && (*(int64_t *)(iVar3 + 0x60) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025ac18;
            iVar3 = func_0x000180257db0(iVar3, 3, 0);
            *(int64_t *)(in_RCX + 10) = iVar3;
            if (iVar3 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025ac26;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025ac3e;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025ac50;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
            goto code_r0x00018025acc9;
        }
        iVar3 = *(int64_t *)(in_RCX + 0x1e);
        if ((iVar3 == 0) || (*(int64_t *)(iVar3 + 0x38) == 0)) goto code_r0x00018025ac90;
        pcVar1 = *(code **)(iVar3 + 0x30);
        if (pcVar1 == (code *)0x0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025ac7f;
        uVar4 = (*pcVar1)(in_RCX);
        uVar5 = uVar4 & 0xffffffff;
        if (0 < (int32_t)uVar4) {
            return uVar4;
        }
    }
    if (in_RCX == (undefined4 *)0x0) {
        return uVar5;
    }
code_r0x00018025acc9:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025acd1;
    fcn.180259930(in_RCX);
    *in_RCX = 0;
    return uVar5;
}

// ============================================================
// Function: FUN_18025acf0
// Address: 0x18025acf0
// Size: 371 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18025acf0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025ad0a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = 0;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar3 + -8) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025ad1f;
    piVar4 = (int32_t *)fcn.180259240(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8));
    if (piVar4 == (int32_t *)0x0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025ad33;
    fcn.180259930(piVar4);
    iVar5 = *(int64_t *)(piVar4 + 8);
    *piVar4 = 4;
    if ((iVar5 == 0) || (*(int64_t *)(iVar5 + 0x60) == 0)) {
        iVar5 = *(int64_t *)(piVar4 + 0x1e);
        if ((iVar5 == 0) || (*(int64_t *)(iVar5 + 0x38) == 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025ae0f;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025ae27;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            goto code_r0x00018025ae2c;
        }
        pcVar1 = *(code **)(iVar5 + 0x30);
        if (pcVar1 == (code *)0x0) {
code_r0x00018025adaa:
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025adb8;
            iVar2 = fcn.1802592a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            if (0 < iVar2) {
                if (*piVar4 == 4) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025ae03;
                    fcn.18025a920(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar3));
                    uVar6 = *(undefined8 *)((int64_t)&iStackX_20 + iVar3 + -8);
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025adca;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025ade2;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025adf4;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
                }
            }
            goto code_r0x00018025ae43;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025ada2;
        iVar2 = (*pcVar1)(piVar4);
        if (0 < iVar2) goto code_r0x00018025adaa;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025ad55;
        iVar5 = func_0x000180257db0(iVar5, 3, 0);
        *(int64_t *)(piVar4 + 10) = iVar5;
        if (iVar5 != 0) goto code_r0x00018025adaa;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025ad63;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025ad7b;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
code_r0x00018025ae2c:
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025ae39;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025ae41;
    fcn.180259930(piVar4);
    *piVar4 = 0;
code_r0x00018025ae43:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025ae4b;
    func_0x000180258be0(piVar4);
    return uVar6;
}

// ============================================================
// Function: FUN_18025ae70
// Address: 0x18025ae70
// Size: 84 bytes
// ============================================================
int32_t fcn.18025ae70(int32_t *param_1, int32_t **param_2)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    undefined8 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 unaff_RBX;
    int32_t *piVar10;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iStack_8;
    
    iStack_8 = 0x18025ae7a;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    if (*param_1 != 2) {
        *(undefined8 *)((int64_t)&iStack_8 + iVar9) = 0x18025ae87;
        fcn.180229480(*(int64_t *)(&stack0x00000020 + iVar9), *(int64_t *)(&stack0x00000028 + iVar9));
        *(undefined8 *)((int64_t)&iStack_8 + iVar9) = 0x18025ae9f;
        fcn.1802295a0(*(int64_t *)(&stack0x00000020 + iVar9), *(int64_t *)(&stack0x00000028 + iVar9), 
                      *(int64_t *)(&stack0x00000030 + iVar9), *(int64_t *)(&stack0x00000038 + iVar9), 
                      *(int64_t *)(&stack0x00000050 + iVar9));
        *(undefined8 *)((int64_t)&iStack_8 + iVar9) = 0x18025aeb1;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar9));
        return -1;
    }
    *(undefined8 *)(&stack0x00000030 + iVar9) = unaff_RBX;
    *(undefined8 *)(&stack0x00000020 + iVar9) = unaff_RBP;
    *(undefined8 *)(&stack0x00000018 + iVar9) = unaff_RSI;
    *(undefined8 *)(&stack0x00000010 + iVar9) = unaff_RDI;
    *(undefined8 *)(&stack0x00000008 + iVar9) = 0x18025a932;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    piVar10 = (int32_t *)0x0;
    if (param_2 == (int32_t **)0x0) {
        return -1;
    }
    if (param_1 == (int32_t *)0x0) {
code_r0x00018025ab0e:
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025ab13;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar5 + iVar9), *(int64_t *)(&stack0x00000038 + iVar5 + iVar9));
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025ab2b;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar5 + iVar9), *(int64_t *)(&stack0x00000038 + iVar5 + iVar9), 
                      *(int64_t *)(&stack0x00000040 + iVar5 + iVar9), *(int64_t *)(&stack0x00000048 + iVar5 + iVar9), 
                      *(int64_t *)(&stack0x00000060 + iVar5 + iVar9));
        *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025ab3d;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar9));
        iVar4 = -2;
    } else {
        if ((*(uint8_t *)param_1 & 6) == 0) {
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025a959;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar5 + iVar9), *(int64_t *)(&stack0x00000038 + iVar5 + iVar9)
                         );
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025a971;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar5 + iVar9), *(int64_t *)(&stack0x00000038 + iVar5 + iVar9)
                          , *(int64_t *)(&stack0x00000040 + iVar5 + iVar9), 
                          *(int64_t *)(&stack0x00000048 + iVar5 + iVar9), *(int64_t *)(&stack0x00000060 + iVar5 + iVar9)
                         );
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025a983;
            fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar9));
            iVar4 = -1;
            goto code_r0x00018025ab4e;
        }
        piVar6 = *param_2;
        if (piVar6 == (int32_t *)0x0) {
            *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025a99a;
            piVar6 = (int32_t *)func_0x00018022fd80();
            *param_2 = piVar6;
            piVar10 = piVar6;
            if (piVar6 == (int32_t *)0x0) {
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025a9ad;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000038 + iVar5 + iVar9));
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025a9c5;
                fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000038 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000040 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000060 + iVar5 + iVar9));
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025a9d7;
                fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar9));
                return -1;
            }
        }
        iVar8 = *(int64_t *)(param_1 + 0x22);
        if (*(int64_t *)(param_1 + 10) == 0) {
            if ((iVar8 != 0) && (*(int64_t *)(iVar8 + 0x60) != 0)) {
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025aa08;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000038 + iVar5 + iVar9));
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025aa20;
                fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000038 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000040 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar9), 
                              *(int64_t *)(&stack0x00000060 + iVar5 + iVar9));
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025aa32;
                fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar9));
                iVar4 = -1;
                goto code_r0x00018025ab42;
            }
            if (*param_1 == 2) {
                pcVar1 = *(code **)(*(int64_t *)(param_1 + 0x1e) + 0x28);
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025aa6f;
                iVar4 = (*pcVar1)(param_1, piVar6);
            } else {
                if (*param_1 != 4) goto code_r0x00018025ab0e;
                pcVar1 = *(code **)(*(int64_t *)(param_1 + 0x1e) + 0x38);
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025aa5a;
                iVar4 = (*pcVar1)(param_1);
            }
        } else {
            param_1[0x1c] = 2;
            *(undefined **)(param_1 + 0x1a) = &stack0x00000070 + iVar5 + iVar9;
            if (iVar8 == 0) {
code_r0x00018025aac2:
                uVar7 = *(undefined8 *)(param_1 + 10);
                uVar2 = *(undefined8 *)(param_1 + 8);
                piVar6 = *param_2;
                *(int32_t **)(&stack0x00000030 + iVar5 + iVar9) = param_1;
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025aade;
                iVar8 = func_0x00018029edc0(piVar6, uVar2, uVar7, 0x18025b010);
                if (iVar8 == 0) goto code_r0x00018025aafa;
                *(undefined8 *)(param_1 + 0x1a) = 0;
                iVar4 = 1;
                piVar6 = *param_2;
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025aaf8;
                func_0x000180231260(piVar6);
            } else {
                uVar7 = *(undefined8 *)(param_1 + 4);
                uVar2 = *(undefined8 *)(param_1 + 2);
                *(undefined8 *)(&stack0x00000068 + iVar5 + iVar9) = *(undefined8 *)(param_1 + 8);
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025aaa6;
                uVar7 = func_0x000180230ea0(iVar8, uVar2, &stack0x00000068 + iVar5 + iVar9, uVar7);
                if (*(int64_t *)(&stack0x00000068 + iVar5 + iVar9) == 0) goto code_r0x00018025ab0e;
                uVar2 = *(undefined8 *)(param_1 + 10);
                uVar3 = *(undefined8 *)(param_1 + 8);
                *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025aabe;
                iVar4 = func_0x000180257e40(uVar3, uVar2, uVar7);
                if (iVar4 != 0) goto code_r0x00018025aac2;
code_r0x00018025aafa:
                iVar4 = 0;
                *(undefined8 *)(param_1 + 0x1a) = 0;
            }
            **param_2 = param_1[0x1d];
        }
        if (0 < iVar4) {
            return iVar4;
        }
    }
code_r0x00018025ab42:
    if (piVar10 != (int32_t *)0x0) {
        *param_2 = (int32_t *)0x0;
    }
code_r0x00018025ab4e:
    *(undefined8 *)(&stack0x00000008 + iVar5 + iVar9) = 0x18025ab56;
    func_0x00018022ecc0(piVar10);
    return iVar4;
}

// ============================================================
// Function: FUN_18025aed0
// Address: 0x18025aed0
// Size: 276 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18025aed0(int64_t arg_28h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined4 *in_RCX;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025aee0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar5 = 0;
    if (in_RCX == (undefined4 *)0x0) {
code_r0x00018025af90:
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025af95;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025afad;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025afbf;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        uVar5 = 0xfffffffe;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025aef6;
        fcn.180259930();
        iVar3 = *(int64_t *)(in_RCX + 8);
        *in_RCX = 2;
        if ((iVar3 != 0) && (*(int64_t *)(iVar3 + 0x60) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025af18;
            iVar3 = func_0x000180257db0(iVar3, 0x84, 0);
            *(int64_t *)(in_RCX + 10) = iVar3;
            if (iVar3 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025af26;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025af3e;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025af50;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
            goto code_r0x00018025afc9;
        }
        iVar3 = *(int64_t *)(in_RCX + 0x1e);
        if ((iVar3 == 0) || (*(int64_t *)(iVar3 + 0x28) == 0)) goto code_r0x00018025af90;
        pcVar1 = *(code **)(iVar3 + 0x20);
        if (pcVar1 == (code *)0x0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025af7f;
        uVar4 = (*pcVar1)(in_RCX);
        uVar5 = uVar4 & 0xffffffff;
        if (0 < (int32_t)uVar4) {
            return uVar4;
        }
    }
    if (in_RCX == (undefined4 *)0x0) {
        return uVar5;
    }
code_r0x00018025afc9:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025afd1;
    fcn.180259930(in_RCX);
    *in_RCX = 0;
    return uVar5;
}

// ============================================================
// Function: FUN_18025aff0
// Address: 0x18025aff0
// Size: 32 bytes
// ============================================================
void fcn.18025aff0(undefined4 *param_1, undefined8 param_2)
{
    fcn.18045a350();
    *param_1 = 2;
    *(undefined8 *)(param_1 + 2) = param_2;
    *(undefined8 *)(param_1 + 4) = 0x18025b0f0;
    return;
}

// ============================================================
// Function: FUN_18025b010
// Address: 0x18025b010
// Size: 189 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18025b010(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_60h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025b020;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = *(int64_t *)(in_RDX + 0x60);
    *(undefined4 *)((int64_t)&arg_30h + iVar3) = 0xffffffff;
    *(undefined4 *)((int64_t)&arg_38h + iVar3) = 0xffffffff;
    if (iVar4 == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025b05c;
    iVar4 = fcn.18022ae60(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025b06e;
        iVar2 = fcn.180229fc0(*(int64_t *)((int64_t)&arg_60h + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025b081;
            iVar4 = fcn.18022ae60(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025b093;
                iVar2 = fcn.180229fc0(*(int64_t *)((int64_t)&arg_60h + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
                if (iVar2 != 0) {
                    **(undefined4 **)(in_RDX + 0x68) = *(undefined4 *)((int64_t)&arg_30h + iVar3);
                    *(undefined4 *)(*(int64_t *)(in_RDX + 0x68) + 4) = *(undefined4 *)((int64_t)&arg_38h + iVar3);
                    pcVar1 = *(code **)(in_RDX + 0x60);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025b0b5;
                    uVar5 = (*pcVar1)(in_RDX);
                    return uVar5;
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18025b0d0
// Address: 0x18025b0d0
// Size: 30 bytes
// ============================================================
void fcn.18025b0d0(code **param_1, undefined8 param_2, undefined8 param_3)
{
    fcn.18045a350();
    // WARNING: Could not recover jumptable at 0x00018025b0eb. Too many branches
    // WARNING: Treating indirect jump as call
    (**param_1)(param_3, param_1[1]);
    return;
}

// ============================================================
// Function: FUN_18025b0f0
// Address: 0x18025b0f0
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18025b0f0(int64_t arg_28h)
{
    int64_t iVar1;
    undefined4 in_ECX;
    undefined4 in_EDX;
    undefined8 in_R8;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025b100;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x18025b10f;
    iVar1 = func_0x0001801bc820(in_R8);
    **(undefined4 **)(iVar1 + 0x68) = in_ECX;
    *(undefined4 *)(*(int64_t *)(iVar1 + 0x68) + 4) = in_EDX;
    // WARNING: Could not recover jumptable at 0x00018025b12e. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(iVar1 + 0x60))(iVar1, *(code **)(iVar1 + 0x60));
    return;
}

// ============================================================
// Function: FUN_18025b140
// Address: 0x18025b140
// Size: 22 bytes
// ============================================================
undefined4 fcn.18025b140(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint8_t *puVar8;
    undefined8 uVar9;
    undefined8 in_RCX;
    code *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int32_t iVar10;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined4 uVar11;
    undefined8 unaff_R15;
    int64_t iStack_8;
    
    iStack_8 = 0x18025b14a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00000020 + iVar4) = unaff_RBX;
    *(undefined8 *)(&stack0x00000018 + iVar4) = unaff_R12;
    *(undefined8 *)(&stack0x00000010 + iVar4) = unaff_R13;
    *(undefined8 *)(&stack0x00000008 + iVar4) = unaff_R14;
    *(undefined8 *)(&stack0x00000020 + iVar4 + -0x20) = unaff_R15;
    *(undefined8 *)((int64_t)&iStack_8 + iVar4) = 0x18027ea04;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar11 = 0;
    *(undefined4 *)((int64_t)&arg_68h + iVar5 + iVar4) = 0;
    *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027ea22;
    iVar6 = func_0x000180245b40();
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027ea2f;
        fcn.180229480(*(int64_t *)(&stack0x00000020 + iVar5 + iVar4), *(int64_t *)(&stack0x00000028 + iVar5 + iVar4));
        *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027ea47;
        fcn.1802295a0(*(int64_t *)(&stack0x00000020 + iVar5 + iVar4), *(int64_t *)(&stack0x00000028 + iVar5 + iVar4), 
                      *(int64_t *)(&stack0x00000030 + iVar5 + iVar4), *(int64_t *)(&stack0x00000038 + iVar5 + iVar4), 
                      *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4));
        *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027ea59;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4));
    }
    *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027ea61;
    iVar2 = func_0x000180245d70(in_RCX);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027ea71;
        fcn.180243560(*(int64_t *)(&stack0x00000020 + iVar5 + iVar4), *(int64_t *)(&stack0x00000028 + iVar5 + iVar4), 
                      *(int64_t *)(&stack0x00000030 + iVar5 + iVar4), *(int64_t *)(&stack0x00000038 + iVar5 + iVar4));
    }
    if (iVar6 == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027ea91;
    iVar2 = func_0x00018027fce0(iVar6);
    if (iVar2 != 0) {
        uVar9 = *(undefined8 *)(iVar6 + 0x20);
        *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027eaa2;
        iVar2 = func_0x000180222850(uVar9);
        if (iVar2 != 0) {
            uVar9 = *(undefined8 *)(iVar6 + 8);
            *(undefined8 *)((int64_t)&arg_50h + iVar5 + iVar4) = unaff_RBP;
            *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027eab8;
            iVar7 = func_0x000180221950(uVar9);
            if (iVar7 == 0) {
                uVar9 = *(undefined8 *)(iVar6 + 0x20);
                *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027eac9;
                fcn.180222910(uVar9);
                return 0;
            }
            *(undefined8 *)((int64_t)&arg_58h + iVar5 + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_60h + iVar5 + iVar4) = unaff_RDI;
            *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027eaf0;
            iVar2 = func_0x000180222010(iVar7);
            iVar10 = iVar2;
            do {
                iVar2 = iVar2 + -1;
                if (iVar2 < 0) {
                    uVar9 = *(undefined8 *)(iVar6 + 0x20);
                    *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027eb95;
                    fcn.180222910(uVar9);
                    iVar2 = 0;
                    if (0 < iVar10) {
                        do {
                            *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027ebaa;
                            uVar9 = fcn.180222340(iVar7, iVar2);
                            *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027ebb3;
                            iVar3 = (*in_RDX)(uVar9, in_R8);
                            if (iVar3 == 0) {
                                iVar2 = 0;
                                goto code_r0x00018027ebd2;
                            }
                            iVar2 = iVar2 + 1;
                        } while (iVar2 < iVar10);
                    }
                    iVar2 = -1;
                    uVar11 = 1;
joined_r0x00018027ebcc:
                    while (iVar2 = iVar2 + 1, iVar2 < iVar10) {
code_r0x00018027ebd2:
                        *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027ebdc;
                        iVar6 = fcn.180222340(iVar7, iVar2);
                        uVar9 = *(undefined8 *)(iVar6 + 0x18);
                        *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027ebf6;
                        iVar3 = func_0x000180222980(iVar6 + 0x20, 0xffffffff, (int64_t)&arg_68h + iVar5 + iVar4, uVar9);
                        if (iVar3 == 0) {
                            uVar11 = 0;
                        } else {
                            if (*(int32_t *)((int64_t)&arg_68h + iVar5 + iVar4) < 1) {
                                uVar9 = *(undefined8 *)(iVar6 + 0x18);
                                *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027ec21;
                                iVar3 = func_0x000180222980(iVar6 + 0x20, 1, (int64_t)&arg_68h + iVar5 + iVar4, uVar9);
                                if (iVar3 == 0) {
                                    uVar11 = 0;
                                } else {
                                    *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027ec35;
                                    func_0x00018027fe80(iVar6, 0, 1);
                                }
                            }
                            LOCK();
                            piVar1 = (int32_t *)(iVar6 + 0x10);
                            iVar3 = *piVar1;
                            *piVar1 = *piVar1 + -1;
                            UNLOCK();
                            *(int32_t *)((int64_t)&arg_68h + iVar5 + iVar4) = iVar3 + -1;
                        }
                    }
                    *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027ec58;
                    func_0x000180221d50(iVar7);
                    return uVar11;
                }
                *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027eb0a;
                puVar8 = (uint8_t *)fcn.180222340(iVar7, iVar2);
                uVar9 = *(undefined8 *)(puVar8 + 8);
                *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027eb16;
                iVar3 = func_0x000180222850(uVar9);
                if (iVar3 == 0) {
code_r0x00018027eb63:
                    uVar9 = *(undefined8 *)(iVar6 + 0x20);
                    *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027eb6c;
                    fcn.180222910(uVar9);
                    goto joined_r0x00018027ebcc;
                }
                if ((*puVar8 & 2) == 0) {
                    *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027eb78;
                    func_0x000180221890(iVar7, iVar2);
                    iVar10 = iVar10 + -1;
                } else {
                    LOCK();
                    piVar1 = (int32_t *)(puVar8 + 0x10);
                    iVar3 = *piVar1;
                    *piVar1 = *piVar1 + 1;
                    UNLOCK();
                    *(int32_t *)((int64_t)&arg_68h + iVar5 + iVar4) = iVar3 + 1;
                    uVar9 = *(undefined8 *)(puVar8 + 0x18);
                    *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027eb46;
                    iVar3 = func_0x000180222980(puVar8 + 0x20, 1, (int64_t)&arg_68h + iVar5 + iVar4, uVar9);
                    if (iVar3 == 0) {
                        LOCK();
                        piVar1 = (int32_t *)(puVar8 + 0x10);
                        iVar3 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        *(int32_t *)((int64_t)&arg_68h + iVar5 + iVar4) = iVar3 + -1;
                        uVar9 = *(undefined8 *)(puVar8 + 8);
                        *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027eb63;
                        fcn.180222910(uVar9);
                        goto code_r0x00018027eb63;
                    }
                }
                uVar9 = *(undefined8 *)(puVar8 + 8);
                *(undefined8 *)((int64_t)&iStack_8 + iVar5 + iVar4) = 0x18027eb83;
                fcn.180222910(uVar9);
            } while( true );
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18025b160
// Address: 0x18025b160
// Size: 22 bytes
// ============================================================
undefined8 fcn.18025b160(int64_t param_1)
{
    fcn.18045a350();
    if (param_1 != 0) {
        return *(undefined8 *)(param_1 + 0xe0);
    }
    return 0;
}

