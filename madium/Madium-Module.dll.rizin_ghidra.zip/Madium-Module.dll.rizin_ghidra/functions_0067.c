// Chunk 67 - 50 functions

// ============================================================
// Function: FUN_1800d5050
// Address: 0x1800d5050
// Size: 70 bytes
// ============================================================
void fcn.1800d5050(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x188))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x20))(*(undefined8 **)(arg1 + 0x20), arg2);
        (**(code **)**(undefined8 **)(arg1 + 0x28))(*(undefined8 **)(arg1 + 0x28), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d50a0
// Address: 0x1800d50a0
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d50a0(int64_t arg1, int64_t arg2, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h,
                  int64_t arg_68h)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    char cVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar3 = (**(code **)(*(int64_t *)arg2 + 0x180))(arg2, arg1);
    if (cVar3 != '\0') {
        piVar4 = *(int64_t **)(arg1 + 0x58);
        piVar1 = piVar4 + *(int64_t *)(arg1 + 0x60);
        for (; piVar4 != piVar1; piVar4 = piVar4 + 1) {
            puVar2 = *(undefined8 **)(*piVar4 + 0x38);
            if (puVar2 != (undefined8 *)0x0) {
                (**(code **)*puVar2)(puVar2, arg2);
            }
        }
        puVar2 = *(undefined8 **)(arg1 + 0x88);
        if (puVar2 != (undefined8 *)0x0) {
            (**(code **)*puVar2)(puVar2, arg2);
        }
        puVar2 = *(undefined8 **)(arg1 + 0x68);
        if (puVar2 != (undefined8 *)0x0) {
            (**(code **)*puVar2)(puVar2, arg2);
        }
        (**(code **)**(undefined8 **)(arg1 + 0x90))(*(undefined8 **)(arg1 + 0x90), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d50c7
// Address: 0x1800d50c7
// Size: 76 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d50a0(int64_t arg1, int64_t arg2, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h,
                  int64_t arg_68h)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    char cVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar3 = (**(code **)(*(int64_t *)arg2 + 0x180))(arg2, arg1);
    if (cVar3 != '\0') {
        piVar4 = *(int64_t **)(arg1 + 0x58);
        piVar1 = piVar4 + *(int64_t *)(arg1 + 0x60);
        for (; piVar4 != piVar1; piVar4 = piVar4 + 1) {
            puVar2 = *(undefined8 **)(*piVar4 + 0x38);
            if (puVar2 != (undefined8 *)0x0) {
                (**(code **)*puVar2)(puVar2, arg2);
            }
        }
        puVar2 = *(undefined8 **)(arg1 + 0x88);
        if (puVar2 != (undefined8 *)0x0) {
            (**(code **)*puVar2)(puVar2, arg2);
        }
        puVar2 = *(undefined8 **)(arg1 + 0x68);
        if (puVar2 != (undefined8 *)0x0) {
            (**(code **)*puVar2)(puVar2, arg2);
        }
        (**(code **)**(undefined8 **)(arg1 + 0x90))(*(undefined8 **)(arg1 + 0x90), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5113
// Address: 0x1800d5113
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d50a0(int64_t arg1, int64_t arg2, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h,
                  int64_t arg_68h)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    char cVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar3 = (**(code **)(*(int64_t *)arg2 + 0x180))(arg2, arg1);
    if (cVar3 != '\0') {
        piVar4 = *(int64_t **)(arg1 + 0x58);
        piVar1 = piVar4 + *(int64_t *)(arg1 + 0x60);
        for (; piVar4 != piVar1; piVar4 = piVar4 + 1) {
            puVar2 = *(undefined8 **)(*piVar4 + 0x38);
            if (puVar2 != (undefined8 *)0x0) {
                (**(code **)*puVar2)(puVar2, arg2);
            }
        }
        puVar2 = *(undefined8 **)(arg1 + 0x88);
        if (puVar2 != (undefined8 *)0x0) {
            (**(code **)*puVar2)(puVar2, arg2);
        }
        puVar2 = *(undefined8 **)(arg1 + 0x68);
        if (puVar2 != (undefined8 *)0x0) {
            (**(code **)*puVar2)(puVar2, arg2);
        }
        (**(code **)**(undefined8 **)(arg1 + 0x90))(*(undefined8 **)(arg1 + 0x90), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5150
// Address: 0x1800d5150
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5150(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined8 *puVar2;
    char cVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar3 = (**(code **)(*(int64_t *)arg2 + 0x178))(arg2, arg1);
    if (cVar3 != '\0') {
        iVar4 = *(int64_t *)(arg1 + 0x20);
        iVar1 = iVar4 + *(int64_t *)(arg1 + 0x28) * 0x18;
        for (; iVar4 != iVar1; iVar4 = iVar4 + 0x18) {
            puVar2 = *(undefined8 **)(iVar4 + 8);
            if (puVar2 != (undefined8 *)0x0) {
                (**(code **)*puVar2)(puVar2, arg2);
            }
            (**(code **)**(undefined8 **)(iVar4 + 0x10))(*(undefined8 **)(iVar4 + 0x10), arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5177
// Address: 0x1800d5177
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5150(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined8 *puVar2;
    char cVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar3 = (**(code **)(*(int64_t *)arg2 + 0x178))(arg2, arg1);
    if (cVar3 != '\0') {
        iVar4 = *(int64_t *)(arg1 + 0x20);
        iVar1 = iVar4 + *(int64_t *)(arg1 + 0x28) * 0x18;
        for (; iVar4 != iVar1; iVar4 = iVar4 + 0x18) {
            puVar2 = *(undefined8 **)(iVar4 + 8);
            if (puVar2 != (undefined8 *)0x0) {
                (**(code **)*puVar2)(puVar2, arg2);
            }
            (**(code **)**(undefined8 **)(iVar4 + 0x10))(*(undefined8 **)(iVar4 + 0x10), arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d51bb
// Address: 0x1800d51bb
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5150(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined8 *puVar2;
    char cVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar3 = (**(code **)(*(int64_t *)arg2 + 0x178))(arg2, arg1);
    if (cVar3 != '\0') {
        iVar4 = *(int64_t *)(arg1 + 0x20);
        iVar1 = iVar4 + *(int64_t *)(arg1 + 0x28) * 0x18;
        for (; iVar4 != iVar1; iVar4 = iVar4 + 0x18) {
            puVar2 = *(undefined8 **)(iVar4 + 8);
            if (puVar2 != (undefined8 *)0x0) {
                (**(code **)*puVar2)(puVar2, arg2);
            }
            (**(code **)**(undefined8 **)(iVar4 + 0x10))(*(undefined8 **)(iVar4 + 0x10), arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d51d0
// Address: 0x1800d51d0
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d51d0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x170))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x28))(*(undefined8 **)(arg1 + 0x28), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5210
// Address: 0x1800d5210
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d5210(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x168))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x28))(*(undefined8 **)(arg1 + 0x28), arg2);
        (**(code **)**(undefined8 **)(arg1 + 0x30))(*(undefined8 **)(arg1 + 0x30), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5260
// Address: 0x1800d5260
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d5260(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x160))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x20))(*(undefined8 **)(arg1 + 0x20), arg2);
        (**(code **)**(undefined8 **)(arg1 + 0x28))(*(undefined8 **)(arg1 + 0x28), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d52b0
// Address: 0x1800d52b0
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d52b0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x158))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x20))(*(undefined8 **)(arg1 + 0x20), arg2);
        (**(code **)**(undefined8 **)(arg1 + 0x30))(*(undefined8 **)(arg1 + 0x30), arg2);
        (**(code **)**(undefined8 **)(arg1 + 0x40))(*(undefined8 **)(arg1 + 0x40), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5310
// Address: 0x1800d5310
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5310(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x150))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x30);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x38);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5337
// Address: 0x1800d5337
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5310(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x150))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x30);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x38);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5369
// Address: 0x1800d5369
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5310(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x150))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x30);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x38);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5380
// Address: 0x1800d5380
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5380(int64_t arg1, int64_t arg2)
{
    char cVar1;
    undefined8 *puVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x148))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x20))(*(undefined8 **)(arg1 + 0x20), arg2);
        piVar3 = *(int64_t **)(arg1 + 0x28);
        piVar4 = piVar3 + *(int64_t *)(arg1 + 0x30) * 2;
        for (; piVar3 != piVar4; piVar3 = piVar3 + 2) {
            puVar2 = (undefined8 *)*piVar3;
            if (puVar2 == (undefined8 *)0x0) {
                puVar2 = (undefined8 *)piVar3[1];
            }
            (**(code **)*puVar2)(puVar2, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d53aa
// Address: 0x1800d53aa
// Size: 72 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5380(int64_t arg1, int64_t arg2)
{
    char cVar1;
    undefined8 *puVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x148))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x20))(*(undefined8 **)(arg1 + 0x20), arg2);
        piVar3 = *(int64_t **)(arg1 + 0x28);
        piVar4 = piVar3 + *(int64_t *)(arg1 + 0x30) * 2;
        for (; piVar3 != piVar4; piVar3 = piVar3 + 2) {
            puVar2 = (undefined8 *)*piVar3;
            if (puVar2 == (undefined8 *)0x0) {
                puVar2 = (undefined8 *)piVar3[1];
            }
            (**(code **)*puVar2)(puVar2, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d53f2
// Address: 0x1800d53f2
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5380(int64_t arg1, int64_t arg2)
{
    char cVar1;
    undefined8 *puVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x148))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x20))(*(undefined8 **)(arg1 + 0x20), arg2);
        piVar3 = *(int64_t **)(arg1 + 0x28);
        piVar4 = piVar3 + *(int64_t *)(arg1 + 0x30) * 2;
        for (; piVar3 != piVar4; piVar3 = piVar3 + 2) {
            puVar2 = (undefined8 *)*piVar3;
            if (puVar2 == (undefined8 *)0x0) {
                puVar2 = (undefined8 *)piVar3[1];
            }
            (**(code **)*puVar2)(puVar2, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5400
// Address: 0x1800d5400
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5400(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x140))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x20);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x28);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5427
// Address: 0x1800d5427
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5400(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x140))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x20);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x28);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5459
// Address: 0x1800d5459
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5400(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x140))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x20);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x28);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5470
// Address: 0x1800d5470
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5470(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x130))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x28);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x30);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5497
// Address: 0x1800d5497
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5470(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x130))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x28);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x30);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d54c9
// Address: 0x1800d54c9
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5470(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x130))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x28);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x30);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d54e0
// Address: 0x1800d54e0
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d54e0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    int64_t var_8h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x128))(arg2, arg1);
    if (cVar2 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x28))(*(undefined8 **)(arg1 + 0x28), arg2);
        (**(code **)**(undefined8 **)(arg1 + 0x30))(*(undefined8 **)(arg1 + 0x30), arg2);
        puVar1 = *(undefined8 **)(arg1 + 0x38);
        if (puVar1 != (undefined8 *)0x0) {
            (**(code **)*puVar1)(puVar1, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5540
// Address: 0x1800d5540
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d5540(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x120))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x28))(*(undefined8 **)(arg1 + 0x28), arg2);
        (**(code **)**(undefined8 **)(arg1 + 0x30))(*(undefined8 **)(arg1 + 0x30), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5590
// Address: 0x1800d5590
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d5590(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x118))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x30))(*(undefined8 **)(arg1 + 0x30), arg2);
        (**(code **)**(undefined8 **)(arg1 + 0x28))(*(undefined8 **)(arg1 + 0x28), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5620
// Address: 0x1800d5620
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5620(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x100))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x28);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x30);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5647
// Address: 0x1800d5647
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5620(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x100))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x28);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x30);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5679
// Address: 0x1800d5679
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5620(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x100))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x28);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x30);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5690
// Address: 0x1800d5690
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d5690(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0xf8))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x28))(*(undefined8 **)(arg1 + 0x28), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d56d0
// Address: 0x1800d56d0
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d56d0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    char cVar3;
    int64_t *piVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar3 = (**(code **)(*(int64_t *)arg2 + 0xf0))(arg2, arg1);
    if (cVar3 != '\0') {
        piVar4 = *(int64_t **)(arg1 + 0x28);
        piVar1 = piVar4 + *(int64_t *)(arg1 + 0x30);
        for (; piVar4 != piVar1; piVar4 = piVar4 + 1) {
            puVar2 = *(undefined8 **)(*piVar4 + 0x38);
            if (puVar2 != (undefined8 *)0x0) {
                (**(code **)*puVar2)(puVar2, arg2);
            }
        }
        puVar5 = *(undefined8 **)(arg1 + 0x38);
        puVar2 = puVar5 + *(int64_t *)(arg1 + 0x40);
        for (; puVar5 != puVar2; puVar5 = puVar5 + 1) {
            (***(code ***)(undefined8 *)*puVar5)((undefined8 *)*puVar5, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d56f7
// Address: 0x1800d56f7
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d56d0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    char cVar3;
    int64_t *piVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar3 = (**(code **)(*(int64_t *)arg2 + 0xf0))(arg2, arg1);
    if (cVar3 != '\0') {
        piVar4 = *(int64_t **)(arg1 + 0x28);
        piVar1 = piVar4 + *(int64_t *)(arg1 + 0x30);
        for (; piVar4 != piVar1; piVar4 = piVar4 + 1) {
            puVar2 = *(undefined8 **)(*piVar4 + 0x38);
            if (puVar2 != (undefined8 *)0x0) {
                (**(code **)*puVar2)(puVar2, arg2);
            }
        }
        puVar5 = *(undefined8 **)(arg1 + 0x38);
        puVar2 = puVar5 + *(int64_t *)(arg1 + 0x40);
        for (; puVar5 != puVar2; puVar5 = puVar5 + 1) {
            (***(code ***)(undefined8 *)*puVar5)((undefined8 *)*puVar5, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d575e
// Address: 0x1800d575e
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d56d0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    char cVar3;
    int64_t *piVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar3 = (**(code **)(*(int64_t *)arg2 + 0xf0))(arg2, arg1);
    if (cVar3 != '\0') {
        piVar4 = *(int64_t **)(arg1 + 0x28);
        piVar1 = piVar4 + *(int64_t *)(arg1 + 0x30);
        for (; piVar4 != piVar1; piVar4 = piVar4 + 1) {
            puVar2 = *(undefined8 **)(*piVar4 + 0x38);
            if (puVar2 != (undefined8 *)0x0) {
                (**(code **)*puVar2)(puVar2, arg2);
            }
        }
        puVar5 = *(undefined8 **)(arg1 + 0x38);
        puVar2 = puVar5 + *(int64_t *)(arg1 + 0x40);
        for (; puVar5 != puVar2; puVar5 = puVar5 + 1) {
            (***(code ***)(undefined8 *)*puVar5)((undefined8 *)*puVar5, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5770
// Address: 0x1800d5770
// Size: 120 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d5770(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    int64_t var_8h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0xe8))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar1 = *(undefined8 **)(*(int64_t *)(arg1 + 0x28) + 0x38);
        if (puVar1 != (undefined8 *)0x0) {
            (**(code **)*puVar1)(puVar1, arg2);
        }
        (**(code **)**(undefined8 **)(arg1 + 0x30))(*(undefined8 **)(arg1 + 0x30), arg2);
        (**(code **)**(undefined8 **)(arg1 + 0x38))(*(undefined8 **)(arg1 + 0x38), arg2);
        puVar1 = *(undefined8 **)(arg1 + 0x40);
        if (puVar1 != (undefined8 *)0x0) {
            (**(code **)*puVar1)(puVar1, arg2);
        }
        (**(code **)**(undefined8 **)(arg1 + 0x48))(*(undefined8 **)(arg1 + 0x48), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d57f0
// Address: 0x1800d57f0
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d57f0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    char cVar3;
    int64_t *piVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    cVar3 = (**(code **)(*(int64_t *)arg2 + 0xe0))(arg2, arg1);
    if (cVar3 != '\0') {
        piVar4 = *(int64_t **)(arg1 + 0x28);
        piVar1 = piVar4 + *(int64_t *)(arg1 + 0x30);
        for (; piVar4 != piVar1; piVar4 = piVar4 + 1) {
            puVar2 = *(undefined8 **)(*piVar4 + 0x38);
            if (puVar2 != (undefined8 *)0x0) {
                (**(code **)*puVar2)(puVar2, arg2);
            }
        }
        puVar5 = *(undefined8 **)(arg1 + 0x38);
        puVar2 = puVar5 + *(int64_t *)(arg1 + 0x40);
        for (; puVar5 != puVar2; puVar5 = puVar5 + 1) {
            (***(code ***)(undefined8 *)*puVar5)((undefined8 *)*puVar5, arg2);
        }
        (**(code **)**(undefined8 **)(arg1 + 0x48))(*(undefined8 **)(arg1 + 0x48), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5817
// Address: 0x1800d5817
// Size: 115 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d57f0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    char cVar3;
    int64_t *piVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    cVar3 = (**(code **)(*(int64_t *)arg2 + 0xe0))(arg2, arg1);
    if (cVar3 != '\0') {
        piVar4 = *(int64_t **)(arg1 + 0x28);
        piVar1 = piVar4 + *(int64_t *)(arg1 + 0x30);
        for (; piVar4 != piVar1; piVar4 = piVar4 + 1) {
            puVar2 = *(undefined8 **)(*piVar4 + 0x38);
            if (puVar2 != (undefined8 *)0x0) {
                (**(code **)*puVar2)(puVar2, arg2);
            }
        }
        puVar5 = *(undefined8 **)(arg1 + 0x38);
        puVar2 = puVar5 + *(int64_t *)(arg1 + 0x40);
        for (; puVar5 != puVar2; puVar5 = puVar5 + 1) {
            (***(code ***)(undefined8 *)*puVar5)((undefined8 *)*puVar5, arg2);
        }
        (**(code **)**(undefined8 **)(arg1 + 0x48))(*(undefined8 **)(arg1 + 0x48), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d588a
// Address: 0x1800d588a
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d57f0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    char cVar3;
    int64_t *piVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    cVar3 = (**(code **)(*(int64_t *)arg2 + 0xe0))(arg2, arg1);
    if (cVar3 != '\0') {
        piVar4 = *(int64_t **)(arg1 + 0x28);
        piVar1 = piVar4 + *(int64_t *)(arg1 + 0x30);
        for (; piVar4 != piVar1; piVar4 = piVar4 + 1) {
            puVar2 = *(undefined8 **)(*piVar4 + 0x38);
            if (puVar2 != (undefined8 *)0x0) {
                (**(code **)*puVar2)(puVar2, arg2);
            }
        }
        puVar5 = *(undefined8 **)(arg1 + 0x38);
        puVar2 = puVar5 + *(int64_t *)(arg1 + 0x40);
        for (; puVar5 != puVar2; puVar5 = puVar5 + 1) {
            (***(code ***)(undefined8 *)*puVar5)((undefined8 *)*puVar5, arg2);
        }
        (**(code **)**(undefined8 **)(arg1 + 0x48))(*(undefined8 **)(arg1 + 0x48), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d58a0
// Address: 0x1800d58a0
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d58a0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0xd8))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x28);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x30);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        puVar3 = *(undefined8 **)(arg1 + 0x38);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x40);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d58c7
// Address: 0x1800d58c7
// Size: 92 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d58a0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0xd8))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x28);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x30);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        puVar3 = *(undefined8 **)(arg1 + 0x38);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x40);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5923
// Address: 0x1800d5923
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d58a0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0xd8))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x28);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x30);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        puVar3 = *(undefined8 **)(arg1 + 0x38);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x40);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5930
// Address: 0x1800d5930
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d5930(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0xd0))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x30))(*(undefined8 **)(arg1 + 0x30), arg2);
        (**(code **)**(undefined8 **)(arg1 + 0x38))(*(undefined8 **)(arg1 + 0x38), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5980
// Address: 0x1800d5980
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d5980(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 200))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x28))(*(undefined8 **)(arg1 + 0x28), arg2);
        (**(code **)**(undefined8 **)(arg1 + 0x30))(*(undefined8 **)(arg1 + 0x30), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d59d0
// Address: 0x1800d59d0
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d59d0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0xc0))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x30))(*(undefined8 **)(arg1 + 0x30), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5a10
// Address: 0x1800d5a10
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5a10(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_38h)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0xb8))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x40);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x48);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        puVar3 = *(undefined8 **)(arg1 + 0x50);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x58);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        (**(code **)**(undefined8 **)(arg1 + 0x60))(*(undefined8 **)(arg1 + 0x60), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5a37
// Address: 0x1800d5a37
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5a10(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_38h)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0xb8))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x40);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x48);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        puVar3 = *(undefined8 **)(arg1 + 0x50);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x58);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        (**(code **)**(undefined8 **)(arg1 + 0x60))(*(undefined8 **)(arg1 + 0x60), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5a9f
// Address: 0x1800d5a9f
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d5a10(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                  int64_t arg_30h, int64_t arg_38h)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0xb8))(arg2, arg1);
    if (cVar2 != '\0') {
        puVar3 = *(undefined8 **)(arg1 + 0x40);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x48);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        puVar3 = *(undefined8 **)(arg1 + 0x50);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x58);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
        (**(code **)**(undefined8 **)(arg1 + 0x60))(*(undefined8 **)(arg1 + 0x60), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5ab0
// Address: 0x1800d5ab0
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d5ab0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0xb0))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x40))(*(undefined8 **)(arg1 + 0x40), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5af0
// Address: 0x1800d5af0
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d5af0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0xa0))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x40))(*(undefined8 **)(arg1 + 0x40), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d5b30
// Address: 0x1800d5b30
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d5b30(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    char cVar1;
    int32_t *piVar2;
    int32_t *piVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t *piStack_10;
    
    var_10h = arg2;
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x98))(arg2, arg1);
    if (cVar1 != '\0') {
        piVar2 = *(int32_t **)(arg1 + 0x30);
        piVar3 = piVar2 + *(int64_t *)(arg1 + 0x38) * 0x14;
        for (; piVar2 != piVar3; piVar2 = piVar2 + 0x14) {
            var_18h = (int64_t)&var_10h;
            piStack_10 = &var_10h;
            (**(code **)((int64_t)*piVar2 * 8 + 0x180641b58))(&var_18h, piVar2 + 2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5b57
// Address: 0x1800d5b57
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d5b30(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    char cVar1;
    int32_t *piVar2;
    int32_t *piVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t *piStack_10;
    
    var_10h = arg2;
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x98))(arg2, arg1);
    if (cVar1 != '\0') {
        piVar2 = *(int32_t **)(arg1 + 0x30);
        piVar3 = piVar2 + *(int64_t *)(arg1 + 0x38) * 0x14;
        for (; piVar2 != piVar3; piVar2 = piVar2 + 0x14) {
            var_18h = (int64_t)&var_10h;
            piStack_10 = &var_10h;
            (**(code **)((int64_t)*piVar2 * 8 + 0x180641b58))(&var_18h, piVar2 + 2);
        }
    }
    return;
}

