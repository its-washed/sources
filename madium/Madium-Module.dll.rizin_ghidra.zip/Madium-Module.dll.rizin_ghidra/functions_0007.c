// Chunk 7 - 50 functions

// ============================================================
// Function: FUN_18000f010
// Address: 0x18000f010
// Size: 49 bytes
// ============================================================
void fcn.18000f010(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined *puVar9;
    uint64_t unaff_RDI;
    undefined in_R9B;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    func_0x000180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x00018000f0b1;
            }
            unaff_RDI = func_0x000180459890(uVar2);
        }
code_r0x00018000f0d4:
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar4 < 0x10) {
            func_0x000180498030(unaff_RDI, arg1, iVar3);
            *(undefined *)(iVar3 + unaff_RDI) = in_R9B;
            *(undefined *)(iVar3 + 1 + unaff_RDI) = 0;
            goto code_r0x00018000f149;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, iVar3);
        *(undefined *)(iVar3 + unaff_RDI) = in_R9B;
        *(undefined *)(iVar3 + 1 + unaff_RDI) = 0;
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x00018000f149;
            }
            goto code_r0x00018000f126;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x00018000f0b1:
        iVar6 = func_0x000180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018000f0d4;
        }
code_r0x00018000f126:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar9 = auStack_30;
    }
    *(undefined8 *)(puVar9 + -8) = 0x18000f135;
    func_0x000180459c3c(uVar8);
code_r0x00018000f149:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18000f041
// Address: 0x18000f041
// Size: 299 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18000f010(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined *puVar9;
    uint64_t unaff_RDI;
    undefined in_R9B;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    func_0x000180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x00018000f0b1;
            }
            unaff_RDI = func_0x000180459890(uVar2);
        }
code_r0x00018000f0d4:
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar4 < 0x10) {
            func_0x000180498030(unaff_RDI, arg1, iVar3);
            *(undefined *)(iVar3 + unaff_RDI) = in_R9B;
            *(undefined *)(iVar3 + 1 + unaff_RDI) = 0;
            goto code_r0x00018000f149;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, iVar3);
        *(undefined *)(iVar3 + unaff_RDI) = in_R9B;
        *(undefined *)(iVar3 + 1 + unaff_RDI) = 0;
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x00018000f149;
            }
            goto code_r0x00018000f126;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x00018000f0b1:
        iVar6 = func_0x000180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018000f0d4;
        }
code_r0x00018000f126:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar9 = auStack_30;
    }
    *(undefined8 *)(puVar9 + -8) = 0x18000f135;
    func_0x000180459c3c(uVar8);
code_r0x00018000f149:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18000f16c
// Address: 0x18000f16c
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18000f010(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined *puVar9;
    uint64_t unaff_RDI;
    undefined in_R9B;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    func_0x000180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x00018000f0b1;
            }
            unaff_RDI = func_0x000180459890(uVar2);
        }
code_r0x00018000f0d4:
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar4 < 0x10) {
            func_0x000180498030(unaff_RDI, arg1, iVar3);
            *(undefined *)(iVar3 + unaff_RDI) = in_R9B;
            *(undefined *)(iVar3 + 1 + unaff_RDI) = 0;
            goto code_r0x00018000f149;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, iVar3);
        *(undefined *)(iVar3 + unaff_RDI) = in_R9B;
        *(undefined *)(iVar3 + 1 + unaff_RDI) = 0;
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x00018000f149;
            }
            goto code_r0x00018000f126;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x00018000f0b1:
        iVar6 = func_0x000180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018000f0d4;
        }
code_r0x00018000f126:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar9 = auStack_30;
    }
    *(undefined8 *)(puVar9 + -8) = 0x18000f135;
    func_0x000180459c3c(uVar8);
code_r0x00018000f149:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18000f172
// Address: 0x18000f172
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18000f010(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined *puVar9;
    uint64_t unaff_RDI;
    undefined in_R9B;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    func_0x000180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x00018000f0b1;
            }
            unaff_RDI = func_0x000180459890(uVar2);
        }
code_r0x00018000f0d4:
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar4 < 0x10) {
            func_0x000180498030(unaff_RDI, arg1, iVar3);
            *(undefined *)(iVar3 + unaff_RDI) = in_R9B;
            *(undefined *)(iVar3 + 1 + unaff_RDI) = 0;
            goto code_r0x00018000f149;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, iVar3);
        *(undefined *)(iVar3 + unaff_RDI) = in_R9B;
        *(undefined *)(iVar3 + 1 + unaff_RDI) = 0;
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x00018000f149;
            }
            goto code_r0x00018000f126;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x00018000f0b1:
        iVar6 = func_0x000180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018000f0d4;
        }
code_r0x00018000f126:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        puVar9 = auStack_30;
    }
    *(undefined8 *)(puVar9 + -8) = 0x18000f135;
    func_0x000180459c3c(uVar8);
code_r0x00018000f149:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18000f180
// Address: 0x18000f180
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000f180(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint64_t uVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined *puVar7;
    uint64_t uVar8;
    uint64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined uStack_38;
    int64_t var_37h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x18);
    if ((uint64_t)arg3 <= uVar2) {
        iVar4 = arg1;
        if (0xf < uVar2) {
            iVar4 = *(int64_t *)arg1;
        }
        *(int64_t *)(arg1 + 0x10) = arg3;
        func_0x000180498030(iVar4);
        *(undefined *)(iVar4 + arg3) = 0;
        return arg1;
    }
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffff < (uint64_t)arg3) {
        func_0x0001800047c0();
        pcVar3 = (code *)swi(3);
        iVar4 = (*pcVar3)();
        return iVar4;
    }
    uVar5 = arg3 | 0xf;
    if ((uVar5 < 0x8000000000000000) && (uVar2 <= 0x7fffffffffffffff - (uVar2 >> 1))) {
        uVar1 = (uVar2 >> 1) + uVar2;
        uVar8 = uVar5;
        if (uVar5 < uVar1) {
            uVar8 = uVar1;
        }
        uVar1 = uVar8 + 1;
        if (uVar1 == 0) {
            unaff_R14 = 0;
        } else {
            if (0xfff < uVar1) {
                uVar5 = uVar8 + 0x28;
                if (uVar5 <= uVar1) {
                    func_0x000180004720();
                    pcVar3 = (code *)swi(3);
                    iVar4 = (*pcVar3)();
                    return iVar4;
                }
                goto code_r0x00018000f239;
            }
            unaff_R14 = func_0x000180459890(uVar1);
        }
code_r0x00018000f25c:
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        func_0x000180498030(unaff_R14, arg2, arg3);
        *(undefined *)(unaff_R14 + arg3) = 0;
        if (uVar2 < 0x10) goto code_r0x00018000f2b6;
        iVar4 = *(int64_t *)arg1;
        iVar6 = iVar4;
        puVar7 = &uStack_38;
        if ((0xfff < uVar2 + 1) && (iVar6 = *(int64_t *)(iVar4 + -8), puVar7 = &uStack_38, 0x1f < (iVar4 - iVar6) - 8U))
        goto code_r0x00018000f2a4;
    } else {
        uVar5 = 0x8000000000000027;
code_r0x00018000f239:
        iVar4 = func_0x000180459890(uVar5);
        if (iVar4 != 0) {
            unaff_R14 = iVar4 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_R14 - 8) = iVar4;
            goto code_r0x00018000f25c;
        }
code_r0x00018000f2a4:
        iVar6 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar7 = (undefined *)((int64_t)&var_37h + 7);
    }
    *(undefined8 *)(puVar7 + -8) = 0x18000f2b6;
    func_0x000180459c3c(iVar6);
code_r0x00018000f2b6:
    *(uint64_t *)arg1 = unaff_R14;
    return arg1;
}

// ============================================================
// Function: FUN_18000f1dd
// Address: 0x18000f1dd
// Size: 228 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000f180(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint64_t uVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined *puVar7;
    uint64_t uVar8;
    uint64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined uStack_38;
    int64_t var_37h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x18);
    if ((uint64_t)arg3 <= uVar2) {
        iVar4 = arg1;
        if (0xf < uVar2) {
            iVar4 = *(int64_t *)arg1;
        }
        *(int64_t *)(arg1 + 0x10) = arg3;
        func_0x000180498030(iVar4);
        *(undefined *)(iVar4 + arg3) = 0;
        return arg1;
    }
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffff < (uint64_t)arg3) {
        func_0x0001800047c0();
        pcVar3 = (code *)swi(3);
        iVar4 = (*pcVar3)();
        return iVar4;
    }
    uVar5 = arg3 | 0xf;
    if ((uVar5 < 0x8000000000000000) && (uVar2 <= 0x7fffffffffffffff - (uVar2 >> 1))) {
        uVar1 = (uVar2 >> 1) + uVar2;
        uVar8 = uVar5;
        if (uVar5 < uVar1) {
            uVar8 = uVar1;
        }
        uVar1 = uVar8 + 1;
        if (uVar1 == 0) {
            unaff_R14 = 0;
        } else {
            if (0xfff < uVar1) {
                uVar5 = uVar8 + 0x28;
                if (uVar5 <= uVar1) {
                    func_0x000180004720();
                    pcVar3 = (code *)swi(3);
                    iVar4 = (*pcVar3)();
                    return iVar4;
                }
                goto code_r0x00018000f239;
            }
            unaff_R14 = func_0x000180459890(uVar1);
        }
code_r0x00018000f25c:
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        func_0x000180498030(unaff_R14, arg2, arg3);
        *(undefined *)(unaff_R14 + arg3) = 0;
        if (uVar2 < 0x10) goto code_r0x00018000f2b6;
        iVar4 = *(int64_t *)arg1;
        iVar6 = iVar4;
        puVar7 = &uStack_38;
        if ((0xfff < uVar2 + 1) && (iVar6 = *(int64_t *)(iVar4 + -8), puVar7 = &uStack_38, 0x1f < (iVar4 - iVar6) - 8U))
        goto code_r0x00018000f2a4;
    } else {
        uVar5 = 0x8000000000000027;
code_r0x00018000f239:
        iVar4 = func_0x000180459890(uVar5);
        if (iVar4 != 0) {
            unaff_R14 = iVar4 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_R14 - 8) = iVar4;
            goto code_r0x00018000f25c;
        }
code_r0x00018000f2a4:
        iVar6 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar7 = (undefined *)((int64_t)&var_37h + 7);
    }
    *(undefined8 *)(puVar7 + -8) = 0x18000f2b6;
    func_0x000180459c3c(iVar6);
code_r0x00018000f2b6:
    *(uint64_t *)arg1 = unaff_R14;
    return arg1;
}

// ============================================================
// Function: FUN_18000f2c1
// Address: 0x18000f2c1
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000f180(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint64_t uVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined *puVar7;
    uint64_t uVar8;
    uint64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined uStack_38;
    int64_t var_37h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x18);
    if ((uint64_t)arg3 <= uVar2) {
        iVar4 = arg1;
        if (0xf < uVar2) {
            iVar4 = *(int64_t *)arg1;
        }
        *(int64_t *)(arg1 + 0x10) = arg3;
        func_0x000180498030(iVar4);
        *(undefined *)(iVar4 + arg3) = 0;
        return arg1;
    }
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffff < (uint64_t)arg3) {
        func_0x0001800047c0();
        pcVar3 = (code *)swi(3);
        iVar4 = (*pcVar3)();
        return iVar4;
    }
    uVar5 = arg3 | 0xf;
    if ((uVar5 < 0x8000000000000000) && (uVar2 <= 0x7fffffffffffffff - (uVar2 >> 1))) {
        uVar1 = (uVar2 >> 1) + uVar2;
        uVar8 = uVar5;
        if (uVar5 < uVar1) {
            uVar8 = uVar1;
        }
        uVar1 = uVar8 + 1;
        if (uVar1 == 0) {
            unaff_R14 = 0;
        } else {
            if (0xfff < uVar1) {
                uVar5 = uVar8 + 0x28;
                if (uVar5 <= uVar1) {
                    func_0x000180004720();
                    pcVar3 = (code *)swi(3);
                    iVar4 = (*pcVar3)();
                    return iVar4;
                }
                goto code_r0x00018000f239;
            }
            unaff_R14 = func_0x000180459890(uVar1);
        }
code_r0x00018000f25c:
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        func_0x000180498030(unaff_R14, arg2, arg3);
        *(undefined *)(unaff_R14 + arg3) = 0;
        if (uVar2 < 0x10) goto code_r0x00018000f2b6;
        iVar4 = *(int64_t *)arg1;
        iVar6 = iVar4;
        puVar7 = &uStack_38;
        if ((0xfff < uVar2 + 1) && (iVar6 = *(int64_t *)(iVar4 + -8), puVar7 = &uStack_38, 0x1f < (iVar4 - iVar6) - 8U))
        goto code_r0x00018000f2a4;
    } else {
        uVar5 = 0x8000000000000027;
code_r0x00018000f239:
        iVar4 = func_0x000180459890(uVar5);
        if (iVar4 != 0) {
            unaff_R14 = iVar4 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_R14 - 8) = iVar4;
            goto code_r0x00018000f25c;
        }
code_r0x00018000f2a4:
        iVar6 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar7 = (undefined *)((int64_t)&var_37h + 7);
    }
    *(undefined8 *)(puVar7 + -8) = 0x18000f2b6;
    func_0x000180459c3c(iVar6);
code_r0x00018000f2b6:
    *(uint64_t *)arg1 = unaff_R14;
    return arg1;
}

// ============================================================
// Function: FUN_18000f2dd
// Address: 0x18000f2dd
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000f180(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    uint64_t uVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined *puVar7;
    uint64_t uVar8;
    uint64_t unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined uStack_38;
    int64_t var_37h;
    
    uVar2 = *(uint64_t *)(arg1 + 0x18);
    if ((uint64_t)arg3 <= uVar2) {
        iVar4 = arg1;
        if (0xf < uVar2) {
            iVar4 = *(int64_t *)arg1;
        }
        *(int64_t *)(arg1 + 0x10) = arg3;
        func_0x000180498030(iVar4);
        *(undefined *)(iVar4 + arg3) = 0;
        return arg1;
    }
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffff < (uint64_t)arg3) {
        func_0x0001800047c0();
        pcVar3 = (code *)swi(3);
        iVar4 = (*pcVar3)();
        return iVar4;
    }
    uVar5 = arg3 | 0xf;
    if ((uVar5 < 0x8000000000000000) && (uVar2 <= 0x7fffffffffffffff - (uVar2 >> 1))) {
        uVar1 = (uVar2 >> 1) + uVar2;
        uVar8 = uVar5;
        if (uVar5 < uVar1) {
            uVar8 = uVar1;
        }
        uVar1 = uVar8 + 1;
        if (uVar1 == 0) {
            unaff_R14 = 0;
        } else {
            if (0xfff < uVar1) {
                uVar5 = uVar8 + 0x28;
                if (uVar5 <= uVar1) {
                    func_0x000180004720();
                    pcVar3 = (code *)swi(3);
                    iVar4 = (*pcVar3)();
                    return iVar4;
                }
                goto code_r0x00018000f239;
            }
            unaff_R14 = func_0x000180459890(uVar1);
        }
code_r0x00018000f25c:
        *(int64_t *)(arg1 + 0x10) = arg3;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        func_0x000180498030(unaff_R14, arg2, arg3);
        *(undefined *)(unaff_R14 + arg3) = 0;
        if (uVar2 < 0x10) goto code_r0x00018000f2b6;
        iVar4 = *(int64_t *)arg1;
        iVar6 = iVar4;
        puVar7 = &uStack_38;
        if ((0xfff < uVar2 + 1) && (iVar6 = *(int64_t *)(iVar4 + -8), puVar7 = &uStack_38, 0x1f < (iVar4 - iVar6) - 8U))
        goto code_r0x00018000f2a4;
    } else {
        uVar5 = 0x8000000000000027;
code_r0x00018000f239:
        iVar4 = func_0x000180459890(uVar5);
        if (iVar4 != 0) {
            unaff_R14 = iVar4 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_R14 - 8) = iVar4;
            goto code_r0x00018000f25c;
        }
code_r0x00018000f2a4:
        iVar6 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar7 = (undefined *)((int64_t)&var_37h + 7);
    }
    *(undefined8 *)(puVar7 + -8) = 0x18000f2b6;
    func_0x000180459c3c(iVar6);
code_r0x00018000f2b6:
    *(uint64_t *)arg1 = unaff_R14;
    return arg1;
}

// ============================================================
// Function: FUN_18000f2f0
// Address: 0x18000f2f0
// Size: 46 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18000f2f0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    func_0x000180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x00018000f393;
            }
            unaff_RDI = func_0x000180459890(uVar2);
        }
code_r0x00018000f3b6:
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        iVar6 = iVar3 + unaff_RDI;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar4 < 0x10) {
            func_0x000180498030(unaff_RDI, arg1, iVar3);
            func_0x0001804986e0(iVar6, (int32_t)(char)arg_28h, arg4);
            *(undefined *)(iVar6 + arg4) = 0;
            goto code_r0x00018000f444;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, iVar3);
        func_0x0001804986e0(iVar6, (int32_t)(char)arg_28h, arg4);
        *(undefined *)(iVar6 + arg4) = 0;
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x00018000f444;
            }
            goto code_r0x00018000f419;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x00018000f393:
        iVar6 = func_0x000180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018000f3b6;
        }
code_r0x00018000f419:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x18000f428;
    func_0x000180459c3c(uVar8);
code_r0x00018000f444:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18000f31e
// Address: 0x18000f31e
// Size: 331 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18000f2f0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    func_0x000180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x00018000f393;
            }
            unaff_RDI = func_0x000180459890(uVar2);
        }
code_r0x00018000f3b6:
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        iVar6 = iVar3 + unaff_RDI;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar4 < 0x10) {
            func_0x000180498030(unaff_RDI, arg1, iVar3);
            func_0x0001804986e0(iVar6, (int32_t)(char)arg_28h, arg4);
            *(undefined *)(iVar6 + arg4) = 0;
            goto code_r0x00018000f444;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, iVar3);
        func_0x0001804986e0(iVar6, (int32_t)(char)arg_28h, arg4);
        *(undefined *)(iVar6 + arg4) = 0;
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x00018000f444;
            }
            goto code_r0x00018000f419;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x00018000f393:
        iVar6 = func_0x000180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018000f3b6;
        }
code_r0x00018000f419:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x18000f428;
    func_0x000180459c3c(uVar8);
code_r0x00018000f444:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18000f469
// Address: 0x18000f469
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18000f2f0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    func_0x000180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x00018000f393;
            }
            unaff_RDI = func_0x000180459890(uVar2);
        }
code_r0x00018000f3b6:
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        iVar6 = iVar3 + unaff_RDI;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar4 < 0x10) {
            func_0x000180498030(unaff_RDI, arg1, iVar3);
            func_0x0001804986e0(iVar6, (int32_t)(char)arg_28h, arg4);
            *(undefined *)(iVar6 + arg4) = 0;
            goto code_r0x00018000f444;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, iVar3);
        func_0x0001804986e0(iVar6, (int32_t)(char)arg_28h, arg4);
        *(undefined *)(iVar6 + arg4) = 0;
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x00018000f444;
            }
            goto code_r0x00018000f419;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x00018000f393:
        iVar6 = func_0x000180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018000f3b6;
        }
code_r0x00018000f419:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x18000f428;
    func_0x000180459c3c(uVar8);
code_r0x00018000f444:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18000f46f
// Address: 0x18000f46f
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18000f2f0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    uint64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    undefined auStack_40 [24];
    int64_t var_28h;
    
    piVar9 = &var_48h;
    iVar3 = *(int64_t *)(arg1 + 0x10);
    uVar8 = 0x7fffffffffffffff;
    if (0x7fffffffffffffffU - iVar3 < (uint64_t)arg2) {
        func_0x0001800047c0();
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
    }
    uVar4 = *(uint64_t *)(arg1 + 0x18);
    uVar7 = iVar3 + arg2 | 0xf;
    if ((uVar7 < 0x8000000000000000) && (uVar4 <= 0x7fffffffffffffff - (uVar4 >> 1))) {
        uVar2 = uVar4 + (uVar4 >> 1);
        uVar8 = uVar7;
        if (uVar7 < uVar2) {
            uVar8 = uVar2;
        }
        uVar2 = uVar8 + 1;
        if (uVar2 == 0) {
            unaff_RDI = 0;
        } else {
            if (0xfff < uVar2) {
                uVar7 = uVar8 + 0x28;
                if (uVar7 <= uVar2) {
                    func_0x000180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                goto code_r0x00018000f393;
            }
            unaff_RDI = func_0x000180459890(uVar2);
        }
code_r0x00018000f3b6:
        *(int64_t *)(arg1 + 0x10) = iVar3 + arg2;
        iVar6 = iVar3 + unaff_RDI;
        *(uint64_t *)(arg1 + 0x18) = uVar8;
        if (uVar4 < 0x10) {
            func_0x000180498030(unaff_RDI, arg1, iVar3);
            func_0x0001804986e0(iVar6, (int32_t)(char)arg_28h, arg4);
            *(undefined *)(iVar6 + arg4) = 0;
            goto code_r0x00018000f444;
        }
        uVar8 = *(uint64_t *)arg1;
        func_0x000180498030(unaff_RDI, uVar8, iVar3);
        func_0x0001804986e0(iVar6, (int32_t)(char)arg_28h, arg4);
        *(undefined *)(iVar6 + arg4) = 0;
        if (0xfff < uVar4 + 1) {
            piVar1 = (int64_t *)(uVar8 - 8);
            uVar8 = (uVar8 - *piVar1) - 8;
            if (uVar8 < 0x20) {
                func_0x000180459c3c(*piVar1, uVar4 + 0x28);
                goto code_r0x00018000f444;
            }
            goto code_r0x00018000f419;
        }
    } else {
        uVar7 = 0x8000000000000027;
code_r0x00018000f393:
        iVar6 = func_0x000180459890(uVar7);
        if (iVar6 != 0) {
            unaff_RDI = iVar6 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar6;
            goto code_r0x00018000f3b6;
        }
code_r0x00018000f419:
        pcVar5 = (code *)swi(0x29);
        (*pcVar5)(5);
        piVar9 = (int64_t *)auStack_40;
    }
    *(undefined8 *)((int64_t)piVar9 + -8) = 0x18000f428;
    func_0x000180459c3c(uVar8);
code_r0x00018000f444:
    *(uint64_t *)arg1 = unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18000f4b0
// Address: 0x18000f4b0
// Size: 243 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.18000f4b0(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    undefined8 uVar7;
    undefined (*pauVar8) [16];
    int64_t var_8h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar6 = (undefined8 *)fcn.1800137d0();
    uVar3 = *puVar6;
    uVar4 = *(undefined8 *)(*(int64_t *)(arg1 + 8) + 0x18);
    uVar7 = fcn.18045838c();
    pauVar8 = (undefined (*) [16])fcn.180459890(0x50);
    *pauVar8 = ZEXT816(0);
    *(undefined4 *)(*pauVar8 + 8) = 1;
    *(undefined4 *)(*pauVar8 + 0xc) = 1;
    *(undefined8 *)*pauVar8 = 0x1805ab1a0;
    *(undefined4 *)(pauVar8[1] + 8) = 2;
    *(undefined8 *)pauVar8[1] = 0x1805ab1c8;
    fcn.18000b4d0(pauVar8 + 2, arg2);
    *(undefined8 *)pauVar8[4] = uVar4;
    *(undefined8 *)(pauVar8[4] + 8) = uVar7;
    *(undefined4 *)(pauVar8[1] + 8) = 0;
    _var_48h = ZEXT816(0);
    var_58h = (int64_t)(pauVar8 + 1);
    var_50h = (int64_t)pauVar8;
    fcn.18000a9d0(uVar3, &var_58h);
    iVar5 = var_50h;
    if (var_50h != 0) {
        LOCK();
        piVar1 = (int32_t *)(var_50h + 8);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
            (***(code ***)var_50h)(var_50h);
            LOCK();
            piVar1 = (int32_t *)(iVar5 + 0xc);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)(*(int64_t *)iVar5 + 8))(iVar5);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18000f5d0
// Address: 0x18000f5d0
// Size: 32 bytes
// ============================================================
void fcn.18000f5d0(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    func_0x000180454ffc(*(undefined8 *)(arg1 + 0x50));
    if (7 < *(uint64_t *)(arg1 + 0x48)) {
        iVar1 = *(int64_t *)(arg1 + 0x30);
        iVar3 = iVar1;
        puVar4 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg1 + 0x48) * 2 + 2) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_28, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18000dccd;
        func_0x000180459c3c(iVar3);
    }
    *(undefined8 *)(arg1 + 0x40) = 0;
    *(undefined2 *)(int64_t *)(arg1 + 0x30) = 0;
    *(undefined8 *)(arg1 + 0x48) = 7;
    return;
}

// ============================================================
// Function: FUN_18000f5f0
// Address: 0x18000f5f0
// Size: 371 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18000f5f0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    if ((arg1 != 0) && (*(int64_t *)arg1 == 0)) {
        puVar3 = (undefined8 *)fcn.180459890(0x10);
        iVar1 = *(int64_t *)(arg2 + 8);
        if (iVar1 == 0) {
            iVar5 = 0x1805aadb1;
        } else {
            iVar5 = *(int64_t *)(iVar1 + 0x28);
            if (iVar5 == 0) {
                iVar5 = iVar1 + 0x30;
            }
        }
        func_0x000180455714(&var_88h, 0);
        var_80h = 0;
        var_78h._0_1_ = 0;
        var_70h = 0;
        var_68h._0_1_ = 0;
        var_60h = 0;
        var_58h._0_2_ = 0;
        var_50h = 0;
        var_48h._0_2_ = 0;
        var_40h = 0;
        var_38h._0_1_ = 0;
        var_30h = 0;
        var_28h._0_1_ = 0;
        if (iVar5 == 0) {
            func_0x000180454740(0x1805aadd8);
            pcVar2 = (code *)swi(3);
            uVar4 = (*pcVar2)();
            return uVar4;
        }
        func_0x000180455a00(&var_88h, iVar5);
        *(undefined4 *)(puVar3 + 1) = 0;
        *puVar3 = 0x1805a0908;
        *(undefined8 **)arg1 = puVar3;
        func_0x000180455a6c(&var_88h);
        if (var_30h != 0) {
            func_0x000180460d90();
        }
        var_30h = 0;
        if (var_40h != 0) {
            func_0x000180460d90();
        }
        var_40h = 0;
        if (var_50h != 0) {
            func_0x000180460d90();
        }
        var_50h = 0;
        if (var_60h != 0) {
            func_0x000180460d90();
        }
        var_60h = 0;
        if (var_70h != 0) {
            func_0x000180460d90();
        }
        var_70h = 0;
        if (var_80h != 0) {
            func_0x000180460d90();
        }
        var_80h = 0;
        func_0x00018045578c(&var_88h);
    }
    return 2;
}

// ============================================================
// Function: FUN_18000f7b0
// Address: 0x18000f7b0
// Size: 36 bytes
// ============================================================
void fcn.18000f7b0(int64_t arg1)
{
    int64_t *piVar1;
    
    piVar1 = *(int64_t **)((int64_t)*(int32_t *)(**(int64_t **)arg1 + 4) + 0x48 + (int64_t)*(int64_t **)arg1);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x10))();
    }
    return;
}

// ============================================================
// Function: FUN_18000f7e0
// Address: 0x18000f7e0
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18000f7e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    uint64_t uVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined *puVar7;
    int64_t *unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    var_18h = arg3;
    if ((uint64_t)arg2 <= (uint64_t)(*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3)) {
        func_0x00018000d540(*(int64_t *)arg1, *(int64_t *)(arg1 + 8), &var_18h);
        return;
    }
    if (0x1fffffffffffffff < (uint64_t)arg2) {
code_r0x00018000f91e:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar2 = arg2 * 8;
    if (uVar2 == 0) {
        unaff_RDI = (int64_t *)0x0;
code_r0x00018000f877:
        iVar4 = *(int64_t *)arg1;
        iVar6 = *(int64_t *)(arg1 + 0x10) - iVar4 >> 3;
        if (iVar6 == 0) goto code_r0x00018000f8c1;
        iVar5 = iVar4;
        puVar7 = auStack_28;
        if ((0xfff < (uint64_t)(iVar6 * 8)) &&
           (iVar5 = *(int64_t *)(iVar4 + -8), puVar7 = auStack_28, 0x1f < (iVar4 - iVar5) - 8U))
        goto code_r0x00018000f8b2;
    } else {
        if (uVar2 < 0x1000) {
            unaff_RDI = (int64_t *)fcn.180459890(uVar2);
            goto code_r0x00018000f877;
        }
        if (uVar2 + 0x27 <= uVar2) goto code_r0x00018000f91e;
        iVar4 = fcn.180459890();
        if (iVar4 != 0) {
            unaff_RDI = (int64_t *)(iVar4 + 0x27U & 0xffffffffffffffe0);
            unaff_RDI[-1] = iVar4;
            goto code_r0x00018000f877;
        }
code_r0x00018000f8b2:
        pcVar3 = (code *)swi(0x29);
        iVar5 = (*pcVar3)(5);
        puVar7 = auStack_20;
    }
    *(undefined8 *)(puVar7 + -8) = 0x18000f8c1;
    func_0x000180459c3c(iVar5);
code_r0x00018000f8c1:
    piVar1 = unaff_RDI + arg2;
    *(int64_t **)arg1 = unaff_RDI;
    *(int64_t **)(arg1 + 8) = piVar1;
    *(int64_t **)(arg1 + 0x10) = piVar1;
    for (; unaff_RDI != piVar1; unaff_RDI = unaff_RDI + 1) {
        *unaff_RDI = arg3;
    }
    return;
}

// ============================================================
// Function: FUN_18000f81a
// Address: 0x18000f81a
// Size: 232 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18000f7e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    uint64_t uVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined *puVar7;
    int64_t *unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    var_18h = arg3;
    if ((uint64_t)arg2 <= (uint64_t)(*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3)) {
        func_0x00018000d540(*(int64_t *)arg1, *(int64_t *)(arg1 + 8), &var_18h);
        return;
    }
    if (0x1fffffffffffffff < (uint64_t)arg2) {
code_r0x00018000f91e:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar2 = arg2 * 8;
    if (uVar2 == 0) {
        unaff_RDI = (int64_t *)0x0;
code_r0x00018000f877:
        iVar4 = *(int64_t *)arg1;
        iVar6 = *(int64_t *)(arg1 + 0x10) - iVar4 >> 3;
        if (iVar6 == 0) goto code_r0x00018000f8c1;
        iVar5 = iVar4;
        puVar7 = auStack_28;
        if ((0xfff < (uint64_t)(iVar6 * 8)) &&
           (iVar5 = *(int64_t *)(iVar4 + -8), puVar7 = auStack_28, 0x1f < (iVar4 - iVar5) - 8U))
        goto code_r0x00018000f8b2;
    } else {
        if (uVar2 < 0x1000) {
            unaff_RDI = (int64_t *)fcn.180459890(uVar2);
            goto code_r0x00018000f877;
        }
        if (uVar2 + 0x27 <= uVar2) goto code_r0x00018000f91e;
        iVar4 = fcn.180459890();
        if (iVar4 != 0) {
            unaff_RDI = (int64_t *)(iVar4 + 0x27U & 0xffffffffffffffe0);
            unaff_RDI[-1] = iVar4;
            goto code_r0x00018000f877;
        }
code_r0x00018000f8b2:
        pcVar3 = (code *)swi(0x29);
        iVar5 = (*pcVar3)(5);
        puVar7 = auStack_20;
    }
    *(undefined8 *)(puVar7 + -8) = 0x18000f8c1;
    func_0x000180459c3c(iVar5);
code_r0x00018000f8c1:
    piVar1 = unaff_RDI + arg2;
    *(int64_t **)arg1 = unaff_RDI;
    *(int64_t **)(arg1 + 8) = piVar1;
    *(int64_t **)(arg1 + 0x10) = piVar1;
    for (; unaff_RDI != piVar1; unaff_RDI = unaff_RDI + 1) {
        *unaff_RDI = arg3;
    }
    return;
}

// ============================================================
// Function: FUN_18000f902
// Address: 0x18000f902
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18000f7e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    uint64_t uVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined *puVar7;
    int64_t *unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    var_18h = arg3;
    if ((uint64_t)arg2 <= (uint64_t)(*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3)) {
        func_0x00018000d540(*(int64_t *)arg1, *(int64_t *)(arg1 + 8), &var_18h);
        return;
    }
    if (0x1fffffffffffffff < (uint64_t)arg2) {
code_r0x00018000f91e:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar2 = arg2 * 8;
    if (uVar2 == 0) {
        unaff_RDI = (int64_t *)0x0;
code_r0x00018000f877:
        iVar4 = *(int64_t *)arg1;
        iVar6 = *(int64_t *)(arg1 + 0x10) - iVar4 >> 3;
        if (iVar6 == 0) goto code_r0x00018000f8c1;
        iVar5 = iVar4;
        puVar7 = auStack_28;
        if ((0xfff < (uint64_t)(iVar6 * 8)) &&
           (iVar5 = *(int64_t *)(iVar4 + -8), puVar7 = auStack_28, 0x1f < (iVar4 - iVar5) - 8U))
        goto code_r0x00018000f8b2;
    } else {
        if (uVar2 < 0x1000) {
            unaff_RDI = (int64_t *)fcn.180459890(uVar2);
            goto code_r0x00018000f877;
        }
        if (uVar2 + 0x27 <= uVar2) goto code_r0x00018000f91e;
        iVar4 = fcn.180459890();
        if (iVar4 != 0) {
            unaff_RDI = (int64_t *)(iVar4 + 0x27U & 0xffffffffffffffe0);
            unaff_RDI[-1] = iVar4;
            goto code_r0x00018000f877;
        }
code_r0x00018000f8b2:
        pcVar3 = (code *)swi(0x29);
        iVar5 = (*pcVar3)(5);
        puVar7 = auStack_20;
    }
    *(undefined8 *)(puVar7 + -8) = 0x18000f8c1;
    func_0x000180459c3c(iVar5);
code_r0x00018000f8c1:
    piVar1 = unaff_RDI + arg2;
    *(int64_t **)arg1 = unaff_RDI;
    *(int64_t **)(arg1 + 8) = piVar1;
    *(int64_t **)(arg1 + 0x10) = piVar1;
    for (; unaff_RDI != piVar1; unaff_RDI = unaff_RDI + 1) {
        *unaff_RDI = arg3;
    }
    return;
}

// ============================================================
// Function: FUN_18000f91e
// Address: 0x18000f91e
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18000f7e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    uint64_t uVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined *puVar7;
    int64_t *unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    var_18h = arg3;
    if ((uint64_t)arg2 <= (uint64_t)(*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3)) {
        func_0x00018000d540(*(int64_t *)arg1, *(int64_t *)(arg1 + 8), &var_18h);
        return;
    }
    if (0x1fffffffffffffff < (uint64_t)arg2) {
code_r0x00018000f91e:
        fcn.180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar2 = arg2 * 8;
    if (uVar2 == 0) {
        unaff_RDI = (int64_t *)0x0;
code_r0x00018000f877:
        iVar4 = *(int64_t *)arg1;
        iVar6 = *(int64_t *)(arg1 + 0x10) - iVar4 >> 3;
        if (iVar6 == 0) goto code_r0x00018000f8c1;
        iVar5 = iVar4;
        puVar7 = auStack_28;
        if ((0xfff < (uint64_t)(iVar6 * 8)) &&
           (iVar5 = *(int64_t *)(iVar4 + -8), puVar7 = auStack_28, 0x1f < (iVar4 - iVar5) - 8U))
        goto code_r0x00018000f8b2;
    } else {
        if (uVar2 < 0x1000) {
            unaff_RDI = (int64_t *)fcn.180459890(uVar2);
            goto code_r0x00018000f877;
        }
        if (uVar2 + 0x27 <= uVar2) goto code_r0x00018000f91e;
        iVar4 = fcn.180459890();
        if (iVar4 != 0) {
            unaff_RDI = (int64_t *)(iVar4 + 0x27U & 0xffffffffffffffe0);
            unaff_RDI[-1] = iVar4;
            goto code_r0x00018000f877;
        }
code_r0x00018000f8b2:
        pcVar3 = (code *)swi(0x29);
        iVar5 = (*pcVar3)(5);
        puVar7 = auStack_20;
    }
    *(undefined8 *)(puVar7 + -8) = 0x18000f8c1;
    func_0x000180459c3c(iVar5);
code_r0x00018000f8c1:
    piVar1 = unaff_RDI + arg2;
    *(int64_t **)arg1 = unaff_RDI;
    *(int64_t **)(arg1 + 8) = piVar1;
    *(int64_t **)(arg1 + 0x10) = piVar1;
    for (; unaff_RDI != piVar1; unaff_RDI = unaff_RDI + 1) {
        *unaff_RDI = arg3;
    }
    return;
}

// ============================================================
// Function: FUN_18000f930
// Address: 0x18000f930
// Size: 17 bytes
// ============================================================
void fcn.18000f930(void)
{
    code *pcVar1;
    
    fcn.1804546f8(0x1805ab140);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_18000f990
// Address: 0x18000f990
// Size: 176 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18000f990(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    int64_t var_8h;
    int64_t in_stack_00000020;
    int64_t var_18h;
    int64_t var_10h;
    
    if (*(int64_t *)(arg1 + 0x80) == 0) {
        iVar2 = fcn.180455d60(arg2, arg3 & 0xffffffff, 0x40);
        if (iVar2 != 0) {
            fcn.18000df00(in_stack_00000020);
            piVar1 = *(int64_t **)(*(int64_t *)(arg1 + 0x60) + 8);
            var_10h = (int64_t)piVar1;
            (**(code **)(*piVar1 + 8))(piVar1);
            uVar3 = fcn.18000da00(&var_18h);
            fcn.18000dd90(arg1, uVar3);
            if (piVar1 != (int64_t *)0x0) {
                puVar4 = (undefined8 *)(**(code **)(*piVar1 + 0x10))(piVar1);
                if (puVar4 != (undefined8 *)0x0) {
                    (**(code **)*puVar4)(puVar4, 1);
                }
            }
            return arg1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18000fa40
// Address: 0x18000fa40
// Size: 132 bytes
// ============================================================
int64_t fcn.18000fa40(int64_t arg1)
{
    fcn.18000fd90();
    *(undefined *)(arg1 + 0x7c) = 0;
    *(undefined *)(arg1 + 0x71) = 0;
    *(undefined8 *)arg1 = 0x1805a0888;
    *(undefined8 **)(arg1 + 0x18) = (undefined8 *)(arg1 + 8);
    *(undefined4 **)(arg1 + 0x58) = (undefined4 *)(arg1 + 0x4c);
    *(undefined8 **)(arg1 + 0x20) = (undefined8 *)(arg1 + 0x10);
    *(undefined8 **)(arg1 + 0x38) = (undefined8 *)(arg1 + 0x28);
    *(undefined8 **)(arg1 + 0x40) = (undefined8 *)(arg1 + 0x30);
    *(undefined4 **)(arg1 + 0x50) = (undefined4 *)(arg1 + 0x48);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x30) = 0;
    *(undefined4 *)(arg1 + 0x4c) = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined4 *)(arg1 + 0x48) = 0;
    *(undefined8 *)(arg1 + 0x80) = 0;
    *(undefined8 *)(arg1 + 0x74) = *(undefined8 *)0x1807823f8;
    *(undefined8 *)(arg1 + 0x68) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_18000fad0
// Address: 0x18000fad0
// Size: 321 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18000fad0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    undefined8 uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    
    piVar1 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
    if (piVar1 != (int64_t *)0x0) {
        func_0x00018000dbe0(&var_58h, arg1);
        if ((char)var_50h != '\0') {
            iVar3 = (**(code **)(*piVar1 + 0x68))(piVar1);
            uVar7 = 0;
            if (iVar3 == -1) {
                uVar7 = 4;
            }
            iVar5 = (int64_t)*(int32_t *)(*(int64_t *)arg1 + 4);
            uVar6 = 4;
            if (*(int64_t *)(iVar5 + 0x48 + arg1) != 0) {
                uVar6 = 0;
            }
            uVar7 = uVar6 | *(uint32_t *)(iVar5 + 0x10 + arg1) & 0x17 | uVar7;
            *(uint32_t *)(iVar5 + 0x10 + arg1) = uVar7;
            uVar7 = uVar7 & *(uint32_t *)(iVar5 + 0x14 + arg1);
            if (uVar7 != 0) {
                if ((uVar7 & 4) == 0) {
                    uVar8 = 0x1805aae00;
                    if ((uVar7 & 2) == 0) {
                        uVar8 = 0x1805aae18;
                    }
                } else {
                    uVar8 = 0x1805aade8;
                }
                uVar4 = func_0x000180005e50(&var_48h, 1);
                func_0x0001800069f0(&var_38h, uVar8, uVar4);
                fcn.18045bae0(var_58h);
                pcVar2 = (code *)swi(3);
                iVar5 = (*pcVar2)();
                return iVar5;
            }
        }
        iVar3 = func_0x0001804557c0();
        if (iVar3 == 0) {
            func_0x00018000fc20(var_58h);
        }
        piVar1 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)var_58h + 4) + 0x48 + var_58h);
        if (piVar1 != (int64_t *)0x0) {
            (**(code **)(*piVar1 + 0x10))();
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_18000fc20
// Address: 0x18000fc20
// Size: 177 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h

void fcn.18000fc20(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    uint32_t uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar5 = (int64_t)*(int32_t *)(*(int64_t *)arg1 + 4);
    if (((*(int32_t *)(iVar5 + 0x10 + arg1) == 0) && ((*(uint8_t *)(iVar5 + 0x18 + arg1) & 2) != 0)) &&
       (iVar2 = (**(code **)(**(int64_t **)(iVar5 + 0x48 + arg1) + 0x68))(), iVar2 == -1)) {
        iVar5 = (int64_t)*(int32_t *)(*(int64_t *)arg1 + 4);
        uVar3 = *(uint32_t *)(iVar5 + 0x10 + arg1) & 0x13 | 4;
        *(uint32_t *)(iVar5 + 0x10 + arg1) = uVar3;
        uVar3 = uVar3 & *(uint32_t *)(iVar5 + 0x14 + arg1);
        if (uVar3 != 0) {
            if ((uVar3 & 4) == 0) {
                uVar6 = 0x1805aae00;
                if ((uVar3 & 2) == 0) {
                    uVar6 = 0x1805aae18;
                }
            } else {
                uVar6 = 0x1805aade8;
            }
            uVar4 = func_0x000180005e50(&var_48h, 1);
            func_0x0001800069f0(&var_38h, uVar6, uVar4);
            fcn.18045bae0(var_48h);
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18000fce0
// Address: 0x18000fce0
// Size: 166 bytes
// ============================================================
int64_t fcn.18000fce0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    int64_t var_8h;
    int64_t var_20h;
    
    if ((int32_t)arg4 != 0) {
        *(undefined8 *)arg1 = 0x1805ab180;
        *(undefined8 *)(arg1 + 0x20) = 0;
        *(undefined8 *)(arg1 + 0x28) = 0;
        *(undefined4 *)(arg1 + 0x30) = 0;
        *(undefined8 *)(arg1 + 0x38) = 0;
        *(undefined8 *)(arg1 + 0x40) = 0;
        *(undefined8 *)(arg1 + 0x48) = 0;
        *(undefined8 *)(arg1 + 0x50) = 0;
        *(undefined8 *)(arg1 + 0x58) = 0;
        *(undefined8 *)(arg1 + 0x18) = 0x1804a54e0;
        *(undefined8 *)(arg1 + 0x60) = 0;
        *(undefined8 *)(arg1 + 0x68) = 0;
        *(undefined *)(arg1 + 0x70) = 0;
    }
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x1804a5600;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0x18;
    *(undefined8 *)(arg1 + 8) = 0;
    fcn.18000fe50(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1, arg2);
    return arg1;
}

// ============================================================
// Function: FUN_18000fd90
// Address: 0x18000fd90
// Size: 190 bytes
// ============================================================
int64_t fcn.18000fd90(int64_t arg1)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    undefined8 *puVar4;
    undefined4 *puVar5;
    undefined4 *puVar6;
    int64_t iVar7;
    undefined8 uVar8;
    
    *(undefined8 *)arg1 = 0x1804a5500;
    puVar1 = (undefined8 *)(arg1 + 8);
    *puVar1 = 0;
    puVar2 = (undefined8 *)(arg1 + 0x10);
    *puVar2 = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    puVar3 = (undefined8 *)(arg1 + 0x28);
    *puVar3 = 0;
    puVar4 = (undefined8 *)(arg1 + 0x30);
    *puVar4 = 0;
    *(undefined8 *)(arg1 + 0x38) = 0;
    *(undefined8 *)(arg1 + 0x40) = 0;
    puVar5 = (undefined4 *)(arg1 + 0x48);
    *puVar5 = 0;
    puVar6 = (undefined4 *)(arg1 + 0x4c);
    *puVar6 = 0;
    *(undefined8 *)(arg1 + 0x50) = 0;
    *(undefined8 *)(arg1 + 0x58) = 0;
    iVar7 = fcn.180459890(0x10);
    uVar8 = fcn.1804558e8(1);
    *(undefined8 *)(iVar7 + 8) = uVar8;
    *(int64_t *)(arg1 + 0x60) = iVar7;
    *(undefined8 **)(arg1 + 0x18) = puVar1;
    *(undefined8 **)(arg1 + 0x20) = puVar2;
    *(undefined8 **)(arg1 + 0x38) = puVar3;
    *(undefined8 **)(arg1 + 0x40) = puVar4;
    *(undefined4 **)(arg1 + 0x50) = puVar5;
    *(undefined4 **)(arg1 + 0x58) = puVar6;
    *puVar2 = 0;
    *puVar4 = 0;
    *puVar6 = 0;
    *puVar1 = 0;
    *puVar3 = 0;
    *puVar5 = 0;
    return arg1;
}

// ============================================================
// Function: FUN_18000fe50
// Address: 0x18000fe50
// Size: 244 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h

void fcn.18000fe50(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    undefined uVar2;
    uint32_t uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    char in_R8B;
    int64_t var_68h;
    int64_t var_58h;
    
    *(undefined8 *)(arg1 + 0x40) = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined4 *)(arg1 + 0x14) = 0;
    *(undefined4 *)(arg1 + 0x18) = 0x201;
    *(undefined8 *)(arg1 + 0x20) = 6;
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined8 *)(arg1 + 0x30) = 0;
    *(undefined8 *)(arg1 + 0x38) = 0;
    *(undefined4 *)(arg1 + 0x10) = 0;
    iVar4 = fcn.180459890(0x10);
    uVar5 = fcn.1804558e8(1);
    *(undefined8 *)(iVar4 + 8) = uVar5;
    *(int64_t *)(arg1 + 0x40) = iVar4;
    *(int64_t *)(arg1 + 0x48) = arg2;
    *(undefined8 *)(arg1 + 0x50) = 0;
    uVar2 = func_0x000180010030(arg1, 0x20);
    *(undefined *)(arg1 + 0x58) = uVar2;
    if (*(int64_t *)(arg1 + 0x48) == 0) {
        *(uint32_t *)(arg1 + 0x10) = *(uint32_t *)(arg1 + 0x10) & 0x13;
        *(uint32_t *)(arg1 + 0x10) = *(uint32_t *)(arg1 + 0x10) | 4;
        uVar3 = *(uint32_t *)(arg1 + 0x10) & *(uint32_t *)(arg1 + 0x14);
        if (uVar3 != 0) {
            if ((uVar3 & 4) == 0) {
                uVar5 = 0x1805aae00;
                if ((uVar3 & 2) == 0) {
                    uVar5 = 0x1805aae18;
                }
            } else {
                uVar5 = 0x1805aade8;
            }
            uVar6 = func_0x000180005e50(&var_68h, 1);
            func_0x0001800069f0(&var_58h, uVar5, uVar6);
            fcn.18045bae0(var_68h);
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    }
    if (in_R8B != '\0') {
        func_0x000180455ba0(arg1);
    }
    return;
}

// ============================================================
// Function: FUN_18000ff50
// Address: 0x18000ff50
// Size: 43 bytes
// ============================================================
int64_t fcn.18000ff50(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1805ab200;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x58);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18000ff80
// Address: 0x18000ff80
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18000ff80(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    iVar5 = *(int64_t *)(arg1 + 0x20);
    for (iVar6 = *(int64_t *)(arg1 + 0x18); iVar6 != iVar5; iVar6 = iVar6 + 0x20) {
        func_0x00018000dc80(iVar6);
    }
    iVar6 = *(int64_t *)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x20)) {
        iVar5 = *(int64_t *)(iVar6 + -8);
        if ((iVar6 - iVar5) - 8U < 0x20) goto code_r0x0001800f4640;
        pcVar1 = (code *)swi(0x29);
        iVar6 = (*pcVar1)(5);
        puVar7 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    iVar5 = iVar6;
code_r0x0001800f4640:
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18000ff90
// Address: 0x18000ff90
// Size: 71 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18000ff80(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    iVar5 = *(int64_t *)(arg1 + 0x20);
    for (iVar6 = *(int64_t *)(arg1 + 0x18); iVar6 != iVar5; iVar6 = iVar6 + 0x20) {
        func_0x00018000dc80(iVar6);
    }
    iVar6 = *(int64_t *)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x20)) {
        iVar5 = *(int64_t *)(iVar6 + -8);
        if ((iVar6 - iVar5) - 8U < 0x20) goto code_r0x0001800f4640;
        pcVar1 = (code *)swi(0x29);
        iVar6 = (*pcVar1)(5);
        puVar7 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    iVar5 = iVar6;
code_r0x0001800f4640:
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18000ffd7
// Address: 0x18000ffd7
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18000ff80(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    iVar5 = *(int64_t *)(arg1 + 0x20);
    for (iVar6 = *(int64_t *)(arg1 + 0x18); iVar6 != iVar5; iVar6 = iVar6 + 0x20) {
        func_0x00018000dc80(iVar6);
    }
    iVar6 = *(int64_t *)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x20)) {
        iVar5 = *(int64_t *)(iVar6 + -8);
        if ((iVar6 - iVar5) - 8U < 0x20) goto code_r0x0001800f4640;
        pcVar1 = (code *)swi(0x29);
        iVar6 = (*pcVar1)(5);
        puVar7 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    iVar5 = iVar6;
code_r0x0001800f4640:
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180010010
// Address: 0x180010010
// Size: 17 bytes
// ============================================================
void fcn.180010010(void)
{
    code *pcVar1;
    
    fcn.1804546d4(0x1805ab130);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180010030
// Address: 0x180010030
// Size: 109 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.180010030(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    uint64_t uVar3;
    undefined8 *puVar4;
    undefined in_DL;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_10h;
    
    piVar1 = *(int64_t **)(*(int64_t *)(arg1 + 0x40) + 8);
    var_10h = (int64_t)piVar1;
    (**(code **)(*piVar1 + 8))(piVar1);
    piVar2 = (int64_t *)fcn.18000a390(&var_18h);
    uVar3 = (**(code **)(*piVar2 + 0x40))(piVar2, in_DL);
    if (piVar1 != (int64_t *)0x0) {
        puVar4 = (undefined8 *)(**(code **)(*piVar1 + 0x10))(piVar1);
        if (puVar4 != (undefined8 *)0x0) {
            (**(code **)*puVar4)(puVar4, 1);
        }
        uVar3 = uVar3 & 0xff;
    }
    return uVar3;
}

// ============================================================
// Function: FUN_1800100a0
// Address: 0x1800100a0
// Size: 281 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018001011d: Changing call to branch
// WARNING: Possible PIC construction at 0x00018001018c: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180010122)
// WARNING: Removing unreachable block (ram,0x00018001012a)
// WARNING: Removing unreachable block (ram,0x000180010191)

int64_t * fcn.1800100a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    int64_t unaff_RBX;
    int64_t iVar7;
    undefined *puVar8;
    int64_t *piVar9;
    int64_t unaff_RDI;
    int64_t iVar10;
    int64_t var_8h;
    undefined auStack_70 [7];
    int64_t var_69h;
    
    iVar10 = arg3 + -1 >> 1;
    if (arg2 < iVar10) {
        iVar10 = arg2 * 2 + 2;
        _auStack_70 = 0x180010102;
        uVar5 = func_0x000180006fa0(iVar10 * 0x20 + arg1, arg1 + -0x20 + iVar10 * 0x20);
        if (0x7fffffff < uVar5) {
            iVar10 = arg2 * 2 + 1;
        }
        unaff_RBX = arg2 * 0x20;
        piVar6 = (int64_t *)(arg1 + unaff_RBX);
        *(undefined **)0x20 = (BADSPACEBASE *)auStack_70;
        _auStack_70 = 0x180010122;
        arg4 = (int64_t)(iVar10 * 0x20 + arg1);
    } else {
        iVar7 = arg2;
        if ((arg2 == iVar10) && ((arg3 & 1U) == 0)) {
            _auStack_70 = 0x180010152;
            func_0x00018000b1a0(arg1 + arg2 * 0x20, arg1 + -0x20 + arg3 * 0x20);
            iVar7 = arg3 + -1;
        }
        if (arg2 < iVar7) {
            iVar10 = iVar7 + -1 >> 1;
            piVar9 = (int64_t *)(iVar10 * 0x20 + arg1);
            _auStack_70 = 0x18001017c;
            uVar5 = func_0x000180006fa0(piVar9, arg4);
            if (0x7fffffff < uVar5) {
                unaff_RBX = iVar7 * 0x20;
                piVar6 = (int64_t *)(arg1 + unaff_RBX);
                *(undefined **)0x20 = (BADSPACEBASE *)auStack_70;
                _auStack_70 = 0x180010191;
                arg4 = (int64_t)piVar9;
                goto code_r0x00018000b1a0;
            }
        }
        iVar10 = unaff_RDI;
        piVar6 = (int64_t *)(arg1 + iVar7 * 0x20);
    }
code_r0x00018000b1a0:
    *(int64_t *)((int64_t)*(undefined **)0x20 + 8) = unaff_RBX;
    *(int64_t *)((int64_t)*(undefined **)0x20 + -8) = iVar10;
    if (piVar6 != (int64_t *)arg4) {
        if (7 < (uint64_t)piVar6[3]) {
            puVar8 = (undefined *)((int64_t)*(undefined **)0x20 + -0x28);
            if ((0xfff < piVar6[3] * 2 + 2U) &&
               (puVar8 = (undefined *)((int64_t)*(undefined **)0x20 + -0x28),
               0x1f < (*piVar6 - *(int64_t *)(*piVar6 + -8)) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                puVar8 = (undefined *)((int64_t)*(undefined **)0x20 + -0x20);
            }
            *(undefined8 *)(puVar8 + -8) = 0x18000b1f9;
            fcn.180459c3c();
        }
        piVar6[3] = 7;
        piVar6[2] = 0;
        *(undefined2 *)piVar6 = 0;
        uVar2 = *(undefined4 *)(arg4 + 4);
        uVar3 = *(undefined4 *)(arg4 + 8);
        uVar4 = *(undefined4 *)(arg4 + 0xc);
        *(undefined4 *)piVar6 = *(undefined4 *)arg4;
        *(undefined4 *)((int64_t)piVar6 + 4) = uVar2;
        *(undefined4 *)(piVar6 + 1) = uVar3;
        *(undefined4 *)((int64_t)piVar6 + 0xc) = uVar4;
        uVar2 = *(undefined4 *)(arg4 + 0x14);
        uVar3 = *(undefined4 *)(arg4 + 0x18);
        uVar4 = *(undefined4 *)(arg4 + 0x1c);
        *(undefined4 *)(piVar6 + 2) = *(undefined4 *)(arg4 + 0x10);
        *(undefined4 *)((int64_t)piVar6 + 0x14) = uVar2;
        *(undefined4 *)(piVar6 + 3) = uVar3;
        *(undefined4 *)((int64_t)piVar6 + 0x1c) = uVar4;
        *(int64_t *)(arg4 + 0x10) = 0;
        *(int64_t *)(arg4 + 0x18) = 7;
        *(undefined2 *)arg4 = 0;
    }
    return piVar6;
}

// ============================================================
// Function: FUN_1800101c0
// Address: 0x1800101c0
// Size: 172 bytes
// ============================================================
void fcn.1800101c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    uint32_t uVar12;
    
    uVar12 = func_0x000180006fa0(arg2, arg1);
    if ((0x7fffffff < uVar12) && (arg2 != arg1)) {
        uVar1 = *(undefined4 *)(arg1 + 4);
        uVar2 = *(undefined4 *)(arg1 + 8);
        uVar3 = *(undefined4 *)(arg1 + 0xc);
        uVar4 = *(undefined4 *)arg2;
        uVar5 = *(undefined4 *)(arg2 + 4);
        uVar6 = *(undefined4 *)(arg2 + 8);
        uVar7 = *(undefined4 *)(arg2 + 0xc);
        uVar8 = *(undefined4 *)(arg2 + 0x10);
        uVar9 = *(undefined4 *)(arg2 + 0x14);
        uVar10 = *(undefined4 *)(arg2 + 0x18);
        uVar11 = *(undefined4 *)(arg2 + 0x1c);
        *(undefined4 *)arg2 = *(undefined4 *)arg1;
        *(undefined4 *)(arg2 + 4) = uVar1;
        *(undefined4 *)(arg2 + 8) = uVar2;
        *(undefined4 *)(arg2 + 0xc) = uVar3;
        uVar1 = *(undefined4 *)(arg1 + 0x14);
        uVar2 = *(undefined4 *)(arg1 + 0x18);
        uVar3 = *(undefined4 *)(arg1 + 0x1c);
        *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(arg1 + 0x10);
        *(undefined4 *)(arg2 + 0x14) = uVar1;
        *(undefined4 *)(arg2 + 0x18) = uVar2;
        *(undefined4 *)(arg2 + 0x1c) = uVar3;
        *(undefined4 *)arg1 = uVar4;
        *(undefined4 *)(arg1 + 4) = uVar5;
        *(undefined4 *)(arg1 + 8) = uVar6;
        *(undefined4 *)(arg1 + 0xc) = uVar7;
        *(undefined4 *)(arg1 + 0x10) = uVar8;
        *(undefined4 *)(arg1 + 0x14) = uVar9;
        *(undefined4 *)(arg1 + 0x18) = uVar10;
        *(undefined4 *)(arg1 + 0x1c) = uVar11;
    }
    uVar12 = func_0x000180006fa0(arg3, arg2);
    if (0x7fffffff < uVar12) {
        if (arg3 != arg2) {
            uVar1 = *(undefined4 *)(arg2 + 4);
            uVar2 = *(undefined4 *)(arg2 + 8);
            uVar3 = *(undefined4 *)(arg2 + 0xc);
            uVar4 = *(undefined4 *)arg3;
            uVar5 = *(undefined4 *)(arg3 + 4);
            uVar6 = *(undefined4 *)(arg3 + 8);
            uVar7 = *(undefined4 *)(arg3 + 0xc);
            uVar8 = *(undefined4 *)(arg3 + 0x10);
            uVar9 = *(undefined4 *)(arg3 + 0x14);
            uVar10 = *(undefined4 *)(arg3 + 0x18);
            uVar11 = *(undefined4 *)(arg3 + 0x1c);
            *(undefined4 *)arg3 = *(undefined4 *)arg2;
            *(undefined4 *)(arg3 + 4) = uVar1;
            *(undefined4 *)(arg3 + 8) = uVar2;
            *(undefined4 *)(arg3 + 0xc) = uVar3;
            uVar1 = *(undefined4 *)(arg2 + 0x14);
            uVar2 = *(undefined4 *)(arg2 + 0x18);
            uVar3 = *(undefined4 *)(arg2 + 0x1c);
            *(undefined4 *)(arg3 + 0x10) = *(undefined4 *)(arg2 + 0x10);
            *(undefined4 *)(arg3 + 0x14) = uVar1;
            *(undefined4 *)(arg3 + 0x18) = uVar2;
            *(undefined4 *)(arg3 + 0x1c) = uVar3;
            *(undefined4 *)arg2 = uVar4;
            *(undefined4 *)(arg2 + 4) = uVar5;
            *(undefined4 *)(arg2 + 8) = uVar6;
            *(undefined4 *)(arg2 + 0xc) = uVar7;
            *(undefined4 *)(arg2 + 0x10) = uVar8;
            *(undefined4 *)(arg2 + 0x14) = uVar9;
            *(undefined4 *)(arg2 + 0x18) = uVar10;
            *(undefined4 *)(arg2 + 0x1c) = uVar11;
        }
        uVar12 = func_0x000180006fa0(arg2, arg1);
        if ((0x7fffffff < uVar12) && (arg2 != arg1)) {
            uVar1 = *(undefined4 *)(arg1 + 4);
            uVar2 = *(undefined4 *)(arg1 + 8);
            uVar3 = *(undefined4 *)(arg1 + 0xc);
            uVar4 = *(undefined4 *)arg2;
            uVar5 = *(undefined4 *)(arg2 + 4);
            uVar6 = *(undefined4 *)(arg2 + 8);
            uVar7 = *(undefined4 *)(arg2 + 0xc);
            uVar8 = *(undefined4 *)(arg2 + 0x10);
            uVar9 = *(undefined4 *)(arg2 + 0x14);
            uVar10 = *(undefined4 *)(arg2 + 0x18);
            uVar11 = *(undefined4 *)(arg2 + 0x1c);
            *(undefined4 *)arg2 = *(undefined4 *)arg1;
            *(undefined4 *)(arg2 + 4) = uVar1;
            *(undefined4 *)(arg2 + 8) = uVar2;
            *(undefined4 *)(arg2 + 0xc) = uVar3;
            uVar1 = *(undefined4 *)(arg1 + 0x14);
            uVar2 = *(undefined4 *)(arg1 + 0x18);
            uVar3 = *(undefined4 *)(arg1 + 0x1c);
            *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(arg1 + 0x10);
            *(undefined4 *)(arg2 + 0x14) = uVar1;
            *(undefined4 *)(arg2 + 0x18) = uVar2;
            *(undefined4 *)(arg2 + 0x1c) = uVar3;
            *(undefined4 *)arg1 = uVar4;
            *(undefined4 *)(arg1 + 4) = uVar5;
            *(undefined4 *)(arg1 + 8) = uVar6;
            *(undefined4 *)(arg1 + 0xc) = uVar7;
            *(undefined4 *)(arg1 + 0x10) = uVar8;
            *(undefined4 *)(arg1 + 0x14) = uVar9;
            *(undefined4 *)(arg1 + 0x18) = uVar10;
            *(undefined4 *)(arg1 + 0x1c) = uVar11;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180010270
// Address: 0x180010270
// Size: 17 bytes
// ============================================================
void fcn.180010270(void)
{
    code *pcVar1;
    
    fcn.1804546d4(0x1805ab158);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800102d0
// Address: 0x1800102d0
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int32_t fcn.1800102d0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    
    var_20h = arg4;
    fcn.1800102c0();
    iVar1 = fcn.1804677a8(0, (int64_t)&var_20h);
    if (iVar1 < 0) {
        iVar1 = -1;
    }
    return iVar1;
}

// ============================================================
// Function: FUN_180010330
// Address: 0x180010330
// Size: 128 bytes
// ============================================================
undefined8 fcn.180010330(void)
{
    int64_t unaff_GS_OFFSET;
    
    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
        *(int32_t *)0x1807827a8) {
        fcn.180459d18(0x1807827a8);
        if (*(int32_t *)0x1807827a8 == -1) {
            *(undefined **)0x180782790 = (undefined *)fcn.180459890(1);
            **(undefined **)0x180782790 = 0;
            fcn.180459c24(0x1804a1ff0);
            fcn.180459cac(0x1807827a8);
            return 0x180782790;
        }
    }
    return 0x180782790;
}

// ============================================================
// Function: FUN_1800103b0
// Address: 0x1800103b0
// Size: 729 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800103b0(int64_t arg1, int64_t arg2)
{
    uint8_t uVar1;
    int64_t *piVar2;
    int64_t arg1_00;
    uint8_t *puVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    uint32_t uVar10;
    int64_t iVar11;
    undefined8 uVar12;
    bool bVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_28h;
    
    iVar11 = 0;
    uVar10 = 0;
    iVar7 = func_0x000180498cd0(arg2);
    iVar9 = *(int64_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x28 + arg1);
    if ((0 < iVar9) && (iVar7 < iVar9)) {
        iVar11 = iVar9 - iVar7;
    }
    piVar2 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
    if (piVar2 != (int64_t *)0x0) {
        (**(code **)(*piVar2 + 8))();
    }
    iVar9 = *(int64_t *)arg1;
    if (*(int32_t *)((int64_t)*(int32_t *)(iVar9 + 4) + 0x10 + arg1) == 0) {
        arg1_00 = *(int64_t *)((int64_t)*(int32_t *)(iVar9 + 4) + 0x50 + arg1);
        if ((arg1_00 == 0) || (arg1_00 == arg1)) {
            bVar13 = true;
        } else {
            fcn.18000fad0(arg1_00);
            iVar9 = *(int64_t *)arg1;
            bVar13 = *(int32_t *)((int64_t)*(int32_t *)(iVar9 + 4) + 0x10 + arg1) == 0;
        }
    } else {
        bVar13 = false;
    }
    if (bVar13) {
        if ((*(uint32_t *)((int64_t)*(int32_t *)(iVar9 + 4) + 0x18 + arg1) & 0x1c0) != 0x40) {
            for (; 0 < iVar11; iVar11 = iVar11 + -1) {
                piVar2 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
                uVar1 = *(uint8_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x58 + arg1);
                if (*(int64_t *)piVar2[8] == 0) {
code_r0x0001800104d5:
                    uVar5 = (**(code **)(*piVar2 + 0x18))(piVar2, uVar1);
                } else {
                    iVar6 = *(int32_t *)piVar2[0xb];
                    if (iVar6 < 1) goto code_r0x0001800104d5;
                    *(int32_t *)piVar2[0xb] = iVar6 + -1;
                    puVar3 = *(uint8_t **)piVar2[8];
                    *(uint8_t **)piVar2[8] = puVar3 + 1;
                    *puVar3 = uVar1;
                    uVar5 = (uint32_t)uVar1;
                }
                if (uVar5 == 0xffffffff) {
                    uVar10 = 4;
                    goto code_r0x0001800105a0;
                }
            }
        }
        piVar2 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
        iVar9 = (**(code **)(*piVar2 + 0x48))(piVar2, arg2, iVar7);
        if (iVar9 == iVar7) {
            for (; 0 < iVar11; iVar11 = iVar11 + -1) {
                piVar2 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
                uVar1 = *(uint8_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x58 + arg1);
                if (*(int64_t *)piVar2[8] == 0) {
code_r0x000180010575:
                    uVar5 = (**(code **)(*piVar2 + 0x18))(piVar2, uVar1);
                } else {
                    iVar6 = *(int32_t *)piVar2[0xb];
                    if (iVar6 < 1) goto code_r0x000180010575;
                    *(int32_t *)piVar2[0xb] = iVar6 + -1;
                    puVar3 = *(uint8_t **)piVar2[8];
                    *(uint8_t **)piVar2[8] = puVar3 + 1;
                    *puVar3 = uVar1;
                    uVar5 = (uint32_t)uVar1;
                }
                if (uVar5 == 0xffffffff) {
                    uVar10 = 4;
                    break;
                }
            }
        } else {
            uVar10 = 4;
        }
code_r0x0001800105a0:
        *(undefined8 *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x28 + arg1) = 0;
    } else {
        uVar10 = 4;
    }
    iVar9 = (int64_t)*(int32_t *)(*(int64_t *)arg1 + 4);
    uVar5 = 4;
    if (*(int64_t *)(iVar9 + 0x48 + arg1) != 0) {
        uVar5 = 0;
    }
    uVar10 = uVar5 | *(uint32_t *)(iVar9 + 0x10 + arg1) & 0x17 | uVar10;
    *(uint32_t *)(iVar9 + 0x10 + arg1) = uVar10;
    uVar10 = uVar10 & *(uint32_t *)(iVar9 + 0x14 + arg1);
    if (uVar10 != 0) {
        if ((uVar10 & 4) == 0) {
            uVar12 = 0x1805aae00;
            if ((uVar10 & 2) == 0) {
                uVar12 = 0x1805aae18;
            }
        } else {
            uVar12 = 0x1805aade8;
        }
        uVar8 = func_0x000180005e50(&var_68h, 1);
        func_0x0001800069f0(&var_58h, uVar12, uVar8);
        fcn.18045bae0(arg1);
        pcVar4 = (code *)swi(3);
        iVar9 = (*pcVar4)();
        return iVar9;
    }
    iVar6 = func_0x0001804557c0();
    if (iVar6 == 0) {
        fcn.18000fc20(arg1);
    }
    piVar2 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
    if (piVar2 != (int64_t *)0x0) {
        (**(code **)(*piVar2 + 0x10))();
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800106c0
// Address: 0x1800106c0
// Size: 266 bytes
// ============================================================
int64_t fcn.1800106c0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined *puVar6;
    char in_R8B;
    int64_t var_1h;
    undefined8 uStack_50;
    undefined auStack_48 [32];
    
    puVar6 = auStack_48;
    uVar5 = 0;
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    if (0x7fffffffffffffff < (uint64_t)arg2) {
        fcn.1800047c0();
        pcVar1 = (code *)swi(3);
        iVar4 = (*pcVar1)();
        return iVar4;
    }
    if ((uint64_t)arg2 < 0x10) {
        *(int64_t *)(arg1 + 0x10) = arg2;
        *(undefined8 *)(arg1 + 0x18) = 0xf;
        fcn.1804986e0(0, (int32_t)in_R8B, arg2);
        *(undefined *)(arg2 + arg1) = 0;
        return arg1;
    }
    uVar2 = arg2 | 0xf;
    if (uVar2 < 0x8000000000000000) goto code_r0x000180010751;
    uVar3 = 0x8000000000000027;
    puVar6 = auStack_48;
    uVar2 = 0x7fffffffffffffff;
    while( true ) {
        *(undefined8 *)(puVar6 + -8) = 0x180010745;
        iVar4 = fcn.180459890(uVar3);
        if (iVar4 != 0) break;
        pcVar1 = (code *)swi(0x29);
        uVar2 = (*pcVar1)(5);
        puVar6 = puVar6 + 8;
code_r0x000180010751:
        if (uVar2 < 0x16) {
            uVar2 = 0x16;
        }
        if (uVar2 == 0xffffffffffffffff) goto code_r0x000180010793;
        if (uVar2 + 1 < 0x1000) {
            *(undefined8 *)(puVar6 + -8) = 0x180010790;
            uVar5 = fcn.180459890();
            goto code_r0x000180010793;
        }
        uVar3 = uVar2 + 0x28;
        if (uVar3 <= uVar2 + 1) {
            *(undefined8 *)(puVar6 + -8) = 0x1800107c9;
            fcn.180004720();
            pcVar1 = (code *)swi(3);
            iVar4 = (*pcVar1)();
            return iVar4;
        }
    }
    uVar5 = iVar4 + 0x27U & 0xffffffffffffffe0;
    *(int64_t *)(uVar5 - 8) = iVar4;
code_r0x000180010793:
    *(uint64_t *)arg1 = uVar5;
    *(int64_t *)(arg1 + 0x10) = arg2;
    *(uint64_t *)(arg1 + 0x18) = uVar2;
    *(undefined8 *)(puVar6 + -8) = 0x1800107ac;
    fcn.1804986e0(uVar5, (int32_t)in_R8B, arg2);
    *(undefined *)(uVar5 + arg2) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_1800107d0
// Address: 0x1800107d0
// Size: 550 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_77h
// WARNING: [rz-ghidra] Detected overlap for variable var_87h
// WARNING: [rz-ghidra] Detected overlap for variable var_73h
// WARNING: [rz-ghidra] Detected overlap for variable var_83h
// WARNING: [rz-ghidra] Detected overlap for variable var_71h
// WARNING: [rz-ghidra] Detected overlap for variable var_81h

int64_t fcn.1800107d0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t arg1_00;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 *puVar5;
    undefined8 uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    
    uVar8 = 0;
    piVar1 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
    var_78h = arg1;
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 8))();
    }
    iVar10 = *(int64_t *)arg1;
    if (*(int32_t *)((int64_t)*(int32_t *)(iVar10 + 4) + 0x10 + arg1) == 0) {
        arg1_00 = *(int64_t *)((int64_t)*(int32_t *)(iVar10 + 4) + 0x50 + arg1);
        if ((arg1_00 == 0) || (arg1_00 == arg1)) {
            var_70h._0_1_ = true;
        } else {
            fcn.18000fad0(arg1_00);
            iVar10 = *(int64_t *)arg1;
            var_70h._0_1_ = *(int32_t *)((int64_t)*(int32_t *)(iVar10 + 4) + 0x10 + arg1) == 0;
        }
    } else {
        var_70h._0_1_ = false;
    }
    if ((bool)(undefined)var_70h) {
        piVar1 = *(int64_t **)(*(int64_t *)((int64_t)*(int32_t *)(iVar10 + 4) + 0x40 + arg1) + 8);
        var_80h = (int64_t)piVar1;
        (**(code **)(*piVar1 + 8))(piVar1);
        piVar4 = (int64_t *)func_0x000180010a00(&var_88h);
        if ((piVar1 != (int64_t *)0x0) &&
           (puVar5 = (undefined8 *)(**(code **)(*piVar1 + 0x10))(piVar1), puVar5 != (undefined8 *)0x0)) {
            (**(code **)*puVar5)(puVar5, 1);
        }
        iVar10 = *(int32_t *)(*(int64_t *)arg1 + 4) + arg1;
        var_88h._0_1_ = 0;
        var_88h._1_4_ = var_78h._1_4_;
        var_88h._5_2_ = var_78h._5_2_;
        var_88h._7_1_ = var_78h._7_1_;
        var_80h = *(int64_t *)(iVar10 + 0x48);
        var_98h._0_1_ = *(undefined *)(iVar10 + 0x58);
        (**(code **)(*piVar4 + 0x30))(piVar4, &var_68h, &var_88h, iVar10, (undefined)var_98h, arg2);
        uVar8 = 0;
        if ((char)var_68h != '\0') {
            uVar8 = 4;
        }
    }
    iVar10 = (int64_t)*(int32_t *)(*(int64_t *)arg1 + 4);
    uVar7 = 4;
    if (*(int64_t *)(iVar10 + 0x48 + arg1) != 0) {
        uVar7 = 0;
    }
    uVar8 = uVar7 | *(uint32_t *)(iVar10 + 0x10 + arg1) & 0x17 | uVar8;
    *(uint32_t *)(iVar10 + 0x10 + arg1) = uVar8;
    uVar8 = uVar8 & *(uint32_t *)(iVar10 + 0x14 + arg1);
    if (uVar8 != 0) {
        if ((uVar8 & 4) == 0) {
            uVar9 = 0x1805aae00;
            if ((uVar8 & 2) == 0) {
                uVar9 = 0x1805aae18;
            }
        } else {
            uVar9 = 0x1805aade8;
        }
        uVar6 = func_0x000180005e50(&var_68h, 1);
        func_0x0001800069f0(&var_58h, uVar9, uVar6);
        fcn.18045bae0(CONCAT71(var_98h._1_7_, (undefined)var_98h));
        pcVar2 = (code *)swi(3);
        iVar10 = (*pcVar2)();
        return iVar10;
    }
    iVar3 = func_0x0001804557c0();
    if (iVar3 == 0) {
        fcn.18000fc20(arg1);
    }
    piVar1 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x10))();
    }
    return arg1;
}

// ============================================================
// Function: FUN_180010a00
// Address: 0x180010a00
// Size: 271 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.180010a00(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    func_0x000180455714(&var_10h, 0);
    iVar5 = *(int64_t *)0x180782450;
    var_18h = *(int64_t *)0x180782450;
    if (*(uint64_t *)0x180782798 == 0) {
        func_0x000180455714(&var_8h, 0);
        if (*(uint64_t *)0x180782798 == 0) {
            *(int32_t *)0x180780f30 = *(int32_t *)0x180780f30 + 1;
            *(uint64_t *)0x180782798 = (uint64_t)*(int32_t *)0x180780f30;
        }
        func_0x00018045578c();
    }
    uVar3 = *(uint64_t *)0x180782798;
    iVar4 = *(int64_t *)(arg1 + 8);
    iVar1 = *(uint64_t *)0x180782798 * 8;
    if (*(uint64_t *)0x180782798 < *(uint64_t *)(iVar4 + 0x18)) {
        iVar6 = *(int64_t *)(iVar1 + *(int64_t *)(iVar4 + 0x10));
        if (iVar6 != 0) goto code_r0x000180010a93;
    } else {
        iVar6 = 0;
    }
    if (*(char *)(iVar4 + 0x24) == '\0') {
code_r0x000180010ac8:
        if (iVar6 != 0) goto code_r0x000180010a93;
    } else {
        iVar4 = func_0x0001804558e0();
        if (uVar3 < *(uint64_t *)(iVar4 + 0x18)) {
            iVar6 = *(int64_t *)(iVar1 + *(int64_t *)(iVar4 + 0x10));
            goto code_r0x000180010ac8;
        }
    }
    iVar6 = iVar5;
    if (iVar5 == 0) {
        iVar5 = func_0x000180012800(&var_18h, arg1);
        iVar6 = var_18h;
        if (iVar5 == -1) {
            func_0x000180005b10();
            pcVar2 = (code *)swi(3);
            iVar5 = (*pcVar2)();
            return iVar5;
        }
        iVar5 = var_18h;
        var_8h = var_18h;
        func_0x0001804558a4(var_18h);
        (**(code **)(*(int64_t *)iVar6 + 8))(iVar6);
        *(int64_t *)0x180782450 = iVar5;
    }
code_r0x000180010a93:
    func_0x00018045578c(&var_10h);
    return iVar6;
}

// ============================================================
// Function: FUN_180010b10
// Address: 0x180010b10
// Size: 156 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: Variable defined which should be unmapped: var_88h

void fcn.180010b10(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    undefined auStackY_b8 [32];
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    undefined4 uStack_70;
    undefined4 uStack_6c;
    int64_t var_68h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_b8;
    var_78h._0_4_ = *(undefined4 *)arg3;
    var_78h._4_4_ = *(undefined4 *)(arg3 + 4);
    uStack_70 = *(undefined4 *)(arg3 + 8);
    uStack_6c = *(undefined4 *)(arg3 + 0xc);
    iVar1 = fcn.1800102d0((int64_t)&var_68h, 0x40, 0x1805ab2d8, arg_30h);
    var_88h = (int64_t)iVar1;
    var_90h = (int64_t)&var_68h;
    var_98h._0_1_ = (undefined)arg_28h;
    fcn.1800121d0(CONCAT71(var_98h._1_7_, (undefined)arg_28h), var_90h, var_88h);
    fcn.180459870(var_28h ^ (uint64_t)auStackY_b8);
    return;
}

// ============================================================
// Function: FUN_180010bb0
// Address: 0x180010bb0
// Size: 757 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_57h
// WARNING: [rz-ghidra] Detected overlap for variable var_56h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h

void fcn.180010bb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint64_t uVar1;
    code *pcVar2;
    undefined auVar3 [16];
    undefined uVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    undefined2 *puVar8;
    uint32_t uVar9;
    int64_t iVar10;
    undefined *puVar11;
    uint64_t arg2_00;
    uint64_t uVar12;
    undefined uVar13;
    int64_t var_8h;
    undefined auStackY_d8 [8];
    undefined auStackY_d0 [24];
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    undefined4 uStack_80;
    undefined4 uStack_7c;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar11 = auStackY_d8;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_d8;
    var_68h = 0;
    var_60h = 0xf;
    stack0xffffffffffffff89 = SUB1615(ZEXT816(0), 1);
    auVar3[15] = 0;
    auVar3._0_15_ = stack0xffffffffffffff89;
    _var_78h = auVar3 << 8;
    uVar5 = *(uint32_t *)(arg4 + 0x18) & 0x3000;
    if (uVar5 == 0x3000) {
        uVar12 = 0xffffffffffffffff;
        iVar10 = 0xd;
    } else {
        uVar12 = *(uint64_t *)(arg4 + 0x20);
        if ((int64_t)uVar12 < 1) {
            if (uVar12 == 0) {
                if (uVar5 == 0) {
                    iVar10 = 1;
                    goto code_r0x000180010ca5;
                }
                iVar6 = 0;
            } else {
                iVar6 = 6;
            }
        } else {
            iVar6 = (int32_t)uVar12;
        }
        iVar10 = (int64_t)iVar6;
        if ((uVar5 == 0x2000) &&
           (10000000000.0 <= (double)(arg_30h & 0x7fffffffffffffff) &&
            (double)(arg_30h & 0x7fffffffffffffff) != 10000000000.0)) {
            func_0x000180467d50((int32_t)arg_30h, (int64_t)&var_98h + 4);
            iVar6 = -var_98h._4_4_;
            if (0 < var_98h._4_4_) {
                iVar6 = var_98h._4_4_;
            }
            iVar10 = iVar10 + (iVar6 * 0x7597) / 100000;
        }
    }
code_r0x000180010ca5:
    uVar1 = iVar10 + 0x32;
    if ((uint64_t)var_68h < uVar1) {
        arg2_00 = uVar1 - var_68h;
        if ((uint64_t)(var_60h - var_68h) < arg2_00) {
            var_b8h = var_b8h & 0xffffffffffffff00;
            fcn.18000f2f0((int64_t)&var_78h, arg2_00, (uint64_t)(uint8_t)var_98h, arg2_00, var_b8h);
        } else {
            piVar7 = &var_78h;
            if (0xf < (uint64_t)var_60h) {
                piVar7 = (int64_t *)var_78h;
            }
            iVar10 = (int64_t)piVar7 + var_68h;
            var_68h = uVar1;
            fcn.1804986e0(iVar10, 0, arg2_00);
            *(undefined *)(iVar10 + arg2_00) = 0;
        }
    } else {
        piVar7 = &var_78h;
        if (0xf < (uint64_t)var_60h) {
            piVar7 = (int64_t *)var_78h;
        }
        var_68h = uVar1;
        *(undefined *)(uVar1 + (int64_t)piVar7) = 0;
    }
    var_a0h._0_1_ = ((uint32_t)((uint64_t)arg_30h >> 0x34) & 0x7ff) != 0x7ff;
    uVar5 = *(uint32_t *)(arg4 + 0x18);
    if (!(bool)(undefined)var_a0h) {
        uVar5 = uVar5 & 0xffffffef;
    }
    var_58h._0_1_ = 0x25;
    if ((uVar5 & 0x20) != 0) {
        var_58h._1_1_ = 0x2b;
    }
    puVar8 = (undefined2 *)((int64_t)&var_58h + 1);
    if ((uVar5 & 0x20) != 0) {
        puVar8 = (undefined2 *)((int64_t)&var_58h + 2);
    }
    if ((uVar5 & 0x10) != 0) {
        *(undefined *)puVar8 = 0x23;
        puVar8 = (undefined2 *)((int64_t)puVar8 + 1);
    }
    *puVar8 = 0x2a2e;
    *(undefined *)(puVar8 + 1) = 0x4c;
    uVar9 = uVar5 & 0x3000;
    if ((uVar5 & 4) == 0) {
        if (uVar9 == 0x2000) {
            uVar4 = 0x66;
            goto code_r0x000180010dc5;
        }
        if (uVar9 == 0x3000) {
            uVar4 = 0x61;
            goto code_r0x000180010dc5;
        }
        uVar4 = 0x67;
        uVar13 = 0x65;
    } else {
        if (uVar9 == 0x2000) {
            uVar4 = 0x46;
            goto code_r0x000180010dc5;
        }
        if (uVar9 == 0x3000) {
            uVar4 = 0x41;
            goto code_r0x000180010dc5;
        }
        uVar4 = 0x47;
        uVar13 = 0x45;
    }
    if (uVar9 == 0x1000) {
        uVar4 = uVar13;
    }
code_r0x000180010dc5:
    *(undefined *)((int64_t)puVar8 + 3) = uVar4;
    *(undefined *)(puVar8 + 2) = 0;
    piVar7 = &var_78h;
    if (0xf < (uint64_t)var_60h) {
        piVar7 = (int64_t *)var_78h;
    }
    var_b8h = arg_30h;
    iVar6 = fcn.1800102d0((int64_t)piVar7, var_68h, (int64_t)&var_58h, uVar12 & 0xffffffff);
    var_a8h = (int64_t)iVar6;
    var_b0h = (int64_t)&var_78h;
    if (0xf < (uint64_t)var_60h) {
        var_b0h = var_78h;
    }
    var_88h._0_4_ = *(undefined4 *)arg3;
    var_88h._4_4_ = *(undefined4 *)(arg3 + 4);
    uStack_80 = *(undefined4 *)(arg3 + 8);
    uStack_7c = *(undefined4 *)(arg3 + 0xc);
    var_b8h = CONCAT71(var_b8h._1_7_, (undefined)arg_28h);
    func_0x000180011900(arg1, arg2, &var_88h, arg4);
    if (0xf < (uint64_t)var_60h) {
        iVar10 = var_78h;
        puVar11 = auStackY_d8;
        if ((0xfff < var_60h + 1U) &&
           (iVar10 = *(int64_t *)(var_78h + -8), puVar11 = auStackY_d8, 0x1f < (var_78h - iVar10) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar10 = (*pcVar2)(5);
            puVar11 = auStackY_d0;
        }
        *(undefined8 *)(puVar11 + -8) = 0x180010e73;
        fcn.180459c3c(iVar10);
    }
    *(undefined8 *)(puVar11 + -8) = 0x180010e82;
    fcn.180459870(var_50h ^ (uint64_t)puVar11);
    return;
}

// ============================================================
// Function: FUN_180010eb0
// Address: 0x180010eb0
// Size: 753 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_57h
// WARNING: [rz-ghidra] Detected overlap for variable var_56h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h

void fcn.180010eb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint64_t uVar1;
    code *pcVar2;
    undefined auVar3 [16];
    undefined uVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    undefined2 *puVar8;
    uint32_t uVar9;
    int64_t iVar10;
    undefined *puVar11;
    uint64_t arg2_00;
    uint64_t uVar12;
    undefined uVar13;
    int64_t var_8h;
    undefined auStackY_d8 [8];
    undefined auStackY_d0 [24];
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    undefined4 uStack_80;
    undefined4 uStack_7c;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar11 = auStackY_d8;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_d8;
    var_68h = 0;
    var_60h = 0xf;
    stack0xffffffffffffff89 = SUB1615(ZEXT816(0), 1);
    auVar3[15] = 0;
    auVar3._0_15_ = stack0xffffffffffffff89;
    _var_78h = auVar3 << 8;
    uVar5 = *(uint32_t *)(arg4 + 0x18) & 0x3000;
    if (uVar5 == 0x3000) {
        uVar12 = 0xffffffffffffffff;
        iVar10 = 0xd;
    } else {
        uVar12 = *(uint64_t *)(arg4 + 0x20);
        if ((int64_t)uVar12 < 1) {
            if (uVar12 == 0) {
                if (uVar5 == 0) {
                    iVar10 = 1;
                    goto code_r0x000180010fa5;
                }
                iVar6 = 0;
            } else {
                iVar6 = 6;
            }
        } else {
            iVar6 = (int32_t)uVar12;
        }
        iVar10 = (int64_t)iVar6;
        if ((uVar5 == 0x2000) &&
           (10000000000.0 <= (double)(arg_30h & 0x7fffffffffffffff) &&
            (double)(arg_30h & 0x7fffffffffffffff) != 10000000000.0)) {
            func_0x000180467d50((int32_t)arg_30h, (int64_t)&var_98h + 4);
            iVar6 = -var_98h._4_4_;
            if (0 < var_98h._4_4_) {
                iVar6 = var_98h._4_4_;
            }
            iVar10 = iVar10 + (iVar6 * 0x7597) / 100000;
        }
    }
code_r0x000180010fa5:
    uVar1 = iVar10 + 0x32;
    if ((uint64_t)var_68h < uVar1) {
        arg2_00 = uVar1 - var_68h;
        if ((uint64_t)(var_60h - var_68h) < arg2_00) {
            var_b8h = var_b8h & 0xffffffffffffff00;
            fcn.18000f2f0((int64_t)&var_78h, arg2_00, (uint64_t)(uint8_t)var_98h, arg2_00, var_b8h);
        } else {
            piVar7 = &var_78h;
            if (0xf < (uint64_t)var_60h) {
                piVar7 = (int64_t *)var_78h;
            }
            iVar10 = (int64_t)piVar7 + var_68h;
            var_68h = uVar1;
            fcn.1804986e0(iVar10, 0, arg2_00);
            *(undefined *)(iVar10 + arg2_00) = 0;
        }
    } else {
        piVar7 = &var_78h;
        if (0xf < (uint64_t)var_60h) {
            piVar7 = (int64_t *)var_78h;
        }
        var_68h = uVar1;
        *(undefined *)(uVar1 + (int64_t)piVar7) = 0;
    }
    var_a0h._0_1_ = ((uint32_t)((uint64_t)arg_30h >> 0x34) & 0x7ff) != 0x7ff;
    uVar5 = *(uint32_t *)(arg4 + 0x18);
    if (!(bool)(undefined)var_a0h) {
        uVar5 = uVar5 & 0xffffffef;
    }
    var_58h._0_1_ = 0x25;
    if ((uVar5 & 0x20) != 0) {
        var_58h._1_1_ = 0x2b;
    }
    puVar8 = (undefined2 *)((int64_t)&var_58h + 1);
    if ((uVar5 & 0x20) != 0) {
        puVar8 = (undefined2 *)((int64_t)&var_58h + 2);
    }
    if ((uVar5 & 0x10) != 0) {
        *(undefined *)puVar8 = 0x23;
        puVar8 = (undefined2 *)((int64_t)puVar8 + 1);
    }
    *puVar8 = 0x2a2e;
    uVar9 = uVar5 & 0x3000;
    if ((uVar5 & 4) == 0) {
        if (uVar9 == 0x2000) {
            uVar4 = 0x66;
            goto code_r0x0001800110c1;
        }
        if (uVar9 == 0x3000) {
            uVar4 = 0x61;
            goto code_r0x0001800110c1;
        }
        uVar4 = 0x67;
        uVar13 = 0x65;
    } else {
        if (uVar9 == 0x2000) {
            uVar4 = 0x46;
            goto code_r0x0001800110c1;
        }
        if (uVar9 == 0x3000) {
            uVar4 = 0x41;
            goto code_r0x0001800110c1;
        }
        uVar4 = 0x47;
        uVar13 = 0x45;
    }
    if (uVar9 == 0x1000) {
        uVar4 = uVar13;
    }
code_r0x0001800110c1:
    *(undefined *)(puVar8 + 1) = uVar4;
    *(undefined *)((int64_t)puVar8 + 3) = 0;
    piVar7 = &var_78h;
    if (0xf < (uint64_t)var_60h) {
        piVar7 = (int64_t *)var_78h;
    }
    var_b8h = arg_30h;
    iVar6 = fcn.1800102d0((int64_t)piVar7, var_68h, (int64_t)&var_58h, uVar12 & 0xffffffff);
    var_a8h = (int64_t)iVar6;
    var_b0h = (int64_t)&var_78h;
    if (0xf < (uint64_t)var_60h) {
        var_b0h = var_78h;
    }
    var_88h._0_4_ = *(undefined4 *)arg3;
    var_88h._4_4_ = *(undefined4 *)(arg3 + 4);
    uStack_80 = *(undefined4 *)(arg3 + 8);
    uStack_7c = *(undefined4 *)(arg3 + 0xc);
    var_b8h = CONCAT71(var_b8h._1_7_, (undefined)arg_28h);
    func_0x000180011900(arg1, arg2, &var_88h, arg4);
    if (0xf < (uint64_t)var_60h) {
        iVar10 = var_78h;
        puVar11 = auStackY_d8;
        if ((0xfff < var_60h + 1U) &&
           (iVar10 = *(int64_t *)(var_78h + -8), puVar11 = auStackY_d8, 0x1f < (var_78h - iVar10) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar10 = (*pcVar2)(5);
            puVar11 = auStackY_d0;
        }
        *(undefined8 *)(puVar11 + -8) = 0x18001116f;
        fcn.180459c3c(iVar10);
    }
    *(undefined8 *)(puVar11 + -8) = 0x18001117e;
    fcn.180459870(var_50h ^ (uint64_t)puVar11);
    return;
}

// ============================================================
// Function: FUN_1800111b0
// Address: 0x1800111b0
// Size: 258 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_a8h
// WARNING: Variable defined which should be unmapped: var_a0h
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_77h
// WARNING: [rz-ghidra] Detected overlap for variable var_76h

void fcn.1800111b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint32_t uVar1;
    uint8_t uVar2;
    int32_t iVar3;
    undefined2 *puVar4;
    undefined auStackY_c8 [32];
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    undefined4 uStack_80;
    undefined4 uStack_7c;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_c8;
    uVar1 = *(uint32_t *)(arg4 + 0x18);
    var_78h._0_1_ = 0x25;
    if ((uVar1 & 0x20) != 0) {
        var_78h._1_1_ = 0x2b;
    }
    puVar4 = (undefined2 *)((int64_t)&var_78h + 1);
    if ((uVar1 & 0x20) != 0) {
        puVar4 = (undefined2 *)((int64_t)&var_78h + 2);
    }
    if ((uVar1 & 8) != 0) {
        *(undefined *)puVar4 = 0x23;
        puVar4 = (undefined2 *)((int64_t)puVar4 + 1);
    }
    *puVar4 = 0x3649;
    *(undefined *)(puVar4 + 1) = 0x34;
    if ((uVar1 & 0xe00) == 0x400) {
        uVar2 = 0x6f;
    } else if ((uVar1 & 0xe00) == 0x800) {
        uVar2 = ~((char)uVar1 << 3) & 0x20U | 0x58;
    } else {
        uVar2 = 0x75;
    }
    var_88h._0_4_ = *(undefined4 *)arg3;
    var_88h._4_4_ = *(undefined4 *)(arg3 + 4);
    uStack_80 = *(undefined4 *)(arg3 + 8);
    uStack_7c = *(undefined4 *)(arg3 + 0xc);
    *(uint8_t *)((int64_t)puVar4 + 3) = uVar2;
    *(undefined *)(puVar4 + 2) = 0;
    iVar3 = fcn.1800102d0((int64_t)&var_68h, 0x40, (int64_t)&var_78h, arg_30h);
    var_98h = (int64_t)iVar3;
    var_a0h = (int64_t)&var_68h;
    var_a8h._0_1_ = (undefined)arg_28h;
    fcn.1800121d0(CONCAT71(var_a8h._1_7_, (undefined)arg_28h), var_a0h, var_98h);
    fcn.180459870(var_28h ^ (uint64_t)auStackY_c8);
    return;
}

// ============================================================
// Function: FUN_1800112c0
// Address: 0x1800112c0
// Size: 258 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_a8h
// WARNING: Variable defined which should be unmapped: var_a0h
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_77h
// WARNING: [rz-ghidra] Detected overlap for variable var_76h

void fcn.1800112c0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint32_t uVar1;
    uint8_t uVar2;
    int32_t iVar3;
    undefined2 *puVar4;
    undefined auStackY_c8 [32];
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    undefined4 uStack_80;
    undefined4 uStack_7c;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_c8;
    uVar1 = *(uint32_t *)(arg4 + 0x18);
    var_78h._0_1_ = 0x25;
    if ((uVar1 & 0x20) != 0) {
        var_78h._1_1_ = 0x2b;
    }
    puVar4 = (undefined2 *)((int64_t)&var_78h + 1);
    if ((uVar1 & 0x20) != 0) {
        puVar4 = (undefined2 *)((int64_t)&var_78h + 2);
    }
    if ((uVar1 & 8) != 0) {
        *(undefined *)puVar4 = 0x23;
        puVar4 = (undefined2 *)((int64_t)puVar4 + 1);
    }
    *puVar4 = 0x3649;
    *(undefined *)(puVar4 + 1) = 0x34;
    if ((uVar1 & 0xe00) == 0x400) {
        uVar2 = 0x6f;
    } else if ((uVar1 & 0xe00) == 0x800) {
        uVar2 = ~((char)uVar1 << 3) & 0x20U | 0x58;
    } else {
        uVar2 = 100;
    }
    var_88h._0_4_ = *(undefined4 *)arg3;
    var_88h._4_4_ = *(undefined4 *)(arg3 + 4);
    uStack_80 = *(undefined4 *)(arg3 + 8);
    uStack_7c = *(undefined4 *)(arg3 + 0xc);
    *(uint8_t *)((int64_t)puVar4 + 3) = uVar2;
    *(undefined *)(puVar4 + 2) = 0;
    iVar3 = fcn.1800102d0((int64_t)&var_68h, 0x40, (int64_t)&var_78h, arg_30h);
    var_98h = (int64_t)iVar3;
    var_a0h = (int64_t)&var_68h;
    var_a8h._0_1_ = (undefined)arg_28h;
    fcn.1800121d0(CONCAT71(var_a8h._1_7_, (undefined)arg_28h), var_a0h, var_98h);
    fcn.180459870(var_28h ^ (uint64_t)auStackY_c8);
    return;
}

// ============================================================
// Function: FUN_1800113d0
// Address: 0x1800113d0
// Size: 252 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_a8h
// WARNING: Variable defined which should be unmapped: var_a0h
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_77h
// WARNING: [rz-ghidra] Detected overlap for variable var_76h

void fcn.1800113d0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint32_t uVar1;
    uint8_t uVar2;
    int32_t iVar3;
    undefined *puVar4;
    undefined auStackY_c8 [32];
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    undefined4 uStack_80;
    undefined4 uStack_7c;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_c8;
    uVar1 = *(uint32_t *)(arg4 + 0x18);
    var_78h._0_1_ = 0x25;
    if ((uVar1 & 0x20) != 0) {
        var_78h._1_1_ = 0x2b;
    }
    puVar4 = (undefined *)((int64_t)&var_78h + 1);
    if ((uVar1 & 0x20) != 0) {
        puVar4 = (undefined *)((int64_t)&var_78h + 2);
    }
    if ((uVar1 & 8) != 0) {
        *puVar4 = 0x23;
        puVar4 = puVar4 + 1;
    }
    *puVar4 = 0x6c;
    if ((uVar1 & 0xe00) == 0x400) {
        uVar2 = 0x6f;
    } else if ((uVar1 & 0xe00) == 0x800) {
        uVar2 = ~((char)uVar1 << 3) & 0x20U | 0x58;
    } else {
        uVar2 = 0x75;
    }
    var_88h._0_4_ = *(undefined4 *)arg3;
    var_88h._4_4_ = *(undefined4 *)(arg3 + 4);
    uStack_80 = *(undefined4 *)(arg3 + 8);
    uStack_7c = *(undefined4 *)(arg3 + 0xc);
    puVar4[1] = uVar2;
    puVar4[2] = 0;
    iVar3 = fcn.1800102d0((int64_t)&var_68h, 0x40, (int64_t)&var_78h, arg_30h & 0xffffffff);
    var_98h = (int64_t)iVar3;
    var_a0h = (int64_t)&var_68h;
    var_a8h._0_1_ = (undefined)arg_28h;
    fcn.1800121d0(CONCAT71(var_a8h._1_7_, (undefined)arg_28h), var_a0h, var_98h);
    fcn.180459870(var_28h ^ (uint64_t)auStackY_c8);
    return;
}

// ============================================================
// Function: FUN_1800114d0
// Address: 0x1800114d0
// Size: 252 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_a8h
// WARNING: Variable defined which should be unmapped: var_a0h
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_77h
// WARNING: [rz-ghidra] Detected overlap for variable var_76h

void fcn.1800114d0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint32_t uVar1;
    uint8_t uVar2;
    int32_t iVar3;
    undefined *puVar4;
    undefined auStackY_c8 [32];
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    undefined4 uStack_80;
    undefined4 uStack_7c;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_c8;
    uVar1 = *(uint32_t *)(arg4 + 0x18);
    var_78h._0_1_ = 0x25;
    if ((uVar1 & 0x20) != 0) {
        var_78h._1_1_ = 0x2b;
    }
    puVar4 = (undefined *)((int64_t)&var_78h + 1);
    if ((uVar1 & 0x20) != 0) {
        puVar4 = (undefined *)((int64_t)&var_78h + 2);
    }
    if ((uVar1 & 8) != 0) {
        *puVar4 = 0x23;
        puVar4 = puVar4 + 1;
    }
    *puVar4 = 0x6c;
    if ((uVar1 & 0xe00) == 0x400) {
        uVar2 = 0x6f;
    } else if ((uVar1 & 0xe00) == 0x800) {
        uVar2 = ~((char)uVar1 << 3) & 0x20U | 0x58;
    } else {
        uVar2 = 100;
    }
    var_88h._0_4_ = *(undefined4 *)arg3;
    var_88h._4_4_ = *(undefined4 *)(arg3 + 4);
    uStack_80 = *(undefined4 *)(arg3 + 8);
    uStack_7c = *(undefined4 *)(arg3 + 0xc);
    puVar4[1] = uVar2;
    puVar4[2] = 0;
    iVar3 = fcn.1800102d0((int64_t)&var_68h, 0x40, (int64_t)&var_78h, arg_30h & 0xffffffff);
    var_98h = (int64_t)iVar3;
    var_a0h = (int64_t)&var_68h;
    var_a8h._0_1_ = (undefined)arg_28h;
    fcn.1800121d0(CONCAT71(var_a8h._1_7_, (undefined)arg_28h), var_a0h, var_98h);
    fcn.180459870(var_28h ^ (uint64_t)auStackY_c8);
    return;
}

