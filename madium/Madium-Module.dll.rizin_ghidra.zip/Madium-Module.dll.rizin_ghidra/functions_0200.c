// Chunk 200 - 50 functions

// ============================================================
// Function: FUN_18026ac20
// Address: 0x18026ac20
// Size: 99 bytes
// ============================================================
undefined8 fcn.18026ac20(int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026ac2c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar1 = *(code **)(in_RCX + 0x38);
    if (pcVar1 != (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026ac47;
        iVar2 = (*pcVar1)();
        if (0 < iVar2) {
            *(undefined4 *)((int64_t)&var_20h + iVar3) = 0;
            *(int32_t *)((int64_t)&var_18h + iVar3) = iVar2;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026ac72;
            uVar4 = fcn.1802dfca0(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3), 
                                  *(int64_t *)(&stack0x00000090 + iVar3));
            return uVar4;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18026aca0
// Address: 0x18026aca0
// Size: 99 bytes
// ============================================================
undefined8 fcn.18026aca0(int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026acac;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar1 = *(code **)(in_RCX + 0x38);
    if (pcVar1 != (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026acc7;
        iVar2 = (*pcVar1)();
        if (0 < iVar2) {
            *(undefined4 *)((int64_t)&var_20h + iVar3) = 1;
            *(int32_t *)((int64_t)&var_18h + iVar3) = iVar2;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026acf2;
            uVar4 = fcn.1802dfca0(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3), 
                                  *(int64_t *)(&stack0x00000090 + iVar3));
            return uVar4;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18026ad10
// Address: 0x18026ad10
// Size: 29 bytes
// ============================================================
undefined8 fcn.18026ad10(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    piVar6 = (int64_t *)0x18077e760;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x1802dfc0c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1802dfc1e;
    uVar4 = func_0x000180222950(*(int64_t *)0x180782b60);
    if ((int32_t)uVar4 == 0) {
        return uVar4;
    }
    iVar5 = *piVar6;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1802dfc36;
        func_0x000180228c50(iVar5, 0x1802dfef0);
        iVar5 = *piVar6;
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1802dfc3e;
        func_0x000180228ec0(iVar5);
        *piVar6 = 0;
    }
    *(undefined8 *)(&stack0x00000040 + iVar3 + iVar2) = 0x18022291a;
    iVar5 = *(int64_t *)0x180782b60;
    iVar1 = fcn.18045a350();
    if (*(int32_t *)(iVar5 + 8) != 0) {
        *(undefined4 *)(iVar5 + 8) = 0;
        *(undefined8 *)(&stack0x00000040 + -iVar1 + iVar3 + iVar2 + 0x20 + -0x20) = 0x180222930;
        (*(code *)0x69a062)();
        return 1;
    }
    *(undefined8 *)(&stack0x00000040 + -iVar1 + iVar3 + iVar2 + 0x20 + -0x20) = 0x180222940;
    (*(code *)0x69a07c)();
    return 1;
}

// ============================================================
// Function: FUN_18026ad30
// Address: 0x18026ad30
// Size: 103 bytes
// ============================================================
undefined8 fcn.18026ad30(int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026ad3a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar1 = *(code **)(in_RCX + 0x40);
    if (pcVar1 != (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026ad53;
        iVar2 = (*pcVar1)();
        if (iVar2 != 0) {
            return *(undefined8 *)((int64_t)&arg_30h + iVar3);
        }
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026ad66;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026ad7e;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                  *(int64_t *)(&stack0x00000050 + iVar3));
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026ad90;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_18026ada0
// Address: 0x18026ada0
// Size: 44 bytes
// ============================================================
int64_t fcn.18026ada0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_70h, int64_t arg_78h,
                     int64_t arg_90h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t in_RCX;
    int64_t *piVar9;
    undefined4 uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar10 = (undefined4)in_RCX;
    piVar9 = (int64_t *)0x18077e768;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = 0x1802dff85;
    uVar6 = fcn.18045a350(0x18077e768, in_RCX & 0xffffffff, 0x1804e7408, 0x45);
    iVar3 = -uVar6;
    iVar8 = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802dff98;
    func_0x000180243560(uVar6 & 0xffffffff, 0);
    if (*piVar9 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802dffad;
    iVar4 = func_0x000180222950(*(undefined8 *)0x180782b60);
    if (iVar4 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802dffba;
    func_0x000180229b10();
    iVar7 = *piVar9;
    if (iVar7 == 0) goto code_r0x0001802e0077;
    *(undefined4 *)((int64_t)&arg_40h + iVar3 + iVar5) = uVar10;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802dffd4;
    iVar7 = func_0x000180229240(iVar7, (int64_t)&arg_40h + iVar3 + iVar5);
    if (iVar7 == 0) goto code_r0x0001802e0077;
    if (*(int64_t *)(iVar7 + 0x10) == 0) {
code_r0x0001802dfff8:
        if (*(int32_t *)(iVar7 + 0x18) != 0) goto code_r0x0001802dfff2;
        uVar1 = *(undefined8 *)(iVar7 + 8);
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802e0008;
        iVar8 = func_0x000180222340(uVar1, 0);
        while (iVar8 != 0) {
            if ((0 < *(int32_t *)(iVar8 + 0xa0)) || ((*(uint8_t *)0x18077ef40 & 1) == 0)) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802e002f;
                iVar4 = func_0x00018026b1e0(iVar8);
                if (iVar4 != 0) {
                    if (*(int64_t *)(iVar7 + 0x10) != iVar8) {
                        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802e0058;
                        iVar4 = func_0x00018026b1e0(iVar8);
                        if (iVar4 != 0) {
                            iVar2 = *(int64_t *)(iVar7 + 0x10);
                            if (iVar2 != 0) {
                                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802e006c;
                                func_0x00018026b120(iVar2, 0);
                            }
                            *(int64_t *)(iVar7 + 0x10) = iVar8;
                        }
                    }
                    break;
                }
            }
            uVar1 = *(undefined8 *)(iVar7 + 8);
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802e003e;
            iVar8 = func_0x000180222340(uVar1);
        }
    } else {
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802dffee;
        iVar4 = func_0x00018026b1e0();
        if (iVar4 == 0) goto code_r0x0001802dfff8;
code_r0x0001802dfff2:
        iVar8 = *(int64_t *)(iVar7 + 0x10);
    }
    *(undefined4 *)(iVar7 + 0x18) = 1;
code_r0x0001802e0077:
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802e0083;
    func_0x000180222910(*(undefined8 *)0x180782b60);
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802e0088;
    func_0x0001802299d0();
    return iVar8;
}

// ============================================================
// Function: FUN_18026add0
// Address: 0x18026add0
// Size: 99 bytes
// ============================================================
undefined8 fcn.18026add0(int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026addc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar1 = *(code **)(in_RCX + 0x40);
    if (pcVar1 != (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026adf7;
        iVar2 = (*pcVar1)();
        if (0 < iVar2) {
            *(undefined4 *)((int64_t)&var_20h + iVar3) = 0;
            *(int32_t *)((int64_t)&var_18h + iVar3) = iVar2;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026ae22;
            uVar4 = fcn.1802dfca0(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3), 
                                  *(int64_t *)(&stack0x00000090 + iVar3));
            return uVar4;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18026ae40
// Address: 0x18026ae40
// Size: 99 bytes
// ============================================================
undefined8 fcn.18026ae40(int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026ae4c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar1 = *(code **)(in_RCX + 0x40);
    if (pcVar1 != (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026ae67;
        iVar2 = (*pcVar1)();
        if (0 < iVar2) {
            *(undefined4 *)((int64_t)&var_20h + iVar3) = 1;
            *(int32_t *)((int64_t)&var_18h + iVar3) = iVar2;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026ae92;
            uVar4 = fcn.1802dfca0(*(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000048 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3), 
                                  *(int64_t *)(&stack0x00000090 + iVar3));
            return uVar4;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18026aec0
// Address: 0x18026aec0
// Size: 29 bytes
// ============================================================
undefined8 fcn.18026aec0(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    piVar6 = (int64_t *)0x18077e768;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x1802dfc0c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1802dfc1e;
    uVar4 = func_0x000180222950(*(int64_t *)0x180782b60);
    if ((int32_t)uVar4 == 0) {
        return uVar4;
    }
    iVar5 = *piVar6;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1802dfc36;
        func_0x000180228c50(iVar5, 0x1802dfef0);
        iVar5 = *piVar6;
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x1802dfc3e;
        func_0x000180228ec0(iVar5);
        *piVar6 = 0;
    }
    *(undefined8 *)(&stack0x00000040 + iVar3 + iVar2) = 0x18022291a;
    iVar5 = *(int64_t *)0x180782b60;
    iVar1 = fcn.18045a350();
    if (*(int32_t *)(iVar5 + 8) != 0) {
        *(undefined4 *)(iVar5 + 8) = 0;
        *(undefined8 *)(&stack0x00000040 + -iVar1 + iVar3 + iVar2 + 0x20 + -0x20) = 0x180222930;
        (*(code *)0x69a062)();
        return 1;
    }
    *(undefined8 *)(&stack0x00000040 + -iVar1 + iVar3 + iVar2 + 0x20 + -0x20) = 0x180222940;
    (*(code *)0x69a07c)();
    return 1;
}

// ============================================================
// Function: FUN_18026aee0
// Address: 0x18026aee0
// Size: 290 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int32_t fcn.18026aee0(int64_t arg_30h)
{
    int32_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026aef0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == 0) {
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026af17;
    iVar3 = fcn.180222950(*(undefined8 *)0x180782b60);
    if (iVar3 == 0) {
        return 0;
    }
    iVar3 = 1;
    piVar1 = (int32_t *)(in_RCX + 0xa0);
    *piVar1 = *piVar1 + -1;
    if ((*piVar1 == 0) && (*(int64_t *)(in_RCX + 0x68) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026af3f;
        fcn.180222910(*(undefined8 *)0x180782b60);
        pcVar2 = *(code **)(in_RCX + 0x68);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026af48;
        iVar3 = (*pcVar2)(in_RCX);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026af56;
        iVar4 = fcn.180222950(*(undefined8 *)0x180782b60);
        if ((iVar4 != 0) && (iVar3 != 0)) goto code_r0x00018026af5e;
    } else {
code_r0x00018026af5e:
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026af68;
        iVar4 = fcn.18029b560(*(int64_t *)((int64_t)aiStackX_18 + iVar5));
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026afb5;
            fcn.180222910(*(undefined8 *)0x180782b60);
            if (iVar3 != 0) {
                return iVar3;
            }
            goto code_r0x00018026afb9;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026af71;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026af89;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026af9b;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar5));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026afa7;
    fcn.180222910(*(undefined8 *)0x180782b60);
code_r0x00018026afb9:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026afbe;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026afd6;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)(&stack0x00000048 + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026afe8;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_18026b010
// Address: 0x18026b010
// Size: 260 bytes
// ============================================================
int32_t fcn.18026b010(int64_t arg_28h)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026b01c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026b02c;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026b044;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026b056;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026b071;
    iVar2 = fcn.180222870(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e9c4;
    }
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026b085;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026b09d;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026b0af;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026b0c3;
    iVar3 = fcn.180222950(*(undefined8 *)0x180782b60);
    if (iVar3 == 0) {
        return 0;
    }
    iVar3 = *(int32_t *)(in_RCX + 0xa0);
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
    iVar2 = 1;
    if ((iVar3 == 0) && (pcVar1 = *(code **)(in_RCX + 0x60), pcVar1 != (code *)0x0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026b0e8;
        iVar2 = (*pcVar1)(in_RCX);
        if (iVar2 == 0) goto code_r0x00018026b0fb;
    }
    LOCK();
    *(int32_t *)(in_RCX + 0x9c) = *(int32_t *)(in_RCX + 0x9c) + 1;
    UNLOCK();
    *(int32_t *)(in_RCX + 0xa0) = *(int32_t *)(in_RCX + 0xa0) + 1;
code_r0x00018026b0fb:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026b107;
    fcn.180222910(*(undefined8 *)0x180782b60);
    return iVar2;
}

// ============================================================
// Function: FUN_18026b120
// Address: 0x18026b120
// Size: 186 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int32_t fcn.18026b120(int64_t arg_30h)
{
    int32_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026b130;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar3 = 1;
    piVar1 = (int32_t *)(in_RCX + 0xa0);
    *piVar1 = *piVar1 + -1;
    if ((*piVar1 == 0) && (*(int64_t *)(in_RCX + 0x68) != 0)) {
        if (in_EDX == 0) {
            pcVar2 = *(code **)(in_RCX + 0x68);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026b17d;
            iVar3 = (*pcVar2)();
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026b15a;
            fcn.180222910(*(undefined8 *)0x180782b60);
            pcVar2 = *(code **)(in_RCX + 0x68);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026b163;
            iVar3 = (*pcVar2)(in_RCX);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026b171;
            iVar4 = fcn.180222950(*(undefined8 *)0x180782b60);
            if (iVar4 == 0) {
                return 0;
            }
        }
        if (iVar3 == 0) {
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026b18d;
    iVar4 = fcn.18029b560(*(int64_t *)((int64_t)aiStackX_18 + iVar5));
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026b196;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026b1ae;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026b1c0;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar5));
        return 0;
    }
    return iVar3;
}

// ============================================================
// Function: FUN_18026b1e0
// Address: 0x18026b1e0
// Size: 66 bytes
// ============================================================
undefined8 fcn.18026b1e0(int64_t param_1)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026b1ec;
    iVar2 = fcn.18045a350();
    uVar3 = 1;
    if ((*(int32_t *)(param_1 + 0xa0) == 0) && (pcVar1 = *(code **)(param_1 + 0x60), pcVar1 != (code *)0x0)) {
        *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x18026b20b;
        uVar3 = (*pcVar1)();
        if ((int32_t)uVar3 == 0) {
            return uVar3;
        }
    }
    LOCK();
    *(int32_t *)(param_1 + 0x9c) = *(int32_t *)(param_1 + 0x9c) + 1;
    UNLOCK();
    *(int32_t *)(param_1 + 0xa0) = *(int32_t *)(param_1 + 0xa0) + 1;
    return uVar3;
}

// ============================================================
// Function: FUN_18026b230
// Address: 0x18026b230
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18026b230(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026b24b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (((in_RCX != 0) && (in_RDX != 0)) && (in_R8 != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026b26b;
        iVar3 = func_0x0001802d4730();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026b27d;
            iVar4 = func_0x0001802554c0();
            if (iVar4 != 0) {
                *(int64_t *)((int64_t)&var_18h + iVar2) = iVar3;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026b29b;
                iVar1 = func_0x0001802d6280(iVar4, in_R8, in_RCX, in_RDX);
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026b2a7;
                    func_0x000180255290(iVar4);
                    iVar4 = 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026b2b1;
            func_0x0001802d44d0(iVar3);
            return iVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18026b273
// Address: 0x18026b273
// Size: 72 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18026b230(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026b24b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (((in_RCX != 0) && (in_RDX != 0)) && (in_R8 != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026b26b;
        iVar3 = func_0x0001802d4730();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026b27d;
            iVar4 = func_0x0001802554c0();
            if (iVar4 != 0) {
                *(int64_t *)((int64_t)&var_18h + iVar2) = iVar3;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026b29b;
                iVar1 = func_0x0001802d6280(iVar4, in_R8, in_RCX, in_RDX);
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026b2a7;
                    func_0x000180255290(iVar4);
                    iVar4 = 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026b2b1;
            func_0x0001802d44d0(iVar3);
            return iVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18026b2bb
// Address: 0x18026b2bb
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18026b230(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026b24b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (((in_RCX != 0) && (in_RDX != 0)) && (in_R8 != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026b26b;
        iVar3 = func_0x0001802d4730();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026b27d;
            iVar4 = func_0x0001802554c0();
            if (iVar4 != 0) {
                *(int64_t *)((int64_t)&var_18h + iVar2) = iVar3;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026b29b;
                iVar1 = func_0x0001802d6280(iVar4, in_R8, in_RCX, in_RDX);
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026b2a7;
                    func_0x000180255290(iVar4);
                    iVar4 = 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026b2b1;
            func_0x0001802d44d0(iVar3);
            return iVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18026b2e0
// Address: 0x18026b2e0
// Size: 113 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18026b2e0(int64_t arg1, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                     int64_t arg_60h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18026b301;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar5 = 0;
    iVar6 = 0;
    iVar7 = 0;
    if ((((arg1 != 0) && (in_RDX != 0)) && (in_R8 != 0)) && (in_R9 != 0)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b345;
        iVar3 = func_0x0001802d4790(*(undefined8 *)((int64_t)&arg_58h + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b35b;
            iVar4 = func_0x0001802554c0();
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b36c;
                iVar5 = func_0x0001802554c0();
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b37d;
                    iVar6 = func_0x0001802554c0();
                    if (iVar6 != 0) {
                        *(int64_t *)(&stack0xfffffffffffffff8 + iVar2) = iVar3;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b3a1;
                        iVar1 = func_0x0001802d6280(iVar5, in_R8, *(undefined8 *)((int64_t)&arg_38h + iVar2), in_RDX);
                        if (iVar1 != 0) {
                            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar2) =
                                 *(undefined8 *)((int64_t)&arg_60h + iVar2);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b3c8;
                            iVar7 = func_0x00018026bc10(in_RDX, in_R8, in_RDX, 
                                                        *(undefined8 *)((int64_t)&arg_58h + iVar2));
                            if (iVar7 != 0) {
                                *(int64_t *)(&stack0xfffffffffffffff8 + iVar2) = iVar3;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b3e6;
                                iVar1 = func_0x0001802e1350(iVar4, in_R9, iVar7, in_RDX);
                                if (iVar1 != 0) {
                                    *(int64_t *)(&stack0xfffffffffffffff8 + iVar2) = iVar3;
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b400;
                                    iVar1 = func_0x0001802e1150(iVar6, iVar5, iVar4, in_RDX);
                                    if (iVar1 != 0) goto code_r0x00018026b40e;
                                }
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b40c;
                        func_0x000180255290(iVar6);
                        iVar6 = 0;
                    }
                }
            }
code_r0x00018026b40e:
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b416;
            func_0x0001802d44d0(iVar3);
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b41e;
            func_0x000180254e90(iVar4);
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b426;
            func_0x000180254e90(iVar5);
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b42e;
            func_0x000180255290(iVar7);
            return iVar6;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18026b351
// Address: 0x18026b351
// Size: 231 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18026b2e0(int64_t arg1, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                     int64_t arg_60h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18026b301;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar5 = 0;
    iVar6 = 0;
    iVar7 = 0;
    if ((((arg1 != 0) && (in_RDX != 0)) && (in_R8 != 0)) && (in_R9 != 0)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b345;
        iVar3 = func_0x0001802d4790(*(undefined8 *)((int64_t)&arg_58h + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b35b;
            iVar4 = func_0x0001802554c0();
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b36c;
                iVar5 = func_0x0001802554c0();
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b37d;
                    iVar6 = func_0x0001802554c0();
                    if (iVar6 != 0) {
                        *(int64_t *)(&stack0xfffffffffffffff8 + iVar2) = iVar3;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b3a1;
                        iVar1 = func_0x0001802d6280(iVar5, in_R8, *(undefined8 *)((int64_t)&arg_38h + iVar2), in_RDX);
                        if (iVar1 != 0) {
                            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar2) =
                                 *(undefined8 *)((int64_t)&arg_60h + iVar2);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b3c8;
                            iVar7 = func_0x00018026bc10(in_RDX, in_R8, in_RDX, 
                                                        *(undefined8 *)((int64_t)&arg_58h + iVar2));
                            if (iVar7 != 0) {
                                *(int64_t *)(&stack0xfffffffffffffff8 + iVar2) = iVar3;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b3e6;
                                iVar1 = func_0x0001802e1350(iVar4, in_R9, iVar7, in_RDX);
                                if (iVar1 != 0) {
                                    *(int64_t *)(&stack0xfffffffffffffff8 + iVar2) = iVar3;
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b400;
                                    iVar1 = func_0x0001802e1150(iVar6, iVar5, iVar4, in_RDX);
                                    if (iVar1 != 0) goto code_r0x00018026b40e;
                                }
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b40c;
                        func_0x000180255290(iVar6);
                        iVar6 = 0;
                    }
                }
            }
code_r0x00018026b40e:
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b416;
            func_0x0001802d44d0(iVar3);
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b41e;
            func_0x000180254e90(iVar4);
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b426;
            func_0x000180254e90(iVar5);
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b42e;
            func_0x000180255290(iVar7);
            return iVar6;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18026b438
// Address: 0x18026b438
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18026b2e0(int64_t arg1, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                     int64_t arg_60h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t in_R9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18026b301;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar5 = 0;
    iVar6 = 0;
    iVar7 = 0;
    if ((((arg1 != 0) && (in_RDX != 0)) && (in_R8 != 0)) && (in_R9 != 0)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b345;
        iVar3 = func_0x0001802d4790(*(undefined8 *)((int64_t)&arg_58h + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b35b;
            iVar4 = func_0x0001802554c0();
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b36c;
                iVar5 = func_0x0001802554c0();
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b37d;
                    iVar6 = func_0x0001802554c0();
                    if (iVar6 != 0) {
                        *(int64_t *)(&stack0xfffffffffffffff8 + iVar2) = iVar3;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b3a1;
                        iVar1 = func_0x0001802d6280(iVar5, in_R8, *(undefined8 *)((int64_t)&arg_38h + iVar2), in_RDX);
                        if (iVar1 != 0) {
                            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar2) =
                                 *(undefined8 *)((int64_t)&arg_60h + iVar2);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b3c8;
                            iVar7 = func_0x00018026bc10(in_RDX, in_R8, in_RDX, 
                                                        *(undefined8 *)((int64_t)&arg_58h + iVar2));
                            if (iVar7 != 0) {
                                *(int64_t *)(&stack0xfffffffffffffff8 + iVar2) = iVar3;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b3e6;
                                iVar1 = func_0x0001802e1350(iVar4, in_R9, iVar7, in_RDX);
                                if (iVar1 != 0) {
                                    *(int64_t *)(&stack0xfffffffffffffff8 + iVar2) = iVar3;
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b400;
                                    iVar1 = func_0x0001802e1150(iVar6, iVar5, iVar4, in_RDX);
                                    if (iVar1 != 0) goto code_r0x00018026b40e;
                                }
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b40c;
                        func_0x000180255290(iVar6);
                        iVar6 = 0;
                    }
                }
            }
code_r0x00018026b40e:
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b416;
            func_0x0001802d44d0(iVar3);
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b41e;
            func_0x000180254e90(iVar4);
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b426;
            func_0x000180254e90(iVar5);
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b42e;
            func_0x000180255290(iVar7);
            return iVar6;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18026b460
// Address: 0x18026b460
// Size: 146 bytes
// ============================================================
int64_t fcn.18026b460(int64_t placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                     undefined8 placeholder_5, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    
    uStack_40 = 0x18026b483;
    var_10h = arg2;
    var_18h = arg3;
    var_20h = arg4;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar5 = 0;
    iVar6 = 0;
    iVar8 = 0;
    iVar9 = 0;
    iVar10 = 0;
    iVar7 = 0;
    if ((((*(int64_t *)((int64_t)&arg_60h + iVar2) != 0) && (arg2 != 0)) && (placeholder_0 != 0)) &&
       (((arg3 != 0 && (arg4 != 0)) && (*(int64_t *)((int64_t)&arg_58h + iVar2) != 0)))) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b4e6;
        iVar3 = fcn.1802d4790(*(undefined8 *)((int64_t)&arg_68h + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b4fc;
            iVar4 = fcn.1802554c0();
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b50d;
                iVar5 = fcn.1802554c0();
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b51e;
                    iVar6 = fcn.1802554c0();
                    if (iVar6 != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b52f;
                        iVar7 = fcn.1802554c0();
                        iVar9 = iVar10;
                        iVar8 = 0;
                        if (iVar7 != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b551;
                            fcn.180255ac0(iVar7, *(undefined8 *)((int64_t)&arg_50h + iVar2), 4);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b55e;
                            fcn.180255830(iVar4, 4);
                            *(int64_t *)(&stack0xffffffffffffffe8 + iVar2) = iVar3;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b579;
                            iVar1 = fcn.1802d6280(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), 
                                                  *(int64_t *)(&stack0x00000000 + iVar2), 
                                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar2));
                            if (iVar1 != 0) {
                                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar2) =
                                     *(undefined8 *)((int64_t)&arg_70h + iVar2);
                                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b5a9;
                                iVar8 = fcn.18026bc10(*(int64_t *)((int64_t)&arg_40h + iVar2));
                                if (iVar8 != 0) {
                                    *(int64_t *)(&stack0xffffffffffffffe8 + iVar2) = iVar3;
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b5cb;
                                    iVar1 = fcn.1802e1350(*(int64_t *)(&stack0xffffffffffffffe8 + iVar2), 
                                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar2), 
                                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar2), 
                                                          *(int64_t *)(&stack0x00000000 + iVar2), 
                                                          *(int64_t *)((int64_t)&iStackX_8 + iVar2));
                                    if (iVar1 != 0) {
                                        *(int64_t *)(&stack0xffffffffffffffe8 + iVar2) = iVar3;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b5e7;
                                        iVar1 = fcn.1802e1480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar2), 
                                                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar2), 
                                                              *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                                              *(int64_t *)((int64_t)&var_18h + iVar2), 
                                                              *(int64_t *)((int64_t)&arg_48h + iVar2));
                                        if (iVar1 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b601;
                                            iVar1 = fcn.1802e00b0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar2));
                                            if (iVar1 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b618;
                                                iVar1 = fcn.1802d49d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar2), 
                                                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar2), 
                                                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar2));
                                                if (iVar1 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b621;
                                                    iVar9 = fcn.1802554c0();
                                                    if (iVar9 != 0) {
                                                        *(int64_t *)(&stack0xffffffffffffffe8 + iVar2) = iVar3;
                                                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b63f;
                                                        iVar1 = fcn.1802d6280(*(int64_t *)
                                                                               (&stack0xfffffffffffffff8 + iVar2), 
                                                                              *(int64_t *)(&stack0x00000000 + iVar2), 
                                                                              *(int64_t *)((int64_t)&iStackX_8 + iVar2)
                                                                              , *(int64_t *)((int64_t)&var_18h + iVar2))
                                                        ;
                                                        if (iVar1 == 0) {
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b64b;
                                                            fcn.180255290(iVar9);
                                                            iVar9 = 0;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b655;
            fcn.1802d44d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar2), *(int64_t *)(&stack0xfffffffffffffff0 + iVar2)
                          , *(int64_t *)((int64_t)&var_20h + iVar2));
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b65d;
            fcn.180255290(iVar7);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b665;
            fcn.180254e90(iVar4);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b66d;
            fcn.180254e90(iVar5);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b675;
            fcn.180254e90(iVar6);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b67d;
            fcn.180255290(iVar8);
            return iVar9;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18026b4f2
// Address: 0x18026b4f2
// Size: 418 bytes
// ============================================================
int64_t fcn.18026b460(int64_t placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                     undefined8 placeholder_5, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    
    uStack_40 = 0x18026b483;
    var_10h = arg2;
    var_18h = arg3;
    var_20h = arg4;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar5 = 0;
    iVar6 = 0;
    iVar8 = 0;
    iVar9 = 0;
    iVar10 = 0;
    iVar7 = 0;
    if ((((*(int64_t *)((int64_t)&arg_60h + iVar2) != 0) && (arg2 != 0)) && (placeholder_0 != 0)) &&
       (((arg3 != 0 && (arg4 != 0)) && (*(int64_t *)((int64_t)&arg_58h + iVar2) != 0)))) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b4e6;
        iVar3 = fcn.1802d4790(*(undefined8 *)((int64_t)&arg_68h + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b4fc;
            iVar4 = fcn.1802554c0();
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b50d;
                iVar5 = fcn.1802554c0();
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b51e;
                    iVar6 = fcn.1802554c0();
                    if (iVar6 != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b52f;
                        iVar7 = fcn.1802554c0();
                        iVar9 = iVar10;
                        iVar8 = 0;
                        if (iVar7 != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b551;
                            fcn.180255ac0(iVar7, *(undefined8 *)((int64_t)&arg_50h + iVar2), 4);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b55e;
                            fcn.180255830(iVar4, 4);
                            *(int64_t *)(&stack0xffffffffffffffe8 + iVar2) = iVar3;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b579;
                            iVar1 = fcn.1802d6280(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), 
                                                  *(int64_t *)(&stack0x00000000 + iVar2), 
                                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar2));
                            if (iVar1 != 0) {
                                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar2) =
                                     *(undefined8 *)((int64_t)&arg_70h + iVar2);
                                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b5a9;
                                iVar8 = fcn.18026bc10(*(int64_t *)((int64_t)&arg_40h + iVar2));
                                if (iVar8 != 0) {
                                    *(int64_t *)(&stack0xffffffffffffffe8 + iVar2) = iVar3;
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b5cb;
                                    iVar1 = fcn.1802e1350(*(int64_t *)(&stack0xffffffffffffffe8 + iVar2), 
                                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar2), 
                                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar2), 
                                                          *(int64_t *)(&stack0x00000000 + iVar2), 
                                                          *(int64_t *)((int64_t)&iStackX_8 + iVar2));
                                    if (iVar1 != 0) {
                                        *(int64_t *)(&stack0xffffffffffffffe8 + iVar2) = iVar3;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b5e7;
                                        iVar1 = fcn.1802e1480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar2), 
                                                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar2), 
                                                              *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                                              *(int64_t *)((int64_t)&var_18h + iVar2), 
                                                              *(int64_t *)((int64_t)&arg_48h + iVar2));
                                        if (iVar1 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b601;
                                            iVar1 = fcn.1802e00b0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar2));
                                            if (iVar1 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b618;
                                                iVar1 = fcn.1802d49d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar2), 
                                                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar2), 
                                                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar2));
                                                if (iVar1 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b621;
                                                    iVar9 = fcn.1802554c0();
                                                    if (iVar9 != 0) {
                                                        *(int64_t *)(&stack0xffffffffffffffe8 + iVar2) = iVar3;
                                                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b63f;
                                                        iVar1 = fcn.1802d6280(*(int64_t *)
                                                                               (&stack0xfffffffffffffff8 + iVar2), 
                                                                              *(int64_t *)(&stack0x00000000 + iVar2), 
                                                                              *(int64_t *)((int64_t)&iStackX_8 + iVar2)
                                                                              , *(int64_t *)((int64_t)&var_18h + iVar2))
                                                        ;
                                                        if (iVar1 == 0) {
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b64b;
                                                            fcn.180255290(iVar9);
                                                            iVar9 = 0;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b655;
            fcn.1802d44d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar2), *(int64_t *)(&stack0xfffffffffffffff0 + iVar2)
                          , *(int64_t *)((int64_t)&var_20h + iVar2));
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b65d;
            fcn.180255290(iVar7);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b665;
            fcn.180254e90(iVar4);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b66d;
            fcn.180254e90(iVar5);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b675;
            fcn.180254e90(iVar6);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b67d;
            fcn.180255290(iVar8);
            return iVar9;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18026b694
// Address: 0x18026b694
// Size: 17 bytes
// ============================================================
int64_t fcn.18026b460(int64_t placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                     undefined8 placeholder_5, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 unaff_R14;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    
    uStack_40 = 0x18026b483;
    var_10h = arg2;
    var_18h = arg3;
    var_20h = arg4;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar5 = 0;
    iVar6 = 0;
    iVar8 = 0;
    iVar9 = 0;
    iVar10 = 0;
    iVar7 = 0;
    if ((((*(int64_t *)((int64_t)&arg_60h + iVar2) != 0) && (arg2 != 0)) && (placeholder_0 != 0)) &&
       (((arg3 != 0 && (arg4 != 0)) && (*(int64_t *)((int64_t)&arg_58h + iVar2) != 0)))) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b4e6;
        iVar3 = fcn.1802d4790(*(undefined8 *)((int64_t)&arg_68h + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b4fc;
            iVar4 = fcn.1802554c0();
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b50d;
                iVar5 = fcn.1802554c0();
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b51e;
                    iVar6 = fcn.1802554c0();
                    if (iVar6 != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b52f;
                        iVar7 = fcn.1802554c0();
                        iVar9 = iVar10;
                        iVar8 = 0;
                        if (iVar7 != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b551;
                            fcn.180255ac0(iVar7, *(undefined8 *)((int64_t)&arg_50h + iVar2), 4);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b55e;
                            fcn.180255830(iVar4, 4);
                            *(int64_t *)(&stack0xffffffffffffffe8 + iVar2) = iVar3;
                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b579;
                            iVar1 = fcn.1802d6280(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), 
                                                  *(int64_t *)(&stack0x00000000 + iVar2), 
                                                  *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar2));
                            if (iVar1 != 0) {
                                *(undefined8 *)(&stack0xffffffffffffffe8 + iVar2) =
                                     *(undefined8 *)((int64_t)&arg_70h + iVar2);
                                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b5a9;
                                iVar8 = fcn.18026bc10(*(int64_t *)((int64_t)&arg_40h + iVar2));
                                if (iVar8 != 0) {
                                    *(int64_t *)(&stack0xffffffffffffffe8 + iVar2) = iVar3;
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b5cb;
                                    iVar1 = fcn.1802e1350(*(int64_t *)(&stack0xffffffffffffffe8 + iVar2), 
                                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar2), 
                                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar2), 
                                                          *(int64_t *)(&stack0x00000000 + iVar2), 
                                                          *(int64_t *)((int64_t)&iStackX_8 + iVar2));
                                    if (iVar1 != 0) {
                                        *(int64_t *)(&stack0xffffffffffffffe8 + iVar2) = iVar3;
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b5e7;
                                        iVar1 = fcn.1802e1480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar2), 
                                                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar2), 
                                                              *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                                              *(int64_t *)((int64_t)&var_18h + iVar2), 
                                                              *(int64_t *)((int64_t)&arg_48h + iVar2));
                                        if (iVar1 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b601;
                                            iVar1 = fcn.1802e00b0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar2));
                                            if (iVar1 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b618;
                                                iVar1 = fcn.1802d49d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar2), 
                                                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar2), 
                                                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar2));
                                                if (iVar1 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b621;
                                                    iVar9 = fcn.1802554c0();
                                                    if (iVar9 != 0) {
                                                        *(int64_t *)(&stack0xffffffffffffffe8 + iVar2) = iVar3;
                                                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b63f;
                                                        iVar1 = fcn.1802d6280(*(int64_t *)
                                                                               (&stack0xfffffffffffffff8 + iVar2), 
                                                                              *(int64_t *)(&stack0x00000000 + iVar2), 
                                                                              *(int64_t *)((int64_t)&iStackX_8 + iVar2)
                                                                              , *(int64_t *)((int64_t)&var_18h + iVar2))
                                                        ;
                                                        if (iVar1 == 0) {
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b64b;
                                                            fcn.180255290(iVar9);
                                                            iVar9 = 0;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b655;
            fcn.1802d44d0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar2), *(int64_t *)(&stack0xfffffffffffffff0 + iVar2)
                          , *(int64_t *)((int64_t)&var_20h + iVar2));
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b65d;
            fcn.180255290(iVar7);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b665;
            fcn.180254e90(iVar4);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b66d;
            fcn.180254e90(iVar5);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b675;
            fcn.180254e90(iVar6);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b67d;
            fcn.180255290(iVar8);
            return iVar9;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18026b6b0
// Address: 0x18026b6b0
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18026b6b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    int64_t in_R8;
    int64_t in_R9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18026b6cd;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar4 = 0;
    iVar5 = 0;
    if ((((in_R8 == 0) || (in_RCX == 0)) || (in_RDX == 0)) ||
       ((in_R9 == 0 || (*(int64_t *)((int64_t)&arg_58h + iVar2) == 0)))) {
        iVar5 = 0;
    } else {
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b71f;
        iVar3 = func_0x0001802d4730();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b72c;
            iVar4 = fcn.1802554c0();
            if (iVar4 != 0) {
                *(int64_t *)((int64_t)&var_8h + iVar2) = iVar3;
                *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b74a;
                iVar1 = fcn.1802d6280(*(int64_t *)((int64_t)&iStackX_8 + iVar2), *(int64_t *)((int64_t)&var_10h + iVar2)
                                      , *(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2))
                ;
                if (iVar1 != 0) {
                    *(int64_t *)((int64_t)&var_8h + iVar2) = iVar3;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b764;
                    iVar1 = fcn.1802e1350(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2)
                                          , *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                          *(int64_t *)((int64_t)&var_10h + iVar2), 
                                          *(int64_t *)((int64_t)&var_18h + iVar2));
                    iVar5 = 0;
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b76d;
                        iVar5 = fcn.1802554c0();
                        if (iVar5 != 0) {
                            *(int64_t *)((int64_t)&var_8h + iVar2) = iVar3;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b78b;
                            iVar1 = fcn.1802d6280(*(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar2), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar2), 
                                                  *(int64_t *)(&stack0x00000028 + iVar2));
                            if (iVar1 == 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b797;
                                fcn.180255290(iVar5);
                                iVar5 = 0;
                            }
                        }
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b7a1;
        fcn.1802d44d0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b7a9;
        fcn.180254e90(iVar4);
    }
    return iVar5;
}

// ============================================================
// Function: FUN_18026b715
// Address: 0x18026b715
// Size: 158 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18026b6b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    int64_t in_R8;
    int64_t in_R9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18026b6cd;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar4 = 0;
    iVar5 = 0;
    if ((((in_R8 == 0) || (in_RCX == 0)) || (in_RDX == 0)) ||
       ((in_R9 == 0 || (*(int64_t *)((int64_t)&arg_58h + iVar2) == 0)))) {
        iVar5 = 0;
    } else {
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b71f;
        iVar3 = func_0x0001802d4730();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b72c;
            iVar4 = fcn.1802554c0();
            if (iVar4 != 0) {
                *(int64_t *)((int64_t)&var_8h + iVar2) = iVar3;
                *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b74a;
                iVar1 = fcn.1802d6280(*(int64_t *)((int64_t)&iStackX_8 + iVar2), *(int64_t *)((int64_t)&var_10h + iVar2)
                                      , *(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2))
                ;
                if (iVar1 != 0) {
                    *(int64_t *)((int64_t)&var_8h + iVar2) = iVar3;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b764;
                    iVar1 = fcn.1802e1350(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2)
                                          , *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                          *(int64_t *)((int64_t)&var_10h + iVar2), 
                                          *(int64_t *)((int64_t)&var_18h + iVar2));
                    iVar5 = 0;
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b76d;
                        iVar5 = fcn.1802554c0();
                        if (iVar5 != 0) {
                            *(int64_t *)((int64_t)&var_8h + iVar2) = iVar3;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b78b;
                            iVar1 = fcn.1802d6280(*(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar2), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar2), 
                                                  *(int64_t *)(&stack0x00000028 + iVar2));
                            if (iVar1 == 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b797;
                                fcn.180255290(iVar5);
                                iVar5 = 0;
                            }
                        }
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b7a1;
        fcn.1802d44d0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b7a9;
        fcn.180254e90(iVar4);
    }
    return iVar5;
}

// ============================================================
// Function: FUN_18026b7b3
// Address: 0x18026b7b3
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18026b6b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    int64_t in_R8;
    int64_t in_R9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18026b6cd;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar4 = 0;
    iVar5 = 0;
    if ((((in_R8 == 0) || (in_RCX == 0)) || (in_RDX == 0)) ||
       ((in_R9 == 0 || (*(int64_t *)((int64_t)&arg_58h + iVar2) == 0)))) {
        iVar5 = 0;
    } else {
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b71f;
        iVar3 = func_0x0001802d4730();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b72c;
            iVar4 = fcn.1802554c0();
            if (iVar4 != 0) {
                *(int64_t *)((int64_t)&var_8h + iVar2) = iVar3;
                *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b74a;
                iVar1 = fcn.1802d6280(*(int64_t *)((int64_t)&iStackX_8 + iVar2), *(int64_t *)((int64_t)&var_10h + iVar2)
                                      , *(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2))
                ;
                if (iVar1 != 0) {
                    *(int64_t *)((int64_t)&var_8h + iVar2) = iVar3;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b764;
                    iVar1 = fcn.1802e1350(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2)
                                          , *(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                          *(int64_t *)((int64_t)&var_10h + iVar2), 
                                          *(int64_t *)((int64_t)&var_18h + iVar2));
                    iVar5 = 0;
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b76d;
                        iVar5 = fcn.1802554c0();
                        if (iVar5 != 0) {
                            *(int64_t *)((int64_t)&var_8h + iVar2) = iVar3;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b78b;
                            iVar1 = fcn.1802d6280(*(int64_t *)((int64_t)&iStackX_8 + iVar2), 
                                                  *(int64_t *)((int64_t)&var_10h + iVar2), 
                                                  *(int64_t *)((int64_t)&var_18h + iVar2), 
                                                  *(int64_t *)(&stack0x00000028 + iVar2));
                            if (iVar1 == 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b797;
                                fcn.180255290(iVar5);
                                iVar5 = 0;
                            }
                        }
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b7a1;
        fcn.1802d44d0(*(int64_t *)((int64_t)&var_8h + iVar2), *(int64_t *)(&stack0x00000000 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2));
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18026b7a9;
        fcn.180254e90(iVar4);
    }
    return iVar5;
}

// ============================================================
// Function: FUN_18026b7d0
// Address: 0x18026b7d0
// Size: 22 bytes
// ============================================================
void fcn.18026b7d0(int64_t param_1, int64_t param_2, int64_t param_3, undefined8 param_4)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 uStack_10;
    int64_t iStack_8;
    
    iStack_8 = 0x18026b7da;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)(&stack0x00000030 + iVar4) = unaff_RBX;
    *(undefined8 *)(&stack0x00000028 + iVar4) = unaff_RBP;
    *(undefined8 *)(&stack0x00000020 + iVar4) = unaff_RSI;
    *(undefined8 *)(&stack0x00000018 + iVar4) = unaff_RDI;
    *(undefined8 *)(&stack0x00000010 + iVar4) = unaff_R12;
    *(undefined8 *)(&stack0x00000008 + iVar4) = unaff_R13;
    *(undefined8 *)(&stack0x00000020 + iVar4 + -0x20) = unaff_R14;
    *(undefined8 *)((int64_t)&iStack_8 + iVar4) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026bc27;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)(&stack0x00000040 + iVar5 + iVar4) = *(uint64_t *)0x1806a3940 ^ (int64_t)&iStack_8 + iVar5 + iVar4;
    uVar1 = *(undefined8 *)(&stack0x000000b8 + iVar5 + iVar4);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar4) = 0x18026bc5b;
    iVar2 = func_0x000180255500(param_3);
    iVar2 = (int32_t)(iVar2 + 7 + (iVar2 + 7 >> 0x1f & 7U)) >> 3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar4) = 0x18026bc7c;
    iVar6 = func_0x000180215540(param_4, 0x1804ad35c, uVar1);
    if (iVar6 == 0) goto code_r0x00018026bd59;
    if (param_1 == param_3) {
code_r0x00018026bca0:
        if (param_2 != param_3) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar4) = 0x18026bcb0;
            iVar3 = func_0x000180255960(param_2, param_3);
            iVar7 = 0;
            if (-1 < iVar3) goto code_r0x00018026bd39;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar4) = 0x18026bcd2;
        iVar7 = func_0x000180224ed0((int64_t)iVar2, 2, 0x1804e74d8, 0x2a);
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar4) = 0x18026bce8;
            iVar3 = func_0x000180254d60(param_1, iVar7, iVar2);
            if (-1 < iVar3) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar4) = 0x18026bcfb;
                iVar3 = func_0x000180254d60(param_2, iVar2 + iVar7, iVar2);
                if (-1 < iVar3) {
                    *(undefined8 *)(&stack0x00000020 + iVar5 + iVar4) = 0;
                    *(int64_t *)(&stack0x00000018 + iVar5 + iVar4) = iVar6;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar4) = 0x18026bd20;
                    iVar2 = func_0x000180214220(iVar7, (int64_t)(iVar2 * 2), &stack0x00000028 + iVar5 + iVar4, 0);
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar4) = 0x18026bd36;
                        func_0x000180254c30(&stack0x00000028 + iVar5 + iVar4, 0x14, 0);
                    }
                }
            }
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar4) = 0x18026bc98;
        iVar3 = func_0x000180255960(param_1, param_3);
        iVar7 = 0;
        if (iVar3 < 0) goto code_r0x00018026bca0;
    }
code_r0x00018026bd39:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar4) = 0x18026bd41;
    func_0x000180215590(iVar6);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar4) = 0x18026bd56;
    fcn.180224990(iVar7, 0x1804e74d8, 0x33);
code_r0x00018026bd59:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar4) = 0x18026bd66;
    func_0x000180459870(*(uint64_t *)(&stack0x00000040 + iVar5 + iVar4) ^ (int64_t)&iStack_8 + iVar5 + iVar4);
    return;
}

// ============================================================
// Function: FUN_18026b7f0
// Address: 0x18026b7f0
// Size: 117 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18026b7f0(int64_t arg_88h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    undefined8 in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_18h;
    int64_t var_10h;
    
    uStack_40 = 0x18026b805;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&var_8h + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar2);
    iVar5 = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = *(undefined8 *)((int64_t)&arg_88h + iVar2);
    if (((in_RCX != 0) && (in_RDX != 0)) && (in_R8 != 0)) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b856;
        iVar3 = func_0x000180215470();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_R15;
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b86f;
            func_0x000180255500(in_RCX);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b890;
            iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_10h + iVar2));
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b8b0;
                iVar5 = func_0x000180215540(in_R9, 0x1804ad35c, *(undefined8 *)((int64_t)&var_18h + iVar2));
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b8ca;
                    iVar1 = func_0x000180214880(iVar3, iVar5, 0);
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b8da;
                        uVar6 = func_0x000180498cd0(in_RDX);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b8e8;
                        iVar1 = func_0x0001802149b0(iVar3, in_RDX, uVar6);
                        if (iVar1 != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b905;
                            iVar1 = func_0x0001802149b0(iVar3, 0x1805ab2c8, 1);
                            if (iVar1 != 0) {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b915;
                                uVar6 = func_0x000180498cd0(in_R8);
                                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b923;
                                iVar1 = func_0x0001802149b0(iVar3, in_R8, uVar6);
                                if (iVar1 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b93b;
                                    iVar1 = func_0x0001802146d0(iVar3, (int64_t)&var_10h + iVar2, 0);
                                    if (iVar1 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b951;
                                        iVar1 = func_0x000180214880(iVar3, iVar5, 0);
                                        if (iVar1 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b960;
                                            iVar1 = func_0x000180254c60(in_RCX, iVar4);
                                            if (-1 < iVar1) {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b96c;
                                                iVar1 = func_0x000180255500(in_RCX);
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b986;
                                                iVar1 = func_0x0001802149b0(iVar3, iVar4, 
                                                                            (int64_t)((int32_t)(iVar1 + 7 +
                                                                                               (iVar1 + 7 >> 0x1f & 7U))
                                                                                     >> 3));
                                                if (iVar1 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b99d;
                                                    iVar1 = func_0x0001802149b0(iVar3, (int64_t)&var_10h + iVar2, 0x14);
                                                    if (iVar1 != 0) {
                                                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b9b1;
                                                        iVar1 = func_0x0001802146d0(iVar3, (int64_t)&var_10h + iVar2, 0)
                                                        ;
                                                        if (iVar1 != 0) {
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b9c7;
                                                            func_0x000180254c30((int64_t)&var_10h + iVar2, 0x14, 0);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b9d2;
            func_0x000180215590(iVar5);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b9e7;
            fcn.180224990(iVar4, 0x1804e74d8, 0xba);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b9ef;
            func_0x000180215310(iVar3);
        }
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026ba08;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_8h + iVar2) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_18026b865
// Address: 0x18026b865
// Size: 404 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18026b7f0(int64_t arg_88h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    undefined8 in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_18h;
    int64_t var_10h;
    
    uStack_40 = 0x18026b805;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&var_8h + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar2);
    iVar5 = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = *(undefined8 *)((int64_t)&arg_88h + iVar2);
    if (((in_RCX != 0) && (in_RDX != 0)) && (in_R8 != 0)) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b856;
        iVar3 = func_0x000180215470();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_R15;
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b86f;
            func_0x000180255500(in_RCX);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b890;
            iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_10h + iVar2));
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b8b0;
                iVar5 = func_0x000180215540(in_R9, 0x1804ad35c, *(undefined8 *)((int64_t)&var_18h + iVar2));
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b8ca;
                    iVar1 = func_0x000180214880(iVar3, iVar5, 0);
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b8da;
                        uVar6 = func_0x000180498cd0(in_RDX);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b8e8;
                        iVar1 = func_0x0001802149b0(iVar3, in_RDX, uVar6);
                        if (iVar1 != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b905;
                            iVar1 = func_0x0001802149b0(iVar3, 0x1805ab2c8, 1);
                            if (iVar1 != 0) {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b915;
                                uVar6 = func_0x000180498cd0(in_R8);
                                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b923;
                                iVar1 = func_0x0001802149b0(iVar3, in_R8, uVar6);
                                if (iVar1 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b93b;
                                    iVar1 = func_0x0001802146d0(iVar3, (int64_t)&var_10h + iVar2, 0);
                                    if (iVar1 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b951;
                                        iVar1 = func_0x000180214880(iVar3, iVar5, 0);
                                        if (iVar1 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b960;
                                            iVar1 = func_0x000180254c60(in_RCX, iVar4);
                                            if (-1 < iVar1) {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b96c;
                                                iVar1 = func_0x000180255500(in_RCX);
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b986;
                                                iVar1 = func_0x0001802149b0(iVar3, iVar4, 
                                                                            (int64_t)((int32_t)(iVar1 + 7 +
                                                                                               (iVar1 + 7 >> 0x1f & 7U))
                                                                                     >> 3));
                                                if (iVar1 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b99d;
                                                    iVar1 = func_0x0001802149b0(iVar3, (int64_t)&var_10h + iVar2, 0x14);
                                                    if (iVar1 != 0) {
                                                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b9b1;
                                                        iVar1 = func_0x0001802146d0(iVar3, (int64_t)&var_10h + iVar2, 0)
                                                        ;
                                                        if (iVar1 != 0) {
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b9c7;
                                                            func_0x000180254c30((int64_t)&var_10h + iVar2, 0x14, 0);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b9d2;
            func_0x000180215590(iVar5);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b9e7;
            fcn.180224990(iVar4, 0x1804e74d8, 0xba);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b9ef;
            func_0x000180215310(iVar3);
        }
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026ba08;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_8h + iVar2) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_18026b9f9
// Address: 0x18026b9f9
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18026b7f0(int64_t arg_88h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    undefined8 in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_18h;
    int64_t var_10h;
    
    uStack_40 = 0x18026b805;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&var_8h + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar2);
    iVar5 = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = *(undefined8 *)((int64_t)&arg_88h + iVar2);
    if (((in_RCX != 0) && (in_RDX != 0)) && (in_R8 != 0)) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b856;
        iVar3 = func_0x000180215470();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_R15;
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b86f;
            func_0x000180255500(in_RCX);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b890;
            iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_10h + iVar2));
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b8b0;
                iVar5 = func_0x000180215540(in_R9, 0x1804ad35c, *(undefined8 *)((int64_t)&var_18h + iVar2));
                if (iVar5 != 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b8ca;
                    iVar1 = func_0x000180214880(iVar3, iVar5, 0);
                    if (iVar1 != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b8da;
                        uVar6 = func_0x000180498cd0(in_RDX);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b8e8;
                        iVar1 = func_0x0001802149b0(iVar3, in_RDX, uVar6);
                        if (iVar1 != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b905;
                            iVar1 = func_0x0001802149b0(iVar3, 0x1805ab2c8, 1);
                            if (iVar1 != 0) {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b915;
                                uVar6 = func_0x000180498cd0(in_R8);
                                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b923;
                                iVar1 = func_0x0001802149b0(iVar3, in_R8, uVar6);
                                if (iVar1 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b93b;
                                    iVar1 = func_0x0001802146d0(iVar3, (int64_t)&var_10h + iVar2, 0);
                                    if (iVar1 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b951;
                                        iVar1 = func_0x000180214880(iVar3, iVar5, 0);
                                        if (iVar1 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b960;
                                            iVar1 = func_0x000180254c60(in_RCX, iVar4);
                                            if (-1 < iVar1) {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b96c;
                                                iVar1 = func_0x000180255500(in_RCX);
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b986;
                                                iVar1 = func_0x0001802149b0(iVar3, iVar4, 
                                                                            (int64_t)((int32_t)(iVar1 + 7 +
                                                                                               (iVar1 + 7 >> 0x1f & 7U))
                                                                                     >> 3));
                                                if (iVar1 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b99d;
                                                    iVar1 = func_0x0001802149b0(iVar3, (int64_t)&var_10h + iVar2, 0x14);
                                                    if (iVar1 != 0) {
                                                        *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b9b1;
                                                        iVar1 = func_0x0001802146d0(iVar3, (int64_t)&var_10h + iVar2, 0)
                                                        ;
                                                        if (iVar1 != 0) {
                                                            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b9c7;
                                                            func_0x000180254c30((int64_t)&var_10h + iVar2, 0x14, 0);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b9d2;
            func_0x000180215590(iVar5);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b9e7;
            fcn.180224990(iVar4, 0x1804e74d8, 0xba);
            *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026b9ef;
            func_0x000180215310(iVar3);
        }
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar2) = 0x18026ba08;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_8h + iVar2) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_18026ba20
// Address: 0x18026ba20
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.18026ba20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    bool bVar4;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026ba3b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    bVar4 = false;
    if ((in_RCX != 0) && (in_RDX != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ba55;
        iVar3 = fcn.1802d4730();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ba67;
            iVar3 = fcn.1802554c0();
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ba80;
                iVar1 = fcn.1802e1570(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                      *(int64_t *)(&stack0x00000048 + iVar2));
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ba8c;
                    iVar1 = fcn.1802553f0(iVar3);
                    bVar4 = iVar1 == 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ba99;
            fcn.1802d44d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026baa1;
            fcn.180255290(iVar3);
        }
    }
    return bVar4;
}

// ============================================================
// Function: FUN_18026ba5d
// Address: 0x18026ba5d
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.18026ba20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    bool bVar4;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026ba3b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    bVar4 = false;
    if ((in_RCX != 0) && (in_RDX != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ba55;
        iVar3 = fcn.1802d4730();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ba67;
            iVar3 = fcn.1802554c0();
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ba80;
                iVar1 = fcn.1802e1570(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                      *(int64_t *)(&stack0x00000048 + iVar2));
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ba8c;
                    iVar1 = fcn.1802553f0(iVar3);
                    bVar4 = iVar1 == 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ba99;
            fcn.1802d44d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026baa1;
            fcn.180255290(iVar3);
        }
    }
    return bVar4;
}

// ============================================================
// Function: FUN_18026baa6
// Address: 0x18026baa6
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.18026ba20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    bool bVar4;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026ba3b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    bVar4 = false;
    if ((in_RCX != 0) && (in_RDX != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ba55;
        iVar3 = fcn.1802d4730();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ba67;
            iVar3 = fcn.1802554c0();
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ba80;
                iVar1 = fcn.1802e1570(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                      *(int64_t *)(&stack0x00000048 + iVar2));
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ba8c;
                    iVar1 = fcn.1802553f0(iVar3);
                    bVar4 = iVar1 == 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ba99;
            fcn.1802d44d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026baa1;
            fcn.180255290(iVar3);
        }
    }
    return bVar4;
}

// ============================================================
// Function: FUN_18026bac0
// Address: 0x18026bac0
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.18026bac0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    bool bVar4;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026badb;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    bVar4 = false;
    if ((in_RCX != 0) && (in_RDX != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026baf5;
        iVar3 = fcn.1802d4730();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026bb07;
            iVar3 = fcn.1802554c0();
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026bb20;
                iVar1 = fcn.1802e1570(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                      *(int64_t *)(&stack0x00000048 + iVar2));
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026bb2c;
                    iVar1 = fcn.1802553f0(iVar3);
                    bVar4 = iVar1 == 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026bb39;
            fcn.1802d44d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026bb41;
            fcn.180255290(iVar3);
            return bVar4;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_18026bafd
// Address: 0x18026bafd
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.18026bac0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    bool bVar4;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026badb;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    bVar4 = false;
    if ((in_RCX != 0) && (in_RDX != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026baf5;
        iVar3 = fcn.1802d4730();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026bb07;
            iVar3 = fcn.1802554c0();
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026bb20;
                iVar1 = fcn.1802e1570(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                      *(int64_t *)(&stack0x00000048 + iVar2));
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026bb2c;
                    iVar1 = fcn.1802553f0(iVar3);
                    bVar4 = iVar1 == 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026bb39;
            fcn.1802d44d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026bb41;
            fcn.180255290(iVar3);
            return bVar4;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_18026bb4a
// Address: 0x18026bb4a
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.18026bac0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    bool bVar4;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026badb;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    bVar4 = false;
    if ((in_RCX != 0) && (in_RDX != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026baf5;
        iVar3 = fcn.1802d4730();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026bb07;
            iVar3 = fcn.1802554c0();
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026bb20;
                iVar1 = fcn.1802e1570(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                                      *(int64_t *)(&stack0x00000048 + iVar2));
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026bb2c;
                    iVar1 = fcn.1802553f0(iVar3);
                    bVar4 = iVar1 == 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026bb39;
            fcn.1802d44d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026bb41;
            fcn.180255290(iVar3);
            return bVar4;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_18026bb70
// Address: 0x18026bb70
// Size: 153 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18026bb70(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026bb90;
    iVar3 = fcn.18045a350();
    if ((in_RCX != 0) && (in_RDX != 0)) {
        uVar4 = 0;
        uVar5 = uVar4;
        do {
            uVar1 = *(undefined8 *)(uVar4 + 0x1806a0438);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x18026bbbd;
            iVar2 = func_0x000180254f10(uVar1, in_RCX);
            if (iVar2 == 0) {
                uVar1 = *(undefined8 *)(uVar4 + 0x1806a0440);
                *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x18026bbce;
                iVar2 = func_0x000180254f10(uVar1, in_RDX);
                if (iVar2 == 0) {
                    return *(undefined8 *)(uVar5 * 0x18 + 0x1806a0430);
                }
            }
            uVar5 = uVar5 + 1;
            uVar4 = uVar4 + 0x18;
        } while (uVar4 < 0xa8);
    }
    return 0;
}

// ============================================================
// Function: FUN_18026bc10
// Address: 0x18026bc10
// Size: 359 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18026bc10(int64_t arg_80h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    undefined8 uStack_48;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    
    uStack_48 = 0x18026bc27;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&var_8h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar4);
    uVar1 = *(undefined8 *)((int64_t)&arg_80h + iVar4);
    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x18026bc5b;
    iVar2 = func_0x000180255500(in_R8);
    iVar2 = (int32_t)(iVar2 + 7 + (iVar2 + 7 >> 0x1f & 7U)) >> 3;
    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x18026bc7c;
    iVar5 = func_0x000180215540(in_R9, 0x1804ad35c, uVar1);
    if (iVar5 == 0) goto code_r0x00018026bd59;
    if (in_RCX == in_R8) {
code_r0x00018026bca0:
        if (in_RDX != in_R8) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x18026bcb0;
            iVar3 = func_0x000180255960(in_RDX, in_R8);
            iVar6 = 0;
            if (-1 < iVar3) goto code_r0x00018026bd39;
        }
        *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x18026bcd2;
        iVar6 = func_0x000180224ed0((int64_t)iVar2, 2, 0x1804e74d8, 0x2a);
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x18026bce8;
            iVar3 = func_0x000180254d60(in_RCX, iVar6, iVar2);
            if (-1 < iVar3) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x18026bcfb;
                iVar3 = func_0x000180254d60(in_RDX, iVar2 + iVar6, iVar2);
                if (-1 < iVar3) {
                    *(undefined8 *)((int64_t)&var_18h + iVar4) = 0;
                    *(int64_t *)((int64_t)&var_20h + iVar4) = iVar5;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x18026bd20;
                    iVar2 = func_0x000180214220(iVar6, (int64_t)(iVar2 * 2), (int64_t)&var_10h + iVar4, 0);
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x18026bd36;
                        func_0x000180254c30((int64_t)&var_10h + iVar4, 0x14, 0);
                    }
                }
            }
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x18026bc98;
        iVar3 = func_0x000180255960(in_RCX, in_R8);
        iVar6 = 0;
        if (iVar3 < 0) goto code_r0x00018026bca0;
    }
code_r0x00018026bd39:
    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x18026bd41;
    func_0x000180215590(iVar5);
    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x18026bd56;
    fcn.180224990(iVar6, 0x1804e74d8, 0x33);
code_r0x00018026bd59:
    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x18026bd66;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_8h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar4));
    return;
}

// ============================================================
// Function: FUN_18026bda0
// Address: 0x18026bda0
// Size: 62 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel

void fcn.18026bda0(int64_t arg1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18026bdb0;
        iVar1 = fcn.18045a350();
        iVar1 = -iVar1;
        if (*(code **)0x18077e790 == (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026bdcc;
            *(code **)0x18077e790 =
                 (code *)fcn.18026cb90(*(int64_t *)((int64_t)aiStackX_18 + iVar1), 
                                       *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                                       *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                                       *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000148 + iVar1));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026bdd8;
        (**(code **)0x18077e790)(arg1);
    }
    return;
}

// ============================================================
// Function: FUN_18026beb0
// Address: 0x18026beb0
// Size: 35 bytes
// ============================================================
void fcn.18026beb0(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4) = 0x18022499a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (param_1 != 0) {
            *(undefined8 *)(&stack0x00000048 + iVar3 + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_18026bee0
// Address: 0x18026bee0
// Size: 52 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_51h
// WARNING: [rz-ghidra] Removing arg arg_39h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_41h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_45h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_47h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_29h

undefined8 fcn.18026bee0(int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026beec;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar3 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026bf03;
    iVar1 = fcn.18026d110(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
    if (iVar1 != 0) {
        uVar3 = *(undefined8 *)((int64_t)&arg_38h + iVar2);
    }
    return uVar3;
}

// ============================================================
// Function: FUN_18026bf70
// Address: 0x18026bf70
// Size: 121 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18026bf70(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    int16_t *in_RCX;
    int64_t in_RDX;
    undefined8 uVar3;
    undefined8 *in_R8;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026bf80;
    iVar1 = fcn.18045a350();
    if (*in_RCX == 2) {
        uVar3 = 4;
        iVar2 = 4;
    } else {
        if (*in_RCX != 0x17) {
            return 0;
        }
        uVar3 = 0x10;
        iVar2 = 8;
    }
    if ((int64_t)in_RCX + iVar2 == 0) {
        return 0;
    }
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x18026bfc4;
        func_0x000180498030(in_RDX, (int64_t)in_RCX + iVar2, uVar3);
    }
    if (in_R8 != (undefined8 *)0x0) {
        *in_R8 = uVar3;
    }
    return 1;
}

// ============================================================
// Function: FUN_18026c010
// Address: 0x18026c010
// Size: 52 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_51h
// WARNING: [rz-ghidra] Removing arg arg_39h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_41h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_45h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_47h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_29h

undefined8 fcn.18026c010(int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026c01c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar3 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026c033;
    iVar1 = fcn.18026d110(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
    if (iVar1 != 0) {
        uVar3 = *(undefined8 *)((int64_t)&arg_38h + iVar2);
    }
    return uVar3;
}

// ============================================================
// Function: FUN_18026c050
// Address: 0x18026c050
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel

undefined4
fcn.18026c050(int64_t arg_28h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h, int64_t arg_80h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    int32_t in_R8D;
    uint32_t in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18026c069;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((in_R9D < 0x18) && ((0x800005U >> (in_R9D & 0x1f) & 1) != 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c097;
        iVar3 = func_0x0001802748f0();
        if (iVar3 == 1) {
            uVar1 = *(undefined4 *)((int64_t)&arg_78h + iVar5);
            uVar6 = 0;
            *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_RSI;
            *(undefined4 *)((int64_t)&var_8h + iVar5) = 0;
            *(uint32_t *)((int64_t)&var_8h + iVar5 + 4) = in_R9D;
            *(undefined4 *)((int64_t)&var_10h + iVar5) = uVar1;
            *(undefined4 *)((int64_t)&var_10h + iVar5 + 4) = 0;
            *(undefined (*) [16])((int64_t)&iStackX_20 + iVar5 + -8) = ZEXT816(0);
            *(undefined (*) [16])((int64_t)&arg_28h + iVar5) = ZEXT816(0);
            if ((in_RCX != 0) && (in_R9D == 0)) {
                uVar6 = 0x400;
                *(undefined4 *)((int64_t)&var_8h + iVar5) = 0x400;
            }
            if (in_R8D == 1) {
                *(uint32_t *)((int64_t)&var_8h + iVar5) = uVar6 | 1;
            }
            uVar2 = *(undefined8 *)((int64_t)&arg_80h + iVar5);
            iVar3 = 0;
            while( true ) {
                if (*(code **)0x18077e780 == (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c113;
                    *(code **)0x18077e780 =
                         (code *)fcn.18026cb90(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                               *(int64_t *)((int64_t)&var_10h + iVar5), 
                                               *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                               *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                                               *(int64_t *)((int64_t)&arg_28h + iVar5), 
                                               *(int64_t *)(&stack0x00000138 + iVar5));
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c12a;
                iVar4 = (**(code **)0x18077e780)(in_RCX, in_RDX, (int64_t)&var_8h + iVar5, uVar2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c134;
                (*(code *)0x8000000000000070)(iVar4);
                if (iVar4 == 0) {
                    return 1;
                }
                if (iVar4 == 8) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c185;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c19d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)(&stack0x00000038 + iVar5));
                    iVar4 = 8;
                    if (iVar3 != 0) {
                        iVar4 = iVar3;
                    }
                    goto code_r0x00018026c1a7;
                }
                if ((*(uint32_t *)((int64_t)&var_8h + iVar5) >> 10 & 1) == 0) break;
                *(uint32_t *)((int64_t)&var_8h + iVar5) = *(uint32_t *)((int64_t)&var_8h + iVar5) & 0xfffffbff | 4;
                iVar3 = iVar4;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c15f;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c177;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5));
            if (iVar3 != 0) {
                iVar4 = iVar3;
            }
code_r0x00018026c1a7:
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c1ac;
            func_0x00018026d340(iVar4);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c1be;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c1d6;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c1ee;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)(&stack0x00000038 + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c200;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
    }
    return 0;
}

// ============================================================
// Function: FUN_18026c0a9
// Address: 0x18026c0a9
// Size: 284 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel

undefined4
fcn.18026c050(int64_t arg_28h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h, int64_t arg_80h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    int32_t in_R8D;
    uint32_t in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18026c069;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((in_R9D < 0x18) && ((0x800005U >> (in_R9D & 0x1f) & 1) != 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c097;
        iVar3 = func_0x0001802748f0();
        if (iVar3 == 1) {
            uVar1 = *(undefined4 *)((int64_t)&arg_78h + iVar5);
            uVar6 = 0;
            *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_RSI;
            *(undefined4 *)((int64_t)&var_8h + iVar5) = 0;
            *(uint32_t *)((int64_t)&var_8h + iVar5 + 4) = in_R9D;
            *(undefined4 *)((int64_t)&var_10h + iVar5) = uVar1;
            *(undefined4 *)((int64_t)&var_10h + iVar5 + 4) = 0;
            *(undefined (*) [16])((int64_t)&iStackX_20 + iVar5 + -8) = ZEXT816(0);
            *(undefined (*) [16])((int64_t)&arg_28h + iVar5) = ZEXT816(0);
            if ((in_RCX != 0) && (in_R9D == 0)) {
                uVar6 = 0x400;
                *(undefined4 *)((int64_t)&var_8h + iVar5) = 0x400;
            }
            if (in_R8D == 1) {
                *(uint32_t *)((int64_t)&var_8h + iVar5) = uVar6 | 1;
            }
            uVar2 = *(undefined8 *)((int64_t)&arg_80h + iVar5);
            iVar3 = 0;
            while( true ) {
                if (*(code **)0x18077e780 == (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c113;
                    *(code **)0x18077e780 =
                         (code *)fcn.18026cb90(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                               *(int64_t *)((int64_t)&var_10h + iVar5), 
                                               *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                               *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                                               *(int64_t *)((int64_t)&arg_28h + iVar5), 
                                               *(int64_t *)(&stack0x00000138 + iVar5));
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c12a;
                iVar4 = (**(code **)0x18077e780)(in_RCX, in_RDX, (int64_t)&var_8h + iVar5, uVar2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c134;
                (*(code *)0x8000000000000070)(iVar4);
                if (iVar4 == 0) {
                    return 1;
                }
                if (iVar4 == 8) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c185;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c19d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)(&stack0x00000038 + iVar5));
                    iVar4 = 8;
                    if (iVar3 != 0) {
                        iVar4 = iVar3;
                    }
                    goto code_r0x00018026c1a7;
                }
                if ((*(uint32_t *)((int64_t)&var_8h + iVar5) >> 10 & 1) == 0) break;
                *(uint32_t *)((int64_t)&var_8h + iVar5) = *(uint32_t *)((int64_t)&var_8h + iVar5) & 0xfffffbff | 4;
                iVar3 = iVar4;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c15f;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c177;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5));
            if (iVar3 != 0) {
                iVar4 = iVar3;
            }
code_r0x00018026c1a7:
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c1ac;
            func_0x00018026d340(iVar4);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c1be;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c1d6;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c1ee;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)(&stack0x00000038 + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c200;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
    }
    return 0;
}

// ============================================================
// Function: FUN_18026c1c5
// Address: 0x18026c1c5
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel

undefined4
fcn.18026c050(int64_t arg_28h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h, int64_t arg_80h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    int32_t in_R8D;
    uint32_t in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18026c069;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((in_R9D < 0x18) && ((0x800005U >> (in_R9D & 0x1f) & 1) != 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c097;
        iVar3 = func_0x0001802748f0();
        if (iVar3 == 1) {
            uVar1 = *(undefined4 *)((int64_t)&arg_78h + iVar5);
            uVar6 = 0;
            *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_RSI;
            *(undefined4 *)((int64_t)&var_8h + iVar5) = 0;
            *(uint32_t *)((int64_t)&var_8h + iVar5 + 4) = in_R9D;
            *(undefined4 *)((int64_t)&var_10h + iVar5) = uVar1;
            *(undefined4 *)((int64_t)&var_10h + iVar5 + 4) = 0;
            *(undefined (*) [16])((int64_t)&iStackX_20 + iVar5 + -8) = ZEXT816(0);
            *(undefined (*) [16])((int64_t)&arg_28h + iVar5) = ZEXT816(0);
            if ((in_RCX != 0) && (in_R9D == 0)) {
                uVar6 = 0x400;
                *(undefined4 *)((int64_t)&var_8h + iVar5) = 0x400;
            }
            if (in_R8D == 1) {
                *(uint32_t *)((int64_t)&var_8h + iVar5) = uVar6 | 1;
            }
            uVar2 = *(undefined8 *)((int64_t)&arg_80h + iVar5);
            iVar3 = 0;
            while( true ) {
                if (*(code **)0x18077e780 == (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c113;
                    *(code **)0x18077e780 =
                         (code *)fcn.18026cb90(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                               *(int64_t *)((int64_t)&var_10h + iVar5), 
                                               *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                               *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                                               *(int64_t *)((int64_t)&arg_28h + iVar5), 
                                               *(int64_t *)(&stack0x00000138 + iVar5));
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c12a;
                iVar4 = (**(code **)0x18077e780)(in_RCX, in_RDX, (int64_t)&var_8h + iVar5, uVar2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c134;
                (*(code *)0x8000000000000070)(iVar4);
                if (iVar4 == 0) {
                    return 1;
                }
                if (iVar4 == 8) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c185;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c19d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)(&stack0x00000038 + iVar5));
                    iVar4 = 8;
                    if (iVar3 != 0) {
                        iVar4 = iVar3;
                    }
                    goto code_r0x00018026c1a7;
                }
                if ((*(uint32_t *)((int64_t)&var_8h + iVar5) >> 10 & 1) == 0) break;
                *(uint32_t *)((int64_t)&var_8h + iVar5) = *(uint32_t *)((int64_t)&var_8h + iVar5) & 0xfffffbff | 4;
                iVar3 = iVar4;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c15f;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c177;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5));
            if (iVar3 != 0) {
                iVar4 = iVar3;
            }
code_r0x00018026c1a7:
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c1ac;
            func_0x00018026d340(iVar4);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c1be;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c1d6;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c1ee;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)(&stack0x00000038 + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c200;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
    }
    return 0;
}

// ============================================================
// Function: FUN_18026c1d1
// Address: 0x18026c1d1
// Size: 72 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel

undefined4
fcn.18026c050(int64_t arg_28h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_78h, int64_t arg_80h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    int32_t in_R8D;
    uint32_t in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x18026c069;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if ((in_R9D < 0x18) && ((0x800005U >> (in_R9D & 0x1f) & 1) != 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c097;
        iVar3 = func_0x0001802748f0();
        if (iVar3 == 1) {
            uVar1 = *(undefined4 *)((int64_t)&arg_78h + iVar5);
            uVar6 = 0;
            *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_RSI;
            *(undefined4 *)((int64_t)&var_8h + iVar5) = 0;
            *(uint32_t *)((int64_t)&var_8h + iVar5 + 4) = in_R9D;
            *(undefined4 *)((int64_t)&var_10h + iVar5) = uVar1;
            *(undefined4 *)((int64_t)&var_10h + iVar5 + 4) = 0;
            *(undefined (*) [16])((int64_t)&iStackX_20 + iVar5 + -8) = ZEXT816(0);
            *(undefined (*) [16])((int64_t)&arg_28h + iVar5) = ZEXT816(0);
            if ((in_RCX != 0) && (in_R9D == 0)) {
                uVar6 = 0x400;
                *(undefined4 *)((int64_t)&var_8h + iVar5) = 0x400;
            }
            if (in_R8D == 1) {
                *(uint32_t *)((int64_t)&var_8h + iVar5) = uVar6 | 1;
            }
            uVar2 = *(undefined8 *)((int64_t)&arg_80h + iVar5);
            iVar3 = 0;
            while( true ) {
                if (*(code **)0x18077e780 == (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c113;
                    *(code **)0x18077e780 =
                         (code *)fcn.18026cb90(*(int64_t *)((int64_t)&var_8h + iVar5), 
                                               *(int64_t *)((int64_t)&var_10h + iVar5), 
                                               *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                               *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                                               *(int64_t *)((int64_t)&arg_28h + iVar5), 
                                               *(int64_t *)(&stack0x00000138 + iVar5));
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c12a;
                iVar4 = (**(code **)0x18077e780)(in_RCX, in_RDX, (int64_t)&var_8h + iVar5, uVar2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c134;
                (*(code *)0x8000000000000070)(iVar4);
                if (iVar4 == 0) {
                    return 1;
                }
                if (iVar4 == 8) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c185;
                    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c19d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)(&stack0x00000038 + iVar5));
                    iVar4 = 8;
                    if (iVar3 != 0) {
                        iVar4 = iVar3;
                    }
                    goto code_r0x00018026c1a7;
                }
                if ((*(uint32_t *)((int64_t)&var_8h + iVar5) >> 10 & 1) == 0) break;
                *(uint32_t *)((int64_t)&var_8h + iVar5) = *(uint32_t *)((int64_t)&var_8h + iVar5) & 0xfffffbff | 4;
                iVar3 = iVar4;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c15f;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c177;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5));
            if (iVar3 != 0) {
                iVar4 = iVar3;
            }
code_r0x00018026c1a7:
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c1ac;
            func_0x00018026d340(iVar4);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c1be;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c1d6;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c1ee;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)(&stack0x00000038 + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18026c200;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
    }
    return 0;
}

// ============================================================
// Function: FUN_18026c220
// Address: 0x18026c220
// Size: 200 bytes
// ============================================================
undefined8 fcn.18026c220(int64_t arg4, int64_t arg_30h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    char *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar5;
    char *pcVar6;
    int64_t *in_R8;
    char *pcVar7;
    int64_t aiStackX_8 [3];
    int64_t var_20h;
    undefined8 uStack_40;
    
    var_20h._0_4_ = (undefined4)arg4;
    uStack_40 = 0x18026c23a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    pcVar7 = (char *)0x0;
    iVar4 = 0;
    if (*in_RCX == '[') {
        *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c261;
        iVar2 = func_0x00018045b928();
        if (iVar2 == 0) goto code_r0x00018026c3ac;
        pcVar7 = in_RCX + 1;
        iVar5 = iVar2 - (int64_t)pcVar7;
        if (*(char *)(iVar2 + 1) != '\0') {
            if (*(char *)(iVar2 + 1) != ':') goto code_r0x00018026c3ac;
            pcVar6 = (char *)(iVar2 + 2);
            goto code_r0x00018026c361;
        }
        in_RCX = (char *)0x0;
        iVar3 = iVar4;
code_r0x00018026c281:
        pcVar6 = in_RCX;
        iVar4 = iVar3;
        in_RCX = pcVar7;
        if (pcVar7 == (char *)0x0) goto code_r0x00018026c3f4;
    } else {
        *(undefined8 *)((int64_t)&arg_30h + iVar1) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c2f2;
        iVar5 = func_0x00018045b9a8();
        *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c302;
        iVar2 = func_0x00018045b928(in_RCX, 0x3a);
        if (iVar2 != iVar5) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c314;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar1), *(int64_t *)(&stack0xfffffffffffffff0 + iVar1)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c32c;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar1), *(int64_t *)(&stack0xfffffffffffffff0 + iVar1)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar1 + 0x10));
            *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c33e;
            fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar1));
            return 0;
        }
        if (iVar2 != 0) {
            iVar5 = iVar2 - (int64_t)in_RCX;
            pcVar6 = (char *)(iVar2 + 1);
            pcVar7 = in_RCX;
code_r0x00018026c361:
            in_RCX = pcVar6;
            *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c369;
            iVar3 = func_0x000180498cd0(in_RCX);
            iVar2 = iVar5;
            if (in_RCX != (char *)0x0) {
code_r0x00018026c396:
                iVar5 = iVar2;
                *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c3a3;
                iVar4 = func_0x00018045b928(in_RCX, 0x3a);
                if (iVar4 != 0) {
code_r0x00018026c3ac:
                    *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c3b1;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar1), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar1));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c3c9;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar1), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar1), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1)
                                  , *(int64_t *)((int64_t)aiStackX_8 + iVar1 + 0x10));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c3db;
                    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar1));
                    return 0;
                }
            }
            goto code_r0x00018026c281;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c37f;
        iVar5 = func_0x000180498cd0(in_RCX);
        iVar2 = 0;
        iVar3 = iVar5;
        if (*(int32_t *)((int64_t)&arg_40h + iVar1) != 0) goto code_r0x00018026c396;
        pcVar6 = (char *)0x0;
    }
    if (in_RDX != (int64_t *)0x0) {
        if ((iVar5 == 0) || ((iVar5 == 1 && (*in_RCX == '*')))) {
            *in_RDX = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c2c4;
            iVar5 = func_0x000180223270(in_RCX, iVar5, 0x1804e7560, 0x234);
            *in_RDX = iVar5;
            if (iVar5 == 0) {
                return 0;
            }
        }
    }
code_r0x00018026c3f4:
    if ((pcVar6 != (char *)0x0) && (in_R8 != (int64_t *)0x0)) {
        if ((iVar4 == 0) || ((iVar4 == 1 && (*pcVar6 == '*')))) {
            *in_R8 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c426;
            iVar4 = func_0x000180223270(pcVar6, iVar4, 0x1804e7560, 0x23e);
            *in_R8 = iVar4;
            if (iVar4 == 0) {
                if ((in_RCX != (char *)0x0) && (in_RDX != (int64_t *)0x0)) {
                    iVar4 = *in_RDX;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c44e;
                    fcn.180224990(iVar4, 0x1804e7560, 0x241);
                    *in_RDX = 0;
                }
                return 0;
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18026c2e8
// Address: 0x18026c2e8
// Size: 39 bytes
// ============================================================
undefined8 fcn.18026c220(int64_t arg4, int64_t arg_30h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    char *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar5;
    char *pcVar6;
    int64_t *in_R8;
    char *pcVar7;
    int64_t aiStackX_8 [3];
    int64_t var_20h;
    undefined8 uStack_40;
    
    var_20h._0_4_ = (undefined4)arg4;
    uStack_40 = 0x18026c23a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    pcVar7 = (char *)0x0;
    iVar4 = 0;
    if (*in_RCX == '[') {
        *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c261;
        iVar2 = func_0x00018045b928();
        if (iVar2 == 0) goto code_r0x00018026c3ac;
        pcVar7 = in_RCX + 1;
        iVar5 = iVar2 - (int64_t)pcVar7;
        if (*(char *)(iVar2 + 1) != '\0') {
            if (*(char *)(iVar2 + 1) != ':') goto code_r0x00018026c3ac;
            pcVar6 = (char *)(iVar2 + 2);
            goto code_r0x00018026c361;
        }
        in_RCX = (char *)0x0;
        iVar3 = iVar4;
code_r0x00018026c281:
        pcVar6 = in_RCX;
        iVar4 = iVar3;
        in_RCX = pcVar7;
        if (pcVar7 == (char *)0x0) goto code_r0x00018026c3f4;
    } else {
        *(undefined8 *)((int64_t)&arg_30h + iVar1) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c2f2;
        iVar5 = func_0x00018045b9a8();
        *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c302;
        iVar2 = func_0x00018045b928(in_RCX, 0x3a);
        if (iVar2 != iVar5) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c314;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar1), *(int64_t *)(&stack0xfffffffffffffff0 + iVar1)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c32c;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar1), *(int64_t *)(&stack0xfffffffffffffff0 + iVar1)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar1 + 0x10));
            *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c33e;
            fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar1));
            return 0;
        }
        if (iVar2 != 0) {
            iVar5 = iVar2 - (int64_t)in_RCX;
            pcVar6 = (char *)(iVar2 + 1);
            pcVar7 = in_RCX;
code_r0x00018026c361:
            in_RCX = pcVar6;
            *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c369;
            iVar3 = func_0x000180498cd0(in_RCX);
            iVar2 = iVar5;
            if (in_RCX != (char *)0x0) {
code_r0x00018026c396:
                iVar5 = iVar2;
                *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c3a3;
                iVar4 = func_0x00018045b928(in_RCX, 0x3a);
                if (iVar4 != 0) {
code_r0x00018026c3ac:
                    *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c3b1;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar1), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar1));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c3c9;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar1), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar1), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1)
                                  , *(int64_t *)((int64_t)aiStackX_8 + iVar1 + 0x10));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c3db;
                    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar1));
                    return 0;
                }
            }
            goto code_r0x00018026c281;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c37f;
        iVar5 = func_0x000180498cd0(in_RCX);
        iVar2 = 0;
        iVar3 = iVar5;
        if (*(int32_t *)((int64_t)&arg_40h + iVar1) != 0) goto code_r0x00018026c396;
        pcVar6 = (char *)0x0;
    }
    if (in_RDX != (int64_t *)0x0) {
        if ((iVar5 == 0) || ((iVar5 == 1 && (*in_RCX == '*')))) {
            *in_RDX = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c2c4;
            iVar5 = func_0x000180223270(in_RCX, iVar5, 0x1804e7560, 0x234);
            *in_RDX = iVar5;
            if (iVar5 == 0) {
                return 0;
            }
        }
    }
code_r0x00018026c3f4:
    if ((pcVar6 != (char *)0x0) && (in_R8 != (int64_t *)0x0)) {
        if ((iVar4 == 0) || ((iVar4 == 1 && (*pcVar6 == '*')))) {
            *in_R8 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c426;
            iVar4 = func_0x000180223270(pcVar6, iVar4, 0x1804e7560, 0x23e);
            *in_R8 = iVar4;
            if (iVar4 == 0) {
                if ((in_RCX != (char *)0x0) && (in_RDX != (int64_t *)0x0)) {
                    iVar4 = *in_RDX;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c44e;
                    fcn.180224990(iVar4, 0x1804e7560, 0x241);
                    *in_RDX = 0;
                }
                return 0;
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18026c30f
// Address: 0x18026c30f
// Size: 373 bytes
// ============================================================
undefined8 fcn.18026c220(int64_t arg4, int64_t arg_30h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    char *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    int64_t iVar5;
    char *pcVar6;
    int64_t *in_R8;
    char *pcVar7;
    int64_t aiStackX_8 [3];
    int64_t var_20h;
    undefined8 uStack_40;
    
    var_20h._0_4_ = (undefined4)arg4;
    uStack_40 = 0x18026c23a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    pcVar7 = (char *)0x0;
    iVar4 = 0;
    if (*in_RCX == '[') {
        *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c261;
        iVar2 = func_0x00018045b928();
        if (iVar2 == 0) goto code_r0x00018026c3ac;
        pcVar7 = in_RCX + 1;
        iVar5 = iVar2 - (int64_t)pcVar7;
        if (*(char *)(iVar2 + 1) != '\0') {
            if (*(char *)(iVar2 + 1) != ':') goto code_r0x00018026c3ac;
            pcVar6 = (char *)(iVar2 + 2);
            goto code_r0x00018026c361;
        }
        in_RCX = (char *)0x0;
        iVar3 = iVar4;
code_r0x00018026c281:
        pcVar6 = in_RCX;
        iVar4 = iVar3;
        in_RCX = pcVar7;
        if (pcVar7 == (char *)0x0) goto code_r0x00018026c3f4;
    } else {
        *(undefined8 *)((int64_t)&arg_30h + iVar1) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c2f2;
        iVar5 = func_0x00018045b9a8();
        *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c302;
        iVar2 = func_0x00018045b928(in_RCX, 0x3a);
        if (iVar2 != iVar5) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c314;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar1), *(int64_t *)(&stack0xfffffffffffffff0 + iVar1)
                         );
            *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c32c;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar1), *(int64_t *)(&stack0xfffffffffffffff0 + iVar1)
                          , *(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar1 + 0x10));
            *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c33e;
            fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar1));
            return 0;
        }
        if (iVar2 != 0) {
            iVar5 = iVar2 - (int64_t)in_RCX;
            pcVar6 = (char *)(iVar2 + 1);
            pcVar7 = in_RCX;
code_r0x00018026c361:
            in_RCX = pcVar6;
            *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c369;
            iVar3 = func_0x000180498cd0(in_RCX);
            iVar2 = iVar5;
            if (in_RCX != (char *)0x0) {
code_r0x00018026c396:
                iVar5 = iVar2;
                *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c3a3;
                iVar4 = func_0x00018045b928(in_RCX, 0x3a);
                if (iVar4 != 0) {
code_r0x00018026c3ac:
                    *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c3b1;
                    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar1), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar1));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c3c9;
                    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar1), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar1), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar1), *(int64_t *)(&stack0x00000000 + iVar1)
                                  , *(int64_t *)((int64_t)aiStackX_8 + iVar1 + 0x10));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c3db;
                    fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar1));
                    return 0;
                }
            }
            goto code_r0x00018026c281;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c37f;
        iVar5 = func_0x000180498cd0(in_RCX);
        iVar2 = 0;
        iVar3 = iVar5;
        if (*(int32_t *)((int64_t)&arg_40h + iVar1) != 0) goto code_r0x00018026c396;
        pcVar6 = (char *)0x0;
    }
    if (in_RDX != (int64_t *)0x0) {
        if ((iVar5 == 0) || ((iVar5 == 1 && (*in_RCX == '*')))) {
            *in_RDX = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c2c4;
            iVar5 = func_0x000180223270(in_RCX, iVar5, 0x1804e7560, 0x234);
            *in_RDX = iVar5;
            if (iVar5 == 0) {
                return 0;
            }
        }
    }
code_r0x00018026c3f4:
    if ((pcVar6 != (char *)0x0) && (in_R8 != (int64_t *)0x0)) {
        if ((iVar4 == 0) || ((iVar4 == 1 && (*pcVar6 == '*')))) {
            *in_R8 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c426;
            iVar4 = func_0x000180223270(pcVar6, iVar4, 0x1804e7560, 0x23e);
            *in_R8 = iVar4;
            if (iVar4 == 0) {
                if ((in_RCX != (char *)0x0) && (in_RDX != (int64_t *)0x0)) {
                    iVar4 = *in_RDX;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar1) = 0x18026c44e;
                    fcn.180224990(iVar4, 0x1804e7560, 0x241);
                    *in_RDX = 0;
                }
                return 0;
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18026c490
// Address: 0x18026c490
// Size: 91 bytes
// ============================================================
void fcn.18026c490(int64_t arg1, int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_10h;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18026c4a5;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        do {
            if (*(int64_t *)(arg1 + 0x18) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026c4be;
                func_0x000180460d90();
            }
            if (*(int64_t *)(arg1 + 0x20) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026c4cc;
                func_0x000180460d90();
            }
            iVar1 = *(int64_t *)(arg1 + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026c4d8;
            func_0x000180460d90(arg1);
            arg1 = iVar1;
        } while (iVar1 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_18026c4f0
// Address: 0x18026c4f0
// Size: 264 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Removing arg arg_838h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_8a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Removing arg arg_428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_429h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_848h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_898h because it doesn't fit into ProtoModel

uint32_t fcn.18026c4f0(int64_t arg4, int64_t arg_48h, int64_t arg_50h, int64_t arg_60h)
{
    undefined4 uVar1;
    uint32_t *puVar2;
    int16_t iVar3;
    int16_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined2 *puVar10;
    uint32_t *puVar11;
    undefined8 uVar12;
    char *in_RCX;
    char cVar13;
    int16_t iVar14;
    int64_t in_RDX;
    uint32_t uVar15;
    uint32_t uVar16;
    uint32_t *in_R8;
    char *pcVar17;
    undefined8 unaff_R12;
    uint32_t **ppuVar18;
    int32_t iVar19;
    bool bVar20;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_40 = 0x18026c509;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar7 = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar8 + 4) = 0;
    *(undefined8 *)(&stack0x00000000 + iVar8) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar8) = 0;
    iVar14 = 0;
    *(undefined2 *)((int64_t)&arg_48h + iVar8) = 0;
    iVar3 = 0;
    *(undefined8 *)arg4 = 0;
    if ((in_RCX == (char *)0x0) && (in_RDX == 0)) {
        return 0x2af9;
    }
    uVar16 = uVar7;
    if (in_R8 != (uint32_t *)0x0) {
        if ((((*(int64_t *)(in_R8 + 4) != 0) || (*(int64_t *)(in_R8 + 6) != 0)) || (*(int64_t *)(in_R8 + 8) != 0)) ||
           (*(int64_t *)(in_R8 + 10) != 0)) {
            return 0x2afb;
        }
        uVar7 = *in_R8;
        if (((uVar7 & 2) != 0) && (in_RCX == (char *)0x0)) {
            return 0x2726;
        }
        if ((in_R8[1] != 0) && (in_R8[1] != 2)) {
            return 0x273f;
        }
        uVar16 = in_R8[2];
        if ((uVar16 != 0) && (2 < uVar16 - 1)) {
            return 0x273c;
        }
        *(uint32_t *)((int64_t)&var_8h + iVar8 + 4) = in_R8[3];
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar8) = unaff_R12;
    if (in_RDX == 0) {
        iVar4 = 0;
code_r0x00018026c71d:
        iVar19 = *(int32_t *)((int64_t)&var_8h + iVar8);
    } else {
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18026c61f;
        iVar3 = fcn.18046c694(in_RDX, (int64_t)&stack0x00000000 + iVar8, 10);
        if (**(char **)(&stack0x00000000 + iVar8) == '\0') {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18026c636;
            iVar4 = (*(code *)0x8000000000000009)(iVar3);
            uVar15 = uVar16;
            if (uVar16 == 0) {
                uVar15 = 1;
            }
            *(uint32_t *)((int64_t)&var_8h + iVar8) = (uint32_t)(uVar16 == 0);
            uVar16 = uVar15;
            iVar3 = iVar4;
            goto code_r0x00018026c71d;
        }
        if ((uVar16 & 0xfffffffd) == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18026c689;
            iVar9 = (*(code *)0x8000000000000037)(in_RDX);
            if (iVar9 != 0) {
                iVar3 = *(int16_t *)(iVar9 + 0x18);
                *(int16_t *)((int64_t)&arg_48h + iVar8) = iVar3;
            }
            if (uVar16 != 0) goto code_r0x00018026c6a2;
code_r0x00018026c6a7:
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18026c6b7;
            iVar9 = (*(code *)0x8000000000000037)(in_RDX);
            if (iVar9 != 0) {
                iVar14 = *(int16_t *)(iVar9 + 0x18);
                iVar3 = iVar14;
            }
        } else {
code_r0x00018026c6a2:
            if (uVar16 == 1) goto code_r0x00018026c6a7;
        }
        if (iVar3 == 0) {
            if (uVar16 == 0) {
                return 0x2af9;
            }
            return 0x277d;
        }
        iVar4 = *(int16_t *)((int64_t)&arg_48h + iVar8);
        if (uVar16 != 0) goto code_r0x00018026c71d;
        uVar16 = 2 - (iVar14 != 0);
        if ((iVar14 == 0) || (iVar4 == 0)) {
            iVar19 = 0;
        } else {
            iVar19 = 1;
        }
    }
    iVar6 = 0;
    if (in_RCX == (char *)0x0) {
        iVar5 = 0x7f000001;
        if ((uVar7 & 1) != 0) {
            iVar5 = iVar6;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18026c8c8;
        iVar6 = (*(code *)0x8000000000000008)(iVar5);
code_r0x00018026c8ca:
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18026c8dc;
        puVar11 = (uint32_t *)
                  fcn.18026cfe0(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                                *(int64_t *)((int64_t)&var_8h + iVar8), *(int64_t *)(&stack0x00000000 + iVar8));
        ppuVar18 = *(uint32_t ***)((int64_t)&arg_60h + iVar8);
        *ppuVar18 = puVar11;
        if (puVar11 == (uint32_t *)0x0) {
            uVar7 = 8;
            goto code_r0x00018026c784;
        }
        if ((in_RCX != (char *)0x0) && (*puVar11 = *puVar11 | 4, (uVar7 & 2) != 0)) {
            puVar11 = *ppuVar18;
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18026c919;
            (*(code *)0x800000000000000c)(iVar6);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18026c921;
            uVar12 = fcn.18026d090(*(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8));
            *(undefined8 *)(puVar11 + 6) = uVar12;
            if (*(int64_t *)(*ppuVar18 + 6) == 0) {
                uVar7 = 8;
                goto code_r0x00018026c784;
            }
        }
code_r0x00018026c81a:
        if (iVar19 == 0) {
            return 0;
        }
        puVar11 = *ppuVar18;
        while (puVar11 != (uint32_t *)0x0) {
            uVar7 = puVar11[3];
            uVar1 = *(undefined4 *)(*(int64_t *)(puVar11 + 8) + 4);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18026c857;
            iVar9 = fcn.180461640(1, 0x30);
            if (iVar9 == 0) break;
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18026c870;
            puVar10 = (undefined2 *)fcn.180461640(1, 0x10);
            if (puVar10 == (undefined2 *)0x0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18026c945;
                fcn.180460d90(iVar9);
                break;
            }
            *puVar10 = 2;
            puVar10[1] = iVar4;
            *(undefined4 *)(puVar10 + 2) = uVar1;
            *(undefined4 *)(iVar9 + 4) = 2;
            *(undefined4 *)(iVar9 + 8) = 2;
            *(uint32_t *)(iVar9 + 0xc) = uVar7;
            *(undefined8 *)(iVar9 + 0x10) = 0x10;
            *(undefined2 **)(iVar9 + 0x20) = puVar10;
            *(undefined8 *)(iVar9 + 0x28) = *(undefined8 *)(puVar11 + 10);
            *(int64_t *)(puVar11 + 10) = iVar9;
            puVar11 = *(uint32_t **)(iVar9 + 0x28);
        }
        uVar7 = -(uint32_t)(puVar11 != (uint32_t *)0x0) & 8;
        if (puVar11 == (uint32_t *)0x0) {
            return uVar7;
        }
    } else {
        cVar13 = *in_RCX;
        pcVar17 = in_RCX;
        if (cVar13 != '\0') {
            do {
                bVar20 = cVar13 != '.';
                cVar13 = pcVar17[1];
                iVar5 = iVar6 + 1;
                if (bVar20) {
                    iVar5 = iVar6;
                }
                pcVar17 = pcVar17 + 1;
                iVar6 = iVar5;
            } while (cVar13 != '\0');
            if (iVar5 == 3) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18026c766;
                iVar6 = (*(code *)0x800000000000000b)(in_RCX);
                if (iVar6 != -1) goto code_r0x00018026c8ca;
            }
        }
        if ((uVar7 & 4) == 0) {
            uVar1 = *(undefined4 *)((int64_t)&var_8h + iVar8 + 4);
            *(undefined8 *)((int64_t)&var_10h + iVar8) = *(undefined8 *)((int64_t)&arg_60h + iVar8);
            *(uint32_t *)((int64_t)&var_18h + iVar8) = uVar7 & 2;
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18026c808;
            uVar7 = fcn.18026cda0(in_RCX, uVar16, uVar1, iVar3);
            if (uVar7 == 0) {
                ppuVar18 = *(uint32_t ***)((int64_t)&arg_60h + iVar8);
                goto code_r0x00018026c81a;
            }
        } else {
            uVar7 = 0x2af9;
        }
        ppuVar18 = *(uint32_t ***)((int64_t)&arg_60h + iVar8);
    }
code_r0x00018026c784:
    puVar11 = *ppuVar18;
    while (puVar11 != (uint32_t *)0x0) {
        if (*(int64_t *)(puVar11 + 6) != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18026c79e;
            fcn.180460d90();
        }
        if (*(int64_t *)(puVar11 + 8) != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18026c7ac;
            fcn.180460d90();
        }
        puVar2 = *(uint32_t **)(puVar11 + 10);
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18026c7b8;
        fcn.180460d90(puVar11);
        puVar11 = puVar2;
    }
    *ppuVar18 = (uint32_t *)0x0;
    return uVar7;
}

