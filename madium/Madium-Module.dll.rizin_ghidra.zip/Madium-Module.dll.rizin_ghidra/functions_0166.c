// Chunk 166 - 50 functions

// ============================================================
// Function: FUN_18022085b
// Address: 0x18022085b
// Size: 7 bytes
// ============================================================
undefined8 fcn.18022085b(void)
{
    return 0;
}

// ============================================================
// Function: FUN_180220870
// Address: 0x180220870
// Size: 102 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180220870(int64_t arg_28h)
{
    uint32_t uVar1;
    uint32_t *puVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint32_t in_ECX;
    uint32_t *in_RDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180220880;
    iVar3 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x18022088d;
    uVar4 = fcn.180221370();
    if ((int32_t)uVar4 != 0) {
        uVar1 = *in_RDX;
        puVar2 = in_RDX;
        while (uVar1 != 0) {
            *puVar2 = uVar1 | (in_ECX & 0xff) << 0x17;
            puVar2 = puVar2 + 4;
            uVar1 = *puVar2;
        }
        *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x1802208c6;
        fcn.180221060(in_RDX);
        return 1;
    }
    return uVar4;
}

// ============================================================
// Function: FUN_1802208e0
// Address: 0x1802208e0
// Size: 52 bytes
// ============================================================
undefined8 fcn.1802208e0(undefined8 param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802208ec;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x1802208f7;
    uVar2 = fcn.180221370();
    if ((int32_t)uVar2 == 0) {
        return uVar2;
    }
    *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180220909;
    fcn.180221060(param_1);
    return 1;
}

// ============================================================
// Function: FUN_180220920
// Address: 0x180220920
// Size: 210 bytes
// ============================================================
undefined4 fcn.180220920(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022092c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180220934;
    iVar2 = fcn.180221280(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)(iVar2 + 0x344);
        iVar5 = *(int32_t *)(iVar2 + 0x340);
        if (iVar3 != iVar5) {
            do {
                if ((*(uint8_t *)(iVar2 + (int64_t)iVar5 * 4) & 2) == 0) {
                    uVar4 = iVar3 + 1U & 0x8000000f;
                    if ((int32_t)uVar4 < 0) {
                        uVar4 = (uVar4 - 1 | 0xfffffff0) + 1;
                    }
                    if ((*(uint8_t *)(iVar2 + (int64_t)(int32_t)uVar4 * 4) & 2) == 0) break;
                    *(uint32_t *)(iVar2 + 0x344) = uVar4;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802209b6;
                    fcn.180220e60(*(int64_t *)((int64_t)aiStackX_18 + iVar1), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18022096a;
                    fcn.180220e60(*(int64_t *)((int64_t)aiStackX_18 + iVar1), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
                    if (*(int32_t *)(iVar2 + 0x340) < 1) {
                        *(undefined4 *)(iVar2 + 0x340) = 0xf;
                    } else {
                        *(int32_t *)(iVar2 + 0x340) = *(int32_t *)(iVar2 + 0x340) + -1;
                    }
                }
                iVar3 = *(int32_t *)(iVar2 + 0x344);
                iVar5 = *(int32_t *)(iVar2 + 0x340);
            } while (iVar3 != iVar5);
            if (iVar3 != iVar5) {
                uVar4 = iVar3 + 1U & 0x8000000f;
                if ((int32_t)uVar4 < 0) {
                    uVar4 = (uVar4 - 1 | 0xfffffff0) + 1;
                }
                return *(undefined4 *)(iVar2 + 0x80 + (int64_t)(int32_t)uVar4 * 4);
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180220a00
// Address: 0x180220a00
// Size: 194 bytes
// ============================================================
undefined4 fcn.180220a00(void)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180220a0c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220a14;
    iVar3 = fcn.180221280(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    if (iVar3 != 0) {
        iVar5 = *(int32_t *)(iVar3 + 0x344);
        iVar4 = *(int32_t *)(iVar3 + 0x340);
        if (iVar5 != iVar4) {
            do {
                if ((*(uint8_t *)(iVar3 + (int64_t)iVar4 * 4) & 2) == 0) {
                    uVar1 = iVar5 + 1U & 0x8000000f;
                    if ((int32_t)uVar1 < 0) {
                        uVar1 = (uVar1 - 1 | 0xfffffff0) + 1;
                    }
                    if ((*(uint8_t *)(iVar3 + (int64_t)(int32_t)uVar1 * 4) & 2) == 0) break;
                    *(uint32_t *)(iVar3 + 0x344) = uVar1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220a97;
                    fcn.180220e60(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220a4a;
                    fcn.180220e60(*(int64_t *)((int64_t)aiStackX_18 + iVar2), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
                    if (*(int32_t *)(iVar3 + 0x340) < 1) {
                        *(undefined4 *)(iVar3 + 0x340) = 0xf;
                    } else {
                        *(int32_t *)(iVar3 + 0x340) = *(int32_t *)(iVar3 + 0x340) + -1;
                    }
                }
                iVar5 = *(int32_t *)(iVar3 + 0x344);
                iVar4 = *(int32_t *)(iVar3 + 0x340);
            } while (iVar5 != iVar4);
            if (iVar5 != iVar4) {
                return *(undefined4 *)(iVar3 + 0x80 + (int64_t)iVar4 * 4);
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180220ad0
// Address: 0x180220ad0
// Size: 76 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180220ad0(int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint32_t in_ECX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180220ae0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220af8;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)&var_18h + iVar3));
    iVar2 = 0;
    if (iVar1 != 0) {
        iVar2 = *(int32_t *)0x18077e314;
    }
    if ((iVar2 == 0) || ((int32_t)in_ECX < 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(uint32_t *)((int64_t)&var_18h + iVar3) = in_ECX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220b32;
    iVar2 = func_0x000180222850(*(undefined8 *)0x18077e318);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220b47;
        iVar4 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&var_18h + iVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220b56;
        fcn.180222910(*(undefined8 *)0x18077e318);
        if (iVar4 != 0) goto code_r0x000180220b94;
    }
    *(uint32_t *)((int64_t)&var_18h + iVar3) = in_ECX & 0x7fffff;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220b6b;
    iVar2 = func_0x000180222850(*(undefined8 *)0x18077e318);
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220b80;
    iVar4 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&var_18h + iVar3);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220b8f;
    fcn.180222910(*(undefined8 *)0x18077e318);
    if (iVar4 == 0) {
        return 0;
    }
code_r0x000180220b94:
    return *(undefined8 *)(iVar4 + 8);
}

// ============================================================
// Function: FUN_180220b1c
// Address: 0x180220b1c
// Size: 143 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180220ad0(int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint32_t in_ECX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180220ae0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220af8;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)&var_18h + iVar3));
    iVar2 = 0;
    if (iVar1 != 0) {
        iVar2 = *(int32_t *)0x18077e314;
    }
    if ((iVar2 == 0) || ((int32_t)in_ECX < 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(uint32_t *)((int64_t)&var_18h + iVar3) = in_ECX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220b32;
    iVar2 = func_0x000180222850(*(undefined8 *)0x18077e318);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220b47;
        iVar4 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&var_18h + iVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220b56;
        fcn.180222910(*(undefined8 *)0x18077e318);
        if (iVar4 != 0) goto code_r0x000180220b94;
    }
    *(uint32_t *)((int64_t)&var_18h + iVar3) = in_ECX & 0x7fffff;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220b6b;
    iVar2 = func_0x000180222850(*(undefined8 *)0x18077e318);
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220b80;
    iVar4 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&var_18h + iVar3);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220b8f;
    fcn.180222910(*(undefined8 *)0x18077e318);
    if (iVar4 == 0) {
        return 0;
    }
code_r0x000180220b94:
    return *(undefined8 *)(iVar4 + 8);
}

// ============================================================
// Function: FUN_180220bab
// Address: 0x180220bab
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180220ad0(int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint32_t in_ECX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180220ae0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220af8;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)&var_18h + iVar3));
    iVar2 = 0;
    if (iVar1 != 0) {
        iVar2 = *(int32_t *)0x18077e314;
    }
    if ((iVar2 == 0) || ((int32_t)in_ECX < 0)) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(uint32_t *)((int64_t)&var_18h + iVar3) = in_ECX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220b32;
    iVar2 = func_0x000180222850(*(undefined8 *)0x18077e318);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220b47;
        iVar4 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&var_18h + iVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220b56;
        fcn.180222910(*(undefined8 *)0x18077e318);
        if (iVar4 != 0) goto code_r0x000180220b94;
    }
    *(uint32_t *)((int64_t)&var_18h + iVar3) = in_ECX & 0x7fffff;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220b6b;
    iVar2 = func_0x000180222850(*(undefined8 *)0x18077e318);
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220b80;
    iVar4 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&var_18h + iVar3);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220b8f;
    fcn.180222910(*(undefined8 *)0x18077e318);
    if (iVar4 == 0) {
        return 0;
    }
code_r0x000180220b94:
    return *(undefined8 *)(iVar4 + 8);
}

// ============================================================
// Function: FUN_180220bc0
// Address: 0x180220bc0
// Size: 135 bytes
// ============================================================
undefined8 fcn.180220bc0(undefined8 param_1, int32_t *param_2)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180220bcc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220be5;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    iVar2 = 0;
    if (iVar1 != 0) {
        iVar2 = *(int32_t *)0x18077e314;
    }
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220c00;
        iVar2 = fcn.180222950(*(undefined8 *)0x18077e318);
        if (iVar2 != 0) {
            iVar2 = *param_2;
            while (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220c1f;
                func_0x000180228b10(*(undefined8 *)0x18077e320, param_2);
                param_2 = param_2 + 4;
                iVar2 = *param_2;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180220c34;
            fcn.180222910(*(undefined8 *)0x18077e318);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180220c50
// Address: 0x180220c50
// Size: 23 bytes
// ============================================================
void fcn.180220c50(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 unaff_RBX;
    undefined8 *puVar3;
    undefined8 unaff_RBP;
    int64_t iVar4;
    undefined8 unaff_RDI;
    undefined4 *puVar5;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180220c64;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBP;
        puVar3 = (undefined8 *)(arg1 + 0xc0);
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RDI;
        iVar4 = 0x10;
        *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_R14;
        puVar5 = (undefined4 *)(arg1 + 0x1c0);
        do {
            if ((*(uint8_t *)puVar5 & 1) != 0) {
                uVar1 = *puVar3;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220cae;
                fcn.180224990(uVar1, 0x1804bf6a0, 0x19);
            }
            *puVar3 = 0;
            puVar3[0x10] = 0;
            *puVar5 = 0;
            puVar5[-0x60] = 0;
            puVar5[-0x70] = 0;
            puVar5[-0x50] = 0;
            puVar5[0x30] = 0xffffffff;
            uVar1 = puVar3[0x28];
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220cf3;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x5b);
            uVar1 = puVar3[0x40];
            puVar3[0x28] = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220d13;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x5d);
            puVar3[0x40] = 0;
            puVar5 = puVar5 + 1;
            puVar3 = puVar3 + 1;
            iVar4 = iVar4 + -1;
        } while (iVar4 != 0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220d55;
        fcn.180224990(arg1, 0x1804bf6f0, 0xcf);
    }
    return;
}

// ============================================================
// Function: FUN_180220c67
// Address: 0x180220c67
// Size: 243 bytes
// ============================================================
void fcn.180220c50(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 unaff_RBX;
    undefined8 *puVar3;
    undefined8 unaff_RBP;
    int64_t iVar4;
    undefined8 unaff_RDI;
    undefined4 *puVar5;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180220c64;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBP;
        puVar3 = (undefined8 *)(arg1 + 0xc0);
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RDI;
        iVar4 = 0x10;
        *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_R14;
        puVar5 = (undefined4 *)(arg1 + 0x1c0);
        do {
            if ((*(uint8_t *)puVar5 & 1) != 0) {
                uVar1 = *puVar3;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220cae;
                fcn.180224990(uVar1, 0x1804bf6a0, 0x19);
            }
            *puVar3 = 0;
            puVar3[0x10] = 0;
            *puVar5 = 0;
            puVar5[-0x60] = 0;
            puVar5[-0x70] = 0;
            puVar5[-0x50] = 0;
            puVar5[0x30] = 0xffffffff;
            uVar1 = puVar3[0x28];
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220cf3;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x5b);
            uVar1 = puVar3[0x40];
            puVar3[0x28] = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220d13;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x5d);
            puVar3[0x40] = 0;
            puVar5 = puVar5 + 1;
            puVar3 = puVar3 + 1;
            iVar4 = iVar4 + -1;
        } while (iVar4 != 0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220d55;
        fcn.180224990(arg1, 0x1804bf6f0, 0xcf);
    }
    return;
}

// ============================================================
// Function: FUN_180220d5a
// Address: 0x180220d5a
// Size: 1 bytes
// ============================================================
void fcn.180220c50(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 unaff_RBX;
    undefined8 *puVar3;
    undefined8 unaff_RBP;
    int64_t iVar4;
    undefined8 unaff_RDI;
    undefined4 *puVar5;
    undefined8 unaff_R14;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180220c64;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBP;
        puVar3 = (undefined8 *)(arg1 + 0xc0);
        *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RDI;
        iVar4 = 0x10;
        *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_R14;
        puVar5 = (undefined4 *)(arg1 + 0x1c0);
        do {
            if ((*(uint8_t *)puVar5 & 1) != 0) {
                uVar1 = *puVar3;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220cae;
                fcn.180224990(uVar1, 0x1804bf6a0, 0x19);
            }
            *puVar3 = 0;
            puVar3[0x10] = 0;
            *puVar5 = 0;
            puVar5[-0x60] = 0;
            puVar5[-0x70] = 0;
            puVar5[-0x50] = 0;
            puVar5[0x30] = 0xffffffff;
            uVar1 = puVar3[0x28];
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220cf3;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x5b);
            uVar1 = puVar3[0x40];
            puVar3[0x28] = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220d13;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x5d);
            puVar3[0x40] = 0;
            puVar5 = puVar5 + 1;
            puVar3 = puVar3 + 1;
            iVar4 = iVar4 + -1;
        } while (iVar4 != 0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220d55;
        fcn.180224990(arg1, 0x1804bf6f0, 0xcf);
    }
    return;
}

// ============================================================
// Function: FUN_180220d60
// Address: 0x180220d60
// Size: 178 bytes
// ============================================================
void fcn.180220d60(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180220d6a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180220d79;
    iVar1 = fcn.180243560(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                          *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180220d8f;
        *(int64_t *)0x18077e318 = fcn.180222800();
        if (*(int64_t *)0x18077e318 != 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180220dae;
            fcn.180229130(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
            *(undefined8 *)((int64_t)&var_20h + iVar2) = 0x180195290;
            *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180220dd7;
            *(int64_t *)0x18077e320 = fcn.180229290(*(int64_t *)((int64_t)&var_20h + iVar2));
            if (*(int64_t *)0x18077e320 == 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180220def;
                fcn.1802227d0(*(int64_t *)0x18077e318);
                *(undefined8 *)0x18077e318 = 0;
                *(undefined4 *)0x18077e314 = 0;
                return;
            }
            *(undefined4 *)0x18077e314 = 1;
            return;
        }
    }
    *(undefined4 *)0x18077e314 = 0;
    return;
}

// ============================================================
// Function: FUN_180220e20
// Address: 0x180220e20
// Size: 64 bytes
// ============================================================
void fcn.180220e20(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x180220e2a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180220e39;
    fcn.1802227d0(*(undefined8 *)0x18077e318);
    *(undefined8 *)0x18077e318 = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180220e50;
    fcn.180228ec0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                  *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1));
    *(undefined8 *)0x18077e320 = 0;
    return;
}

// ============================================================
// Function: FUN_180220e60
// Address: 0x180220e60
// Size: 146 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180220e60(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180220e75;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220e83;
    fcn.180220f00(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
    *(undefined4 *)(in_RCX + 0x280 + in_RDX * 4) = 0xffffffff;
    *(undefined4 *)(in_RCX + 0x40 + in_RDX * 4) = 0;
    *(undefined4 *)(in_RCX + in_RDX * 4) = 0;
    *(undefined4 *)(in_RCX + 0x80 + in_RDX * 4) = 0;
    uVar1 = *(undefined8 *)(in_RCX + 0x200 + in_RDX * 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220eb8;
    fcn.180224990(uVar1, 0x1804bf6a0, 0x5b);
    uVar1 = *(undefined8 *)(in_RCX + 0x2c0 + in_RDX * 8);
    *(undefined8 *)(in_RCX + 0x200 + in_RDX * 8) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180220eda;
    fcn.180224990(uVar1, 0x1804bf6a0, 0x5d);
    *(undefined8 *)(in_RCX + 0x2c0 + in_RDX * 8) = 0;
    return;
}

// ============================================================
// Function: FUN_180220f00
// Address: 0x180220f00
// Size: 176 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180220f00(int64_t arg_28h)
{
    undefined8 uVar1;
    undefined *puVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    int32_t in_R8D;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180220f10;
    iVar3 = fcn.18045a350();
    if ((*(uint8_t *)(in_RCX + 0x1c0 + in_RDX * 4) & 1) == 0) {
        *(undefined8 *)(in_RCX + 0xc0 + in_RDX * 8) = 0;
        *(undefined8 *)(in_RCX + 0x140 + in_RDX * 8) = 0;
        *(undefined4 *)(in_RCX + 0x1c0 + in_RDX * 4) = 0;
    } else {
        if (in_R8D != 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0xc0 + in_RDX * 8);
            *(undefined8 *)((int64_t)&uStack_10 - iVar3) = 0x180220f42;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x19);
            *(undefined8 *)(in_RCX + 0xc0 + in_RDX * 8) = 0;
            *(undefined8 *)(in_RCX + 0x140 + in_RDX * 8) = 0;
            *(undefined4 *)(in_RCX + 0x1c0 + in_RDX * 4) = 0;
            return;
        }
        puVar2 = *(undefined **)(in_RCX + 0xc0 + in_RDX * 8);
        if (puVar2 != (undefined *)0x0) {
            *puVar2 = 0;
            *(undefined4 *)(in_RCX + 0x1c0 + in_RDX * 4) = 1;
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180220fb0
// Address: 0x180220fb0
// Size: 83 bytes
// ============================================================
uint64_t fcn.180220fb0(int64_t arg_30h)
{
    uint32_t *puVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint32_t in_ECX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180220fbc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180220fc6;
    uVar5 = fcn.180221280(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
    uVar6 = uVar5;
    if (uVar5 != 0) {
        iVar2 = *(int32_t *)(uVar5 + 0x340);
        uVar3 = (int32_t)(in_ECX - 1 & ~in_ECX) >> 0x1f;
        *(uint32_t *)((int64_t)&arg_30h + iVar4) = uVar3;
        uVar6 = (uint64_t)*(uint32_t *)((int64_t)&arg_30h + iVar4);
        *(uint32_t *)((int64_t)&arg_30h + iVar4) = ~uVar3;
        puVar1 = (uint32_t *)(uVar5 + (int64_t)iVar2 * 4);
        *puVar1 = *puVar1 | *(uint32_t *)((int64_t)&arg_30h + iVar4) & 2;
    }
    return uVar6;
}

// ============================================================
// Function: FUN_180221010
// Address: 0x180221010
// Size: 75 bytes
// ============================================================
void fcn.180221010(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    int64_t iVar6;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined4 *puVar7;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18022101c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022102e;
    iVar3 = fcn.18028a240(*(int64_t *)((int64_t)aiStackX_10 + iVar2 + 8));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180221048;
        fcn.18028a2c0(*(int64_t *)((int64_t)aiStackX_10 + iVar2 + 8), *(int64_t *)((int64_t)aiStackX_10 + iVar2 + 0x10)
                      , *(int64_t *)(&stack0x00000028 + iVar2));
        uVar5 = *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + 8);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + 8) = unaff_RSI;
            *(undefined8 *)((int64_t)aiStackX_10 + iVar2) = 0x180220c64;
            iVar1 = fcn.18045a350();
            iVar1 = -iVar1;
            *(undefined8 *)(&stack0x00000048 + iVar1 + iVar2) = uVar5;
            *(undefined8 *)(&stack0x00000050 + iVar1 + iVar2) = unaff_RBP;
            puVar4 = (undefined8 *)(iVar3 + 0xc0);
            *(undefined8 *)(&stack0x00000058 + iVar1 + iVar2) = unaff_RDI;
            iVar6 = 0x10;
            *(undefined8 *)(&stack0x00000060 + iVar1 + iVar2) = unaff_R14;
            puVar7 = (undefined4 *)(iVar3 + 0x1c0);
            do {
                if ((*(uint8_t *)puVar7 & 1) != 0) {
                    uVar5 = *puVar4;
                    *(undefined8 *)((int64_t)aiStackX_10 + iVar1 + iVar2) = 0x180220cae;
                    fcn.180224990(uVar5, 0x1804bf6a0, 0x19);
                }
                *puVar4 = 0;
                puVar4[0x10] = 0;
                *puVar7 = 0;
                puVar7[-0x60] = 0;
                puVar7[-0x70] = 0;
                puVar7[-0x50] = 0;
                puVar7[0x30] = 0xffffffff;
                uVar5 = puVar4[0x28];
                *(undefined8 *)((int64_t)aiStackX_10 + iVar1 + iVar2) = 0x180220cf3;
                fcn.180224990(uVar5, 0x1804bf6a0, 0x5b);
                uVar5 = puVar4[0x40];
                puVar4[0x28] = 0;
                *(undefined8 *)((int64_t)aiStackX_10 + iVar1 + iVar2) = 0x180220d13;
                fcn.180224990(uVar5, 0x1804bf6a0, 0x5d);
                puVar4[0x40] = 0;
                puVar7 = puVar7 + 1;
                puVar4 = puVar4 + 1;
                iVar6 = iVar6 + -1;
            } while (iVar6 != 0);
            *(undefined8 *)((int64_t)aiStackX_10 + iVar1 + iVar2) = 0x180220d55;
            fcn.180224990(iVar3, 0x1804bf6f0, 0xcf);
        }
        return;
    }
    return;
}

// ============================================================
// Function: FUN_180221060
// Address: 0x180221060
// Size: 95 bytes
// ============================================================
undefined8 fcn.180221060(int32_t *param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x18022106c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022107e;
    uVar3 = fcn.180222950(*(undefined8 *)0x18077e318);
    if ((int32_t)uVar3 != 0) {
        iVar1 = *param_1;
        while (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18022109f;
            fcn.180228fb0(*(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000038 + iVar2));
            param_1 = param_1 + 4;
            iVar1 = *param_1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802210b4;
        fcn.180222910(*(undefined8 *)0x18077e318);
        return 1;
    }
    return uVar3;
}

// ============================================================
// Function: FUN_1802210c0
// Address: 0x1802210c0
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1802210c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    int64_t iVar5;
    undefined4 in_R8D;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802210d9;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1802210ed;
    iVar3 = fcn.180221280(*(int64_t *)((int64_t)&iStackX_8 + iVar2));
    iVar4 = iVar3;
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18022110c;
        fcn.180220f00(*(int64_t *)((int64_t)&iStackX_8 + iVar2));
        iVar5 = (int64_t)*(int32_t *)(iVar3 + 0x340);
        if ((*(uint8_t *)(iVar3 + 0x1c0 + iVar5 * 4) & 1) != 0) {
            uVar1 = *(undefined8 *)(iVar3 + 0xc0 + iVar5 * 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x180221137;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x4e);
        }
        *(undefined8 *)(iVar3 + 0xc0 + iVar5 * 8) = in_RCX;
        iVar4 = 1;
        *(undefined8 *)(iVar3 + 0x140 + iVar5 * 8) = in_RDX;
        *(undefined4 *)(iVar3 + 0x1c0 + iVar5 * 4) = in_R8D;
    }
    return iVar4;
}

// ============================================================
// Function: FUN_180221102
// Address: 0x180221102
// Size: 86 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1802210c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    int64_t iVar5;
    undefined4 in_R8D;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802210d9;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1802210ed;
    iVar3 = fcn.180221280(*(int64_t *)((int64_t)&iStackX_8 + iVar2));
    iVar4 = iVar3;
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18022110c;
        fcn.180220f00(*(int64_t *)((int64_t)&iStackX_8 + iVar2));
        iVar5 = (int64_t)*(int32_t *)(iVar3 + 0x340);
        if ((*(uint8_t *)(iVar3 + 0x1c0 + iVar5 * 4) & 1) != 0) {
            uVar1 = *(undefined8 *)(iVar3 + 0xc0 + iVar5 * 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x180221137;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x4e);
        }
        *(undefined8 *)(iVar3 + 0xc0 + iVar5 * 8) = in_RCX;
        iVar4 = 1;
        *(undefined8 *)(iVar3 + 0x140 + iVar5 * 8) = in_RDX;
        *(undefined4 *)(iVar3 + 0x1c0 + iVar5 * 4) = in_R8D;
    }
    return iVar4;
}

// ============================================================
// Function: FUN_180221158
// Address: 0x180221158
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1802210c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    int64_t iVar5;
    undefined4 in_R8D;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802210d9;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1802210ed;
    iVar3 = fcn.180221280(*(int64_t *)((int64_t)&iStackX_8 + iVar2));
    iVar4 = iVar3;
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18022110c;
        fcn.180220f00(*(int64_t *)((int64_t)&iStackX_8 + iVar2));
        iVar5 = (int64_t)*(int32_t *)(iVar3 + 0x340);
        if ((*(uint8_t *)(iVar3 + 0x1c0 + iVar5 * 4) & 1) != 0) {
            uVar1 = *(undefined8 *)(iVar3 + 0xc0 + iVar5 * 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x180221137;
            fcn.180224990(uVar1, 0x1804bf6a0, 0x4e);
        }
        *(undefined8 *)(iVar3 + 0xc0 + iVar5 * 8) = in_RCX;
        iVar4 = 1;
        *(undefined8 *)(iVar3 + 0x140 + iVar5 * 8) = in_RDX;
        *(undefined4 *)(iVar3 + 0x1c0 + iVar5 * 4) = in_R8D;
    }
    return iVar4;
}

// ============================================================
// Function: FUN_180221170
// Address: 0x180221170
// Size: 127 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180221170(int64_t arg_28h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 *in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180221180;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022118c;
    uVar1 = (*(code *)0x699ff6)();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022119a;
    iVar2 = fcn.180243560(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802211ad;
        uVar4 = fcn.18028a240(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
        *in_RCX = uVar4;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802211c6;
        iVar2 = fcn.18028a2c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802211d2;
            (*(code *)0x69a006)(uVar1);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180221250
// Address: 0x180221250
// Size: 42 bytes
// ============================================================
void fcn.180221250(int64_t arg1)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    if (arg1 != -1) {
        uStack_8 = 0x180221260;
        iVar1 = fcn.18045a350();
        iVar1 = -iVar1;
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180221275;
        fcn.18028a2c0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1));
    }
    return;
}

// ============================================================
// Function: FUN_180221280
// Address: 0x180221280
// Size: 234 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180221280(int64_t arg_28h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t arg1;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180221290;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221299;
    uVar1 = (*(code *)0x699ff6)();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802212a7;
    iVar2 = fcn.180243560(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802212be;
        arg1 = fcn.18028a240(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
        if (arg1 != -1) {
            if (arg1 != 0) {
code_r0x00018022132d:
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221335;
                (*(code *)0x69a006)(uVar1);
                return arg1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802212e6;
            iVar2 = fcn.18028a2c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802212ef;
                arg1 = fcn.1802542f0();
                if (arg1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180221307;
                    iVar2 = fcn.18028c680(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar3));
                    if (iVar2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022131d;
                        iVar2 = fcn.18028a2c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar3));
                        if (iVar2 != 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022132d;
                            fcn.180243560(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar3), 
                                          *(int64_t *)(&stack0x00000030 + iVar3));
                            goto code_r0x00018022132d;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022134b;
                    fcn.180220c50(arg1, *(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3));
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18022135d;
                fcn.18028a2c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3));
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180221370
// Address: 0x180221370
// Size: 227 bytes
// ============================================================
undefined8 fcn.180221370(void)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int32_t *piVar4;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18022137a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180221390;
    iVar1 = fcn.180222870(*(int64_t *)((int64_t)&var_20h + iVar3));
    iVar2 = 0;
    if (iVar1 != 0) {
        iVar2 = *(int32_t *)0x18077e314;
    }
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RBX;
        piVar4 = (int32_t *)0x1804bedd0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802213be;
        iVar2 = fcn.180222950(*(undefined8 *)0x18077e318);
        if (iVar2 != 0) {
            do {
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802213df;
                fcn.180228fb0(*(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3));
                piVar4 = piVar4 + 4;
            } while (*piVar4 != 0);
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802213f4;
            fcn.180222910(*(undefined8 *)0x18077e318);
        }
        piVar4 = (int32_t *)0x18069fd90;
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180221407;
        iVar1 = fcn.180222950(*(undefined8 *)0x18077e318);
        iVar2 = *(int32_t *)0x18069fd90;
        if (iVar1 != 0) {
            while (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18022142f;
                fcn.180228fb0(*(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                              *(int64_t *)(&stack0x00000040 + iVar3));
                piVar4 = piVar4 + 4;
                iVar2 = *piVar4;
            }
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180221444;
            fcn.180222910(*(undefined8 *)0x18077e318);
        }
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180221460
// Address: 0x180221460
// Size: 46 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_220h because it doesn't fit into ProtoModel

void fcn.180221460(int64_t arg4, int64_t arg_28h, int64_t arg_38h, int64_t arg_50h, int64_t arg_90h, int64_t arg_190h,
                  int64_t arg_1a8h, int64_t arg_1b0h, int64_t arg_1b8h, int64_t arg_1c0h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    uint64_t in_RCX;
    int64_t iVar7;
    undefined8 in_RDX;
    uint32_t uVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 unaff_R12;
    uint32_t uVar9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    if (arg4 == 0) {
        return;
    }
    uStack_28 = 0x180221479;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_190h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4);
    *(undefined8 *)((int64_t)&arg_1c0h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_1b8h + iVar4) = unaff_RSI;
    uVar6 = (uint32_t)in_RCX;
    *(undefined8 *)((int64_t)&arg_1b0h + iVar4) = unaff_R12;
    uVar1 = (uint8_t)(in_RCX >> 0x17);
    *(undefined8 *)((int64_t)&arg_1a8h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = in_RDX;
    uVar9 = 2;
    if (-1 < (int32_t)uVar6) {
        uVar9 = (uint32_t)uVar1;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802214e6;
    iVar2 = fcn.180222870(*(int64_t *)(&stack0x00000000 + iVar4));
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e314;
    }
    if (iVar3 == 0) {
code_r0x000180221544:
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022155d;
        func_0x000180245f70((int64_t)&arg_50h + iVar4, 0x40, 0x1804bf708, uVar9);
        iVar5 = (int64_t)&arg_50h + iVar4;
    } else {
        if ((int32_t)uVar6 < 0) {
            uVar1 = 2;
        }
        *(uint32_t *)((int64_t)&arg_38h + iVar4) = (uint32_t)uVar1 << 0x17;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221512;
        iVar3 = func_0x000180222850(*(undefined8 *)0x18077e318);
        if (iVar3 == 0) goto code_r0x000180221544;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221527;
        iVar5 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&arg_38h + iVar4);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221536;
        fcn.180222910(*(undefined8 *)0x18077e318);
        if ((iVar5 == 0) || (iVar5 = *(int64_t *)(iVar5 + 8), iVar5 == 0)) goto code_r0x000180221544;
    }
    uVar8 = ((int32_t)uVar6 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar6;
    if ((int32_t)uVar6 < 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022158e;
        iVar3 = func_0x000180223be0(uVar8, (int64_t)&arg_90h + iVar4, 0x100);
        iVar7 = (int64_t)&arg_90h + iVar4;
        if (iVar3 == 0) {
            iVar7 = 0;
        }
        goto code_r0x000180221661;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802215b9;
    iVar2 = fcn.180222870(*(int64_t *)(&stack0x00000000 + iVar4));
    iVar7 = 0;
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e314;
    }
    if (iVar3 == 0) goto code_r0x000180221661;
    *(uint32_t *)((int64_t)&arg_28h + iVar4) = ((uint32_t)(in_RCX >> 0x17) & 0xff) << 0x17 | uVar6 & 0x7fffff;
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802215f2;
    iVar3 = func_0x000180222850(*(undefined8 *)0x18077e318);
    if (iVar3 == 0) {
code_r0x00018022161b:
        *(uint32_t *)((int64_t)&arg_28h + iVar4) = uVar6 & 0x7fffff;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022162b;
        iVar3 = func_0x000180222850();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221640;
            iVar7 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&arg_28h + iVar4);
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022164f;
            fcn.180222910();
            if (iVar7 != 0) goto code_r0x000180221654;
        }
        iVar7 = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221607;
        iVar7 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&arg_28h + iVar4);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221616;
        fcn.180222910(*(undefined8 *)0x18077e318);
        if (iVar7 == 0) goto code_r0x00018022161b;
code_r0x000180221654:
        iVar7 = *(int64_t *)(iVar7 + 8);
    }
    in_RDX = *(undefined8 *)((int64_t)&var_20h + iVar4);
code_r0x000180221661:
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221691;
        func_0x000180245f70((int64_t)&arg_90h + iVar4, 0x100, 0x1804bf718, uVar8 & 0xff83ffff);
        iVar7 = (int64_t)&arg_90h + iVar4;
    }
    *(int64_t *)((int64_t)&var_10h + iVar4) = iVar7;
    *(undefined8 *)((int64_t)&var_8h + iVar4) = in_RDX;
    *(int64_t *)(&stack0x00000000 + iVar4) = iVar5;
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802216bd;
    func_0x000180245f70(in_R8, arg4, 0x1804bf728, in_RCX & 0xffffffff);
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802216c5;
    iVar5 = func_0x000180498cd0(in_R8);
    if (iVar5 == arg4 + -1) {
        *(uint32_t *)((int64_t)&var_10h + iVar4) = uVar8;
        *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
        *(uint32_t *)(&stack0x00000000 + iVar4) = uVar9;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802216fd;
        func_0x000180245f70(in_R8, arg4, 0x1804bf740, in_RCX & 0xffffffff);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022171d;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_190h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4));
    return;
}

// ============================================================
// Function: FUN_18022148e
// Address: 0x18022148e
// Size: 11 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_220h because it doesn't fit into ProtoModel

void fcn.180221460(int64_t arg4, int64_t arg_28h, int64_t arg_38h, int64_t arg_50h, int64_t arg_90h, int64_t arg_190h,
                  int64_t arg_1a8h, int64_t arg_1b0h, int64_t arg_1b8h, int64_t arg_1c0h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    uint64_t in_RCX;
    int64_t iVar7;
    undefined8 in_RDX;
    uint32_t uVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 unaff_R12;
    uint32_t uVar9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    if (arg4 == 0) {
        return;
    }
    uStack_28 = 0x180221479;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_190h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4);
    *(undefined8 *)((int64_t)&arg_1c0h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_1b8h + iVar4) = unaff_RSI;
    uVar6 = (uint32_t)in_RCX;
    *(undefined8 *)((int64_t)&arg_1b0h + iVar4) = unaff_R12;
    uVar1 = (uint8_t)(in_RCX >> 0x17);
    *(undefined8 *)((int64_t)&arg_1a8h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = in_RDX;
    uVar9 = 2;
    if (-1 < (int32_t)uVar6) {
        uVar9 = (uint32_t)uVar1;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802214e6;
    iVar2 = fcn.180222870(*(int64_t *)(&stack0x00000000 + iVar4));
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e314;
    }
    if (iVar3 == 0) {
code_r0x000180221544:
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022155d;
        func_0x000180245f70((int64_t)&arg_50h + iVar4, 0x40, 0x1804bf708, uVar9);
        iVar5 = (int64_t)&arg_50h + iVar4;
    } else {
        if ((int32_t)uVar6 < 0) {
            uVar1 = 2;
        }
        *(uint32_t *)((int64_t)&arg_38h + iVar4) = (uint32_t)uVar1 << 0x17;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221512;
        iVar3 = func_0x000180222850(*(undefined8 *)0x18077e318);
        if (iVar3 == 0) goto code_r0x000180221544;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221527;
        iVar5 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&arg_38h + iVar4);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221536;
        fcn.180222910(*(undefined8 *)0x18077e318);
        if ((iVar5 == 0) || (iVar5 = *(int64_t *)(iVar5 + 8), iVar5 == 0)) goto code_r0x000180221544;
    }
    uVar8 = ((int32_t)uVar6 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar6;
    if ((int32_t)uVar6 < 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022158e;
        iVar3 = func_0x000180223be0(uVar8, (int64_t)&arg_90h + iVar4, 0x100);
        iVar7 = (int64_t)&arg_90h + iVar4;
        if (iVar3 == 0) {
            iVar7 = 0;
        }
        goto code_r0x000180221661;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802215b9;
    iVar2 = fcn.180222870(*(int64_t *)(&stack0x00000000 + iVar4));
    iVar7 = 0;
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e314;
    }
    if (iVar3 == 0) goto code_r0x000180221661;
    *(uint32_t *)((int64_t)&arg_28h + iVar4) = ((uint32_t)(in_RCX >> 0x17) & 0xff) << 0x17 | uVar6 & 0x7fffff;
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802215f2;
    iVar3 = func_0x000180222850(*(undefined8 *)0x18077e318);
    if (iVar3 == 0) {
code_r0x00018022161b:
        *(uint32_t *)((int64_t)&arg_28h + iVar4) = uVar6 & 0x7fffff;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022162b;
        iVar3 = func_0x000180222850();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221640;
            iVar7 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&arg_28h + iVar4);
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022164f;
            fcn.180222910();
            if (iVar7 != 0) goto code_r0x000180221654;
        }
        iVar7 = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221607;
        iVar7 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&arg_28h + iVar4);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221616;
        fcn.180222910(*(undefined8 *)0x18077e318);
        if (iVar7 == 0) goto code_r0x00018022161b;
code_r0x000180221654:
        iVar7 = *(int64_t *)(iVar7 + 8);
    }
    in_RDX = *(undefined8 *)((int64_t)&var_20h + iVar4);
code_r0x000180221661:
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221691;
        func_0x000180245f70((int64_t)&arg_90h + iVar4, 0x100, 0x1804bf718, uVar8 & 0xff83ffff);
        iVar7 = (int64_t)&arg_90h + iVar4;
    }
    *(int64_t *)((int64_t)&var_10h + iVar4) = iVar7;
    *(undefined8 *)((int64_t)&var_8h + iVar4) = in_RDX;
    *(int64_t *)(&stack0x00000000 + iVar4) = iVar5;
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802216bd;
    func_0x000180245f70(in_R8, arg4, 0x1804bf728, in_RCX & 0xffffffff);
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802216c5;
    iVar5 = func_0x000180498cd0(in_R8);
    if (iVar5 == arg4 + -1) {
        *(uint32_t *)((int64_t)&var_10h + iVar4) = uVar8;
        *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
        *(uint32_t *)(&stack0x00000000 + iVar4) = uVar9;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802216fd;
        func_0x000180245f70(in_R8, arg4, 0x1804bf740, in_RCX & 0xffffffff);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022171d;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_190h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4));
    return;
}

// ============================================================
// Function: FUN_180221499
// Address: 0x180221499
// Size: 469 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_220h because it doesn't fit into ProtoModel

void fcn.180221460(int64_t arg4, int64_t arg_28h, int64_t arg_38h, int64_t arg_50h, int64_t arg_90h, int64_t arg_190h,
                  int64_t arg_1a8h, int64_t arg_1b0h, int64_t arg_1b8h, int64_t arg_1c0h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    uint64_t in_RCX;
    int64_t iVar7;
    undefined8 in_RDX;
    uint32_t uVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 unaff_R12;
    uint32_t uVar9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    if (arg4 == 0) {
        return;
    }
    uStack_28 = 0x180221479;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_190h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4);
    *(undefined8 *)((int64_t)&arg_1c0h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_1b8h + iVar4) = unaff_RSI;
    uVar6 = (uint32_t)in_RCX;
    *(undefined8 *)((int64_t)&arg_1b0h + iVar4) = unaff_R12;
    uVar1 = (uint8_t)(in_RCX >> 0x17);
    *(undefined8 *)((int64_t)&arg_1a8h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = in_RDX;
    uVar9 = 2;
    if (-1 < (int32_t)uVar6) {
        uVar9 = (uint32_t)uVar1;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802214e6;
    iVar2 = fcn.180222870(*(int64_t *)(&stack0x00000000 + iVar4));
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e314;
    }
    if (iVar3 == 0) {
code_r0x000180221544:
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022155d;
        func_0x000180245f70((int64_t)&arg_50h + iVar4, 0x40, 0x1804bf708, uVar9);
        iVar5 = (int64_t)&arg_50h + iVar4;
    } else {
        if ((int32_t)uVar6 < 0) {
            uVar1 = 2;
        }
        *(uint32_t *)((int64_t)&arg_38h + iVar4) = (uint32_t)uVar1 << 0x17;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221512;
        iVar3 = func_0x000180222850(*(undefined8 *)0x18077e318);
        if (iVar3 == 0) goto code_r0x000180221544;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221527;
        iVar5 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&arg_38h + iVar4);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221536;
        fcn.180222910(*(undefined8 *)0x18077e318);
        if ((iVar5 == 0) || (iVar5 = *(int64_t *)(iVar5 + 8), iVar5 == 0)) goto code_r0x000180221544;
    }
    uVar8 = ((int32_t)uVar6 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar6;
    if ((int32_t)uVar6 < 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022158e;
        iVar3 = func_0x000180223be0(uVar8, (int64_t)&arg_90h + iVar4, 0x100);
        iVar7 = (int64_t)&arg_90h + iVar4;
        if (iVar3 == 0) {
            iVar7 = 0;
        }
        goto code_r0x000180221661;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802215b9;
    iVar2 = fcn.180222870(*(int64_t *)(&stack0x00000000 + iVar4));
    iVar7 = 0;
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e314;
    }
    if (iVar3 == 0) goto code_r0x000180221661;
    *(uint32_t *)((int64_t)&arg_28h + iVar4) = ((uint32_t)(in_RCX >> 0x17) & 0xff) << 0x17 | uVar6 & 0x7fffff;
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802215f2;
    iVar3 = func_0x000180222850(*(undefined8 *)0x18077e318);
    if (iVar3 == 0) {
code_r0x00018022161b:
        *(uint32_t *)((int64_t)&arg_28h + iVar4) = uVar6 & 0x7fffff;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022162b;
        iVar3 = func_0x000180222850();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221640;
            iVar7 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&arg_28h + iVar4);
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022164f;
            fcn.180222910();
            if (iVar7 != 0) goto code_r0x000180221654;
        }
        iVar7 = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221607;
        iVar7 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&arg_28h + iVar4);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221616;
        fcn.180222910(*(undefined8 *)0x18077e318);
        if (iVar7 == 0) goto code_r0x00018022161b;
code_r0x000180221654:
        iVar7 = *(int64_t *)(iVar7 + 8);
    }
    in_RDX = *(undefined8 *)((int64_t)&var_20h + iVar4);
code_r0x000180221661:
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221691;
        func_0x000180245f70((int64_t)&arg_90h + iVar4, 0x100, 0x1804bf718, uVar8 & 0xff83ffff);
        iVar7 = (int64_t)&arg_90h + iVar4;
    }
    *(int64_t *)((int64_t)&var_10h + iVar4) = iVar7;
    *(undefined8 *)((int64_t)&var_8h + iVar4) = in_RDX;
    *(int64_t *)(&stack0x00000000 + iVar4) = iVar5;
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802216bd;
    func_0x000180245f70(in_R8, arg4, 0x1804bf728, in_RCX & 0xffffffff);
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802216c5;
    iVar5 = func_0x000180498cd0(in_R8);
    if (iVar5 == arg4 + -1) {
        *(uint32_t *)((int64_t)&var_10h + iVar4) = uVar8;
        *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
        *(uint32_t *)(&stack0x00000000 + iVar4) = uVar9;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802216fd;
        func_0x000180245f70(in_R8, arg4, 0x1804bf740, in_RCX & 0xffffffff);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022171d;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_190h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4));
    return;
}

// ============================================================
// Function: FUN_18022166e
// Address: 0x18022166e
// Size: 104 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_220h because it doesn't fit into ProtoModel

void fcn.180221460(int64_t arg4, int64_t arg_28h, int64_t arg_38h, int64_t arg_50h, int64_t arg_90h, int64_t arg_190h,
                  int64_t arg_1a8h, int64_t arg_1b0h, int64_t arg_1b8h, int64_t arg_1c0h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    uint64_t in_RCX;
    int64_t iVar7;
    undefined8 in_RDX;
    uint32_t uVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 unaff_R12;
    uint32_t uVar9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    if (arg4 == 0) {
        return;
    }
    uStack_28 = 0x180221479;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_190h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4);
    *(undefined8 *)((int64_t)&arg_1c0h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_1b8h + iVar4) = unaff_RSI;
    uVar6 = (uint32_t)in_RCX;
    *(undefined8 *)((int64_t)&arg_1b0h + iVar4) = unaff_R12;
    uVar1 = (uint8_t)(in_RCX >> 0x17);
    *(undefined8 *)((int64_t)&arg_1a8h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = in_RDX;
    uVar9 = 2;
    if (-1 < (int32_t)uVar6) {
        uVar9 = (uint32_t)uVar1;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802214e6;
    iVar2 = fcn.180222870(*(int64_t *)(&stack0x00000000 + iVar4));
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e314;
    }
    if (iVar3 == 0) {
code_r0x000180221544:
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022155d;
        func_0x000180245f70((int64_t)&arg_50h + iVar4, 0x40, 0x1804bf708, uVar9);
        iVar5 = (int64_t)&arg_50h + iVar4;
    } else {
        if ((int32_t)uVar6 < 0) {
            uVar1 = 2;
        }
        *(uint32_t *)((int64_t)&arg_38h + iVar4) = (uint32_t)uVar1 << 0x17;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221512;
        iVar3 = func_0x000180222850(*(undefined8 *)0x18077e318);
        if (iVar3 == 0) goto code_r0x000180221544;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221527;
        iVar5 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&arg_38h + iVar4);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221536;
        fcn.180222910(*(undefined8 *)0x18077e318);
        if ((iVar5 == 0) || (iVar5 = *(int64_t *)(iVar5 + 8), iVar5 == 0)) goto code_r0x000180221544;
    }
    uVar8 = ((int32_t)uVar6 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar6;
    if ((int32_t)uVar6 < 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022158e;
        iVar3 = func_0x000180223be0(uVar8, (int64_t)&arg_90h + iVar4, 0x100);
        iVar7 = (int64_t)&arg_90h + iVar4;
        if (iVar3 == 0) {
            iVar7 = 0;
        }
        goto code_r0x000180221661;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802215b9;
    iVar2 = fcn.180222870(*(int64_t *)(&stack0x00000000 + iVar4));
    iVar7 = 0;
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e314;
    }
    if (iVar3 == 0) goto code_r0x000180221661;
    *(uint32_t *)((int64_t)&arg_28h + iVar4) = ((uint32_t)(in_RCX >> 0x17) & 0xff) << 0x17 | uVar6 & 0x7fffff;
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802215f2;
    iVar3 = func_0x000180222850(*(undefined8 *)0x18077e318);
    if (iVar3 == 0) {
code_r0x00018022161b:
        *(uint32_t *)((int64_t)&arg_28h + iVar4) = uVar6 & 0x7fffff;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022162b;
        iVar3 = func_0x000180222850();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221640;
            iVar7 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&arg_28h + iVar4);
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022164f;
            fcn.180222910();
            if (iVar7 != 0) goto code_r0x000180221654;
        }
        iVar7 = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221607;
        iVar7 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&arg_28h + iVar4);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221616;
        fcn.180222910(*(undefined8 *)0x18077e318);
        if (iVar7 == 0) goto code_r0x00018022161b;
code_r0x000180221654:
        iVar7 = *(int64_t *)(iVar7 + 8);
    }
    in_RDX = *(undefined8 *)((int64_t)&var_20h + iVar4);
code_r0x000180221661:
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221691;
        func_0x000180245f70((int64_t)&arg_90h + iVar4, 0x100, 0x1804bf718, uVar8 & 0xff83ffff);
        iVar7 = (int64_t)&arg_90h + iVar4;
    }
    *(int64_t *)((int64_t)&var_10h + iVar4) = iVar7;
    *(undefined8 *)((int64_t)&var_8h + iVar4) = in_RDX;
    *(int64_t *)(&stack0x00000000 + iVar4) = iVar5;
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802216bd;
    func_0x000180245f70(in_R8, arg4, 0x1804bf728, in_RCX & 0xffffffff);
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802216c5;
    iVar5 = func_0x000180498cd0(in_R8);
    if (iVar5 == arg4 + -1) {
        *(uint32_t *)((int64_t)&var_10h + iVar4) = uVar8;
        *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
        *(uint32_t *)(&stack0x00000000 + iVar4) = uVar9;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802216fd;
        func_0x000180245f70(in_R8, arg4, 0x1804bf740, in_RCX & 0xffffffff);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022171d;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_190h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1802216d6
// Address: 0x1802216d6
// Size: 84 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_220h because it doesn't fit into ProtoModel

void fcn.180221460(int64_t arg4, int64_t arg_28h, int64_t arg_38h, int64_t arg_50h, int64_t arg_90h, int64_t arg_190h,
                  int64_t arg_1a8h, int64_t arg_1b0h, int64_t arg_1b8h, int64_t arg_1c0h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    uint64_t in_RCX;
    int64_t iVar7;
    undefined8 in_RDX;
    uint32_t uVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 unaff_R12;
    uint32_t uVar9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    if (arg4 == 0) {
        return;
    }
    uStack_28 = 0x180221479;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_190h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4);
    *(undefined8 *)((int64_t)&arg_1c0h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_1b8h + iVar4) = unaff_RSI;
    uVar6 = (uint32_t)in_RCX;
    *(undefined8 *)((int64_t)&arg_1b0h + iVar4) = unaff_R12;
    uVar1 = (uint8_t)(in_RCX >> 0x17);
    *(undefined8 *)((int64_t)&arg_1a8h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = in_RDX;
    uVar9 = 2;
    if (-1 < (int32_t)uVar6) {
        uVar9 = (uint32_t)uVar1;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802214e6;
    iVar2 = fcn.180222870(*(int64_t *)(&stack0x00000000 + iVar4));
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e314;
    }
    if (iVar3 == 0) {
code_r0x000180221544:
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022155d;
        func_0x000180245f70((int64_t)&arg_50h + iVar4, 0x40, 0x1804bf708, uVar9);
        iVar5 = (int64_t)&arg_50h + iVar4;
    } else {
        if ((int32_t)uVar6 < 0) {
            uVar1 = 2;
        }
        *(uint32_t *)((int64_t)&arg_38h + iVar4) = (uint32_t)uVar1 << 0x17;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221512;
        iVar3 = func_0x000180222850(*(undefined8 *)0x18077e318);
        if (iVar3 == 0) goto code_r0x000180221544;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221527;
        iVar5 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&arg_38h + iVar4);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221536;
        fcn.180222910(*(undefined8 *)0x18077e318);
        if ((iVar5 == 0) || (iVar5 = *(int64_t *)(iVar5 + 8), iVar5 == 0)) goto code_r0x000180221544;
    }
    uVar8 = ((int32_t)uVar6 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar6;
    if ((int32_t)uVar6 < 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022158e;
        iVar3 = func_0x000180223be0(uVar8, (int64_t)&arg_90h + iVar4, 0x100);
        iVar7 = (int64_t)&arg_90h + iVar4;
        if (iVar3 == 0) {
            iVar7 = 0;
        }
        goto code_r0x000180221661;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802215b9;
    iVar2 = fcn.180222870(*(int64_t *)(&stack0x00000000 + iVar4));
    iVar7 = 0;
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e314;
    }
    if (iVar3 == 0) goto code_r0x000180221661;
    *(uint32_t *)((int64_t)&arg_28h + iVar4) = ((uint32_t)(in_RCX >> 0x17) & 0xff) << 0x17 | uVar6 & 0x7fffff;
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802215f2;
    iVar3 = func_0x000180222850(*(undefined8 *)0x18077e318);
    if (iVar3 == 0) {
code_r0x00018022161b:
        *(uint32_t *)((int64_t)&arg_28h + iVar4) = uVar6 & 0x7fffff;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022162b;
        iVar3 = func_0x000180222850();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221640;
            iVar7 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&arg_28h + iVar4);
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022164f;
            fcn.180222910();
            if (iVar7 != 0) goto code_r0x000180221654;
        }
        iVar7 = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221607;
        iVar7 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&arg_28h + iVar4);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221616;
        fcn.180222910(*(undefined8 *)0x18077e318);
        if (iVar7 == 0) goto code_r0x00018022161b;
code_r0x000180221654:
        iVar7 = *(int64_t *)(iVar7 + 8);
    }
    in_RDX = *(undefined8 *)((int64_t)&var_20h + iVar4);
code_r0x000180221661:
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221691;
        func_0x000180245f70((int64_t)&arg_90h + iVar4, 0x100, 0x1804bf718, uVar8 & 0xff83ffff);
        iVar7 = (int64_t)&arg_90h + iVar4;
    }
    *(int64_t *)((int64_t)&var_10h + iVar4) = iVar7;
    *(undefined8 *)((int64_t)&var_8h + iVar4) = in_RDX;
    *(int64_t *)(&stack0x00000000 + iVar4) = iVar5;
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802216bd;
    func_0x000180245f70(in_R8, arg4, 0x1804bf728, in_RCX & 0xffffffff);
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802216c5;
    iVar5 = func_0x000180498cd0(in_R8);
    if (iVar5 == arg4 + -1) {
        *(uint32_t *)((int64_t)&var_10h + iVar4) = uVar8;
        *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
        *(uint32_t *)(&stack0x00000000 + iVar4) = uVar9;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802216fd;
        func_0x000180245f70(in_R8, arg4, 0x1804bf740, in_RCX & 0xffffffff);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022171d;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_190h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4));
    return;
}

// ============================================================
// Function: FUN_18022172a
// Address: 0x18022172a
// Size: 1 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_220h because it doesn't fit into ProtoModel

void fcn.180221460(int64_t arg4, int64_t arg_28h, int64_t arg_38h, int64_t arg_50h, int64_t arg_90h, int64_t arg_190h,
                  int64_t arg_1a8h, int64_t arg_1b0h, int64_t arg_1b8h, int64_t arg_1c0h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    uint64_t in_RCX;
    int64_t iVar7;
    undefined8 in_RDX;
    uint32_t uVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 unaff_R12;
    uint32_t uVar9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    if (arg4 == 0) {
        return;
    }
    uStack_28 = 0x180221479;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_190h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4);
    *(undefined8 *)((int64_t)&arg_1c0h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_1b8h + iVar4) = unaff_RSI;
    uVar6 = (uint32_t)in_RCX;
    *(undefined8 *)((int64_t)&arg_1b0h + iVar4) = unaff_R12;
    uVar1 = (uint8_t)(in_RCX >> 0x17);
    *(undefined8 *)((int64_t)&arg_1a8h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = in_RDX;
    uVar9 = 2;
    if (-1 < (int32_t)uVar6) {
        uVar9 = (uint32_t)uVar1;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802214e6;
    iVar2 = fcn.180222870(*(int64_t *)(&stack0x00000000 + iVar4));
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e314;
    }
    if (iVar3 == 0) {
code_r0x000180221544:
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022155d;
        func_0x000180245f70((int64_t)&arg_50h + iVar4, 0x40, 0x1804bf708, uVar9);
        iVar5 = (int64_t)&arg_50h + iVar4;
    } else {
        if ((int32_t)uVar6 < 0) {
            uVar1 = 2;
        }
        *(uint32_t *)((int64_t)&arg_38h + iVar4) = (uint32_t)uVar1 << 0x17;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221512;
        iVar3 = func_0x000180222850(*(undefined8 *)0x18077e318);
        if (iVar3 == 0) goto code_r0x000180221544;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221527;
        iVar5 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&arg_38h + iVar4);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221536;
        fcn.180222910(*(undefined8 *)0x18077e318);
        if ((iVar5 == 0) || (iVar5 = *(int64_t *)(iVar5 + 8), iVar5 == 0)) goto code_r0x000180221544;
    }
    uVar8 = ((int32_t)uVar6 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar6;
    if ((int32_t)uVar6 < 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022158e;
        iVar3 = func_0x000180223be0(uVar8, (int64_t)&arg_90h + iVar4, 0x100);
        iVar7 = (int64_t)&arg_90h + iVar4;
        if (iVar3 == 0) {
            iVar7 = 0;
        }
        goto code_r0x000180221661;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802215b9;
    iVar2 = fcn.180222870(*(int64_t *)(&stack0x00000000 + iVar4));
    iVar7 = 0;
    iVar3 = 0;
    if (iVar2 != 0) {
        iVar3 = *(int32_t *)0x18077e314;
    }
    if (iVar3 == 0) goto code_r0x000180221661;
    *(uint32_t *)((int64_t)&arg_28h + iVar4) = ((uint32_t)(in_RCX >> 0x17) & 0xff) << 0x17 | uVar6 & 0x7fffff;
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802215f2;
    iVar3 = func_0x000180222850(*(undefined8 *)0x18077e318);
    if (iVar3 == 0) {
code_r0x00018022161b:
        *(uint32_t *)((int64_t)&arg_28h + iVar4) = uVar6 & 0x7fffff;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022162b;
        iVar3 = func_0x000180222850();
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221640;
            iVar7 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&arg_28h + iVar4);
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022164f;
            fcn.180222910();
            if (iVar7 != 0) goto code_r0x000180221654;
        }
        iVar7 = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221607;
        iVar7 = func_0x000180229240(*(undefined8 *)0x18077e320, (int64_t)&arg_28h + iVar4);
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221616;
        fcn.180222910(*(undefined8 *)0x18077e318);
        if (iVar7 == 0) goto code_r0x00018022161b;
code_r0x000180221654:
        iVar7 = *(int64_t *)(iVar7 + 8);
    }
    in_RDX = *(undefined8 *)((int64_t)&var_20h + iVar4);
code_r0x000180221661:
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180221691;
        func_0x000180245f70((int64_t)&arg_90h + iVar4, 0x100, 0x1804bf718, uVar8 & 0xff83ffff);
        iVar7 = (int64_t)&arg_90h + iVar4;
    }
    *(int64_t *)((int64_t)&var_10h + iVar4) = iVar7;
    *(undefined8 *)((int64_t)&var_8h + iVar4) = in_RDX;
    *(int64_t *)(&stack0x00000000 + iVar4) = iVar5;
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802216bd;
    func_0x000180245f70(in_R8, arg4, 0x1804bf728, in_RCX & 0xffffffff);
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802216c5;
    iVar5 = func_0x000180498cd0(in_R8);
    if (iVar5 == arg4 + -1) {
        *(uint32_t *)((int64_t)&var_10h + iVar4) = uVar8;
        *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
        *(uint32_t *)(&stack0x00000000 + iVar4) = uVar9;
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802216fd;
        func_0x000180245f70(in_R8, arg4, 0x1804bf740, in_RCX & 0xffffffff);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x18022171d;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_190h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4));
    return;
}

// ============================================================
// Function: FUN_180221730
// Address: 0x180221730
// Size: 347 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int32_t * fcn.180221730(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    int64_t iVar7;
    int32_t *in_RCX;
    code *in_RDX;
    uint64_t uVar8;
    uint32_t uVar9;
    uint64_t uVar10;
    code *in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18022174e;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180221771;
    piVar6 = (int32_t *)fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
    if (piVar6 == (int32_t *)0x0) {
code_r0x000180221870:
        piVar6 = (int32_t *)0x0;
    } else {
        uVar8 = 0;
        if (in_RCX == (int32_t *)0x0) {
            *piVar6 = 0;
            piVar6[4] = 0;
            *(undefined8 *)(piVar6 + 6) = 0;
        } else {
            iVar4 = in_RCX[1];
            iVar3 = in_RCX[2];
            iVar2 = in_RCX[3];
            *piVar6 = *in_RCX;
            piVar6[1] = iVar4;
            piVar6[2] = iVar3;
            piVar6[3] = iVar2;
            iVar4 = in_RCX[5];
            iVar3 = in_RCX[6];
            iVar2 = in_RCX[7];
            piVar6[4] = in_RCX[4];
            piVar6[5] = iVar4;
            piVar6[6] = iVar3;
            piVar6[7] = iVar2;
            *(undefined8 *)(piVar6 + 8) = *(undefined8 *)(in_RCX + 8);
            iVar4 = *in_RCX;
            if (iVar4 != 0) {
                iVar3 = 4;
                if (4 < iVar4) {
                    iVar3 = iVar4;
                }
                piVar6[5] = iVar3;
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1802217e2;
                iVar7 = fcn.180224e40(*(int64_t *)((int64_t)&var_8h + iVar5));
                *(int64_t *)(piVar6 + 2) = iVar7;
                if (iVar7 != 0) {
                    uVar10 = uVar8;
                    if (*piVar6 < 1) {
                        return piVar6;
                    }
                    do {
                        if (*(int64_t *)(uVar8 + *(int64_t *)(in_RCX + 2)) != 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180221802;
                            iVar7 = (*in_RDX)();
                            *(int64_t *)(uVar8 + *(int64_t *)(piVar6 + 2)) = iVar7;
                            if (iVar7 == 0) {
                                iVar4 = (int32_t)uVar10 + -1;
                                iVar7 = (int64_t)iVar4;
                                if (-1 < iVar4) {
                                    do {
                                        if (*(int64_t *)(*(int64_t *)(piVar6 + 2) + iVar7 * 8) != 0) {
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18022183f;
                                            (*in_R8)();
                                        }
                                        iVar7 = iVar7 + -1;
                                    } while (-1 < iVar7);
                                }
                                break;
                            }
                        }
                        uVar9 = (int32_t)uVar10 + 1;
                        uVar8 = uVar8 + 8;
                        uVar10 = (uint64_t)uVar9;
                        if (*piVar6 <= (int32_t)uVar9) {
                            return piVar6;
                        }
                    } while( true );
                }
                uVar1 = *(undefined8 *)(piVar6 + 2);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18022185b;
                fcn.180224990(uVar1, 0x1804bf768, 0x1ce);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180221870;
                fcn.180224990(piVar6, 0x1804bf768, 0x1cf);
                goto code_r0x000180221870;
            }
        }
        *(undefined8 *)(piVar6 + 2) = 0;
        piVar6[5] = 0;
    }
    return piVar6;
}

// ============================================================
// Function: FUN_180221890
// Address: 0x180221890
// Size: 42 bytes
// ============================================================
undefined8 fcn.180221890(int64_t arg_30h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *in_RCX;
    uint32_t in_EDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (((in_RCX != (int32_t *)0x0) && (-1 < (int32_t)in_EDX)) && ((int32_t)in_EDX < *in_RCX)) {
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x180222580;
        iVar5 = fcn.18045a350();
        iVar2 = *(int64_t *)(in_RCX + 2);
        uVar3 = *(undefined8 *)(iVar2 + (int64_t)(int32_t)in_EDX * 8);
        iVar1 = *in_RCX;
        if (in_EDX != iVar1 - 1U) {
            *(undefined8 *)((int64_t)auStackX_18 + (iVar4 - iVar5)) = 0x1802225be;
            fcn.180498030(iVar2 + (int64_t)(int32_t)in_EDX * 8, iVar2 + (int64_t)(int32_t)(in_EDX + 1) * 8, 
                          (int64_t)(int32_t)(~in_EDX + iVar1) << 3);
        }
        *in_RCX = *in_RCX + -1;
        return uVar3;
    }
    return 0;
}

// ============================================================
// Function: FUN_1802218c0
// Address: 0x1802218c0
// Size: 131 bytes
// ============================================================
int64_t fcn.1802218c0(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t *piVar6;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802218cc;
    iVar5 = fcn.18045a350();
    if (in_RCX != (int32_t *)0x0) {
        iVar1 = *in_RCX;
        uVar4 = 0;
        if (0 < iVar1) {
            piVar2 = *(int64_t **)(in_RCX + 2);
            piVar6 = piVar2;
            do {
                if (*piVar6 == in_RDX) {
                    *(undefined8 *)((int64_t)&arg_28h + -iVar5) = unaff_RDI;
                    iVar3 = piVar2[(int32_t)uVar4];
                    if (uVar4 != iVar1 - 1U) {
                        *(undefined8 *)((int64_t)&uStack_10 + -iVar5) = 0x180221933;
                        fcn.180498030(piVar2 + (int32_t)uVar4, piVar2 + (int32_t)(uVar4 + 1), 
                                      (int64_t)(int32_t)(~uVar4 + iVar1) << 3);
                    }
                    *in_RCX = *in_RCX + -1;
                    return iVar3;
                }
                uVar4 = uVar4 + 1;
                piVar6 = piVar6 + 1;
            } while ((int32_t)uVar4 < iVar1);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180221950
// Address: 0x180221950
// Size: 243 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int32_t * fcn.180221950(int64_t arg_28h)
{
    int32_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    int64_t iVar7;
    int32_t *in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180221960;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18022197d;
    piVar6 = (int32_t *)
             fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
    if (piVar6 == (int32_t *)0x0) {
        return (int32_t *)0x0;
    }
    if (in_RCX == (int32_t *)0x0) {
        *piVar6 = 0;
        piVar6[4] = 0;
        *(undefined8 *)(piVar6 + 6) = 0;
    } else {
        iVar1 = in_RCX[1];
        iVar3 = in_RCX[2];
        iVar4 = in_RCX[3];
        *piVar6 = *in_RCX;
        piVar6[1] = iVar1;
        piVar6[2] = iVar3;
        piVar6[3] = iVar4;
        iVar1 = in_RCX[5];
        iVar3 = in_RCX[6];
        iVar4 = in_RCX[7];
        piVar6[4] = in_RCX[4];
        piVar6[5] = iVar1;
        piVar6[6] = iVar3;
        piVar6[7] = iVar4;
        *(undefined8 *)(piVar6 + 8) = *(undefined8 *)(in_RCX + 8);
        if (*in_RCX != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802219e5;
            iVar7 = fcn.180224ed0(*(int64_t *)((int64_t)aiStackX_18 + iVar5));
            *(int64_t *)(piVar6 + 2) = iVar7;
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180221a03;
                fcn.180224990(0, 0x1804bf768, 0x1ce);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180221a18;
                fcn.180224990(piVar6, 0x1804bf768, 0x1cf);
                return (int32_t *)0x0;
            }
            iVar1 = *in_RCX;
            uVar2 = *(undefined8 *)(in_RCX + 2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180221a35;
            fcn.180498030(iVar7, uVar2, (int64_t)iVar1 << 3);
            return piVar6;
        }
    }
    *(undefined8 *)(piVar6 + 2) = 0;
    piVar6[5] = 0;
    return piVar6;
}

// ============================================================
// Function: FUN_180221a50
// Address: 0x180221a50
// Size: 48 bytes
// ============================================================
uint64_t fcn.180221a50(int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int32_t *in_RCX;
    uint64_t uVar6;
    int64_t in_RDX;
    uint32_t uVar7;
    undefined8 unaff_RBX;
    uint64_t uVar8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180221a5c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(int64_t *)((int64_t)&arg_38h + iVar4) = in_RDX;
    if (in_RCX != (int32_t *)0x0) {
        iVar3 = *in_RCX;
        if (iVar3 != 0) {
            iVar1 = *(int64_t *)(in_RCX + 6);
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBX;
            if (iVar1 == 0) {
                uVar6 = 0;
                if (0 < iVar3) {
                    piVar5 = *(int64_t **)(in_RCX + 2);
                    uVar8 = uVar6;
                    do {
                        if (*piVar5 == in_RDX) {
                            return uVar8;
                        }
                        uVar8 = (uint64_t)((int32_t)uVar8 + 1);
                        uVar6 = uVar6 + 1;
                        piVar5 = piVar5 + 1;
                    } while ((int64_t)uVar6 < (int64_t)iVar3);
                    return 0xffffffff;
                }
            } else if (in_RDX != 0) {
                if (in_RCX[4] == 0) {
                    uVar6 = 0;
                    if (0 < iVar3) {
                        do {
                            iVar1 = *(int64_t *)(in_RCX + 2);
                            pcVar2 = *(code **)(in_RCX + 6);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180221af6;
                            iVar3 = (*pcVar2)((int64_t)&arg_38h + iVar4, iVar1 + (int64_t)(int32_t)uVar6 * 8);
                            if (iVar3 == 0) {
                                return uVar6;
                            }
                            uVar7 = (int32_t)uVar6 + 1;
                            uVar6 = (uint64_t)uVar7;
                        } while ((int32_t)uVar7 < *in_RCX);
                        return 0xffffffff;
                    }
                } else {
                    *(undefined4 *)((int64_t)&var_20h + iVar4) = 2;
                    *(int64_t *)((int64_t)&var_18h + iVar4) = iVar1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180221b3e;
                    iVar4 = fcn.1802963b0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4));
                    if (iVar4 != 0) {
                        return iVar4 - *(int64_t *)(in_RCX + 2) >> 3;
                    }
                }
            }
            return 0xffffffff;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180221a80
// Address: 0x180221a80
// Size: 67 bytes
// ============================================================
uint64_t fcn.180221a50(int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int32_t *in_RCX;
    uint64_t uVar6;
    int64_t in_RDX;
    uint32_t uVar7;
    undefined8 unaff_RBX;
    uint64_t uVar8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180221a5c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(int64_t *)((int64_t)&arg_38h + iVar4) = in_RDX;
    if (in_RCX != (int32_t *)0x0) {
        iVar3 = *in_RCX;
        if (iVar3 != 0) {
            iVar1 = *(int64_t *)(in_RCX + 6);
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBX;
            if (iVar1 == 0) {
                uVar6 = 0;
                if (0 < iVar3) {
                    piVar5 = *(int64_t **)(in_RCX + 2);
                    uVar8 = uVar6;
                    do {
                        if (*piVar5 == in_RDX) {
                            return uVar8;
                        }
                        uVar8 = (uint64_t)((int32_t)uVar8 + 1);
                        uVar6 = uVar6 + 1;
                        piVar5 = piVar5 + 1;
                    } while ((int64_t)uVar6 < (int64_t)iVar3);
                    return 0xffffffff;
                }
            } else if (in_RDX != 0) {
                if (in_RCX[4] == 0) {
                    uVar6 = 0;
                    if (0 < iVar3) {
                        do {
                            iVar1 = *(int64_t *)(in_RCX + 2);
                            pcVar2 = *(code **)(in_RCX + 6);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180221af6;
                            iVar3 = (*pcVar2)((int64_t)&arg_38h + iVar4, iVar1 + (int64_t)(int32_t)uVar6 * 8);
                            if (iVar3 == 0) {
                                return uVar6;
                            }
                            uVar7 = (int32_t)uVar6 + 1;
                            uVar6 = (uint64_t)uVar7;
                        } while ((int32_t)uVar7 < *in_RCX);
                        return 0xffffffff;
                    }
                } else {
                    *(undefined4 *)((int64_t)&var_20h + iVar4) = 2;
                    *(int64_t *)((int64_t)&var_18h + iVar4) = iVar1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180221b3e;
                    iVar4 = fcn.1802963b0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4));
                    if (iVar4 != 0) {
                        return iVar4 - *(int64_t *)(in_RCX + 2) >> 3;
                    }
                }
            }
            return 0xffffffff;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180221ac3
// Address: 0x180221ac3
// Size: 77 bytes
// ============================================================
uint64_t fcn.180221a50(int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int32_t *in_RCX;
    uint64_t uVar6;
    int64_t in_RDX;
    uint32_t uVar7;
    undefined8 unaff_RBX;
    uint64_t uVar8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180221a5c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(int64_t *)((int64_t)&arg_38h + iVar4) = in_RDX;
    if (in_RCX != (int32_t *)0x0) {
        iVar3 = *in_RCX;
        if (iVar3 != 0) {
            iVar1 = *(int64_t *)(in_RCX + 6);
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBX;
            if (iVar1 == 0) {
                uVar6 = 0;
                if (0 < iVar3) {
                    piVar5 = *(int64_t **)(in_RCX + 2);
                    uVar8 = uVar6;
                    do {
                        if (*piVar5 == in_RDX) {
                            return uVar8;
                        }
                        uVar8 = (uint64_t)((int32_t)uVar8 + 1);
                        uVar6 = uVar6 + 1;
                        piVar5 = piVar5 + 1;
                    } while ((int64_t)uVar6 < (int64_t)iVar3);
                    return 0xffffffff;
                }
            } else if (in_RDX != 0) {
                if (in_RCX[4] == 0) {
                    uVar6 = 0;
                    if (0 < iVar3) {
                        do {
                            iVar1 = *(int64_t *)(in_RCX + 2);
                            pcVar2 = *(code **)(in_RCX + 6);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180221af6;
                            iVar3 = (*pcVar2)((int64_t)&arg_38h + iVar4, iVar1 + (int64_t)(int32_t)uVar6 * 8);
                            if (iVar3 == 0) {
                                return uVar6;
                            }
                            uVar7 = (int32_t)uVar6 + 1;
                            uVar6 = (uint64_t)uVar7;
                        } while ((int32_t)uVar7 < *in_RCX);
                        return 0xffffffff;
                    }
                } else {
                    *(undefined4 *)((int64_t)&var_20h + iVar4) = 2;
                    *(int64_t *)((int64_t)&var_18h + iVar4) = iVar1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180221b3e;
                    iVar4 = fcn.1802963b0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4));
                    if (iVar4 != 0) {
                        return iVar4 - *(int64_t *)(in_RCX + 2) >> 3;
                    }
                }
            }
            return 0xffffffff;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180221b10
// Address: 0x180221b10
// Size: 13 bytes
// ============================================================
uint64_t fcn.180221a50(int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int32_t *in_RCX;
    uint64_t uVar6;
    int64_t in_RDX;
    uint32_t uVar7;
    undefined8 unaff_RBX;
    uint64_t uVar8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180221a5c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(int64_t *)((int64_t)&arg_38h + iVar4) = in_RDX;
    if (in_RCX != (int32_t *)0x0) {
        iVar3 = *in_RCX;
        if (iVar3 != 0) {
            iVar1 = *(int64_t *)(in_RCX + 6);
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBX;
            if (iVar1 == 0) {
                uVar6 = 0;
                if (0 < iVar3) {
                    piVar5 = *(int64_t **)(in_RCX + 2);
                    uVar8 = uVar6;
                    do {
                        if (*piVar5 == in_RDX) {
                            return uVar8;
                        }
                        uVar8 = (uint64_t)((int32_t)uVar8 + 1);
                        uVar6 = uVar6 + 1;
                        piVar5 = piVar5 + 1;
                    } while ((int64_t)uVar6 < (int64_t)iVar3);
                    return 0xffffffff;
                }
            } else if (in_RDX != 0) {
                if (in_RCX[4] == 0) {
                    uVar6 = 0;
                    if (0 < iVar3) {
                        do {
                            iVar1 = *(int64_t *)(in_RCX + 2);
                            pcVar2 = *(code **)(in_RCX + 6);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180221af6;
                            iVar3 = (*pcVar2)((int64_t)&arg_38h + iVar4, iVar1 + (int64_t)(int32_t)uVar6 * 8);
                            if (iVar3 == 0) {
                                return uVar6;
                            }
                            uVar7 = (int32_t)uVar6 + 1;
                            uVar6 = (uint64_t)uVar7;
                        } while ((int32_t)uVar7 < *in_RCX);
                        return 0xffffffff;
                    }
                } else {
                    *(undefined4 *)((int64_t)&var_20h + iVar4) = 2;
                    *(int64_t *)((int64_t)&var_18h + iVar4) = iVar1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180221b3e;
                    iVar4 = fcn.1802963b0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4));
                    if (iVar4 != 0) {
                        return iVar4 - *(int64_t *)(in_RCX + 2) >> 3;
                    }
                }
            }
            return 0xffffffff;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180221b1d
// Address: 0x180221b1d
// Size: 54 bytes
// ============================================================
uint64_t fcn.180221a50(int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int32_t *in_RCX;
    uint64_t uVar6;
    int64_t in_RDX;
    uint32_t uVar7;
    undefined8 unaff_RBX;
    uint64_t uVar8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180221a5c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(int64_t *)((int64_t)&arg_38h + iVar4) = in_RDX;
    if (in_RCX != (int32_t *)0x0) {
        iVar3 = *in_RCX;
        if (iVar3 != 0) {
            iVar1 = *(int64_t *)(in_RCX + 6);
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBX;
            if (iVar1 == 0) {
                uVar6 = 0;
                if (0 < iVar3) {
                    piVar5 = *(int64_t **)(in_RCX + 2);
                    uVar8 = uVar6;
                    do {
                        if (*piVar5 == in_RDX) {
                            return uVar8;
                        }
                        uVar8 = (uint64_t)((int32_t)uVar8 + 1);
                        uVar6 = uVar6 + 1;
                        piVar5 = piVar5 + 1;
                    } while ((int64_t)uVar6 < (int64_t)iVar3);
                    return 0xffffffff;
                }
            } else if (in_RDX != 0) {
                if (in_RCX[4] == 0) {
                    uVar6 = 0;
                    if (0 < iVar3) {
                        do {
                            iVar1 = *(int64_t *)(in_RCX + 2);
                            pcVar2 = *(code **)(in_RCX + 6);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180221af6;
                            iVar3 = (*pcVar2)((int64_t)&arg_38h + iVar4, iVar1 + (int64_t)(int32_t)uVar6 * 8);
                            if (iVar3 == 0) {
                                return uVar6;
                            }
                            uVar7 = (int32_t)uVar6 + 1;
                            uVar6 = (uint64_t)uVar7;
                        } while ((int32_t)uVar7 < *in_RCX);
                        return 0xffffffff;
                    }
                } else {
                    *(undefined4 *)((int64_t)&var_20h + iVar4) = 2;
                    *(int64_t *)((int64_t)&var_18h + iVar4) = iVar1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180221b3e;
                    iVar4 = fcn.1802963b0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4));
                    if (iVar4 != 0) {
                        return iVar4 - *(int64_t *)(in_RCX + 2) >> 3;
                    }
                }
            }
            return 0xffffffff;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180221b53
// Address: 0x180221b53
// Size: 19 bytes
// ============================================================
uint64_t fcn.180221a50(int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int32_t *in_RCX;
    uint64_t uVar6;
    int64_t in_RDX;
    uint32_t uVar7;
    undefined8 unaff_RBX;
    uint64_t uVar8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180221a5c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(int64_t *)((int64_t)&arg_38h + iVar4) = in_RDX;
    if (in_RCX != (int32_t *)0x0) {
        iVar3 = *in_RCX;
        if (iVar3 != 0) {
            iVar1 = *(int64_t *)(in_RCX + 6);
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBX;
            if (iVar1 == 0) {
                uVar6 = 0;
                if (0 < iVar3) {
                    piVar5 = *(int64_t **)(in_RCX + 2);
                    uVar8 = uVar6;
                    do {
                        if (*piVar5 == in_RDX) {
                            return uVar8;
                        }
                        uVar8 = (uint64_t)((int32_t)uVar8 + 1);
                        uVar6 = uVar6 + 1;
                        piVar5 = piVar5 + 1;
                    } while ((int64_t)uVar6 < (int64_t)iVar3);
                    return 0xffffffff;
                }
            } else if (in_RDX != 0) {
                if (in_RCX[4] == 0) {
                    uVar6 = 0;
                    if (0 < iVar3) {
                        do {
                            iVar1 = *(int64_t *)(in_RCX + 2);
                            pcVar2 = *(code **)(in_RCX + 6);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180221af6;
                            iVar3 = (*pcVar2)((int64_t)&arg_38h + iVar4, iVar1 + (int64_t)(int32_t)uVar6 * 8);
                            if (iVar3 == 0) {
                                return uVar6;
                            }
                            uVar7 = (int32_t)uVar6 + 1;
                            uVar6 = (uint64_t)uVar7;
                        } while ((int32_t)uVar7 < *in_RCX);
                        return 0xffffffff;
                    }
                } else {
                    *(undefined4 *)((int64_t)&var_20h + iVar4) = 2;
                    *(int64_t *)((int64_t)&var_18h + iVar4) = iVar1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180221b3e;
                    iVar4 = fcn.1802963b0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4));
                    if (iVar4 != 0) {
                        return iVar4 - *(int64_t *)(in_RCX + 2) >> 3;
                    }
                }
            }
            return 0xffffffff;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180221b66
// Address: 0x180221b66
// Size: 11 bytes
// ============================================================
uint64_t fcn.180221a50(int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int32_t *in_RCX;
    uint64_t uVar6;
    int64_t in_RDX;
    uint32_t uVar7;
    undefined8 unaff_RBX;
    uint64_t uVar8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180221a5c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(int64_t *)((int64_t)&arg_38h + iVar4) = in_RDX;
    if (in_RCX != (int32_t *)0x0) {
        iVar3 = *in_RCX;
        if (iVar3 != 0) {
            iVar1 = *(int64_t *)(in_RCX + 6);
            *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBX;
            if (iVar1 == 0) {
                uVar6 = 0;
                if (0 < iVar3) {
                    piVar5 = *(int64_t **)(in_RCX + 2);
                    uVar8 = uVar6;
                    do {
                        if (*piVar5 == in_RDX) {
                            return uVar8;
                        }
                        uVar8 = (uint64_t)((int32_t)uVar8 + 1);
                        uVar6 = uVar6 + 1;
                        piVar5 = piVar5 + 1;
                    } while ((int64_t)uVar6 < (int64_t)iVar3);
                    return 0xffffffff;
                }
            } else if (in_RDX != 0) {
                if (in_RCX[4] == 0) {
                    uVar6 = 0;
                    if (0 < iVar3) {
                        do {
                            iVar1 = *(int64_t *)(in_RCX + 2);
                            pcVar2 = *(code **)(in_RCX + 6);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180221af6;
                            iVar3 = (*pcVar2)((int64_t)&arg_38h + iVar4, iVar1 + (int64_t)(int32_t)uVar6 * 8);
                            if (iVar3 == 0) {
                                return uVar6;
                            }
                            uVar7 = (int32_t)uVar6 + 1;
                            uVar6 = (uint64_t)uVar7;
                        } while ((int32_t)uVar7 < *in_RCX);
                        return 0xffffffff;
                    }
                } else {
                    *(undefined4 *)((int64_t)&var_20h + iVar4) = 2;
                    *(int64_t *)((int64_t)&var_18h + iVar4) = iVar1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180221b3e;
                    iVar4 = fcn.1802963b0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4));
                    if (iVar4 != 0) {
                        return iVar4 - *(int64_t *)(in_RCX + 2) >> 3;
                    }
                }
            }
            return 0xffffffff;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180221b80
// Address: 0x180221b80
// Size: 69 bytes
// ============================================================
uint64_t fcn.180221b80(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_b0h)
{
    int64_t iVar1;
    code *pcVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    int32_t *in_RCX;
    uint32_t uVar8;
    int64_t in_RDX;
    uint32_t uVar9;
    undefined8 unaff_RSI;
    uint64_t uVar10;
    int32_t *in_R8;
    undefined8 unaff_R14;
    int32_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_20;
    undefined8 uStack_28;
    
    uStack_28 = 0x180221b90;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(int64_t *)((int64_t)&arg_48h + iVar5) = in_RDX;
    *(undefined4 *)((int64_t)&arg_40h + iVar5) = 0;
    if (in_RCX == (int32_t *)0x0) {
        return 0xffffffff;
    }
    iVar4 = *in_RCX;
    if (iVar4 == 0) {
        return 0xffffffff;
    }
    iVar1 = *(int64_t *)(in_RCX + 6);
    *(undefined8 *)((int64_t)&var_10h + iVar5) = unaff_R14;
    piVar11 = (int32_t *)((int64_t)&arg_40h + iVar5);
    if (in_R8 != (int32_t *)0x0) {
        piVar11 = in_R8;
    }
    if (iVar1 == 0) {
        uVar8 = 0;
        if (0 < iVar4) {
            piVar6 = *(int64_t **)(in_RCX + 2);
            iVar5 = 0;
            do {
                if (*piVar6 == in_RDX) {
                    *piVar11 = 1;
                    return (uint64_t)uVar8;
                }
                uVar8 = uVar8 + 1;
                iVar5 = iVar5 + 1;
                piVar6 = piVar6 + 1;
            } while (iVar5 < iVar4);
        }
        *piVar11 = 0;
        return 0xffffffff;
    }
    if (in_RDX == 0) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RSI;
    if (in_RCX[4] != 0) {
        *(undefined4 *)((int64_t)&var_8h + iVar5) = 2;
        *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20) = iVar1;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180221cc5;
        uVar7 = fcn.1802963b0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar5)
                              , *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                              *(int64_t *)(&stack0x00000028 + iVar5));
        if (in_R8 != (int32_t *)0x0) {
            *piVar11 = 0;
            if (uVar7 == 0) {
                return 0xffffffff;
            }
            uVar10 = uVar7;
            if ((uint64_t)(*(int64_t *)(in_RCX + 2) + (int64_t)*in_RCX * 8) <= uVar7) goto code_r0x000180221d28;
            do {
                pcVar2 = *(code **)(in_RCX + 6);
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180221cfe;
                iVar4 = (*pcVar2)((int64_t)&arg_48h + iVar5, uVar10);
                if (iVar4 != 0) goto code_r0x000180221d28;
                *piVar11 = *piVar11 + 1;
                uVar10 = uVar10 + 8;
            } while (uVar10 < (uint64_t)(*(int64_t *)(in_RCX + 2) + (int64_t)*in_RCX * 8));
        }
        if (uVar7 == 0) {
            return 0xffffffff;
        }
code_r0x000180221d28:
        uVar7 = (int64_t)(uVar7 - *(int64_t *)(in_RCX + 2)) >> 3;
code_r0x000180221d30:
        return uVar7 & 0xffffffff;
    }
    uVar8 = 0xffffffff;
    uVar7 = 0;
    if (0 < iVar4) {
        do {
            iVar1 = *(int64_t *)(in_RCX + 2);
            uVar9 = (uint32_t)uVar7;
            pcVar2 = *(code **)(in_RCX + 6);
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180221c66;
            iVar4 = (*pcVar2)((int64_t)&arg_48h + iVar5, iVar1 + (int64_t)(int32_t)uVar9 * 8);
            if (iVar4 == 0) {
                *piVar11 = *piVar11 + 1;
                uVar3 = uVar9;
                if (uVar8 != 0xffffffff) {
                    uVar3 = uVar8;
                }
                uVar8 = uVar3;
                if (in_R8 == (int32_t *)0x0) goto code_r0x000180221d30;
            }
            uVar7 = (uint64_t)(uVar9 + 1);
        } while ((int32_t)(uVar9 + 1) < *in_RCX);
        if (uVar8 != 0xffffffff) goto code_r0x000180221c8e;
    }
    *piVar11 = 0;
code_r0x000180221c8e:
    return (uint64_t)uVar8;
}

// ============================================================
// Function: FUN_180221bc5
// Address: 0x180221bc5
// Size: 76 bytes
// ============================================================
uint64_t fcn.180221b80(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_b0h)
{
    int64_t iVar1;
    code *pcVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    int32_t *in_RCX;
    uint32_t uVar8;
    int64_t in_RDX;
    uint32_t uVar9;
    undefined8 unaff_RSI;
    uint64_t uVar10;
    int32_t *in_R8;
    undefined8 unaff_R14;
    int32_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_20;
    undefined8 uStack_28;
    
    uStack_28 = 0x180221b90;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(int64_t *)((int64_t)&arg_48h + iVar5) = in_RDX;
    *(undefined4 *)((int64_t)&arg_40h + iVar5) = 0;
    if (in_RCX == (int32_t *)0x0) {
        return 0xffffffff;
    }
    iVar4 = *in_RCX;
    if (iVar4 == 0) {
        return 0xffffffff;
    }
    iVar1 = *(int64_t *)(in_RCX + 6);
    *(undefined8 *)((int64_t)&var_10h + iVar5) = unaff_R14;
    piVar11 = (int32_t *)((int64_t)&arg_40h + iVar5);
    if (in_R8 != (int32_t *)0x0) {
        piVar11 = in_R8;
    }
    if (iVar1 == 0) {
        uVar8 = 0;
        if (0 < iVar4) {
            piVar6 = *(int64_t **)(in_RCX + 2);
            iVar5 = 0;
            do {
                if (*piVar6 == in_RDX) {
                    *piVar11 = 1;
                    return (uint64_t)uVar8;
                }
                uVar8 = uVar8 + 1;
                iVar5 = iVar5 + 1;
                piVar6 = piVar6 + 1;
            } while (iVar5 < iVar4);
        }
        *piVar11 = 0;
        return 0xffffffff;
    }
    if (in_RDX == 0) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RSI;
    if (in_RCX[4] != 0) {
        *(undefined4 *)((int64_t)&var_8h + iVar5) = 2;
        *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20) = iVar1;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180221cc5;
        uVar7 = fcn.1802963b0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar5)
                              , *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                              *(int64_t *)(&stack0x00000028 + iVar5));
        if (in_R8 != (int32_t *)0x0) {
            *piVar11 = 0;
            if (uVar7 == 0) {
                return 0xffffffff;
            }
            uVar10 = uVar7;
            if ((uint64_t)(*(int64_t *)(in_RCX + 2) + (int64_t)*in_RCX * 8) <= uVar7) goto code_r0x000180221d28;
            do {
                pcVar2 = *(code **)(in_RCX + 6);
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180221cfe;
                iVar4 = (*pcVar2)((int64_t)&arg_48h + iVar5, uVar10);
                if (iVar4 != 0) goto code_r0x000180221d28;
                *piVar11 = *piVar11 + 1;
                uVar10 = uVar10 + 8;
            } while (uVar10 < (uint64_t)(*(int64_t *)(in_RCX + 2) + (int64_t)*in_RCX * 8));
        }
        if (uVar7 == 0) {
            return 0xffffffff;
        }
code_r0x000180221d28:
        uVar7 = (int64_t)(uVar7 - *(int64_t *)(in_RCX + 2)) >> 3;
code_r0x000180221d30:
        return uVar7 & 0xffffffff;
    }
    uVar8 = 0xffffffff;
    uVar7 = 0;
    if (0 < iVar4) {
        do {
            iVar1 = *(int64_t *)(in_RCX + 2);
            uVar9 = (uint32_t)uVar7;
            pcVar2 = *(code **)(in_RCX + 6);
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180221c66;
            iVar4 = (*pcVar2)((int64_t)&arg_48h + iVar5, iVar1 + (int64_t)(int32_t)uVar9 * 8);
            if (iVar4 == 0) {
                *piVar11 = *piVar11 + 1;
                uVar3 = uVar9;
                if (uVar8 != 0xffffffff) {
                    uVar3 = uVar8;
                }
                uVar8 = uVar3;
                if (in_R8 == (int32_t *)0x0) goto code_r0x000180221d30;
            }
            uVar7 = (uint64_t)(uVar9 + 1);
        } while ((int32_t)(uVar9 + 1) < *in_RCX);
        if (uVar8 != 0xffffffff) goto code_r0x000180221c8e;
    }
    *piVar11 = 0;
code_r0x000180221c8e:
    return (uint64_t)uVar8;
}

// ============================================================
// Function: FUN_180221c11
// Address: 0x180221c11
// Size: 24 bytes
// ============================================================
uint64_t fcn.180221b80(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_b0h)
{
    int64_t iVar1;
    code *pcVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    int32_t *in_RCX;
    uint32_t uVar8;
    int64_t in_RDX;
    uint32_t uVar9;
    undefined8 unaff_RSI;
    uint64_t uVar10;
    int32_t *in_R8;
    undefined8 unaff_R14;
    int32_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_20;
    undefined8 uStack_28;
    
    uStack_28 = 0x180221b90;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(int64_t *)((int64_t)&arg_48h + iVar5) = in_RDX;
    *(undefined4 *)((int64_t)&arg_40h + iVar5) = 0;
    if (in_RCX == (int32_t *)0x0) {
        return 0xffffffff;
    }
    iVar4 = *in_RCX;
    if (iVar4 == 0) {
        return 0xffffffff;
    }
    iVar1 = *(int64_t *)(in_RCX + 6);
    *(undefined8 *)((int64_t)&var_10h + iVar5) = unaff_R14;
    piVar11 = (int32_t *)((int64_t)&arg_40h + iVar5);
    if (in_R8 != (int32_t *)0x0) {
        piVar11 = in_R8;
    }
    if (iVar1 == 0) {
        uVar8 = 0;
        if (0 < iVar4) {
            piVar6 = *(int64_t **)(in_RCX + 2);
            iVar5 = 0;
            do {
                if (*piVar6 == in_RDX) {
                    *piVar11 = 1;
                    return (uint64_t)uVar8;
                }
                uVar8 = uVar8 + 1;
                iVar5 = iVar5 + 1;
                piVar6 = piVar6 + 1;
            } while (iVar5 < iVar4);
        }
        *piVar11 = 0;
        return 0xffffffff;
    }
    if (in_RDX == 0) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RSI;
    if (in_RCX[4] != 0) {
        *(undefined4 *)((int64_t)&var_8h + iVar5) = 2;
        *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20) = iVar1;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180221cc5;
        uVar7 = fcn.1802963b0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar5)
                              , *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                              *(int64_t *)(&stack0x00000028 + iVar5));
        if (in_R8 != (int32_t *)0x0) {
            *piVar11 = 0;
            if (uVar7 == 0) {
                return 0xffffffff;
            }
            uVar10 = uVar7;
            if ((uint64_t)(*(int64_t *)(in_RCX + 2) + (int64_t)*in_RCX * 8) <= uVar7) goto code_r0x000180221d28;
            do {
                pcVar2 = *(code **)(in_RCX + 6);
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180221cfe;
                iVar4 = (*pcVar2)((int64_t)&arg_48h + iVar5, uVar10);
                if (iVar4 != 0) goto code_r0x000180221d28;
                *piVar11 = *piVar11 + 1;
                uVar10 = uVar10 + 8;
            } while (uVar10 < (uint64_t)(*(int64_t *)(in_RCX + 2) + (int64_t)*in_RCX * 8));
        }
        if (uVar7 == 0) {
            return 0xffffffff;
        }
code_r0x000180221d28:
        uVar7 = (int64_t)(uVar7 - *(int64_t *)(in_RCX + 2)) >> 3;
code_r0x000180221d30:
        return uVar7 & 0xffffffff;
    }
    uVar8 = 0xffffffff;
    uVar7 = 0;
    if (0 < iVar4) {
        do {
            iVar1 = *(int64_t *)(in_RCX + 2);
            uVar9 = (uint32_t)uVar7;
            pcVar2 = *(code **)(in_RCX + 6);
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180221c66;
            iVar4 = (*pcVar2)((int64_t)&arg_48h + iVar5, iVar1 + (int64_t)(int32_t)uVar9 * 8);
            if (iVar4 == 0) {
                *piVar11 = *piVar11 + 1;
                uVar3 = uVar9;
                if (uVar8 != 0xffffffff) {
                    uVar3 = uVar8;
                }
                uVar8 = uVar3;
                if (in_R8 == (int32_t *)0x0) goto code_r0x000180221d30;
            }
            uVar7 = (uint64_t)(uVar9 + 1);
        } while ((int32_t)(uVar9 + 1) < *in_RCX);
        if (uVar8 != 0xffffffff) goto code_r0x000180221c8e;
    }
    *piVar11 = 0;
code_r0x000180221c8e:
    return (uint64_t)uVar8;
}

// ============================================================
// Function: FUN_180221c29
// Address: 0x180221c29
// Size: 123 bytes
// ============================================================
uint64_t fcn.180221b80(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_b0h)
{
    int64_t iVar1;
    code *pcVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    int32_t *in_RCX;
    uint32_t uVar8;
    int64_t in_RDX;
    uint32_t uVar9;
    undefined8 unaff_RSI;
    uint64_t uVar10;
    int32_t *in_R8;
    undefined8 unaff_R14;
    int32_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_20;
    undefined8 uStack_28;
    
    uStack_28 = 0x180221b90;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(int64_t *)((int64_t)&arg_48h + iVar5) = in_RDX;
    *(undefined4 *)((int64_t)&arg_40h + iVar5) = 0;
    if (in_RCX == (int32_t *)0x0) {
        return 0xffffffff;
    }
    iVar4 = *in_RCX;
    if (iVar4 == 0) {
        return 0xffffffff;
    }
    iVar1 = *(int64_t *)(in_RCX + 6);
    *(undefined8 *)((int64_t)&var_10h + iVar5) = unaff_R14;
    piVar11 = (int32_t *)((int64_t)&arg_40h + iVar5);
    if (in_R8 != (int32_t *)0x0) {
        piVar11 = in_R8;
    }
    if (iVar1 == 0) {
        uVar8 = 0;
        if (0 < iVar4) {
            piVar6 = *(int64_t **)(in_RCX + 2);
            iVar5 = 0;
            do {
                if (*piVar6 == in_RDX) {
                    *piVar11 = 1;
                    return (uint64_t)uVar8;
                }
                uVar8 = uVar8 + 1;
                iVar5 = iVar5 + 1;
                piVar6 = piVar6 + 1;
            } while (iVar5 < iVar4);
        }
        *piVar11 = 0;
        return 0xffffffff;
    }
    if (in_RDX == 0) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RSI;
    if (in_RCX[4] != 0) {
        *(undefined4 *)((int64_t)&var_8h + iVar5) = 2;
        *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20) = iVar1;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180221cc5;
        uVar7 = fcn.1802963b0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar5)
                              , *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                              *(int64_t *)(&stack0x00000028 + iVar5));
        if (in_R8 != (int32_t *)0x0) {
            *piVar11 = 0;
            if (uVar7 == 0) {
                return 0xffffffff;
            }
            uVar10 = uVar7;
            if ((uint64_t)(*(int64_t *)(in_RCX + 2) + (int64_t)*in_RCX * 8) <= uVar7) goto code_r0x000180221d28;
            do {
                pcVar2 = *(code **)(in_RCX + 6);
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180221cfe;
                iVar4 = (*pcVar2)((int64_t)&arg_48h + iVar5, uVar10);
                if (iVar4 != 0) goto code_r0x000180221d28;
                *piVar11 = *piVar11 + 1;
                uVar10 = uVar10 + 8;
            } while (uVar10 < (uint64_t)(*(int64_t *)(in_RCX + 2) + (int64_t)*in_RCX * 8));
        }
        if (uVar7 == 0) {
            return 0xffffffff;
        }
code_r0x000180221d28:
        uVar7 = (int64_t)(uVar7 - *(int64_t *)(in_RCX + 2)) >> 3;
code_r0x000180221d30:
        return uVar7 & 0xffffffff;
    }
    uVar8 = 0xffffffff;
    uVar7 = 0;
    if (0 < iVar4) {
        do {
            iVar1 = *(int64_t *)(in_RCX + 2);
            uVar9 = (uint32_t)uVar7;
            pcVar2 = *(code **)(in_RCX + 6);
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180221c66;
            iVar4 = (*pcVar2)((int64_t)&arg_48h + iVar5, iVar1 + (int64_t)(int32_t)uVar9 * 8);
            if (iVar4 == 0) {
                *piVar11 = *piVar11 + 1;
                uVar3 = uVar9;
                if (uVar8 != 0xffffffff) {
                    uVar3 = uVar8;
                }
                uVar8 = uVar3;
                if (in_R8 == (int32_t *)0x0) goto code_r0x000180221d30;
            }
            uVar7 = (uint64_t)(uVar9 + 1);
        } while ((int32_t)(uVar9 + 1) < *in_RCX);
        if (uVar8 != 0xffffffff) goto code_r0x000180221c8e;
    }
    *piVar11 = 0;
code_r0x000180221c8e:
    return (uint64_t)uVar8;
}

// ============================================================
// Function: FUN_180221ca4
// Address: 0x180221ca4
// Size: 147 bytes
// ============================================================
uint64_t fcn.180221b80(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_b0h)
{
    int64_t iVar1;
    code *pcVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    int32_t *in_RCX;
    uint32_t uVar8;
    int64_t in_RDX;
    uint32_t uVar9;
    undefined8 unaff_RSI;
    uint64_t uVar10;
    int32_t *in_R8;
    undefined8 unaff_R14;
    int32_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_20;
    undefined8 uStack_28;
    
    uStack_28 = 0x180221b90;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(int64_t *)((int64_t)&arg_48h + iVar5) = in_RDX;
    *(undefined4 *)((int64_t)&arg_40h + iVar5) = 0;
    if (in_RCX == (int32_t *)0x0) {
        return 0xffffffff;
    }
    iVar4 = *in_RCX;
    if (iVar4 == 0) {
        return 0xffffffff;
    }
    iVar1 = *(int64_t *)(in_RCX + 6);
    *(undefined8 *)((int64_t)&var_10h + iVar5) = unaff_R14;
    piVar11 = (int32_t *)((int64_t)&arg_40h + iVar5);
    if (in_R8 != (int32_t *)0x0) {
        piVar11 = in_R8;
    }
    if (iVar1 == 0) {
        uVar8 = 0;
        if (0 < iVar4) {
            piVar6 = *(int64_t **)(in_RCX + 2);
            iVar5 = 0;
            do {
                if (*piVar6 == in_RDX) {
                    *piVar11 = 1;
                    return (uint64_t)uVar8;
                }
                uVar8 = uVar8 + 1;
                iVar5 = iVar5 + 1;
                piVar6 = piVar6 + 1;
            } while (iVar5 < iVar4);
        }
        *piVar11 = 0;
        return 0xffffffff;
    }
    if (in_RDX == 0) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RSI;
    if (in_RCX[4] != 0) {
        *(undefined4 *)((int64_t)&var_8h + iVar5) = 2;
        *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20) = iVar1;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180221cc5;
        uVar7 = fcn.1802963b0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar5)
                              , *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                              *(int64_t *)(&stack0x00000028 + iVar5));
        if (in_R8 != (int32_t *)0x0) {
            *piVar11 = 0;
            if (uVar7 == 0) {
                return 0xffffffff;
            }
            uVar10 = uVar7;
            if ((uint64_t)(*(int64_t *)(in_RCX + 2) + (int64_t)*in_RCX * 8) <= uVar7) goto code_r0x000180221d28;
            do {
                pcVar2 = *(code **)(in_RCX + 6);
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180221cfe;
                iVar4 = (*pcVar2)((int64_t)&arg_48h + iVar5, uVar10);
                if (iVar4 != 0) goto code_r0x000180221d28;
                *piVar11 = *piVar11 + 1;
                uVar10 = uVar10 + 8;
            } while (uVar10 < (uint64_t)(*(int64_t *)(in_RCX + 2) + (int64_t)*in_RCX * 8));
        }
        if (uVar7 == 0) {
            return 0xffffffff;
        }
code_r0x000180221d28:
        uVar7 = (int64_t)(uVar7 - *(int64_t *)(in_RCX + 2)) >> 3;
code_r0x000180221d30:
        return uVar7 & 0xffffffff;
    }
    uVar8 = 0xffffffff;
    uVar7 = 0;
    if (0 < iVar4) {
        do {
            iVar1 = *(int64_t *)(in_RCX + 2);
            uVar9 = (uint32_t)uVar7;
            pcVar2 = *(code **)(in_RCX + 6);
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180221c66;
            iVar4 = (*pcVar2)((int64_t)&arg_48h + iVar5, iVar1 + (int64_t)(int32_t)uVar9 * 8);
            if (iVar4 == 0) {
                *piVar11 = *piVar11 + 1;
                uVar3 = uVar9;
                if (uVar8 != 0xffffffff) {
                    uVar3 = uVar8;
                }
                uVar8 = uVar3;
                if (in_R8 == (int32_t *)0x0) goto code_r0x000180221d30;
            }
            uVar7 = (uint64_t)(uVar9 + 1);
        } while ((int32_t)(uVar9 + 1) < *in_RCX);
        if (uVar8 != 0xffffffff) goto code_r0x000180221c8e;
    }
    *piVar11 = 0;
code_r0x000180221c8e:
    return (uint64_t)uVar8;
}

// ============================================================
// Function: FUN_180221d37
// Address: 0x180221d37
// Size: 15 bytes
// ============================================================
uint64_t fcn.180221b80(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_b0h)
{
    int64_t iVar1;
    code *pcVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    int32_t *in_RCX;
    uint32_t uVar8;
    int64_t in_RDX;
    uint32_t uVar9;
    undefined8 unaff_RSI;
    uint64_t uVar10;
    int32_t *in_R8;
    undefined8 unaff_R14;
    int32_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_20;
    undefined8 uStack_28;
    
    uStack_28 = 0x180221b90;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(int64_t *)((int64_t)&arg_48h + iVar5) = in_RDX;
    *(undefined4 *)((int64_t)&arg_40h + iVar5) = 0;
    if (in_RCX == (int32_t *)0x0) {
        return 0xffffffff;
    }
    iVar4 = *in_RCX;
    if (iVar4 == 0) {
        return 0xffffffff;
    }
    iVar1 = *(int64_t *)(in_RCX + 6);
    *(undefined8 *)((int64_t)&var_10h + iVar5) = unaff_R14;
    piVar11 = (int32_t *)((int64_t)&arg_40h + iVar5);
    if (in_R8 != (int32_t *)0x0) {
        piVar11 = in_R8;
    }
    if (iVar1 == 0) {
        uVar8 = 0;
        if (0 < iVar4) {
            piVar6 = *(int64_t **)(in_RCX + 2);
            iVar5 = 0;
            do {
                if (*piVar6 == in_RDX) {
                    *piVar11 = 1;
                    return (uint64_t)uVar8;
                }
                uVar8 = uVar8 + 1;
                iVar5 = iVar5 + 1;
                piVar6 = piVar6 + 1;
            } while (iVar5 < iVar4);
        }
        *piVar11 = 0;
        return 0xffffffff;
    }
    if (in_RDX == 0) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RSI;
    if (in_RCX[4] != 0) {
        *(undefined4 *)((int64_t)&var_8h + iVar5) = 2;
        *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20) = iVar1;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180221cc5;
        uVar7 = fcn.1802963b0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), *(int64_t *)((int64_t)&var_8h + iVar5)
                              , *(int64_t *)((int64_t)&var_10h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                              *(int64_t *)(&stack0x00000028 + iVar5));
        if (in_R8 != (int32_t *)0x0) {
            *piVar11 = 0;
            if (uVar7 == 0) {
                return 0xffffffff;
            }
            uVar10 = uVar7;
            if ((uint64_t)(*(int64_t *)(in_RCX + 2) + (int64_t)*in_RCX * 8) <= uVar7) goto code_r0x000180221d28;
            do {
                pcVar2 = *(code **)(in_RCX + 6);
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180221cfe;
                iVar4 = (*pcVar2)((int64_t)&arg_48h + iVar5, uVar10);
                if (iVar4 != 0) goto code_r0x000180221d28;
                *piVar11 = *piVar11 + 1;
                uVar10 = uVar10 + 8;
            } while (uVar10 < (uint64_t)(*(int64_t *)(in_RCX + 2) + (int64_t)*in_RCX * 8));
        }
        if (uVar7 == 0) {
            return 0xffffffff;
        }
code_r0x000180221d28:
        uVar7 = (int64_t)(uVar7 - *(int64_t *)(in_RCX + 2)) >> 3;
code_r0x000180221d30:
        return uVar7 & 0xffffffff;
    }
    uVar8 = 0xffffffff;
    uVar7 = 0;
    if (0 < iVar4) {
        do {
            iVar1 = *(int64_t *)(in_RCX + 2);
            uVar9 = (uint32_t)uVar7;
            pcVar2 = *(code **)(in_RCX + 6);
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180221c66;
            iVar4 = (*pcVar2)((int64_t)&arg_48h + iVar5, iVar1 + (int64_t)(int32_t)uVar9 * 8);
            if (iVar4 == 0) {
                *piVar11 = *piVar11 + 1;
                uVar3 = uVar9;
                if (uVar8 != 0xffffffff) {
                    uVar3 = uVar8;
                }
                uVar8 = uVar3;
                if (in_R8 == (int32_t *)0x0) goto code_r0x000180221d30;
            }
            uVar7 = (uint64_t)(uVar9 + 1);
        } while ((int32_t)(uVar9 + 1) < *in_RCX);
        if (uVar8 != 0xffffffff) goto code_r0x000180221c8e;
    }
    *piVar11 = 0;
code_r0x000180221c8e:
    return (uint64_t)uVar8;
}

// ============================================================
// Function: FUN_180221d50
// Address: 0x180221d50
// Size: 71 bytes
// ============================================================
void fcn.180221d50(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180221d60;
        iVar2 = fcn.18045a350();
        uVar1 = *(undefined8 *)(arg1 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x180221d7c;
        fcn.180224990(uVar1, 0x1804bf768, 0x1ce);
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x180221d91;
        fcn.180224990(arg1, 0x1804bf768, 0x1cf);
    }
    return;
}

