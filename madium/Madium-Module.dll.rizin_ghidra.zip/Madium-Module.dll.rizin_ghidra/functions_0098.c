// Chunk 98 - 50 functions

// ============================================================
// Function: FUN_18014e5c0
// Address: 0x18014e5c0
// Size: 106 bytes
// ============================================================
float fcn.18014e5c0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h
                   , int64_t arg_88h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    double dVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (arg3 == arg4) {
        return 0.0;
    }
    if ((uint64_t)arg3 < (uint64_t)arg4) {
        uVar2 = arg3;
        if (((uint64_t)arg3 <= (uint64_t)arg2) && (uVar2 = arg2, (uint64_t)arg4 < (uint64_t)arg2)) {
            uVar2 = arg4;
        }
    } else {
        uVar2 = arg4;
        if (((uint64_t)arg4 <= (uint64_t)arg2) && (uVar2 = arg2, (uint64_t)arg3 < (uint64_t)arg2)) {
            uVar2 = arg3;
        }
    }
    fVar9 = 0.0;
    if ((float)arg_28h <= 0.0) {
        return (float)(uVar2 - arg3) / (float)(arg4 - arg3);
    }
    uVar3 = arg3;
    uVar1 = arg4;
    if ((uint64_t)arg3 <= (uint64_t)arg4) {
        uVar3 = arg4;
        uVar1 = arg3;
    }
    dVar6 = (double)(float)arg_28h;
    if ((int64_t)uVar1 < 0) {
        dVar7 = (double)(uVar1 >> 1 | (uint64_t)((uint32_t)uVar1 & 1));
        dVar7 = dVar7 + dVar7;
    } else {
        dVar7 = (double)uVar1;
    }
    fVar11 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
    if ((int64_t)uVar1 < 0) {
        fVar10 = (float)(uVar1 >> 1 | (uint64_t)((uint32_t)uVar1 & 1));
        fVar10 = fVar10 + fVar10;
    } else {
        fVar10 = (float)uVar1;
    }
    if ((double)((uint64_t)dVar7 & 0x7fffffffffffffff) < dVar6) {
        fVar8 = (float)arg_28h;
        if (fVar10 < 0.0) {
            fVar8 = fVar11;
        }
        dVar7 = (double)fVar8;
    }
    if ((int64_t)uVar3 < 0) {
        dVar5 = (double)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
        dVar5 = dVar5 + dVar5;
        fVar8 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
        fVar8 = fVar8 + fVar8;
    } else {
        dVar5 = (double)uVar3;
        fVar8 = (float)uVar3;
    }
    if ((double)((uint64_t)dVar5 & 0x7fffffffffffffff) < dVar6) {
        if (fVar8 < 0.0) {
            arg_28h._0_4_ = fVar11;
        }
        dVar5 = (double)(float)arg_28h;
    }
    if ((fVar10 != 0.0) || (0.0 <= fVar8)) {
        if ((fVar8 == 0.0) && (fVar10 < 0.0)) {
            dVar5 = (double)fVar11;
        }
    } else {
        dVar7 = (double)fVar11;
    }
    if ((int64_t)uVar2 < 0) {
        dVar4 = (double)(uVar2 >> 1 | (uint64_t)((uint32_t)uVar2 & 1));
        dVar4 = dVar4 + dVar4;
    } else {
        dVar4 = (double)uVar2;
    }
    if (dVar7 < dVar4) {
        if (dVar4 < dVar5) {
            uVar3 = uVar3 * uVar1;
            if ((int64_t)uVar3 < 0) {
                fVar9 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
                fVar9 = fVar9 + fVar9;
            } else {
                fVar9 = (float)uVar3;
            }
            if (0.0 <= fVar9) {
                if ((fVar10 < 0.0) || (fVar8 < 0.0)) {
                    dVar6 = (double)fcn.180491150((double)((uint64_t)dVar4 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar5 ^ 0x8000000000000000));
                    dVar7 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar5 ^ 0x8000000000000000));
                    fVar9 = 1.0 - (float)(dVar6 / dVar7);
                } else {
                    dVar6 = (double)fcn.180491150(dVar4 / dVar7);
                    dVar7 = (double)fcn.180491150(dVar5 / dVar7);
                    fVar9 = (float)(dVar6 / dVar7);
                }
            } else {
                fVar9 = (float)((uint32_t)fVar10 ^ 0x80000000) / (fVar8 - fVar10);
                if (arg2 < 0) {
                    fVar11 = (float)((uint64_t)arg2 >> 1 | (uint64_t)((uint32_t)arg2 & 1));
                    fVar11 = fVar11 + fVar11;
                } else {
                    fVar11 = (float)arg2;
                }
                if (fVar11 != 0.0) {
                    if (0.0 <= fVar11) {
                        dVar7 = (double)fcn.180491150(dVar4 / dVar6);
                        dVar6 = (double)fcn.180491150(dVar5 / dVar6);
                        fVar9 = (float)(dVar7 / dVar6) * (1.0 - (fVar9 + (float)arg_30h)) + fVar9 + (float)arg_30h;
                    } else {
                        dVar5 = (double)fcn.180491150((double)((uint64_t)dVar4 ^ 0x8000000000000000) / dVar6);
                        dVar6 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) / dVar6);
                        fVar9 = (1.0 - (float)(dVar5 / dVar6)) * (fVar9 - (float)arg_30h);
                    }
                }
            }
        } else {
            fVar9 = 1.0;
        }
    }
    if ((uint64_t)arg3 <= (uint64_t)arg4) {
        return fVar9;
    }
    return 1.0 - fVar9;
}

// ============================================================
// Function: FUN_18014e62a
// Address: 0x18014e62a
// Size: 398 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

float fcn.18014e5c0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h
                   , int64_t arg_88h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    double dVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (arg3 == arg4) {
        return 0.0;
    }
    if ((uint64_t)arg3 < (uint64_t)arg4) {
        uVar2 = arg3;
        if (((uint64_t)arg3 <= (uint64_t)arg2) && (uVar2 = arg2, (uint64_t)arg4 < (uint64_t)arg2)) {
            uVar2 = arg4;
        }
    } else {
        uVar2 = arg4;
        if (((uint64_t)arg4 <= (uint64_t)arg2) && (uVar2 = arg2, (uint64_t)arg3 < (uint64_t)arg2)) {
            uVar2 = arg3;
        }
    }
    fVar9 = 0.0;
    if ((float)arg_28h <= 0.0) {
        return (float)(uVar2 - arg3) / (float)(arg4 - arg3);
    }
    uVar3 = arg3;
    uVar1 = arg4;
    if ((uint64_t)arg3 <= (uint64_t)arg4) {
        uVar3 = arg4;
        uVar1 = arg3;
    }
    dVar6 = (double)(float)arg_28h;
    if ((int64_t)uVar1 < 0) {
        dVar7 = (double)(uVar1 >> 1 | (uint64_t)((uint32_t)uVar1 & 1));
        dVar7 = dVar7 + dVar7;
    } else {
        dVar7 = (double)uVar1;
    }
    fVar11 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
    if ((int64_t)uVar1 < 0) {
        fVar10 = (float)(uVar1 >> 1 | (uint64_t)((uint32_t)uVar1 & 1));
        fVar10 = fVar10 + fVar10;
    } else {
        fVar10 = (float)uVar1;
    }
    if ((double)((uint64_t)dVar7 & 0x7fffffffffffffff) < dVar6) {
        fVar8 = (float)arg_28h;
        if (fVar10 < 0.0) {
            fVar8 = fVar11;
        }
        dVar7 = (double)fVar8;
    }
    if ((int64_t)uVar3 < 0) {
        dVar5 = (double)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
        dVar5 = dVar5 + dVar5;
        fVar8 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
        fVar8 = fVar8 + fVar8;
    } else {
        dVar5 = (double)uVar3;
        fVar8 = (float)uVar3;
    }
    if ((double)((uint64_t)dVar5 & 0x7fffffffffffffff) < dVar6) {
        if (fVar8 < 0.0) {
            arg_28h._0_4_ = fVar11;
        }
        dVar5 = (double)(float)arg_28h;
    }
    if ((fVar10 != 0.0) || (0.0 <= fVar8)) {
        if ((fVar8 == 0.0) && (fVar10 < 0.0)) {
            dVar5 = (double)fVar11;
        }
    } else {
        dVar7 = (double)fVar11;
    }
    if ((int64_t)uVar2 < 0) {
        dVar4 = (double)(uVar2 >> 1 | (uint64_t)((uint32_t)uVar2 & 1));
        dVar4 = dVar4 + dVar4;
    } else {
        dVar4 = (double)uVar2;
    }
    if (dVar7 < dVar4) {
        if (dVar4 < dVar5) {
            uVar3 = uVar3 * uVar1;
            if ((int64_t)uVar3 < 0) {
                fVar9 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
                fVar9 = fVar9 + fVar9;
            } else {
                fVar9 = (float)uVar3;
            }
            if (0.0 <= fVar9) {
                if ((fVar10 < 0.0) || (fVar8 < 0.0)) {
                    dVar6 = (double)fcn.180491150((double)((uint64_t)dVar4 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar5 ^ 0x8000000000000000));
                    dVar7 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar5 ^ 0x8000000000000000));
                    fVar9 = 1.0 - (float)(dVar6 / dVar7);
                } else {
                    dVar6 = (double)fcn.180491150(dVar4 / dVar7);
                    dVar7 = (double)fcn.180491150(dVar5 / dVar7);
                    fVar9 = (float)(dVar6 / dVar7);
                }
            } else {
                fVar9 = (float)((uint32_t)fVar10 ^ 0x80000000) / (fVar8 - fVar10);
                if (arg2 < 0) {
                    fVar11 = (float)((uint64_t)arg2 >> 1 | (uint64_t)((uint32_t)arg2 & 1));
                    fVar11 = fVar11 + fVar11;
                } else {
                    fVar11 = (float)arg2;
                }
                if (fVar11 != 0.0) {
                    if (0.0 <= fVar11) {
                        dVar7 = (double)fcn.180491150(dVar4 / dVar6);
                        dVar6 = (double)fcn.180491150(dVar5 / dVar6);
                        fVar9 = (float)(dVar7 / dVar6) * (1.0 - (fVar9 + (float)arg_30h)) + fVar9 + (float)arg_30h;
                    } else {
                        dVar5 = (double)fcn.180491150((double)((uint64_t)dVar4 ^ 0x8000000000000000) / dVar6);
                        dVar6 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) / dVar6);
                        fVar9 = (1.0 - (float)(dVar5 / dVar6)) * (fVar9 - (float)arg_30h);
                    }
                }
            }
        } else {
            fVar9 = 1.0;
        }
    }
    if ((uint64_t)arg3 <= (uint64_t)arg4) {
        return fVar9;
    }
    return 1.0 - fVar9;
}

// ============================================================
// Function: FUN_18014e7b8
// Address: 0x18014e7b8
// Size: 459 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

float fcn.18014e5c0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h
                   , int64_t arg_88h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    double dVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (arg3 == arg4) {
        return 0.0;
    }
    if ((uint64_t)arg3 < (uint64_t)arg4) {
        uVar2 = arg3;
        if (((uint64_t)arg3 <= (uint64_t)arg2) && (uVar2 = arg2, (uint64_t)arg4 < (uint64_t)arg2)) {
            uVar2 = arg4;
        }
    } else {
        uVar2 = arg4;
        if (((uint64_t)arg4 <= (uint64_t)arg2) && (uVar2 = arg2, (uint64_t)arg3 < (uint64_t)arg2)) {
            uVar2 = arg3;
        }
    }
    fVar9 = 0.0;
    if ((float)arg_28h <= 0.0) {
        return (float)(uVar2 - arg3) / (float)(arg4 - arg3);
    }
    uVar3 = arg3;
    uVar1 = arg4;
    if ((uint64_t)arg3 <= (uint64_t)arg4) {
        uVar3 = arg4;
        uVar1 = arg3;
    }
    dVar6 = (double)(float)arg_28h;
    if ((int64_t)uVar1 < 0) {
        dVar7 = (double)(uVar1 >> 1 | (uint64_t)((uint32_t)uVar1 & 1));
        dVar7 = dVar7 + dVar7;
    } else {
        dVar7 = (double)uVar1;
    }
    fVar11 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
    if ((int64_t)uVar1 < 0) {
        fVar10 = (float)(uVar1 >> 1 | (uint64_t)((uint32_t)uVar1 & 1));
        fVar10 = fVar10 + fVar10;
    } else {
        fVar10 = (float)uVar1;
    }
    if ((double)((uint64_t)dVar7 & 0x7fffffffffffffff) < dVar6) {
        fVar8 = (float)arg_28h;
        if (fVar10 < 0.0) {
            fVar8 = fVar11;
        }
        dVar7 = (double)fVar8;
    }
    if ((int64_t)uVar3 < 0) {
        dVar5 = (double)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
        dVar5 = dVar5 + dVar5;
        fVar8 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
        fVar8 = fVar8 + fVar8;
    } else {
        dVar5 = (double)uVar3;
        fVar8 = (float)uVar3;
    }
    if ((double)((uint64_t)dVar5 & 0x7fffffffffffffff) < dVar6) {
        if (fVar8 < 0.0) {
            arg_28h._0_4_ = fVar11;
        }
        dVar5 = (double)(float)arg_28h;
    }
    if ((fVar10 != 0.0) || (0.0 <= fVar8)) {
        if ((fVar8 == 0.0) && (fVar10 < 0.0)) {
            dVar5 = (double)fVar11;
        }
    } else {
        dVar7 = (double)fVar11;
    }
    if ((int64_t)uVar2 < 0) {
        dVar4 = (double)(uVar2 >> 1 | (uint64_t)((uint32_t)uVar2 & 1));
        dVar4 = dVar4 + dVar4;
    } else {
        dVar4 = (double)uVar2;
    }
    if (dVar7 < dVar4) {
        if (dVar4 < dVar5) {
            uVar3 = uVar3 * uVar1;
            if ((int64_t)uVar3 < 0) {
                fVar9 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
                fVar9 = fVar9 + fVar9;
            } else {
                fVar9 = (float)uVar3;
            }
            if (0.0 <= fVar9) {
                if ((fVar10 < 0.0) || (fVar8 < 0.0)) {
                    dVar6 = (double)fcn.180491150((double)((uint64_t)dVar4 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar5 ^ 0x8000000000000000));
                    dVar7 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar5 ^ 0x8000000000000000));
                    fVar9 = 1.0 - (float)(dVar6 / dVar7);
                } else {
                    dVar6 = (double)fcn.180491150(dVar4 / dVar7);
                    dVar7 = (double)fcn.180491150(dVar5 / dVar7);
                    fVar9 = (float)(dVar6 / dVar7);
                }
            } else {
                fVar9 = (float)((uint32_t)fVar10 ^ 0x80000000) / (fVar8 - fVar10);
                if (arg2 < 0) {
                    fVar11 = (float)((uint64_t)arg2 >> 1 | (uint64_t)((uint32_t)arg2 & 1));
                    fVar11 = fVar11 + fVar11;
                } else {
                    fVar11 = (float)arg2;
                }
                if (fVar11 != 0.0) {
                    if (0.0 <= fVar11) {
                        dVar7 = (double)fcn.180491150(dVar4 / dVar6);
                        dVar6 = (double)fcn.180491150(dVar5 / dVar6);
                        fVar9 = (float)(dVar7 / dVar6) * (1.0 - (fVar9 + (float)arg_30h)) + fVar9 + (float)arg_30h;
                    } else {
                        dVar5 = (double)fcn.180491150((double)((uint64_t)dVar4 ^ 0x8000000000000000) / dVar6);
                        dVar6 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) / dVar6);
                        fVar9 = (1.0 - (float)(dVar5 / dVar6)) * (fVar9 - (float)arg_30h);
                    }
                }
            }
        } else {
            fVar9 = 1.0;
        }
    }
    if ((uint64_t)arg3 <= (uint64_t)arg4) {
        return fVar9;
    }
    return 1.0 - fVar9;
}

// ============================================================
// Function: FUN_18014e983
// Address: 0x18014e983
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

float fcn.18014e5c0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h
                   , int64_t arg_88h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    double dVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (arg3 == arg4) {
        return 0.0;
    }
    if ((uint64_t)arg3 < (uint64_t)arg4) {
        uVar2 = arg3;
        if (((uint64_t)arg3 <= (uint64_t)arg2) && (uVar2 = arg2, (uint64_t)arg4 < (uint64_t)arg2)) {
            uVar2 = arg4;
        }
    } else {
        uVar2 = arg4;
        if (((uint64_t)arg4 <= (uint64_t)arg2) && (uVar2 = arg2, (uint64_t)arg3 < (uint64_t)arg2)) {
            uVar2 = arg3;
        }
    }
    fVar9 = 0.0;
    if ((float)arg_28h <= 0.0) {
        return (float)(uVar2 - arg3) / (float)(arg4 - arg3);
    }
    uVar3 = arg3;
    uVar1 = arg4;
    if ((uint64_t)arg3 <= (uint64_t)arg4) {
        uVar3 = arg4;
        uVar1 = arg3;
    }
    dVar6 = (double)(float)arg_28h;
    if ((int64_t)uVar1 < 0) {
        dVar7 = (double)(uVar1 >> 1 | (uint64_t)((uint32_t)uVar1 & 1));
        dVar7 = dVar7 + dVar7;
    } else {
        dVar7 = (double)uVar1;
    }
    fVar11 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
    if ((int64_t)uVar1 < 0) {
        fVar10 = (float)(uVar1 >> 1 | (uint64_t)((uint32_t)uVar1 & 1));
        fVar10 = fVar10 + fVar10;
    } else {
        fVar10 = (float)uVar1;
    }
    if ((double)((uint64_t)dVar7 & 0x7fffffffffffffff) < dVar6) {
        fVar8 = (float)arg_28h;
        if (fVar10 < 0.0) {
            fVar8 = fVar11;
        }
        dVar7 = (double)fVar8;
    }
    if ((int64_t)uVar3 < 0) {
        dVar5 = (double)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
        dVar5 = dVar5 + dVar5;
        fVar8 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
        fVar8 = fVar8 + fVar8;
    } else {
        dVar5 = (double)uVar3;
        fVar8 = (float)uVar3;
    }
    if ((double)((uint64_t)dVar5 & 0x7fffffffffffffff) < dVar6) {
        if (fVar8 < 0.0) {
            arg_28h._0_4_ = fVar11;
        }
        dVar5 = (double)(float)arg_28h;
    }
    if ((fVar10 != 0.0) || (0.0 <= fVar8)) {
        if ((fVar8 == 0.0) && (fVar10 < 0.0)) {
            dVar5 = (double)fVar11;
        }
    } else {
        dVar7 = (double)fVar11;
    }
    if ((int64_t)uVar2 < 0) {
        dVar4 = (double)(uVar2 >> 1 | (uint64_t)((uint32_t)uVar2 & 1));
        dVar4 = dVar4 + dVar4;
    } else {
        dVar4 = (double)uVar2;
    }
    if (dVar7 < dVar4) {
        if (dVar4 < dVar5) {
            uVar3 = uVar3 * uVar1;
            if ((int64_t)uVar3 < 0) {
                fVar9 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
                fVar9 = fVar9 + fVar9;
            } else {
                fVar9 = (float)uVar3;
            }
            if (0.0 <= fVar9) {
                if ((fVar10 < 0.0) || (fVar8 < 0.0)) {
                    dVar6 = (double)fcn.180491150((double)((uint64_t)dVar4 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar5 ^ 0x8000000000000000));
                    dVar7 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar5 ^ 0x8000000000000000));
                    fVar9 = 1.0 - (float)(dVar6 / dVar7);
                } else {
                    dVar6 = (double)fcn.180491150(dVar4 / dVar7);
                    dVar7 = (double)fcn.180491150(dVar5 / dVar7);
                    fVar9 = (float)(dVar6 / dVar7);
                }
            } else {
                fVar9 = (float)((uint32_t)fVar10 ^ 0x80000000) / (fVar8 - fVar10);
                if (arg2 < 0) {
                    fVar11 = (float)((uint64_t)arg2 >> 1 | (uint64_t)((uint32_t)arg2 & 1));
                    fVar11 = fVar11 + fVar11;
                } else {
                    fVar11 = (float)arg2;
                }
                if (fVar11 != 0.0) {
                    if (0.0 <= fVar11) {
                        dVar7 = (double)fcn.180491150(dVar4 / dVar6);
                        dVar6 = (double)fcn.180491150(dVar5 / dVar6);
                        fVar9 = (float)(dVar7 / dVar6) * (1.0 - (fVar9 + (float)arg_30h)) + fVar9 + (float)arg_30h;
                    } else {
                        dVar5 = (double)fcn.180491150((double)((uint64_t)dVar4 ^ 0x8000000000000000) / dVar6);
                        dVar6 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) / dVar6);
                        fVar9 = (1.0 - (float)(dVar5 / dVar6)) * (fVar9 - (float)arg_30h);
                    }
                }
            }
        } else {
            fVar9 = 1.0;
        }
    }
    if ((uint64_t)arg3 <= (uint64_t)arg4) {
        return fVar9;
    }
    return 1.0 - fVar9;
}

// ============================================================
// Function: FUN_18014e9a3
// Address: 0x18014e9a3
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

float fcn.18014e5c0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h
                   , int64_t arg_88h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    double dVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (arg3 == arg4) {
        return 0.0;
    }
    if ((uint64_t)arg3 < (uint64_t)arg4) {
        uVar2 = arg3;
        if (((uint64_t)arg3 <= (uint64_t)arg2) && (uVar2 = arg2, (uint64_t)arg4 < (uint64_t)arg2)) {
            uVar2 = arg4;
        }
    } else {
        uVar2 = arg4;
        if (((uint64_t)arg4 <= (uint64_t)arg2) && (uVar2 = arg2, (uint64_t)arg3 < (uint64_t)arg2)) {
            uVar2 = arg3;
        }
    }
    fVar9 = 0.0;
    if ((float)arg_28h <= 0.0) {
        return (float)(uVar2 - arg3) / (float)(arg4 - arg3);
    }
    uVar3 = arg3;
    uVar1 = arg4;
    if ((uint64_t)arg3 <= (uint64_t)arg4) {
        uVar3 = arg4;
        uVar1 = arg3;
    }
    dVar6 = (double)(float)arg_28h;
    if ((int64_t)uVar1 < 0) {
        dVar7 = (double)(uVar1 >> 1 | (uint64_t)((uint32_t)uVar1 & 1));
        dVar7 = dVar7 + dVar7;
    } else {
        dVar7 = (double)uVar1;
    }
    fVar11 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
    if ((int64_t)uVar1 < 0) {
        fVar10 = (float)(uVar1 >> 1 | (uint64_t)((uint32_t)uVar1 & 1));
        fVar10 = fVar10 + fVar10;
    } else {
        fVar10 = (float)uVar1;
    }
    if ((double)((uint64_t)dVar7 & 0x7fffffffffffffff) < dVar6) {
        fVar8 = (float)arg_28h;
        if (fVar10 < 0.0) {
            fVar8 = fVar11;
        }
        dVar7 = (double)fVar8;
    }
    if ((int64_t)uVar3 < 0) {
        dVar5 = (double)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
        dVar5 = dVar5 + dVar5;
        fVar8 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
        fVar8 = fVar8 + fVar8;
    } else {
        dVar5 = (double)uVar3;
        fVar8 = (float)uVar3;
    }
    if ((double)((uint64_t)dVar5 & 0x7fffffffffffffff) < dVar6) {
        if (fVar8 < 0.0) {
            arg_28h._0_4_ = fVar11;
        }
        dVar5 = (double)(float)arg_28h;
    }
    if ((fVar10 != 0.0) || (0.0 <= fVar8)) {
        if ((fVar8 == 0.0) && (fVar10 < 0.0)) {
            dVar5 = (double)fVar11;
        }
    } else {
        dVar7 = (double)fVar11;
    }
    if ((int64_t)uVar2 < 0) {
        dVar4 = (double)(uVar2 >> 1 | (uint64_t)((uint32_t)uVar2 & 1));
        dVar4 = dVar4 + dVar4;
    } else {
        dVar4 = (double)uVar2;
    }
    if (dVar7 < dVar4) {
        if (dVar4 < dVar5) {
            uVar3 = uVar3 * uVar1;
            if ((int64_t)uVar3 < 0) {
                fVar9 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
                fVar9 = fVar9 + fVar9;
            } else {
                fVar9 = (float)uVar3;
            }
            if (0.0 <= fVar9) {
                if ((fVar10 < 0.0) || (fVar8 < 0.0)) {
                    dVar6 = (double)fcn.180491150((double)((uint64_t)dVar4 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar5 ^ 0x8000000000000000));
                    dVar7 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar5 ^ 0x8000000000000000));
                    fVar9 = 1.0 - (float)(dVar6 / dVar7);
                } else {
                    dVar6 = (double)fcn.180491150(dVar4 / dVar7);
                    dVar7 = (double)fcn.180491150(dVar5 / dVar7);
                    fVar9 = (float)(dVar6 / dVar7);
                }
            } else {
                fVar9 = (float)((uint32_t)fVar10 ^ 0x80000000) / (fVar8 - fVar10);
                if (arg2 < 0) {
                    fVar11 = (float)((uint64_t)arg2 >> 1 | (uint64_t)((uint32_t)arg2 & 1));
                    fVar11 = fVar11 + fVar11;
                } else {
                    fVar11 = (float)arg2;
                }
                if (fVar11 != 0.0) {
                    if (0.0 <= fVar11) {
                        dVar7 = (double)fcn.180491150(dVar4 / dVar6);
                        dVar6 = (double)fcn.180491150(dVar5 / dVar6);
                        fVar9 = (float)(dVar7 / dVar6) * (1.0 - (fVar9 + (float)arg_30h)) + fVar9 + (float)arg_30h;
                    } else {
                        dVar5 = (double)fcn.180491150((double)((uint64_t)dVar4 ^ 0x8000000000000000) / dVar6);
                        dVar6 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) / dVar6);
                        fVar9 = (1.0 - (float)(dVar5 / dVar6)) * (fVar9 - (float)arg_30h);
                    }
                }
            }
        } else {
            fVar9 = 1.0;
        }
    }
    if ((uint64_t)arg3 <= (uint64_t)arg4) {
        return fVar9;
    }
    return 1.0 - fVar9;
}

// ============================================================
// Function: FUN_18014e9bd
// Address: 0x18014e9bd
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

float fcn.18014e5c0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h
                   , int64_t arg_88h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    double dVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (arg3 == arg4) {
        return 0.0;
    }
    if ((uint64_t)arg3 < (uint64_t)arg4) {
        uVar2 = arg3;
        if (((uint64_t)arg3 <= (uint64_t)arg2) && (uVar2 = arg2, (uint64_t)arg4 < (uint64_t)arg2)) {
            uVar2 = arg4;
        }
    } else {
        uVar2 = arg4;
        if (((uint64_t)arg4 <= (uint64_t)arg2) && (uVar2 = arg2, (uint64_t)arg3 < (uint64_t)arg2)) {
            uVar2 = arg3;
        }
    }
    fVar9 = 0.0;
    if ((float)arg_28h <= 0.0) {
        return (float)(uVar2 - arg3) / (float)(arg4 - arg3);
    }
    uVar3 = arg3;
    uVar1 = arg4;
    if ((uint64_t)arg3 <= (uint64_t)arg4) {
        uVar3 = arg4;
        uVar1 = arg3;
    }
    dVar6 = (double)(float)arg_28h;
    if ((int64_t)uVar1 < 0) {
        dVar7 = (double)(uVar1 >> 1 | (uint64_t)((uint32_t)uVar1 & 1));
        dVar7 = dVar7 + dVar7;
    } else {
        dVar7 = (double)uVar1;
    }
    fVar11 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
    if ((int64_t)uVar1 < 0) {
        fVar10 = (float)(uVar1 >> 1 | (uint64_t)((uint32_t)uVar1 & 1));
        fVar10 = fVar10 + fVar10;
    } else {
        fVar10 = (float)uVar1;
    }
    if ((double)((uint64_t)dVar7 & 0x7fffffffffffffff) < dVar6) {
        fVar8 = (float)arg_28h;
        if (fVar10 < 0.0) {
            fVar8 = fVar11;
        }
        dVar7 = (double)fVar8;
    }
    if ((int64_t)uVar3 < 0) {
        dVar5 = (double)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
        dVar5 = dVar5 + dVar5;
        fVar8 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
        fVar8 = fVar8 + fVar8;
    } else {
        dVar5 = (double)uVar3;
        fVar8 = (float)uVar3;
    }
    if ((double)((uint64_t)dVar5 & 0x7fffffffffffffff) < dVar6) {
        if (fVar8 < 0.0) {
            arg_28h._0_4_ = fVar11;
        }
        dVar5 = (double)(float)arg_28h;
    }
    if ((fVar10 != 0.0) || (0.0 <= fVar8)) {
        if ((fVar8 == 0.0) && (fVar10 < 0.0)) {
            dVar5 = (double)fVar11;
        }
    } else {
        dVar7 = (double)fVar11;
    }
    if ((int64_t)uVar2 < 0) {
        dVar4 = (double)(uVar2 >> 1 | (uint64_t)((uint32_t)uVar2 & 1));
        dVar4 = dVar4 + dVar4;
    } else {
        dVar4 = (double)uVar2;
    }
    if (dVar7 < dVar4) {
        if (dVar4 < dVar5) {
            uVar3 = uVar3 * uVar1;
            if ((int64_t)uVar3 < 0) {
                fVar9 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
                fVar9 = fVar9 + fVar9;
            } else {
                fVar9 = (float)uVar3;
            }
            if (0.0 <= fVar9) {
                if ((fVar10 < 0.0) || (fVar8 < 0.0)) {
                    dVar6 = (double)fcn.180491150((double)((uint64_t)dVar4 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar5 ^ 0x8000000000000000));
                    dVar7 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar5 ^ 0x8000000000000000));
                    fVar9 = 1.0 - (float)(dVar6 / dVar7);
                } else {
                    dVar6 = (double)fcn.180491150(dVar4 / dVar7);
                    dVar7 = (double)fcn.180491150(dVar5 / dVar7);
                    fVar9 = (float)(dVar6 / dVar7);
                }
            } else {
                fVar9 = (float)((uint32_t)fVar10 ^ 0x80000000) / (fVar8 - fVar10);
                if (arg2 < 0) {
                    fVar11 = (float)((uint64_t)arg2 >> 1 | (uint64_t)((uint32_t)arg2 & 1));
                    fVar11 = fVar11 + fVar11;
                } else {
                    fVar11 = (float)arg2;
                }
                if (fVar11 != 0.0) {
                    if (0.0 <= fVar11) {
                        dVar7 = (double)fcn.180491150(dVar4 / dVar6);
                        dVar6 = (double)fcn.180491150(dVar5 / dVar6);
                        fVar9 = (float)(dVar7 / dVar6) * (1.0 - (fVar9 + (float)arg_30h)) + fVar9 + (float)arg_30h;
                    } else {
                        dVar5 = (double)fcn.180491150((double)((uint64_t)dVar4 ^ 0x8000000000000000) / dVar6);
                        dVar6 = (double)fcn.180491150((double)((uint64_t)dVar7 ^ 0x8000000000000000) / dVar6);
                        fVar9 = (1.0 - (float)(dVar5 / dVar6)) * (fVar9 - (float)arg_30h);
                    }
                }
            }
        } else {
            fVar9 = 1.0;
        }
    }
    if ((uint64_t)arg3 <= (uint64_t)arg4) {
        return fVar9;
    }
    return 1.0 - fVar9;
}

// ============================================================
// Function: FUN_18014e9f0
// Address: 0x18014e9f0
// Size: 61 bytes
// ============================================================
int64_t fcn.18014e9f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h,
                     int64_t arg_30h)
{
    double dVar1;
    double dVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    double dVar6;
    double dVar7;
    float in_XMM1_Da;
    float fVar8;
    float fVar9;
    float fVar10;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if ((in_XMM1_Da <= 0.0) || (arg3 == arg4)) {
        return arg3;
    }
    if (1.0 <= in_XMM1_Da) {
        return arg4;
    }
    uVar5 = (uint32_t)arg3;
    if ((float)arg_28h <= 0.0) {
        if ((int32_t)arg1 - 8U < 2) {
            uVar3 = arg4 - arg3;
            if ((int64_t)uVar3 < 0) {
                fVar10 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
                fVar10 = fVar10 + fVar10;
            } else {
                fVar10 = (float)uVar3;
            }
            if (arg3 < 0) {
                fVar9 = (float)((uint64_t)arg3 >> 1 | (uint64_t)(uVar5 & 1));
                fVar9 = fVar9 + fVar9;
            } else {
                fVar9 = (float)arg3;
            }
            fVar9 = fVar10 * in_XMM1_Da + fVar9;
            iVar4 = 0;
            if ((9.223372e+18 <= fVar9) && (fVar9 = fVar9 - 9.223372e+18, fVar9 < 9.223372e+18)) {
                iVar4 = -0x8000000000000000;
            }
            iVar4 = (int64_t)fVar9 + iVar4;
        } else {
            iVar4 = 0;
            if (in_XMM1_Da < 1.0) {
                if ((uint64_t)arg4 < (uint64_t)arg3) {
                    fVar10 = -0.5;
                } else {
                    fVar10 = 0.5;
                }
                iVar4 = (int64_t)((float)(arg4 - arg3) * in_XMM1_Da + fVar10) + arg3;
            }
        }
    } else {
        dVar7 = (double)(float)arg_28h;
        if (arg3 < 0) {
            dVar6 = (double)((uint64_t)arg3 >> 1 | (uint64_t)(uVar5 & 1));
            dVar6 = dVar6 + dVar6;
        } else {
            dVar6 = (double)arg3;
        }
        fVar10 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        if (arg3 < 0) {
            fVar9 = (float)((uint64_t)arg3 >> 1 | (uint64_t)(uVar5 & 1));
            fVar9 = fVar9 + fVar9;
        } else {
            fVar9 = (float)arg3;
        }
        if ((double)((uint64_t)dVar6 & 0x7fffffffffffffff) < dVar7) {
            fVar8 = (float)arg_28h;
            if (fVar9 < 0.0) {
                fVar8 = fVar10;
            }
            dVar6 = (double)fVar8;
        }
        if (arg4 < 0) {
            dVar1 = (double)((uint64_t)arg4 >> 1 | (uint64_t)((uint32_t)arg4 & 1));
            dVar1 = dVar1 + dVar1;
            fVar8 = (float)((uint64_t)arg4 >> 1 | (uint64_t)((uint32_t)arg4 & 1));
            fVar8 = fVar8 + fVar8;
        } else {
            dVar1 = (double)arg4;
            fVar8 = (float)arg4;
        }
        if ((double)((uint64_t)dVar1 & 0x7fffffffffffffff) < dVar7) {
            if (fVar8 < 0.0) {
                arg_28h._0_4_ = fVar10;
            }
            dVar1 = (double)(float)arg_28h;
        }
        dVar2 = dVar6;
        if ((uint64_t)arg4 < (uint64_t)arg3) {
            dVar2 = dVar1;
            dVar1 = dVar6;
        }
        if ((fVar8 == 0.0) && (fVar9 < 0.0)) {
            dVar1 = (double)fVar10;
        }
        if ((uint64_t)arg4 < (uint64_t)arg3) {
            in_XMM1_Da = 1.0 - in_XMM1_Da;
        }
        uVar3 = arg3 * arg4;
        if ((int64_t)uVar3 < 0) {
            fVar10 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
            fVar10 = fVar10 + fVar10;
        } else {
            fVar10 = (float)uVar3;
        }
        if (0.0 <= fVar10) {
            if ((fVar9 < 0.0) || (fVar8 < 0.0)) {
                dVar7 = (double)fcn.180491d70((double)((uint64_t)dVar2 ^ 0x8000000000000000) /
                                              (double)((uint64_t)dVar1 ^ 0x8000000000000000), (double)(1.0 - in_XMM1_Da)
                                             );
                dVar6 = (double)((uint64_t)(dVar7 * (double)((uint64_t)dVar1 ^ 0x8000000000000000)) ^ 0x8000000000000000
                                );
            } else {
                dVar6 = (double)fcn.180491d70(dVar1 / dVar2, (double)in_XMM1_Da);
                dVar6 = dVar6 * dVar2;
            }
        } else {
            if ((uint64_t)arg3 < (uint64_t)arg4) {
                arg4 = arg3;
            }
            if (arg4 < 0) {
                fVar10 = (float)((uint64_t)arg4 >> 1 | (uint64_t)((uint32_t)arg4 & 1));
                fVar10 = fVar10 + fVar10;
            } else {
                fVar10 = (float)arg4;
            }
            fVar10 = (float)((uint32_t)fVar10 ^ 0x80000000) / (float)((uint32_t)(fVar8 - fVar9) & 0x7fffffff);
            fVar9 = fVar10 + (float)arg_30h;
            if ((fVar10 - (float)arg_30h <= in_XMM1_Da) && (in_XMM1_Da <= fVar9)) {
                return 0;
            }
            if (fVar10 <= in_XMM1_Da) {
                dVar6 = (double)fcn.180491d70(dVar1 / dVar7, (double)((in_XMM1_Da - fVar9) / (1.0 - fVar9)));
                dVar6 = dVar6 * dVar7;
            } else {
                dVar6 = (double)fcn.180491d70((double)((uint64_t)dVar2 ^ 0x8000000000000000) / dVar7, 
                                              (double)(1.0 - in_XMM1_Da / (fVar10 - (float)arg_30h)));
                dVar6 = (double)((uint64_t)(dVar6 * dVar7) ^ 0x8000000000000000);
            }
        }
        iVar4 = 0;
        if ((9.223372036854776e+18 <= dVar6) && (dVar6 = dVar6 - 9.223372036854776e+18, dVar6 < 9.223372036854776e+18))
        {
            iVar4 = -0x8000000000000000;
        }
        iVar4 = (int64_t)dVar6 + iVar4;
    }
    return iVar4;
}

// ============================================================
// Function: FUN_18014ea2d
// Address: 0x18014ea2d
// Size: 28 bytes
// ============================================================
int64_t fcn.18014e9f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h,
                     int64_t arg_30h)
{
    double dVar1;
    double dVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    double dVar6;
    double dVar7;
    float in_XMM1_Da;
    float fVar8;
    float fVar9;
    float fVar10;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if ((in_XMM1_Da <= 0.0) || (arg3 == arg4)) {
        return arg3;
    }
    if (1.0 <= in_XMM1_Da) {
        return arg4;
    }
    uVar5 = (uint32_t)arg3;
    if ((float)arg_28h <= 0.0) {
        if ((int32_t)arg1 - 8U < 2) {
            uVar3 = arg4 - arg3;
            if ((int64_t)uVar3 < 0) {
                fVar10 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
                fVar10 = fVar10 + fVar10;
            } else {
                fVar10 = (float)uVar3;
            }
            if (arg3 < 0) {
                fVar9 = (float)((uint64_t)arg3 >> 1 | (uint64_t)(uVar5 & 1));
                fVar9 = fVar9 + fVar9;
            } else {
                fVar9 = (float)arg3;
            }
            fVar9 = fVar10 * in_XMM1_Da + fVar9;
            iVar4 = 0;
            if ((9.223372e+18 <= fVar9) && (fVar9 = fVar9 - 9.223372e+18, fVar9 < 9.223372e+18)) {
                iVar4 = -0x8000000000000000;
            }
            iVar4 = (int64_t)fVar9 + iVar4;
        } else {
            iVar4 = 0;
            if (in_XMM1_Da < 1.0) {
                if ((uint64_t)arg4 < (uint64_t)arg3) {
                    fVar10 = -0.5;
                } else {
                    fVar10 = 0.5;
                }
                iVar4 = (int64_t)((float)(arg4 - arg3) * in_XMM1_Da + fVar10) + arg3;
            }
        }
    } else {
        dVar7 = (double)(float)arg_28h;
        if (arg3 < 0) {
            dVar6 = (double)((uint64_t)arg3 >> 1 | (uint64_t)(uVar5 & 1));
            dVar6 = dVar6 + dVar6;
        } else {
            dVar6 = (double)arg3;
        }
        fVar10 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        if (arg3 < 0) {
            fVar9 = (float)((uint64_t)arg3 >> 1 | (uint64_t)(uVar5 & 1));
            fVar9 = fVar9 + fVar9;
        } else {
            fVar9 = (float)arg3;
        }
        if ((double)((uint64_t)dVar6 & 0x7fffffffffffffff) < dVar7) {
            fVar8 = (float)arg_28h;
            if (fVar9 < 0.0) {
                fVar8 = fVar10;
            }
            dVar6 = (double)fVar8;
        }
        if (arg4 < 0) {
            dVar1 = (double)((uint64_t)arg4 >> 1 | (uint64_t)((uint32_t)arg4 & 1));
            dVar1 = dVar1 + dVar1;
            fVar8 = (float)((uint64_t)arg4 >> 1 | (uint64_t)((uint32_t)arg4 & 1));
            fVar8 = fVar8 + fVar8;
        } else {
            dVar1 = (double)arg4;
            fVar8 = (float)arg4;
        }
        if ((double)((uint64_t)dVar1 & 0x7fffffffffffffff) < dVar7) {
            if (fVar8 < 0.0) {
                arg_28h._0_4_ = fVar10;
            }
            dVar1 = (double)(float)arg_28h;
        }
        dVar2 = dVar6;
        if ((uint64_t)arg4 < (uint64_t)arg3) {
            dVar2 = dVar1;
            dVar1 = dVar6;
        }
        if ((fVar8 == 0.0) && (fVar9 < 0.0)) {
            dVar1 = (double)fVar10;
        }
        if ((uint64_t)arg4 < (uint64_t)arg3) {
            in_XMM1_Da = 1.0 - in_XMM1_Da;
        }
        uVar3 = arg3 * arg4;
        if ((int64_t)uVar3 < 0) {
            fVar10 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
            fVar10 = fVar10 + fVar10;
        } else {
            fVar10 = (float)uVar3;
        }
        if (0.0 <= fVar10) {
            if ((fVar9 < 0.0) || (fVar8 < 0.0)) {
                dVar7 = (double)fcn.180491d70((double)((uint64_t)dVar2 ^ 0x8000000000000000) /
                                              (double)((uint64_t)dVar1 ^ 0x8000000000000000), (double)(1.0 - in_XMM1_Da)
                                             );
                dVar6 = (double)((uint64_t)(dVar7 * (double)((uint64_t)dVar1 ^ 0x8000000000000000)) ^ 0x8000000000000000
                                );
            } else {
                dVar6 = (double)fcn.180491d70(dVar1 / dVar2, (double)in_XMM1_Da);
                dVar6 = dVar6 * dVar2;
            }
        } else {
            if ((uint64_t)arg3 < (uint64_t)arg4) {
                arg4 = arg3;
            }
            if (arg4 < 0) {
                fVar10 = (float)((uint64_t)arg4 >> 1 | (uint64_t)((uint32_t)arg4 & 1));
                fVar10 = fVar10 + fVar10;
            } else {
                fVar10 = (float)arg4;
            }
            fVar10 = (float)((uint32_t)fVar10 ^ 0x80000000) / (float)((uint32_t)(fVar8 - fVar9) & 0x7fffffff);
            fVar9 = fVar10 + (float)arg_30h;
            if ((fVar10 - (float)arg_30h <= in_XMM1_Da) && (in_XMM1_Da <= fVar9)) {
                return 0;
            }
            if (fVar10 <= in_XMM1_Da) {
                dVar6 = (double)fcn.180491d70(dVar1 / dVar7, (double)((in_XMM1_Da - fVar9) / (1.0 - fVar9)));
                dVar6 = dVar6 * dVar7;
            } else {
                dVar6 = (double)fcn.180491d70((double)((uint64_t)dVar2 ^ 0x8000000000000000) / dVar7, 
                                              (double)(1.0 - in_XMM1_Da / (fVar10 - (float)arg_30h)));
                dVar6 = (double)((uint64_t)(dVar6 * dVar7) ^ 0x8000000000000000);
            }
        }
        iVar4 = 0;
        if ((9.223372036854776e+18 <= dVar6) && (dVar6 = dVar6 - 9.223372036854776e+18, dVar6 < 9.223372036854776e+18))
        {
            iVar4 = -0x8000000000000000;
        }
        iVar4 = (int64_t)dVar6 + iVar4;
    }
    return iVar4;
}

// ============================================================
// Function: FUN_18014ea49
// Address: 0x18014ea49
// Size: 301 bytes
// ============================================================
int64_t fcn.18014e9f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h,
                     int64_t arg_30h)
{
    double dVar1;
    double dVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    double dVar6;
    double dVar7;
    float in_XMM1_Da;
    float fVar8;
    float fVar9;
    float fVar10;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if ((in_XMM1_Da <= 0.0) || (arg3 == arg4)) {
        return arg3;
    }
    if (1.0 <= in_XMM1_Da) {
        return arg4;
    }
    uVar5 = (uint32_t)arg3;
    if ((float)arg_28h <= 0.0) {
        if ((int32_t)arg1 - 8U < 2) {
            uVar3 = arg4 - arg3;
            if ((int64_t)uVar3 < 0) {
                fVar10 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
                fVar10 = fVar10 + fVar10;
            } else {
                fVar10 = (float)uVar3;
            }
            if (arg3 < 0) {
                fVar9 = (float)((uint64_t)arg3 >> 1 | (uint64_t)(uVar5 & 1));
                fVar9 = fVar9 + fVar9;
            } else {
                fVar9 = (float)arg3;
            }
            fVar9 = fVar10 * in_XMM1_Da + fVar9;
            iVar4 = 0;
            if ((9.223372e+18 <= fVar9) && (fVar9 = fVar9 - 9.223372e+18, fVar9 < 9.223372e+18)) {
                iVar4 = -0x8000000000000000;
            }
            iVar4 = (int64_t)fVar9 + iVar4;
        } else {
            iVar4 = 0;
            if (in_XMM1_Da < 1.0) {
                if ((uint64_t)arg4 < (uint64_t)arg3) {
                    fVar10 = -0.5;
                } else {
                    fVar10 = 0.5;
                }
                iVar4 = (int64_t)((float)(arg4 - arg3) * in_XMM1_Da + fVar10) + arg3;
            }
        }
    } else {
        dVar7 = (double)(float)arg_28h;
        if (arg3 < 0) {
            dVar6 = (double)((uint64_t)arg3 >> 1 | (uint64_t)(uVar5 & 1));
            dVar6 = dVar6 + dVar6;
        } else {
            dVar6 = (double)arg3;
        }
        fVar10 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        if (arg3 < 0) {
            fVar9 = (float)((uint64_t)arg3 >> 1 | (uint64_t)(uVar5 & 1));
            fVar9 = fVar9 + fVar9;
        } else {
            fVar9 = (float)arg3;
        }
        if ((double)((uint64_t)dVar6 & 0x7fffffffffffffff) < dVar7) {
            fVar8 = (float)arg_28h;
            if (fVar9 < 0.0) {
                fVar8 = fVar10;
            }
            dVar6 = (double)fVar8;
        }
        if (arg4 < 0) {
            dVar1 = (double)((uint64_t)arg4 >> 1 | (uint64_t)((uint32_t)arg4 & 1));
            dVar1 = dVar1 + dVar1;
            fVar8 = (float)((uint64_t)arg4 >> 1 | (uint64_t)((uint32_t)arg4 & 1));
            fVar8 = fVar8 + fVar8;
        } else {
            dVar1 = (double)arg4;
            fVar8 = (float)arg4;
        }
        if ((double)((uint64_t)dVar1 & 0x7fffffffffffffff) < dVar7) {
            if (fVar8 < 0.0) {
                arg_28h._0_4_ = fVar10;
            }
            dVar1 = (double)(float)arg_28h;
        }
        dVar2 = dVar6;
        if ((uint64_t)arg4 < (uint64_t)arg3) {
            dVar2 = dVar1;
            dVar1 = dVar6;
        }
        if ((fVar8 == 0.0) && (fVar9 < 0.0)) {
            dVar1 = (double)fVar10;
        }
        if ((uint64_t)arg4 < (uint64_t)arg3) {
            in_XMM1_Da = 1.0 - in_XMM1_Da;
        }
        uVar3 = arg3 * arg4;
        if ((int64_t)uVar3 < 0) {
            fVar10 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
            fVar10 = fVar10 + fVar10;
        } else {
            fVar10 = (float)uVar3;
        }
        if (0.0 <= fVar10) {
            if ((fVar9 < 0.0) || (fVar8 < 0.0)) {
                dVar7 = (double)fcn.180491d70((double)((uint64_t)dVar2 ^ 0x8000000000000000) /
                                              (double)((uint64_t)dVar1 ^ 0x8000000000000000), (double)(1.0 - in_XMM1_Da)
                                             );
                dVar6 = (double)((uint64_t)(dVar7 * (double)((uint64_t)dVar1 ^ 0x8000000000000000)) ^ 0x8000000000000000
                                );
            } else {
                dVar6 = (double)fcn.180491d70(dVar1 / dVar2, (double)in_XMM1_Da);
                dVar6 = dVar6 * dVar2;
            }
        } else {
            if ((uint64_t)arg3 < (uint64_t)arg4) {
                arg4 = arg3;
            }
            if (arg4 < 0) {
                fVar10 = (float)((uint64_t)arg4 >> 1 | (uint64_t)((uint32_t)arg4 & 1));
                fVar10 = fVar10 + fVar10;
            } else {
                fVar10 = (float)arg4;
            }
            fVar10 = (float)((uint32_t)fVar10 ^ 0x80000000) / (float)((uint32_t)(fVar8 - fVar9) & 0x7fffffff);
            fVar9 = fVar10 + (float)arg_30h;
            if ((fVar10 - (float)arg_30h <= in_XMM1_Da) && (in_XMM1_Da <= fVar9)) {
                return 0;
            }
            if (fVar10 <= in_XMM1_Da) {
                dVar6 = (double)fcn.180491d70(dVar1 / dVar7, (double)((in_XMM1_Da - fVar9) / (1.0 - fVar9)));
                dVar6 = dVar6 * dVar7;
            } else {
                dVar6 = (double)fcn.180491d70((double)((uint64_t)dVar2 ^ 0x8000000000000000) / dVar7, 
                                              (double)(1.0 - in_XMM1_Da / (fVar10 - (float)arg_30h)));
                dVar6 = (double)((uint64_t)(dVar6 * dVar7) ^ 0x8000000000000000);
            }
        }
        iVar4 = 0;
        if ((9.223372036854776e+18 <= dVar6) && (dVar6 = dVar6 - 9.223372036854776e+18, dVar6 < 9.223372036854776e+18))
        {
            iVar4 = -0x8000000000000000;
        }
        iVar4 = (int64_t)dVar6 + iVar4;
    }
    return iVar4;
}

// ============================================================
// Function: FUN_18014eb76
// Address: 0x18014eb76
// Size: 616 bytes
// ============================================================
int64_t fcn.18014e9f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h,
                     int64_t arg_30h)
{
    double dVar1;
    double dVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    double dVar6;
    double dVar7;
    float in_XMM1_Da;
    float fVar8;
    float fVar9;
    float fVar10;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if ((in_XMM1_Da <= 0.0) || (arg3 == arg4)) {
        return arg3;
    }
    if (1.0 <= in_XMM1_Da) {
        return arg4;
    }
    uVar5 = (uint32_t)arg3;
    if ((float)arg_28h <= 0.0) {
        if ((int32_t)arg1 - 8U < 2) {
            uVar3 = arg4 - arg3;
            if ((int64_t)uVar3 < 0) {
                fVar10 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
                fVar10 = fVar10 + fVar10;
            } else {
                fVar10 = (float)uVar3;
            }
            if (arg3 < 0) {
                fVar9 = (float)((uint64_t)arg3 >> 1 | (uint64_t)(uVar5 & 1));
                fVar9 = fVar9 + fVar9;
            } else {
                fVar9 = (float)arg3;
            }
            fVar9 = fVar10 * in_XMM1_Da + fVar9;
            iVar4 = 0;
            if ((9.223372e+18 <= fVar9) && (fVar9 = fVar9 - 9.223372e+18, fVar9 < 9.223372e+18)) {
                iVar4 = -0x8000000000000000;
            }
            iVar4 = (int64_t)fVar9 + iVar4;
        } else {
            iVar4 = 0;
            if (in_XMM1_Da < 1.0) {
                if ((uint64_t)arg4 < (uint64_t)arg3) {
                    fVar10 = -0.5;
                } else {
                    fVar10 = 0.5;
                }
                iVar4 = (int64_t)((float)(arg4 - arg3) * in_XMM1_Da + fVar10) + arg3;
            }
        }
    } else {
        dVar7 = (double)(float)arg_28h;
        if (arg3 < 0) {
            dVar6 = (double)((uint64_t)arg3 >> 1 | (uint64_t)(uVar5 & 1));
            dVar6 = dVar6 + dVar6;
        } else {
            dVar6 = (double)arg3;
        }
        fVar10 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        if (arg3 < 0) {
            fVar9 = (float)((uint64_t)arg3 >> 1 | (uint64_t)(uVar5 & 1));
            fVar9 = fVar9 + fVar9;
        } else {
            fVar9 = (float)arg3;
        }
        if ((double)((uint64_t)dVar6 & 0x7fffffffffffffff) < dVar7) {
            fVar8 = (float)arg_28h;
            if (fVar9 < 0.0) {
                fVar8 = fVar10;
            }
            dVar6 = (double)fVar8;
        }
        if (arg4 < 0) {
            dVar1 = (double)((uint64_t)arg4 >> 1 | (uint64_t)((uint32_t)arg4 & 1));
            dVar1 = dVar1 + dVar1;
            fVar8 = (float)((uint64_t)arg4 >> 1 | (uint64_t)((uint32_t)arg4 & 1));
            fVar8 = fVar8 + fVar8;
        } else {
            dVar1 = (double)arg4;
            fVar8 = (float)arg4;
        }
        if ((double)((uint64_t)dVar1 & 0x7fffffffffffffff) < dVar7) {
            if (fVar8 < 0.0) {
                arg_28h._0_4_ = fVar10;
            }
            dVar1 = (double)(float)arg_28h;
        }
        dVar2 = dVar6;
        if ((uint64_t)arg4 < (uint64_t)arg3) {
            dVar2 = dVar1;
            dVar1 = dVar6;
        }
        if ((fVar8 == 0.0) && (fVar9 < 0.0)) {
            dVar1 = (double)fVar10;
        }
        if ((uint64_t)arg4 < (uint64_t)arg3) {
            in_XMM1_Da = 1.0 - in_XMM1_Da;
        }
        uVar3 = arg3 * arg4;
        if ((int64_t)uVar3 < 0) {
            fVar10 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
            fVar10 = fVar10 + fVar10;
        } else {
            fVar10 = (float)uVar3;
        }
        if (0.0 <= fVar10) {
            if ((fVar9 < 0.0) || (fVar8 < 0.0)) {
                dVar7 = (double)fcn.180491d70((double)((uint64_t)dVar2 ^ 0x8000000000000000) /
                                              (double)((uint64_t)dVar1 ^ 0x8000000000000000), (double)(1.0 - in_XMM1_Da)
                                             );
                dVar6 = (double)((uint64_t)(dVar7 * (double)((uint64_t)dVar1 ^ 0x8000000000000000)) ^ 0x8000000000000000
                                );
            } else {
                dVar6 = (double)fcn.180491d70(dVar1 / dVar2, (double)in_XMM1_Da);
                dVar6 = dVar6 * dVar2;
            }
        } else {
            if ((uint64_t)arg3 < (uint64_t)arg4) {
                arg4 = arg3;
            }
            if (arg4 < 0) {
                fVar10 = (float)((uint64_t)arg4 >> 1 | (uint64_t)((uint32_t)arg4 & 1));
                fVar10 = fVar10 + fVar10;
            } else {
                fVar10 = (float)arg4;
            }
            fVar10 = (float)((uint32_t)fVar10 ^ 0x80000000) / (float)((uint32_t)(fVar8 - fVar9) & 0x7fffffff);
            fVar9 = fVar10 + (float)arg_30h;
            if ((fVar10 - (float)arg_30h <= in_XMM1_Da) && (in_XMM1_Da <= fVar9)) {
                return 0;
            }
            if (fVar10 <= in_XMM1_Da) {
                dVar6 = (double)fcn.180491d70(dVar1 / dVar7, (double)((in_XMM1_Da - fVar9) / (1.0 - fVar9)));
                dVar6 = dVar6 * dVar7;
            } else {
                dVar6 = (double)fcn.180491d70((double)((uint64_t)dVar2 ^ 0x8000000000000000) / dVar7, 
                                              (double)(1.0 - in_XMM1_Da / (fVar10 - (float)arg_30h)));
                dVar6 = (double)((uint64_t)(dVar6 * dVar7) ^ 0x8000000000000000);
            }
        }
        iVar4 = 0;
        if ((9.223372036854776e+18 <= dVar6) && (dVar6 = dVar6 - 9.223372036854776e+18, dVar6 < 9.223372036854776e+18))
        {
            iVar4 = -0x8000000000000000;
        }
        iVar4 = (int64_t)dVar6 + iVar4;
    }
    return iVar4;
}

// ============================================================
// Function: FUN_18014edde
// Address: 0x18014edde
// Size: 8 bytes
// ============================================================
int64_t fcn.18014e9f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h,
                     int64_t arg_30h)
{
    double dVar1;
    double dVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    double dVar6;
    double dVar7;
    float in_XMM1_Da;
    float fVar8;
    float fVar9;
    float fVar10;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if ((in_XMM1_Da <= 0.0) || (arg3 == arg4)) {
        return arg3;
    }
    if (1.0 <= in_XMM1_Da) {
        return arg4;
    }
    uVar5 = (uint32_t)arg3;
    if ((float)arg_28h <= 0.0) {
        if ((int32_t)arg1 - 8U < 2) {
            uVar3 = arg4 - arg3;
            if ((int64_t)uVar3 < 0) {
                fVar10 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
                fVar10 = fVar10 + fVar10;
            } else {
                fVar10 = (float)uVar3;
            }
            if (arg3 < 0) {
                fVar9 = (float)((uint64_t)arg3 >> 1 | (uint64_t)(uVar5 & 1));
                fVar9 = fVar9 + fVar9;
            } else {
                fVar9 = (float)arg3;
            }
            fVar9 = fVar10 * in_XMM1_Da + fVar9;
            iVar4 = 0;
            if ((9.223372e+18 <= fVar9) && (fVar9 = fVar9 - 9.223372e+18, fVar9 < 9.223372e+18)) {
                iVar4 = -0x8000000000000000;
            }
            iVar4 = (int64_t)fVar9 + iVar4;
        } else {
            iVar4 = 0;
            if (in_XMM1_Da < 1.0) {
                if ((uint64_t)arg4 < (uint64_t)arg3) {
                    fVar10 = -0.5;
                } else {
                    fVar10 = 0.5;
                }
                iVar4 = (int64_t)((float)(arg4 - arg3) * in_XMM1_Da + fVar10) + arg3;
            }
        }
    } else {
        dVar7 = (double)(float)arg_28h;
        if (arg3 < 0) {
            dVar6 = (double)((uint64_t)arg3 >> 1 | (uint64_t)(uVar5 & 1));
            dVar6 = dVar6 + dVar6;
        } else {
            dVar6 = (double)arg3;
        }
        fVar10 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        if (arg3 < 0) {
            fVar9 = (float)((uint64_t)arg3 >> 1 | (uint64_t)(uVar5 & 1));
            fVar9 = fVar9 + fVar9;
        } else {
            fVar9 = (float)arg3;
        }
        if ((double)((uint64_t)dVar6 & 0x7fffffffffffffff) < dVar7) {
            fVar8 = (float)arg_28h;
            if (fVar9 < 0.0) {
                fVar8 = fVar10;
            }
            dVar6 = (double)fVar8;
        }
        if (arg4 < 0) {
            dVar1 = (double)((uint64_t)arg4 >> 1 | (uint64_t)((uint32_t)arg4 & 1));
            dVar1 = dVar1 + dVar1;
            fVar8 = (float)((uint64_t)arg4 >> 1 | (uint64_t)((uint32_t)arg4 & 1));
            fVar8 = fVar8 + fVar8;
        } else {
            dVar1 = (double)arg4;
            fVar8 = (float)arg4;
        }
        if ((double)((uint64_t)dVar1 & 0x7fffffffffffffff) < dVar7) {
            if (fVar8 < 0.0) {
                arg_28h._0_4_ = fVar10;
            }
            dVar1 = (double)(float)arg_28h;
        }
        dVar2 = dVar6;
        if ((uint64_t)arg4 < (uint64_t)arg3) {
            dVar2 = dVar1;
            dVar1 = dVar6;
        }
        if ((fVar8 == 0.0) && (fVar9 < 0.0)) {
            dVar1 = (double)fVar10;
        }
        if ((uint64_t)arg4 < (uint64_t)arg3) {
            in_XMM1_Da = 1.0 - in_XMM1_Da;
        }
        uVar3 = arg3 * arg4;
        if ((int64_t)uVar3 < 0) {
            fVar10 = (float)(uVar3 >> 1 | (uint64_t)((uint32_t)uVar3 & 1));
            fVar10 = fVar10 + fVar10;
        } else {
            fVar10 = (float)uVar3;
        }
        if (0.0 <= fVar10) {
            if ((fVar9 < 0.0) || (fVar8 < 0.0)) {
                dVar7 = (double)fcn.180491d70((double)((uint64_t)dVar2 ^ 0x8000000000000000) /
                                              (double)((uint64_t)dVar1 ^ 0x8000000000000000), (double)(1.0 - in_XMM1_Da)
                                             );
                dVar6 = (double)((uint64_t)(dVar7 * (double)((uint64_t)dVar1 ^ 0x8000000000000000)) ^ 0x8000000000000000
                                );
            } else {
                dVar6 = (double)fcn.180491d70(dVar1 / dVar2, (double)in_XMM1_Da);
                dVar6 = dVar6 * dVar2;
            }
        } else {
            if ((uint64_t)arg3 < (uint64_t)arg4) {
                arg4 = arg3;
            }
            if (arg4 < 0) {
                fVar10 = (float)((uint64_t)arg4 >> 1 | (uint64_t)((uint32_t)arg4 & 1));
                fVar10 = fVar10 + fVar10;
            } else {
                fVar10 = (float)arg4;
            }
            fVar10 = (float)((uint32_t)fVar10 ^ 0x80000000) / (float)((uint32_t)(fVar8 - fVar9) & 0x7fffffff);
            fVar9 = fVar10 + (float)arg_30h;
            if ((fVar10 - (float)arg_30h <= in_XMM1_Da) && (in_XMM1_Da <= fVar9)) {
                return 0;
            }
            if (fVar10 <= in_XMM1_Da) {
                dVar6 = (double)fcn.180491d70(dVar1 / dVar7, (double)((in_XMM1_Da - fVar9) / (1.0 - fVar9)));
                dVar6 = dVar6 * dVar7;
            } else {
                dVar6 = (double)fcn.180491d70((double)((uint64_t)dVar2 ^ 0x8000000000000000) / dVar7, 
                                              (double)(1.0 - in_XMM1_Da / (fVar10 - (float)arg_30h)));
                dVar6 = (double)((uint64_t)(dVar6 * dVar7) ^ 0x8000000000000000);
            }
        }
        iVar4 = 0;
        if ((9.223372036854776e+18 <= dVar6) && (dVar6 = dVar6 - 9.223372036854776e+18, dVar6 < 9.223372036854776e+18))
        {
            iVar4 = -0x8000000000000000;
        }
        iVar4 = (int64_t)dVar6 + iVar4;
    }
    return iVar4;
}

// ============================================================
// Function: FUN_18014edf0
// Address: 0x18014edf0
// Size: 102 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18014edf0(int64_t arg_28h, int64_t arg_30h, int64_t arg_a8h)
{
    float fVar1;
    float fVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    float in_XMM1_Da;
    undefined4 uVar5;
    float in_XMM2_Da;
    undefined4 in_XMM2_Db;
    float in_XMM3_Da;
    float fVar6;
    undefined4 in_XMM3_Db;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    if (in_XMM2_Da == in_XMM3_Da) {
        return 0;
    }
    if (in_XMM3_Da <= in_XMM2_Da) {
        fVar1 = in_XMM3_Da;
        fVar8 = in_XMM2_Da;
        uVar5 = in_XMM2_Db;
        uVar4 = in_XMM3_Db;
        if (in_XMM1_Da < in_XMM3_Da) goto code_r0x00018014ee3f;
    } else {
        fVar1 = in_XMM2_Da;
        fVar8 = in_XMM3_Da;
        uVar5 = in_XMM3_Db;
        uVar4 = in_XMM2_Db;
        if (in_XMM1_Da < in_XMM2_Da) goto code_r0x00018014ee3f;
    }
    fVar1 = fVar8;
    uVar4 = uVar5;
    if (in_XMM1_Da <= fVar8) {
        fVar1 = in_XMM1_Da;
    }
code_r0x00018014ee3f:
    fVar8 = 0.0;
    if ((float)arg_28h <= 0.0) {
        fVar8 = (fVar1 - in_XMM2_Da) / (in_XMM3_Da - in_XMM2_Da);
    } else {
        fVar2 = in_XMM2_Da;
        fVar6 = in_XMM3_Da;
        if (in_XMM3_Da < in_XMM2_Da) {
            fVar2 = in_XMM3_Da;
            in_XMM2_Db = in_XMM3_Db;
            fVar6 = in_XMM2_Da;
        }
        fVar7 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        fVar10 = fVar2;
        if (((float)((uint32_t)fVar2 & 0x7fffffff) < (float)arg_28h) && (fVar10 = (float)arg_28h, fVar2 < 0.0)) {
            fVar10 = fVar7;
        }
        fVar9 = fVar6;
        if (((float)((uint32_t)fVar6 & 0x7fffffff) < (float)arg_28h) && (fVar9 = (float)arg_28h, fVar6 < 0.0)) {
            fVar9 = fVar7;
        }
        if ((((fVar2 != 0.0) || (fVar11 = fVar7, 0.0 <= fVar6)) && (fVar11 = fVar10, fVar6 == 0.0)) && (fVar2 < 0.0)) {
            fVar9 = fVar7;
        }
        uVar4 = 0;
        if (fVar11 < fVar1) {
            if (fVar1 < fVar9) {
                if (0.0 <= fVar2 * fVar6) {
                    if ((fVar2 < 0.0) || (fVar6 < 0.0)) {
                        fVar1 = (float)fcn.180491ba0((float)((uint32_t)fVar1 ^ 0x80000000) /
                                                     (float)((uint32_t)fVar9 ^ 0x80000000));
                        fVar8 = (float)fcn.180491ba0((float)((uint32_t)fVar11 ^ 0x80000000) /
                                                     (float)((uint32_t)fVar9 ^ 0x80000000));
                        fVar8 = 1.0 - fVar1 / fVar8;
                        uVar4 = 0;
                    } else {
                        uVar3 = fcn.180491ba0(fVar1 / fVar11);
                        fVar8 = (float)fcn.180491ba0(fVar9 / fVar11);
                        fVar8 = (float)uVar3 / fVar8;
                        uVar4 = (int32_t)((uint64_t)uVar3 >> 0x20);
                    }
                } else {
                    fVar8 = (float)((uint32_t)fVar2 ^ 0x80000000) / (fVar6 - fVar2);
                    uVar4 = in_XMM2_Db;
                    if (in_XMM1_Da != 0.0) {
                        if (0.0 <= in_XMM1_Da) {
                            uVar3 = fcn.180491ba0(fVar1 / (float)arg_28h);
                            fVar1 = (float)fcn.180491ba0(fVar9 / (float)arg_28h);
                            fVar8 = ((float)uVar3 / fVar1) * (1.0 - (fVar8 + (float)arg_30h)) + fVar8 + (float)arg_30h;
                            uVar4 = (int32_t)((uint64_t)uVar3 >> 0x20);
                        } else {
                            fVar1 = (float)fcn.180491ba0((float)((uint32_t)fVar1 ^ 0x80000000) / (float)arg_28h);
                            fVar2 = (float)fcn.180491ba0((float)((uint32_t)fVar11 ^ 0x80000000) / (float)arg_28h);
                            fVar8 = (1.0 - fVar1 / fVar2) * (fVar8 - (float)arg_30h);
                            uVar4 = 0;
                        }
                    }
                }
            } else {
                fVar8 = 1.0;
                uVar4 = 0;
            }
        }
        if (in_XMM3_Da < in_XMM2_Da) {
            fVar8 = 1.0 - fVar8;
            uVar4 = 0;
        }
    }
    return CONCAT44(uVar4, fVar8);
}

// ============================================================
// Function: FUN_18014ee56
// Address: 0x18014ee56
// Size: 556 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18014edf0(int64_t arg_28h, int64_t arg_30h, int64_t arg_a8h)
{
    float fVar1;
    float fVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    float in_XMM1_Da;
    undefined4 uVar5;
    float in_XMM2_Da;
    undefined4 in_XMM2_Db;
    float in_XMM3_Da;
    float fVar6;
    undefined4 in_XMM3_Db;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    if (in_XMM2_Da == in_XMM3_Da) {
        return 0;
    }
    if (in_XMM3_Da <= in_XMM2_Da) {
        fVar1 = in_XMM3_Da;
        fVar8 = in_XMM2_Da;
        uVar5 = in_XMM2_Db;
        uVar4 = in_XMM3_Db;
        if (in_XMM1_Da < in_XMM3_Da) goto code_r0x00018014ee3f;
    } else {
        fVar1 = in_XMM2_Da;
        fVar8 = in_XMM3_Da;
        uVar5 = in_XMM3_Db;
        uVar4 = in_XMM2_Db;
        if (in_XMM1_Da < in_XMM2_Da) goto code_r0x00018014ee3f;
    }
    fVar1 = fVar8;
    uVar4 = uVar5;
    if (in_XMM1_Da <= fVar8) {
        fVar1 = in_XMM1_Da;
    }
code_r0x00018014ee3f:
    fVar8 = 0.0;
    if ((float)arg_28h <= 0.0) {
        fVar8 = (fVar1 - in_XMM2_Da) / (in_XMM3_Da - in_XMM2_Da);
    } else {
        fVar2 = in_XMM2_Da;
        fVar6 = in_XMM3_Da;
        if (in_XMM3_Da < in_XMM2_Da) {
            fVar2 = in_XMM3_Da;
            in_XMM2_Db = in_XMM3_Db;
            fVar6 = in_XMM2_Da;
        }
        fVar7 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        fVar10 = fVar2;
        if (((float)((uint32_t)fVar2 & 0x7fffffff) < (float)arg_28h) && (fVar10 = (float)arg_28h, fVar2 < 0.0)) {
            fVar10 = fVar7;
        }
        fVar9 = fVar6;
        if (((float)((uint32_t)fVar6 & 0x7fffffff) < (float)arg_28h) && (fVar9 = (float)arg_28h, fVar6 < 0.0)) {
            fVar9 = fVar7;
        }
        if ((((fVar2 != 0.0) || (fVar11 = fVar7, 0.0 <= fVar6)) && (fVar11 = fVar10, fVar6 == 0.0)) && (fVar2 < 0.0)) {
            fVar9 = fVar7;
        }
        uVar4 = 0;
        if (fVar11 < fVar1) {
            if (fVar1 < fVar9) {
                if (0.0 <= fVar2 * fVar6) {
                    if ((fVar2 < 0.0) || (fVar6 < 0.0)) {
                        fVar1 = (float)fcn.180491ba0((float)((uint32_t)fVar1 ^ 0x80000000) /
                                                     (float)((uint32_t)fVar9 ^ 0x80000000));
                        fVar8 = (float)fcn.180491ba0((float)((uint32_t)fVar11 ^ 0x80000000) /
                                                     (float)((uint32_t)fVar9 ^ 0x80000000));
                        fVar8 = 1.0 - fVar1 / fVar8;
                        uVar4 = 0;
                    } else {
                        uVar3 = fcn.180491ba0(fVar1 / fVar11);
                        fVar8 = (float)fcn.180491ba0(fVar9 / fVar11);
                        fVar8 = (float)uVar3 / fVar8;
                        uVar4 = (int32_t)((uint64_t)uVar3 >> 0x20);
                    }
                } else {
                    fVar8 = (float)((uint32_t)fVar2 ^ 0x80000000) / (fVar6 - fVar2);
                    uVar4 = in_XMM2_Db;
                    if (in_XMM1_Da != 0.0) {
                        if (0.0 <= in_XMM1_Da) {
                            uVar3 = fcn.180491ba0(fVar1 / (float)arg_28h);
                            fVar1 = (float)fcn.180491ba0(fVar9 / (float)arg_28h);
                            fVar8 = ((float)uVar3 / fVar1) * (1.0 - (fVar8 + (float)arg_30h)) + fVar8 + (float)arg_30h;
                            uVar4 = (int32_t)((uint64_t)uVar3 >> 0x20);
                        } else {
                            fVar1 = (float)fcn.180491ba0((float)((uint32_t)fVar1 ^ 0x80000000) / (float)arg_28h);
                            fVar2 = (float)fcn.180491ba0((float)((uint32_t)fVar11 ^ 0x80000000) / (float)arg_28h);
                            fVar8 = (1.0 - fVar1 / fVar2) * (fVar8 - (float)arg_30h);
                            uVar4 = 0;
                        }
                    }
                }
            } else {
                fVar8 = 1.0;
                uVar4 = 0;
            }
        }
        if (in_XMM3_Da < in_XMM2_Da) {
            fVar8 = 1.0 - fVar8;
            uVar4 = 0;
        }
    }
    return CONCAT44(uVar4, fVar8);
}

// ============================================================
// Function: FUN_18014f082
// Address: 0x18014f082
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18014edf0(int64_t arg_28h, int64_t arg_30h, int64_t arg_a8h)
{
    float fVar1;
    float fVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    float in_XMM1_Da;
    undefined4 uVar5;
    float in_XMM2_Da;
    undefined4 in_XMM2_Db;
    float in_XMM3_Da;
    float fVar6;
    undefined4 in_XMM3_Db;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    if (in_XMM2_Da == in_XMM3_Da) {
        return 0;
    }
    if (in_XMM3_Da <= in_XMM2_Da) {
        fVar1 = in_XMM3_Da;
        fVar8 = in_XMM2_Da;
        uVar5 = in_XMM2_Db;
        uVar4 = in_XMM3_Db;
        if (in_XMM1_Da < in_XMM3_Da) goto code_r0x00018014ee3f;
    } else {
        fVar1 = in_XMM2_Da;
        fVar8 = in_XMM3_Da;
        uVar5 = in_XMM3_Db;
        uVar4 = in_XMM2_Db;
        if (in_XMM1_Da < in_XMM2_Da) goto code_r0x00018014ee3f;
    }
    fVar1 = fVar8;
    uVar4 = uVar5;
    if (in_XMM1_Da <= fVar8) {
        fVar1 = in_XMM1_Da;
    }
code_r0x00018014ee3f:
    fVar8 = 0.0;
    if ((float)arg_28h <= 0.0) {
        fVar8 = (fVar1 - in_XMM2_Da) / (in_XMM3_Da - in_XMM2_Da);
    } else {
        fVar2 = in_XMM2_Da;
        fVar6 = in_XMM3_Da;
        if (in_XMM3_Da < in_XMM2_Da) {
            fVar2 = in_XMM3_Da;
            in_XMM2_Db = in_XMM3_Db;
            fVar6 = in_XMM2_Da;
        }
        fVar7 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        fVar10 = fVar2;
        if (((float)((uint32_t)fVar2 & 0x7fffffff) < (float)arg_28h) && (fVar10 = (float)arg_28h, fVar2 < 0.0)) {
            fVar10 = fVar7;
        }
        fVar9 = fVar6;
        if (((float)((uint32_t)fVar6 & 0x7fffffff) < (float)arg_28h) && (fVar9 = (float)arg_28h, fVar6 < 0.0)) {
            fVar9 = fVar7;
        }
        if ((((fVar2 != 0.0) || (fVar11 = fVar7, 0.0 <= fVar6)) && (fVar11 = fVar10, fVar6 == 0.0)) && (fVar2 < 0.0)) {
            fVar9 = fVar7;
        }
        uVar4 = 0;
        if (fVar11 < fVar1) {
            if (fVar1 < fVar9) {
                if (0.0 <= fVar2 * fVar6) {
                    if ((fVar2 < 0.0) || (fVar6 < 0.0)) {
                        fVar1 = (float)fcn.180491ba0((float)((uint32_t)fVar1 ^ 0x80000000) /
                                                     (float)((uint32_t)fVar9 ^ 0x80000000));
                        fVar8 = (float)fcn.180491ba0((float)((uint32_t)fVar11 ^ 0x80000000) /
                                                     (float)((uint32_t)fVar9 ^ 0x80000000));
                        fVar8 = 1.0 - fVar1 / fVar8;
                        uVar4 = 0;
                    } else {
                        uVar3 = fcn.180491ba0(fVar1 / fVar11);
                        fVar8 = (float)fcn.180491ba0(fVar9 / fVar11);
                        fVar8 = (float)uVar3 / fVar8;
                        uVar4 = (int32_t)((uint64_t)uVar3 >> 0x20);
                    }
                } else {
                    fVar8 = (float)((uint32_t)fVar2 ^ 0x80000000) / (fVar6 - fVar2);
                    uVar4 = in_XMM2_Db;
                    if (in_XMM1_Da != 0.0) {
                        if (0.0 <= in_XMM1_Da) {
                            uVar3 = fcn.180491ba0(fVar1 / (float)arg_28h);
                            fVar1 = (float)fcn.180491ba0(fVar9 / (float)arg_28h);
                            fVar8 = ((float)uVar3 / fVar1) * (1.0 - (fVar8 + (float)arg_30h)) + fVar8 + (float)arg_30h;
                            uVar4 = (int32_t)((uint64_t)uVar3 >> 0x20);
                        } else {
                            fVar1 = (float)fcn.180491ba0((float)((uint32_t)fVar1 ^ 0x80000000) / (float)arg_28h);
                            fVar2 = (float)fcn.180491ba0((float)((uint32_t)fVar11 ^ 0x80000000) / (float)arg_28h);
                            fVar8 = (1.0 - fVar1 / fVar2) * (fVar8 - (float)arg_30h);
                            uVar4 = 0;
                        }
                    }
                }
            } else {
                fVar8 = 1.0;
                uVar4 = 0;
            }
        }
        if (in_XMM3_Da < in_XMM2_Da) {
            fVar8 = 1.0 - fVar8;
            uVar4 = 0;
        }
    }
    return CONCAT44(uVar4, fVar8);
}

// ============================================================
// Function: FUN_18014f093
// Address: 0x18014f093
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18014edf0(int64_t arg_28h, int64_t arg_30h, int64_t arg_a8h)
{
    float fVar1;
    float fVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    float in_XMM1_Da;
    undefined4 uVar5;
    float in_XMM2_Da;
    undefined4 in_XMM2_Db;
    float in_XMM3_Da;
    float fVar6;
    undefined4 in_XMM3_Db;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    if (in_XMM2_Da == in_XMM3_Da) {
        return 0;
    }
    if (in_XMM3_Da <= in_XMM2_Da) {
        fVar1 = in_XMM3_Da;
        fVar8 = in_XMM2_Da;
        uVar5 = in_XMM2_Db;
        uVar4 = in_XMM3_Db;
        if (in_XMM1_Da < in_XMM3_Da) goto code_r0x00018014ee3f;
    } else {
        fVar1 = in_XMM2_Da;
        fVar8 = in_XMM3_Da;
        uVar5 = in_XMM3_Db;
        uVar4 = in_XMM2_Db;
        if (in_XMM1_Da < in_XMM2_Da) goto code_r0x00018014ee3f;
    }
    fVar1 = fVar8;
    uVar4 = uVar5;
    if (in_XMM1_Da <= fVar8) {
        fVar1 = in_XMM1_Da;
    }
code_r0x00018014ee3f:
    fVar8 = 0.0;
    if ((float)arg_28h <= 0.0) {
        fVar8 = (fVar1 - in_XMM2_Da) / (in_XMM3_Da - in_XMM2_Da);
    } else {
        fVar2 = in_XMM2_Da;
        fVar6 = in_XMM3_Da;
        if (in_XMM3_Da < in_XMM2_Da) {
            fVar2 = in_XMM3_Da;
            in_XMM2_Db = in_XMM3_Db;
            fVar6 = in_XMM2_Da;
        }
        fVar7 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        fVar10 = fVar2;
        if (((float)((uint32_t)fVar2 & 0x7fffffff) < (float)arg_28h) && (fVar10 = (float)arg_28h, fVar2 < 0.0)) {
            fVar10 = fVar7;
        }
        fVar9 = fVar6;
        if (((float)((uint32_t)fVar6 & 0x7fffffff) < (float)arg_28h) && (fVar9 = (float)arg_28h, fVar6 < 0.0)) {
            fVar9 = fVar7;
        }
        if ((((fVar2 != 0.0) || (fVar11 = fVar7, 0.0 <= fVar6)) && (fVar11 = fVar10, fVar6 == 0.0)) && (fVar2 < 0.0)) {
            fVar9 = fVar7;
        }
        uVar4 = 0;
        if (fVar11 < fVar1) {
            if (fVar1 < fVar9) {
                if (0.0 <= fVar2 * fVar6) {
                    if ((fVar2 < 0.0) || (fVar6 < 0.0)) {
                        fVar1 = (float)fcn.180491ba0((float)((uint32_t)fVar1 ^ 0x80000000) /
                                                     (float)((uint32_t)fVar9 ^ 0x80000000));
                        fVar8 = (float)fcn.180491ba0((float)((uint32_t)fVar11 ^ 0x80000000) /
                                                     (float)((uint32_t)fVar9 ^ 0x80000000));
                        fVar8 = 1.0 - fVar1 / fVar8;
                        uVar4 = 0;
                    } else {
                        uVar3 = fcn.180491ba0(fVar1 / fVar11);
                        fVar8 = (float)fcn.180491ba0(fVar9 / fVar11);
                        fVar8 = (float)uVar3 / fVar8;
                        uVar4 = (int32_t)((uint64_t)uVar3 >> 0x20);
                    }
                } else {
                    fVar8 = (float)((uint32_t)fVar2 ^ 0x80000000) / (fVar6 - fVar2);
                    uVar4 = in_XMM2_Db;
                    if (in_XMM1_Da != 0.0) {
                        if (0.0 <= in_XMM1_Da) {
                            uVar3 = fcn.180491ba0(fVar1 / (float)arg_28h);
                            fVar1 = (float)fcn.180491ba0(fVar9 / (float)arg_28h);
                            fVar8 = ((float)uVar3 / fVar1) * (1.0 - (fVar8 + (float)arg_30h)) + fVar8 + (float)arg_30h;
                            uVar4 = (int32_t)((uint64_t)uVar3 >> 0x20);
                        } else {
                            fVar1 = (float)fcn.180491ba0((float)((uint32_t)fVar1 ^ 0x80000000) / (float)arg_28h);
                            fVar2 = (float)fcn.180491ba0((float)((uint32_t)fVar11 ^ 0x80000000) / (float)arg_28h);
                            fVar8 = (1.0 - fVar1 / fVar2) * (fVar8 - (float)arg_30h);
                            uVar4 = 0;
                        }
                    }
                }
            } else {
                fVar8 = 1.0;
                uVar4 = 0;
            }
        }
        if (in_XMM3_Da < in_XMM2_Da) {
            fVar8 = 1.0 - fVar8;
            uVar4 = 0;
        }
    }
    return CONCAT44(uVar4, fVar8);
}

// ============================================================
// Function: FUN_18014f0a2
// Address: 0x18014f0a2
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18014edf0(int64_t arg_28h, int64_t arg_30h, int64_t arg_a8h)
{
    float fVar1;
    float fVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    float in_XMM1_Da;
    undefined4 uVar5;
    float in_XMM2_Da;
    undefined4 in_XMM2_Db;
    float in_XMM3_Da;
    float fVar6;
    undefined4 in_XMM3_Db;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    if (in_XMM2_Da == in_XMM3_Da) {
        return 0;
    }
    if (in_XMM3_Da <= in_XMM2_Da) {
        fVar1 = in_XMM3_Da;
        fVar8 = in_XMM2_Da;
        uVar5 = in_XMM2_Db;
        uVar4 = in_XMM3_Db;
        if (in_XMM1_Da < in_XMM3_Da) goto code_r0x00018014ee3f;
    } else {
        fVar1 = in_XMM2_Da;
        fVar8 = in_XMM3_Da;
        uVar5 = in_XMM3_Db;
        uVar4 = in_XMM2_Db;
        if (in_XMM1_Da < in_XMM2_Da) goto code_r0x00018014ee3f;
    }
    fVar1 = fVar8;
    uVar4 = uVar5;
    if (in_XMM1_Da <= fVar8) {
        fVar1 = in_XMM1_Da;
    }
code_r0x00018014ee3f:
    fVar8 = 0.0;
    if ((float)arg_28h <= 0.0) {
        fVar8 = (fVar1 - in_XMM2_Da) / (in_XMM3_Da - in_XMM2_Da);
    } else {
        fVar2 = in_XMM2_Da;
        fVar6 = in_XMM3_Da;
        if (in_XMM3_Da < in_XMM2_Da) {
            fVar2 = in_XMM3_Da;
            in_XMM2_Db = in_XMM3_Db;
            fVar6 = in_XMM2_Da;
        }
        fVar7 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        fVar10 = fVar2;
        if (((float)((uint32_t)fVar2 & 0x7fffffff) < (float)arg_28h) && (fVar10 = (float)arg_28h, fVar2 < 0.0)) {
            fVar10 = fVar7;
        }
        fVar9 = fVar6;
        if (((float)((uint32_t)fVar6 & 0x7fffffff) < (float)arg_28h) && (fVar9 = (float)arg_28h, fVar6 < 0.0)) {
            fVar9 = fVar7;
        }
        if ((((fVar2 != 0.0) || (fVar11 = fVar7, 0.0 <= fVar6)) && (fVar11 = fVar10, fVar6 == 0.0)) && (fVar2 < 0.0)) {
            fVar9 = fVar7;
        }
        uVar4 = 0;
        if (fVar11 < fVar1) {
            if (fVar1 < fVar9) {
                if (0.0 <= fVar2 * fVar6) {
                    if ((fVar2 < 0.0) || (fVar6 < 0.0)) {
                        fVar1 = (float)fcn.180491ba0((float)((uint32_t)fVar1 ^ 0x80000000) /
                                                     (float)((uint32_t)fVar9 ^ 0x80000000));
                        fVar8 = (float)fcn.180491ba0((float)((uint32_t)fVar11 ^ 0x80000000) /
                                                     (float)((uint32_t)fVar9 ^ 0x80000000));
                        fVar8 = 1.0 - fVar1 / fVar8;
                        uVar4 = 0;
                    } else {
                        uVar3 = fcn.180491ba0(fVar1 / fVar11);
                        fVar8 = (float)fcn.180491ba0(fVar9 / fVar11);
                        fVar8 = (float)uVar3 / fVar8;
                        uVar4 = (int32_t)((uint64_t)uVar3 >> 0x20);
                    }
                } else {
                    fVar8 = (float)((uint32_t)fVar2 ^ 0x80000000) / (fVar6 - fVar2);
                    uVar4 = in_XMM2_Db;
                    if (in_XMM1_Da != 0.0) {
                        if (0.0 <= in_XMM1_Da) {
                            uVar3 = fcn.180491ba0(fVar1 / (float)arg_28h);
                            fVar1 = (float)fcn.180491ba0(fVar9 / (float)arg_28h);
                            fVar8 = ((float)uVar3 / fVar1) * (1.0 - (fVar8 + (float)arg_30h)) + fVar8 + (float)arg_30h;
                            uVar4 = (int32_t)((uint64_t)uVar3 >> 0x20);
                        } else {
                            fVar1 = (float)fcn.180491ba0((float)((uint32_t)fVar1 ^ 0x80000000) / (float)arg_28h);
                            fVar2 = (float)fcn.180491ba0((float)((uint32_t)fVar11 ^ 0x80000000) / (float)arg_28h);
                            fVar8 = (1.0 - fVar1 / fVar2) * (fVar8 - (float)arg_30h);
                            uVar4 = 0;
                        }
                    }
                }
            } else {
                fVar8 = 1.0;
                uVar4 = 0;
            }
        }
        if (in_XMM3_Da < in_XMM2_Da) {
            fVar8 = 1.0 - fVar8;
            uVar4 = 0;
        }
    }
    return CONCAT44(uVar4, fVar8);
}

// ============================================================
// Function: FUN_18014f0d0
// Address: 0x18014f0d0
// Size: 66 bytes
// ============================================================
undefined8 fcn.18014f0d0(int64_t arg1, int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    float in_XMM1_Da;
    float fVar2;
    float in_XMM2_Da;
    undefined4 in_XMM2_Db;
    float in_XMM3_Da;
    undefined4 in_XMM3_Db;
    float fVar3;
    undefined4 uVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    fVar3 = 0.0;
    uVar4 = 0;
    if ((in_XMM1_Da <= 0.0) || (in_XMM2_Da == in_XMM3_Da)) {
        return CONCAT44(in_XMM2_Db, in_XMM2_Da);
    }
    if (1.0 <= in_XMM1_Da) {
        return CONCAT44(in_XMM3_Db, in_XMM3_Da);
    }
    if ((float)arg_28h <= 0.0) {
        if ((int32_t)arg1 - 8U < 2) {
            fVar3 = (in_XMM3_Da - in_XMM2_Da) * in_XMM1_Da;
            uVar4 = in_XMM3_Db;
        } else {
            if (1.0 <= in_XMM1_Da) goto code_r0x00018014f307;
            if (in_XMM2_Da <= in_XMM3_Da) {
                fVar3 = 0.5;
            } else {
                fVar3 = -0.5;
            }
            uVar4 = 0;
            fVar3 = fVar3 + (in_XMM3_Da - in_XMM2_Da) * in_XMM1_Da;
        }
        fVar3 = fVar3 + in_XMM2_Da;
    } else {
        fVar2 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        fVar6 = in_XMM2_Da;
        if (((float)((uint32_t)in_XMM2_Da & 0x7fffffff) < (float)arg_28h) && (fVar6 = (float)arg_28h, in_XMM2_Da < 0.0))
        {
            fVar6 = fVar2;
        }
        fVar7 = in_XMM3_Da;
        if (((float)((uint32_t)in_XMM3_Da & 0x7fffffff) < (float)arg_28h) && (fVar7 = (float)arg_28h, in_XMM3_Da < 0.0))
        {
            fVar7 = fVar2;
        }
        fVar5 = fVar7;
        if (in_XMM3_Da < in_XMM2_Da) {
            fVar5 = fVar6;
            fVar6 = fVar7;
        }
        if ((in_XMM3_Da == 0.0) && (in_XMM2_Da < 0.0)) {
            fVar5 = fVar2;
        }
        if (in_XMM3_Da < in_XMM2_Da) {
            in_XMM1_Da = 1.0 - in_XMM1_Da;
        }
        if (0.0 <= in_XMM2_Da * in_XMM3_Da) {
            if ((in_XMM2_Da < 0.0) || (in_XMM3_Da < 0.0)) {
                uVar1 = func_0x000180492580((float)((uint32_t)fVar6 ^ 0x80000000) /
                                            (float)((uint32_t)fVar5 ^ 0x80000000), 1.0 - in_XMM1_Da);
                uVar4 = (undefined4)((uint64_t)uVar1 >> 0x20);
                fVar3 = (float)((uint32_t)((float)uVar1 * (float)((uint32_t)fVar5 ^ 0x80000000)) ^ 0x80000000);
            } else {
                uVar1 = func_0x000180492580(fVar5 / fVar6);
                uVar4 = (undefined4)((uint64_t)uVar1 >> 0x20);
                fVar3 = (float)uVar1 * fVar6;
            }
        } else {
            fVar2 = in_XMM2_Da;
            if (in_XMM3_Da <= in_XMM2_Da) {
                fVar2 = in_XMM3_Da;
            }
            fVar7 = (float)((uint32_t)fVar2 ^ 0x80000000) / (float)((uint32_t)(in_XMM3_Da - in_XMM2_Da) & 0x7fffffff);
            fVar2 = fVar7 + (float)arg_30h;
            if ((in_XMM1_Da < fVar7 - (float)arg_30h) || (fVar2 < in_XMM1_Da)) {
                if (fVar7 <= in_XMM1_Da) {
                    uVar1 = func_0x000180492580(fVar5 / (float)arg_28h, (in_XMM1_Da - fVar2) / (1.0 - fVar2));
                    uVar4 = (undefined4)((uint64_t)uVar1 >> 0x20);
                    fVar3 = (float)uVar1 * (float)arg_28h;
                } else {
                    uVar1 = func_0x000180492580((float)((uint32_t)fVar6 ^ 0x80000000) / (float)arg_28h, 
                                                1.0 - in_XMM1_Da / (fVar7 - (float)arg_30h));
                    uVar4 = (undefined4)((uint64_t)uVar1 >> 0x20);
                    fVar3 = (float)((uint32_t)((float)uVar1 * (float)arg_28h) ^ 0x80000000);
                }
            }
        }
    }
code_r0x00018014f307:
    return CONCAT44(uVar4, fVar3);
}

// ============================================================
// Function: FUN_18014f112
// Address: 0x18014f112
// Size: 537 bytes
// ============================================================
undefined8 fcn.18014f0d0(int64_t arg1, int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    float in_XMM1_Da;
    float fVar2;
    float in_XMM2_Da;
    undefined4 in_XMM2_Db;
    float in_XMM3_Da;
    undefined4 in_XMM3_Db;
    float fVar3;
    undefined4 uVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    fVar3 = 0.0;
    uVar4 = 0;
    if ((in_XMM1_Da <= 0.0) || (in_XMM2_Da == in_XMM3_Da)) {
        return CONCAT44(in_XMM2_Db, in_XMM2_Da);
    }
    if (1.0 <= in_XMM1_Da) {
        return CONCAT44(in_XMM3_Db, in_XMM3_Da);
    }
    if ((float)arg_28h <= 0.0) {
        if ((int32_t)arg1 - 8U < 2) {
            fVar3 = (in_XMM3_Da - in_XMM2_Da) * in_XMM1_Da;
            uVar4 = in_XMM3_Db;
        } else {
            if (1.0 <= in_XMM1_Da) goto code_r0x00018014f307;
            if (in_XMM2_Da <= in_XMM3_Da) {
                fVar3 = 0.5;
            } else {
                fVar3 = -0.5;
            }
            uVar4 = 0;
            fVar3 = fVar3 + (in_XMM3_Da - in_XMM2_Da) * in_XMM1_Da;
        }
        fVar3 = fVar3 + in_XMM2_Da;
    } else {
        fVar2 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        fVar6 = in_XMM2_Da;
        if (((float)((uint32_t)in_XMM2_Da & 0x7fffffff) < (float)arg_28h) && (fVar6 = (float)arg_28h, in_XMM2_Da < 0.0))
        {
            fVar6 = fVar2;
        }
        fVar7 = in_XMM3_Da;
        if (((float)((uint32_t)in_XMM3_Da & 0x7fffffff) < (float)arg_28h) && (fVar7 = (float)arg_28h, in_XMM3_Da < 0.0))
        {
            fVar7 = fVar2;
        }
        fVar5 = fVar7;
        if (in_XMM3_Da < in_XMM2_Da) {
            fVar5 = fVar6;
            fVar6 = fVar7;
        }
        if ((in_XMM3_Da == 0.0) && (in_XMM2_Da < 0.0)) {
            fVar5 = fVar2;
        }
        if (in_XMM3_Da < in_XMM2_Da) {
            in_XMM1_Da = 1.0 - in_XMM1_Da;
        }
        if (0.0 <= in_XMM2_Da * in_XMM3_Da) {
            if ((in_XMM2_Da < 0.0) || (in_XMM3_Da < 0.0)) {
                uVar1 = func_0x000180492580((float)((uint32_t)fVar6 ^ 0x80000000) /
                                            (float)((uint32_t)fVar5 ^ 0x80000000), 1.0 - in_XMM1_Da);
                uVar4 = (undefined4)((uint64_t)uVar1 >> 0x20);
                fVar3 = (float)((uint32_t)((float)uVar1 * (float)((uint32_t)fVar5 ^ 0x80000000)) ^ 0x80000000);
            } else {
                uVar1 = func_0x000180492580(fVar5 / fVar6);
                uVar4 = (undefined4)((uint64_t)uVar1 >> 0x20);
                fVar3 = (float)uVar1 * fVar6;
            }
        } else {
            fVar2 = in_XMM2_Da;
            if (in_XMM3_Da <= in_XMM2_Da) {
                fVar2 = in_XMM3_Da;
            }
            fVar7 = (float)((uint32_t)fVar2 ^ 0x80000000) / (float)((uint32_t)(in_XMM3_Da - in_XMM2_Da) & 0x7fffffff);
            fVar2 = fVar7 + (float)arg_30h;
            if ((in_XMM1_Da < fVar7 - (float)arg_30h) || (fVar2 < in_XMM1_Da)) {
                if (fVar7 <= in_XMM1_Da) {
                    uVar1 = func_0x000180492580(fVar5 / (float)arg_28h, (in_XMM1_Da - fVar2) / (1.0 - fVar2));
                    uVar4 = (undefined4)((uint64_t)uVar1 >> 0x20);
                    fVar3 = (float)uVar1 * (float)arg_28h;
                } else {
                    uVar1 = func_0x000180492580((float)((uint32_t)fVar6 ^ 0x80000000) / (float)arg_28h, 
                                                1.0 - in_XMM1_Da / (fVar7 - (float)arg_30h));
                    uVar4 = (undefined4)((uint64_t)uVar1 >> 0x20);
                    fVar3 = (float)((uint32_t)((float)uVar1 * (float)arg_28h) ^ 0x80000000);
                }
            }
        }
    }
code_r0x00018014f307:
    return CONCAT44(uVar4, fVar3);
}

// ============================================================
// Function: FUN_18014f32b
// Address: 0x18014f32b
// Size: 14 bytes
// ============================================================
undefined8 fcn.18014f0d0(int64_t arg1, int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    float in_XMM1_Da;
    float fVar2;
    float in_XMM2_Da;
    undefined4 in_XMM2_Db;
    float in_XMM3_Da;
    undefined4 in_XMM3_Db;
    float fVar3;
    undefined4 uVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    fVar3 = 0.0;
    uVar4 = 0;
    if ((in_XMM1_Da <= 0.0) || (in_XMM2_Da == in_XMM3_Da)) {
        return CONCAT44(in_XMM2_Db, in_XMM2_Da);
    }
    if (1.0 <= in_XMM1_Da) {
        return CONCAT44(in_XMM3_Db, in_XMM3_Da);
    }
    if ((float)arg_28h <= 0.0) {
        if ((int32_t)arg1 - 8U < 2) {
            fVar3 = (in_XMM3_Da - in_XMM2_Da) * in_XMM1_Da;
            uVar4 = in_XMM3_Db;
        } else {
            if (1.0 <= in_XMM1_Da) goto code_r0x00018014f307;
            if (in_XMM2_Da <= in_XMM3_Da) {
                fVar3 = 0.5;
            } else {
                fVar3 = -0.5;
            }
            uVar4 = 0;
            fVar3 = fVar3 + (in_XMM3_Da - in_XMM2_Da) * in_XMM1_Da;
        }
        fVar3 = fVar3 + in_XMM2_Da;
    } else {
        fVar2 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        fVar6 = in_XMM2_Da;
        if (((float)((uint32_t)in_XMM2_Da & 0x7fffffff) < (float)arg_28h) && (fVar6 = (float)arg_28h, in_XMM2_Da < 0.0))
        {
            fVar6 = fVar2;
        }
        fVar7 = in_XMM3_Da;
        if (((float)((uint32_t)in_XMM3_Da & 0x7fffffff) < (float)arg_28h) && (fVar7 = (float)arg_28h, in_XMM3_Da < 0.0))
        {
            fVar7 = fVar2;
        }
        fVar5 = fVar7;
        if (in_XMM3_Da < in_XMM2_Da) {
            fVar5 = fVar6;
            fVar6 = fVar7;
        }
        if ((in_XMM3_Da == 0.0) && (in_XMM2_Da < 0.0)) {
            fVar5 = fVar2;
        }
        if (in_XMM3_Da < in_XMM2_Da) {
            in_XMM1_Da = 1.0 - in_XMM1_Da;
        }
        if (0.0 <= in_XMM2_Da * in_XMM3_Da) {
            if ((in_XMM2_Da < 0.0) || (in_XMM3_Da < 0.0)) {
                uVar1 = func_0x000180492580((float)((uint32_t)fVar6 ^ 0x80000000) /
                                            (float)((uint32_t)fVar5 ^ 0x80000000), 1.0 - in_XMM1_Da);
                uVar4 = (undefined4)((uint64_t)uVar1 >> 0x20);
                fVar3 = (float)((uint32_t)((float)uVar1 * (float)((uint32_t)fVar5 ^ 0x80000000)) ^ 0x80000000);
            } else {
                uVar1 = func_0x000180492580(fVar5 / fVar6);
                uVar4 = (undefined4)((uint64_t)uVar1 >> 0x20);
                fVar3 = (float)uVar1 * fVar6;
            }
        } else {
            fVar2 = in_XMM2_Da;
            if (in_XMM3_Da <= in_XMM2_Da) {
                fVar2 = in_XMM3_Da;
            }
            fVar7 = (float)((uint32_t)fVar2 ^ 0x80000000) / (float)((uint32_t)(in_XMM3_Da - in_XMM2_Da) & 0x7fffffff);
            fVar2 = fVar7 + (float)arg_30h;
            if ((in_XMM1_Da < fVar7 - (float)arg_30h) || (fVar2 < in_XMM1_Da)) {
                if (fVar7 <= in_XMM1_Da) {
                    uVar1 = func_0x000180492580(fVar5 / (float)arg_28h, (in_XMM1_Da - fVar2) / (1.0 - fVar2));
                    uVar4 = (undefined4)((uint64_t)uVar1 >> 0x20);
                    fVar3 = (float)uVar1 * (float)arg_28h;
                } else {
                    uVar1 = func_0x000180492580((float)((uint32_t)fVar6 ^ 0x80000000) / (float)arg_28h, 
                                                1.0 - in_XMM1_Da / (fVar7 - (float)arg_30h));
                    uVar4 = (undefined4)((uint64_t)uVar1 >> 0x20);
                    fVar3 = (float)((uint32_t)((float)uVar1 * (float)arg_28h) ^ 0x80000000);
                }
            }
        }
    }
code_r0x00018014f307:
    return CONCAT44(uVar4, fVar3);
}

// ============================================================
// Function: FUN_18014f340
// Address: 0x18014f340
// Size: 142 bytes
// ============================================================
void fcn.18014f340(int64_t arg1)
{
    char *pcVar1;
    char cVar2;
    int64_t *piVar3;
    undefined auStack_88 [48];
    int64_t var_58h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    cVar2 = *(char *)arg1;
    while (cVar2 != '\0') {
        if (cVar2 == '%') {
            if (*(char *)(arg1 + 1) != '%') break;
            arg1 = arg1 + 1;
        }
        pcVar1 = (char *)(arg1 + 1);
        arg1 = arg1 + 1;
        cVar2 = *pcVar1;
    }
    if ((*(char *)arg1 == '%') && (*(char *)(arg1 + 1) != '%')) {
        piVar3 = &var_58h;
        if ((char)var_58h == ' ') {
            do {
                piVar3 = (int64_t *)((int64_t)piVar3 + 1);
            } while (*(char *)piVar3 == ' ');
        }
        func_0x000180471c88();
        func_0x000180459870(var_18h ^ (uint64_t)auStack_88);
        return;
    }
    func_0x000180459870(*(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88 ^ (uint64_t)auStack_88);
    return;
}

// ============================================================
// Function: FUN_18014f3d0
// Address: 0x18014f3d0
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18014f3d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_98h)
{
    double dVar1;
    double dVar2;
    double dVar3;
    undefined4 uVar4;
    double dVar5;
    double dVar6;
    uint64_t uVar7;
    undefined4 in_XMM1_Da;
    undefined4 in_XMM1_Db;
    undefined4 uVar8;
    double in_XMM2_Qa;
    double in_XMM3_Qa;
    undefined4 uVar9;
    float fVar10;
    undefined4 uVar11;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    uVar8 = SUB84(in_XMM2_Qa, 0);
    if (in_XMM2_Qa == in_XMM3_Qa) {
        return 0;
    }
    if (in_XMM3_Qa <= in_XMM2_Qa) {
        dVar5 = in_XMM3_Qa;
        dVar6 = in_XMM2_Qa;
        if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= in_XMM3_Qa &&
            in_XMM3_Qa != (double)CONCAT44(in_XMM1_Db, in_XMM1_Da)) goto code_r0x00018014f418;
    } else {
        dVar5 = in_XMM2_Qa;
        dVar6 = in_XMM3_Qa;
        if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= in_XMM2_Qa &&
            in_XMM2_Qa != (double)CONCAT44(in_XMM1_Db, in_XMM1_Da)) goto code_r0x00018014f418;
    }
    dVar5 = dVar6;
    if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= dVar6) {
        dVar5 = (double)CONCAT44(in_XMM1_Db, in_XMM1_Da);
    }
code_r0x00018014f418:
    if ((float)arg_28h <= 0.0) {
        uVar7 = (uint64_t)(uint32_t)(float)((dVar5 - in_XMM2_Qa) / (in_XMM3_Qa - in_XMM2_Qa));
    } else {
        dVar6 = in_XMM3_Qa;
        uVar9 = (int32_t)((uint64_t)in_XMM2_Qa >> 0x20);
        if (in_XMM3_Qa < in_XMM2_Qa) {
            uVar8 = SUB84(in_XMM3_Qa, 0);
            dVar6 = in_XMM2_Qa;
            uVar9 = (int32_t)((uint64_t)in_XMM3_Qa >> 0x20);
        }
        dVar2 = (double)CONCAT44(uVar9, uVar8);
        dVar3 = (double)(float)arg_28h;
        fVar10 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        if ((double)(CONCAT44(uVar9, uVar8) & 0x7fffffffffffffff) < dVar3) {
            if (0.0 < (double)CONCAT44(uVar9, uVar8) || (double)CONCAT44(uVar9, uVar8) == 0.0) {
                dVar2 = (double)(float)arg_28h;
            } else {
                dVar2 = (double)fVar10;
            }
        }
        dVar1 = dVar6;
        if ((double)((uint64_t)dVar6 & 0x7fffffffffffffff) < dVar3) {
            if (dVar6 < 0.0) {
                arg_28h._0_4_ = fVar10;
            }
            dVar1 = (double)(float)arg_28h;
        }
        if (((double)CONCAT44(uVar9, uVar8) != 0.0) || (0.0 <= dVar6)) {
            if ((dVar6 == 0.0) && ((double)CONCAT44(uVar9, uVar8) <= 0.0 && (double)CONCAT44(uVar9, uVar8) != 0.0)) {
                dVar1 = (double)fVar10;
            }
        } else {
            dVar2 = (double)fVar10;
        }
        fVar10 = 0.0;
        uVar11 = 0;
        if ((dVar2 < dVar5) && (uVar4 = 0, fVar10 = 1.0, uVar11 = uVar4, dVar5 < dVar1)) {
            if (0.0 <= (double)CONCAT44(uVar9, uVar8) * dVar6) {
                if (((double)CONCAT44(uVar9, uVar8) <= 0.0 && (double)CONCAT44(uVar9, uVar8) != 0.0) || (dVar6 < 0.0)) {
                    dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar1 ^ 0x8000000000000000));
                    dVar6 = (double)fcn.180491150((double)((uint64_t)dVar2 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar1 ^ 0x8000000000000000));
                    fVar10 = 1.0 - (float)(dVar5 / dVar6);
                } else {
                    dVar5 = (double)fcn.180491150(dVar5 / dVar2);
                    dVar6 = (double)fcn.180491150(dVar1 / dVar2);
                    fVar10 = (float)(dVar5 / dVar6);
                    uVar11 = 0;
                }
            } else {
                fVar10 = (float)((uint32_t)(float)(double)CONCAT44(uVar9, uVar8) ^ 0x80000000) /
                         ((float)dVar6 - (float)(double)CONCAT44(uVar9, uVar8));
                uVar11 = 0x80000000;
                if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) != 0.0) {
                    if (0.0 < (double)CONCAT44(in_XMM1_Db, in_XMM1_Da) ||
                        (double)CONCAT44(in_XMM1_Db, in_XMM1_Da) == 0.0) {
                        dVar5 = (double)fcn.180491150(dVar5 / dVar3);
                        dVar6 = (double)fcn.180491150(dVar1 / dVar3);
                        fVar10 = (float)(dVar5 / dVar6) * (1.0 - (fVar10 + (float)arg_30h)) + fVar10 + (float)arg_30h;
                        uVar11 = 0;
                    } else {
                        dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) / dVar3);
                        dVar6 = (double)fcn.180491150((double)((uint64_t)dVar2 ^ 0x8000000000000000) / dVar3);
                        fVar10 = (1.0 - (float)(dVar5 / dVar6)) * (fVar10 - (float)arg_30h);
                        uVar11 = uVar4;
                    }
                }
            }
        }
        if (in_XMM2_Qa <= in_XMM3_Qa) {
            uVar7 = CONCAT44(uVar11, fVar10);
        } else {
            uVar7 = (uint64_t)(uint32_t)(1.0 - fVar10);
        }
    }
    return uVar7;
}

// ============================================================
// Function: FUN_18014f42f
// Address: 0x18014f42f
// Size: 111 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18014f3d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_98h)
{
    double dVar1;
    double dVar2;
    double dVar3;
    undefined4 uVar4;
    double dVar5;
    double dVar6;
    uint64_t uVar7;
    undefined4 in_XMM1_Da;
    undefined4 in_XMM1_Db;
    undefined4 uVar8;
    double in_XMM2_Qa;
    double in_XMM3_Qa;
    undefined4 uVar9;
    float fVar10;
    undefined4 uVar11;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    uVar8 = SUB84(in_XMM2_Qa, 0);
    if (in_XMM2_Qa == in_XMM3_Qa) {
        return 0;
    }
    if (in_XMM3_Qa <= in_XMM2_Qa) {
        dVar5 = in_XMM3_Qa;
        dVar6 = in_XMM2_Qa;
        if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= in_XMM3_Qa &&
            in_XMM3_Qa != (double)CONCAT44(in_XMM1_Db, in_XMM1_Da)) goto code_r0x00018014f418;
    } else {
        dVar5 = in_XMM2_Qa;
        dVar6 = in_XMM3_Qa;
        if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= in_XMM2_Qa &&
            in_XMM2_Qa != (double)CONCAT44(in_XMM1_Db, in_XMM1_Da)) goto code_r0x00018014f418;
    }
    dVar5 = dVar6;
    if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= dVar6) {
        dVar5 = (double)CONCAT44(in_XMM1_Db, in_XMM1_Da);
    }
code_r0x00018014f418:
    if ((float)arg_28h <= 0.0) {
        uVar7 = (uint64_t)(uint32_t)(float)((dVar5 - in_XMM2_Qa) / (in_XMM3_Qa - in_XMM2_Qa));
    } else {
        dVar6 = in_XMM3_Qa;
        uVar9 = (int32_t)((uint64_t)in_XMM2_Qa >> 0x20);
        if (in_XMM3_Qa < in_XMM2_Qa) {
            uVar8 = SUB84(in_XMM3_Qa, 0);
            dVar6 = in_XMM2_Qa;
            uVar9 = (int32_t)((uint64_t)in_XMM3_Qa >> 0x20);
        }
        dVar2 = (double)CONCAT44(uVar9, uVar8);
        dVar3 = (double)(float)arg_28h;
        fVar10 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        if ((double)(CONCAT44(uVar9, uVar8) & 0x7fffffffffffffff) < dVar3) {
            if (0.0 < (double)CONCAT44(uVar9, uVar8) || (double)CONCAT44(uVar9, uVar8) == 0.0) {
                dVar2 = (double)(float)arg_28h;
            } else {
                dVar2 = (double)fVar10;
            }
        }
        dVar1 = dVar6;
        if ((double)((uint64_t)dVar6 & 0x7fffffffffffffff) < dVar3) {
            if (dVar6 < 0.0) {
                arg_28h._0_4_ = fVar10;
            }
            dVar1 = (double)(float)arg_28h;
        }
        if (((double)CONCAT44(uVar9, uVar8) != 0.0) || (0.0 <= dVar6)) {
            if ((dVar6 == 0.0) && ((double)CONCAT44(uVar9, uVar8) <= 0.0 && (double)CONCAT44(uVar9, uVar8) != 0.0)) {
                dVar1 = (double)fVar10;
            }
        } else {
            dVar2 = (double)fVar10;
        }
        fVar10 = 0.0;
        uVar11 = 0;
        if ((dVar2 < dVar5) && (uVar4 = 0, fVar10 = 1.0, uVar11 = uVar4, dVar5 < dVar1)) {
            if (0.0 <= (double)CONCAT44(uVar9, uVar8) * dVar6) {
                if (((double)CONCAT44(uVar9, uVar8) <= 0.0 && (double)CONCAT44(uVar9, uVar8) != 0.0) || (dVar6 < 0.0)) {
                    dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar1 ^ 0x8000000000000000));
                    dVar6 = (double)fcn.180491150((double)((uint64_t)dVar2 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar1 ^ 0x8000000000000000));
                    fVar10 = 1.0 - (float)(dVar5 / dVar6);
                } else {
                    dVar5 = (double)fcn.180491150(dVar5 / dVar2);
                    dVar6 = (double)fcn.180491150(dVar1 / dVar2);
                    fVar10 = (float)(dVar5 / dVar6);
                    uVar11 = 0;
                }
            } else {
                fVar10 = (float)((uint32_t)(float)(double)CONCAT44(uVar9, uVar8) ^ 0x80000000) /
                         ((float)dVar6 - (float)(double)CONCAT44(uVar9, uVar8));
                uVar11 = 0x80000000;
                if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) != 0.0) {
                    if (0.0 < (double)CONCAT44(in_XMM1_Db, in_XMM1_Da) ||
                        (double)CONCAT44(in_XMM1_Db, in_XMM1_Da) == 0.0) {
                        dVar5 = (double)fcn.180491150(dVar5 / dVar3);
                        dVar6 = (double)fcn.180491150(dVar1 / dVar3);
                        fVar10 = (float)(dVar5 / dVar6) * (1.0 - (fVar10 + (float)arg_30h)) + fVar10 + (float)arg_30h;
                        uVar11 = 0;
                    } else {
                        dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) / dVar3);
                        dVar6 = (double)fcn.180491150((double)((uint64_t)dVar2 ^ 0x8000000000000000) / dVar3);
                        fVar10 = (1.0 - (float)(dVar5 / dVar6)) * (fVar10 - (float)arg_30h);
                        uVar11 = uVar4;
                    }
                }
            }
        }
        if (in_XMM2_Qa <= in_XMM3_Qa) {
            uVar7 = CONCAT44(uVar11, fVar10);
        } else {
            uVar7 = (uint64_t)(uint32_t)(1.0 - fVar10);
        }
    }
    return uVar7;
}

// ============================================================
// Function: FUN_18014f49e
// Address: 0x18014f49e
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18014f3d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_98h)
{
    double dVar1;
    double dVar2;
    double dVar3;
    undefined4 uVar4;
    double dVar5;
    double dVar6;
    uint64_t uVar7;
    undefined4 in_XMM1_Da;
    undefined4 in_XMM1_Db;
    undefined4 uVar8;
    double in_XMM2_Qa;
    double in_XMM3_Qa;
    undefined4 uVar9;
    float fVar10;
    undefined4 uVar11;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    uVar8 = SUB84(in_XMM2_Qa, 0);
    if (in_XMM2_Qa == in_XMM3_Qa) {
        return 0;
    }
    if (in_XMM3_Qa <= in_XMM2_Qa) {
        dVar5 = in_XMM3_Qa;
        dVar6 = in_XMM2_Qa;
        if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= in_XMM3_Qa &&
            in_XMM3_Qa != (double)CONCAT44(in_XMM1_Db, in_XMM1_Da)) goto code_r0x00018014f418;
    } else {
        dVar5 = in_XMM2_Qa;
        dVar6 = in_XMM3_Qa;
        if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= in_XMM2_Qa &&
            in_XMM2_Qa != (double)CONCAT44(in_XMM1_Db, in_XMM1_Da)) goto code_r0x00018014f418;
    }
    dVar5 = dVar6;
    if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= dVar6) {
        dVar5 = (double)CONCAT44(in_XMM1_Db, in_XMM1_Da);
    }
code_r0x00018014f418:
    if ((float)arg_28h <= 0.0) {
        uVar7 = (uint64_t)(uint32_t)(float)((dVar5 - in_XMM2_Qa) / (in_XMM3_Qa - in_XMM2_Qa));
    } else {
        dVar6 = in_XMM3_Qa;
        uVar9 = (int32_t)((uint64_t)in_XMM2_Qa >> 0x20);
        if (in_XMM3_Qa < in_XMM2_Qa) {
            uVar8 = SUB84(in_XMM3_Qa, 0);
            dVar6 = in_XMM2_Qa;
            uVar9 = (int32_t)((uint64_t)in_XMM3_Qa >> 0x20);
        }
        dVar2 = (double)CONCAT44(uVar9, uVar8);
        dVar3 = (double)(float)arg_28h;
        fVar10 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        if ((double)(CONCAT44(uVar9, uVar8) & 0x7fffffffffffffff) < dVar3) {
            if (0.0 < (double)CONCAT44(uVar9, uVar8) || (double)CONCAT44(uVar9, uVar8) == 0.0) {
                dVar2 = (double)(float)arg_28h;
            } else {
                dVar2 = (double)fVar10;
            }
        }
        dVar1 = dVar6;
        if ((double)((uint64_t)dVar6 & 0x7fffffffffffffff) < dVar3) {
            if (dVar6 < 0.0) {
                arg_28h._0_4_ = fVar10;
            }
            dVar1 = (double)(float)arg_28h;
        }
        if (((double)CONCAT44(uVar9, uVar8) != 0.0) || (0.0 <= dVar6)) {
            if ((dVar6 == 0.0) && ((double)CONCAT44(uVar9, uVar8) <= 0.0 && (double)CONCAT44(uVar9, uVar8) != 0.0)) {
                dVar1 = (double)fVar10;
            }
        } else {
            dVar2 = (double)fVar10;
        }
        fVar10 = 0.0;
        uVar11 = 0;
        if ((dVar2 < dVar5) && (uVar4 = 0, fVar10 = 1.0, uVar11 = uVar4, dVar5 < dVar1)) {
            if (0.0 <= (double)CONCAT44(uVar9, uVar8) * dVar6) {
                if (((double)CONCAT44(uVar9, uVar8) <= 0.0 && (double)CONCAT44(uVar9, uVar8) != 0.0) || (dVar6 < 0.0)) {
                    dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar1 ^ 0x8000000000000000));
                    dVar6 = (double)fcn.180491150((double)((uint64_t)dVar2 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar1 ^ 0x8000000000000000));
                    fVar10 = 1.0 - (float)(dVar5 / dVar6);
                } else {
                    dVar5 = (double)fcn.180491150(dVar5 / dVar2);
                    dVar6 = (double)fcn.180491150(dVar1 / dVar2);
                    fVar10 = (float)(dVar5 / dVar6);
                    uVar11 = 0;
                }
            } else {
                fVar10 = (float)((uint32_t)(float)(double)CONCAT44(uVar9, uVar8) ^ 0x80000000) /
                         ((float)dVar6 - (float)(double)CONCAT44(uVar9, uVar8));
                uVar11 = 0x80000000;
                if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) != 0.0) {
                    if (0.0 < (double)CONCAT44(in_XMM1_Db, in_XMM1_Da) ||
                        (double)CONCAT44(in_XMM1_Db, in_XMM1_Da) == 0.0) {
                        dVar5 = (double)fcn.180491150(dVar5 / dVar3);
                        dVar6 = (double)fcn.180491150(dVar1 / dVar3);
                        fVar10 = (float)(dVar5 / dVar6) * (1.0 - (fVar10 + (float)arg_30h)) + fVar10 + (float)arg_30h;
                        uVar11 = 0;
                    } else {
                        dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) / dVar3);
                        dVar6 = (double)fcn.180491150((double)((uint64_t)dVar2 ^ 0x8000000000000000) / dVar3);
                        fVar10 = (1.0 - (float)(dVar5 / dVar6)) * (fVar10 - (float)arg_30h);
                        uVar11 = uVar4;
                    }
                }
            }
        }
        if (in_XMM2_Qa <= in_XMM3_Qa) {
            uVar7 = CONCAT44(uVar11, fVar10);
        } else {
            uVar7 = (uint64_t)(uint32_t)(1.0 - fVar10);
        }
    }
    return uVar7;
}

// ============================================================
// Function: FUN_18014f4b0
// Address: 0x18014f4b0
// Size: 545 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18014f3d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_98h)
{
    double dVar1;
    double dVar2;
    double dVar3;
    undefined4 uVar4;
    double dVar5;
    double dVar6;
    uint64_t uVar7;
    undefined4 in_XMM1_Da;
    undefined4 in_XMM1_Db;
    undefined4 uVar8;
    double in_XMM2_Qa;
    double in_XMM3_Qa;
    undefined4 uVar9;
    float fVar10;
    undefined4 uVar11;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    uVar8 = SUB84(in_XMM2_Qa, 0);
    if (in_XMM2_Qa == in_XMM3_Qa) {
        return 0;
    }
    if (in_XMM3_Qa <= in_XMM2_Qa) {
        dVar5 = in_XMM3_Qa;
        dVar6 = in_XMM2_Qa;
        if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= in_XMM3_Qa &&
            in_XMM3_Qa != (double)CONCAT44(in_XMM1_Db, in_XMM1_Da)) goto code_r0x00018014f418;
    } else {
        dVar5 = in_XMM2_Qa;
        dVar6 = in_XMM3_Qa;
        if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= in_XMM2_Qa &&
            in_XMM2_Qa != (double)CONCAT44(in_XMM1_Db, in_XMM1_Da)) goto code_r0x00018014f418;
    }
    dVar5 = dVar6;
    if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= dVar6) {
        dVar5 = (double)CONCAT44(in_XMM1_Db, in_XMM1_Da);
    }
code_r0x00018014f418:
    if ((float)arg_28h <= 0.0) {
        uVar7 = (uint64_t)(uint32_t)(float)((dVar5 - in_XMM2_Qa) / (in_XMM3_Qa - in_XMM2_Qa));
    } else {
        dVar6 = in_XMM3_Qa;
        uVar9 = (int32_t)((uint64_t)in_XMM2_Qa >> 0x20);
        if (in_XMM3_Qa < in_XMM2_Qa) {
            uVar8 = SUB84(in_XMM3_Qa, 0);
            dVar6 = in_XMM2_Qa;
            uVar9 = (int32_t)((uint64_t)in_XMM3_Qa >> 0x20);
        }
        dVar2 = (double)CONCAT44(uVar9, uVar8);
        dVar3 = (double)(float)arg_28h;
        fVar10 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        if ((double)(CONCAT44(uVar9, uVar8) & 0x7fffffffffffffff) < dVar3) {
            if (0.0 < (double)CONCAT44(uVar9, uVar8) || (double)CONCAT44(uVar9, uVar8) == 0.0) {
                dVar2 = (double)(float)arg_28h;
            } else {
                dVar2 = (double)fVar10;
            }
        }
        dVar1 = dVar6;
        if ((double)((uint64_t)dVar6 & 0x7fffffffffffffff) < dVar3) {
            if (dVar6 < 0.0) {
                arg_28h._0_4_ = fVar10;
            }
            dVar1 = (double)(float)arg_28h;
        }
        if (((double)CONCAT44(uVar9, uVar8) != 0.0) || (0.0 <= dVar6)) {
            if ((dVar6 == 0.0) && ((double)CONCAT44(uVar9, uVar8) <= 0.0 && (double)CONCAT44(uVar9, uVar8) != 0.0)) {
                dVar1 = (double)fVar10;
            }
        } else {
            dVar2 = (double)fVar10;
        }
        fVar10 = 0.0;
        uVar11 = 0;
        if ((dVar2 < dVar5) && (uVar4 = 0, fVar10 = 1.0, uVar11 = uVar4, dVar5 < dVar1)) {
            if (0.0 <= (double)CONCAT44(uVar9, uVar8) * dVar6) {
                if (((double)CONCAT44(uVar9, uVar8) <= 0.0 && (double)CONCAT44(uVar9, uVar8) != 0.0) || (dVar6 < 0.0)) {
                    dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar1 ^ 0x8000000000000000));
                    dVar6 = (double)fcn.180491150((double)((uint64_t)dVar2 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar1 ^ 0x8000000000000000));
                    fVar10 = 1.0 - (float)(dVar5 / dVar6);
                } else {
                    dVar5 = (double)fcn.180491150(dVar5 / dVar2);
                    dVar6 = (double)fcn.180491150(dVar1 / dVar2);
                    fVar10 = (float)(dVar5 / dVar6);
                    uVar11 = 0;
                }
            } else {
                fVar10 = (float)((uint32_t)(float)(double)CONCAT44(uVar9, uVar8) ^ 0x80000000) /
                         ((float)dVar6 - (float)(double)CONCAT44(uVar9, uVar8));
                uVar11 = 0x80000000;
                if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) != 0.0) {
                    if (0.0 < (double)CONCAT44(in_XMM1_Db, in_XMM1_Da) ||
                        (double)CONCAT44(in_XMM1_Db, in_XMM1_Da) == 0.0) {
                        dVar5 = (double)fcn.180491150(dVar5 / dVar3);
                        dVar6 = (double)fcn.180491150(dVar1 / dVar3);
                        fVar10 = (float)(dVar5 / dVar6) * (1.0 - (fVar10 + (float)arg_30h)) + fVar10 + (float)arg_30h;
                        uVar11 = 0;
                    } else {
                        dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) / dVar3);
                        dVar6 = (double)fcn.180491150((double)((uint64_t)dVar2 ^ 0x8000000000000000) / dVar3);
                        fVar10 = (1.0 - (float)(dVar5 / dVar6)) * (fVar10 - (float)arg_30h);
                        uVar11 = uVar4;
                    }
                }
            }
        }
        if (in_XMM2_Qa <= in_XMM3_Qa) {
            uVar7 = CONCAT44(uVar11, fVar10);
        } else {
            uVar7 = (uint64_t)(uint32_t)(1.0 - fVar10);
        }
    }
    return uVar7;
}

// ============================================================
// Function: FUN_18014f6d1
// Address: 0x18014f6d1
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18014f3d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_98h)
{
    double dVar1;
    double dVar2;
    double dVar3;
    undefined4 uVar4;
    double dVar5;
    double dVar6;
    uint64_t uVar7;
    undefined4 in_XMM1_Da;
    undefined4 in_XMM1_Db;
    undefined4 uVar8;
    double in_XMM2_Qa;
    double in_XMM3_Qa;
    undefined4 uVar9;
    float fVar10;
    undefined4 uVar11;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    uVar8 = SUB84(in_XMM2_Qa, 0);
    if (in_XMM2_Qa == in_XMM3_Qa) {
        return 0;
    }
    if (in_XMM3_Qa <= in_XMM2_Qa) {
        dVar5 = in_XMM3_Qa;
        dVar6 = in_XMM2_Qa;
        if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= in_XMM3_Qa &&
            in_XMM3_Qa != (double)CONCAT44(in_XMM1_Db, in_XMM1_Da)) goto code_r0x00018014f418;
    } else {
        dVar5 = in_XMM2_Qa;
        dVar6 = in_XMM3_Qa;
        if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= in_XMM2_Qa &&
            in_XMM2_Qa != (double)CONCAT44(in_XMM1_Db, in_XMM1_Da)) goto code_r0x00018014f418;
    }
    dVar5 = dVar6;
    if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= dVar6) {
        dVar5 = (double)CONCAT44(in_XMM1_Db, in_XMM1_Da);
    }
code_r0x00018014f418:
    if ((float)arg_28h <= 0.0) {
        uVar7 = (uint64_t)(uint32_t)(float)((dVar5 - in_XMM2_Qa) / (in_XMM3_Qa - in_XMM2_Qa));
    } else {
        dVar6 = in_XMM3_Qa;
        uVar9 = (int32_t)((uint64_t)in_XMM2_Qa >> 0x20);
        if (in_XMM3_Qa < in_XMM2_Qa) {
            uVar8 = SUB84(in_XMM3_Qa, 0);
            dVar6 = in_XMM2_Qa;
            uVar9 = (int32_t)((uint64_t)in_XMM3_Qa >> 0x20);
        }
        dVar2 = (double)CONCAT44(uVar9, uVar8);
        dVar3 = (double)(float)arg_28h;
        fVar10 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        if ((double)(CONCAT44(uVar9, uVar8) & 0x7fffffffffffffff) < dVar3) {
            if (0.0 < (double)CONCAT44(uVar9, uVar8) || (double)CONCAT44(uVar9, uVar8) == 0.0) {
                dVar2 = (double)(float)arg_28h;
            } else {
                dVar2 = (double)fVar10;
            }
        }
        dVar1 = dVar6;
        if ((double)((uint64_t)dVar6 & 0x7fffffffffffffff) < dVar3) {
            if (dVar6 < 0.0) {
                arg_28h._0_4_ = fVar10;
            }
            dVar1 = (double)(float)arg_28h;
        }
        if (((double)CONCAT44(uVar9, uVar8) != 0.0) || (0.0 <= dVar6)) {
            if ((dVar6 == 0.0) && ((double)CONCAT44(uVar9, uVar8) <= 0.0 && (double)CONCAT44(uVar9, uVar8) != 0.0)) {
                dVar1 = (double)fVar10;
            }
        } else {
            dVar2 = (double)fVar10;
        }
        fVar10 = 0.0;
        uVar11 = 0;
        if ((dVar2 < dVar5) && (uVar4 = 0, fVar10 = 1.0, uVar11 = uVar4, dVar5 < dVar1)) {
            if (0.0 <= (double)CONCAT44(uVar9, uVar8) * dVar6) {
                if (((double)CONCAT44(uVar9, uVar8) <= 0.0 && (double)CONCAT44(uVar9, uVar8) != 0.0) || (dVar6 < 0.0)) {
                    dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar1 ^ 0x8000000000000000));
                    dVar6 = (double)fcn.180491150((double)((uint64_t)dVar2 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar1 ^ 0x8000000000000000));
                    fVar10 = 1.0 - (float)(dVar5 / dVar6);
                } else {
                    dVar5 = (double)fcn.180491150(dVar5 / dVar2);
                    dVar6 = (double)fcn.180491150(dVar1 / dVar2);
                    fVar10 = (float)(dVar5 / dVar6);
                    uVar11 = 0;
                }
            } else {
                fVar10 = (float)((uint32_t)(float)(double)CONCAT44(uVar9, uVar8) ^ 0x80000000) /
                         ((float)dVar6 - (float)(double)CONCAT44(uVar9, uVar8));
                uVar11 = 0x80000000;
                if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) != 0.0) {
                    if (0.0 < (double)CONCAT44(in_XMM1_Db, in_XMM1_Da) ||
                        (double)CONCAT44(in_XMM1_Db, in_XMM1_Da) == 0.0) {
                        dVar5 = (double)fcn.180491150(dVar5 / dVar3);
                        dVar6 = (double)fcn.180491150(dVar1 / dVar3);
                        fVar10 = (float)(dVar5 / dVar6) * (1.0 - (fVar10 + (float)arg_30h)) + fVar10 + (float)arg_30h;
                        uVar11 = 0;
                    } else {
                        dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) / dVar3);
                        dVar6 = (double)fcn.180491150((double)((uint64_t)dVar2 ^ 0x8000000000000000) / dVar3);
                        fVar10 = (1.0 - (float)(dVar5 / dVar6)) * (fVar10 - (float)arg_30h);
                        uVar11 = uVar4;
                    }
                }
            }
        }
        if (in_XMM2_Qa <= in_XMM3_Qa) {
            uVar7 = CONCAT44(uVar11, fVar10);
        } else {
            uVar7 = (uint64_t)(uint32_t)(1.0 - fVar10);
        }
    }
    return uVar7;
}

// ============================================================
// Function: FUN_18014f6e2
// Address: 0x18014f6e2
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18014f3d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_98h)
{
    double dVar1;
    double dVar2;
    double dVar3;
    undefined4 uVar4;
    double dVar5;
    double dVar6;
    uint64_t uVar7;
    undefined4 in_XMM1_Da;
    undefined4 in_XMM1_Db;
    undefined4 uVar8;
    double in_XMM2_Qa;
    double in_XMM3_Qa;
    undefined4 uVar9;
    float fVar10;
    undefined4 uVar11;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    uVar8 = SUB84(in_XMM2_Qa, 0);
    if (in_XMM2_Qa == in_XMM3_Qa) {
        return 0;
    }
    if (in_XMM3_Qa <= in_XMM2_Qa) {
        dVar5 = in_XMM3_Qa;
        dVar6 = in_XMM2_Qa;
        if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= in_XMM3_Qa &&
            in_XMM3_Qa != (double)CONCAT44(in_XMM1_Db, in_XMM1_Da)) goto code_r0x00018014f418;
    } else {
        dVar5 = in_XMM2_Qa;
        dVar6 = in_XMM3_Qa;
        if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= in_XMM2_Qa &&
            in_XMM2_Qa != (double)CONCAT44(in_XMM1_Db, in_XMM1_Da)) goto code_r0x00018014f418;
    }
    dVar5 = dVar6;
    if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= dVar6) {
        dVar5 = (double)CONCAT44(in_XMM1_Db, in_XMM1_Da);
    }
code_r0x00018014f418:
    if ((float)arg_28h <= 0.0) {
        uVar7 = (uint64_t)(uint32_t)(float)((dVar5 - in_XMM2_Qa) / (in_XMM3_Qa - in_XMM2_Qa));
    } else {
        dVar6 = in_XMM3_Qa;
        uVar9 = (int32_t)((uint64_t)in_XMM2_Qa >> 0x20);
        if (in_XMM3_Qa < in_XMM2_Qa) {
            uVar8 = SUB84(in_XMM3_Qa, 0);
            dVar6 = in_XMM2_Qa;
            uVar9 = (int32_t)((uint64_t)in_XMM3_Qa >> 0x20);
        }
        dVar2 = (double)CONCAT44(uVar9, uVar8);
        dVar3 = (double)(float)arg_28h;
        fVar10 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        if ((double)(CONCAT44(uVar9, uVar8) & 0x7fffffffffffffff) < dVar3) {
            if (0.0 < (double)CONCAT44(uVar9, uVar8) || (double)CONCAT44(uVar9, uVar8) == 0.0) {
                dVar2 = (double)(float)arg_28h;
            } else {
                dVar2 = (double)fVar10;
            }
        }
        dVar1 = dVar6;
        if ((double)((uint64_t)dVar6 & 0x7fffffffffffffff) < dVar3) {
            if (dVar6 < 0.0) {
                arg_28h._0_4_ = fVar10;
            }
            dVar1 = (double)(float)arg_28h;
        }
        if (((double)CONCAT44(uVar9, uVar8) != 0.0) || (0.0 <= dVar6)) {
            if ((dVar6 == 0.0) && ((double)CONCAT44(uVar9, uVar8) <= 0.0 && (double)CONCAT44(uVar9, uVar8) != 0.0)) {
                dVar1 = (double)fVar10;
            }
        } else {
            dVar2 = (double)fVar10;
        }
        fVar10 = 0.0;
        uVar11 = 0;
        if ((dVar2 < dVar5) && (uVar4 = 0, fVar10 = 1.0, uVar11 = uVar4, dVar5 < dVar1)) {
            if (0.0 <= (double)CONCAT44(uVar9, uVar8) * dVar6) {
                if (((double)CONCAT44(uVar9, uVar8) <= 0.0 && (double)CONCAT44(uVar9, uVar8) != 0.0) || (dVar6 < 0.0)) {
                    dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar1 ^ 0x8000000000000000));
                    dVar6 = (double)fcn.180491150((double)((uint64_t)dVar2 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar1 ^ 0x8000000000000000));
                    fVar10 = 1.0 - (float)(dVar5 / dVar6);
                } else {
                    dVar5 = (double)fcn.180491150(dVar5 / dVar2);
                    dVar6 = (double)fcn.180491150(dVar1 / dVar2);
                    fVar10 = (float)(dVar5 / dVar6);
                    uVar11 = 0;
                }
            } else {
                fVar10 = (float)((uint32_t)(float)(double)CONCAT44(uVar9, uVar8) ^ 0x80000000) /
                         ((float)dVar6 - (float)(double)CONCAT44(uVar9, uVar8));
                uVar11 = 0x80000000;
                if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) != 0.0) {
                    if (0.0 < (double)CONCAT44(in_XMM1_Db, in_XMM1_Da) ||
                        (double)CONCAT44(in_XMM1_Db, in_XMM1_Da) == 0.0) {
                        dVar5 = (double)fcn.180491150(dVar5 / dVar3);
                        dVar6 = (double)fcn.180491150(dVar1 / dVar3);
                        fVar10 = (float)(dVar5 / dVar6) * (1.0 - (fVar10 + (float)arg_30h)) + fVar10 + (float)arg_30h;
                        uVar11 = 0;
                    } else {
                        dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) / dVar3);
                        dVar6 = (double)fcn.180491150((double)((uint64_t)dVar2 ^ 0x8000000000000000) / dVar3);
                        fVar10 = (1.0 - (float)(dVar5 / dVar6)) * (fVar10 - (float)arg_30h);
                        uVar11 = uVar4;
                    }
                }
            }
        }
        if (in_XMM2_Qa <= in_XMM3_Qa) {
            uVar7 = CONCAT44(uVar11, fVar10);
        } else {
            uVar7 = (uint64_t)(uint32_t)(1.0 - fVar10);
        }
    }
    return uVar7;
}

// ============================================================
// Function: FUN_18014f6f2
// Address: 0x18014f6f2
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18014f3d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_98h)
{
    double dVar1;
    double dVar2;
    double dVar3;
    undefined4 uVar4;
    double dVar5;
    double dVar6;
    uint64_t uVar7;
    undefined4 in_XMM1_Da;
    undefined4 in_XMM1_Db;
    undefined4 uVar8;
    double in_XMM2_Qa;
    double in_XMM3_Qa;
    undefined4 uVar9;
    float fVar10;
    undefined4 uVar11;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_8h;
    
    uVar8 = SUB84(in_XMM2_Qa, 0);
    if (in_XMM2_Qa == in_XMM3_Qa) {
        return 0;
    }
    if (in_XMM3_Qa <= in_XMM2_Qa) {
        dVar5 = in_XMM3_Qa;
        dVar6 = in_XMM2_Qa;
        if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= in_XMM3_Qa &&
            in_XMM3_Qa != (double)CONCAT44(in_XMM1_Db, in_XMM1_Da)) goto code_r0x00018014f418;
    } else {
        dVar5 = in_XMM2_Qa;
        dVar6 = in_XMM3_Qa;
        if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= in_XMM2_Qa &&
            in_XMM2_Qa != (double)CONCAT44(in_XMM1_Db, in_XMM1_Da)) goto code_r0x00018014f418;
    }
    dVar5 = dVar6;
    if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) <= dVar6) {
        dVar5 = (double)CONCAT44(in_XMM1_Db, in_XMM1_Da);
    }
code_r0x00018014f418:
    if ((float)arg_28h <= 0.0) {
        uVar7 = (uint64_t)(uint32_t)(float)((dVar5 - in_XMM2_Qa) / (in_XMM3_Qa - in_XMM2_Qa));
    } else {
        dVar6 = in_XMM3_Qa;
        uVar9 = (int32_t)((uint64_t)in_XMM2_Qa >> 0x20);
        if (in_XMM3_Qa < in_XMM2_Qa) {
            uVar8 = SUB84(in_XMM3_Qa, 0);
            dVar6 = in_XMM2_Qa;
            uVar9 = (int32_t)((uint64_t)in_XMM3_Qa >> 0x20);
        }
        dVar2 = (double)CONCAT44(uVar9, uVar8);
        dVar3 = (double)(float)arg_28h;
        fVar10 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
        if ((double)(CONCAT44(uVar9, uVar8) & 0x7fffffffffffffff) < dVar3) {
            if (0.0 < (double)CONCAT44(uVar9, uVar8) || (double)CONCAT44(uVar9, uVar8) == 0.0) {
                dVar2 = (double)(float)arg_28h;
            } else {
                dVar2 = (double)fVar10;
            }
        }
        dVar1 = dVar6;
        if ((double)((uint64_t)dVar6 & 0x7fffffffffffffff) < dVar3) {
            if (dVar6 < 0.0) {
                arg_28h._0_4_ = fVar10;
            }
            dVar1 = (double)(float)arg_28h;
        }
        if (((double)CONCAT44(uVar9, uVar8) != 0.0) || (0.0 <= dVar6)) {
            if ((dVar6 == 0.0) && ((double)CONCAT44(uVar9, uVar8) <= 0.0 && (double)CONCAT44(uVar9, uVar8) != 0.0)) {
                dVar1 = (double)fVar10;
            }
        } else {
            dVar2 = (double)fVar10;
        }
        fVar10 = 0.0;
        uVar11 = 0;
        if ((dVar2 < dVar5) && (uVar4 = 0, fVar10 = 1.0, uVar11 = uVar4, dVar5 < dVar1)) {
            if (0.0 <= (double)CONCAT44(uVar9, uVar8) * dVar6) {
                if (((double)CONCAT44(uVar9, uVar8) <= 0.0 && (double)CONCAT44(uVar9, uVar8) != 0.0) || (dVar6 < 0.0)) {
                    dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar1 ^ 0x8000000000000000));
                    dVar6 = (double)fcn.180491150((double)((uint64_t)dVar2 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar1 ^ 0x8000000000000000));
                    fVar10 = 1.0 - (float)(dVar5 / dVar6);
                } else {
                    dVar5 = (double)fcn.180491150(dVar5 / dVar2);
                    dVar6 = (double)fcn.180491150(dVar1 / dVar2);
                    fVar10 = (float)(dVar5 / dVar6);
                    uVar11 = 0;
                }
            } else {
                fVar10 = (float)((uint32_t)(float)(double)CONCAT44(uVar9, uVar8) ^ 0x80000000) /
                         ((float)dVar6 - (float)(double)CONCAT44(uVar9, uVar8));
                uVar11 = 0x80000000;
                if ((double)CONCAT44(in_XMM1_Db, in_XMM1_Da) != 0.0) {
                    if (0.0 < (double)CONCAT44(in_XMM1_Db, in_XMM1_Da) ||
                        (double)CONCAT44(in_XMM1_Db, in_XMM1_Da) == 0.0) {
                        dVar5 = (double)fcn.180491150(dVar5 / dVar3);
                        dVar6 = (double)fcn.180491150(dVar1 / dVar3);
                        fVar10 = (float)(dVar5 / dVar6) * (1.0 - (fVar10 + (float)arg_30h)) + fVar10 + (float)arg_30h;
                        uVar11 = 0;
                    } else {
                        dVar5 = (double)fcn.180491150((double)((uint64_t)dVar5 ^ 0x8000000000000000) / dVar3);
                        dVar6 = (double)fcn.180491150((double)((uint64_t)dVar2 ^ 0x8000000000000000) / dVar3);
                        fVar10 = (1.0 - (float)(dVar5 / dVar6)) * (fVar10 - (float)arg_30h);
                        uVar11 = uVar4;
                    }
                }
            }
        }
        if (in_XMM2_Qa <= in_XMM3_Qa) {
            uVar7 = CONCAT44(uVar11, fVar10);
        } else {
            uVar7 = (uint64_t)(uint32_t)(1.0 - fVar10);
        }
    }
    return uVar7;
}

// ============================================================
// Function: FUN_18014f720
// Address: 0x18014f720
// Size: 34 bytes
// ============================================================
double fcn.18014f720(int64_t arg1, int64_t arg_28h, int64_t arg_30h)
{
    bool bVar1;
    bool bVar2;
    double dVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    float in_XMM1_Da;
    double in_XMM2_Qa;
    undefined4 in_XMM3_Da;
    undefined4 in_XMM3_Db;
    float fVar7;
    float fVar8;
    double dVar9;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if ((0.0 < in_XMM1_Da) && (in_XMM2_Qa != (double)CONCAT44(in_XMM3_Db, in_XMM3_Da))) {
        if (1.0 <= in_XMM1_Da) {
            return (double)CONCAT44(in_XMM3_Db, in_XMM3_Da);
        }
        if ((float)arg_28h <= 0.0) {
            if ((int32_t)arg1 - 8U < 2) {
                dVar6 = ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) - in_XMM2_Qa) * (double)in_XMM1_Da + in_XMM2_Qa;
            } else if (1.0 <= in_XMM1_Da) {
                dVar6 = 0.0;
            } else {
                dVar6 = ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) - in_XMM2_Qa) * (double)in_XMM1_Da;
                if (in_XMM2_Qa < (double)CONCAT44(in_XMM3_Db, in_XMM3_Da) ||
                    in_XMM2_Qa == (double)CONCAT44(in_XMM3_Db, in_XMM3_Da)) {
                    dVar6 = dVar6 + 0.5 + in_XMM2_Qa;
                } else {
                    dVar6 = dVar6 + -0.5 + in_XMM2_Qa;
                }
            }
        } else {
            dVar3 = (double)(float)arg_28h;
            fVar7 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            dVar6 = 0.0;
            dVar5 = in_XMM2_Qa;
            if ((double)((uint64_t)in_XMM2_Qa & 0x7fffffffffffffff) < dVar3) {
                if (0.0 <= in_XMM2_Qa) {
                    dVar5 = (double)(float)arg_28h;
                } else {
                    dVar5 = (double)fVar7;
                }
            }
            if (dVar3 <= (double)(CONCAT44(in_XMM3_Db, in_XMM3_Da) & 0x7fffffffffffffff)) {
                dVar9 = (double)CONCAT44(in_XMM3_Db, in_XMM3_Da);
            } else {
                if ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) <= 0.0 && (double)CONCAT44(in_XMM3_Db, in_XMM3_Da) != 0.0)
                {
                    arg_28h._0_4_ = fVar7;
                }
                dVar9 = (double)(float)arg_28h;
            }
            bVar1 = in_XMM2_Qa != (double)CONCAT44(in_XMM3_Db, in_XMM3_Da);
            bVar2 = (double)CONCAT44(in_XMM3_Db, in_XMM3_Da) <= in_XMM2_Qa;
            dVar4 = dVar5;
            if (bVar2 && bVar1) {
                dVar4 = dVar9;
                dVar9 = dVar5;
            }
            if (((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) == 0.0) && (in_XMM2_Qa < 0.0)) {
                dVar9 = (double)fVar7;
            }
            if (bVar2 && bVar1) {
                in_XMM1_Da = 1.0 - in_XMM1_Da;
            }
            if (0.0 <= in_XMM2_Qa * (double)CONCAT44(in_XMM3_Db, in_XMM3_Da)) {
                if ((in_XMM2_Qa < 0.0) ||
                   ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) <= 0.0 && (double)CONCAT44(in_XMM3_Db, in_XMM3_Da) != 0.0))
                {
                    dVar6 = (double)fcn.180491d70((double)((uint64_t)dVar4 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar9 ^ 0x8000000000000000), 
                                                  (double)(1.0 - in_XMM1_Da));
                    dVar6 = dVar6 * (double)((uint64_t)dVar9 ^ 0x8000000000000000);
                } else {
                    dVar6 = (double)fcn.180491d70(dVar9 / dVar4, (double)in_XMM1_Da);
                    dVar6 = dVar6 * dVar4;
                }
            } else {
                dVar5 = in_XMM2_Qa;
                if ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) <= in_XMM2_Qa) {
                    dVar5 = (double)CONCAT44(in_XMM3_Db, in_XMM3_Da);
                }
                fVar8 = (float)((uint32_t)(float)dVar5 ^ 0x80000000) /
                        (float)((uint32_t)((float)(double)CONCAT44(in_XMM3_Db, in_XMM3_Da) - (float)in_XMM2_Qa) &
                               0x7fffffff);
                fVar7 = fVar8 + (float)arg_30h;
                if ((in_XMM1_Da < fVar8 - (float)arg_30h) || (fVar7 < in_XMM1_Da)) {
                    if (fVar8 <= in_XMM1_Da) {
                        dVar6 = (double)fcn.180491d70(dVar9 / dVar3, (double)((in_XMM1_Da - fVar7) / (1.0 - fVar7)));
                        dVar6 = dVar6 * dVar3;
                    } else {
                        dVar6 = (double)fcn.180491d70((double)((uint64_t)dVar4 ^ 0x8000000000000000) / dVar3, 
                                                      (double)(1.0 - in_XMM1_Da / (fVar8 - (float)arg_30h)));
                        dVar6 = (double)((uint64_t)(dVar6 * dVar3) & 0xffffffff);
                    }
                }
            }
        }
        return dVar6;
    }
    return in_XMM2_Qa;
}

// ============================================================
// Function: FUN_18014f742
// Address: 0x18014f742
// Size: 35 bytes
// ============================================================
double fcn.18014f720(int64_t arg1, int64_t arg_28h, int64_t arg_30h)
{
    bool bVar1;
    bool bVar2;
    double dVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    float in_XMM1_Da;
    double in_XMM2_Qa;
    undefined4 in_XMM3_Da;
    undefined4 in_XMM3_Db;
    float fVar7;
    float fVar8;
    double dVar9;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if ((0.0 < in_XMM1_Da) && (in_XMM2_Qa != (double)CONCAT44(in_XMM3_Db, in_XMM3_Da))) {
        if (1.0 <= in_XMM1_Da) {
            return (double)CONCAT44(in_XMM3_Db, in_XMM3_Da);
        }
        if ((float)arg_28h <= 0.0) {
            if ((int32_t)arg1 - 8U < 2) {
                dVar6 = ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) - in_XMM2_Qa) * (double)in_XMM1_Da + in_XMM2_Qa;
            } else if (1.0 <= in_XMM1_Da) {
                dVar6 = 0.0;
            } else {
                dVar6 = ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) - in_XMM2_Qa) * (double)in_XMM1_Da;
                if (in_XMM2_Qa < (double)CONCAT44(in_XMM3_Db, in_XMM3_Da) ||
                    in_XMM2_Qa == (double)CONCAT44(in_XMM3_Db, in_XMM3_Da)) {
                    dVar6 = dVar6 + 0.5 + in_XMM2_Qa;
                } else {
                    dVar6 = dVar6 + -0.5 + in_XMM2_Qa;
                }
            }
        } else {
            dVar3 = (double)(float)arg_28h;
            fVar7 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            dVar6 = 0.0;
            dVar5 = in_XMM2_Qa;
            if ((double)((uint64_t)in_XMM2_Qa & 0x7fffffffffffffff) < dVar3) {
                if (0.0 <= in_XMM2_Qa) {
                    dVar5 = (double)(float)arg_28h;
                } else {
                    dVar5 = (double)fVar7;
                }
            }
            if (dVar3 <= (double)(CONCAT44(in_XMM3_Db, in_XMM3_Da) & 0x7fffffffffffffff)) {
                dVar9 = (double)CONCAT44(in_XMM3_Db, in_XMM3_Da);
            } else {
                if ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) <= 0.0 && (double)CONCAT44(in_XMM3_Db, in_XMM3_Da) != 0.0)
                {
                    arg_28h._0_4_ = fVar7;
                }
                dVar9 = (double)(float)arg_28h;
            }
            bVar1 = in_XMM2_Qa != (double)CONCAT44(in_XMM3_Db, in_XMM3_Da);
            bVar2 = (double)CONCAT44(in_XMM3_Db, in_XMM3_Da) <= in_XMM2_Qa;
            dVar4 = dVar5;
            if (bVar2 && bVar1) {
                dVar4 = dVar9;
                dVar9 = dVar5;
            }
            if (((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) == 0.0) && (in_XMM2_Qa < 0.0)) {
                dVar9 = (double)fVar7;
            }
            if (bVar2 && bVar1) {
                in_XMM1_Da = 1.0 - in_XMM1_Da;
            }
            if (0.0 <= in_XMM2_Qa * (double)CONCAT44(in_XMM3_Db, in_XMM3_Da)) {
                if ((in_XMM2_Qa < 0.0) ||
                   ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) <= 0.0 && (double)CONCAT44(in_XMM3_Db, in_XMM3_Da) != 0.0))
                {
                    dVar6 = (double)fcn.180491d70((double)((uint64_t)dVar4 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar9 ^ 0x8000000000000000), 
                                                  (double)(1.0 - in_XMM1_Da));
                    dVar6 = dVar6 * (double)((uint64_t)dVar9 ^ 0x8000000000000000);
                } else {
                    dVar6 = (double)fcn.180491d70(dVar9 / dVar4, (double)in_XMM1_Da);
                    dVar6 = dVar6 * dVar4;
                }
            } else {
                dVar5 = in_XMM2_Qa;
                if ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) <= in_XMM2_Qa) {
                    dVar5 = (double)CONCAT44(in_XMM3_Db, in_XMM3_Da);
                }
                fVar8 = (float)((uint32_t)(float)dVar5 ^ 0x80000000) /
                        (float)((uint32_t)((float)(double)CONCAT44(in_XMM3_Db, in_XMM3_Da) - (float)in_XMM2_Qa) &
                               0x7fffffff);
                fVar7 = fVar8 + (float)arg_30h;
                if ((in_XMM1_Da < fVar8 - (float)arg_30h) || (fVar7 < in_XMM1_Da)) {
                    if (fVar8 <= in_XMM1_Da) {
                        dVar6 = (double)fcn.180491d70(dVar9 / dVar3, (double)((in_XMM1_Da - fVar7) / (1.0 - fVar7)));
                        dVar6 = dVar6 * dVar3;
                    } else {
                        dVar6 = (double)fcn.180491d70((double)((uint64_t)dVar4 ^ 0x8000000000000000) / dVar3, 
                                                      (double)(1.0 - in_XMM1_Da / (fVar8 - (float)arg_30h)));
                        dVar6 = (double)((uint64_t)(dVar6 * dVar3) & 0xffffffff);
                    }
                }
            }
        }
        return dVar6;
    }
    return in_XMM2_Qa;
}

// ============================================================
// Function: FUN_18014f765
// Address: 0x18014f765
// Size: 654 bytes
// ============================================================
double fcn.18014f720(int64_t arg1, int64_t arg_28h, int64_t arg_30h)
{
    bool bVar1;
    bool bVar2;
    double dVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    float in_XMM1_Da;
    double in_XMM2_Qa;
    undefined4 in_XMM3_Da;
    undefined4 in_XMM3_Db;
    float fVar7;
    float fVar8;
    double dVar9;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if ((0.0 < in_XMM1_Da) && (in_XMM2_Qa != (double)CONCAT44(in_XMM3_Db, in_XMM3_Da))) {
        if (1.0 <= in_XMM1_Da) {
            return (double)CONCAT44(in_XMM3_Db, in_XMM3_Da);
        }
        if ((float)arg_28h <= 0.0) {
            if ((int32_t)arg1 - 8U < 2) {
                dVar6 = ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) - in_XMM2_Qa) * (double)in_XMM1_Da + in_XMM2_Qa;
            } else if (1.0 <= in_XMM1_Da) {
                dVar6 = 0.0;
            } else {
                dVar6 = ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) - in_XMM2_Qa) * (double)in_XMM1_Da;
                if (in_XMM2_Qa < (double)CONCAT44(in_XMM3_Db, in_XMM3_Da) ||
                    in_XMM2_Qa == (double)CONCAT44(in_XMM3_Db, in_XMM3_Da)) {
                    dVar6 = dVar6 + 0.5 + in_XMM2_Qa;
                } else {
                    dVar6 = dVar6 + -0.5 + in_XMM2_Qa;
                }
            }
        } else {
            dVar3 = (double)(float)arg_28h;
            fVar7 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            dVar6 = 0.0;
            dVar5 = in_XMM2_Qa;
            if ((double)((uint64_t)in_XMM2_Qa & 0x7fffffffffffffff) < dVar3) {
                if (0.0 <= in_XMM2_Qa) {
                    dVar5 = (double)(float)arg_28h;
                } else {
                    dVar5 = (double)fVar7;
                }
            }
            if (dVar3 <= (double)(CONCAT44(in_XMM3_Db, in_XMM3_Da) & 0x7fffffffffffffff)) {
                dVar9 = (double)CONCAT44(in_XMM3_Db, in_XMM3_Da);
            } else {
                if ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) <= 0.0 && (double)CONCAT44(in_XMM3_Db, in_XMM3_Da) != 0.0)
                {
                    arg_28h._0_4_ = fVar7;
                }
                dVar9 = (double)(float)arg_28h;
            }
            bVar1 = in_XMM2_Qa != (double)CONCAT44(in_XMM3_Db, in_XMM3_Da);
            bVar2 = (double)CONCAT44(in_XMM3_Db, in_XMM3_Da) <= in_XMM2_Qa;
            dVar4 = dVar5;
            if (bVar2 && bVar1) {
                dVar4 = dVar9;
                dVar9 = dVar5;
            }
            if (((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) == 0.0) && (in_XMM2_Qa < 0.0)) {
                dVar9 = (double)fVar7;
            }
            if (bVar2 && bVar1) {
                in_XMM1_Da = 1.0 - in_XMM1_Da;
            }
            if (0.0 <= in_XMM2_Qa * (double)CONCAT44(in_XMM3_Db, in_XMM3_Da)) {
                if ((in_XMM2_Qa < 0.0) ||
                   ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) <= 0.0 && (double)CONCAT44(in_XMM3_Db, in_XMM3_Da) != 0.0))
                {
                    dVar6 = (double)fcn.180491d70((double)((uint64_t)dVar4 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar9 ^ 0x8000000000000000), 
                                                  (double)(1.0 - in_XMM1_Da));
                    dVar6 = dVar6 * (double)((uint64_t)dVar9 ^ 0x8000000000000000);
                } else {
                    dVar6 = (double)fcn.180491d70(dVar9 / dVar4, (double)in_XMM1_Da);
                    dVar6 = dVar6 * dVar4;
                }
            } else {
                dVar5 = in_XMM2_Qa;
                if ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) <= in_XMM2_Qa) {
                    dVar5 = (double)CONCAT44(in_XMM3_Db, in_XMM3_Da);
                }
                fVar8 = (float)((uint32_t)(float)dVar5 ^ 0x80000000) /
                        (float)((uint32_t)((float)(double)CONCAT44(in_XMM3_Db, in_XMM3_Da) - (float)in_XMM2_Qa) &
                               0x7fffffff);
                fVar7 = fVar8 + (float)arg_30h;
                if ((in_XMM1_Da < fVar8 - (float)arg_30h) || (fVar7 < in_XMM1_Da)) {
                    if (fVar8 <= in_XMM1_Da) {
                        dVar6 = (double)fcn.180491d70(dVar9 / dVar3, (double)((in_XMM1_Da - fVar7) / (1.0 - fVar7)));
                        dVar6 = dVar6 * dVar3;
                    } else {
                        dVar6 = (double)fcn.180491d70((double)((uint64_t)dVar4 ^ 0x8000000000000000) / dVar3, 
                                                      (double)(1.0 - in_XMM1_Da / (fVar8 - (float)arg_30h)));
                        dVar6 = (double)((uint64_t)(dVar6 * dVar3) & 0xffffffff);
                    }
                }
            }
        }
        return dVar6;
    }
    return in_XMM2_Qa;
}

// ============================================================
// Function: FUN_18014f9f3
// Address: 0x18014f9f3
// Size: 8 bytes
// ============================================================
double fcn.18014f720(int64_t arg1, int64_t arg_28h, int64_t arg_30h)
{
    bool bVar1;
    bool bVar2;
    double dVar3;
    double dVar4;
    double dVar5;
    double dVar6;
    float in_XMM1_Da;
    double in_XMM2_Qa;
    undefined4 in_XMM3_Da;
    undefined4 in_XMM3_Db;
    float fVar7;
    float fVar8;
    double dVar9;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    if ((0.0 < in_XMM1_Da) && (in_XMM2_Qa != (double)CONCAT44(in_XMM3_Db, in_XMM3_Da))) {
        if (1.0 <= in_XMM1_Da) {
            return (double)CONCAT44(in_XMM3_Db, in_XMM3_Da);
        }
        if ((float)arg_28h <= 0.0) {
            if ((int32_t)arg1 - 8U < 2) {
                dVar6 = ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) - in_XMM2_Qa) * (double)in_XMM1_Da + in_XMM2_Qa;
            } else if (1.0 <= in_XMM1_Da) {
                dVar6 = 0.0;
            } else {
                dVar6 = ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) - in_XMM2_Qa) * (double)in_XMM1_Da;
                if (in_XMM2_Qa < (double)CONCAT44(in_XMM3_Db, in_XMM3_Da) ||
                    in_XMM2_Qa == (double)CONCAT44(in_XMM3_Db, in_XMM3_Da)) {
                    dVar6 = dVar6 + 0.5 + in_XMM2_Qa;
                } else {
                    dVar6 = dVar6 + -0.5 + in_XMM2_Qa;
                }
            }
        } else {
            dVar3 = (double)(float)arg_28h;
            fVar7 = (float)((uint32_t)(float)arg_28h ^ 0x80000000);
            dVar6 = 0.0;
            dVar5 = in_XMM2_Qa;
            if ((double)((uint64_t)in_XMM2_Qa & 0x7fffffffffffffff) < dVar3) {
                if (0.0 <= in_XMM2_Qa) {
                    dVar5 = (double)(float)arg_28h;
                } else {
                    dVar5 = (double)fVar7;
                }
            }
            if (dVar3 <= (double)(CONCAT44(in_XMM3_Db, in_XMM3_Da) & 0x7fffffffffffffff)) {
                dVar9 = (double)CONCAT44(in_XMM3_Db, in_XMM3_Da);
            } else {
                if ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) <= 0.0 && (double)CONCAT44(in_XMM3_Db, in_XMM3_Da) != 0.0)
                {
                    arg_28h._0_4_ = fVar7;
                }
                dVar9 = (double)(float)arg_28h;
            }
            bVar1 = in_XMM2_Qa != (double)CONCAT44(in_XMM3_Db, in_XMM3_Da);
            bVar2 = (double)CONCAT44(in_XMM3_Db, in_XMM3_Da) <= in_XMM2_Qa;
            dVar4 = dVar5;
            if (bVar2 && bVar1) {
                dVar4 = dVar9;
                dVar9 = dVar5;
            }
            if (((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) == 0.0) && (in_XMM2_Qa < 0.0)) {
                dVar9 = (double)fVar7;
            }
            if (bVar2 && bVar1) {
                in_XMM1_Da = 1.0 - in_XMM1_Da;
            }
            if (0.0 <= in_XMM2_Qa * (double)CONCAT44(in_XMM3_Db, in_XMM3_Da)) {
                if ((in_XMM2_Qa < 0.0) ||
                   ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) <= 0.0 && (double)CONCAT44(in_XMM3_Db, in_XMM3_Da) != 0.0))
                {
                    dVar6 = (double)fcn.180491d70((double)((uint64_t)dVar4 ^ 0x8000000000000000) /
                                                  (double)((uint64_t)dVar9 ^ 0x8000000000000000), 
                                                  (double)(1.0 - in_XMM1_Da));
                    dVar6 = dVar6 * (double)((uint64_t)dVar9 ^ 0x8000000000000000);
                } else {
                    dVar6 = (double)fcn.180491d70(dVar9 / dVar4, (double)in_XMM1_Da);
                    dVar6 = dVar6 * dVar4;
                }
            } else {
                dVar5 = in_XMM2_Qa;
                if ((double)CONCAT44(in_XMM3_Db, in_XMM3_Da) <= in_XMM2_Qa) {
                    dVar5 = (double)CONCAT44(in_XMM3_Db, in_XMM3_Da);
                }
                fVar8 = (float)((uint32_t)(float)dVar5 ^ 0x80000000) /
                        (float)((uint32_t)((float)(double)CONCAT44(in_XMM3_Db, in_XMM3_Da) - (float)in_XMM2_Qa) &
                               0x7fffffff);
                fVar7 = fVar8 + (float)arg_30h;
                if ((in_XMM1_Da < fVar8 - (float)arg_30h) || (fVar7 < in_XMM1_Da)) {
                    if (fVar8 <= in_XMM1_Da) {
                        dVar6 = (double)fcn.180491d70(dVar9 / dVar3, (double)((in_XMM1_Da - fVar7) / (1.0 - fVar7)));
                        dVar6 = dVar6 * dVar3;
                    } else {
                        dVar6 = (double)fcn.180491d70((double)((uint64_t)dVar4 ^ 0x8000000000000000) / dVar3, 
                                                      (double)(1.0 - in_XMM1_Da / (fVar8 - (float)arg_30h)));
                        dVar6 = (double)((uint64_t)(dVar6 * dVar3) & 0xffffffff);
                    }
                }
            }
        }
        return dVar6;
    }
    return in_XMM2_Qa;
}

// ============================================================
// Function: FUN_18014fa00
// Address: 0x18014fa00
// Size: 138 bytes
// ============================================================
void fcn.18014fa00(int64_t arg1)
{
    char *pcVar1;
    char cVar2;
    int64_t *piVar3;
    undefined auStack_88 [48];
    int64_t var_58h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    cVar2 = *(char *)arg1;
    while (cVar2 != '\0') {
        if (cVar2 == '%') {
            if (*(char *)(arg1 + 1) != '%') break;
            arg1 = arg1 + 1;
        }
        pcVar1 = (char *)(arg1 + 1);
        arg1 = arg1 + 1;
        cVar2 = *pcVar1;
    }
    if ((*(char *)arg1 == '%') && (*(char *)(arg1 + 1) != '%')) {
        piVar3 = &var_58h;
        if ((char)var_58h == ' ') {
            do {
                piVar3 = (int64_t *)((int64_t)piVar3 + 1);
            } while (*(char *)piVar3 == ' ');
        }
        func_0x000180471c88();
        func_0x000180459870(var_18h ^ (uint64_t)auStack_88);
        return;
    }
    func_0x000180459870(*(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88 ^ (uint64_t)auStack_88);
    return;
}

// ============================================================
// Function: FUN_18014fa90
// Address: 0x18014fa90
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014fa90(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x18);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x18);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18014faa9
// Address: 0x18014faa9
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014fa90(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x18);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x18);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18014faeb
// Address: 0x18014faeb
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014fa90(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x18);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x18);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18014fb00
// Address: 0x18014fb00
// Size: 28 bytes
// ============================================================
uint64_t fcn.18014fb00(int64_t arg1)
{
    code *pcVar1;
    uint64_t uVar2;
    char in_DL;
    
    if ((uint64_t)(int64_t)in_DL < 0x16) {
        return (uint64_t)*(uint32_t *)(arg1 + (int64_t)in_DL * 4);
    }
    fcn.18014fd00();
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_18014fb40
// Address: 0x18014fb40
// Size: 447 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.18014fb40(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    undefined8 *puVar6;
    undefined8 *puVar7;
    undefined *puVar8;
    undefined *puVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    uint64_t uVar12;
    undefined8 *puVar13;
    uint64_t uVar14;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t var_8h;
    
    puVar9 = auStack_58;
    puVar8 = auStack_58;
    puVar5 = *(undefined8 **)(arg1 + 8);
    if (puVar5 != *(undefined8 **)(arg1 + 0x10)) {
        *(undefined4 *)((int64_t)puVar5 + 0x19) = 0;
        *(undefined2 *)((int64_t)puVar5 + 0x1d) = 0;
        *(undefined *)((int64_t)puVar5 + 0x1f) = 0;
        *(undefined2 *)((int64_t)puVar5 + 0x2d) = 0;
        *(undefined *)((int64_t)puVar5 + 0x2f) = 0;
        *puVar5 = 0;
        puVar5[1] = 0;
        puVar5[2] = 0;
        *(undefined *)(puVar5 + 3) = 0;
        puVar5[4] = 0;
        *(undefined4 *)(puVar5 + 5) = 0;
        *(undefined *)((int64_t)puVar5 + 0x2c) = 1;
        puVar5[6] = 0;
        puVar5 = *(undefined8 **)(arg1 + 8);
        *(undefined8 **)(arg1 + 8) = puVar5 + 7;
        return puVar5;
    }
    iVar2 = ((int64_t)puVar5 - *(int64_t *)arg1) / 0x38;
    if (iVar2 == 0x492492492492492) {
        func_0x000180010010();
        pcVar1 = (code *)swi(3);
        puVar5 = (undefined8 *)(*pcVar1)();
        return puVar5;
    }
    uVar12 = ((int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    uVar3 = 0x492492492492492 - (uVar12 >> 1);
    if (uVar12 < uVar3 || uVar12 - uVar3 == 0) {
        uVar3 = iVar2 + 1;
        uVar12 = uVar12 + (uVar12 >> 1);
        uVar14 = uVar3;
        if (uVar3 <= uVar12) {
            uVar14 = uVar12;
        }
        if (uVar14 < 0x492492492492493) {
            uVar12 = uVar14 * 0x38;
            puVar10 = (undefined8 *)0x0;
            if (uVar12 != 0) {
                if (uVar12 < 0x1000) {
                    puVar10 = (undefined8 *)func_0x000180459890();
                    puVar9 = auStack_58;
                } else {
                    if (uVar12 + 0x27 <= uVar12) goto code_r0x00018014fcf9;
                    iVar4 = func_0x000180459890(uVar12 + 0x27);
                    if (iVar4 == 0) {
                        pcVar1 = (code *)swi(0x29);
                        iVar4 = (*pcVar1)(5);
                        puVar8 = auStack_50;
                    }
                    puVar10 = (undefined8 *)(iVar4 + 0x27U & 0xffffffffffffffe0);
                    puVar10[-1] = iVar4;
                    puVar9 = puVar8;
                }
            }
            puVar11 = puVar10 + iVar2 * 7;
            *(undefined4 *)((int64_t)puVar11 + 0x19) = 0;
            *(undefined2 *)((int64_t)puVar11 + 0x1d) = 0;
            *(undefined *)((int64_t)puVar11 + 0x1f) = 0;
            *(undefined2 *)((int64_t)puVar11 + 0x2d) = 0;
            *(undefined *)((int64_t)puVar11 + 0x2f) = 0;
            *puVar11 = 0;
            puVar11[1] = 0;
            puVar11[2] = 0;
            *(undefined *)(puVar11 + 3) = 0;
            puVar11[4] = 0;
            *(undefined4 *)(puVar11 + 5) = 0;
            *(undefined *)((int64_t)puVar11 + 0x2c) = 1;
            puVar11[6] = 0;
            puVar7 = *(undefined8 **)(arg1 + 8);
            puVar6 = *(undefined8 **)arg1;
            puVar13 = puVar10;
            if (puVar5 != puVar7) {
                *(undefined8 *)(puVar9 + -8) = 0x18014fcc0;
                func_0x00018014fd20(puVar6, puVar5, puVar10);
                puVar7 = *(undefined8 **)(arg1 + 8);
                puVar13 = puVar11 + 7;
                puVar6 = puVar5;
            }
            *(undefined8 *)(puVar9 + -8) = 0x18014fcd0;
            func_0x00018014fd20(puVar6, puVar7, puVar13);
            *(undefined8 *)(puVar9 + -8) = 0x18014fce1;
            func_0x00018014fd90(arg1, puVar10, uVar3, uVar14);
            return puVar11;
        }
    }
code_r0x00018014fcf9:
    func_0x000180004720();
    pcVar1 = (code *)swi(3);
    puVar5 = (undefined8 *)(*pcVar1)();
    return puVar5;
}

// ============================================================
// Function: FUN_18014fd00
// Address: 0x18014fd00
// Size: 17 bytes
// ============================================================
void fcn.18014fd00(void)
{
    code *pcVar1;
    
    fcn.1804546f8(0x180645c68);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_18014fd90
// Address: 0x18014fd90
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014fd90(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_48h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    undefined auStack_30 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x38) {
            func_0x00018002ee50(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        piVar4 = &var_38h;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), piVar4 = &var_38h, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            piVar4 = (int64_t *)auStack_30;
        }
        *(undefined8 *)((int64_t)piVar4 + -8) = 0x18014fe2d;
        func_0x000180459c3c(iVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg3 * 0x38 + arg2;
    *(int64_t *)(arg1 + 0x10) = arg4 * 0x38 + arg2;
    return;
}

// ============================================================
// Function: FUN_18014fdb7
// Address: 0x18014fdb7
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014fd90(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_48h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    undefined auStack_30 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x38) {
            func_0x00018002ee50(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        piVar4 = &var_38h;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), piVar4 = &var_38h, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            piVar4 = (int64_t *)auStack_30;
        }
        *(undefined8 *)((int64_t)piVar4 + -8) = 0x18014fe2d;
        func_0x000180459c3c(iVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg3 * 0x38 + arg2;
    *(int64_t *)(arg1 + 0x10) = arg4 * 0x38 + arg2;
    return;
}

// ============================================================
// Function: FUN_18014fe04
// Address: 0x18014fe04
// Size: 86 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18014fd90(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_48h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    undefined auStack_30 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x38) {
            func_0x00018002ee50(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        piVar4 = &var_38h;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), piVar4 = &var_38h, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            piVar4 = (int64_t *)auStack_30;
        }
        *(undefined8 *)((int64_t)piVar4 + -8) = 0x18014fe2d;
        func_0x000180459c3c(iVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg3 * 0x38 + arg2;
    *(int64_t *)(arg1 + 0x10) = arg4 * 0x38 + arg2;
    return;
}

// ============================================================
// Function: FUN_18014fe80
// Address: 0x18014fe80
// Size: 77 bytes
// ============================================================
void fcn.18014fe80(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    int64_t var_10h;
    
    if (*(int64_t *)arg1 != *(int64_t *)(arg1 + 8)) {
        *(int64_t *)(arg1 + 8) = *(int64_t *)arg1;
    }
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    var_8h = arg2;
    var_10h = arg2;
    fcn.180163690(arg1, &var_10h, &var_8h);
    *(undefined *)(*(int64_t *)arg1 + 0x10) = 1;
    *(undefined *)(*(int64_t *)arg1 + 0x11) = 1;
    return;
}

// ============================================================
// Function: FUN_18014fed0
// Address: 0x18014fed0
// Size: 67 bytes
// ============================================================
void fcn.18014fed0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    uint64_t uVar2;
    code *pcVar3;
    uint64_t uVar4;
    
    iVar1 = *(int64_t *)arg1;
    uVar2 = *(uint64_t *)(arg1 + 0x20);
    uVar4 = (*(int64_t *)(arg1 + 8) - iVar1 >> 2) * -0x3333333333333333;
    if (uVar2 <= uVar4 && uVar4 - uVar2 != 0) {
        *(int64_t *)(iVar1 + 8 + uVar2 * 0x14) = arg2;
        *(undefined *)(iVar1 + 0x12 + uVar2 * 0x14) = 1;
        return;
    }
    fcn.180060370();
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_18014ff20
// Address: 0x18014ff20
// Size: 71 bytes
// ============================================================
void fcn.18014ff20(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    uint64_t uVar2;
    code *pcVar3;
    uint64_t uVar4;
    
    iVar1 = *(int64_t *)arg1;
    uVar2 = *(uint64_t *)(arg1 + 0x20);
    uVar4 = (*(int64_t *)(arg1 + 8) - iVar1 >> 2) * -0x3333333333333333;
    if (uVar2 <= uVar4 && uVar4 - uVar2 != 0) {
        *(int64_t *)(iVar1 + uVar2 * 0x14) = arg2;
        *(int64_t *)(iVar1 + 8 + uVar2 * 0x14) = arg3;
        *(undefined *)(iVar1 + 0x12 + uVar2 * 0x14) = 1;
        return;
    }
    fcn.180060370();
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_18014ff70
// Address: 0x18014ff70
// Size: 75 bytes
// ============================================================
int64_t fcn.18014ff70(int64_t arg1)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    
    uVar4 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333;
    uVar2 = *(uint64_t *)(arg1 + 0x18);
    if (uVar4 < uVar2 || uVar4 - uVar2 == 0) {
        uVar2 = 0;
        *(undefined8 *)(arg1 + 0x18) = 0;
        if (uVar4 == 0) {
            fcn.180060370();
            pcVar1 = (code *)swi(3);
            iVar3 = (*pcVar1)();
            return iVar3;
        }
    }
    return *(int64_t *)arg1 + uVar2 * 0x14;
}

// ============================================================
// Function: FUN_18014ffc0
// Address: 0x18014ffc0
// Size: 83 bytes
// ============================================================
int64_t fcn.18014ffc0(int64_t arg1)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    
    uVar4 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333;
    uVar2 = *(uint64_t *)(arg1 + 0x20);
    if (uVar4 < uVar2 || uVar4 - uVar2 == 0) {
        uVar2 = *(uint64_t *)(arg1 + 0x18);
        if (uVar4 <= *(uint64_t *)(arg1 + 0x18)) {
            uVar2 = 0;
        }
        *(uint64_t *)(arg1 + 0x20) = uVar2;
        if (uVar4 < uVar2 || uVar4 - uVar2 == 0) {
            fcn.180060370();
            pcVar1 = (code *)swi(3);
            iVar3 = (*pcVar1)();
            return iVar3;
        }
    }
    return *(int64_t *)arg1 + uVar2 * 0x14;
}

// ============================================================
// Function: FUN_180150020
// Address: 0x180150020
// Size: 121 bytes
// ============================================================
uint64_t fcn.180150020(int64_t arg1, int64_t arg2)
{
    int16_t *piVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int16_t *piVar5;
    int64_t in_R8;
    uint32_t uVar6;
    
    uVar4 = (uint64_t)(int32_t)arg2;
    uVar3 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 3) * 0x6db6db6db6db6db7;
    if (uVar4 <= uVar3 && uVar3 - uVar4 != 0) {
        piVar5 = *(int16_t **)(uVar4 * 0x38 + *(int64_t *)arg1);
        uVar6 = 0;
        piVar1 = piVar5 + in_R8 * 2;
        while (piVar5 < piVar1) {
            if (*piVar5 == 9) {
                uVar6 = uVar6 + (*(int32_t *)(arg1 + 0x18) - (int32_t)uVar6 % *(int32_t *)(arg1 + 0x18));
                piVar5 = piVar5 + 2;
            } else {
                uVar6 = uVar6 + 1;
                piVar5 = piVar5 + 2;
            }
        }
        return (uint64_t)uVar6;
    }
    fcn.180060370();
    pcVar2 = (code *)swi(3);
    uVar3 = (*pcVar2)();
    return uVar3;
}

// ============================================================
// Function: FUN_1801500b0
// Address: 0x1801500b0
// Size: 371 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801500b0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined auVar5 [16];
    int64_t *piVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined *puVar9;
    bool bVar10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_90;
    undefined auStack_88 [8];
    undefined auStack_80 [24];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    uint64_t uStack_18;
    int64_t var_10h;
    int64_t var_8h;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    var_68h._0_4_ = 0;
    bVar10 = (uint64_t)(*(int64_t *)(arg1 + 0x108) - *(int64_t *)(arg1 + 0x100) >> 5) <= *(uint64_t *)(arg1 + 0x128);
    var_60h = arg2;
    if (bVar10) {
        var_48h = 0;
        var_40h = 0xf;
        stack0xffffffffffffffa9 = SUB1615(ZEXT816(0), 1);
        auVar5[15] = 0;
        auVar5._0_15_ = stack0xffffffffffffffa9;
        _var_58h = auVar5 << 8;
        piVar6 = &var_58h;
    } else {
        piVar6 = (int64_t *)
                 func_0x00018000b4d0(&var_38h, *(uint64_t *)(arg1 + 0x128) * 0x20 + *(int64_t *)(arg1 + 0x100));
    }
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0;
    uVar2 = *(undefined4 *)((int64_t)piVar6 + 4);
    uVar3 = *(undefined4 *)(piVar6 + 1);
    uVar4 = *(undefined4 *)((int64_t)piVar6 + 0xc);
    *(undefined4 *)arg2 = *(undefined4 *)piVar6;
    *(undefined4 *)(arg2 + 4) = uVar2;
    *(undefined4 *)(arg2 + 8) = uVar3;
    *(undefined4 *)(arg2 + 0xc) = uVar4;
    uVar2 = *(undefined4 *)((int64_t)piVar6 + 0x14);
    uVar3 = *(undefined4 *)(piVar6 + 3);
    uVar4 = *(undefined4 *)((int64_t)piVar6 + 0x1c);
    *(undefined4 *)(arg2 + 0x10) = *(undefined4 *)(piVar6 + 2);
    *(undefined4 *)(arg2 + 0x14) = uVar2;
    *(undefined4 *)(arg2 + 0x18) = uVar3;
    *(undefined4 *)(arg2 + 0x1c) = uVar4;
    piVar6[2] = 0;
    piVar6[3] = 0xf;
    *(undefined *)piVar6 = 0;
    puVar9 = auStack_88;
    if ((bVar10) && (puVar9 = auStack_88, 0xf < (uint64_t)var_40h)) {
        iVar7 = var_58h;
        puVar9 = auStack_88;
        if ((0xfff < var_40h + 1U) &&
           (iVar7 = *(int64_t *)(var_58h + -8), puVar9 = auStack_88, 0x1f < (var_58h - iVar7) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar7 = (*pcVar1)(5);
            puVar9 = auStack_80;
        }
        *(undefined8 *)(puVar9 + -8) = 0x1801501b6;
        func_0x000180459c3c(iVar7);
    }
    if ((!bVar10) && (0xf < *(uint64_t *)(puVar9 + 0x68))) {
        iVar7 = *(int64_t *)(puVar9 + 0x50);
        iVar8 = iVar7;
        if ((0xfff < *(uint64_t *)(puVar9 + 0x68) + 1) &&
           (iVar8 = *(int64_t *)(iVar7 + -8), 0x1f < (iVar7 - iVar8) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar8 = (*pcVar1)(5);
            puVar9 = puVar9 + 8;
        }
        *(undefined8 *)(puVar9 + -8) = 0x1801501fe;
        func_0x000180459c3c(iVar8);
    }
    *(undefined8 *)(puVar9 + -8) = 0x18015020e;
    func_0x000180459870(*(uint64_t *)(puVar9 + 0x70) ^ (uint64_t)puVar9);
    return;
}

// ============================================================
// Function: FUN_180150230
// Address: 0x180150230
// Size: 532 bytes
// ============================================================
int64_t fcn.180150230(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined *puVar9;
    undefined *puVar10;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    
    puVar9 = auStack_58;
    puVar10 = auStack_58;
    if (arg1 == arg2) goto code_r0x000180150416;
    iVar4 = *(int64_t *)arg1;
    iVar1 = *(int64_t *)arg2;
    iVar5 = *(int64_t *)(arg1 + 0x10) - iVar4 >> 2;
    iVar7 = *(int64_t *)(arg2 + 8) - iVar1 >> 2;
    uVar6 = iVar5 * -0x3333333333333333;
    uVar8 = iVar7 * -0x3333333333333333;
    if (uVar8 < uVar6 || uVar8 + iVar5 * 0x3333333333333333 == 0) {
        iVar5 = *(int64_t *)(arg1 + 8) - iVar4 >> 2;
        if (uVar8 < (uint64_t)(iVar5 * -0x3333333333333333) || uVar8 + iVar5 * 0x3333333333333333 == 0) {
            fcn.180498030(iVar4, iVar1, iVar7 * 4);
            iVar4 = iVar4 + iVar7 * 4;
        } else {
            fcn.180498030(iVar4, iVar1, iVar5 * 4);
            iVar7 = *(int64_t *)(arg1 + 8);
            iVar4 = (uVar8 + iVar5 * 0x3333333333333333) * 0x14;
            fcn.180498030(iVar7, iVar1 + iVar5 * 4, iVar4);
            iVar4 = iVar4 + iVar7;
        }
    } else {
        if (0xccccccccccccccc < uVar8) {
            func_0x000180010010();
            pcVar2 = (code *)swi(3);
            iVar4 = (*pcVar2)();
            return iVar4;
        }
        uVar3 = 0xccccccccccccccc - (uVar6 >> 1);
        if (uVar6 < uVar3 || uVar6 - uVar3 == 0) {
            uVar6 = uVar6 + (uVar6 >> 1);
            if (uVar6 < uVar8) {
                uVar6 = uVar8;
            }
        } else {
            uVar6 = 0xccccccccccccccc;
        }
        if (iVar4 == 0) {
code_r0x000180150317:
            if (0xccccccccccccccc < uVar6) {
code_r0x000180150438:
                func_0x000180004720();
                pcVar2 = (code *)swi(3);
                iVar4 = (*pcVar2)();
                return iVar4;
            }
            uVar6 = uVar6 * 0x14;
            if (uVar6 == 0) {
                uVar8 = 0;
                puVar10 = auStack_58;
            } else {
                if (0xfff < uVar6) {
                    if (uVar6 + 0x27 <= uVar6) goto code_r0x000180150438;
                    iVar4 = func_0x000180459890();
                    if (iVar4 == 0) goto code_r0x000180150355;
                    goto code_r0x00018015035c;
                }
                uVar8 = func_0x000180459890(uVar6);
            }
        } else {
            uVar8 = (*(int64_t *)(arg1 + 0x10) - iVar4 >> 2) * 4;
            if (uVar8 < 0x1000) {
code_r0x0001801502fb:
                func_0x000180459c3c(iVar4, uVar8);
                *(undefined8 *)arg1 = 0;
                *(undefined8 *)(arg1 + 8) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
                goto code_r0x000180150317;
            }
            if ((iVar4 - *(int64_t *)(iVar4 + -8)) - 8U < 0x20) {
                uVar8 = uVar8 + 0x27;
                iVar4 = *(int64_t *)(iVar4 + -8);
                goto code_r0x0001801502fb;
            }
code_r0x000180150355:
            pcVar2 = (code *)swi(0x29);
            iVar4 = (*pcVar2)(5);
            puVar9 = auStack_50;
code_r0x00018015035c:
            uVar8 = iVar4 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar8 - 8) = iVar4;
            puVar10 = puVar9;
        }
        *(uint64_t *)arg1 = uVar8;
        *(uint64_t *)(arg1 + 8) = uVar8;
        *(uint64_t *)(arg1 + 0x10) = uVar6 + uVar8;
        *(undefined8 *)(puVar10 + -8) = 0x18015039e;
        fcn.180498030(uVar8, iVar1, iVar7 * 4);
        iVar4 = iVar7 * 4 + uVar8;
    }
    *(int64_t *)(arg1 + 8) = iVar4;
code_r0x000180150416:
    *(undefined8 *)(arg1 + 0x18) = *(undefined8 *)(arg2 + 0x18);
    *(undefined8 *)(arg1 + 0x20) = *(undefined8 *)(arg2 + 0x20);
    return arg1;
}

// ============================================================
// Function: FUN_180150450
// Address: 0x180150450
// Size: 1017 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180150450(int64_t arg1)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    fcn.18015c180();
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined8 *)(arg1 + 0x30) = 0;
    *(undefined8 *)(arg1 + 0x38) = 0;
    *(undefined8 *)(arg1 + 0x40) = 0;
    *(undefined8 *)(arg1 + 0x48) = 0;
    *(undefined8 *)(arg1 + 0x50) = 0;
    *(undefined4 *)(arg1 + 0x58) = 4;
    *(undefined *)(arg1 + 0x5c) = 0;
    *(undefined4 *)(arg1 + 0x60) = 0;
    *(undefined *)(arg1 + 100) = 0;
    *(undefined8 *)(arg1 + 0xa0) = 0;
    *(undefined8 *)(arg1 + 0xe0) = 0;
    fcn.18014fb40((int64_t)(undefined8 *)(arg1 + 0x40), in_RDX);
    *(undefined8 *)(arg1 + 0xe8) = 0;
    *(undefined8 *)(arg1 + 0xf0) = 0;
    *(undefined8 *)(arg1 + 0xf8) = 0;
    *(undefined8 *)(arg1 + 0x100) = 0;
    *(undefined8 *)(arg1 + 0x108) = 0;
    *(undefined8 *)(arg1 + 0x118) = 0;
    *(undefined8 *)(arg1 + 0x120) = 0;
    *(undefined8 *)(arg1 + 0x128) = 0;
    *(undefined4 *)(arg1 + 0x130) = 0;
    *(undefined8 *)(arg1 + 0x134) = 0;
    *(undefined8 *)(arg1 + 0x13c) = 0;
    *(undefined8 *)(arg1 + 0x148) = 0;
    *(undefined4 *)(arg1 + 0x150) = 0x101;
    *(undefined4 *)(arg1 + 0x154) = 0x120c;
    *(undefined *)(arg1 + 0x158) = 0;
    *(undefined8 *)(arg1 + 0x160) = 200;
    *(undefined (*) [16])(arg1 + 0x168) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x178) = 0xe;
    *(undefined8 *)(arg1 + 0x180) = 0xf;
    *(undefined8 *)(arg1 + 0x168) = 0x6567677573206f4e;
    *(undefined4 *)(arg1 + 0x170) = 0x6f697473;
    *(undefined2 *)(arg1 + 0x174) = 0x736e;
    *(undefined *)(arg1 + 0x176) = 0;
    *(undefined8 *)(arg1 + 0x1c0) = 0;
    *(undefined8 *)(arg1 + 0x1c8) = 0;
    *(undefined (*) [16])(arg1 + 0x1d0) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x1e0) = 0;
    *(undefined8 *)(arg1 + 0x1e8) = 0xf;
    *(undefined *)(arg1 + 0x1d0) = 0;
    *(undefined8 *)(arg1 + 0x230) = 0;
    *(undefined8 *)(arg1 + 0x238) = 0;
    *(undefined8 *)(arg1 + 0x240) = 0;
    *(undefined *)(arg1 + 0x248) = 0;
    *(undefined *)(arg1 + 0x250) = 0;
    *(undefined8 *)(arg1 + 600) = 0;
    *(undefined4 *)(arg1 + 0x260) = 0x3f800000;
    *(undefined4 *)(arg1 + 0x264) = 0x1010100;
    *(undefined4 *)(arg1 + 0x268) = 0x1010101;
    *(undefined *)(arg1 + 0x26c) = 0;
    *(undefined8 *)(arg1 + 0x27c) = 0;
    *(undefined8 *)(arg1 + 0x284) = 0;
    *(undefined4 *)(arg1 + 0x2c4) = 0;
    *(undefined *)(arg1 + 0x2c8) = 0;
    *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    *(undefined4 *)(arg1 + 0x2d0) = 1;
    *(undefined2 *)(arg1 + 0x2d4) = 0;
    *(undefined4 *)(arg1 + 0x2d8) = 0;
    *(undefined8 *)(arg1 + 0x318) = 0;
    *(undefined8 *)(arg1 + 0x358) = 0;
    *(undefined8 *)(arg1 + 0x398) = 0;
    *(undefined8 *)(arg1 + 0x3a0) = 0;
    *(undefined (*) [16])(arg1 + 0x3a8) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x3b8) = 4;
    *(undefined8 *)(arg1 + 0x3c0) = 0xf;
    *(undefined4 *)(arg1 + 0x3a8) = 0x646e6946;
    *(undefined *)(arg1 + 0x3ac) = 0;
    *(undefined (*) [16])(arg1 + 0x3c8) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x3d8) = 8;
    *(undefined8 *)(arg1 + 0x3e0) = 0xf;
    *(undefined8 *)(arg1 + 0x3c8) = 0x6c6c4120646e6946;
    *(undefined *)(arg1 + 0x3d0) = 0;
    *(undefined (*) [16])(arg1 + 1000) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x3f8) = 7;
    *(undefined8 *)(arg1 + 0x400) = 0xf;
    *(undefined4 *)(arg1 + 1000) = 0x6c706552;
    *(undefined2 *)(arg1 + 0x3ec) = 0x6361;
    *(undefined *)(arg1 + 0x3ee) = 0x65;
    *(undefined *)(arg1 + 0x3ef) = 0;
    *(undefined (*) [16])(arg1 + 0x408) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x418) = 0xb;
    *(undefined8 *)(arg1 + 0x420) = 0xf;
    *(undefined8 *)(arg1 + 0x408) = 0x206563616c706552;
    *(undefined4 *)(arg1 + 0x40f) = 0x6c6c4120;
    *(undefined *)(arg1 + 0x413) = 0;
    *(undefined4 *)(arg1 + 0x428) = 0x100;
    *(undefined (*) [16])(arg1 + 0x430) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x440) = 0;
    *(undefined8 *)(arg1 + 0x448) = 0xf;
    *(undefined *)(arg1 + 0x430) = 0;
    *(undefined (*) [16])(arg1 + 0x450) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x460) = 0;
    *(undefined8 *)(arg1 + 0x468) = 0xf;
    *(undefined *)(arg1 + 0x450) = 0;
    *(undefined2 *)(arg1 + 0x470) = 0;
    *(undefined4 *)(arg1 + 0x474) = 0xbf800000;
    *(undefined2 *)(arg1 + 0x478) = 0;
    *(undefined8 *)(arg1 + 0x47c) = 0;
    *(undefined2 *)(arg1 + 0x484) = 1;
    *(undefined *)(arg1 + 0x486) = 0;
    *(undefined8 *)(arg1 + 0x488) = 0;
    *(undefined *)(arg1 + 0x490) = 1;
    *(undefined8 *)(arg1 + 0x4d0) = 0;
    *(undefined8 *)(arg1 + 0x4e0) = 0;
    *(undefined *)(arg1 + 0x4e8) = 0;
    *(undefined8 *)(arg1 + 0x528) = 0;
    *(undefined8 *)(arg1 + 0x5e8) = 0;
    uVar3 = *(undefined4 *)0x18077a63c;
    uVar2 = *(undefined4 *)0x18077a638;
    uVar1 = *(undefined4 *)0x18077a634;
    *(undefined4 *)(arg1 + 0x530) = *(undefined4 *)0x18077a630;
    *(undefined4 *)(arg1 + 0x534) = uVar1;
    *(undefined4 *)(arg1 + 0x538) = uVar2;
    *(undefined4 *)(arg1 + 0x53c) = uVar3;
    uVar3 = *(undefined4 *)0x18077a64c;
    uVar2 = *(undefined4 *)0x18077a648;
    uVar1 = *(undefined4 *)0x18077a644;
    *(undefined4 *)(arg1 + 0x540) = *(undefined4 *)0x18077a640;
    *(undefined4 *)(arg1 + 0x544) = uVar1;
    *(undefined4 *)(arg1 + 0x548) = uVar2;
    *(undefined4 *)(arg1 + 0x54c) = uVar3;
    uVar3 = *(undefined4 *)0x18077a65c;
    uVar2 = *(undefined4 *)0x18077a658;
    uVar1 = *(undefined4 *)0x18077a654;
    *(undefined4 *)(arg1 + 0x550) = *(undefined4 *)0x18077a650;
    *(undefined4 *)(arg1 + 0x554) = uVar1;
    *(undefined4 *)(arg1 + 0x558) = uVar2;
    *(undefined4 *)(arg1 + 0x55c) = uVar3;
    uVar3 = *(undefined4 *)0x18077a66c;
    uVar2 = *(undefined4 *)0x18077a668;
    uVar1 = *(undefined4 *)0x18077a664;
    *(undefined4 *)(arg1 + 0x560) = *(undefined4 *)0x18077a660;
    *(undefined4 *)(arg1 + 0x564) = uVar1;
    *(undefined4 *)(arg1 + 0x568) = uVar2;
    *(undefined4 *)(arg1 + 0x56c) = uVar3;
    uVar3 = *(undefined4 *)0x18077a67c;
    uVar2 = *(undefined4 *)0x18077a678;
    uVar1 = *(undefined4 *)0x18077a674;
    *(undefined4 *)(arg1 + 0x570) = *(undefined4 *)0x18077a670;
    *(undefined4 *)(arg1 + 0x574) = uVar1;
    *(undefined4 *)(arg1 + 0x578) = uVar2;
    *(undefined4 *)(arg1 + 0x57c) = uVar3;
    *(undefined8 *)(arg1 + 0x580) = *(undefined8 *)0x18077a680;
    *(undefined4 *)(arg1 + 0x5e0) = 0xbf800000;
    return arg1;
}

