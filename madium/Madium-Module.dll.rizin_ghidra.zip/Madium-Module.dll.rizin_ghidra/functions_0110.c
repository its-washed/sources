// Chunk 110 - 50 functions

// ============================================================
// Function: FUN_18017fa80
// Address: 0x18017fa80
// Size: 50 bytes
// ============================================================
void fcn.18017fa80(void)
{
    int64_t iVar1;
    
    iVar1 = fcn.1801736d0();
    if (iVar1 != 0) {
        LOCK();
        *(undefined4 *)(iVar1 + 0x20) = 4;
        UNLOCK();
        if (*(int64_t **)(iVar1 + 0xe0) != (int64_t *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018017faa9. Too many branches
    // WARNING: Treating indirect jump as call
            (**(code **)(**(int64_t **)(iVar1 + 0xe0) + 0x10))();
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18017fac0
// Address: 0x18017fac0
// Size: 50 bytes
// ============================================================
void fcn.18017fac0(void)
{
    int64_t iVar1;
    
    iVar1 = fcn.1801736d0();
    if (iVar1 != 0) {
        LOCK();
        *(undefined4 *)(iVar1 + 0x20) = 2;
        UNLOCK();
        if (*(int64_t **)(iVar1 + 0x130) != (int64_t *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018017fae9. Too many branches
    // WARNING: Treating indirect jump as call
            (**(code **)(**(int64_t **)(iVar1 + 0x130) + 0x10))();
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18017fb00
// Address: 0x18017fb00
// Size: 122 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18017fb00(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t *piStackX_20;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    
    iVar2 = fcn.1801736d0();
    if ((iVar2 != 0) && (piVar1 = *(int64_t **)(iVar2 + 0x60), piVar1 != (int64_t *)0x0)) {
        var_28h = 0x1804a6a88;
        var_10h._0_1_ = '\0';
        piStackX_20 = &var_28h;
        var_20h = arg2;
        var_18h = (int64_t)(int32_t)arg3;
        (**(code **)(*piVar1 + 0x10))(piVar1, &piStackX_20);
        var_28h = 0x1804a6a88;
        if (((char)var_10h != '\0') && (var_20h != 0)) {
            fcn.180180fe0();
        }
    }
    return;
}

// ============================================================
// Function: FUN_18017fb80
// Address: 0x18017fb80
// Size: 125 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18017fb80(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t *piStackX_20;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    
    iVar2 = fcn.1801736d0();
    if ((iVar2 != 0) && (piVar1 = *(int64_t **)(iVar2 + 0xa0), piVar1 != (int64_t *)0x0)) {
        var_28h = 0x1804a6a88;
        var_10h._0_1_ = '\0';
        piStackX_20 = &var_28h;
        var_20h = arg2;
        var_18h = (int64_t)(int32_t)arg3;
        (**(code **)(*piVar1 + 0x10))(piVar1, &piStackX_20);
        var_28h = 0x1804a6a88;
        if (((char)var_10h != '\0') && (var_20h != 0)) {
            fcn.180180fe0();
        }
    }
    return;
}

// ============================================================
// Function: FUN_18017fc00
// Address: 0x18017fc00
// Size: 2149 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18017fc00(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    char cVar2;
    undefined4 uVar3;
    code *pcVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int32_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    undefined (*pauVar10) [16];
    int64_t iVar11;
    int64_t *piVar12;
    int64_t **ppiVar13;
    undefined (*pauVar14) [16];
    int64_t **ppiVar15;
    undefined *puVar16;
    int32_t iVar17;
    undefined (*pauVar18) [16];
    int64_t var_18h;
    undefined8 uStack_240;
    undefined auStack_238 [8];
    undefined auStack_230 [24];
    int64_t var_218h;
    int64_t var_210h;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1f8h;
    int64_t var_1e8h;
    int64_t var_1b0h;
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar16 = auStack_238;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_238;
    pauVar18 = (undefined (*) [16])0x0;
    if ((*(int64_t *)(arg1 + 8) != 0) && (*(int32_t *)(*(int64_t *)(arg1 + 8) + 0x20) != 4)) {
        var_1a8h = 0x1804a7198;
        var_170h = (int64_t)&var_1a8h;
        var_1a0h = arg1;
        func_0x000180180470(*(undefined8 *)(arg1 + 0x138), &var_1a8h);
    }
    *(undefined4 *)(arg1 + 600) = 4;
    if (arg2 != 0) {
        iVar7 = func_0x000180498f90(arg2, 0x18063cc2c, 2);
        if (iVar7 == 0) {
            uVar8 = func_0x000180498cd0(arg2);
            func_0x00018000f180(arg1 + 0x178, arg2, uVar8);
        } else {
            func_0x00018000f180(arg1 + 0x178, 0x1804a6dc4, 5);
            uVar8 = func_0x000180498cd0(arg2);
            func_0x00018000d970(arg1 + 0x178, arg2, uVar8);
        }
    }
    ppiVar15 = (int64_t **)(arg1 + 0x178);
    ppiVar13 = ppiVar15;
    if (0xf < *(uint64_t *)(arg1 + 400)) {
        ppiVar13 = (int64_t **)*ppiVar15;
    }
    iVar9 = func_0x00018045b9a8(0x1804a6bd0, 0x5c);
    uVar8 = func_0x0001801723e0();
    var_208h = 0x1804a6dd0;
    var_210h = CONCAT44(var_210h._4_4_, 0x28);
    var_218h = iVar9 + 1;
    func_0x000180172b00(uVar8, 2, 0x1804a6340, ppiVar13);
    if (*(int64_t *)(arg1 + 0x270) == 0) {
        pauVar10 = (undefined (*) [16])func_0x000180459890(0x1c8);
        pauVar14 = pauVar18;
        var_1a8h = (int64_t)pauVar10;
        if (pauVar10 != (undefined (*) [16])0x0) {
            *pauVar10 = ZEXT816(0);
            *(undefined4 *)(*pauVar10 + 8) = 1;
            *(undefined4 *)(*pauVar10 + 0xc) = 1;
            *(undefined8 *)*pauVar10 = 0x1804a6ec8;
            func_0x000180175a50(pauVar10 + 1);
            pauVar14 = pauVar10;
        }
        *(undefined (**) [16])(arg1 + 0x270) = pauVar14 + 1;
        piVar12 = *(int64_t **)(arg1 + 0x278);
        *(undefined (**) [16])(arg1 + 0x278) = pauVar14;
        if (piVar12 != (int64_t *)0x0) {
            LOCK();
            piVar5 = piVar12 + 1;
            iVar7 = *(int32_t *)piVar5;
            *(int32_t *)piVar5 = *(int32_t *)piVar5 + -1;
            UNLOCK();
            if (iVar7 == 1) {
                (**(code **)*piVar12)(piVar12);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar12 + 0xc);
                iVar7 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar7 == 1) {
                    (**(code **)(*piVar12 + 8))(piVar12);
                }
            }
        }
    }
    _var_168h = ZEXT816(0);
    var_158h = 0;
    var_150h = 0;
    if (*(uint64_t *)(arg1 + 0x188) < 2) {
        func_0x00018000f930();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    iVar11 = *(uint64_t *)(arg1 + 0x188) - 2;
    iVar9 = -1;
    if (iVar11 != -1) {
        iVar9 = iVar11;
    }
    ppiVar13 = ppiVar15;
    if (0xf < *(uint64_t *)(arg1 + 400)) {
        ppiVar13 = (int64_t **)*ppiVar15;
    }
    func_0x000180004830(&var_168h, (int64_t)ppiVar13 + 2, iVar9);
    if ((uint64_t)(var_150h - var_158h) < 4) {
        var_210h = 4;
        var_218h = 0x180623910;
        piVar12 = (int64_t *)func_0x000180018d80(&var_168h, 4, 0, 0);
    } else {
        piVar12 = &var_168h;
        if (0xf < (uint64_t)var_150h) {
            piVar12 = (int64_t *)var_168h;
        }
        if ((piVar12 < (int64_t *)0x180623914) && (0x18062390f < (uint64_t)((int64_t)piVar12 + var_158h))) {
            if ((int64_t *)0x180623910 < piVar12) {
                pauVar18 = (undefined (*) [16])(piVar12 + -0x300c4722);
            }
        } else {
            pauVar18 = (undefined (*) [16])0x4;
        }
        iVar9 = var_158h + 1;
        var_158h = var_158h + 4;
        func_0x000180498030((int64_t)piVar12 + 4, piVar12, iVar9);
        func_0x000180498030(piVar12, 0x180623910, pauVar18);
        func_0x000180498030((int64_t)piVar12 + (int64_t)pauVar18, pauVar18[0x18062391] + 4, 4 - (int64_t)pauVar18);
        piVar12 = &var_168h;
    }
    var_1a8h = *piVar12;
    var_1a0h = piVar12[1];
    var_198h = piVar12[2];
    var_190h._0_4_ = *(undefined4 *)(piVar12 + 3);
    var_190h._4_4_ = *(undefined4 *)((int64_t)piVar12 + 0x1c);
    piVar12[2] = 0;
    piVar12[3] = 0xf;
    *(undefined *)piVar12 = 0;
    func_0x000180012c10(*(int64_t *)(arg1 + 0x270) + 0xe8, &var_1a8h);
    if (0xf < CONCAT44(var_190h._4_4_, (undefined4)var_190h)) {
        iVar9 = var_1a8h;
        puVar16 = auStack_238;
        if ((0xfff < CONCAT44(var_190h._4_4_, (undefined4)var_190h) + 1) &&
           (iVar9 = *(int64_t *)(var_1a8h + -8), puVar16 = auStack_238, 0x1f < (var_1a8h - iVar9) - 8U)) {
            pcVar4 = (code *)swi(0x29);
            iVar9 = (*pcVar4)(5);
            puVar16 = auStack_230;
        }
        *(undefined8 *)(puVar16 + -8) = 0x18017ff64;
        func_0x000180459c3c(iVar9);
    }
    if (0xf < (uint64_t)var_150h) {
        iVar9 = var_168h;
        if ((0xfff < var_150h + 1U) && (iVar9 = *(int64_t *)(var_168h + -8), 0x1f < (var_168h - iVar9) - 8U)) {
            pcVar4 = (code *)swi(0x29);
            iVar9 = (*pcVar4)(5);
            puVar16 = puVar16 + 8;
        }
        *(undefined8 *)(puVar16 + -8) = 0x18017ffa5;
        func_0x000180459c3c(iVar9);
    }
    uVar8 = *(undefined8 *)(arg1 + 0x270);
    *(undefined8 *)(puVar16 + -8) = 0x18017ffb1;
    func_0x0001801787a0(uVar8);
    iVar9 = *(int64_t *)(arg1 + 0x270);
    piVar12 = (int64_t *)(iVar9 + 0x128);
    if (0xf < *(uint64_t *)(iVar9 + 0x140)) {
        piVar12 = (int64_t *)*piVar12;
    }
    uVar3 = *(undefined4 *)(iVar9 + 0x148);
    *(undefined (*) [16])(arg1 + 0x3c) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x48) = ZEXT816(0);
    *(undefined8 *)(puVar16 + -8) = 0x18017ffea;
    iVar7 = func_0x000180184b70(arg1 + 0x3c, piVar12, uVar3);
    if (iVar7 == 0) {
        *(undefined8 *)(puVar16 + -8) = 0x180180005;
        uVar8 = func_0x000180498cd0(piVar12);
        *(undefined8 *)(puVar16 + -8) = 0x180180014;
        func_0x00018000f180(arg1 + 0x18, piVar12, uVar8);
        *(undefined4 *)(arg1 + 0x38) = uVar3;
        *(undefined8 *)(puVar16 + -8) = 0x180180024;
        iVar17 = func_0x00018017f7d0(arg1, arg1 + 0x3c);
    } else {
        iVar17 = -iVar7;
        if (0 < iVar7) {
            iVar17 = iVar7;
        }
        iVar17 = -iVar17;
    }
    if (iVar17 < 0) {
        iVar9 = *(int64_t *)(arg1 + 0x270);
        piVar12 = (int64_t *)(iVar9 + 0x128);
        if (0xf < *(uint64_t *)(iVar9 + 0x140)) {
            piVar12 = (int64_t *)*piVar12;
        }
        *(undefined8 *)(puVar16 + -8) = 0x180180055;
        iVar11 = func_0x00018045b9a8(0x1804a6bd0, 0x5c);
        uVar3 = *(undefined4 *)(iVar9 + 0x148);
        *(undefined8 *)(puVar16 + -8) = 0x180180064;
        uVar8 = func_0x0001801723e0();
        *(undefined8 *)(puVar16 + 0x40) = 0x1804a6dd0;
        *(undefined4 *)(puVar16 + 0x38) = 0x32;
        *(int64_t *)(puVar16 + 0x30) = iVar11 + 1;
        *(int32_t *)(puVar16 + 0x28) = iVar17;
        *(undefined4 *)(puVar16 + 0x20) = uVar3;
        *(undefined8 *)(puVar16 + -8) = 0x18018009d;
        func_0x000180172b00(uVar8, 4, 0x1804a6df0, piVar12);
        goto code_r0x000180180435;
    }
    if (0xf < *(uint64_t *)(arg1 + 400)) {
        ppiVar15 = (int64_t **)*ppiVar15;
    }
    *(undefined8 *)(puVar16 + -8) = 0x1801800c4;
    iVar7 = func_0x000180498f90(ppiVar15, 0x18063cc28, 3);
    if ((iVar7 == 0) && ((*(uint32_t *)(*(int64_t *)(arg1 + 0x270) + 0x1b4) >> 1 & 1) == 0)) {
        *(undefined *)(arg1 + 0x5c) = 1;
    }
    ppiVar15 = (int64_t **)**(int64_t ***)arg3;
    cVar2 = *(char *)((int64_t)ppiVar15 + 0x19);
    while (cVar2 == '\0') {
        ppiVar13 = ppiVar15 + 8;
        iVar9 = *(int64_t *)(arg1 + 0x270);
        *(undefined8 *)(puVar16 + -8) = 0x18018010d;
        piVar12 = (int64_t *)func_0x00018017c5b0(iVar9 + 0x10, &var_1a8h);
        iVar9 = *piVar12;
        if ((int64_t **)(iVar9 + 0x40) != ppiVar13) {
            if ((int64_t *)0xf < ppiVar15[0xb]) {
                ppiVar13 = (int64_t **)*ppiVar13;
            }
            piVar12 = ppiVar15[10];
            *(undefined8 *)(puVar16 + -8) = 0x180180131;
            func_0x00018000f180((int64_t **)(iVar9 + 0x40), ppiVar13, piVar12);
        }
        ppiVar13 = (int64_t **)ppiVar15[2];
        if (*(char *)((int64_t)ppiVar13 + 0x19) == '\0') {
            cVar2 = *(char *)((int64_t)*ppiVar13 + 0x19);
            ppiVar15 = ppiVar13;
            ppiVar13 = (int64_t **)*ppiVar13;
            while (cVar2 == '\0') {
                cVar2 = *(char *)((int64_t)*ppiVar13 + 0x19);
                ppiVar15 = ppiVar13;
                ppiVar13 = (int64_t **)*ppiVar13;
            }
        } else {
            cVar2 = *(char *)((int64_t)ppiVar15[1] + 0x19);
            ppiVar6 = (int64_t **)ppiVar15[1];
            ppiVar13 = ppiVar15;
            while ((ppiVar15 = ppiVar6, cVar2 == '\0' && (ppiVar13 == (int64_t **)ppiVar15[2]))) {
                cVar2 = *(char *)((int64_t)ppiVar15[1] + 0x19);
                ppiVar6 = (int64_t **)ppiVar15[1];
                ppiVar13 = ppiVar15;
            }
        }
        cVar2 = *(char *)((int64_t)ppiVar15 + 0x19);
    }
    piVar12 = (int64_t *)(arg1 + 0x78);
    var_148h = 0x1804a70f0;
    var_110h = (int64_t)&var_148h;
    var_90h = 0;
    *(undefined8 *)(puVar16 + -8) = 0x1801801b8;
    var_140h = arg1;
    var_90h = func_0x00018017e960(&var_148h, &var_c8h);
    if (var_110h != 0) {
        pcVar4 = *(code **)(*(int64_t *)var_110h + 0x20);
        *(undefined8 *)(puVar16 + -8) = 0x1801801db;
        (*pcVar4)(var_110h, CONCAT71((unkint7)((uint64_t)&var_148h >> 8), (int64_t *)var_110h != &var_148h));
        var_110h = 0;
    }
    piVar5 = *(int64_t **)(arg1 + 0xb0);
    if (piVar5 != (int64_t *)0x0) {
        if (piVar5 == piVar12) {
            pcVar4 = *(code **)(*piVar5 + 8);
            *(undefined8 *)(puVar16 + -8) = 0x180180204;
            var_110h = (*pcVar4)(piVar5, &var_148h);
            piVar5 = *(int64_t **)(arg1 + 0xb0);
            if (piVar5 == (int64_t *)0x0) goto code_r0x000180180241;
            pcVar4 = *(code **)(*piVar5 + 0x20);
            *(undefined8 *)(puVar16 + -8) = 0x180180223;
            (*pcVar4)(piVar5, piVar5 != piVar12);
            piVar5 = (int64_t *)var_110h;
        }
        var_110h = (int64_t)piVar5;
        *(undefined8 *)(arg1 + 0xb0) = 0;
    }
code_r0x000180180241:
    if (var_90h != 0) {
        if ((int64_t *)var_90h == &var_c8h) {
            pcVar4 = *(code **)(*(int64_t *)var_90h + 8);
            *(undefined8 *)(puVar16 + -8) = 0x18018025b;
            uVar8 = (*pcVar4)(var_90h, piVar12);
            *(undefined8 *)(arg1 + 0xb0) = uVar8;
            if (var_90h != 0) {
                pcVar4 = *(code **)(*(int64_t *)var_90h + 0x20);
                *(undefined8 *)(puVar16 + -8) = 0x18018027b;
                (*pcVar4)(var_90h, CONCAT71((unkint7)((uint64_t)&var_c8h >> 8), (int64_t *)var_90h != &var_c8h));
            }
        } else {
            *(int64_t *)(arg1 + 0xb0) = var_90h;
        }
    }
    if (var_110h != 0) {
        pcVar4 = *(code **)(*(int64_t *)var_110h + 0x20);
        *(undefined8 *)(puVar16 + -8) = 0x18018029a;
        (*pcVar4)(var_110h, CONCAT71((unkint7)((uint64_t)&var_148h >> 8), (int64_t *)var_110h != &var_148h));
    }
    piVar12 = (int64_t *)(arg1 + 0xb8);
    var_108h = 0x1804a7160;
    var_d0h = (int64_t)&var_108h;
    var_50h = 0;
    *(undefined8 *)(puVar16 + -8) = 0x1801802cf;
    var_100h = arg1;
    var_50h = func_0x00018017e8a0(&var_108h, &var_88h);
    if (var_d0h != 0) {
        pcVar4 = *(code **)(*(int64_t *)var_d0h + 0x20);
        *(undefined8 *)(puVar16 + -8) = 0x1801802f2;
        (*pcVar4)(var_d0h, CONCAT71((unkint7)((uint64_t)&var_108h >> 8), (int64_t *)var_d0h != &var_108h));
        var_d0h = 0;
    }
    piVar5 = *(int64_t **)(arg1 + 0xf0);
    if (piVar5 != (int64_t *)0x0) {
        if (piVar5 == piVar12) {
            pcVar4 = *(code **)(*piVar5 + 8);
            *(undefined8 *)(puVar16 + -8) = 0x18018031b;
            var_d0h = (*pcVar4)(piVar5, &var_108h);
            piVar5 = *(int64_t **)(arg1 + 0xf0);
            if (piVar5 == (int64_t *)0x0) goto code_r0x000180180358;
            pcVar4 = *(code **)(*piVar5 + 0x20);
            *(undefined8 *)(puVar16 + -8) = 0x18018033a;
            (*pcVar4)(piVar5, piVar5 != piVar12);
            piVar5 = (int64_t *)var_d0h;
        }
        var_d0h = (int64_t)piVar5;
        *(undefined8 *)(arg1 + 0xf0) = 0;
    }
code_r0x000180180358:
    if (var_50h != 0) {
        if ((int64_t *)var_50h == &var_88h) {
            pcVar4 = *(code **)(*(int64_t *)var_50h + 8);
            *(undefined8 *)(puVar16 + -8) = 0x180180375;
            uVar8 = (*pcVar4)(var_50h, piVar12);
            *(undefined8 *)(arg1 + 0xf0) = uVar8;
            if (var_50h != 0) {
                pcVar4 = *(code **)(*(int64_t *)var_50h + 0x20);
                *(undefined8 *)(puVar16 + -8) = 0x180180398;
                (*pcVar4)(var_50h, CONCAT71((unkint7)((uint64_t)&var_88h >> 8), (int64_t *)var_50h != &var_88h));
            }
        } else {
            *(int64_t *)(arg1 + 0xf0) = var_50h;
        }
    }
    if (var_d0h != 0) {
        pcVar4 = *(code **)(*(int64_t *)var_d0h + 0x20);
        *(undefined8 *)(puVar16 + -8) = 0x1801803b7;
        (*pcVar4)(var_d0h, CONCAT71((unkint7)((uint64_t)&var_108h >> 8), (int64_t *)var_d0h != &var_108h));
    }
    *(undefined4 *)(arg1 + 600) = 0;
    iVar7 = **(int32_t **)(arg1 + 0x150);
    if (iVar7 == 5) {
        var_1a8h = 0x1804a72b0;
        var_1a0h = 0x180180a60;
        var_170h = (int64_t)&var_1a8h;
        uVar8 = *(undefined8 *)(arg1 + 0x138);
        *(undefined8 *)(puVar16 + -8) = 0x1801803ff;
        var_198h = arg1;
        func_0x000180180470(uVar8, &var_1a8h);
    } else {
        var_1b0h = 0;
        var_1a8h = 0x1804a71d0;
        var_170h = (int64_t)&var_1a8h;
        *(undefined8 *)(puVar16 + -8) = 0x180180433;
        var_1a0h = arg1;
        func_0x000180061b50(arg1 + 0x148, CONCAT71((unkuint7)(unkuint3)((uint32_t)iVar7 >> 8), 1), &var_1a8h, 
                            puVar16 + 0x50);
    }
code_r0x000180180435:
    *(undefined8 *)(puVar16 + -8) = 0x180180444;
    func_0x000180459870(var_48h ^ (uint64_t)puVar16);
    return;
}

// ============================================================
// Function: FUN_180180470
// Address: 0x180180470
// Size: 196 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180180470(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_88 [40];
    int64_t var_60h;
    int64_t var_28h;
    int64_t iStack_20;
    uint64_t uStack_18;
    int64_t var_8h;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    iStack_20 = arg2;
    if ((*(int32_t *)arg1 == 5) && (*(int64_t *)(arg1 + 8) != 0)) {
        iVar2 = (*(code *)0x699ddc)();
        iVar3 = func_0x000180182b10(*(undefined8 *)(arg1 + 8));
        if (iVar2 == iVar3) {
            if (*(int64_t **)(arg2 + 0x38) != (int64_t *)0x0) {
                (**(code **)(**(int64_t **)(arg2 + 0x38) + 0x10))();
            }
            goto code_r0x0001801804f5;
        }
    }
    var_28h = 0;
    func_0x000180014de0(&var_60h, arg2);
    func_0x0001800613f0(arg1, &var_60h);
code_r0x0001801804f5:
    piVar1 = *(int64_t **)(arg2 + 0x38);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)arg2);
        *(undefined8 *)(arg2 + 0x38) = 0;
    }
    func_0x000180459870(uStack_18 ^ (uint64_t)auStack_88);
    return;
}

// ============================================================
// Function: FUN_180180540
// Address: 0x180180540
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180180540(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t var_18h;
    
    iVar1 = arg2;
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        iVar1 = *(int64_t *)arg2;
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        uVar2 = func_0x0001801899b0(*(int64_t *)(arg1 + 8), iVar1, *(undefined4 *)(arg2 + 0x10), 1, 1);
        return uVar2;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180180590
// Address: 0x180180590
// Size: 42 bytes
// ============================================================
void fcn.180180590(void)
{
    int64_t iVar1;
    
    iVar1 = fcn.1801736d0();
    if ((iVar1 != 0) && (*(int64_t **)(iVar1 + 0x170) != (int64_t *)0x0)) {
    // WARNING: Could not recover jumptable at 0x0001801805b1. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(**(int64_t **)(iVar1 + 0x170) + 0x10))();
        return;
    }
    return;
}

// ============================================================
// Function: FUN_1801805c0
// Address: 0x1801805c0
// Size: 448 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801805c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    int64_t iVar2;
    int32_t iVar3;
    undefined8 *puVar4;
    int64_t var_10h;
    undefined auStack_168 [32];
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_168;
    var_140h = (int64_t)&var_138h;
    var_100h = 0;
    puVar4 = *(undefined8 **)(arg3 + 0x38);
    var_b0h = arg3;
    if (puVar4 != (undefined8 *)0x0) {
        var_100h = (**(code **)*puVar4)(puVar4, &var_138h);
    }
    var_140h = (int64_t)&var_138h;
    if (*(int64_t *)(arg1 + 8) == 0) {
        iVar3 = (*(code *)0x699ddc)();
    } else {
        iVar3 = func_0x000180182b10();
    }
    LOCK();
    piVar1 = (int64_t *)(arg1 + 0xa0);
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    var_a0h = (int64_t)iVar3 << 0x20 | iVar2 + 1U;
    var_f8h = (int64_t)&var_f0h;
    var_a8h = 0x180180780;
    var_98h._0_4_ = 1;
    var_148h = (int64_t)&var_90h;
    var_58h = 0;
    if (var_100h != 0) {
        var_58h = (***(code ***)var_100h)(var_100h, &var_90h);
    }
    var_50h._0_4_ = (undefined4)arg2;
    var_b8h = 0;
    var_48h = arg1;
    puVar4 = (undefined8 *)func_0x000180459890(0x70);
    *puVar4 = 0x1804a6f40;
    puVar4[1] = var_a8h;
    puVar4[2] = var_a0h;
    *(undefined4 *)(puVar4 + 3) = (undefined4)var_98h;
    puVar4[0xb] = 0;
    func_0x000180014de0(puVar4 + 4, &var_90h);
    *(undefined4 *)(puVar4 + 0xc) = (undefined4)var_50h;
    puVar4[0xd] = var_48h;
    var_b8h = (int64_t)puVar4;
    fcn.180180470(arg1, (int64_t)&var_f0h);
    if (var_58h != 0) {
        (**(code **)(*(int64_t *)var_58h + 0x20))
                  (var_58h, CONCAT71((unkint7)((uint64_t)&var_90h >> 8), (int64_t *)var_58h != &var_90h));
    }
    if (var_100h != 0) {
        (**(code **)(*(int64_t *)var_100h + 0x20))
                  (var_100h, CONCAT71((unkint7)((uint64_t)&var_138h >> 8), (int64_t *)var_100h != &var_138h));
        var_100h = 0;
    }
    piVar1 = *(int64_t **)(arg3 + 0x38);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)arg3);
        *(undefined8 *)(arg3 + 0x38) = 0;
    }
    func_0x000180459870(var_38h ^ (uint64_t)auStack_168);
    return;
}

// ============================================================
// Function: FUN_180180780
// Address: 0x180180780
// Size: 723 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_bch

void fcn.180180780(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    undefined (*pauVar1) [16];
    int32_t *piVar2;
    int64_t iVar3;
    int64_t *piVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined (*pauVar8) [16];
    undefined8 *puVar9;
    int64_t *piVar10;
    undefined8 *puVar11;
    uint32_t uVar12;
    undefined8 *puVar13;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_e8 [32];
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_e8;
    var_58h = arg3;
    if (*(int64_t *)(arg1 + 8) == 0) {
        piVar4 = *(int64_t **)(arg3 + 0x38);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)arg3);
            *(undefined8 *)(arg3 + 0x38) = 0;
        }
    } else {
        iVar7 = func_0x000180182c00(*(int64_t *)(arg1 + 8), 0x18017f900, arg2 & 0xffffffff);
        if (arg_28h == -1) {
            if (*(int64_t *)(arg1 + 8) == 0) {
                iVar6 = (*(code *)0x699ddc)();
            } else {
                iVar6 = func_0x000180182b10();
            }
            LOCK();
            piVar4 = (int64_t *)(arg1 + 0xa0);
            iVar3 = *piVar4;
            *piVar4 = *piVar4 + 1;
            UNLOCK();
            arg_28h = (int64_t)iVar6 << 0x20 | iVar3 + 1U;
        }
        *(int64_t *)(iVar7 + 0x10) = arg_28h;
        *(int64_t *)(iVar7 + 0x20) = arg1;
        pauVar8 = (undefined (*) [16])func_0x000180459890(0x60);
        var_a8h = (int64_t)pauVar8;
        if (pauVar8 == (undefined (*) [16])0x0) {
            pauVar8 = (undefined (*) [16])0x0;
        } else {
            *pauVar8 = ZEXT816(0);
            *(undefined4 *)(*pauVar8 + 8) = 1;
            *(undefined4 *)(*pauVar8 + 0xc) = 1;
            *(undefined8 *)*pauVar8 = 0x1804a6e28;
            var_c8h = (int64_t)&var_98h;
            var_60h = 0;
            puVar11 = *(undefined8 **)(arg3 + 0x38);
            if (puVar11 != (undefined8 *)0x0) {
                var_60h = (**(code **)*puVar11)(puVar11, &var_98h);
            }
            *(undefined8 *)pauVar8[5] = 0;
            *(int64_t *)pauVar8[1] = iVar7;
            if ((int64_t *)(pauVar8[1] + 8) != &var_98h) {
                func_0x000180014de0(pauVar8[1] + 8, &var_98h);
            }
            *(int32_t *)(pauVar8[5] + 8) = (int32_t)arg4;
            if (var_60h != 0) {
                (**(code **)(*(int64_t *)var_60h + 0x20))
                          (var_60h, CONCAT71((unkint7)((uint64_t)&var_98h >> 8), (int64_t *)var_60h != &var_98h));
            }
        }
        pauVar1 = pauVar8 + 1;
        piVar4 = (int64_t *)(arg1 + 0x90);
        puVar11 = (undefined8 *)*piVar4;
        puVar13 = (undefined8 *)puVar11[1];
        puVar9 = puVar13;
        if (*(char *)((int64_t)puVar13 + 0x19) == '\0') {
            do {
                puVar13 = puVar9;
                if ((uint64_t)arg_28h <= (uint64_t)puVar13[4]) {
                    puVar9 = (undefined8 *)*puVar13;
                    puVar11 = puVar13;
                } else {
                    puVar9 = (undefined8 *)puVar13[2];
                }
                uVar12 = (uint32_t)((uint64_t)arg_28h <= (uint64_t)puVar13[4]);
            } while (*(char *)((int64_t)puVar9 + 0x19) == '\0');
        } else {
            uVar12 = 0;
        }
        var_c8h = (int64_t)pauVar1;
        var_c0h = (int64_t)pauVar8;
        if ((*(char *)((int64_t)puVar11 + 0x19) != '\0') || ((uint64_t)arg_28h < (uint64_t)puVar11[4])) {
            if (*(int64_t *)(arg1 + 0x98) == 0x492492492492492) {
                func_0x000180013c00();
                pcVar5 = (code *)swi(3);
                (*pcVar5)();
                return;
            }
            iVar7 = *piVar4;
            var_a0h = 0;
            var_a8h = (int64_t)piVar4;
            piVar10 = (int64_t *)func_0x000180459890();
            piVar10[4] = arg_28h;
            piVar10[5] = 0;
            piVar10[6] = 0;
            *piVar10 = iVar7;
            piVar10[1] = iVar7;
            piVar10[2] = iVar7;
            *(undefined2 *)(piVar10 + 3) = 0;
            var_c0h = CONCAT44(var_c0h._4_4_, uVar12);
            var_c8h = (int64_t)puVar13;
            puVar11 = (undefined8 *)func_0x0001800156d0(piVar4, &var_c8h, piVar10);
        }
        puVar11[5] = pauVar1;
        piVar4 = (int64_t *)puVar11[6];
        puVar11[6] = pauVar8;
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar10 = piVar4 + 1;
            iVar6 = *(int32_t *)piVar10;
            *(int32_t *)piVar10 = *(int32_t *)piVar10 + -1;
            UNLOCK();
            if (iVar6 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar6 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar6 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        piVar4 = *(int64_t **)(arg3 + 0x38);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)arg3);
            *(undefined8 *)(arg3 + 0x38) = 0;
        }
    }
    func_0x000180459870(var_50h ^ (uint64_t)auStack_e8);
    return;
}

// ============================================================
// Function: FUN_180180a60
// Address: 0x180180a60
// Size: 911 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180180a60(int64_t arg1)
{
    undefined4 uVar1;
    bool bVar2;
    char cVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t **ppiVar8;
    int64_t *piVar9;
    int64_t **ppiVar10;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_138h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    iVar6 = *(int64_t *)(arg1 + 8);
    if (iVar6 == 0) {
code_r0x000180180ad4:
        iVar5 = func_0x00018017f7d0(arg1, arg1 + 0x3c);
        if (iVar5 < 0) {
            piVar9 = (int64_t *)(arg1 + 0x18);
            if (0xf < *(uint64_t *)(arg1 + 0x30)) {
                piVar9 = (int64_t *)*piVar9;
            }
            iVar6 = func_0x00018045b9a8(0x1804a7020, 0x5c);
            uVar1 = *(undefined4 *)(arg1 + 0x38);
            uVar7 = func_0x0001801723e0();
            var_188h = 0x1804a6fd0;
            var_190h._0_4_ = 0x6e;
            var_1a8h = CONCAT44(var_1a8h._4_4_, uVar1);
            var_1a0h._0_4_ = iVar5;
            var_198h = iVar6 + 1;
            func_0x000180172b00(uVar7, 4, 0x1804a7088, piVar9);
            goto code_r0x000180180dc8;
        }
    } else {
        if ((((*(int64_t *)(iVar6 + 8) == 0) || (2 < *(int32_t *)(iVar6 + 0x20))) ||
            (iVar5 = *(int32_t *)(iVar6 + 0x14), iVar4 = func_0x000180173bc0(*(undefined8 *)(iVar6 + 8)), iVar5 != iVar4
            )) || (cVar3 = func_0x000180173be0(*(undefined8 *)(iVar6 + 8)), cVar3 == '\0')) {
            bVar2 = true;
        } else {
            bVar2 = false;
        }
        if (bVar2) goto code_r0x000180180ad4;
    }
    if ((*(int64_t *)(arg1 + 8) == 0) || (0 < *(int32_t *)(*(int64_t *)(arg1 + 8) + 0x20))) goto code_r0x000180180dc8;
    if ((*(int32_t *)(arg1 + 0x58) != 0) && (*(int64_t *)(*(int64_t *)(arg1 + 8) + 8) != 0)) {
        func_0x000180174080();
    }
    if (*(char *)(arg1 + 0x5c) != '\0') {
        if (*(int64_t *)(*(int64_t *)(arg1 + 8) + 8) != 0) {
            func_0x000180173960();
        }
        if (*(int64_t *)(arg1 + 0x60) != 0) {
            if (*(int64_t *)(*(int64_t *)(arg1 + 8) + 8) == 0) {
                iVar5 = -1;
            } else {
                iVar5 = func_0x000180173c70();
                if (iVar5 == 0) goto code_r0x000180180c60;
            }
            iVar6 = func_0x00018045b9a8(0x1804a7020, 0x5c);
            uVar7 = func_0x0001801723e0();
            var_198h = 0x1804a6fd0;
            var_1a0h._0_4_ = 0x7d;
            var_1a8h = iVar6 + 1;
            func_0x000180172b00(uVar7, 4, 0x1804a70b8, iVar5);
            if ((*(int64_t *)(arg1 + 8) != 0) && (*(int32_t *)(*(int64_t *)(arg1 + 8) + 0x20) != 4)) {
                var_170h = 0x1804a7198;
                var_138h = (int64_t)&var_170h;
                var_168h = arg1;
                fcn.180180470(*(int64_t *)(arg1 + 0x138), (int64_t)&var_170h);
            }
            goto code_r0x000180180dc8;
        }
code_r0x000180180c60:
        ppiVar8 = (int64_t **)(arg1 + 0x18);
        ppiVar10 = ppiVar8;
        if (0xf < *(uint64_t *)(arg1 + 0x30)) {
            ppiVar10 = (int64_t **)*ppiVar8;
        }
        cVar3 = func_0x000180184ad0(ppiVar10);
        if (((cVar3 == '\0') && (cVar3 = func_0x000180184b10(ppiVar10), cVar3 == '\0')) &&
           (iVar6 = *(int64_t *)(*(int64_t *)(arg1 + 8) + 8), iVar6 != 0)) {
            if (0xf < *(uint64_t *)(arg1 + 0x30)) {
                ppiVar8 = (int64_t **)*ppiVar8;
            }
            func_0x000180174140(iVar6, ppiVar8);
        }
    }
    var_128h = 0x1804a72e8;
    var_f0h = (int64_t)&var_128h;
    var_120h = arg1;
    func_0x000180014e50(&var_128h, *(int64_t *)(arg1 + 8) + 0xf8);
    if (var_f0h != 0) {
        (**(code **)(*(int64_t *)var_f0h + 0x20))
                  (var_f0h, CONCAT71((unkint7)((uint64_t)&var_128h >> 8), (int64_t *)var_f0h != &var_128h));
    }
    var_e8h = 0x1804a7320;
    var_b0h = (int64_t)&var_e8h;
    var_e0h = arg1;
    func_0x000180014e50(&var_e8h, *(int64_t *)(arg1 + 8) + 0x28);
    if (var_b0h != 0) {
        (**(code **)(*(int64_t *)var_b0h + 0x20))
                  (var_b0h, CONCAT71((unkint7)((uint64_t)&var_e8h >> 8), (int64_t *)var_b0h != &var_e8h));
    }
    var_a8h = 0x1804a7358;
    var_70h = (int64_t)&var_a8h;
    var_a0h = arg1;
    func_0x000180014e50(&var_a8h, *(int64_t *)(arg1 + 8) + 0x68);
    if (var_70h != 0) {
        (**(code **)(*(int64_t *)var_70h + 0x20))
                  (var_70h, CONCAT71((unkint7)((uint64_t)&var_a8h >> 8), (int64_t *)var_70h != &var_a8h));
    }
    var_68h = 0x1804a7390;
    var_30h = (int64_t)&var_68h;
    var_60h = arg1;
    func_0x000180014e50(&var_68h, *(int64_t *)(arg1 + 8) + 0xa8);
    if (var_30h != 0) {
        (**(code **)(*(int64_t *)var_30h + 0x20))
                  (var_30h, CONCAT71((unkint7)((uint64_t)&var_68h >> 8), (int64_t *)var_30h != &var_68h));
    }
    func_0x000180180df0(*(undefined8 *)(arg1 + 8));
code_r0x000180180dc8:
    func_0x000180459870(var_28h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_180180df0
// Address: 0x180180df0
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int32_t fcn.180180df0(int64_t arg1)
{
    int32_t *piVar1;
    int64_t *piVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000028;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uStack_20;
    undefined auStack_18 [16];
    
    if (*(int64_t *)(arg1 + 8) == 0) {
        return -1;
    }
    LOCK();
    *(undefined4 *)(arg1 + 0x20) = 1;
    UNLOCK();
    var_30h = 0x180180e23;
    fcn.180174300(*(undefined8 *)(arg1 + 8), fcn.18017fac0);
    piVar2 = *(int64_t **)(arg1 + 8);
    iVar7 = piVar2[0xc];
    iVar4 = *(int32_t *)(piVar2 + 9);
    uVar3 = fcn.180184b50(iVar7);
    iVar4 = (*(code *)0x8000000000000004)((int64_t)iVar4, iVar7, uVar3);
    if ((iVar4 < 0) && (iVar5 = (*(code *)0x800000000000006f)(), iVar5 != 0x2733)) {
        fcn.18047208c(0x180624fe0);
        uVar3 = (*(code *)0x800000000000006f)();
        *(undefined4 *)((int64_t)piVar2 + 0x4c) = uVar3;
        fcn.180181d00(piVar2);
        return iVar4;
    }
    if (iVar4 == 0) {
        var_48h = 0;
        var_40h = 0;
        var_38h = 0;
        var_30h = 0x180184380;
        uStack_20 = (uint64_t)*(uint32_t *)((int64_t)piVar2 + 0x44);
        auStack_18 = ZEXT816(0);
        var_28h = (int64_t)piVar2;
        fcn.1801823b0(*piVar2, &var_48h);
        return 0;
    }
    iVar4 = 10000;
    if (*(int32_t *)(piVar2 + 0x24) != 0) {
        iVar4 = *(int32_t *)(piVar2 + 0x24);
    }
    iVar7 = fcn.180182c00(*piVar2, 0x180183500, iVar4, 1);
    piVar2[0x28] = iVar7;
    *(int64_t **)(iVar7 + 0x28) = piVar2;
    *(uint32_t *)((int64_t)piVar2 + 0x3c) = *(uint32_t *)((int64_t)piVar2 + 0x3c) | 0x80;
    if (2 < *(int32_t *)(piVar2 + 9)) {
        iVar7 = *piVar2;
        if ((*(uint8_t *)((int64_t)piVar2 + 0x3c) & 2) == 0) {
            var_30h = 0x180181c8b;
            iVar6 = fcn.180174350();
            piVar2[2] = iVar6;
            piVar2[3] = 0x180183a50;
            if ((*(uint32_t *)((int64_t)piVar2 + 0x3c) & 2) == 0) {
                *(uint32_t *)((int64_t)piVar2 + 0x3c) = *(uint32_t *)((int64_t)piVar2 + 0x3c) | 2;
                *(int32_t *)(*piVar2 + 0x44) = *(int32_t *)(*piVar2 + 0x44) + 1;
            }
            piVar1 = (int32_t *)(iVar7 + 0x130);
            *piVar1 = *piVar1 + 1;
        }
        if ((*(uint8_t *)((int64_t)piVar2 + 0x3c) & 8) == 0) {
            var_30h = 0x180181cbb;
            fcn.180173db0(in_stack_00000028);
        }
        piVar2[3] = 0x180183a50;
        if ((*(uint32_t *)(piVar2 + 10) & 4) == 0) {
            var_30h = 0x180181cdc;
            fcn.18018a050(iVar7, *(undefined4 *)(piVar2 + 9), 4);
            *(uint32_t *)(piVar2 + 10) = *(uint32_t *)(piVar2 + 10) | 4;
        }
        return 0;
    }
    return -1;
}

// ============================================================
// Function: FUN_180180e40
// Address: 0x180180e40
// Size: 115 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180180e40(int64_t arg1)
{
    int32_t iVar1;
    int32_t iVar2;
    char in_DL;
    int32_t *piVar3;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t *piStack_10;
    
    if ((*(int64_t *)(arg1 + 8) != 0) && (*(int32_t *)(*(int64_t *)(arg1 + 8) + 0x20) != 4)) {
        var_48h = 0x1804a7198;
        piStack_10 = &var_48h;
        var_40h = arg1;
        fcn.180180470(*(int64_t *)(arg1 + 0x138), (int64_t)&var_48h);
    }
    if (((*(char *)(arg1 + 0x170) != '\0') && (piVar3 = (int32_t *)(arg1 + 0x148), 2 < *piVar3)) && (*piVar3 < 7)) {
        LOCK();
        *piVar3 = 7;
        UNLOCK();
        if (*(int64_t *)(*(int64_t *)(arg1 + 0x150) + 8) == 0) {
            iVar1 = (*(code *)0x699ddc)();
        } else {
            iVar1 = func_0x000180182b10();
        }
        func_0x0001800613a0(*(undefined8 *)(arg1 + 0x150));
        if ((in_DL != '\0') && (iVar2 = (*(code *)0x699ddc)(), iVar2 != iVar1)) {
            func_0x000180061db0(piVar3);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180180eb3
// Address: 0x180180eb3
// Size: 72 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180180e40(int64_t arg1)
{
    int32_t iVar1;
    int32_t iVar2;
    char in_DL;
    int32_t *piVar3;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t *piStack_10;
    
    if ((*(int64_t *)(arg1 + 8) != 0) && (*(int32_t *)(*(int64_t *)(arg1 + 8) + 0x20) != 4)) {
        var_48h = 0x1804a7198;
        piStack_10 = &var_48h;
        var_40h = arg1;
        fcn.180180470(*(int64_t *)(arg1 + 0x138), (int64_t)&var_48h);
    }
    if (((*(char *)(arg1 + 0x170) != '\0') && (piVar3 = (int32_t *)(arg1 + 0x148), 2 < *piVar3)) && (*piVar3 < 7)) {
        LOCK();
        *piVar3 = 7;
        UNLOCK();
        if (*(int64_t *)(*(int64_t *)(arg1 + 0x150) + 8) == 0) {
            iVar1 = (*(code *)0x699ddc)();
        } else {
            iVar1 = func_0x000180182b10();
        }
        func_0x0001800613a0(*(undefined8 *)(arg1 + 0x150));
        if ((in_DL != '\0') && (iVar2 = (*(code *)0x699ddc)(), iVar2 != iVar1)) {
            func_0x000180061db0(piVar3);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180180efb
// Address: 0x180180efb
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180180e40(int64_t arg1)
{
    int32_t iVar1;
    int32_t iVar2;
    char in_DL;
    int32_t *piVar3;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t *piStack_10;
    
    if ((*(int64_t *)(arg1 + 8) != 0) && (*(int32_t *)(*(int64_t *)(arg1 + 8) + 0x20) != 4)) {
        var_48h = 0x1804a7198;
        piStack_10 = &var_48h;
        var_40h = arg1;
        fcn.180180470(*(int64_t *)(arg1 + 0x138), (int64_t)&var_48h);
    }
    if (((*(char *)(arg1 + 0x170) != '\0') && (piVar3 = (int32_t *)(arg1 + 0x148), 2 < *piVar3)) && (*piVar3 < 7)) {
        LOCK();
        *piVar3 = 7;
        UNLOCK();
        if (*(int64_t *)(*(int64_t *)(arg1 + 0x150) + 8) == 0) {
            iVar1 = (*(code *)0x699ddc)();
        } else {
            iVar1 = func_0x000180182b10();
        }
        func_0x0001800613a0(*(undefined8 *)(arg1 + 0x150));
        if ((in_DL != '\0') && (iVar2 = (*(code *)0x699ddc)(), iVar2 != iVar1)) {
            func_0x000180061db0(piVar3);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180180f10
// Address: 0x180180f10
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int32_t fcn.180180f10(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 uVar1;
    uint32_t uVar2;
    int64_t *piVar3;
    char cVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t unaff_R15;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    uVar12 = (uint64_t)(int32_t)arg3;
    if ((((*(int64_t *)(arg1 + 8) == 0) || (2 < *(int32_t *)(arg1 + 0x20))) ||
        (iVar6 = *(int32_t *)(arg1 + 0x14), iVar5 = fcn.180173bc0(*(undefined8 *)(arg1 + 8)), iVar6 != iVar5)) ||
       (cVar4 = fcn.180173be0(*(undefined8 *)(arg1 + 8)), cVar4 == '\0')) {
        return -1;
    }
    piVar3 = *(int64_t **)(arg1 + 8);
    iVar7 = piVar3[0xc];
    if ((*(uint8_t *)((int64_t)piVar3 + 0x3c) & 0x20) != 0) {
        iVar7 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar1 = *(undefined4 *)(piVar3 + 9);
        uVar8 = fcn.1801723e0(var_50h);
        fcn.180172b00(uVar8, 4, 0x1804a7a20, uVar1, iVar7 + 1, 0x1ef, 0x1804a7a10);
        return -1;
    }
    iVar6 = 0;
    (*(code *)0x699f1c)(piVar3 + 0x19);
    if (piVar3[0x16] == 0) {
        iVar6 = fcn.180183630(unaff_R15);
        if (-1 < iVar6) {
            if ((int64_t)iVar6 == uVar12) goto code_r0x000180183fb0;
            if ((iVar6 == 0) && ((*(uint32_t *)(piVar3 + 8) & 0xff00000) != 0)) goto code_r0x000180183d99;
code_r0x000180183d0d:
            fcn.180181c40(var_60h, var_58h, var_50h, CONCAT44(var_48h._4_4_, (undefined4)var_48h));
            goto code_r0x000180183d22;
        }
        iVar5 = (*(code *)0x800000000000006f)();
        if ((iVar5 == 0x2733) || (iVar5 == 0x2714)) {
            iVar6 = 0;
            iVar9 = fcn.18045b9a8(0x1804a77e0, 0x5c);
            uVar8 = fcn.1801723e0(var_50h);
            var_60h = 0x1804a7a10;
            fcn.180172b00(uVar8, 3, 0x1804a7a58, iVar9 + 1, 0x203);
            goto code_r0x000180183d0d;
        }
code_r0x000180183d96:
        *(int32_t *)((int64_t)piVar3 + 0x4c) = iVar5;
code_r0x000180183d99:
        (*(code *)0x699f34)(piVar3 + 0x19);
        if ((*(uint32_t *)(piVar3 + 8) & 0xff00000) != 0) {
            fcn.180181d00(piVar3);
        }
        if (-1 < iVar6) {
            return -1;
        }
        return iVar6;
    }
code_r0x000180183d22:
    uVar11 = (uint64_t)iVar6;
    if (uVar12 <= uVar11) goto code_r0x000180183fb0;
    uVar12 = uVar12 - uVar11;
    if ((uint64_t)*(uint32_t *)((int64_t)piVar3 + 0xf4) < *(uint32_t *)(piVar3 + 0x1e) + uVar12) {
        iVar7 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar1 = *(undefined4 *)((int64_t)piVar3 + 0xf4);
        uVar8 = fcn.1801723e0(var_50h);
        fcn.180172b00(uVar8, 4, 0x1804a7a80, uVar1, iVar7 + 1, 0x217, 0x1804a7a10);
        iVar5 = 0x3fe;
        goto code_r0x000180183d96;
    }
    if (((*(uint32_t *)(piVar3 + 8) & 0xfff00) == 0) || (iVar7 == 0)) {
        iVar9 = fcn.1801813b0(uVar12);
        iVar13 = 0;
        var_8h = uVar12;
        if (iVar7 != 0) goto code_r0x000180183e18;
    } else {
        iVar5 = fcn.180184b50(iVar7);
        iVar13 = (int64_t)iVar5;
        iVar9 = fcn.1801813b0(iVar13 + uVar12);
        var_8h = iVar13 + uVar12;
code_r0x000180183e18:
        if (iVar13 != 0) {
            fcn.180498030(iVar9, iVar7, iVar13);
        }
    }
    fcn.180498030(iVar13 + iVar9, arg2 + uVar11, uVar12);
    if (piVar3[0x17] == 0) {
        piVar3[0x18] = 0;
        piVar3[0x16] = 0;
        piVar3[0x17] = 4;
        iVar7 = fcn.1801813b0(0x60);
        piVar3[0x15] = iVar7;
    }
    iVar7 = piVar3[0x17];
    iVar10 = piVar3[0x16];
    if (iVar10 == iVar7) {
        iVar5 = (int32_t)iVar7 * 2;
        if (iVar5 == 0) {
            iVar5 = 0x10;
        }
        iVar7 = fcn.180181320(piVar3[0x15], (int64_t)iVar5 * 0x18, iVar7 * 0x18);
        piVar3[0x15] = iVar7;
        piVar3[0x17] = (int64_t)iVar5;
    } else if (piVar3[0x18] + iVar10 == iVar7) {
        fcn.180498030(piVar3[0x15], piVar3[0x15] + piVar3[0x18] * 0x18, iVar10 * 0x18);
        piVar3[0x18] = 0;
    }
    iVar10 = piVar3[0x16] + piVar3[0x18];
    iVar7 = piVar3[0x15];
    *(int64_t *)(iVar7 + iVar10 * 0x18) = iVar9;
    *(int64_t *)(iVar7 + 8 + iVar10 * 0x18) = var_8h;
    *(int64_t *)(iVar7 + 0x10 + iVar10 * 0x18) = iVar13;
    piVar3[0x16] = piVar3[0x16] + 1;
    *(int32_t *)(piVar3 + 0x1e) = *(int32_t *)(piVar3 + 0x1e) + (int32_t)uVar12;
    if (0x800000 < *(uint32_t *)(piVar3 + 0x1e)) {
        iVar7 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar2 = *(uint32_t *)(piVar3 + 0x1e);
        uVar8 = fcn.1801723e0(var_50h);
        var_60h = (int64_t)uVar2;
        var_68h = uVar12 & 0xffffffff;
        fcn.180172b00(uVar8, 3, 0x1804a7ab0, arg3 & 0xffffffff, var_68h, var_60h, 0x800000, iVar7 + 1, 0x232, 
                      0x1804a7a10);
    }
code_r0x000180183fb0:
    (*(code *)0x699f34)(piVar3 + 0x19);
    if (0 < iVar6) {
        piVar3[0xe] = *(int64_t *)(*piVar3 + 0x20);
        fcn.180174330(piVar3, arg2, iVar6);
    }
    return iVar6;
}

// ============================================================
// Function: FUN_180180f38
// Address: 0x180180f38
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int32_t fcn.180180f10(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 uVar1;
    uint32_t uVar2;
    int64_t *piVar3;
    char cVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t unaff_R15;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    uVar12 = (uint64_t)(int32_t)arg3;
    if ((((*(int64_t *)(arg1 + 8) == 0) || (2 < *(int32_t *)(arg1 + 0x20))) ||
        (iVar6 = *(int32_t *)(arg1 + 0x14), iVar5 = fcn.180173bc0(*(undefined8 *)(arg1 + 8)), iVar6 != iVar5)) ||
       (cVar4 = fcn.180173be0(*(undefined8 *)(arg1 + 8)), cVar4 == '\0')) {
        return -1;
    }
    piVar3 = *(int64_t **)(arg1 + 8);
    iVar7 = piVar3[0xc];
    if ((*(uint8_t *)((int64_t)piVar3 + 0x3c) & 0x20) != 0) {
        iVar7 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar1 = *(undefined4 *)(piVar3 + 9);
        uVar8 = fcn.1801723e0(var_50h);
        fcn.180172b00(uVar8, 4, 0x1804a7a20, uVar1, iVar7 + 1, 0x1ef, 0x1804a7a10);
        return -1;
    }
    iVar6 = 0;
    (*(code *)0x699f1c)(piVar3 + 0x19);
    if (piVar3[0x16] == 0) {
        iVar6 = fcn.180183630(unaff_R15);
        if (-1 < iVar6) {
            if ((int64_t)iVar6 == uVar12) goto code_r0x000180183fb0;
            if ((iVar6 == 0) && ((*(uint32_t *)(piVar3 + 8) & 0xff00000) != 0)) goto code_r0x000180183d99;
code_r0x000180183d0d:
            fcn.180181c40(var_60h, var_58h, var_50h, CONCAT44(var_48h._4_4_, (undefined4)var_48h));
            goto code_r0x000180183d22;
        }
        iVar5 = (*(code *)0x800000000000006f)();
        if ((iVar5 == 0x2733) || (iVar5 == 0x2714)) {
            iVar6 = 0;
            iVar9 = fcn.18045b9a8(0x1804a77e0, 0x5c);
            uVar8 = fcn.1801723e0(var_50h);
            var_60h = 0x1804a7a10;
            fcn.180172b00(uVar8, 3, 0x1804a7a58, iVar9 + 1, 0x203);
            goto code_r0x000180183d0d;
        }
code_r0x000180183d96:
        *(int32_t *)((int64_t)piVar3 + 0x4c) = iVar5;
code_r0x000180183d99:
        (*(code *)0x699f34)(piVar3 + 0x19);
        if ((*(uint32_t *)(piVar3 + 8) & 0xff00000) != 0) {
            fcn.180181d00(piVar3);
        }
        if (-1 < iVar6) {
            return -1;
        }
        return iVar6;
    }
code_r0x000180183d22:
    uVar11 = (uint64_t)iVar6;
    if (uVar12 <= uVar11) goto code_r0x000180183fb0;
    uVar12 = uVar12 - uVar11;
    if ((uint64_t)*(uint32_t *)((int64_t)piVar3 + 0xf4) < *(uint32_t *)(piVar3 + 0x1e) + uVar12) {
        iVar7 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar1 = *(undefined4 *)((int64_t)piVar3 + 0xf4);
        uVar8 = fcn.1801723e0(var_50h);
        fcn.180172b00(uVar8, 4, 0x1804a7a80, uVar1, iVar7 + 1, 0x217, 0x1804a7a10);
        iVar5 = 0x3fe;
        goto code_r0x000180183d96;
    }
    if (((*(uint32_t *)(piVar3 + 8) & 0xfff00) == 0) || (iVar7 == 0)) {
        iVar9 = fcn.1801813b0(uVar12);
        iVar13 = 0;
        var_8h = uVar12;
        if (iVar7 != 0) goto code_r0x000180183e18;
    } else {
        iVar5 = fcn.180184b50(iVar7);
        iVar13 = (int64_t)iVar5;
        iVar9 = fcn.1801813b0(iVar13 + uVar12);
        var_8h = iVar13 + uVar12;
code_r0x000180183e18:
        if (iVar13 != 0) {
            fcn.180498030(iVar9, iVar7, iVar13);
        }
    }
    fcn.180498030(iVar13 + iVar9, arg2 + uVar11, uVar12);
    if (piVar3[0x17] == 0) {
        piVar3[0x18] = 0;
        piVar3[0x16] = 0;
        piVar3[0x17] = 4;
        iVar7 = fcn.1801813b0(0x60);
        piVar3[0x15] = iVar7;
    }
    iVar7 = piVar3[0x17];
    iVar10 = piVar3[0x16];
    if (iVar10 == iVar7) {
        iVar5 = (int32_t)iVar7 * 2;
        if (iVar5 == 0) {
            iVar5 = 0x10;
        }
        iVar7 = fcn.180181320(piVar3[0x15], (int64_t)iVar5 * 0x18, iVar7 * 0x18);
        piVar3[0x15] = iVar7;
        piVar3[0x17] = (int64_t)iVar5;
    } else if (piVar3[0x18] + iVar10 == iVar7) {
        fcn.180498030(piVar3[0x15], piVar3[0x15] + piVar3[0x18] * 0x18, iVar10 * 0x18);
        piVar3[0x18] = 0;
    }
    iVar10 = piVar3[0x16] + piVar3[0x18];
    iVar7 = piVar3[0x15];
    *(int64_t *)(iVar7 + iVar10 * 0x18) = iVar9;
    *(int64_t *)(iVar7 + 8 + iVar10 * 0x18) = var_8h;
    *(int64_t *)(iVar7 + 0x10 + iVar10 * 0x18) = iVar13;
    piVar3[0x16] = piVar3[0x16] + 1;
    *(int32_t *)(piVar3 + 0x1e) = *(int32_t *)(piVar3 + 0x1e) + (int32_t)uVar12;
    if (0x800000 < *(uint32_t *)(piVar3 + 0x1e)) {
        iVar7 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar2 = *(uint32_t *)(piVar3 + 0x1e);
        uVar8 = fcn.1801723e0(var_50h);
        var_60h = (int64_t)uVar2;
        var_68h = uVar12 & 0xffffffff;
        fcn.180172b00(uVar8, 3, 0x1804a7ab0, arg3 & 0xffffffff, var_68h, var_60h, 0x800000, iVar7 + 1, 0x232, 
                      0x1804a7a10);
    }
code_r0x000180183fb0:
    (*(code *)0x699f34)(piVar3 + 0x19);
    if (0 < iVar6) {
        piVar3[0xe] = *(int64_t *)(*piVar3 + 0x20);
        fcn.180174330(piVar3, arg2, iVar6);
    }
    return iVar6;
}

// ============================================================
// Function: FUN_180180f52
// Address: 0x180180f52
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_62h
// WARNING: [rz-ghidra] Detected overlap for variable var_8ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_5eh
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ah
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int32_t fcn.180180f10(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 uVar1;
    uint32_t uVar2;
    int64_t *piVar3;
    char cVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t unaff_R15;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    uVar12 = (uint64_t)(int32_t)arg3;
    if ((((*(int64_t *)(arg1 + 8) == 0) || (2 < *(int32_t *)(arg1 + 0x20))) ||
        (iVar6 = *(int32_t *)(arg1 + 0x14), iVar5 = fcn.180173bc0(*(undefined8 *)(arg1 + 8)), iVar6 != iVar5)) ||
       (cVar4 = fcn.180173be0(*(undefined8 *)(arg1 + 8)), cVar4 == '\0')) {
        return -1;
    }
    piVar3 = *(int64_t **)(arg1 + 8);
    iVar7 = piVar3[0xc];
    if ((*(uint8_t *)((int64_t)piVar3 + 0x3c) & 0x20) != 0) {
        iVar7 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar1 = *(undefined4 *)(piVar3 + 9);
        uVar8 = fcn.1801723e0(var_50h);
        fcn.180172b00(uVar8, 4, 0x1804a7a20, uVar1, iVar7 + 1, 0x1ef, 0x1804a7a10);
        return -1;
    }
    iVar6 = 0;
    (*(code *)0x699f1c)(piVar3 + 0x19);
    if (piVar3[0x16] == 0) {
        iVar6 = fcn.180183630(unaff_R15);
        if (-1 < iVar6) {
            if ((int64_t)iVar6 == uVar12) goto code_r0x000180183fb0;
            if ((iVar6 == 0) && ((*(uint32_t *)(piVar3 + 8) & 0xff00000) != 0)) goto code_r0x000180183d99;
code_r0x000180183d0d:
            fcn.180181c40(var_60h, var_58h, var_50h, CONCAT44(var_48h._4_4_, (undefined4)var_48h));
            goto code_r0x000180183d22;
        }
        iVar5 = (*(code *)0x800000000000006f)();
        if ((iVar5 == 0x2733) || (iVar5 == 0x2714)) {
            iVar6 = 0;
            iVar9 = fcn.18045b9a8(0x1804a77e0, 0x5c);
            uVar8 = fcn.1801723e0(var_50h);
            var_60h = 0x1804a7a10;
            fcn.180172b00(uVar8, 3, 0x1804a7a58, iVar9 + 1, 0x203);
            goto code_r0x000180183d0d;
        }
code_r0x000180183d96:
        *(int32_t *)((int64_t)piVar3 + 0x4c) = iVar5;
code_r0x000180183d99:
        (*(code *)0x699f34)(piVar3 + 0x19);
        if ((*(uint32_t *)(piVar3 + 8) & 0xff00000) != 0) {
            fcn.180181d00(piVar3);
        }
        if (-1 < iVar6) {
            return -1;
        }
        return iVar6;
    }
code_r0x000180183d22:
    uVar11 = (uint64_t)iVar6;
    if (uVar12 <= uVar11) goto code_r0x000180183fb0;
    uVar12 = uVar12 - uVar11;
    if ((uint64_t)*(uint32_t *)((int64_t)piVar3 + 0xf4) < *(uint32_t *)(piVar3 + 0x1e) + uVar12) {
        iVar7 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar1 = *(undefined4 *)((int64_t)piVar3 + 0xf4);
        uVar8 = fcn.1801723e0(var_50h);
        fcn.180172b00(uVar8, 4, 0x1804a7a80, uVar1, iVar7 + 1, 0x217, 0x1804a7a10);
        iVar5 = 0x3fe;
        goto code_r0x000180183d96;
    }
    if (((*(uint32_t *)(piVar3 + 8) & 0xfff00) == 0) || (iVar7 == 0)) {
        iVar9 = fcn.1801813b0(uVar12);
        iVar13 = 0;
        var_8h = uVar12;
        if (iVar7 != 0) goto code_r0x000180183e18;
    } else {
        iVar5 = fcn.180184b50(iVar7);
        iVar13 = (int64_t)iVar5;
        iVar9 = fcn.1801813b0(iVar13 + uVar12);
        var_8h = iVar13 + uVar12;
code_r0x000180183e18:
        if (iVar13 != 0) {
            fcn.180498030(iVar9, iVar7, iVar13);
        }
    }
    fcn.180498030(iVar13 + iVar9, arg2 + uVar11, uVar12);
    if (piVar3[0x17] == 0) {
        piVar3[0x18] = 0;
        piVar3[0x16] = 0;
        piVar3[0x17] = 4;
        iVar7 = fcn.1801813b0(0x60);
        piVar3[0x15] = iVar7;
    }
    iVar7 = piVar3[0x17];
    iVar10 = piVar3[0x16];
    if (iVar10 == iVar7) {
        iVar5 = (int32_t)iVar7 * 2;
        if (iVar5 == 0) {
            iVar5 = 0x10;
        }
        iVar7 = fcn.180181320(piVar3[0x15], (int64_t)iVar5 * 0x18, iVar7 * 0x18);
        piVar3[0x15] = iVar7;
        piVar3[0x17] = (int64_t)iVar5;
    } else if (piVar3[0x18] + iVar10 == iVar7) {
        fcn.180498030(piVar3[0x15], piVar3[0x15] + piVar3[0x18] * 0x18, iVar10 * 0x18);
        piVar3[0x18] = 0;
    }
    iVar10 = piVar3[0x16] + piVar3[0x18];
    iVar7 = piVar3[0x15];
    *(int64_t *)(iVar7 + iVar10 * 0x18) = iVar9;
    *(int64_t *)(iVar7 + 8 + iVar10 * 0x18) = var_8h;
    *(int64_t *)(iVar7 + 0x10 + iVar10 * 0x18) = iVar13;
    piVar3[0x16] = piVar3[0x16] + 1;
    *(int32_t *)(piVar3 + 0x1e) = *(int32_t *)(piVar3 + 0x1e) + (int32_t)uVar12;
    if (0x800000 < *(uint32_t *)(piVar3 + 0x1e)) {
        iVar7 = fcn.18045b9a8(0x1804a77e0, 0x5c);
        uVar2 = *(uint32_t *)(piVar3 + 0x1e);
        uVar8 = fcn.1801723e0(var_50h);
        var_60h = (int64_t)uVar2;
        var_68h = uVar12 & 0xffffffff;
        fcn.180172b00(uVar8, 3, 0x1804a7ab0, arg3 & 0xffffffff, var_68h, var_60h, 0x800000, iVar7 + 1, 0x232, 
                      0x1804a7a10);
    }
code_r0x000180183fb0:
    (*(code *)0x699f34)(piVar3 + 0x19);
    if (0 < iVar6) {
        piVar3[0xe] = *(int64_t *)(*piVar3 + 0x20);
        fcn.180174330(piVar3, arg2, iVar6);
    }
    return iVar6;
}

// ============================================================
// Function: FUN_180180fe0
// Address: 0x180180fe0
// Size: 26 bytes
// ============================================================
void fcn.180180fe0(int64_t arg1)
{
    if (arg1 != 0) {
        fcn.180460d90();
        LOCK();
        *(int32_t *)0x18077e0f4 = *(int32_t *)0x18077e0f4 + 1;
        UNLOCK();
    }
    return;
}

// ============================================================
// Function: FUN_180181000
// Address: 0x180181000
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.180181000(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    char *pcVar4;
    char *pcVar5;
    char *pcVar6;
    int16_t iVar7;
    int16_t iVar8;
    char *pcVar9;
    char *pcVar10;
    int16_t iVar11;
    char *pcVar12;
    uint16_t uVar13;
    uint64_t uVar14;
    uint16_t uVar15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    if ((arg1 == 0) || (arg2 == 0)) {
        return 0xffffffff;
    }
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x10) = ZEXT816(0);
    *(undefined2 *)(arg1 + 0x20) = 0;
    cVar1 = *(char *)arg2;
    pcVar12 = (char *)arg2;
    while (cVar1 != '\0') {
        pcVar12 = pcVar12 + 1;
        cVar1 = *pcVar12;
    }
    if (0xffff < (int64_t)pcVar12 - arg2) {
        return 0xfffffffe;
    }
    iVar3 = func_0x00018045bb90(arg2, 0x1804a63dc);
    iVar11 = (int16_t)arg2;
    pcVar10 = (char *)arg2;
    if (iVar3 != 0) {
        pcVar10 = (char *)(iVar3 + 3);
        *(int16_t *)(arg1 + 2) = (int16_t)iVar3 - iVar11;
    }
    pcVar4 = (char *)func_0x00018045b928(pcVar10, 0x2f);
    if (pcVar4 == (char *)0x0) {
        pcVar4 = pcVar12;
    }
    cVar1 = *pcVar10;
    pcVar9 = pcVar10;
    for (iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10; (cVar1 != '\0' && (iVar3 != 0)); iVar3 = iVar3 + -1) {
        if (*pcVar9 == '@') {
            iVar3 = (int64_t)pcVar9 - (int64_t)pcVar10;
            pcVar5 = pcVar10;
            goto code_r0x000180181118;
        }
        pcVar9 = pcVar9 + 1;
        cVar1 = *pcVar9;
    }
code_r0x0001801810de:
    pcVar9 = pcVar10;
    if (*pcVar10 == '[') {
        iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10;
        pcVar5 = pcVar10;
        do {
            if (iVar3 == 0) break;
            if (*pcVar5 == ']') {
                pcVar9 = pcVar10 + 1;
                iVar7 = (int16_t)pcVar9;
                *(int16_t *)(arg1 + 0xc) = iVar7 - iVar11;
                *(int16_t *)(arg1 + 0xe) = (int16_t)pcVar5 - iVar7;
                pcVar10 = pcVar5;
                break;
            }
            pcVar5 = pcVar5 + 1;
            iVar3 = iVar3 + -1;
        } while (*pcVar5 != '\0');
    }
    iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10;
    cVar1 = *pcVar10;
    iVar7 = (int16_t)pcVar4;
    while( true ) {
        if ((cVar1 == '\0') || (iVar3 == 0)) goto code_r0x0001801811b1;
        if (*pcVar10 == ':') break;
        pcVar10 = pcVar10 + 1;
        iVar3 = iVar3 + -1;
        cVar1 = *pcVar10;
    }
    if (pcVar10 != (char *)0x0) {
        uVar15 = (iVar7 - (int16_t)pcVar10) - 1;
        *(int16_t *)(arg1 + 0x10) = ((int16_t)pcVar10 - iVar11) + 1;
        *(uint16_t *)(arg1 + 0x12) = uVar15;
        if (uVar15 != 0) {
            iVar8 = *(int16_t *)(arg1 + 0x20);
            uVar14 = 1;
            do {
                uVar13 = (int16_t)uVar14 + 1;
                iVar8 = (int16_t)pcVar10[uVar14] + iVar8 * 10 + -0x30;
                *(int16_t *)(arg1 + 0x20) = iVar8;
                uVar14 = (uint64_t)uVar13;
            } while (uVar13 <= uVar15);
        }
        goto code_r0x0001801811e0;
    }
code_r0x0001801811b1:
    *(undefined2 *)(arg1 + 0x20) = 0x50;
    pcVar10 = pcVar4;
    if ((*(int16_t *)(arg1 + 2) != 0) && (iVar2 = func_0x000180498f90(arg2, 0x180623770, 8), iVar2 == 0)) {
        *(undefined2 *)(arg1 + 0x20) = 0x1bb;
    }
code_r0x0001801811e0:
    if (*(int16_t *)(arg1 + 0xe) == 0) {
        *(int16_t *)(arg1 + 0xc) = (int16_t)pcVar9 - iVar11;
        *(int16_t *)(arg1 + 0xe) = (int16_t)pcVar10 - (int16_t)pcVar9;
    }
    if (pcVar4 != pcVar12) {
        pcVar10 = (char *)func_0x00018045b928(pcVar4, 0x3f);
        if (pcVar10 == (char *)0x0) {
            pcVar10 = pcVar12;
        }
        *(int16_t *)(arg1 + 0x14) = iVar7 - iVar11;
        *(int16_t *)(arg1 + 0x16) = (int16_t)pcVar10 - iVar7;
        if (pcVar10 != pcVar12) {
            pcVar4 = (char *)func_0x00018045b928(pcVar10 + 1, 0x23);
            iVar7 = (int16_t)(pcVar10 + 1);
            if (pcVar4 == (char *)0x0) {
                pcVar4 = pcVar12;
            }
            *(int16_t *)(arg1 + 0x18) = iVar7 - iVar11;
            *(int16_t *)(arg1 + 0x1a) = (int16_t)pcVar4 - iVar7;
            if (pcVar4 != pcVar12) {
                iVar7 = (int16_t)pcVar4 + 1;
                *(int16_t *)(arg1 + 0x1c) = iVar7 - iVar11;
                *(int16_t *)(arg1 + 0x1e) = (int16_t)pcVar12 - iVar7;
            }
        }
    }
    return 0;
code_r0x000180181118:
    pcVar6 = pcVar9;
    if (iVar3 == 0) goto code_r0x000180181134;
    if (*pcVar5 == ':') {
        if (pcVar5 != (char *)0x0) {
            *(int16_t *)(arg1 + 8) = ((int16_t)pcVar5 - iVar11) + 1;
            *(int16_t *)(arg1 + 10) = ((int16_t)pcVar9 - (int16_t)pcVar5) + -1;
            pcVar6 = pcVar5;
        }
        goto code_r0x000180181134;
    }
    pcVar5 = pcVar5 + 1;
    iVar3 = iVar3 + -1;
    if (*pcVar5 == '\0') goto code_r0x000180181134;
    goto code_r0x000180181118;
code_r0x000180181134:
    *(int16_t *)(arg1 + 4) = (int16_t)pcVar10 - iVar11;
    *(int16_t *)(arg1 + 6) = (int16_t)pcVar6 - (int16_t)pcVar10;
    pcVar10 = pcVar9 + 1;
    goto code_r0x0001801810de;
}

// ============================================================
// Function: FUN_180181022
// Address: 0x180181022
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.180181000(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    char *pcVar4;
    char *pcVar5;
    char *pcVar6;
    int16_t iVar7;
    int16_t iVar8;
    char *pcVar9;
    char *pcVar10;
    int16_t iVar11;
    char *pcVar12;
    uint16_t uVar13;
    uint64_t uVar14;
    uint16_t uVar15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    if ((arg1 == 0) || (arg2 == 0)) {
        return 0xffffffff;
    }
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x10) = ZEXT816(0);
    *(undefined2 *)(arg1 + 0x20) = 0;
    cVar1 = *(char *)arg2;
    pcVar12 = (char *)arg2;
    while (cVar1 != '\0') {
        pcVar12 = pcVar12 + 1;
        cVar1 = *pcVar12;
    }
    if (0xffff < (int64_t)pcVar12 - arg2) {
        return 0xfffffffe;
    }
    iVar3 = func_0x00018045bb90(arg2, 0x1804a63dc);
    iVar11 = (int16_t)arg2;
    pcVar10 = (char *)arg2;
    if (iVar3 != 0) {
        pcVar10 = (char *)(iVar3 + 3);
        *(int16_t *)(arg1 + 2) = (int16_t)iVar3 - iVar11;
    }
    pcVar4 = (char *)func_0x00018045b928(pcVar10, 0x2f);
    if (pcVar4 == (char *)0x0) {
        pcVar4 = pcVar12;
    }
    cVar1 = *pcVar10;
    pcVar9 = pcVar10;
    for (iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10; (cVar1 != '\0' && (iVar3 != 0)); iVar3 = iVar3 + -1) {
        if (*pcVar9 == '@') {
            iVar3 = (int64_t)pcVar9 - (int64_t)pcVar10;
            pcVar5 = pcVar10;
            goto code_r0x000180181118;
        }
        pcVar9 = pcVar9 + 1;
        cVar1 = *pcVar9;
    }
code_r0x0001801810de:
    pcVar9 = pcVar10;
    if (*pcVar10 == '[') {
        iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10;
        pcVar5 = pcVar10;
        do {
            if (iVar3 == 0) break;
            if (*pcVar5 == ']') {
                pcVar9 = pcVar10 + 1;
                iVar7 = (int16_t)pcVar9;
                *(int16_t *)(arg1 + 0xc) = iVar7 - iVar11;
                *(int16_t *)(arg1 + 0xe) = (int16_t)pcVar5 - iVar7;
                pcVar10 = pcVar5;
                break;
            }
            pcVar5 = pcVar5 + 1;
            iVar3 = iVar3 + -1;
        } while (*pcVar5 != '\0');
    }
    iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10;
    cVar1 = *pcVar10;
    iVar7 = (int16_t)pcVar4;
    while( true ) {
        if ((cVar1 == '\0') || (iVar3 == 0)) goto code_r0x0001801811b1;
        if (*pcVar10 == ':') break;
        pcVar10 = pcVar10 + 1;
        iVar3 = iVar3 + -1;
        cVar1 = *pcVar10;
    }
    if (pcVar10 != (char *)0x0) {
        uVar15 = (iVar7 - (int16_t)pcVar10) - 1;
        *(int16_t *)(arg1 + 0x10) = ((int16_t)pcVar10 - iVar11) + 1;
        *(uint16_t *)(arg1 + 0x12) = uVar15;
        if (uVar15 != 0) {
            iVar8 = *(int16_t *)(arg1 + 0x20);
            uVar14 = 1;
            do {
                uVar13 = (int16_t)uVar14 + 1;
                iVar8 = (int16_t)pcVar10[uVar14] + iVar8 * 10 + -0x30;
                *(int16_t *)(arg1 + 0x20) = iVar8;
                uVar14 = (uint64_t)uVar13;
            } while (uVar13 <= uVar15);
        }
        goto code_r0x0001801811e0;
    }
code_r0x0001801811b1:
    *(undefined2 *)(arg1 + 0x20) = 0x50;
    pcVar10 = pcVar4;
    if ((*(int16_t *)(arg1 + 2) != 0) && (iVar2 = func_0x000180498f90(arg2, 0x180623770, 8), iVar2 == 0)) {
        *(undefined2 *)(arg1 + 0x20) = 0x1bb;
    }
code_r0x0001801811e0:
    if (*(int16_t *)(arg1 + 0xe) == 0) {
        *(int16_t *)(arg1 + 0xc) = (int16_t)pcVar9 - iVar11;
        *(int16_t *)(arg1 + 0xe) = (int16_t)pcVar10 - (int16_t)pcVar9;
    }
    if (pcVar4 != pcVar12) {
        pcVar10 = (char *)func_0x00018045b928(pcVar4, 0x3f);
        if (pcVar10 == (char *)0x0) {
            pcVar10 = pcVar12;
        }
        *(int16_t *)(arg1 + 0x14) = iVar7 - iVar11;
        *(int16_t *)(arg1 + 0x16) = (int16_t)pcVar10 - iVar7;
        if (pcVar10 != pcVar12) {
            pcVar4 = (char *)func_0x00018045b928(pcVar10 + 1, 0x23);
            iVar7 = (int16_t)(pcVar10 + 1);
            if (pcVar4 == (char *)0x0) {
                pcVar4 = pcVar12;
            }
            *(int16_t *)(arg1 + 0x18) = iVar7 - iVar11;
            *(int16_t *)(arg1 + 0x1a) = (int16_t)pcVar4 - iVar7;
            if (pcVar4 != pcVar12) {
                iVar7 = (int16_t)pcVar4 + 1;
                *(int16_t *)(arg1 + 0x1c) = iVar7 - iVar11;
                *(int16_t *)(arg1 + 0x1e) = (int16_t)pcVar12 - iVar7;
            }
        }
    }
    return 0;
code_r0x000180181118:
    pcVar6 = pcVar9;
    if (iVar3 == 0) goto code_r0x000180181134;
    if (*pcVar5 == ':') {
        if (pcVar5 != (char *)0x0) {
            *(int16_t *)(arg1 + 8) = ((int16_t)pcVar5 - iVar11) + 1;
            *(int16_t *)(arg1 + 10) = ((int16_t)pcVar9 - (int16_t)pcVar5) + -1;
            pcVar6 = pcVar5;
        }
        goto code_r0x000180181134;
    }
    pcVar5 = pcVar5 + 1;
    iVar3 = iVar3 + -1;
    if (*pcVar5 == '\0') goto code_r0x000180181134;
    goto code_r0x000180181118;
code_r0x000180181134:
    *(int16_t *)(arg1 + 4) = (int16_t)pcVar10 - iVar11;
    *(int16_t *)(arg1 + 6) = (int16_t)pcVar6 - (int16_t)pcVar10;
    pcVar10 = pcVar9 + 1;
    goto code_r0x0001801810de;
}

// ============================================================
// Function: FUN_180181066
// Address: 0x180181066
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.180181000(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    char *pcVar4;
    char *pcVar5;
    char *pcVar6;
    int16_t iVar7;
    int16_t iVar8;
    char *pcVar9;
    char *pcVar10;
    int16_t iVar11;
    char *pcVar12;
    uint16_t uVar13;
    uint64_t uVar14;
    uint16_t uVar15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    if ((arg1 == 0) || (arg2 == 0)) {
        return 0xffffffff;
    }
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x10) = ZEXT816(0);
    *(undefined2 *)(arg1 + 0x20) = 0;
    cVar1 = *(char *)arg2;
    pcVar12 = (char *)arg2;
    while (cVar1 != '\0') {
        pcVar12 = pcVar12 + 1;
        cVar1 = *pcVar12;
    }
    if (0xffff < (int64_t)pcVar12 - arg2) {
        return 0xfffffffe;
    }
    iVar3 = func_0x00018045bb90(arg2, 0x1804a63dc);
    iVar11 = (int16_t)arg2;
    pcVar10 = (char *)arg2;
    if (iVar3 != 0) {
        pcVar10 = (char *)(iVar3 + 3);
        *(int16_t *)(arg1 + 2) = (int16_t)iVar3 - iVar11;
    }
    pcVar4 = (char *)func_0x00018045b928(pcVar10, 0x2f);
    if (pcVar4 == (char *)0x0) {
        pcVar4 = pcVar12;
    }
    cVar1 = *pcVar10;
    pcVar9 = pcVar10;
    for (iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10; (cVar1 != '\0' && (iVar3 != 0)); iVar3 = iVar3 + -1) {
        if (*pcVar9 == '@') {
            iVar3 = (int64_t)pcVar9 - (int64_t)pcVar10;
            pcVar5 = pcVar10;
            goto code_r0x000180181118;
        }
        pcVar9 = pcVar9 + 1;
        cVar1 = *pcVar9;
    }
code_r0x0001801810de:
    pcVar9 = pcVar10;
    if (*pcVar10 == '[') {
        iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10;
        pcVar5 = pcVar10;
        do {
            if (iVar3 == 0) break;
            if (*pcVar5 == ']') {
                pcVar9 = pcVar10 + 1;
                iVar7 = (int16_t)pcVar9;
                *(int16_t *)(arg1 + 0xc) = iVar7 - iVar11;
                *(int16_t *)(arg1 + 0xe) = (int16_t)pcVar5 - iVar7;
                pcVar10 = pcVar5;
                break;
            }
            pcVar5 = pcVar5 + 1;
            iVar3 = iVar3 + -1;
        } while (*pcVar5 != '\0');
    }
    iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10;
    cVar1 = *pcVar10;
    iVar7 = (int16_t)pcVar4;
    while( true ) {
        if ((cVar1 == '\0') || (iVar3 == 0)) goto code_r0x0001801811b1;
        if (*pcVar10 == ':') break;
        pcVar10 = pcVar10 + 1;
        iVar3 = iVar3 + -1;
        cVar1 = *pcVar10;
    }
    if (pcVar10 != (char *)0x0) {
        uVar15 = (iVar7 - (int16_t)pcVar10) - 1;
        *(int16_t *)(arg1 + 0x10) = ((int16_t)pcVar10 - iVar11) + 1;
        *(uint16_t *)(arg1 + 0x12) = uVar15;
        if (uVar15 != 0) {
            iVar8 = *(int16_t *)(arg1 + 0x20);
            uVar14 = 1;
            do {
                uVar13 = (int16_t)uVar14 + 1;
                iVar8 = (int16_t)pcVar10[uVar14] + iVar8 * 10 + -0x30;
                *(int16_t *)(arg1 + 0x20) = iVar8;
                uVar14 = (uint64_t)uVar13;
            } while (uVar13 <= uVar15);
        }
        goto code_r0x0001801811e0;
    }
code_r0x0001801811b1:
    *(undefined2 *)(arg1 + 0x20) = 0x50;
    pcVar10 = pcVar4;
    if ((*(int16_t *)(arg1 + 2) != 0) && (iVar2 = func_0x000180498f90(arg2, 0x180623770, 8), iVar2 == 0)) {
        *(undefined2 *)(arg1 + 0x20) = 0x1bb;
    }
code_r0x0001801811e0:
    if (*(int16_t *)(arg1 + 0xe) == 0) {
        *(int16_t *)(arg1 + 0xc) = (int16_t)pcVar9 - iVar11;
        *(int16_t *)(arg1 + 0xe) = (int16_t)pcVar10 - (int16_t)pcVar9;
    }
    if (pcVar4 != pcVar12) {
        pcVar10 = (char *)func_0x00018045b928(pcVar4, 0x3f);
        if (pcVar10 == (char *)0x0) {
            pcVar10 = pcVar12;
        }
        *(int16_t *)(arg1 + 0x14) = iVar7 - iVar11;
        *(int16_t *)(arg1 + 0x16) = (int16_t)pcVar10 - iVar7;
        if (pcVar10 != pcVar12) {
            pcVar4 = (char *)func_0x00018045b928(pcVar10 + 1, 0x23);
            iVar7 = (int16_t)(pcVar10 + 1);
            if (pcVar4 == (char *)0x0) {
                pcVar4 = pcVar12;
            }
            *(int16_t *)(arg1 + 0x18) = iVar7 - iVar11;
            *(int16_t *)(arg1 + 0x1a) = (int16_t)pcVar4 - iVar7;
            if (pcVar4 != pcVar12) {
                iVar7 = (int16_t)pcVar4 + 1;
                *(int16_t *)(arg1 + 0x1c) = iVar7 - iVar11;
                *(int16_t *)(arg1 + 0x1e) = (int16_t)pcVar12 - iVar7;
            }
        }
    }
    return 0;
code_r0x000180181118:
    pcVar6 = pcVar9;
    if (iVar3 == 0) goto code_r0x000180181134;
    if (*pcVar5 == ':') {
        if (pcVar5 != (char *)0x0) {
            *(int16_t *)(arg1 + 8) = ((int16_t)pcVar5 - iVar11) + 1;
            *(int16_t *)(arg1 + 10) = ((int16_t)pcVar9 - (int16_t)pcVar5) + -1;
            pcVar6 = pcVar5;
        }
        goto code_r0x000180181134;
    }
    pcVar5 = pcVar5 + 1;
    iVar3 = iVar3 + -1;
    if (*pcVar5 == '\0') goto code_r0x000180181134;
    goto code_r0x000180181118;
code_r0x000180181134:
    *(int16_t *)(arg1 + 4) = (int16_t)pcVar10 - iVar11;
    *(int16_t *)(arg1 + 6) = (int16_t)pcVar6 - (int16_t)pcVar10;
    pcVar10 = pcVar9 + 1;
    goto code_r0x0001801810de;
}

// ============================================================
// Function: FUN_18018107a
// Address: 0x18018107a
// Size: 395 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.180181000(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    char *pcVar4;
    char *pcVar5;
    char *pcVar6;
    int16_t iVar7;
    int16_t iVar8;
    char *pcVar9;
    char *pcVar10;
    int16_t iVar11;
    char *pcVar12;
    uint16_t uVar13;
    uint64_t uVar14;
    uint16_t uVar15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    if ((arg1 == 0) || (arg2 == 0)) {
        return 0xffffffff;
    }
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x10) = ZEXT816(0);
    *(undefined2 *)(arg1 + 0x20) = 0;
    cVar1 = *(char *)arg2;
    pcVar12 = (char *)arg2;
    while (cVar1 != '\0') {
        pcVar12 = pcVar12 + 1;
        cVar1 = *pcVar12;
    }
    if (0xffff < (int64_t)pcVar12 - arg2) {
        return 0xfffffffe;
    }
    iVar3 = func_0x00018045bb90(arg2, 0x1804a63dc);
    iVar11 = (int16_t)arg2;
    pcVar10 = (char *)arg2;
    if (iVar3 != 0) {
        pcVar10 = (char *)(iVar3 + 3);
        *(int16_t *)(arg1 + 2) = (int16_t)iVar3 - iVar11;
    }
    pcVar4 = (char *)func_0x00018045b928(pcVar10, 0x2f);
    if (pcVar4 == (char *)0x0) {
        pcVar4 = pcVar12;
    }
    cVar1 = *pcVar10;
    pcVar9 = pcVar10;
    for (iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10; (cVar1 != '\0' && (iVar3 != 0)); iVar3 = iVar3 + -1) {
        if (*pcVar9 == '@') {
            iVar3 = (int64_t)pcVar9 - (int64_t)pcVar10;
            pcVar5 = pcVar10;
            goto code_r0x000180181118;
        }
        pcVar9 = pcVar9 + 1;
        cVar1 = *pcVar9;
    }
code_r0x0001801810de:
    pcVar9 = pcVar10;
    if (*pcVar10 == '[') {
        iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10;
        pcVar5 = pcVar10;
        do {
            if (iVar3 == 0) break;
            if (*pcVar5 == ']') {
                pcVar9 = pcVar10 + 1;
                iVar7 = (int16_t)pcVar9;
                *(int16_t *)(arg1 + 0xc) = iVar7 - iVar11;
                *(int16_t *)(arg1 + 0xe) = (int16_t)pcVar5 - iVar7;
                pcVar10 = pcVar5;
                break;
            }
            pcVar5 = pcVar5 + 1;
            iVar3 = iVar3 + -1;
        } while (*pcVar5 != '\0');
    }
    iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10;
    cVar1 = *pcVar10;
    iVar7 = (int16_t)pcVar4;
    while( true ) {
        if ((cVar1 == '\0') || (iVar3 == 0)) goto code_r0x0001801811b1;
        if (*pcVar10 == ':') break;
        pcVar10 = pcVar10 + 1;
        iVar3 = iVar3 + -1;
        cVar1 = *pcVar10;
    }
    if (pcVar10 != (char *)0x0) {
        uVar15 = (iVar7 - (int16_t)pcVar10) - 1;
        *(int16_t *)(arg1 + 0x10) = ((int16_t)pcVar10 - iVar11) + 1;
        *(uint16_t *)(arg1 + 0x12) = uVar15;
        if (uVar15 != 0) {
            iVar8 = *(int16_t *)(arg1 + 0x20);
            uVar14 = 1;
            do {
                uVar13 = (int16_t)uVar14 + 1;
                iVar8 = (int16_t)pcVar10[uVar14] + iVar8 * 10 + -0x30;
                *(int16_t *)(arg1 + 0x20) = iVar8;
                uVar14 = (uint64_t)uVar13;
            } while (uVar13 <= uVar15);
        }
        goto code_r0x0001801811e0;
    }
code_r0x0001801811b1:
    *(undefined2 *)(arg1 + 0x20) = 0x50;
    pcVar10 = pcVar4;
    if ((*(int16_t *)(arg1 + 2) != 0) && (iVar2 = func_0x000180498f90(arg2, 0x180623770, 8), iVar2 == 0)) {
        *(undefined2 *)(arg1 + 0x20) = 0x1bb;
    }
code_r0x0001801811e0:
    if (*(int16_t *)(arg1 + 0xe) == 0) {
        *(int16_t *)(arg1 + 0xc) = (int16_t)pcVar9 - iVar11;
        *(int16_t *)(arg1 + 0xe) = (int16_t)pcVar10 - (int16_t)pcVar9;
    }
    if (pcVar4 != pcVar12) {
        pcVar10 = (char *)func_0x00018045b928(pcVar4, 0x3f);
        if (pcVar10 == (char *)0x0) {
            pcVar10 = pcVar12;
        }
        *(int16_t *)(arg1 + 0x14) = iVar7 - iVar11;
        *(int16_t *)(arg1 + 0x16) = (int16_t)pcVar10 - iVar7;
        if (pcVar10 != pcVar12) {
            pcVar4 = (char *)func_0x00018045b928(pcVar10 + 1, 0x23);
            iVar7 = (int16_t)(pcVar10 + 1);
            if (pcVar4 == (char *)0x0) {
                pcVar4 = pcVar12;
            }
            *(int16_t *)(arg1 + 0x18) = iVar7 - iVar11;
            *(int16_t *)(arg1 + 0x1a) = (int16_t)pcVar4 - iVar7;
            if (pcVar4 != pcVar12) {
                iVar7 = (int16_t)pcVar4 + 1;
                *(int16_t *)(arg1 + 0x1c) = iVar7 - iVar11;
                *(int16_t *)(arg1 + 0x1e) = (int16_t)pcVar12 - iVar7;
            }
        }
    }
    return 0;
code_r0x000180181118:
    pcVar6 = pcVar9;
    if (iVar3 == 0) goto code_r0x000180181134;
    if (*pcVar5 == ':') {
        if (pcVar5 != (char *)0x0) {
            *(int16_t *)(arg1 + 8) = ((int16_t)pcVar5 - iVar11) + 1;
            *(int16_t *)(arg1 + 10) = ((int16_t)pcVar9 - (int16_t)pcVar5) + -1;
            pcVar6 = pcVar5;
        }
        goto code_r0x000180181134;
    }
    pcVar5 = pcVar5 + 1;
    iVar3 = iVar3 + -1;
    if (*pcVar5 == '\0') goto code_r0x000180181134;
    goto code_r0x000180181118;
code_r0x000180181134:
    *(int16_t *)(arg1 + 4) = (int16_t)pcVar10 - iVar11;
    *(int16_t *)(arg1 + 6) = (int16_t)pcVar6 - (int16_t)pcVar10;
    pcVar10 = pcVar9 + 1;
    goto code_r0x0001801810de;
}

// ============================================================
// Function: FUN_180181205
// Address: 0x180181205
// Size: 151 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.180181000(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    char *pcVar4;
    char *pcVar5;
    char *pcVar6;
    int16_t iVar7;
    int16_t iVar8;
    char *pcVar9;
    char *pcVar10;
    int16_t iVar11;
    char *pcVar12;
    uint16_t uVar13;
    uint64_t uVar14;
    uint16_t uVar15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    if ((arg1 == 0) || (arg2 == 0)) {
        return 0xffffffff;
    }
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x10) = ZEXT816(0);
    *(undefined2 *)(arg1 + 0x20) = 0;
    cVar1 = *(char *)arg2;
    pcVar12 = (char *)arg2;
    while (cVar1 != '\0') {
        pcVar12 = pcVar12 + 1;
        cVar1 = *pcVar12;
    }
    if (0xffff < (int64_t)pcVar12 - arg2) {
        return 0xfffffffe;
    }
    iVar3 = func_0x00018045bb90(arg2, 0x1804a63dc);
    iVar11 = (int16_t)arg2;
    pcVar10 = (char *)arg2;
    if (iVar3 != 0) {
        pcVar10 = (char *)(iVar3 + 3);
        *(int16_t *)(arg1 + 2) = (int16_t)iVar3 - iVar11;
    }
    pcVar4 = (char *)func_0x00018045b928(pcVar10, 0x2f);
    if (pcVar4 == (char *)0x0) {
        pcVar4 = pcVar12;
    }
    cVar1 = *pcVar10;
    pcVar9 = pcVar10;
    for (iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10; (cVar1 != '\0' && (iVar3 != 0)); iVar3 = iVar3 + -1) {
        if (*pcVar9 == '@') {
            iVar3 = (int64_t)pcVar9 - (int64_t)pcVar10;
            pcVar5 = pcVar10;
            goto code_r0x000180181118;
        }
        pcVar9 = pcVar9 + 1;
        cVar1 = *pcVar9;
    }
code_r0x0001801810de:
    pcVar9 = pcVar10;
    if (*pcVar10 == '[') {
        iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10;
        pcVar5 = pcVar10;
        do {
            if (iVar3 == 0) break;
            if (*pcVar5 == ']') {
                pcVar9 = pcVar10 + 1;
                iVar7 = (int16_t)pcVar9;
                *(int16_t *)(arg1 + 0xc) = iVar7 - iVar11;
                *(int16_t *)(arg1 + 0xe) = (int16_t)pcVar5 - iVar7;
                pcVar10 = pcVar5;
                break;
            }
            pcVar5 = pcVar5 + 1;
            iVar3 = iVar3 + -1;
        } while (*pcVar5 != '\0');
    }
    iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10;
    cVar1 = *pcVar10;
    iVar7 = (int16_t)pcVar4;
    while( true ) {
        if ((cVar1 == '\0') || (iVar3 == 0)) goto code_r0x0001801811b1;
        if (*pcVar10 == ':') break;
        pcVar10 = pcVar10 + 1;
        iVar3 = iVar3 + -1;
        cVar1 = *pcVar10;
    }
    if (pcVar10 != (char *)0x0) {
        uVar15 = (iVar7 - (int16_t)pcVar10) - 1;
        *(int16_t *)(arg1 + 0x10) = ((int16_t)pcVar10 - iVar11) + 1;
        *(uint16_t *)(arg1 + 0x12) = uVar15;
        if (uVar15 != 0) {
            iVar8 = *(int16_t *)(arg1 + 0x20);
            uVar14 = 1;
            do {
                uVar13 = (int16_t)uVar14 + 1;
                iVar8 = (int16_t)pcVar10[uVar14] + iVar8 * 10 + -0x30;
                *(int16_t *)(arg1 + 0x20) = iVar8;
                uVar14 = (uint64_t)uVar13;
            } while (uVar13 <= uVar15);
        }
        goto code_r0x0001801811e0;
    }
code_r0x0001801811b1:
    *(undefined2 *)(arg1 + 0x20) = 0x50;
    pcVar10 = pcVar4;
    if ((*(int16_t *)(arg1 + 2) != 0) && (iVar2 = func_0x000180498f90(arg2, 0x180623770, 8), iVar2 == 0)) {
        *(undefined2 *)(arg1 + 0x20) = 0x1bb;
    }
code_r0x0001801811e0:
    if (*(int16_t *)(arg1 + 0xe) == 0) {
        *(int16_t *)(arg1 + 0xc) = (int16_t)pcVar9 - iVar11;
        *(int16_t *)(arg1 + 0xe) = (int16_t)pcVar10 - (int16_t)pcVar9;
    }
    if (pcVar4 != pcVar12) {
        pcVar10 = (char *)func_0x00018045b928(pcVar4, 0x3f);
        if (pcVar10 == (char *)0x0) {
            pcVar10 = pcVar12;
        }
        *(int16_t *)(arg1 + 0x14) = iVar7 - iVar11;
        *(int16_t *)(arg1 + 0x16) = (int16_t)pcVar10 - iVar7;
        if (pcVar10 != pcVar12) {
            pcVar4 = (char *)func_0x00018045b928(pcVar10 + 1, 0x23);
            iVar7 = (int16_t)(pcVar10 + 1);
            if (pcVar4 == (char *)0x0) {
                pcVar4 = pcVar12;
            }
            *(int16_t *)(arg1 + 0x18) = iVar7 - iVar11;
            *(int16_t *)(arg1 + 0x1a) = (int16_t)pcVar4 - iVar7;
            if (pcVar4 != pcVar12) {
                iVar7 = (int16_t)pcVar4 + 1;
                *(int16_t *)(arg1 + 0x1c) = iVar7 - iVar11;
                *(int16_t *)(arg1 + 0x1e) = (int16_t)pcVar12 - iVar7;
            }
        }
    }
    return 0;
code_r0x000180181118:
    pcVar6 = pcVar9;
    if (iVar3 == 0) goto code_r0x000180181134;
    if (*pcVar5 == ':') {
        if (pcVar5 != (char *)0x0) {
            *(int16_t *)(arg1 + 8) = ((int16_t)pcVar5 - iVar11) + 1;
            *(int16_t *)(arg1 + 10) = ((int16_t)pcVar9 - (int16_t)pcVar5) + -1;
            pcVar6 = pcVar5;
        }
        goto code_r0x000180181134;
    }
    pcVar5 = pcVar5 + 1;
    iVar3 = iVar3 + -1;
    if (*pcVar5 == '\0') goto code_r0x000180181134;
    goto code_r0x000180181118;
code_r0x000180181134:
    *(int16_t *)(arg1 + 4) = (int16_t)pcVar10 - iVar11;
    *(int16_t *)(arg1 + 6) = (int16_t)pcVar6 - (int16_t)pcVar10;
    pcVar10 = pcVar9 + 1;
    goto code_r0x0001801810de;
}

// ============================================================
// Function: FUN_18018129c
// Address: 0x18018129c
// Size: 114 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.180181000(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    char *pcVar4;
    char *pcVar5;
    char *pcVar6;
    int16_t iVar7;
    int16_t iVar8;
    char *pcVar9;
    char *pcVar10;
    int16_t iVar11;
    char *pcVar12;
    uint16_t uVar13;
    uint64_t uVar14;
    uint16_t uVar15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    if ((arg1 == 0) || (arg2 == 0)) {
        return 0xffffffff;
    }
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x10) = ZEXT816(0);
    *(undefined2 *)(arg1 + 0x20) = 0;
    cVar1 = *(char *)arg2;
    pcVar12 = (char *)arg2;
    while (cVar1 != '\0') {
        pcVar12 = pcVar12 + 1;
        cVar1 = *pcVar12;
    }
    if (0xffff < (int64_t)pcVar12 - arg2) {
        return 0xfffffffe;
    }
    iVar3 = func_0x00018045bb90(arg2, 0x1804a63dc);
    iVar11 = (int16_t)arg2;
    pcVar10 = (char *)arg2;
    if (iVar3 != 0) {
        pcVar10 = (char *)(iVar3 + 3);
        *(int16_t *)(arg1 + 2) = (int16_t)iVar3 - iVar11;
    }
    pcVar4 = (char *)func_0x00018045b928(pcVar10, 0x2f);
    if (pcVar4 == (char *)0x0) {
        pcVar4 = pcVar12;
    }
    cVar1 = *pcVar10;
    pcVar9 = pcVar10;
    for (iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10; (cVar1 != '\0' && (iVar3 != 0)); iVar3 = iVar3 + -1) {
        if (*pcVar9 == '@') {
            iVar3 = (int64_t)pcVar9 - (int64_t)pcVar10;
            pcVar5 = pcVar10;
            goto code_r0x000180181118;
        }
        pcVar9 = pcVar9 + 1;
        cVar1 = *pcVar9;
    }
code_r0x0001801810de:
    pcVar9 = pcVar10;
    if (*pcVar10 == '[') {
        iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10;
        pcVar5 = pcVar10;
        do {
            if (iVar3 == 0) break;
            if (*pcVar5 == ']') {
                pcVar9 = pcVar10 + 1;
                iVar7 = (int16_t)pcVar9;
                *(int16_t *)(arg1 + 0xc) = iVar7 - iVar11;
                *(int16_t *)(arg1 + 0xe) = (int16_t)pcVar5 - iVar7;
                pcVar10 = pcVar5;
                break;
            }
            pcVar5 = pcVar5 + 1;
            iVar3 = iVar3 + -1;
        } while (*pcVar5 != '\0');
    }
    iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10;
    cVar1 = *pcVar10;
    iVar7 = (int16_t)pcVar4;
    while( true ) {
        if ((cVar1 == '\0') || (iVar3 == 0)) goto code_r0x0001801811b1;
        if (*pcVar10 == ':') break;
        pcVar10 = pcVar10 + 1;
        iVar3 = iVar3 + -1;
        cVar1 = *pcVar10;
    }
    if (pcVar10 != (char *)0x0) {
        uVar15 = (iVar7 - (int16_t)pcVar10) - 1;
        *(int16_t *)(arg1 + 0x10) = ((int16_t)pcVar10 - iVar11) + 1;
        *(uint16_t *)(arg1 + 0x12) = uVar15;
        if (uVar15 != 0) {
            iVar8 = *(int16_t *)(arg1 + 0x20);
            uVar14 = 1;
            do {
                uVar13 = (int16_t)uVar14 + 1;
                iVar8 = (int16_t)pcVar10[uVar14] + iVar8 * 10 + -0x30;
                *(int16_t *)(arg1 + 0x20) = iVar8;
                uVar14 = (uint64_t)uVar13;
            } while (uVar13 <= uVar15);
        }
        goto code_r0x0001801811e0;
    }
code_r0x0001801811b1:
    *(undefined2 *)(arg1 + 0x20) = 0x50;
    pcVar10 = pcVar4;
    if ((*(int16_t *)(arg1 + 2) != 0) && (iVar2 = func_0x000180498f90(arg2, 0x180623770, 8), iVar2 == 0)) {
        *(undefined2 *)(arg1 + 0x20) = 0x1bb;
    }
code_r0x0001801811e0:
    if (*(int16_t *)(arg1 + 0xe) == 0) {
        *(int16_t *)(arg1 + 0xc) = (int16_t)pcVar9 - iVar11;
        *(int16_t *)(arg1 + 0xe) = (int16_t)pcVar10 - (int16_t)pcVar9;
    }
    if (pcVar4 != pcVar12) {
        pcVar10 = (char *)func_0x00018045b928(pcVar4, 0x3f);
        if (pcVar10 == (char *)0x0) {
            pcVar10 = pcVar12;
        }
        *(int16_t *)(arg1 + 0x14) = iVar7 - iVar11;
        *(int16_t *)(arg1 + 0x16) = (int16_t)pcVar10 - iVar7;
        if (pcVar10 != pcVar12) {
            pcVar4 = (char *)func_0x00018045b928(pcVar10 + 1, 0x23);
            iVar7 = (int16_t)(pcVar10 + 1);
            if (pcVar4 == (char *)0x0) {
                pcVar4 = pcVar12;
            }
            *(int16_t *)(arg1 + 0x18) = iVar7 - iVar11;
            *(int16_t *)(arg1 + 0x1a) = (int16_t)pcVar4 - iVar7;
            if (pcVar4 != pcVar12) {
                iVar7 = (int16_t)pcVar4 + 1;
                *(int16_t *)(arg1 + 0x1c) = iVar7 - iVar11;
                *(int16_t *)(arg1 + 0x1e) = (int16_t)pcVar12 - iVar7;
            }
        }
    }
    return 0;
code_r0x000180181118:
    pcVar6 = pcVar9;
    if (iVar3 == 0) goto code_r0x000180181134;
    if (*pcVar5 == ':') {
        if (pcVar5 != (char *)0x0) {
            *(int16_t *)(arg1 + 8) = ((int16_t)pcVar5 - iVar11) + 1;
            *(int16_t *)(arg1 + 10) = ((int16_t)pcVar9 - (int16_t)pcVar5) + -1;
            pcVar6 = pcVar5;
        }
        goto code_r0x000180181134;
    }
    pcVar5 = pcVar5 + 1;
    iVar3 = iVar3 + -1;
    if (*pcVar5 == '\0') goto code_r0x000180181134;
    goto code_r0x000180181118;
code_r0x000180181134:
    *(int16_t *)(arg1 + 4) = (int16_t)pcVar10 - iVar11;
    *(int16_t *)(arg1 + 6) = (int16_t)pcVar6 - (int16_t)pcVar10;
    pcVar10 = pcVar9 + 1;
    goto code_r0x0001801810de;
}

// ============================================================
// Function: FUN_18018130e
// Address: 0x18018130e
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.180181000(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    char *pcVar4;
    char *pcVar5;
    char *pcVar6;
    int16_t iVar7;
    int16_t iVar8;
    char *pcVar9;
    char *pcVar10;
    int16_t iVar11;
    char *pcVar12;
    uint16_t uVar13;
    uint64_t uVar14;
    uint16_t uVar15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    if ((arg1 == 0) || (arg2 == 0)) {
        return 0xffffffff;
    }
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x10) = ZEXT816(0);
    *(undefined2 *)(arg1 + 0x20) = 0;
    cVar1 = *(char *)arg2;
    pcVar12 = (char *)arg2;
    while (cVar1 != '\0') {
        pcVar12 = pcVar12 + 1;
        cVar1 = *pcVar12;
    }
    if (0xffff < (int64_t)pcVar12 - arg2) {
        return 0xfffffffe;
    }
    iVar3 = func_0x00018045bb90(arg2, 0x1804a63dc);
    iVar11 = (int16_t)arg2;
    pcVar10 = (char *)arg2;
    if (iVar3 != 0) {
        pcVar10 = (char *)(iVar3 + 3);
        *(int16_t *)(arg1 + 2) = (int16_t)iVar3 - iVar11;
    }
    pcVar4 = (char *)func_0x00018045b928(pcVar10, 0x2f);
    if (pcVar4 == (char *)0x0) {
        pcVar4 = pcVar12;
    }
    cVar1 = *pcVar10;
    pcVar9 = pcVar10;
    for (iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10; (cVar1 != '\0' && (iVar3 != 0)); iVar3 = iVar3 + -1) {
        if (*pcVar9 == '@') {
            iVar3 = (int64_t)pcVar9 - (int64_t)pcVar10;
            pcVar5 = pcVar10;
            goto code_r0x000180181118;
        }
        pcVar9 = pcVar9 + 1;
        cVar1 = *pcVar9;
    }
code_r0x0001801810de:
    pcVar9 = pcVar10;
    if (*pcVar10 == '[') {
        iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10;
        pcVar5 = pcVar10;
        do {
            if (iVar3 == 0) break;
            if (*pcVar5 == ']') {
                pcVar9 = pcVar10 + 1;
                iVar7 = (int16_t)pcVar9;
                *(int16_t *)(arg1 + 0xc) = iVar7 - iVar11;
                *(int16_t *)(arg1 + 0xe) = (int16_t)pcVar5 - iVar7;
                pcVar10 = pcVar5;
                break;
            }
            pcVar5 = pcVar5 + 1;
            iVar3 = iVar3 + -1;
        } while (*pcVar5 != '\0');
    }
    iVar3 = (int64_t)pcVar4 - (int64_t)pcVar10;
    cVar1 = *pcVar10;
    iVar7 = (int16_t)pcVar4;
    while( true ) {
        if ((cVar1 == '\0') || (iVar3 == 0)) goto code_r0x0001801811b1;
        if (*pcVar10 == ':') break;
        pcVar10 = pcVar10 + 1;
        iVar3 = iVar3 + -1;
        cVar1 = *pcVar10;
    }
    if (pcVar10 != (char *)0x0) {
        uVar15 = (iVar7 - (int16_t)pcVar10) - 1;
        *(int16_t *)(arg1 + 0x10) = ((int16_t)pcVar10 - iVar11) + 1;
        *(uint16_t *)(arg1 + 0x12) = uVar15;
        if (uVar15 != 0) {
            iVar8 = *(int16_t *)(arg1 + 0x20);
            uVar14 = 1;
            do {
                uVar13 = (int16_t)uVar14 + 1;
                iVar8 = (int16_t)pcVar10[uVar14] + iVar8 * 10 + -0x30;
                *(int16_t *)(arg1 + 0x20) = iVar8;
                uVar14 = (uint64_t)uVar13;
            } while (uVar13 <= uVar15);
        }
        goto code_r0x0001801811e0;
    }
code_r0x0001801811b1:
    *(undefined2 *)(arg1 + 0x20) = 0x50;
    pcVar10 = pcVar4;
    if ((*(int16_t *)(arg1 + 2) != 0) && (iVar2 = func_0x000180498f90(arg2, 0x180623770, 8), iVar2 == 0)) {
        *(undefined2 *)(arg1 + 0x20) = 0x1bb;
    }
code_r0x0001801811e0:
    if (*(int16_t *)(arg1 + 0xe) == 0) {
        *(int16_t *)(arg1 + 0xc) = (int16_t)pcVar9 - iVar11;
        *(int16_t *)(arg1 + 0xe) = (int16_t)pcVar10 - (int16_t)pcVar9;
    }
    if (pcVar4 != pcVar12) {
        pcVar10 = (char *)func_0x00018045b928(pcVar4, 0x3f);
        if (pcVar10 == (char *)0x0) {
            pcVar10 = pcVar12;
        }
        *(int16_t *)(arg1 + 0x14) = iVar7 - iVar11;
        *(int16_t *)(arg1 + 0x16) = (int16_t)pcVar10 - iVar7;
        if (pcVar10 != pcVar12) {
            pcVar4 = (char *)func_0x00018045b928(pcVar10 + 1, 0x23);
            iVar7 = (int16_t)(pcVar10 + 1);
            if (pcVar4 == (char *)0x0) {
                pcVar4 = pcVar12;
            }
            *(int16_t *)(arg1 + 0x18) = iVar7 - iVar11;
            *(int16_t *)(arg1 + 0x1a) = (int16_t)pcVar4 - iVar7;
            if (pcVar4 != pcVar12) {
                iVar7 = (int16_t)pcVar4 + 1;
                *(int16_t *)(arg1 + 0x1c) = iVar7 - iVar11;
                *(int16_t *)(arg1 + 0x1e) = (int16_t)pcVar12 - iVar7;
            }
        }
    }
    return 0;
code_r0x000180181118:
    pcVar6 = pcVar9;
    if (iVar3 == 0) goto code_r0x000180181134;
    if (*pcVar5 == ':') {
        if (pcVar5 != (char *)0x0) {
            *(int16_t *)(arg1 + 8) = ((int16_t)pcVar5 - iVar11) + 1;
            *(int16_t *)(arg1 + 10) = ((int16_t)pcVar9 - (int16_t)pcVar5) + -1;
            pcVar6 = pcVar5;
        }
        goto code_r0x000180181134;
    }
    pcVar5 = pcVar5 + 1;
    iVar3 = iVar3 + -1;
    if (*pcVar5 == '\0') goto code_r0x000180181134;
    goto code_r0x000180181118;
code_r0x000180181134:
    *(int16_t *)(arg1 + 4) = (int16_t)pcVar10 - iVar11;
    *(int16_t *)(arg1 + 6) = (int16_t)pcVar6 - (int16_t)pcVar10;
    pcVar10 = pcVar9 + 1;
    goto code_r0x0001801810de;
}

// ============================================================
// Function: FUN_180181320
// Address: 0x180181320
// Size: 130 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h

int64_t fcn.180181320(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    LOCK();
    *(int32_t *)0x18077e0f0 = *(int32_t *)0x18077e0f0 + 1;
    UNLOCK();
    if (arg1 != 0) {
        LOCK();
        *(int32_t *)0x18077e0f4 = *(int32_t *)0x18077e0f4 + 1;
        UNLOCK();
    }
    iVar2 = func_0x00018046d060();
    if (iVar2 != 0) {
        if ((uint64_t)arg3 < (uint64_t)arg2) {
            fcn.1804986e0(iVar2 + arg3, 0, arg2 - arg3);
        }
        return iVar2;
    }
    uVar3 = fcn.1804605f8(2);
    fcn.180094530(uVar3, 0x1804a7408);
    fcn.18046df7c(0xffffffff);
    pcVar1 = (code *)swi(3);
    iVar2 = (*pcVar1)();
    return iVar2;
}

// ============================================================
// Function: FUN_1801813b0
// Address: 0x1801813b0
// Size: 96 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h

int64_t fcn.1801813b0(int64_t arg1)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t var_8h;
    
    LOCK();
    *(int32_t *)0x18077e0f0 = *(int32_t *)0x18077e0f0 + 1;
    UNLOCK();
    iVar2 = fcn.18046d050();
    if (iVar2 != 0) {
        fcn.1804986e0(iVar2, 0, arg1);
        return iVar2;
    }
    uVar3 = fcn.1804605f8(2);
    fcn.180094530(uVar3, 0x1804a73f8);
    fcn.18046df7c(0xffffffff);
    pcVar1 = (code *)swi(3);
    iVar2 = (*pcVar1)();
    return iVar2;
}

// ============================================================
// Function: FUN_180181410
// Address: 0x180181410
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180181410(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar3 = (uint32_t)arg2;
    uVar4 = (uint64_t)(int32_t)uVar3;
    if (*(uint64_t *)(arg1 + 0x128) <= uVar4) {
        iVar5 = 1;
        if (1 < uVar3) {
            uVar6 = uVar3 - 1;
            iVar1 = 1;
            while (uVar6 = uVar6 >> 1, uVar6 != 0) {
                iVar1 = iVar1 + 1;
            }
            for (; iVar1 != 0; iVar1 = iVar1 + -1) {
                iVar5 = iVar5 * 2;
            }
        }
        iVar1 = 0x400;
        if (0x400 < iVar5) {
            iVar1 = iVar5;
        }
        if (iVar1 <= (int32_t)uVar3) {
            iVar1 = uVar3 * 2;
        }
        if (iVar1 == 0) {
            iVar1 = 0x10;
        }
        iVar2 = fcn.180181320(*(int64_t *)(arg1 + 0x118), (int64_t)iVar1 * 8, *(int64_t *)(arg1 + 0x128) << 3);
        *(int64_t *)(arg1 + 0x128) = (int64_t)iVar1;
        *(int64_t *)(arg1 + 0x118) = iVar2;
        return *(undefined8 *)(iVar2 + uVar4 * 8);
    }
    return *(undefined8 *)(*(int64_t *)(arg1 + 0x118) + uVar4 * 8);
}

// ============================================================
// Function: FUN_18018142d
// Address: 0x18018142d
// Size: 156 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180181410(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar3 = (uint32_t)arg2;
    uVar4 = (uint64_t)(int32_t)uVar3;
    if (*(uint64_t *)(arg1 + 0x128) <= uVar4) {
        iVar5 = 1;
        if (1 < uVar3) {
            uVar6 = uVar3 - 1;
            iVar1 = 1;
            while (uVar6 = uVar6 >> 1, uVar6 != 0) {
                iVar1 = iVar1 + 1;
            }
            for (; iVar1 != 0; iVar1 = iVar1 + -1) {
                iVar5 = iVar5 * 2;
            }
        }
        iVar1 = 0x400;
        if (0x400 < iVar5) {
            iVar1 = iVar5;
        }
        if (iVar1 <= (int32_t)uVar3) {
            iVar1 = uVar3 * 2;
        }
        if (iVar1 == 0) {
            iVar1 = 0x10;
        }
        iVar2 = fcn.180181320(*(int64_t *)(arg1 + 0x118), (int64_t)iVar1 * 8, *(int64_t *)(arg1 + 0x128) << 3);
        *(int64_t *)(arg1 + 0x128) = (int64_t)iVar1;
        *(int64_t *)(arg1 + 0x118) = iVar2;
        return *(undefined8 *)(iVar2 + uVar4 * 8);
    }
    return *(undefined8 *)(*(int64_t *)(arg1 + 0x118) + uVar4 * 8);
}

// ============================================================
// Function: FUN_1801814c9
// Address: 0x1801814c9
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180181410(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar3 = (uint32_t)arg2;
    uVar4 = (uint64_t)(int32_t)uVar3;
    if (*(uint64_t *)(arg1 + 0x128) <= uVar4) {
        iVar5 = 1;
        if (1 < uVar3) {
            uVar6 = uVar3 - 1;
            iVar1 = 1;
            while (uVar6 = uVar6 >> 1, uVar6 != 0) {
                iVar1 = iVar1 + 1;
            }
            for (; iVar1 != 0; iVar1 = iVar1 + -1) {
                iVar5 = iVar5 * 2;
            }
        }
        iVar1 = 0x400;
        if (0x400 < iVar5) {
            iVar1 = iVar5;
        }
        if (iVar1 <= (int32_t)uVar3) {
            iVar1 = uVar3 * 2;
        }
        if (iVar1 == 0) {
            iVar1 = 0x10;
        }
        iVar2 = fcn.180181320(*(int64_t *)(arg1 + 0x118), (int64_t)iVar1 * 8, *(int64_t *)(arg1 + 0x128) << 3);
        *(int64_t *)(arg1 + 0x128) = (int64_t)iVar1;
        *(int64_t *)(arg1 + 0x118) = iVar2;
        return *(undefined8 *)(iVar2 + uVar4 * 8);
    }
    return *(undefined8 *)(*(int64_t *)(arg1 + 0x118) + uVar4 * 8);
}

// ============================================================
// Function: FUN_1801814e0
// Address: 0x1801814e0
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.1801814e0(int64_t arg1, int64_t arg2, int64_t arg_68h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    uint32_t uVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    uint32_t uVar13;
    int32_t iVar14;
    int64_t var_8h;
    int64_t var_38h;
    
    ppiVar11 = *(int64_t ***)arg1;
    iVar14 = 0;
    if (ppiVar11 == (int64_t **)0x0) {
        return 0;
    }
    do {
        ppiVar1 = ppiVar11 + -10;
        if ((uint64_t)arg2 < ppiVar11[-1]) {
            return iVar14;
        }
        if ((*(int32_t *)(ppiVar11 + -2) == -1) ||
           (iVar5 = *(int32_t *)(ppiVar11 + -2) + -1, *(int32_t *)(ppiVar11 + -2) = iVar5, iVar5 != 0)) {
            func_0x0001801819b0(arg1);
            if (*(int32_t *)(ppiVar11 + -9) == 0x10) {
                piVar7 = ppiVar11[-1];
                if (piVar7 <= (uint64_t)arg2) {
                    do {
                        piVar7 = piVar7 + (uint64_t)*(uint32_t *)(ppiVar11 + 3) * 0x7d;
                    } while (piVar7 <= (uint64_t)arg2);
code_r0x0001801815d5:
                    ppiVar11[-1] = piVar7;
                }
            } else if (*(int32_t *)(ppiVar11 + -9) == 0x20) {
                iVar6 = func_0x0001801890b0((int32_t)*(char *)(ppiVar11 + 3), 
                                            (int32_t)*(char *)((int64_t)ppiVar11 + 0x19), 
                                            (int32_t)*(char *)((int64_t)ppiVar11 + 0x1a), 
                                            (int32_t)*(char *)((int64_t)ppiVar11 + 0x1b), 
                                            (int32_t)*(char *)((int64_t)ppiVar11 + 0x1c));
                piVar7 = (int64_t *)(iVar6 * 1000000);
                goto code_r0x0001801815d5;
            }
            *(int32_t *)(arg1 + 8) = *(int32_t *)(arg1 + 8) + 1;
            uVar9 = 0;
            iVar5 = 0;
            for (uVar13 = *(uint32_t *)(arg1 + 8); 1 < (int32_t)uVar13; uVar13 = (int32_t)uVar13 >> 1) {
                iVar5 = iVar5 + 1;
                uVar9 = uVar13 & 1 | uVar9 * 2;
            }
            piVar7 = *(int64_t **)arg1;
            for (; 1 < iVar5; iVar5 = iVar5 + -1) {
                uVar13 = uVar9 & 1;
                uVar9 = (int32_t)uVar9 >> 1;
                piVar7 = (int64_t *)piVar7[(uint64_t)uVar13 + 1];
            }
            *ppiVar11 = piVar7;
            if (piVar7 == (int64_t *)0x0) {
                *(int64_t ***)arg1 = ppiVar11;
            } else if ((uVar9 & 1) == 0) {
                piVar7[1] = (int64_t)ppiVar11;
            } else {
                piVar7[2] = (int64_t)ppiVar11;
            }
            if (*(int64_t *)(arg1 + 0x10) != 0) {
                piVar7 = *ppiVar11;
                while ((piVar7 != (int64_t *)0x0 && (iVar5 = (**(code **)(arg1 + 0x10))(ppiVar11, piVar7), iVar5 != 0)))
                {
                    ppiVar2 = (int64_t **)*ppiVar11;
                    ppiVar3 = (int64_t **)ppiVar11[1];
                    ppiVar4 = (int64_t **)ppiVar11[2];
                    piVar7 = *ppiVar2;
                    if (piVar7 == (int64_t *)0x0) {
                        *(int64_t ***)arg1 = ppiVar11;
                    } else if ((int64_t **)piVar7[1] == ppiVar2) {
                        piVar7[1] = (int64_t)ppiVar11;
                    } else if ((int64_t **)piVar7[2] == ppiVar2) {
                        piVar7[2] = (int64_t)ppiVar11;
                    }
                    if (ppiVar3 != (int64_t **)0x0) {
                        *ppiVar3 = (int64_t *)ppiVar2;
                    }
                    if (ppiVar4 != (int64_t **)0x0) {
                        *ppiVar4 = (int64_t *)ppiVar2;
                    }
                    *ppiVar11 = piVar7;
                    ppiVar8 = (int64_t **)ppiVar2[1];
                    ppiVar10 = ppiVar2;
                    ppiVar12 = ppiVar8;
                    if (ppiVar8 == ppiVar11) {
                        ppiVar8 = (int64_t **)ppiVar2[2];
                        ppiVar10 = ppiVar8;
                        ppiVar12 = ppiVar2;
                    }
                    ppiVar11[1] = (int64_t *)ppiVar12;
                    ppiVar11[2] = (int64_t *)ppiVar10;
                    if (ppiVar8 != (int64_t **)0x0) {
                        *ppiVar8 = (int64_t *)ppiVar11;
                    }
                    *ppiVar2 = (int64_t *)ppiVar11;
                    ppiVar2[1] = (int64_t *)ppiVar3;
                    ppiVar2[2] = (int64_t *)ppiVar4;
                    piVar7 = *ppiVar11;
                }
            }
        } else if ((*(uint8_t *)((int64_t)ppiVar11 + -0x14) & 1) == 0) {
            if (*(int32_t *)(ppiVar11 + -9) == 0x10) {
                piVar7 = *ppiVar1 + 0x1c;
code_r0x00018018155b:
                func_0x0001801819b0(piVar7, ppiVar11);
            } else if (*(int32_t *)(ppiVar11 + -9) == 0x20) {
                piVar7 = *ppiVar1 + 0x1f;
                goto code_r0x00018018155b;
            }
            *(int32_t *)(*ppiVar1 + 0x22) = *(int32_t *)(*ppiVar1 + 0x22) + -1;
            *(uint32_t *)((int64_t)ppiVar11 + -0x14) = *(uint32_t *)((int64_t)ppiVar11 + -0x14) | 1;
        }
        if ((*(uint32_t *)((int64_t)ppiVar11 + -0x14) & 4) == 0) {
            *(uint32_t *)((int64_t)ppiVar11 + -0x14) = *(uint32_t *)((int64_t)ppiVar11 + -0x14) | 4;
            *(int32_t *)(*ppiVar1 + 9) = *(int32_t *)(*ppiVar1 + 9) + 1;
            ppiVar11[-4] = (int64_t *)(*ppiVar1)[(int64_t)*(int32_t *)(ppiVar11 + -3) + 0xf];
            (*ppiVar1)[(int64_t)*(int32_t *)(ppiVar11 + -3) + 0xf] = (int64_t)ppiVar1;
        }
        ppiVar11 = *(int64_t ***)arg1;
        iVar14 = iVar14 + 1;
        if (ppiVar11 == (int64_t **)0x0) {
            return iVar14;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1801814ff
// Address: 0x1801814ff
// Size: 593 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.1801814e0(int64_t arg1, int64_t arg2, int64_t arg_68h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    uint32_t uVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    uint32_t uVar13;
    int32_t iVar14;
    int64_t var_8h;
    int64_t var_38h;
    
    ppiVar11 = *(int64_t ***)arg1;
    iVar14 = 0;
    if (ppiVar11 == (int64_t **)0x0) {
        return 0;
    }
    do {
        ppiVar1 = ppiVar11 + -10;
        if ((uint64_t)arg2 < ppiVar11[-1]) {
            return iVar14;
        }
        if ((*(int32_t *)(ppiVar11 + -2) == -1) ||
           (iVar5 = *(int32_t *)(ppiVar11 + -2) + -1, *(int32_t *)(ppiVar11 + -2) = iVar5, iVar5 != 0)) {
            func_0x0001801819b0(arg1);
            if (*(int32_t *)(ppiVar11 + -9) == 0x10) {
                piVar7 = ppiVar11[-1];
                if (piVar7 <= (uint64_t)arg2) {
                    do {
                        piVar7 = piVar7 + (uint64_t)*(uint32_t *)(ppiVar11 + 3) * 0x7d;
                    } while (piVar7 <= (uint64_t)arg2);
code_r0x0001801815d5:
                    ppiVar11[-1] = piVar7;
                }
            } else if (*(int32_t *)(ppiVar11 + -9) == 0x20) {
                iVar6 = func_0x0001801890b0((int32_t)*(char *)(ppiVar11 + 3), 
                                            (int32_t)*(char *)((int64_t)ppiVar11 + 0x19), 
                                            (int32_t)*(char *)((int64_t)ppiVar11 + 0x1a), 
                                            (int32_t)*(char *)((int64_t)ppiVar11 + 0x1b), 
                                            (int32_t)*(char *)((int64_t)ppiVar11 + 0x1c));
                piVar7 = (int64_t *)(iVar6 * 1000000);
                goto code_r0x0001801815d5;
            }
            *(int32_t *)(arg1 + 8) = *(int32_t *)(arg1 + 8) + 1;
            uVar9 = 0;
            iVar5 = 0;
            for (uVar13 = *(uint32_t *)(arg1 + 8); 1 < (int32_t)uVar13; uVar13 = (int32_t)uVar13 >> 1) {
                iVar5 = iVar5 + 1;
                uVar9 = uVar13 & 1 | uVar9 * 2;
            }
            piVar7 = *(int64_t **)arg1;
            for (; 1 < iVar5; iVar5 = iVar5 + -1) {
                uVar13 = uVar9 & 1;
                uVar9 = (int32_t)uVar9 >> 1;
                piVar7 = (int64_t *)piVar7[(uint64_t)uVar13 + 1];
            }
            *ppiVar11 = piVar7;
            if (piVar7 == (int64_t *)0x0) {
                *(int64_t ***)arg1 = ppiVar11;
            } else if ((uVar9 & 1) == 0) {
                piVar7[1] = (int64_t)ppiVar11;
            } else {
                piVar7[2] = (int64_t)ppiVar11;
            }
            if (*(int64_t *)(arg1 + 0x10) != 0) {
                piVar7 = *ppiVar11;
                while ((piVar7 != (int64_t *)0x0 && (iVar5 = (**(code **)(arg1 + 0x10))(ppiVar11, piVar7), iVar5 != 0)))
                {
                    ppiVar2 = (int64_t **)*ppiVar11;
                    ppiVar3 = (int64_t **)ppiVar11[1];
                    ppiVar4 = (int64_t **)ppiVar11[2];
                    piVar7 = *ppiVar2;
                    if (piVar7 == (int64_t *)0x0) {
                        *(int64_t ***)arg1 = ppiVar11;
                    } else if ((int64_t **)piVar7[1] == ppiVar2) {
                        piVar7[1] = (int64_t)ppiVar11;
                    } else if ((int64_t **)piVar7[2] == ppiVar2) {
                        piVar7[2] = (int64_t)ppiVar11;
                    }
                    if (ppiVar3 != (int64_t **)0x0) {
                        *ppiVar3 = (int64_t *)ppiVar2;
                    }
                    if (ppiVar4 != (int64_t **)0x0) {
                        *ppiVar4 = (int64_t *)ppiVar2;
                    }
                    *ppiVar11 = piVar7;
                    ppiVar8 = (int64_t **)ppiVar2[1];
                    ppiVar10 = ppiVar2;
                    ppiVar12 = ppiVar8;
                    if (ppiVar8 == ppiVar11) {
                        ppiVar8 = (int64_t **)ppiVar2[2];
                        ppiVar10 = ppiVar8;
                        ppiVar12 = ppiVar2;
                    }
                    ppiVar11[1] = (int64_t *)ppiVar12;
                    ppiVar11[2] = (int64_t *)ppiVar10;
                    if (ppiVar8 != (int64_t **)0x0) {
                        *ppiVar8 = (int64_t *)ppiVar11;
                    }
                    *ppiVar2 = (int64_t *)ppiVar11;
                    ppiVar2[1] = (int64_t *)ppiVar3;
                    ppiVar2[2] = (int64_t *)ppiVar4;
                    piVar7 = *ppiVar11;
                }
            }
        } else if ((*(uint8_t *)((int64_t)ppiVar11 + -0x14) & 1) == 0) {
            if (*(int32_t *)(ppiVar11 + -9) == 0x10) {
                piVar7 = *ppiVar1 + 0x1c;
code_r0x00018018155b:
                func_0x0001801819b0(piVar7, ppiVar11);
            } else if (*(int32_t *)(ppiVar11 + -9) == 0x20) {
                piVar7 = *ppiVar1 + 0x1f;
                goto code_r0x00018018155b;
            }
            *(int32_t *)(*ppiVar1 + 0x22) = *(int32_t *)(*ppiVar1 + 0x22) + -1;
            *(uint32_t *)((int64_t)ppiVar11 + -0x14) = *(uint32_t *)((int64_t)ppiVar11 + -0x14) | 1;
        }
        if ((*(uint32_t *)((int64_t)ppiVar11 + -0x14) & 4) == 0) {
            *(uint32_t *)((int64_t)ppiVar11 + -0x14) = *(uint32_t *)((int64_t)ppiVar11 + -0x14) | 4;
            *(int32_t *)(*ppiVar1 + 9) = *(int32_t *)(*ppiVar1 + 9) + 1;
            ppiVar11[-4] = (int64_t *)(*ppiVar1)[(int64_t)*(int32_t *)(ppiVar11 + -3) + 0xf];
            (*ppiVar1)[(int64_t)*(int32_t *)(ppiVar11 + -3) + 0xf] = (int64_t)ppiVar1;
        }
        ppiVar11 = *(int64_t ***)arg1;
        iVar14 = iVar14 + 1;
        if (ppiVar11 == (int64_t **)0x0) {
            return iVar14;
        }
    } while( true );
}

// ============================================================
// Function: FUN_180181750
// Address: 0x180181750
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.1801814e0(int64_t arg1, int64_t arg2, int64_t arg_68h)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t **ppiVar8;
    uint32_t uVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    uint32_t uVar13;
    int32_t iVar14;
    int64_t var_8h;
    int64_t var_38h;
    
    ppiVar11 = *(int64_t ***)arg1;
    iVar14 = 0;
    if (ppiVar11 == (int64_t **)0x0) {
        return 0;
    }
    do {
        ppiVar1 = ppiVar11 + -10;
        if ((uint64_t)arg2 < ppiVar11[-1]) {
            return iVar14;
        }
        if ((*(int32_t *)(ppiVar11 + -2) == -1) ||
           (iVar5 = *(int32_t *)(ppiVar11 + -2) + -1, *(int32_t *)(ppiVar11 + -2) = iVar5, iVar5 != 0)) {
            func_0x0001801819b0(arg1);
            if (*(int32_t *)(ppiVar11 + -9) == 0x10) {
                piVar7 = ppiVar11[-1];
                if (piVar7 <= (uint64_t)arg2) {
                    do {
                        piVar7 = piVar7 + (uint64_t)*(uint32_t *)(ppiVar11 + 3) * 0x7d;
                    } while (piVar7 <= (uint64_t)arg2);
code_r0x0001801815d5:
                    ppiVar11[-1] = piVar7;
                }
            } else if (*(int32_t *)(ppiVar11 + -9) == 0x20) {
                iVar6 = func_0x0001801890b0((int32_t)*(char *)(ppiVar11 + 3), 
                                            (int32_t)*(char *)((int64_t)ppiVar11 + 0x19), 
                                            (int32_t)*(char *)((int64_t)ppiVar11 + 0x1a), 
                                            (int32_t)*(char *)((int64_t)ppiVar11 + 0x1b), 
                                            (int32_t)*(char *)((int64_t)ppiVar11 + 0x1c));
                piVar7 = (int64_t *)(iVar6 * 1000000);
                goto code_r0x0001801815d5;
            }
            *(int32_t *)(arg1 + 8) = *(int32_t *)(arg1 + 8) + 1;
            uVar9 = 0;
            iVar5 = 0;
            for (uVar13 = *(uint32_t *)(arg1 + 8); 1 < (int32_t)uVar13; uVar13 = (int32_t)uVar13 >> 1) {
                iVar5 = iVar5 + 1;
                uVar9 = uVar13 & 1 | uVar9 * 2;
            }
            piVar7 = *(int64_t **)arg1;
            for (; 1 < iVar5; iVar5 = iVar5 + -1) {
                uVar13 = uVar9 & 1;
                uVar9 = (int32_t)uVar9 >> 1;
                piVar7 = (int64_t *)piVar7[(uint64_t)uVar13 + 1];
            }
            *ppiVar11 = piVar7;
            if (piVar7 == (int64_t *)0x0) {
                *(int64_t ***)arg1 = ppiVar11;
            } else if ((uVar9 & 1) == 0) {
                piVar7[1] = (int64_t)ppiVar11;
            } else {
                piVar7[2] = (int64_t)ppiVar11;
            }
            if (*(int64_t *)(arg1 + 0x10) != 0) {
                piVar7 = *ppiVar11;
                while ((piVar7 != (int64_t *)0x0 && (iVar5 = (**(code **)(arg1 + 0x10))(ppiVar11, piVar7), iVar5 != 0)))
                {
                    ppiVar2 = (int64_t **)*ppiVar11;
                    ppiVar3 = (int64_t **)ppiVar11[1];
                    ppiVar4 = (int64_t **)ppiVar11[2];
                    piVar7 = *ppiVar2;
                    if (piVar7 == (int64_t *)0x0) {
                        *(int64_t ***)arg1 = ppiVar11;
                    } else if ((int64_t **)piVar7[1] == ppiVar2) {
                        piVar7[1] = (int64_t)ppiVar11;
                    } else if ((int64_t **)piVar7[2] == ppiVar2) {
                        piVar7[2] = (int64_t)ppiVar11;
                    }
                    if (ppiVar3 != (int64_t **)0x0) {
                        *ppiVar3 = (int64_t *)ppiVar2;
                    }
                    if (ppiVar4 != (int64_t **)0x0) {
                        *ppiVar4 = (int64_t *)ppiVar2;
                    }
                    *ppiVar11 = piVar7;
                    ppiVar8 = (int64_t **)ppiVar2[1];
                    ppiVar10 = ppiVar2;
                    ppiVar12 = ppiVar8;
                    if (ppiVar8 == ppiVar11) {
                        ppiVar8 = (int64_t **)ppiVar2[2];
                        ppiVar10 = ppiVar8;
                        ppiVar12 = ppiVar2;
                    }
                    ppiVar11[1] = (int64_t *)ppiVar12;
                    ppiVar11[2] = (int64_t *)ppiVar10;
                    if (ppiVar8 != (int64_t **)0x0) {
                        *ppiVar8 = (int64_t *)ppiVar11;
                    }
                    *ppiVar2 = (int64_t *)ppiVar11;
                    ppiVar2[1] = (int64_t *)ppiVar3;
                    ppiVar2[2] = (int64_t *)ppiVar4;
                    piVar7 = *ppiVar11;
                }
            }
        } else if ((*(uint8_t *)((int64_t)ppiVar11 + -0x14) & 1) == 0) {
            if (*(int32_t *)(ppiVar11 + -9) == 0x10) {
                piVar7 = *ppiVar1 + 0x1c;
code_r0x00018018155b:
                func_0x0001801819b0(piVar7, ppiVar11);
            } else if (*(int32_t *)(ppiVar11 + -9) == 0x20) {
                piVar7 = *ppiVar1 + 0x1f;
                goto code_r0x00018018155b;
            }
            *(int32_t *)(*ppiVar1 + 0x22) = *(int32_t *)(*ppiVar1 + 0x22) + -1;
            *(uint32_t *)((int64_t)ppiVar11 + -0x14) = *(uint32_t *)((int64_t)ppiVar11 + -0x14) | 1;
        }
        if ((*(uint32_t *)((int64_t)ppiVar11 + -0x14) & 4) == 0) {
            *(uint32_t *)((int64_t)ppiVar11 + -0x14) = *(uint32_t *)((int64_t)ppiVar11 + -0x14) | 4;
            *(int32_t *)(*ppiVar1 + 9) = *(int32_t *)(*ppiVar1 + 9) + 1;
            ppiVar11[-4] = (int64_t *)(*ppiVar1)[(int64_t)*(int32_t *)(ppiVar11 + -3) + 0xf];
            (*ppiVar1)[(int64_t)*(int32_t *)(ppiVar11 + -3) + 0xf] = (int64_t)ppiVar1;
        }
        ppiVar11 = *(int64_t ***)arg1;
        iVar14 = iVar14 + 1;
        if (ppiVar11 == (int64_t **)0x0) {
            return iVar14;
        }
    } while( true );
}

// ============================================================
// Function: FUN_180181760
// Address: 0x180181760
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180181760(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    undefined4 *puVar1;
    uint64_t uVar2;
    int64_t var_8h;
    int64_t var_68h;
    undefined4 uStack_60;
    undefined4 uStack_5c;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    undefined4 uStack_40;
    undefined4 uStack_3c;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    
    if ((int32_t)arg3 != 0) {
        arg1 = *(int64_t *)arg1;
        uVar2 = 0;
        do {
            (*(code *)0x699f1c)(arg1 + 0x178);
            if ((*(int64_t *)(arg1 + 0x160) == 0) ||
               (puVar1 = (undefined4 *)(*(int64_t *)(arg1 + 0x170) * 0x40 + *(int64_t *)(arg1 + 0x158)),
               puVar1 == (undefined4 *)0x0)) {
                (*(code *)0x699f34)(arg1 + 0x178);
                return;
            }
            var_68h._0_4_ = *puVar1;
            var_68h._4_4_ = puVar1[1];
            uStack_60 = puVar1[2];
            uStack_5c = puVar1[3];
            var_58h._0_4_ = puVar1[4];
            var_58h._4_4_ = puVar1[5];
            var_50h._0_4_ = puVar1[6];
            var_50h._4_4_ = puVar1[7];
            var_48h._0_4_ = puVar1[8];
            var_48h._4_4_ = puVar1[9];
            uStack_40 = puVar1[10];
            uStack_3c = puVar1[0xb];
            var_38h._0_4_ = puVar1[0xc];
            var_38h._4_4_ = puVar1[0xd];
            uStack_30 = puVar1[0xe];
            uStack_2c = puVar1[0xf];
            *(int64_t *)(arg1 + 0x170) = *(int64_t *)(arg1 + 0x170) + 1;
            *(int64_t *)(arg1 + 0x160) = *(int64_t *)(arg1 + 0x160) + -1;
            if (*(int64_t *)(arg1 + 0x170) == *(int64_t *)(arg1 + 0x168)) {
                *(undefined8 *)(arg1 + 0x170) = 0;
            }
            (*(code *)0x699f34)(arg1 + 0x178);
            if ((code *)CONCAT44(var_50h._4_4_, (undefined4)var_50h) != (code *)0x0) {
                (*(code *)CONCAT44(var_50h._4_4_, (undefined4)var_50h))(&var_68h);
            }
            uVar2 = uVar2 + 1;
        } while (uVar2 < (uint64_t)(int64_t)(int32_t)arg3);
    }
    return;
}

// ============================================================
// Function: FUN_18018177e
// Address: 0x18018177e
// Size: 210 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180181760(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    undefined4 *puVar1;
    uint64_t uVar2;
    int64_t var_8h;
    int64_t var_68h;
    undefined4 uStack_60;
    undefined4 uStack_5c;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    undefined4 uStack_40;
    undefined4 uStack_3c;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    
    if ((int32_t)arg3 != 0) {
        arg1 = *(int64_t *)arg1;
        uVar2 = 0;
        do {
            (*(code *)0x699f1c)(arg1 + 0x178);
            if ((*(int64_t *)(arg1 + 0x160) == 0) ||
               (puVar1 = (undefined4 *)(*(int64_t *)(arg1 + 0x170) * 0x40 + *(int64_t *)(arg1 + 0x158)),
               puVar1 == (undefined4 *)0x0)) {
                (*(code *)0x699f34)(arg1 + 0x178);
                return;
            }
            var_68h._0_4_ = *puVar1;
            var_68h._4_4_ = puVar1[1];
            uStack_60 = puVar1[2];
            uStack_5c = puVar1[3];
            var_58h._0_4_ = puVar1[4];
            var_58h._4_4_ = puVar1[5];
            var_50h._0_4_ = puVar1[6];
            var_50h._4_4_ = puVar1[7];
            var_48h._0_4_ = puVar1[8];
            var_48h._4_4_ = puVar1[9];
            uStack_40 = puVar1[10];
            uStack_3c = puVar1[0xb];
            var_38h._0_4_ = puVar1[0xc];
            var_38h._4_4_ = puVar1[0xd];
            uStack_30 = puVar1[0xe];
            uStack_2c = puVar1[0xf];
            *(int64_t *)(arg1 + 0x170) = *(int64_t *)(arg1 + 0x170) + 1;
            *(int64_t *)(arg1 + 0x160) = *(int64_t *)(arg1 + 0x160) + -1;
            if (*(int64_t *)(arg1 + 0x170) == *(int64_t *)(arg1 + 0x168)) {
                *(undefined8 *)(arg1 + 0x170) = 0;
            }
            (*(code *)0x699f34)(arg1 + 0x178);
            if ((code *)CONCAT44(var_50h._4_4_, (undefined4)var_50h) != (code *)0x0) {
                (*(code *)CONCAT44(var_50h._4_4_, (undefined4)var_50h))(&var_68h);
            }
            uVar2 = uVar2 + 1;
        } while (uVar2 < (uint64_t)(int64_t)(int32_t)arg3);
    }
    return;
}

// ============================================================
// Function: FUN_180181850
// Address: 0x180181850
// Size: 1 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180181760(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    undefined4 *puVar1;
    uint64_t uVar2;
    int64_t var_8h;
    int64_t var_68h;
    undefined4 uStack_60;
    undefined4 uStack_5c;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    undefined4 uStack_40;
    undefined4 uStack_3c;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    
    if ((int32_t)arg3 != 0) {
        arg1 = *(int64_t *)arg1;
        uVar2 = 0;
        do {
            (*(code *)0x699f1c)(arg1 + 0x178);
            if ((*(int64_t *)(arg1 + 0x160) == 0) ||
               (puVar1 = (undefined4 *)(*(int64_t *)(arg1 + 0x170) * 0x40 + *(int64_t *)(arg1 + 0x158)),
               puVar1 == (undefined4 *)0x0)) {
                (*(code *)0x699f34)(arg1 + 0x178);
                return;
            }
            var_68h._0_4_ = *puVar1;
            var_68h._4_4_ = puVar1[1];
            uStack_60 = puVar1[2];
            uStack_5c = puVar1[3];
            var_58h._0_4_ = puVar1[4];
            var_58h._4_4_ = puVar1[5];
            var_50h._0_4_ = puVar1[6];
            var_50h._4_4_ = puVar1[7];
            var_48h._0_4_ = puVar1[8];
            var_48h._4_4_ = puVar1[9];
            uStack_40 = puVar1[10];
            uStack_3c = puVar1[0xb];
            var_38h._0_4_ = puVar1[0xc];
            var_38h._4_4_ = puVar1[0xd];
            uStack_30 = puVar1[0xe];
            uStack_2c = puVar1[0xf];
            *(int64_t *)(arg1 + 0x170) = *(int64_t *)(arg1 + 0x170) + 1;
            *(int64_t *)(arg1 + 0x160) = *(int64_t *)(arg1 + 0x160) + -1;
            if (*(int64_t *)(arg1 + 0x170) == *(int64_t *)(arg1 + 0x168)) {
                *(undefined8 *)(arg1 + 0x170) = 0;
            }
            (*(code *)0x699f34)(arg1 + 0x178);
            if ((code *)CONCAT44(var_50h._4_4_, (undefined4)var_50h) != (code *)0x0) {
                (*(code *)CONCAT44(var_50h._4_4_, (undefined4)var_50h))(&var_68h);
            }
            uVar2 = uVar2 + 1;
        } while (uVar2 < (uint64_t)(int64_t)(int32_t)arg3);
    }
    return;
}

// ============================================================
// Function: FUN_180181860
// Address: 0x180181860
// Size: 335 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180181860(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t *piVar8;
    uint32_t uVar9;
    int64_t *piVar10;
    int64_t var_8h;
    
    *(int32_t *)(arg1 + 8) = *(int32_t *)(arg1 + 8) + 1;
    uVar6 = 0;
    iVar7 = 0;
    for (uVar9 = *(uint32_t *)(arg1 + 8); 1 < (int32_t)uVar9; uVar9 = (int32_t)uVar9 >> 1) {
        iVar7 = iVar7 + 1;
        uVar6 = uVar9 & 1 | uVar6 * 2;
    }
    iVar1 = *(int64_t *)arg1;
    for (; 1 < iVar7; iVar7 = iVar7 + -1) {
        uVar9 = uVar6 & 1;
        uVar6 = (int32_t)uVar6 >> 1;
        iVar1 = *(int64_t *)(iVar1 + 8 + (uint64_t)uVar9 * 8);
    }
    *(int64_t *)arg2 = iVar1;
    if (iVar1 == 0) {
        *(int64_t *)arg1 = arg2;
    } else if ((uVar6 & 1) == 0) {
        *(int64_t *)(iVar1 + 8) = arg2;
    } else {
        *(int64_t *)(iVar1 + 0x10) = arg2;
    }
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        iVar1 = *(int64_t *)arg2;
        while ((iVar1 != 0 && (iVar7 = (**(code **)(arg1 + 0x10))(arg2, iVar1), iVar7 != 0))) {
            piVar2 = *(int64_t **)arg2;
            ppiVar3 = *(int64_t ***)(arg2 + 8);
            ppiVar4 = *(int64_t ***)(arg2 + 0x10);
            iVar1 = *piVar2;
            if (iVar1 == 0) {
                *(int64_t *)arg1 = arg2;
            } else if (*(int64_t **)(iVar1 + 8) == piVar2) {
                *(int64_t *)(iVar1 + 8) = arg2;
            } else if (*(int64_t **)(iVar1 + 0x10) == piVar2) {
                *(int64_t *)(iVar1 + 0x10) = arg2;
            }
            if (ppiVar3 != (int64_t **)0x0) {
                *ppiVar3 = piVar2;
            }
            if (ppiVar4 != (int64_t **)0x0) {
                *ppiVar4 = piVar2;
            }
            *(int64_t *)arg2 = iVar1;
            piVar5 = (int64_t *)piVar2[1];
            piVar8 = piVar2;
            piVar10 = piVar5;
            if (piVar5 == (int64_t *)arg2) {
                piVar5 = (int64_t *)piVar2[2];
                piVar8 = piVar5;
                piVar10 = piVar2;
            }
            *(int64_t **)(arg2 + 8) = piVar10;
            *(int64_t **)(arg2 + 0x10) = piVar8;
            if (piVar5 != (int64_t *)0x0) {
                *piVar5 = arg2;
            }
            *piVar2 = arg2;
            piVar2[1] = (int64_t)ppiVar3;
            piVar2[2] = (int64_t)ppiVar4;
            iVar1 = *(int64_t *)arg2;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801819b0
// Address: 0x1801819b0
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801819b0(int64_t arg1, int64_t arg2, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t **ppiVar7;
    uint32_t uVar8;
    int64_t **ppiVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    uint32_t uVar13;
    uint32_t uVar14;
    int64_t **ppiVar15;
    uint32_t uVar16;
    int64_t **ppiVar17;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar5 = *(uint32_t *)(arg1 + 8);
    if (uVar5 != 0) {
        uVar13 = 0;
        uVar16 = uVar5;
        uVar14 = uVar13;
        if (1 < (int32_t)uVar5) {
            do {
                uVar8 = uVar16 & 1;
                uVar16 = uVar16 >> 1;
                uVar14 = uVar14 + 1;
                uVar13 = uVar8 | uVar13 * 2;
            } while (1 < uVar16);
        }
        iVar1 = *(int64_t *)arg1;
        *(uint32_t *)(arg1 + 8) = uVar5 - 1;
        for (; 1 < (int32_t)uVar14; uVar14 = uVar14 - 1) {
            uVar5 = uVar13 & 1;
            uVar13 = (int32_t)uVar13 >> 1;
            iVar1 = *(int64_t *)(iVar1 + 8 + (uint64_t)uVar5 * 8);
        }
        if (iVar1 != 0) {
            if ((uVar13 & 1) == 0) {
                ppiVar11 = *(int64_t ***)(iVar1 + 8);
                *(undefined8 *)(iVar1 + 8) = 0;
            } else {
                ppiVar11 = *(int64_t ***)(iVar1 + 0x10);
                *(undefined8 *)(iVar1 + 0x10) = 0;
            }
            if (ppiVar11 == (int64_t **)0x0) {
                if (*(int64_t *)arg1 == arg2) {
                    *(undefined8 *)arg1 = 0;
                    return;
                }
            } else {
                iVar1 = *(int64_t *)arg2;
                if (iVar1 == 0) {
                    *(int64_t ***)arg1 = ppiVar11;
                } else if (*(int64_t *)(iVar1 + 8) == arg2) {
                    *(int64_t ***)(iVar1 + 8) = ppiVar11;
                } else if (*(int64_t *)(iVar1 + 0x10) == arg2) {
                    *(int64_t ***)(iVar1 + 0x10) = ppiVar11;
                }
                if (*(undefined8 **)(arg2 + 8) != (undefined8 *)0x0) {
                    **(undefined8 **)(arg2 + 8) = ppiVar11;
                }
                if (*(undefined8 **)(arg2 + 0x10) != (undefined8 *)0x0) {
                    **(undefined8 **)(arg2 + 0x10) = ppiVar11;
                }
                *ppiVar11 = *(int64_t **)arg2;
                ppiVar11[1] = *(int64_t **)(arg2 + 8);
                ppiVar11[2] = *(int64_t **)(arg2 + 0x10);
                *(undefined8 *)(arg2 + 0x10) = 0;
                *(undefined8 *)(arg2 + 8) = 0;
                *(undefined8 *)arg2 = 0;
                if (*(int64_t *)(arg1 + 0x10) != 0) {
                    while( true ) {
                        ppiVar12 = ppiVar11;
                        if ((ppiVar11[1] != (int64_t *)0x0) &&
                           (iVar6 = (**(code **)(arg1 + 0x10))(ppiVar11), iVar6 == 0)) {
                            ppiVar12 = (int64_t **)ppiVar11[1];
                        }
                        if ((ppiVar11[2] != (int64_t *)0x0) &&
                           (iVar6 = (**(code **)(arg1 + 0x10))(ppiVar12), iVar6 == 0)) {
                            ppiVar12 = (int64_t **)ppiVar11[2];
                        }
                        piVar2 = *ppiVar11;
                        if (ppiVar12 == ppiVar11) break;
                        piVar3 = ppiVar12[1];
                        piVar4 = ppiVar12[2];
                        if (piVar2 == (int64_t *)0x0) {
                            *(int64_t ***)arg1 = ppiVar12;
                        } else if ((int64_t **)piVar2[1] == ppiVar11) {
                            piVar2[1] = (int64_t)ppiVar12;
                        } else if ((int64_t **)piVar2[2] == ppiVar11) {
                            piVar2[2] = (int64_t)ppiVar12;
                        }
                        if (piVar3 != (int64_t *)0x0) {
                            *piVar3 = (int64_t)ppiVar11;
                        }
                        if (piVar4 != (int64_t *)0x0) {
                            *piVar4 = (int64_t)ppiVar11;
                        }
                        *ppiVar12 = piVar2;
                        ppiVar7 = (int64_t **)ppiVar11[1];
                        ppiVar9 = ppiVar11;
                        ppiVar10 = ppiVar7;
                        if (ppiVar7 == ppiVar12) {
                            ppiVar7 = (int64_t **)ppiVar11[2];
                            ppiVar9 = ppiVar7;
                            ppiVar10 = ppiVar11;
                        }
                        ppiVar12[1] = (int64_t *)ppiVar10;
                        ppiVar12[2] = (int64_t *)ppiVar9;
                        if (ppiVar7 != (int64_t **)0x0) {
                            *ppiVar7 = (int64_t *)ppiVar12;
                        }
                        *ppiVar11 = (int64_t *)ppiVar12;
                        ppiVar11[1] = piVar3;
                        ppiVar11[2] = piVar4;
                    }
                    while ((piVar2 != (int64_t *)0x0 &&
                           (iVar6 = (**(code **)(arg1 + 0x10))(ppiVar11, piVar2), iVar6 != 0))) {
                        ppiVar12 = (int64_t **)*ppiVar11;
                        ppiVar7 = (int64_t **)ppiVar11[1];
                        ppiVar9 = (int64_t **)ppiVar11[2];
                        piVar2 = *ppiVar12;
                        if (piVar2 == (int64_t *)0x0) {
                            *(int64_t ***)arg1 = ppiVar11;
                        } else if ((int64_t **)piVar2[1] == ppiVar12) {
                            piVar2[1] = (int64_t)ppiVar11;
                        } else if ((int64_t **)piVar2[2] == ppiVar12) {
                            piVar2[2] = (int64_t)ppiVar11;
                        }
                        if (ppiVar7 != (int64_t **)0x0) {
                            *ppiVar7 = (int64_t *)ppiVar12;
                        }
                        if (ppiVar9 != (int64_t **)0x0) {
                            *ppiVar9 = (int64_t *)ppiVar12;
                        }
                        *ppiVar11 = piVar2;
                        ppiVar10 = (int64_t **)ppiVar12[1];
                        ppiVar15 = ppiVar12;
                        ppiVar17 = ppiVar10;
                        if (ppiVar10 == ppiVar11) {
                            ppiVar10 = (int64_t **)ppiVar12[2];
                            ppiVar15 = ppiVar10;
                            ppiVar17 = ppiVar12;
                        }
                        ppiVar11[1] = (int64_t *)ppiVar17;
                        ppiVar11[2] = (int64_t *)ppiVar15;
                        if (ppiVar10 != (int64_t **)0x0) {
                            *ppiVar10 = (int64_t *)ppiVar11;
                        }
                        *ppiVar12 = (int64_t *)ppiVar11;
                        ppiVar12[1] = (int64_t *)ppiVar7;
                        ppiVar12[2] = (int64_t *)ppiVar9;
                        piVar2 = *ppiVar11;
                    }
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801819c6
// Address: 0x1801819c6
// Size: 168 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801819b0(int64_t arg1, int64_t arg2, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t **ppiVar7;
    uint32_t uVar8;
    int64_t **ppiVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    uint32_t uVar13;
    uint32_t uVar14;
    int64_t **ppiVar15;
    uint32_t uVar16;
    int64_t **ppiVar17;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar5 = *(uint32_t *)(arg1 + 8);
    if (uVar5 != 0) {
        uVar13 = 0;
        uVar16 = uVar5;
        uVar14 = uVar13;
        if (1 < (int32_t)uVar5) {
            do {
                uVar8 = uVar16 & 1;
                uVar16 = uVar16 >> 1;
                uVar14 = uVar14 + 1;
                uVar13 = uVar8 | uVar13 * 2;
            } while (1 < uVar16);
        }
        iVar1 = *(int64_t *)arg1;
        *(uint32_t *)(arg1 + 8) = uVar5 - 1;
        for (; 1 < (int32_t)uVar14; uVar14 = uVar14 - 1) {
            uVar5 = uVar13 & 1;
            uVar13 = (int32_t)uVar13 >> 1;
            iVar1 = *(int64_t *)(iVar1 + 8 + (uint64_t)uVar5 * 8);
        }
        if (iVar1 != 0) {
            if ((uVar13 & 1) == 0) {
                ppiVar11 = *(int64_t ***)(iVar1 + 8);
                *(undefined8 *)(iVar1 + 8) = 0;
            } else {
                ppiVar11 = *(int64_t ***)(iVar1 + 0x10);
                *(undefined8 *)(iVar1 + 0x10) = 0;
            }
            if (ppiVar11 == (int64_t **)0x0) {
                if (*(int64_t *)arg1 == arg2) {
                    *(undefined8 *)arg1 = 0;
                    return;
                }
            } else {
                iVar1 = *(int64_t *)arg2;
                if (iVar1 == 0) {
                    *(int64_t ***)arg1 = ppiVar11;
                } else if (*(int64_t *)(iVar1 + 8) == arg2) {
                    *(int64_t ***)(iVar1 + 8) = ppiVar11;
                } else if (*(int64_t *)(iVar1 + 0x10) == arg2) {
                    *(int64_t ***)(iVar1 + 0x10) = ppiVar11;
                }
                if (*(undefined8 **)(arg2 + 8) != (undefined8 *)0x0) {
                    **(undefined8 **)(arg2 + 8) = ppiVar11;
                }
                if (*(undefined8 **)(arg2 + 0x10) != (undefined8 *)0x0) {
                    **(undefined8 **)(arg2 + 0x10) = ppiVar11;
                }
                *ppiVar11 = *(int64_t **)arg2;
                ppiVar11[1] = *(int64_t **)(arg2 + 8);
                ppiVar11[2] = *(int64_t **)(arg2 + 0x10);
                *(undefined8 *)(arg2 + 0x10) = 0;
                *(undefined8 *)(arg2 + 8) = 0;
                *(undefined8 *)arg2 = 0;
                if (*(int64_t *)(arg1 + 0x10) != 0) {
                    while( true ) {
                        ppiVar12 = ppiVar11;
                        if ((ppiVar11[1] != (int64_t *)0x0) &&
                           (iVar6 = (**(code **)(arg1 + 0x10))(ppiVar11), iVar6 == 0)) {
                            ppiVar12 = (int64_t **)ppiVar11[1];
                        }
                        if ((ppiVar11[2] != (int64_t *)0x0) &&
                           (iVar6 = (**(code **)(arg1 + 0x10))(ppiVar12), iVar6 == 0)) {
                            ppiVar12 = (int64_t **)ppiVar11[2];
                        }
                        piVar2 = *ppiVar11;
                        if (ppiVar12 == ppiVar11) break;
                        piVar3 = ppiVar12[1];
                        piVar4 = ppiVar12[2];
                        if (piVar2 == (int64_t *)0x0) {
                            *(int64_t ***)arg1 = ppiVar12;
                        } else if ((int64_t **)piVar2[1] == ppiVar11) {
                            piVar2[1] = (int64_t)ppiVar12;
                        } else if ((int64_t **)piVar2[2] == ppiVar11) {
                            piVar2[2] = (int64_t)ppiVar12;
                        }
                        if (piVar3 != (int64_t *)0x0) {
                            *piVar3 = (int64_t)ppiVar11;
                        }
                        if (piVar4 != (int64_t *)0x0) {
                            *piVar4 = (int64_t)ppiVar11;
                        }
                        *ppiVar12 = piVar2;
                        ppiVar7 = (int64_t **)ppiVar11[1];
                        ppiVar9 = ppiVar11;
                        ppiVar10 = ppiVar7;
                        if (ppiVar7 == ppiVar12) {
                            ppiVar7 = (int64_t **)ppiVar11[2];
                            ppiVar9 = ppiVar7;
                            ppiVar10 = ppiVar11;
                        }
                        ppiVar12[1] = (int64_t *)ppiVar10;
                        ppiVar12[2] = (int64_t *)ppiVar9;
                        if (ppiVar7 != (int64_t **)0x0) {
                            *ppiVar7 = (int64_t *)ppiVar12;
                        }
                        *ppiVar11 = (int64_t *)ppiVar12;
                        ppiVar11[1] = piVar3;
                        ppiVar11[2] = piVar4;
                    }
                    while ((piVar2 != (int64_t *)0x0 &&
                           (iVar6 = (**(code **)(arg1 + 0x10))(ppiVar11, piVar2), iVar6 != 0))) {
                        ppiVar12 = (int64_t **)*ppiVar11;
                        ppiVar7 = (int64_t **)ppiVar11[1];
                        ppiVar9 = (int64_t **)ppiVar11[2];
                        piVar2 = *ppiVar12;
                        if (piVar2 == (int64_t *)0x0) {
                            *(int64_t ***)arg1 = ppiVar11;
                        } else if ((int64_t **)piVar2[1] == ppiVar12) {
                            piVar2[1] = (int64_t)ppiVar11;
                        } else if ((int64_t **)piVar2[2] == ppiVar12) {
                            piVar2[2] = (int64_t)ppiVar11;
                        }
                        if (ppiVar7 != (int64_t **)0x0) {
                            *ppiVar7 = (int64_t *)ppiVar12;
                        }
                        if (ppiVar9 != (int64_t **)0x0) {
                            *ppiVar9 = (int64_t *)ppiVar12;
                        }
                        *ppiVar11 = piVar2;
                        ppiVar10 = (int64_t **)ppiVar12[1];
                        ppiVar15 = ppiVar12;
                        ppiVar17 = ppiVar10;
                        if (ppiVar10 == ppiVar11) {
                            ppiVar10 = (int64_t **)ppiVar12[2];
                            ppiVar15 = ppiVar10;
                            ppiVar17 = ppiVar12;
                        }
                        ppiVar11[1] = (int64_t *)ppiVar17;
                        ppiVar11[2] = (int64_t *)ppiVar15;
                        if (ppiVar10 != (int64_t **)0x0) {
                            *ppiVar10 = (int64_t *)ppiVar11;
                        }
                        *ppiVar12 = (int64_t *)ppiVar11;
                        ppiVar12[1] = (int64_t *)ppiVar7;
                        ppiVar12[2] = (int64_t *)ppiVar9;
                        piVar2 = *ppiVar11;
                    }
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180181a6e
// Address: 0x180181a6e
// Size: 443 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801819b0(int64_t arg1, int64_t arg2, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t **ppiVar7;
    uint32_t uVar8;
    int64_t **ppiVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    uint32_t uVar13;
    uint32_t uVar14;
    int64_t **ppiVar15;
    uint32_t uVar16;
    int64_t **ppiVar17;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar5 = *(uint32_t *)(arg1 + 8);
    if (uVar5 != 0) {
        uVar13 = 0;
        uVar16 = uVar5;
        uVar14 = uVar13;
        if (1 < (int32_t)uVar5) {
            do {
                uVar8 = uVar16 & 1;
                uVar16 = uVar16 >> 1;
                uVar14 = uVar14 + 1;
                uVar13 = uVar8 | uVar13 * 2;
            } while (1 < uVar16);
        }
        iVar1 = *(int64_t *)arg1;
        *(uint32_t *)(arg1 + 8) = uVar5 - 1;
        for (; 1 < (int32_t)uVar14; uVar14 = uVar14 - 1) {
            uVar5 = uVar13 & 1;
            uVar13 = (int32_t)uVar13 >> 1;
            iVar1 = *(int64_t *)(iVar1 + 8 + (uint64_t)uVar5 * 8);
        }
        if (iVar1 != 0) {
            if ((uVar13 & 1) == 0) {
                ppiVar11 = *(int64_t ***)(iVar1 + 8);
                *(undefined8 *)(iVar1 + 8) = 0;
            } else {
                ppiVar11 = *(int64_t ***)(iVar1 + 0x10);
                *(undefined8 *)(iVar1 + 0x10) = 0;
            }
            if (ppiVar11 == (int64_t **)0x0) {
                if (*(int64_t *)arg1 == arg2) {
                    *(undefined8 *)arg1 = 0;
                    return;
                }
            } else {
                iVar1 = *(int64_t *)arg2;
                if (iVar1 == 0) {
                    *(int64_t ***)arg1 = ppiVar11;
                } else if (*(int64_t *)(iVar1 + 8) == arg2) {
                    *(int64_t ***)(iVar1 + 8) = ppiVar11;
                } else if (*(int64_t *)(iVar1 + 0x10) == arg2) {
                    *(int64_t ***)(iVar1 + 0x10) = ppiVar11;
                }
                if (*(undefined8 **)(arg2 + 8) != (undefined8 *)0x0) {
                    **(undefined8 **)(arg2 + 8) = ppiVar11;
                }
                if (*(undefined8 **)(arg2 + 0x10) != (undefined8 *)0x0) {
                    **(undefined8 **)(arg2 + 0x10) = ppiVar11;
                }
                *ppiVar11 = *(int64_t **)arg2;
                ppiVar11[1] = *(int64_t **)(arg2 + 8);
                ppiVar11[2] = *(int64_t **)(arg2 + 0x10);
                *(undefined8 *)(arg2 + 0x10) = 0;
                *(undefined8 *)(arg2 + 8) = 0;
                *(undefined8 *)arg2 = 0;
                if (*(int64_t *)(arg1 + 0x10) != 0) {
                    while( true ) {
                        ppiVar12 = ppiVar11;
                        if ((ppiVar11[1] != (int64_t *)0x0) &&
                           (iVar6 = (**(code **)(arg1 + 0x10))(ppiVar11), iVar6 == 0)) {
                            ppiVar12 = (int64_t **)ppiVar11[1];
                        }
                        if ((ppiVar11[2] != (int64_t *)0x0) &&
                           (iVar6 = (**(code **)(arg1 + 0x10))(ppiVar12), iVar6 == 0)) {
                            ppiVar12 = (int64_t **)ppiVar11[2];
                        }
                        piVar2 = *ppiVar11;
                        if (ppiVar12 == ppiVar11) break;
                        piVar3 = ppiVar12[1];
                        piVar4 = ppiVar12[2];
                        if (piVar2 == (int64_t *)0x0) {
                            *(int64_t ***)arg1 = ppiVar12;
                        } else if ((int64_t **)piVar2[1] == ppiVar11) {
                            piVar2[1] = (int64_t)ppiVar12;
                        } else if ((int64_t **)piVar2[2] == ppiVar11) {
                            piVar2[2] = (int64_t)ppiVar12;
                        }
                        if (piVar3 != (int64_t *)0x0) {
                            *piVar3 = (int64_t)ppiVar11;
                        }
                        if (piVar4 != (int64_t *)0x0) {
                            *piVar4 = (int64_t)ppiVar11;
                        }
                        *ppiVar12 = piVar2;
                        ppiVar7 = (int64_t **)ppiVar11[1];
                        ppiVar9 = ppiVar11;
                        ppiVar10 = ppiVar7;
                        if (ppiVar7 == ppiVar12) {
                            ppiVar7 = (int64_t **)ppiVar11[2];
                            ppiVar9 = ppiVar7;
                            ppiVar10 = ppiVar11;
                        }
                        ppiVar12[1] = (int64_t *)ppiVar10;
                        ppiVar12[2] = (int64_t *)ppiVar9;
                        if (ppiVar7 != (int64_t **)0x0) {
                            *ppiVar7 = (int64_t *)ppiVar12;
                        }
                        *ppiVar11 = (int64_t *)ppiVar12;
                        ppiVar11[1] = piVar3;
                        ppiVar11[2] = piVar4;
                    }
                    while ((piVar2 != (int64_t *)0x0 &&
                           (iVar6 = (**(code **)(arg1 + 0x10))(ppiVar11, piVar2), iVar6 != 0))) {
                        ppiVar12 = (int64_t **)*ppiVar11;
                        ppiVar7 = (int64_t **)ppiVar11[1];
                        ppiVar9 = (int64_t **)ppiVar11[2];
                        piVar2 = *ppiVar12;
                        if (piVar2 == (int64_t *)0x0) {
                            *(int64_t ***)arg1 = ppiVar11;
                        } else if ((int64_t **)piVar2[1] == ppiVar12) {
                            piVar2[1] = (int64_t)ppiVar11;
                        } else if ((int64_t **)piVar2[2] == ppiVar12) {
                            piVar2[2] = (int64_t)ppiVar11;
                        }
                        if (ppiVar7 != (int64_t **)0x0) {
                            *ppiVar7 = (int64_t *)ppiVar12;
                        }
                        if (ppiVar9 != (int64_t **)0x0) {
                            *ppiVar9 = (int64_t *)ppiVar12;
                        }
                        *ppiVar11 = piVar2;
                        ppiVar10 = (int64_t **)ppiVar12[1];
                        ppiVar15 = ppiVar12;
                        ppiVar17 = ppiVar10;
                        if (ppiVar10 == ppiVar11) {
                            ppiVar10 = (int64_t **)ppiVar12[2];
                            ppiVar15 = ppiVar10;
                            ppiVar17 = ppiVar12;
                        }
                        ppiVar11[1] = (int64_t *)ppiVar17;
                        ppiVar11[2] = (int64_t *)ppiVar15;
                        if (ppiVar10 != (int64_t **)0x0) {
                            *ppiVar10 = (int64_t *)ppiVar11;
                        }
                        *ppiVar12 = (int64_t *)ppiVar11;
                        ppiVar12[1] = (int64_t *)ppiVar7;
                        ppiVar12[2] = (int64_t *)ppiVar9;
                        piVar2 = *ppiVar11;
                    }
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180181c29
// Address: 0x180181c29
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801819b0(int64_t arg1, int64_t arg2, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t **ppiVar7;
    uint32_t uVar8;
    int64_t **ppiVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    uint32_t uVar13;
    uint32_t uVar14;
    int64_t **ppiVar15;
    uint32_t uVar16;
    int64_t **ppiVar17;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar5 = *(uint32_t *)(arg1 + 8);
    if (uVar5 != 0) {
        uVar13 = 0;
        uVar16 = uVar5;
        uVar14 = uVar13;
        if (1 < (int32_t)uVar5) {
            do {
                uVar8 = uVar16 & 1;
                uVar16 = uVar16 >> 1;
                uVar14 = uVar14 + 1;
                uVar13 = uVar8 | uVar13 * 2;
            } while (1 < uVar16);
        }
        iVar1 = *(int64_t *)arg1;
        *(uint32_t *)(arg1 + 8) = uVar5 - 1;
        for (; 1 < (int32_t)uVar14; uVar14 = uVar14 - 1) {
            uVar5 = uVar13 & 1;
            uVar13 = (int32_t)uVar13 >> 1;
            iVar1 = *(int64_t *)(iVar1 + 8 + (uint64_t)uVar5 * 8);
        }
        if (iVar1 != 0) {
            if ((uVar13 & 1) == 0) {
                ppiVar11 = *(int64_t ***)(iVar1 + 8);
                *(undefined8 *)(iVar1 + 8) = 0;
            } else {
                ppiVar11 = *(int64_t ***)(iVar1 + 0x10);
                *(undefined8 *)(iVar1 + 0x10) = 0;
            }
            if (ppiVar11 == (int64_t **)0x0) {
                if (*(int64_t *)arg1 == arg2) {
                    *(undefined8 *)arg1 = 0;
                    return;
                }
            } else {
                iVar1 = *(int64_t *)arg2;
                if (iVar1 == 0) {
                    *(int64_t ***)arg1 = ppiVar11;
                } else if (*(int64_t *)(iVar1 + 8) == arg2) {
                    *(int64_t ***)(iVar1 + 8) = ppiVar11;
                } else if (*(int64_t *)(iVar1 + 0x10) == arg2) {
                    *(int64_t ***)(iVar1 + 0x10) = ppiVar11;
                }
                if (*(undefined8 **)(arg2 + 8) != (undefined8 *)0x0) {
                    **(undefined8 **)(arg2 + 8) = ppiVar11;
                }
                if (*(undefined8 **)(arg2 + 0x10) != (undefined8 *)0x0) {
                    **(undefined8 **)(arg2 + 0x10) = ppiVar11;
                }
                *ppiVar11 = *(int64_t **)arg2;
                ppiVar11[1] = *(int64_t **)(arg2 + 8);
                ppiVar11[2] = *(int64_t **)(arg2 + 0x10);
                *(undefined8 *)(arg2 + 0x10) = 0;
                *(undefined8 *)(arg2 + 8) = 0;
                *(undefined8 *)arg2 = 0;
                if (*(int64_t *)(arg1 + 0x10) != 0) {
                    while( true ) {
                        ppiVar12 = ppiVar11;
                        if ((ppiVar11[1] != (int64_t *)0x0) &&
                           (iVar6 = (**(code **)(arg1 + 0x10))(ppiVar11), iVar6 == 0)) {
                            ppiVar12 = (int64_t **)ppiVar11[1];
                        }
                        if ((ppiVar11[2] != (int64_t *)0x0) &&
                           (iVar6 = (**(code **)(arg1 + 0x10))(ppiVar12), iVar6 == 0)) {
                            ppiVar12 = (int64_t **)ppiVar11[2];
                        }
                        piVar2 = *ppiVar11;
                        if (ppiVar12 == ppiVar11) break;
                        piVar3 = ppiVar12[1];
                        piVar4 = ppiVar12[2];
                        if (piVar2 == (int64_t *)0x0) {
                            *(int64_t ***)arg1 = ppiVar12;
                        } else if ((int64_t **)piVar2[1] == ppiVar11) {
                            piVar2[1] = (int64_t)ppiVar12;
                        } else if ((int64_t **)piVar2[2] == ppiVar11) {
                            piVar2[2] = (int64_t)ppiVar12;
                        }
                        if (piVar3 != (int64_t *)0x0) {
                            *piVar3 = (int64_t)ppiVar11;
                        }
                        if (piVar4 != (int64_t *)0x0) {
                            *piVar4 = (int64_t)ppiVar11;
                        }
                        *ppiVar12 = piVar2;
                        ppiVar7 = (int64_t **)ppiVar11[1];
                        ppiVar9 = ppiVar11;
                        ppiVar10 = ppiVar7;
                        if (ppiVar7 == ppiVar12) {
                            ppiVar7 = (int64_t **)ppiVar11[2];
                            ppiVar9 = ppiVar7;
                            ppiVar10 = ppiVar11;
                        }
                        ppiVar12[1] = (int64_t *)ppiVar10;
                        ppiVar12[2] = (int64_t *)ppiVar9;
                        if (ppiVar7 != (int64_t **)0x0) {
                            *ppiVar7 = (int64_t *)ppiVar12;
                        }
                        *ppiVar11 = (int64_t *)ppiVar12;
                        ppiVar11[1] = piVar3;
                        ppiVar11[2] = piVar4;
                    }
                    while ((piVar2 != (int64_t *)0x0 &&
                           (iVar6 = (**(code **)(arg1 + 0x10))(ppiVar11, piVar2), iVar6 != 0))) {
                        ppiVar12 = (int64_t **)*ppiVar11;
                        ppiVar7 = (int64_t **)ppiVar11[1];
                        ppiVar9 = (int64_t **)ppiVar11[2];
                        piVar2 = *ppiVar12;
                        if (piVar2 == (int64_t *)0x0) {
                            *(int64_t ***)arg1 = ppiVar11;
                        } else if ((int64_t **)piVar2[1] == ppiVar12) {
                            piVar2[1] = (int64_t)ppiVar11;
                        } else if ((int64_t **)piVar2[2] == ppiVar12) {
                            piVar2[2] = (int64_t)ppiVar11;
                        }
                        if (ppiVar7 != (int64_t **)0x0) {
                            *ppiVar7 = (int64_t *)ppiVar12;
                        }
                        if (ppiVar9 != (int64_t **)0x0) {
                            *ppiVar9 = (int64_t *)ppiVar12;
                        }
                        *ppiVar11 = piVar2;
                        ppiVar10 = (int64_t **)ppiVar12[1];
                        ppiVar15 = ppiVar12;
                        ppiVar17 = ppiVar10;
                        if (ppiVar10 == ppiVar11) {
                            ppiVar10 = (int64_t **)ppiVar12[2];
                            ppiVar15 = ppiVar10;
                            ppiVar17 = ppiVar12;
                        }
                        ppiVar11[1] = (int64_t *)ppiVar17;
                        ppiVar11[2] = (int64_t *)ppiVar15;
                        if (ppiVar10 != (int64_t **)0x0) {
                            *ppiVar10 = (int64_t *)ppiVar11;
                        }
                        *ppiVar12 = (int64_t *)ppiVar11;
                        ppiVar12[1] = (int64_t *)ppiVar7;
                        ppiVar12[2] = (int64_t *)ppiVar9;
                        piVar2 = *ppiVar11;
                    }
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180181c2e
// Address: 0x180181c2e
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801819b0(int64_t arg1, int64_t arg2, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t **ppiVar7;
    uint32_t uVar8;
    int64_t **ppiVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t **ppiVar12;
    uint32_t uVar13;
    uint32_t uVar14;
    int64_t **ppiVar15;
    uint32_t uVar16;
    int64_t **ppiVar17;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar5 = *(uint32_t *)(arg1 + 8);
    if (uVar5 != 0) {
        uVar13 = 0;
        uVar16 = uVar5;
        uVar14 = uVar13;
        if (1 < (int32_t)uVar5) {
            do {
                uVar8 = uVar16 & 1;
                uVar16 = uVar16 >> 1;
                uVar14 = uVar14 + 1;
                uVar13 = uVar8 | uVar13 * 2;
            } while (1 < uVar16);
        }
        iVar1 = *(int64_t *)arg1;
        *(uint32_t *)(arg1 + 8) = uVar5 - 1;
        for (; 1 < (int32_t)uVar14; uVar14 = uVar14 - 1) {
            uVar5 = uVar13 & 1;
            uVar13 = (int32_t)uVar13 >> 1;
            iVar1 = *(int64_t *)(iVar1 + 8 + (uint64_t)uVar5 * 8);
        }
        if (iVar1 != 0) {
            if ((uVar13 & 1) == 0) {
                ppiVar11 = *(int64_t ***)(iVar1 + 8);
                *(undefined8 *)(iVar1 + 8) = 0;
            } else {
                ppiVar11 = *(int64_t ***)(iVar1 + 0x10);
                *(undefined8 *)(iVar1 + 0x10) = 0;
            }
            if (ppiVar11 == (int64_t **)0x0) {
                if (*(int64_t *)arg1 == arg2) {
                    *(undefined8 *)arg1 = 0;
                    return;
                }
            } else {
                iVar1 = *(int64_t *)arg2;
                if (iVar1 == 0) {
                    *(int64_t ***)arg1 = ppiVar11;
                } else if (*(int64_t *)(iVar1 + 8) == arg2) {
                    *(int64_t ***)(iVar1 + 8) = ppiVar11;
                } else if (*(int64_t *)(iVar1 + 0x10) == arg2) {
                    *(int64_t ***)(iVar1 + 0x10) = ppiVar11;
                }
                if (*(undefined8 **)(arg2 + 8) != (undefined8 *)0x0) {
                    **(undefined8 **)(arg2 + 8) = ppiVar11;
                }
                if (*(undefined8 **)(arg2 + 0x10) != (undefined8 *)0x0) {
                    **(undefined8 **)(arg2 + 0x10) = ppiVar11;
                }
                *ppiVar11 = *(int64_t **)arg2;
                ppiVar11[1] = *(int64_t **)(arg2 + 8);
                ppiVar11[2] = *(int64_t **)(arg2 + 0x10);
                *(undefined8 *)(arg2 + 0x10) = 0;
                *(undefined8 *)(arg2 + 8) = 0;
                *(undefined8 *)arg2 = 0;
                if (*(int64_t *)(arg1 + 0x10) != 0) {
                    while( true ) {
                        ppiVar12 = ppiVar11;
                        if ((ppiVar11[1] != (int64_t *)0x0) &&
                           (iVar6 = (**(code **)(arg1 + 0x10))(ppiVar11), iVar6 == 0)) {
                            ppiVar12 = (int64_t **)ppiVar11[1];
                        }
                        if ((ppiVar11[2] != (int64_t *)0x0) &&
                           (iVar6 = (**(code **)(arg1 + 0x10))(ppiVar12), iVar6 == 0)) {
                            ppiVar12 = (int64_t **)ppiVar11[2];
                        }
                        piVar2 = *ppiVar11;
                        if (ppiVar12 == ppiVar11) break;
                        piVar3 = ppiVar12[1];
                        piVar4 = ppiVar12[2];
                        if (piVar2 == (int64_t *)0x0) {
                            *(int64_t ***)arg1 = ppiVar12;
                        } else if ((int64_t **)piVar2[1] == ppiVar11) {
                            piVar2[1] = (int64_t)ppiVar12;
                        } else if ((int64_t **)piVar2[2] == ppiVar11) {
                            piVar2[2] = (int64_t)ppiVar12;
                        }
                        if (piVar3 != (int64_t *)0x0) {
                            *piVar3 = (int64_t)ppiVar11;
                        }
                        if (piVar4 != (int64_t *)0x0) {
                            *piVar4 = (int64_t)ppiVar11;
                        }
                        *ppiVar12 = piVar2;
                        ppiVar7 = (int64_t **)ppiVar11[1];
                        ppiVar9 = ppiVar11;
                        ppiVar10 = ppiVar7;
                        if (ppiVar7 == ppiVar12) {
                            ppiVar7 = (int64_t **)ppiVar11[2];
                            ppiVar9 = ppiVar7;
                            ppiVar10 = ppiVar11;
                        }
                        ppiVar12[1] = (int64_t *)ppiVar10;
                        ppiVar12[2] = (int64_t *)ppiVar9;
                        if (ppiVar7 != (int64_t **)0x0) {
                            *ppiVar7 = (int64_t *)ppiVar12;
                        }
                        *ppiVar11 = (int64_t *)ppiVar12;
                        ppiVar11[1] = piVar3;
                        ppiVar11[2] = piVar4;
                    }
                    while ((piVar2 != (int64_t *)0x0 &&
                           (iVar6 = (**(code **)(arg1 + 0x10))(ppiVar11, piVar2), iVar6 != 0))) {
                        ppiVar12 = (int64_t **)*ppiVar11;
                        ppiVar7 = (int64_t **)ppiVar11[1];
                        ppiVar9 = (int64_t **)ppiVar11[2];
                        piVar2 = *ppiVar12;
                        if (piVar2 == (int64_t *)0x0) {
                            *(int64_t ***)arg1 = ppiVar11;
                        } else if ((int64_t **)piVar2[1] == ppiVar12) {
                            piVar2[1] = (int64_t)ppiVar11;
                        } else if ((int64_t **)piVar2[2] == ppiVar12) {
                            piVar2[2] = (int64_t)ppiVar11;
                        }
                        if (ppiVar7 != (int64_t **)0x0) {
                            *ppiVar7 = (int64_t *)ppiVar12;
                        }
                        if (ppiVar9 != (int64_t **)0x0) {
                            *ppiVar9 = (int64_t *)ppiVar12;
                        }
                        *ppiVar11 = piVar2;
                        ppiVar10 = (int64_t **)ppiVar12[1];
                        ppiVar15 = ppiVar12;
                        ppiVar17 = ppiVar10;
                        if (ppiVar10 == ppiVar11) {
                            ppiVar10 = (int64_t **)ppiVar12[2];
                            ppiVar15 = ppiVar10;
                            ppiVar17 = ppiVar12;
                        }
                        ppiVar11[1] = (int64_t *)ppiVar17;
                        ppiVar11[2] = (int64_t *)ppiVar15;
                        if (ppiVar10 != (int64_t **)0x0) {
                            *ppiVar10 = (int64_t *)ppiVar11;
                        }
                        *ppiVar12 = (int64_t *)ppiVar11;
                        ppiVar12[1] = (int64_t *)ppiVar7;
                        ppiVar12[2] = (int64_t *)ppiVar9;
                        piVar2 = *ppiVar11;
                    }
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180181c40
// Address: 0x180181c40
// Size: 55 bytes
// ============================================================
undefined8
fcn.180181c40(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t placeholder_4, int64_t var_8h,
             int64_t var_10h, int64_t var_18h, int64_t var_20h)
{
    int32_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    
    if (*(int32_t *)(arg1 + 0x48) < 3) {
        return 0xffffffff;
    }
    iVar2 = *(int64_t *)arg1;
    if ((*(uint8_t *)(arg1 + 0x3c) & 2) == 0) {
        uVar3 = fcn.180174350();
        *(undefined8 *)(arg1 + 0x10) = uVar3;
        *(int64_t *)(arg1 + 0x18) = arg2;
        if ((*(uint32_t *)(arg1 + 0x3c) & 2) == 0) {
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 2;
            *(int32_t *)(*(int64_t *)arg1 + 0x44) = *(int32_t *)(*(int64_t *)arg1 + 0x44) + 1;
        }
        piVar1 = (int32_t *)(iVar2 + 0x130);
        *piVar1 = *piVar1 + 1;
    }
    if ((*(uint8_t *)(arg1 + 0x3c) & 8) == 0) {
        fcn.180173db0(placeholder_4);
    }
    if (arg2 != 0) {
        *(int64_t *)(arg1 + 0x18) = arg2;
    }
    if ((*(uint32_t *)(arg1 + 0x50) & (uint32_t)arg3) == 0) {
        fcn.18018a050(iVar2, *(undefined4 *)(arg1 + 0x48), arg3 & 0xffffffff);
        *(uint32_t *)(arg1 + 0x50) = *(uint32_t *)(arg1 + 0x50) | (uint32_t)arg3;
    }
    return 0;
}

// ============================================================
// Function: FUN_180181c77
// Address: 0x180181c77
// Size: 87 bytes
// ============================================================
undefined8
fcn.180181c40(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t placeholder_4, int64_t var_8h,
             int64_t var_10h, int64_t var_18h, int64_t var_20h)
{
    int32_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    
    if (*(int32_t *)(arg1 + 0x48) < 3) {
        return 0xffffffff;
    }
    iVar2 = *(int64_t *)arg1;
    if ((*(uint8_t *)(arg1 + 0x3c) & 2) == 0) {
        uVar3 = fcn.180174350();
        *(undefined8 *)(arg1 + 0x10) = uVar3;
        *(int64_t *)(arg1 + 0x18) = arg2;
        if ((*(uint32_t *)(arg1 + 0x3c) & 2) == 0) {
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 2;
            *(int32_t *)(*(int64_t *)arg1 + 0x44) = *(int32_t *)(*(int64_t *)arg1 + 0x44) + 1;
        }
        piVar1 = (int32_t *)(iVar2 + 0x130);
        *piVar1 = *piVar1 + 1;
    }
    if ((*(uint8_t *)(arg1 + 0x3c) & 8) == 0) {
        fcn.180173db0(placeholder_4);
    }
    if (arg2 != 0) {
        *(int64_t *)(arg1 + 0x18) = arg2;
    }
    if ((*(uint32_t *)(arg1 + 0x50) & (uint32_t)arg3) == 0) {
        fcn.18018a050(iVar2, *(undefined4 *)(arg1 + 0x48), arg3 & 0xffffffff);
        *(uint32_t *)(arg1 + 0x50) = *(uint32_t *)(arg1 + 0x50) | (uint32_t)arg3;
    }
    return 0;
}

// ============================================================
// Function: FUN_180181cce
// Address: 0x180181cce
// Size: 40 bytes
// ============================================================
undefined8
fcn.180181c40(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t placeholder_4, int64_t var_8h,
             int64_t var_10h, int64_t var_18h, int64_t var_20h)
{
    int32_t *piVar1;
    int64_t iVar2;
    undefined8 uVar3;
    
    if (*(int32_t *)(arg1 + 0x48) < 3) {
        return 0xffffffff;
    }
    iVar2 = *(int64_t *)arg1;
    if ((*(uint8_t *)(arg1 + 0x3c) & 2) == 0) {
        uVar3 = fcn.180174350();
        *(undefined8 *)(arg1 + 0x10) = uVar3;
        *(int64_t *)(arg1 + 0x18) = arg2;
        if ((*(uint32_t *)(arg1 + 0x3c) & 2) == 0) {
            *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) | 2;
            *(int32_t *)(*(int64_t *)arg1 + 0x44) = *(int32_t *)(*(int64_t *)arg1 + 0x44) + 1;
        }
        piVar1 = (int32_t *)(iVar2 + 0x130);
        *piVar1 = *piVar1 + 1;
    }
    if ((*(uint8_t *)(arg1 + 0x3c) & 8) == 0) {
        fcn.180173db0(placeholder_4);
    }
    if (arg2 != 0) {
        *(int64_t *)(arg1 + 0x18) = arg2;
    }
    if ((*(uint32_t *)(arg1 + 0x50) & (uint32_t)arg3) == 0) {
        fcn.18018a050(iVar2, *(undefined4 *)(arg1 + 0x48), arg3 & 0xffffffff);
        *(uint32_t *)(arg1 + 0x50) = *(uint32_t *)(arg1 + 0x50) | (uint32_t)arg3;
    }
    return 0;
}

// ============================================================
// Function: FUN_180181d00
// Address: 0x180181d00
// Size: 71 bytes
// ============================================================
undefined8 fcn.180181d00(int64_t arg1)
{
    undefined8 uStack_48;
    undefined8 uStack_40;
    undefined8 uStack_38;
    undefined8 uStack_30;
    int64_t iStack_28;
    uint64_t uStack_20;
    int64_t var_18h;
    
    uStack_48 = 0;
    uStack_40 = 0;
    uStack_38 = 0;
    _var_18h = ZEXT816(0);
    uStack_30 = 0x180181d50;
    uStack_20 = (uint64_t)*(uint32_t *)(arg1 + 0x44);
    iStack_28 = arg1;
    fcn.1801823b0(*(undefined8 *)arg1, &uStack_48);
    return 0;
}

// ============================================================
// Function: FUN_180181d70
// Address: 0x180181d70
// Size: 135 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180181d70(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t var_8h;
    
    if ((2 < *(int32_t *)(arg1 + 0x48)) && ((*(uint8_t *)(arg1 + 0x3c) & 2) != 0)) {
        uVar1 = *(uint32_t *)(arg1 + 0x50);
        if (((uint32_t)arg2 & uVar1) != 0) {
            func_0x00018018a1f0(*(undefined8 *)arg1, *(int32_t *)(arg1 + 0x48), arg2 & 0xffffffff);
            *(uint32_t *)(arg1 + 0x50) = *(uint32_t *)(arg1 + 0x50) & ~(uint32_t)arg2;
            uVar1 = *(uint32_t *)(arg1 + 0x50);
        }
        if (uVar1 == 0) {
            *(int32_t *)(*(int64_t *)arg1 + 0x130) = *(int32_t *)(*(int64_t *)arg1 + 0x130) + -1;
            if ((*(uint32_t *)(arg1 + 0x3c) & 2) != 0) {
                *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xfffffffd;
                *(int32_t *)(*(int64_t *)arg1 + 0x44) = *(int32_t *)(*(int64_t *)arg1 + 0x44) + -1;
            }
            if ((*(uint32_t *)(arg1 + 0x3c) & 4) != 0) {
                *(uint32_t *)(arg1 + 0x3c) = *(uint32_t *)(arg1 + 0x3c) & 0xfffffffb;
                *(int32_t *)(*(int64_t *)arg1 + 0x48) = *(int32_t *)(*(int64_t *)arg1 + 0x48) + -1;
            }
        }
        return 0;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180181e00
// Address: 0x180181e00
// Size: 114 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t * fcn.180181e00(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t in_stack_00000028;
    
    piVar1 = (int64_t *)fcn.180181410(arg1, arg2 & 0xffffffff, unaff_RBX);
    if (piVar1 == (int64_t *)0x0) {
        piVar1 = (int64_t *)fcn.1801813b0(0x1a0);
        func_0x000180173bd0(piVar1);
        *(undefined4 *)(piVar1 + 1) = 1;
        *piVar1 = arg1;
        *(int32_t *)(piVar1 + 9) = (int32_t)arg2;
        *(int64_t **)(*(int64_t *)(arg1 + 0x118) + (int64_t)(int32_t)arg2 * 8) = piVar1;
    }
    if ((*(uint8_t *)((int64_t)piVar1 + 0x3c) & 8) == 0) {
        fcn.180173db0(in_stack_00000028);
    }
    return piVar1;
}

// ============================================================
// Function: FUN_180181e80
// Address: 0x180181e80
// Size: 616 bytes
// ============================================================
void fcn.180181e80(int64_t arg1)
{
    undefined8 *arg1_00;
    undefined8 *puVar1;
    int64_t *piVar2;
    undefined8 *puVar3;
    int64_t iVar4;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int32_t iVar5;
    int32_t iVar6;
    
    iVar6 = 0;
    *(undefined8 *)(arg1 + 0x50) = 0;
    *(undefined8 *)(arg1 + 0x58) = 0;
    *(undefined8 *)(arg1 + 0x60) = 0;
    *(undefined8 *)(arg1 + 0x68) = 0;
    *(undefined8 *)(arg1 + 0x70) = 0;
    *(undefined8 *)(arg1 + 0x78) = 0;
    *(undefined8 *)(arg1 + 0x80) = 0;
    *(undefined8 *)(arg1 + 0x88) = 0;
    *(undefined8 *)(arg1 + 0x90) = 0;
    *(undefined8 *)(arg1 + 0x98) = 0;
    *(undefined8 *)(arg1 + 0xa0) = 0;
    iVar5 = iVar6;
    if (*(int64_t *)(arg1 + 0x128) != 0) {
        do {
            if (*(int64_t *)(*(int64_t *)(arg1 + 0x118) + (int64_t)iVar5 * 8) != 0) {
                func_0x000180173980();
            }
            iVar5 = iVar5 + 1;
        } while ((uint64_t)(int64_t)iVar5 < *(uint64_t *)(arg1 + 0x128));
    }
    if (*(int64_t *)(arg1 + 0x118) != 0) {
        fcn.180180fe0(*(int64_t *)(arg1 + 0x118));
        *(undefined8 *)(arg1 + 0x118) = 0;
    }
    puVar1 = (undefined8 *)(arg1 + 200);
    *(undefined8 *)(arg1 + 0x128) = 0;
    *(undefined8 *)(arg1 + 0x120) = 0;
    puVar3 = (undefined8 *)*puVar1;
    while (puVar3 != puVar1) {
        arg1_00 = puVar3 + -9;
        puVar3 = (undefined8 *)*puVar3;
        if (arg1_00 != (undefined8 *)0x0) {
            fcn.180180fe0((int64_t)arg1_00);
        }
    }
    piVar2 = (int64_t *)(arg1 + 0xe0);
    *puVar1 = puVar1;
    *(undefined8 **)(arg1 + 0xd0) = puVar1;
    iVar4 = *piVar2;
    while (iVar4 != 0) {
        fcn.1801819b0((int64_t)piVar2, iVar4, unaff_RSI, unaff_RBP);
        if (iVar4 + -0x50 != 0) {
            fcn.180180fe0(iVar4 + -0x50);
        }
        iVar4 = *piVar2;
    }
    *piVar2 = 0;
    *(undefined4 *)(arg1 + 0xe8) = 0;
    *(undefined8 *)(arg1 + 0xf0) = 0;
    piVar2 = (int64_t *)(arg1 + 0xf8);
    iVar4 = *piVar2;
    while (iVar4 != 0) {
        fcn.1801819b0((int64_t)piVar2, iVar4, unaff_RSI, unaff_RBP);
        if (iVar4 + -0x50 != 0) {
            fcn.180180fe0(iVar4 + -0x50);
        }
        iVar4 = *piVar2;
    }
    *piVar2 = 0;
    *(undefined4 *)(arg1 + 0x100) = 0;
    *(undefined8 *)(arg1 + 0x108) = 0;
    if (*(int64_t *)(arg1 + 0xb8) != 0) {
        do {
            iVar4 = *(int64_t *)(*(int64_t *)(arg1 + 0xa8) + (int64_t)iVar6 * 8);
            if (iVar4 != 0) {
                fcn.180180fe0(iVar4);
            }
            iVar6 = iVar6 + 1;
        } while ((uint64_t)(int64_t)iVar6 < *(uint64_t *)(arg1 + 0xb8));
    }
    if (*(int64_t *)(arg1 + 0xa8) != 0) {
        fcn.180180fe0(*(int64_t *)(arg1 + 0xa8));
        *(undefined8 *)(arg1 + 0xa8) = 0;
    }
    *(undefined8 *)(arg1 + 0xb8) = 0;
    *(undefined8 *)(arg1 + 0xb0) = 0;
    if ((*(int64_t *)(arg1 + 0x138) != 0) && (*(int64_t *)(arg1 + 0x140) != 0)) {
        fcn.180180fe0(*(int64_t *)(arg1 + 0x138));
        *(undefined8 *)(arg1 + 0x138) = 0;
        *(undefined8 *)(arg1 + 0x140) = 0;
    }
    func_0x00018018a170(arg1);
    (*(code *)0x699f1c)(arg1 + 0x178);
    if (-1 < *(int32_t *)(arg1 + 0x154)) {
        (*(code *)0x8000000000000003)((int64_t)*(int32_t *)(arg1 + 0x154));
    }
    *(undefined8 *)(arg1 + 0x150) = 0xffffffffffffffff;
    if (*(int64_t *)(arg1 + 0x158) != 0) {
        fcn.180180fe0(*(int64_t *)(arg1 + 0x158));
        *(undefined8 *)(arg1 + 0x158) = 0;
    }
    *(undefined8 *)(arg1 + 0x168) = 0;
    *(undefined8 *)(arg1 + 0x160) = 0;
    *(undefined8 *)(arg1 + 0x170) = 0;
    (*(code *)0x699f34)(arg1 + 0x178);
    // WARNING: Treating indirect jump as call
    (*(code *)0x699f4c)(arg1 + 0x178);
    return;
}

