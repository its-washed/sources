// Chunk 177 - 50 functions

// ============================================================
// Function: FUN_180234b20
// Address: 0x180234b20
// Size: 29 bytes
// ============================================================
void fcn.180234b20(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_60h, int64_t arg_70h, int64_t arg_78h, int64_t arg_90h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t iVar4;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar5;
    undefined8 uStackX_8;
    undefined8 auStackX_10 [3];
    
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    iVar5 = 0x1804e24e8;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 0x10) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar2) = 0x18026177e;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_90h + iVar3 + iVar2) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_10 + iVar3 + iVar2;
    *(undefined8 *)((int64_t)&arg_70h + iVar3 + iVar2) = 0;
    *(undefined *)((int64_t)&arg_78h + iVar3 + iVar2) = 0;
    iVar4 = (int64_t)&arg_70h + iVar3 + iVar2;
    if (in_RCX != 0) {
        iVar4 = in_RCX;
    }
    if ((iVar4 == 0) || (iVar5 == 0)) {
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261804;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026181c;
        func_0x0001802295a0(0x1804e6d08, 0x73, 0x1804e6cf0);
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026182e;
        func_0x0001802296d0(0xd, 0xc0102, 0);
    } else {
        *(undefined8 *)((int64_t)&arg_60h + iVar3 + iVar2) = 0;
        *(undefined8 *)((int64_t)&arg_58h + iVar3 + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_50h + iVar3 + iVar2) = 0;
        *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2) = (int64_t)&arg_78h + iVar3 + iVar2;
        *(undefined *)((int64_t)&arg_40h + iVar3 + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_38h + iVar3 + iVar2) = 0;
        *(undefined4 *)((int64_t)&arg_30h + iVar3 + iVar2) = 0xffffffff;
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617e9;
        iVar1 = func_0x0001802629a0(iVar4);
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617f8;
            func_0x000180261290(iVar4, iVar5);
        }
    }
    *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261841;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_90h + iVar3 + iVar2) ^ (int64_t)auStackX_10 + iVar3 + iVar2);
    return;
}

// ============================================================
// Function: FUN_180234b40
// Address: 0x180234b40
// Size: 29 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.180234b40(int64_t arg_58h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    int64_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar6;
    undefined8 unaff_R14;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x1802642ca;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = iVar4 + iVar3 + 0x20;
    uVar6 = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar4 + iVar3) = in_RCX;
    *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + 0x20 + -0x20) = unaff_RSI;
    *(undefined8 *)(&stack0x00000030 + iVar4 + iVar3) = 0x1802645e2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RDX != (int64_t *)0x0) && (*in_RDX == 0)) {
        *(undefined4 *)((int64_t)&arg_58h + iVar3 + iVar1 + -0x20) = uVar6;
        *(undefined8 *)((int64_t)&arg_98h + iVar3 + iVar1 + -0x20) = unaff_RDI;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026461d;
        uVar2 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)((int64_t)&arg_88h + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)((int64_t)&arg_90h + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
        if ((int32_t)uVar2 < 1) {
            return (uint64_t)uVar2;
        }
        *(undefined8 *)((int64_t)&arg_a0h + iVar3 + iVar1 + -0x20) = unaff_R14;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026464d;
        iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_58h + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000060 + iVar3 + iVar1 + -0x20));
        if (iVar4 == 0) {
            uVar5 = 0xffffffff;
        } else {
            *(int64_t *)((int64_t)&arg_90h + iVar3 + iVar1 + -0x20) = iVar4;
            *(undefined4 *)((int64_t)&arg_58h + iVar3 + iVar1 + -0x20) = uVar6;
            *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026468d;
            fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_88h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_90h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
            uVar5 = (uint64_t)uVar2;
            *in_RDX = iVar4;
        }
        return uVar5;
    }
    *(undefined4 *)((int64_t)&arg_58h + iVar3 + iVar1 + -0x20) = uVar6;
    *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x1802646a8;
    uVar5 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_88h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)((int64_t)&arg_90h + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
    return uVar5;
}

// ============================================================
// Function: FUN_180234b60
// Address: 0x180234b60
// Size: 160 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

int32_t fcn.180234b60(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 in_RCX;
    int32_t iVar4;
    int32_t iVar5;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180234b7a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar4 = 0;
    iVar5 = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234b8c;
    iVar1 = func_0x000180222010();
    if (0 < iVar1) {
        do {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234b9a;
            uVar3 = func_0x000180222340(in_RCX, iVar5);
            *(undefined8 *)((int64_t)&arg_38h + iVar2) = uVar3;
            *(undefined4 *)((int64_t)&var_18h + iVar2) = 0xffffffff;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234bc1;
            iVar1 = fcn.180263ea0(*(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar2), *(int64_t *)((int64_t)&arg_50h + iVar2), 
                                  *(int64_t *)(&stack0x000000c8 + iVar2));
            if ((iVar1 < 0) || (0x7fffffff - iVar1 < iVar4)) {
                return -1;
            }
            iVar4 = iVar4 + iVar1;
            iVar5 = iVar5 + 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234bde;
            iVar1 = func_0x000180222010(in_RCX);
        } while (iVar5 < iVar1);
    }
    return iVar4;
}

// ============================================================
// Function: FUN_180234c00
// Address: 0x180234c00
// Size: 22 bytes
// ============================================================
void fcn.180234c00(int64_t param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_1 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x180221d60;
        iVar2 = fcn.18045a350();
        uVar1 = *(undefined8 *)(param_1 + 8);
        *(undefined8 *)((int64_t)auStackX_18 + -iVar2 + iVar3) = 0x180221d7c;
        fcn.180224990(uVar1, 0x1804bf768, 0x1ce);
        *(undefined8 *)((int64_t)auStackX_18 + -iVar2 + iVar3) = 0x180221d91;
        fcn.180224990(param_1, 0x1804bf768, 0x1cf);
    }
    return;
}

// ============================================================
// Function: FUN_180234c20
// Address: 0x180234c20
// Size: 29 bytes
// ============================================================
void fcn.180234c20(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_88h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *in_RCX;
    code *pcVar6;
    int32_t iVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar8;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 auStackX_18 [2];
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    pcVar6 = (code *)0x180234890;
    if (in_RCX != (int32_t *)0x0) {
        *(undefined8 *)(&stack0x00000048 + iVar5) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + 8) = unaff_RSI;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5) = 0x180222069;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_50h + iVar4 + iVar5) = unaff_RBX;
        iVar7 = 0;
        *(undefined8 *)((int64_t)&arg_60h + iVar4 + iVar5) = unaff_R14;
        if (0 < *in_RCX) {
            *(undefined8 *)((int64_t)&arg_58h + iVar4 + iVar5) = unaff_RDI;
            iVar8 = 0;
            do {
                iVar1 = *(int64_t *)(iVar8 + *(int64_t *)(in_RCX + 2));
                if (iVar1 != 0) {
                    pcVar2 = *(code **)(in_RCX + 8);
                    if (pcVar2 == (code *)0x0) {
                        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1802220b2;
                        (*pcVar6)();
                    } else {
                        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1802220ae;
                        (*pcVar2)(pcVar6, iVar1);
                    }
                }
                iVar7 = iVar7 + 1;
                iVar8 = iVar8 + 8;
            } while (iVar7 < *in_RCX);
        }
        uVar3 = *(undefined8 *)(in_RCX + 2);
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1802220d7;
        fcn.180224990(uVar3, 0x1804bf768, 0x1ce);
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar5) = 0x1802220ec;
        fcn.180224990(in_RCX, 0x1804bf768, 0x1cf);
    }
    return;
}

// ============================================================
// Function: FUN_180234c40
// Address: 0x180234c40
// Size: 189 bytes
// ============================================================
undefined4
fcn.180234c40(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t *piVar3;
    uint8_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    undefined8 unaff_RBX;
    uint8_t *puVar14;
    undefined8 unaff_RSI;
    uint8_t *puVar15;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x180234c55;
    var_8h = arg1;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar2 = *(undefined8 *)(arg1 + 0x18);
    iVar7 = -1;
    *(undefined4 *)((int64_t)&arg_78h + iVar8) = 0;
    *(undefined4 *)((int64_t)&arg_70h + iVar8) = 0xffffffff;
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234c8b;
    fcn.180224990(uVar2, 0x1804e2570, 0x13e);
    uVar2 = *(undefined8 *)arg1;
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234c97;
    iVar5 = fcn.180222010(uVar2);
    if (iVar5 == 0) {
        *(undefined4 *)(arg1 + 0x20) = 0;
        return 1;
    }
    *(undefined8 *)((int64_t)&var_18h + iVar8) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234cb9;
    iVar9 = fcn.180221f20();
    *(int64_t *)(&stack0x00000000 + iVar8) = iVar9;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234ccb;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar8), *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234ce3;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar8), *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                      *(int64_t *)((int64_t)&arg_30h + iVar8));
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234cf5;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar8));
    } else {
        uVar2 = *(undefined8 *)arg1;
        *(undefined8 *)((int64_t)&arg_30h + iVar8) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_28h + iVar8) = unaff_RSI;
        iVar5 = 0;
        *(undefined4 *)((int64_t)&arg_68h + iVar8) = 0;
        *(undefined8 *)((int64_t)&var_20h + iVar8) = unaff_R12;
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d1a;
        iVar6 = fcn.180222010(uVar2);
        if (0 < iVar6) {
            do {
                uVar2 = *(undefined8 *)arg1;
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d2c;
                iVar10 = fcn.180222340(uVar2, iVar5);
                if (*(int32_t *)(iVar10 + 0x10) != iVar7) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d39;
                    iVar11 = fcn.180221f20();
                    if (iVar11 == 0) goto code_r0x000180235027;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d50;
                    iVar7 = fcn.180222110(*(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                                          *(int64_t *)((int64_t)&var_18h + iVar8), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                          *(int64_t *)(&stack0x00000038 + iVar8));
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234ef9;
                        fcn.180221d50(iVar11);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234efe;
                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
                        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f16;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8));
                        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f28;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar8));
                        goto code_r0x000180235027;
                    }
                    *(undefined4 *)((int64_t)&arg_70h + iVar8) = *(undefined4 *)(iVar10 + 0x10);
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d6e;
                piVar12 = (int64_t *)fcn.180260b40(*(int64_t *)((int64_t)&var_18h + iVar8));
                if (piVar12 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f9d;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234fb5;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234fc7;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar8));
                    goto code_r0x000180235027;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d82;
                iVar11 = fcn.1802983b0(*(int64_t *)(&stack0x00000000 + iVar8));
                *piVar12 = iVar11;
                if (iVar11 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f69;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f81;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f93;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar8));
                    goto code_r0x000180235027;
                }
                piVar3 = (int32_t *)piVar12[1];
                uVar1 = *(undefined4 *)(*(int64_t *)(iVar10 + 8) + 4);
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d9e;
                uVar13 = fcn.180261a10(uVar1);
                if ((uVar13 & 0x2956) == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234db0;
                    iVar7 = fcn.180296580(*(int64_t *)(&stack0x00000000 + iVar8), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                                          *(int64_t *)((int64_t)&var_18h + iVar8));
                    if (iVar7 == 0) goto code_r0x000180235027;
                } else {
                    piVar3[1] = 0xc;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234dd0;
                    iVar7 = fcn.1802a7f60(*(int64_t *)(&stack0x00000000 + iVar8), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                                          *(int64_t *)(&stack0x00000038 + iVar8));
                    *piVar3 = iVar7;
                    if (iVar7 == -1) goto code_r0x000180235027;
                    puVar14 = *(uint8_t **)(piVar3 + 2);
                    for (; 0 < iVar7; iVar7 = iVar7 + -1) {
                        uVar4 = *puVar14;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234dfd;
                        iVar5 = fcn.180275490(uVar4, 8);
                        if (iVar5 == 0) break;
                        puVar14 = puVar14 + 1;
                    }
                    if (0 < iVar7) {
                        puVar15 = puVar14 + (int64_t)iVar7 + -1;
                        do {
                            uVar4 = *puVar15;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234e2d;
                            iVar5 = fcn.180275490(uVar4, 8);
                            if (iVar5 == 0) break;
                            puVar15 = puVar15 + -1;
                            iVar7 = iVar7 + -1;
                        } while (0 < iVar7);
                    }
                    puVar15 = *(uint8_t **)(piVar3 + 2);
                    iVar5 = 0;
                    if (0 < iVar7) {
                        do {
                            uVar4 = *puVar14;
                            if ((uVar4 & 0x80) == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234e5f;
                                iVar6 = fcn.180275490(uVar4, 8);
                                if (iVar6 == 0) {
                                    uVar4 = *puVar14;
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234e91;
                                    uVar4 = fcn.1802754c0(uVar4);
                                    *puVar15 = uVar4;
                                    goto code_r0x000180234e94;
                                }
                                *puVar15 = 0x20;
                                do {
                                    uVar4 = puVar14[1];
                                    puVar14 = puVar14 + 1;
                                    iVar5 = iVar5 + 1;
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234e83;
                                    iVar6 = fcn.180275490(uVar4, 8);
                                } while (iVar6 != 0);
                            } else {
                                *puVar15 = uVar4;
code_r0x000180234e94:
                                puVar14 = puVar14 + 1;
                                iVar5 = iVar5 + 1;
                            }
                            puVar15 = puVar15 + 1;
                        } while (iVar5 < iVar7);
                    }
                    arg1 = *(undefined8 *)((int64_t)&arg_60h + iVar8);
                    iVar5 = *(int32_t *)((int64_t)&arg_68h + iVar8);
                    *piVar3 = (int32_t)puVar15 - piVar3[2];
                    iVar9 = *(int64_t *)(&stack0x00000000 + iVar8);
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234ec8;
                iVar7 = fcn.180222110(*(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar8), *(int64_t *)(&stack0x00000038 + iVar8));
                if (iVar7 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f35;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f4d;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f5f;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar8));
                    goto code_r0x000180235027;
                }
                uVar2 = *(undefined8 *)arg1;
                iVar5 = iVar5 + 1;
                *(int32_t *)((int64_t)&arg_68h + iVar8) = iVar5;
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234edd;
                iVar7 = fcn.180222010(uVar2);
                if (iVar7 <= iVar5) break;
                iVar7 = *(int32_t *)((int64_t)&arg_70h + iVar8);
            } while( true );
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234fd3;
        iVar7 = fcn.180234b60(*(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                              *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8));
        if (-1 < iVar7) {
            *(int32_t *)(arg1 + 0x20) = iVar7;
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234ff2;
            iVar10 = fcn.1802248d0(*(int64_t *)(&stack0x00000000 + iVar8), 
                                   *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
            *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8) = iVar10;
            if (iVar10 != 0) {
                *(int64_t *)(arg1 + 0x18) = iVar10;
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18023500d;
                fcn.180234b60(*(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                              *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8));
                *(undefined4 *)((int64_t)&arg_78h + iVar8) = 1;
            }
        }
    }
code_r0x000180235027:
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180235036;
    fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180235045;
    fcn.180222290(iVar9, 0x180196ec0);
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180235054;
    fcn.180222050(*(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                  *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8), 
                  *(int64_t *)((int64_t)&arg_60h + iVar8));
    return *(undefined4 *)((int64_t)&arg_78h + iVar8);
}

// ============================================================
// Function: FUN_180234cfd
// Address: 0x180234cfd
// Size: 810 bytes
// ============================================================
undefined4
fcn.180234c40(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t *piVar3;
    uint8_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    undefined8 unaff_RBX;
    uint8_t *puVar14;
    undefined8 unaff_RSI;
    uint8_t *puVar15;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x180234c55;
    var_8h = arg1;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar2 = *(undefined8 *)(arg1 + 0x18);
    iVar7 = -1;
    *(undefined4 *)((int64_t)&arg_78h + iVar8) = 0;
    *(undefined4 *)((int64_t)&arg_70h + iVar8) = 0xffffffff;
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234c8b;
    fcn.180224990(uVar2, 0x1804e2570, 0x13e);
    uVar2 = *(undefined8 *)arg1;
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234c97;
    iVar5 = fcn.180222010(uVar2);
    if (iVar5 == 0) {
        *(undefined4 *)(arg1 + 0x20) = 0;
        return 1;
    }
    *(undefined8 *)((int64_t)&var_18h + iVar8) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234cb9;
    iVar9 = fcn.180221f20();
    *(int64_t *)(&stack0x00000000 + iVar8) = iVar9;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234ccb;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar8), *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234ce3;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar8), *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                      *(int64_t *)((int64_t)&arg_30h + iVar8));
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234cf5;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar8));
    } else {
        uVar2 = *(undefined8 *)arg1;
        *(undefined8 *)((int64_t)&arg_30h + iVar8) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_28h + iVar8) = unaff_RSI;
        iVar5 = 0;
        *(undefined4 *)((int64_t)&arg_68h + iVar8) = 0;
        *(undefined8 *)((int64_t)&var_20h + iVar8) = unaff_R12;
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d1a;
        iVar6 = fcn.180222010(uVar2);
        if (0 < iVar6) {
            do {
                uVar2 = *(undefined8 *)arg1;
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d2c;
                iVar10 = fcn.180222340(uVar2, iVar5);
                if (*(int32_t *)(iVar10 + 0x10) != iVar7) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d39;
                    iVar11 = fcn.180221f20();
                    if (iVar11 == 0) goto code_r0x000180235027;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d50;
                    iVar7 = fcn.180222110(*(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                                          *(int64_t *)((int64_t)&var_18h + iVar8), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                          *(int64_t *)(&stack0x00000038 + iVar8));
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234ef9;
                        fcn.180221d50(iVar11);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234efe;
                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
                        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f16;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8));
                        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f28;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar8));
                        goto code_r0x000180235027;
                    }
                    *(undefined4 *)((int64_t)&arg_70h + iVar8) = *(undefined4 *)(iVar10 + 0x10);
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d6e;
                piVar12 = (int64_t *)fcn.180260b40(*(int64_t *)((int64_t)&var_18h + iVar8));
                if (piVar12 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f9d;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234fb5;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234fc7;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar8));
                    goto code_r0x000180235027;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d82;
                iVar11 = fcn.1802983b0(*(int64_t *)(&stack0x00000000 + iVar8));
                *piVar12 = iVar11;
                if (iVar11 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f69;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f81;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f93;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar8));
                    goto code_r0x000180235027;
                }
                piVar3 = (int32_t *)piVar12[1];
                uVar1 = *(undefined4 *)(*(int64_t *)(iVar10 + 8) + 4);
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d9e;
                uVar13 = fcn.180261a10(uVar1);
                if ((uVar13 & 0x2956) == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234db0;
                    iVar7 = fcn.180296580(*(int64_t *)(&stack0x00000000 + iVar8), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                                          *(int64_t *)((int64_t)&var_18h + iVar8));
                    if (iVar7 == 0) goto code_r0x000180235027;
                } else {
                    piVar3[1] = 0xc;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234dd0;
                    iVar7 = fcn.1802a7f60(*(int64_t *)(&stack0x00000000 + iVar8), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                                          *(int64_t *)(&stack0x00000038 + iVar8));
                    *piVar3 = iVar7;
                    if (iVar7 == -1) goto code_r0x000180235027;
                    puVar14 = *(uint8_t **)(piVar3 + 2);
                    for (; 0 < iVar7; iVar7 = iVar7 + -1) {
                        uVar4 = *puVar14;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234dfd;
                        iVar5 = fcn.180275490(uVar4, 8);
                        if (iVar5 == 0) break;
                        puVar14 = puVar14 + 1;
                    }
                    if (0 < iVar7) {
                        puVar15 = puVar14 + (int64_t)iVar7 + -1;
                        do {
                            uVar4 = *puVar15;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234e2d;
                            iVar5 = fcn.180275490(uVar4, 8);
                            if (iVar5 == 0) break;
                            puVar15 = puVar15 + -1;
                            iVar7 = iVar7 + -1;
                        } while (0 < iVar7);
                    }
                    puVar15 = *(uint8_t **)(piVar3 + 2);
                    iVar5 = 0;
                    if (0 < iVar7) {
                        do {
                            uVar4 = *puVar14;
                            if ((uVar4 & 0x80) == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234e5f;
                                iVar6 = fcn.180275490(uVar4, 8);
                                if (iVar6 == 0) {
                                    uVar4 = *puVar14;
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234e91;
                                    uVar4 = fcn.1802754c0(uVar4);
                                    *puVar15 = uVar4;
                                    goto code_r0x000180234e94;
                                }
                                *puVar15 = 0x20;
                                do {
                                    uVar4 = puVar14[1];
                                    puVar14 = puVar14 + 1;
                                    iVar5 = iVar5 + 1;
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234e83;
                                    iVar6 = fcn.180275490(uVar4, 8);
                                } while (iVar6 != 0);
                            } else {
                                *puVar15 = uVar4;
code_r0x000180234e94:
                                puVar14 = puVar14 + 1;
                                iVar5 = iVar5 + 1;
                            }
                            puVar15 = puVar15 + 1;
                        } while (iVar5 < iVar7);
                    }
                    arg1 = *(undefined8 *)((int64_t)&arg_60h + iVar8);
                    iVar5 = *(int32_t *)((int64_t)&arg_68h + iVar8);
                    *piVar3 = (int32_t)puVar15 - piVar3[2];
                    iVar9 = *(int64_t *)(&stack0x00000000 + iVar8);
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234ec8;
                iVar7 = fcn.180222110(*(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar8), *(int64_t *)(&stack0x00000038 + iVar8));
                if (iVar7 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f35;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f4d;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f5f;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar8));
                    goto code_r0x000180235027;
                }
                uVar2 = *(undefined8 *)arg1;
                iVar5 = iVar5 + 1;
                *(int32_t *)((int64_t)&arg_68h + iVar8) = iVar5;
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234edd;
                iVar7 = fcn.180222010(uVar2);
                if (iVar7 <= iVar5) break;
                iVar7 = *(int32_t *)((int64_t)&arg_70h + iVar8);
            } while( true );
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234fd3;
        iVar7 = fcn.180234b60(*(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                              *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8));
        if (-1 < iVar7) {
            *(int32_t *)(arg1 + 0x20) = iVar7;
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234ff2;
            iVar10 = fcn.1802248d0(*(int64_t *)(&stack0x00000000 + iVar8), 
                                   *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
            *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8) = iVar10;
            if (iVar10 != 0) {
                *(int64_t *)(arg1 + 0x18) = iVar10;
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18023500d;
                fcn.180234b60(*(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                              *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8));
                *(undefined4 *)((int64_t)&arg_78h + iVar8) = 1;
            }
        }
    }
code_r0x000180235027:
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180235036;
    fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180235045;
    fcn.180222290(iVar9, 0x180196ec0);
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180235054;
    fcn.180222050(*(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                  *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8), 
                  *(int64_t *)((int64_t)&arg_60h + iVar8));
    return *(undefined4 *)((int64_t)&arg_78h + iVar8);
}

// ============================================================
// Function: FUN_180235027
// Address: 0x180235027
// Size: 68 bytes
// ============================================================
undefined4
fcn.180234c40(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t *piVar3;
    uint8_t uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    undefined8 unaff_RBX;
    uint8_t *puVar14;
    undefined8 unaff_RSI;
    uint8_t *puVar15;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x180234c55;
    var_8h = arg1;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar2 = *(undefined8 *)(arg1 + 0x18);
    iVar7 = -1;
    *(undefined4 *)((int64_t)&arg_78h + iVar8) = 0;
    *(undefined4 *)((int64_t)&arg_70h + iVar8) = 0xffffffff;
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234c8b;
    fcn.180224990(uVar2, 0x1804e2570, 0x13e);
    uVar2 = *(undefined8 *)arg1;
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234c97;
    iVar5 = fcn.180222010(uVar2);
    if (iVar5 == 0) {
        *(undefined4 *)(arg1 + 0x20) = 0;
        return 1;
    }
    *(undefined8 *)((int64_t)&var_18h + iVar8) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234cb9;
    iVar9 = fcn.180221f20();
    *(int64_t *)(&stack0x00000000 + iVar8) = iVar9;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234ccb;
        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar8), *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234ce3;
        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar8), *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                      *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                      *(int64_t *)((int64_t)&arg_30h + iVar8));
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234cf5;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar8));
    } else {
        uVar2 = *(undefined8 *)arg1;
        *(undefined8 *)((int64_t)&arg_30h + iVar8) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_28h + iVar8) = unaff_RSI;
        iVar5 = 0;
        *(undefined4 *)((int64_t)&arg_68h + iVar8) = 0;
        *(undefined8 *)((int64_t)&var_20h + iVar8) = unaff_R12;
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d1a;
        iVar6 = fcn.180222010(uVar2);
        if (0 < iVar6) {
            do {
                uVar2 = *(undefined8 *)arg1;
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d2c;
                iVar10 = fcn.180222340(uVar2, iVar5);
                if (*(int32_t *)(iVar10 + 0x10) != iVar7) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d39;
                    iVar11 = fcn.180221f20();
                    if (iVar11 == 0) goto code_r0x000180235027;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d50;
                    iVar7 = fcn.180222110(*(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                                          *(int64_t *)((int64_t)&var_18h + iVar8), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar8), 
                                          *(int64_t *)(&stack0x00000038 + iVar8));
                    if (iVar7 == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234ef9;
                        fcn.180221d50(iVar11);
                        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234efe;
                        fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
                        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f16;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8));
                        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f28;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar8));
                        goto code_r0x000180235027;
                    }
                    *(undefined4 *)((int64_t)&arg_70h + iVar8) = *(undefined4 *)(iVar10 + 0x10);
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d6e;
                piVar12 = (int64_t *)fcn.180260b40(*(int64_t *)((int64_t)&var_18h + iVar8));
                if (piVar12 == (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f9d;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234fb5;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234fc7;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar8));
                    goto code_r0x000180235027;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d82;
                iVar11 = fcn.1802983b0(*(int64_t *)(&stack0x00000000 + iVar8));
                *piVar12 = iVar11;
                if (iVar11 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f69;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f81;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f93;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar8));
                    goto code_r0x000180235027;
                }
                piVar3 = (int32_t *)piVar12[1];
                uVar1 = *(undefined4 *)(*(int64_t *)(iVar10 + 8) + 4);
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234d9e;
                uVar13 = fcn.180261a10(uVar1);
                if ((uVar13 & 0x2956) == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234db0;
                    iVar7 = fcn.180296580(*(int64_t *)(&stack0x00000000 + iVar8), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                                          *(int64_t *)((int64_t)&var_18h + iVar8));
                    if (iVar7 == 0) goto code_r0x000180235027;
                } else {
                    piVar3[1] = 0xc;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234dd0;
                    iVar7 = fcn.1802a7f60(*(int64_t *)(&stack0x00000000 + iVar8), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                                          *(int64_t *)(&stack0x00000038 + iVar8));
                    *piVar3 = iVar7;
                    if (iVar7 == -1) goto code_r0x000180235027;
                    puVar14 = *(uint8_t **)(piVar3 + 2);
                    for (; 0 < iVar7; iVar7 = iVar7 + -1) {
                        uVar4 = *puVar14;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234dfd;
                        iVar5 = fcn.180275490(uVar4, 8);
                        if (iVar5 == 0) break;
                        puVar14 = puVar14 + 1;
                    }
                    if (0 < iVar7) {
                        puVar15 = puVar14 + (int64_t)iVar7 + -1;
                        do {
                            uVar4 = *puVar15;
                            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234e2d;
                            iVar5 = fcn.180275490(uVar4, 8);
                            if (iVar5 == 0) break;
                            puVar15 = puVar15 + -1;
                            iVar7 = iVar7 + -1;
                        } while (0 < iVar7);
                    }
                    puVar15 = *(uint8_t **)(piVar3 + 2);
                    iVar5 = 0;
                    if (0 < iVar7) {
                        do {
                            uVar4 = *puVar14;
                            if ((uVar4 & 0x80) == 0) {
                                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234e5f;
                                iVar6 = fcn.180275490(uVar4, 8);
                                if (iVar6 == 0) {
                                    uVar4 = *puVar14;
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234e91;
                                    uVar4 = fcn.1802754c0(uVar4);
                                    *puVar15 = uVar4;
                                    goto code_r0x000180234e94;
                                }
                                *puVar15 = 0x20;
                                do {
                                    uVar4 = puVar14[1];
                                    puVar14 = puVar14 + 1;
                                    iVar5 = iVar5 + 1;
                                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234e83;
                                    iVar6 = fcn.180275490(uVar4, 8);
                                } while (iVar6 != 0);
                            } else {
                                *puVar15 = uVar4;
code_r0x000180234e94:
                                puVar14 = puVar14 + 1;
                                iVar5 = iVar5 + 1;
                            }
                            puVar15 = puVar15 + 1;
                        } while (iVar5 < iVar7);
                    }
                    arg1 = *(undefined8 *)((int64_t)&arg_60h + iVar8);
                    iVar5 = *(int32_t *)((int64_t)&arg_68h + iVar8);
                    *piVar3 = (int32_t)puVar15 - piVar3[2];
                    iVar9 = *(int64_t *)(&stack0x00000000 + iVar8);
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234ec8;
                iVar7 = fcn.180222110(*(int64_t *)((int64_t)&iStackX_10 + iVar8), 
                                      *(int64_t *)((int64_t)&var_18h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar8), *(int64_t *)(&stack0x00000038 + iVar8));
                if (iVar7 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f35;
                    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f4d;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar8));
                    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234f5f;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar8));
                    goto code_r0x000180235027;
                }
                uVar2 = *(undefined8 *)arg1;
                iVar5 = iVar5 + 1;
                *(int32_t *)((int64_t)&arg_68h + iVar8) = iVar5;
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234edd;
                iVar7 = fcn.180222010(uVar2);
                if (iVar7 <= iVar5) break;
                iVar7 = *(int32_t *)((int64_t)&arg_70h + iVar8);
            } while( true );
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234fd3;
        iVar7 = fcn.180234b60(*(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                              *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8));
        if (-1 < iVar7) {
            *(int32_t *)(arg1 + 0x20) = iVar7;
            *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180234ff2;
            iVar10 = fcn.1802248d0(*(int64_t *)(&stack0x00000000 + iVar8), 
                                   *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
            *(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8) = iVar10;
            if (iVar10 != 0) {
                *(int64_t *)(arg1 + 0x18) = iVar10;
                *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x18023500d;
                fcn.180234b60(*(int64_t *)((int64_t)&iStackX_10 + iVar8), *(int64_t *)((int64_t)&var_18h + iVar8), 
                              *(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8));
                *(undefined4 *)((int64_t)&arg_78h + iVar8) = 1;
            }
        }
    }
code_r0x000180235027:
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180235036;
    fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar8 + -8));
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180235045;
    fcn.180222290(iVar9, 0x180196ec0);
    *(undefined8 *)((int64_t)&uStack_28 + iVar8) = 0x180235054;
    fcn.180222050(*(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)((int64_t)&arg_30h + iVar8), 
                  *(int64_t *)(&stack0x00000038 + iVar8), *(int64_t *)(&stack0x00000040 + iVar8), 
                  *(int64_t *)((int64_t)&arg_60h + iVar8));
    return *(undefined4 *)((int64_t)&arg_78h + iVar8);
}

// ============================================================
// Function: FUN_180235070
// Address: 0x180235070
// Size: 423 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

int32_t fcn.180235070(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 *in_RCX;
    int32_t iVar7;
    int64_t var_8h;
    int64_t aiStackX_10 [2];
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180235088;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar3 = -1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023509a;
    iVar5 = fcn.180221f20();
    *(int64_t *)((int64_t)&arg_40h + iVar4) = iVar5;
    if (iVar5 != 0) {
        uVar1 = *in_RCX;
        iVar7 = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802350b2;
        iVar2 = fcn.180222010(uVar1);
        if (0 < iVar2) {
            do {
                uVar1 = *in_RCX;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802350c0;
                iVar5 = fcn.180222340(uVar1, iVar7);
                if (*(int32_t *)(iVar5 + 0x10) != iVar3) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802350cd;
                    iVar6 = fcn.180221f20();
                    if (iVar6 == 0) goto code_r0x000180235159;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802350e2;
                    iVar3 = fcn.180222110(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000030 + iVar4), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4));
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023514f;
                        fcn.180221d50(iVar6);
                        goto code_r0x000180235159;
                    }
                    iVar3 = *(int32_t *)(iVar5 + 0x10);
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802350f4;
                iVar2 = fcn.180222110(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), 
                                      *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
                if (iVar2 == 0) goto code_r0x000180235159;
                uVar1 = *in_RCX;
                iVar7 = iVar7 + 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235102;
                iVar2 = fcn.180222010(uVar1);
            } while (iVar7 < iVar2);
        }
        *(undefined4 *)((int64_t)aiStackX_10 + iVar4 + -8) = 0xffffffff;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235127;
        iVar3 = fcn.180263ea0(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                              *(int64_t *)(&stack0x000000b8 + iVar4));
        uVar1 = in_RCX[2];
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235136;
        iVar5 = func_0x000180226380(uVar1, (int64_t)iVar3);
        if (iVar5 != 0) {
            iVar5 = in_RCX[2];
            *(undefined4 *)((int64_t)aiStackX_10 + iVar4 + -8) = 0xffffffff;
            *(undefined8 *)((int64_t)&arg_48h + iVar4) = *(undefined8 *)(iVar5 + 8);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802351eb;
            fcn.180263ea0(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                          *(int64_t *)(&stack0x000000b8 + iVar4));
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802351fc;
            fcn.180222290(*(undefined8 *)((int64_t)&arg_40h + iVar4), 0x180196ec0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023520b;
            fcn.180222050(*(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4), 
                          *(int64_t *)((int64_t)&arg_40h + iVar4), *(int64_t *)((int64_t)&arg_48h + iVar4), 
                          *(int64_t *)(&stack0x00000068 + iVar4));
            *(undefined4 *)(in_RCX + 1) = 0;
            return iVar3;
        }
    }
code_r0x000180235159:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023515e;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235173;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar4), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_38h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235182;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235193;
    fcn.180222290(*(undefined8 *)((int64_t)&arg_40h + iVar4), 0x180196ec0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802351a2;
    fcn.180222050(*(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4), 
                  *(int64_t *)((int64_t)&arg_40h + iVar4), *(int64_t *)((int64_t)&arg_48h + iVar4), 
                  *(int64_t *)(&stack0x00000068 + iVar4));
    return -1;
}

// ============================================================
// Function: FUN_180235220
// Address: 0x180235220
// Size: 19 bytes
// ============================================================
void fcn.180235220(int64_t arg1, int64_t arg_28h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180235230;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        puVar1 = *(undefined8 **)arg1;
        if (puVar1 != (undefined8 *)0x0) {
            uVar2 = *puVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023524b;
            fcn.18027d040(uVar2);
            uVar2 = puVar1[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180235254;
            fcn.180228780(uVar2);
            uVar2 = puVar1[2];
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023525d;
            fcn.18022ecc0(uVar2);
            uVar2 = puVar1[4];
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180235273;
            fcn.180224990(uVar2, 0x1804e2700, 0x5e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180235288;
            fcn.180224990(puVar1, 0x1804e2700, 0x5f);
            *(int64_t *)arg1 = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180235233
// Address: 0x180235233
// Size: 102 bytes
// ============================================================
void fcn.180235220(int64_t arg1, int64_t arg_28h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180235230;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        puVar1 = *(undefined8 **)arg1;
        if (puVar1 != (undefined8 *)0x0) {
            uVar2 = *puVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023524b;
            fcn.18027d040(uVar2);
            uVar2 = puVar1[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180235254;
            fcn.180228780(uVar2);
            uVar2 = puVar1[2];
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023525d;
            fcn.18022ecc0(uVar2);
            uVar2 = puVar1[4];
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180235273;
            fcn.180224990(uVar2, 0x1804e2700, 0x5e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180235288;
            fcn.180224990(puVar1, 0x1804e2700, 0x5f);
            *(int64_t *)arg1 = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180235299
// Address: 0x180235299
// Size: 1 bytes
// ============================================================
void fcn.180235220(int64_t arg1, int64_t arg_28h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180235230;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        puVar1 = *(undefined8 **)arg1;
        if (puVar1 != (undefined8 *)0x0) {
            uVar2 = *puVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023524b;
            fcn.18027d040(uVar2);
            uVar2 = puVar1[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180235254;
            fcn.180228780(uVar2);
            uVar2 = puVar1[2];
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023525d;
            fcn.18022ecc0(uVar2);
            uVar2 = puVar1[4];
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180235273;
            fcn.180224990(uVar2, 0x1804e2700, 0x5e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180235288;
            fcn.180224990(puVar1, 0x1804e2700, 0x5f);
            *(int64_t *)arg1 = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1802352a0
// Address: 0x1802352a0
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.1802352a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t **in_RCX;
    undefined8 unaff_RDI;
    int64_t in_R8;
    int64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802352bb;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802352de;
    piVar2 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar1));
    if (piVar2 == (int64_t *)0x0) {
        return false;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RDI;
    if (*piVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802352fb;
        iVar3 = func_0x00018027d0a0();
        *piVar2 = iVar3;
        if (iVar3 != 0) goto code_r0x000180235303;
code_r0x000180235364:
        iVar3 = *piVar2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023536c;
        fcn.18027d040(iVar3);
        iVar3 = piVar2[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180235375;
        fcn.180228780(iVar3);
        iVar3 = piVar2[2];
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023537e;
        fcn.18022ecc0(iVar3);
        iVar3 = piVar2[4];
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180235393;
        fcn.180224990(iVar3, 0x1804e2700, 0x5e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802353a8;
        fcn.180224990(piVar2, 0x1804e2700, 0x5f);
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802353b0;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802353c8;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802353da;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar1));
        piVar2 = (int64_t *)0x0;
    } else {
code_r0x000180235303:
        if (piVar2[1] == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023530e;
            iVar3 = func_0x0001802287b0();
            piVar2[1] = iVar3;
            if (iVar3 == 0) goto code_r0x000180235364;
        }
        iVar3 = piVar2[4];
        piVar2[3] = in_R8;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023533b;
        fcn.180224990(iVar3, 0x1804e2700, 0x34);
        piVar2[4] = 0;
        if (in_R9 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023535c;
            iVar3 = fcn.1802231e0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar1));
            piVar2[4] = iVar3;
            if (iVar3 == 0) goto code_r0x000180235364;
        }
        *in_RCX = piVar2;
    }
    return piVar2 != (int64_t *)0x0;
}

// ============================================================
// Function: FUN_1802352ea
// Address: 0x1802352ea
// Size: 259 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.1802352a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t **in_RCX;
    undefined8 unaff_RDI;
    int64_t in_R8;
    int64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802352bb;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802352de;
    piVar2 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar1));
    if (piVar2 == (int64_t *)0x0) {
        return false;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RDI;
    if (*piVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802352fb;
        iVar3 = func_0x00018027d0a0();
        *piVar2 = iVar3;
        if (iVar3 != 0) goto code_r0x000180235303;
code_r0x000180235364:
        iVar3 = *piVar2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023536c;
        fcn.18027d040(iVar3);
        iVar3 = piVar2[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180235375;
        fcn.180228780(iVar3);
        iVar3 = piVar2[2];
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023537e;
        fcn.18022ecc0(iVar3);
        iVar3 = piVar2[4];
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180235393;
        fcn.180224990(iVar3, 0x1804e2700, 0x5e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802353a8;
        fcn.180224990(piVar2, 0x1804e2700, 0x5f);
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802353b0;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802353c8;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802353da;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar1));
        piVar2 = (int64_t *)0x0;
    } else {
code_r0x000180235303:
        if (piVar2[1] == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023530e;
            iVar3 = func_0x0001802287b0();
            piVar2[1] = iVar3;
            if (iVar3 == 0) goto code_r0x000180235364;
        }
        iVar3 = piVar2[4];
        piVar2[3] = in_R8;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023533b;
        fcn.180224990(iVar3, 0x1804e2700, 0x34);
        piVar2[4] = 0;
        if (in_R9 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023535c;
            iVar3 = fcn.1802231e0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar1));
            piVar2[4] = iVar3;
            if (iVar3 == 0) goto code_r0x000180235364;
        }
        *in_RCX = piVar2;
    }
    return piVar2 != (int64_t *)0x0;
}

// ============================================================
// Function: FUN_1802353ed
// Address: 0x1802353ed
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.1802352a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t **in_RCX;
    undefined8 unaff_RDI;
    int64_t in_R8;
    int64_t in_R9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802352bb;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802352de;
    piVar2 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar1));
    if (piVar2 == (int64_t *)0x0) {
        return false;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RDI;
    if (*piVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802352fb;
        iVar3 = func_0x00018027d0a0();
        *piVar2 = iVar3;
        if (iVar3 != 0) goto code_r0x000180235303;
code_r0x000180235364:
        iVar3 = *piVar2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023536c;
        fcn.18027d040(iVar3);
        iVar3 = piVar2[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180235375;
        fcn.180228780(iVar3);
        iVar3 = piVar2[2];
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023537e;
        fcn.18022ecc0(iVar3);
        iVar3 = piVar2[4];
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180235393;
        fcn.180224990(iVar3, 0x1804e2700, 0x5e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802353a8;
        fcn.180224990(piVar2, 0x1804e2700, 0x5f);
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802353b0;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802353c8;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802353da;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar1));
        piVar2 = (int64_t *)0x0;
    } else {
code_r0x000180235303:
        if (piVar2[1] == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023530e;
            iVar3 = func_0x0001802287b0();
            piVar2[1] = iVar3;
            if (iVar3 == 0) goto code_r0x000180235364;
        }
        iVar3 = piVar2[4];
        piVar2[3] = in_R8;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023533b;
        fcn.180224990(iVar3, 0x1804e2700, 0x34);
        piVar2[4] = 0;
        if (in_R9 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023535c;
            iVar3 = fcn.1802231e0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar1));
            piVar2[4] = iVar3;
            if (iVar3 == 0) goto code_r0x000180235364;
        }
        *in_RCX = piVar2;
    }
    return piVar2 != (int64_t *)0x0;
}

// ============================================================
// Function: FUN_180235410
// Address: 0x180235410
// Size: 961 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180235410(int64_t arg_50h, int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d0h,
                  int64_t arg_d8h, int64_t arg_e0h)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined *puVar10;
    undefined *puVar11;
    int64_t **in_RCX;
    int64_t *in_RDX;
    undefined4 in_R8D;
    undefined *puVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_18h;
    
    uStack_40 = 0x18023542a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_50h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar6);
    puVar11 = (undefined *)0x0;
    iVar9 = *(int64_t *)((int64_t)&arg_e0h + iVar6);
    puVar10 = (undefined *)*in_RDX;
    *(undefined4 *)((int64_t)&var_8h + iVar6) = in_R8D;
    *(undefined8 *)((int64_t)&iStackX_18 + iVar6 + -8) = *(undefined8 *)((int64_t)&arg_d0h + iVar6);
    if (*in_RCX == (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18023548a;
        piVar7 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar6));
        if (piVar7 == (int64_t *)0x0) goto code_r0x0001802357a6;
        if (*piVar7 != 0) {
code_r0x0001802354a8:
            if (piVar7[1] == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1802354b3;
                iVar8 = func_0x0001802287b0();
                piVar7[1] = iVar8;
                if (iVar8 == 0) goto code_r0x00018023550c;
            }
            piVar1 = piVar7 + 4;
            iVar8 = *piVar1;
            piVar7[3] = *(int64_t *)((int64_t)&arg_d8h + iVar6);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1802354e7;
            fcn.180224990(iVar8, 0x1804e2700, 0x34);
            *piVar1 = 0;
            if (iVar9 != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180235504;
                iVar9 = fcn.1802231e0(*(int64_t *)((int64_t)&var_18h + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar6));
                *piVar1 = iVar9;
                if (iVar9 == 0) goto code_r0x00018023550c;
            }
            in_R8D = *(undefined4 *)((int64_t)&var_8h + iVar6);
            *in_RCX = piVar7;
            goto code_r0x00018023556a;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1802354a0;
        iVar8 = func_0x00018027d0a0();
        *piVar7 = iVar8;
        if (iVar8 != 0) goto code_r0x0001802354a8;
code_r0x00018023550c:
        iVar9 = *piVar7;
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180235514;
        fcn.18027d040(iVar9);
        iVar9 = piVar7[1];
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18023551d;
        fcn.180228780(iVar9);
        iVar9 = piVar7[2];
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180235526;
        fcn.18022ecc0(iVar9);
        iVar9 = piVar7[4];
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18023553b;
        fcn.180224990(iVar9, 0x1804e2700, 0x5e);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180235550;
        fcn.180224990(piVar7, 0x1804e2700, 0x5f);
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180235555;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
    } else {
code_r0x00018023556a:
        piVar7 = *in_RCX;
        if (*piVar7 != 0) {
code_r0x00018023557f:
            if (piVar7[1] == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18023558a;
                iVar9 = func_0x0001802287b0();
                piVar7[1] = iVar9;
                if (iVar9 == 0) goto code_r0x000180235593;
            }
            iVar5 = *(int32_t *)((int64_t)&arg_c0h + iVar6);
            *(undefined8 *)(&stack0x00000000 + iVar6) = *(undefined8 *)((int64_t)&iStackX_18 + iVar6 + -8);
            (&stack0xfffffffffffffff8)[iVar6] = *(undefined *)((int64_t)&arg_c8h + iVar6);
            *(int32_t *)(&stack0xfffffffffffffff0 + iVar6) = iVar5;
            *(undefined4 *)((int64_t)&var_18h + iVar6) = *(undefined4 *)((int64_t)&arg_b8h + iVar6);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18023560c;
            iVar4 = func_0x000180261940(in_RCX, in_RDX, in_R8D, 0x1804e2630);
            if (iVar4 < 1) goto code_r0x0001802357a6;
            iVar9 = *in_RDX;
            if (iVar9 - (int64_t)puVar10 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180235621;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180235639;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_18 + iVar6));
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18023564b;
                fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                goto code_r0x0001802357a6;
            }
            piVar7 = *in_RCX;
            iVar8 = piVar7[2];
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18023565e;
            fcn.18022ecc0(iVar8);
            piVar7[2] = 0;
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180235667;
            func_0x000180229b10();
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180235673;
            iVar4 = func_0x0001802372f0(piVar7 + 2, piVar7);
            puVar12 = puVar11;
            if (iVar4 == -1) {
code_r0x00018023567a:
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18023567f;
                func_0x000180229900();
            } else {
                if ((iVar4 < 1) && (puVar12 = (undefined *)0x0, (*(uint8_t *)(piVar7 + 5) & 1) == 0)) {
                    *(int64_t *)((int64_t)&var_8h + iVar6) = iVar9 - (int64_t)puVar10;
                    puVar12 = puVar11;
                    if (iVar5 != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1802356b8;
                        puVar10 = (undefined *)fcn.180223170(*(int64_t *)((int64_t)&var_18h + iVar6));
                        if (puVar10 == (undefined *)0x0) goto code_r0x0001802357a6;
                        *puVar10 = 0x30;
                        puVar12 = puVar10;
                    }
                    puVar2 = (undefined8 *)*piVar7;
                    *(undefined **)((int64_t)&iStackX_18 + iVar6 + -8) = puVar10;
                    uVar3 = *puVar2;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1802356e7;
                    iVar5 = func_0x00018022cd40((int64_t)&iStackX_18 + iVar6, 0x32, uVar3, 0);
                    if (iVar5 < 1) goto code_r0x00018023567a;
                    *(int64_t *)(&stack0xfffffffffffffff8 + iVar6) = piVar7[4];
                    *(int64_t *)(&stack0xfffffffffffffff0 + iVar6) = piVar7[3];
                    *(undefined4 *)((int64_t)&var_18h + iVar6) = 0x86;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180235721;
                    puVar11 = (undefined *)
                              func_0x000180271890(piVar7 + 2, 0x1804e2760, 0x1804e2748, (int64_t)&iStackX_18 + iVar6);
                    if (puVar11 != (undefined *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18023573b;
                        iVar5 = func_0x000180270af0(puVar11, (int64_t)&iStackX_18 + iVar6 + -8, (int64_t)&var_8h + iVar6
                                                   );
                        if ((iVar5 != 0) && (*(int64_t *)((int64_t)&var_8h + iVar6) != 0)) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18023574c;
                            func_0x000180229900();
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180235751;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180235769;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), 
                                          *(int64_t *)(&stack0x00000000 + iVar6), 
                                          *(int64_t *)((int64_t)&iStackX_18 + iVar6));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18023577b;
                            fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
                            goto code_r0x000180235787;
                        }
                    }
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180235782;
                func_0x0001802299d0();
            }
code_r0x000180235787:
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x18023578f;
            func_0x00018026f440(puVar11);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1802357a4;
            fcn.180224990(puVar12, 0x1804e2700, 0xea);
            goto code_r0x0001802357a6;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180235577;
        iVar9 = func_0x00018027d0a0();
        *piVar7 = iVar9;
        if (iVar9 != 0) goto code_r0x00018023557f;
code_r0x000180235593:
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x180235598;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1802355b0;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)(&stack0xfffffffffffffff0 + iVar6), 
                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6), 
                  *(int64_t *)((int64_t)&iStackX_18 + iVar6));
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1802355c2;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar6));
code_r0x0001802357a6:
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1802357b6;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_50h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1802357e0
// Address: 0x1802357e0
// Size: 29 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling

uint64_t fcn.1802357e0(int64_t *param_1, int64_t param_2, undefined8 param_3, uint64_t param_4)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    uint32_t uVar8;
    code *pcVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t iVar10;
    uint32_t uVar11;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar13;
    char *pcVar14;
    undefined8 unaff_R12;
    code *pcVar15;
    undefined8 unaff_R13;
    code *pcVar16;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    code *apcStackX_8 [4];
    code *pcVar12;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar14 = "\x01";
    *(undefined8 *)(&stack0x00000040 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000048 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000058 + iVar3) = unaff_RSI;
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RDI;
    *(undefined8 *)(&stack0x00000028 + iVar3) = unaff_R12;
    *(undefined8 *)((int64_t)apcStackX_8 + iVar3 + 0x18) = unaff_R13;
    *(undefined8 *)((int64_t)apcStackX_8 + iVar3 + 0x10) = unaff_R14;
    *(undefined8 *)((int64_t)apcStackX_8 + iVar3 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)apcStackX_8 + iVar3) = 0x180263ec2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    pcVar16 = (code *)0x0;
    uVar13 = 1;
    *(undefined4 *)(&stack0x00000040 + iVar4 + iVar3) = 1;
    iVar2 = (int32_t)param_4;
    iVar10 = *(int64_t *)(pcVar14 + 0x18);
    if ((*pcVar14 != '\0') && (*param_1 == 0)) {
        return 0;
    }
    pcVar15 = pcVar16;
    if (iVar10 != 0) {
        iVar5 = 0x28;
        if ((*(uint8_t *)(iVar10 + 8) & 8) == 0) {
            iVar5 = 0x18;
        }
        pcVar15 = *(code **)(iVar5 + iVar10);
    }
    uVar8 = *(uint32_t *)(&stack0x000000a0 + iVar4 + iVar3);
    switch(*pcVar14) {
    case '\0':
        iVar10 = *(int64_t *)(pcVar14 + 8);
        param_4 = param_4 & 0xffffffff;
        *(uint32_t *)(&stack0x00000030 + iVar4 + iVar3) = uVar8;
        if (iVar10 == 0) {
            *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x180263f59;
            uVar7 = func_0x0001802644b0(param_1, param_2, pcVar14);
            return uVar7;
        }
        break;
    case '\x02':
        if (iVar2 != -1) {
            *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x180263fc3;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar4 + iVar3), *(int64_t *)(&stack0x00000038 + iVar4 + iVar3)
                         );
            *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x180263fdb;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar4 + iVar3), *(int64_t *)(&stack0x00000038 + iVar4 + iVar3)
                          , *(int64_t *)(&stack0x00000040 + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000060 + iVar4 + iVar3)
                         );
            *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x180263fed;
            fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
            return 0xffffffff;
        }
        if (pcVar15 != (code *)0x0) {
            *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x18026400a;
            iVar2 = (*pcVar15)(6, param_1, pcVar14, 0);
            if (iVar2 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x180264019;
        iVar2 = func_0x0001802d4410(param_1, pcVar14);
        if ((iVar2 < 0) || (*(int32_t *)(pcVar14 + 0x10) <= iVar2)) {
            if (pcVar15 != (code *)0x0) {
                *(code **)((int64_t)apcStackX_8 + iVar4 + iVar3) = case.0x180263f35.3;
                (*pcVar15)(7, param_1, pcVar14, 0);
                return 0;
            }
            return 0;
        }
        iVar10 = *(int64_t *)(pcVar14 + 8) + (int64_t)iVar2 * 0x20;
        *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x18026403b;
        param_1 = (int64_t *)func_0x0001802d4420(param_1, iVar10);
        param_4 = 0xffffffff;
        *(uint32_t *)(&stack0x00000030 + iVar4 + iVar3) = uVar8;
        break;
    default:
        return 0;
    case '\x04':
        pcVar16 = *(code **)(iVar10 + 0x28);
        *(uint32_t *)(&stack0x00000030 + iVar4 + iVar3) = uVar8;
        *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x1802640a3;
        uVar7 = (*pcVar16)(param_1, param_2, pcVar14, param_4 & 0xffffffff);
        return uVar7;
    case '\x05':
        if (iVar2 == -1) {
            *(uint32_t *)(&stack0x00000030 + iVar4 + iVar3) = uVar8;
            *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x180263fb4;
            uVar7 = func_0x0001802644b0(param_1, param_2, pcVar14, 0xffffffff);
            return uVar7;
        }
        *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x180263f68;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar4 + iVar3), *(int64_t *)(&stack0x00000038 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x180263f80;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar4 + iVar3), *(int64_t *)(&stack0x00000038 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000060 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x180263f92;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
        return 0xffffffff;
    case '\x06':
        if ((uVar8 >> 0xb & 1) != 0) {
            uVar13 = 2;
        }
        *(undefined4 *)(&stack0x00000040 + iVar4 + iVar3) = uVar13;
    case '\x01':
        *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x1802640cd;
        iVar1 = func_0x0001802d4270(&stack0x00000090 + iVar4 + iVar3, param_2, param_1, pcVar14);
        if (iVar1 < 0) {
            return 0;
        }
        if (0 < iVar1) {
            return (uint64_t)*(uint32_t *)(&stack0x00000090 + iVar4 + iVar3);
        }
        iVar1 = 0x10;
        if (iVar2 != -1) {
            iVar1 = iVar2;
        }
        *(undefined4 *)(&stack0x00000090 + iVar4 + iVar3) = 0;
        *(int32_t *)(&stack0x00000048 + iVar4 + iVar3) = iVar1;
        uVar11 = uVar8 & 0xffffff3f;
        if (iVar2 != -1) {
            uVar11 = uVar8;
        }
        *(uint32_t *)(&stack0x00000044 + iVar4 + iVar3) = uVar11;
        pcVar9 = pcVar16;
        if (pcVar15 != (code *)0x0) {
            *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x180264121;
            iVar2 = (*pcVar15)(6, param_1, pcVar14, 0);
            if (iVar2 == 0) {
                return 0;
            }
            pcVar9 = (code *)(uint64_t)*(uint32_t *)(&stack0x00000090 + iVar4 + iVar3);
        }
        iVar10 = *(int64_t *)(pcVar14 + 8);
        pcVar12 = pcVar16;
        if (0 < *(int32_t *)(pcVar14 + 0x10)) {
            do {
                iVar5 = *param_1;
                *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x180264151;
                iVar5 = func_0x0001802d3f90(iVar5, iVar10, 1);
                if (iVar5 == 0) {
                    return 0;
                }
                *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x180264168;
                uVar6 = func_0x0001802d4420(param_1, iVar5);
                *(undefined4 *)(&stack0x00000030 + iVar4 + iVar3) = *(undefined4 *)(&stack0x00000044 + iVar4 + iVar3);
                *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x180264183;
                iVar2 = func_0x000180264940(uVar6, 0, iVar5, 0xffffffff);
                if (iVar2 == -1) {
                    return 0xffffffff;
                }
                if (0x7fffffff - *(int32_t *)(&stack0x00000090 + iVar4 + iVar3) < iVar2) {
                    return 0xffffffff;
                }
                uVar8 = *(int32_t *)(&stack0x00000090 + iVar4 + iVar3) + iVar2;
                pcVar9 = (code *)(uint64_t)uVar8;
                iVar10 = iVar10 + 0x20;
                uVar11 = (int32_t)pcVar12 + 1;
                pcVar12 = (code *)(uint64_t)uVar11;
                *(uint32_t *)(&stack0x00000090 + iVar4 + iVar3) = uVar8;
            } while ((int32_t)uVar11 < *(int32_t *)(pcVar14 + 0x10));
            uVar11 = *(uint32_t *)(&stack0x00000044 + iVar4 + iVar3);
        }
        uVar13 = *(undefined4 *)(&stack0x00000048 + iVar4 + iVar3);
        iVar2 = *(int32_t *)(&stack0x00000040 + iVar4 + iVar3);
        *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x1802641cd;
        uVar7 = func_0x000180296c90(iVar2, pcVar9, uVar13);
        *(int32_t *)(&stack0x00000044 + iVar4 + iVar3) = (int32_t)uVar7;
        if (param_2 == 0) {
            return uVar7;
        }
        if ((int32_t)uVar7 == -1) {
            return uVar7;
        }
        *(uint32_t *)(&stack0x00000030 + iVar4 + iVar3) = uVar11;
        *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x1802641fd;
        func_0x000180296d10(param_2, iVar2, *(undefined4 *)(&stack0x00000090 + iVar4 + iVar3), uVar13);
        iVar10 = *(int64_t *)(pcVar14 + 8);
        if (0 < *(int32_t *)(pcVar14 + 0x10)) {
            do {
                iVar5 = *param_1;
                *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x180264221;
                iVar5 = func_0x0001802d3f90(iVar5, iVar10, 1);
                if (iVar5 == 0) {
                    return 0;
                }
                *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x180264238;
                uVar6 = func_0x0001802d4420(param_1, iVar5);
                *(uint32_t *)(&stack0x00000030 + iVar4 + iVar3) = uVar11;
                *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x180264251;
                func_0x000180264940(uVar6, param_2, iVar5, 0xffffffff);
                iVar10 = iVar10 + 0x20;
                uVar8 = (int32_t)pcVar16 + 1;
                pcVar16 = (code *)(uint64_t)uVar8;
            } while ((int32_t)uVar8 < *(int32_t *)(pcVar14 + 0x10));
            iVar2 = *(int32_t *)(&stack0x00000040 + iVar4 + iVar3);
        }
        if (iVar2 == 2) {
            *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x18026426f;
            func_0x000180296cf0(param_2);
        }
        if (pcVar15 != (code *)0x0) {
            *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x180264285;
            iVar2 = (*pcVar15)(7, param_1, pcVar14, 0);
            if (iVar2 == 0) {
                return 0;
            }
        }
        return (uint64_t)*(uint32_t *)(&stack0x00000044 + iVar4 + iVar3);
    }
    *(undefined8 *)((int64_t)apcStackX_8 + iVar4 + iVar3) = 0x180264053;
    uVar7 = func_0x000180264940(param_1, param_2, iVar10, param_4);
    return uVar7;
}

// ============================================================
// Function: FUN_180235800
// Address: 0x180235800
// Size: 32 bytes
// ============================================================
void fcn.180235800(int64_t arg_48h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_90h,
                  int64_t arg_a8h)
{
    uint32_t *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 *in_RDX;
    uint32_t *puVar5;
    int64_t iVar6;
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar6 = 0x1804e2630;
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = *in_RDX;
    *(undefined8 *)(&stack0x00000030 + iVar2) = 0x1802a951f;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    puVar1 = *(uint32_t **)((int64_t)&arg_a8h + iVar3 + iVar2);
    puVar5 = (uint32_t *)0x1806a0770;
    if (puVar1 != (uint32_t *)0x0) {
        puVar5 = puVar1;
    }
    uVar4 = 0;
    if ((*puVar5 & 0x100) == 0) {
        uVar4 = *(undefined8 *)(iVar6 + 0x28);
    }
    *(uint32_t **)((int64_t)&arg_70h + iVar3 + iVar2) = puVar5;
    *(undefined4 *)((int64_t)&arg_68h + iVar3 + iVar2) = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar3 + iVar2) = uVar4;
    *(undefined8 *)((int64_t)&arg_58h + iVar3 + iVar2) = 0;
    *(undefined8 *)(&stack0x00000030 + iVar3 + iVar2) = 0x1802a9565;
    fcn.1802a9570(*(int64_t *)((int64_t)&arg_58h + iVar3 + iVar2), *(int64_t *)(&stack0x00000098 + iVar3 + iVar2), 
                  *(int64_t *)(&stack0x000000a0 + iVar3 + iVar2), *(int64_t *)((int64_t)&arg_a8h + iVar3 + iVar2), 
                  *(int64_t *)(&stack0x000000b0 + iVar3 + iVar2), *(int64_t *)(&stack0x000000b8 + iVar3 + iVar2), 
                  *(int64_t *)(&stack0x000000c0 + iVar3 + iVar2), *(int64_t *)(&stack0x000000c8 + iVar3 + iVar2), 
                  *(int64_t *)(&stack0x000000d0 + iVar3 + iVar2));
    return;
}

// ============================================================
// Function: FUN_180235820
// Address: 0x180235820
// Size: 29 bytes
// ============================================================
void fcn.180235820(undefined8 param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00000030 + iVar1) = param_1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1) = 0x1802612bf;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x1802612cf;
    fcn.1802612e0(*(int64_t *)(&stack0x00000048 + iVar2 + iVar1), *(int64_t *)(&stack0x00000050 + iVar2 + iVar1), 
                  *(int64_t *)(&stack0x00000058 + iVar2 + iVar1), *(int64_t *)(&stack0x00000060 + iVar2 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180235840
// Address: 0x180235840
// Size: 72 bytes
// ============================================================
int64_t fcn.180235840(int64_t param_1)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18023584a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180235857;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18023586f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180235881;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RBX;
    iVar1 = *(int64_t *)(param_1 + 0x10);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18023589b;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358b3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358c5;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358d9;
    iVar2 = fcn.1802308d0(iVar1);
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358e2;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358fa;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18023590c;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    return iVar1;
}

// ============================================================
// Function: FUN_180235888
// Address: 0x180235888
// Size: 73 bytes
// ============================================================
int64_t fcn.180235840(int64_t param_1)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18023584a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180235857;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18023586f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180235881;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RBX;
    iVar1 = *(int64_t *)(param_1 + 0x10);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18023589b;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358b3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358c5;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358d9;
    iVar2 = fcn.1802308d0(iVar1);
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358e2;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358fa;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18023590c;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    return iVar1;
}

// ============================================================
// Function: FUN_1802358d1
// Address: 0x1802358d1
// Size: 71 bytes
// ============================================================
int64_t fcn.180235840(int64_t param_1)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18023584a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180235857;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18023586f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180235881;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RBX;
    iVar1 = *(int64_t *)(param_1 + 0x10);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18023589b;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358b3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358c5;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358d9;
    iVar2 = fcn.1802308d0(iVar1);
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358e2;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358fa;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18023590c;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    return iVar1;
}

// ============================================================
// Function: FUN_180235918
// Address: 0x180235918
// Size: 13 bytes
// ============================================================
int64_t fcn.180235840(int64_t param_1)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18023584a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180235857;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18023586f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180235881;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RBX;
    iVar1 = *(int64_t *)(param_1 + 0x10);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18023589b;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358b3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358c5;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358d9;
    iVar2 = fcn.1802308d0(iVar1);
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358e2;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802358fa;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18023590c;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    return iVar1;
}

// ============================================================
// Function: FUN_180235930
// Address: 0x180235930
// Size: 135 bytes
// ============================================================
int64_t fcn.180235930(int64_t param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18023593a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180235947;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18023595f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180235971;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    iVar2 = *(int64_t *)(param_1 + 0x10);
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180235986;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18023599e;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802359b0;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        iVar2 = 0;
    }
    return iVar2;
}

// ============================================================
// Function: FUN_180235a10
// Address: 0x180235a10
// Size: 29 bytes
// ============================================================
undefined8 fcn.180235a10(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 uVar4;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x180260b4c;
    iVar3 = fcn.18045a350(0x1804e26a8);
    iVar3 = -iVar3;
    uVar4 = 0;
    *(undefined8 *)(&stack0x00000068 + iVar3 + iVar2) = 0;
    *(undefined8 *)(&stack0x00000040 + iVar3 + iVar2) = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180260b6e;
    iVar1 = fcn.180260bc0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2)
                          , *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
    if (0 < iVar1) {
        uVar4 = *(undefined8 *)(&stack0x00000068 + iVar3 + iVar2);
    }
    return uVar4;
}

// ============================================================
// Function: FUN_180235a30
// Address: 0x180235a30
// Size: 161 bytes
// ============================================================
undefined8 fcn.180235a30(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_20;
    
    uStack_20 = 0x180235a3e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = 0;
    if ((in_RCX == (int64_t *)0x0) || (in_RDX == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235bfa;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235c12;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar3), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar3 + 8), *(int64_t *)((int64_t)aiStackX_10 + iVar3 + 0x10)
                      , *(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235c24;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
        return 0;
    }
    if (*(int64_t *)(in_RDX + 8) == 0) {
        if (*(int64_t *)(in_RDX + 0x60) == 0) goto code_r0x000180235bb3;
        *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0;
        *(undefined8 *)((int64_t)&arg_58h + iVar3) = 0;
        *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + -8) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235af9;
        uVar5 = func_0x00018029d9e0(in_RDX, 0x86, 0x1804e2760, 0x1804e2748);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b0e;
        iVar2 = func_0x00018029cb20(uVar5, (int64_t)&arg_48h + iVar3, (int64_t)&arg_58h + iVar3);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&arg_60h + iVar3) = *(undefined8 *)((int64_t)&arg_48h + iVar3);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b34;
            iVar4 = func_0x000180261770(0, (int64_t)&arg_60h + iVar3, *(undefined4 *)((int64_t)&arg_58h + iVar3), 
                                        0x1804e26a8);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b3f;
        func_0x00018029b870(uVar5);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b56;
        fcn.180224990(*(undefined8 *)((int64_t)&arg_48h + iVar3), 0x1804e2700, 0x169);
        if (iVar4 == 0) goto code_r0x000180235bb3;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235a6d;
        iVar4 = fcn.180260b40(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + 0x10));
        if ((iVar4 == 0) || (pcVar1 = *(code **)(*(int64_t *)(in_RDX + 8) + 0x28), pcVar1 == (code *)0x0))
        goto code_r0x000180235bb3;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235a9a;
        iVar2 = (*pcVar1)(iVar4, in_RDX);
        if (iVar2 == 0) goto code_r0x000180235bb3;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b6f;
    fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b77;
    iVar2 = fcn.1802308d0(in_RDX);
    if (iVar2 != 0) {
        *in_RCX = iVar4;
        if (*(int64_t *)(iVar4 + 0x10) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b98;
            fcn.18022ecc0();
        }
        *(int64_t *)(iVar4 + 0x10) = in_RDX;
        return 1;
    }
code_r0x000180235bb3:
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235bb8;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235bcd;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar3), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar3 + 8), *(int64_t *)((int64_t)aiStackX_10 + iVar3 + 0x10), 
                  *(int64_t *)(&stack0x00000038 + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235bdc;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235beb;
    fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_180235ad1
// Address: 0x180235ad1
// Size: 143 bytes
// ============================================================
undefined8 fcn.180235a30(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_20;
    
    uStack_20 = 0x180235a3e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = 0;
    if ((in_RCX == (int64_t *)0x0) || (in_RDX == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235bfa;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235c12;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar3), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar3 + 8), *(int64_t *)((int64_t)aiStackX_10 + iVar3 + 0x10)
                      , *(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235c24;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
        return 0;
    }
    if (*(int64_t *)(in_RDX + 8) == 0) {
        if (*(int64_t *)(in_RDX + 0x60) == 0) goto code_r0x000180235bb3;
        *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0;
        *(undefined8 *)((int64_t)&arg_58h + iVar3) = 0;
        *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + -8) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235af9;
        uVar5 = func_0x00018029d9e0(in_RDX, 0x86, 0x1804e2760, 0x1804e2748);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b0e;
        iVar2 = func_0x00018029cb20(uVar5, (int64_t)&arg_48h + iVar3, (int64_t)&arg_58h + iVar3);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&arg_60h + iVar3) = *(undefined8 *)((int64_t)&arg_48h + iVar3);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b34;
            iVar4 = func_0x000180261770(0, (int64_t)&arg_60h + iVar3, *(undefined4 *)((int64_t)&arg_58h + iVar3), 
                                        0x1804e26a8);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b3f;
        func_0x00018029b870(uVar5);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b56;
        fcn.180224990(*(undefined8 *)((int64_t)&arg_48h + iVar3), 0x1804e2700, 0x169);
        if (iVar4 == 0) goto code_r0x000180235bb3;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235a6d;
        iVar4 = fcn.180260b40(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + 0x10));
        if ((iVar4 == 0) || (pcVar1 = *(code **)(*(int64_t *)(in_RDX + 8) + 0x28), pcVar1 == (code *)0x0))
        goto code_r0x000180235bb3;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235a9a;
        iVar2 = (*pcVar1)(iVar4, in_RDX);
        if (iVar2 == 0) goto code_r0x000180235bb3;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b6f;
    fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b77;
    iVar2 = fcn.1802308d0(in_RDX);
    if (iVar2 != 0) {
        *in_RCX = iVar4;
        if (*(int64_t *)(iVar4 + 0x10) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b98;
            fcn.18022ecc0();
        }
        *(int64_t *)(iVar4 + 0x10) = in_RDX;
        return 1;
    }
code_r0x000180235bb3:
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235bb8;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235bcd;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar3), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar3 + 8), *(int64_t *)((int64_t)aiStackX_10 + iVar3 + 0x10), 
                  *(int64_t *)(&stack0x00000038 + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235bdc;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235beb;
    fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_180235b60
// Address: 0x180235b60
// Size: 206 bytes
// ============================================================
undefined8 fcn.180235a30(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_20;
    
    uStack_20 = 0x180235a3e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = 0;
    if ((in_RCX == (int64_t *)0x0) || (in_RDX == 0)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235bfa;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235c12;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar3), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar3 + 8), *(int64_t *)((int64_t)aiStackX_10 + iVar3 + 0x10)
                      , *(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235c24;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
        return 0;
    }
    if (*(int64_t *)(in_RDX + 8) == 0) {
        if (*(int64_t *)(in_RDX + 0x60) == 0) goto code_r0x000180235bb3;
        *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0;
        *(undefined8 *)((int64_t)&arg_58h + iVar3) = 0;
        *(undefined8 *)((int64_t)aiStackX_10 + iVar3 + -8) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235af9;
        uVar5 = func_0x00018029d9e0(in_RDX, 0x86, 0x1804e2760, 0x1804e2748);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b0e;
        iVar2 = func_0x00018029cb20(uVar5, (int64_t)&arg_48h + iVar3, (int64_t)&arg_58h + iVar3);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&arg_60h + iVar3) = *(undefined8 *)((int64_t)&arg_48h + iVar3);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b34;
            iVar4 = func_0x000180261770(0, (int64_t)&arg_60h + iVar3, *(undefined4 *)((int64_t)&arg_58h + iVar3), 
                                        0x1804e26a8);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b3f;
        func_0x00018029b870(uVar5);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b56;
        fcn.180224990(*(undefined8 *)((int64_t)&arg_48h + iVar3), 0x1804e2700, 0x169);
        if (iVar4 == 0) goto code_r0x000180235bb3;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235a6d;
        iVar4 = fcn.180260b40(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + 0x10));
        if ((iVar4 == 0) || (pcVar1 = *(code **)(*(int64_t *)(in_RDX + 8) + 0x28), pcVar1 == (code *)0x0))
        goto code_r0x000180235bb3;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235a9a;
        iVar2 = (*pcVar1)(iVar4, in_RDX);
        if (iVar2 == 0) goto code_r0x000180235bb3;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b6f;
    fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b77;
    iVar2 = fcn.1802308d0(in_RDX);
    if (iVar2 != 0) {
        *in_RCX = iVar4;
        if (*(int64_t *)(iVar4 + 0x10) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235b98;
            fcn.18022ecc0();
        }
        *(int64_t *)(iVar4 + 0x10) = in_RDX;
        return 1;
    }
code_r0x000180235bb3:
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235bb8;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235bcd;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar3), 
                  *(int64_t *)((int64_t)aiStackX_10 + iVar3 + 8), *(int64_t *)((int64_t)aiStackX_10 + iVar3 + 0x10), 
                  *(int64_t *)(&stack0x00000038 + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235bdc;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar3));
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180235beb;
    fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_180235c30
// Address: 0x180235c30
// Size: 82 bytes
// ============================================================
undefined8 fcn.180235c30(int64_t arg_48h, int64_t arg_80h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t in_RCX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180235c3c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180235c4a;
    uVar2 = fcn.18027d0c0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar1));
    if ((int32_t)uVar2 == 0) {
        return uVar2;
    }
    if (*(int64_t *)((int64_t)&arg_48h + iVar1) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180235c6c;
        fcn.1802969f0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        uVar2 = *(undefined8 *)(in_RCX + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180235c77;
        fcn.180296e80(uVar2, 0);
    }
    return 1;
}

// ============================================================
// Function: FUN_180235cb0
// Address: 0x180235cb0
// Size: 477 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180235cb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t *puVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 *in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180235cc8;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = *in_RDX;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235cf5;
    iVar5 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8));
    *(int64_t *)((int64_t)&arg_30h + iVar4) = iVar5;
    if (iVar5 != 0) {
        uVar2 = *(undefined8 *)(iVar5 + 0x20);
        *(undefined8 *)(iVar5 + 0x18) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235d20;
        fcn.180224990(uVar2, 0x1804e2700, 0x34);
        *(undefined8 *)(iVar5 + 0x20) = 0;
        puVar1 = (uint32_t *)(*(int64_t *)((int64_t)&arg_30h + iVar4) + 0x28);
        *puVar1 = *puVar1 | 1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235d46;
        iVar5 = func_0x000180261770((int64_t)&arg_30h + iVar4, (int64_t)&arg_40h + iVar4, in_R8 & 0xffffffff, 
                                    0x1804e26a8);
        if (iVar5 != 0) {
            iVar5 = *(int64_t *)(iVar5 + 0x10);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235d60;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235d78;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235d8a;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235d99;
                fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235dad;
                iVar3 = fcn.1802308d0(iVar5);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235e08;
                    fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                    uVar2 = *(undefined8 *)((int64_t)&arg_40h + iVar4);
                    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235e21;
                    fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235e29;
                    iVar3 = func_0x000180203a00(iVar5);
                    if ((iVar3 == 0x198) || (iVar3 == 0x494)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235e3f;
                        iVar6 = func_0x000180299f50(iVar5);
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235e4a;
                    fcn.18022ecc0(iVar5);
                    if (iVar6 == 0) {
                        return 0;
                    }
                    *in_RDX = uVar2;
                    if (in_RCX != (int64_t *)0x0) {
                        iVar5 = *in_RCX;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235e5f;
                        func_0x000180268f80(iVar5);
                        *in_RCX = iVar6;
                        return iVar6;
                    }
                    return iVar6;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235db6;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235dce;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235de0;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235def;
                fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180235e78;
        fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
    }
    return 0;
}

// ============================================================
// Function: FUN_180235e90
// Address: 0x180235e90
// Size: 53 bytes
// ============================================================
void fcn.180235e90(int64_t arg_28h, int64_t arg_30h, int64_t arg_70h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180235e9a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0x1802362c0;
    *(undefined4 *)((int64_t)&arg_28h + iVar1) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = *(undefined8 *)((int64_t)&arg_70h + iVar1);
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180235ec0;
    fcn.180235ed0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x00000090 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180235ed0
// Address: 0x180235ed0
// Size: 525 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180235ed0(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_58h, int64_t arg_98h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    undefined8 *in_RDX;
    int64_t iVar6;
    uint64_t in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_30;
    
    uStack_30 = 0x180235ee7;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *in_RDX;
    iVar4 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = uVar1;
    if (((in_R9 != 0) || (*(int64_t *)((int64_t)&arg_48h + iVar3) != 0)) ||
       (*(int32_t *)((int64_t)&arg_50h + iVar3) != 0)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180235f38;
        iVar4 = fcn.180224d60(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3));
        *(int64_t *)((int64_t)&arg_30h + iVar3) = iVar4;
        if (iVar4 == 0) {
            return 0;
        }
        uVar1 = *(undefined8 *)(iVar4 + 0x20);
        *(int64_t *)(iVar4 + 0x18) = in_R9;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180235f71;
        fcn.180224990(uVar1, 0x1804e2700, 0x34);
        *(undefined8 *)(iVar4 + 0x20) = 0;
        if (*(int64_t *)((int64_t)&arg_48h + iVar3) != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180235f96;
            iVar5 = fcn.1802231e0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar3 + -0x10), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar3 + -8));
            *(int64_t *)(iVar4 + 0x20) = iVar5;
            if (iVar5 == 0) goto code_r0x0001802360b7;
        }
        *(uint32_t *)(*(int64_t *)((int64_t)&arg_30h + iVar3) + 0x28) =
             (uint32_t)(*(int32_t *)((int64_t)&arg_50h + iVar3) != 0) |
             *(uint32_t *)(*(int64_t *)((int64_t)&arg_30h + iVar3) + 0x28) & 0xfffffffe;
        iVar4 = (int64_t)&arg_30h + iVar3;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180235fd6;
    iVar4 = (**(code **)((int64_t)&arg_58h + iVar3))(iVar4, (int64_t)&arg_40h + iVar3, in_R8 & 0xffffffff);
    if (iVar4 != 0) {
        iVar6 = *(int64_t *)(iVar4 + 0x10);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180235ff0;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar3 + -0x10));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180236008;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar3 + -0x10), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar3 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023601a;
            fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + 8));
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180236029;
            fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + -0x10));
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
            iVar6 = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023603e;
            iVar2 = fcn.1802308d0(iVar6);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180236047;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar3 + -0x10));
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023605f;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar3 + -0x10), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar3 + -8), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3));
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180236071;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + 8));
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180236080;
                fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + -0x10));
                *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
                iVar6 = 0;
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180236099;
                fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + -0x10));
                *in_RDX = *(undefined8 *)((int64_t)&arg_40h + iVar3);
                *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
                if (in_RCX != (int64_t *)0x0) {
                    iVar4 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802360b4;
                    fcn.18022ecc0(iVar4);
                    *in_RCX = iVar6;
                }
            }
        }
    }
code_r0x0001802360b7:
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802360c8;
    fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar3 + -0x10));
    return iVar6;
}

// ============================================================
// Function: FUN_1802360e0
// Address: 0x1802360e0
// Size: 468 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1802360e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h)
{
    uint32_t *puVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 *in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1802360f6;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = *in_RDX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236121;
    iVar5 = fcn.180224d60(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
    *(int64_t *)((int64_t)&arg_30h + iVar4) = iVar5;
    if (iVar5 != 0) {
        uVar2 = *(undefined8 *)(iVar5 + 0x20);
        *(undefined8 *)(iVar5 + 0x18) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18023614f;
        fcn.180224990(uVar2, 0x1804e2700, 0x34);
        *(undefined8 *)(iVar5 + 0x20) = 0;
        puVar1 = (uint32_t *)(*(int64_t *)((int64_t)&arg_30h + iVar4) + 0x28);
        *puVar1 = *puVar1 | 1;
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236175;
        iVar5 = func_0x000180261770((int64_t)&arg_30h + iVar4, (int64_t)&arg_40h + iVar4, in_R8 & 0xffffffff, 
                                    0x1804e26a8);
        if (iVar5 != 0) {
            iVar5 = *(int64_t *)(iVar5 + 0x10);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18023618f;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802361a7;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802361b9;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802361c8;
                fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802361dd;
                iVar3 = fcn.1802308d0(iVar5);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236238;
                    fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
                    uVar2 = *(undefined8 *)((int64_t)&arg_40h + iVar4);
                    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236251;
                    fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236259;
                    iVar6 = func_0x000180299f90(iVar5);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236264;
                    fcn.18022ecc0(iVar5);
                    if (iVar6 == 0) {
                        return 0;
                    }
                    *in_RDX = uVar2;
                    if (in_RCX != (int64_t *)0x0) {
                        iVar5 = *in_RCX;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236279;
                        func_0x00018025def0(iVar5);
                        *in_RCX = iVar6;
                    }
                    return iVar6;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802361e6;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802361fe;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236210;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18023621f;
                fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802362a1;
        fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
    }
    return 0;
}

// ============================================================
// Function: FUN_1802362c0
// Address: 0x1802362c0
// Size: 29 bytes
// ============================================================
void fcn.1802362c0(undefined *param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined *puVar4;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar5;
    undefined8 uStackX_8;
    undefined8 auStackX_10 [3];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar5 = 0x1804e26a8;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 0x10) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2 + 8) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStackX_8 + iVar2) = 0x18026177e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)(&stack0x00000090 + iVar3 + iVar2) = *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_10 + iVar3 + iVar2;
    *(undefined8 *)(&stack0x00000070 + iVar3 + iVar2) = 0;
    (&stack0x00000078)[iVar3 + iVar2] = 0;
    puVar4 = &stack0x00000070 + iVar3 + iVar2;
    if (param_1 != (undefined *)0x0) {
        puVar4 = param_1;
    }
    if ((puVar4 == (undefined *)0x0) || (iVar5 == 0)) {
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261804;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar3 + iVar2), *(int64_t *)(&stack0x00000038 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026181c;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar3 + iVar2), *(int64_t *)(&stack0x00000038 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x18026182e;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
    } else {
        *(undefined8 *)(&stack0x00000060 + iVar3 + iVar2) = 0;
        *(undefined8 *)(&stack0x00000058 + iVar3 + iVar2) = 0;
        *(undefined4 *)(&stack0x00000050 + iVar3 + iVar2) = 0;
        *(undefined **)(&stack0x00000048 + iVar3 + iVar2) = &stack0x00000078 + iVar3 + iVar2;
        (&stack0x00000040)[iVar3 + iVar2] = 0;
        *(undefined4 *)(&stack0x00000038 + iVar3 + iVar2) = 0;
        *(undefined4 *)(&stack0x00000030 + iVar3 + iVar2) = 0xffffffff;
        *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617e9;
        iVar1 = func_0x0001802629a0(puVar4);
        if (iVar1 < 1) {
            *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x1802617f8;
            func_0x000180261290(puVar4, iVar5);
        }
    }
    *(undefined8 *)((int64_t)&uStackX_8 + iVar3 + iVar2) = 0x180261841;
    func_0x000180459870(*(uint64_t *)(&stack0x00000090 + iVar3 + iVar2) ^ (int64_t)auStackX_10 + iVar3 + iVar2);
    return;
}

// ============================================================
// Function: FUN_1802362e0
// Address: 0x1802362e0
// Size: 175 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_54h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ch because it doesn't fit into ProtoModel

uint64_t fcn.1802362e0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    code *pcVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    int64_t *in_RDX;
    uint64_t uVar9;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_20;
    
    uStack_20 = 0x1802362ee;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar9 = 0xffffffff;
    if (in_RCX == 0) {
        return 0;
    }
    iVar7 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_R14;
    if (iVar7 == 0) {
        if (*(int64_t *)(in_RCX + 0x60) != 0) {
            *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_R15;
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + -8) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802363b1;
            uVar8 = fcn.18029d9e0(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar6 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar6 + 0x10), 
                                  *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6), *(int64_t *)((int64_t)&arg_50h + iVar6), 
                                  *(int64_t *)(&stack0x00000088 + iVar6), *(int64_t *)(&stack0x00000090 + iVar6), 
                                  *(int64_t *)(&stack0x00000098 + iVar6), *(int64_t *)(&stack0x000000a8 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802363b9;
            fcn.1802199b0();
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802363c1;
            iVar7 = fcn.18021a7c0(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
            *(undefined8 *)((int64_t)&arg_38h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802363d1;
            iVar4 = fcn.1802705e0(uVar8);
            if ((iVar4 != 0) && (iVar7 != 0)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802363e5;
                iVar4 = fcn.18029ca20(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8));
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802363fe;
                    iVar4 = fcn.180219d10(*(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6)
                                          , *(int64_t *)((int64_t)&arg_38h + iVar6));
                    if (0 < iVar4) {
                        puVar2 = *(undefined8 **)((int64_t)&arg_38h + iVar6);
                        uVar9 = (uint64_t)*(int32_t *)puVar2;
                        if (in_RDX != (int64_t *)0x0) {
                            iVar7 = *in_RDX;
                            if (iVar7 == 0) {
                                *in_RDX = puVar2[1];
                                *puVar2 = 0;
                                *(undefined8 *)(*(int64_t *)((int64_t)&arg_38h + iVar6) + 8) = 0;
                            } else {
                                uVar3 = puVar2[1];
                                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180236438;
                                fcn.180498030(iVar7, uVar3, uVar9);
                                *in_RDX = *in_RDX + uVar9;
                            }
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180236443;
            fcn.180219f80(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18023644b;
            fcn.18029b870(uVar8);
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180236328;
        iVar7 = fcn.180260b40(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + 0x10));
        if (iVar7 != 0) {
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x28);
            if (pcVar1 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18023634a;
                iVar4 = (*pcVar1)(iVar7, in_RCX);
                if (iVar4 != 0) {
                    *(int64_t *)(iVar7 + 0x10) = in_RCX;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180236364;
                    uVar5 = fcn.1802642c0(*(int64_t *)((int64_t)&arg_38h + iVar6), 
                                          *(int64_t *)(&stack0x00000068 + iVar6), *(int64_t *)(&stack0x00000070 + iVar6)
                                          , *(int64_t *)(&stack0x00000078 + iVar6), 
                                          *(int64_t *)(&stack0x00000080 + iVar6));
                    uVar9 = (uint64_t)uVar5;
                    *(undefined8 *)(iVar7 + 0x10) = 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18023637c;
            fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar6));
        }
    }
    return uVar9 & 0xffffffff;
}

// ============================================================
// Function: FUN_18023638f
// Address: 0x18023638f
// Size: 193 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_54h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ch because it doesn't fit into ProtoModel

uint64_t fcn.1802362e0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    code *pcVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    int64_t *in_RDX;
    uint64_t uVar9;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_20;
    
    uStack_20 = 0x1802362ee;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar9 = 0xffffffff;
    if (in_RCX == 0) {
        return 0;
    }
    iVar7 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_R14;
    if (iVar7 == 0) {
        if (*(int64_t *)(in_RCX + 0x60) != 0) {
            *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_R15;
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + -8) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802363b1;
            uVar8 = fcn.18029d9e0(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar6 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar6 + 0x10), 
                                  *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6), *(int64_t *)((int64_t)&arg_50h + iVar6), 
                                  *(int64_t *)(&stack0x00000088 + iVar6), *(int64_t *)(&stack0x00000090 + iVar6), 
                                  *(int64_t *)(&stack0x00000098 + iVar6), *(int64_t *)(&stack0x000000a8 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802363b9;
            fcn.1802199b0();
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802363c1;
            iVar7 = fcn.18021a7c0(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
            *(undefined8 *)((int64_t)&arg_38h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802363d1;
            iVar4 = fcn.1802705e0(uVar8);
            if ((iVar4 != 0) && (iVar7 != 0)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802363e5;
                iVar4 = fcn.18029ca20(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8));
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802363fe;
                    iVar4 = fcn.180219d10(*(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6)
                                          , *(int64_t *)((int64_t)&arg_38h + iVar6));
                    if (0 < iVar4) {
                        puVar2 = *(undefined8 **)((int64_t)&arg_38h + iVar6);
                        uVar9 = (uint64_t)*(int32_t *)puVar2;
                        if (in_RDX != (int64_t *)0x0) {
                            iVar7 = *in_RDX;
                            if (iVar7 == 0) {
                                *in_RDX = puVar2[1];
                                *puVar2 = 0;
                                *(undefined8 *)(*(int64_t *)((int64_t)&arg_38h + iVar6) + 8) = 0;
                            } else {
                                uVar3 = puVar2[1];
                                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180236438;
                                fcn.180498030(iVar7, uVar3, uVar9);
                                *in_RDX = *in_RDX + uVar9;
                            }
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180236443;
            fcn.180219f80(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18023644b;
            fcn.18029b870(uVar8);
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180236328;
        iVar7 = fcn.180260b40(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + 0x10));
        if (iVar7 != 0) {
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x28);
            if (pcVar1 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18023634a;
                iVar4 = (*pcVar1)(iVar7, in_RCX);
                if (iVar4 != 0) {
                    *(int64_t *)(iVar7 + 0x10) = in_RCX;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180236364;
                    uVar5 = fcn.1802642c0(*(int64_t *)((int64_t)&arg_38h + iVar6), 
                                          *(int64_t *)(&stack0x00000068 + iVar6), *(int64_t *)(&stack0x00000070 + iVar6)
                                          , *(int64_t *)(&stack0x00000078 + iVar6), 
                                          *(int64_t *)(&stack0x00000080 + iVar6));
                    uVar9 = (uint64_t)uVar5;
                    *(undefined8 *)(iVar7 + 0x10) = 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18023637c;
            fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar6));
        }
    }
    return uVar9 & 0xffffffff;
}

// ============================================================
// Function: FUN_180236450
// Address: 0x180236450
// Size: 20 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_34h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_44h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_54h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5ch because it doesn't fit into ProtoModel

uint64_t fcn.1802362e0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    code *pcVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    int64_t *in_RDX;
    uint64_t uVar9;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_20;
    
    uStack_20 = 0x1802362ee;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar9 = 0xffffffff;
    if (in_RCX == 0) {
        return 0;
    }
    iVar7 = *(int64_t *)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_R14;
    if (iVar7 == 0) {
        if (*(int64_t *)(in_RCX + 0x60) != 0) {
            *(undefined8 *)((int64_t)&arg_50h + iVar6) = unaff_R15;
            *(undefined8 *)((int64_t)aiStackX_10 + iVar6 + -8) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802363b1;
            uVar8 = fcn.18029d9e0(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar6 + 8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar6 + 0x10), 
                                  *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar6), *(int64_t *)((int64_t)&arg_50h + iVar6), 
                                  *(int64_t *)(&stack0x00000088 + iVar6), *(int64_t *)(&stack0x00000090 + iVar6), 
                                  *(int64_t *)(&stack0x00000098 + iVar6), *(int64_t *)(&stack0x000000a8 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802363b9;
            fcn.1802199b0();
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802363c1;
            iVar7 = fcn.18021a7c0(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_10 + iVar6), *(int64_t *)((int64_t)&arg_40h + iVar6));
            *(undefined8 *)((int64_t)&arg_38h + iVar6) = 0;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802363d1;
            iVar4 = fcn.1802705e0(uVar8);
            if ((iVar4 != 0) && (iVar7 != 0)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802363e5;
                iVar4 = fcn.18029ca20(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8));
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802363fe;
                    iVar4 = fcn.180219d10(*(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6)
                                          , *(int64_t *)((int64_t)&arg_38h + iVar6));
                    if (0 < iVar4) {
                        puVar2 = *(undefined8 **)((int64_t)&arg_38h + iVar6);
                        uVar9 = (uint64_t)*(int32_t *)puVar2;
                        if (in_RDX != (int64_t *)0x0) {
                            iVar7 = *in_RDX;
                            if (iVar7 == 0) {
                                *in_RDX = puVar2[1];
                                *puVar2 = 0;
                                *(undefined8 *)(*(int64_t *)((int64_t)&arg_38h + iVar6) + 8) = 0;
                            } else {
                                uVar3 = puVar2[1];
                                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180236438;
                                fcn.180498030(iVar7, uVar3, uVar9);
                                *in_RDX = *in_RDX + uVar9;
                            }
                        }
                    }
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180236443;
            fcn.180219f80(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_10 + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18023644b;
            fcn.18029b870(uVar8);
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180236328;
        iVar7 = fcn.180260b40(*(int64_t *)((int64_t)aiStackX_10 + iVar6 + 0x10));
        if (iVar7 != 0) {
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 8) + 0x28);
            if (pcVar1 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18023634a;
                iVar4 = (*pcVar1)(iVar7, in_RCX);
                if (iVar4 != 0) {
                    *(int64_t *)(iVar7 + 0x10) = in_RCX;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180236364;
                    uVar5 = fcn.1802642c0(*(int64_t *)((int64_t)&arg_38h + iVar6), 
                                          *(int64_t *)(&stack0x00000068 + iVar6), *(int64_t *)(&stack0x00000070 + iVar6)
                                          , *(int64_t *)(&stack0x00000078 + iVar6), 
                                          *(int64_t *)(&stack0x00000080 + iVar6));
                    uVar9 = (uint64_t)uVar5;
                    *(undefined8 *)(iVar7 + 0x10) = 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18023637c;
            fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar6));
        }
    }
    return uVar9 & 0xffffffff;
}

// ============================================================
// Function: FUN_180236470
// Address: 0x180236470
// Size: 29 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.180236470(undefined8 param_1, int64_t *param_2)
{
    int64_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined4 uVar6;
    undefined8 unaff_R14;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x1802642ca;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = iVar4 + iVar3 + 0x20;
    uVar6 = 0;
    *(undefined8 *)(&stack0x00000058 + iVar4 + iVar3) = param_1;
    *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000038 + iVar4 + iVar3 + 0x20 + -0x20) = unaff_RSI;
    *(undefined8 *)(&stack0x00000030 + iVar4 + iVar3) = 0x1802645e2;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((param_2 != (int64_t *)0x0) && (*param_2 == 0)) {
        *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
        *(undefined8 *)(&stack0x00000098 + iVar3 + iVar1 + -0x20) = unaff_RDI;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026461d;
        uVar2 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
        if ((int32_t)uVar2 < 1) {
            return (uint64_t)uVar2;
        }
        *(undefined8 *)(&stack0x000000a0 + iVar3 + iVar1 + -0x20) = unaff_R14;
        *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026464d;
        iVar4 = fcn.1802248d0(*(int64_t *)(&stack0x00000058 + iVar3 + iVar1 + -0x20), 
                              *(int64_t *)(&stack0x00000060 + iVar3 + iVar1 + -0x20));
        if (iVar4 == 0) {
            uVar5 = 0xffffffff;
        } else {
            *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20) = iVar4;
            *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
            *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x18026468d;
            fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
            uVar5 = (uint64_t)uVar2;
            *param_2 = iVar4;
        }
        return uVar5;
    }
    *(undefined4 *)(&stack0x00000058 + iVar3 + iVar1 + -0x20) = uVar6;
    *(undefined8 *)(&stack0x00000030 + iVar3 + iVar1 + -0x20) = 0x1802646a8;
    uVar5 = fcn.180263ea0(*(int64_t *)(&stack0x00000078 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000080 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000088 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x20), 
                          *(int64_t *)(&stack0x00000108 + iVar3 + iVar1 + -0x20));
    return uVar5;
}

// ============================================================
// Function: FUN_180236490
// Address: 0x180236490
// Size: 29 bytes
// ============================================================
void fcn.180236490(undefined8 param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00000030 + iVar1) = param_1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1) = 0x1802612bf;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x1802612cf;
    fcn.1802612e0(*(int64_t *)(&stack0x00000048 + iVar2 + iVar1), *(int64_t *)(&stack0x00000050 + iVar2 + iVar1), 
                  *(int64_t *)(&stack0x00000058 + iVar2 + iVar1), *(int64_t *)(&stack0x00000060 + iVar2 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1802364b0
// Address: 0x1802364b0
// Size: 468 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1802364b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t *puVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 *in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802364c8;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = *in_RDX;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802364f5;
    iVar5 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8));
    *(int64_t *)((int64_t)&arg_30h + iVar4) = iVar5;
    if (iVar5 != 0) {
        uVar2 = *(undefined8 *)(iVar5 + 0x20);
        *(undefined8 *)(iVar5 + 0x18) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236520;
        fcn.180224990(uVar2, 0x1804e2700, 0x34);
        *(undefined8 *)(iVar5 + 0x20) = 0;
        puVar1 = (uint32_t *)(*(int64_t *)((int64_t)&arg_30h + iVar4) + 0x28);
        *puVar1 = *puVar1 | 1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236546;
        iVar5 = func_0x000180261770((int64_t)&arg_30h + iVar4, (int64_t)&arg_40h + iVar4, in_R8 & 0xffffffff, 
                                    0x1804e26a8);
        if (iVar5 != 0) {
            iVar5 = *(int64_t *)(iVar5 + 0x10);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236560;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236578;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023658a;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236599;
                fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802365ad;
                iVar3 = fcn.1802308d0(iVar5);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236608;
                    fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                    uVar2 = *(undefined8 *)((int64_t)&arg_40h + iVar4);
                    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236621;
                    fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236629;
                    iVar3 = func_0x000180203a00(iVar5);
                    if (iVar3 == 0x1c) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236636;
                        iVar6 = func_0x00018022edf0(iVar5);
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236641;
                    fcn.18022ecc0(iVar5);
                    if (iVar6 == 0) {
                        return 0;
                    }
                    *in_RDX = uVar2;
                    if (in_RCX != (int64_t *)0x0) {
                        iVar5 = *in_RCX;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236656;
                        func_0x00018029a130(iVar5);
                        *in_RCX = iVar6;
                        return iVar6;
                    }
                    return iVar6;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802365b6;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802365ce;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802365e0;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802365ef;
                fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023666f;
        fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
    }
    return 0;
}

// ============================================================
// Function: FUN_180236690
// Address: 0x180236690
// Size: 470 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180236690(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t *puVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 *in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802366a8;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = *in_RDX;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802366d5;
    iVar5 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8));
    *(int64_t *)((int64_t)&arg_30h + iVar4) = iVar5;
    if (iVar5 != 0) {
        uVar2 = *(undefined8 *)(iVar5 + 0x20);
        *(undefined8 *)(iVar5 + 0x18) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236700;
        fcn.180224990(uVar2, 0x1804e2700, 0x34);
        *(undefined8 *)(iVar5 + 0x20) = 0;
        puVar1 = (uint32_t *)(*(int64_t *)((int64_t)&arg_30h + iVar4) + 0x28);
        *puVar1 = *puVar1 | 1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236726;
        iVar5 = func_0x000180261770((int64_t)&arg_30h + iVar4, (int64_t)&arg_40h + iVar4, in_R8 & 0xffffffff, 
                                    0x1804e26a8);
        if (iVar5 != 0) {
            iVar5 = *(int64_t *)(iVar5 + 0x10);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236740;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236758;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023676a;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236779;
                fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023678d;
                iVar3 = fcn.1802308d0(iVar5);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802367e8;
                    fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                    uVar2 = *(undefined8 *)((int64_t)&arg_40h + iVar4);
                    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236801;
                    fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236809;
                    iVar3 = func_0x000180203a00(iVar5);
                    if (iVar3 == 0x398) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236818;
                        iVar6 = func_0x00018022edf0(iVar5);
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236823;
                    fcn.18022ecc0(iVar5);
                    if (iVar6 == 0) {
                        return 0;
                    }
                    *in_RDX = uVar2;
                    if (in_RCX != (int64_t *)0x0) {
                        iVar5 = *in_RCX;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236838;
                        func_0x00018029a130(iVar5);
                        *in_RCX = iVar6;
                        return iVar6;
                    }
                    return iVar6;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236796;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802367ae;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802367c0;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802367cf;
                fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236851;
        fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
    }
    return 0;
}

// ============================================================
// Function: FUN_180236870
// Address: 0x180236870
// Size: 534 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.180236870(int64_t arg_48h, int64_t arg_50h, int64_t arg_60h)
{
    uint32_t *puVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 *in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x180236886;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_60h + iVar4) = *in_RDX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802368b4;
    iVar5 = fcn.180224d60(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
    *(int64_t *)((int64_t)&arg_50h + iVar4) = iVar5;
    if (iVar5 != 0) {
        uVar2 = *(undefined8 *)(iVar5 + 0x20);
        *(undefined8 *)(iVar5 + 0x18) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802368e2;
        fcn.180224990(uVar2, 0x1804e2700, 0x34);
        *(undefined8 *)(iVar5 + 0x20) = 0;
        puVar1 = (uint32_t *)(*(int64_t *)((int64_t)&arg_50h + iVar4) + 0x28);
        *puVar1 = *puVar1 | 1;
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18023690b;
        iVar5 = func_0x000180261770((int64_t)&arg_50h + iVar4, (int64_t)&arg_60h + iVar4, in_R8 & 0xffffffff, 
                                    0x1804e26a8);
        if (iVar5 != 0) {
            iVar5 = *(int64_t *)(iVar5 + 0x10);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236925;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18023693d;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18023694f;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18023695e;
                fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
                *(undefined8 *)((int64_t)&arg_50h + iVar4) = 0;
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236973;
                iVar3 = fcn.1802308d0(iVar5);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802369d1;
                    fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
                    uVar2 = *(undefined8 *)((int64_t)&arg_60h + iVar4);
                    *(undefined8 *)((int64_t)&arg_50h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802369ed;
                    fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802369f5;
                    iVar6 = func_0x00018022ee80(iVar5);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236a00;
                    fcn.18022ecc0(iVar5);
                    if (iVar6 == 0) {
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236a1c;
                    func_0x00018029a200(iVar6, &stack0xfffffffffffffff8 + iVar4, (int64_t)aiStackX_10 + iVar4 + -0x10, 
                                        (int64_t)aiStackX_10 + iVar4 + -8);
                    if (((*(int64_t *)(&stack0xfffffffffffffff8 + iVar4) != 0) &&
                        (*(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10) != 0)) &&
                       (*(int64_t *)((int64_t)aiStackX_10 + iVar4 + -8) != 0)) {
                        *in_RDX = uVar2;
                        if (in_RCX != (int64_t *)0x0) {
                            iVar5 = *in_RCX;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236a41;
                            func_0x00018029a6a0(iVar5);
                            *in_RCX = iVar6;
                        }
                        return iVar6;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236a60;
                    func_0x00018029a6a0(iVar6);
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x18023697c;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236994;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802369a6;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1802369b5;
                fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
                *(undefined8 *)((int64_t)&arg_50h + iVar4) = 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236a73;
        fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
    }
    return 0;
}

// ============================================================
// Function: FUN_180236a90
// Address: 0x180236a90
// Size: 468 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.180236a90(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h)
{
    uint32_t *puVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 *in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x180236aa6;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = *in_RDX;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236ad1;
    iVar5 = fcn.180224d60(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4));
    *(int64_t *)((int64_t)&arg_30h + iVar4) = iVar5;
    if (iVar5 != 0) {
        uVar2 = *(undefined8 *)(iVar5 + 0x20);
        *(undefined8 *)(iVar5 + 0x18) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236aff;
        fcn.180224990(uVar2, 0x1804e2700, 0x34);
        *(undefined8 *)(iVar5 + 0x20) = 0;
        puVar1 = (uint32_t *)(*(int64_t *)((int64_t)&arg_30h + iVar4) + 0x28);
        *puVar1 = *puVar1 | 1;
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236b25;
        iVar5 = func_0x000180261770((int64_t)&arg_30h + iVar4, (int64_t)&arg_40h + iVar4, in_R8 & 0xffffffff, 
                                    0x1804e26a8);
        if (iVar5 != 0) {
            iVar5 = *(int64_t *)(iVar5 + 0x10);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236b3f;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236b57;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236b69;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236b78;
                fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236b8d;
                iVar3 = fcn.1802308d0(iVar5);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236be8;
                    fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
                    uVar2 = *(undefined8 *)((int64_t)&arg_40h + iVar4);
                    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236c01;
                    fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236c09;
                    iVar6 = func_0x000180231cb0(iVar5);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236c14;
                    fcn.18022ecc0(iVar5);
                    if (iVar6 == 0) {
                        return 0;
                    }
                    *in_RDX = uVar2;
                    if (in_RCX != (int64_t *)0x0) {
                        iVar5 = *in_RCX;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236c29;
                        func_0x00018029e3b0(iVar5);
                        *in_RCX = iVar6;
                    }
                    return iVar6;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236b96;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236bae;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)aiStackX_10 + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236bc0;
                fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236bcf;
                fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180236c51;
        fcn.1802612b0(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + -0x10));
    }
    return 0;
}

// ============================================================
// Function: FUN_180236c70
// Address: 0x180236c70
// Size: 470 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180236c70(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t *puVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 *in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180236c88;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = *in_RDX;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236cb5;
    iVar5 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8));
    *(int64_t *)((int64_t)&arg_30h + iVar4) = iVar5;
    if (iVar5 != 0) {
        uVar2 = *(undefined8 *)(iVar5 + 0x20);
        *(undefined8 *)(iVar5 + 0x18) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236ce0;
        fcn.180224990(uVar2, 0x1804e2700, 0x34);
        *(undefined8 *)(iVar5 + 0x20) = 0;
        puVar1 = (uint32_t *)(*(int64_t *)((int64_t)&arg_30h + iVar4) + 0x28);
        *puVar1 = *puVar1 | 1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236d06;
        iVar5 = func_0x000180261770((int64_t)&arg_30h + iVar4, (int64_t)&arg_40h + iVar4, in_R8 & 0xffffffff, 
                                    0x1804e26a8);
        if (iVar5 != 0) {
            iVar5 = *(int64_t *)(iVar5 + 0x10);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236d20;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236d38;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236d4a;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236d59;
                fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236d6d;
                iVar3 = fcn.1802308d0(iVar5);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236dc8;
                    fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                    uVar2 = *(undefined8 *)((int64_t)&arg_40h + iVar4);
                    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236de1;
                    fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236de9;
                    iVar3 = func_0x000180203a00(iVar5);
                    if (iVar3 == 0x440) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236df8;
                        iVar6 = func_0x000180231cd0(iVar5);
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236e03;
                    fcn.18022ecc0(iVar5);
                    if (iVar6 == 0) {
                        return 0;
                    }
                    *in_RDX = uVar2;
                    if (in_RCX != (int64_t *)0x0) {
                        iVar5 = *in_RCX;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236e18;
                        func_0x00018029e3b0(iVar5);
                        *in_RCX = iVar6;
                        return iVar6;
                    }
                    return iVar6;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236d76;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236d8e;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236da0;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236daf;
                fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236e31;
        fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
    }
    return 0;
}

// ============================================================
// Function: FUN_180236e50
// Address: 0x180236e50
// Size: 55 bytes
// ============================================================
void fcn.180236e50(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180236e5a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(code **)((int64_t)&arg_30h + iVar1) = fcn.1802362c0;
    *(undefined4 *)((int64_t)&arg_28h + iVar1) = 1;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180236e82;
    fcn.180235ed0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x00000090 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180236e90
// Address: 0x180236e90
// Size: 470 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180236e90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t *puVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 *in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180236ea8;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = *in_RDX;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236ed5;
    iVar5 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8));
    *(int64_t *)((int64_t)&arg_30h + iVar4) = iVar5;
    if (iVar5 != 0) {
        uVar2 = *(undefined8 *)(iVar5 + 0x20);
        *(undefined8 *)(iVar5 + 0x18) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236f00;
        fcn.180224990(uVar2, 0x1804e2700, 0x34);
        *(undefined8 *)(iVar5 + 0x20) = 0;
        puVar1 = (uint32_t *)(*(int64_t *)((int64_t)&arg_30h + iVar4) + 0x28);
        *puVar1 = *puVar1 | 1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236f26;
        iVar5 = func_0x000180261770((int64_t)&arg_30h + iVar4, (int64_t)&arg_40h + iVar4, in_R8 & 0xffffffff, 
                                    0x1804e26a8);
        if (iVar5 != 0) {
            iVar5 = *(int64_t *)(iVar5 + 0x10);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236f40;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236f58;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236f6a;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236f79;
                fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236f8d;
                iVar3 = fcn.1802308d0(iVar5);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236fe8;
                    fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                    uVar2 = *(undefined8 *)((int64_t)&arg_40h + iVar4);
                    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180237001;
                    fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180237009;
                    iVar3 = func_0x000180203a00(iVar5);
                    if (iVar3 == 0x40a) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180237018;
                        iVar6 = func_0x000180231cf0(iVar5);
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180237023;
                    fcn.18022ecc0(iVar5);
                    if (iVar6 == 0) {
                        return 0;
                    }
                    *in_RDX = uVar2;
                    if (in_RCX != (int64_t *)0x0) {
                        iVar5 = *in_RCX;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180237038;
                        func_0x00018029e3b0(iVar5);
                        *in_RCX = iVar6;
                        return iVar6;
                    }
                    return iVar6;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236f96;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236fae;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236fc0;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180236fcf;
                fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180237051;
        fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
    }
    return 0;
}

// ============================================================
// Function: FUN_180237070
// Address: 0x180237070
// Size: 470 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180237070(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint32_t *puVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 *in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180237088;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = *in_RDX;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802370b5;
    iVar5 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8));
    *(int64_t *)((int64_t)&arg_30h + iVar4) = iVar5;
    if (iVar5 != 0) {
        uVar2 = *(undefined8 *)(iVar5 + 0x20);
        *(undefined8 *)(iVar5 + 0x18) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802370e0;
        fcn.180224990(uVar2, 0x1804e2700, 0x34);
        *(undefined8 *)(iVar5 + 0x20) = 0;
        puVar1 = (uint32_t *)(*(int64_t *)((int64_t)&arg_30h + iVar4) + 0x28);
        *puVar1 = *puVar1 | 1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180237106;
        iVar5 = func_0x000180261770((int64_t)&arg_30h + iVar4, (int64_t)&arg_40h + iVar4, in_R8 & 0xffffffff, 
                                    0x1804e26a8);
        if (iVar5 != 0) {
            iVar5 = *(int64_t *)(iVar5 + 0x10);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180237120;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180237138;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023714a;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180237159;
                fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
            } else {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023716d;
                iVar3 = fcn.1802308d0(iVar5);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802371c8;
                    fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                    uVar2 = *(undefined8 *)((int64_t)&arg_40h + iVar4);
                    *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802371e1;
                    fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802371e9;
                    iVar3 = func_0x000180203a00(iVar5);
                    if (iVar3 == 0x40b) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802371f8;
                        iVar6 = func_0x000180231d10(iVar5);
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180237203;
                    fcn.18022ecc0(iVar5);
                    if (iVar6 == 0) {
                        return 0;
                    }
                    *in_RDX = uVar2;
                    if (in_RCX != (int64_t *)0x0) {
                        iVar5 = *in_RCX;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180237218;
                        func_0x00018029e3b0(iVar5);
                        *in_RCX = iVar6;
                        return iVar6;
                    }
                    return iVar6;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180237176;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023718e;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802371a0;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802371af;
                fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
                *(undefined8 *)((int64_t)&arg_30h + iVar4) = 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180237231;
        fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_10 + iVar4));
    }
    return 0;
}

// ============================================================
// Function: FUN_180237250
// Address: 0x180237250
// Size: 127 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180237250(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_70h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023726a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023728f;
    iVar2 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + iVar1 + -8));
    *(int64_t *)((int64_t)&arg_28h + iVar1) = iVar2;
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&iStackX_20 + iVar1) = in_R9;
        *(undefined8 *)((int64_t)&iStackX_20 + iVar1 + -8) = in_R8;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802372ba;
        fcn.180261850(*(int64_t *)((int64_t)&iStackX_20 + iVar1 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar1), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                      *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_48h + iVar1), 
                      *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x000000b0 + iVar1), 
                      *(int64_t *)(&stack0x000000b8 + iVar1));
    }
    return;
}

// ============================================================
// Function: FUN_1802372f0
// Address: 0x1802372f0
// Size: 327 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1802372f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180237306;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023731a;
    fcn.18022cd20(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3), *(int64_t *)(&stack0x00000060 + iVar3));
    if ((*(uint8_t *)(in_RDX + 0x28) & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180237329;
        iVar4 = fcn.18029b6c0(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000060 + iVar3), 
                              *(int64_t *)(&stack0x00000068 + iVar3), *(int64_t *)(&stack0x00000080 + iVar3));
        if (iVar4 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180237347;
        fcn.18026aee0(*(int64_t *)((int64_t)&iStackX_20 + iVar3));
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180237351;
    iVar4 = fcn.18022fd80(*(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000040 + iVar3));
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023735e;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180237376;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180237388;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023739c;
    iVar2 = fcn.1802304b0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3));
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802373a5;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802373bd;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
    } else {
        pcVar1 = *(code **)(*(int64_t *)(iVar4 + 8) + 0x20);
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802373da;
            iVar2 = (*pcVar1)(iVar4, in_RDX);
            if (iVar2 != 0) {
                *in_RCX = iVar4;
                return 1;
            }
            goto code_r0x000180237417;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802373ed;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180237405;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180237417;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
code_r0x000180237417:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18023741f;
    fcn.18022ecc0(iVar4);
    return 0;
}

// ============================================================
// Function: FUN_180237450
// Address: 0x180237450
// Size: 29 bytes
// ============================================================
void fcn.180237450(undefined8 param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00000030 + iVar1) = param_1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1) = 0x1802612bf;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x1802612cf;
    fcn.1802612e0(*(int64_t *)(&stack0x00000048 + iVar2 + iVar1), *(int64_t *)(&stack0x00000050 + iVar2 + iVar1), 
                  *(int64_t *)(&stack0x00000058 + iVar2 + iVar1), *(int64_t *)(&stack0x00000060 + iVar2 + iVar1));
    return;
}

