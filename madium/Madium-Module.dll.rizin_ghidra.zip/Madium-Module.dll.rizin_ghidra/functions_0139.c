// Chunk 139 - 50 functions

// ============================================================
// Function: FUN_1801dd2b0
// Address: 0x1801dd2b0
// Size: 187 bytes
// ============================================================
void fcn.1801dd2b0(int64_t arg_28h)
{
    char cVar1;
    code *pcVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dd2bc;
    iVar5 = func_0x00018045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_28h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar5);
    pcVar2 = *(code **)(in_RCX + 0x28);
    uVar3 = *(undefined8 *)(in_RCX + 0x30);
    *(undefined (*) [16])((int64_t)&var_18h + iVar5) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dd2eb;
    (*pcVar2)((int64_t)&var_18h + iVar5, uVar3, in_RDX & 0xffffffff);
    cVar1 = *(char *)((int64_t)&var_20h + iVar5 + 1);
    uVar6 = ((int32_t)*(char *)((int64_t)&var_20h + iVar5) ^ *(uint32_t *)(in_RCX + 0x58)) & 1 ^
            *(uint32_t *)(in_RCX + 0x58);
    *(undefined8 *)(in_RCX + 0x20) = *(undefined8 *)((int64_t)&var_18h + iVar5);
    uVar6 = (cVar1 * 2 ^ uVar6) & 2 ^ uVar6;
    cVar1 = *(char *)((int64_t)&var_20h + iVar5 + 2);
    *(uint32_t *)(in_RCX + 0x58) = uVar6;
    if (((cVar1 != '\0') && ((uVar6 & 0x10) != 0)) && (*(int64_t *)(in_RCX + 0x50) != 0)) {
        if ((uVar6 & 0x20) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dd334;
            func_0x0001801f81d0(in_RCX + 0x40);
            *(uint32_t *)(in_RCX + 0x58) = *(uint32_t *)(in_RCX + 0x58) | 0x20;
            if ((*(uint32_t *)(in_RCX + 0x58) & 0x20) == 0) goto code_r0x0001801dd353;
        }
        do {
            uVar3 = *(undefined8 *)(in_RCX + 0x38);
            uVar4 = *(undefined8 *)(in_RCX + 0x48);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dd34d;
            func_0x00018026d610(uVar4, uVar3);
        } while ((*(uint8_t *)(in_RCX + 0x58) & 0x20) != 0);
    }
code_r0x0001801dd353:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801dd365;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_28h + iVar5) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_1801dd370
// Address: 0x1801dd370
// Size: 370 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_690h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6a0h because it doesn't fit into ProtoModel

void fcn.1801dd370(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined auVar1 [16];
    undefined auVar2 [16];
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t in_RCX;
    int32_t in_EDX;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    uint32_t uVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    uint64_t in_R8;
    uint64_t uVar13;
    int32_t in_R9D;
    int32_t iVar14;
    undefined8 unaff_R12;
    undefined8 unaff_R15;
    bool bVar15;
    uint64_t auStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_458h;
    int64_t var_450h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_38h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801dd389;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar4);
    uVar12 = 0;
    uVar5 = in_R8 & 0xffffffff;
    iVar3 = (int32_t)in_RCX;
    var_458h._0_4_ = 0;
    var_248h._0_4_ = 0;
    *(undefined4 *)((int64_t)&var_18h + iVar4) = 0;
    if ((iVar3 != -1) && (in_EDX != 0)) {
        uVar12 = 1;
        var_450h = in_RCX & 0xffffffff;
        var_458h._0_4_ = 1;
    }
    iVar14 = (int32_t)in_R8;
    if ((iVar14 != -1) && (in_R9D != 0)) {
        var_240h = uVar5;
        var_248h._0_4_ = 1;
    }
    bVar15 = iVar3 != -1;
    if (bVar15) {
        *(uint64_t *)((int64_t)&var_20h + iVar4) = in_RCX & 0xffffffff;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 1;
    }
    uVar6 = (uint32_t)bVar15;
    if (iVar14 != -1) {
        uVar13 = 0;
        uVar11 = (uint32_t)bVar15;
        if (uVar11 != 0) {
            do {
                if (*(uint64_t *)((int64_t)&var_20h + uVar13 * 8 + iVar4) == uVar5) break;
                uVar10 = (int32_t)uVar13 + 1;
                uVar13 = (uint64_t)uVar10;
            } while (uVar10 < uVar11);
        }
        if (((uint32_t)uVar13 == uVar11) && (uVar11 < 0x40)) {
            *(uint64_t *)((int64_t)&var_20h + uVar13 * 8 + iVar4) = uVar5;
            uVar6 = *(int32_t *)((int64_t)&var_18h + iVar4) + 1;
            *(uint32_t *)((int64_t)&var_18h + iVar4) = uVar6;
        }
    }
    uVar5 = arg_28h & 0xffffffff;
    if ((int32_t)arg_28h != -1) {
        uVar13 = 0;
        if (uVar12 != 0) {
            do {
                if ((&var_450h)[uVar13] == uVar5) break;
                uVar11 = (int32_t)uVar13 + 1;
                uVar13 = (uint64_t)uVar11;
            } while (uVar11 < uVar12);
        }
        if (((uint32_t)uVar13 == uVar12) && (uVar12 < 0x40)) {
            (&var_450h)[uVar13] = uVar5;
            var_458h._0_4_ = (int32_t)var_458h + 1;
        }
        uVar13 = 0;
        if (uVar6 != 0) {
            do {
                if (*(uint64_t *)((int64_t)&var_20h + uVar13 * 8 + iVar4) == uVar5) break;
                uVar12 = (int32_t)uVar13 + 1;
                uVar13 = (uint64_t)uVar12;
            } while (uVar12 < uVar6);
        }
        if (((uint32_t)uVar13 == uVar6) && (uVar6 < 0x40)) {
            *(uint64_t *)((int64_t)&var_20h + uVar13 * 8 + iVar4) = uVar5;
            *(int32_t *)((int64_t)&var_18h + iVar4) = *(int32_t *)((int64_t)&var_18h + iVar4) + 1;
        }
    }
    iVar9 = iVar14;
    if (iVar14 <= iVar3) {
        iVar9 = iVar3;
    }
    if (iVar9 < (int32_t)arg_28h) {
        iVar9 = (int32_t)arg_28h;
    }
    if (((iVar3 != -1) || (iVar14 != -1)) || (arg_30h != -1)) {
        *(undefined8 *)(&stack0x00000690 + iVar4) = unaff_R12;
        *(undefined8 *)(&stack0x000006a0 + iVar4) = unaff_R15;
        if (arg_38h != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801dd4ff;
            func_0x00018026d900(arg_38h);
        }
        do {
            if (arg_30h == -1) {
                iVar7 = 0;
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801dd525;
                uVar5 = func_0x0001802450c0();
                if ((uint64_t)arg_30h < uVar5) {
                    uVar5 = 999;
                } else if (~(arg_30h - uVar5) < 999) {
                    uVar5 = 0xffffffffffffffff;
                } else {
                    uVar5 = (arg_30h - uVar5) + 999;
                }
                auVar1._8_8_ = 0;
                auVar1._0_8_ = uVar5;
                iVar7 = SUB168(ZEXT816(0x12e0be826d694b2f) * auVar1, 8);
                uVar13 = (uVar5 - iVar7 >> 1) + iVar7 >> 0x1d;
                uVar5 = uVar5 + uVar13 * -1000000000;
                auVar2._8_8_ = 0;
                auVar2._0_8_ = uVar5;
                iVar8 = SUB168(ZEXT816(0x624dd2f1a9fbe77) * auVar2, 8);
                iVar7 = (int64_t)auStackX_8 + iVar4;
                *(uint64_t *)((int64_t)auStackX_8 + iVar4) =
                     (iVar8 + (uVar5 - iVar8 >> 1) >> 9) << 0x20 | uVar13 & 0xffffffff;
            }
            *(int64_t *)((int64_t)&var_8h + iVar4) = iVar7;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801dd5c2;
            iVar3 = (*(code *)0x8000000000000012)(iVar9 + 1, &var_458h, &var_248h, (int64_t)&var_18h + iVar4);
            if (iVar3 != -1) break;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801dd5cf;
            iVar3 = (*(code *)0x800000000000006f)();
        } while (iVar3 == 0x2714);
        if (arg_38h != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801dd5f7;
            func_0x00018026d890(arg_38h);
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801dd60d;
    func_0x000180459870(var_38h ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801dd4e2
// Address: 0x1801dd4e2
// Size: 269 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_690h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6a0h because it doesn't fit into ProtoModel

void fcn.1801dd370(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined auVar1 [16];
    undefined auVar2 [16];
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t in_RCX;
    int32_t in_EDX;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    uint32_t uVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    uint64_t in_R8;
    uint64_t uVar13;
    int32_t in_R9D;
    int32_t iVar14;
    undefined8 unaff_R12;
    undefined8 unaff_R15;
    bool bVar15;
    uint64_t auStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_458h;
    int64_t var_450h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_38h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801dd389;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar4);
    uVar12 = 0;
    uVar5 = in_R8 & 0xffffffff;
    iVar3 = (int32_t)in_RCX;
    var_458h._0_4_ = 0;
    var_248h._0_4_ = 0;
    *(undefined4 *)((int64_t)&var_18h + iVar4) = 0;
    if ((iVar3 != -1) && (in_EDX != 0)) {
        uVar12 = 1;
        var_450h = in_RCX & 0xffffffff;
        var_458h._0_4_ = 1;
    }
    iVar14 = (int32_t)in_R8;
    if ((iVar14 != -1) && (in_R9D != 0)) {
        var_240h = uVar5;
        var_248h._0_4_ = 1;
    }
    bVar15 = iVar3 != -1;
    if (bVar15) {
        *(uint64_t *)((int64_t)&var_20h + iVar4) = in_RCX & 0xffffffff;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 1;
    }
    uVar6 = (uint32_t)bVar15;
    if (iVar14 != -1) {
        uVar13 = 0;
        uVar11 = (uint32_t)bVar15;
        if (uVar11 != 0) {
            do {
                if (*(uint64_t *)((int64_t)&var_20h + uVar13 * 8 + iVar4) == uVar5) break;
                uVar10 = (int32_t)uVar13 + 1;
                uVar13 = (uint64_t)uVar10;
            } while (uVar10 < uVar11);
        }
        if (((uint32_t)uVar13 == uVar11) && (uVar11 < 0x40)) {
            *(uint64_t *)((int64_t)&var_20h + uVar13 * 8 + iVar4) = uVar5;
            uVar6 = *(int32_t *)((int64_t)&var_18h + iVar4) + 1;
            *(uint32_t *)((int64_t)&var_18h + iVar4) = uVar6;
        }
    }
    uVar5 = arg_28h & 0xffffffff;
    if ((int32_t)arg_28h != -1) {
        uVar13 = 0;
        if (uVar12 != 0) {
            do {
                if ((&var_450h)[uVar13] == uVar5) break;
                uVar11 = (int32_t)uVar13 + 1;
                uVar13 = (uint64_t)uVar11;
            } while (uVar11 < uVar12);
        }
        if (((uint32_t)uVar13 == uVar12) && (uVar12 < 0x40)) {
            (&var_450h)[uVar13] = uVar5;
            var_458h._0_4_ = (int32_t)var_458h + 1;
        }
        uVar13 = 0;
        if (uVar6 != 0) {
            do {
                if (*(uint64_t *)((int64_t)&var_20h + uVar13 * 8 + iVar4) == uVar5) break;
                uVar12 = (int32_t)uVar13 + 1;
                uVar13 = (uint64_t)uVar12;
            } while (uVar12 < uVar6);
        }
        if (((uint32_t)uVar13 == uVar6) && (uVar6 < 0x40)) {
            *(uint64_t *)((int64_t)&var_20h + uVar13 * 8 + iVar4) = uVar5;
            *(int32_t *)((int64_t)&var_18h + iVar4) = *(int32_t *)((int64_t)&var_18h + iVar4) + 1;
        }
    }
    iVar9 = iVar14;
    if (iVar14 <= iVar3) {
        iVar9 = iVar3;
    }
    if (iVar9 < (int32_t)arg_28h) {
        iVar9 = (int32_t)arg_28h;
    }
    if (((iVar3 != -1) || (iVar14 != -1)) || (arg_30h != -1)) {
        *(undefined8 *)(&stack0x00000690 + iVar4) = unaff_R12;
        *(undefined8 *)(&stack0x000006a0 + iVar4) = unaff_R15;
        if (arg_38h != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801dd4ff;
            func_0x00018026d900(arg_38h);
        }
        do {
            if (arg_30h == -1) {
                iVar7 = 0;
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801dd525;
                uVar5 = func_0x0001802450c0();
                if ((uint64_t)arg_30h < uVar5) {
                    uVar5 = 999;
                } else if (~(arg_30h - uVar5) < 999) {
                    uVar5 = 0xffffffffffffffff;
                } else {
                    uVar5 = (arg_30h - uVar5) + 999;
                }
                auVar1._8_8_ = 0;
                auVar1._0_8_ = uVar5;
                iVar7 = SUB168(ZEXT816(0x12e0be826d694b2f) * auVar1, 8);
                uVar13 = (uVar5 - iVar7 >> 1) + iVar7 >> 0x1d;
                uVar5 = uVar5 + uVar13 * -1000000000;
                auVar2._8_8_ = 0;
                auVar2._0_8_ = uVar5;
                iVar8 = SUB168(ZEXT816(0x624dd2f1a9fbe77) * auVar2, 8);
                iVar7 = (int64_t)auStackX_8 + iVar4;
                *(uint64_t *)((int64_t)auStackX_8 + iVar4) =
                     (iVar8 + (uVar5 - iVar8 >> 1) >> 9) << 0x20 | uVar13 & 0xffffffff;
            }
            *(int64_t *)((int64_t)&var_8h + iVar4) = iVar7;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801dd5c2;
            iVar3 = (*(code *)0x8000000000000012)(iVar9 + 1, &var_458h, &var_248h, (int64_t)&var_18h + iVar4);
            if (iVar3 != -1) break;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801dd5cf;
            iVar3 = (*(code *)0x800000000000006f)();
        } while (iVar3 == 0x2714);
        if (arg_38h != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801dd5f7;
            func_0x00018026d890(arg_38h);
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801dd60d;
    func_0x000180459870(var_38h ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801dd5ef
// Address: 0x1801dd5ef
// Size: 44 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_690h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6a0h because it doesn't fit into ProtoModel

void fcn.1801dd370(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined auVar1 [16];
    undefined auVar2 [16];
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t in_RCX;
    int32_t in_EDX;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    uint32_t uVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    uint64_t in_R8;
    uint64_t uVar13;
    int32_t in_R9D;
    int32_t iVar14;
    undefined8 unaff_R12;
    undefined8 unaff_R15;
    bool bVar15;
    uint64_t auStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_458h;
    int64_t var_450h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_38h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801dd389;
    iVar4 = func_0x00018045a350();
    iVar4 = -iVar4;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar4);
    uVar12 = 0;
    uVar5 = in_R8 & 0xffffffff;
    iVar3 = (int32_t)in_RCX;
    var_458h._0_4_ = 0;
    var_248h._0_4_ = 0;
    *(undefined4 *)((int64_t)&var_18h + iVar4) = 0;
    if ((iVar3 != -1) && (in_EDX != 0)) {
        uVar12 = 1;
        var_450h = in_RCX & 0xffffffff;
        var_458h._0_4_ = 1;
    }
    iVar14 = (int32_t)in_R8;
    if ((iVar14 != -1) && (in_R9D != 0)) {
        var_240h = uVar5;
        var_248h._0_4_ = 1;
    }
    bVar15 = iVar3 != -1;
    if (bVar15) {
        *(uint64_t *)((int64_t)&var_20h + iVar4) = in_RCX & 0xffffffff;
        *(undefined4 *)((int64_t)&var_18h + iVar4) = 1;
    }
    uVar6 = (uint32_t)bVar15;
    if (iVar14 != -1) {
        uVar13 = 0;
        uVar11 = (uint32_t)bVar15;
        if (uVar11 != 0) {
            do {
                if (*(uint64_t *)((int64_t)&var_20h + uVar13 * 8 + iVar4) == uVar5) break;
                uVar10 = (int32_t)uVar13 + 1;
                uVar13 = (uint64_t)uVar10;
            } while (uVar10 < uVar11);
        }
        if (((uint32_t)uVar13 == uVar11) && (uVar11 < 0x40)) {
            *(uint64_t *)((int64_t)&var_20h + uVar13 * 8 + iVar4) = uVar5;
            uVar6 = *(int32_t *)((int64_t)&var_18h + iVar4) + 1;
            *(uint32_t *)((int64_t)&var_18h + iVar4) = uVar6;
        }
    }
    uVar5 = arg_28h & 0xffffffff;
    if ((int32_t)arg_28h != -1) {
        uVar13 = 0;
        if (uVar12 != 0) {
            do {
                if ((&var_450h)[uVar13] == uVar5) break;
                uVar11 = (int32_t)uVar13 + 1;
                uVar13 = (uint64_t)uVar11;
            } while (uVar11 < uVar12);
        }
        if (((uint32_t)uVar13 == uVar12) && (uVar12 < 0x40)) {
            (&var_450h)[uVar13] = uVar5;
            var_458h._0_4_ = (int32_t)var_458h + 1;
        }
        uVar13 = 0;
        if (uVar6 != 0) {
            do {
                if (*(uint64_t *)((int64_t)&var_20h + uVar13 * 8 + iVar4) == uVar5) break;
                uVar12 = (int32_t)uVar13 + 1;
                uVar13 = (uint64_t)uVar12;
            } while (uVar12 < uVar6);
        }
        if (((uint32_t)uVar13 == uVar6) && (uVar6 < 0x40)) {
            *(uint64_t *)((int64_t)&var_20h + uVar13 * 8 + iVar4) = uVar5;
            *(int32_t *)((int64_t)&var_18h + iVar4) = *(int32_t *)((int64_t)&var_18h + iVar4) + 1;
        }
    }
    iVar9 = iVar14;
    if (iVar14 <= iVar3) {
        iVar9 = iVar3;
    }
    if (iVar9 < (int32_t)arg_28h) {
        iVar9 = (int32_t)arg_28h;
    }
    if (((iVar3 != -1) || (iVar14 != -1)) || (arg_30h != -1)) {
        *(undefined8 *)(&stack0x00000690 + iVar4) = unaff_R12;
        *(undefined8 *)(&stack0x000006a0 + iVar4) = unaff_R15;
        if (arg_38h != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801dd4ff;
            func_0x00018026d900(arg_38h);
        }
        do {
            if (arg_30h == -1) {
                iVar7 = 0;
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801dd525;
                uVar5 = func_0x0001802450c0();
                if ((uint64_t)arg_30h < uVar5) {
                    uVar5 = 999;
                } else if (~(arg_30h - uVar5) < 999) {
                    uVar5 = 0xffffffffffffffff;
                } else {
                    uVar5 = (arg_30h - uVar5) + 999;
                }
                auVar1._8_8_ = 0;
                auVar1._0_8_ = uVar5;
                iVar7 = SUB168(ZEXT816(0x12e0be826d694b2f) * auVar1, 8);
                uVar13 = (uVar5 - iVar7 >> 1) + iVar7 >> 0x1d;
                uVar5 = uVar5 + uVar13 * -1000000000;
                auVar2._8_8_ = 0;
                auVar2._0_8_ = uVar5;
                iVar8 = SUB168(ZEXT816(0x624dd2f1a9fbe77) * auVar2, 8);
                iVar7 = (int64_t)auStackX_8 + iVar4;
                *(uint64_t *)((int64_t)auStackX_8 + iVar4) =
                     (iVar8 + (uVar5 - iVar8 >> 1) >> 9) << 0x20 | uVar13 & 0xffffffff;
            }
            *(int64_t *)((int64_t)&var_8h + iVar4) = iVar7;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801dd5c2;
            iVar3 = (*(code *)0x8000000000000012)(iVar9 + 1, &var_458h, &var_248h, (int64_t)&var_18h + iVar4);
            if (iVar3 != -1) break;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801dd5cf;
            iVar3 = (*(code *)0x800000000000006f)();
        } while (iVar3 == 0x2714);
        if (arg_38h != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801dd5f7;
            func_0x00018026d890(arg_38h);
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801dd60d;
    func_0x000180459870(var_38h ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801dd620
// Address: 0x1801dd620
// Size: 88 bytes
// ============================================================
undefined8 fcn.1801dd620(int64_t arg_30h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t in_RCX;
    int64_t *in_RDX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801dd62a;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    iVar2 = *(int64_t *)(in_RCX + 0x98);
    iVar3 = *in_RDX;
    iVar4 = in_RDX[1];
    uVar5 = *(undefined4 *)(in_RDX + 2);
    uVar6 = *(undefined4 *)((int64_t)in_RDX + 0x14);
    uVar7 = *(undefined4 *)(in_RDX + 3);
    uVar8 = *(undefined4 *)((int64_t)in_RDX + 0x1c);
    iVar1 = in_RDX[4];
    *(int64_t *)((int64_t)&var_20h + iVar9) = iVar3;
    *(int64_t *)(&stack0x00000028 + iVar9) = iVar4;
    *(undefined4 *)((int64_t)&arg_30h + iVar9) = uVar5;
    *(undefined4 *)((int64_t)&arg_30h + iVar9 + 4) = uVar6;
    *(undefined4 *)(&stack0x00000038 + iVar9) = uVar7;
    *(undefined4 *)(&stack0x0000003c + iVar9) = uVar8;
    *(int64_t *)((int64_t)&arg_40h + iVar9) = iVar1;
    if ((iVar2 == 0) && (iVar3 == 0)) {
        *(int64_t *)((int64_t)&var_20h + iVar9) = in_RCX;
        *(undefined8 *)((int64_t)&uStack_8 + iVar9) = 0x1801dd66c;
        uVar10 = fcn.1801e8ea0(*(int64_t *)((int64_t)&var_20h + iVar9));
        return uVar10;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801dd680
// Address: 0x1801dd680
// Size: 58 bytes
// ============================================================
void fcn.1801dd680(int64_t arg1)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801dd690;
        iVar1 = fcn.18045a350();
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x1801dd69f;
        fcn.1801dd130(arg1 + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x1801dd6b4;
        fcn.180224990(arg1, 0x1804b6330, 0x33);
    }
    return;
}

// ============================================================
// Function: FUN_1801dd6e0
// Address: 0x1801dd6e0
// Size: 42 bytes
// ============================================================
void fcn.1801dd6e0(int64_t arg_48h, int64_t arg_50h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(code **)(in_RCX + 0x18) == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar1) = 0x1802450ca;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        *(uint64_t *)((int64_t)&arg_60h + iVar2 + iVar1) =
             *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0x00000028 + iVar2 + iVar1);
        *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x1802450e7;
        (*(code *)0x69a176)((int64_t)&arg_50h + iVar2 + iVar1);
        *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x1802450f7;
        (*(code *)0x69a186)((int64_t)&arg_50h + iVar2 + iVar1, (int64_t)&arg_48h + iVar2 + iVar1);
        *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x180245117;
        fcn.180459870(*(uint64_t *)((int64_t)&arg_60h + iVar2 + iVar1) ^ (uint64_t)(&stack0x00000028 + iVar2 + iVar1));
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001801dd707. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(in_RCX + 0x18))(*(undefined8 *)(in_RCX + 0x20));
    return;
}

// ============================================================
// Function: FUN_1801dd710
// Address: 0x1801dd710
// Size: 41 bytes
// ============================================================
uint64_t fcn.1801dd710(int64_t arg_28h, int64_t arg_58h)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    uint64_t uVar5;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dd71c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar1 = *(code **)(in_RCX + 0x18);
    if ((pcVar1 == (code *)0x0) || (0xfffffffffffffffd < in_RDX - 1)) {
        return in_RDX;
    }
    uVar2 = *(undefined8 *)(in_RCX + 0x20);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801dd740;
    uVar4 = (*pcVar1)(uVar2);
    uVar5 = 0;
    if (uVar4 <= in_RDX) {
        uVar5 = in_RDX - uVar4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801dd754;
    uVar4 = fcn.1802450c0(*(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
    if (~uVar5 < uVar4) {
        return 0xffffffffffffffff;
    }
    return uVar4 + uVar5;
}

// ============================================================
// Function: FUN_1801dd739
// Address: 0x1801dd739
// Size: 56 bytes
// ============================================================
uint64_t fcn.1801dd710(int64_t arg_28h, int64_t arg_58h)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    uint64_t uVar5;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dd71c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar1 = *(code **)(in_RCX + 0x18);
    if ((pcVar1 == (code *)0x0) || (0xfffffffffffffffd < in_RDX - 1)) {
        return in_RDX;
    }
    uVar2 = *(undefined8 *)(in_RCX + 0x20);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801dd740;
    uVar4 = (*pcVar1)(uVar2);
    uVar5 = 0;
    if (uVar4 <= in_RDX) {
        uVar5 = in_RDX - uVar4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801dd754;
    uVar4 = fcn.1802450c0(*(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
    if (~uVar5 < uVar4) {
        return 0xffffffffffffffff;
    }
    return uVar4 + uVar5;
}

// ============================================================
// Function: FUN_1801dd771
// Address: 0x1801dd771
// Size: 14 bytes
// ============================================================
uint64_t fcn.1801dd710(int64_t arg_28h, int64_t arg_58h)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    uint64_t uVar5;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dd71c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar1 = *(code **)(in_RCX + 0x18);
    if ((pcVar1 == (code *)0x0) || (0xfffffffffffffffd < in_RDX - 1)) {
        return in_RDX;
    }
    uVar2 = *(undefined8 *)(in_RCX + 0x20);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801dd740;
    uVar4 = (*pcVar1)(uVar2);
    uVar5 = 0;
    if (uVar4 <= in_RDX) {
        uVar5 = in_RDX - uVar4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801dd754;
    uVar4 = fcn.1802450c0(*(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
    if (~uVar5 < uVar4) {
        return 0xffffffffffffffff;
    }
    return uVar4 + uVar5;
}

// ============================================================
// Function: FUN_1801dd77f
// Address: 0x1801dd77f
// Size: 9 bytes
// ============================================================
uint64_t fcn.1801dd710(int64_t arg_28h, int64_t arg_58h)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RDI;
    uint64_t uVar5;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dd71c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar1 = *(code **)(in_RCX + 0x18);
    if ((pcVar1 == (code *)0x0) || (0xfffffffffffffffd < in_RDX - 1)) {
        return in_RDX;
    }
    uVar2 = *(undefined8 *)(in_RCX + 0x20);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801dd740;
    uVar4 = (*pcVar1)(uVar2);
    uVar5 = 0;
    if (uVar4 <= in_RDX) {
        uVar5 = in_RDX - uVar4;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801dd754;
    uVar4 = fcn.1802450c0(*(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
    if (~uVar5 < uVar4) {
        return 0xffffffffffffffff;
    }
    return uVar4 + uVar5;
}

// ============================================================
// Function: FUN_1801dd790
// Address: 0x1801dd790
// Size: 164 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.1801dd790(int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 *puVar3;
    undefined8 *in_RCX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dd7a0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dd7bd;
    puVar3 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar2));
    if (puVar3 != (undefined8 *)0x0) {
        *puVar3 = *in_RCX;
        puVar3[1] = in_RCX[1];
        puVar3[2] = in_RCX[2];
        *(undefined8 *)((int64_t)&var_20h + iVar2) = in_RCX[3];
        *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dd800;
        iVar1 = fcn.1801dd180(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&arg_38h + iVar2), 
                              *(int64_t *)(&stack0x00000040 + iVar2));
        if (iVar1 != 0) {
            return puVar3;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dd819;
        fcn.180224990(puVar3, 0x1804b6330, 0x26);
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_1801dd860
// Address: 0x1801dd860
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801dd860(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dd870;
    iVar2 = fcn.18045a350();
    for (iVar1 = *(int64_t *)(in_RCX + 0x88); iVar1 != 0; iVar1 = *(int64_t *)(iVar1 + 8)) {
        *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801dd88b;
        func_0x0001801e93b0(iVar1, in_RDX & 0xffffffff);
    }
    return;
}

// ============================================================
// Function: FUN_1801dd8a0
// Address: 0x1801dd8a0
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

void fcn.1801dd8a0(int64_t arg_30h, int64_t arg_90h)
{
    int64_t iVar1;
    uint64_t uVar2;
    undefined uVar3;
    int64_t iVar4;
    uint64_t *in_RCX;
    uint64_t uVar5;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    int64_t var_10h;
    char var_18h [8];
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801dd8ad;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&var_20h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar4);
    *(undefined2 *)(in_RCX + 1) = 0;
    *(undefined *)((int64_t)in_RCX + 10) = 0;
    *in_RCX = 0xffffffffffffffff;
    if ((*(uint8_t *)(in_RDX + 0xa0) & 1) == 0) {
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
        for (iVar1 = *(int64_t *)(in_RDX + 0x88); iVar1 != 0; iVar1 = *(int64_t *)(iVar1 + 8)) {
            *(undefined (*) [16])(var_18h + iVar4 + -8) = ZEXT816(0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801dd918;
            func_0x0001801e9220(iVar1, var_18h + iVar4 + -8, in_R8 & 0xffffffff);
            if ((*(char *)(in_RCX + 1) == '\0') && (var_18h[iVar4] == '\0')) {
                uVar3 = 0;
            } else {
                uVar3 = 1;
            }
            *(undefined *)(in_RCX + 1) = uVar3;
            if ((*(char *)((int64_t)in_RCX + 9) == '\0') && (var_18h[iVar4 + 1] == '\0')) {
                uVar3 = 0;
            } else {
                uVar3 = 1;
            }
            *(undefined *)((int64_t)in_RCX + 9) = uVar3;
            if ((*(char *)((int64_t)in_RCX + 10) == '\0') && (var_18h[iVar4 + 2] == '\0')) {
                uVar3 = 0;
            } else {
                uVar3 = 1;
            }
            uVar5 = *in_RCX;
            uVar2 = *(uint64_t *)(var_18h + iVar4 + -8);
            *(undefined *)((int64_t)in_RCX + 10) = uVar3;
            if (uVar2 <= uVar5) {
                uVar5 = *(uint64_t *)(var_18h + iVar4 + -8);
            }
            *in_RCX = uVar5;
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801dd986;
    fcn.180459870(*(uint64_t *)((int64_t)&var_20h + iVar4) ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801dd8e3
// Address: 0x1801dd8e3
// Size: 150 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

void fcn.1801dd8a0(int64_t arg_30h, int64_t arg_90h)
{
    int64_t iVar1;
    uint64_t uVar2;
    undefined uVar3;
    int64_t iVar4;
    uint64_t *in_RCX;
    uint64_t uVar5;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    int64_t var_10h;
    char var_18h [8];
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801dd8ad;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&var_20h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar4);
    *(undefined2 *)(in_RCX + 1) = 0;
    *(undefined *)((int64_t)in_RCX + 10) = 0;
    *in_RCX = 0xffffffffffffffff;
    if ((*(uint8_t *)(in_RDX + 0xa0) & 1) == 0) {
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
        for (iVar1 = *(int64_t *)(in_RDX + 0x88); iVar1 != 0; iVar1 = *(int64_t *)(iVar1 + 8)) {
            *(undefined (*) [16])(var_18h + iVar4 + -8) = ZEXT816(0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801dd918;
            func_0x0001801e9220(iVar1, var_18h + iVar4 + -8, in_R8 & 0xffffffff);
            if ((*(char *)(in_RCX + 1) == '\0') && (var_18h[iVar4] == '\0')) {
                uVar3 = 0;
            } else {
                uVar3 = 1;
            }
            *(undefined *)(in_RCX + 1) = uVar3;
            if ((*(char *)((int64_t)in_RCX + 9) == '\0') && (var_18h[iVar4 + 1] == '\0')) {
                uVar3 = 0;
            } else {
                uVar3 = 1;
            }
            *(undefined *)((int64_t)in_RCX + 9) = uVar3;
            if ((*(char *)((int64_t)in_RCX + 10) == '\0') && (var_18h[iVar4 + 2] == '\0')) {
                uVar3 = 0;
            } else {
                uVar3 = 1;
            }
            uVar5 = *in_RCX;
            uVar2 = *(uint64_t *)(var_18h + iVar4 + -8);
            *(undefined *)((int64_t)in_RCX + 10) = uVar3;
            if (uVar2 <= uVar5) {
                uVar5 = *(uint64_t *)(var_18h + iVar4 + -8);
            }
            *in_RCX = uVar5;
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801dd986;
    fcn.180459870(*(uint64_t *)((int64_t)&var_20h + iVar4) ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801dd979
// Address: 0x1801dd979
// Size: 20 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_1ah
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

void fcn.1801dd8a0(int64_t arg_30h, int64_t arg_90h)
{
    int64_t iVar1;
    uint64_t uVar2;
    undefined uVar3;
    int64_t iVar4;
    uint64_t *in_RCX;
    uint64_t uVar5;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    int64_t var_10h;
    char var_18h [8];
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801dd8ad;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&var_20h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar4);
    *(undefined2 *)(in_RCX + 1) = 0;
    *(undefined *)((int64_t)in_RCX + 10) = 0;
    *in_RCX = 0xffffffffffffffff;
    if ((*(uint8_t *)(in_RDX + 0xa0) & 1) == 0) {
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
        for (iVar1 = *(int64_t *)(in_RDX + 0x88); iVar1 != 0; iVar1 = *(int64_t *)(iVar1 + 8)) {
            *(undefined (*) [16])(var_18h + iVar4 + -8) = ZEXT816(0);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801dd918;
            func_0x0001801e9220(iVar1, var_18h + iVar4 + -8, in_R8 & 0xffffffff);
            if ((*(char *)(in_RCX + 1) == '\0') && (var_18h[iVar4] == '\0')) {
                uVar3 = 0;
            } else {
                uVar3 = 1;
            }
            *(undefined *)(in_RCX + 1) = uVar3;
            if ((*(char *)((int64_t)in_RCX + 9) == '\0') && (var_18h[iVar4 + 1] == '\0')) {
                uVar3 = 0;
            } else {
                uVar3 = 1;
            }
            *(undefined *)((int64_t)in_RCX + 9) = uVar3;
            if ((*(char *)((int64_t)in_RCX + 10) == '\0') && (var_18h[iVar4 + 2] == '\0')) {
                uVar3 = 0;
            } else {
                uVar3 = 1;
            }
            uVar5 = *in_RCX;
            uVar2 = *(uint64_t *)(var_18h + iVar4 + -8);
            *(undefined *)((int64_t)in_RCX + 10) = uVar3;
            if (uVar2 <= uVar5) {
                uVar5 = *(uint64_t *)(var_18h + iVar4 + -8);
            }
            *in_RCX = uVar5;
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x1801dd986;
    fcn.180459870(*(uint64_t *)((int64_t)&var_20h + iVar4) ^ (uint64_t)(&stack0xfffffffffffffff0 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801dd990
// Address: 0x1801dd990
// Size: 189 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801dd990(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint64_t uVar1;
    int64_t iVar2;
    undefined (*pauVar3) [16];
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dd9aa;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar1 = *(uint64_t *)(in_RCX + 0x50);
    while( true ) {
        if (in_RDX <= uVar1) {
            return 1;
        }
        uVar1 = *(uint64_t *)(in_RCX + 0x10);
        if (0xffffffffffffff7e < uVar1) break;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801dd9e6;
        pauVar3 = (undefined (*) [16])
                  fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                *(int64_t *)((int64_t)&iStackX_20 + iVar2));
        if (pauVar3 == (undefined (*) [16])0x0) {
            return 0;
        }
        *pauVar3 = ZEXT816(0);
        *(uint64_t *)(pauVar3[1] + 8) = uVar1;
        *(undefined8 *)pauVar3[1] = 0;
        if (*(undefined (***) [16])(in_RCX + 0x48) != (undefined (**) [16])0x0) {
            **(undefined (***) [16])(in_RCX + 0x48) = pauVar3;
        }
        *(undefined8 *)(*pauVar3 + 8) = *(undefined8 *)(in_RCX + 0x48);
        *(undefined8 *)*pauVar3 = 0;
        *(undefined (**) [16])(in_RCX + 0x48) = pauVar3;
        if (*(int64_t *)(in_RCX + 0x40) == 0) {
            *(undefined (**) [16])(in_RCX + 0x40) = pauVar3;
        }
        *(int64_t *)(in_RCX + 0x50) = *(int64_t *)(in_RCX + 0x50) + 1;
        pauVar3[7][9] = 0;
        uVar1 = *(uint64_t *)(in_RCX + 0x50);
    }
    return 0;
}

// ============================================================
// Function: FUN_1801dda50
// Address: 0x1801dda50
// Size: 26 bytes
// ============================================================
void fcn.1801dda50(int64_t arg_28h, int64_t arg_58h)
{
    undefined (*pauVar1) [16];
    int64_t iVar2;
    undefined (*pauVar3) [16];
    undefined (**in_RCX) [16];
    undefined (*pauVar4) [16];
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dda5c;
    iVar2 = fcn.18045a350();
    pauVar3 = *in_RCX;
    if (pauVar3 != (undefined (*) [16])0x0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar2) = unaff_RDI;
        do {
            pauVar1 = *(undefined (**) [16])*pauVar3;
            pauVar4 = pauVar1;
            if (*in_RCX == pauVar3) {
                *in_RCX = pauVar1;
                pauVar4 = *(undefined (**) [16])*pauVar3;
            }
            if (in_RCX[1] == pauVar3) {
                in_RCX[1] = *(undefined (**) [16])(*pauVar3 + 8);
                pauVar4 = *(undefined (**) [16])*pauVar3;
            }
            if (*(undefined (***) [16])(*pauVar3 + 8) != (undefined (**) [16])0x0) {
                **(undefined (***) [16])(*pauVar3 + 8) = pauVar4;
            }
            if (*(int64_t *)*pauVar3 != 0) {
                *(undefined8 *)(*(int64_t *)*pauVar3 + 8) = *(undefined8 *)(*pauVar3 + 8);
            }
            in_RCX[2] = (undefined (*) [16])(in_RCX[2][-1] + 0xf);
            *pauVar3 = ZEXT816(0);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801ddacd;
            fcn.180224990(pauVar3, 0x1804b6348, 0x68);
            pauVar3 = pauVar1;
        } while (pauVar1 != (undefined (*) [16])0x0);
    }
    return;
}

// ============================================================
// Function: FUN_1801dda6a
// Address: 0x1801dda6a
// Size: 112 bytes
// ============================================================
void fcn.1801dda50(int64_t arg_28h, int64_t arg_58h)
{
    undefined (*pauVar1) [16];
    int64_t iVar2;
    undefined (*pauVar3) [16];
    undefined (**in_RCX) [16];
    undefined (*pauVar4) [16];
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dda5c;
    iVar2 = fcn.18045a350();
    pauVar3 = *in_RCX;
    if (pauVar3 != (undefined (*) [16])0x0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar2) = unaff_RDI;
        do {
            pauVar1 = *(undefined (**) [16])*pauVar3;
            pauVar4 = pauVar1;
            if (*in_RCX == pauVar3) {
                *in_RCX = pauVar1;
                pauVar4 = *(undefined (**) [16])*pauVar3;
            }
            if (in_RCX[1] == pauVar3) {
                in_RCX[1] = *(undefined (**) [16])(*pauVar3 + 8);
                pauVar4 = *(undefined (**) [16])*pauVar3;
            }
            if (*(undefined (***) [16])(*pauVar3 + 8) != (undefined (**) [16])0x0) {
                **(undefined (***) [16])(*pauVar3 + 8) = pauVar4;
            }
            if (*(int64_t *)*pauVar3 != 0) {
                *(undefined8 *)(*(int64_t *)*pauVar3 + 8) = *(undefined8 *)(*pauVar3 + 8);
            }
            in_RCX[2] = (undefined (*) [16])(in_RCX[2][-1] + 0xf);
            *pauVar3 = ZEXT816(0);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801ddacd;
            fcn.180224990(pauVar3, 0x1804b6348, 0x68);
            pauVar3 = pauVar1;
        } while (pauVar1 != (undefined (*) [16])0x0);
    }
    return;
}

// ============================================================
// Function: FUN_1801ddada
// Address: 0x1801ddada
// Size: 6 bytes
// ============================================================
void fcn.1801dda50(int64_t arg_28h, int64_t arg_58h)
{
    undefined (*pauVar1) [16];
    int64_t iVar2;
    undefined (*pauVar3) [16];
    undefined (**in_RCX) [16];
    undefined (*pauVar4) [16];
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dda5c;
    iVar2 = fcn.18045a350();
    pauVar3 = *in_RCX;
    if (pauVar3 != (undefined (*) [16])0x0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar2) = unaff_RDI;
        do {
            pauVar1 = *(undefined (**) [16])*pauVar3;
            pauVar4 = pauVar1;
            if (*in_RCX == pauVar3) {
                *in_RCX = pauVar1;
                pauVar4 = *(undefined (**) [16])*pauVar3;
            }
            if (in_RCX[1] == pauVar3) {
                in_RCX[1] = *(undefined (**) [16])(*pauVar3 + 8);
                pauVar4 = *(undefined (**) [16])*pauVar3;
            }
            if (*(undefined (***) [16])(*pauVar3 + 8) != (undefined (**) [16])0x0) {
                **(undefined (***) [16])(*pauVar3 + 8) = pauVar4;
            }
            if (*(int64_t *)*pauVar3 != 0) {
                *(undefined8 *)(*(int64_t *)*pauVar3 + 8) = *(undefined8 *)(*pauVar3 + 8);
            }
            in_RCX[2] = (undefined (*) [16])(in_RCX[2][-1] + 0xf);
            *pauVar3 = ZEXT816(0);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801ddacd;
            fcn.180224990(pauVar3, 0x1804b6348, 0x68);
            pauVar3 = pauVar1;
        } while (pauVar1 != (undefined (*) [16])0x0);
    }
    return;
}

// ============================================================
// Function: FUN_1801ddae0
// Address: 0x1801ddae0
// Size: 303 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x0001801ddc0b)
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801ddae0(int64_t arg_30h, int64_t arg_50h, int64_t arg_58h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined (*pauVar6) [16];
    int64_t iVar7;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ddaf5;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_30h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar5);
    pauVar6 = *(undefined (**) [16])(in_RCX + 0x58);
    if (pauVar6 != (undefined (*) [16])0x0) {
        do {
            uVar1 = *(undefined8 *)(in_RCX + 8);
            uVar2 = *(undefined8 *)pauVar6[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ddb42;
            iVar4 = func_0x0001801f9900(pauVar6 + 8, uVar2, uVar1, (int64_t)&var_18h + iVar5);
            if (*(undefined (**) [16])(in_RCX + 0x58) == pauVar6) {
                *(undefined8 *)(in_RCX + 0x58) = *(undefined8 *)*pauVar6;
            }
            if (*(undefined (**) [16])(in_RCX + 0x60) == pauVar6) {
                *(undefined8 *)(in_RCX + 0x60) = *(undefined8 *)(*pauVar6 + 8);
            }
            if (*(undefined8 **)(*pauVar6 + 8) != (undefined8 *)0x0) {
                **(undefined8 **)(*pauVar6 + 8) = *(undefined8 *)*pauVar6;
            }
            if (*(int64_t *)*pauVar6 != 0) {
                *(undefined8 *)(*(int64_t *)*pauVar6 + 8) = *(undefined8 *)(*pauVar6 + 8);
            }
            *(int64_t *)(in_RCX + 0x68) = *(int64_t *)(in_RCX + 0x68) + -1;
            *pauVar6 = ZEXT816(0);
            if (*(int64_t *)(in_RCX + 0x30) == 0) {
                if (*(undefined (***) [16])(in_RCX + 0x48) != (undefined (**) [16])0x0) {
                    **(undefined (***) [16])(in_RCX + 0x48) = pauVar6;
                }
                *(undefined8 *)(*pauVar6 + 8) = *(undefined8 *)(in_RCX + 0x48);
                *(undefined8 *)*pauVar6 = 0;
                *(undefined (**) [16])(in_RCX + 0x48) = pauVar6;
                if (*(int64_t *)(in_RCX + 0x40) == 0) {
                    *(undefined (**) [16])(in_RCX + 0x40) = pauVar6;
                }
                *(int64_t *)(in_RCX + 0x50) = *(int64_t *)(in_RCX + 0x50) + 1;
                pauVar6[7][9] = 0;
            } else {
                pauVar6[7][9] = 2;
                pcVar3 = *(code **)(in_RCX + 0x30);
                uVar1 = *(undefined8 *)(in_RCX + 0x38);
                iVar7 = (int64_t)&var_18h + iVar5;
                if (iVar4 == 0) {
                    iVar7 = 0;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ddbaa;
                (*pcVar3)(pauVar6, uVar1, iVar7);
            }
            pauVar6 = *(undefined (**) [16])(in_RCX + 0x58);
        } while (pauVar6 != (undefined (*) [16])0x0);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801ddbfb;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_30h + iVar5) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_1801ddc10
// Address: 0x1801ddc10
// Size: 56 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_538h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_570h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_550h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_548h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_578h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5b0h because it doesn't fit into ProtoModel

void fcn.1801ddc10(int64_t arg_28h, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined (*pauVar3) [16];
    int32_t iVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t *in_RCX;
    int64_t iVar8;
    undefined (*pauVar9) [16];
    undefined8 unaff_RBP;
    uint64_t uVar10;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t **ppiVar11;
    undefined8 *puVar12;
    undefined8 *puVar13;
    uint64_t uVar14;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ddc1c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)(&stack0x00000538 + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6);
    iVar8 = in_RCX[8];
    if (*in_RCX != 0) {
        *(undefined8 *)(&stack0x00000570 + iVar6) = unaff_RBP;
        *(undefined8 *)(&stack0x00000550 + iVar6) = unaff_RDI;
        ppiVar11 = (int64_t **)((int64_t)&arg_38h + iVar6);
        *(undefined8 *)(&stack0x00000548 + iVar6) = unaff_R14;
        uVar14 = 0;
        *(undefined8 *)(&stack0x00000578 + iVar6) = unaff_RSI;
        uVar10 = uVar14;
        do {
            if (iVar8 == 0) {
                if (uVar10 == 0) goto code_r0x0001801dde45;
                break;
            }
            iVar1 = in_RCX[2];
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddc84;
            piVar7 = (int64_t *)func_0x0001801dde60(in_RCX, iVar8, iVar1);
            if (piVar7 == (int64_t *)0x0) goto code_r0x0001801dde45;
            ppiVar11[1] = (int64_t *)0x0;
            ppiVar11[2] = (int64_t *)0x0;
            ppiVar11[3] = (int64_t *)0x0;
            ppiVar11[4] = (int64_t *)0x0;
            *ppiVar11 = piVar7 + 0x10;
            ppiVar11[1] = (int64_t *)piVar7[3];
            ppiVar11[2] = piVar7 + 7;
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddcbf;
            func_0x00018026be30();
            if (*(char *)(in_RCX + 0xe) == '\0') {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddcd4;
                func_0x00018026be30();
            } else {
                ppiVar11[3] = (int64_t *)((int64_t)piVar7 + 0x54);
            }
            iVar8 = *piVar7;
            uVar10 = uVar10 + 1;
            ppiVar11 = ppiVar11 + 5;
        } while (uVar10 < 0x20);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddcf0;
        func_0x000180229b10();
        iVar8 = *in_RCX;
        *(int64_t *)((int64_t)&var_20h + iVar6) = (int64_t)&arg_28h + iVar6;
        *(undefined8 *)((int64_t)&var_18h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd15;
        iVar4 = func_0x00018021ace0(iVar8, (int64_t)&arg_38h + iVar6, 0x28, uVar10);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd1e;
            uVar5 = func_0x000180220a00();
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd25;
            iVar4 = func_0x000180219eb0(uVar5);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd3d;
                func_0x000180229900();
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd2e;
                func_0x0001802299d0();
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd4c;
            func_0x000180229900();
            pcVar2 = (code *)in_RCX[4];
            uVar10 = uVar14;
            if (pcVar2 != (code *)0x0) {
                iVar8 = in_RCX[5];
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd5b;
                uVar10 = (*pcVar2)(iVar8);
            }
            if (*(int64_t *)((int64_t)&arg_28h + iVar6) != 0) {
                puVar13 = (undefined8 *)(&stack0x00000040 + iVar6);
                pauVar9 = (undefined (*) [16])in_RCX[8];
                do {
                    pauVar3 = *(undefined (**) [16])*pauVar9;
                    *(undefined8 *)pauVar9[1] = *puVar13;
                    *(uint64_t *)pauVar9[7] = uVar10;
                    *(int64_t *)pauVar9[3] = in_RCX[3];
                    in_RCX[3] = in_RCX[3] + 1;
                    if ((undefined (*) [16])in_RCX[8] == pauVar9) {
                        in_RCX[8] = *(int64_t *)*pauVar9;
                    }
                    if ((undefined (*) [16])in_RCX[9] == pauVar9) {
                        in_RCX[9] = *(int64_t *)(*pauVar9 + 8);
                    }
                    puVar12 = *(undefined8 **)(*pauVar9 + 8);
                    if (puVar12 != (undefined8 *)0x0) {
                        *puVar12 = *(undefined8 *)*pauVar9;
                        puVar12 = *(undefined8 **)(*pauVar9 + 8);
                    }
                    if (*(int64_t *)*pauVar9 != 0) {
                        *(undefined8 **)(*(int64_t *)*pauVar9 + 8) = puVar12;
                    }
                    in_RCX[10] = in_RCX[10] + -1;
                    *pauVar9 = ZEXT816(0);
                    if ((undefined (**) [16])in_RCX[0xc] != (undefined (**) [16])0x0) {
                        *(undefined (**) [16])in_RCX[0xc] = pauVar9;
                    }
                    *(int64_t *)(*pauVar9 + 8) = in_RCX[0xc];
                    *(undefined8 *)*pauVar9 = 0;
                    in_RCX[0xc] = (int64_t)pauVar9;
                    if (in_RCX[0xb] == 0) {
                        in_RCX[0xb] = (int64_t)pauVar9;
                    }
                    in_RCX[0xd] = in_RCX[0xd] + 1;
                    uVar14 = uVar14 + 1;
                    pauVar9[7][9] = 1;
                    puVar13 = puVar13 + 5;
                    pauVar9 = pauVar3;
                } while (uVar14 < *(uint64_t *)((int64_t)&arg_28h + iVar6));
            }
        }
    }
code_r0x0001801dde45:
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dde55;
    fcn.180459870(*(uint64_t *)(&stack0x00000538 + iVar6) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801ddc48
// Address: 0x1801ddc48
// Size: 509 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_538h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_570h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_550h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_548h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_578h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5b0h because it doesn't fit into ProtoModel

void fcn.1801ddc10(int64_t arg_28h, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined (*pauVar3) [16];
    int32_t iVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t *in_RCX;
    int64_t iVar8;
    undefined (*pauVar9) [16];
    undefined8 unaff_RBP;
    uint64_t uVar10;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t **ppiVar11;
    undefined8 *puVar12;
    undefined8 *puVar13;
    uint64_t uVar14;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ddc1c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)(&stack0x00000538 + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6);
    iVar8 = in_RCX[8];
    if (*in_RCX != 0) {
        *(undefined8 *)(&stack0x00000570 + iVar6) = unaff_RBP;
        *(undefined8 *)(&stack0x00000550 + iVar6) = unaff_RDI;
        ppiVar11 = (int64_t **)((int64_t)&arg_38h + iVar6);
        *(undefined8 *)(&stack0x00000548 + iVar6) = unaff_R14;
        uVar14 = 0;
        *(undefined8 *)(&stack0x00000578 + iVar6) = unaff_RSI;
        uVar10 = uVar14;
        do {
            if (iVar8 == 0) {
                if (uVar10 == 0) goto code_r0x0001801dde45;
                break;
            }
            iVar1 = in_RCX[2];
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddc84;
            piVar7 = (int64_t *)func_0x0001801dde60(in_RCX, iVar8, iVar1);
            if (piVar7 == (int64_t *)0x0) goto code_r0x0001801dde45;
            ppiVar11[1] = (int64_t *)0x0;
            ppiVar11[2] = (int64_t *)0x0;
            ppiVar11[3] = (int64_t *)0x0;
            ppiVar11[4] = (int64_t *)0x0;
            *ppiVar11 = piVar7 + 0x10;
            ppiVar11[1] = (int64_t *)piVar7[3];
            ppiVar11[2] = piVar7 + 7;
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddcbf;
            func_0x00018026be30();
            if (*(char *)(in_RCX + 0xe) == '\0') {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddcd4;
                func_0x00018026be30();
            } else {
                ppiVar11[3] = (int64_t *)((int64_t)piVar7 + 0x54);
            }
            iVar8 = *piVar7;
            uVar10 = uVar10 + 1;
            ppiVar11 = ppiVar11 + 5;
        } while (uVar10 < 0x20);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddcf0;
        func_0x000180229b10();
        iVar8 = *in_RCX;
        *(int64_t *)((int64_t)&var_20h + iVar6) = (int64_t)&arg_28h + iVar6;
        *(undefined8 *)((int64_t)&var_18h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd15;
        iVar4 = func_0x00018021ace0(iVar8, (int64_t)&arg_38h + iVar6, 0x28, uVar10);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd1e;
            uVar5 = func_0x000180220a00();
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd25;
            iVar4 = func_0x000180219eb0(uVar5);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd3d;
                func_0x000180229900();
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd2e;
                func_0x0001802299d0();
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd4c;
            func_0x000180229900();
            pcVar2 = (code *)in_RCX[4];
            uVar10 = uVar14;
            if (pcVar2 != (code *)0x0) {
                iVar8 = in_RCX[5];
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd5b;
                uVar10 = (*pcVar2)(iVar8);
            }
            if (*(int64_t *)((int64_t)&arg_28h + iVar6) != 0) {
                puVar13 = (undefined8 *)(&stack0x00000040 + iVar6);
                pauVar9 = (undefined (*) [16])in_RCX[8];
                do {
                    pauVar3 = *(undefined (**) [16])*pauVar9;
                    *(undefined8 *)pauVar9[1] = *puVar13;
                    *(uint64_t *)pauVar9[7] = uVar10;
                    *(int64_t *)pauVar9[3] = in_RCX[3];
                    in_RCX[3] = in_RCX[3] + 1;
                    if ((undefined (*) [16])in_RCX[8] == pauVar9) {
                        in_RCX[8] = *(int64_t *)*pauVar9;
                    }
                    if ((undefined (*) [16])in_RCX[9] == pauVar9) {
                        in_RCX[9] = *(int64_t *)(*pauVar9 + 8);
                    }
                    puVar12 = *(undefined8 **)(*pauVar9 + 8);
                    if (puVar12 != (undefined8 *)0x0) {
                        *puVar12 = *(undefined8 *)*pauVar9;
                        puVar12 = *(undefined8 **)(*pauVar9 + 8);
                    }
                    if (*(int64_t *)*pauVar9 != 0) {
                        *(undefined8 **)(*(int64_t *)*pauVar9 + 8) = puVar12;
                    }
                    in_RCX[10] = in_RCX[10] + -1;
                    *pauVar9 = ZEXT816(0);
                    if ((undefined (**) [16])in_RCX[0xc] != (undefined (**) [16])0x0) {
                        *(undefined (**) [16])in_RCX[0xc] = pauVar9;
                    }
                    *(int64_t *)(*pauVar9 + 8) = in_RCX[0xc];
                    *(undefined8 *)*pauVar9 = 0;
                    in_RCX[0xc] = (int64_t)pauVar9;
                    if (in_RCX[0xb] == 0) {
                        in_RCX[0xb] = (int64_t)pauVar9;
                    }
                    in_RCX[0xd] = in_RCX[0xd] + 1;
                    uVar14 = uVar14 + 1;
                    pauVar9[7][9] = 1;
                    puVar13 = puVar13 + 5;
                    pauVar9 = pauVar3;
                } while (uVar14 < *(uint64_t *)((int64_t)&arg_28h + iVar6));
            }
        }
    }
code_r0x0001801dde45:
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dde55;
    fcn.180459870(*(uint64_t *)(&stack0x00000538 + iVar6) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801dde45
// Address: 0x1801dde45
// Size: 25 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_538h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_570h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_550h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_548h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_578h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5b0h because it doesn't fit into ProtoModel

void fcn.1801ddc10(int64_t arg_28h, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined (*pauVar3) [16];
    int32_t iVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t *in_RCX;
    int64_t iVar8;
    undefined (*pauVar9) [16];
    undefined8 unaff_RBP;
    uint64_t uVar10;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t **ppiVar11;
    undefined8 *puVar12;
    undefined8 *puVar13;
    uint64_t uVar14;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801ddc1c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)(&stack0x00000538 + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6);
    iVar8 = in_RCX[8];
    if (*in_RCX != 0) {
        *(undefined8 *)(&stack0x00000570 + iVar6) = unaff_RBP;
        *(undefined8 *)(&stack0x00000550 + iVar6) = unaff_RDI;
        ppiVar11 = (int64_t **)((int64_t)&arg_38h + iVar6);
        *(undefined8 *)(&stack0x00000548 + iVar6) = unaff_R14;
        uVar14 = 0;
        *(undefined8 *)(&stack0x00000578 + iVar6) = unaff_RSI;
        uVar10 = uVar14;
        do {
            if (iVar8 == 0) {
                if (uVar10 == 0) goto code_r0x0001801dde45;
                break;
            }
            iVar1 = in_RCX[2];
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddc84;
            piVar7 = (int64_t *)func_0x0001801dde60(in_RCX, iVar8, iVar1);
            if (piVar7 == (int64_t *)0x0) goto code_r0x0001801dde45;
            ppiVar11[1] = (int64_t *)0x0;
            ppiVar11[2] = (int64_t *)0x0;
            ppiVar11[3] = (int64_t *)0x0;
            ppiVar11[4] = (int64_t *)0x0;
            *ppiVar11 = piVar7 + 0x10;
            ppiVar11[1] = (int64_t *)piVar7[3];
            ppiVar11[2] = piVar7 + 7;
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddcbf;
            func_0x00018026be30();
            if (*(char *)(in_RCX + 0xe) == '\0') {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddcd4;
                func_0x00018026be30();
            } else {
                ppiVar11[3] = (int64_t *)((int64_t)piVar7 + 0x54);
            }
            iVar8 = *piVar7;
            uVar10 = uVar10 + 1;
            ppiVar11 = ppiVar11 + 5;
        } while (uVar10 < 0x20);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddcf0;
        func_0x000180229b10();
        iVar8 = *in_RCX;
        *(int64_t *)((int64_t)&var_20h + iVar6) = (int64_t)&arg_28h + iVar6;
        *(undefined8 *)((int64_t)&var_18h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd15;
        iVar4 = func_0x00018021ace0(iVar8, (int64_t)&arg_38h + iVar6, 0x28, uVar10);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd1e;
            uVar5 = func_0x000180220a00();
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd25;
            iVar4 = func_0x000180219eb0(uVar5);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd3d;
                func_0x000180229900();
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd2e;
                func_0x0001802299d0();
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd4c;
            func_0x000180229900();
            pcVar2 = (code *)in_RCX[4];
            uVar10 = uVar14;
            if (pcVar2 != (code *)0x0) {
                iVar8 = in_RCX[5];
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801ddd5b;
                uVar10 = (*pcVar2)(iVar8);
            }
            if (*(int64_t *)((int64_t)&arg_28h + iVar6) != 0) {
                puVar13 = (undefined8 *)(&stack0x00000040 + iVar6);
                pauVar9 = (undefined (*) [16])in_RCX[8];
                do {
                    pauVar3 = *(undefined (**) [16])*pauVar9;
                    *(undefined8 *)pauVar9[1] = *puVar13;
                    *(uint64_t *)pauVar9[7] = uVar10;
                    *(int64_t *)pauVar9[3] = in_RCX[3];
                    in_RCX[3] = in_RCX[3] + 1;
                    if ((undefined (*) [16])in_RCX[8] == pauVar9) {
                        in_RCX[8] = *(int64_t *)*pauVar9;
                    }
                    if ((undefined (*) [16])in_RCX[9] == pauVar9) {
                        in_RCX[9] = *(int64_t *)(*pauVar9 + 8);
                    }
                    puVar12 = *(undefined8 **)(*pauVar9 + 8);
                    if (puVar12 != (undefined8 *)0x0) {
                        *puVar12 = *(undefined8 *)*pauVar9;
                        puVar12 = *(undefined8 **)(*pauVar9 + 8);
                    }
                    if (*(int64_t *)*pauVar9 != 0) {
                        *(undefined8 **)(*(int64_t *)*pauVar9 + 8) = puVar12;
                    }
                    in_RCX[10] = in_RCX[10] + -1;
                    *pauVar9 = ZEXT816(0);
                    if ((undefined (**) [16])in_RCX[0xc] != (undefined (**) [16])0x0) {
                        *(undefined (**) [16])in_RCX[0xc] = pauVar9;
                    }
                    *(int64_t *)(*pauVar9 + 8) = in_RCX[0xc];
                    *(undefined8 *)*pauVar9 = 0;
                    in_RCX[0xc] = (int64_t)pauVar9;
                    if (in_RCX[0xb] == 0) {
                        in_RCX[0xb] = (int64_t)pauVar9;
                    }
                    in_RCX[0xd] = in_RCX[0xd] + 1;
                    uVar14 = uVar14 + 1;
                    pauVar9[7][9] = 1;
                    puVar13 = puVar13 + 5;
                    pauVar9 = pauVar3;
                } while (uVar14 < *(uint64_t *)((int64_t)&arg_28h + iVar6));
            }
        }
    }
code_r0x0001801dde45:
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801dde55;
    fcn.180459870(*(uint64_t *)(&stack0x00000538 + iVar6) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801dde60
// Address: 0x1801dde60
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined (*) [16] fcn.1801dde60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined (**ppauVar1) [16];
    int64_t iVar2;
    undefined (*pauVar3) [16];
    int64_t in_RCX;
    undefined (*in_RDX) [16];
    undefined8 unaff_RSI;
    uint64_t in_R8;
    bool bVar4;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801dde75;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_R8 <= *(uint64_t *)(in_RDX[1] + 8)) {
        return in_RDX;
    }
    if (in_RDX[7][9] != '\0') {
        return (undefined (*) [16])0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RSI;
    ppauVar1 = *(undefined (***) [16])(*in_RDX + 8);
    if (*(undefined (**) [16])(in_RCX + 0x40) == in_RDX) {
        *(undefined8 *)(in_RCX + 0x40) = *(undefined8 *)*in_RDX;
    }
    if (*(undefined (**) [16])(in_RCX + 0x48) == in_RDX) {
        *(undefined8 *)(in_RCX + 0x48) = *(undefined8 *)(*in_RDX + 8);
    }
    if (*(undefined8 **)(*in_RDX + 8) != (undefined8 *)0x0) {
        **(undefined8 **)(*in_RDX + 8) = *(undefined8 *)*in_RDX;
    }
    if (*(int64_t *)*in_RDX != 0) {
        *(undefined8 *)(*(int64_t *)*in_RDX + 8) = *(undefined8 *)(*in_RDX + 8);
    }
    *(int64_t *)(in_RCX + 0x50) = *(int64_t *)(in_RCX + 0x50) + -1;
    *in_RDX = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ddf0e;
    pauVar3 = (undefined (*) [16])
              fcn.1802249c0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2)
                            , *(int64_t *)((int64_t)&arg_28h + iVar2));
    if (pauVar3 == (undefined (*) [16])0x0) {
        if (ppauVar1 == (undefined (**) [16])0x0) {
            if (*(int64_t *)(in_RCX + 0x40) != 0) {
                *(undefined (**) [16])(*(int64_t *)(in_RCX + 0x40) + 8) = in_RDX;
            }
            *(undefined8 *)*in_RDX = *(undefined8 *)(in_RCX + 0x40);
            *(undefined8 *)(*in_RDX + 8) = 0;
            bVar4 = *(int64_t *)(in_RCX + 0x48) == 0;
            *(undefined (**) [16])(in_RCX + 0x40) = in_RDX;
        } else {
            *(undefined (***) [16])(*in_RDX + 8) = ppauVar1;
            *(undefined (**) [16])*in_RDX = *ppauVar1;
            if (*ppauVar1 != (undefined (*) [16])0x0) {
                *(undefined (**) [16])(**ppauVar1 + 8) = in_RDX;
            }
            *ppauVar1 = in_RDX;
            bVar4 = *(undefined (***) [16])(in_RCX + 0x48) == ppauVar1;
        }
        if (bVar4) {
            *(undefined (**) [16])(in_RCX + 0x48) = in_RDX;
        }
        *(int64_t *)(in_RCX + 0x50) = *(int64_t *)(in_RCX + 0x50) + 1;
        return (undefined (*) [16])0x0;
    }
    if (ppauVar1 == (undefined (**) [16])0x0) {
        if (*(int64_t *)(in_RCX + 0x40) != 0) {
            *(undefined (**) [16])(*(int64_t *)(in_RCX + 0x40) + 8) = pauVar3;
        }
        *(undefined8 *)*pauVar3 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)(*pauVar3 + 8) = 0;
        bVar4 = *(int64_t *)(in_RCX + 0x48) == 0;
        *(undefined (**) [16])(in_RCX + 0x40) = pauVar3;
    } else {
        *(undefined (***) [16])(*pauVar3 + 8) = ppauVar1;
        *(undefined (**) [16])*pauVar3 = *ppauVar1;
        if (*ppauVar1 != (undefined (*) [16])0x0) {
            *(undefined (**) [16])(**ppauVar1 + 8) = pauVar3;
        }
        *ppauVar1 = pauVar3;
        bVar4 = *(undefined (***) [16])(in_RCX + 0x48) == ppauVar1;
    }
    if (bVar4) {
        *(undefined (**) [16])(in_RCX + 0x48) = pauVar3;
    }
    *(int64_t *)(in_RCX + 0x50) = *(int64_t *)(in_RCX + 0x50) + 1;
    *(uint64_t *)(pauVar3[1] + 8) = in_R8;
    return pauVar3;
}

// ============================================================
// Function: FUN_1801ddea5
// Address: 0x1801ddea5
// Size: 217 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined (*) [16] fcn.1801dde60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined (**ppauVar1) [16];
    int64_t iVar2;
    undefined (*pauVar3) [16];
    int64_t in_RCX;
    undefined (*in_RDX) [16];
    undefined8 unaff_RSI;
    uint64_t in_R8;
    bool bVar4;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801dde75;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_R8 <= *(uint64_t *)(in_RDX[1] + 8)) {
        return in_RDX;
    }
    if (in_RDX[7][9] != '\0') {
        return (undefined (*) [16])0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RSI;
    ppauVar1 = *(undefined (***) [16])(*in_RDX + 8);
    if (*(undefined (**) [16])(in_RCX + 0x40) == in_RDX) {
        *(undefined8 *)(in_RCX + 0x40) = *(undefined8 *)*in_RDX;
    }
    if (*(undefined (**) [16])(in_RCX + 0x48) == in_RDX) {
        *(undefined8 *)(in_RCX + 0x48) = *(undefined8 *)(*in_RDX + 8);
    }
    if (*(undefined8 **)(*in_RDX + 8) != (undefined8 *)0x0) {
        **(undefined8 **)(*in_RDX + 8) = *(undefined8 *)*in_RDX;
    }
    if (*(int64_t *)*in_RDX != 0) {
        *(undefined8 *)(*(int64_t *)*in_RDX + 8) = *(undefined8 *)(*in_RDX + 8);
    }
    *(int64_t *)(in_RCX + 0x50) = *(int64_t *)(in_RCX + 0x50) + -1;
    *in_RDX = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ddf0e;
    pauVar3 = (undefined (*) [16])
              fcn.1802249c0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2)
                            , *(int64_t *)((int64_t)&arg_28h + iVar2));
    if (pauVar3 == (undefined (*) [16])0x0) {
        if (ppauVar1 == (undefined (**) [16])0x0) {
            if (*(int64_t *)(in_RCX + 0x40) != 0) {
                *(undefined (**) [16])(*(int64_t *)(in_RCX + 0x40) + 8) = in_RDX;
            }
            *(undefined8 *)*in_RDX = *(undefined8 *)(in_RCX + 0x40);
            *(undefined8 *)(*in_RDX + 8) = 0;
            bVar4 = *(int64_t *)(in_RCX + 0x48) == 0;
            *(undefined (**) [16])(in_RCX + 0x40) = in_RDX;
        } else {
            *(undefined (***) [16])(*in_RDX + 8) = ppauVar1;
            *(undefined (**) [16])*in_RDX = *ppauVar1;
            if (*ppauVar1 != (undefined (*) [16])0x0) {
                *(undefined (**) [16])(**ppauVar1 + 8) = in_RDX;
            }
            *ppauVar1 = in_RDX;
            bVar4 = *(undefined (***) [16])(in_RCX + 0x48) == ppauVar1;
        }
        if (bVar4) {
            *(undefined (**) [16])(in_RCX + 0x48) = in_RDX;
        }
        *(int64_t *)(in_RCX + 0x50) = *(int64_t *)(in_RCX + 0x50) + 1;
        return (undefined (*) [16])0x0;
    }
    if (ppauVar1 == (undefined (**) [16])0x0) {
        if (*(int64_t *)(in_RCX + 0x40) != 0) {
            *(undefined (**) [16])(*(int64_t *)(in_RCX + 0x40) + 8) = pauVar3;
        }
        *(undefined8 *)*pauVar3 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)(*pauVar3 + 8) = 0;
        bVar4 = *(int64_t *)(in_RCX + 0x48) == 0;
        *(undefined (**) [16])(in_RCX + 0x40) = pauVar3;
    } else {
        *(undefined (***) [16])(*pauVar3 + 8) = ppauVar1;
        *(undefined (**) [16])*pauVar3 = *ppauVar1;
        if (*ppauVar1 != (undefined (*) [16])0x0) {
            *(undefined (**) [16])(**ppauVar1 + 8) = pauVar3;
        }
        *ppauVar1 = pauVar3;
        bVar4 = *(undefined (***) [16])(in_RCX + 0x48) == ppauVar1;
    }
    if (bVar4) {
        *(undefined (**) [16])(in_RCX + 0x48) = pauVar3;
    }
    *(int64_t *)(in_RCX + 0x50) = *(int64_t *)(in_RCX + 0x50) + 1;
    *(uint64_t *)(pauVar3[1] + 8) = in_R8;
    return pauVar3;
}

// ============================================================
// Function: FUN_1801ddf7e
// Address: 0x1801ddf7e
// Size: 108 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined (*) [16] fcn.1801dde60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined (**ppauVar1) [16];
    int64_t iVar2;
    undefined (*pauVar3) [16];
    int64_t in_RCX;
    undefined (*in_RDX) [16];
    undefined8 unaff_RSI;
    uint64_t in_R8;
    bool bVar4;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801dde75;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_R8 <= *(uint64_t *)(in_RDX[1] + 8)) {
        return in_RDX;
    }
    if (in_RDX[7][9] != '\0') {
        return (undefined (*) [16])0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RSI;
    ppauVar1 = *(undefined (***) [16])(*in_RDX + 8);
    if (*(undefined (**) [16])(in_RCX + 0x40) == in_RDX) {
        *(undefined8 *)(in_RCX + 0x40) = *(undefined8 *)*in_RDX;
    }
    if (*(undefined (**) [16])(in_RCX + 0x48) == in_RDX) {
        *(undefined8 *)(in_RCX + 0x48) = *(undefined8 *)(*in_RDX + 8);
    }
    if (*(undefined8 **)(*in_RDX + 8) != (undefined8 *)0x0) {
        **(undefined8 **)(*in_RDX + 8) = *(undefined8 *)*in_RDX;
    }
    if (*(int64_t *)*in_RDX != 0) {
        *(undefined8 *)(*(int64_t *)*in_RDX + 8) = *(undefined8 *)(*in_RDX + 8);
    }
    *(int64_t *)(in_RCX + 0x50) = *(int64_t *)(in_RCX + 0x50) + -1;
    *in_RDX = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ddf0e;
    pauVar3 = (undefined (*) [16])
              fcn.1802249c0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2)
                            , *(int64_t *)((int64_t)&arg_28h + iVar2));
    if (pauVar3 == (undefined (*) [16])0x0) {
        if (ppauVar1 == (undefined (**) [16])0x0) {
            if (*(int64_t *)(in_RCX + 0x40) != 0) {
                *(undefined (**) [16])(*(int64_t *)(in_RCX + 0x40) + 8) = in_RDX;
            }
            *(undefined8 *)*in_RDX = *(undefined8 *)(in_RCX + 0x40);
            *(undefined8 *)(*in_RDX + 8) = 0;
            bVar4 = *(int64_t *)(in_RCX + 0x48) == 0;
            *(undefined (**) [16])(in_RCX + 0x40) = in_RDX;
        } else {
            *(undefined (***) [16])(*in_RDX + 8) = ppauVar1;
            *(undefined (**) [16])*in_RDX = *ppauVar1;
            if (*ppauVar1 != (undefined (*) [16])0x0) {
                *(undefined (**) [16])(**ppauVar1 + 8) = in_RDX;
            }
            *ppauVar1 = in_RDX;
            bVar4 = *(undefined (***) [16])(in_RCX + 0x48) == ppauVar1;
        }
        if (bVar4) {
            *(undefined (**) [16])(in_RCX + 0x48) = in_RDX;
        }
        *(int64_t *)(in_RCX + 0x50) = *(int64_t *)(in_RCX + 0x50) + 1;
        return (undefined (*) [16])0x0;
    }
    if (ppauVar1 == (undefined (**) [16])0x0) {
        if (*(int64_t *)(in_RCX + 0x40) != 0) {
            *(undefined (**) [16])(*(int64_t *)(in_RCX + 0x40) + 8) = pauVar3;
        }
        *(undefined8 *)*pauVar3 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)(*pauVar3 + 8) = 0;
        bVar4 = *(int64_t *)(in_RCX + 0x48) == 0;
        *(undefined (**) [16])(in_RCX + 0x40) = pauVar3;
    } else {
        *(undefined (***) [16])(*pauVar3 + 8) = ppauVar1;
        *(undefined (**) [16])*pauVar3 = *ppauVar1;
        if (*ppauVar1 != (undefined (*) [16])0x0) {
            *(undefined (**) [16])(**ppauVar1 + 8) = pauVar3;
        }
        *ppauVar1 = pauVar3;
        bVar4 = *(undefined (***) [16])(in_RCX + 0x48) == ppauVar1;
    }
    if (bVar4) {
        *(undefined (**) [16])(in_RCX + 0x48) = pauVar3;
    }
    *(int64_t *)(in_RCX + 0x50) = *(int64_t *)(in_RCX + 0x50) + 1;
    *(uint64_t *)(pauVar3[1] + 8) = in_R8;
    return pauVar3;
}

// ============================================================
// Function: FUN_1801ddfea
// Address: 0x1801ddfea
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined (*) [16] fcn.1801dde60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined (**ppauVar1) [16];
    int64_t iVar2;
    undefined (*pauVar3) [16];
    int64_t in_RCX;
    undefined (*in_RDX) [16];
    undefined8 unaff_RSI;
    uint64_t in_R8;
    bool bVar4;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801dde75;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_R8 <= *(uint64_t *)(in_RDX[1] + 8)) {
        return in_RDX;
    }
    if (in_RDX[7][9] != '\0') {
        return (undefined (*) [16])0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RSI;
    ppauVar1 = *(undefined (***) [16])(*in_RDX + 8);
    if (*(undefined (**) [16])(in_RCX + 0x40) == in_RDX) {
        *(undefined8 *)(in_RCX + 0x40) = *(undefined8 *)*in_RDX;
    }
    if (*(undefined (**) [16])(in_RCX + 0x48) == in_RDX) {
        *(undefined8 *)(in_RCX + 0x48) = *(undefined8 *)(*in_RDX + 8);
    }
    if (*(undefined8 **)(*in_RDX + 8) != (undefined8 *)0x0) {
        **(undefined8 **)(*in_RDX + 8) = *(undefined8 *)*in_RDX;
    }
    if (*(int64_t *)*in_RDX != 0) {
        *(undefined8 *)(*(int64_t *)*in_RDX + 8) = *(undefined8 *)(*in_RDX + 8);
    }
    *(int64_t *)(in_RCX + 0x50) = *(int64_t *)(in_RCX + 0x50) + -1;
    *in_RDX = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801ddf0e;
    pauVar3 = (undefined (*) [16])
              fcn.1802249c0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2)
                            , *(int64_t *)((int64_t)&arg_28h + iVar2));
    if (pauVar3 == (undefined (*) [16])0x0) {
        if (ppauVar1 == (undefined (**) [16])0x0) {
            if (*(int64_t *)(in_RCX + 0x40) != 0) {
                *(undefined (**) [16])(*(int64_t *)(in_RCX + 0x40) + 8) = in_RDX;
            }
            *(undefined8 *)*in_RDX = *(undefined8 *)(in_RCX + 0x40);
            *(undefined8 *)(*in_RDX + 8) = 0;
            bVar4 = *(int64_t *)(in_RCX + 0x48) == 0;
            *(undefined (**) [16])(in_RCX + 0x40) = in_RDX;
        } else {
            *(undefined (***) [16])(*in_RDX + 8) = ppauVar1;
            *(undefined (**) [16])*in_RDX = *ppauVar1;
            if (*ppauVar1 != (undefined (*) [16])0x0) {
                *(undefined (**) [16])(**ppauVar1 + 8) = in_RDX;
            }
            *ppauVar1 = in_RDX;
            bVar4 = *(undefined (***) [16])(in_RCX + 0x48) == ppauVar1;
        }
        if (bVar4) {
            *(undefined (**) [16])(in_RCX + 0x48) = in_RDX;
        }
        *(int64_t *)(in_RCX + 0x50) = *(int64_t *)(in_RCX + 0x50) + 1;
        return (undefined (*) [16])0x0;
    }
    if (ppauVar1 == (undefined (**) [16])0x0) {
        if (*(int64_t *)(in_RCX + 0x40) != 0) {
            *(undefined (**) [16])(*(int64_t *)(in_RCX + 0x40) + 8) = pauVar3;
        }
        *(undefined8 *)*pauVar3 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)(*pauVar3 + 8) = 0;
        bVar4 = *(int64_t *)(in_RCX + 0x48) == 0;
        *(undefined (**) [16])(in_RCX + 0x40) = pauVar3;
    } else {
        *(undefined (***) [16])(*pauVar3 + 8) = ppauVar1;
        *(undefined (**) [16])*pauVar3 = *ppauVar1;
        if (*ppauVar1 != (undefined (*) [16])0x0) {
            *(undefined (**) [16])(**ppauVar1 + 8) = pauVar3;
        }
        *ppauVar1 = pauVar3;
        bVar4 = *(undefined (***) [16])(in_RCX + 0x48) == ppauVar1;
    }
    if (bVar4) {
        *(undefined (**) [16])(in_RCX + 0x48) = pauVar3;
    }
    *(int64_t *)(in_RCX + 0x50) = *(int64_t *)(in_RCX + 0x50) + 1;
    *(uint64_t *)(pauVar3[1] + 8) = in_R8;
    return pauVar3;
}

// ============================================================
// Function: FUN_1801de000
// Address: 0x1801de000
// Size: 67 bytes
// ============================================================
void fcn.1801de000(int64_t arg1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801de010;
        iVar1 = fcn.18045a350();
        iVar1 = -iVar1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801de01f;
        fcn.1801dda50(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801de028;
        fcn.1801dda50(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801de03d;
        fcn.180224990(arg1, 0x1804b6348, 0x75);
    }
    return;
}

// ============================================================
// Function: FUN_1801de060
// Address: 0x1801de060
// Size: 189 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t * fcn.1801de060(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801de080;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801de0a6;
    piVar3 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar2));
    if (piVar3 != (int64_t *)0x0) {
        *piVar3 = in_RCX;
        piVar3[1] = in_RDX;
        piVar3[2] = 0x5dc;
        piVar3[4] = in_R8;
        piVar3[5] = in_R9;
        if (in_RCX != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801de0dd;
            iVar1 = fcn.180219d10(*(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                                  *(int64_t *)(&stack0x00000048 + iVar2));
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801de0f7;
                iVar1 = fcn.180219d10(*(int64_t *)((int64_t)&arg_38h + iVar2), *(int64_t *)((int64_t)&arg_40h + iVar2), 
                                      *(int64_t *)(&stack0x00000048 + iVar2));
                if (iVar1 != 0) {
                    *(undefined *)(piVar3 + 0xe) = 1;
                }
            }
        }
    }
    return piVar3;
}

// ============================================================
// Function: FUN_1801de120
// Address: 0x1801de120
// Size: 92 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_538h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_570h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_550h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_548h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_578h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5b0h because it doesn't fit into ProtoModel

undefined8 fcn.1801de120(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801de12c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int64_t *)(param_1 + 0x58) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801de140;
        iVar1 = fcn.1801dd990(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar2));
        if (iVar1 != 1) {
            return 0xfffffffe;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801de14d;
        uVar3 = fcn.1801ddc10(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        if ((int32_t)uVar3 != 1) {
            return uVar3;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801de15a;
    iVar1 = fcn.1801ddae0(*(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), *(int64_t *)(&stack0x00000040 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
    uVar3 = 1;
    if (iVar1 < 1) {
        uVar3 = 0xfffffffe;
    }
    return uVar3;
}

// ============================================================
// Function: FUN_1801de1c0
// Address: 0x1801de1c0
// Size: 67 bytes
// ============================================================
uint64_t fcn.1801de1c0(uint64_t *param_1, uint64_t param_2)
{
    int64_t iVar1;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801de1cc;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *param_1 = param_2;
    if (param_2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801de1f0;
        param_2 = fcn.180219d10(*(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                                *(int64_t *)(&stack0x00000048 + iVar1));
        if (0x4af < (uint32_t)param_2) {
            param_2 = param_2 & 0xffffffff;
            param_1[2] = param_2;
        }
    }
    return param_2;
}

// ============================================================
// Function: FUN_1801de360
// Address: 0x1801de360
// Size: 590 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801de360(int64_t arg_28h, int64_t arg_30h)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    int64_t iVar5;
    uint32_t uVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801de375;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX[0x79] != 0) {
        uVar6 = 0;
        do {
            iVar5 = in_RCX[0x79];
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de39e;
            func_0x000180202d20(iVar5, uVar6);
            uVar6 = uVar6 + 1;
        } while (uVar6 < 3);
    }
    iVar5 = in_RCX[7];
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de3b6;
        func_0x000180200d30(iVar5, in_RCX);
    }
    iVar5 = in_RCX[8];
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de3c7;
        func_0x0001802013a0(iVar5, in_RCX);
    }
    iVar5 = in_RCX[0x11];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de3d3;
    func_0x000180207310(iVar5);
    iVar5 = in_RCX[0x12];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de3df;
    func_0x000180203a40(iVar5);
    iVar5 = in_RCX[0x13];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de3eb;
    func_0x000180201e30(iVar5);
    iVar5 = in_RCX[0x7a];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de3f7;
    func_0x0001801fb660(iVar5);
    if (in_RCX[0x77] != 0) {
        pcVar1 = *(code **)(in_RCX[0x78] + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de410;
        (*pcVar1)();
    }
    if ((*(uint32_t *)(in_RCX + 0xba) & 0x1000) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de428;
        func_0x0001800086f0(in_RCX + 0x72);
    }
    iVar5 = in_RCX[0x79];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de434;
    func_0x0001802025f0(iVar5);
    if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de44c;
        func_0x0001801e7780(in_RCX + 0x60);
    }
    piVar7 = in_RCX + 0x82;
    iVar5 = 3;
    do {
        iVar4 = piVar7[-3];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de469;
        func_0x0001801e6180(iVar4);
        iVar4 = *piVar7;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de471;
        func_0x0001801e6b30(iVar4);
        piVar7 = piVar7 + 1;
        iVar5 = iVar5 + -1;
    } while (iVar5 != 0);
    iVar5 = in_RCX[0xa0];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de487;
    func_0x0001802054c0(iVar5);
    iVar5 = in_RCX[5];
    in_RCX[0xa0] = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de497;
    func_0x0001801a6070(iVar5);
    iVar5 = in_RCX[0x7b];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de4a3;
    func_0x000180205160(iVar5);
    iVar5 = in_RCX[10];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de4b9;
    fcn.180224990(iVar5, 0x1804b6360, 0x1ae);
    iVar5 = in_RCX[0xb0];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de4d2;
    fcn.180224990(iVar5, 0x1804b6360, 0x1af);
    iVar5 = in_RCX[0xbb];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de4de;
    func_0x000180220c50(iVar5);
    iVar5 = in_RCX[0xbc];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de4f7;
    fcn.180224990(iVar5, 0x1804b6360, 0x1b1);
    iVar5 = in_RCX[0xb];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de50d;
    fcn.180224990(iVar5, 0x1804b6360, 0x1b2);
    if ((*(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0x100) != 0) {
        iVar5 = *in_RCX;
        if (*(int64_t **)(iVar5 + 0x48) == in_RCX) {
            *(int64_t *)(iVar5 + 0x48) = in_RCX[1];
        }
        if (*(int64_t **)(iVar5 + 0x50) == in_RCX) {
            *(int64_t *)(iVar5 + 0x50) = in_RCX[2];
        }
        if (in_RCX[2] != 0) {
            *(int64_t *)(in_RCX[2] + 8) = in_RCX[1];
        }
        if (in_RCX[1] != 0) {
            *(int64_t *)(in_RCX[1] + 0x10) = in_RCX[2];
        }
        *(int64_t *)(iVar5 + 0x58) = *(int64_t *)(iVar5 + 0x58) + -1;
        *(undefined (*) [16])(in_RCX + 1) = ZEXT816(0);
        *(uint32_t *)((int64_t)in_RCX + 0x5d4) = *(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0xfffffeff;
    }
    if (in_RCX[9] != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de57d;
        func_0x0001801fa350();
    }
    iVar5 = in_RCX[0xbe];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de596;
    fcn.180224990(iVar5, 0x1804b6360, 0x1bd);
    iVar5 = in_RCX[9];
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar3) = *(undefined8 *)((int64_t)&arg_28h + iVar3);
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + -8) = 0x1801fa394;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3 + -8) = 0x1801fa3a6;
        func_0x00018020c870(iVar5 + 0x98);
        uVar2 = *(undefined8 *)(iVar5 + 0x58);
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3 + -8) = 0x1801fa3af;
        func_0x00018021a070(uVar2);
        uVar2 = *(undefined8 *)(iVar5 + 0x18);
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3 + -8) = 0x1801fa3c5;
        fcn.180224990(uVar2, 0x1804b8ac8, 0xa8);
        uVar2 = *(undefined8 *)(iVar5 + 0x20);
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3 + -8) = 0x1801fa3db;
        fcn.180224990(uVar2, 0x1804b8ac8, 0xa9);
        uVar2 = *(undefined8 *)(iVar5 + 0x28);
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3 + -8) = 0x1801fa3f1;
        fcn.180224990(uVar2, 0x1804b8ac8, 0xaa);
        uVar2 = *(undefined8 *)(iVar5 + 0x50);
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3 + -8) = 0x1801fa407;
        fcn.180224990(uVar2, 0x1804b8ac8, 0xab);
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3 + -8) = 0x1801fa41c;
        fcn.180224990(iVar5, 0x1804b8ac8, 0xac);
    }
    return;
}

// ============================================================
// Function: FUN_1801de5b0
// Address: 0x1801de5b0
// Size: 305 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801de5b0(int64_t arg_28h, int64_t arg_30h)
{
    uint32_t uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint32_t uVar4;
    uint64_t in_RDX;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801de5c5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar4 = (uint32_t)in_RDX;
    if (2 < uVar4) {
        return 0;
    }
    if ((*(uint32_t *)(in_RCX + 0x5d0) >> 0x14 & 1 << ((uint8_t)in_RDX & 0x1f) & 0xf) == 0) {
        uVar2 = *(undefined8 *)(in_RCX + 0x88);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de605;
        func_0x000180207270(uVar2);
        uVar2 = *(undefined8 *)(in_RCX + 0x3d8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de613;
        func_0x000180205130(uVar2, in_RDX & 0xffffffff);
        uVar2 = *(undefined8 *)(in_RCX + 0x3d0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de621;
        func_0x0001801fb350(uVar2, in_RDX & 0xffffffff);
        if (uVar4 != 1) {
            if (uVar4 == 0) {
                iVar5 = 0;
            } else if ((uVar4 == 1) || (uVar4 != 2)) {
                iVar5 = 2;
            } else {
                iVar5 = 1;
            }
            uVar2 = *(undefined8 *)(in_RCX + 0x3c8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de654;
            func_0x000180202d20(uVar2, iVar5);
            if (*(int64_t *)(in_RCX + 0x3f8 + iVar5 * 8) == 0) {
                return 0;
            }
            if (*(int64_t *)(in_RCX + 0x410 + iVar5 * 8) == 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de671;
            func_0x0001801e6180();
            uVar2 = *(undefined8 *)(in_RCX + 0x410 + iVar5 * 8);
            *(undefined8 *)(in_RCX + 0x3f8 + iVar5 * 8) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801de68a;
            func_0x0001801e6b30(uVar2);
            *(undefined8 *)(in_RCX + 0x410 + iVar5 * 8) = 0;
        }
        uVar1 = *(uint32_t *)(in_RCX + 0x5d0);
        *(uint32_t *)(in_RCX + 0x5d0) = ((uVar1 >> 0x14 & 0xf | 1 << (uVar4 & 0x1f)) << 0x14 ^ uVar1) & 0xf00000 ^ uVar1
        ;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801de6f0
// Address: 0x1801de6f0
// Size: 145 bytes
// ============================================================
undefined8
fcn.1801de6f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_a0h, int64_t arg_d0h, int64_t arg_d8h,
             int64_t arg_e0h, int64_t arg_e8h, int64_t arg_1c8h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 uVar7;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    undefined8 unaff_R14;
    undefined8 uVar9;
    undefined8 unaff_R15;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801de701;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar7 = *(undefined8 *)(in_RCX + 0x40);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de719;
    func_0x0001802017f0(uVar7, in_RCX, in_RDX);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de71e;
    iVar3 = func_0x000180226610();
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de738;
        iVar1 = func_0x000180244300((int64_t)&arg_68h + iVar2, iVar3);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de74c;
            iVar1 = func_0x0001801fe500((int64_t)&arg_68h + iVar2, in_RDX);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de761;
                func_0x000180243fb0();
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de91f;
                func_0x000180244200((int64_t)&arg_68h + iVar2);
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de934;
                iVar1 = func_0x0001802442e0((int64_t)&arg_68h + iVar2, (int64_t)&arg_d0h + iVar2);
                if (iVar1 != 0) {
                    uVar7 = *(undefined8 *)(iVar3 + 8);
                    *(undefined8 *)((int64_t)&var_20h + iVar2) = 0;
                    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0x1801e3640;
                    *(undefined8 *)((int64_t)&var_10h + iVar2) = *(undefined8 *)((int64_t)&arg_d0h + iVar2);
                    *(undefined8 *)((int64_t)&var_8h + iVar2) = uVar7;
                    uVar7 = *(undefined8 *)(in_RCX + 0x98);
                    *(undefined4 *)(&stack0x00000000 + iVar2) = 0;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de985;
                    iVar4 = func_0x000180201cf0(uVar7, 1, 2, 0x19);
                    if (iVar4 != 0) {
                        *(undefined8 *)(iVar3 + 8) = 0;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de99b;
                        func_0x000180226310(iVar3);
                        return 1;
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de773;
    iVar4 = func_0x0001801fca50(1);
    if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) goto code_r0x0001801de902;
    *(undefined8 *)((int64_t)&arg_d8h + iVar2) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_e0h + iVar2) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_e8h + iVar2) = unaff_R14;
    uVar9 = 0x1805aadb1;
    *(undefined8 *)((int64_t)&arg_a0h + iVar2) = unaff_R15;
    uVar7 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar7 = 0x1805ab2bc;
    }
    uVar8 = 0x1805aadb1;
    iVar10 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar8 = 0x1805ab2cc;
        iVar10 = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de7d8;
    iVar5 = func_0x0001801fcb70(0x18);
    iVar4 = 0x1805aadb1;
    if (iVar5 != 0) {
        iVar4 = iVar5;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de7ea;
    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2));
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de802;
    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                  *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                  *(int64_t *)((int64_t)&arg_30h + iVar2));
    uVar6 = 0x1805aadb1;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0x1804b7258;
    if (iVar5 != 0) {
        uVar6 = 0x1805ab2bc;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = uVar6;
    *(int64_t *)((int64_t)&arg_28h + iVar2) = iVar4;
    if (iVar5 != 0) {
        uVar9 = 0x1805ab2cc;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar2) = uVar9;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0x18;
    *(undefined8 *)((int64_t)&var_10h + iVar2) = uVar7;
    *(int64_t *)((int64_t)&var_8h + iVar2) = iVar10;
    *(undefined8 *)(&stack0x00000000 + iVar2) = uVar8;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de86d;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar2));
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de885;
    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                  *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                  *(int64_t *)((int64_t)&arg_30h + iVar2));
    iVar4 = *(int64_t *)(in_RCX + 0x5d8);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de8b6;
        iVar4 = func_0x0001802542f0();
        *(int64_t *)(in_RCX + 0x5d8) = iVar4;
        if (iVar4 != 0) goto code_r0x0001801de8c2;
    } else {
code_r0x0001801de8c2:
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de8ca;
        func_0x000180254600(iVar4);
    }
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = 1;
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = 0x18;
    *(undefined8 *)((int64_t)&arg_50h + iVar2) = 0x1804b7258;
    *(undefined8 *)((int64_t)&arg_58h + iVar2) = 0x28;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de902;
    func_0x0001801e2d20(in_RCX, (int64_t)&arg_40h + iVar2, 0);
code_r0x0001801de902:
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de90a;
    func_0x000180226310(iVar3);
    return 0;
}

// ============================================================
// Function: FUN_1801de781
// Address: 0x1801de781
// Size: 304 bytes
// ============================================================
undefined8
fcn.1801de6f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_a0h, int64_t arg_d0h, int64_t arg_d8h,
             int64_t arg_e0h, int64_t arg_e8h, int64_t arg_1c8h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 uVar7;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    undefined8 unaff_R14;
    undefined8 uVar9;
    undefined8 unaff_R15;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801de701;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar7 = *(undefined8 *)(in_RCX + 0x40);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de719;
    func_0x0001802017f0(uVar7, in_RCX, in_RDX);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de71e;
    iVar3 = func_0x000180226610();
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de738;
        iVar1 = func_0x000180244300((int64_t)&arg_68h + iVar2, iVar3);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de74c;
            iVar1 = func_0x0001801fe500((int64_t)&arg_68h + iVar2, in_RDX);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de761;
                func_0x000180243fb0();
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de91f;
                func_0x000180244200((int64_t)&arg_68h + iVar2);
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de934;
                iVar1 = func_0x0001802442e0((int64_t)&arg_68h + iVar2, (int64_t)&arg_d0h + iVar2);
                if (iVar1 != 0) {
                    uVar7 = *(undefined8 *)(iVar3 + 8);
                    *(undefined8 *)((int64_t)&var_20h + iVar2) = 0;
                    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0x1801e3640;
                    *(undefined8 *)((int64_t)&var_10h + iVar2) = *(undefined8 *)((int64_t)&arg_d0h + iVar2);
                    *(undefined8 *)((int64_t)&var_8h + iVar2) = uVar7;
                    uVar7 = *(undefined8 *)(in_RCX + 0x98);
                    *(undefined4 *)(&stack0x00000000 + iVar2) = 0;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de985;
                    iVar4 = func_0x000180201cf0(uVar7, 1, 2, 0x19);
                    if (iVar4 != 0) {
                        *(undefined8 *)(iVar3 + 8) = 0;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de99b;
                        func_0x000180226310(iVar3);
                        return 1;
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de773;
    iVar4 = func_0x0001801fca50(1);
    if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) goto code_r0x0001801de902;
    *(undefined8 *)((int64_t)&arg_d8h + iVar2) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_e0h + iVar2) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_e8h + iVar2) = unaff_R14;
    uVar9 = 0x1805aadb1;
    *(undefined8 *)((int64_t)&arg_a0h + iVar2) = unaff_R15;
    uVar7 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar7 = 0x1805ab2bc;
    }
    uVar8 = 0x1805aadb1;
    iVar10 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar8 = 0x1805ab2cc;
        iVar10 = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de7d8;
    iVar5 = func_0x0001801fcb70(0x18);
    iVar4 = 0x1805aadb1;
    if (iVar5 != 0) {
        iVar4 = iVar5;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de7ea;
    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2));
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de802;
    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                  *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                  *(int64_t *)((int64_t)&arg_30h + iVar2));
    uVar6 = 0x1805aadb1;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0x1804b7258;
    if (iVar5 != 0) {
        uVar6 = 0x1805ab2bc;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = uVar6;
    *(int64_t *)((int64_t)&arg_28h + iVar2) = iVar4;
    if (iVar5 != 0) {
        uVar9 = 0x1805ab2cc;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar2) = uVar9;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0x18;
    *(undefined8 *)((int64_t)&var_10h + iVar2) = uVar7;
    *(int64_t *)((int64_t)&var_8h + iVar2) = iVar10;
    *(undefined8 *)(&stack0x00000000 + iVar2) = uVar8;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de86d;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar2));
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de885;
    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                  *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                  *(int64_t *)((int64_t)&arg_30h + iVar2));
    iVar4 = *(int64_t *)(in_RCX + 0x5d8);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de8b6;
        iVar4 = func_0x0001802542f0();
        *(int64_t *)(in_RCX + 0x5d8) = iVar4;
        if (iVar4 != 0) goto code_r0x0001801de8c2;
    } else {
code_r0x0001801de8c2:
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de8ca;
        func_0x000180254600(iVar4);
    }
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = 1;
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = 0x18;
    *(undefined8 *)((int64_t)&arg_50h + iVar2) = 0x1804b7258;
    *(undefined8 *)((int64_t)&arg_58h + iVar2) = 0x28;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de902;
    func_0x0001801e2d20(in_RCX, (int64_t)&arg_40h + iVar2, 0);
code_r0x0001801de902:
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de90a;
    func_0x000180226310(iVar3);
    return 0;
}

// ============================================================
// Function: FUN_1801de8b1
// Address: 0x1801de8b1
// Size: 253 bytes
// ============================================================
undefined8
fcn.1801de6f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_a0h, int64_t arg_d0h, int64_t arg_d8h,
             int64_t arg_e0h, int64_t arg_e8h, int64_t arg_1c8h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 uVar7;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    undefined8 unaff_R14;
    undefined8 uVar9;
    undefined8 unaff_R15;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801de701;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar7 = *(undefined8 *)(in_RCX + 0x40);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de719;
    func_0x0001802017f0(uVar7, in_RCX, in_RDX);
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de71e;
    iVar3 = func_0x000180226610();
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de738;
        iVar1 = func_0x000180244300((int64_t)&arg_68h + iVar2, iVar3);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de74c;
            iVar1 = func_0x0001801fe500((int64_t)&arg_68h + iVar2, in_RDX);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de761;
                func_0x000180243fb0();
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de91f;
                func_0x000180244200((int64_t)&arg_68h + iVar2);
                *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de934;
                iVar1 = func_0x0001802442e0((int64_t)&arg_68h + iVar2, (int64_t)&arg_d0h + iVar2);
                if (iVar1 != 0) {
                    uVar7 = *(undefined8 *)(iVar3 + 8);
                    *(undefined8 *)((int64_t)&var_20h + iVar2) = 0;
                    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0x1801e3640;
                    *(undefined8 *)((int64_t)&var_10h + iVar2) = *(undefined8 *)((int64_t)&arg_d0h + iVar2);
                    *(undefined8 *)((int64_t)&var_8h + iVar2) = uVar7;
                    uVar7 = *(undefined8 *)(in_RCX + 0x98);
                    *(undefined4 *)(&stack0x00000000 + iVar2) = 0;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de985;
                    iVar4 = func_0x000180201cf0(uVar7, 1, 2, 0x19);
                    if (iVar4 != 0) {
                        *(undefined8 *)(iVar3 + 8) = 0;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de99b;
                        func_0x000180226310(iVar3);
                        return 1;
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de773;
    iVar4 = func_0x0001801fca50(1);
    if ((*(uint8_t *)(in_RCX + 0x5d4) & 0x40) != 0) goto code_r0x0001801de902;
    *(undefined8 *)((int64_t)&arg_d8h + iVar2) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_e0h + iVar2) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_e8h + iVar2) = unaff_R14;
    uVar9 = 0x1805aadb1;
    *(undefined8 *)((int64_t)&arg_a0h + iVar2) = unaff_R15;
    uVar7 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar7 = 0x1805ab2bc;
    }
    uVar8 = 0x1805aadb1;
    iVar10 = 0x1805aadb1;
    if (iVar4 != 0) {
        uVar8 = 0x1805ab2cc;
        iVar10 = iVar4;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de7d8;
    iVar5 = func_0x0001801fcb70(0x18);
    iVar4 = 0x1805aadb1;
    if (iVar5 != 0) {
        iVar4 = iVar5;
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de7ea;
    fcn.180229480(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2));
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de802;
    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                  *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                  *(int64_t *)((int64_t)&arg_30h + iVar2));
    uVar6 = 0x1805aadb1;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0x1804b7258;
    if (iVar5 != 0) {
        uVar6 = 0x1805ab2bc;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = uVar6;
    *(int64_t *)((int64_t)&arg_28h + iVar2) = iVar4;
    if (iVar5 != 0) {
        uVar9 = 0x1805ab2cc;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar2) = uVar9;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0x18;
    *(undefined8 *)((int64_t)&var_10h + iVar2) = uVar7;
    *(int64_t *)((int64_t)&var_8h + iVar2) = iVar10;
    *(undefined8 *)(&stack0x00000000 + iVar2) = uVar8;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de86d;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_20h + iVar2));
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de885;
    fcn.1802295a0(*(int64_t *)(&stack0x00000000 + iVar2), *(int64_t *)((int64_t)&var_8h + iVar2), 
                  *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&var_18h + iVar2), 
                  *(int64_t *)((int64_t)&arg_30h + iVar2));
    iVar4 = *(int64_t *)(in_RCX + 0x5d8);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de8b6;
        iVar4 = func_0x0001802542f0();
        *(int64_t *)(in_RCX + 0x5d8) = iVar4;
        if (iVar4 != 0) goto code_r0x0001801de8c2;
    } else {
code_r0x0001801de8c2:
        *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de8ca;
        func_0x000180254600(iVar4);
    }
    *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) | 0x40;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = 1;
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = 0x18;
    *(undefined8 *)((int64_t)&arg_50h + iVar2) = 0x1804b7258;
    *(undefined8 *)((int64_t)&arg_58h + iVar2) = 0x28;
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de902;
    func_0x0001801e2d20(in_RCX, (int64_t)&arg_40h + iVar2, 0);
code_r0x0001801de902:
    *(undefined8 *)((int64_t)&uStack_28 + iVar2) = 0x1801de90a;
    func_0x000180226310(iVar3);
    return 0;
}

// ============================================================
// Function: FUN_1801de9b0
// Address: 0x1801de9b0
// Size: 107 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1801de9b0(int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h)
{
    char cVar1;
    undefined uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 uVar8;
    int64_t iVar9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801de9c2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    cVar1 = *(char *)(in_RCX + 0x43d);
    iVar9 = 0;
    *(undefined8 *)((int64_t)&arg_78h + iVar4) = 0;
    iVar5 = iVar9;
    iVar6 = iVar9;
    if ((*(int64_t *)(in_RCX + 0x50) != 0) || (iVar5 = 0, (*(uint32_t *)(in_RCX + 0x5d0) & 0x100) != 0))
    goto code_r0x0001801dee52;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801de9fa;
    iVar5 = func_0x000180226610();
    if (iVar5 == 0) goto code_r0x0001801dee52;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dea13;
    iVar3 = func_0x000180244300((int64_t)&var_18h + iVar4, iVar5);
    iVar6 = 0;
    if (iVar3 == 0) goto code_r0x0001801dee52;
    *(undefined8 *)((int64_t)&arg_80h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_88h + iVar4) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dea40;
    iVar6 = func_0x0001801fe6a0((int64_t)&var_18h + iVar4, 0xc, 0, 0);
    if (iVar6 != 0) {
        if ((*(uint32_t *)(in_RCX + 0x5d0) & 0x2000000) == 0) {
            iVar6 = in_RCX + 0x452;
            uVar8 = 0xf;
code_r0x0001801deac4:
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deac9;
            iVar3 = func_0x0001801fe750((int64_t)&var_18h + iVar4, uVar8, iVar6);
            if (iVar3 != 0) {
code_r0x0001801dead1:
                uVar8 = *(undefined8 *)(in_RCX + 0x518);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deae7;
                iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 1, uVar8);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deb04;
                    iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 3, 0x4b0);
                    if (iVar3 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deb21;
                        iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 0xe, 2);
                        if (iVar3 != 0) {
                            if (*(int64_t *)(in_RCX + 0x4d0) != 0x19) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deb45;
                                iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 0xb);
                                if (iVar3 == 0) goto code_r0x0001801dee38;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deb59;
                            uVar8 = func_0x00018001ed90(in_RCX + 0xc0);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deb6b;
                            iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 4, uVar8);
                            if (iVar3 != 0) {
                                uVar8 = *(undefined8 *)(in_RCX + 0x4b8);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deb89;
                                iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 5, uVar8);
                                if (iVar3 != 0) {
                                    uVar8 = *(undefined8 *)(in_RCX + 0x4c0);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deba7;
                                    iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 6, uVar8);
                                    if (iVar3 != 0) {
                                        uVar8 = *(undefined8 *)(in_RCX + 0x4c8);
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801debc5;
                                        iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 7, uVar8);
                                        if (iVar3 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801debd9;
                                            uVar8 = func_0x00018001ed90(in_RCX + 0x240);
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801debeb;
                                            iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 8, uVar8);
                                            if (iVar3 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801debff;
                                                uVar8 = func_0x00018001ed90(in_RCX + 0x2a0);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dec11;
                                                iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 9, uVar8);
                                                if (iVar3 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dec23;
                                                    iVar3 = func_0x000180244200((int64_t)&var_18h + iVar4);
                                                    if (iVar3 != 0) {
                                                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dec3d;
                                                        iVar3 = func_0x0001802442e0((int64_t)&var_18h + iVar4, 
                                                                                    (int64_t)&arg_78h + iVar4);
                                                        iVar6 = iVar9;
                                                        if (iVar3 != 0) {
                                                            *(undefined8 *)(in_RCX + 0x50) = *(undefined8 *)(iVar5 + 8);
                                                            *(undefined8 *)(iVar5 + 8) = 0;
                                                            uVar8 = *(undefined8 *)(in_RCX + 0x50);
                                                            uVar7 = *(undefined8 *)(in_RCX + 0x28);
                                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dec66;
                                                            iVar3 = func_0x0001801a62a0(uVar7, uVar8, 
                                                                                        *(undefined8 *)
                                                                                         ((int64_t)&arg_78h + iVar4));
                                                            if (iVar3 != 0) {
                                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                     0x1801dec76;
                                                                uVar8 = func_0x0001801deee0(in_RCX);
                                                                *(undefined8 *)((int64_t)&var_8h + iVar4) = 0x1804b6dc8;
                                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                     0x1801deca0;
                                                                iVar3 = func_0x0001801fa270(uVar8, 4, 0x1804b6df8, 
                                                                                            0x1804b6de8);
                                                                if (iVar3 != 0) {
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801decbe;
                                                                    func_0x0001801fae90(uVar8, 0x1804b6e0c, 0x18064232c)
                                                                    ;
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801decd0;
                                                                    func_0x0001801fa130(uVar8, 0x1804b7010, 1);
                                                                    if ((*(uint32_t *)(in_RCX + 0x5d0) & 0x2000000) == 0
                                                                       ) {
                                                                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                             0x1801ded2d;
                                                                        func_0x0001801fae90(uVar8, 0x1804b7030, 
                                                                                            0x1805aadb1);
                                                                    } else {
                                                                        uVar2 = *(undefined *)(in_RCX + 0x428);
                                                                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                             0x1801decfa;
                                                                        func_0x0001801fa0e0(uVar8, 0x1804b6e18, 
                                                                                            in_RCX + 0x429, uVar2);
                                                                        uVar2 = *(undefined *)(in_RCX + 0x47c);
                                                                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                             0x1801ded18;
                                                                        func_0x0001801fa0e0(uVar8, 0x1804b7030, 
                                                                                            in_RCX + 0x47d, uVar2);
                                                                    }
                                                                    uVar7 = *(undefined8 *)(in_RCX + 0x528);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801ded43;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6f80, uVar7);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801ded58;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6f68, 0x4b0);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801ded6d;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6f98, 2);
                                                                    uVar7 = *(undefined8 *)(in_RCX + 0x4d0);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801ded83;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6f58, uVar7);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801ded8f;
                                                                    uVar7 = func_0x00018001ed90(in_RCX + 0xc0);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801deda1;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6e80, uVar7);
                                                                    uVar7 = *(undefined8 *)(in_RCX + 0x4b8);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dedb7;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6e98, uVar7);
                                                                    uVar7 = *(undefined8 *)(in_RCX + 0x4c0);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dedcd;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6ec0, uVar7);
                                                                    uVar7 = *(undefined8 *)(in_RCX + 0x4c8);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dede3;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6ee8, uVar7);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dedef;
                                                                    uVar7 = func_0x00018001ed90(in_RCX + 0x240);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dee01;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6f08, uVar7);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dee0d;
                                                                    uVar7 = func_0x00018001ed90(in_RCX + 0x2a0);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dee1f;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6f28, uVar7);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dee27;
                                                                    func_0x0001801fa180(uVar8);
                                                                }
                                                                *(uint32_t *)(in_RCX + 0x5d0) =
                                                                     *(uint32_t *)(in_RCX + 0x5d0) | 0x100;
                                                                iVar6 = 1;
                                                            }
                                                        }
                                                        goto code_r0x0001801dee52;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            iVar6 = 0x428;
            if (cVar1 != '\0') {
                iVar6 = 0x43d;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dea76;
            iVar3 = func_0x0001801fe750((int64_t)&var_18h + iVar4, 0, iVar6 + in_RCX);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dea94;
                iVar3 = func_0x0001801fe750((int64_t)&var_18h + iVar4, 0xf, in_RCX + 0x47c);
                if (iVar3 != 0) {
                    if (*(char *)(in_RCX + 0x43d) != '\0') {
                        iVar6 = in_RCX + 0x428;
                        uVar8 = 0x10;
                        goto code_r0x0001801deac4;
                    }
                    goto code_r0x0001801dead1;
                }
            }
        }
    }
code_r0x0001801dee38:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dee42;
    func_0x000180243fb0((int64_t)&var_18h + iVar4);
    iVar6 = iVar9;
code_r0x0001801dee52:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dee5a;
    func_0x000180226310(iVar5);
    return iVar6;
}

// ============================================================
// Function: FUN_1801dea1b
// Address: 0x1801dea1b
// Size: 1079 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1801de9b0(int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h)
{
    char cVar1;
    undefined uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 uVar8;
    int64_t iVar9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801de9c2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    cVar1 = *(char *)(in_RCX + 0x43d);
    iVar9 = 0;
    *(undefined8 *)((int64_t)&arg_78h + iVar4) = 0;
    iVar5 = iVar9;
    iVar6 = iVar9;
    if ((*(int64_t *)(in_RCX + 0x50) != 0) || (iVar5 = 0, (*(uint32_t *)(in_RCX + 0x5d0) & 0x100) != 0))
    goto code_r0x0001801dee52;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801de9fa;
    iVar5 = func_0x000180226610();
    if (iVar5 == 0) goto code_r0x0001801dee52;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dea13;
    iVar3 = func_0x000180244300((int64_t)&var_18h + iVar4, iVar5);
    iVar6 = 0;
    if (iVar3 == 0) goto code_r0x0001801dee52;
    *(undefined8 *)((int64_t)&arg_80h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_88h + iVar4) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dea40;
    iVar6 = func_0x0001801fe6a0((int64_t)&var_18h + iVar4, 0xc, 0, 0);
    if (iVar6 != 0) {
        if ((*(uint32_t *)(in_RCX + 0x5d0) & 0x2000000) == 0) {
            iVar6 = in_RCX + 0x452;
            uVar8 = 0xf;
code_r0x0001801deac4:
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deac9;
            iVar3 = func_0x0001801fe750((int64_t)&var_18h + iVar4, uVar8, iVar6);
            if (iVar3 != 0) {
code_r0x0001801dead1:
                uVar8 = *(undefined8 *)(in_RCX + 0x518);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deae7;
                iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 1, uVar8);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deb04;
                    iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 3, 0x4b0);
                    if (iVar3 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deb21;
                        iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 0xe, 2);
                        if (iVar3 != 0) {
                            if (*(int64_t *)(in_RCX + 0x4d0) != 0x19) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deb45;
                                iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 0xb);
                                if (iVar3 == 0) goto code_r0x0001801dee38;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deb59;
                            uVar8 = func_0x00018001ed90(in_RCX + 0xc0);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deb6b;
                            iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 4, uVar8);
                            if (iVar3 != 0) {
                                uVar8 = *(undefined8 *)(in_RCX + 0x4b8);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deb89;
                                iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 5, uVar8);
                                if (iVar3 != 0) {
                                    uVar8 = *(undefined8 *)(in_RCX + 0x4c0);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deba7;
                                    iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 6, uVar8);
                                    if (iVar3 != 0) {
                                        uVar8 = *(undefined8 *)(in_RCX + 0x4c8);
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801debc5;
                                        iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 7, uVar8);
                                        if (iVar3 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801debd9;
                                            uVar8 = func_0x00018001ed90(in_RCX + 0x240);
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801debeb;
                                            iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 8, uVar8);
                                            if (iVar3 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801debff;
                                                uVar8 = func_0x00018001ed90(in_RCX + 0x2a0);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dec11;
                                                iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 9, uVar8);
                                                if (iVar3 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dec23;
                                                    iVar3 = func_0x000180244200((int64_t)&var_18h + iVar4);
                                                    if (iVar3 != 0) {
                                                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dec3d;
                                                        iVar3 = func_0x0001802442e0((int64_t)&var_18h + iVar4, 
                                                                                    (int64_t)&arg_78h + iVar4);
                                                        iVar6 = iVar9;
                                                        if (iVar3 != 0) {
                                                            *(undefined8 *)(in_RCX + 0x50) = *(undefined8 *)(iVar5 + 8);
                                                            *(undefined8 *)(iVar5 + 8) = 0;
                                                            uVar8 = *(undefined8 *)(in_RCX + 0x50);
                                                            uVar7 = *(undefined8 *)(in_RCX + 0x28);
                                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dec66;
                                                            iVar3 = func_0x0001801a62a0(uVar7, uVar8, 
                                                                                        *(undefined8 *)
                                                                                         ((int64_t)&arg_78h + iVar4));
                                                            if (iVar3 != 0) {
                                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                     0x1801dec76;
                                                                uVar8 = func_0x0001801deee0(in_RCX);
                                                                *(undefined8 *)((int64_t)&var_8h + iVar4) = 0x1804b6dc8;
                                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                     0x1801deca0;
                                                                iVar3 = func_0x0001801fa270(uVar8, 4, 0x1804b6df8, 
                                                                                            0x1804b6de8);
                                                                if (iVar3 != 0) {
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801decbe;
                                                                    func_0x0001801fae90(uVar8, 0x1804b6e0c, 0x18064232c)
                                                                    ;
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801decd0;
                                                                    func_0x0001801fa130(uVar8, 0x1804b7010, 1);
                                                                    if ((*(uint32_t *)(in_RCX + 0x5d0) & 0x2000000) == 0
                                                                       ) {
                                                                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                             0x1801ded2d;
                                                                        func_0x0001801fae90(uVar8, 0x1804b7030, 
                                                                                            0x1805aadb1);
                                                                    } else {
                                                                        uVar2 = *(undefined *)(in_RCX + 0x428);
                                                                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                             0x1801decfa;
                                                                        func_0x0001801fa0e0(uVar8, 0x1804b6e18, 
                                                                                            in_RCX + 0x429, uVar2);
                                                                        uVar2 = *(undefined *)(in_RCX + 0x47c);
                                                                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                             0x1801ded18;
                                                                        func_0x0001801fa0e0(uVar8, 0x1804b7030, 
                                                                                            in_RCX + 0x47d, uVar2);
                                                                    }
                                                                    uVar7 = *(undefined8 *)(in_RCX + 0x528);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801ded43;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6f80, uVar7);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801ded58;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6f68, 0x4b0);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801ded6d;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6f98, 2);
                                                                    uVar7 = *(undefined8 *)(in_RCX + 0x4d0);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801ded83;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6f58, uVar7);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801ded8f;
                                                                    uVar7 = func_0x00018001ed90(in_RCX + 0xc0);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801deda1;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6e80, uVar7);
                                                                    uVar7 = *(undefined8 *)(in_RCX + 0x4b8);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dedb7;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6e98, uVar7);
                                                                    uVar7 = *(undefined8 *)(in_RCX + 0x4c0);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dedcd;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6ec0, uVar7);
                                                                    uVar7 = *(undefined8 *)(in_RCX + 0x4c8);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dede3;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6ee8, uVar7);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dedef;
                                                                    uVar7 = func_0x00018001ed90(in_RCX + 0x240);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dee01;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6f08, uVar7);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dee0d;
                                                                    uVar7 = func_0x00018001ed90(in_RCX + 0x2a0);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dee1f;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6f28, uVar7);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dee27;
                                                                    func_0x0001801fa180(uVar8);
                                                                }
                                                                *(uint32_t *)(in_RCX + 0x5d0) =
                                                                     *(uint32_t *)(in_RCX + 0x5d0) | 0x100;
                                                                iVar6 = 1;
                                                            }
                                                        }
                                                        goto code_r0x0001801dee52;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            iVar6 = 0x428;
            if (cVar1 != '\0') {
                iVar6 = 0x43d;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dea76;
            iVar3 = func_0x0001801fe750((int64_t)&var_18h + iVar4, 0, iVar6 + in_RCX);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dea94;
                iVar3 = func_0x0001801fe750((int64_t)&var_18h + iVar4, 0xf, in_RCX + 0x47c);
                if (iVar3 != 0) {
                    if (*(char *)(in_RCX + 0x43d) != '\0') {
                        iVar6 = in_RCX + 0x428;
                        uVar8 = 0x10;
                        goto code_r0x0001801deac4;
                    }
                    goto code_r0x0001801dead1;
                }
            }
        }
    }
code_r0x0001801dee38:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dee42;
    func_0x000180243fb0((int64_t)&var_18h + iVar4);
    iVar6 = iVar9;
code_r0x0001801dee52:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dee5a;
    func_0x000180226310(iVar5);
    return iVar6;
}

// ============================================================
// Function: FUN_1801dee52
// Address: 0x1801dee52
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1801de9b0(int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h)
{
    char cVar1;
    undefined uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 uVar8;
    int64_t iVar9;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801de9c2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    cVar1 = *(char *)(in_RCX + 0x43d);
    iVar9 = 0;
    *(undefined8 *)((int64_t)&arg_78h + iVar4) = 0;
    iVar5 = iVar9;
    iVar6 = iVar9;
    if ((*(int64_t *)(in_RCX + 0x50) != 0) || (iVar5 = 0, (*(uint32_t *)(in_RCX + 0x5d0) & 0x100) != 0))
    goto code_r0x0001801dee52;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801de9fa;
    iVar5 = func_0x000180226610();
    if (iVar5 == 0) goto code_r0x0001801dee52;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dea13;
    iVar3 = func_0x000180244300((int64_t)&var_18h + iVar4, iVar5);
    iVar6 = 0;
    if (iVar3 == 0) goto code_r0x0001801dee52;
    *(undefined8 *)((int64_t)&arg_80h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_88h + iVar4) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dea40;
    iVar6 = func_0x0001801fe6a0((int64_t)&var_18h + iVar4, 0xc, 0, 0);
    if (iVar6 != 0) {
        if ((*(uint32_t *)(in_RCX + 0x5d0) & 0x2000000) == 0) {
            iVar6 = in_RCX + 0x452;
            uVar8 = 0xf;
code_r0x0001801deac4:
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deac9;
            iVar3 = func_0x0001801fe750((int64_t)&var_18h + iVar4, uVar8, iVar6);
            if (iVar3 != 0) {
code_r0x0001801dead1:
                uVar8 = *(undefined8 *)(in_RCX + 0x518);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deae7;
                iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 1, uVar8);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deb04;
                    iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 3, 0x4b0);
                    if (iVar3 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deb21;
                        iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 0xe, 2);
                        if (iVar3 != 0) {
                            if (*(int64_t *)(in_RCX + 0x4d0) != 0x19) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deb45;
                                iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 0xb);
                                if (iVar3 == 0) goto code_r0x0001801dee38;
                            }
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deb59;
                            uVar8 = func_0x00018001ed90(in_RCX + 0xc0);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deb6b;
                            iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 4, uVar8);
                            if (iVar3 != 0) {
                                uVar8 = *(undefined8 *)(in_RCX + 0x4b8);
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deb89;
                                iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 5, uVar8);
                                if (iVar3 != 0) {
                                    uVar8 = *(undefined8 *)(in_RCX + 0x4c0);
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801deba7;
                                    iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 6, uVar8);
                                    if (iVar3 != 0) {
                                        uVar8 = *(undefined8 *)(in_RCX + 0x4c8);
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801debc5;
                                        iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 7, uVar8);
                                        if (iVar3 != 0) {
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801debd9;
                                            uVar8 = func_0x00018001ed90(in_RCX + 0x240);
                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801debeb;
                                            iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 8, uVar8);
                                            if (iVar3 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801debff;
                                                uVar8 = func_0x00018001ed90(in_RCX + 0x2a0);
                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dec11;
                                                iVar3 = func_0x0001801fe800((int64_t)&var_18h + iVar4, 9, uVar8);
                                                if (iVar3 != 0) {
                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dec23;
                                                    iVar3 = func_0x000180244200((int64_t)&var_18h + iVar4);
                                                    if (iVar3 != 0) {
                                                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dec3d;
                                                        iVar3 = func_0x0001802442e0((int64_t)&var_18h + iVar4, 
                                                                                    (int64_t)&arg_78h + iVar4);
                                                        iVar6 = iVar9;
                                                        if (iVar3 != 0) {
                                                            *(undefined8 *)(in_RCX + 0x50) = *(undefined8 *)(iVar5 + 8);
                                                            *(undefined8 *)(iVar5 + 8) = 0;
                                                            uVar8 = *(undefined8 *)(in_RCX + 0x50);
                                                            uVar7 = *(undefined8 *)(in_RCX + 0x28);
                                                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dec66;
                                                            iVar3 = func_0x0001801a62a0(uVar7, uVar8, 
                                                                                        *(undefined8 *)
                                                                                         ((int64_t)&arg_78h + iVar4));
                                                            if (iVar3 != 0) {
                                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                     0x1801dec76;
                                                                uVar8 = func_0x0001801deee0(in_RCX);
                                                                *(undefined8 *)((int64_t)&var_8h + iVar4) = 0x1804b6dc8;
                                                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                     0x1801deca0;
                                                                iVar3 = func_0x0001801fa270(uVar8, 4, 0x1804b6df8, 
                                                                                            0x1804b6de8);
                                                                if (iVar3 != 0) {
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801decbe;
                                                                    func_0x0001801fae90(uVar8, 0x1804b6e0c, 0x18064232c)
                                                                    ;
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801decd0;
                                                                    func_0x0001801fa130(uVar8, 0x1804b7010, 1);
                                                                    if ((*(uint32_t *)(in_RCX + 0x5d0) & 0x2000000) == 0
                                                                       ) {
                                                                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                             0x1801ded2d;
                                                                        func_0x0001801fae90(uVar8, 0x1804b7030, 
                                                                                            0x1805aadb1);
                                                                    } else {
                                                                        uVar2 = *(undefined *)(in_RCX + 0x428);
                                                                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                             0x1801decfa;
                                                                        func_0x0001801fa0e0(uVar8, 0x1804b6e18, 
                                                                                            in_RCX + 0x429, uVar2);
                                                                        uVar2 = *(undefined *)(in_RCX + 0x47c);
                                                                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                             0x1801ded18;
                                                                        func_0x0001801fa0e0(uVar8, 0x1804b7030, 
                                                                                            in_RCX + 0x47d, uVar2);
                                                                    }
                                                                    uVar7 = *(undefined8 *)(in_RCX + 0x528);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801ded43;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6f80, uVar7);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801ded58;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6f68, 0x4b0);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801ded6d;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6f98, 2);
                                                                    uVar7 = *(undefined8 *)(in_RCX + 0x4d0);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801ded83;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6f58, uVar7);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801ded8f;
                                                                    uVar7 = func_0x00018001ed90(in_RCX + 0xc0);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801deda1;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6e80, uVar7);
                                                                    uVar7 = *(undefined8 *)(in_RCX + 0x4b8);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dedb7;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6e98, uVar7);
                                                                    uVar7 = *(undefined8 *)(in_RCX + 0x4c0);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dedcd;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6ec0, uVar7);
                                                                    uVar7 = *(undefined8 *)(in_RCX + 0x4c8);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dede3;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6ee8, uVar7);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dedef;
                                                                    uVar7 = func_0x00018001ed90(in_RCX + 0x240);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dee01;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6f08, uVar7);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dee0d;
                                                                    uVar7 = func_0x00018001ed90(in_RCX + 0x2a0);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dee1f;
                                                                    func_0x0001801faf20(uVar8, 0x1804b6f28, uVar7);
                                                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) =
                                                                         0x1801dee27;
                                                                    func_0x0001801fa180(uVar8);
                                                                }
                                                                *(uint32_t *)(in_RCX + 0x5d0) =
                                                                     *(uint32_t *)(in_RCX + 0x5d0) | 0x100;
                                                                iVar6 = 1;
                                                            }
                                                        }
                                                        goto code_r0x0001801dee52;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            iVar6 = 0x428;
            if (cVar1 != '\0') {
                iVar6 = 0x43d;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dea76;
            iVar3 = func_0x0001801fe750((int64_t)&var_18h + iVar4, 0, iVar6 + in_RCX);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dea94;
                iVar3 = func_0x0001801fe750((int64_t)&var_18h + iVar4, 0xf, in_RCX + 0x47c);
                if (iVar3 != 0) {
                    if (*(char *)(in_RCX + 0x43d) != '\0') {
                        iVar6 = in_RCX + 0x428;
                        uVar8 = 0x10;
                        goto code_r0x0001801deac4;
                    }
                    goto code_r0x0001801dead1;
                }
            }
        }
    }
code_r0x0001801dee38:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dee42;
    func_0x000180243fb0((int64_t)&var_18h + iVar4);
    iVar6 = iVar9;
code_r0x0001801dee52:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801dee5a;
    func_0x000180226310(iVar5);
    return iVar6;
}

// ============================================================
// Function: FUN_1801dee70
// Address: 0x1801dee70
// Size: 103 bytes
// ============================================================
uint64_t fcn.1801dee70(int64_t param_1)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801dee7c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(int64_t *)(param_1 + 0x528) == 0) {
        return 0xffffffffffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801deea5;
    uVar2 = fcn.180202870(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
    uVar3 = 0xffffffffffffffff;
    if (uVar2 < 0x5555555555555556) {
        uVar3 = uVar2 * 3;
    }
    uVar2 = *(int64_t *)(param_1 + 0x528) * 1000000;
    if (uVar2 < uVar3 || uVar2 - uVar3 == 0) {
        uVar2 = uVar3;
    }
    return uVar2;
}

// ============================================================
// Function: FUN_1801deee0
// Address: 0x1801deee0
// Size: 249 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch

void fcn.1801deee0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_68h,
                  int64_t arg_78h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint32_t uVar7;
    int64_t in_RCX;
    int64_t var_18h;
    undefined4 auStackX_20 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801deeec;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_78h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar5);
    *(undefined8 *)((int64_t)&arg_68h + iVar5) = 0;
    iVar6 = *(int64_t *)(in_RCX + 0x48);
    *(undefined (*) [16])((int64_t)auStackX_20 + iVar5 + -8) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_28h + iVar5) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_38h + iVar5) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_48h + iVar5) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_58h + iVar5) = ZEXT816(0);
    if (((iVar6 == 0) && ((*(uint32_t *)(in_RCX + 0x5d4) & 0x200) != 0)) &&
       ((uVar7 = *(uint32_t *)(in_RCX + 0x5d0) >> 0x19 & 1, uVar7 == 0 || (*(char *)(in_RCX + 0x428) != '\0')))) {
        uVar1 = *(undefined4 *)(in_RCX + 0x428);
        uVar2 = *(undefined4 *)(in_RCX + 0x42c);
        uVar3 = *(undefined4 *)(in_RCX + 0x430);
        uVar4 = *(undefined4 *)(in_RCX + 0x434);
        *(undefined4 *)((int64_t)&arg_28h + iVar5) = *(undefined4 *)(in_RCX + 0x438);
        *(undefined *)((int64_t)&arg_28h + iVar5 + 4) = *(undefined *)(in_RCX + 0x43c);
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = *(undefined8 *)(in_RCX + 0x5f0);
        *(undefined4 *)((int64_t)auStackX_20 + iVar5 + -8) = uVar1;
        *(undefined4 *)((int64_t)auStackX_20 + iVar5 + -4) = uVar2;
        *(undefined4 *)((int64_t)auStackX_20 + iVar5) = uVar3;
        *(undefined4 *)((int64_t)auStackX_20 + iVar5 + 4) = uVar4;
        *(uint32_t *)((int64_t)&arg_48h + iVar5) = uVar7;
        *(undefined8 *)((int64_t)&arg_50h + iVar5) = 0x1801e36e0;
        *(undefined (*) [16])((int64_t)&arg_38h + iVar5) = ZEXT816(0);
        *(int64_t *)((int64_t)&arg_58h + iVar5) = in_RCX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801defab;
        iVar6 = func_0x0001801fa480((int64_t)auStackX_20 + iVar5 + -8);
        *(int64_t *)(in_RCX + 0x48) = iVar6;
        if (iVar6 == 0) {
            *(uint32_t *)(in_RCX + 0x5d4) = *(uint32_t *)(in_RCX + 0x5d4) & 0xfffffdff;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801defd0;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_78h + iVar5) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_1801defe0
// Address: 0x1801defe0
// Size: 22 bytes
// ============================================================
void fcn.1801defe0(int64_t param_1)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint32_t uVar8;
    undefined8 unaff_RBX;
    undefined8 uStackX_18;
    undefined8 uStackX_20;
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStackX_18 + iVar7) = 0x1801deeec;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)(&stack0x000000a0 + iVar5 + iVar7) = *(uint64_t *)0x1806a3940 ^ (int64_t)&uStackX_20 + iVar5 + iVar7;
    *(undefined8 *)(&stack0x00000090 + iVar5 + iVar7) = 0;
    iVar6 = *(int64_t *)(param_1 + 0x48);
    *(undefined (*) [16])(&stack0x00000040 + iVar5 + iVar7) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00000050 + iVar5 + iVar7) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00000060 + iVar5 + iVar7) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00000070 + iVar5 + iVar7) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00000080 + iVar5 + iVar7) = ZEXT816(0);
    if (((iVar6 == 0) && ((*(uint32_t *)(param_1 + 0x5d4) & 0x200) != 0)) &&
       ((uVar8 = *(uint32_t *)(param_1 + 0x5d0) >> 0x19 & 1, uVar8 == 0 || (*(char *)(param_1 + 0x428) != '\0')))) {
        uVar1 = *(undefined4 *)(param_1 + 0x428);
        uVar2 = *(undefined4 *)(param_1 + 0x42c);
        uVar3 = *(undefined4 *)(param_1 + 0x430);
        uVar4 = *(undefined4 *)(param_1 + 0x434);
        *(undefined4 *)(&stack0x00000050 + iVar5 + iVar7) = *(undefined4 *)(param_1 + 0x438);
        (&stack0x00000054)[iVar5 + iVar7] = *(undefined *)(param_1 + 0x43c);
        *(undefined8 *)(&stack0x00000058 + iVar5 + iVar7) = *(undefined8 *)(param_1 + 0x5f0);
        *(undefined4 *)(&stack0x00000040 + iVar5 + iVar7) = uVar1;
        *(undefined4 *)(&stack0x00000044 + iVar5 + iVar7) = uVar2;
        *(undefined4 *)(&stack0x00000048 + iVar5 + iVar7) = uVar3;
        *(undefined4 *)(&stack0x0000004c + iVar5 + iVar7) = uVar4;
        *(uint32_t *)(&stack0x00000070 + iVar5 + iVar7) = uVar8;
        *(undefined8 *)(&stack0x00000078 + iVar5 + iVar7) = 0x1801e36e0;
        *(undefined (*) [16])(&stack0x00000060 + iVar5 + iVar7) = ZEXT816(0);
        *(int64_t *)(&stack0x00000080 + iVar5 + iVar7) = param_1;
        *(undefined8 *)((int64_t)&uStackX_18 + iVar5 + iVar7) = 0x1801defab;
        iVar6 = func_0x0001801fa480(&stack0x00000040 + iVar5 + iVar7);
        *(int64_t *)(param_1 + 0x48) = iVar6;
        if (iVar6 == 0) {
            *(uint32_t *)(param_1 + 0x5d4) = *(uint32_t *)(param_1 + 0x5d4) & 0xfffffdff;
        }
    }
    *(undefined8 *)((int64_t)&uStackX_18 + iVar5 + iVar7) = 0x1801defd0;
    fcn.180459870(*(uint64_t *)(&stack0x000000a0 + iVar5 + iVar7) ^ (int64_t)&uStackX_20 + iVar5 + iVar7);
    return;
}

// ============================================================
// Function: FUN_1801df000
// Address: 0x1801df000
// Size: 1838 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_ffh
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ach

void fcn.1801df000(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_208h)
{
    int64_t *piVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    int64_t *piVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    uint64_t uVar11;
    int64_t *piVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_1d8h;
    int64_t var_1d0h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    int64_t var_1b8h;
    int64_t var_1b0h;
    int64_t var_1a8h;
    undefined8 uStack_1a0;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    undefined8 uStack_170;
    int64_t var_168h;
    int64_t var_160h;
    undefined auStack_158 [16];
    int64_t var_148h;
    int64_t var_138h;
    int64_t var_128h;
    undefined4 uStack_120;
    undefined4 uStack_11c;
    int64_t var_118h;
    undefined4 uStack_10f;
    undefined4 uStack_10b;
    undefined4 uStack_107;
    int64_t var_103h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_38h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801df02a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar6);
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df052;
    fcn.1804986e0(&var_128h, 0, 0xe8);
    iVar7 = *in_RCX;
    var_138h = 0;
    _var_1a8h = ZEXT816(0);
    _var_198h = ZEXT816(0);
    _var_188h = ZEXT816(0);
    _var_178h = ZEXT816(0);
    _var_168h = ZEXT816(0);
    auStack_158 = ZEXT816(0);
    _var_148h = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&var_8h + iVar6) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&var_18h + iVar6) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_28h + iVar6) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_38h + iVar6) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_48h + iVar6) = ZEXT816(0);
    if (((iVar7 != 0) && (in_RCX[7] != 0)) && (in_RCX[8] != 0)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df0c4;
        iVar4 = func_0x0001801e8e40();
        iVar7 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df0cf;
        iVar5 = func_0x0001801e8e70(iVar7);
        if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) == 0) {
            uVar2 = **(undefined8 **)*in_RCX;
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df0f3;
            iVar5 = func_0x0001801f99a0(uVar2, (int64_t)iVar5, in_RCX + 0x85);
            if (iVar5 == 0) goto code_r0x0001801df6f4;
        }
        var_1a8h = **(undefined8 **)*in_RCX;
        var_180h = (int64_t)in_RCX;
        var_188h = (int64_t)fcn.1801defe0;
        var_190h = 0x4b0;
        in_RCX[0xa6] = 0x4b0;
        in_RCX[0xb5] = -1;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df13e;
        iVar7 = func_0x0001801fb810(&var_1a8h);
        in_RCX[0x7a] = iVar7;
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df153;
            iVar7 = func_0x000180203ae0();
            in_RCX[0x12] = iVar7;
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df168;
                iVar7 = func_0x000180202050();
                in_RCX[0x13] = iVar7;
                if (iVar7 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df189;
                    iVar5 = func_0x0001801e5c50(in_RCX + 0x14, 0);
                    if (iVar5 != 0) {
                        *(int64_t **)(&stack0x00000000 + iVar6) = in_RCX;
                        in_RCX[0x97] = 0x80000;
                        in_RCX[0x98] = 0x80000;
                        in_RCX[0x99] = 0x80000;
                        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = 0x1801e36e0;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df1e0;
                        iVar5 = func_0x0001801e59b0(in_RCX + 0x18, 0, 0xc0000, 0xf00000);
                        if (iVar5 != 0) {
                            uVar11 = 0;
                            do {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df211;
                                iVar5 = func_0x0001801e5a00(in_RCX + (uVar11 + 3) * 0xc, 0x4000, 0x1801e36e0, in_RCX);
                                if (iVar5 == 0) goto code_r0x0001801df6f4;
                                uVar9 = (int32_t)uVar11 + 1;
                                uVar11 = (uint64_t)uVar9;
                            } while (uVar9 < 3);
                            piVar8 = in_RCX + 0x48;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df23a;
                            iVar5 = func_0x0001801e5a00(piVar8, 100, 0x1801e36e0, in_RCX);
                            if (iVar5 != 0) {
                                piVar1 = in_RCX + 0x54;
                                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df260;
                                iVar5 = func_0x0001801e5a00(piVar1, 100, 0x1801e36e0, in_RCX);
                                if (iVar5 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df274;
                                    iVar5 = func_0x0001801de240(in_RCX + 0x72);
                                    if (iVar5 != 0) {
                                        *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x1000;
                                        in_RCX[0x78] = 0x1804ba130;
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df2a7;
                                        iVar7 = (*(code *)0x18020a610)(0x1801e36e0, in_RCX);
                                        in_RCX[0x77] = iVar7;
                                        if (iVar7 != 0) {
                                            iVar3 = in_RCX[0x78];
                                            *(uint32_t *)(&stack0x00000000 + iVar6) =
                                                 *(uint32_t *)(in_RCX + 0xba) >> 0x19 & 1;
                                            *(int64_t *)(&stack0xfffffffffffffff8 + iVar6) = iVar7;
                                            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df2e9;
                                            iVar7 = func_0x000180202ae0(0x1801e36e0, in_RCX, in_RCX + 0x72, iVar3);
                                            in_RCX[0x79] = iVar7;
                                            if (iVar7 != 0) {
                                                *(int64_t **)(&stack0x00000000 + iVar6) = in_RCX;
                                                *(int64_t **)(&stack0xfffffffffffffff8 + iVar6) = piVar1;
                                                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df31f;
                                                iVar5 = func_0x0001801e78a0(in_RCX + 0x60, 0x1801e36c0, in_RCX, piVar8);
                                                if (iVar5 != 0) {
                                                    *(uint32_t *)(in_RCX + 0xba) = *(uint32_t *)(in_RCX + 0xba) | 0x2000
                                                    ;
                                                    if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) == 0) {
                                                        iVar7 = in_RCX[7];
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df350;
                                                        iVar5 = func_0x000180200eb0(iVar7, in_RCX, 
                                                                                    (int64_t)in_RCX + 0x452);
                                                        if (iVar5 == 0) goto code_r0x0001801df6f4;
                                                    }
                                                    var_118h._0_4_ = *(undefined4 *)((int64_t)in_RCX + 0x462);
                                                    var_128h._0_4_ = *(undefined4 *)((int64_t)in_RCX + 0x452);
                                                    var_128h._4_4_ = *(undefined4 *)((int64_t)in_RCX + 0x456);
                                                    uStack_120 = *(undefined4 *)((int64_t)in_RCX + 0x45a);
                                                    uStack_11c = *(undefined4 *)((int64_t)in_RCX + 0x45e);
                                                    var_118h._4_1_ = *(undefined *)((int64_t)in_RCX + 0x466);
                                                    var_103h._0_4_ = *(undefined4 *)(in_RCX + 0x87);
                                                    var_103h._4_1_ = *(undefined *)((int64_t)in_RCX + 0x43c);
                                                    var_d8h = in_RCX[0x7a];
                                                    var_d0h = in_RCX[0x12];
                                                    var_c8h = in_RCX[0x13];
                                                    var_c0h = in_RCX[0x79];
                                                    var_90h = in_RCX[0x78];
                                                    var_88h = in_RCX[0x77];
                                                    var_80h = 0x1801e36e0;
                                                    unique0x100006f3 = *(undefined4 *)(in_RCX + 0x85);
                                                    uStack_10f = *(undefined4 *)((int64_t)in_RCX + 0x42c);
                                                    uStack_10b = *(undefined4 *)(in_RCX + 0x86);
                                                    uStack_107 = *(undefined4 *)((int64_t)in_RCX + 0x434);
                                                    var_70h = (int64_t)fcn.1801defe0;
                                                    uVar10 = 0;
                                                    piVar12 = &var_58h;
                                                    var_e0h._0_4_ = 3;
                                                    var_60h._0_4_ = 1;
                                                    uVar9 = uVar10;
                                                    var_b8h = (int64_t)(in_RCX + 0x60);
                                                    var_b0h = (int64_t)(in_RCX + 0x14);
                                                    var_a8h = (int64_t)(in_RCX + 0x18);
                                                    var_a0h = (int64_t)piVar8;
                                                    var_98h = (int64_t)piVar1;
                                                    do {
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df46a;
                                                        iVar7 = func_0x0001801e66a0(0x4000);
                                                        *(int64_t *)
                                                         ((int64_t)in_RCX + (0x3f8 - (int64_t)&var_58h) +
                                                         (int64_t)piVar12) = iVar7;
                                                        if (iVar7 == 0) goto code_r0x0001801df6f4;
                                                        *piVar12 = iVar7;
                                                        uVar9 = uVar9 + 1;
                                                        piVar12 = piVar12 + 1;
                                                    } while (uVar9 < 3);
                                                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df492;
                                                    iVar7 = func_0x000180207c40(&var_128h);
                                                    in_RCX[0x11] = iVar7;
                                                    if (iVar7 != 0) {
                                                        if ((*(uint32_t *)(in_RCX + 0xba) & 0x2000000) == 0) {
                                                            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df4b6;
                                                            func_0x000180208210(iVar7);
                                                        }
                                                        iVar7 = in_RCX[0x11];
                                                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df4cc;
                                                        func_0x000180207fe0(iVar7, 0x1801e1a30, in_RCX);
                                                        iVar7 = in_RCX[0x7b];
                                                        if (iVar7 == 0) {
                                                            if ((*(uint32_t *)((int64_t)in_RCX + 0x5d4) & 0x400) == 0) {
                                                                var_178h = **(undefined8 **)(undefined8 *)*in_RCX;
                                                                var_160h = (int64_t)iVar4;
                                                                var_168h = ((undefined8 *)*in_RCX)[8];
                                                                auStack_158._0_8_ = 0x20;
                                                                *(undefined8 *)((int64_t)&uStack_30 + iVar6) =
                                                                     0x1801df50e;
                                                                iVar7 = func_0x000180205410(&var_178h);
                                                                in_RCX[0x7b] = iVar7;
                                                                if (iVar7 == 0) goto code_r0x0001801df6f4;
                                                                goto code_r0x0001801df51e;
                                                            }
code_r0x0001801df556:
                                                            piVar8 = in_RCX + 0x82;
                                                            do {
                                                                *(undefined8 *)((int64_t)&uStack_30 + iVar6) =
                                                                     0x1801df56c;
                                                                iVar7 = func_0x0001801e6c90(0, 0, 0);
                                                                *piVar8 = iVar7;
                                                                if (iVar7 == 0) goto code_r0x0001801df6f4;
                                                                uVar10 = uVar10 + 1;
                                                                piVar8 = piVar8 + 1;
                                                            } while (uVar10 < 3);
                                                            *(int64_t *)((int64_t)&var_8h + iVar6) = in_RCX[6];
                                                            *(undefined8 *)((int64_t)&var_10h + iVar6) = 0x1801dfc30;
                                                            *(undefined8 *)((int64_t)&var_20h + iVar6) = 0x1801df8c0;
                                                            *(undefined8 *)((int64_t)&arg_30h + iVar6) = 0x1801dfb70;
                                                            *(undefined8 *)((int64_t)&arg_40h + iVar6) = 0x1801e03b0;
                                                            *(undefined8 *)((int64_t)&arg_50h + iVar6) = 0x1801e0890;
                                                            *(int64_t **)((int64_t)&var_18h + iVar6) = in_RCX;
                                                            *(int64_t **)((int64_t)&arg_28h + iVar6) = in_RCX;
                                                            *(int64_t **)((int64_t)&arg_38h + iVar6) = in_RCX;
                                                            *(int64_t **)((int64_t)&arg_48h + iVar6) = in_RCX;
                                                            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df61e;
                                                            iVar7 = func_0x0001801a6180((int64_t)&var_8h + iVar6);
                                                            in_RCX[5] = iVar7;
                                                            if (iVar7 != 0) {
                                                                iVar7 = in_RCX[0x79];
                                                                *(uint32_t *)(in_RCX + 0xba) =
                                                                     *(uint32_t *)(in_RCX + 0xba) & 0xfff03fff;
                                                                in_RCX[0x9a] = 0x19;
                                                                in_RCX[0x9e] = 0x19;
                                                                *(undefined *)(in_RCX + 0x9f) = 3;
                                                                in_RCX[0xa7] = 2;
                                                                in_RCX[0xad] = -1;
                                                                in_RCX[0xa3] = 30000;
                                                                in_RCX[0xa4] = 0;
                                                                in_RCX[0xa5] = 30000;
                                                                *(undefined8 *)((int64_t)&uStack_30 + iVar6) =
                                                                     0x1801df696;
                                                                func_0x0001802038a0(iVar7, 25000000);
                                                                iVar7 = in_RCX[0x9e];
                                                                iVar3 = in_RCX[0x79];
                                                                *(undefined8 *)((int64_t)&uStack_30 + iVar6) =
                                                                     0x1801df6ad;
                                                                func_0x000180203890(iVar3, iVar7 * 1000000);
                                                                *(undefined8 *)((int64_t)&uStack_30 + iVar6) =
                                                                     0x1801df6b5;
                                                                func_0x0001801e3460(in_RCX);
                                                                iVar7 = *in_RCX;
                                                                if (*(int64_t *)(iVar7 + 0x50) != 0) {
                                                                    *(int64_t **)(*(int64_t *)(iVar7 + 0x50) + 8) =
                                                                         in_RCX;
                                                                }
                                                                in_RCX[2] = *(int64_t *)(iVar7 + 0x50);
                                                                in_RCX[1] = 0;
                                                                *(int64_t **)(iVar7 + 0x50) = in_RCX;
                                                                if (*(int64_t *)(iVar7 + 0x48) == 0) {
                                                                    *(int64_t **)(iVar7 + 0x48) = in_RCX;
                                                                }
                                                                *(int64_t *)(iVar7 + 0x58) =
                                                                     *(int64_t *)(iVar7 + 0x58) + 1;
                                                                *(uint32_t *)((int64_t)in_RCX + 0x5d4) =
                                                                     *(uint32_t *)((int64_t)in_RCX + 0x5d4) | 0x100;
                                                                goto code_r0x0001801df6fe;
                                                            }
                                                        } else {
code_r0x0001801df51e:
                                                            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df530;
                                                            iVar4 = func_0x000180205740(iVar7, 0x1801e55f0, in_RCX);
                                                            if (iVar4 != 0) {
                                                                iVar7 = in_RCX[0x7b];
                                                                *(undefined8 *)((int64_t)&uStack_30 + iVar6) =
                                                                     0x1801df54e;
                                                                iVar4 = func_0x000180205720(iVar7, 0x1801e5620, in_RCX);
                                                                if (iVar4 != 0) goto code_r0x0001801df556;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
code_r0x0001801df6f4:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df6fc;
    fcn.1801de360(*(int64_t *)(&stack0xfffffffffffffff8 + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
code_r0x0001801df6fe:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1801df70d;
    fcn.180459870(var_38h ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801df730
// Address: 0x1801df730
// Size: 385 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801df730(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int32_t in_R8D;
    int32_t in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801df754;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar5 = *(uint32_t *)(in_RDX + 0x100) & 2;
    uVar6 = (~(*(uint32_t *)(in_RCX + 0x5d0) >> 0x19) ^ *(uint32_t *)(in_RDX + 0x100)) & 1;
    if (in_R8D != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801df78b;
        iVar3 = func_0x0001801e66a0(0x2000);
        *(int64_t *)(in_RDX + 0x70) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801df86e;
    }
    if (in_R9D != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801df7a9;
        iVar3 = func_0x0001801e6c90(0, 0, 0);
        *(int64_t *)(in_RDX + 0x78) = iVar3;
        if (iVar3 == 0) goto code_r0x0001801df86e;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801df7c9;
    iVar1 = func_0x0001801e5c50(in_RDX + 0x80, in_RCX + 0xa0);
    if (iVar1 != 0) {
        if (((*(uint8_t *)(in_RCX + 0x5d0) & 0x80) != 0) && (in_R8D != 0)) {
            if (uVar5 == 0) {
                if (uVar6 == 0) {
                    uVar4 = *(undefined8 *)(in_RCX + 0x4e0);
                } else {
                    uVar4 = *(undefined8 *)(in_RCX + 0x4d8);
                }
            } else {
                uVar4 = *(undefined8 *)(in_RCX + 0x4e8);
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801df80c;
            func_0x0001801e5b80(in_RDX + 0x80, uVar4);
        }
        if (in_R9D == 0) {
            iVar3 = 0;
        } else if (uVar5 == 0) {
            if (uVar6 == 0) {
                iVar3 = *(int64_t *)(in_RCX + 0x4c0);
            } else {
                iVar3 = *(int64_t *)(in_RCX + 0x4b8);
            }
        } else {
            iVar3 = *(int64_t *)(in_RCX + 0x4c8);
        }
        *(int64_t *)((int64_t)&var_10h + iVar2) = in_RCX;
        *(undefined8 *)((int64_t)&var_8h + iVar2) = 0x1801e36e0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801df863;
        iVar1 = func_0x0001801e59b0(in_RDX + 0xa0, in_RCX + 0xc0, iVar3, iVar3 * 0xc);
        if (iVar1 != 0) {
            return 1;
        }
    }
code_r0x0001801df86e:
    uVar4 = *(undefined8 *)(in_RDX + 0x70);
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801df877;
    func_0x0001801e6180(uVar4);
    uVar4 = *(undefined8 *)(in_RDX + 0x78);
    *(undefined8 *)(in_RDX + 0x70) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801df888;
    func_0x0001801e6b30(uVar4);
    *(undefined8 *)(in_RDX + 0x78) = 0;
    return 0;
}

// ============================================================
// Function: FUN_1801df8c0
// Address: 0x1801df8c0
// Size: 256 bytes
// ============================================================
undefined8
fcn.1801df8c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_a0h, int64_t arg_b0h, int64_t arg_b8h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    undefined8 in_RCX;
    undefined8 in_RDX;
    uint32_t uVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t in_R8;
    undefined8 unaff_R12;
    undefined8 uVar11;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_38;
    
    uStack_38 = 0x1801df8d3;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(uint32_t *)(in_R8 + 0x5d0);
    uVar8 = 0;
    *(undefined4 *)((int64_t)&arg_b8h + iVar3) = 0;
    iVar10 = 0x420;
    if ((uVar1 & 0xe0000) != 0) {
        do {
            if (uVar8 != 1) {
                if (uVar8 == 0) {
                    iVar4 = 0x410;
                } else if ((uVar8 == 1) || (uVar8 != 2)) {
                    iVar4 = 0x420;
                } else {
                    iVar4 = 0x418;
                }
                iVar4 = *(int64_t *)(iVar4 + in_R8);
                *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
                *(undefined4 *)((int64_t)&arg_b0h + iVar3) = 0;
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801df950;
                    iVar2 = func_0x0001801e6a70(iVar4, (int64_t)&arg_30h + iVar3, (int64_t)&arg_b0h + iVar3);
                    if ((iVar2 == 0) || (*(int64_t *)((int64_t)&arg_30h + iVar3) != 0)) {
                        *(undefined8 *)((int64_t)&arg_58h + iVar3) = 0;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801df9af;
                        iVar10 = func_0x0001801fca50(10);
                        if ((*(uint8_t *)(in_R8 + 0x5d4) & 0x40) != 0) {
                            return 0;
                        }
                        *(undefined8 *)((int64_t)&arg_a0h + iVar3) = unaff_R12;
                        uVar11 = 0x1805aadb1;
                        *(undefined8 *)((int64_t)&arg_60h + iVar3) = unaff_R15;
                        uVar7 = 0x1805aadb1;
                        if (iVar10 != 0) {
                            uVar7 = 0x1805ab2bc;
                        }
                        uVar9 = 0x1805aadb1;
                        iVar4 = 0x1805aadb1;
                        if (iVar10 != 0) {
                            uVar9 = 0x1805ab2cc;
                            iVar4 = iVar10;
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfa04;
                        iVar5 = func_0x0001801fcb70(6);
                        iVar10 = 0x1805aadb1;
                        if (iVar5 != 0) {
                            iVar10 = iVar5;
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfa16;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar3), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfa2e;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar3), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar3), 
                                      *(int64_t *)(&stack0x00000000 + iVar3), *(int64_t *)((int64_t)&var_8h + iVar3), 
                                      *(int64_t *)((int64_t)&var_20h + iVar3));
                        uVar6 = 0x1805aadb1;
                        *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0x1804b6418;
                        if (iVar5 != 0) {
                            uVar6 = 0x1805ab2bc;
                            uVar11 = 0x1805ab2cc;
                        }
                        *(undefined8 *)((int64_t)&var_20h + iVar3) = uVar6;
                        *(int64_t *)((int64_t)&var_18h + iVar3) = iVar10;
                        *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar11;
                        *(undefined8 *)((int64_t)&var_8h + iVar3) = 6;
                        *(undefined8 *)(&stack0x00000000 + iVar3) = uVar7;
                        *(int64_t *)(&stack0xfffffffffffffff8 + iVar3) = iVar4;
                        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar3) = uVar9;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfa92;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_10h + iVar3));
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfaaa;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar3), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar3), 
                                      *(int64_t *)(&stack0x00000000 + iVar3), *(int64_t *)((int64_t)&var_8h + iVar3), 
                                      *(int64_t *)((int64_t)&var_20h + iVar3));
                        iVar10 = *(int64_t *)(in_R8 + 0x5d8);
                        if (iVar10 == 0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfacb;
                            iVar10 = func_0x0001802542f0();
                            *(int64_t *)(in_R8 + 0x5d8) = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801dfadf;
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfadf;
                        func_0x000180254600(iVar10);
code_r0x0001801dfadf:
                        *(uint32_t *)(in_R8 + 0x5d4) = *(uint32_t *)(in_R8 + 0x5d4) | 0x40;
                        *(undefined8 *)((int64_t)&arg_38h + iVar3) = 10;
                        *(undefined8 *)((int64_t)&arg_40h + iVar3) = 6;
                        *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0x1804b6418;
                        *(undefined8 *)((int64_t)&arg_50h + iVar3) = 0x1e;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfb1a;
                        func_0x0001801e2d20(in_R8, (int64_t)&arg_38h + iVar3, 0);
                        return 0;
                    }
                }
            }
            uVar1 = *(uint32_t *)(in_R8 + 0x5d0);
            uVar8 = uVar8 + 1;
        } while (uVar8 < (uVar1 >> 0x11 & 7));
    }
    uVar8 = uVar1 >> 0x11 & 7;
    if ((uVar1 >> 0x11 & 7) == 0) {
        iVar10 = 0x410;
    } else if ((uVar8 != 1) && (uVar8 == 2)) {
        iVar10 = 0x418;
    }
    iVar10 = *(int64_t *)(iVar10 + in_R8);
    if (iVar10 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfb5f;
    uVar7 = func_0x0001801e6bb0(iVar10, in_RCX, in_RDX, (int64_t)&arg_b8h + iVar3);
    return uVar7;
}

// ============================================================
// Function: FUN_1801df9c0
// Address: 0x1801df9c0
// Size: 262 bytes
// ============================================================
undefined8
fcn.1801df8c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_a0h, int64_t arg_b0h, int64_t arg_b8h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    undefined8 in_RCX;
    undefined8 in_RDX;
    uint32_t uVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t in_R8;
    undefined8 unaff_R12;
    undefined8 uVar11;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_38;
    
    uStack_38 = 0x1801df8d3;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(uint32_t *)(in_R8 + 0x5d0);
    uVar8 = 0;
    *(undefined4 *)((int64_t)&arg_b8h + iVar3) = 0;
    iVar10 = 0x420;
    if ((uVar1 & 0xe0000) != 0) {
        do {
            if (uVar8 != 1) {
                if (uVar8 == 0) {
                    iVar4 = 0x410;
                } else if ((uVar8 == 1) || (uVar8 != 2)) {
                    iVar4 = 0x420;
                } else {
                    iVar4 = 0x418;
                }
                iVar4 = *(int64_t *)(iVar4 + in_R8);
                *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
                *(undefined4 *)((int64_t)&arg_b0h + iVar3) = 0;
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801df950;
                    iVar2 = func_0x0001801e6a70(iVar4, (int64_t)&arg_30h + iVar3, (int64_t)&arg_b0h + iVar3);
                    if ((iVar2 == 0) || (*(int64_t *)((int64_t)&arg_30h + iVar3) != 0)) {
                        *(undefined8 *)((int64_t)&arg_58h + iVar3) = 0;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801df9af;
                        iVar10 = func_0x0001801fca50(10);
                        if ((*(uint8_t *)(in_R8 + 0x5d4) & 0x40) != 0) {
                            return 0;
                        }
                        *(undefined8 *)((int64_t)&arg_a0h + iVar3) = unaff_R12;
                        uVar11 = 0x1805aadb1;
                        *(undefined8 *)((int64_t)&arg_60h + iVar3) = unaff_R15;
                        uVar7 = 0x1805aadb1;
                        if (iVar10 != 0) {
                            uVar7 = 0x1805ab2bc;
                        }
                        uVar9 = 0x1805aadb1;
                        iVar4 = 0x1805aadb1;
                        if (iVar10 != 0) {
                            uVar9 = 0x1805ab2cc;
                            iVar4 = iVar10;
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfa04;
                        iVar5 = func_0x0001801fcb70(6);
                        iVar10 = 0x1805aadb1;
                        if (iVar5 != 0) {
                            iVar10 = iVar5;
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfa16;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar3), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfa2e;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar3), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar3), 
                                      *(int64_t *)(&stack0x00000000 + iVar3), *(int64_t *)((int64_t)&var_8h + iVar3), 
                                      *(int64_t *)((int64_t)&var_20h + iVar3));
                        uVar6 = 0x1805aadb1;
                        *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0x1804b6418;
                        if (iVar5 != 0) {
                            uVar6 = 0x1805ab2bc;
                            uVar11 = 0x1805ab2cc;
                        }
                        *(undefined8 *)((int64_t)&var_20h + iVar3) = uVar6;
                        *(int64_t *)((int64_t)&var_18h + iVar3) = iVar10;
                        *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar11;
                        *(undefined8 *)((int64_t)&var_8h + iVar3) = 6;
                        *(undefined8 *)(&stack0x00000000 + iVar3) = uVar7;
                        *(int64_t *)(&stack0xfffffffffffffff8 + iVar3) = iVar4;
                        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar3) = uVar9;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfa92;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_10h + iVar3));
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfaaa;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar3), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar3), 
                                      *(int64_t *)(&stack0x00000000 + iVar3), *(int64_t *)((int64_t)&var_8h + iVar3), 
                                      *(int64_t *)((int64_t)&var_20h + iVar3));
                        iVar10 = *(int64_t *)(in_R8 + 0x5d8);
                        if (iVar10 == 0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfacb;
                            iVar10 = func_0x0001802542f0();
                            *(int64_t *)(in_R8 + 0x5d8) = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801dfadf;
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfadf;
                        func_0x000180254600(iVar10);
code_r0x0001801dfadf:
                        *(uint32_t *)(in_R8 + 0x5d4) = *(uint32_t *)(in_R8 + 0x5d4) | 0x40;
                        *(undefined8 *)((int64_t)&arg_38h + iVar3) = 10;
                        *(undefined8 *)((int64_t)&arg_40h + iVar3) = 6;
                        *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0x1804b6418;
                        *(undefined8 *)((int64_t)&arg_50h + iVar3) = 0x1e;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfb1a;
                        func_0x0001801e2d20(in_R8, (int64_t)&arg_38h + iVar3, 0);
                        return 0;
                    }
                }
            }
            uVar1 = *(uint32_t *)(in_R8 + 0x5d0);
            uVar8 = uVar8 + 1;
        } while (uVar8 < (uVar1 >> 0x11 & 7));
    }
    uVar8 = uVar1 >> 0x11 & 7;
    if ((uVar1 >> 0x11 & 7) == 0) {
        iVar10 = 0x410;
    } else if ((uVar8 != 1) && (uVar8 == 2)) {
        iVar10 = 0x418;
    }
    iVar10 = *(int64_t *)(iVar10 + in_R8);
    if (iVar10 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfb5f;
    uVar7 = func_0x0001801e6bb0(iVar10, in_RCX, in_RDX, (int64_t)&arg_b8h + iVar3);
    return uVar7;
}

// ============================================================
// Function: FUN_1801dfac6
// Address: 0x1801dfac6
// Size: 169 bytes
// ============================================================
undefined8
fcn.1801df8c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_a0h, int64_t arg_b0h, int64_t arg_b8h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    undefined8 in_RCX;
    undefined8 in_RDX;
    uint32_t uVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t in_R8;
    undefined8 unaff_R12;
    undefined8 uVar11;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_38;
    
    uStack_38 = 0x1801df8d3;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(uint32_t *)(in_R8 + 0x5d0);
    uVar8 = 0;
    *(undefined4 *)((int64_t)&arg_b8h + iVar3) = 0;
    iVar10 = 0x420;
    if ((uVar1 & 0xe0000) != 0) {
        do {
            if (uVar8 != 1) {
                if (uVar8 == 0) {
                    iVar4 = 0x410;
                } else if ((uVar8 == 1) || (uVar8 != 2)) {
                    iVar4 = 0x420;
                } else {
                    iVar4 = 0x418;
                }
                iVar4 = *(int64_t *)(iVar4 + in_R8);
                *(undefined8 *)((int64_t)&arg_30h + iVar3) = 0;
                *(undefined4 *)((int64_t)&arg_b0h + iVar3) = 0;
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801df950;
                    iVar2 = func_0x0001801e6a70(iVar4, (int64_t)&arg_30h + iVar3, (int64_t)&arg_b0h + iVar3);
                    if ((iVar2 == 0) || (*(int64_t *)((int64_t)&arg_30h + iVar3) != 0)) {
                        *(undefined8 *)((int64_t)&arg_58h + iVar3) = 0;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801df9af;
                        iVar10 = func_0x0001801fca50(10);
                        if ((*(uint8_t *)(in_R8 + 0x5d4) & 0x40) != 0) {
                            return 0;
                        }
                        *(undefined8 *)((int64_t)&arg_a0h + iVar3) = unaff_R12;
                        uVar11 = 0x1805aadb1;
                        *(undefined8 *)((int64_t)&arg_60h + iVar3) = unaff_R15;
                        uVar7 = 0x1805aadb1;
                        if (iVar10 != 0) {
                            uVar7 = 0x1805ab2bc;
                        }
                        uVar9 = 0x1805aadb1;
                        iVar4 = 0x1805aadb1;
                        if (iVar10 != 0) {
                            uVar9 = 0x1805ab2cc;
                            iVar4 = iVar10;
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfa04;
                        iVar5 = func_0x0001801fcb70(6);
                        iVar10 = 0x1805aadb1;
                        if (iVar5 != 0) {
                            iVar10 = iVar5;
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfa16;
                        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff0 + iVar3), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfa2e;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar3), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar3), 
                                      *(int64_t *)(&stack0x00000000 + iVar3), *(int64_t *)((int64_t)&var_8h + iVar3), 
                                      *(int64_t *)((int64_t)&var_20h + iVar3));
                        uVar6 = 0x1805aadb1;
                        *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0x1804b6418;
                        if (iVar5 != 0) {
                            uVar6 = 0x1805ab2bc;
                            uVar11 = 0x1805ab2cc;
                        }
                        *(undefined8 *)((int64_t)&var_20h + iVar3) = uVar6;
                        *(int64_t *)((int64_t)&var_18h + iVar3) = iVar10;
                        *(undefined8 *)((int64_t)&var_10h + iVar3) = uVar11;
                        *(undefined8 *)((int64_t)&var_8h + iVar3) = 6;
                        *(undefined8 *)(&stack0x00000000 + iVar3) = uVar7;
                        *(int64_t *)(&stack0xfffffffffffffff8 + iVar3) = iVar4;
                        *(undefined8 *)(&stack0xfffffffffffffff0 + iVar3) = uVar9;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfa92;
                        fcn.1802296d0(*(int64_t *)((int64_t)&var_10h + iVar3));
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfaaa;
                        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff0 + iVar3), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar3), 
                                      *(int64_t *)(&stack0x00000000 + iVar3), *(int64_t *)((int64_t)&var_8h + iVar3), 
                                      *(int64_t *)((int64_t)&var_20h + iVar3));
                        iVar10 = *(int64_t *)(in_R8 + 0x5d8);
                        if (iVar10 == 0) {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfacb;
                            iVar10 = func_0x0001802542f0();
                            *(int64_t *)(in_R8 + 0x5d8) = iVar10;
                            if (iVar10 == 0) goto code_r0x0001801dfadf;
                        }
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfadf;
                        func_0x000180254600(iVar10);
code_r0x0001801dfadf:
                        *(uint32_t *)(in_R8 + 0x5d4) = *(uint32_t *)(in_R8 + 0x5d4) | 0x40;
                        *(undefined8 *)((int64_t)&arg_38h + iVar3) = 10;
                        *(undefined8 *)((int64_t)&arg_40h + iVar3) = 6;
                        *(undefined8 *)((int64_t)&arg_48h + iVar3) = 0x1804b6418;
                        *(undefined8 *)((int64_t)&arg_50h + iVar3) = 0x1e;
                        *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfb1a;
                        func_0x0001801e2d20(in_R8, (int64_t)&arg_38h + iVar3, 0);
                        return 0;
                    }
                }
            }
            uVar1 = *(uint32_t *)(in_R8 + 0x5d0);
            uVar8 = uVar8 + 1;
        } while (uVar8 < (uVar1 >> 0x11 & 7));
    }
    uVar8 = uVar1 >> 0x11 & 7;
    if ((uVar1 >> 0x11 & 7) == 0) {
        iVar10 = 0x410;
    } else if ((uVar8 != 1) && (uVar8 == 2)) {
        iVar10 = 0x418;
    }
    iVar10 = *(int64_t *)(iVar10 + in_R8);
    if (iVar10 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_38 + iVar3) = 0x1801dfb5f;
    uVar7 = func_0x0001801e6bb0(iVar10, in_RCX, in_RDX, (int64_t)&arg_b8h + iVar3);
    return uVar7;
}

// ============================================================
// Function: FUN_1801dfb70
// Address: 0x1801dfb70
// Size: 191 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801dfb70(int64_t arg_28h, int64_t arg_68h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 in_RCX;
    int64_t in_RDX;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801dfb82;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_28h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar3);
    uVar1 = *(uint32_t *)(in_RDX + 0x5d0) >> 0x11 & 7;
    if (uVar1 == 0) {
        iVar4 = 0x410;
        iVar5 = 0x120;
    } else if ((uVar1 == 1) || (uVar1 != 2)) {
        iVar4 = 0x420;
        iVar5 = 0x1e0;
    } else {
        iVar4 = 0x418;
        iVar5 = 0x180;
    }
    iVar4 = *(int64_t *)(iVar4 + in_RDX);
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfbee;
        func_0x0001801de220(in_RDX + 0x390, (int64_t)&var_8h + iVar3);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfbff;
        iVar2 = func_0x0001801e5a40(iVar5 + in_RDX, in_RCX, *(undefined8 *)((int64_t)&var_8h + iVar3));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfc0e;
            func_0x0001801e6f10(iVar4, in_RCX);
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801dfc1f;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_28h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801dfc30
// Address: 0x1801dfc30
// Size: 94 bytes
// ============================================================
undefined8
fcn.1801dfc30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_60h,
             int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h,
             int64_t arg_100h, int64_t arg_158h)
{
    uint8_t uVar1;
    uint64_t uVar2;
    undefined8 *puVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    uint32_t uVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    undefined8 uVar14;
    int64_t in_RCX;
    int64_t *piVar15;
    uint64_t in_RDX;
    uint64_t uVar16;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t iVar17;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t *in_R8;
    int64_t in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iVar18;
    undefined8 auStackX_8 [4];
    
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    uVar9 = *(uint32_t *)(in_R9 + 0x5d0) >> 0xe & 7;
    if (uVar9 == 0) {
        iVar12 = 0x3f8;
    } else if ((uVar9 == 1) || (uVar9 != 2)) {
        iVar12 = 0x408;
    } else {
        iVar12 = 0x400;
    }
    piVar15 = *(int64_t **)(iVar12 + in_R9);
    if (piVar15 == (int64_t *)0x0) {
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar11 + 0x18) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar11 + 0x10) = unaff_R12;
    *(undefined8 *)((int64_t)auStackX_8 + iVar11 + 8) = unaff_R13;
    *(undefined8 *)((int64_t)auStackX_8 + iVar11) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar11 + -8) = 0x1801e5fb2;
    iVar13 = fcn.18045a350(piVar15, in_RCX);
    iVar13 = -iVar13;
    *(uint64_t *)((int64_t)&arg_70h + iVar13 + iVar11) =
         *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_8 + iVar13 + iVar11;
    uVar5 = *(undefined4 *)piVar15;
    uVar6 = *(undefined4 *)((int64_t)piVar15 + 4);
    uVar7 = *(undefined4 *)(piVar15 + 1);
    uVar8 = *(undefined4 *)((int64_t)piVar15 + 0xc);
    iVar12 = 0;
    *(int64_t **)((int64_t)&arg_28h + iVar13 + iVar11) = in_R8;
    uVar1 = *(uint8_t *)(piVar15 + 10);
    *(undefined4 *)((int64_t)&arg_50h + iVar13 + iVar11) = uVar5;
    *(undefined4 *)((int64_t)&arg_50h + iVar13 + iVar11 + 4) = uVar6;
    *(undefined4 *)(&stack0x00000058 + iVar13 + iVar11) = uVar7;
    *(undefined4 *)(&stack0x0000005c + iVar13 + iVar11) = uVar8;
    *(uint64_t *)((int64_t)&arg_30h + iVar13 + iVar11) = in_RDX;
    uVar5 = *(undefined4 *)(piVar15 + 2);
    uVar6 = *(undefined4 *)((int64_t)piVar15 + 0x14);
    uVar7 = *(undefined4 *)(piVar15 + 3);
    uVar8 = *(undefined4 *)((int64_t)piVar15 + 0x1c);
    *(undefined8 *)((int64_t)&arg_38h + iVar13 + iVar11) = 0;
    *(undefined4 *)((int64_t)&arg_40h + iVar13 + iVar11) = uVar5;
    *(undefined4 *)((int64_t)&arg_40h + iVar13 + iVar11 + 4) = uVar6;
    *(undefined4 *)(&stack0x00000048 + iVar13 + iVar11) = uVar7;
    *(undefined4 *)(&stack0x0000004c + iVar13 + iVar11) = uVar8;
    if (((uVar1 & 1) == 0) && (in_RDX != 0)) {
        *(undefined8 *)((int64_t)&arg_98h + iVar13 + iVar11) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_90h + iVar13 + iVar11) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_88h + iVar13 + iVar11) = unaff_RDI;
        *(undefined8 *)((int64_t)&arg_80h + iVar13 + iVar11) = unaff_R15;
        do {
            iVar12 = *piVar15;
            iVar17 = 0;
            iVar18 = in_RCX;
            while( true ) {
                uVar4 = piVar15[2];
                uVar2 = piVar15[1];
                uVar16 = (uVar2 - uVar4) + piVar15[3];
                if (in_RDX <= uVar16) {
                    uVar16 = in_RDX;
                }
                in_RDX = 0x4000000000000000 - uVar4;
                if (uVar16 <= 0x4000000000000000 - uVar4) {
                    in_RDX = uVar16;
                }
                if (in_RDX == 0) break;
                uVar16 = uVar2 - uVar4 % uVar2;
                if (in_RDX < uVar16) {
                    uVar16 = in_RDX;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar13 + iVar11 + -8) = 0x1801e609c;
                func_0x000180498030(uVar4 % uVar2 + iVar12, iVar18, uVar16);
                piVar15[2] = piVar15[2] + uVar16;
                iVar18 = iVar18 + uVar16;
                in_RDX = in_RDX - uVar16;
                iVar17 = iVar17 + uVar16;
            }
            iVar12 = *(int64_t *)((int64_t)&arg_38h + iVar13 + iVar11);
            if (iVar17 == 0) break;
            in_RDX = *(int64_t *)((int64_t)&arg_30h + iVar13 + iVar11) - iVar17;
            iVar12 = iVar12 + iVar17;
            in_RCX = in_RCX + iVar17;
            *(uint64_t *)((int64_t)&arg_30h + iVar13 + iVar11) = in_RDX;
            *(int64_t *)((int64_t)&arg_38h + iVar13 + iVar11) = iVar12;
        } while (in_RDX != 0);
        if (iVar12 != 0) {
            iVar18 = *(int64_t *)((int64_t)&arg_40h + iVar13 + iVar11);
            *(int64_t *)((int64_t)&arg_60h + iVar13 + iVar11) = iVar18;
            *(int64_t *)((int64_t)&arg_68h + iVar13 + iVar11) = iVar18 + -1 + iVar12;
            *(undefined8 *)((int64_t)auStackX_8 + iVar13 + iVar11 + -8) = 0x1801e611b;
            iVar10 = func_0x00018020b010(piVar15 + 4, (int64_t)&arg_60h + iVar13 + iVar11);
            if (iVar10 == 0) {
                uVar5 = *(undefined4 *)((int64_t)&arg_50h + iVar13 + iVar11 + 4);
                uVar6 = *(undefined4 *)(&stack0x00000058 + iVar13 + iVar11);
                uVar7 = *(undefined4 *)(&stack0x0000005c + iVar13 + iVar11);
                puVar3 = *(undefined8 **)((int64_t)&arg_28h + iVar13 + iVar11);
                *(undefined4 *)piVar15 = *(undefined4 *)((int64_t)&arg_50h + iVar13 + iVar11);
                *(undefined4 *)((int64_t)piVar15 + 4) = uVar5;
                *(undefined4 *)(piVar15 + 1) = uVar6;
                *(undefined4 *)((int64_t)piVar15 + 0xc) = uVar7;
                uVar5 = *(undefined4 *)((int64_t)&arg_40h + iVar13 + iVar11 + 4);
                uVar6 = *(undefined4 *)(&stack0x00000048 + iVar13 + iVar11);
                uVar7 = *(undefined4 *)(&stack0x0000004c + iVar13 + iVar11);
                *(undefined4 *)(piVar15 + 2) = *(undefined4 *)((int64_t)&arg_40h + iVar13 + iVar11);
                *(undefined4 *)((int64_t)piVar15 + 0x14) = uVar5;
                *(undefined4 *)(piVar15 + 3) = uVar6;
                *(undefined4 *)((int64_t)piVar15 + 0x1c) = uVar7;
                *puVar3 = 0;
                goto code_r0x0001801e614d;
            }
        }
        in_R8 = *(int64_t **)((int64_t)&arg_28h + iVar13 + iVar11);
    }
    *in_R8 = iVar12;
code_r0x0001801e614d:
    uVar4 = *(uint64_t *)((int64_t)&arg_70h + iVar13 + iVar11);
    *(undefined8 *)((int64_t)auStackX_8 + iVar13 + iVar11 + -8) = 0x1801e615a;
    uVar14 = fcn.180459870(uVar4 ^ (int64_t)auStackX_8 + iVar13 + iVar11);
    return uVar14;
}

