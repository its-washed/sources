// Chunk 142 - 50 functions

// ============================================================
// Function: FUN_1801e58dd
// Address: 0x1801e58dd
// Size: 29 bytes
// ============================================================
undefined8 fcn.1801e58dd(int64_t arg_30h, int64_t arg_38h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 *unaff_RSI;
    uint64_t uVar4;
    
    uVar4 = unaff_RSI[0xb8];
    uVar1 = func_0x000180202850();
    if (uVar4 <= uVar1) {
        uVar1 = func_0x000180202870(unaff_RSI[0x79]);
        *(uint32_t *)((int64_t)unaff_RSI + 0x5d4) = *(uint32_t *)((int64_t)unaff_RSI + 0x5d4) & 0xfffffffe;
        iVar3 = -1;
        uVar4 = 0xffffffffffffffff;
        if (uVar1 < 0x5555555555555556) {
            uVar4 = uVar1 * 3;
        }
        iVar2 = func_0x0001801e8e50(*unaff_RSI);
        if (uVar4 <= -iVar2 - 1U) {
            iVar3 = uVar4 + iVar2;
        }
        unaff_RSI[0xb6] = iVar3;
    }
    if ((*(uint8_t *)((int64_t)unaff_RSI + 0x5d4) & 1) == 0) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e58fa
// Address: 0x1801e58fa
// Size: 81 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_30h
// WARNING: Variable defined which should be unmapped: arg_38h

undefined8 fcn.1801e58dd(int64_t arg_30h, int64_t arg_38h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 *unaff_RSI;
    uint64_t uVar4;
    
    uVar4 = unaff_RSI[0xb8];
    uVar1 = func_0x000180202850();
    if (uVar4 <= uVar1) {
        uVar1 = func_0x000180202870(unaff_RSI[0x79]);
        *(uint32_t *)((int64_t)unaff_RSI + 0x5d4) = *(uint32_t *)((int64_t)unaff_RSI + 0x5d4) & 0xfffffffe;
        iVar3 = -1;
        uVar4 = 0xffffffffffffffff;
        if (uVar1 < 0x5555555555555556) {
            uVar4 = uVar1 * 3;
        }
        iVar2 = func_0x0001801e8e50(*unaff_RSI);
        if (uVar4 <= -iVar2 - 1U) {
            iVar3 = uVar4 + iVar2;
        }
        unaff_RSI[0xb6] = iVar3;
    }
    if ((*(uint8_t *)((int64_t)unaff_RSI + 0x5d4) & 1) == 0) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e594b
// Address: 0x1801e594b
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_30h
// WARNING: Variable defined which should be unmapped: arg_38h

undefined8 fcn.1801e58dd(int64_t arg_30h, int64_t arg_38h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 *unaff_RSI;
    uint64_t uVar4;
    
    uVar4 = unaff_RSI[0xb8];
    uVar1 = func_0x000180202850();
    if (uVar4 <= uVar1) {
        uVar1 = func_0x000180202870(unaff_RSI[0x79]);
        *(uint32_t *)((int64_t)unaff_RSI + 0x5d4) = *(uint32_t *)((int64_t)unaff_RSI + 0x5d4) & 0xfffffffe;
        iVar3 = -1;
        uVar4 = 0xffffffffffffffff;
        if (uVar1 < 0x5555555555555556) {
            uVar4 = uVar1 * 3;
        }
        iVar2 = func_0x0001801e8e50(*unaff_RSI);
        if (uVar4 <= -iVar2 - 1U) {
            iVar3 = uVar4 + iVar2;
        }
        unaff_RSI[0xb6] = iVar3;
    }
    if ((*(uint8_t *)((int64_t)unaff_RSI + 0x5d4) & 1) == 0) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e5959
// Address: 0x1801e5959
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_30h
// WARNING: Variable defined which should be unmapped: arg_38h

undefined8 fcn.1801e58dd(int64_t arg_30h, int64_t arg_38h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 *unaff_RSI;
    uint64_t uVar4;
    
    uVar4 = unaff_RSI[0xb8];
    uVar1 = func_0x000180202850();
    if (uVar4 <= uVar1) {
        uVar1 = func_0x000180202870(unaff_RSI[0x79]);
        *(uint32_t *)((int64_t)unaff_RSI + 0x5d4) = *(uint32_t *)((int64_t)unaff_RSI + 0x5d4) & 0xfffffffe;
        iVar3 = -1;
        uVar4 = 0xffffffffffffffff;
        if (uVar1 < 0x5555555555555556) {
            uVar4 = uVar1 * 3;
        }
        iVar2 = func_0x0001801e8e50(*unaff_RSI);
        if (uVar4 <= -iVar2 - 1U) {
            iVar3 = uVar4 + iVar2;
        }
        unaff_RSI[0xb6] = iVar3;
    }
    if ((*(uint8_t *)((int64_t)unaff_RSI + 0x5d4) & 1) == 0) {
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e5a40
// Address: 0x1801e5a40
// Size: 140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801e5a40(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e5a5b;
    iVar2 = func_0x00018045a350();
    if ((*(int64_t *)(in_RCX + 0x50) == 0) && (*(char *)(in_RCX + 0x5b) == '\0')) {
code_r0x0001801e5a86:
        uVar3 = 0;
    } else {
        if (in_RDX != 0) {
            if (*(uint64_t *)(in_RCX + 8) < (uint64_t)(*(int64_t *)(in_RCX + 0x10) + in_RDX)) goto code_r0x0001801e5a86;
            *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801e5a98;
            func_0x0001801e5e20(in_RCX);
            if (*(char *)(in_RCX + 0x5b) == '\0') {
                uVar3 = *(undefined8 *)(in_RCX + 0x28);
                uVar1 = *(undefined8 *)(in_RCX + 0x50);
                *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801e5ab1;
                func_0x0001801e5e20(uVar1, in_RDX, uVar3, in_R8);
            }
        }
        uVar3 = 1;
    }
    return uVar3;
}

// ============================================================
// Function: FUN_1801e5c80
// Address: 0x1801e5c80
// Size: 405 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1801e5c80(int64_t placeholder_0, int64_t arg2, uint64_t placeholder_2, undefined8 placeholder_3,
                  int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    code *pcVar1;
    undefined auVar2 [16];
    undefined auVar3 [16];
    undefined auVar4 [16];
    bool bVar5;
    bool bVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801e5ca7;
    iVar7 = func_0x00018045a350();
    iVar7 = -iVar7;
    uVar13 = *(uint64_t *)(placeholder_0 + 0x28);
    uVar14 = *(int64_t *)(placeholder_0 + 0x10) - *(int64_t *)(placeholder_0 + 0x18);
    if (uVar14 == 0) goto code_r0x0001801e5dcc;
    pcVar1 = *(code **)(placeholder_0 + 0x40);
    uVar9 = *(undefined8 *)(placeholder_0 + 0x48);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801e5ccf;
    uVar8 = (*pcVar1)(uVar9);
    uVar11 = *(uint64_t *)(placeholder_0 + 0x28);
    bVar6 = false;
    bVar5 = false;
    uVar10 = 0xffffffffffffffff;
    uVar12 = 0;
    if (*(uint64_t *)(placeholder_0 + 0x38) <= uVar8) {
        uVar12 = uVar8 - *(int64_t *)(placeholder_0 + 0x38);
    }
    if ((uVar11 == 0) ||
       (auVar2._8_8_ = 0, auVar2._0_8_ = uVar11,
       uVar12 <= SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar2, 0))) {
        uVar14 = (uVar12 * uVar11) / uVar14;
    } else {
        uVar8 = uVar11;
        if (uVar12 < uVar11) {
            uVar8 = uVar12;
            uVar12 = uVar11;
        }
        if ((uVar8 == 0) ||
           (auVar3._8_8_ = 0, auVar3._0_8_ = uVar8,
           uVar12 % uVar14 <= SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar3, 0))) {
            bVar5 = false;
            if (uVar8 != 0) goto code_r0x0001801e5d5a;
        } else {
            bVar6 = true;
code_r0x0001801e5d5a:
            auVar4._8_8_ = 0;
            auVar4._0_8_ = uVar8;
            bVar5 = bVar6;
            if (SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar4, 0) < uVar12 / uVar14) {
                bVar5 = true;
            }
        }
        uVar11 = (uVar12 / uVar14) * uVar8;
        arg2 = *(uint64_t *)((int64_t)&arg_30h + iVar7);
        uVar14 = ((uVar12 % uVar14) * uVar8) / uVar14;
        if (~uVar11 < uVar14) {
            bVar5 = true;
        }
        uVar14 = uVar14 + uVar11;
    }
    uVar11 = 0;
    if (!bVar5) {
        uVar11 = uVar14;
    }
    if (placeholder_2 < 0x4000000000000000) {
        uVar10 = placeholder_2 * 4;
    }
    if (uVar11 < uVar10) {
        uVar13 = uVar13 * 2;
    }
code_r0x0001801e5dcc:
    uVar9 = *(undefined8 *)(placeholder_0 + 0x48);
    if (uVar13 < (uint64_t)arg2) {
        uVar13 = arg2;
    }
    uVar14 = *(uint64_t *)(placeholder_0 + 0x30);
    if (uVar13 <= *(uint64_t *)(placeholder_0 + 0x30)) {
        uVar14 = uVar13;
    }
    *(uint64_t *)(placeholder_0 + 0x28) = uVar14;
    pcVar1 = *(code **)(placeholder_0 + 0x40);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801e5dec;
    uVar9 = (*pcVar1)(uVar9);
    *(undefined8 *)(placeholder_0 + 0x38) = uVar9;
    *(undefined8 *)(placeholder_0 + 0x18) = *(undefined8 *)(placeholder_0 + 0x10);
    return;
}

// ============================================================
// Function: FUN_1801e5e20
// Address: 0x1801e5e20
// Size: 285 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801e5e20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint64_t *in_RCX;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t in_RDX;
    int64_t in_R8;
    uint64_t uVar6;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e5e3e;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    if (in_RCX[7] == 0) {
        pcVar1 = (code *)in_RCX[8];
        uVar3 = in_RCX[9];
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801e5e5e;
        uVar3 = (*pcVar1)(uVar3);
        in_RCX[7] = uVar3;
        in_RCX[3] = in_RCX[2];
    }
    in_RCX[2] = in_RCX[2] + in_RDX;
    uVar3 = in_RCX[5];
    if (uVar3 < 0x5555555555555556) {
        uVar6 = uVar3 * 3 >> 2;
    } else {
        uVar4 = (uint64_t)((uint32_t)uVar3 & 3);
        uVar6 = (uVar3 >> 2) * 3;
        uVar5 = uVar4 * 3 >> 2;
        if ((~uVar6 < uVar5) ||
           (uVar6 = uVar6 + uVar5,
           SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / ZEXT816(3), 0) < uVar3 >> 2 ||
           0x5555555555555555 < uVar4)) {
            uVar6 = uVar3 >> 1;
        }
    }
    if ((*(char *)((int64_t)in_RCX + 0x5a) == '\0') && (*in_RCX - in_RCX[2] <= uVar6)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801e5f08;
        fcn.1801e5c80(in_RCX, in_R8, in_R9, uVar3, *(int64_t *)((int64_t)&var_8h + iVar2), 
                      *(int64_t *)((int64_t)&var_10h + iVar2), *(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2));
        if (*in_RCX < in_RCX[2] + in_RCX[5]) {
            *in_RCX = in_RCX[2] + in_RCX[5];
            *(undefined *)((int64_t)in_RCX + 0x59) = 1;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801e5f40
// Address: 0x1801e5f40
// Size: 81 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801e5f40(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t *piVar2;
    uint64_t uVar3;
    int64_t var_8h;
    
    if (arg3 != 0) {
        piVar2 = (int64_t *)(arg2 + 8);
        uVar3 = 0;
        do {
            iVar1 = *piVar2;
            if (uVar3 < (uint64_t)arg1) {
                if ((uint64_t)arg1 < iVar1 + uVar3) {
                    *piVar2 = arg1 - uVar3;
                }
            } else {
                *piVar2 = 0;
            }
            piVar2 = piVar2 + 2;
            arg3 = arg3 + -1;
            uVar3 = iVar1 + uVar3;
        } while (arg3 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_1801e5fa0
// Address: 0x1801e5fa0
// Size: 102 bytes
// ============================================================
void fcn.1801e5fa0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_d8h, int64_t arg_130h)
{
    uint8_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    undefined8 *puVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint64_t uVar11;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t iVar12;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    int64_t *in_R9;
    int64_t iVar13;
    undefined8 unaff_R15;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 auStackX_20 [2];
    undefined8 uStack_28;
    
    uStack_28 = 0x1801e5fb2;
    iVar10 = func_0x00018045a350();
    iVar10 = -iVar10;
    *(uint64_t *)((int64_t)&arg_48h + iVar10) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar10)
    ;
    uVar5 = *(undefined4 *)in_RCX;
    uVar6 = *(undefined4 *)((int64_t)in_RCX + 4);
    uVar7 = *(undefined4 *)(in_RCX + 1);
    uVar8 = *(undefined4 *)((int64_t)in_RCX + 0xc);
    iVar13 = 0;
    *(int64_t **)((int64_t)auStackX_20 + iVar10 + -0x20) = in_R9;
    uVar1 = *(uint8_t *)(in_RCX + 10);
    *(undefined4 *)((int64_t)&arg_28h + iVar10) = uVar5;
    *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4) = uVar6;
    *(undefined4 *)(&stack0x00000030 + iVar10) = uVar7;
    *(undefined4 *)(&stack0x00000034 + iVar10) = uVar8;
    *(uint64_t *)((int64_t)&var_8h + iVar10) = in_R8;
    uVar5 = *(undefined4 *)(in_RCX + 2);
    uVar6 = *(undefined4 *)((int64_t)in_RCX + 0x14);
    uVar7 = *(undefined4 *)(in_RCX + 3);
    uVar8 = *(undefined4 *)((int64_t)in_RCX + 0x1c);
    *(undefined8 *)((int64_t)&var_10h + iVar10) = 0;
    *(undefined4 *)((int64_t)auStackX_20 + iVar10 + -8) = uVar5;
    *(undefined4 *)((int64_t)auStackX_20 + iVar10 + -4) = uVar6;
    *(undefined4 *)((int64_t)auStackX_20 + iVar10) = uVar7;
    *(undefined4 *)((int64_t)auStackX_20 + iVar10 + 4) = uVar8;
    if (((uVar1 & 1) == 0) && (in_R8 != 0)) {
        *(undefined8 *)((int64_t)&arg_70h + iVar10) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_68h + iVar10) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_60h + iVar10) = unaff_RDI;
        *(undefined8 *)((int64_t)&arg_58h + iVar10) = unaff_R15;
        do {
            iVar13 = *in_RCX;
            iVar12 = 0;
            iVar14 = in_RDX;
            while( true ) {
                uVar2 = in_RCX[2];
                uVar3 = in_RCX[1];
                uVar11 = (uVar3 - uVar2) + in_RCX[3];
                if (in_R8 <= uVar11) {
                    uVar11 = in_R8;
                }
                in_R8 = 0x4000000000000000 - uVar2;
                if (uVar11 <= 0x4000000000000000 - uVar2) {
                    in_R8 = uVar11;
                }
                if (in_R8 == 0) break;
                uVar11 = uVar3 - uVar2 % uVar3;
                if (in_R8 < uVar11) {
                    uVar11 = in_R8;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801e609c;
                func_0x000180498030(uVar2 % uVar3 + iVar13, iVar14, uVar11);
                in_RCX[2] = in_RCX[2] + uVar11;
                iVar14 = iVar14 + uVar11;
                in_R8 = in_R8 - uVar11;
                iVar12 = iVar12 + uVar11;
            }
            iVar13 = *(int64_t *)((int64_t)&var_10h + iVar10);
            if (iVar12 == 0) break;
            in_R8 = *(int64_t *)((int64_t)&var_8h + iVar10) - iVar12;
            iVar13 = iVar13 + iVar12;
            in_RDX = in_RDX + iVar12;
            *(uint64_t *)((int64_t)&var_8h + iVar10) = in_R8;
            *(int64_t *)((int64_t)&var_10h + iVar10) = iVar13;
        } while (in_R8 != 0);
        if (iVar13 != 0) {
            iVar14 = *(int64_t *)((int64_t)auStackX_20 + iVar10 + -8);
            *(int64_t *)((int64_t)&arg_38h + iVar10) = iVar14;
            *(int64_t *)((int64_t)&arg_40h + iVar10) = iVar14 + -1 + iVar13;
            *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801e611b;
            iVar9 = func_0x00018020b010(in_RCX + 4, (int64_t)&arg_38h + iVar10);
            if (iVar9 == 0) {
                uVar5 = *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4);
                uVar6 = *(undefined4 *)(&stack0x00000030 + iVar10);
                uVar7 = *(undefined4 *)(&stack0x00000034 + iVar10);
                puVar4 = *(undefined8 **)((int64_t)auStackX_20 + iVar10 + -0x20);
                *(undefined4 *)in_RCX = *(undefined4 *)((int64_t)&arg_28h + iVar10);
                *(undefined4 *)((int64_t)in_RCX + 4) = uVar5;
                *(undefined4 *)(in_RCX + 1) = uVar6;
                *(undefined4 *)((int64_t)in_RCX + 0xc) = uVar7;
                uVar5 = *(undefined4 *)((int64_t)auStackX_20 + iVar10 + -4);
                uVar6 = *(undefined4 *)((int64_t)auStackX_20 + iVar10);
                uVar7 = *(undefined4 *)((int64_t)auStackX_20 + iVar10 + 4);
                *(undefined4 *)(in_RCX + 2) = *(undefined4 *)((int64_t)auStackX_20 + iVar10 + -8);
                *(undefined4 *)((int64_t)in_RCX + 0x14) = uVar5;
                *(undefined4 *)(in_RCX + 3) = uVar6;
                *(undefined4 *)((int64_t)in_RCX + 0x1c) = uVar7;
                *puVar4 = 0;
                goto code_r0x0001801e614d;
            }
        }
        in_R9 = *(int64_t **)((int64_t)auStackX_20 + iVar10 + -0x20);
    }
    *in_R9 = iVar13;
code_r0x0001801e614d:
    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801e615a;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_48h + iVar10) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar10));
    return;
}

// ============================================================
// Function: FUN_1801e6006
// Address: 0x1801e6006
// Size: 242 bytes
// ============================================================
void fcn.1801e5fa0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_d8h, int64_t arg_130h)
{
    uint8_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    undefined8 *puVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint64_t uVar11;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t iVar12;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    int64_t *in_R9;
    int64_t iVar13;
    undefined8 unaff_R15;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 auStackX_20 [2];
    undefined8 uStack_28;
    
    uStack_28 = 0x1801e5fb2;
    iVar10 = func_0x00018045a350();
    iVar10 = -iVar10;
    *(uint64_t *)((int64_t)&arg_48h + iVar10) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar10)
    ;
    uVar5 = *(undefined4 *)in_RCX;
    uVar6 = *(undefined4 *)((int64_t)in_RCX + 4);
    uVar7 = *(undefined4 *)(in_RCX + 1);
    uVar8 = *(undefined4 *)((int64_t)in_RCX + 0xc);
    iVar13 = 0;
    *(int64_t **)((int64_t)auStackX_20 + iVar10 + -0x20) = in_R9;
    uVar1 = *(uint8_t *)(in_RCX + 10);
    *(undefined4 *)((int64_t)&arg_28h + iVar10) = uVar5;
    *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4) = uVar6;
    *(undefined4 *)(&stack0x00000030 + iVar10) = uVar7;
    *(undefined4 *)(&stack0x00000034 + iVar10) = uVar8;
    *(uint64_t *)((int64_t)&var_8h + iVar10) = in_R8;
    uVar5 = *(undefined4 *)(in_RCX + 2);
    uVar6 = *(undefined4 *)((int64_t)in_RCX + 0x14);
    uVar7 = *(undefined4 *)(in_RCX + 3);
    uVar8 = *(undefined4 *)((int64_t)in_RCX + 0x1c);
    *(undefined8 *)((int64_t)&var_10h + iVar10) = 0;
    *(undefined4 *)((int64_t)auStackX_20 + iVar10 + -8) = uVar5;
    *(undefined4 *)((int64_t)auStackX_20 + iVar10 + -4) = uVar6;
    *(undefined4 *)((int64_t)auStackX_20 + iVar10) = uVar7;
    *(undefined4 *)((int64_t)auStackX_20 + iVar10 + 4) = uVar8;
    if (((uVar1 & 1) == 0) && (in_R8 != 0)) {
        *(undefined8 *)((int64_t)&arg_70h + iVar10) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_68h + iVar10) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_60h + iVar10) = unaff_RDI;
        *(undefined8 *)((int64_t)&arg_58h + iVar10) = unaff_R15;
        do {
            iVar13 = *in_RCX;
            iVar12 = 0;
            iVar14 = in_RDX;
            while( true ) {
                uVar2 = in_RCX[2];
                uVar3 = in_RCX[1];
                uVar11 = (uVar3 - uVar2) + in_RCX[3];
                if (in_R8 <= uVar11) {
                    uVar11 = in_R8;
                }
                in_R8 = 0x4000000000000000 - uVar2;
                if (uVar11 <= 0x4000000000000000 - uVar2) {
                    in_R8 = uVar11;
                }
                if (in_R8 == 0) break;
                uVar11 = uVar3 - uVar2 % uVar3;
                if (in_R8 < uVar11) {
                    uVar11 = in_R8;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801e609c;
                func_0x000180498030(uVar2 % uVar3 + iVar13, iVar14, uVar11);
                in_RCX[2] = in_RCX[2] + uVar11;
                iVar14 = iVar14 + uVar11;
                in_R8 = in_R8 - uVar11;
                iVar12 = iVar12 + uVar11;
            }
            iVar13 = *(int64_t *)((int64_t)&var_10h + iVar10);
            if (iVar12 == 0) break;
            in_R8 = *(int64_t *)((int64_t)&var_8h + iVar10) - iVar12;
            iVar13 = iVar13 + iVar12;
            in_RDX = in_RDX + iVar12;
            *(uint64_t *)((int64_t)&var_8h + iVar10) = in_R8;
            *(int64_t *)((int64_t)&var_10h + iVar10) = iVar13;
        } while (in_R8 != 0);
        if (iVar13 != 0) {
            iVar14 = *(int64_t *)((int64_t)auStackX_20 + iVar10 + -8);
            *(int64_t *)((int64_t)&arg_38h + iVar10) = iVar14;
            *(int64_t *)((int64_t)&arg_40h + iVar10) = iVar14 + -1 + iVar13;
            *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801e611b;
            iVar9 = func_0x00018020b010(in_RCX + 4, (int64_t)&arg_38h + iVar10);
            if (iVar9 == 0) {
                uVar5 = *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4);
                uVar6 = *(undefined4 *)(&stack0x00000030 + iVar10);
                uVar7 = *(undefined4 *)(&stack0x00000034 + iVar10);
                puVar4 = *(undefined8 **)((int64_t)auStackX_20 + iVar10 + -0x20);
                *(undefined4 *)in_RCX = *(undefined4 *)((int64_t)&arg_28h + iVar10);
                *(undefined4 *)((int64_t)in_RCX + 4) = uVar5;
                *(undefined4 *)(in_RCX + 1) = uVar6;
                *(undefined4 *)((int64_t)in_RCX + 0xc) = uVar7;
                uVar5 = *(undefined4 *)((int64_t)auStackX_20 + iVar10 + -4);
                uVar6 = *(undefined4 *)((int64_t)auStackX_20 + iVar10);
                uVar7 = *(undefined4 *)((int64_t)auStackX_20 + iVar10 + 4);
                *(undefined4 *)(in_RCX + 2) = *(undefined4 *)((int64_t)auStackX_20 + iVar10 + -8);
                *(undefined4 *)((int64_t)in_RCX + 0x14) = uVar5;
                *(undefined4 *)(in_RCX + 3) = uVar6;
                *(undefined4 *)((int64_t)in_RCX + 0x1c) = uVar7;
                *puVar4 = 0;
                goto code_r0x0001801e614d;
            }
        }
        in_R9 = *(int64_t **)((int64_t)auStackX_20 + iVar10 + -0x20);
    }
    *in_R9 = iVar13;
code_r0x0001801e614d:
    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801e615a;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_48h + iVar10) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar10));
    return;
}

// ============================================================
// Function: FUN_1801e60f8
// Address: 0x1801e60f8
// Size: 113 bytes
// ============================================================
void fcn.1801e5fa0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_70h, int64_t arg_d8h, int64_t arg_130h)
{
    uint8_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    undefined8 *puVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint64_t uVar11;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t iVar12;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    int64_t *in_R9;
    int64_t iVar13;
    undefined8 unaff_R15;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 auStackX_20 [2];
    undefined8 uStack_28;
    
    uStack_28 = 0x1801e5fb2;
    iVar10 = func_0x00018045a350();
    iVar10 = -iVar10;
    *(uint64_t *)((int64_t)&arg_48h + iVar10) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar10)
    ;
    uVar5 = *(undefined4 *)in_RCX;
    uVar6 = *(undefined4 *)((int64_t)in_RCX + 4);
    uVar7 = *(undefined4 *)(in_RCX + 1);
    uVar8 = *(undefined4 *)((int64_t)in_RCX + 0xc);
    iVar13 = 0;
    *(int64_t **)((int64_t)auStackX_20 + iVar10 + -0x20) = in_R9;
    uVar1 = *(uint8_t *)(in_RCX + 10);
    *(undefined4 *)((int64_t)&arg_28h + iVar10) = uVar5;
    *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4) = uVar6;
    *(undefined4 *)(&stack0x00000030 + iVar10) = uVar7;
    *(undefined4 *)(&stack0x00000034 + iVar10) = uVar8;
    *(uint64_t *)((int64_t)&var_8h + iVar10) = in_R8;
    uVar5 = *(undefined4 *)(in_RCX + 2);
    uVar6 = *(undefined4 *)((int64_t)in_RCX + 0x14);
    uVar7 = *(undefined4 *)(in_RCX + 3);
    uVar8 = *(undefined4 *)((int64_t)in_RCX + 0x1c);
    *(undefined8 *)((int64_t)&var_10h + iVar10) = 0;
    *(undefined4 *)((int64_t)auStackX_20 + iVar10 + -8) = uVar5;
    *(undefined4 *)((int64_t)auStackX_20 + iVar10 + -4) = uVar6;
    *(undefined4 *)((int64_t)auStackX_20 + iVar10) = uVar7;
    *(undefined4 *)((int64_t)auStackX_20 + iVar10 + 4) = uVar8;
    if (((uVar1 & 1) == 0) && (in_R8 != 0)) {
        *(undefined8 *)((int64_t)&arg_70h + iVar10) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_68h + iVar10) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_60h + iVar10) = unaff_RDI;
        *(undefined8 *)((int64_t)&arg_58h + iVar10) = unaff_R15;
        do {
            iVar13 = *in_RCX;
            iVar12 = 0;
            iVar14 = in_RDX;
            while( true ) {
                uVar2 = in_RCX[2];
                uVar3 = in_RCX[1];
                uVar11 = (uVar3 - uVar2) + in_RCX[3];
                if (in_R8 <= uVar11) {
                    uVar11 = in_R8;
                }
                in_R8 = 0x4000000000000000 - uVar2;
                if (uVar11 <= 0x4000000000000000 - uVar2) {
                    in_R8 = uVar11;
                }
                if (in_R8 == 0) break;
                uVar11 = uVar3 - uVar2 % uVar3;
                if (in_R8 < uVar11) {
                    uVar11 = in_R8;
                }
                *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801e609c;
                func_0x000180498030(uVar2 % uVar3 + iVar13, iVar14, uVar11);
                in_RCX[2] = in_RCX[2] + uVar11;
                iVar14 = iVar14 + uVar11;
                in_R8 = in_R8 - uVar11;
                iVar12 = iVar12 + uVar11;
            }
            iVar13 = *(int64_t *)((int64_t)&var_10h + iVar10);
            if (iVar12 == 0) break;
            in_R8 = *(int64_t *)((int64_t)&var_8h + iVar10) - iVar12;
            iVar13 = iVar13 + iVar12;
            in_RDX = in_RDX + iVar12;
            *(uint64_t *)((int64_t)&var_8h + iVar10) = in_R8;
            *(int64_t *)((int64_t)&var_10h + iVar10) = iVar13;
        } while (in_R8 != 0);
        if (iVar13 != 0) {
            iVar14 = *(int64_t *)((int64_t)auStackX_20 + iVar10 + -8);
            *(int64_t *)((int64_t)&arg_38h + iVar10) = iVar14;
            *(int64_t *)((int64_t)&arg_40h + iVar10) = iVar14 + -1 + iVar13;
            *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801e611b;
            iVar9 = func_0x00018020b010(in_RCX + 4, (int64_t)&arg_38h + iVar10);
            if (iVar9 == 0) {
                uVar5 = *(undefined4 *)((int64_t)&arg_28h + iVar10 + 4);
                uVar6 = *(undefined4 *)(&stack0x00000030 + iVar10);
                uVar7 = *(undefined4 *)(&stack0x00000034 + iVar10);
                puVar4 = *(undefined8 **)((int64_t)auStackX_20 + iVar10 + -0x20);
                *(undefined4 *)in_RCX = *(undefined4 *)((int64_t)&arg_28h + iVar10);
                *(undefined4 *)((int64_t)in_RCX + 4) = uVar5;
                *(undefined4 *)(in_RCX + 1) = uVar6;
                *(undefined4 *)((int64_t)in_RCX + 0xc) = uVar7;
                uVar5 = *(undefined4 *)((int64_t)auStackX_20 + iVar10 + -4);
                uVar6 = *(undefined4 *)((int64_t)auStackX_20 + iVar10);
                uVar7 = *(undefined4 *)((int64_t)auStackX_20 + iVar10 + 4);
                *(undefined4 *)(in_RCX + 2) = *(undefined4 *)((int64_t)auStackX_20 + iVar10 + -8);
                *(undefined4 *)((int64_t)in_RCX + 0x14) = uVar5;
                *(undefined4 *)(in_RCX + 3) = uVar6;
                *(undefined4 *)((int64_t)in_RCX + 0x1c) = uVar7;
                *puVar4 = 0;
                goto code_r0x0001801e614d;
            }
        }
        in_R9 = *(int64_t **)((int64_t)auStackX_20 + iVar10 + -0x20);
    }
    *in_R9 = iVar13;
code_r0x0001801e614d:
    *(undefined8 *)((int64_t)&uStack_28 + iVar10) = 0x1801e615a;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_48h + iVar10) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar10));
    return;
}

// ============================================================
// Function: FUN_1801e6180
// Address: 0x1801e6180
// Size: 126 bytes
// ============================================================
void fcn.1801e6180(int64_t arg1)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801e6190;
        iVar4 = func_0x00018045a350();
        iVar3 = -iVar4;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e619e;
        func_0x00018020afb0(arg1 + iVar4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e61a7;
        func_0x00018020afb0((undefined8 *)(arg1 + 0x38));
        uVar1 = *(undefined8 *)arg1;
        if ((*(uint8_t *)(arg1 + 0x50) & 8) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e61da;
            func_0x000180224990(uVar1, 0x1804b7430, 0x3c);
        } else {
            uVar2 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e61c6;
            func_0x000180224b90(uVar1, uVar2, 0x1804b7430, 0x3a);
        }
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e61f8;
        func_0x000180224990(arg1, 0x1804b7488, 0x58);
    }
    return;
}

// ============================================================
// Function: FUN_1801e6230
// Address: 0x1801e6230
// Size: 348 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801e6230(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    undefined8 uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint32_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    undefined8 *puVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar11 = 0;
    puVar10 = *(undefined8 **)(arg1 + 0x20);
    uVar6 = 0;
    if (1 < *(uint64_t *)arg_28h) {
        uVar4 = uVar11;
        if (arg2 != 0) {
            do {
                if (puVar10 == (undefined8 *)0x0) {
                    return 0;
                }
                puVar10 = (undefined8 *)*puVar10;
                uVar4 = uVar4 + 1;
            } while (uVar4 < (uint64_t)arg2);
        }
        if (puVar10 != (undefined8 *)0x0) {
            uVar9 = (puVar10[3] - puVar10[2]) + 1;
            uVar4 = uVar11;
            if (uVar9 != 0) {
                do {
                    uVar5 = puVar10[2] + uVar11;
                    if (*(uint64_t *)(arg1 + 0x10) < uVar5) {
                        return 0;
                    }
                    if (uVar5 < *(uint64_t *)(arg1 + 0x18)) {
                        return 0;
                    }
                    uVar2 = *(uint64_t *)(arg1 + 8);
                    if (uVar2 == 0) break;
                    uVar7 = *(uint64_t *)(arg1 + 0x10) - uVar5;
                    uVar8 = uVar2 - uVar5 % uVar2;
                    if (uVar7 <= uVar8) {
                        uVar8 = uVar7;
                    }
                    if (uVar8 == 0) break;
                    *(uint64_t *)arg4 = uVar5 % uVar2 + *(int64_t *)arg1;
                    uVar5 = uVar9 - uVar11;
                    if (uVar8 + uVar11 <= uVar9) {
                        uVar5 = uVar8;
                    }
                    uVar4 = uVar4 + 1;
                    *(uint64_t *)(arg4 + 8) = uVar5;
                    uVar11 = uVar11 + uVar5;
                    arg4 = arg4 + 0x10;
                } while (uVar11 < uVar9);
            }
            iVar3 = puVar10[2];
            *(int64_t *)(arg3 + 8) = iVar3;
            *(uint64_t *)(arg3 + 0x10) = uVar11;
            if (((*(uint8_t *)(arg1 + 0x50) & 1) != 0) && (iVar3 + uVar11 == *(int64_t *)(arg1 + 0x10))) {
                uVar6 = 2;
            }
            *(uint32_t *)(arg3 + 0x20) = *(uint32_t *)(arg3 + 0x20) & 0xfffffffd;
            *(uint32_t *)(arg3 + 0x20) = *(uint32_t *)(arg3 + 0x20) | uVar6;
            *(uint64_t *)arg_28h = uVar4;
            return 1;
        }
        if (((uint64_t)arg2 <= uVar4) && (((uint8_t)*(undefined4 *)(arg1 + 0x50) & 3) == 1)) {
            uVar1 = *(undefined8 *)(arg1 + 0x10);
            *(uint32_t *)(arg3 + 0x20) = *(uint32_t *)(arg3 + 0x20) | 2;
            *(undefined8 *)(arg3 + 8) = uVar1;
            *(undefined8 *)(arg3 + 0x10) = 0;
            *(undefined8 *)arg_28h = 0;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e6390
// Address: 0x1801e6390
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1801e6390(int64_t arg1)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg1 + 0x20);
    uVar5 = 0;
    if (iVar1 == 0) {
        return (*(uint8_t *)(arg1 + 0x50) & 3) == 1;
    }
    uVar6 = (*(int64_t *)(iVar1 + 0x18) - *(int64_t *)(iVar1 + 0x10)) + 1;
    if (uVar6 != 0) {
        do {
            uVar3 = *(int64_t *)(iVar1 + 0x10) + uVar5;
            if ((*(uint64_t *)(arg1 + 0x10) < uVar3) || (uVar3 < *(uint64_t *)(arg1 + 0x18))) {
                return false;
            }
            uVar2 = *(uint64_t *)(arg1 + 8);
            if (uVar2 == 0) {
                return true;
            }
            uVar4 = *(uint64_t *)(arg1 + 0x10) - uVar3;
            uVar2 = uVar2 - uVar3 % uVar2;
            if (uVar4 <= uVar2) {
                uVar2 = uVar4;
            }
            if (uVar2 == 0) {
                return true;
            }
            uVar3 = uVar6 - uVar5;
            if (uVar2 + uVar5 <= uVar6) {
                uVar3 = uVar2;
            }
            uVar5 = uVar5 + uVar3;
        } while (uVar5 < uVar6);
    }
    return true;
}

// ============================================================
// Function: FUN_1801e63b5
// Address: 0x1801e63b5
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1801e6390(int64_t arg1)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg1 + 0x20);
    uVar5 = 0;
    if (iVar1 == 0) {
        return (*(uint8_t *)(arg1 + 0x50) & 3) == 1;
    }
    uVar6 = (*(int64_t *)(iVar1 + 0x18) - *(int64_t *)(iVar1 + 0x10)) + 1;
    if (uVar6 != 0) {
        do {
            uVar3 = *(int64_t *)(iVar1 + 0x10) + uVar5;
            if ((*(uint64_t *)(arg1 + 0x10) < uVar3) || (uVar3 < *(uint64_t *)(arg1 + 0x18))) {
                return false;
            }
            uVar2 = *(uint64_t *)(arg1 + 8);
            if (uVar2 == 0) {
                return true;
            }
            uVar4 = *(uint64_t *)(arg1 + 0x10) - uVar3;
            uVar2 = uVar2 - uVar3 % uVar2;
            if (uVar4 <= uVar2) {
                uVar2 = uVar4;
            }
            if (uVar2 == 0) {
                return true;
            }
            uVar3 = uVar6 - uVar5;
            if (uVar2 + uVar5 <= uVar6) {
                uVar3 = uVar2;
            }
            uVar5 = uVar5 + uVar3;
        } while (uVar5 < uVar6);
    }
    return true;
}

// ============================================================
// Function: FUN_1801e6430
// Address: 0x1801e6430
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1801e6390(int64_t arg1)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)(arg1 + 0x20);
    uVar5 = 0;
    if (iVar1 == 0) {
        return (*(uint8_t *)(arg1 + 0x50) & 3) == 1;
    }
    uVar6 = (*(int64_t *)(iVar1 + 0x18) - *(int64_t *)(iVar1 + 0x10)) + 1;
    if (uVar6 != 0) {
        do {
            uVar3 = *(int64_t *)(iVar1 + 0x10) + uVar5;
            if ((*(uint64_t *)(arg1 + 0x10) < uVar3) || (uVar3 < *(uint64_t *)(arg1 + 0x18))) {
                return false;
            }
            uVar2 = *(uint64_t *)(arg1 + 8);
            if (uVar2 == 0) {
                return true;
            }
            uVar4 = *(uint64_t *)(arg1 + 0x10) - uVar3;
            uVar2 = uVar2 - uVar3 % uVar2;
            if (uVar4 <= uVar2) {
                uVar2 = uVar4;
            }
            if (uVar2 == 0) {
                return true;
            }
            uVar3 = uVar6 - uVar5;
            if (uVar2 + uVar5 <= uVar6) {
                uVar3 = uVar2;
            }
            uVar5 = uVar5 + uVar3;
        } while (uVar5 < uVar6);
    }
    return true;
}

// ============================================================
// Function: FUN_1801e6480
// Address: 0x1801e6480
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_fh

void fcn.1801e6480(int64_t arg_30h, int64_t arg_68h)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 in_RDX;
    uint64_t uVar7;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar8;
    undefined8 in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    undefined uStack_10;
    int64_t var_fh;
    
    uStack_18 = 0x1801e648d;
    iVar6 = func_0x00018045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&var_20h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&uStack_10 + iVar6);
    *(undefined8 *)((int64_t)&var_10h + iVar6) = in_RDX;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = in_R8;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e64ba;
    iVar5 = func_0x00018020b010(in_RCX + 7);
    if ((iVar5 != 0) && (iVar1 = in_RCX[7], iVar1 != 0)) {
        uVar2 = in_RCX[3];
        *(undefined8 *)((int64_t)&arg_68h + iVar6) = unaff_RBP;
        uVar3 = *(uint64_t *)(iVar1 + 0x18);
        if ((*(uint64_t *)(iVar1 + 0x10) <= uVar2) && (uVar3 < 0x4000000000000000)) {
            if ((((*(uint8_t *)(in_RCX + 10) & 8) != 0) && (uVar4 = in_RCX[1], uVar4 != 0)) && (uVar2 < uVar3)) {
                uVar8 = in_RCX[2];
                *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
                uVar7 = uVar2 % uVar4;
                if (uVar3 + 1 <= uVar8) {
                    uVar8 = uVar3 + 1;
                }
                uVar8 = uVar8 - uVar2;
                if (uVar4 - uVar7 < uVar8) {
                    iVar1 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e6541;
                    func_0x000180244fc0(iVar1 + uVar7, uVar4 - uVar7);
                    uVar8 = uVar8 + (uVar7 - in_RCX[1]);
                    uVar7 = 0;
                }
                if (uVar8 != 0) {
                    iVar1 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e655d;
                    func_0x000180244fc0(iVar1 + uVar7, uVar8);
                }
            }
            uVar3 = uVar3 + 1;
            in_RCX[3] = uVar3;
            if ((uint64_t)in_RCX[2] < uVar3) {
                in_RCX[2] = uVar3;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e658b;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_20h + iVar6) ^ (uint64_t)(&uStack_10 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801e64d3
// Address: 0x1801e64d3
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_fh

void fcn.1801e6480(int64_t arg_30h, int64_t arg_68h)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 in_RDX;
    uint64_t uVar7;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar8;
    undefined8 in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    undefined uStack_10;
    int64_t var_fh;
    
    uStack_18 = 0x1801e648d;
    iVar6 = func_0x00018045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&var_20h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&uStack_10 + iVar6);
    *(undefined8 *)((int64_t)&var_10h + iVar6) = in_RDX;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = in_R8;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e64ba;
    iVar5 = func_0x00018020b010(in_RCX + 7);
    if ((iVar5 != 0) && (iVar1 = in_RCX[7], iVar1 != 0)) {
        uVar2 = in_RCX[3];
        *(undefined8 *)((int64_t)&arg_68h + iVar6) = unaff_RBP;
        uVar3 = *(uint64_t *)(iVar1 + 0x18);
        if ((*(uint64_t *)(iVar1 + 0x10) <= uVar2) && (uVar3 < 0x4000000000000000)) {
            if ((((*(uint8_t *)(in_RCX + 10) & 8) != 0) && (uVar4 = in_RCX[1], uVar4 != 0)) && (uVar2 < uVar3)) {
                uVar8 = in_RCX[2];
                *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
                uVar7 = uVar2 % uVar4;
                if (uVar3 + 1 <= uVar8) {
                    uVar8 = uVar3 + 1;
                }
                uVar8 = uVar8 - uVar2;
                if (uVar4 - uVar7 < uVar8) {
                    iVar1 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e6541;
                    func_0x000180244fc0(iVar1 + uVar7, uVar4 - uVar7);
                    uVar8 = uVar8 + (uVar7 - in_RCX[1]);
                    uVar7 = 0;
                }
                if (uVar8 != 0) {
                    iVar1 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e655d;
                    func_0x000180244fc0(iVar1 + uVar7, uVar8);
                }
            }
            uVar3 = uVar3 + 1;
            in_RCX[3] = uVar3;
            if ((uint64_t)in_RCX[2] < uVar3) {
                in_RCX[2] = uVar3;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e658b;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_20h + iVar6) ^ (uint64_t)(&uStack_10 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801e6512
// Address: 0x1801e6512
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_fh

void fcn.1801e6480(int64_t arg_30h, int64_t arg_68h)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 in_RDX;
    uint64_t uVar7;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar8;
    undefined8 in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    undefined uStack_10;
    int64_t var_fh;
    
    uStack_18 = 0x1801e648d;
    iVar6 = func_0x00018045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&var_20h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&uStack_10 + iVar6);
    *(undefined8 *)((int64_t)&var_10h + iVar6) = in_RDX;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = in_R8;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e64ba;
    iVar5 = func_0x00018020b010(in_RCX + 7);
    if ((iVar5 != 0) && (iVar1 = in_RCX[7], iVar1 != 0)) {
        uVar2 = in_RCX[3];
        *(undefined8 *)((int64_t)&arg_68h + iVar6) = unaff_RBP;
        uVar3 = *(uint64_t *)(iVar1 + 0x18);
        if ((*(uint64_t *)(iVar1 + 0x10) <= uVar2) && (uVar3 < 0x4000000000000000)) {
            if ((((*(uint8_t *)(in_RCX + 10) & 8) != 0) && (uVar4 = in_RCX[1], uVar4 != 0)) && (uVar2 < uVar3)) {
                uVar8 = in_RCX[2];
                *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
                uVar7 = uVar2 % uVar4;
                if (uVar3 + 1 <= uVar8) {
                    uVar8 = uVar3 + 1;
                }
                uVar8 = uVar8 - uVar2;
                if (uVar4 - uVar7 < uVar8) {
                    iVar1 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e6541;
                    func_0x000180244fc0(iVar1 + uVar7, uVar4 - uVar7);
                    uVar8 = uVar8 + (uVar7 - in_RCX[1]);
                    uVar7 = 0;
                }
                if (uVar8 != 0) {
                    iVar1 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e655d;
                    func_0x000180244fc0(iVar1 + uVar7, uVar8);
                }
            }
            uVar3 = uVar3 + 1;
            in_RCX[3] = uVar3;
            if ((uint64_t)in_RCX[2] < uVar3) {
                in_RCX[2] = uVar3;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e658b;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_20h + iVar6) ^ (uint64_t)(&uStack_10 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801e6562
// Address: 0x1801e6562
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_fh

void fcn.1801e6480(int64_t arg_30h, int64_t arg_68h)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 in_RDX;
    uint64_t uVar7;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar8;
    undefined8 in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    undefined uStack_10;
    int64_t var_fh;
    
    uStack_18 = 0x1801e648d;
    iVar6 = func_0x00018045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&var_20h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&uStack_10 + iVar6);
    *(undefined8 *)((int64_t)&var_10h + iVar6) = in_RDX;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = in_R8;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e64ba;
    iVar5 = func_0x00018020b010(in_RCX + 7);
    if ((iVar5 != 0) && (iVar1 = in_RCX[7], iVar1 != 0)) {
        uVar2 = in_RCX[3];
        *(undefined8 *)((int64_t)&arg_68h + iVar6) = unaff_RBP;
        uVar3 = *(uint64_t *)(iVar1 + 0x18);
        if ((*(uint64_t *)(iVar1 + 0x10) <= uVar2) && (uVar3 < 0x4000000000000000)) {
            if ((((*(uint8_t *)(in_RCX + 10) & 8) != 0) && (uVar4 = in_RCX[1], uVar4 != 0)) && (uVar2 < uVar3)) {
                uVar8 = in_RCX[2];
                *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
                uVar7 = uVar2 % uVar4;
                if (uVar3 + 1 <= uVar8) {
                    uVar8 = uVar3 + 1;
                }
                uVar8 = uVar8 - uVar2;
                if (uVar4 - uVar7 < uVar8) {
                    iVar1 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e6541;
                    func_0x000180244fc0(iVar1 + uVar7, uVar4 - uVar7);
                    uVar8 = uVar8 + (uVar7 - in_RCX[1]);
                    uVar7 = 0;
                }
                if (uVar8 != 0) {
                    iVar1 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e655d;
                    func_0x000180244fc0(iVar1 + uVar7, uVar8);
                }
            }
            uVar3 = uVar3 + 1;
            in_RCX[3] = uVar3;
            if ((uint64_t)in_RCX[2] < uVar3) {
                in_RCX[2] = uVar3;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e658b;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_20h + iVar6) ^ (uint64_t)(&uStack_10 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801e6579
// Address: 0x1801e6579
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_fh

void fcn.1801e6480(int64_t arg_30h, int64_t arg_68h)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    undefined8 in_RDX;
    uint64_t uVar7;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar8;
    undefined8 in_R8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    undefined uStack_10;
    int64_t var_fh;
    
    uStack_18 = 0x1801e648d;
    iVar6 = func_0x00018045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&var_20h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&uStack_10 + iVar6);
    *(undefined8 *)((int64_t)&var_10h + iVar6) = in_RDX;
    *(undefined8 *)((int64_t)&var_18h + iVar6) = in_R8;
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e64ba;
    iVar5 = func_0x00018020b010(in_RCX + 7);
    if ((iVar5 != 0) && (iVar1 = in_RCX[7], iVar1 != 0)) {
        uVar2 = in_RCX[3];
        *(undefined8 *)((int64_t)&arg_68h + iVar6) = unaff_RBP;
        uVar3 = *(uint64_t *)(iVar1 + 0x18);
        if ((*(uint64_t *)(iVar1 + 0x10) <= uVar2) && (uVar3 < 0x4000000000000000)) {
            if ((((*(uint8_t *)(in_RCX + 10) & 8) != 0) && (uVar4 = in_RCX[1], uVar4 != 0)) && (uVar2 < uVar3)) {
                uVar8 = in_RCX[2];
                *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RSI;
                uVar7 = uVar2 % uVar4;
                if (uVar3 + 1 <= uVar8) {
                    uVar8 = uVar3 + 1;
                }
                uVar8 = uVar8 - uVar2;
                if (uVar4 - uVar7 < uVar8) {
                    iVar1 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e6541;
                    func_0x000180244fc0(iVar1 + uVar7, uVar4 - uVar7);
                    uVar8 = uVar8 + (uVar7 - in_RCX[1]);
                    uVar7 = 0;
                }
                if (uVar8 != 0) {
                    iVar1 = *in_RCX;
                    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e655d;
                    func_0x000180244fc0(iVar1 + uVar7, uVar8);
                }
            }
            uVar3 = uVar3 + 1;
            in_RCX[3] = uVar3;
            if ((uint64_t)in_RCX[2] < uVar3) {
                in_RCX[2] = uVar3;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801e658b;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_20h + iVar6) ^ (uint64_t)(&uStack_10 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801e65c0
// Address: 0x1801e65c0
// Size: 79 bytes
// ============================================================
void fcn.1801e65c0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    undefined8 in_RDX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801e65ca;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(uint64_t *)((int64_t)&arg_30h + iVar1) = *(uint64_t *)0x1806a3940 ^ (int64_t)&stack0x00000000 + iVar1;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = in_R8;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801e65f4;
    fcn.18020b010(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801e660a;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_30h + iVar1) ^ (int64_t)&stack0x00000000 + iVar1);
    return;
}

// ============================================================
// Function: FUN_1801e6630
// Address: 0x1801e6630
// Size: 79 bytes
// ============================================================
void fcn.1801e6630(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    undefined8 in_RDX;
    undefined8 in_R8;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801e663a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(uint64_t *)((int64_t)&arg_30h + iVar1) = *(uint64_t *)0x1806a3940 ^ (int64_t)&stack0x00000000 + iVar1;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = in_R8;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801e6664;
    fcn.18020b3b0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000058 + iVar1));
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801e667a;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_30h + iVar1) ^ (int64_t)&stack0x00000000 + iVar1);
    return;
}

// ============================================================
// Function: FUN_1801e66a0
// Address: 0x1801e66a0
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.1801e66a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e66b0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e66cd;
    puVar4 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    if (puVar4 == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    *puVar4 = 0;
    puVar4[1] = 0;
    puVar4[3] = 0;
    puVar4[2] = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6704;
    iVar2 = fcn.1801e68e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
    if (iVar2 == 0) {
        uVar1 = *puVar4;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e671d;
        fcn.180224990(uVar1, 0x1804b7430, 0x3c);
        *puVar4 = 0;
        puVar4[1] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6739;
        fcn.180224990(puVar4, 0x1804b7488, 0x47);
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6754;
    fcn.18020b000(puVar4 + 4);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e675d;
    fcn.18020b000(puVar4 + 7);
    return puVar4;
}

// ============================================================
// Function: FUN_1801e66e0
// Address: 0x1801e66e0
// Size: 107 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.1801e66a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e66b0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e66cd;
    puVar4 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    if (puVar4 == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    *puVar4 = 0;
    puVar4[1] = 0;
    puVar4[3] = 0;
    puVar4[2] = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6704;
    iVar2 = fcn.1801e68e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
    if (iVar2 == 0) {
        uVar1 = *puVar4;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e671d;
        fcn.180224990(uVar1, 0x1804b7430, 0x3c);
        *puVar4 = 0;
        puVar4[1] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6739;
        fcn.180224990(puVar4, 0x1804b7488, 0x47);
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6754;
    fcn.18020b000(puVar4 + 4);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e675d;
    fcn.18020b000(puVar4 + 7);
    return puVar4;
}

// ============================================================
// Function: FUN_1801e674b
// Address: 0x1801e674b
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.1801e66a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e66b0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e66cd;
    puVar4 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    if (puVar4 == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    *puVar4 = 0;
    puVar4[1] = 0;
    puVar4[3] = 0;
    puVar4[2] = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6704;
    iVar2 = fcn.1801e68e0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
    if (iVar2 == 0) {
        uVar1 = *puVar4;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e671d;
        fcn.180224990(uVar1, 0x1804b7430, 0x3c);
        *puVar4 = 0;
        puVar4[1] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6739;
        fcn.180224990(puVar4, 0x1804b7488, 0x47);
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6754;
    fcn.18020b000(puVar4 + 4);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e675d;
    fcn.18020b000(puVar4 + 7);
    return puVar4;
}

// ============================================================
// Function: FUN_1801e6770
// Address: 0x1801e6770
// Size: 34 bytes
// ============================================================
undefined8 fcn.1801e6770(int64_t *param_1, uint64_t param_2)
{
    uint64_t uVar1;
    uint64_t uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    uint64_t uVar13;
    undefined8 unaff_RBX;
    uint64_t uVar14;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar15;
    undefined8 unaff_RDI;
    uint64_t uVar16;
    undefined8 uVar17;
    uint64_t uVar18;
    undefined8 auStackX_18 [2];
    
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    uVar16 = (uint64_t)(*(uint32_t *)(param_1 + 10) >> 3 & 1);
    *(undefined8 *)(&stack0x00000030 + iVar10) = unaff_RBX;
    *(undefined8 *)(&stack0x00000038 + iVar10) = unaff_RBP;
    *(undefined8 *)(&stack0x00000040 + iVar10) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar10 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar10) = 0x1801e68fa;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    iVar15 = 0;
    *(undefined8 *)(&stack0x00000050 + iVar11 + iVar10) = 0;
    if (param_2 == param_1[1]) {
code_r0x0001801e69db:
        uVar17 = 1;
    } else {
        if ((uint64_t)(param_1[2] - param_1[3]) <= param_2) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar11 + iVar10) = 0x1801e693d;
            iVar12 = fcn.1802248d0(*(int64_t *)(&stack0x00000040 + iVar11 + iVar10), 
                                   *(int64_t *)(&stack0x00000048 + iVar11 + iVar10));
            *(int64_t *)(&stack0x00000040 + iVar11 + iVar10) = iVar12;
            if (iVar12 != 0) {
                iVar12 = param_1[3];
                *(int64_t *)(&stack0x00000050 + iVar11 + iVar10) = iVar12;
                *(int64_t *)(&stack0x00000058 + iVar11 + iVar10) = iVar12;
                *(uint64_t *)(&stack0x00000048 + iVar11 + iVar10) = param_2;
                while( true ) {
                    uVar1 = param_1[3];
                    uVar13 = uVar1 + iVar15;
                    if (((uint64_t)param_1[2] < uVar13) || (uVar13 < uVar1)) break;
                    uVar2 = param_1[1];
                    if (uVar2 == 0) {
code_r0x0001801e69bb:
                        *(uint64_t *)(&stack0x00000058 + iVar11 + iVar10) = uVar1;
                        *(undefined8 *)((int64_t)auStackX_18 + iVar11 + iVar10) = 0x1801e69ca;
                        func_0x0001801e67c0(param_1, uVar16 & 0xffffffff);
                        uVar3 = *(undefined4 *)(&stack0x00000044 + iVar11 + iVar10);
                        uVar4 = *(undefined4 *)(&stack0x00000048 + iVar11 + iVar10);
                        uVar5 = *(undefined4 *)(&stack0x0000004c + iVar11 + iVar10);
                        uVar6 = *(undefined4 *)(&stack0x00000050 + iVar11 + iVar10);
                        uVar7 = *(undefined4 *)(&stack0x00000054 + iVar11 + iVar10);
                        uVar8 = *(undefined4 *)(&stack0x00000058 + iVar11 + iVar10);
                        uVar9 = *(undefined4 *)(&stack0x0000005c + iVar11 + iVar10);
                        *(undefined4 *)param_1 = *(undefined4 *)(&stack0x00000040 + iVar11 + iVar10);
                        *(undefined4 *)((int64_t)param_1 + 4) = uVar3;
                        *(undefined4 *)(param_1 + 1) = uVar4;
                        *(undefined4 *)((int64_t)param_1 + 0xc) = uVar5;
                        *(undefined4 *)(param_1 + 2) = uVar6;
                        *(undefined4 *)((int64_t)param_1 + 0x14) = uVar7;
                        *(undefined4 *)(param_1 + 3) = uVar8;
                        *(undefined4 *)((int64_t)param_1 + 0x1c) = uVar9;
                        goto code_r0x0001801e69db;
                    }
                    uVar18 = param_1[2] - uVar13;
                    uVar14 = uVar2 - uVar13 % uVar2;
                    iVar12 = *param_1;
                    if (uVar18 <= uVar14) {
                        uVar14 = uVar18;
                    }
                    if (uVar14 == 0) goto code_r0x0001801e69bb;
                    *(undefined8 *)((int64_t)auStackX_18 + iVar11 + iVar10) = 0x1801e69a9;
                    uVar13 = func_0x0001801e6820(&stack0x00000040 + iVar11 + iVar10, uVar13 % uVar2 + iVar12, uVar14);
                    if (uVar13 != uVar14) {
                        uVar17 = 0x106;
                        goto code_r0x0001801e69e8;
                    }
                    iVar15 = iVar15 + uVar14;
                }
                uVar17 = 0xfe;
code_r0x0001801e69e8:
                *(undefined8 *)((int64_t)auStackX_18 + iVar11 + iVar10) = 0x1801e69f9;
                fcn.180224990(*(undefined8 *)(&stack0x00000040 + iVar11 + iVar10), 0x1804b7430, uVar17);
            }
        }
        uVar17 = 0;
    }
    return uVar17;
}

// ============================================================
// Function: FUN_1801e67c0
// Address: 0x1801e67c0
// Size: 95 bytes
// ============================================================
void fcn.1801e67c0(undefined8 *param_1, int32_t param_2)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e67cc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar1 = *param_1;
    if (param_2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e67ef;
        fcn.180224b90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        param_1[1] = 0;
        *param_1 = 0;
        return;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e6810;
    fcn.180224990(uVar1, 0x1804b7430, 0x3c);
    param_1[1] = 0;
    *param_1 = 0;
    return;
}

// ============================================================
// Function: FUN_1801e6820
// Address: 0x1801e6820
// Size: 189 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1801e6820(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e6844;
    iVar4 = fcn.18045a350();
    iVar1 = *in_RCX;
    iVar6 = 0;
    while( true ) {
        uVar2 = in_RCX[2];
        uVar3 = in_RCX[1];
        uVar5 = (uVar3 - uVar2) + in_RCX[3];
        if (in_R8 <= uVar5) {
            uVar5 = in_R8;
        }
        in_R8 = 0x4000000000000000 - uVar2;
        if (uVar5 <= 0x4000000000000000 - uVar2) {
            in_R8 = uVar5;
        }
        if (in_R8 == 0) break;
        uVar5 = uVar3 - uVar2 % uVar3;
        if (in_R8 < uVar5) {
            uVar5 = in_R8;
        }
        *(undefined8 *)((int64_t)&uStack_20 - iVar4) = 0x1801e68ac;
        func_0x000180498030(uVar2 % uVar3 + iVar1, in_RDX, uVar5);
        in_RCX[2] = in_RCX[2] + uVar5;
        in_RDX = in_RDX + uVar5;
        in_R8 = in_R8 - uVar5;
        iVar6 = iVar6 + uVar5;
    }
    return iVar6;
}

// ============================================================
// Function: FUN_1801e68e0
// Address: 0x1801e68e0
// Size: 304 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801e68e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    uint64_t uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint64_t uVar11;
    undefined4 *in_RCX;
    uint64_t in_RDX;
    uint64_t uVar12;
    int64_t iVar13;
    uint64_t in_R8;
    undefined8 uVar14;
    uint64_t uVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e68fa;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    iVar13 = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar9) = 0;
    if (in_RDX == *(uint64_t *)(in_RCX + 2)) {
code_r0x0001801e69db:
        uVar14 = 1;
    } else {
        if ((uint64_t)(*(int64_t *)(in_RCX + 4) - *(int64_t *)(in_RCX + 6)) <= in_RDX) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801e693d;
            iVar10 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar9), *(int64_t *)((int64_t)&var_20h + iVar9));
            *(int64_t *)((int64_t)&var_18h + iVar9) = iVar10;
            if (iVar10 != 0) {
                uVar14 = *(undefined8 *)(in_RCX + 6);
                *(undefined8 *)((int64_t)&arg_28h + iVar9) = uVar14;
                *(undefined8 *)((int64_t)&arg_30h + iVar9) = uVar14;
                *(uint64_t *)((int64_t)&var_20h + iVar9) = in_RDX;
                while( true ) {
                    uVar1 = *(uint64_t *)(in_RCX + 6);
                    uVar11 = uVar1 + iVar13;
                    if ((*(uint64_t *)(in_RCX + 4) < uVar11) || (uVar11 < uVar1)) break;
                    uVar12 = *(uint64_t *)(in_RCX + 2);
                    if (uVar12 == 0) {
code_r0x0001801e69bb:
                        *(uint64_t *)((int64_t)&arg_30h + iVar9) = uVar1;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801e69ca;
                        fcn.1801e67c0(in_RCX, in_R8 & 0xffffffff);
                        uVar2 = *(undefined4 *)((int64_t)&var_18h + iVar9 + 4);
                        uVar3 = *(undefined4 *)((int64_t)&var_20h + iVar9);
                        uVar4 = *(undefined4 *)((int64_t)&var_20h + iVar9 + 4);
                        uVar5 = *(undefined4 *)((int64_t)&arg_28h + iVar9);
                        uVar6 = *(undefined4 *)((int64_t)&arg_28h + iVar9 + 4);
                        uVar7 = *(undefined4 *)((int64_t)&arg_30h + iVar9);
                        uVar8 = *(undefined4 *)((int64_t)&arg_30h + iVar9 + 4);
                        *in_RCX = *(undefined4 *)((int64_t)&var_18h + iVar9);
                        in_RCX[1] = uVar2;
                        in_RCX[2] = uVar3;
                        in_RCX[3] = uVar4;
                        in_RCX[4] = uVar5;
                        in_RCX[5] = uVar6;
                        in_RCX[6] = uVar7;
                        in_RCX[7] = uVar8;
                        goto code_r0x0001801e69db;
                    }
                    uVar15 = *(uint64_t *)(in_RCX + 4) - uVar11;
                    uVar12 = uVar12 - uVar11 % uVar12;
                    if (uVar15 <= uVar12) {
                        uVar12 = uVar15;
                    }
                    if (uVar12 == 0) goto code_r0x0001801e69bb;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801e69a9;
                    uVar11 = fcn.1801e6820(*(int64_t *)((int64_t)&var_18h + iVar9), 
                                           *(int64_t *)((int64_t)&var_20h + iVar9), 
                                           *(int64_t *)((int64_t)&arg_28h + iVar9), 
                                           *(int64_t *)((int64_t)&arg_30h + iVar9));
                    if (uVar11 != uVar12) {
                        uVar14 = 0x106;
                        goto code_r0x0001801e69e8;
                    }
                    iVar13 = iVar13 + uVar12;
                }
                uVar14 = 0xfe;
code_r0x0001801e69e8:
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801e69f9;
                fcn.180224990(*(undefined8 *)((int64_t)&var_18h + iVar9), 0x1804b7430, uVar14);
            }
        }
        uVar14 = 0;
    }
    return uVar14;
}

// ============================================================
// Function: FUN_1801e6a10
// Address: 0x1801e6a10
// Size: 90 bytes
// ============================================================
void fcn.1801e6a10(int64_t arg_40h, int64_t arg_80h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801e6a1a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&arg_40h + iVar2) = *(uint64_t *)0x1806a3940 ^ (int64_t)&stack0x00000000 + iVar2;
    iVar1 = *(int64_t *)(in_RCX + 0x38);
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801e6a3f;
        fcn.1801de220(iVar1, (int64_t)&var_20h + iVar2);
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801e6a51;
        fcn.180459870(*(uint64_t *)((int64_t)&arg_40h + iVar2) ^ (int64_t)&stack0x00000000 + iVar2);
        return;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801e6a65;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_40h + iVar2) ^ (int64_t)&stack0x00000000 + iVar2);
    return;
}

// ============================================================
// Function: FUN_1801e6a70
// Address: 0x1801e6a70
// Size: 179 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1801e6a70(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_80h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 in_RCX;
    int64_t *in_RDX;
    int64_t iVar3;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e6a83;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&arg_38h + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar2);
    *(undefined8 *)((int64_t)&var_8h + iVar2) = in_R8;
    iVar3 = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801e6abe;
    iVar1 = func_0x00018020ba50();
    while (iVar1 != 0) {
        *(undefined8 *)((int64_t)&var_8h + iVar2) = in_R8;
        iVar3 = iVar3 + (*(int64_t *)((int64_t)&arg_30h + iVar2) - *(int64_t *)((int64_t)&arg_28h + iVar2));
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801e6af9;
        iVar1 = func_0x00018020ba50(in_RCX, (int64_t)&var_18h + iVar2, (int64_t)&arg_28h + iVar2, 
                                    (int64_t)&var_20h + iVar2);
    }
    *in_RDX = iVar3;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1801e6b12;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_38h + iVar2) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_1801e6b30
// Address: 0x1801e6b30
// Size: 19 bytes
// ============================================================
void fcn.1801e6b30(int64_t arg1, int64_t arg_28h)
{
    int32_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801e6b40;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        iVar1 = *(int32_t *)(arg1 + 0x2c);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6b53;
        func_0x00018020b590();
        uVar2 = *(undefined8 *)(arg1 + 0x50);
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6b8a;
            fcn.180224990(uVar2, 0x1804b7430, 0x3c);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6b76;
            fcn.180224b90(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        }
        *(undefined8 *)(arg1 + 0x50) = 0;
        *(undefined8 *)(arg1 + 0x58) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6ba9;
        fcn.180224990(arg1, 0x1804b74a0, 0x36);
    }
    return;
}

// ============================================================
// Function: FUN_1801e6b43
// Address: 0x1801e6b43
// Size: 29 bytes
// ============================================================
void fcn.1801e6b30(int64_t arg1, int64_t arg_28h)
{
    int32_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801e6b40;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        iVar1 = *(int32_t *)(arg1 + 0x2c);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6b53;
        func_0x00018020b590();
        uVar2 = *(undefined8 *)(arg1 + 0x50);
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6b8a;
            fcn.180224990(uVar2, 0x1804b7430, 0x3c);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6b76;
            fcn.180224b90(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        }
        *(undefined8 *)(arg1 + 0x50) = 0;
        *(undefined8 *)(arg1 + 0x58) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6ba9;
        fcn.180224990(arg1, 0x1804b74a0, 0x36);
    }
    return;
}

// ============================================================
// Function: FUN_1801e6b60
// Address: 0x1801e6b60
// Size: 79 bytes
// ============================================================
void fcn.1801e6b30(int64_t arg1, int64_t arg_28h)
{
    int32_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801e6b40;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        iVar1 = *(int32_t *)(arg1 + 0x2c);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6b53;
        func_0x00018020b590();
        uVar2 = *(undefined8 *)(arg1 + 0x50);
        if (iVar1 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6b8a;
            fcn.180224990(uVar2, 0x1804b7430, 0x3c);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6b76;
            fcn.180224b90(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        }
        *(undefined8 *)(arg1 + 0x50) = 0;
        *(undefined8 *)(arg1 + 0x58) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6ba9;
        fcn.180224990(arg1, 0x1804b74a0, 0x36);
    }
    return;
}

// ============================================================
// Function: FUN_1801e6bb0
// Address: 0x1801e6bb0
// Size: 220 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801e6bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint64_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    uint64_t uVar5;
    int64_t *in_RDX;
    uint64_t uVar6;
    uint64_t *in_R8;
    int32_t *in_R9;
    uint64_t uVar7;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801e6bce;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e6bf3;
    iVar2 = func_0x00018020b9c0();
    if (iVar2 == 0) {
        *in_RDX = 0;
        *in_R8 = 0;
code_r0x0001801e6c6a:
        uVar4 = 1;
    } else {
        if (*(int64_t *)(in_RCX + 0x48) == *(int64_t *)(in_RCX + 0x40)) {
            if (*in_R9 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801e6c17;
                iVar2 = func_0x00018020b610(in_RCX);
                if (iVar2 != 0) goto code_r0x0001801e6c1b;
            }
        } else {
code_r0x0001801e6c1b:
            uVar1 = *(uint64_t *)(in_RCX + 0x40);
            iVar3 = *(int64_t *)((int64_t)&arg_28h + iVar3);
            uVar5 = *(int64_t *)(in_RCX + 0x48) - uVar1;
            if ((iVar3 != 0) || (uVar5 == 0)) {
code_r0x0001801e6c64:
                *in_R8 = uVar5;
                *in_RDX = iVar3;
                goto code_r0x0001801e6c6a;
            }
            if ((uVar1 < *(uint64_t *)(in_RCX + 0x60)) && (*(uint64_t *)(in_RCX + 0x68) <= uVar1)) {
                uVar6 = uVar1 % *(uint64_t *)(in_RCX + 0x58);
                uVar7 = *(uint64_t *)(in_RCX + 0x58) - uVar6;
                iVar3 = uVar6 + *(int64_t *)(in_RCX + 0x50);
                if (iVar3 != 0) {
                    if (uVar7 < uVar5) {
                        *(uint64_t *)(in_RCX + 0x48) = uVar7 + uVar1;
                        uVar5 = uVar7;
                    }
                    goto code_r0x0001801e6c64;
                }
            }
        }
        uVar4 = 0;
    }
    return uVar4;
}

// ============================================================
// Function: FUN_1801e6c90
// Address: 0x1801e6c90
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1801e6c90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e6caa;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e6ccd;
    iVar3 = fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar2));
    if (iVar3 != 0) {
        *(undefined8 *)(iVar3 + 0x50) = 0;
        *(undefined8 *)(iVar3 + 0x58) = 0;
        *(undefined8 *)(iVar3 + 0x68) = 0;
        *(undefined8 *)(iVar3 + 0x60) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e6cf5;
        iVar1 = func_0x0001801e72d0((undefined8 *)(iVar3 + 0x50), in_R8, 0);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e6d17;
            func_0x00018020b710(iVar3);
            *(undefined8 *)(iVar3 + 0x30) = in_RCX;
            *(undefined8 *)(iVar3 + 0x38) = in_RDX;
            return iVar3;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801e6d0e;
        fcn.180224990(iVar3, 0x1804b74a0, 0x22);
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e6d40
// Address: 0x1801e6d40
// Size: 41 bytes
// ============================================================
void fcn.1801e6d40(int64_t arg_28h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801e6d4a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&arg_28h + iVar1) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = *(undefined8 *)((int64_t)&arg_60h + iVar1);
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801e6d64;
    fcn.1801e6ff0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000098 + iVar1), 
                  *(int64_t *)(&stack0x000000a0 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1801e6d70
// Address: 0x1801e6d70
// Size: 185 bytes
// ============================================================
void fcn.1801e6d70(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_80h, int64_t arg_88h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int64_t in_R8;
    int64_t in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801e6d7a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&arg_40h + iVar2) = *(uint64_t *)0x1806a3940 ^ (int64_t)&stack0x00000000 + iVar2;
    iVar1 = *(int64_t *)((int64_t)&arg_80h + iVar2);
    if (in_R9 == 0) {
        if (iVar1 != 0) goto code_r0x0001801e6db3;
    } else if (iVar1 != 0) goto code_r0x0001801e6df6;
    if (*(int32_t *)((int64_t)&arg_88h + iVar2) != 0) {
code_r0x0001801e6df6:
        *(int64_t *)((int64_t)&arg_30h + iVar2) = in_R8;
        *(int32_t *)((int64_t)&var_20h + iVar2) = *(int32_t *)((int64_t)&arg_88h + iVar2);
        *(int64_t *)((int64_t)&arg_38h + iVar2) = iVar1 + in_R8;
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801e6e17;
        func_0x00018020b720(in_RCX, (int64_t)&arg_30h + iVar2, in_RDX);
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801e6e24;
        fcn.180459870(*(uint64_t *)((int64_t)&arg_40h + iVar2) ^ (int64_t)&stack0x00000000 + iVar2);
        return;
    }
code_r0x0001801e6db3:
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801e6db8;
    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801e6dd0;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                  *(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)((int64_t)&arg_38h + iVar2), 
                  *(int64_t *)(&stack0x00000050 + iVar2));
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801e6de2;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar2));
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801e6df1;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_40h + iVar2) ^ (int64_t)&stack0x00000000 + iVar2);
    return;
}

// ============================================================
// Function: FUN_1801e6e30
// Address: 0x1801e6e30
// Size: 34 bytes
// ============================================================
void fcn.1801e6e30(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_a0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_R12;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801e6e40;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_30h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4);
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBP;
    iVar1 = *(int64_t *)(in_RCX + 0x38);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R12;
    uVar2 = *(undefined8 *)((int64_t)&arg_a0h + iVar4);
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R15;
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801e6e8a;
        fcn.1801de220(iVar1, (int64_t)&var_10h + iVar4);
    }
    *(undefined4 *)((int64_t)&var_8h + iVar4) = 1;
    *(undefined8 *)(&stack0x00000000 + iVar4) = uVar2;
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801e6eb2;
    iVar3 = fcn.1801e6ff0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)(&stack0x00000078 + iVar4), 
                          *(int64_t *)(&stack0x00000080 + iVar4));
    if ((iVar3 != 0) && (*(int64_t *)(in_RCX + 0x30) != 0)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801e6ed9;
        fcn.1801e5a40(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)((int64_t)&var_10h + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801e6ef9;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_30h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801e6e52
// Address: 0x1801e6e52
// Size: 115 bytes
// ============================================================
void fcn.1801e6e30(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_a0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_R12;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801e6e40;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_30h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4);
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBP;
    iVar1 = *(int64_t *)(in_RCX + 0x38);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R12;
    uVar2 = *(undefined8 *)((int64_t)&arg_a0h + iVar4);
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R15;
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801e6e8a;
        fcn.1801de220(iVar1, (int64_t)&var_10h + iVar4);
    }
    *(undefined4 *)((int64_t)&var_8h + iVar4) = 1;
    *(undefined8 *)(&stack0x00000000 + iVar4) = uVar2;
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801e6eb2;
    iVar3 = fcn.1801e6ff0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)(&stack0x00000078 + iVar4), 
                          *(int64_t *)(&stack0x00000080 + iVar4));
    if ((iVar3 != 0) && (*(int64_t *)(in_RCX + 0x30) != 0)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801e6ed9;
        fcn.1801e5a40(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)((int64_t)&var_10h + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801e6ef9;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_30h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801e6ec5
// Address: 0x1801e6ec5
// Size: 62 bytes
// ============================================================
void fcn.1801e6e30(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_a0h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 unaff_RBP;
    undefined8 unaff_R12;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801e6e40;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_30h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4);
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_RBP;
    iVar1 = *(int64_t *)(in_RCX + 0x38);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R12;
    uVar2 = *(undefined8 *)((int64_t)&arg_a0h + iVar4);
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_R15;
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801e6e8a;
        fcn.1801de220(iVar1, (int64_t)&var_10h + iVar4);
    }
    *(undefined4 *)((int64_t)&var_8h + iVar4) = 1;
    *(undefined8 *)(&stack0x00000000 + iVar4) = uVar2;
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801e6eb2;
    iVar3 = fcn.1801e6ff0(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)(&stack0x00000078 + iVar4), 
                          *(int64_t *)(&stack0x00000080 + iVar4));
    if ((iVar3 != 0) && (*(int64_t *)(in_RCX + 0x30) != 0)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801e6ed9;
        fcn.1801e5a40(*(int64_t *)(&stack0x00000000 + iVar4), *(int64_t *)((int64_t)&var_8h + iVar4), 
                      *(int64_t *)((int64_t)&var_10h + iVar4));
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1801e6ef9;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_30h + iVar4) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801e6f10
// Address: 0x1801e6f10
// Size: 201 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1801e6f10(int64_t arg_28h, int64_t arg_30h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e6f25;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6f33;
    iVar2 = func_0x00018020b9b0();
    if (iVar2 != 0) {
        iVar4 = *(int64_t *)(in_RCX + 0x48);
        if ((uint64_t)(iVar4 - *(int64_t *)(in_RCX + 0x40)) < in_RDX) {
            if (in_RDX != 0xffffffffffffffff) {
                return false;
            }
        } else {
            iVar4 = *(int64_t *)(in_RCX + 0x40) + in_RDX;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6f71;
        iVar2 = func_0x00018020b610(in_RCX, iVar4);
        if (iVar2 != 0) {
            if (iVar4 != 0) {
                uVar1 = *(undefined4 *)(in_RCX + 0x2c);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6f8d;
                func_0x0001801e7200(in_RCX + 0x50, 0, iVar4 + -1, uVar1);
            }
            if (*(int64_t *)(in_RCX + 0x30) == 0) {
                return true;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6f9c;
            fcn.1801e6a10(*(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000070 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801e6fab;
            iVar2 = fcn.1801e5a40(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3));
            return iVar2 != 0;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1801e6ff0
// Address: 0x1801e6ff0
// Size: 518 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1801e6ff0(int64_t arg_28h, int64_t arg_a0h, int64_t arg_a8h)
{
    undefined4 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined4 *puVar9;
    uint64_t in_R8;
    int64_t *in_R9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_48;
    int64_t var_20h;
    
    uStack_48 = 0x1801e7007;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_28h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar3);
    puVar9 = *(undefined4 **)((int64_t)&arg_a0h + iVar3);
    iVar4 = 0;
    *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
    *(undefined4 *)(&stack0xfffffffffffffff0 + iVar3) = 0;
    *(int64_t **)((int64_t)&iStackX_20 + iVar3 + -0x20) = in_R9;
    *(undefined4 **)((int64_t)&var_8h + iVar3) = puVar9;
    *(undefined **)((int64_t)&var_20h + iVar3) = &stack0xfffffffffffffff0 + iVar3;
    *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x1801e706c;
    iVar2 = func_0x00018020ba50();
    iVar10 = iVar4;
    if (iVar2 != 0) {
        do {
            uVar5 = *(uint64_t *)((int64_t)&iStackX_20 + iVar3 + -8);
            uVar7 = *(int64_t *)((int64_t)&iStackX_20 + iVar3) - uVar5;
            if (in_R8 < uVar7) {
                *(undefined4 *)(&stack0xfffffffffffffff0 + iVar3) = 0;
                uVar7 = in_R8;
            }
            iVar4 = uVar5 + uVar7;
            if (uVar7 == 0) break;
            iVar6 = *(int64_t *)(&stack0xfffffffffffffff8 + iVar3);
            if (iVar6 == 0) {
                if ((*(uint64_t *)(in_RCX + 0x60) <= uVar5) || (uVar5 < *(uint64_t *)(in_RCX + 0x68))) {
code_r0x0001801e71e9:
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = 0;
                    goto code_r0x0001801e71cb;
                }
                uVar5 = uVar5 % *(uint64_t *)(in_RCX + 0x58);
                uVar8 = *(uint64_t *)(in_RCX + 0x58) - uVar5;
                iVar6 = uVar5 + *(int64_t *)(in_RCX + 0x50);
                *(int64_t *)(&stack0xfffffffffffffff8 + iVar3) = iVar6;
                if (iVar6 == 0) goto code_r0x0001801e71cb;
                if (uVar8 < uVar7) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x1801e70f5;
                    func_0x000180498030(in_RDX, iVar6, uVar8);
                    in_R8 = in_R8 - uVar8;
                    uVar5 = *(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8) + uVar8;
                    in_RDX = in_RDX + uVar8;
                    iVar10 = iVar10 + uVar8;
                    uVar7 = uVar7 - uVar8;
                    if ((*(uint64_t *)(in_RCX + 0x60) <= uVar5) || (uVar5 < *(uint64_t *)(in_RCX + 0x68)))
                    goto code_r0x0001801e71e9;
                    uVar8 = *(uint64_t *)(in_RCX + 0x58);
                    uVar5 = uVar5 % uVar8;
                    iVar6 = uVar5 + *(int64_t *)(in_RCX + 0x50);
                    *(int64_t *)(&stack0xfffffffffffffff8 + iVar3) = iVar6;
                    if ((iVar6 == 0) || (uVar8 - uVar5 <= uVar7)) goto code_r0x0001801e71cb;
                }
            }
            *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x1801e714c;
            func_0x000180498030(in_RDX, iVar6, uVar7);
            in_RDX = in_RDX + uVar7;
            iVar10 = iVar10 + uVar7;
            in_R8 = in_R8 - uVar7;
            if (in_R8 == 0) break;
            *(undefined **)((int64_t)&var_20h + iVar3) = &stack0xfffffffffffffff0 + iVar3;
            *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x1801e7178;
            iVar2 = func_0x00018020ba50(in_RCX, (int64_t)&var_10h + iVar3, (int64_t)&iStackX_20 + iVar3 + -8, 
                                        &stack0xfffffffffffffff8 + iVar3);
        } while (iVar2 != 0);
        in_R9 = *(int64_t **)((int64_t)&iStackX_20 + iVar3 + -0x20);
        puVar9 = *(undefined4 **)((int64_t)&var_8h + iVar3);
    }
    if ((*(int32_t *)((int64_t)&arg_a8h + iVar3) != 0) && (iVar4 != 0)) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x1801e71a4;
        iVar2 = func_0x00018020b610(in_RCX, iVar4);
        uVar1 = *(undefined4 *)(in_RCX + 0x2c);
        *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x1801e71ba;
        func_0x0001801e7200(in_RCX + 0x50, 0, iVar4 + -1, uVar1);
        if (iVar2 == 0) goto code_r0x0001801e71cb;
    }
    uVar1 = *(undefined4 *)(&stack0xfffffffffffffff0 + iVar3);
    *in_R9 = iVar10;
    *puVar9 = uVar1;
code_r0x0001801e71cb:
    *(undefined8 *)((int64_t)&uStack_48 + iVar3) = 0x1801e71d8;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_28h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801e7200
// Address: 0x1801e7200
// Size: 78 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801e7200(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    uint64_t in_RDX;
    uint64_t uVar5;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    uint64_t in_R8;
    int32_t in_R9D;
    int64_t var_1h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e7210;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = in_RCX[3];
    if ((in_RDX <= uVar1) && (in_R8 < 0x4000000000000000)) {
        if ((in_R9D != 0) && ((uVar2 = in_RCX[1], uVar2 != 0 && (uVar1 < in_R8)))) {
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
            uVar5 = uVar1 % uVar2;
            uVar6 = in_RCX[2];
            if (in_R8 + 1 <= (uint64_t)in_RCX[2]) {
                uVar6 = in_R8 + 1;
            }
            uVar6 = uVar6 - uVar1;
            if (uVar2 - uVar5 < uVar6) {
                iVar3 = *in_RCX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e7289;
                func_0x000180244fc0(iVar3 + uVar5, uVar2 - uVar5);
                uVar6 = uVar6 + (uVar5 - in_RCX[1]);
                uVar5 = 0;
            }
            if (uVar6 != 0) {
                iVar3 = *in_RCX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e72a5;
                func_0x000180244fc0(iVar3 + uVar5, uVar6);
            }
        }
        in_R8 = in_R8 + 1;
        in_RCX[3] = in_R8;
        if ((uint64_t)in_RCX[2] < in_R8) {
            in_RCX[2] = in_R8;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e724e
// Address: 0x1801e724e
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801e7200(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    uint64_t in_RDX;
    uint64_t uVar5;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    uint64_t in_R8;
    int32_t in_R9D;
    int64_t var_1h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e7210;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = in_RCX[3];
    if ((in_RDX <= uVar1) && (in_R8 < 0x4000000000000000)) {
        if ((in_R9D != 0) && ((uVar2 = in_RCX[1], uVar2 != 0 && (uVar1 < in_R8)))) {
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
            uVar5 = uVar1 % uVar2;
            uVar6 = in_RCX[2];
            if (in_R8 + 1 <= (uint64_t)in_RCX[2]) {
                uVar6 = in_R8 + 1;
            }
            uVar6 = uVar6 - uVar1;
            if (uVar2 - uVar5 < uVar6) {
                iVar3 = *in_RCX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e7289;
                func_0x000180244fc0(iVar3 + uVar5, uVar2 - uVar5);
                uVar6 = uVar6 + (uVar5 - in_RCX[1]);
                uVar5 = 0;
            }
            if (uVar6 != 0) {
                iVar3 = *in_RCX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e72a5;
                func_0x000180244fc0(iVar3 + uVar5, uVar6);
            }
        }
        in_R8 = in_R8 + 1;
        in_RCX[3] = in_R8;
        if ((uint64_t)in_RCX[2] < in_R8) {
            in_RCX[2] = in_R8;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e72af
// Address: 0x1801e72af
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801e7200(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    uint64_t in_RDX;
    uint64_t uVar5;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    uint64_t in_R8;
    int32_t in_R9D;
    int64_t var_1h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801e7210;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = in_RCX[3];
    if ((in_RDX <= uVar1) && (in_R8 < 0x4000000000000000)) {
        if ((in_R9D != 0) && ((uVar2 = in_RCX[1], uVar2 != 0 && (uVar1 < in_R8)))) {
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
            uVar5 = uVar1 % uVar2;
            uVar6 = in_RCX[2];
            if (in_R8 + 1 <= (uint64_t)in_RCX[2]) {
                uVar6 = in_R8 + 1;
            }
            uVar6 = uVar6 - uVar1;
            if (uVar2 - uVar5 < uVar6) {
                iVar3 = *in_RCX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e7289;
                func_0x000180244fc0(iVar3 + uVar5, uVar2 - uVar5);
                uVar6 = uVar6 + (uVar5 - in_RCX[1]);
                uVar5 = 0;
            }
            if (uVar6 != 0) {
                iVar3 = *in_RCX;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801e72a5;
                func_0x000180244fc0(iVar3 + uVar5, uVar6);
            }
        }
        in_R8 = in_R8 + 1;
        in_RCX[3] = in_R8;
        if ((uint64_t)in_RCX[2] < in_R8) {
            in_RCX[2] = in_R8;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801e72d0
// Address: 0x1801e72d0
// Size: 138 bytes
// ============================================================
undefined8
fcn.1801e72d0(int64_t arg1, uint64_t placeholder_1, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
             undefined8 placeholder_5, undefined8 placeholder_6, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    uint64_t uVar13;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar14;
    undefined8 unaff_RSI;
    uint64_t uVar15;
    uint64_t uVar16;
    undefined8 uVar17;
    undefined8 unaff_R12;
    int64_t iVar18;
    undefined8 unaff_R13;
    int64_t iVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    var_18h._0_4_ = (undefined4)arg3;
    uStack_20 = 0x1801e72e9;
    var_8h = arg1;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    iVar19 = 0;
    *(undefined8 *)((int64_t)&var_10h + iVar11) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar11) = 0;
    *(undefined8 *)((int64_t)&arg_90h + iVar11) = 0;
    if (placeholder_1 == *(uint64_t *)(arg1 + 8)) {
        return 1;
    }
    if ((uint64_t)(*(int64_t *)(arg1 + 0x10) - *(int64_t *)(arg1 + 0x18)) <= placeholder_1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801e734c;
        iVar12 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
        *(int64_t *)((int64_t)&var_10h + iVar11) = iVar12;
        if (iVar12 != 0) {
            *(undefined8 *)((int64_t)&arg_60h + iVar11) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_58h + iVar11) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_50h + iVar11) = unaff_RSI;
            uVar15 = *(uint64_t *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&arg_48h + iVar11) = unaff_R12;
            *(uint64_t *)((int64_t)&var_20h + iVar11) = uVar15;
            *(uint64_t *)((int64_t)&arg_a0h + iVar11) = uVar15;
            *(uint64_t *)((int64_t)&arg_28h + iVar11) = uVar15;
            *(undefined8 *)((int64_t)&arg_40h + iVar11) = unaff_R13;
            *(uint64_t *)((int64_t)&var_18h + iVar11) = placeholder_1;
            do {
                uVar1 = *(uint64_t *)(arg1 + 0x18);
                uVar13 = uVar1 + iVar19;
                if ((*(uint64_t *)(arg1 + 0x10) < uVar13) || (uVar13 < uVar1)) {
                    uVar17 = 0xfe;
code_r0x0001801e74fd:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801e750e;
                    fcn.180224990(*(undefined8 *)((int64_t)&var_10h + iVar11), 0x1804b7430, uVar17);
                    return 0;
                }
                uVar2 = *(uint64_t *)(arg1 + 8);
                if (uVar2 == 0) {
code_r0x0001801e74a5:
                    *(uint64_t *)((int64_t)&arg_28h + iVar11) = uVar1;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801e74b9;
                    fcn.1801e67c0(arg1, *(undefined4 *)((int64_t)&arg_98h + iVar11));
                    uVar4 = *(undefined4 *)((int64_t)&var_10h + iVar11 + 4);
                    uVar5 = *(undefined4 *)((int64_t)&var_18h + iVar11);
                    uVar6 = *(undefined4 *)((int64_t)&var_18h + iVar11 + 4);
                    uVar7 = *(undefined4 *)((int64_t)&var_20h + iVar11);
                    uVar8 = *(undefined4 *)((int64_t)&var_20h + iVar11 + 4);
                    uVar9 = *(undefined4 *)((int64_t)&arg_28h + iVar11);
                    uVar10 = *(undefined4 *)((int64_t)&arg_28h + iVar11 + 4);
                    *(undefined4 *)arg1 = *(undefined4 *)((int64_t)&var_10h + iVar11);
                    *(undefined4 *)(arg1 + 4) = uVar4;
                    *(undefined4 *)(arg1 + 8) = uVar5;
                    *(undefined4 *)(arg1 + 0xc) = uVar6;
                    *(undefined4 *)(arg1 + 0x10) = uVar7;
                    *(undefined4 *)(arg1 + 0x14) = uVar8;
                    *(undefined4 *)(arg1 + 0x18) = uVar9;
                    *(undefined4 *)(arg1 + 0x1c) = uVar10;
                    return 1;
                }
                uVar16 = *(uint64_t *)(arg1 + 0x10) - uVar13;
                uVar14 = uVar2 - uVar13 % uVar2;
                iVar19 = *(int64_t *)arg1 + uVar13 % uVar2;
                if (uVar16 <= uVar14) {
                    uVar14 = uVar16;
                }
                *(uint64_t *)((int64_t)&var_8h + iVar11) = uVar14;
                if (uVar14 == 0) goto code_r0x0001801e74a5;
                iVar12 = *(int64_t *)((int64_t)&var_10h + iVar11);
                iVar3 = *(int64_t *)((int64_t)&arg_a0h + iVar11);
                iVar18 = 0;
                while( true ) {
                    uVar13 = (iVar3 - uVar15) + placeholder_1;
                    if (uVar14 <= uVar13) {
                        uVar13 = uVar14;
                    }
                    uVar14 = 0x4000000000000000 - uVar15;
                    if (uVar13 <= 0x4000000000000000 - uVar15) {
                        uVar14 = uVar13;
                    }
                    if (uVar14 == 0) break;
                    uVar13 = placeholder_1 - uVar15 % placeholder_1;
                    if (uVar14 < uVar13) {
                        uVar13 = uVar14;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801e7456;
                    fcn.180498030(uVar15 % placeholder_1 + iVar12, iVar19, uVar13);
                    uVar15 = uVar15 + uVar13;
                    iVar19 = iVar19 + uVar13;
                    uVar14 = uVar14 - uVar13;
                    iVar18 = iVar18 + uVar13;
                }
                arg1 = *(int64_t *)((int64_t)&arg_88h + iVar11);
                *(uint64_t *)((int64_t)&var_20h + iVar11) = uVar15;
                if (iVar18 != *(int64_t *)((int64_t)&var_8h + iVar11)) {
                    uVar17 = 0x106;
                    goto code_r0x0001801e74fd;
                }
                iVar19 = *(int64_t *)((int64_t)&arg_90h + iVar11) + *(int64_t *)((int64_t)&var_8h + iVar11);
                *(int64_t *)((int64_t)&arg_90h + iVar11) = iVar19;
            } while( true );
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e735a
// Address: 0x1801e735a
// Size: 413 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.1801e72d0(int64_t arg1, uint64_t placeholder_1, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
             undefined8 placeholder_5, undefined8 placeholder_6, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    uint64_t uVar13;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar14;
    undefined8 unaff_RSI;
    uint64_t uVar15;
    uint64_t uVar16;
    undefined8 uVar17;
    undefined8 unaff_R12;
    int64_t iVar18;
    undefined8 unaff_R13;
    int64_t iVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    var_18h._0_4_ = (undefined4)arg3;
    uStack_20 = 0x1801e72e9;
    var_8h = arg1;
    iVar11 = fcn.18045a350(arg1, placeholder_1, arg3, placeholder_3, arg1);
    iVar11 = -iVar11;
    iVar19 = 0;
    *(undefined8 *)((int64_t)&var_10h + iVar11) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar11) = 0;
    *(undefined8 *)((int64_t)&arg_90h + iVar11) = 0;
    if (placeholder_1 == *(uint64_t *)(arg1 + 8)) {
        return 1;
    }
    if ((uint64_t)(*(int64_t *)(arg1 + 0x10) - *(int64_t *)(arg1 + 0x18)) <= placeholder_1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801e734c;
        iVar12 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
        *(int64_t *)((int64_t)&var_10h + iVar11) = iVar12;
        if (iVar12 != 0) {
            *(undefined8 *)((int64_t)&arg_60h + iVar11) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_58h + iVar11) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_50h + iVar11) = unaff_RSI;
            uVar15 = *(uint64_t *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&arg_48h + iVar11) = unaff_R12;
            *(uint64_t *)((int64_t)&var_20h + iVar11) = uVar15;
            *(uint64_t *)((int64_t)&arg_a0h + iVar11) = uVar15;
            *(uint64_t *)((int64_t)&arg_28h + iVar11) = uVar15;
            *(undefined8 *)((int64_t)&arg_40h + iVar11) = unaff_R13;
            *(uint64_t *)((int64_t)&var_18h + iVar11) = placeholder_1;
            do {
                uVar1 = *(uint64_t *)(arg1 + 0x18);
                uVar13 = uVar1 + iVar19;
                if ((*(uint64_t *)(arg1 + 0x10) < uVar13) || (uVar13 < uVar1)) {
                    uVar17 = 0xfe;
code_r0x0001801e74fd:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801e750e;
                    fcn.180224990(*(undefined8 *)((int64_t)&var_10h + iVar11), 0x1804b7430, uVar17);
                    return 0;
                }
                uVar2 = *(uint64_t *)(arg1 + 8);
                if (uVar2 == 0) {
code_r0x0001801e74a5:
                    *(uint64_t *)((int64_t)&arg_28h + iVar11) = uVar1;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801e74b9;
                    fcn.1801e67c0(arg1, *(undefined4 *)((int64_t)&arg_98h + iVar11));
                    uVar4 = *(undefined4 *)((int64_t)&var_10h + iVar11 + 4);
                    uVar5 = *(undefined4 *)((int64_t)&var_18h + iVar11);
                    uVar6 = *(undefined4 *)((int64_t)&var_18h + iVar11 + 4);
                    uVar7 = *(undefined4 *)((int64_t)&var_20h + iVar11);
                    uVar8 = *(undefined4 *)((int64_t)&var_20h + iVar11 + 4);
                    uVar9 = *(undefined4 *)((int64_t)&arg_28h + iVar11);
                    uVar10 = *(undefined4 *)((int64_t)&arg_28h + iVar11 + 4);
                    *(undefined4 *)arg1 = *(undefined4 *)((int64_t)&var_10h + iVar11);
                    *(undefined4 *)(arg1 + 4) = uVar4;
                    *(undefined4 *)(arg1 + 8) = uVar5;
                    *(undefined4 *)(arg1 + 0xc) = uVar6;
                    *(undefined4 *)(arg1 + 0x10) = uVar7;
                    *(undefined4 *)(arg1 + 0x14) = uVar8;
                    *(undefined4 *)(arg1 + 0x18) = uVar9;
                    *(undefined4 *)(arg1 + 0x1c) = uVar10;
                    return 1;
                }
                uVar16 = *(uint64_t *)(arg1 + 0x10) - uVar13;
                uVar14 = uVar2 - uVar13 % uVar2;
                iVar19 = *(int64_t *)arg1 + uVar13 % uVar2;
                if (uVar16 <= uVar14) {
                    uVar14 = uVar16;
                }
                *(uint64_t *)((int64_t)&var_8h + iVar11) = uVar14;
                if (uVar14 == 0) goto code_r0x0001801e74a5;
                iVar12 = *(int64_t *)((int64_t)&var_10h + iVar11);
                iVar3 = *(int64_t *)((int64_t)&arg_a0h + iVar11);
                iVar18 = 0;
                while( true ) {
                    uVar13 = (iVar3 - uVar15) + placeholder_1;
                    if (uVar14 <= uVar13) {
                        uVar13 = uVar14;
                    }
                    uVar14 = 0x4000000000000000 - uVar15;
                    if (uVar13 <= 0x4000000000000000 - uVar15) {
                        uVar14 = uVar13;
                    }
                    if (uVar14 == 0) break;
                    uVar13 = placeholder_1 - uVar15 % placeholder_1;
                    if (uVar14 < uVar13) {
                        uVar13 = uVar14;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801e7456;
                    fcn.180498030(uVar15 % placeholder_1 + iVar12, iVar19, uVar13);
                    uVar15 = uVar15 + uVar13;
                    iVar19 = iVar19 + uVar13;
                    uVar14 = uVar14 - uVar13;
                    iVar18 = iVar18 + uVar13;
                }
                arg1 = *(int64_t *)((int64_t)&arg_88h + iVar11);
                *(uint64_t *)((int64_t)&var_20h + iVar11) = uVar15;
                if (iVar18 != *(int64_t *)((int64_t)&var_8h + iVar11)) {
                    uVar17 = 0x106;
                    goto code_r0x0001801e74fd;
                }
                iVar19 = *(int64_t *)((int64_t)&arg_90h + iVar11) + *(int64_t *)((int64_t)&var_8h + iVar11);
                *(int64_t *)((int64_t)&arg_90h + iVar11) = iVar19;
            } while( true );
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801e74f7
// Address: 0x1801e74f7
// Size: 27 bytes
// ============================================================
undefined8
fcn.1801e72d0(int64_t arg1, uint64_t placeholder_1, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
             undefined8 placeholder_5, undefined8 placeholder_6, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
             int64_t arg_58h, int64_t arg_60h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    uint64_t uVar13;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    uint64_t uVar14;
    undefined8 unaff_RSI;
    uint64_t uVar15;
    uint64_t uVar16;
    undefined8 uVar17;
    undefined8 unaff_R12;
    int64_t iVar18;
    undefined8 unaff_R13;
    int64_t iVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    var_18h._0_4_ = (undefined4)arg3;
    uStack_20 = 0x1801e72e9;
    var_8h = arg1;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    iVar19 = 0;
    *(undefined8 *)((int64_t)&var_10h + iVar11) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar11) = 0;
    *(undefined8 *)((int64_t)&arg_90h + iVar11) = 0;
    if (placeholder_1 == *(uint64_t *)(arg1 + 8)) {
        return 1;
    }
    if ((uint64_t)(*(int64_t *)(arg1 + 0x10) - *(int64_t *)(arg1 + 0x18)) <= placeholder_1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801e734c;
        iVar12 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar11), *(int64_t *)((int64_t)&var_10h + iVar11));
        *(int64_t *)((int64_t)&var_10h + iVar11) = iVar12;
        if (iVar12 != 0) {
            *(undefined8 *)((int64_t)&arg_60h + iVar11) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_58h + iVar11) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_50h + iVar11) = unaff_RSI;
            uVar15 = *(uint64_t *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&arg_48h + iVar11) = unaff_R12;
            *(uint64_t *)((int64_t)&var_20h + iVar11) = uVar15;
            *(uint64_t *)((int64_t)&arg_a0h + iVar11) = uVar15;
            *(uint64_t *)((int64_t)&arg_28h + iVar11) = uVar15;
            *(undefined8 *)((int64_t)&arg_40h + iVar11) = unaff_R13;
            *(uint64_t *)((int64_t)&var_18h + iVar11) = placeholder_1;
            do {
                uVar1 = *(uint64_t *)(arg1 + 0x18);
                uVar13 = uVar1 + iVar19;
                if ((*(uint64_t *)(arg1 + 0x10) < uVar13) || (uVar13 < uVar1)) {
                    uVar17 = 0xfe;
code_r0x0001801e74fd:
                    *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801e750e;
                    fcn.180224990(*(undefined8 *)((int64_t)&var_10h + iVar11), 0x1804b7430, uVar17);
                    return 0;
                }
                uVar2 = *(uint64_t *)(arg1 + 8);
                if (uVar2 == 0) {
code_r0x0001801e74a5:
                    *(uint64_t *)((int64_t)&arg_28h + iVar11) = uVar1;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801e74b9;
                    fcn.1801e67c0(arg1, *(undefined4 *)((int64_t)&arg_98h + iVar11));
                    uVar4 = *(undefined4 *)((int64_t)&var_10h + iVar11 + 4);
                    uVar5 = *(undefined4 *)((int64_t)&var_18h + iVar11);
                    uVar6 = *(undefined4 *)((int64_t)&var_18h + iVar11 + 4);
                    uVar7 = *(undefined4 *)((int64_t)&var_20h + iVar11);
                    uVar8 = *(undefined4 *)((int64_t)&var_20h + iVar11 + 4);
                    uVar9 = *(undefined4 *)((int64_t)&arg_28h + iVar11);
                    uVar10 = *(undefined4 *)((int64_t)&arg_28h + iVar11 + 4);
                    *(undefined4 *)arg1 = *(undefined4 *)((int64_t)&var_10h + iVar11);
                    *(undefined4 *)(arg1 + 4) = uVar4;
                    *(undefined4 *)(arg1 + 8) = uVar5;
                    *(undefined4 *)(arg1 + 0xc) = uVar6;
                    *(undefined4 *)(arg1 + 0x10) = uVar7;
                    *(undefined4 *)(arg1 + 0x14) = uVar8;
                    *(undefined4 *)(arg1 + 0x18) = uVar9;
                    *(undefined4 *)(arg1 + 0x1c) = uVar10;
                    return 1;
                }
                uVar16 = *(uint64_t *)(arg1 + 0x10) - uVar13;
                uVar14 = uVar2 - uVar13 % uVar2;
                iVar19 = *(int64_t *)arg1 + uVar13 % uVar2;
                if (uVar16 <= uVar14) {
                    uVar14 = uVar16;
                }
                *(uint64_t *)((int64_t)&var_8h + iVar11) = uVar14;
                if (uVar14 == 0) goto code_r0x0001801e74a5;
                iVar12 = *(int64_t *)((int64_t)&var_10h + iVar11);
                iVar3 = *(int64_t *)((int64_t)&arg_a0h + iVar11);
                iVar18 = 0;
                while( true ) {
                    uVar13 = (iVar3 - uVar15) + placeholder_1;
                    if (uVar14 <= uVar13) {
                        uVar13 = uVar14;
                    }
                    uVar14 = 0x4000000000000000 - uVar15;
                    if (uVar13 <= 0x4000000000000000 - uVar15) {
                        uVar14 = uVar13;
                    }
                    if (uVar14 == 0) break;
                    uVar13 = placeholder_1 - uVar15 % placeholder_1;
                    if (uVar14 < uVar13) {
                        uVar13 = uVar14;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar11) = 0x1801e7456;
                    fcn.180498030(uVar15 % placeholder_1 + iVar12, iVar19, uVar13);
                    uVar15 = uVar15 + uVar13;
                    iVar19 = iVar19 + uVar13;
                    uVar14 = uVar14 - uVar13;
                    iVar18 = iVar18 + uVar13;
                }
                arg1 = *(int64_t *)((int64_t)&arg_88h + iVar11);
                *(uint64_t *)((int64_t)&var_20h + iVar11) = uVar15;
                if (iVar18 != *(int64_t *)((int64_t)&var_8h + iVar11)) {
                    uVar17 = 0x106;
                    goto code_r0x0001801e74fd;
                }
                iVar19 = *(int64_t *)((int64_t)&arg_90h + iVar11) + *(int64_t *)((int64_t)&var_8h + iVar11);
                *(int64_t *)((int64_t)&arg_90h + iVar11) = iVar19;
            } while( true );
        }
    }
    return 0;
}

