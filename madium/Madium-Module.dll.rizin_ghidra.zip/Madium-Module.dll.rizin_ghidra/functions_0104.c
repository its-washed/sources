// Chunk 104 - 50 functions

// ============================================================
// Function: FUN_18016abb0
// Address: 0x18016abb0
// Size: 103 bytes
// ============================================================
void fcn.18016abb0(int64_t arg1, int64_t arg2)
{
    undefined auStack_48 [32];
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_48;
    (*(code *)0x69a3e6)(**(undefined8 **)(arg2 + 0x50), &var_28h);
    *(float *)arg1 = (float)((int32_t)var_20h - (int32_t)var_28h);
    *(float *)(arg1 + 4) = (float)(var_20h._4_4_ - var_28h._4_4_);
    fcn.180459870(var_18h ^ (uint64_t)auStack_48);
    return;
}

// ============================================================
// Function: FUN_18016ac20
// Address: 0x18016ac20
// Size: 303 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.18016ac20(int64_t arg1, int64_t arg2, int64_t arg_30h)
{
    undefined4 uVar1;
    undefined8 *puVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t var_18h;
    undefined auStack_78 [32];
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    puVar2 = *(undefined8 **)(arg1 + 0x50);
    var_28h._0_4_ = (int32_t)(float)arg2;
    var_30h = 0;
    var_38h._4_4_ = (float)((uint64_t)arg2 >> 0x20);
    var_28h._4_4_ = (int32_t)var_38h._4_4_;
    var_38h = arg2;
    if ((*(uint8_t *)(arg1 + 4) & 4) != 0) {
        uVar3 = (*(code *)0x69a73c)(*puVar2, 0xfffffff0);
        *(undefined4 *)((int64_t)puVar2 + 0x14) = uVar3;
        uVar3 = (*(code *)0x69a73c)(*puVar2, 0xffffffec);
        *(undefined4 *)(puVar2 + 3) = uVar3;
    }
    uVar3 = *(undefined4 *)(puVar2 + 3);
    uVar1 = *(undefined4 *)((int64_t)puVar2 + 0x14);
    iVar5 = *(int64_t *)0x180781f28;
    if (*(int64_t *)0x180781f28 != 0) {
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0xd0);
    }
    if ((*(code **)(iVar5 + 0x38) != (code *)0x0) && (*(char *)(iVar5 + 0x31) != '\0')) {
        iVar4 = (int32_t)(int64_t)(*(float *)(arg1 + 0x30) * 96.0 + 0.5);
        if (iVar4 != 0) {
            var_58h._0_4_ = iVar4;
            iVar4 = (**(code **)(iVar5 + 0x38))(&var_30h, uVar1, 0, uVar3);
            if (iVar4 != 0) goto code_r0x00018016ad01;
        }
    }
    (*(code *)0x69a714)(&var_30h, uVar1, 0, uVar3);
code_r0x00018016ad01:
    var_50h._0_4_ = var_28h._4_4_ - var_30h._4_4_;
    var_58h._0_4_ = (int32_t)var_28h - (int32_t)var_30h;
    var_48h._0_4_ = 0x16;
    (*(code *)0x69a6ae)(*puVar2, 0, 0, 0);
    fcn.180459870(var_20h ^ (uint64_t)auStack_78);
    return;
}

// ============================================================
// Function: FUN_18016ad50
// Address: 0x18016ad50
// Size: 43 bytes
// ============================================================
void fcn.18016ad50(int64_t arg1)
{
    undefined8 *puVar1;
    
    puVar1 = *(undefined8 **)(arg1 + 0x50);
    (*(code *)0x69a580)(*puVar1);
    (*(code *)0x69a51a)(*puVar1);
    // WARNING: Treating indirect jump as call
    (*(code *)0x69a594)(*puVar1);
    return;
}

// ============================================================
// Function: FUN_18016ad80
// Address: 0x18016ad80
// Size: 28 bytes
// ============================================================
bool fcn.18016ad80(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    
    piVar1 = *(int64_t **)(arg1 + 0x50);
    iVar2 = (*(code *)0x69a404)();
    return iVar2 == *piVar1;
}

// ============================================================
// Function: FUN_18016ada0
// Address: 0x18016ada0
// Size: 27 bytes
// ============================================================
bool fcn.18016ada0(int64_t arg1)
{
    int32_t iVar1;
    
    iVar1 = (*(code *)0x69a50e)(**(undefined8 **)(arg1 + 0x50));
    return iVar1 != 0;
}

// ============================================================
// Function: FUN_18016adc0
// Address: 0x18016adc0
// Size: 162 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.18016adc0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t var_48h;
    int64_t var_40h;
    
    puVar1 = *(undefined8 **)(arg1 + 0x50);
    iVar3 = 0;
    iVar2 = (*(code *)0x699e90)(0xfde9, 0, arg2, 0xffffffff, 0, 0);
    if (0 < iVar2) {
        iVar4 = iVar2;
        if (iVar2 < 8) {
            iVar4 = 8;
        }
        if (0 < iVar4) {
            iVar3 = func_0x00018046d050((int64_t)iVar4 * 2);
        }
    }
    (*(code *)0x699e90)(0xfde9, 0, arg2, 0xffffffff, iVar3, iVar2);
    (*(code *)0x69a72a)(*puVar1, 0xc, 0, iVar3);
    if (iVar3 != 0) {
        func_0x000180460d90(iVar3);
    }
    return;
}

// ============================================================
// Function: FUN_18016ae70
// Address: 0x18016ae70
// Size: 145 bytes
// ============================================================
void fcn.18016ae70(int64_t arg1)
{
    undefined8 *puVar1;
    uint32_t uVar2;
    float in_XMM1_Da;
    int64_t var_18h;
    
    puVar1 = *(undefined8 **)(arg1 + 0x50);
    if (in_XMM1_Da < 1.0) {
        uVar2 = (*(code *)0x69a73c)();
        (*(code *)0x69a554)(*puVar1, 0xffffffec, uVar2 | 0x80000);
    // WARNING: Treating indirect jump as call
        (*(code *)0x69a5a0)(*puVar1, 0, (int32_t)(in_XMM1_Da * 255.0), 2);
        return;
    }
    uVar2 = (*(code *)0x69a73c)(*puVar1, 0xffffffec);
    // WARNING: Treating indirect jump as call
    (*(code *)0x69a554)(*puVar1, 0xffffffec, uVar2 & 0xfff7ffff);
    return;
}

// ============================================================
// Function: FUN_18016af10
// Address: 0x18016af10
// Size: 34 bytes
// ============================================================
float fcn.18016af10(int64_t arg1)
{
    int32_t iVar1;
    undefined8 uVar2;
    int64_t unaff_GS_OFFSET;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar2 = (*(code *)0x69a69a)(**(undefined8 **)(arg1 + 0x50), 2);
    var_10h._0_4_ = 0x60;
    var_18h._0_4_ = 0x60;
    iVar1 = func_0x00018016a2c0(6, 3);
    if (iVar1 != 0) {
        if (*(int32_t *)
             (*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
            *(int32_t *)0x180782b58) {
            func_0x000180459d18(0x180782b58);
            if (*(int32_t *)0x180782b58 == -1) {
                *(int64_t *)0x180782b48 = (*(code *)0x699e24)(0x180646620);
                func_0x000180459cac(0x180782b58);
            }
        }
        if (*(code **)0x180782518 != (code *)0x0) {
code_r0x00018016a434:
            (**(code **)0x180782518)(uVar2, 0, &var_10h, &var_18h);
            goto code_r0x00018016a481;
        }
        if (*(int64_t *)0x180782b48 != 0) {
            *(code **)0x180782518 = (code *)(*(code *)0x699eee)(*(int64_t *)0x180782b48, 0x1806465f0);
            if (*(code **)0x180782518 != (code *)0x0) goto code_r0x00018016a434;
        }
    }
    uVar2 = (*(code *)0x69a6be)(0);
    var_10h._0_4_ = (*(code *)0x69a79e)(uVar2, 0x58);
    var_18h._0_4_ = (*(code *)0x69a79e)(uVar2, 0x5a);
    (*(code *)0x69a4f2)(0, uVar2);
code_r0x00018016a481:
    return (float)(uint64_t)(uint32_t)var_10h / 96.0;
}

// ============================================================
// Function: FUN_18016af40
// Address: 0x18016af40
// Size: 264 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_41h
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_2dh
// WARNING: [rz-ghidra] Detected overlap for variable var_29h
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_11h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_dh

uint64_t fcn.18016af40(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    int32_t iVar7;
    int64_t var_38h;
    
    iVar2 = (*(code *)0x69a5be)(arg1, 0x1806464b8);
    iVar7 = (int32_t)arg2;
    if (iVar2 != 0) {
        iVar3 = fcn.180168ea0(arg1, arg2 & 0xffffffffU, arg3, arg4, iVar2 + 0x30);
        if (iVar3 != 0) {
            return 1;
        }
        piVar6 = *(int64_t **)(iVar2 + 0xd88);
        piVar1 = piVar6 + *(int32_t *)(iVar2 + 0xd80);
        for (; piVar6 != piVar1; piVar6 = piVar6 + 1) {
            iVar2 = *piVar6;
            if (*(int64_t *)(iVar2 + 0x60) == arg1) {
                if (iVar7 == 3) {
                    *(undefined *)(iVar2 + 0x71) = 1;
                } else if (iVar7 == 5) {
                    *(undefined *)(iVar2 + 0x72) = 1;
                } else {
                    if (iVar7 == 0x10) {
                        *(undefined *)(iVar2 + 0x73) = 1;
                        return 0;
                    }
                    if (iVar7 == 0x21) {
                        uVar5 = *(uint32_t *)(iVar2 + 4) & 0x40;
                        if (uVar5 != 0) {
                            return (uint64_t)(-(uint32_t)(uVar5 != 0) & 3);
                        }
                    } else if ((iVar7 == 0x84) && ((*(uint8_t *)(iVar2 + 4) & 0x80) != 0)) {
                        return 0xffffffffffffffff;
                    }
                }
                break;
            }
        }
    }
    uVar4 = (*(code *)0x69a72a)(arg1, arg2 & 0xffffffffU, arg3, arg4);
    return uVar4;
}

// ============================================================
// Function: FUN_18016b050
// Address: 0x18016b050
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18016b050(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x30);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x30);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18016b069
// Address: 0x18016b069
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18016b050(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x30);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x30);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18016b0ab
// Address: 0x18016b0ab
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18016b050(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = (int32_t)arg2;
    if (*(int32_t *)(arg1 + 4) < iVar2) {
        uVar1 = fcn.18046d050((int64_t)iVar2 * 0x30);
        if (*(int64_t *)(arg1 + 8) != 0) {
            fcn.180498030(uVar1, *(int64_t *)(arg1 + 8), (int64_t)*(int32_t *)arg1 * 0x30);
            fcn.180460d90(*(undefined8 *)(arg1 + 8));
        }
        *(undefined8 *)(arg1 + 8) = uVar1;
        *(int32_t *)(arg1 + 4) = iVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18016b0d0
// Address: 0x18016b0d0
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint32_t fcn.18016b0d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    uint8_t uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int32_t *piVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    uint64_t uVar8;
    int32_t iVar9;
    uint32_t uVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    int64_t var_20h;
    int64_t var_8h;
    
    iVar4 = (int32_t)arg3;
    if ((uint64_t)arg2 < 0x10) {
        iVar4 = iVar4 + 0x165667b1;
    } else {
        iVar9 = iVar4 + 0x24234428;
        piVar5 = (int32_t *)(arg2 + -0xf + arg1);
        uVar12 = iVar4 + 0x85ebca77;
        uVar3 = iVar4 + 0x61c8864f;
        do {
            uVar10 = iVar9 + *(int32_t *)arg1 * -0x7a143589;
            uVar11 = uVar10 * 0x2000 | uVar10 >> 0x13;
            iVar9 = uVar11 * -0x61c8864f;
            uVar12 = uVar12 + *(int32_t *)(arg1 + 4) * -0x7a143589;
            uVar13 = uVar12 * 0x2000 | uVar12 >> 0x13;
            uVar12 = uVar13 * -0x61c8864f;
            uVar10 = (int32_t)arg3 + *(int32_t *)(arg1 + 8) * -0x7a143589;
            piVar1 = (int32_t *)(arg1 + 0xc);
            uVar6 = uVar10 * 0x2000 | uVar10 >> 0x13;
            arg1 = arg1 + 0x10;
            uVar7 = uVar6 * -0x61c8864f;
            arg3 = (int64_t)uVar7;
            uVar3 = uVar3 + *piVar1 * -0x7a143589;
            uVar10 = uVar3 * 0x2000 | uVar3 >> 0x13;
            uVar3 = uVar10 * -0x61c8864f;
        } while ((uint64_t)arg1 < piVar5);
        iVar4 = (uVar10 * -0x193c0000 | uVar3 >> 0xe) + (uVar6 * 0x779b1000 | uVar7 >> 0x14) +
                (uVar13 * 0x1bbcd880 | uVar12 >> 0x19) + (uVar11 * 0x3c6ef362 | (uint32_t)(iVar9 < 0));
    }
    uVar3 = iVar4 + (uint32_t)arg2;
    for (uVar8 = (uint64_t)((uint32_t)arg2 & 0xf); 3 < uVar8; uVar8 = uVar8 - 4) {
        iVar4 = *(int32_t *)arg1;
        arg1 = arg1 + 4;
        uVar3 = uVar3 + iVar4 * -0x3d4d51c3;
        uVar3 = (uVar3 * 0x20000 | uVar3 >> 0xf) * 0x27d4eb2f;
    }
    for (; uVar8 != 0; uVar8 = uVar8 - 1) {
        uVar2 = *(uint8_t *)arg1;
        arg1 = arg1 + 1;
        uVar3 = (uint32_t)uVar2 * 0x165667b1 + uVar3;
        uVar3 = (uVar3 * 0x800 | uVar3 >> 0x15) * -0x61c8864f;
    }
    uVar3 = (uVar3 >> 0xf ^ uVar3) * -0x7a143589;
    uVar3 = (uVar3 >> 0xd ^ uVar3) * -0x3d4d51c3;
    return uVar3 >> 0x10 ^ uVar3;
}

// ============================================================
// Function: FUN_18016b0e4
// Address: 0x18016b0e4
// Size: 163 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint32_t fcn.18016b0d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    uint8_t uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int32_t *piVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    uint64_t uVar8;
    int32_t iVar9;
    uint32_t uVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    int64_t var_20h;
    int64_t var_8h;
    
    iVar4 = (int32_t)arg3;
    if ((uint64_t)arg2 < 0x10) {
        iVar4 = iVar4 + 0x165667b1;
    } else {
        iVar9 = iVar4 + 0x24234428;
        piVar5 = (int32_t *)(arg2 + -0xf + arg1);
        uVar12 = iVar4 + 0x85ebca77;
        uVar3 = iVar4 + 0x61c8864f;
        do {
            uVar10 = iVar9 + *(int32_t *)arg1 * -0x7a143589;
            uVar11 = uVar10 * 0x2000 | uVar10 >> 0x13;
            iVar9 = uVar11 * -0x61c8864f;
            uVar12 = uVar12 + *(int32_t *)(arg1 + 4) * -0x7a143589;
            uVar13 = uVar12 * 0x2000 | uVar12 >> 0x13;
            uVar12 = uVar13 * -0x61c8864f;
            uVar10 = (int32_t)arg3 + *(int32_t *)(arg1 + 8) * -0x7a143589;
            piVar1 = (int32_t *)(arg1 + 0xc);
            uVar6 = uVar10 * 0x2000 | uVar10 >> 0x13;
            arg1 = arg1 + 0x10;
            uVar7 = uVar6 * -0x61c8864f;
            arg3 = (int64_t)uVar7;
            uVar3 = uVar3 + *piVar1 * -0x7a143589;
            uVar10 = uVar3 * 0x2000 | uVar3 >> 0x13;
            uVar3 = uVar10 * -0x61c8864f;
        } while ((uint64_t)arg1 < piVar5);
        iVar4 = (uVar10 * -0x193c0000 | uVar3 >> 0xe) + (uVar6 * 0x779b1000 | uVar7 >> 0x14) +
                (uVar13 * 0x1bbcd880 | uVar12 >> 0x19) + (uVar11 * 0x3c6ef362 | (uint32_t)(iVar9 < 0));
    }
    uVar3 = iVar4 + (uint32_t)arg2;
    for (uVar8 = (uint64_t)((uint32_t)arg2 & 0xf); 3 < uVar8; uVar8 = uVar8 - 4) {
        iVar4 = *(int32_t *)arg1;
        arg1 = arg1 + 4;
        uVar3 = uVar3 + iVar4 * -0x3d4d51c3;
        uVar3 = (uVar3 * 0x20000 | uVar3 >> 0xf) * 0x27d4eb2f;
    }
    for (; uVar8 != 0; uVar8 = uVar8 - 1) {
        uVar2 = *(uint8_t *)arg1;
        arg1 = arg1 + 1;
        uVar3 = (uint32_t)uVar2 * 0x165667b1 + uVar3;
        uVar3 = (uVar3 * 0x800 | uVar3 >> 0x15) * -0x61c8864f;
    }
    uVar3 = (uVar3 >> 0xf ^ uVar3) * -0x7a143589;
    uVar3 = (uVar3 >> 0xd ^ uVar3) * -0x3d4d51c3;
    return uVar3 >> 0x10 ^ uVar3;
}

// ============================================================
// Function: FUN_18016b187
// Address: 0x18016b187
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint32_t fcn.18016b0d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    uint8_t uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int32_t *piVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    uint64_t uVar8;
    int32_t iVar9;
    uint32_t uVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    int64_t var_20h;
    int64_t var_8h;
    
    iVar4 = (int32_t)arg3;
    if ((uint64_t)arg2 < 0x10) {
        iVar4 = iVar4 + 0x165667b1;
    } else {
        iVar9 = iVar4 + 0x24234428;
        piVar5 = (int32_t *)(arg2 + -0xf + arg1);
        uVar12 = iVar4 + 0x85ebca77;
        uVar3 = iVar4 + 0x61c8864f;
        do {
            uVar10 = iVar9 + *(int32_t *)arg1 * -0x7a143589;
            uVar11 = uVar10 * 0x2000 | uVar10 >> 0x13;
            iVar9 = uVar11 * -0x61c8864f;
            uVar12 = uVar12 + *(int32_t *)(arg1 + 4) * -0x7a143589;
            uVar13 = uVar12 * 0x2000 | uVar12 >> 0x13;
            uVar12 = uVar13 * -0x61c8864f;
            uVar10 = (int32_t)arg3 + *(int32_t *)(arg1 + 8) * -0x7a143589;
            piVar1 = (int32_t *)(arg1 + 0xc);
            uVar6 = uVar10 * 0x2000 | uVar10 >> 0x13;
            arg1 = arg1 + 0x10;
            uVar7 = uVar6 * -0x61c8864f;
            arg3 = (int64_t)uVar7;
            uVar3 = uVar3 + *piVar1 * -0x7a143589;
            uVar10 = uVar3 * 0x2000 | uVar3 >> 0x13;
            uVar3 = uVar10 * -0x61c8864f;
        } while ((uint64_t)arg1 < piVar5);
        iVar4 = (uVar10 * -0x193c0000 | uVar3 >> 0xe) + (uVar6 * 0x779b1000 | uVar7 >> 0x14) +
                (uVar13 * 0x1bbcd880 | uVar12 >> 0x19) + (uVar11 * 0x3c6ef362 | (uint32_t)(iVar9 < 0));
    }
    uVar3 = iVar4 + (uint32_t)arg2;
    for (uVar8 = (uint64_t)((uint32_t)arg2 & 0xf); 3 < uVar8; uVar8 = uVar8 - 4) {
        iVar4 = *(int32_t *)arg1;
        arg1 = arg1 + 4;
        uVar3 = uVar3 + iVar4 * -0x3d4d51c3;
        uVar3 = (uVar3 * 0x20000 | uVar3 >> 0xf) * 0x27d4eb2f;
    }
    for (; uVar8 != 0; uVar8 = uVar8 - 1) {
        uVar2 = *(uint8_t *)arg1;
        arg1 = arg1 + 1;
        uVar3 = (uint32_t)uVar2 * 0x165667b1 + uVar3;
        uVar3 = (uVar3 * 0x800 | uVar3 >> 0x15) * -0x61c8864f;
    }
    uVar3 = (uVar3 >> 0xf ^ uVar3) * -0x7a143589;
    uVar3 = (uVar3 >> 0xd ^ uVar3) * -0x3d4d51c3;
    return uVar3 >> 0x10 ^ uVar3;
}

// ============================================================
// Function: FUN_18016b240
// Address: 0x18016b240
// Size: 182 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 fcn.18016b240(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    undefined uVar2;
    int32_t iVar3;
    int32_t iVar4;
    undefined4 uVar5;
    undefined *puVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar1 = (int64_t *)(arg3 + 0x10);
    if (*(uint64_t *)(arg3 + 0x18) < 0x10) {
        puVar6 = (undefined *)(*piVar1 + arg3);
    } else {
        arg3 = *(int64_t *)arg3;
        puVar6 = (undefined *)(arg3 + *piVar1);
    }
    piVar1 = (int64_t *)(arg2 + 0x10);
    if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
        puVar7 = (undefined *)(*piVar1 + arg2);
    } else {
        arg2 = *(int64_t *)arg2;
        puVar7 = (undefined *)(arg2 + *piVar1);
    }
    for (; (undefined *)arg2 != puVar7; arg2 = arg2 + 1) {
        if ((undefined *)arg3 == puVar6) goto code_r0x00018016b2db;
        uVar2 = *(undefined *)arg3;
        iVar3 = func_0x000180460320(*(undefined *)arg2);
        iVar4 = func_0x000180460320(uVar2);
        if (iVar3 < iVar4) goto code_r0x00018016b2d7;
        uVar2 = *(undefined *)arg2;
        iVar3 = func_0x000180460320(*(undefined *)arg3);
        iVar4 = func_0x000180460320(uVar2);
        if (iVar3 < iVar4) goto code_r0x00018016b2db;
        arg3 = arg3 + 1;
    }
    if ((undefined *)arg3 == puVar6) {
code_r0x00018016b2db:
        uVar5 = 0;
    } else {
code_r0x00018016b2d7:
        uVar5 = 1;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_18016b300
// Address: 0x18016b300
// Size: 618 bytes
// ============================================================
int64_t fcn.18016b300(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    undefined *puVar8;
    undefined *puVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t var_18h;
    undefined8 uStack_a0;
    undefined auStack_98 [8];
    undefined auStack_90 [24];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar8 = auStack_98;
    puVar9 = auStack_98;
    iVar6 = *(int64_t *)arg1;
    iVar3 = (*(int64_t *)(arg1 + 8) - iVar6) / 0x98;
    uVar7 = 0x1af286bca1af286;
    if (iVar3 == 0x1af286bca1af286) {
        func_0x000180010010();
        pcVar2 = (code *)swi(3);
        iVar6 = (*pcVar2)();
        return iVar6;
    }
    uVar1 = iVar3 + 1;
    uVar11 = (*(int64_t *)(arg1 + 0x10) - iVar6) / 0x98;
    if (0x1af286bca1af286 - (uVar11 >> 1) < uVar11) {
        uVar4 = 0xffffffffffffffb7;
        uVar11 = 0xffffffffffffff90;
    } else {
        uVar11 = uVar11 + (uVar11 >> 1);
        uVar7 = uVar1;
        if (uVar1 <= uVar11) {
            uVar7 = uVar11;
        }
        if (0x1af286bca1af286 < uVar7) {
code_r0x00018016b564:
            func_0x000180004720();
            pcVar2 = (code *)swi(3);
            iVar6 = (*pcVar2)();
            return iVar6;
        }
        uVar11 = uVar7 * 0x98;
        if (uVar11 == 0) {
            uVar4 = 0;
            puVar9 = auStack_98;
            goto code_r0x00018016b400;
        }
        if (uVar11 < 0x1000) {
            uVar4 = func_0x000180459890(uVar11);
            goto code_r0x00018016b400;
        }
        uVar4 = uVar11 + 0x27;
        if (uVar4 <= uVar11) goto code_r0x00018016b564;
    }
    iVar3 = func_0x000180459890(uVar4);
    if (iVar3 == 0) {
        pcVar2 = (code *)swi(0x29);
        iVar3 = (*pcVar2)(5);
        puVar8 = auStack_90;
    }
    uVar4 = iVar3 + 0x27U & 0xffffffffffffffe0;
    *(int64_t *)(uVar4 - 8) = iVar3;
    puVar9 = puVar8;
code_r0x00018016b400:
    iVar6 = (arg2 - iVar6) / 0x26 + (arg2 - iVar6 >> 0x3f);
    iVar10 = (iVar6 >> 2) - (iVar6 >> 0x3f);
    iVar6 = iVar10 * 0x98 + uVar4;
    uVar5 = iVar6 + 0x98;
    *(int64_t *)(puVar9 + 0x20) = arg1;
    *(uint64_t *)(puVar9 + 0x28) = uVar4;
    *(uint64_t *)(puVar9 + 0x30) = uVar7;
    *(uint64_t *)(puVar9 + 0x38) = uVar5;
    *(uint64_t *)(puVar9 + 0x40) = uVar5;
    *(undefined8 *)(puVar9 + -8) = 0x18016b457;
    func_0x00018005d340(arg1, iVar6, *(undefined8 *)(puVar9 + 0xb0));
    iVar3 = *(int64_t *)(arg1 + 8);
    iVar6 = *(int64_t *)arg1;
    uVar7 = uVar4;
    if (arg2 != iVar3) {
        *(undefined8 *)(puVar9 + -8) = 0x18016b476;
        func_0x00018016b570(iVar6, arg2, uVar4, arg1);
        iVar3 = *(int64_t *)(arg1 + 8);
        iVar6 = arg2;
        uVar7 = uVar5;
    }
    *(undefined8 *)(puVar9 + -8) = 0x18016b488;
    func_0x00018016b570(iVar6, iVar3, uVar7, arg1);
    iVar6 = *(int64_t *)arg1;
    if (iVar6 != 0) {
        iVar3 = *(int64_t *)(arg1 + 8);
        for (; iVar6 != iVar3; iVar6 = iVar6 + 0x98) {
            *(undefined8 *)(puVar9 + -8) = 0x18016b4a9;
            func_0x000180004dd0(iVar6 + 0x68);
            *(undefined8 *)(puVar9 + -8) = 0x18016b4b2;
            func_0x000180004dd0(iVar6 + 0x40);
            *(undefined8 *)(puVar9 + -8) = 0x18016b4bb;
            func_0x000180004dd0(iVar6 + 0x20);
            *(undefined8 *)(puVar9 + -8) = 0x18016b4c3;
            func_0x000180004dd0(iVar6);
        }
        uVar7 = *(uint64_t *)arg1;
        uVar5 = uVar7;
        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar7) / 0x98) * 0x98)) {
            uVar5 = *(uint64_t *)(uVar7 - 8);
            uVar7 = (uVar7 - uVar5) - 8;
            if (0x1f < uVar7) {
                pcVar2 = (code *)swi(0x29);
                uVar5 = uVar7;
                (*pcVar2)(5);
                puVar9 = puVar9 + 8;
            }
        }
        *(undefined8 *)(puVar9 + -8) = 0x18016b52a;
        func_0x000180459c3c(uVar5);
    }
    *(uint64_t *)arg1 = uVar4;
    *(uint64_t *)(arg1 + 8) = uVar1 * 0x98 + uVar4;
    *(uint64_t *)(arg1 + 0x10) = uVar11 + uVar4;
    return iVar10 * 0x98 + uVar4;
}

// ============================================================
// Function: FUN_18016b690
// Address: 0x18016b690
// Size: 488 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18016b690(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    undefined8 *puVar4;
    undefined4 *puVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if ((int32_t)arg2 != 0) {
        *(undefined8 *)arg1 = 0x1804a5628;
        *(undefined8 *)(arg1 + 0x10) = 0x1804a5630;
        *(undefined8 *)(arg1 + 0xa0) = 0;
        *(undefined8 *)(arg1 + 0xa8) = 0;
        *(undefined4 *)(arg1 + 0xb0) = 0;
        *(undefined8 *)(arg1 + 0xb8) = 0;
        *(undefined8 *)(arg1 + 0xc0) = 0;
        *(undefined8 *)(arg1 + 200) = 0;
        *(undefined8 *)(arg1 + 0xd0) = 0;
        *(undefined8 *)(arg1 + 0xd8) = 0;
        *(undefined8 *)(arg1 + 0x98) = 0x1804a54e0;
        *(undefined8 *)(arg1 + 0xe0) = 0;
        *(undefined8 *)(arg1 + 0xe8) = 0;
        *(undefined *)(arg1 + 0xf0) = 0;
    }
    func_0x00018000fce0(arg1, arg1 + 0x18, 0, 0);
    *(undefined8 *)((int64_t)*(int32_t *)(*(int64_t *)(arg1 + 0x10) + 4) + 0x10 + arg1) = 0x1804a54f0;
    iVar6 = *(int32_t *)(*(int64_t *)(arg1 + 0x10) + 4);
    *(int32_t *)((int64_t)iVar6 + 0xc + arg1) = iVar6 + -0x10;
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x1804a5610;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0x20;
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x1804a5620;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0x98;
    *(undefined8 *)(arg1 + 0x18) = 0x1804a5500;
    puVar1 = (undefined8 *)(arg1 + 0x20);
    *puVar1 = 0;
    puVar2 = (undefined8 *)(arg1 + 0x28);
    *puVar2 = 0;
    *(undefined8 *)(arg1 + 0x30) = 0;
    *(undefined8 *)(arg1 + 0x38) = 0;
    puVar3 = (undefined8 *)(arg1 + 0x40);
    *puVar3 = 0;
    puVar4 = (undefined8 *)(arg1 + 0x48);
    *puVar4 = 0;
    *(undefined8 *)(arg1 + 0x50) = 0;
    *(undefined8 *)(arg1 + 0x58) = 0;
    puVar5 = (undefined4 *)(arg1 + 0x60);
    *puVar5 = 0;
    *(undefined4 *)(arg1 + 100) = 0;
    *(undefined8 *)(arg1 + 0x68) = 0;
    *(undefined8 *)(arg1 + 0x70) = 0;
    iVar7 = func_0x000180459890();
    if (iVar7 == 0) {
        iVar7 = 0;
    } else {
        uVar8 = func_0x0001804558e8();
        *(undefined8 *)(iVar7 + 8) = uVar8;
    }
    *(int64_t *)(arg1 + 0x78) = iVar7;
    *(undefined8 **)(arg1 + 0x30) = puVar1;
    *(undefined8 **)(arg1 + 0x38) = puVar2;
    *(undefined8 **)(arg1 + 0x50) = puVar3;
    *(undefined8 **)(arg1 + 0x58) = puVar4;
    *(undefined4 **)(arg1 + 0x68) = puVar5;
    *(undefined4 **)(arg1 + 0x70) = (undefined4 *)(arg1 + 100);
    *puVar2 = 0;
    *puVar4 = 0;
    *(undefined4 *)(arg1 + 100) = 0;
    *puVar1 = 0;
    *puVar3 = 0;
    *puVar5 = 0;
    *(undefined8 *)(arg1 + 0x18) = 0x1804a5580;
    *(undefined8 *)(arg1 + 0x80) = 0;
    *(undefined4 *)(arg1 + 0x88) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_18016b900
// Address: 0x18016b900
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18016b900(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    iVar5 = *(int64_t *)(arg1 + 0x20);
    for (iVar6 = *(int64_t *)(arg1 + 0x18); iVar6 != iVar5; iVar6 = iVar6 + 0x98) {
        func_0x000180004dd0(iVar6 + 0x68);
        func_0x000180004dd0(iVar6 + 0x40);
        func_0x000180004dd0(iVar6 + 0x20);
        func_0x000180004dd0(iVar6);
    }
    iVar6 = *(int64_t *)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x98)) {
        iVar5 = *(int64_t *)(iVar6 + -8);
        if ((iVar6 - iVar5) - 8U < 0x20) goto code_r0x0001800f4640;
        pcVar1 = (code *)swi(0x29);
        iVar6 = (*pcVar1)(5);
        puVar7 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    iVar5 = iVar6;
code_r0x0001800f4640:
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18016b914
// Address: 0x18016b914
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18016b900(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    iVar5 = *(int64_t *)(arg1 + 0x20);
    for (iVar6 = *(int64_t *)(arg1 + 0x18); iVar6 != iVar5; iVar6 = iVar6 + 0x98) {
        func_0x000180004dd0(iVar6 + 0x68);
        func_0x000180004dd0(iVar6 + 0x40);
        func_0x000180004dd0(iVar6 + 0x20);
        func_0x000180004dd0(iVar6);
    }
    iVar6 = *(int64_t *)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x98)) {
        iVar5 = *(int64_t *)(iVar6 + -8);
        if ((iVar6 - iVar5) - 8U < 0x20) goto code_r0x0001800f4640;
        pcVar1 = (code *)swi(0x29);
        iVar6 = (*pcVar1)(5);
        puVar7 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    iVar5 = iVar6;
code_r0x0001800f4640:
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18016b97e
// Address: 0x18016b97e
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18016b900(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    iVar5 = *(int64_t *)(arg1 + 0x20);
    for (iVar6 = *(int64_t *)(arg1 + 0x18); iVar6 != iVar5; iVar6 = iVar6 + 0x98) {
        func_0x000180004dd0(iVar6 + 0x68);
        func_0x000180004dd0(iVar6 + 0x40);
        func_0x000180004dd0(iVar6 + 0x20);
        func_0x000180004dd0(iVar6);
    }
    iVar6 = *(int64_t *)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x98)) {
        iVar5 = *(int64_t *)(iVar6 + -8);
        if ((iVar6 - iVar5) - 8U < 0x20) goto code_r0x0001800f4640;
        pcVar1 = (code *)swi(0x29);
        iVar6 = (*pcVar1)(5);
        puVar7 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    iVar5 = iVar6;
code_r0x0001800f4640:
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18016b9c0
// Address: 0x18016b9c0
// Size: 183 bytes
// ============================================================
void fcn.18016b9c0(int64_t arg1)
{
    int32_t iVar1;
    
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x1804a5620;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0x98;
    fcn.18000c970(arg1 + 0x18);
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x1804a5610;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0x20;
    *(undefined8 *)((int64_t)*(int32_t *)(*(int64_t *)(arg1 + 0x10) + 4) + 0x10 + arg1) = 0x1804a54f0;
    iVar1 = *(int32_t *)(*(int64_t *)(arg1 + 0x10) + 4);
    *(int32_t *)((int64_t)iVar1 + 0xc + arg1) = iVar1 + -0x10;
    *(undefined8 *)(*(int32_t *)(*(int64_t *)arg1 + 4) + arg1) = 0x1804a5600;
    *(int32_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + -4 + arg1) = *(int32_t *)(*(int64_t *)arg1 + 4) + -0x18;
    *(undefined8 *)(arg1 + 0x98) = 0x1804a54d0;
    fcn.180455c14();
    return;
}

// ============================================================
// Function: FUN_18016ba90
// Address: 0x18016ba90
// Size: 175 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t * fcn.18016ba90(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t var_8h;
    
    piVar1 = (int64_t *)(arg1 + -0x20);
    *(undefined8 *)((int64_t)*(int32_t *)(*piVar1 + 4) + -0x20 + arg1) = 0x1804a5610;
    *(int32_t *)((int64_t)*(int32_t *)(*piVar1 + 4) + -0x24 + arg1) = *(int32_t *)(*piVar1 + 4) + -0x20;
    *(undefined8 *)((int64_t)*(int32_t *)(*(int64_t *)(arg1 + -0x10) + 4) + -0x10 + arg1) = 0x1804a54f0;
    iVar2 = *(int32_t *)(*(int64_t *)(arg1 + -0x10) + 4);
    *(int32_t *)((int64_t)iVar2 + -0x14 + arg1) = iVar2 + -0x10;
    *(undefined8 *)((int64_t)*(int32_t *)(*piVar1 + 4) + -0x20 + arg1) = 0x1804a5600;
    *(int32_t *)((int64_t)*(int32_t *)(*piVar1 + 4) + -0x24 + arg1) = *(int32_t *)(*piVar1 + 4) + -0x18;
    *(undefined8 *)arg1 = 0x1804a54d0;
    fcn.180455c14(arg1);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(piVar1, 0x80);
    }
    return piVar1;
}

// ============================================================
// Function: FUN_18016bb40
// Address: 0x18016bb40
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18016bb40(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    arg1 = arg1 + -0x98;
    fcn.18016b9c0(arg1);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0xf8);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18016bb80
// Address: 0x18016bb80
// Size: 1710 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18016bb80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t **ppiVar1;
    code *pcVar2;
    bool bVar3;
    int64_t **ppiVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    undefined *puVar12;
    undefined *puVar13;
    undefined *puVar14;
    undefined *puVar15;
    undefined *puVar16;
    undefined *puVar17;
    int64_t iVar18;
    int64_t var_20h;
    undefined8 uStack_260;
    undefined auStack_258 [8];
    undefined auStack_250 [24];
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_220h;
    int64_t var_218h;
    int64_t var_208h;
    int64_t var_1f8h;
    int64_t var_1d8h;
    int64_t var_1d0h;
    int64_t var_1b8h;
    int64_t var_1b0h;
    int64_t var_1a0h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_108h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar12 = auStack_258;
    puVar13 = auStack_258;
    puVar14 = auStack_258;
    puVar15 = auStack_258;
    puVar16 = auStack_258;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_258;
    uVar11 = 0;
    var_238h._0_4_ = 0;
    var_230h = arg1;
    var_228h = arg3;
    var_218h = arg2;
    fcn.18016b690((int64_t)&var_208h, 1);
    iVar18 = *(int64_t *)(arg1 + 8);
    var_220h = *(int64_t *)(arg1 + 0x10);
    puVar17 = auStack_258;
    if (iVar18 != var_220h) {
        do {
            if (*(char *)arg1 == '\0') {
                func_0x00018000b4d0(&var_a8h, iVar18);
                ppiVar4 = (int64_t **)&var_a8h;
                uVar11 = uVar11 | 0x4004;
            } else {
                func_0x00018000b4d0(&var_e8h, iVar18);
                var_238h._0_4_ = uVar11 | 0x2001;
                ppiVar4 = (int64_t **)func_0x000180170630(arg3, &var_108h, &var_e8h);
                uVar11 = uVar11 | 0x2003;
            }
            ppiVar1 = ppiVar4 + 2;
            if ((int64_t *)0xf < ppiVar4[3]) {
                ppiVar4 = (int64_t **)*ppiVar4;
            }
            var_238h._0_4_ = uVar11;
            uVar5 = func_0x000180017f30(&var_1f8h, ppiVar4, *ppiVar1);
            func_0x0001800103b0(uVar5, 0x1805aae98);
            if ((uVar11 & 4) != 0) {
                uVar11 = uVar11 & 0xfffffffb;
                if ((uint64_t)var_90h < 0x10) {
code_r0x00018016bcb8:
                    var_98h = 0;
                    var_90h = 0xf;
                    var_a8h._0_1_ = 0;
                    goto code_r0x00018016bcd5;
                }
                uVar9 = var_90h + 1;
                iVar7 = CONCAT71(var_a8h._1_7_, (undefined)var_a8h);
                iVar8 = iVar7;
                if (uVar9 < 0x1000) {
code_r0x00018016bcb3:
                    fcn.180459c3c(iVar8, uVar9);
                    goto code_r0x00018016bcb8;
                }
                iVar8 = *(int64_t *)(iVar7 + -8);
                if ((iVar7 - iVar8) - 8U < 0x20) {
                    uVar9 = var_90h + 0x28;
                    goto code_r0x00018016bcb3;
                }
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar12 = auStack_250;
code_r0x00018016c144:
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar13 = puVar12 + 8;
code_r0x00018016c14b:
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar14 = puVar13 + 8;
code_r0x00018016c152:
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar15 = puVar14 + 8;
code_r0x00018016c159:
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar16 = puVar15 + 8;
code_r0x00018016c160:
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar17 = puVar16 + 8;
code_r0x00018016c167:
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar17 = puVar17 + 8;
                break;
            }
code_r0x00018016bcd5:
            if ((uVar11 & 2) != 0) {
                uVar11 = uVar11 & 0xfffffffd;
                if (0xf < (uint64_t)var_f0h) {
                    uVar9 = var_f0h + 1;
                    iVar7 = CONCAT71(var_108h._1_7_, (undefined)var_108h);
                    iVar8 = iVar7;
                    if (0xfff < uVar9) {
                        iVar8 = *(int64_t *)(iVar7 + -8);
                        if (0x1f < (iVar7 - iVar8) - 8U) goto code_r0x00018016c144;
                        uVar9 = var_f0h + 0x28;
                    }
                    fcn.180459c3c(iVar8, uVar9);
                }
                var_f8h = 0;
                var_f0h = 0xf;
                var_108h._0_1_ = 0;
            }
            if (((uVar11 & 1) != 0) && (uVar11 = uVar11 & 0xfffffffe, 0xf < (uint64_t)var_d0h)) {
                uVar9 = var_d0h + 1;
                iVar8 = var_e8h;
                if (uVar9 < 0x1000) {
code_r0x00018016bd6d:
                    fcn.180459c3c(iVar8, uVar9);
                    goto code_r0x00018016bd72;
                }
                iVar8 = *(int64_t *)(var_e8h + -8);
                puVar17 = auStack_258;
                if ((var_e8h - iVar8) - 8U < 0x20) {
                    uVar9 = var_d0h + 0x28;
                    goto code_r0x00018016bd6d;
                }
                goto code_r0x00018016c167;
            }
code_r0x00018016bd72:
            func_0x00018000b4d0(&var_e8h, iVar18 + 0x20);
            var_238h._0_4_ = uVar11 | 0x408;
            uVar9 = var_50h;
            iVar8 = var_68h;
            if (var_d8h == 0) {
code_r0x00018016be31:
                bVar3 = false;
            } else {
                func_0x00018000b4d0(&var_68h, iVar18 + 0x20);
                uVar9 = var_50h;
                iVar8 = var_68h;
                var_238h._0_4_ = uVar11 | 0x8418;
                piVar6 = &var_68h;
                if (0xf < (uint64_t)var_50h) {
                    piVar6 = (int64_t *)var_68h;
                }
                if (*(char *)piVar6 != '\"') goto code_r0x00018016be31;
                func_0x00018000b4d0(&var_c8h, iVar18 + 0x20);
                var_238h._0_4_ = uVar11 | 0x28438;
                piVar6 = &var_c8h;
                if (0xf < (uint64_t)var_b0h) {
                    piVar6 = (int64_t *)var_c8h;
                }
                if (*(char *)(var_b8h + -1 + (int64_t)piVar6) != '\"') goto code_r0x00018016be31;
                bVar3 = true;
            }
            uVar11 = (uint32_t)var_238h;
            if ((((uint32_t)var_238h & 0x20) != 0) &&
               (uVar11 = (uint32_t)var_238h & 0xffffffdf, var_238h._0_4_ = uVar11, 0xf < (uint64_t)var_b0h)) {
                uVar10 = var_b0h + 1;
                iVar7 = var_c8h;
                if (0xfff < uVar10) {
                    iVar7 = *(int64_t *)(var_c8h + -8);
                    if (0x1f < (var_c8h - iVar7) - 8U) goto code_r0x00018016c14b;
                    uVar10 = var_b0h + 0x28;
                }
                fcn.180459c3c(iVar7, uVar10);
            }
            if (((uVar11 & 0x10) != 0) && (uVar11 = uVar11 & 0xffffffef, var_238h._0_4_ = uVar11, 0xf < uVar9)) {
                uVar10 = uVar9 + 1;
                iVar7 = iVar8;
                if (0xfff < uVar10) {
                    iVar7 = *(int64_t *)(iVar8 + -8);
                    if (0x1f < (iVar8 - iVar7) - 8U) goto code_r0x00018016c152;
                    uVar10 = uVar9 + 0x28;
                }
                fcn.180459c3c(iVar7, uVar10);
            }
            if (((uVar11 & 8) != 0) && (uVar11 = uVar11 & 0xfffffff7, var_238h._0_4_ = uVar11, 0xf < (uint64_t)var_d0h))
            {
                uVar9 = var_d0h + 1;
                iVar8 = var_e8h;
                if (0xfff < uVar9) {
                    iVar8 = *(int64_t *)(var_e8h + -8);
                    puVar17 = auStack_258;
                    if (0x1f < (var_e8h - iVar8) - 8U) goto code_r0x00018016c167;
                    uVar9 = var_d0h + 0x28;
                }
                fcn.180459c3c(iVar8, uVar9);
            }
            arg1 = var_230h;
            iVar8 = iVar18 + 0x20;
            if (bVar3) {
                func_0x00018000b4d0(&var_108h, iVar8);
                uVar11 = uVar11 | 0x10000;
                piVar6 = &var_108h;
                if (0xf < (uint64_t)var_f0h) {
                    piVar6 = (int64_t *)CONCAT71(var_108h._1_7_, (undefined)var_108h);
                }
                var_238h._0_4_ = uVar11;
                func_0x000180017f30(&var_1f8h, piVar6, var_f8h);
                arg1 = var_230h;
                if (0xf < (uint64_t)var_f0h) {
                    uVar9 = var_f0h + 1;
                    iVar7 = CONCAT71(var_108h._1_7_, (undefined)var_108h);
                    iVar8 = iVar7;
                    if (0xfff < uVar9) {
                        iVar8 = *(int64_t *)(iVar7 + -8);
                        puVar17 = auStack_258;
                        if (0x1f < (iVar7 - iVar8) - 8U) goto code_r0x00018016c167;
                        uVar9 = var_f0h + 0x28;
                    }
                    fcn.180459c3c(iVar8, uVar9);
                    arg1 = var_230h;
                }
            } else {
                if (*(char *)var_230h == '\0') {
                    func_0x00018000b4d0(&var_88h, iVar8);
                    ppiVar4 = (int64_t **)&var_88h;
                    uVar11 = uVar11 | 0x80100;
                } else {
                    func_0x00018000b4d0(&var_e8h, iVar8);
                    var_238h._0_4_ = uVar11 | 0x40040;
                    ppiVar4 = (int64_t **)func_0x000180170630(var_228h, &var_108h, &var_e8h);
                    uVar11 = uVar11 | 0x400c0;
                }
                ppiVar1 = ppiVar4 + 2;
                if ((int64_t *)0xf < ppiVar4[3]) {
                    ppiVar4 = (int64_t **)*ppiVar4;
                }
                var_238h._0_4_ = uVar11;
                func_0x000180017f30(&var_1f8h, ppiVar4, *ppiVar1);
                if ((uVar11 >> 8 & 1) != 0) {
                    uVar11 = uVar11 & 0xfffffeff;
                    var_238h._0_4_ = uVar11;
                    if (0xf < (uint64_t)var_70h) {
                        uVar9 = var_70h + 1;
                        iVar7 = CONCAT71(var_88h._1_7_, (undefined)var_88h);
                        iVar8 = iVar7;
                        if (0xfff < uVar9) {
                            iVar8 = *(int64_t *)(iVar7 + -8);
                            if (0x1f < (iVar7 - iVar8) - 8U) goto code_r0x00018016c159;
                            uVar9 = var_70h + 0x28;
                        }
                        fcn.180459c3c(iVar8, uVar9);
                    }
                    var_78h = 0;
                    var_70h = 0xf;
                    var_88h._0_1_ = 0;
                }
                if ((char)uVar11 < '\0') {
                    uVar11 = uVar11 & 0xffffff7f;
                    var_238h._0_4_ = uVar11;
                    if (0xf < (uint64_t)var_f0h) {
                        uVar9 = var_f0h + 1;
                        iVar7 = CONCAT71(var_108h._1_7_, (undefined)var_108h);
                        iVar8 = iVar7;
                        if (0xfff < uVar9) {
                            iVar8 = *(int64_t *)(iVar7 + -8);
                            if (0x1f < (iVar7 - iVar8) - 8U) goto code_r0x00018016c160;
                            uVar9 = var_f0h + 0x28;
                        }
                        fcn.180459c3c(iVar8, uVar9);
                    }
                    var_f8h = 0;
                    var_f0h = 0xf;
                    var_108h._0_1_ = 0;
                }
                if (((uVar11 & 0x40) != 0) &&
                   (uVar11 = uVar11 & 0xffffffbf, var_238h._0_4_ = uVar11, 0xf < (uint64_t)var_d0h)) {
                    uVar9 = var_d0h + 1;
                    iVar8 = var_e8h;
                    if (0xfff < uVar9) {
                        iVar8 = *(int64_t *)(var_e8h + -8);
                        puVar17 = auStack_258;
                        if (0x1f < (var_e8h - iVar8) - 8U) goto code_r0x00018016c167;
                        uVar9 = var_d0h + 0x28;
                    }
                    fcn.180459c3c(iVar8, uVar9);
                }
            }
            func_0x0001800103b0(&var_1f8h, 0x1804a5638);
            iVar18 = iVar18 + 0x98;
            puVar17 = auStack_258;
            arg3 = var_228h;
        } while (iVar18 != var_220h);
    }
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    *(uint32_t *)(puVar17 + 0x20) = uVar11 | 0x1000;
    if ((((uint8_t)(uint32_t)var_180h & 0x22) == 2) || (uVar9 = *(uint64_t *)var_1b0h, uVar9 == 0)) {
        if ((((uint32_t)var_180h & 4) != 0) || (*(int64_t *)var_1b8h == 0)) goto code_r0x00018016c1f7;
        var_1d0h = *(int64_t *)var_1d8h;
        iVar18 = (*(int32_t *)var_1a0h - var_1d0h) + *(int64_t *)var_1b8h;
    } else {
        var_1d0h = *(int64_t *)var_1d0h;
        if (uVar9 < (uint64_t)var_188h) {
            uVar9 = var_188h;
        }
        iVar18 = uVar9 - var_1d0h;
    }
    if (var_1d0h != 0) {
        *(undefined8 *)(puVar17 + -8) = 0x18016c1f6;
        func_0x00018000f180(arg2, var_1d0h, iVar18);
    }
code_r0x00018016c1f7:
    *(undefined8 *)(puVar17 + -8) = 0x18016c201;
    fcn.18016b9c0((int64_t)(puVar17 + 0x50));
    *(undefined8 *)(puVar17 + -8) = 0x18016c213;
    fcn.180459870(var_48h ^ (uint64_t)puVar17);
    return;
}

// ============================================================
// Function: FUN_18016c230
// Address: 0x18016c230
// Size: 55 bytes
// ============================================================
int64_t fcn.18016c230(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    uint64_t *puVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    undefined *puVar10;
    undefined *puVar11;
    uint64_t uVar12;
    int64_t iVar13;
    uint64_t uVar14;
    undefined8 uStack_a0;
    undefined auStack_98 [8];
    undefined auStack_90 [80];
    
    puVar2 = (uint64_t *)(arg1 + 8);
    uVar9 = *(uint64_t *)(arg1 + 0x10);
    if (uVar9 != *(uint64_t *)(arg1 + 0x18)) {
        iVar4 = fcn.18005d340();
        *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 0x98;
        return iVar4;
    }
    puVar10 = auStack_98;
    puVar11 = auStack_98;
    uVar6 = *puVar2;
    iVar4 = (int64_t)(*(int64_t *)(arg1 + 0x10) - uVar6) / 0x98;
    uVar8 = 0x1af286bca1af286;
    if (iVar4 == 0x1af286bca1af286) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        iVar4 = (*pcVar3)();
        return iVar4;
    }
    uVar1 = iVar4 + 1;
    uVar14 = (int64_t)(*(int64_t *)(arg1 + 0x18) - uVar6) / 0x98;
    if (0x1af286bca1af286 - (uVar14 >> 1) < uVar14) {
        uVar5 = 0xffffffffffffffb7;
        uVar14 = 0xffffffffffffff90;
    } else {
        uVar14 = uVar14 + (uVar14 >> 1);
        uVar8 = uVar1;
        if (uVar1 <= uVar14) {
            uVar8 = uVar14;
        }
        if (0x1af286bca1af286 < uVar8) {
code_r0x00018016b564:
            func_0x000180004720();
            pcVar3 = (code *)swi(3);
            iVar4 = (*pcVar3)();
            return iVar4;
        }
        uVar14 = uVar8 * 0x98;
        if (uVar14 == 0) {
            uVar5 = 0;
            puVar11 = auStack_98;
            goto code_r0x00018016b400;
        }
        if (uVar14 < 0x1000) {
            uVar5 = func_0x000180459890(uVar14);
            goto code_r0x00018016b400;
        }
        uVar5 = uVar14 + 0x27;
        if (uVar5 <= uVar14) goto code_r0x00018016b564;
    }
    iVar4 = func_0x000180459890(uVar5);
    if (iVar4 == 0) {
        pcVar3 = (code *)swi(0x29);
        iVar4 = (*pcVar3)(5);
        puVar10 = auStack_90;
    }
    uVar5 = iVar4 + 0x27U & 0xffffffffffffffe0;
    *(int64_t *)(uVar5 - 8) = iVar4;
    puVar11 = puVar10;
code_r0x00018016b400:
    iVar4 = (int64_t)(uVar9 - uVar6) / 0x26 + ((int64_t)(uVar9 - uVar6) >> 0x3f);
    iVar13 = (iVar4 >> 2) - (iVar4 >> 0x3f);
    iVar4 = iVar13 * 0x98 + uVar5;
    uVar6 = iVar4 + 0x98;
    *(uint64_t **)(puVar11 + 0x20) = puVar2;
    *(uint64_t *)(puVar11 + 0x28) = uVar5;
    *(uint64_t *)(puVar11 + 0x30) = uVar8;
    *(uint64_t *)(puVar11 + 0x38) = uVar6;
    *(uint64_t *)(puVar11 + 0x40) = uVar6;
    *(undefined8 *)(puVar11 + -8) = 0x18016b457;
    fcn.18005d340(puVar2, iVar4, *(undefined8 *)(puVar11 + 0xb0));
    uVar7 = *(uint64_t *)(arg1 + 0x10);
    uVar8 = *puVar2;
    uVar12 = uVar5;
    if (uVar9 != uVar7) {
        *(undefined8 *)(puVar11 + -8) = 0x18016b476;
        func_0x00018016b570(uVar8, uVar9, uVar5, puVar2);
        uVar7 = *(uint64_t *)(arg1 + 0x10);
        uVar8 = uVar9;
        uVar12 = uVar6;
    }
    *(undefined8 *)(puVar11 + -8) = 0x18016b488;
    func_0x00018016b570(uVar8, uVar7, uVar12, puVar2);
    uVar9 = *puVar2;
    if (uVar9 != 0) {
        uVar6 = *(uint64_t *)(arg1 + 0x10);
        for (; uVar9 != uVar6; uVar9 = uVar9 + 0x98) {
            *(undefined8 *)(puVar11 + -8) = 0x18016b4a9;
            func_0x000180004dd0(uVar9 + 0x68);
            *(undefined8 *)(puVar11 + -8) = 0x18016b4b2;
            func_0x000180004dd0(uVar9 + 0x40);
            *(undefined8 *)(puVar11 + -8) = 0x18016b4bb;
            func_0x000180004dd0(uVar9 + 0x20);
            *(undefined8 *)(puVar11 + -8) = 0x18016b4c3;
            func_0x000180004dd0(uVar9);
        }
        uVar9 = *puVar2;
        uVar6 = uVar9;
        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x18) - uVar9) / 0x98) * 0x98)) {
            uVar6 = *(uint64_t *)(uVar9 - 8);
            uVar9 = (uVar9 - uVar6) - 8;
            if (0x1f < uVar9) {
                pcVar3 = (code *)swi(0x29);
                uVar6 = uVar9;
                (*pcVar3)(5);
                puVar11 = puVar11 + 8;
            }
        }
        *(undefined8 *)(puVar11 + -8) = 0x18016b52a;
        fcn.180459c3c(uVar6);
    }
    *puVar2 = uVar5;
    *(uint64_t *)(arg1 + 0x10) = uVar1 * 0x98 + uVar5;
    *(uint64_t *)(arg1 + 0x18) = uVar14 + uVar5;
    return iVar13 * 0x98 + uVar5;
}

// ============================================================
// Function: FUN_18016c270
// Address: 0x18016c270
// Size: 1394 bytes
// ============================================================
void fcn.18016c270(int64_t arg1)
{
    undefined4 *puVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    code *pcVar4;
    uint8_t uVar5;
    undefined auVar6 [16];
    undefined uVar7;
    uint8_t uVar8;
    char cVar9;
    undefined (*pauVar10) [16];
    int64_t iVar11;
    undefined (*pauVar12) [16];
    undefined8 *puVar13;
    undefined8 uVar14;
    int64_t *piVar15;
    undefined *puVar16;
    undefined (*pauVar17) [16];
    undefined8 uStack_d0;
    undefined auStack_c8 [8];
    undefined auStack_c0 [24];
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    puVar16 = auStack_c8;
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_c8;
    pauVar17 = (undefined (*) [16])0x0;
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined *)(arg1 + 0x10) = 0;
    *(undefined *)(arg1 + 0x40) = 0;
    var_88h = arg1;
    var_98h = func_0x000180459890(0x120);
    pauVar10 = pauVar17;
    if (var_98h != 0) {
        pauVar10 = (undefined (*) [16])func_0x000180170560(var_98h);
    }
    *(undefined8 *)(arg1 + 0x48) = 0;
    *(undefined8 *)(arg1 + 0x50) = 0;
    var_98h = (int64_t)pauVar10;
    var_98h = func_0x000180459890(0x18);
    pauVar12 = pauVar17;
    if ((undefined (*) [16])var_98h != (undefined (*) [16])0x0) {
        *(undefined (*) [16])var_98h = ZEXT816(0);
        *(undefined4 *)((undefined *)var_98h + 8) = 1;
        *(undefined4 *)((undefined *)var_98h + 0xc) = 1;
        *(undefined8 *)(undefined *)var_98h = 0x1804a5808;
        *(undefined (**) [16])*(undefined (*) [16])(var_98h + 0x10) = pauVar10;
        pauVar12 = (undefined (*) [16])var_98h;
    }
    *(undefined (**) [16])(arg1 + 0x48) = pauVar10;
    *(undefined (**) [16])(arg1 + 0x50) = pauVar12;
    *(undefined (*) [16])(arg1 + 0x60) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x70) = 0;
    *(undefined8 *)(arg1 + 0x78) = 0xf;
    *(undefined *)(arg1 + 0x60) = 0;
    *(undefined8 *)(arg1 + 0x58) = 0x1804a56f0;
    *(undefined *)(arg1 + 0x80) = 1;
    *(undefined8 *)(arg1 + 0x88) = 0;
    *(undefined8 *)(arg1 + 0x90) = 0;
    *(undefined8 *)(arg1 + 0x98) = 0;
    *(undefined8 *)(arg1 + 0xa0) = 0;
    *(undefined8 *)(arg1 + 0xa8) = 0;
    iVar11 = func_0x000180459890(0x60);
    *(int64_t *)iVar11 = iVar11;
    *(int64_t *)(iVar11 + 8) = iVar11;
    *(int64_t *)(iVar11 + 0x10) = iVar11;
    *(undefined2 *)(iVar11 + 0x18) = 0x101;
    *(int64_t *)(arg1 + 0xa0) = iVar11;
    *(undefined8 *)(arg1 + 0xb0) = 0;
    *(undefined8 *)(arg1 + 0xb8) = 0;
    iVar11 = func_0x000180459890(0x88);
    *(int64_t *)iVar11 = iVar11;
    *(int64_t *)(iVar11 + 8) = iVar11;
    *(int64_t *)(iVar11 + 0x10) = iVar11;
    *(undefined2 *)(iVar11 + 0x18) = 0x101;
    *(int64_t *)(arg1 + 0xb0) = iVar11;
    *(undefined8 *)(arg1 + 0xc0) = 0;
    *(undefined8 *)(arg1 + 200) = 0;
    iVar11 = func_0x000180459890(0x60);
    *(int64_t *)iVar11 = iVar11;
    *(int64_t *)(iVar11 + 8) = iVar11;
    *(int64_t *)(iVar11 + 0x10) = iVar11;
    *(undefined2 *)(iVar11 + 0x18) = 0x101;
    *(int64_t *)(arg1 + 0xc0) = iVar11;
    puVar1 = (undefined4 *)(arg1 + 0xd0);
    *puVar1 = 0;
    *(undefined8 *)(arg1 + 0xd8) = 0;
    *(undefined8 *)(arg1 + 0xe0) = 0;
    var_98h = (int64_t)puVar1;
    iVar11 = func_0x000180459890(0x30);
    *(int64_t *)iVar11 = iVar11;
    *(int64_t *)(iVar11 + 8) = iVar11;
    *(int64_t *)(arg1 + 0xd8) = iVar11;
    *(undefined8 *)(arg1 + 0xe8) = 0;
    *(undefined8 *)(arg1 + 0xf0) = 0;
    *(undefined8 *)(arg1 + 0xf8) = 0;
    *(undefined8 *)(arg1 + 0x100) = 7;
    *(undefined8 *)(arg1 + 0x108) = 8;
    *puVar1 = 0x3f800000;
    func_0x00018000f7e0((undefined8 *)(arg1 + 0xe8), 0x10, *(undefined8 *)(arg1 + 0xd8));
    pauVar12 = (undefined (*) [16])func_0x000180459890(400);
    pauVar10 = pauVar17;
    if (pauVar12 != (undefined (*) [16])0x0) {
        func_0x0001804986e0(pauVar12, 0, 400);
        pauVar10 = pauVar12;
    }
    *(undefined (**) [16])(arg1 + 0x110) = pauVar10;
    *(undefined8 *)(arg1 + 0x118) = 0;
    *(undefined (*) [16])(arg1 + 0x120) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x130) = 0;
    *(undefined8 *)(arg1 + 0x138) = 0xf;
    *(undefined *)(arg1 + 0x120) = 0;
    *(undefined (*) [16])(arg1 + 0x140) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x150) = 0;
    *(undefined8 *)(arg1 + 0x158) = 0xf;
    *(undefined *)(arg1 + 0x140) = 0;
    puVar2 = (undefined8 *)(arg1 + 0x160);
    *puVar2 = 0;
    *(undefined8 *)(arg1 + 0x168) = 0;
    *(undefined8 *)(arg1 + 0x170) = 0;
    *(undefined8 *)(arg1 + 0x178) = 0;
    *(undefined8 *)(arg1 + 0x180) = 0;
    puVar13 = (undefined8 *)func_0x000180459890(0x10);
    puVar13[1] = 0;
    *puVar2 = puVar13;
    *puVar13 = puVar2;
    *(undefined2 *)(arg1 + 0x188) = 0;
    iVar11 = func_0x000180413d70(10);
    uVar3 = *(undefined8 *)(iVar11 + 8);
    _var_80h = ZEXT816(0);
    var_70h = 0;
    var_68h = 0;
    uVar14 = func_0x000180498cd0(uVar3);
    func_0x000180004830(&var_80h, uVar3, uVar14);
    if ((uint64_t)(var_68h - var_70h) < 5) {
        var_a0h = 5;
        var_a8h = 0x1804a57c8;
        pauVar10 = (undefined (*) [16])func_0x000180018d80(&var_80h, 5, (undefined)var_90h, 0);
    } else {
        piVar15 = &var_80h;
        if (0xf < (uint64_t)var_68h) {
            piVar15 = (int64_t *)var_80h;
        }
        if ((piVar15 < (int64_t *)0x1804a57cd) && (0x1804a57c7 < (uint64_t)((int64_t)piVar15 + var_70h))) {
            if ((int64_t *)0x1804a57c8 < piVar15) {
                pauVar17 = (undefined (*) [16])(piVar15 + -0x30094af9);
            }
        } else {
            pauVar17 = (undefined (*) [16])0x5;
        }
        iVar11 = var_70h + 1;
        var_70h = var_70h + 5;
        fcn.180498030((int64_t)piVar15 + 5, piVar15, iVar11);
        fcn.180498030(piVar15, 0x1804a57c8, pauVar17);
        fcn.180498030((int64_t)piVar15 + (int64_t)pauVar17, pauVar17[0x1804a57c] + 0xd, 5 - (int64_t)pauVar17);
        pauVar10 = (undefined (*) [16])&var_80h;
    }
    _var_60h = ZEXT816(0);
    var_50h = 0;
    var_48h = 0;
    _var_60h = *pauVar10;
    var_50h = *(int64_t *)pauVar10[1];
    var_48h = *(int64_t *)(pauVar10[1] + 8);
    *(undefined8 *)pauVar10[1] = 0;
    *(undefined8 *)(pauVar10[1] + 8) = 0xf;
    (*pauVar10)[0] = 0;
    if (0xf < (uint64_t)var_68h) {
        iVar11 = var_80h;
        puVar16 = auStack_c8;
        if ((0xfff < var_68h + 1U) &&
           (iVar11 = *(int64_t *)(var_80h + -8), puVar16 = auStack_c8, 0x1f < (var_80h - iVar11) - 8U)) {
            pcVar4 = (code *)swi(0x29);
            iVar11 = (*pcVar4)(5);
            puVar16 = auStack_c0;
        }
        *(undefined8 *)(puVar16 + -8) = 0x18016c657;
        fcn.180459c3c(iVar11);
    }
    var_70h = 0;
    var_68h = 0xf;
    auVar6[15] = 0;
    auVar6._0_15_ = stack0xffffffffffffff81;
    _var_80h = auVar6 << 8;
    piVar15 = &var_60h;
    if (0xf < (uint64_t)var_48h) {
        piVar15 = (int64_t *)var_60h;
    }
    uVar3 = **(undefined8 **)(arg1 + 0x48);
    *(undefined8 *)(puVar16 + -8) = 0x18016c686;
    func_0x0001804166c0(uVar3, 0x2722, piVar15);
    uVar3 = **(undefined8 **)(arg1 + 0x48);
    *(undefined8 *)(puVar16 + -8) = 0x18016c69d;
    func_0x0001804166c0(uVar3, 0x34, 1);
    uVar3 = **(undefined8 **)(arg1 + 0x48);
    *(undefined8 *)(puVar16 + -8) = 0x18016c6b4;
    func_0x0001804166c0(uVar3, 0x44, 0x32);
    uVar3 = **(undefined8 **)(arg1 + 0x48);
    *(undefined8 *)(puVar16 + -8) = 0x18016c6c8;
    func_0x0001804166c0(uVar3, 0x69, 0);
    *(undefined8 *)(puVar16 + -8) = 0x18016c6d1;
    uVar7 = func_0x0001801722a0(7, 1);
    *(undefined8 *)(puVar16 + -8) = 0x18016c6d9;
    uVar8 = func_0x0001801722b0(uVar7);
    *(undefined8 *)(puVar16 + -8) = 0x18016c6e5;
    uVar7 = func_0x0001801722a0(7, 2);
    *(undefined8 *)(puVar16 + -8) = 0x18016c6ed;
    cVar9 = func_0x0001801722b0(uVar7);
    uVar5 = uVar8 | 2;
    if (cVar9 == '\0') {
        uVar5 = uVar8;
    }
    *(undefined8 *)(puVar16 + -8) = 0x18016c700;
    uVar7 = func_0x0001801722a0(7, 4);
    *(undefined8 *)(puVar16 + -8) = 0x18016c708;
    cVar9 = func_0x0001801722b0(uVar7);
    uVar8 = uVar5 | 4;
    if (cVar9 == '\0') {
        uVar8 = uVar5;
    }
    uVar3 = **(undefined8 **)(arg1 + 0x48);
    *(undefined8 *)(puVar16 + -8) = 0x18016c726;
    func_0x0001804166c0(uVar3, 0xa1, uVar8);
    uVar3 = **(undefined8 **)(arg1 + 0x48);
    *(undefined8 *)(puVar16 + -8) = 0x18016c73d;
    func_0x0001804166c0(uVar3, 0x2b, 1);
    puVar2 = *(undefined8 **)(arg1 + 0x48);
    uVar3 = *puVar2;
    *(undefined8 *)(puVar16 + -8) = 0x18016c752;
    func_0x0001804166c0(uVar3, 0x271a, puVar2 + 4);
    uVar3 = **(undefined8 **)(arg1 + 0x48);
    *(undefined8 *)(puVar16 + -8) = 0x18016c76a;
    func_0x0001804166c0(uVar3, 0x272f, 0x1805aadb1);
    uVar3 = **(undefined8 **)(arg1 + 0x48);
    *(undefined8 *)(puVar16 + -8) = 0x18016c781;
    func_0x0001804166c0(uVar3, 0xd5, 1);
    if (0xf < (uint64_t)var_48h) {
        iVar11 = var_60h;
        if ((0xfff < var_48h + 1U) && (iVar11 = *(int64_t *)(var_60h + -8), 0x1f < (var_60h - iVar11) - 8U)) {
            pcVar4 = (code *)swi(0x29);
            iVar11 = (*pcVar4)(5);
            puVar16 = puVar16 + 8;
        }
        *(undefined8 *)(puVar16 + -8) = 0x18016c7c2;
        fcn.180459c3c(iVar11);
    }
    *(undefined8 *)(puVar16 + -8) = 0x18016c7d2;
    fcn.180459870(var_40h ^ (uint64_t)puVar16);
    return;
}

// ============================================================
// Function: FUN_18016c7f0
// Address: 0x18016c7f0
// Size: 60 bytes
// ============================================================
int64_t fcn.18016c7f0(int64_t arg1, int64_t arg2)
{
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    fcn.18045b4e4(arg2 + 8);
    *(undefined8 *)arg1 = 0x1804a5678;
    return arg1;
}

// ============================================================
// Function: FUN_18016c830
// Address: 0x18016c830
// Size: 71 bytes
// ============================================================
int64_t fcn.18016c830(int64_t arg1, int64_t arg2)
{
    int64_t var_18h;
    int64_t var_10h;
    
    var_10h._0_1_ = 1;
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    var_18h = arg2;
    fcn.18045b4e4(&var_18h);
    *(undefined8 *)arg1 = 0x1804a5678;
    return arg1;
}

// ============================================================
// Function: FUN_18016c880
// Address: 0x18016c880
// Size: 71 bytes
// ============================================================
int64_t fcn.18016c880(int64_t arg1, int64_t arg2)
{
    int64_t var_18h;
    int64_t var_10h;
    
    var_10h._0_1_ = 1;
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    var_18h = arg2;
    fcn.18045b4e4(&var_18h);
    *(undefined8 *)arg1 = 0x1804a53a0;
    return arg1;
}

// ============================================================
// Function: FUN_18016c8f0
// Address: 0x18016c8f0
// Size: 46 bytes
// ============================================================
void fcn.18016c8f0(int64_t arg1)
{
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 == 0) {
        return;
    }
    func_0x0001801705f0(arg1);
    if ((arg1 != 0) && (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, arg1, in_R9, unaff_RBX), iVar2 == 0))
    {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar1 = (undefined4 *)fcn.18046b77c();
        *puVar1 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_18016c920
// Address: 0x18016c920
// Size: 33 bytes
// ============================================================
int64_t fcn.18016c920(int64_t arg1)
{
    uint64_t in_RDX;
    
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x18);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18016c950
// Address: 0x18016c950
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18016c950(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    fcn.1801702c0();
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x48);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18016c990
// Address: 0x18016c990
// Size: 418 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18016c990(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    code *pcVar2;
    undefined auVar3 [16];
    undefined auVar4 [16];
    undefined8 uVar5;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_20h;
    undefined auStack_e8 [8];
    undefined auStack_e0 [24];
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    puVar7 = auStack_e8;
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_e8;
    var_b8h = 0;
    func_0x000180416800(**(undefined8 **)(arg1 + 0x48), 0x40001c, &var_b8h);
    func_0x00018016ef60(&var_98h, var_b8h);
    func_0x000180413cf0(var_b8h);
    iVar6 = *(int64_t *)(arg1 + 0x48);
    _var_78h = ZEXT816(0);
    var_68h = 0;
    var_60h = 0;
    uVar5 = func_0x000180498cd0(iVar6 + 0x20);
    func_0x000180004830(&var_78h, iVar6 + 0x20, uVar5);
    var_58h._0_4_ = func_0x000180170cb0(arg3 & 0xffffffff);
    _var_50h = _var_78h;
    var_40h = var_68h;
    var_38h = var_60h;
    var_68h = 0;
    var_60h = 0xf;
    auVar3[15] = 0;
    auVar3._0_15_ = stack0xffffffffffffff89;
    _var_78h = auVar3 << 8;
    if (*(int64_t *)(arg1 + 0x50) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(arg1 + 0x50) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    _var_b0h = *(undefined (*) [16])(arg1 + 0x48);
    var_c0h = (int64_t)&var_58h;
    var_c8h = (int64_t)&var_98h;
    func_0x000180170de0(arg2, &var_b0h, arg1 + 0x120, arg1 + 0x140);
    if (0xf < (uint64_t)var_38h) {
        iVar6 = var_50h;
        puVar7 = auStack_e8;
        if ((0xfff < var_38h + 1U) &&
           (iVar6 = *(int64_t *)(var_50h + -8), puVar7 = auStack_e8, 0x1f < (var_50h - iVar6) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar6 = (*pcVar2)(5);
            puVar7 = auStack_e0;
        }
        *(undefined8 *)(puVar7 + -8) = 0x18016caf3;
        fcn.180459c3c(iVar6);
    }
    var_40h = 0;
    var_38h = 0xf;
    auVar4[15] = 0;
    auVar4._0_15_ = stack0xffffffffffffffb1;
    _var_50h = auVar4 << 8;
    *(undefined8 *)(puVar7 + -8) = 0x18016cb0c;
    func_0x00018003e790(&var_90h);
    *(undefined8 *)(puVar7 + -8) = 0x18016cb1b;
    fcn.180459870(var_30h ^ (uint64_t)puVar7);
    return;
}

// ============================================================
// Function: FUN_18016cb40
// Address: 0x18016cb40
// Size: 156 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_128h

int64_t fcn.18016cb40(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t var_8h;
    int64_t in_stack_00000028;
    
    fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x50, 0);
    fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2c, 0);
    fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2734, 0x1804a57d4);
    fcn.18016dc10(arg1);
    if (*(int64_t *)(arg1 + 0x180) != 0) {
        fcn.18016d770(arg1, arg2);
        return arg2;
    }
    uVar1 = fcn.18016cbe0(in_stack_00000028);
    fcn.18016c990(arg1, arg2, (uint64_t)uVar1);
    return arg2;
}

// ============================================================
// Function: FUN_18016cbe0
// Address: 0x18016cbe0
// Size: 207 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 fcn.18016cbe0(int64_t arg1, int64_t arg_68h)
{
    int64_t *piVar1;
    undefined uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    undefined8 *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t unaff_RBX;
    int64_t unaff_RBP;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    undefined auStack_18 [8];
    int64_t *piStack_10;
    
    if (*(char *)(arg1 + 0x188) != '\0') {
        piVar5 = (int64_t *)fcn.1800103b0(0x180781030, 0x1804a5730);
        piVar1 = *(int64_t **)(*(int64_t *)((int64_t)*(int32_t *)(*piVar5 + 4) + 0x40 + (int64_t)piVar5) + 8);
        piStack_10 = piVar1;
        (**(code **)(*piVar1 + 8))(piVar1);
        piVar6 = (int64_t *)fcn.18000a390(auStack_18);
        uVar2 = (**(code **)(*piVar6 + 0x40))(piVar6, 10);
        if (piVar1 != (int64_t *)0x0) {
            puVar7 = (undefined8 *)(**(code **)(*piVar1 + 0x10))(piVar1);
            if (puVar7 != (undefined8 *)0x0) {
                (**(code **)*puVar7)(puVar7, 1);
            }
        }
        fcn.18016e850(piVar5, uVar2);
        fcn.18000fad0(piVar5);
        return 2;
    }
    iVar9 = **(int64_t **)(arg1 + 0x48);
    if (iVar9 == 0) {
        return 0x2b;
    }
    if (*(undefined **)(iVar9 + 0x1e8) != (undefined *)0x0) {
        **(undefined **)(iVar9 + 0x1e8) = 0;
    }
    if (*(int64_t *)(iVar9 + 0xd8) != 0) {
        fcn.18042bc90(iVar9, 0x180590400);
        return 2;
    }
    iVar8 = *(int64_t *)(iVar9 + 0xe0);
    var_8h = unaff_RBX;
    if (iVar8 == 0) {
        iVar8 = fcn.180425220(1, 3, 7);
        if (iVar8 == 0) {
            return 0x1b;
        }
        *(int64_t *)(iVar9 + 0xe0) = iVar8;
    }
    if (*(char *)(iVar8 + 0x1b3) != '\0') {
        return 0x5d;
    }
    fcn.180425e60(iVar8, 6, *(undefined8 *)(iVar9 + 0x9f0));
    iVar3 = fcn.1804256c0(iVar8, iVar9);
    if (iVar3 != 0) {
        fcn.180425910(unaff_RBP);
        *(undefined8 *)(iVar9 + 0xe0) = 0;
        uVar4 = 2;
        if (iVar3 == 3) {
            uVar4 = 0x1b;
        }
        return uVar4;
    }
    iVar3 = 0;
    do {
        do {
            do {
                if (iVar3 != 0) {
                    uVar4 = 0x2b;
                    if (iVar3 == 3) {
                        uVar4 = 0x1b;
                    }
                    goto code_r0x000180416a16;
                }
                var_8h = var_8h & 0xffffffff00000000;
                iVar3 = fcn.180425c10(0);
            } while (iVar3 != 0);
            iVar3 = fcn.180425ae0(iVar8, &var_8h);
        } while ((iVar3 != 0) || ((int32_t)var_8h != 0));
        iVar9 = fcn.180425a50(iVar8, &var_10h);
    } while (iVar9 == 0);
    uVar4 = *(undefined4 *)(iVar9 + 0x10);
code_r0x000180416a16:
    fcn.180425c40(unaff_RBP);
    return uVar4;
}

// ============================================================
// Function: FUN_18016ccb0
// Address: 0x18016ccb0
// Size: 203 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_128h

int64_t fcn.18016ccb0(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t var_8h;
    int64_t in_stack_00000028;
    
    if ((uint8_t)(*(char *)(arg1 + 0x40) - 1U) < 2) {
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2c, 0);
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2734, 0x1804a57dc);
    } else {
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2c, 0);
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2734, 0);
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x50, 1);
    }
    fcn.18016dc10(arg1);
    if (*(int64_t *)(arg1 + 0x180) != 0) {
        fcn.18016d770(arg1, arg2);
        return arg2;
    }
    uVar1 = fcn.18016cbe0(arg1, in_stack_00000028);
    fcn.18016c990(arg1, arg2, (uint64_t)uVar1);
    return arg2;
}

// ============================================================
// Function: FUN_18016cd80
// Address: 0x18016cd80
// Size: 136 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_128h

int64_t fcn.18016cd80(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t var_8h;
    int64_t in_stack_00000028;
    
    fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2c, 0);
    fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2734, 0x1804a57e8);
    fcn.18016dc10(arg1);
    if (*(int64_t *)(arg1 + 0x180) != 0) {
        fcn.18016d770(arg1, arg2);
        return arg2;
    }
    uVar1 = fcn.18016cbe0(arg1, in_stack_00000028);
    fcn.18016c990(arg1, arg2, (uint64_t)uVar1);
    return arg2;
}

// ============================================================
// Function: FUN_18016ce10
// Address: 0x18016ce10
// Size: 195 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_128h

int64_t fcn.18016ce10(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    undefined8 uVar2;
    int64_t var_8h;
    int64_t in_stack_00000028;
    
    fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2c, 0);
    if ((uint8_t)(*(char *)(arg1 + 0x40) - 1U) < 2) {
        uVar2 = 0;
    } else {
        uVar2 = 0x1805aadb1;
        if (*(int64_t *)(*(int64_t *)(arg1 + 0x110) + 0x48) != 0) {
            uVar2 = 0;
        }
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x271f, uVar2);
        uVar2 = 0x1804a57f0;
    }
    fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2734, uVar2);
    fcn.18016dc10(arg1);
    if (*(int64_t *)(arg1 + 0x180) != 0) {
        fcn.18016d770(arg1, arg2);
        return arg2;
    }
    uVar1 = fcn.18016cbe0(arg1, in_stack_00000028);
    fcn.18016c990(arg1, arg2, (uint64_t)uVar1);
    return arg2;
}

// ============================================================
// Function: FUN_18016cee0
// Address: 0x18016cee0
// Size: 200 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_128h

int64_t fcn.18016cee0(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t var_8h;
    int64_t in_stack_00000028;
    
    fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2c, 0);
    if ((1 < (uint8_t)(*(char *)(arg1 + 0x40) - 1U)) && (*(int64_t *)(*(int64_t *)(arg1 + 0x110) + 0x48) != 0)) {
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x271f, 0);
    }
    fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2734, 0x1804a57f8);
    fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2717, 0);
    fcn.18016dc10(arg1);
    if (*(int64_t *)(arg1 + 0x180) != 0) {
        fcn.18016d770(arg1, arg2);
        return arg2;
    }
    uVar1 = fcn.18016cbe0(arg1, in_stack_00000028);
    fcn.18016c990(arg1, arg2, (uint64_t)uVar1);
    return arg2;
}

// ============================================================
// Function: FUN_18016cfc0
// Address: 0x18016cfc0
// Size: 306 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.18016cfc0(int64_t arg1, int64_t arg2)
{
    int64_t **ppiVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t **ppiVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t *piVar9;
    undefined8 in_R9;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    ppiVar1 = (int64_t **)(arg1 + 0xc0);
    if (ppiVar1 != (int64_t **)arg2) {
        piVar9 = *ppiVar1;
        func_0x000180015170(ppiVar1, ppiVar1, piVar9[1]);
        piVar9[1] = (int64_t)piVar9;
        *piVar9 = (int64_t)piVar9;
        piVar9[2] = (int64_t)piVar9;
        *(undefined8 *)(arg1 + 200) = 0;
        piVar9 = *ppiVar1;
        puVar3 = *(undefined8 **)(*(int64_t *)arg2 + 8);
        if (*(char *)((int64_t)puVar3 + 0x19) == '\0') {
            piVar7 = (int64_t *)func_0x000180016a70(ppiVar1, piVar9, puVar3 + 4);
            piVar7[1] = (int64_t)piVar9;
            *(undefined *)(piVar7 + 3) = *(undefined *)(puVar3 + 3);
            iVar8 = func_0x000180015950(ppiVar1, *puVar3, piVar7, in_R9, ppiVar1, ppiVar1, piVar7);
            *piVar7 = iVar8;
            iVar8 = func_0x000180015950(ppiVar1, puVar3[2], piVar7);
            piVar7[2] = iVar8;
            piVar9 = piVar7;
        }
        (*ppiVar1)[1] = (int64_t)piVar9;
        *(undefined8 *)(arg1 + 200) = *(undefined8 *)(arg2 + 8);
        ppiVar4 = (int64_t **)*ppiVar1;
        ppiVar5 = (int64_t **)ppiVar4[1];
        if (*(char *)((int64_t)ppiVar5 + 0x19) == '\0') {
            cVar2 = *(char *)((int64_t)*ppiVar5 + 0x19);
            ppiVar6 = (int64_t **)*ppiVar5;
            while (cVar2 == '\0') {
                cVar2 = *(char *)((int64_t)*ppiVar6 + 0x19);
                ppiVar5 = ppiVar6;
                ppiVar6 = (int64_t **)*ppiVar6;
            }
            *ppiVar4 = (int64_t *)ppiVar5;
            iVar8 = (*ppiVar1)[1];
            cVar2 = *(char *)(*(int64_t *)(iVar8 + 0x10) + 0x19);
            while (cVar2 == '\0') {
                iVar8 = *(int64_t *)(iVar8 + 0x10);
                cVar2 = *(char *)(*(int64_t *)(iVar8 + 0x10) + 0x19);
            }
            (*ppiVar1)[2] = iVar8;
            return;
        }
        *ppiVar4 = (int64_t *)ppiVar4;
        (*ppiVar1)[2] = (int64_t)*ppiVar1;
    }
    return;
}

// ============================================================
// Function: FUN_18016d100
// Address: 0x18016d100
// Size: 175 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18016d100(int64_t arg1, int64_t arg2)
{
    int64_t **ppiVar1;
    int64_t **ppiVar2;
    int64_t var_18h;
    undefined auStack_58 [32];
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t var_10h;
    
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    ppiVar2 = (int64_t **)(arg2 + 8);
    ppiVar1 = (int64_t **)(arg1 + 0x20);
    if (*(char *)(arg1 + 0x40) == '\x02') {
        if (ppiVar1 != ppiVar2) {
            if (0xf < *(uint64_t *)(arg2 + 0x20)) {
                ppiVar2 = (int64_t **)*ppiVar2;
            }
            func_0x00018000f180(ppiVar1, ppiVar2, *(undefined8 *)(arg2 + 0x18));
        }
    } else {
        var_38h = 0x1804a5700;
        fcn.18000b4d0(&var_30h);
        func_0x00018016d700((undefined8 *)(arg1 + 0x18));
        *ppiVar1 = (int64_t *)var_30h;
        *(int64_t *)(arg1 + 0x28) = var_28h;
        *(int64_t *)(arg1 + 0x30) = var_20h;
        *(undefined8 *)(arg1 + 0x38) = uStack_18;
        *(undefined8 *)(arg1 + 0x18) = 0x1804a5710;
        *(undefined *)(arg1 + 0x40) = 2;
    }
    fcn.180459870(var_10h ^ (uint64_t)auStack_58);
    return;
}

// ============================================================
// Function: FUN_18016d1b0
// Address: 0x18016d1b0
// Size: 192 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18016d1b0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    code *pcVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_18h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t var_38h;
    int64_t var_20h;
    uint64_t uStack_18;
    
    puVar4 = auStack_58;
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2797, 0x1804a57d0);
    puVar2 = (undefined8 *)fcn.18016bb80(arg2, (int64_t)&var_38h, *(int64_t *)(arg1 + 0x48));
    if (0xf < (uint64_t)puVar2[3]) {
        puVar2 = (undefined8 *)*puVar2;
    }
    fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2726, puVar2);
    if (0xf < (uint64_t)var_20h) {
        iVar3 = var_38h;
        puVar4 = auStack_58;
        if ((0xfff < var_20h + 1U) &&
           (iVar3 = *(int64_t *)(var_38h + -8), puVar4 = auStack_58, 0x1f < (var_38h - iVar3) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar3 = (*pcVar1)(5);
            puVar4 = auStack_50;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18016d258;
        fcn.180459c3c(iVar3);
    }
    *(undefined8 *)(puVar4 + -8) = 0x18016d265;
    fcn.180459870(*(uint64_t *)(puVar4 + 0x40) ^ (uint64_t)puVar4);
    return;
}

// ============================================================
// Function: FUN_18016d2a0
// Address: 0x18016d2a0
// Size: 1068 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18016d2a0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    undefined8 uVar4;
    code *pcVar5;
    int64_t iVar6;
    undefined *puVar7;
    int64_t *piVar8;
    int64_t var_18h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_20h;
    uint64_t uStack_18;
    int64_t var_10h;
    
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    if (*(int64_t *)(arg2 + 0x10) != 0) {
        iVar6 = arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            iVar6 = *(int64_t *)arg2;
        }
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2729, iVar6);
        if (*(int64_t *)(arg2 + 0x30) != 0) {
            piVar8 = (int64_t *)(arg2 + 0x20);
            if (0xf < *(uint64_t *)(arg2 + 0x38)) {
                piVar8 = (int64_t *)*piVar8;
            }
            fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2766, piVar8);
        }
    }
    if (*(int64_t *)(arg2 + 0x50) == 0) {
        puVar7 = auStack_68;
        if (*(int64_t *)(arg2 + 0x70) != 0) {
            fcn.18000b4d0(&var_30h, arg2 + 0x60);
            var_48h = (int64_t)&var_30h;
            if (0xf < uStack_18) {
                var_48h = var_30h;
            }
            var_40h = var_20h;
            var_38h = 0;
            fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x9d64, &var_48h);
            if (*(int64_t *)(arg2 + 0x90) != 0) {
                piVar8 = (int64_t *)(arg2 + 0x80);
                if (0xf < *(uint64_t *)(arg2 + 0x98)) {
                    piVar8 = (int64_t *)*piVar8;
                }
                fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2768, piVar8);
            }
            if (*(int64_t *)(arg2 + 0xb0) != 0) {
                piVar8 = (int64_t *)(arg2 + 0xa0);
                if (0xf < *(uint64_t *)(arg2 + 0xb8)) {
                    piVar8 = (int64_t *)*piVar8;
                }
                fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x272a, piVar8);
            }
            puVar7 = auStack_68;
            if (0xf < uStack_18) {
                iVar6 = var_30h;
                puVar7 = auStack_68;
                if ((0xfff < uStack_18 + 1) &&
                   (iVar6 = *(int64_t *)(var_30h + -8), puVar7 = auStack_68, 0x1f < (var_30h - iVar6) - 8U)) {
                    pcVar5 = (code *)swi(0x29);
                    iVar6 = (*pcVar5)(5);
                    puVar7 = auStack_60;
                }
                *(undefined8 *)(puVar7 + -8) = 0x18016d489;
                fcn.180459c3c(iVar6);
            }
        }
    } else {
        piVar8 = (int64_t *)(arg2 + 0x40);
        if (0xf < *(uint64_t *)(arg2 + 0x58)) {
            piVar8 = (int64_t *)*piVar8;
        }
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2767, piVar8);
        if (*(int64_t *)(arg2 + 0x90) != 0) {
            piVar8 = (int64_t *)(arg2 + 0x80);
            if (0xf < *(uint64_t *)(arg2 + 0x98)) {
                piVar8 = (int64_t *)*piVar8;
            }
            fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x2768, piVar8);
        }
        puVar7 = auStack_68;
        if (*(int64_t *)(arg2 + 0xb0) != 0) {
            piVar8 = (int64_t *)(arg2 + 0xa0);
            if (0xf < *(uint64_t *)(arg2 + 0xb8)) {
                piVar8 = (int64_t *)*piVar8;
            }
            fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x272a, piVar8);
            puVar7 = auStack_68;
        }
    }
    if (*(int64_t *)(arg2 + 0xd0) != 0) {
        piVar8 = (int64_t *)(arg2 + 0xc0);
        if (0xf < *(uint64_t *)(arg2 + 0xd8)) {
            piVar8 = (int64_t *)*piVar8;
        }
        uVar4 = **(undefined8 **)(arg1 + 0x48);
        *(undefined8 *)(puVar7 + -8) = 0x18016d4b5;
        fcn.1804166c0(uVar4, 0x27f6, piVar8);
    }
    cVar1 = *(char *)(arg2 + 0xe0);
    uVar4 = **(undefined8 **)(arg1 + 0x48);
    *(undefined8 *)(puVar7 + -8) = 0x18016d4d4;
    fcn.1804166c0(uVar4, 0xe2, cVar1 != '\0');
    cVar1 = *(char *)(arg2 + 0xe2);
    uVar4 = **(undefined8 **)(arg1 + 0x48);
    *(undefined8 *)(puVar7 + -8) = 0x18016d4f3;
    fcn.1804166c0(uVar4, 0x40, cVar1 != '\0');
    cVar1 = *(char *)(arg2 + 0xe1);
    uVar4 = **(undefined8 **)(arg1 + 0x48);
    *(undefined8 *)(puVar7 + -8) = 0x18016d514;
    fcn.1804166c0(uVar4, 0x51, -(cVar1 != '\0') & 2);
    cVar1 = *(char *)(arg2 + 0xe3);
    uVar4 = **(undefined8 **)(arg1 + 0x48);
    *(undefined8 *)(puVar7 + -8) = 0x18016d533;
    fcn.1804166c0(uVar4, 0xe8, cVar1 != '\0');
    uVar2 = *(uint32_t *)(arg2 + 0xec);
    uVar3 = *(uint32_t *)(arg2 + 0xe4);
    uVar4 = **(undefined8 **)(arg1 + 0x48);
    *(undefined8 *)(puVar7 + -8) = 0x18016d552;
    fcn.1804166c0(uVar4, 0x20, uVar2 | uVar3);
    if (*(char *)(arg2 + 0xe8) != '\0') {
        uVar4 = **(undefined8 **)(arg1 + 0x48);
        *(undefined8 *)(puVar7 + -8) = 0x18016d572;
        fcn.1804166c0(uVar4, 0xd8, 2);
    }
    if (*(int64_t *)(arg2 + 0x100) != 0) {
        piVar8 = (int64_t *)(arg2 + 0xf0);
        if (0xf < *(uint64_t *)(arg2 + 0x108)) {
            piVar8 = (int64_t *)*piVar8;
        }
        uVar4 = **(undefined8 **)(arg1 + 0x48);
        *(undefined8 *)(puVar7 + -8) = 0x18016d59e;
        fcn.1804166c0(uVar4, 0x2751, piVar8);
    }
    if (*(int64_t *)(arg2 + 0x120) != 0) {
        piVar8 = (int64_t *)(arg2 + 0x110);
        if (0xf < *(uint64_t *)(arg2 + 0x128)) {
            piVar8 = (int64_t *)*piVar8;
        }
        uVar4 = **(undefined8 **)(arg1 + 0x48);
        *(undefined8 *)(puVar7 + -8) = 0x18016d5ca;
        fcn.1804166c0(uVar4, 0x2771, piVar8);
    }
    if (*(int64_t *)(arg2 + 0x140) != 0) {
        uVar4 = **(undefined8 **)(arg1 + 0x48);
        *(undefined8 *)(puVar7 + -8) = 0x18016d5ec;
        fcn.1804166c0(uVar4, 0x4e8c, 0x1801722c0);
        piVar8 = (int64_t *)(arg2 + 0x130);
        if (0xf < *(uint64_t *)(arg2 + 0x148)) {
            piVar8 = (int64_t *)*piVar8;
        }
        uVar4 = **(undefined8 **)(arg1 + 0x48);
        *(undefined8 *)(puVar7 + -8) = 0x18016d60e;
        fcn.1804166c0(uVar4, 0x277d, piVar8);
    }
    if (*(int64_t *)(arg2 + 0x160) != 0) {
        piVar8 = (int64_t *)(arg2 + 0x150);
        if (0xf < *(uint64_t *)(arg2 + 0x168)) {
            piVar8 = (int64_t *)*piVar8;
        }
        uVar4 = **(undefined8 **)(arg1 + 0x48);
        *(undefined8 *)(puVar7 + -8) = 0x18016d63a;
        fcn.1804166c0(uVar4, 0x27b9, piVar8);
    }
    if (*(int64_t *)(arg2 + 0x180) != 0) {
        piVar8 = (int64_t *)(arg2 + 0x170);
        if (0xf < *(uint64_t *)(arg2 + 0x188)) {
            piVar8 = (int64_t *)*piVar8;
        }
        uVar4 = **(undefined8 **)(arg1 + 0x48);
        *(undefined8 *)(puVar7 + -8) = 0x18016d666;
        fcn.1804166c0(uVar4, 0x2763, piVar8);
    }
    if (*(int64_t *)(arg2 + 0x1a0) != 0) {
        piVar8 = (int64_t *)(arg2 + 0x170);
        if (0xf < *(uint64_t *)(arg2 + 0x188)) {
            piVar8 = (int64_t *)*piVar8;
        }
        uVar4 = **(undefined8 **)(arg1 + 0x48);
        *(undefined8 *)(puVar7 + -8) = 0x18016d692;
        fcn.1804166c0(uVar4, 0x2824, piVar8);
    }
    cVar1 = *(char *)(arg2 + 0x1b0);
    uVar4 = **(undefined8 **)(arg1 + 0x48);
    *(undefined8 *)(puVar7 + -8) = 0x18016d6b1;
    fcn.1804166c0(uVar4, 0x96, cVar1 != '\0');
    *(undefined8 *)(puVar7 + -8) = 0x18016d6be;
    fcn.180459870(*(uint64_t *)(puVar7 + 0x58) ^ (uint64_t)puVar7);
    return;
}

// ============================================================
// Function: FUN_18016d6d0
// Address: 0x18016d6d0
// Size: 47 bytes
// ============================================================
void fcn.18016d6d0(int64_t arg1)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    
    iVar1 = *(int64_t *)(arg1 + 0x10);
    if (iVar1 == 0) {
        return;
    }
    func_0x0001801705f0(iVar1);
    if ((iVar1 != 0) &&
       (iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar1, in_R9, unaff_RBX), iVar3 == 0)) {
        uVar4 = (*(code *)0x699ff6)();
        uVar4 = fcn.18046b63c(uVar4);
        puVar2 = (undefined4 *)fcn.18046b77c();
        *puVar2 = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_18016d700
// Address: 0x18016d700
// Size: 99 bytes
// ============================================================
void fcn.18016d700(int64_t arg1)
{
    char cVar1;
    int64_t in_stack_00000008;
    int64_t in_stack_00000020;
    
    cVar1 = *(char *)(arg1 + 0x28);
    if ((cVar1 == -1) || (cVar1 == '\0')) {
        *(undefined *)(arg1 + 0x28) = 0xff;
        return;
    }
    if (cVar1 == '\x01') {
        fcn.180084ec0(in_stack_00000008);
        *(undefined *)(arg1 + 0x28) = 0xff;
        return;
    }
    if (cVar1 != '\x02') {
        fcn.180085150(in_stack_00000020);
        *(undefined *)(arg1 + 0x28) = 0xff;
        return;
    }
    (***(code ***)arg1)(arg1, 0);
    *(undefined *)(arg1 + 0x28) = 0xff;
    return;
}

// ============================================================
// Function: FUN_18016d770
// Address: 0x18016d770
// Size: 268 bytes
// ============================================================
int64_t fcn.18016d770(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    int64_t var_50h;
    int64_t var_48h;
    
    ppiVar4 = *(int64_t ***)
               (*(int64_t *)(arg1 + 0x168) + (*(int64_t *)(arg1 + 0x170) - 1U & *(uint64_t *)(arg1 + 0x178)) * 8);
    if (ppiVar4[1] != (int64_t *)0x0) {
        LOCK();
        piVar5 = ppiVar4[1] + 1;
        *(int32_t *)piVar5 = *(int32_t *)piVar5 + 1;
        UNLOCK();
    }
    piVar5 = *ppiVar4;
    piVar6 = ppiVar4[1];
    piVar7 = *(int64_t **)
              (*(int64_t *)
                (*(int64_t *)(arg1 + 0x168) + (*(int64_t *)(arg1 + 0x170) - 1U & *(uint64_t *)(arg1 + 0x178)) * 8) + 8);
    if (piVar7 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar7 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar7)(piVar7);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar7 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar7 + 8))(piVar7);
            }
        }
    }
    piVar7 = (int64_t *)(arg1 + 0x180);
    *piVar7 = *piVar7 + -1;
    if (*piVar7 == 0) {
        *(undefined8 *)(arg1 + 0x178) = 0;
    } else {
        *(int64_t *)(arg1 + 0x178) = *(int64_t *)(arg1 + 0x178) + 1;
    }
    (**(code **)(*piVar5 + 8))(piVar5, arg2, arg1);
    if (piVar6 != (int64_t *)0x0) {
        LOCK();
        piVar5 = piVar6 + 1;
        iVar3 = *(int32_t *)piVar5;
        *(int32_t *)piVar5 = *(int32_t *)piVar5 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar6)(piVar6);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar6 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar6 + 8))(piVar6);
            }
        }
    }
    return arg2;
}

// ============================================================
// Function: FUN_18016d880
// Address: 0x18016d880
// Size: 230 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18016d880(int64_t arg1, int64_t arg_40h, int64_t arg_48h)
{
    char cVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 *puVar6;
    int64_t *piVar7;
    undefined *puVar8;
    undefined8 *puVar9;
    undefined8 *puVar10;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_78 [8];
    undefined auStackY_70 [24];
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar8 = auStackY_78;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_78;
    cVar1 = *(char *)(arg1 + 0x40);
    if (cVar1 == '\x01') {
        if (*(char *)(arg1 + 0x40) != '\x01') {
            fcn.180016af0();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        fcn.180171250(arg1 + 0x18, &var_48h, *(undefined8 *)(arg1 + 0x48));
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x75a8, var_38h);
        piVar7 = &var_48h;
        if (0xf < (uint64_t)var_30h) {
            piVar7 = (int64_t *)var_48h;
        }
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x27b5, piVar7);
        if (0xf < (uint64_t)var_30h) {
            if (0xfff < var_30h + 1U) {
                if ((var_48h - *(int64_t *)(var_48h + -8)) - 8U < 0x20) {
                    fcn.180459c3c(*(int64_t *)(var_48h + -8), var_30h + 0x28);
                    fcn.180459870(var_28h ^ (uint64_t)auStackY_78);
                    return;
                }
                pcVar3 = (code *)swi(0x29);
                var_48h = (*pcVar3)(5);
                puVar8 = auStackY_70;
            }
            *(undefined8 *)(puVar8 + -8) = 0x18016d953;
            fcn.180459c3c(var_48h);
            *(undefined8 *)(puVar8 + -8) = 0x18016d960;
            fcn.180459870(*(uint64_t *)(puVar8 + 0x50) ^ (uint64_t)puVar8);
            return;
        }
    } else if (cVar1 == '\x02') {
        piVar7 = (int64_t *)(arg1 + 0x20);
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x75a8, *(undefined8 *)(arg1 + 0x30));
        if (0xf < *(uint64_t *)(arg1 + 0x38)) {
            piVar7 = (int64_t *)*piVar7;
        }
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x27b5, piVar7);
    } else if (cVar1 == '\x03') {
        if (*(int64_t *)(*(int64_t *)(arg1 + 0x48) + 0x18) != 0) {
            fcn.180412b80();
        }
        uVar5 = fcn.180412c60(**(undefined8 **)(arg1 + 0x48));
        *(undefined8 *)(*(int64_t *)(arg1 + 0x48) + 0x18) = uVar5;
        if (*(char *)(arg1 + 0x40) != '\x03') {
            fcn.180016af0();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        puVar9 = *(undefined8 **)(arg1 + 0x18);
        puVar2 = *(undefined8 **)(arg1 + 0x20);
        if (puVar9 != puVar2) {
            puVar10 = puVar9 + 4;
            do {
                if (*(char *)(puVar9 + 0xe) == '\0') {
                    uVar5 = fcn.180412740(*(undefined8 *)(*(int64_t *)(arg1 + 0x48) + 0x18));
                    if (puVar9[10] != 0) {
                        piVar7 = puVar9 + 8;
                        if (0xf < (uint64_t)puVar9[0xb]) {
                            piVar7 = (int64_t *)*piVar7;
                        }
                        fcn.180412e40(uVar5, piVar7);
                    }
                    if (*(char *)((int64_t)puVar9 + 0x71) == '\0') {
                        puVar6 = puVar9;
                        if (0xf < (uint64_t)puVar9[3]) {
                            puVar6 = (undefined8 *)*puVar9;
                        }
                        fcn.180412d00(uVar5, puVar6);
                        puVar6 = puVar10;
                        if (0xf < (uint64_t)puVar10[3]) {
                            puVar6 = (undefined8 *)*puVar10;
                        }
                        fcn.180412800(uVar5, puVar6, 0xffffffffffffffff);
                    } else {
                        puVar6 = puVar9;
                        if (0xf < (uint64_t)puVar9[3]) {
                            puVar6 = (undefined8 *)*puVar9;
                        }
                        fcn.180412d00(uVar5, puVar6);
                        fcn.180412800(uVar5, puVar9[0xc], puVar9[0xd]);
                        puVar6 = puVar10;
                        if (0xf < (uint64_t)puVar10[3]) {
                            puVar6 = (undefined8 *)*puVar10;
                        }
                        fcn.180412b10(uVar5, puVar6);
                    }
                } else {
                    fcn.180171230(puVar9 + 0xf, &var_58h);
                    fcn.180171240(puVar9 + 0xf, &var_50h);
                    if (var_58h != var_50h) {
                        do {
                            iVar4 = var_58h;
                            uVar5 = fcn.180412740(*(undefined8 *)(*(int64_t *)(arg1 + 0x48) + 0x18));
                            if (puVar9[10] != 0) {
                                piVar7 = puVar9 + 8;
                                if (0xf < (uint64_t)puVar9[0xb]) {
                                    piVar7 = (int64_t *)*piVar7;
                                }
                                fcn.180412e40(uVar5, piVar7);
                            }
                            fcn.180412950(var_58h);
                            puVar6 = puVar9;
                            if (0xf < (uint64_t)puVar9[3]) {
                                puVar6 = (undefined8 *)*puVar9;
                            }
                            fcn.180412d00(uVar5, puVar6);
                            if (*(int64_t *)(iVar4 + 0x30) != 0) {
                                piVar7 = (int64_t *)(iVar4 + 0x20);
                                if (0xf < *(uint64_t *)(iVar4 + 0x38)) {
                                    piVar7 = (int64_t *)*piVar7;
                                }
                                fcn.180412b10(uVar5, piVar7);
                            }
                            var_58h = var_58h + 0x40;
                        } while (var_58h != var_50h);
                    }
                }
                puVar9 = puVar9 + 0x12;
                puVar10 = puVar10 + 0x12;
            } while (puVar9 != puVar2);
        }
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x281d, (*(undefined8 **)(arg1 + 0x48))[3]);
    }
    fcn.180459870(var_28h ^ (uint64_t)auStackY_78);
    return;
}

// ============================================================
// Function: FUN_18016d966
// Address: 0x18016d966
// Size: 75 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18016d880(int64_t arg1, int64_t arg_40h, int64_t arg_48h)
{
    char cVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 *puVar6;
    int64_t *piVar7;
    undefined *puVar8;
    undefined8 *puVar9;
    undefined8 *puVar10;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_78 [8];
    undefined auStackY_70 [24];
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar8 = auStackY_78;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_78;
    cVar1 = *(char *)(arg1 + 0x40);
    if (cVar1 == '\x01') {
        if (*(char *)(arg1 + 0x40) != '\x01') {
            fcn.180016af0();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        fcn.180171250(arg1 + 0x18, &var_48h, *(undefined8 *)(arg1 + 0x48));
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x75a8, var_38h);
        piVar7 = &var_48h;
        if (0xf < (uint64_t)var_30h) {
            piVar7 = (int64_t *)var_48h;
        }
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x27b5, piVar7);
        if (0xf < (uint64_t)var_30h) {
            if (0xfff < var_30h + 1U) {
                if ((var_48h - *(int64_t *)(var_48h + -8)) - 8U < 0x20) {
                    fcn.180459c3c(*(int64_t *)(var_48h + -8), var_30h + 0x28);
                    fcn.180459870(var_28h ^ (uint64_t)auStackY_78);
                    return;
                }
                pcVar3 = (code *)swi(0x29);
                var_48h = (*pcVar3)(5);
                puVar8 = auStackY_70;
            }
            *(undefined8 *)(puVar8 + -8) = 0x18016d953;
            fcn.180459c3c(var_48h);
            *(undefined8 *)(puVar8 + -8) = 0x18016d960;
            fcn.180459870(*(uint64_t *)(puVar8 + 0x50) ^ (uint64_t)puVar8);
            return;
        }
    } else if (cVar1 == '\x02') {
        piVar7 = (int64_t *)(arg1 + 0x20);
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x75a8, *(undefined8 *)(arg1 + 0x30));
        if (0xf < *(uint64_t *)(arg1 + 0x38)) {
            piVar7 = (int64_t *)*piVar7;
        }
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x27b5, piVar7);
    } else if (cVar1 == '\x03') {
        if (*(int64_t *)(*(int64_t *)(arg1 + 0x48) + 0x18) != 0) {
            fcn.180412b80();
        }
        uVar5 = fcn.180412c60(**(undefined8 **)(arg1 + 0x48));
        *(undefined8 *)(*(int64_t *)(arg1 + 0x48) + 0x18) = uVar5;
        if (*(char *)(arg1 + 0x40) != '\x03') {
            fcn.180016af0();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        puVar9 = *(undefined8 **)(arg1 + 0x18);
        puVar2 = *(undefined8 **)(arg1 + 0x20);
        if (puVar9 != puVar2) {
            puVar10 = puVar9 + 4;
            do {
                if (*(char *)(puVar9 + 0xe) == '\0') {
                    uVar5 = fcn.180412740(*(undefined8 *)(*(int64_t *)(arg1 + 0x48) + 0x18));
                    if (puVar9[10] != 0) {
                        piVar7 = puVar9 + 8;
                        if (0xf < (uint64_t)puVar9[0xb]) {
                            piVar7 = (int64_t *)*piVar7;
                        }
                        fcn.180412e40(uVar5, piVar7);
                    }
                    if (*(char *)((int64_t)puVar9 + 0x71) == '\0') {
                        puVar6 = puVar9;
                        if (0xf < (uint64_t)puVar9[3]) {
                            puVar6 = (undefined8 *)*puVar9;
                        }
                        fcn.180412d00(uVar5, puVar6);
                        puVar6 = puVar10;
                        if (0xf < (uint64_t)puVar10[3]) {
                            puVar6 = (undefined8 *)*puVar10;
                        }
                        fcn.180412800(uVar5, puVar6, 0xffffffffffffffff);
                    } else {
                        puVar6 = puVar9;
                        if (0xf < (uint64_t)puVar9[3]) {
                            puVar6 = (undefined8 *)*puVar9;
                        }
                        fcn.180412d00(uVar5, puVar6);
                        fcn.180412800(uVar5, puVar9[0xc], puVar9[0xd]);
                        puVar6 = puVar10;
                        if (0xf < (uint64_t)puVar10[3]) {
                            puVar6 = (undefined8 *)*puVar10;
                        }
                        fcn.180412b10(uVar5, puVar6);
                    }
                } else {
                    fcn.180171230(puVar9 + 0xf, &var_58h);
                    fcn.180171240(puVar9 + 0xf, &var_50h);
                    if (var_58h != var_50h) {
                        do {
                            iVar4 = var_58h;
                            uVar5 = fcn.180412740(*(undefined8 *)(*(int64_t *)(arg1 + 0x48) + 0x18));
                            if (puVar9[10] != 0) {
                                piVar7 = puVar9 + 8;
                                if (0xf < (uint64_t)puVar9[0xb]) {
                                    piVar7 = (int64_t *)*piVar7;
                                }
                                fcn.180412e40(uVar5, piVar7);
                            }
                            fcn.180412950(var_58h);
                            puVar6 = puVar9;
                            if (0xf < (uint64_t)puVar9[3]) {
                                puVar6 = (undefined8 *)*puVar9;
                            }
                            fcn.180412d00(uVar5, puVar6);
                            if (*(int64_t *)(iVar4 + 0x30) != 0) {
                                piVar7 = (int64_t *)(iVar4 + 0x20);
                                if (0xf < *(uint64_t *)(iVar4 + 0x38)) {
                                    piVar7 = (int64_t *)*piVar7;
                                }
                                fcn.180412b10(uVar5, piVar7);
                            }
                            var_58h = var_58h + 0x40;
                        } while (var_58h != var_50h);
                    }
                }
                puVar9 = puVar9 + 0x12;
                puVar10 = puVar10 + 0x12;
            } while (puVar9 != puVar2);
        }
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x281d, (*(undefined8 **)(arg1 + 0x48))[3]);
    }
    fcn.180459870(var_28h ^ (uint64_t)auStackY_78);
    return;
}

// ============================================================
// Function: FUN_18016d9b1
// Address: 0x18016d9b1
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18016d880(int64_t arg1, int64_t arg_40h, int64_t arg_48h)
{
    char cVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int64_t iVar4;
    undefined8 uVar5;
    undefined8 *puVar6;
    int64_t *piVar7;
    undefined *puVar8;
    undefined8 *puVar9;
    undefined8 *puVar10;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_78 [8];
    undefined auStackY_70 [24];
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar8 = auStackY_78;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_78;
    cVar1 = *(char *)(arg1 + 0x40);
    if (cVar1 == '\x01') {
        if (*(char *)(arg1 + 0x40) != '\x01') {
            fcn.180016af0();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        fcn.180171250(arg1 + 0x18, &var_48h, *(undefined8 *)(arg1 + 0x48));
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x75a8, var_38h);
        piVar7 = &var_48h;
        if (0xf < (uint64_t)var_30h) {
            piVar7 = (int64_t *)var_48h;
        }
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x27b5, piVar7);
        if (0xf < (uint64_t)var_30h) {
            if (0xfff < var_30h + 1U) {
                if ((var_48h - *(int64_t *)(var_48h + -8)) - 8U < 0x20) {
                    fcn.180459c3c(*(int64_t *)(var_48h + -8), var_30h + 0x28);
                    fcn.180459870(var_28h ^ (uint64_t)auStackY_78);
                    return;
                }
                pcVar3 = (code *)swi(0x29);
                var_48h = (*pcVar3)(5);
                puVar8 = auStackY_70;
            }
            *(undefined8 *)(puVar8 + -8) = 0x18016d953;
            fcn.180459c3c(var_48h);
            *(undefined8 *)(puVar8 + -8) = 0x18016d960;
            fcn.180459870(*(uint64_t *)(puVar8 + 0x50) ^ (uint64_t)puVar8);
            return;
        }
    } else if (cVar1 == '\x02') {
        piVar7 = (int64_t *)(arg1 + 0x20);
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x75a8, *(undefined8 *)(arg1 + 0x30));
        if (0xf < *(uint64_t *)(arg1 + 0x38)) {
            piVar7 = (int64_t *)*piVar7;
        }
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x27b5, piVar7);
    } else if (cVar1 == '\x03') {
        if (*(int64_t *)(*(int64_t *)(arg1 + 0x48) + 0x18) != 0) {
            fcn.180412b80();
        }
        uVar5 = fcn.180412c60(**(undefined8 **)(arg1 + 0x48));
        *(undefined8 *)(*(int64_t *)(arg1 + 0x48) + 0x18) = uVar5;
        if (*(char *)(arg1 + 0x40) != '\x03') {
            fcn.180016af0();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        puVar9 = *(undefined8 **)(arg1 + 0x18);
        puVar2 = *(undefined8 **)(arg1 + 0x20);
        if (puVar9 != puVar2) {
            puVar10 = puVar9 + 4;
            do {
                if (*(char *)(puVar9 + 0xe) == '\0') {
                    uVar5 = fcn.180412740(*(undefined8 *)(*(int64_t *)(arg1 + 0x48) + 0x18));
                    if (puVar9[10] != 0) {
                        piVar7 = puVar9 + 8;
                        if (0xf < (uint64_t)puVar9[0xb]) {
                            piVar7 = (int64_t *)*piVar7;
                        }
                        fcn.180412e40(uVar5, piVar7);
                    }
                    if (*(char *)((int64_t)puVar9 + 0x71) == '\0') {
                        puVar6 = puVar9;
                        if (0xf < (uint64_t)puVar9[3]) {
                            puVar6 = (undefined8 *)*puVar9;
                        }
                        fcn.180412d00(uVar5, puVar6);
                        puVar6 = puVar10;
                        if (0xf < (uint64_t)puVar10[3]) {
                            puVar6 = (undefined8 *)*puVar10;
                        }
                        fcn.180412800(uVar5, puVar6, 0xffffffffffffffff);
                    } else {
                        puVar6 = puVar9;
                        if (0xf < (uint64_t)puVar9[3]) {
                            puVar6 = (undefined8 *)*puVar9;
                        }
                        fcn.180412d00(uVar5, puVar6);
                        fcn.180412800(uVar5, puVar9[0xc], puVar9[0xd]);
                        puVar6 = puVar10;
                        if (0xf < (uint64_t)puVar10[3]) {
                            puVar6 = (undefined8 *)*puVar10;
                        }
                        fcn.180412b10(uVar5, puVar6);
                    }
                } else {
                    fcn.180171230(puVar9 + 0xf, &var_58h);
                    fcn.180171240(puVar9 + 0xf, &var_50h);
                    if (var_58h != var_50h) {
                        do {
                            iVar4 = var_58h;
                            uVar5 = fcn.180412740(*(undefined8 *)(*(int64_t *)(arg1 + 0x48) + 0x18));
                            if (puVar9[10] != 0) {
                                piVar7 = puVar9 + 8;
                                if (0xf < (uint64_t)puVar9[0xb]) {
                                    piVar7 = (int64_t *)*piVar7;
                                }
                                fcn.180412e40(uVar5, piVar7);
                            }
                            fcn.180412950(var_58h);
                            puVar6 = puVar9;
                            if (0xf < (uint64_t)puVar9[3]) {
                                puVar6 = (undefined8 *)*puVar9;
                            }
                            fcn.180412d00(uVar5, puVar6);
                            if (*(int64_t *)(iVar4 + 0x30) != 0) {
                                piVar7 = (int64_t *)(iVar4 + 0x20);
                                if (0xf < *(uint64_t *)(iVar4 + 0x38)) {
                                    piVar7 = (int64_t *)*piVar7;
                                }
                                fcn.180412b10(uVar5, piVar7);
                            }
                            var_58h = var_58h + 0x40;
                        } while (var_58h != var_50h);
                    }
                }
                puVar9 = puVar9 + 0x12;
                puVar10 = puVar10 + 0x12;
            } while (puVar9 != puVar2);
        }
        fcn.1804166c0(**(undefined8 **)(arg1 + 0x48), 0x281d, (*(undefined8 **)(arg1 + 0x48))[3]);
    }
    fcn.180459870(var_28h ^ (uint64_t)auStackY_78);
    return;
}

